/**
 * **El orden de una transición de relaciones, DEMOSTRADO por fuerza bruta** (plan 2.5 · lote D · cierre 2 de D2, 🟡 N3;
 * linaje L10 promovido). Sin servidor y sin base: `tests/helpers/order_bruteforce.ts` recorre TODOS los pares (inicial,
 * final) de un universo pequeño —y una muestra con semilla de dos universos mayores— y, en CADA prefijo del orden que da
 * `relationTransitionOrder`, comprueba:
 *
 *   concedido(prefijo) ⊆ concedido(inicial) ∪ concedido(final), y ningún sujeto denegado en los dos concede.
 *
 * La garantía que se demuestra (README «Denies migrate as denies»): **un par cuyo grafo de precedencias no tiene ciclo
 * (`residue` vacío) no concede en ningún prefijo**; el residuo es el ciclo y se mide cuánto de él NO admite ningún orden
 * seguro (inherente). Las cifras están FIJADAS: cambiar el orden cambia las cifras y pone rojo este spec — se re-miden y
 * se reescriben README/CHANGELOG/informe. También fija por qué se DESCARTARON el orden del cierre 1 de D2 y el candidato
 * del brief (cada uno con su contraejemplo).
 */
import { test } from '@japa/runner'
import { bruteForce, ORDER_CUTS, oracle, packageOrder, pick, universe, walkPair } from './helpers/order_bruteforce.js'
import type { OrderFn } from './helpers/order_bruteforce.js'
import type { RelationOrderView } from '../src/relations/tuple_order.js'
import { denyCarrierGroups } from '../src/relations/tuple_order.js'

const isMembership = (v: RelationOrderView) => !v.deny && v.object.startsWith('group:')
const by = (a: RelationOrderView, b: RelationOrderView) => (a.object + a.user < b.object + b.user ? -1 : 1)

/** El orden del CIERRE 1 de D2: todas las escrituras (denies → portadoras → membresías → allows) y luego toda la poda. */
const closure1: OrderFn = ({ writes, deletes, context }) => {
  const carriers = denyCarrierGroups([...context, ...writes, ...deletes])
  const w = (v: RelationOrderView) => (v.deny ? 0 : isMembership(v) ? (carriers.has(v.object) ? 1 : 2) : 3)
  const d = (v: RelationOrderView) => (v.deny ? 3 : isMembership(v) ? (carriers.has(v.object) ? 2 : 1) : 0)
  return {
    steps: [
      ...[...writes].sort((a, b) => w(a) - w(b) || by(a, b)).map((item) => ({ item, op: 'write' as const })),
      ...[...deletes].sort((a, b) => d(a) - d(b) || by(a, b)).map((item) => ({ item, op: 'delete' as const })),
    ],
    residue: [],
  }
}

/** El CANDIDATO del brief: denies → allows sobrantes → membresías nuevas → membresías sobrantes → allows → denies sobrantes. */
const briefCandidate: OrderFn = ({ writes, deletes, context }) => {
  const carriers = denyCarrierGroups([...context, ...writes, ...deletes])
  const rank = (v: RelationOrderView, op: 'write' | 'delete') =>
    op === 'write'
      ? v.deny ? 0 : isMembership(v) ? (carriers.has(v.object) ? 2 : 2.5) : 4
      : v.deny ? 5 : isMembership(v) ? (carriers.has(v.object) ? 3.5 : 3) : 1
  const steps = [...writes.map((item) => ({ item, op: 'write' as const })), ...deletes.map((item) => ({ item, op: 'delete' as const }))]
  return { steps: steps.sort((a, b) => rank(a.item, a.op) - rank(b.item, b.op) || by(a.item, b.item)), residue: [] }
}

test.group('relations · orden de transición · demostración por fuerza bruta (cierre 2 de D2 · 🟡 N3, L10)', () => {
  test('el oráculo rápido decide lo MISMO que cutPathAllows del paquete en las 1 024 máscaras de E1', ({ assert }) => {
    const views = universe('E1')
    const fast = oracle(views)
    const pkg = oracle(views, { package: true })
    assert.deepEqual([...fast.granted], [...pkg.granted])
    assert.deepEqual([...fast.denied], [...pkg.denied])
  })

  test('E1 EXHAUSTIVO (10 tuplas · 4^10 pares × {--prune, sin --prune} = 2 097 152): sin residuo, ningún prefijo concede; cifras fijadas', ({ assert }) => {
    const r = bruteForce('E1', packageOrder(ORDER_CUTS))
    console.log(`  E1 exhaustivo: ${JSON.stringify({ ...r, examples: undefined })}\n  ${r.examples.join('\n  ')}`)
    assert.equal(r.pairs, 2_097_152)
    assert.equal(r.malformed, 0, 'el orden es una permutación del diff y llega al final')
    assert.equal(r.unsafeWithoutResidue, 0, `ROJO (L10): un par SIN residuo concede en un prefijo — ${r.examples.join(' ;; ')}`)
    assert.deepEqual(
      { residuePairs: r.residuePairs, unsafe: r.unsafe, inherent: r.inherent },
      { residuePairs: 4560, unsafe: 828, inherent: 352 },
      'cifras del residuo (re-mídelas y reescribe README/CHANGELOG/informe si el orden cambia)'
    )
  }).timeout(180_000)

  test('U2 (el universo del brief: 2 usuarios, 2 grupos con 1 nivel, 2 objetos, allows y denies directos y por grupo; 21 tuplas) · MUESTRA de 30 000 pares por modo: sin residuo, ningún prefijo concede', ({ assert }) => {
    const r = bruteForce('U2', packageOrder(ORDER_CUTS), { sample: 30_000 })
    console.log(`  U2 muestra: ${JSON.stringify({ ...r, examples: undefined })}`)
    assert.equal(r.malformed, 0)
    assert.equal(r.unsafeWithoutResidue, 0, `ROJO (L10): ${r.examples.join(' ;; ')}`)
    assert.deepEqual({ residuePairs: r.residuePairs, unsafe: r.unsafe, inherent: r.inherent }, { residuePairs: 233, unsafe: 9, inherent: 0 })
  }).timeout(180_000)

  test('E3 (3 grupos con DOS niveles de anidamiento, 20 tuplas) · MUESTRA de 30 000 pares por modo: sin residuo, ningún prefijo concede', ({ assert }) => {
    const r = bruteForce('E3', packageOrder(ORDER_CUTS), { sample: 30_000 })
    console.log(`  E3 muestra: ${JSON.stringify({ ...r, examples: undefined })}`)
    assert.equal(r.malformed, 0)
    assert.equal(r.unsafeWithoutResidue, 0, `ROJO (L10): ${r.examples.join(' ;; ')}`)
    assert.deepEqual({ residuePairs: r.residuePairs, unsafe: r.unsafe, inherent: r.inherent }, { residuePairs: 842, unsafe: 7, inherent: 0 })
  }).timeout(180_000)

  test('SIN la config del destino (sin el predicado del auto-corte) el orden sigue siendo SEGURO fuera del residuo — solo es más conservador (E1-reduced exhaustivo)', ({ assert }) => {
    const r = bruteForce('E1-reduced', packageOrder(undefined))
    assert.equal(r.malformed, 0)
    assert.equal(r.unsafeWithoutResidue, 0, `ROJO (L10): ${r.examples.join(' ;; ')}`)
    const withCuts = bruteForce('E1-reduced', packageOrder(ORDER_CUTS))
    assert.isAbove(r.residuePairs, withCuts.residuePairs, 'sin el auto-corte hay MÁS residuo (más precedencias), nunca menos garantía')
  }).timeout(60_000)

  test('DESCARTADOS: el orden del cierre 1 (escrituras y luego poda) y el candidato del brief conceden SIN residuo — cada uno con su contraejemplo', ({ assert }) => {
    const c1 = bruteForce('E1-reduced', closure1, { maxExamples: 1 })
    const brief = bruteForce('E1-reduced', briefCandidate, { maxExamples: 1 })
    console.log(`  cierre 1: ${c1.unsafeWithoutResidue} pares · ${c1.examples[0]}\n  candidato del brief: ${brief.unsafeWithoutResidue} pares · ${brief.examples[0]}`)
    assert.isAbove(c1.unsafeWithoutResidue, 0, 'el orden del cierre 1 concede (🟡 N3: el ex-miembro compone con el allow nuevo)')
    assert.isAbove(brief.unsafeWithoutResidue, 0, 'el candidato del brief concede (composición ANIDADA: U ∈ h nuevo y h ⊂ g sobrante)')
    // Los contraejemplos, literales (los del informe): C2 del auditor (🟡 N3) descarta el cierre 1; la composición ANIDADA
    // descarta el candidato del brief; el orden del paquete pasa los dos.
    const c2 = [pick('E1-reduced', 'g@u1'), pick('E1-reduced', 'x@g#member')] as const
    assert.equal(walkPair('E1-reduced', closure1, ...c2).bad, 1, 'C2: U ∈ g sobra, g#member viewer X es nuevo, --prune ⇒ concede tras la 1.ª escritura')
    assert.isNull(walkPair('E1-reduced', packageOrder(ORDER_CUTS), ...c2).bad)
    const nested = [pick('E1-reduced', 'g@h#member', 'x@g#member'), pick('E1-reduced', 'h@u1', 'x@g#member')] as const
    assert.equal(walkPair('E1-reduced', briefCandidate, ...nested).bad, 1, 'anidada: U ∈ h nuevo antes de borrar h ⊂ g ⇒ U alcanza el allow de g')
    assert.isNull(walkPair('E1-reduced', packageOrder(ORDER_CUTS), ...nested).bad)
    // 🟡 N2 (el otro grupo solo transporta un deny): el orden del cierre 1 concedía; el del paquete no.
    const n2 = [pick('E1-reduced', 'x@g#member', '¬y@g#member', '¬x@h#member'), pick('E1-reduced', 'g@u1', 'h@u1', 'x@g#member', '¬y@g#member', '¬x@h#member')] as const
    assert.equal(walkPair('E1-reduced', closure1, ...n2).bad, 1, 'N2: la portadora de g (mixto) va antes que la de h (solo deny)')
    assert.isNull(walkPair('E1-reduced', packageOrder(ORDER_CUTS), ...n2).bad)
  }).timeout(60_000)

  test('el RESIDUO es real: el cruce de dos grupos (cada uno deniega lo que el otro concede) no admite NINGÚN orden seguro', ({ assert }) => {
    const r = bruteForce('E1-reduced', packageOrder(ORDER_CUTS), { maxExamples: 1 })
    assert.isAbove(r.inherent, 0)
    assert.match(r.examples[0], /sin orden seguro/)
    assert.include(r.examples[0], 'residuo [')
    assert.notInclude(r.examples[0], 'residuo []')
    console.log(`  residuo inherente: ${r.examples[0]}`)
  }).timeout(60_000)
})
