/**
 * **La demostración por FUERZA BRUTA del orden de una transición de relaciones** (plan 2.5 · lote D · cierre 2 de D2,
 * 🟡 N3; linaje L10). Sin servidor, sin base: el universo es un conjunto pequeño de tuplas en la forma del STORE y el
 * oráculo es el corte de camino (D5) de UNA relación con deny (`viewer`): concede ⇔ algún allow alcanza al sujeto
 * (directo o por `group#member`, anidado) y ningún deny lo alcanza. Para cada par (inicial, final) —el final es el ORIGEN
 * con `--prune` y la UNIÓN sin él— se pide a `relationTransitionOrder` el orden del diff y se recorre CADA prefijo:
 *
 *   concedido(prefijo) ⊆ concedido(inicial) ∪ concedido(final), y ningún sujeto denegado en los dos concede.
 *
 * Además, para cada par en el que el orden concede, se mide si EXISTÍA algún orden seguro (programación dinámica sobre el
 * retículo de subconjuntos del diff): así se sabe qué parte del residuo es inherente.
 *
 * Lo usan la propiedad `relations.order.exhaustive` de la guardia de superficie (universo reducido, en cada mutante) y
 * `tests/relations_order_exhaustive.spec.ts` (los universos completos, con sus cifras y su tiempo).
 */
import { cutPathAllows, defineRelationsConfig, relationsUp } from '../../src/relations/define_relations_config.js'
import { relationTransitionOrder } from '../../src/relations/tuple_order.js'
import type { RelationCuts, RelationOrderView } from '../../src/relations/tuple_order.js'

export type UniverseName = 'E1' | 'E1-reduced' | 'U2' | 'E3'

const U1 = 'user:u1'
const U2 = 'user:u2'
const X = 'document:x'
const Y = 'document:y'
const member = (group: string) => `${group}#member`
const m = (user: string, group: string): RelationOrderView => ({ deny: false, object: group, user, relation: 'member' })
const a = (user: string, object: string): RelationOrderView => ({ deny: false, object, user, relation: 'viewer' })
const d = (user: string, object: string): RelationOrderView => ({ deny: true, object, user, relation: 'viewer' })

/**
 * Los universos (cada uno, la lista de tuplas POSIBLES):
 *  - `E1` (EXHAUSTIVO, 10 tuplas ⇒ 4^10 pares por modo): 1 usuario, 2 grupos (g, h) con 1 nivel de anidamiento (h ⊂ g),
 *    2 objetos, `viewer` con deny; allows directos y por grupo, denies por grupo. Reúne las cinco formas medidas: el
 *    ex-miembro que compone con un allow nuevo (🟡 N3), la composición ANIDADA, el grupo que solo transporta un deny
 *    (🟡 N2), el cambio de grupo denegado, y el cruce de dos grupos (residuo).
 *  - `E1-reduced` (EXHAUSTIVO, 8 tuplas): el de la guardia — corre en cada mutante del corredor.
 *  - `U2` (MUESTRA): el universo del brief entero — 2 usuarios, 2 grupos (h ⊂ g), 2 objetos, allows y denies directos y
 *    por grupo (21 tuplas, 4^21 pares: no se recorre entero).
 *  - `E3` (MUESTRA): 1 usuario, 3 grupos con DOS niveles de anidamiento (a ⊂ b ⊂ c y a ⊂ c), 2 objetos (20 tuplas).
 */
export function universe(name: UniverseName): RelationOrderView[] {
  const g = 'group:g'
  const h = 'group:h'
  if (name === 'E1') {
    return [m(U1, g), m(U1, h), m(member(h), g), a(U1, X), a(member(g), X), a(member(h), X), a(member(h), Y), d(member(g), X), d(member(h), X), d(member(g), Y)]
  }
  if (name === 'E1-reduced') {
    return [m(U1, g), m(U1, h), m(member(h), g), a(U1, X), a(member(g), X), a(member(h), Y), d(member(h), X), d(member(g), Y)]
  }
  if (name === 'E3') {
    const ga = 'group:a'
    const gb = 'group:b'
    const gc = 'group:c'
    const out = [m(U1, ga), m(U1, gb), m(U1, gc), m(member(ga), gb), m(member(gb), gc), m(member(ga), gc)]
    for (const s of [U1, member(ga), member(gb), member(gc)]) for (const o of [X, Y]) out.push(a(s, o))
    for (const s of [member(ga), member(gb), member(gc)]) for (const o of [X, Y]) out.push(d(s, o))
    return out
  }
  const out = [m(U1, g), m(U1, h), m(U2, g), m(U2, h), m(member(h), g)]
  for (const s of [U1, U2, member(g), member(h)]) for (const o of [X, Y]) out.push(a(s, o))
  for (const s of [U1, U2, member(g), member(h)]) for (const o of [X, Y]) out.push(d(s, o))
  return out
}

/** La config de UNA relación con deny del universo: el predicado `cuts` del auto-corte sale de aquí (D5). */
export const ORDER_CONFIG = defineRelationsConfig({
  objectTypes: [{ type: 'document', relations: [{ name: 'viewer' }], deny: 'write' }],
  holderTypes: ['user'],
})
export const ORDER_CUTS: RelationCuts = (objectType, denied, allowed) => relationsUp(ORDER_CONFIG, objectType, allowed).includes(denied)

/**
 * El ORÁCULO: por máscara de presencia, los bits de (usuario, objeto) concedidos y denegados. Con `package: true` decide
 * con `cutPathAllows` del paquete (la MISMA función que `database`, el doble y el modelo FGA); si no, la regla de una
 * relación escrita a mano (más rápida) — el spec cruza las dos sobre `E1`.
 */
export function oracle(views: RelationOrderView[], opts: { package?: boolean } = {}) {
  const users = [...new Set(views.map((v) => v.user).filter((u) => !u.includes('#')))].sort()
  const objects = [...new Set(views.filter((v) => !v.object.startsWith('group:')).map((v) => v.object))].sort()
  const pairs = users.flatMap((u) => objects.map((o) => [u, o] as const))
  const size = 1 << views.length
  const granted = new Uint32Array(size)
  const denied = new Uint32Array(size)
  // Las membresías del universo (pocas): el alcance de cada usuario se calcula UNA vez por sub-máscara de membresías.
  const memberships = views.map((v, i) => [v, i] as const).filter(([v]) => !v.deny && v.object.startsWith('group:'))
  const reachMemo = new Map<string, Set<string>>()
  const reachOf = (user: string, membershipMask: number): Set<string> => {
    const memoKey = `${user}|${membershipMask}`
    let reached = reachMemo.get(memoKey)
    if (reached) return reached
    reached = new Set([user])
    for (let grew = true; grew; ) {
      grew = false
      for (const [t, i] of memberships) {
        if (!(membershipMask & (1 << i))) continue
        if (reached.has(t.user) && !reached.has(member(t.object))) {
          reached.add(member(t.object))
          grew = true
        }
      }
    }
    reachMemo.set(memoKey, reached)
    return reached
  }
  const membershipBits = memberships.reduce((acc, [, i]) => acc | (1 << i), 0)
  const facts = views.map((v, i) => [v, i] as const).filter(([v]) => !v.object.startsWith('group:'))
  for (let mask = 0; mask < size; mask++) {
    let g = 0
    let dn = 0
    pairs.forEach(([user, object], bit) => {
      const reached = reachOf(user, mask & membershipBits)
      const allows = new Set<string>()
      const denies = new Set<string>()
      for (const [t, i] of facts) {
        if (!(mask & (1 << i)) || t.object !== object || !reached.has(t.user)) continue
        ;(t.deny ? denies : allows).add(t.relation!)
      }
      const grant = opts.package ? cutPathAllows(ORDER_CONFIG, 'document', 'viewer', allows, denies) : allows.size > 0 && denies.size === 0
      if (grant) g |= 1 << bit
      if (denies.size > 0) dn |= 1 << bit
    })
    granted[mask] = g
    denied[mask] = dn
  }
  return { granted, denied, pairs }
}

/**
 * Un par CONCRETO (inicial, final, en vistas del universo) recorrido con `order`: el primer prefijo que concede fuera de
 * inicial ∪ final (o a un denegado en los dos), o `null`. Para fijar los contraejemplos literales del informe.
 */
export function walkPair(name: UniverseName, order: OrderFn, initial: RelationOrderView[], final: RelationOrderView[]): { bad: number | null; steps: string[] } {
  const views = universe(name)
  const { granted, denied } = oracle(views)
  const key = (v: RelationOrderView) => `${v.deny}|${v.object}|${v.user}`
  const index = new Map(views.map((v, i) => [key(v), i]))
  const maskOf = (list: RelationOrderView[]) => list.reduce((acc, v) => acc | (1 << index.get(key(v))!), 0)
  const i0 = maskOf(initial)
  const f0 = maskOf(final)
  const plan = order({
    writes: views.filter((_, i) => f0 & ~i0 & (1 << i)),
    deletes: views.filter((_, i) => i0 & ~f0 & (1 << i)),
    context: views.filter((_, i) => (i0 | f0) & (1 << i)),
  })
  const bound = granted[i0] | granted[f0]
  const both = denied[i0] & denied[f0]
  let mask = i0
  let bad: number | null = null
  plan.steps.forEach((step, k) => {
    const i = index.get(key(step.item))!
    mask = step.op === 'write' ? mask | (1 << i) : step.op === 'delete' ? mask & ~(1 << i) : mask
    if (bad === null && ((granted[mask] & ~bound) !== 0 || (granted[mask] & both) !== 0)) bad = k + 1
  })
  return { bad, steps: plan.steps.map((s) => (s.op === 'write' ? '+' : '-') + show(s.item)) }
}

/** Las vistas del universo, por nombre corto (`g@u1`, `x@g#member`, `¬x@h#member`): para escribir pares a mano. */
export function pick(name: UniverseName, ...shorts: string[]): RelationOrderView[] {
  const views = universe(name)
  return shorts.map((short) => {
    const found = views.find((v) => show(v) === short)
    if (!found) throw new Error(`'${short}' no está en el universo ${name}`)
    return found
  })
}

export type OrderFn = (transition: { writes: RelationOrderView[]; deletes: RelationOrderView[]; context: RelationOrderView[] }) => {
  steps: Array<{ item: RelationOrderView; op: 'write' | 'delete' | 'renew' }>
  residue: RelationOrderView[]
}

/** El orden del paquete, con (`cuts`) o sin el predicado del auto-corte (sin él, el modo conservador). */
export function packageOrder(cuts: RelationCuts | undefined): OrderFn {
  return (transition) => relationTransitionOrder(transition, (v) => v, cuts ? { cuts } : {})
}

export interface BruteForceResult {
  universe: UniverseName
  tuples: number
  mode: 'exhaustive' | 'sample'
  /** Pares (inicial, final) recorridos, sumando los dos modos (`--prune` y sin él). */
  pairs: number
  /** Pares cuyo grafo de precedencias tiene un ciclo (`residue` no vacío). */
  residuePairs: number
  /** Pares en los que algún prefijo concede fuera de inicial ∪ final (o a un denegado en los dos). */
  unsafe: number
  /** De esos, los que NO tenían ningún orden seguro (inherentes). */
  inherent: number
  /** ROJO: pares que conceden SIN residuo declarado (la propiedad exige cero). */
  unsafeWithoutResidue: number
  /** ROJO: el orden no es una permutación del diff o no llega al final. */
  malformed: number
  ms: number
  examples: string[]
}

export function show(v: RelationOrderView): string {
  const s = (x: string) => x.replace('document:', '').replace('group:', '').replace('user:', '')
  return `${v.deny ? '¬' : ''}${s(v.object)}@${s(v.user)}`
}

/** Recorre el universo (entero o una muestra con semilla) contra `order`. */
export function bruteForce(name: UniverseName, order: OrderFn, opts: { sample?: number; seed?: number; maxExamples?: number } = {}): BruteForceResult {
  const started = Date.now()
  const views = universe(name)
  const n = views.length
  const { granted, denied } = oracle(views)
  const full = (1 << n) - 1
  const index = new Map(views.map((v, i) => [`${v.deny}|${v.object}|${v.user}`, i]))
  const result: BruteForceResult = {
    universe: name,
    tuples: n,
    mode: opts.sample ? 'sample' : 'exhaustive',
    pairs: 0,
    residuePairs: 0,
    unsafe: 0,
    inherent: 0,
    unsafeWithoutResidue: 0,
    malformed: 0,
    ms: 0,
    examples: [],
  }
  // mulberry32: muestra reproducible.
  let seed = opts.seed ?? 20261015
  const random = () => {
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
  const total = opts.sample ?? 4 ** n
  for (const prune of [true, false]) {
    for (let t = 0; t < total; t++) {
      const initial = opts.sample ? Math.floor(random() * (full + 1)) : t & full
      const source = opts.sample ? Math.floor(random() * (full + 1)) : Math.floor(t / (full + 1))
      const final = prune ? source : initial | source
      const writes = views.filter((_, i) => final & ~initial & (1 << i))
      const deletes = views.filter((_, i) => initial & ~final & (1 << i))
      const context = views.filter((_, i) => (initial | final) & (1 << i))
      result.pairs++
      const plan = order({ writes, deletes, context })
      if (plan.residue.length > 0) result.residuePairs++
      const bound = granted[initial] | granted[final]
      const both = denied[initial] & denied[final]
      let mask = initial
      let bad: number | null = (granted[mask] & ~bound) !== 0 || (granted[mask] & both) !== 0 ? 0 : null
      const seen = new Set<number>()
      plan.steps.forEach((step, k) => {
        const i = index.get(`${step.item.deny}|${step.item.object}|${step.item.user}`)!
        seen.add(i)
        mask = step.op === 'write' ? mask | (1 << i) : step.op === 'delete' ? mask & ~(1 << i) : mask
        if (bad === null && ((granted[mask] & ~bound) !== 0 || (granted[mask] & both) !== 0)) bad = k + 1
      })
      if (mask !== final || seen.size !== writes.length + deletes.length || plan.steps.length !== writes.length + deletes.length) result.malformed++
      if (bad === null) continue
      result.unsafe++
      const inherent = !admissible(initial, final, n, granted, bound, both)
      if (inherent) result.inherent++
      if (plan.residue.length === 0) result.unsafeWithoutResidue++
      if (result.examples.length < (opts.maxExamples ?? 3) && (plan.residue.length === 0 || result.examples.length === 0)) {
        result.examples.push(
          `${prune ? '--prune' : 'sin --prune'} · inicial [${views.filter((_, i) => initial & (1 << i)).map(show).join(' ')}] · final [${views
            .filter((_, i) => final & (1 << i))
            .map(show)
            .join(' ')}] · orden [${plan.steps.map((s) => (s.op === 'write' ? '+' : '-') + show(s.item)).join(' ')}] · concede tras ${bad} · residuo [${plan.residue.map(show).join(' ')}]${inherent ? ' · sin orden seguro' : ''}`
        )
      }
    }
  }
  result.ms = Date.now() - started
  return result
}

/** ¿Existe ALGUNA permutación del diff con todos los prefijos seguros? DP sobre los subconjuntos del diff. */
export function admissible(initial: number, final: number, n: number, granted: Uint32Array, bound: number, both: number): boolean {
  const diff: number[] = []
  for (let i = 0; i < n; i++) if (((initial ^ final) >> i) & 1) diff.push(i)
  const reach = new Uint8Array(1 << diff.length)
  reach[0] = 1
  for (let sub = 0; sub < reach.length; sub++) {
    if (!reach[sub]) continue
    for (let j = 0; j < diff.length; j++) {
      const next = sub | (1 << j)
      if (next === sub || reach[next]) continue
      let mask = initial
      for (let k = 0; k < diff.length; k++) if (next & (1 << k)) mask ^= 1 << diff[k]
      if ((granted[mask] & ~bound) === 0 && (granted[mask] & both) === 0) reach[next] = 1
    }
  }
  return reach[reach.length - 1] === 1
}
