# Repaso del auditor — cierre 5 de D2 (2026-10-16), opción A

Mismas reglas que los repasos anteriores (solo lectura; reproducciones en `.claude/reproducciones/`; SQLite `:memory:` y stores efímeros en `:8090` con prefijo propio, borrados; sin docker restart ni gates).

Lee: decisión §2026-10-16 (10) (final de `decisiones-dueno-2026-08-28.md`), `loteD2-cierre5-coordinador.md`, `loteD2-informe-cierre5.md`, tu `loteD2-auditor-cierre4.md`, `panel-optimo-auditor.md` (R2).

Coordinador verificó: 2053/2081/2178/2180, guardia 188/188 (modo filtrado, 8 workers, 23 s), banderas 37/37, runbook ×2.

Comprueba:
1. D4-1…D4-5 y R2 cerrados en efecto (re-ejecuta `loteD2-auditor-cierre4.ts` y `panel-optimo-auditor-model-drift.ts`).
2. **Partición negada**: ¿de verdad cero escrituras y cero borrados en TODOS los caminos (`--prune`, vencidas, `expiredDelete`, dry vs real, fallo a mitad de pasada de OTRA partición)? ¿Puede un tenant hacer que se niegue la partición de OTRO (frontera de partición, usersets cruzados)? ¿La línea y el exit dicen la verdad?
3. **Cambios en `relationTransitionOrder`** (C3 cuenta membresía como concesión, C4 con la exclusión de C2): ¿regresión en la propiedad de prefijos/horizonte fuera del universo de la fuerza bruta? ¿El oráculo nuevo (sin `preexisting`, con `group:`) es fiel?
4. **D-31 ampliada**: la excepción «tipo sin opt-in acepta la forma con deny (D8)» — ¿abre un hueco (modelo con deny publicado, config sin opt-in, deny escrito por otro proceso que concede o niega distinto)?
5. **Corredor filtrado de mutantes**: ¿puede un mutante sobrevivir en filtrado y morir en completo (o al revés) por casos colaterales? Revisa la prueba de equivalencia (`loteD2-cierre5-equivalencia/`, `scripts/compare_guard_mutants.mjs`) y `--skip-db-independent`.
6. Letra del 409 y del README «The limit»: ¿alguna receta presentada como segura que reabra la ventana? ¿Frases universales falsas?
7. D4-5: ventana declarada del contador de `purgeScope` — ¿solo letra o efecto?

Salida: `.claude/contexto/loteD2-auditor-cierre5.md`, veredicto APTA / NO APTA y hallazgos 🔴🟠🟡⚪ con reproducción.
