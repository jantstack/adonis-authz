# Sublote D2 · cierre 5 — informe del implementador (2026-10-16)

Brief: `loteD2-cierre5-coordinador.md`. Decisión: §2026-10-16 (10) del dueño, **opción A** (negar la PARTICIÓN). Origen:
`loteD2-auditor-cierre4.md` (NO APTA: D4-1 🟠, D4-2/D4-3 🟡, D4-4/D4-5 ⚪) y el panel «paquete óptimo»
(`panel-optimo-{juez,auditor,tester,analista-global}.md`: G1–G3, H2, R2 🟠, mutantes «solo por cifras»).
Árbol: `main` sobre `75353fe`, D2 + cierres 1–5 SIN commit. Sin commit, sin `npm version`, sin push, sin sellado; el
CHANGELOG solo bajo `[Unreleased]` (`git diff HEAD -- CHANGELOG.md`: 0 líneas borradas).

**Respaldo previo** (antes de tocar nada): `.claude/respaldos/D2-pre-cierre5-2026-10-16.tgz` (los 33 ficheros modificados
y los 7 nuevos de D2 + cierres 1–4, más `.claude/contexto/`; 329 entradas).

Orden seguido: (1) el gate barato, con la prueba de equivalencia sobre el árbol del cierre 4 ANTES de tocar `src/`;
(2) opción A; (3) lo del panel (R2 y la letra).

---

## 1 · Gate más barato: G1 + G2 + G3 (sin tocar `src/`)

**Qué** (`scripts/check_guard_mutants.mjs`, reescrito; `scripts/compare_guard_mutants.mjs`, nuevo; `.github/workflows/ci.yml`):

- **G1** — por mutante corre SOLO los títulos de su `expectRed` (Japa `--tests=<título>` exacto y repetible; medido:
  `processAsArray(…, false)` no parte por comas). El criterio de muerte no cambia (ya solo miraba esos títulos). La línea
  base sigue siendo la guardia ENTERA, una vez. `--full` = el spec entero por mutante (recupera `collateral`).
- **G2** — `--jobs=N` con un directorio temporal por worker (`node_modules` enlazado); por defecto
  `min(availableParallelism − 1, memoria libre / 400 MB, 8)` (345 MB de RSS medidos por proceso por el tester). La salida
  se reordena por el orden del manifiesto al final.
- **G3** — `--skip-db-independent`: salta los mutantes cuyos ficheros son TODOS de `DB_INDEPENDENT_FILES`
  (`tuple_order.ts`, `reconcile.ts`). CI: la pierna `sqlite-file` del job `guard-mutants` lo usa; nuevo job nocturno
  `guard-mutants-full` (`schedule` diario + `workflow_dispatch`, `--full`). Declarado: el disparador `schedule` corre
  también los demás jobs del workflow por la noche.

**Prueba de equivalencia, una vez, sobre el árbol del cierre 4** (foto congelada del árbol antes de tocar `src/`; salidas
en `.claude/contexto/loteD2-cierre5-equivalencia/`):

| corrida | mutantes | resultado | tiempo (6 workers) |
|---|---|---|---|
| `:memory:` filtrado (G1) | 181 | 181 muertos | 27 s (33 s de pared con línea base) |
| `:memory:` completo (`--full`) | 181 | 181 muertos | 200 s (3 min 26 s de pared) |
| `compare_guard_mutants.mjs completo filtrado` | — | **181 ids con el mismo veredicto, 0 diferencias** | — |
| `sqlite-file` filtrado, los 19 de `tuple_order`/`reconcile` | 19 | 19 muertos; **mismo veredicto que en `:memory:`** (`--subset`) | 10 s |
| `sqlite-file` filtrado, `--skip-db-independent` | 162 | 162 muertos | 18 s |

Antes (informe del cierre 4): 181 en serie con el spec entero = **962 s**. Objetivo del brief (≤ 3 min local): cumplido
con margen; ver la corrida final en «Verificación».

Mutantes del gate: no aplica (no es una guarda del producto); la prueba de que el filtro no pierde muertes es la
equivalencia de arriba.

---

## 2 · Opción A

### 2.1 · `relate` en `openfga`: el 409 se conserva y la receta es honesta

**Qué.** `RenewalUnsafeError.carrier` (`src/errors.ts`): se conserva el 409 `E_AUTHZ_RENEWAL_UNSAFE` con cero escrituras,
`E_AUTHZ_RENEWAL_RACED`, la marca parcial y C2-4 (una portadora vencida no es 409; sin cambios en el driver). La receta:
«en este driver NO hay forma sin ventana de cambiar esta caducidad» + `openfga/openfga#2151`; (1) patrón recomendado,
membresías SIN caducidad en grupos con deny, que se terminan con `unrelate`; (2) `unrelate` + `relate` ACEPTANDO la
ventana, diciendo qué concede la ventana. Fuera «retira antes el deny, renueva y vuelve a escribirlo» (abría la misma
ventana y se presentaba como salida).

**Casos.** `relations_openfga.spec` N1 (servidor): + `#2151`, «ACEPTANDO la ventana», sin «retira antes el deny»;
`relations_reconcile_deny.spec` «la RECETA es honesta…» (sin servidor: la del 409 y la de la partición).

### 2.2 · Reconcile: la PARTICIÓN negada (cierra D4-1, D4-2 y D4-3)

**Qué** (`src/relations/reconcile.ts`, `src/relations/tuple_order.ts`, `commands/authz_relations_reconcile.ts`, `index.ts`):

- FUERA: `relationWithheldWrites`, `HeldRenewal`, `WithholdInput`, `WithholdPlan` (−~150 líneas de `tuple_order.ts`), el
  residuo `withheld-by-unsafe-deny` (motivo, registro L9, línea `retenida …`), la negativa GLOBAL `carrier-conflict`
  (motivo de `DenyRefusal`, su receta y su letra), y el contexto separado `transitionContext` (ya es `orderContext`).
- DENTRO, en `planPartition`: una partición con ≥ 1 `renewal-unsafe` o `deny-conditional` lleva
  `refusal: RelationsPartitionRefusal` (`partition`, `causes`, `pending: { write, update, delete }`, `recipe` de
  `partitionRefusalRecipe`, exportada). `reconcileRelations` la salta ENTERA (`refusePartition`): cero escrituras, cero
  borrados —también con `--prune` y las vencidas—, `status: 'refused'`, `report.partitionsRefused`; el seguro de borrado
  masivo y la puerta del deny no la cuentan (no escribe nada). El resto de particiones migra. Decidido en el PLAN ⇒
  `--dry-run` y la real dan los mismos números. Las líneas `renewal-unsafe` / `deny-conditional` nombran la partición y su
  receta; nueva línea `partición NEGADA <partición>:` (prefijo estable, `error`, exit ≠ 0) con causas, «COMO ESTABA», la
  deriva pendiente y la receta. `pasada PARCIAL:` dice `NEGADA (cero escrituras)` para esa fila. Tipo exportado:
  `RelationsPartitionRefusal` (`index.ts`).
- SE CONSERVA: `tuple_order.ts` (orden con renovaciones/vigencia/`shortening`, horizonte), `liveInDestination`,
  `expiredDelete`, streaming de `provision`, C2-5/C3-4, `atomicRenewal`.

**Reproducciones del auditor (`loteD2-auditor-cierre4.ts`, `:8090`), ahora:**

| repro | cierre 4 | cierre 5 |
|---|---|---|
| D4-1 | retiene `U∈K`; el destino concede Y en `now` y la línea dice lo contrario | partición NEGADA, `written 0, updated 0` dry = real; el destino queda **como estaba** (concedía Y antes y después: deriva previa a la vista, `por escribir 1`); ninguna línea promete «más restrictivo» |
| D4-2 | `--prune` retiene el borrado de `U∈K`; `check(member K)` true | partición NEGADA, `deleted 0`; `U∈K` sigue (deriva previa a la vista, `por borrar 1`); el README ya no dice «Withholding only restricts» |
| D4-3 | 500 `carrier-conflict`; la partición del OTRO tenant no migra (`V viewer W` false) | la real con `--prune` es ÉXITO; P negada (6 → 6 tuplas en P), P2 migra (`V viewer W` **true**; 7 tuplas en total) |

**Casos** (`tests/relations_reconcile_deny.spec.ts`, grupo nuevo «cierre 5 de D2 · opción A»):
- D4-3 (dos particiones, `--prune`, dry y real): P `refused` con `pending {1,1,1}`, P2 `done`; el espía ve SOLO la
  escritura de P2; el destino de P no cambia; dry == real; la línea (partición, «COMO ESTABA», «Cero escrituras y cero
  borrados», «por escribir 1, por renovar 1, por borrar 1», `#2151`, «SIN caducidad»); ninguna línea `withheld`/`carrier-conflict`.
- D4-1: el destino queda idéntico (enumeración antes = después) y ninguna línea dice «más restrictivo».
- C3-2 (🟡 4 → C3-2 → A): `deny-conditional` + partición negada, `written 0`, línea `partición NEGADA`.
- L9: fixture `withheld-by-unsafe-deny` borrado; `renewal-unsafe` y `deny-conditional` afirman además `partitionsRefused`.
- Contrato publicado (`runRelationsReconcileContract`, `denies: true`) «vigencia · C3-1»: sin `atomicRenewal` ⇒
  `written 0, updated 0, details [renewal-unsafe], refused [renewal-unsafe]` y niega en `now` y tras la caducidad vieja;
  con `atomicRenewal` igual que antes.
- `relations_openfga.spec` C3-2 (servidor): `written 0`, `[deny-conditional]`, `refused 1`, el destino niega.
- Guardia `relations.reconcile.order`: filas C3-1 y C3-2 marcadas `refused` (exigen CERO escrituras y siguen
  comprobando `now` y el horizonte). **Fila nueva C2-2** («un deny VENCIDO del grupo que concede, podado, no corta su
  allow en el orden»): la verificación final encontró VIVO `rec.apply.expired-deletes-in-order` — con C3 sin auto-corte,
  las dos filas C2-2 del cierre 3 ya no lo mataban (el defecto de C2-2 vivía en el auto-corte de C3); queda vivo por C1
  (un deny vencido dentro del orden corta el allow del grupo y U entra en el grupo que concede antes que en el que niega).
  Con la fila, MUERTO.

**Mutantes** (en el corredor): `rec.plan.refusal-off` (el plan nunca niega) MUERTO — y, medido aparte con
`scratchpad/c5/scripts/mutspec.mjs`, pone rojos 7 casos de los specs (D4-3, D4-1, C3-2, L9 ×2, contrato C3-1 ×2);
`rec.plan.conditional-in-pass` (c42 al corredor) MUERTO — 2 rojos en los specs.

### 2.3 · Fuerza bruta / oráculo

**Qué** (`tests/helpers/order_bruteforce.ts`):
- (a) **fuera la exclusión general `preexisting`** (H2): la única exclusión es la partición NEGADA (cero escrituras ⇒ el
  estado es el inicial en todo instante); para las demás, ningún prefijo concede, en ningún instante del horizonte, fuera
  de inicial(t) ∪ origen(t) ni a un denegado en los dos, salvo ciclo declarado; y **el estado final no concede nada que el
  origen niegue, sin excepción**.
- (b) **el oráculo cuenta los objetos `group:`** (D4-2): `(usuario, group:G)` concede si el usuario alcanza `G#member`.
- (c) el modo «dos Write» NIEGA la partición (`refused`); `refuse: false` solo para demostrar que hace falta.
- `walkVigencia(name, order, estados, { prune, atomic })`: una combinación CONCRETA con vigencia (el cuerpo es el mismo
  `vigenciaCombination` que la fuerza bruta).

**Lo que apareció al añadir `group:` al oráculo — y se ARREGLÓ, no solo se declaró** (`relationTransitionOrder`):
- Con el orden del cierre 4, el oráculo nuevo daba **pares sin residuo que conceden**: E1 32 256, E1-reduced 1 920,
  U2 1 751/60 000, E3 1 621/60 000. Forma mínima: `+h@u1 −g@h#member` (inicial `[g@h#member]`, final `[h@u1]`): cortada
  tras el 1.º, U1 es miembro de g, cosa que ni el inicial ni el final hacen. C3 solo daba precedencia si el camino
  compuesto llevaba un allow EFECTIVO.
- Arreglo 1: **C3 cuenta la membresía como concesión** (sin la condición de allow efectivo). 0 sin residuo, pero los
  ciclos se disparaban (E1 74 640) porque C4 chocaba con C3.
- Arreglo 2: **C4 con la exclusión de C2** (`union.below(…, otra.key)` por los dos lados): un sujeto que solo alcanza la
  que sale a través de la que entra no tenía ese deny en el inicial. E1 vuelve a 4 176 ciclos (menos que los 4 560 del
  cierre 4).

**Cifras** (semillas sin cambio; `0 sin residuo` y `0 malformados` en todas):

| universo | modo | cierre 4 (ciclo / conceden / inherentes) | cierre 5 |
|---|---|---|---|
| E1 exhaustivo (2 097 152) | — | 4 560 / 828 / 352 | **4 176 / 816 / 352** |
| E1-reduced exhaustivo (131 072, guardia) | — | 1 140 / 210 / 88 | **1 044 / 204 / 88** |
| U2 30k | — | 233 / 9 / 0 | **209 / 17 / 0** |
| E3 30k | — | 842 / 7 / 0 | **4 188 / 155 / 0** (precio declarado: más ciclos con dos niveles; todos residuo avisado) |
| vigencia E1-reduced 50k (guardia) | atómico / dos W | 2 985·326·80 / 235·53·24 | **2 506·306·80 / 187·50·24**; negadas 0 / 76 389 |
| vigencia E1-reduced 300k | atóm. / dos W | 18 004·1 972·454 / 1 442·287·108 | **15 140·1 857·454 / 1 133·273·108**; negadas 0 / 458 369 |
| vigencia E1 300k | atóm. / dos W | 4 435·457·110 / 386·54·18 | **3 731·448·110 / 284·52·18**; negadas 0 / 525 780 |
| vigencia U2 30k | atóm. / dos W | 866·14·0 / 6·0·0 | **751·28·0 / 2·0·0**; negadas 0 / 59 573 |
| vigencia E3 30k | atóm. / dos W | 3 215·16·2 / 48·1·0 | **11 022·326·2 / 53·5·0**; negadas 0 / 59 178 |
| **vigencia E1-reduced EXHAUSTIVO** (33 554 432 por destino) | atómico | 993 024·105 696·26 496 | **836 352·100 512·26 496** (475 s) |
| idem | dos Write | 82 728·15 264·5 976 | **63 432·14 400·5 976**; negadas 25 632 768 (109 s) |

`renewalUnsafe`/`denyConditional` sin cambio (mismos estados). Densidad declarada: en el universo «dos Write» la
partición se niega en el 76 % (E1-reduced) y el ~99 % (U2/E3) de las combinaciones, porque todo deny del destino lleva
caducidad (`+1 h`) y cualquier cambio de caducidad de una portadora o de un deny niega; en la vida real `deny-conditional`
solo existe escrito a mano y la portadora con caducidad es el patrón que el README desaconseja.

`refuse: false` (sin negar): E1-reduced 50k dos Write ⇒ `unsafeWithoutResidue` > 0 con «estado FINAL en el horizonte»
(caso del spec «cierre 4 → cierre 5»): la negativa hace falta.

### 2.4 · Los mutantes que solo morían por cifras

| mutante | ahora | cómo |
|---|---|---|
| `order.c4.off` (seguridad) | **muere por SEMÁNTICA en el corredor** | literal U2 de una línea (`walkPair`, `--prune`): con el mutante concede tras el paso 2; en la guardia (`relations.order.exhaustive`) y en el spec |
| `c4h.order.renewals-not-changing` → `order.renewals-not-changing` | **muere por semántica en el corredor** | literal E3 de 8 tuplas con `walkVigencia` (`--prune`, atómico): con el mutante concede tras el paso 3 |
| `c41.order.without-ignored` | **desaparece** con `relationWithheldWrites` | — (lo había previsto el tester: «si gana (ii), este mutante y su caso desaparecen») |
| `order.priority.deletes-first` | **declarado EQUIVALENTE** (`note` en el manifiesto) | medido en E1/E1-r exh., U2/E3 30k, vigencia 50k: 0 sin residuo; solo cambia el reparto dentro del residuo (E1-r 228 frente a 204) |
| `order.c2.no-exclusion` | **declarado PRECISIÓN** (`note`) | 0 sin residuo en todo; más ciclos (E1-r 1 152 frente a 1 044) |
| `order.c4.no-exclusion` (nuevo) | **declarado PRECISIÓN** (`note`) | 0 sin residuo; E1-r 2 508 ciclos, E1 74 640 |
| `order.c3.membership-needs-allow` (nuevo) | muere por semántica | E1-r exhaustivo: 1 920 sin residuo; literal `+h@u1 −g@h#member` |

**Los mutantes del cierre 4 que siguen teniendo sentido, en `guard_mutants.json`:** `c4h.plan.shortening-not-passed` →
`rec.plan.shortening-not-passed` (fila nueva de `relations.reconcile.order`, «horizonte · una renovación que ACORTA un
allow…», juzgada solo en el horizonte: `horizonOnly`); `c4h.order.renewals-not-changing` → `order.renewals-not-changing`;
`c42.plan.conditional-in-pass` → `rec.plan.conditional-in-pass`; `c44.roles.purgeScope-no-partial` →
`roles.purgeScope.no-partial` (la propiedad `openfga.roles.purgeScope.order` afirma ahora la marca parcial en cada corte).
Fuera por no tener sentido: los cinco `c41.order.*` y `c41.plan.withhold-off`/`rec.plan.withhold-off`/`order.withhold.off`
(la retención ya no existe). **Fuera del corredor, con razón:** `c43.raced.same-code` — su asesino es
`relations_openfga.spec` C2-3, que necesita el servidor (espía-barrera sobre el cliente REAL entre la comprobación y los
dos `Write`); el corredor corre solo la guardia sin servidor. Sigue medible a mano.

### 2.5 · ⚪ D4-4 y ⚪ D4-5

- **D4-4** — la línea `orden SIN garantía` dice ahora que un ciclo puede contener una RENOVACIÓN (que entra o sale cuando
  vence la caducidad más corta) y que el corte puede conceder «ya o en un instante posterior». Caso de letra en
  `relations_reconcile_deny.spec`.
- **D4-5** — `purgeScope` de roles (`src/drivers/openfga_driver.ts`): el contador suma lo BORRADO DE VERDAD. Una lectura
  del scope antes de la fase 1 dice qué aristas `#binding` existen; la estructura a ciegas cuenta solo esas (y su
  `role_binding#role`); un `#role` sin `#binding` no cambia ninguna respuesta. Ventana declarada (docblock + CHANGELOG):
  una arista que un `grant` concurrente escribe entre esa lectura y el borrado se borra sin contarse. Coste: +1 `Read`
  por purga. Caso: la propiedad `openfga.roles.purgeScope.order` corta una purga SIN estructura en el 2.º `Write` ⇒ sin
  marca parcial (y la marca en cada corte del escenario con estructura). Mutante `roles.purgeScope.count-requested` MUERTO.

---

## 3 · Del panel

### 3.1 · 🟠 R2 — la guarda D-31 compara modelo y config en TODOS los tipos

**Qué** (`src/drivers/openfga_relations_driver.ts`): la MISMA lectura del modelo (memo por proceso, compartido con las
vistas `withClock`; un fallo no se memoriza) calcula además la deriva de cada tipo de la config y de `group`: las
relaciones cuya regla no es la de `factsRelationRewrites` (igualdad tras `canonicalRewrite`) o que faltan. `#assertModelDeny`
(lo llaman todas las operaciones) lanza 500 `E_AUTHZ_CONFIG` nombrando `tipo#relación` (letra «D-31 en todos los
tipos, R2»). En un tipo SIN opt-in también vale la forma CON deny (`<rel> = base but not denied_<rel>`): es D8 (opt-in
retirado con el modelo aún publicado), más restrictivo; sin esa excepción la primera versión ponía rojos D8 y el 🟡 3 de
`decideMany` contra el servidor (medido: 2 rojos), que son estados legítimos.

**Reproducción del auditor** (`panel-optimo-auditor-model-drift.ts`, `:8090`): `note SIN deny` antes `openfga TRUE ·
database FALSE` ⇒ ahora **`THROW 500 E_AUTHZ_CONFIG` · database false**; `note deny:'read'` igual que antes (500).

**Casos.** `relations_openfga.spec` «🟠 R2 …» (servidor: modelo de la config ancha, pod con `note#viewer` estrecho ⇒ 500
nombrando `note#viewer`; `database` niega; el pod con la config de su modelo responde); propiedad nueva de la guardia
`openfga.model.drift` (sin servidor, cliente falso que sirve el modelo del contrato). Clientes falsos sin
`readAuthorizationModel` de `relations_openfga.spec` (grupo B4/N5): ahora sirven el modelo (`servedModel`), porque todo
tipo lee el modelo (coste declarado: una lectura por proceso también para tipos sin deny).

**Mutante.** `fga.model.drift-off` (la deriva solo en tipos con deny) MUERTO.

### 3.2 · Letra

- **README**: el párrafo de la renovación (receta honesta); el de «Not renewing is not neutral» reescrito: la partición
  NEGADA, sus campos y su línea, sin ninguna frase universal («Refusing does not make the destination more restrictive
  than the source: it leaves it as it was»); **párrafo nuevo «The limit: changing the expiry of a deny-carrying membership
  on `openfga`»** (409; no hay forma sin ventana; enlace a #2151; patrón recomendado; `unrelate` + `relate` aceptando la
  ventana; **TOCTOU de N1 declarado**; «When OpenFGA offers an upsert … `atomicRenewal` will become `true`»); la sección
  de la fuerza bruta (cifras nuevas, «Group membership counts as a grant», la única exclusión, sin `preexisting`); la
  puerta del deny sin `carrier-conflict`; la fila de `E_AUTHZ_RENEWAL_UNSAFE` en la tabla. Caso de letra con dientes en
  `relations_reconcile_deny.spec` (frases exigidas y prohibidas: «Withholding only restricts», la receta vieja, `retenida`).
- **CHANGELOG** `[Unreleased]`: sección «Closure 5 of sublot D2» (problema → decisión → qué no se hace). `[2.5.0-alpha.1]`
  sin tocar.

---

## Cuatro líneas de cierre

**🟠 D4-1 / 🟡 D4-2 / 🟡 D4-3 (opción A)**
- (a) *Gemelos*: comando ↔ función ↔ manager — `runRelationsReconcile` devuelve el reporte de `reconcileRelations` tal
  cual y el comando lo imprime (`relationsReconcileLines`, casos D4-3/C3-2); runner publicado: contrato «vigencia · C3-1»
  (dos direcciones, dobles y `database ↔ openfga`). `authz:reconcile` de ROLES: no aplica — en roles el deny es un hecho
  directo del scope (`denied_<P>`), no viaja por una membresía, y la renovación de `grant` en `openfga` falla CERRADO
  (pierde el `assignee`, marcado parcial desde el cierre 3).
- (b) *Tabla de verdad*: dominios `atomicRenewal ∈ {sí, no}` × `renewal-unsafe ∈ {0, ≥1}` × `deny-conditional ∈ {0, ≥1}` ×
  `--prune ∈ {sí, no}` × `--dry-run ∈ {sí, no}`; guardia de producto: negada ⇔ `¬atomicRenewal ∧ (ru ≥ 1 ∨ dc ≥ 1)`
  (con `atomicRenewal` ni `ru` ni `dc` existen: el plan no los produce); rama: negada ⇒ 0 escrituras y 0 borrados en esa
  partición, las demás aplican; exit ≠ 0 si hay alguna negada, en los cuatro modos. Filas con caso: (no, ≥1, 0, sí, sí/no)
  D4-3; (no, ≥1, 0, no, no) D4-1 y contrato C3-1; (no, 0, ≥1, no, sí/no) C3-2 doble y servidor; (sí, ·, ·, no, sí/no)
  contrato C3-1 cara `atomicRenewal`; (no, ≥1, 0, no, sí/no) L9.
- (c) *Casos que el arreglo puso rojos*: L9 `withheld-by-unsafe-deny` (borrado: el motivo ya no existe); deny spec 🟡 4/C3-2,
  contrato C3-1 ×2, `relations_openfga` C3-2 (esperaban `withheld-by-unsafe-deny`: ahora `partitionsRefused`); guardia
  filas C3-1/C3-2 («la pasada no escribe nada» era «fila mal construida»: ahora es lo exigido); cifras fijadas de la fuerza
  bruta (spec y guardia: cambian el oráculo y C3/C4, re-medidas arriba).
- (d) *Linaje*: **L10** (estado intermedio que concede). No es una iteración nueva del defecto: el punto de paso único
  sigue siendo `relationTransitionOrder` y la propiedad, la fuerza bruta; el cierre la ENDURECE (el oráculo ve `group:`,
  sin exclusión `preexisting`) y el endurecimiento encontró y cerró la composición de membresías (C3). Las tres retenciones
  sucesivas (cierres 3 → 4 → D4-1) eran la 3.ª iteración de «parchear lo que no viaja tupla a tupla»: la opción A la cierra
  estructuralmente (la unidad de decisión es la partición, decidida en el plan).

**🟠 R2**
- (a) *Gemelos*: vistas `withClock` — comparten el memo (mismo resultado, sin caso propio: el memo es el mismo objeto).
  El driver de ROLES `openfga` (`facts`): no aplica en la misma forma — sus relaciones de permiso no tienen `includes` que
  el consumidor estreche; si el modelo fijado de roles puede derivar del catálogo es otra pregunta, NO medida en este
  cierre (la dejo escrita para el coordinador).
- (b) *Tabla de verdad*: tipo `{con deny, sin deny}` × modelo `{igual a la config, forma con deny de la config, otra regla,
  tipo ausente}`: con deny — solo «igual» pasa (D-31 previo); sin deny — «igual» y «forma con deny» (D8) pasan, «otra
  regla» y «ausente» ⇒ 500. Filas con caso: (sin deny, otra regla) guardia + servidor; (sin deny, forma con deny) D8 y 🟡 3
  contra el servidor; (con deny, otra regla) D-31 existente.
- (c) *Casos rojos*: 4 de `relations_openfga.spec` sin servidor (clientes falsos sin `readAuthorizationModel`: ahora lo
  sirven) y, con la primera versión, D8 y 🟡 3 (corregido el ARREGLO, no los casos).
- (d) *Linaje*: candidato nuevo «guarda modelo ↔ config aplicada a medias»: D-31 (D1) → ⚪ 7 (cierre 1 de D1: forma
  `subtract`) → ⚪ N4 (cierre 2: igualdad estructural) → R2 (todos los tipos). Son 4 apariciones de la misma guarda; el
  arreglo ya es estructural (un punto de paso, `#assertModelDeny`/`#readModel`, y la propiedad `openfga.model.drift` en
  la guardia con su mutante). Propongo al coordinador la fila en `linajes.md` (no la toco).

---

## Mutantes

En el corredor (`tests/fixtures/guard_mutants.json`): **181 → 188** (−2 de la retención, +9 nuevos: `rec.plan.refusal-off`,
`rec.plan.conditional-in-pass`, `rec.plan.shortening-not-passed`, `order.renewals-not-changing`,
`order.c3.membership-needs-allow`, `order.c4.no-exclusion`, `roles.purgeScope.no-partial`,
`roles.purgeScope.count-requested`, `fga.model.drift-off`); `roles.purgeScope.denies-first` con el `find` re-anclado.
Propiedad nueva `openfga.model.drift`. Declarados «solo por cifras» con `note`: `order.priority.deletes-first`
(equivalente), `order.c2.no-exclusion` y `order.c4.no-exclusion` (precisión). Resultado: ver «Verificación».

## Ficheros tocados en el cierre 5

`scripts/check_guard_mutants.mjs`, `scripts/compare_guard_mutants.mjs` (nuevo), `.github/workflows/ci.yml`,
`src/relations/tuple_order.ts`, `src/relations/reconcile.ts`, `src/drivers/openfga_relations_driver.ts`,
`src/drivers/openfga_driver.ts`, `src/errors.ts`, `src/testing/relations_reconcile_contract.ts`, `index.ts`,
`commands/authz_relations_reconcile.ts`, `tests/helpers/order_bruteforce.ts`, `tests/guard_surface.spec.ts`,
`tests/fixtures/guard_manifest.ts`, `tests/fixtures/guard_mutants.json`, `tests/relations_order_exhaustive.spec.ts`,
`tests/relations_reconcile_deny.spec.ts`, `tests/relations_reconcile_l9.spec.ts`, `tests/relations_openfga.spec.ts`,
`README.md`, `CHANGELOG.md`. Contexto: `loteD2-cierre5-equivalencia/` (salidas de la prueba de equivalencia y del
exhaustivo con vigencia), este informe.

**Líneas netas** (frente al árbol del cierre 4): `src/` −330 / +283 (**−47 netas**; `tuple_order.ts` 739 → 594, −145);
`commands/` +13; `tests/` −362 / +807 (+445, de ellas +89 del manifiesto de mutantes); `README.md` +19; `CHANGELOG.md` +63.

## Verificación

Yo, en SECUENCIA (`scratchpad/c5/verify.sh`; `docker restart openfga-dev && sleep 8` antes de cada suite con OpenFGA).
Node 22, `OPENFGA_TEST_URL=http://localhost:8090`, `TEST_PG_URL` con la contraseña de `postgres18`, `TEST_MYSQL_URL`
`root/root`. Logs en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/c5/v-*.log`.

| paso | resultado |
|---|---|
| `npm run build` (purity + typecheck + tsc) | exit 0 |
| `npm test` (`:memory:` + OpenFGA) | **2053 passed, 3 skipped (2056)** (cierre 4: 2046) |
| `test:sqlite-file` | **2081 passed, 3 skipped (2084)** |
| `test:pg` | **2178 passed, 2 skipped (2180)** |
| `test:mysql` | **2180 passed, 2 skipped (2182)** |
| `cutover-runbook` sqlite-file / pg | VERDE / VERDE (2 / 2) |
| `check:flag-mutants` | **37 / 37 muertos**, 1 pendiente (`--prune-undeclared`), VERDE |
| `check:guard-mutants` `:memory:` (8 workers, filtrado) | **188 / 188 muertos, 33 s de pared** (cierre 4: 181 en 962 s); con 4 workers (lo de CI) 47 s |
| `check:guard-mutants --db sqlite-file --skip-db-independent` | **165 / 165 muertos, 24 s** ⇒ la matriz de CI completa, ~1 min local |
| la 1.ª corrida del corredor en la verificación | 187/188: `rec.apply.expired-deletes-in-order` VIVO ⇒ fila C2-2 nueva (§2.2), y muerto |
| exhaustivo con vigencia E1-reduced (`AUTHZ_ORDER_VIGENCIA_EXHAUSTIVE=1`) | 2 × 33 554 432, 0 sin residuo, 0 malformados (cifras de §2.3) |
| reproducciones del auditor | `loteD2-auditor-cierre4.ts` y `panel-optimo-auditor-model-drift.ts`: tablas de §2.2 y §3.1 |

Nada queda corriendo en segundo plano. Stores efímeros de OpenFGA: los borran las propias suites/repros.

## No hecho / declarado

- `c43.raced.same-code` fuera del corredor (necesita servidor; §2.4).
- La densidad de particiones negadas en el universo «dos Write» (76–99 %) es del universo (todo deny del destino lleva
  caducidad), no de la vida real; declarado.
- E3 tiene ~5× más pares con ciclo que en el cierre 4 (precio de contar la membresía como concesión); todos residuo
  avisado («orden SIN garantía»), 0 sin residuo.
- D4-5: ventana declarada (arista concurrente entre la lectura del scope y el borrado a ciegas, sin contar).
- R2: una lectura del modelo por proceso también para tipos sin deny (antes: sin coste); la deriva del modelo de ROLES
  frente al catálogo no se midió.
- El `schedule` nocturno de CI corre todo el workflow, no solo `guard-mutants-full`.
- `CLAUDE.md`, `linajes.md` (candidato «guarda modelo ↔ config a medias», 4 apariciones), `RETOMAR.md`: le tocan al
  coordinador (mapa: fuera `relationWithheldWrites`/`withheld-by-unsafe-deny`/`carrier-conflict`; dentro
  `partitionsRefused`/`RelationsPartitionRefusal`/`partitionRefusalRecipe`, `walkVigencia`, propiedad
  `openfga.model.drift`, flags `--jobs`/`--full`/`--skip-db-independent` del corredor).
