# Sublote D2 — repaso adversarial del CIERRE 5 (auditor, 2026-10-16), opción A

**Cómo se trabajó**
- Árbol: `main` sobre `75353fe`, con D2 y los cierres 1–5 sin commit.
- Solo lectura sobre el repo.
- Escrito: este informe y cinco ficheros en `.claude/reproducciones/`:
  - `loteD2-auditor-cierre5.ts` (E1–E4, `:8090`);
  - `loteD2-auditor-cierre5-d31.ts` (punto 4);
  - `loteD2-auditor-cierre5-orden.ts` (fuerza bruta, otras semillas);
  - `loteD2-auditor-cierre5-orden-extra.ts` + `loteD2-auditor-cierre5-bfhelper.ts` (copia del helper con tres universos nuevos).
- Entorno: SQLite `:memory:` y stores efímeros `aud-d2c5-*` en OpenFGA, borrados. Comprobado al terminar: 0 residuales.
- Sin docker restart, sin gates y sin `test:pg|mysql`.
- La línea base aislada del corredor (punto 5) se corrió sobre copias del árbol en el scratchpad, ya borradas.

```
source ~/.config/nvm/nvm.sh && nvm use 22
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre4.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-auditor-model-drift.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre5.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre5-d31.ts
node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre5-orden.ts
node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre5-orden-extra.ts
```

## Veredicto en una línea

**APTA con reservas.** Sin 🔴 ni 🟠.

**Cerrado en efecto:**
- D4-1, D4-2, D4-3, D4-4 y R2: re-ejecutados, salen en el sentido correcto.
- La partición negada recibe de verdad cero escrituras y cero borrados en todos los caminos que el PLAN decide.
- La fuerza bruta del orden nuevo da 0 sin residuo, también fuera de las semillas fijadas y en tres universos que el paquete no tiene.

**Quedan dos 🟡** que conviene cerrar antes de sellar (cada arreglo es de pocas líneas):
- **D5-1.** El plan y el driver no están de acuerdo sobre qué es una portadora. Un deny del destino ya VENCIDO hace que la pasada REAL reviente con un 409 que el dry-run no anunció, y las particiones siguientes no migran. Rompe «dry == real» y «el resto migra» en ese caso.
- **D5-2.** La excepción D8 de R2 compara solo `<rel>`, no `denied_<rel>`. Con un modelo hecho a mano, `openfga` concede donde `database` niega, sin error.

Además hay tres ⚪ (letra, contador de D4-5 y línea base del corredor filtrado).

---

## 1. D4-1…D4-5 y R2: re-ejecución

`loteD2-auditor-cierre4.ts` contra `:8090`:

| repro | cierre 4 | ahora |
|---|---|---|
| D4-1 | se retenía `U∈K`; el destino concedía Y y la línea decía lo contrario | dry = real: `written 0, updated 0`. Partición negada; el destino concede Y antes y después (deriva previa, a la vista). Ninguna línea dice «más restrictivo» |
| D4-2 | con `--prune` se retenía el borrado; `member K` daba true | `deleted 0`; `U∈K` sigue (deriva previa, `por borrar 1`). El README ya no dice «Withholding only restricts» |
| D4-3 | 500 `carrier-conflict` y P2 no migraba | `--prune` real con **ÉXITO**: P negada, **P2 migra** (`V viewer W` true); tuplas 6 → 7 |

**`panel-optimo-auditor-model-drift.ts`**
- `note` sin deny: `THROW 500 E_AUTHZ_CONFIG`, y `database` da false.
- Con `deny:'read'`: lo mismo.
- **R2 cerrado** para el caso medido. La excepción D8 deja un hueco: D5-2.

**D4-4:** letra corregida (`commands/authz_relations_reconcile.ts:212-218`).

**D4-5:** cambió en efecto, no solo en letra. Ver ⚪ D5-4.

## 2. Partición negada

**Lo que resiste (✅ en código y medido):**
- **Cero escrituras y cero borrados.** `reconcileRelations` hace `refusePartition` y `continue` antes de `applyPartition` (`reconcile.ts:654-657`), así que no se llega a ninguna operación del driver:
  - ni `expiredDelete` (solo se borra dentro de `applyPartition`, `:806-807`);
  - ni la poda con `--prune`;
  - ni denies.
  - `massDelete && !refusal` (`:1409`): el seguro de borrado masivo no la cuenta.
- **Lo decide el plan, así que dry == real en los números.** D4-3 está medido en las dos, y E3/E4 dan la misma partición negada.
- **Fallo a mitad de pasada de OTRA partición:**
  - `partialReconcileError` suma las filas ya visitadas.
  - Una negada ya visitada aparece `refused` con 0; una posterior aparece `pending`/«sin tocar», que es verdad.
  - La marca parcial solo depende de `progress.writes`, y la negada no suma nada.
- **Frontera de partición:**
  - En `openfga` el userset comparte la clave de partición del objeto (`#subjectUser`/`#objectId`), y `#carriedDeny` filtra `t.object` por `<type>:<partitionKey>|`.
  - En `database` el trigger rechaza el userset cruzado.
  - Un tenant **no** puede hacer que se niegue la partición de otro con su API. La única negativa global que queda es la puerta del deny (`denyGate`, D2), que ya estaba declarada y depende de la config o de filas a mano.
- **Línea y exit:**
  - `partición NEGADA <p>:` sale a nivel `error` con causas, «COMO ESTABA», pendientes y receta.
  - `clean` exige `partitionsRefused.length === 0`, así que el exit es 1 en dry y en real.
  - ⚪ menor: en la real se imprime primero `success` «Relaciones … reconciliadas» y después el aviso. Es el patrón de siempre con residuo.

**Lo que NO resiste:** D5-1, porque el plan no ve lo mismo que el driver. Y la letra de «COMO ESTABA» no avisa de que ese estado evoluciona con el tiempo (⚪ D5-3, E3).

## 3. `relationTransitionOrder` (C3 cuenta la membresía, C4 con la exclusión de C2)

**Código real con semillas propias** (`loteD2-auditor-cierre5-orden.ts`): 400 000 pares por corrida; semillas 1, 7 y 4242; plano, vigencia atómica y vigencia con dos Write.

| universo | plano (residuo / conceden) | atómico | dos Write (negadas) | sin residuo | malformados |
|---|---|---|---|---|---|
| E1 ×3 | 768–858 / 152–175 | 2 481–2 610 / 278–329 | 175–206 / 35–51 (350 k) | **0** | 0 |
| U2 ×3 | 1 454… / 70… | 5 227… / 199… | 26… / 2… (397 k) | **0** | 0 |
| E3 ×3 | 27 934–28 114 / 1 024–1 083 | 74 441–74 686 / 2 109–2 167 | 308–365 / 20–28 (394 k) | **0** | 0 |

**Fuera de los universos del paquete** (`-orden-extra.ts`, copia del helper con su oráculo, que cuenta `group:` y no tiene `preexisting`):

| universo | qué ejercita | resultado |
|---|---|---|
| **E4** | 2 usuarios y DOS niveles (a ⊂ b ⊂ c); no existe en el paquete, que tiene U2 con 2 usuarios y 1 nivel, y E3 con 1 usuario y 2 niveles | 300 k × 2 semillas × 3 modos: conceden 568–2 280; **0 sin residuo** |
| **E5** | CICLO de grupos (g ⊂ h ⊂ g) | exhaustivo, 8,4 M pares: 0 conceden y 0 malformados. No discrimina, pero no rompe ni cuelga `#groupHeight` |
| **E6** | diamante a ⊂ b,c ⊂ d con denies en b y c | conceden 1 186–4 681; **0 sin residuo** |

**Fidelidad del oráculo nuevo:**
- (usuario, `group:G`) concede si el usuario alcanza `G#member`. Es fiel: `group` no admite deny (422), así que ser miembro es exactamente `check(member)`.
- La exclusión `refused` es correcta como exclusión de la *pasada*, porque cero escrituras implica que el estado es el inicial.
- Lo que no mide, ni pretende, es que el inicial evolucione y conceda con el tiempo. Eso es la consecuencia aceptada de A (E3, ⚪ D5-3).
- `oracle` usa la regla a mano (`allows>0 && denies==0`) en lugar de `cutPathAllows`. Es equivalente con UNA relación, que es lo que usa el universo.

**Sin regresión medida.**
- El precio es precisión: el 18,6 % de los pares de E3 atómico tienen ciclo y por tanto aviso «orden SIN garantía».
- Está declarado en el informe del implementador.

## 4. D-31 ampliada: la excepción «tipo sin opt-in acepta la forma con deny»

Hueco medido: 🟡 D5-2.

Además, ⚪ dentro del mismo punto:
- `#assertModelDeny` solo compara los tipos de la operación (`distinct`), nunca `group`.
- Una deriva de `group#member` en el modelo fijado (solo posible a mano, porque el paquete siempre genera `member: this`) no se detecta en un `check` de `document`.

## 5. Corredor filtrado de mutantes

**Lo que resiste:**
- **El criterio de muerte es idéntico en los dos modos:** solo miran `expectRed` (`judge`); `collateral` es informativo.
  - Un mutante no puede morir en completo y sobrevivir en filtrado por colaterales.
  - El único sentido peligroso es el falso «muerto» en filtrado: un caso de `expectRed` que se pone ROJO al correr aislado aunque el código esté sano, por dependencia de orden u otro estado compartido.
- **Lo medí:**
  - Hay 159 conjuntos distintos de `expectRed`, que cubren los 188 mutantes.
  - Corrí cada conjunto SIN mutar, aislado, con el mismo `--tests=` que usa el corredor: **todos verdes, 0 sin ejecutar** (27 s, 6 workers).
  - Hoy no hay falsos muertos por aislamiento.
- **`--skip-db-independent`:**
  - Solo lo usa la pierna `sqlite-file`. `:memory:` es el mismo motor y corre los 23 mutantes de `tuple_order.ts`/`reconcile.ts`.
  - PG y MySQL nunca corrieron mutantes (no es nuevo).
  - Resiste.
- **Un `--tests` que no casa** da SIN-CASO, que cuenta como vivo con exit 1: es ruidoso. Resiste.

Lo que no resiste: ⚪ D5-5.

## 6. Letra del 409 y del README «The limit»

**Lo que resiste:**
- La receta del 409 (`errors.ts:472-481`) y la de la partición (`reconcile.ts:483-502`) no presentan nada como seguro.
- (2) dice «ACEPTANDO la ventana» y qué concede la ventana.
- Fuera «retira antes el deny».
- El TOCTOU de N1 está declarado.
- Hay enlace a #2151.
- Ninguna receta reabre una ventana sin decirlo.

**Lo que es inexacto:** ⚪ D5-3 (E3, E4 y la frase «the reconcile refuses that partition», que D5-1 falsa).

## 7. D4-5: ¿solo letra o efecto?

**Efecto.**
- Hasta el cierre 4 el contador sobre-notificaba: lado seguro.
- Ahora cuenta solo las aristas `#binding` vistas en una lectura previa. Eso abre una ventana de SUB-notificación más ancha que la declarada: ⚪ D5-4.

---

## Hallazgos (por severidad)

### 🟡 D5-1 · Plan y driver discrepan sobre la portadora: con un deny VENCIDO en el destino la pasada real revienta (409) donde el dry-run dice «done», y las particiones siguientes no migran

**Escenario**
- **Precondición:**
  - Destino `openfga` con un `denied_viewer` sobre `group:G#member`, escrito con condición `not_expired` y ya vencido. Es el «deny condicional escrito fuera del paquete» que el propio plan reconoce como caso real (`deny-conditional`).
  - El origen no tiene ese deny.
  - `U∈G` dura 1 h en el destino y 1 día en el origen.
  - Pasada sobre `[P, P2]`, con P2 de otro tenant y trabajo pendiente.
- **Acción:** `reconcileRelations` dry y real, sin `--prune`.
- **Resultado (E1, `:8090`):**
  ```
  dry   written 1 · updated 1 · status [done, done] · refused []
  real  409 E_AUTHZ_RENEWAL_UNSAFE «el grupo TRANSPORTA un deny vivo (…)» · status [failed, pending]
  P2 migró (V viewer W): false
  ```
  - Pasa en cada pasada, mientras no se use `--prune` (E2: con `--prune` la vencida se borra primero y todo pasa) o hasta que alguien borre el deny a mano.
  - El mensaje dice «vivo», y es falso.

**Evidencia**
- ✅ Medido (E1/E2).
- ✅ El plan trata como AUSENTE la tupla vencida del destino (`reconcile.ts:1268-1271`). No entra en `orderContext` ni en `denyCarrierGroups` (`:1337`, `:1352`), así que la renovación va a `toUpdate`.
- ✅ El driver no mira la caducidad del DENY (`openfga_relations_driver.ts:803-816`): `#carriedDeny` acepta toda tupla `denied_*` del userset y solo filtra por caducidad las aristas de anidación (`:820`).
- ✅ Contradice la letra en tres sitios:
  - README: «A destination tuple that is expired at the pass's `now` is ABSENT for the plan … (no carrier …)».
  - README «The limit»: «the reconcile refuses that partition».
  - El criterio del brief del coordinador: «Se decide en el PLAN: `--dry-run` y la pasada real dan los mismos números … el resto de particiones migra».
- La otra discrepancia del mismo tipo, por razonamiento (❓ sin medir): un deny residuo del destino (relación retirada de `toConfig` y por tanto `undeclared`) tampoco está en `orderContext`, y el driver sí lo ve.

**Steelman del defensor:** «Hace falta un deny con condición escrito a mano. Falla CERRADO: un 409 sin escrituras en esa tupla, nunca una concesión. Con `--prune` desaparece.»
- **¿Me convence?** Para no subirlo de 🟡, sí: no concede nada.
- Para cerrarlo, no:
  - Es justo la clase de defecto que el cierre 5 decía eliminar estructuralmente: la decisión en el plan, dry == real y una partición que no bloquea a las demás.
  - El estado de partida es uno que el paquete ya admite como real.
  - Mientras dure, una partición con ese residuo vuelve a bloquear a todas las que vienen detrás, que es D4-3 por otra puerta.

**Mitigación mínima:** en `#carriedDeny`, ignorar el deny vencido (`isActiveExpiry(t.validUntil, now)`, la misma regla de C2-4). Alternativa más conservadora: que el plan cuente como portadora también la vencida, lo que lleva a negar la partición. Una de las dos, con un caso E1.

### 🟡 D5-2 · R2: la excepción D8 compara solo `<rel>` y no `denied_<rel>`: un modelo a mano sin el cierre del corte de camino concede en `openfga` lo que `database` niega, sin error

**Escenario**
- **Precondición:**
  - Tipo `note` con `editor` y `viewer ⊇ editor`.
  - Config del pod **sin opt-in** del deny: el estado D8.
  - El modelo fijado tiene la forma CON deny, pero con `denied_editor = this` (sin `or denied_viewer`).
  - Hay filas `editor@U` y `denied_viewer@U`, escritas por otro proceso.
- **Acción:** `check(U, editor, N)`.
- **Resultado (`loteD2-auditor-cierre5-d31.ts`):**
  ```
  pod SIN opt-in:  openfga editor TRUE · database editor FALSE (honra el deny siempre, con el corte D5)
  control pod CON opt-in, mismo modelo: 500 E_AUTHZ_CONFIG
  ```

**Evidencia**
- ✅ Medido.
- ✅ `openfga_relations_driver.ts:515-528`: `alternative` solo se aplica a las claves de `expectedRelations`, que son los `<rel>` sin deny. `denied_<rel>` no se compara.
- ✅ El bloque `out` (`:536-551`), para un tipo sin opt-in, solo exige la forma `subtract`.
- Es el ⚪ N4 de D1 reabierto para los tipos sin opt-in, y justo por la excepción añadida en este cierre.

**Steelman del defensor:** «El generador del paquete siempre emite el cierre. Solo un modelo escrito a mano llega aquí, y la excepción hacía falta para D8 y para el 🟡 3 de `decideMany`.»
- **¿Me convence?** Para la severidad, sí: hace falta una configuración inusual, así que es 🟡 y no el 🟠 de R2.
- Para dejarlo, no: R2 se aceptó precisamente como «el modelo fijado no puede contradecir a la config sin error», y aquí lo contradice.

**Mitigación mínima:** cuando se acepta `alternative[rel]`, exigir además `sameRewrite(served[denied_rel], alternative[denied_rel])`. De paso, incluir `group` en los tipos comparados de toda operación (el ⚪ del punto 4).

### ⚪ D5-3 · Letra: «COMO ESTABA» no es estático, la receta (1) no desbloquea la partición y «the reconcile refuses that partition» no es universal

- **E3 (medido):**
  - Destino con `U viewer X` y `U∈H` de 1 h (H transporta deny viewer X); origen con `U∈H` de 1 día.
  - La partición queda negada. En `now` el destino niega; **a +2 h el destino CONCEDE X y el origen niega**.
  - La línea `renewal-unsafe` dice «Desde <vieja> el destino ya no transporta ese deny por esta membresía», pero no dice que desde entonces concede lo que ese deny corta.
  - El README presenta «So the PARTITION is refused» como respuesta a «Not renewing is not neutral over time». La partición negada es exactamente «no renovar»: la no neutralidad sigue. Está aceptado por la decisión A, pero la letra tiene que decirlo.
- **E4 (medido):**
  - Se aplica la receta (1) al pie de la letra: la membresía pasa a SIN caducidad en el ORIGEN, y se repite.
  - La 2.ª pasada sigue NEGADA: 1 h frente a `null` también es un cambio de caducidad.
  - (1) es un patrón para el futuro, no una salida para la partición ya negada. Salidas reales hoy:
    - `unrelate` en el origen;
    - (2) en el destino;
    - esperar a que venza la vieja (entonces la tupla queda ausente, la reescritura es una escritura normal y la partición migra sola), con el intervalo E3 en medio.
- **README «The limit»:** «the reconcile refuses that partition» es falso en el caso D5-1, donde aborta con un 409.
- **Comentario rancio** en `applyPartition` (`reconcile.ts:~809`): «con los allows que corta retenidos». La retención ya no existe.
- **Steelman del defensor:** «la línea ya dice "desde X ya no transporta ese deny"». Me convence a medias: el operador tiene que deducir la concesión.

### ⚪ D5-4 · D4-5: el contador nuevo puede SUB-notificar, y la ventana declarada es más estrecha que la real

- **Escenario:**
  - Un `grant` concurrente escribe sus tres tuplas en el scope que se purga, entre la lectura `visible` y el borrado a ciegas de la fase 1.
  - Sus aristas se borran sin contarse.
  - Si la siguiente request falla (el `Read` de `purgeable` o el `deleteTuples` de la fase 2), el error sale **sin** `markPartialWrite`, y `onWrite` no recibe `indeterminate` aunque se borraron aristas que cambiaban una respuesta.
- **Evidencia:**
  - ✅ `openfga_driver.ts`, `steps()`: `visible` se lee antes, y en `deleteKeys(…, effective)` el filtro descuenta.
  - El docblock dice «(la fase 2 borra después su `assignee`, que sí cuenta)», pero eso supone que la fase 2 llega a correr.
  - ❓ No lo medí contra el servidor: hace falta un espía con barrera y fallo.
- **Steelman del defensor:** «el scope se está desligando: desde (c2r) ya no concede nada, así que el efecto en `authorize` es nulo; solo cambia la auditoría». Me convence: ⚪.
  - Pero hasta el cierre 4 el error iba al lado seguro (sobre-notificar) y ahora va al inseguro, en una ventana estrecha.
- **Mitigación:** declararlo bien. Otra opción: contar la arista si `visible` la tenía O si la fase 2 aún no confirmó su ausencia.

### ⚪ D5-5 · Corredor filtrado: la línea base es el spec ENTERO y se juzga por títulos AISLADOS; los 9 mutantes nuevos nunca se juzgaron en completo

- **Riesgo:** un caso que esté rojo aislado sin mutar «mataría» siempre a sus mutantes en filtrado. La línea base completa no lo ve.
- **Hoy:** medí los 159 conjuntos y todos están verdes aislados, así que el riesgo es para el futuro.
- **La prueba de equivalencia** (`compare_guard_mutants.mjs`) se hizo con 181 mutantes sobre el árbol del cierre 4, con todos «muerto» en los dos modos. Los 9 nuevos solo están juzgados en filtrado; la nocturna `--full` los cubrirá.
- **Mitigación:** una línea base filtrada en el propio corredor (correr cada conjunto `expectRed` sin mutar; ~27 s con 6 workers) o, al menos, la unión una vez.

## Lo que intenté y NO se rompió

- D4-1…D4-4 y R2: re-ejecutados, todos en el sentido correcto (§1).
- Partición negada:
  - cero escrituras y cero borrados, también con `--prune`, en las vencidas y en `expiredDelete`;
  - el seguro de borrado masivo no la cuenta;
  - dry == real en los casos decididos por el plan;
  - el fallo a mitad de pasada de otra partición deja un reporte veraz;
  - exit ≠ 0.
- Frontera de partición: ni un userset cruzado (FGA por clave de partición; `database` por trigger) ni `#carriedDeny` (filtra por partición). Un tenant no niega la partición de otro.
- Fuerza bruta del código real:
  - 27 corridas de 400 k (E1/U2/E3 × 3 semillas × 3 modos);
  - tres universos nuevos: E4 con 2 usuarios y 2 niveles, E5 con un ciclo de grupos (exhaustivo, 8,4 M) y E6 con un diamante;
  - **0 sin residuo, 0 malformados**.
- Oráculo con `group:`: fiel, porque `group` no admite deny.
- Corredor filtrado: 159 conjuntos `expectRed` verdes aislados sin mutar; `--tests` que no casa da SIN-CASO (ruidoso); `--skip-db-independent` solo salta en el mismo motor.
- Recetas del 409 y de la partición: ninguna se presenta como segura ni reabre una ventana sin decirlo.
- Stores: cero `aud*` residuales en `:8090`.

## Preguntas abiertas para el arquitecto

1. 🟡 D5-1: ¿`#carriedDeny` ignora el deny vencido (coherente con C2-4 y con «vencida = ausente» del plan), o el plan cuenta la vencida como portadora y niega la partición?
2. 🟡 D5-2: ¿se compara también `denied_<rel>` en la excepción D8 (y `group` en toda operación)?
