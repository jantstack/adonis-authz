/**
 * Modo `facts` (3b-2a) — el GENERADOR del modelo (c2) y la PROYECCIÓN del
 * catálogo. Pieza pura: aquí no hay `authorize` ni camino caliente.
 *
 * El modelo (c2) es el que fijó el panel 2 (`panel2-2026-08-28-juez.md`,
 * cruce 1) y no se rediseña: se compara con el literal del plan y se escribe
 * contra el servidor REAL (`OPENFGA_TEST_URL`). Si el servidor lo rechaza, el
 * generador está mal, no el servidor.
 */

import { test } from '@japa/runner'
import {
  FACTS_MAX_RESOLVE_DEPTH,
  FACTS_MODEL_MAX_BYTES,
  FGA_MAX_BATCH_CHECK,
  FGA_MAX_OBJECT_ID,
  FGA_MAX_RELATION_NAME,
  factsCatalogTuples,
  factsModelBytes,
  factsRootTuples,
  openFgaFactsModel,
  assertFactsModelPublishable,
} from '../src/openfga.js'
import { OpenFgaAuthorizationDriver } from '../src/openfga.js'
import { syncAuthzCatalog, syncCatalogs } from '../src/catalog/catalog.js'
import { catalogSyncOptions } from '../commands/authz_catalog_sync.js'
import { invalidateAuthzCatalog, withAuthzCatalogWrite } from '../src/catalog/catalog_cache.js'
import { DatabaseAuthorizationDriver } from '../src/drivers/database_driver.js'
import { cleanAuthzTables } from './helpers/schema.js'
import db from '@adonisjs/lucid/services/db'
import { readFile } from 'node:fs/promises'
import { APP_SCOPE } from '../src/types.js'
import type { AuthorizationDriver } from '../src/types.js'
import { memoryScopeTree, resolveChainFrom } from '../src/testing/main.js'
import { assertValidSlug } from '../src/identity.js'
import { defineRelationsConfig } from '../src/relations/define_relations_config.js'
import { AuthorizationManager } from '../src/manager.js'
import { v7 as uuidv7 } from 'uuid'

/** Los tres holders y los dos permisos del literal del plan. */
const HOLDERS = { users: 'user', admins: 'admin', integrations: 'integration' }
const PERMISSIONS = ['docs:read', 'docs:write']

/** `[user:*, admin:*, integration:*]` — el catálogo de (c2) por comodín de USUARIO. */
const WILDCARDS = [
  { type: 'user', wildcard: {} },
  { type: 'admin', wildcard: {} },
  { type: 'integration', wildcard: {} },
]
/** `[user, admin, integration]` — los denies, sin condición (no caducan hoy). */
const DIRECT = [{ type: 'user' }, { type: 'admin' }, { type: 'integration' }]
/** `[<holders> with not_expired]` — la asignación, con y sin caducidad. */
const DIRECT_WITH_EXPIRY = [
  ...DIRECT,
  { type: 'user', condition: 'not_expired' },
  { type: 'admin', condition: 'not_expired' },
  { type: 'integration', condition: 'not_expired' },
]

const ttu = (tupleset: string, relation: string) => ({
  tupleToUserset: { tupleset: { relation: tupleset }, computedUserset: { relation } },
})
const computed = (relation: string) => ({ computedUserset: { relation } })

/**
 * El modelo (c2) para `docs:read` y `docs:write` con tres holders, escrito a
 * mano desde el literal del plan. Si el generador se desvía de esto, se
 * desvía del diseño que el juez validó contra el servidor real.
 */
const EXPECTED = {
  schema_version: '1.1',
  type_definitions: [
    { type: 'user', relations: {}, metadata: null },
    { type: 'admin', relations: {}, metadata: null },
    { type: 'integration', relations: {}, metadata: null },
    {
      type: 'role',
      relations: {
        permits_docs_read: { this: {} },
        permits_docs_write: { this: {} },
      },
      metadata: {
        relations: {
          permits_docs_read: { directly_related_user_types: WILDCARDS },
          permits_docs_write: { directly_related_user_types: WILDCARDS },
        },
      },
    },
    {
      type: 'role_binding',
      relations: {
        role: { this: {} },
        assignee: { this: {} },
        docs_read: {
          intersection: { child: [computed('assignee'), ttu('role', 'permits_docs_read')] },
        },
        docs_write: {
          intersection: { child: [computed('assignee'), ttu('role', 'permits_docs_write')] },
        },
      },
      metadata: {
        relations: {
          role: { directly_related_user_types: [{ type: 'role' }] },
          assignee: { directly_related_user_types: DIRECT_WITH_EXPIRY },
          docs_read: { directly_related_user_types: [] },
          docs_write: { directly_related_user_types: [] },
        },
      },
    },
    {
      type: 'scope',
      relations: {
        parent: { this: {} },
        binding: { this: {} },
        docs_read: { union: { child: [ttu('binding', 'docs_read'), ttu('parent', 'docs_read')] } },
        denied_docs_read: { union: { child: [{ this: {} }, ttu('parent', 'denied_docs_read')] } },
        can_docs_read: {
          intersection: {
            child: [
              { difference: { base: computed('docs_read'), subtract: computed('denied_docs_read') } },
              computed('rooted'),
            ],
          },
        },
        docs_write: {
          union: { child: [ttu('binding', 'docs_write'), ttu('parent', 'docs_write')] },
        },
        denied_docs_write: { union: { child: [{ this: {} }, ttu('parent', 'denied_docs_write')] } },
        can_docs_write: {
          intersection: {
            child: [
              { difference: { base: computed('docs_write'), subtract: computed('denied_docs_write') } },
              computed('rooted'),
            ],
          },
        },
        ancestor: { union: { child: [computed('parent'), ttu('parent', 'ancestor')] } },
        // (c2r) — «desde aquí se llega a la raíz». Solo `scope:app` la tiene
        // directa (el marcador de raíz); todo lo demás la hereda por `parent`.
        rooted: { union: { child: [{ this: {} }, ttu('parent', 'rooted')] } },
      },
      metadata: {
        relations: {
          parent: { directly_related_user_types: [{ type: 'scope' }] },
          binding: { directly_related_user_types: [{ type: 'role_binding' }] },
          docs_read: { directly_related_user_types: [] },
          denied_docs_read: { directly_related_user_types: DIRECT },
          can_docs_read: { directly_related_user_types: [] },
          docs_write: { directly_related_user_types: [] },
          denied_docs_write: { directly_related_user_types: DIRECT },
          can_docs_write: { directly_related_user_types: [] },
          ancestor: { directly_related_user_types: [] },
          rooted: { directly_related_user_types: WILDCARDS },
        },
      },
    },
  ],
  conditions: {
    not_expired: {
      name: 'not_expired',
      expression: 'current_time < valid_until',
      parameters: {
        current_time: { type_name: 'TYPE_NAME_TIMESTAMP' },
        valid_until: { type_name: 'TYPE_NAME_TIMESTAMP' },
      },
    },
  },
}

test.group('facts · A1 — el generador del modelo (c2)', () => {
  test('openFgaFactsModel(holderTypes, permissions) es el literal del plan para 2 permisos y 3 holders', ({
    assert,
  }) => {
    assert.deepEqual(openFgaFactsModel(HOLDERS, PERMISSIONS), EXPECTED)
  })

  /**
   * **Gemelo de roles del 🟠 N1 (cierre 2 de D2): «no aplica», con evidencia.** `grant` con otra caducidad en `facts`
   * TAMBIÉN es delete + write (`replaceAssignment`, dos llamadas: M5), pero lo que se renueva es un `assignee` y el deny
   * de roles NO viaja por él: `denied_<P>` vive en `scope`, admite como sujeto DIRECTO solo a los holders (ni usersets ni
   * `*`) y solo se hereda por `parent`. Un `assignee` renovado no transporta nada que corte: en el hueco el holder solo
   * PIERDE el grant (fail-closed), nunca un deny. Si un día `denied_<P>` admitiera `role_binding#assignee` (o cualquier
   * userset), este caso se pone rojo y el gemelo pasa a aplicar.
   */
  test('gemelo de roles de N1 · denied_<P> solo admite holders DIRECTOS y solo se hereda por parent: un assignee renovado (delete + write) no puede transportar un deny', ({ assert }) => {
    const model = openFgaFactsModel(HOLDERS, PERMISSIONS) as any
    const holders = Object.values(HOLDERS).sort()
    let deniedRelations = 0
    for (const type of model.type_definitions) {
      for (const [name, rewrite] of Object.entries<any>(type.relations ?? {})) {
        if (!name.startsWith('denied_')) continue
        assert.equal(type.type, 'scope', `${type.type}#${name}: el deny de roles solo existe en scope`)
        deniedRelations++
        const direct = type.metadata.relations[name].directly_related_user_types
        assert.deepEqual(direct.map((t: any) => t.type).sort(), holders, `${name}: solo holders`)
        for (const t of direct) {
          assert.notProperty(t, 'relation', `${name}: ningún userset (${JSON.stringify(t)})`)
          assert.notProperty(t, 'wildcard', `${name}: ningún comodín`)
        }
        // La única vía indirecta es `denied_<P> from parent` (nunca por binding/assignee).
        const json = JSON.stringify(rewrite)
        assert.notInclude(json, 'binding')
        assert.notInclude(json, 'assignee')
        assert.include(json, '"parent"')
      }
    }
    assert.equal(deniedRelations, PERMISSIONS.length, 'una denied_<P> por permiso')
  })
})

/**
 * A1, segunda mitad: **el modelo se escribe contra el servidor REAL**. Un
 * generador que produce JSON bonito y que OpenFGA rechaza no vale nada, y el
 * literal de arriba no lo demuestra. Además se ejercita la SEMÁNTICA mínima
 * de (c2) —herencia hacia abajo por `parent` y deny explícito que gana—,
 * porque un modelo aceptado que no decide lo que dice el invariante 1 y el 2
 * también sería un generador roto. Esto NO es `authorize`: el driver sigue
 * siendo el de hoy (el lote es aditivo); son tuplas y un `Check` crudos.
 */
const openFgaTestUrl = process.env.OPENFGA_TEST_URL
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · A1 — el servidor real acepta el modelo (c2)', (group) => {
    const stores: string[] = []

    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    async function storeWithFactsModel(): Promise<any> {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-model-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const client = new OpenFgaClient({ apiUrl, storeId: store.id })
      const model = await client.writeAuthorizationModel(openFgaFactsModel(HOLDERS, PERMISSIONS))
      return { client: new OpenFgaClient({ apiUrl, storeId: store.id, authorizationModelId: model.authorization_model_id }), modelId: model.authorization_model_id }
    }

    test('OpenFGA acepta el modelo generado y devuelve un authorization_model_id', async ({
      assert,
    }) => {
      const { modelId } = await storeWithFactsModel()
      assert.isString(modelId)
      assert.isNotEmpty(modelId)
    })

    /**
     * A3 — la medida del techo tiene que ser LA DEL SERVIDOR. OpenFGA cuenta
     * el tamaño protobuf del modelo (`proto.Size`), no el JSON: la razón
     * proto/JSON va de 0,33 a 0,57 según la longitud de los slugs, así que
     * medir el JSON deja pasar lo que el servidor rechaza o rechaza catálogos
     * legales por el doble de margen. Aquí se contrasta con el número que el
     * propio servidor reporta, que es el único oráculo que hay.
     */
    test('factsModelBytes cuenta LOS MISMOS bytes que el servidor (cuatro formas de catálogo)', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `facts-size-${Date.now()}` })
      stores.push(store.id!)
      const client = new OpenFgaClient({ apiUrl, storeId: store.id })

      const shapes: Array<[string, Record<string, string>, number, (i: number) => string]> = [
        ['1 holder, slug corto', { users: 'user' }, 1500, (i) => `p${i}`],
        ['3 holders, slug corto', HOLDERS, 800, (i) => `p${i}`],
        ['3 holders, slug de 40', HOLDERS, 500, (i) => `p${i}`.padEnd(40, 'x')],
        [
          '6 holders, slug corto',
          { u: 'user', a: 'admin', i: 'integration', b: 'bot', s: 'service', t: 'team' },
          700,
          (i) => `p${i}`,
        ],
      ]
      for (const [name, holders, count, slug] of shapes) {
        const model = openFgaFactsModel(
          holders,
          Array.from({ length: count }, (_, i) => slug(i))
        )
        let reported: number | null = null
        try {
          await client.writeAuthorizationModel(model)
        } catch (error: any) {
          reported = Number(/limit: (\d+) bytes/.exec(String(error?.message))?.[1] ?? NaN)
        }
        assert.isNotNull(reported, `${name}: el modelo tenía que pasarse del techo para que el servidor diga su cuenta`)
        assert.equal(factsModelBytes(model), reported, name)
      }
    })

    test('la semántica de (c2): el catálogo por tuplas concede, el árbol hereda hacia abajo y el deny gana', async ({
      assert,
    }) => {
      const { client } = await storeWithFactsModel()
      const role = 'role:0192f000-0000-7000-8000-000000000001'
      const binding = 'role_binding:app|0192f000-0000-7000-8000-000000000001'
      const child = 'scope:organization|0192f000-0000-7000-8000-0000000000aa'

      await client.writeTuples([
        // **El marcador de raíz de (c2r)** (3b-2i): este montaje escribe las
        // tuplas A PELO, sin pasar por `syncAuthzCatalog`, así que tiene que
        // poner el marcador él mismo. Sin él `rooted` es falso en TODO el
        // store y `can_<P>` no concede en ninguna parte — es el modo de
        // fallo que fija el caso I5, y el caso lo documenta aquí de paso.
        { user: 'user:*', relation: 'rooted', object: 'scope:app' },
        // Catálogo proyectado: el rol vincula docs:read para CUALQUIER holder.
        { user: 'user:*', relation: 'permits_docs_read', object: role },
        // Asignación: el binding apunta al rol y tiene a u1 de asignado.
        { user: role, relation: 'role', object: binding },
        { user: 'user:u1', relation: 'assignee', object: binding },
        // Árbol: el binding cuelga de app y la organization cuelga de app.
        { user: binding, relation: 'binding', object: 'scope:app' },
        { user: 'scope:app', relation: 'parent', object: child },
      ])

      const inherited = await client.check({
        user: 'user:u1',
        relation: 'can_docs_read',
        object: child,
        context: { current_time: new Date().toISOString() },
      })
      assert.isTrue(inherited.allowed, 'un grant en app tiene que valer en la organization (invariante 1)')

      // Un permiso que el rol NO vincula no se concede aunque la asignación exista.
      const other = await client.check({
        user: 'user:u1',
        relation: 'can_docs_write',
        object: child,
        context: { current_time: new Date().toISOString() },
      })
      assert.isFalse(other.allowed, 'el catálogo por tuplas tiene que acotar lo que concede el rol')

      // Deny explícito en el hijo: gana aunque el rol conceda (invariante 2).
      await client.writeTuples([{ user: 'user:u1', relation: 'denied_docs_read', object: child }])
      const denied = await client.check({
        user: 'user:u1',
        relation: 'can_docs_read',
        object: child,
        context: { current_time: new Date().toISOString() },
      })
      assert.isFalse(denied.allowed, 'el deny explícito gana (invariante 2)')

      // `ancestor` sin una sola tupla extra: la organization está dentro de app.
      const within = await client.check({
        user: 'scope:app',
        relation: 'ancestor',
        object: child,
        context: { current_time: new Date().toISOString() },
      })
      assert.isTrue(within.allowed, 'ancestor da isWithin/descendantsOf con 0 tuplas')
    })
  })
}

/**
 * A2 — **colisión de familias (S4, bloqueante del juez).** Con CUATRO
 * familias por permiso, dos permisos distintos pueden generar el mismo
 * nombre de relación: `can_docs_read` sale del permiso `can_docs:read` y
 * también del permiso `docs:read`. El generador de antes las colapsaba en
 * silencio y el modelo publicado anulaba un deny (el auditor lo reprodujo
 * con `allowed: true`). Se detecta con un `Map` nombre→origen y se lanza 422
 * ANTES de tocar el servidor.
 */
test.group('facts · A2 — colisión de familias de relación (S4)', () => {
  /** Cliente de mentira: cuenta las escrituras de modelo que llegarían al servidor. */
  function countingClient() {
    const calls: unknown[] = []
    return {
      calls,
      async provision(permissions: string[]) {
        // El orden importa: generar PRIMERO, escribir después. Si el
        // generador no lanza, el modelo ambiguo se publica.
        const model = openFgaFactsModel(HOLDERS, permissions)
        calls.push(model)
        return model
      },
    }
  }

  test("['docs:read', 'can_docs:read'] ⇒ 422 nombrando los DOS permisos y la relación, y 0 escrituras de modelo", async ({
    assert,
  }) => {
    const client = countingClient()
    let caught: any
    try {
      await client.provision(['docs:read', 'can_docs:read'])
      assert.fail('debería haber lanzado')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_INVALID_SLUG')
    assert.include(caught.message, 'can_docs_read')
    assert.include(caught.message, "'docs:read'")
    assert.include(caught.message, "'can_docs:read'")
    assert.lengthOf(client.calls, 0)
  })

  test('las otras dos familias colisionan igual, y también una relación PROPIA del modelo', ({
    assert,
  }) => {
    const cases: Array<[string[], string]> = [
      [['docs:read', 'denied_docs:read'], 'denied_docs_read'],
      [['docs:read', 'permits_docs:read'], 'permits_docs_read'],
      // `parent` es relación de `scope`: un permiso así invalidaría el modelo entero (S14).
      [['parent'], 'parent'],
      // Y `rooted` desde (c2r) (3b-2i): un permiso con ese nombre reescribiría
      // la relación que decide si el scope alcanza la raíz — o sea, apagaría
      // el arreglo del 🔴 1 desde el catálogo.
      [['rooted'], 'rooted'],
    ]
    for (const [permissions, relation] of cases) {
      let caught: any
      try {
        openFgaFactsModel(HOLDERS, permissions)
        assert.fail(`${permissions.join(', ')}: debería haber lanzado`)
      } catch (error) {
        caught = error
      }
      assert.equal(caught.status, 422, permissions.join(', '))
      assert.equal(caught.code, 'E_AUTHZ_INVALID_SLUG', permissions.join(', '))
      assert.include(caught.message, relation)
    }
  })

  test('`rooted` es slug RESERVADO en el núcleo, o sea en los DOS drivers (no solo en el generador)', ({
    assert,
  }) => {
    // Si solo lo parase el generador, un catálogo con un permiso `rooted`
    // sería legal en `database` e impublicable en `openfga`: el cambio de
    // driver dejaría de ser una migración de hechos.
    for (const kind of ['permiso', 'rol'] as const) {
      let caught: any
      try {
        assertValidSlug(kind, 'rooted')
        assert.fail(`${kind}: debería haber lanzado`)
      } catch (error) {
        caught = error
      }
      assert.equal(caught.status, 422)
      assert.equal(caught.code, 'E_AUTHZ_INVALID_SLUG')
      assert.include(caught.message, 'reservado')
      assert.include(caught.message, 'rooted')
    }
  })

  test('dos permisos que se proyectan a la MISMA relación (`docs:write` / `docs_write`) tampoco pasan', ({
    assert,
  }) => {
    let caught: any
    try {
      openFgaFactsModel(HOLDERS, ['docs:write', 'docs_write'])
      assert.fail('debería haber lanzado')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_INVALID_SLUG')
    assert.include(caught.message, 'docs_write')
  })
})

/**
 * A4 — **cotas de nombre del servidor**: una relación admite 50 caracteres y
 * el id de un objeto 256. Las dos se comprueban donde se COMPONE el nombre,
 * no en runtime: un catálogo que no se puede publicar tiene que morir en el
 * `sync`, no el día que alguien pregunta.
 */
test.group('facts · A4 — cotas de nombre (relación ≤ 50, id de objeto ≤ 256)', (group) => {
  group.each.setup(() => cleanAuthzTables())

  test('un permiso cuyo `permits_<P>` pasa de 50 se rechaza nombrando el permiso y el prefijo que lo desborda', ({
    assert,
  }) => {
    // 43 caracteres: `permits_` + 43 = 51 > 50. El slug es legal en formato.
    const permission = 'a'.repeat(43)
    assert.equal(`permits_${permission}`.length, FGA_MAX_RELATION_NAME + 1)
    let caught: any
    try {
      openFgaFactsModel(HOLDERS, [permission])
      assert.fail('debería haber lanzado')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_INVALID_SLUG')
    assert.include(caught.message, permission)
    assert.include(caught.message, 'permits_')
    assert.include(caught.message, String(FGA_MAX_RELATION_NAME))
  })

  test('la misma cota se aplica en el SYNC, no en runtime: el catálogo no llega a escribirse', async ({
    assert,
  }) => {
    const permission = 'a'.repeat(43)
    let caught: any
    try {
      await syncAuthzCatalog({ permissions: [{ slug: permission }], roles: [] })
      assert.fail('debería haber lanzado')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_INVALID_SLUG')
    assert.include(caught.message, 'permits_')
  })

  test('un id de objeto que pasa de 256 no se escribe: 422 E_AUTHZ_INVALID_IDENTITY', ({
    assert,
  }) => {
    // Con la gramática publicada es inalcanzable (`role:<uuid>` son 41): el
    // caso entra por la puerta de la BASE, que es de donde salen las partes.
    const corrupt = 'x'.repeat(FGA_MAX_OBJECT_ID)
    let caught: any
    try {
      factsCatalogTuples([{ uuid: corrupt, permissions: ['docs:read'] }], HOLDERS)
      assert.fail('debería haber lanzado')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_INVALID_IDENTITY')
    assert.include(caught.message, String(FGA_MAX_OBJECT_ID))
    assert.include(caught.message, 'role')
  })
})

/**
 * Driver `openfga` con el cliente sustituido por un store en memoria: la
 * proyección se puede juzgar (qué lee, qué escribe, cuántas requests) sin
 * servidor. `logger` es el canal por el que sale el aviso del 80 %.
 */
function projectingDriver(
  options: {
    holderTypes?: Record<string, string>
    /** El MISMO store en memoria que otro driver (para el caso del holderType nuevo). */
    tuples?: Map<string, { user: string; relation: string; object: string }>
  } = {}
) {
  const logs: string[] = []
  const driver = new OpenFgaAuthorizationDriver({
    apiUrl: 'http://127.0.0.1:9',
    storeId: '01ARZ3NDEKTSV4RRFFQ69G5FAV',
    holderTypes: options.holderTypes ?? HOLDERS,
    // Sin manager ni transacción del consumidor: el gate de 3b-2d no aporta
    // nada aquí (mismo criterio que `treeDriver`).
    acceptScopeDriftRisk: true,
    logger: { warn: (message: string) => void logs.push(message) },
  })
  const tuples =
    options.tuples ?? new Map<string, { user: string; relation: string; object: string }>()
  const reads: any[] = []
  const writes: any[] = []
  const other: string[] = []
  const key = (t: any) => `${t.user}#${t.relation}@${t.object}`
  const client: any = (driver as any).client
  client.read = async (filter: any) => {
    reads.push(filter)
    const prefix = filter?.object ?? ''
    return {
      tuples: [...tuples.values()]
        .filter((t) => t.object.startsWith(prefix))
        .filter((t) => (filter?.relation ? t.relation === filter.relation : true))
        .map((k) => ({ key: k })),
      continuation_token: '',
    }
  }
  client.write = async (body: any) => {
    writes.push(body)
    for (const t of body.deletes ?? []) tuples.delete(key(t))
    for (const t of body.writes ?? []) tuples.set(key(t), t)
    return {}
  }
  // Cualquier otra escritura sería el patrón prohibido por el panel (cruce 8).
  client.writeTuples = async () => void other.push('writeTuples')
  client.deleteTuples = async () => void other.push('deleteTuples')
  return { driver, logs, reads, writes, other, tuples }
}

/** Un slug de permiso de 40 caracteres (el techo se alcanza con menos permisos). */
const longSlug = (i: number) => `p${i}`.padEnd(40, 'x')
const longPermissions = (n: number) => Array.from({ length: n }, (_, i) => ({ slug: longSlug(i) }))

/**
 * A3 — **techo del modelo: 262.144 bytes.** El servidor mide el tamaño
 * PROTOBUF del `AuthorizationModel` y rechaza por encima de ahí. Se valida en
 * `syncAuthzCatalog` ANTES de escribir: un catálogo que no se puede publicar
 * no puede quedarse en la base dejando el store sin poder regenerarse. Con
 * aviso al 80 %, porque quien declara permisos a ese ritmo tiene que
 * enterarse antes de chocar.
 */
test.group('facts · A3 — techo del modelo (262.144 bytes)', (group) => {
  group.each.setup(() => cleanAuthzTables())

  test('un catálogo que pasa del techo ⇒ 500 E_AUTHZ_MODEL_TOO_LARGE nombrando bytes y nº de permisos, y NADA escrito', async ({
    assert,
  }) => {
    const { driver, writes } = projectingDriver()
    let caught: any
    try {
      await syncAuthzCatalog(
        { permissions: longPermissions(289), roles: [] },
        { projection: driver.catalogProjection() }
      )
      assert.fail('debería haber lanzado')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 500)
    assert.equal(caught.code, 'E_AUTHZ_MODEL_TOO_LARGE')
    assert.include(caught.message, '289')
    assert.include(caught.message, '262144')
    assert.match(caught.message, /\b\d{6} bytes\b/)
    // Ni catálogo ni proyección: se valida antes de escribir.
    const [{ total }] = await db.from('authz_permissions').count('* as total')
    assert.equal(Number(total), 0)
    assert.lengthOf(writes, 0)
  })

  test('al 80 % del techo: escribe Y avisa por el canal de log del driver', async ({ assert }) => {
    const { driver, logs } = projectingDriver()
    await syncAuthzCatalog(
      { permissions: longPermissions(230), roles: [] },
      { projection: driver.catalogProjection() }
    )
    const [{ total }] = await db.from('authz_permissions').count('* as total')
    assert.equal(Number(total), 230)
    assert.lengthOf(logs, 1)
    assert.include(logs[0], '262144')
    assert.include(logs[0], '230 permisos')
  })

  test('un catálogo normal: escribe y NO avisa', async ({ assert }) => {
    const { driver, logs } = projectingDriver()
    await syncAuthzCatalog(
      { permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }], roles: [] },
      { projection: driver.catalogProjection() }
    )
    const [{ total }] = await db.from('authz_permissions').count('* as total')
    assert.equal(Number(total), 2)
    assert.deepEqual(logs, [])
  })
})

/**
 * **Lote 3b-4 · C3 — la cifra derivada del techo, con el catálogo con el que
 * se midió.**
 *
 * El techo en BYTES es exacto: `factsModelBytes` cuenta los mismos que el
 * servidor (caso de arriba, cuatro formas, delta 0). Lo que NO era una
 * propiedad del modelo es el **≈691 permisos** que se publicó: se midió con un
 * catálogo cuyos permisos se llaman `p0`…`p690` y con tres holder types cuyos
 * nombres FGA son `user`/`admin`/`integration`. Con slugs realistas
 * (`recurso:accion`) el techo real es **447**, un 35 % por debajo — y ningún
 * caso lo sostenía: el 691 vivía en tres comentarios y en el README.
 *
 * Este caso fija la TABLA entera. No sujeta «691» ni «447»: sujeta que cada
 * cifra va con su catálogo, y que el techo depende de **tres** cosas —cuántos
 * holder types, cuánto miden sus NOMBRES en el modelo y cuánto miden los
 * slugs—. Cambiar el modelo mueve la tabla y el caso lo dice; publicar un
 * número a secas vuelve a ser imposible sin tocarla.
 */
test.group('facts · 3b-4 · C3 — cuántos permisos caben depende del CATÁLOGO', () => {
  const H1 = { users: 'user' }
  const H3 = HOLDERS // { users: 'user', admins: 'admin', integrations: 'integration' }

  /** El mayor N que cabe en el techo con ese catálogo (busca, no supone). */
  function ceiling(holders: Record<string, string>, slug: (i: number) => string): number {
    let low = 1
    let high = 2000
    while (low < high) {
      const mid = Math.ceil((low + high) / 2)
      const bytes = factsModelBytes(
        openFgaFactsModel(
          holders,
          Array.from({ length: mid }, (_, i) => slug(i))
        )
      )
      if (bytes <= FACTS_MODEL_MAX_BYTES) low = mid
      else high = mid - 1
    }
    return low
  }

  const TABLE: Array<[string, Record<string, string>, (i: number) => string, number]> = [
    ['1 holder type · `p0`…`pN`', H1, (i) => `p${i}`, 800],
    ['3 holder types · `p0`…`pN` (la cifra del README)', H3, (i) => `p${i}`, 691],
    ['1 holder type · `docs:readN`', H1, (i) => `docs:read${i}`, 576],
    ['3 holder types · `recursoN:accion` (slugs REALISTAS)', H3, (i) => `recurso${i}:accion`, 447],
    ['3 holder types · slugs de 40 caracteres', H3, (i) => `p${i}`.padEnd(40, 'x'), 272],
  ]

  test('la tabla del techo: cada cifra con la forma de catálogo que la produce', ({ assert }) => {
    for (const [name, holders, slug, expected] of TABLE) {
      assert.equal(ceiling(holders, slug), expected, name)
    }
  })

  test('y en cada cifra el borde es EXACTO: N cabe y N+1 no', ({ assert }) => {
    for (const [name, holders, slug, expected] of TABLE) {
      const bytesOf = (count: number) =>
        factsModelBytes(
          openFgaFactsModel(
            holders,
            Array.from({ length: count }, (_, i) => slug(i))
          )
        )
      assert.isAtMost(bytesOf(expected), FACTS_MODEL_MAX_BYTES, `${name}: ${expected} tenía que caber`)
      assert.isAbove(bytesOf(expected + 1), FACTS_MODEL_MAX_BYTES, `${name}: ${expected + 1} NO puede caber`)
    }
  })

  test('el nombre del holder type en el MODELO también cuenta: `bot` no es `integration`', ({
    assert,
  }) => {
    // Los tres holder types no son «tres holder types» a secas: lo que ocupa
    // es el NOMBRE FGA de cada uno, repetido en cada restricción de tipo. Con
    // `bot` en vez de `integration` el mismo catálogo sube de 691 a 721 — que
    // es, casualmente, la cifra que se publicaba ANTES de `rooted`. Sin esta
    // frase la tabla parecería depender solo del número de holders.
    const corto = ceiling({ users: 'user', admins: 'admin', bots: 'bot' }, (i) => `p${i}`)
    assert.equal(corto, 721)
    assert.isAbove(corto, 691)
  })
})

/**
 * A5 — **la proyección del catálogo.** `syncAuthzCatalog` escribe las tuplas
 * `role:<uuid>#permits_<P>@<holder>:*` de cada par (rol, permiso) y BORRA las
 * que sobran, en UN `Write` por lote. Con (c2) quitar un permiso de un rol
 * son tantos deletes como holders y ninguna reescritura del modelo — que es
 * justo lo que hacía inviable a (c1) (S10: 30 requests no atómicas sobre
 * 3.000 tenants).
 */
test.group('facts · A5 — la proyección del catálogo (tuplas permits_<P>)', (group) => {
  group.each.setup(() => cleanAuthzTables())

  /**
   * Los `Write` de la PROYECCIÓN, sin el del marcador de raíz de (c2r)
   * —`scope:app#rooted@<holder>:*`, que `projectCatalog` repone en cada sync
   * y tiene su propio grupo más abajo—. Antes este grupo corría en el modo
   * `resolver`, donde el marcador no existía; desde 3b-2k · K2 no hay otro
   * modo y hay que separarlos aquí.
   */
  const catalogWrites = (writes: any[]) =>
    writes.filter((w) => !(w.writes ?? []).some((t: any) => t.relation === 'rooted'))
  /** Las tuplas de la proyección, sin las del marcador. */
  const projected = (tuples: Map<string, any>) =>
    [...tuples.values()].filter((t) => t.relation !== 'rooted')

  const roleUuid = '0192f000-0000-7000-8000-0000000000a1'
  const spec = (permissions: string[]) => ({
    permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
    roles: [{ slug: 'editor', scopeType: 'app', uuid: roleUuid, permissions }],
  })

  test('el primer sync escribe una tupla por (rol, permiso, holder), con el comodín de USUARIO', async ({
    assert,
  }) => {
    const { driver, writes, tuples } = projectingDriver()
    const report = await syncAuthzCatalog(spec(['docs:read', 'docs:write']), {
      projection: driver.catalogProjection(),
    })
    assert.deepEqual(report.projection, { written: 6, deleted: 0, unchanged: 0 })
    assert.lengthOf(catalogWrites(writes), 1)
    assert.deepEqual(
      projected(tuples).map((t) => `${t.user}#${t.relation}@${t.object}`).sort(),
      [
        `admin:*#permits_docs_read@role:${roleUuid}`,
        `admin:*#permits_docs_write@role:${roleUuid}`,
        `integration:*#permits_docs_read@role:${roleUuid}`,
        `integration:*#permits_docs_write@role:${roleUuid}`,
        `user:*#permits_docs_read@role:${roleUuid}`,
        `user:*#permits_docs_write@role:${roleUuid}`,
      ]
    )
  })

  test('quitar 1 permiso de 1 rol con 3 holderTypes ⇒ exactamente 1 Write con 3 deletes y 0 writes', async ({
    assert,
  }) => {
    const { driver, writes, other, tuples } = projectingDriver()
    const projection = driver.catalogProjection()
    await syncAuthzCatalog(spec(['docs:read', 'docs:write']), { projection })
    writes.length = 0

    const report = await syncAuthzCatalog(spec(['docs:read']), { projection })

    assert.deepEqual(report.projection, { written: 0, deleted: 3, unchanged: 3 })
    assert.lengthOf(catalogWrites(writes), 1)
    assert.lengthOf(catalogWrites(writes)[0].deletes, 3)
    assert.isEmpty(catalogWrites(writes)[0].writes ?? [])
    // El patrón `deleteTuples()` + `writeTuples()` queda prohibido (cruce 8
    // del panel): no es atómico dentro de la request.
    assert.deepEqual(other, [])
    assert.lengthOf(projected(tuples), 3)
  })

  test('idempotencia: el segundo sync seguido escribe 0 tuplas y no llama al servidor', async ({
    assert,
  }) => {
    const { driver, writes } = projectingDriver()
    const projection = driver.catalogProjection()
    await syncAuthzCatalog(spec(['docs:read', 'docs:write']), { projection })
    writes.length = 0

    const report = await syncAuthzCatalog(spec(['docs:read', 'docs:write']), { projection })

    assert.deepEqual(report.projection, { written: 0, deleted: 0, unchanged: 6 })
    assert.lengthOf(catalogWrites(writes), 0)
  })

  test('una tupla que el catálogo ya no respalda se borra aunque nadie la haya pedido (el espejo converge)', async ({
    assert,
  }) => {
    const { driver, tuples } = projectingDriver()
    const projection = driver.catalogProjection()
    await syncAuthzCatalog(spec(['docs:read']), { projection })
    // Alguien escribe a mano un permiso que el catálogo no da: con (c2) una
    // sola tupla concede un permiso a un rol GLOBALMENTE (riesgo 4 del panel).
    tuples.set(`user:*#permits_docs_write@role:${roleUuid}`, {
      user: 'user:*',
      relation: 'permits_docs_write',
      object: `role:${roleUuid}`,
    })

    const report = await syncAuthzCatalog(spec(['docs:read']), { projection })

    assert.deepEqual(report.projection, { written: 0, deleted: 1, unchanged: 3 })
    assert.notInclude(
      [...tuples.keys()],
      `user:*#permits_docs_write@role:${roleUuid}`
    )
  })
})

/**
 * A6 — **la proyección nunca se lee como catálogo.** Es la condición (c) de
 * la regla reescrita (panel 2, cruce 7): un driver puede mantener un espejo
 * derivado si es reconstruible, si `reconcile` lo vigila y si NUNCA se lee
 * como catálogo. Lo tercero es lo que evita que el store se convierta en la
 * fuente de verdad por la puerta de atrás — y con (c2) una sola tupla
 * escrita a mano concede un permiso a un rol globalmente (riesgo 4 del
 * panel), así que leerla sería exactamente la escalada.
 */
/**
 * **3b-2i · I2 — el marcador de raíz.** (c2r) exige que `scope:app` lleve
 * `rooted` para CADA holder type: es lo único directo de esa relación y sin
 * ello el store entero deniega (fail-closed, §I5). Cero tuplas por scope: lo
 * escribe quien toca el CATÁLOGO, porque ése es el momento en el que un
 * holderType nuevo del config aparece — `attached`/`moved`/`detached` no
 * escriben ni una tupla más y la outbox no lleva entradas nuevas.
 */
test.group('facts · 3b-2i — el marcador de raíz `scope:app#rooted`', (group) => {
  group.each.setup(() => cleanAuthzTables())

  const roleUuid = '0192f000-0000-7000-8000-0000000000a1'
  const spec = {
    permissions: [{ slug: 'docs:read' }],
    roles: [{ slug: 'editor', scopeType: 'app', uuid: roleUuid, permissions: ['docs:read'] }],
  }
  /** Los `Write` que llevan el marcador (la proyección del catálogo va aparte). */
  const rootWrites = (writes: any[]) =>
    writes.filter((w) => (w.writes ?? []).some((t: any) => t.relation === 'rooted'))

  test('un sync en un store virgen escribe UNA tupla `rooted` por holder type sobre `scope:app`', async ({
    assert,
  }) => {
    const { driver, writes, tuples } = projectingDriver()

    await syncAuthzCatalog(spec, { projection: driver.catalogProjection() })

    const marker = rootWrites(writes)
    assert.lengthOf(marker, 1, 'el marcador va en UN solo Write')
    assert.deepEqual(
      marker[0].writes.map((t: any) => `${t.user}#${t.relation}@${t.object}`).sort(),
      ['admin:*#rooted@scope:app', 'integration:*#rooted@scope:app', 'user:*#rooted@scope:app']
    )
    assert.isEmpty(marker[0].deletes ?? [], 'el marcador no borra nada')
    // Y es lo ÚNICO que se escribe de más: cero tuplas por scope.
    assert.deepEqual(
      [...tuples.values()].filter((t) => t.relation === 'rooted').length,
      3
    )
  })

  test('idempotencia: el segundo sync no reescribe el marcador (0 escrituras)', async ({
    assert,
  }) => {
    const { driver, writes } = projectingDriver()
    const projection = driver.catalogProjection()
    await syncAuthzCatalog(spec, { projection })
    writes.length = 0

    await syncAuthzCatalog(spec, { projection })

    assert.lengthOf(rootWrites(writes), 0, 'el marcador ya estaba: no se reescribe')
  })

  test('añadir un holderType al config ⇒ 1 Write con SOLO la tupla que falta', async ({
    assert,
  }) => {
    const shared = new Map<string, { user: string; relation: string; object: string }>()
    const first = projectingDriver({ tuples: shared })
    await syncAuthzCatalog(spec, { projection: first.driver.catalogProjection() })

    // El consumidor añade un holder: el modelo se republica y el marcador
    // tiene que crecer, o ese holder denegaría en TODO el store.
    const second = projectingDriver({
      holderTypes: { ...HOLDERS, bots: 'bot' },
      tuples: shared,
    })
    await syncAuthzCatalog(spec, { projection: second.driver.catalogProjection() })

    const marker = rootWrites(second.writes)
    assert.lengthOf(marker, 1)
    assert.deepEqual(
      marker[0].writes.map((t: any) => `${t.user}#${t.relation}@${t.object}`),
      ['bot:*#rooted@scope:app']
    )
  })
})

test.group('facts · A6 — la proyección no es catálogo', (group) => {
  group.each.setup(async () => {
    await cleanAuthzTables()
    await syncAuthzCatalog({
      permissions: [{ slug: 'docs:read' }],
      roles: [{ slug: 'editor', scopeType: 'app', permissions: ['docs:read'] }],
    })
  })

  test('listRoles, rolesInChain y authorize (findPermission) hacen 0 lecturas sobre el tipo `role`', async ({
    assert,
  }) => {
    const { driver, reads } = projectingDriver()
    const client: any = (driver as any).client
    const checks: any[] = []
    // `authorize` es UN `check` (facts); la membresía sigue usando `batchCheck`.
    client.check = async (body: any) => {
      checks.push({ checks: [body] })
      return { allowed: false }
    }
    client.batchCheck = async (body: any) => {
      checks.push(body)
      return {
        result: (body.checks ?? []).map((c: any) => ({ allowed: false, correlationId: c.correlationId })),
      }
    }
    const subject = { type: 'users', uuid: 'u1' }

    await driver.listRoles(subject, APP_SCOPE)
    await driver.rolesInChain(subject, [APP_SCOPE])
    await driver.authorize(subject, 'docs:read', APP_SCOPE)

    // Que hayan preguntado algo: si no leyeran nada, el caso no probaría nada.
    assert.isNotEmpty(reads)
    assert.isNotEmpty(checks)
    for (const filter of reads) {
      assert.notMatch(String(filter?.object ?? ''), /^role:/, JSON.stringify(filter))
      assert.notMatch(String(filter?.relation ?? ''), /^permits_/, JSON.stringify(filter))
    }
    for (const body of checks) {
      for (const check of body.checks ?? []) {
        assert.notMatch(String(check.object), /^role:/, JSON.stringify(check))
        assert.notMatch(String(check.relation), /^permits_/, JSON.stringify(check))
      }
    }
  })

  test('guardia de fuente: el driver solo mira el tipo `role` en la proyección (una vez, y es una escritura)', async ({
    assert,
  }) => {
    const source = await readFile(new URL('../src/drivers/openfga_driver.ts', import.meta.url), 'utf-8')
    const reads = source.match(/FACTS_ROLE_TYPE\}:/g) ?? []
    // OCHO sitios, y ninguno pregunta QUÉ PERMISOS tiene un rol (que es lo
    // que A6 protege): `projectCatalog` y `projectCatalogRole` (escrituras del
    // espejo), los DOS barridos de la arista `scope#binding` —el del owner en
    // `moved` (3b-2e · E1) y el del NIVEL en una escritura de catálogo
    // (3b-2g · R1)—, `purgeRole` y `countRoleAssignments` (3b-2j), que
    // enumeran los `role_binding` de un rol filtrando por `user`, y desde
    // 3b-3a los DOS de `reconcile`: la arista `role_binding#role` que ESCRIBE
    // por cada asignación del origen y la clasificación de una tupla del
    // store por familia (`familyOfTuple`), que mira el TIPO del objeto para
    // saber si es del espejo del catálogo. Ninguno de los dos lee qué
    // permisos vincula un rol: eso sigue saliendo de `authz_*`.
    assert.lengthOf(reads, 8)
    const between = (from: string, to: string) => source.slice(source.indexOf(from), source.indexOf(to))
    const projection = between('private async projectCatalog(', '  /**\n   * **Purga un ROL')
    assert.include(projection, 'FACTS_ROLE_TYPE}:')
    // Y el de `reconcile` es una ESCRITURA (la arista de (c2)), no una lectura.
    const reconcile = between('private async readSourceFacts(', 'private async eachRow(')
    assert.include(reconcile, 'relation: FACTS_ROLE_RELATION')
    assert.notInclude(reconcile, 'FACTS_PERMITS_PREFIX')
    const sweep = between('private async sweepLocalRoleBindings(', 'private async storeChain(')
    assert.include(sweep, `object: \`\${FACTS_BINDING_TYPE}:\``, 'el objeto que enumera es role_binding, no role')
    // Y ningún camino de LECTURA de membresía toca el tipo `role`.
    for (const method of ['async authorize(', 'async hasRole(', 'async listRoles(', 'async rolesInChain(']) {
      const body = source.slice(source.indexOf(method), source.indexOf(method) + 3_000)
      assert.notInclude(body, 'FACTS_ROLE_TYPE}:', `${method}: la proyección no es catálogo`)
    }
  })
})

/* ════════════════════════════════════════════════════════════════════════
 * 3b-2b — EL ÁRBOL COMO HECHOS
 *
 * `hierarchy: 'facts'` en las opciones del driver: `scopes.attached/moved/
 * detached` escriben (y borran) la arista `scope:<hijo>#parent@scope:<padre>`.
 * Por defecto el driver sigue en `'resolver'` (el modo de hoy): este lote es
 * ADITIVO y no cambia una sola respuesta de las suites existentes.
 * ════════════════════════════════════════════════════════════════════════ */

/**
 * **Cruce 3 del panel 2, reproducido aquí: FGA acepta el ciclo.** No se
 * cuelga, no avisa, responde en milisegundos — y la herencia se vuelve
 * BIDIRECCIONAL: un grant en un descendiente concede en el ancestro, que es
 * exactamente lo que el invariante 1 prohíbe. Fail-open mudo.
 *
 * Este caso monta el ciclo A MANO, saltándose la validación del paquete, y
 * enseña el `true` que no debería existir. Es la prueba de que el anti-ciclos
 * tiene que vivir EN EL PAQUETE y no puede delegarse en el backend (y el
 * caso hermano V5 del tester: que nadie confíe en FGA como segunda línea).
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2b — el ciclo que FGA acepta (cruce 3)', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    test('un ciclo `parent` escrito a mano hace que un grant en el DESCENDIENTE conceda en el ANCESTRO (fail-open del servidor)', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-cycle-${Date.now()}`,
      })
      stores.push(store.id!)
      const bare = new OpenFgaClient({ apiUrl, storeId: store.id })
      const model = await bare.writeAuthorizationModel(openFgaFactsModel(HOLDERS, PERMISSIONS))
      const client = new OpenFgaClient({
        apiUrl,
        storeId: store.id,
        authorizationModelId: model.authorization_model_id,
      })

      const role = 'role:0192f000-0000-7000-8000-000000000001'
      const org = 'scope:organization|0192f000-0000-7000-8000-0000000000aa'
      const unit = 'scope:unit|0192f000-0000-7000-8000-0000000000bb'
      // El binding cuelga de la UNIT: el grant está abajo del todo.
      const binding = 'role_binding:unit|0192f000-0000-7000-8000-0000000000bb|0192f000-0000-7000-8000-000000000001'

      await client.writeTuples([
        // El marcador de raíz (3b-2i): store montado a mano, ver A1.
        { user: 'user:*', relation: 'rooted', object: 'scope:app' },
        { user: 'user:*', relation: 'permits_docs_read', object: role },
        { user: role, relation: 'role', object: binding },
        { user: 'user:u1', relation: 'assignee', object: binding },
        { user: binding, relation: 'binding', object: unit },
        // El árbol legítimo: unit → org → app.
        { user: org, relation: 'parent', object: unit },
        { user: 'scope:app', relation: 'parent', object: org },
      ])

      const context = { current_time: new Date().toISOString() }
      const before = await client.check({ user: 'user:u1', relation: 'can_docs_read', object: org, context })
      assert.isFalse(before.allowed, 'precondición: sin ciclo, el grant de la unit NO concede en la org')

      // El ciclo: la org pasa a colgar de la unit (su propio descendiente).
      await client.writeTuples([{ user: unit, relation: 'parent', object: org }])

      const started = Date.now()
      const after = await client.check({ user: 'user:u1', relation: 'can_docs_read', object: org, context })
      const elapsed = Date.now() - started

      // Esto es el DEFECTO, no el contrato: se fija para que nadie proponga
      // delegar el anti-ciclos en el servidor.
      assert.isTrue(
        after.allowed,
        'FGA evalúa el ciclo y concede hacia ARRIBA: la herencia deja de ser solo hacia abajo'
      )
      assert.isBelow(elapsed, 2_000, 'y no se cuelga: responde en milisegundos, sin avisar de nada')

      // La RAÍZ todavía se salva, y por una razón que conviene tener escrita:
      // la herencia va padre→hijo, así que un ciclo org↔unit no alcanza a
      // `scope:app` mientras `app` no cuelgue de nadie. Eso es EXACTAMENTE
      // lo que defiende la validación (i) del cruce 3 (`child ≠ app`): en
      // cuanto la raíz cuelga de algo, el grant de la unit concede en la
      // raíz y con él en TODOS los tenants del store.
      const rootBefore = await client.check({ user: 'user:u1', relation: 'can_docs_read', object: 'scope:app', context })
      assert.isFalse(rootBefore.allowed, 'la raíz no cuelga de nadie: el ciclo de abajo no la alcanza')

      await client.writeTuples([{ user: org, relation: 'parent', object: 'scope:app' }])
      const rootAfter = await client.check({ user: 'user:u1', relation: 'can_docs_read', object: 'scope:app', context })
      assert.isTrue(rootAfter.allowed, 'con la raíz colgada, el grant de una unit concede en scope:app')
    })
  })
}

/**
 * El driver `openfga` en modo `facts` con el cliente sustituido por un store
 * en memoria y un árbol de mentira: qué lee, qué escribe y CUÁNTAS requests
 * hace se pueden juzgar sin servidor.
 */
function treeDriver(options: { tree?: any; resolveChain?: any } = {}) {
  const tree = options.tree ?? memoryScopeTree()
  const driver = new OpenFgaAuthorizationDriver({
    apiUrl: 'http://127.0.0.1:9',
    storeId: '01ARZ3NDEKTSV4RRFFQ69G5FAV',
    holderTypes: HOLDERS,
    resolveChain: options.resolveChain ?? resolveChainFrom(tree),
    // Estos tests construyen el driver A PELO (sin manager ni transacción del
    // consumidor), así que el gate de 3b-2d no aporta nada aquí: se firma.
    acceptScopeDriftRisk: true,
    logger: { warn: () => {} },
  })
  const tuples = new Map<string, { user: string; relation: string; object: string }>()
  const reads: any[] = []
  const writes: any[] = []
  const other: string[] = []
  const key = (t: any) => `${t.user}#${t.relation}@${t.object}`
  const client: any = (driver as any).client
  client.read = async (filter: any) => {
    reads.push(filter)
    return {
      tuples: [...tuples.values()]
        .filter((t) => (filter?.object ? t.object.startsWith(filter.object) : true))
        .filter((t) => (filter?.relation ? t.relation === filter.relation : true))
        .map((k) => ({ key: k })),
      continuation_token: '',
    }
  }
  client.write = async (body: any) => {
    writes.push(body)
    for (const t of body.deletes ?? []) tuples.delete(key(t))
    for (const t of body.writes ?? []) tuples.set(key(t), t)
    return {}
  }
  client.writeTuples = async () => void other.push('writeTuples')
  client.deleteTuples = async () => void other.push('deleteTuples')
  return { driver, tree, tuples, reads, writes, other }
}

/** Las aristas `#parent` que hay en el store, como `hijo → padre`. */
function edgesOf(tuples: Map<string, { user: string; relation: string; object: string }>): string[] {
  return [...tuples.values()]
    .filter((t) => t.relation === 'parent')
    .map((t) => `${t.object} → ${t.user}`)
    .sort()
}


/** Un caso negativo: la promesa lanza, con el `status` y el `code` esperados. */
async function rejects(
  assert: any,
  run: () => Promise<unknown>,
  expected: { status: number; code: string },
  message?: string
): Promise<any> {
  let caught: any = null
  try {
    await run()
  } catch (error) {
    caught = error
  }
  assert.isNotNull(caught, `${message ?? 'la operación'}: debería haber lanzado`)
  assert.equal(caught.status, expected.status, message)
  assert.equal(caught.code, expected.code, message)
  return caught
}

const orgScope = () => ({ type: 'organization', uuid: uuidv7() })
const unitScope = () => ({ type: 'unit', uuid: uuidv7() })

test.group('facts · 3b-2b — hierarchy: facts escribe el árbol', () => {
  test('`scopes.attached` escribe la arista scope:<hijo>#parent@scope:<padre> en UN solo write', async ({
    assert,
  }) => {
    const { driver, tree, tuples, writes, other } = treeDriver({ })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    await driver.onScopeAttached!(org, APP_SCOPE)

    assert.deepEqual(edgesOf(tuples), [`scope:organization|${org.uuid} → scope:app`])
    assert.lengthOf(writes, 1)
    assert.deepEqual(writes[0].deletes ?? [], [])
    assert.deepEqual(other, [], 'writeTuples/deleteTuples quedan prohibidos (cruce 8)')
  })

  test('la arista lleva la identidad CANÓNICA del árbol (invariante 17): un alias del uuid no abre una segunda rama', async ({
    assert,
  }) => {
    // El árbol del consumidor funde el alias sin guiones con su fila (el tipo
    // `uuid` de PostgreSQL lo hace solo) y responde CANÓNICO. Si la arista se
    // escribiera con lo que trajo el llamante, el store tendría dos nodos
    // para el mismo scope y la herencia colgaría del que nadie vuelve a tocar.
    const org = orgScope()
    const unit = unitScope()
    const rows = new Map<string, { self: any; parent: any }>([
      [`organization|${org.uuid.replaceAll('-', '')}`, { self: org, parent: APP_SCOPE }],
      [`unit|${unit.uuid.replaceAll('-', '')}`, { self: unit, parent: org }],
    ])
    const resolveChain = async (scope: any): Promise<any[] | null> => {
      const chain: any[] = []
      let current = scope
      for (let depth = 0; depth < 10; depth++) {
        if (current.type === 'app') return [...chain, APP_SCOPE]
        const row = rows.get(`${current.type}|${String(current.uuid).replaceAll('-', '')}`)
        if (!row) return null
        chain.push(row.self)
        current = row.parent
      }
      return null
    }
    const { driver, tuples } = treeDriver({ resolveChain })
    const aliasUnit = { type: 'unit', uuid: unit.uuid.replaceAll('-', '') }
    const aliasOrg = { type: 'organization', uuid: org.uuid.replaceAll('-', '') }

    await driver.onScopeAttached!(aliasUnit as any, aliasOrg as any)

    assert.deepEqual(edgesOf(tuples), [
      `scope:unit|${unit.uuid} → scope:organization|${org.uuid}`,
    ])
  })

  test('idempotencia (invariante 6): re-anexar al MISMO padre no escribe nada', async ({ assert }) => {
    const { driver, tree, tuples, writes } = treeDriver({ })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    await driver.onScopeAttached!(org, APP_SCOPE)
    await driver.onScopeAttached!(org, APP_SCOPE)

    assert.lengthOf(writes, 1, 'la segunda no llega al servidor')
    assert.deepEqual(edgesOf(tuples), [`scope:organization|${org.uuid} → scope:app`])
  })
})

/**
 * **Anti-ciclos EN EL PAQUETE, antes de escribir** (cruce 3, bloqueante S2).
 * El caso de arriba enseña por qué no se puede delegar: el servidor acepta la
 * arista, la evalúa y concede hacia arriba sin decir nada. Las tres
 * validaciones son las del cruce 8 —`child ≠ app`, el padre existe, y el hijo
 * no es ancestro-o-igual del padre— y en los tres casos NO se escribe
 * ninguna arista.
 *
 * Viven en el manager (`#assertEdge`, probado en `tests/manager.spec.ts`) y
 * se repiten aquí por defensa en profundidad: `manager.driver()` es la salida
 * documentada de todas las barreras del paquete, y por ahí se llega al
 * driver sin pasar por el manager.
 */
test.group('facts · 3b-2b — anti-ciclos en el paquete (cruce 3)', () => {
  async function treeWithOrgAndUnit() {
    const t = treeDriver({ })
    const org = orgScope()
    const unit = unitScope()
    await t.tree.attach(org, APP_SCOPE)
    await t.tree.attach(unit, org)
    return { ...t, org, unit }
  }

  test('(i) la raíz `app` no puede colgar de nada ⇒ 422 E_AUTHZ_INVALID_IDENTITY sin escribir', async ({
    assert,
  }) => {
    const { driver, org, tuples, writes } = await treeWithOrgAndUnit()
    const expected = { status: 422, code: 'E_AUTHZ_INVALID_IDENTITY' }
    await rejects(assert, () => driver.onScopeAttached!(APP_SCOPE, org), expected, 'attached')
    await rejects(assert, () => driver.onScopeMoved!(APP_SCOPE, org), expected, 'moved')
    assert.deepEqual(edgesOf(tuples), [])
    assert.deepEqual(writes, [])
  })

  test('(ii) un padre que el árbol no conoce ⇒ 422 E_AUTHZ_UNKNOWN_SCOPE sin escribir', async ({
    assert,
  }) => {
    const { driver, unit, tuples, writes } = await treeWithOrgAndUnit()
    const ghost = orgScope()
    const expected = { status: 422, code: 'E_AUTHZ_UNKNOWN_SCOPE' }
    await rejects(assert, () => driver.onScopeAttached!(unit, ghost), expected, 'attached')
    await rejects(assert, () => driver.onScopeMoved!(unit, ghost), expected, 'moved')
    assert.deepEqual(edgesOf(tuples), [])
    assert.deepEqual(writes, [])
  })

  test('(iii) colgar un scope de su propio DESCENDIENTE (o de sí mismo) ⇒ 422 E_AUTHZ_SCOPE_CYCLE sin escribir', async ({
    assert,
  }) => {
    const { driver, org, unit, tuples, writes } = await treeWithOrgAndUnit()
    const expected = { status: 422, code: 'E_AUTHZ_SCOPE_CYCLE' }
    await rejects(assert, () => driver.onScopeMoved!(org, unit), expected, 'moved: org bajo su unit')
    await rejects(assert, () => driver.onScopeAttached!(org, unit), expected, 'attached: org bajo su unit')
    await rejects(assert, () => driver.onScopeMoved!(org, org), expected, 'moved: org bajo sí misma')
    assert.deepEqual(edgesOf(tuples), [], 'ninguna arista que cierra un ciclo llega al store')
    assert.deepEqual(writes, [])
  })

  test('el anti-ciclos canoniza: un ALIAS del uuid del hijo tampoco cierra el ciclo, y una arista legítima sí pasa', async ({
    assert,
  }) => {
    const org = orgScope()
    const unit = unitScope()
    const rows = new Map<string, { self: any; parent: any }>([
      [`organization|${org.uuid.replaceAll('-', '')}`, { self: org, parent: APP_SCOPE }],
      [`unit|${unit.uuid.replaceAll('-', '')}`, { self: unit, parent: org }],
    ])
    const resolveChain = async (scope: any): Promise<any[] | null> => {
      const chain: any[] = []
      let current = scope
      for (let depth = 0; depth < 10; depth++) {
        if (current.type === 'app') return [...chain, APP_SCOPE]
        const row = rows.get(`${current.type}|${String(current.uuid).replaceAll('-', '')}`)
        if (!row) return null
        chain.push(row.self)
        current = row.parent
      }
      return null
    }
    const { driver, tuples, writes } = treeDriver({ resolveChain })
    const aliasOrg = { type: 'organization', uuid: org.uuid.replaceAll('-', '') }

    await rejects(
      assert,
      () => driver.onScopeMoved!(aliasOrg as any, unit),
      { status: 422, code: 'E_AUTHZ_SCOPE_CYCLE' },
      'el alias del hijo desciende del padre'
    )
    assert.deepEqual(writes, [])

    // El inverso: la arista legítima escrita con el alias sigue pasando.
    await driver.onScopeAttached!({ type: 'unit', uuid: unit.uuid.replaceAll('-', '') } as any, org)
    assert.deepEqual(edgesOf(tuples), [`scope:unit|${unit.uuid} → scope:organization|${org.uuid}`])
  })
})

/**
 * **`moved` atómico** (cruce 8, bloqueante S3). Procedimiento fijado:
 * `Read({object:'scope:<hijo>', relation:'parent'})` —una request, y es
 * OBLIGATORIA porque FGA rechaza borrar una tupla inexistente— y **UN solo
 * `Write`** con el delete del padre viejo y el write del nuevo, que es
 * atómico dentro de la request. Total: 2 requests, 1 mutación.
 *
 * Queda prohibido el patrón `deleteTuples()` + `writeTuples()`: son dos
 * requests y entre ellas el scope se queda sin padre (o con dos).
 */
test.group('facts · 3b-2b — `moved` es un Read y UN Write (cruce 8)', () => {
  test('mover un scope: 1 Read del padre actual + 1 write con deletes Y writes juntos, y 0 writeTuples/deleteTuples', async ({
    assert,
  }) => {
    const { driver, tree, tuples, reads, writes, other } = treeDriver({ })
    const orgA = orgScope()
    const orgB = orgScope()
    const unit = unitScope()
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE)
    await tree.attach(unit, orgA)
    await driver.onScopeAttached!(unit, orgA)
    reads.length = 0
    writes.length = 0

    await driver.onScopeMoved!(unit, orgB)

    // Desde 3b-8 · A5 el `moved` lee ADEMÁS la cadena del PADRE en el store
    // (el anti-ciclos del consumidor no ve un store desincronizado): el Read
    // del padre actual + O(profundidad) de la cadena. La mutación sigue
    // siendo UNA.
    assert.lengthOf(reads, 2, 'el Read del padre actual + la cadena del padre nuevo en el store')
    assert.deepEqual(reads[0], { object: `scope:unit|${unit.uuid}`, relation: 'parent' })
    assert.deepEqual(reads[1], { object: `scope:organization|${orgB.uuid}`, relation: 'parent' })
    assert.lengthOf(writes, 1, 'UNA sola mutación: deletes y writes en la misma request')
    assert.deepEqual(writes[0].deletes, [
      { user: `scope:organization|${orgA.uuid}`, relation: 'parent', object: `scope:unit|${unit.uuid}` },
    ])
    assert.deepEqual(writes[0].writes, [
      { user: `scope:organization|${orgB.uuid}`, relation: 'parent', object: `scope:unit|${unit.uuid}` },
    ])
    assert.deepEqual(other, [], 'writeTuples()/deleteTuples() quedan prohibidos')
    assert.deepEqual(
      edgesOf(tuples),
      [`scope:unit|${unit.uuid} → scope:organization|${orgB.uuid}`],
      'queda UNA arista por nodo: la vieja se fue en la misma request'
    )
  })

  test('si el Read devuelve 0 padres (la arista nunca llegó al store) el Write lleva solo writes', async ({
    assert,
  }) => {
    const { driver, tree, tuples, writes } = treeDriver({ })
    const orgA = orgScope()
    const unit = unitScope()
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(unit, orgA)

    // Nadie escribió la arista antes (un store recién migrado, un relay con
    // retraso): mover no puede borrar lo que no existe.
    await driver.onScopeMoved!(unit, orgA)

    assert.lengthOf(writes, 1)
    assert.deepEqual(writes[0].deletes, [])
    assert.deepEqual(edgesOf(tuples), [`scope:unit|${unit.uuid} → scope:organization|${orgA.uuid}`])
  })

  test('si el Read devuelve MÁS DE UN padre eso es deriva del store: lanza 500 E_AUTHZ_SCOPE_TREE_DRIFT y no toca nada', async ({
    assert,
  }) => {
    const { driver, tree, tuples, writes } = treeDriver({ })
    const orgA = orgScope()
    const orgB = orgScope()
    const unit = unitScope()
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE)
    await tree.attach(unit, orgA)
    // Dos padres a la vez: el paquete no escribe esto nunca (una sola arista
    // por nodo), así que verlo significa que alguien más escribe en el store.
    // "Arreglarlo" en silencio sería adivinar cuál de los dos es el bueno —y
    // con dos padres la herencia YA está trayendo hechos de otra rama—.
    for (const parent of [orgA, orgB]) {
      tuples.set(`scope:organization|${parent.uuid}#parent@scope:unit|${unit.uuid}`, {
        user: `scope:organization|${parent.uuid}`,
        relation: 'parent',
        object: `scope:unit|${unit.uuid}`,
      })
    }
    writes.length = 0

    const error = await rejects(
      assert,
      () => driver.onScopeMoved!(unit, orgB),
      { status: 500, code: 'E_AUTHZ_SCOPE_TREE_DRIFT' },
      'dos padres'
    )
    assert.include(error.message, `scope:unit|${unit.uuid}`)
    assert.deepEqual(writes, [], 'no se arregla: se denuncia')
    assert.lengthOf(edgesOf(tuples), 2, 'las dos aristas siguen ahí, tal cual')
  })
})

/**
 * **S6 — el orden de `detached`** (cruce 9, bloqueante). Primero los HECHOS
 * (el driver los purga y DEMUESTRA cero o lanza), la arista al final. Si se
 * hiciera al revés y la purga muriera a medias, los grants supervivientes se
 * quedarían sin ancestro: los denies que heredaban del padre dejarían de
 * aplicar y esos permisos pasarían a ser **indenegables** (invariante 2).
 *
 * El orden lo fija el manager (`scopes.detached` = `purgeScope` y luego
 * `onScopeDetached`); aquí se demuestra con la purga fallando de verdad.
 */
test.group('facts · 3b-2b — `detached`: hechos primero, arista al final (S6)', (group) => {
  group.each.setup(async () => {
    await cleanAuthzTables()
    await syncAuthzCatalog({
      permissions: [{ slug: 'docs:read' }],
      roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
    })
  })

  test('la arista del scope se borra al final, en un Write de solo deletes', async ({ assert }) => {
    const { driver, tree, tuples, writes } = treeDriver({ })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    await driver.onScopeAttached!(org, APP_SCOPE)
    writes.length = 0

    await driver.onScopeDetached!(org)

    assert.lengthOf(writes, 1)
    assert.deepEqual(writes[0].writes ?? [], [])
    assert.deepEqual(edgesOf(tuples), [])
  })

  test('un scope sin arista en el store no escribe nada (re-detach es un no-op seguro)', async ({
    assert,
  }) => {
    const { driver, tree, writes } = treeDriver({ })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    await driver.onScopeDetached!(org)
    assert.deepEqual(writes, [])
  })

  test('si la purga de hechos NO puede demostrar cero, la arista SIGUE en el store: el subárbol no se queda sin ancestro', async ({
    assert,
  }) => {
    const { driver, tree, tuples } = treeDriver({ })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    await driver.onScopeAttached!(org, APP_SCOPE)
    // Un deny vivo en ese scope que el borrado NO se lleva (el harness deja
    // `deleteTuples` sin efecto): `purgeScope` lo vuelve a leer y lanza. Desde
    // 3b-2c el deny del modo `facts` es `scope:<key>#denied_<P>@<holder>`, no
    // un `deny_binding`: el hecho que la purga tiene que demostrar a cero es
    // este.
    tuples.set(`user:u1#denied_docs_read@scope:organization|${org.uuid}`, {
      user: 'user:u1',
      relation: 'denied_docs_read',
      object: `scope:organization|${org.uuid}`,
    })
    const manager = new AuthorizationManager({
      default: 'openfga',
      drivers: { openfga: () => driver },
      scopes: { resolveChain: resolveChainFrom(tree), acceptScopeDriftRisk: true },
      warnOnOptInSecurity: false,
    } as any)

    await rejects(
      assert,
      () => manager.scopes.detached(org),
      { status: 500, code: 'E_AUTHZ_PURGE_INCOMPLETE' },
      'la purga no demuestra cero'
    )

    assert.deepEqual(
      edgesOf(tuples),
      [`scope:organization|${org.uuid} → scope:app`],
      'la arista se borra DESPUÉS de la purga: si la purga falla, el scope conserva su ancestro y los denies heredados siguen valiendo'
    )
  })

  test('con la purga en verde, `scopes.detached` sí se lleva la arista (mismo camino, orden completo)', async ({
    assert,
  }) => {
    const { driver, tree, tuples } = treeDriver({ })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    await driver.onScopeAttached!(org, APP_SCOPE)
    const manager = new AuthorizationManager({
      default: 'openfga',
      drivers: { openfga: () => driver },
      scopes: { resolveChain: resolveChainFrom(tree), acceptScopeDriftRisk: true },
      warnOnOptInSecurity: false,
    } as any)

    await manager.scopes.detached(org)

    assert.deepEqual(edgesOf(tuples), [])
  })
})

/**
 * De punta a punta por donde entra el consumidor: `manager.scopes.*`. El
 * anti-ciclos del manager (`#assertEdge`) corta ANTES del driver, así que un
 * ciclo no llega ni a intentarse contra el store.
 */
test.group('facts · 3b-2b — `manager.scopes.*` mantiene el árbol del store', () => {
  function managerOver(tree: any, driver: any) {
    return new AuthorizationManager({
      default: 'openfga',
      drivers: { openfga: () => driver },
      scopes: { resolveChain: resolveChainFrom(tree), acceptScopeDriftRisk: true },
      warnOnOptInSecurity: false,
    } as any)
  }

  test('attached y moved mantienen UNA arista por nodo; un ciclo es 422 y no llega al store', async ({
    assert,
  }) => {
    const { driver, tree, tuples, writes } = treeDriver({ })
    const manager = managerOver(tree, driver)
    const orgA = orgScope()
    const orgB = orgScope()
    const unit = unitScope()
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE)

    await manager.scopes.attached(orgA, APP_SCOPE)
    await manager.scopes.attached(orgB, APP_SCOPE)
    await tree.attach(unit, orgA)
    await manager.scopes.attached(unit, orgA)
    assert.deepEqual(edgesOf(tuples), [
      `scope:organization|${orgA.uuid} → scope:app`,
      `scope:organization|${orgB.uuid} → scope:app`,
      `scope:unit|${unit.uuid} → scope:organization|${orgA.uuid}`,
    ])

    await tree.attach(unit, orgB)
    await manager.scopes.moved(unit, orgB)
    assert.deepEqual(edgesOf(tuples), [
      `scope:organization|${orgA.uuid} → scope:app`,
      `scope:organization|${orgB.uuid} → scope:app`,
      `scope:unit|${unit.uuid} → scope:organization|${orgB.uuid}`,
    ])

    const before = writes.length
    await rejects(
      assert,
      () => manager.scopes.moved(orgB, unit),
      { status: 422, code: 'E_AUTHZ_SCOPE_CYCLE' },
      'la org bajo su propia unit'
    )
    await rejects(
      assert,
      () => manager.scopes.attached(APP_SCOPE, orgA),
      { status: 422, code: 'E_AUTHZ_INVALID_IDENTITY' },
      'la raíz colgando de una org'
    )
    await rejects(
      assert,
      () => manager.scopes.moved(unit, orgScope()),
      { status: 422, code: 'E_AUTHZ_UNKNOWN_SCOPE' },
      'un padre fantasma'
    )
    assert.lengthOf(writes, before, 'ninguna de las tres tocó el store')
  })
})

/**
 * Lo de arriba se juzga contra un store en memoria. Esto lo repite contra el
 * servidor REAL con el modelo (c2) publicado: que FGA acepte las aristas que
 * el driver escribe, que la herencia las use, y —la razón por la que el
 * `moved` del cruce 8 necesita un `Read`— que borrar una tupla inexistente
 * sea un error del servidor, no un no-op.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2b — el árbol del driver contra el servidor real', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    test('attached/moved/detached mantienen el árbol en un store real y la herencia lo sigue', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `facts-tree-${Date.now()}` })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const orgA = orgScope()
      const orgB = orgScope()
      const unit = unitScope()
      await tree.attach(orgA, APP_SCOPE)
      await tree.attach(orgB, APP_SCOPE)
      await tree.attach(unit, orgA)
      const driver = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      const client = new OpenFgaClient({
        apiUrl,
        storeId: store.id,
        authorizationModelId: model.authorization_model_id,
      })

      await driver.onScopeAttached(orgA, APP_SCOPE)
      await driver.onScopeAttached(orgB, APP_SCOPE)
      await driver.onScopeAttached(unit, orgA)

      // Un grant en orgA: el rol, el binding y el vínculo del catálogo.
      const roleUuid = '0192f000-0000-7000-8000-000000000001'
      const binding = `role_binding:organization|${orgA.uuid}|${roleUuid}`
      await client.writeTuples([
        // El marcador de raíz (3b-2i): store montado a mano, ver A1.
        { user: 'user:*', relation: 'rooted', object: 'scope:app' },
        { user: 'user:*', relation: 'permits_docs_read', object: `role:${roleUuid}` },
        { user: `role:${roleUuid}`, relation: 'role', object: binding },
        { user: 'user:u1', relation: 'assignee', object: binding },
        { user: binding, relation: 'binding', object: `scope:organization|${orgA.uuid}` },
      ])
      const ask = async (scope: any) =>
        (
          await client.check({
            user: 'user:u1',
            relation: 'can_docs_read',
            object: `scope:${scope}`,
            context: { current_time: new Date().toISOString() },
          })
        ).allowed

      assert.isTrue(await ask(`unit|${unit.uuid}`), 'la unit hereda de su org (invariante 1)')
      assert.isFalse(await ask(`organization|${orgB.uuid}`), 'la otra org no (nunca a hermanos)')
      assert.isFalse(await ask('app'), 'y nunca hacia arriba')

      // Mover la unit a orgB: deja de heredar de A y no hereda de B (que no concede).
      await tree.attach(unit, orgB)
      await driver.onScopeMoved(unit, orgB)
      assert.isFalse(await ask(`unit|${unit.uuid}`), 'movida a orgB, la unit ya no hereda el grant de orgA')

      // Y sacarla del árbol le quita el ancestro por completo.
      await driver.onScopeDetached(unit)
      const left = await client.read({ object: `scope:unit|${unit.uuid}`, relation: 'parent' })
      assert.lengthOf(left.tuples ?? [], 0, 'la arista se fue')
    })

    test('por qué `moved` necesita el `Read`: FGA RECHAZA borrar una tupla que no existe', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `facts-del-${Date.now()}` })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const client = new OpenFgaClient({
        apiUrl,
        storeId: store.id,
        authorizationModelId: model.authorization_model_id,
      })

      let caught: any = null
      try {
        await client.write({
          writes: [{ user: 'scope:app', relation: 'parent', object: 'scope:organization|nada' }],
          deletes: [{ user: 'scope:app', relation: 'parent', object: 'scope:unit|fantasma' }],
        })
      } catch (error) {
        caught = error
      }
      assert.isNotNull(caught, 'el servidor no ignora un delete de una tupla inexistente')
      // …y el write que la acompañaba TAMPOCO aterrizó: el Write es atómico,
      // que es lo que hace legal el `moved` del cruce 8.
      const written = await client.read({ object: 'scope:organization|nada', relation: 'parent' })
      assert.lengthOf(written.tuples ?? [], 0, 'un delete fallido aborta el write que lo acompaña')
    })
  })
}

/* ════════════════════════════════════════════════════════════════════════
 * 3b-2c — `authorize` DE UN SOLO `Check`
 *
 * En modo `facts` la jerarquía, el catálogo y los denies ya están en el
 * store: `authorize` deja de expandir la cadena a un `batchCheck` de N×M
 * items y pasa a ser UN `Check` de `can_<P>` sobre `scope:<key>`. Lo único
 * local que sigue consultando es el MEMO del catálogo, y es obligatorio: un
 * permiso desconocido tiene que ser `false` (invariante 5) y no una relación
 * inexistente que el servidor rechaza con un 400 que saldría como 503.
 *
 * Lo demás de este sub-lote es la forma NUEVA de los objetos que escriben
 * `grant`/`deny`/`revoke`/`removeDeny`: el binding enlazado al scope y al
 * rol, y el deny como `scope:<key>#denied_<P>@<holder>`.
 * ════════════════════════════════════════════════════════════════════════ */

/**
 * El driver en modo `facts` con el cliente sustituido por un store en memoria
 * COMPLETO (`read`/`write`/`writeTuples`/`deleteTuples`) y espías de `check`,
 * `batchCheck` y del resolutor del consumidor: cuántas requests hace cada
 * operación —y de qué forma son las tuplas— se juzga aquí sin servidor; la
 * SEMÁNTICA se juzga contra el `:8101` más abajo.
 */
function factsDriver(
  options: { allow?: (check: any) => boolean } = {}
) {
  const tree = memoryScopeTree()
  const base = resolveChainFrom(tree)
  /** Cada llamada al resolutor del consumidor: `authorize` no puede hacer ninguna. */
  const resolved: any[] = []
  const driver = new OpenFgaAuthorizationDriver({
    apiUrl: 'http://127.0.0.1:9',
    storeId: '01ARZ3NDEKTSV4RRFFQ69G5FAV',
    holderTypes: HOLDERS,
    resolveChain: async (scope: any) => {
      resolved.push(scope)
      return base(scope)
    },
    acceptScopeDriftRisk: true,
    logger: { warn: () => {} },
  })
  const tuples = new Map<string, any>()
  const reads: any[] = []
  const mutations: Array<{ kind: string; writes: any[]; deletes: any[] }> = []
  const checks: any[] = []
  const batches: any[] = []
  const key = (t: any) => `${t.user}#${t.relation}@${t.object}`
  const allow = options.allow ?? (() => false)
  const client: any = (driver as any).client
  client.read = async (filter: any) => {
    reads.push(filter)
    return {
      tuples: [...tuples.values()]
        .filter((t) => (filter?.object ? t.object.startsWith(filter.object) : true))
        .filter((t) => (filter?.relation ? t.relation === filter.relation : true))
        .filter((t) => (filter?.user ? t.user === filter.user : true))
        .map((t) => ({ key: t })),
      continuation_token: '',
    }
  }
  client.write = async (body: any) => {
    mutations.push({ kind: 'write', writes: body.writes ?? [], deletes: body.deletes ?? [] })
    for (const t of body.deletes ?? []) tuples.delete(key(t))
    for (const t of body.writes ?? []) tuples.set(key(t), t)
    return {}
  }
  client.writeTuples = async (list: any[]) => {
    mutations.push({ kind: 'writeTuples', writes: list, deletes: [] })
    for (const t of list) tuples.set(key(t), t)
    return {}
  }
  client.deleteTuples = async (list: any[]) => {
    mutations.push({ kind: 'deleteTuples', writes: [], deletes: list })
    for (const t of list) tuples.delete(key(t))
    return {}
  }
  client.check = async (body: any) => {
    checks.push(body)
    return { allowed: allow(body) }
  }
  client.batchCheck = async (body: any) => {
    batches.push(body)
    return {
      result: (body.checks ?? []).map((c: any) => ({
        allowed: allow(c),
        correlationId: c.correlationId,
        request: c,
      })),
    }
  }
  return { driver, tree, tuples, reads, mutations, checks, batches, resolved }
}

/** Las tuplas del store en memoria, como `user#relation@object`, ordenadas. */
function tupleList(tuples: Map<string, any>): string[] {
  return [...tuples.values()].map((t) => `${t.user}#${t.relation}@${t.object}`).sort()
}

/** El catálogo mínimo de los casos de 2c: un permiso y un rol de organization. */
async function seedCatalog() {
  await cleanAuthzTables()
  await syncAuthzCatalog({
    permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
    roles: [
      { slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] },
      { slug: 'app-admin', scopeType: 'app', permissions: ['docs:read', 'docs:write'] },
    ],
  })
}

const roleUuidOf = async (slug: string): Promise<string> =>
  (await db.from('authz_roles').where('slug', slug).select('uuid').first()).uuid

test.group('facts · 3b-2c — `authorize` es UN solo Check', (group) => {
  group.each.setup(seedCatalog)

  test('un `check` de `can_<P>` sobre `scope:<key>`: 0 batchCheck y 0 resolveChain', async ({
    assert,
  }) => {
    const { driver, tree, checks, batches, resolved } = factsDriver({
      allow: (c) => c.relation === 'can_docs_read',
    })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    const allowed = await driver.authorize({ type: 'users', uuid: 'u1' }, 'docs:read', org)

    assert.isTrue(allowed)
    assert.lengthOf(checks, 1)
    assert.equal(checks[0].user, 'user:u1')
    assert.equal(checks[0].relation, 'can_docs_read')
    assert.equal(checks[0].object, `scope:organization|${org.uuid}`)
    assert.isString(checks[0].context?.current_time, 'el instante de la operación viaja en el check (K9)')
    assert.lengthOf(batches, 0, 'ni un batchCheck: la cadena ya no se expande')
    assert.deepEqual(resolved, [], 'ni una llamada al resolutor del consumidor (cruce 6)')
  })

  test('el `false` del Check es el `false` de la respuesta (denegación por defecto)', async ({
    assert,
  }) => {
    const { driver, tree, checks } = factsDriver({ allow: () => false })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    assert.isFalse(await driver.authorize({ type: 'users', uuid: 'u1' }, 'docs:read', org))
    assert.lengthOf(checks, 1)
  })

  test('MEMO OBLIGATORIO: un permiso desconocido es `false` y NO llega al servidor (invariante 5)', async ({
    assert,
  }) => {
    const { driver, tree, checks, batches } = factsDriver({ allow: () => true })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    // Sin la guardia del catálogo esto sería un Check de `can_no_existe`, una
    // relación que el modelo no declara: 400 del servidor ⇒ 503. El invariante
    // 5 exige `false`.
    assert.isFalse(await driver.authorize({ type: 'users', uuid: 'u1' }, 'no:existe', org))
    assert.deepEqual(checks, [])
    assert.deepEqual(batches, [])
  })

  test('un fallo del backend es 503, nunca un `false` silencioso', async ({ assert }) => {
    const { driver, tree } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    ;(driver as any).client.check = async () => {
      throw new Error('boom')
    }

    await rejects(
      assert,
      () => driver.authorize({ type: 'users', uuid: 'u1' }, 'docs:read', org),
      { status: 503, code: 'E_AUTHZ_BACKEND_UNAVAILABLE' },
      'el Check se cayó'
    )
  })
})

test.group('facts · 3b-2c — `authorizeMany` es UN batchCheck de N items', (group) => {
  group.each.setup(seedCatalog)

  test('N scopes ⇒ 1 batchCheck con un item por scope (no el N×M de hoy), 0 resolveChain', async ({
    assert,
  }) => {
    const orgA = orgScope()
    const orgB = orgScope()
    const { driver, tree, batches, checks, resolved } = factsDriver({
      allow: (c) => c.object === `scope:organization|${orgA.uuid}`,
    })
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE)

    const answers = await driver.authorizeMany({ type: 'users', uuid: 'u1' }, 'docs:read', [
      orgA,
      orgB,
      APP_SCOPE,
    ])

    assert.deepEqual(answers, [true, false, false])
    assert.lengthOf(batches, 1)
    assert.lengthOf(batches[0].checks, 3, 'un item por scope')
    assert.deepEqual(
      batches[0].checks.map((c: any) => `${c.relation} ${c.object}`),
      [
        `can_docs_read scope:organization|${orgA.uuid}`,
        `can_docs_read scope:organization|${orgB.uuid}`,
        'can_docs_read scope:app',
      ]
    )
    assert.deepEqual(checks, [], 'y ni un `check` suelto')
    assert.deepEqual(resolved, [])
  })

  test('un scope repetido COMPARTE item y su respuesta (no duplica el lote)', async ({
    assert,
  }) => {
    const orgA = orgScope()
    const { driver, tree, batches } = factsDriver({
      allow: (c) => c.object === `scope:organization|${orgA.uuid}`,
    })
    const orgB = orgScope()
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE)

    const answers = await driver.authorizeMany({ type: 'users', uuid: 'u1' }, 'docs:read', [
      orgA,
      orgB,
      orgA,
    ])

    assert.deepEqual(answers, [true, false, true])
    assert.lengthOf(batches, 1)
    assert.lengthOf(batches[0].checks, 2, 'dos scopes distintos, dos items')
  })

  test('permiso desconocido ⇒ todo `false` sin tocar el servidor; sin scopes, `[]`', async ({
    assert,
  }) => {
    const { driver, tree, batches } = factsDriver({ allow: () => true })
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    assert.deepEqual(
      await driver.authorizeMany({ type: 'users', uuid: 'u1' }, 'no:existe', [org, APP_SCOPE]),
      [false, false]
    )
    assert.deepEqual(await driver.authorizeMany({ type: 'users', uuid: 'u1' }, 'docs:read', []), [])
    assert.deepEqual(batches, [])
  })

  test('un `error` en un check del lote es 503, no un `false` (invariante 5)', async ({ assert }) => {
    const { driver, tree } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    ;(driver as any).client.batchCheck = async (body: any) => ({
      result: (body.checks ?? []).map((c: any) => ({
        correlationId: c.correlationId,
        error: { message: 'input_error' },
        request: c,
      })),
    })

    await rejects(
      assert,
      () => driver.authorizeMany({ type: 'users', uuid: 'u1' }, 'docs:read', [org]),
      { status: 503, code: 'E_AUTHZ_BACKEND_UNAVAILABLE' },
      'un error por check'
    )
  })
})

test.group('facts · 3b-2c — `grant`/`revoke` escriben el binding ENLAZADO', (group) => {
  group.each.setup(seedCatalog)

  test('`grant` enlaza el binding al scope y al rol, además del asignado', async ({ assert }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')
    const binding = `role_binding:organization|${org.uuid}|${roleUuid}`

    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })

    assert.deepEqual(tupleList(tuples), [
      `role:${roleUuid}#role@${binding}`,
      `${binding}#binding@scope:organization|${org.uuid}`,
      `user:u1#assignee@${binding}`,
    ])
  })

  test('el enlace es idempotente: un segundo grant no lo duplica ni falla', async ({ assert }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')

    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })
    await driver.grant({ type: 'users', uuid: 'u2' }, 'org-editor', org, { expiresAt: null })

    assert.deepEqual(tupleList(tuples), [
      `role:${roleUuid}#role@role_binding:organization|${org.uuid}|${roleUuid}`,
      `role_binding:organization|${org.uuid}|${roleUuid}#binding@scope:organization|${org.uuid}`,
      `user:u1#assignee@role_binding:organization|${org.uuid}|${roleUuid}`,
      `user:u2#assignee@role_binding:organization|${org.uuid}|${roleUuid}`,
    ])
  })

  test('`revoke` se lleva la asignación y deja el enlace (inerte sin asignados, y otro holder lo sigue usando)', async ({
    assert,
  }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')
    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })
    await driver.grant({ type: 'users', uuid: 'u2' }, 'org-editor', org, { expiresAt: null })

    await driver.revoke({ type: 'users', uuid: 'u1' }, 'org-editor', org)

    assert.deepEqual(tupleList(tuples), [
      `role:${roleUuid}#role@role_binding:organization|${org.uuid}|${roleUuid}`,
      `role_binding:organization|${org.uuid}|${roleUuid}#binding@scope:organization|${org.uuid}`,
      `user:u2#assignee@role_binding:organization|${org.uuid}|${roleUuid}`,
    ])
  })
})

/**
 * **3b-2f · R3 — el `grant` de (c2) es UNA escritura, no tres.**
 *
 * En (c2) una asignación son TRES tuplas: el `assignee`, la arista
 * `role_binding#role` y la arista `scope#binding`. Hasta 3b-2e viajaban en
 * DOS `Write` (las aristas primero, el `assignee` después), y eso no es
 * atómico: un `purgeScope` concurrente podía llevarse la arista entre una y
 * otra y dejar la asignación VISIBLE para `listRoles`/`hasRole` e INERTE para
 * `authorize` — las dos lecturas contradiciéndose sobre el mismo hecho. Aquí
 * se cuenta lo que sale por el cable; la carrera de verdad la juzgan los
 * casos del contrato contra el servidor real.
 */
test.group('facts · 3b-2f · R3 — el `grant` es UN solo Write atómico', (group) => {
  group.each.setup(seedCatalog)

  test('un grant nuevo son las TRES tuplas en UNA sola escritura', async ({ assert }) => {
    const { driver, tree, mutations } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')
    const binding = `role_binding:organization|${org.uuid}|${roleUuid}`

    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })

    assert.lengthOf(mutations, 1, `una sola escritura: ${mutations.map((m) => m.kind).join(', ')}`)
    assert.deepEqual(
      mutations[0].writes.map((t: any) => `${t.user}#${t.relation}@${t.object}`).sort(),
      [
        `role:${roleUuid}#role@${binding}`,
        `${binding}#binding@scope:organization|${org.uuid}`,
        `user:u1#assignee@${binding}`,
      ].sort()
    )
    assert.deepEqual(mutations[0].deletes, [])
  })

  /**
   * **La otra puerta de `grant`** (tester Fase 3b · M13). El caso de arriba
   * cubre el camino feliz (`readAssignment` ⇒ `absent`), que escribe con
   * `client.writeTuples(writeSet(...))`. Pero hay una SEGUNDA puerta —
   * `writeAssignment`— por la que se pasa cuando la RELECTURA del store no
   * responde (`current.kind === 'unknown'`, con `expiresAt` explícito) y
   * cuando una carrera obliga a releer y la relectura tampoco responde. Es el
   * camino DEGRADADO, justo el que más se usa cuando el store va mal, y su
   * atomicidad no la observaba nadie: partirla en dos `Write` —el `assignee`
   * primero y sus aristas después— dejaba la suite ENTERA en verde (752/752),
   * y deja exactamente el estado que el invariante 6 prohíbe: una asignación
   * que `listRoles`/`hasRole` enumeran y `authorize` no honra.
   */
  test('con la RELECTURA del store caída, el grant sigue siendo UNA sola escritura con las tres tuplas (la puerta degradada, invariante 6)', async ({
    assert,
  }) => {
    const { driver, tree, mutations } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')
    const binding = `role_binding:organization|${org.uuid}|${roleUuid}`
    // El store no deja LEER (pero sí escribir): es el camino `unknown`.
    const client: any = (driver as any).client
    client.read = async () => {
      throw new Error('el store no responde a la lectura')
    }

    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })

    assert.deepEqual(
      mutations.map((m) => m.kind),
      ['writeTuples'],
      `también aquí es UNA escritura: ${mutations.map((m) => m.kind).join(', ')}`
    )
    assert.deepEqual(
      mutations[0].writes.map((t: any) => `${t.user}#${t.relation}@${t.object}`).sort(),
      [
        `role:${roleUuid}#role@${binding}`,
        `${binding}#binding@scope:organization|${org.uuid}`,
        `user:u1#assignee@${binding}`,
      ].sort(),
      'las tres juntas: un `assignee` sin sus aristas es una asignación que se enumera y no concede'
    )
  })

  test('cambiar la caducidad es delete + write, y el write LLEVA las aristas (el estado final es coherente)', async ({
    assert,
  }) => {
    const { driver, tree, mutations } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')
    const binding = `role_binding:organization|${org.uuid}|${roleUuid}`
    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })
    mutations.length = 0

    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, {
      expiresAt: new Date(Date.now() + 3_600_000),
    })

    // FGA no admite delete+write de la misma tuple key en una transacción; lo
    // que sí se exige es que el WRITE reponga la estructura, para que una
    // purga que se llevó la arista entre medias no deje la asignación inerte.
    assert.deepEqual(mutations.map((m) => m.kind), ['deleteTuples', 'writeTuples'])
    assert.deepEqual(
      mutations[1].writes.map((t: any) => `${t.user}#${t.relation}@${t.object}`).sort(),
      [
        `role:${roleUuid}#role@${binding}`,
        `${binding}#binding@scope:organization|${org.uuid}`,
        `user:u1#assignee@${binding}`,
      ].sort()
    )
  })

  test('un segundo holder en el mismo scope: las aristas ya estaban y el choque NO es un 503 (una sola asignación más)', async ({
    assert,
  }) => {
    const { driver, tree, tuples, mutations } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    const roleUuid = await roleUuidOf('org-editor')
    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })

    // El servidor REAL rechaza con «cannot write a tuple which already
    // exists» un Write cuya transacción incluye una tupla que ya está: el
    // doble lo imita para el par de aristas, que es justo lo que un segundo
    // holder vuelve a mandar. Un grant que se rindiera aquí sería un 503 en
    // el camino más común que hay.
    const client: any = (driver as any).client
    const plain = client.writeTuples
    client.writeTuples = async (list: any[], options: any) => {
      const already = list.some((t) => tuples.has(`${t.user}#${t.relation}@${t.object}`))
      if (already && options?.conflict?.onDuplicateWrites !== 'ignore') {
        throw Object.assign(new Error('FGA API Validation Error: post write'), {
          apiErrorCode: 'write_failed_due_to_invalid_input',
          apiErrorMessage: 'cannot write a tuple which already exists',
        })
      }
      return plain(list, options)
    }
    mutations.length = 0

    const outcome = await driver.grant({ type: 'users', uuid: 'u2' }, 'org-editor', org, {
      expiresAt: null,
    })

    assert.isFalse(outcome.existed)
    assert.deepEqual(tupleList(tuples), [
      `role:${roleUuid}#role@role_binding:organization|${org.uuid}|${roleUuid}`,
      `role_binding:organization|${org.uuid}|${roleUuid}#binding@scope:organization|${org.uuid}`,
      `user:u1#assignee@role_binding:organization|${org.uuid}|${roleUuid}`,
      `user:u2#assignee@role_binding:organization|${org.uuid}|${roleUuid}`,
    ])
  })

  test('`purgeScope` borra la ESTRUCTURA primero, los `assignee` después y los `denied_<P>` al final', async ({
    assert,
  }) => {
    const { driver, tree, tuples, mutations } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    await driver.onScopeAttached!(org, APP_SCOPE)
    await driver.grant({ type: 'users', uuid: 'u1' }, 'org-editor', org, { expiresAt: null })
    await driver.deny({ type: 'users', uuid: 'u1' }, 'docs:read', org)
    mutations.length = 0

    await driver.purgeScope(org)

    // El orden es lo que hace que ningún hueco de la carrera deje un
    // `assignee` sin arista (un grant que aterrice tarde se trae las suyas) y
    // que una purga que muera a medias deje denies de más, nunca de menos.
    assert.deepEqual(
      mutations.map((m) => `${m.kind}:${m.deletes.map((t: any) => t.relation).sort().join('+')}`),
      ['deleteTuples:binding+role', 'deleteTuples:assignee', 'deleteTuples:denied_docs_read']
    )
    // Y la arista `parent` no se toca: la borra `scopes.detached` después.
    assert.deepEqual(tupleList(tuples), [`scope:app#parent@scope:organization|${org.uuid}`])
  })
})

test.group('facts · 3b-2c — `deny`/`removeDeny` son `scope#denied_<P>`', (group) => {
  group.each.setup(seedCatalog)

  test('`deny` escribe `scope:<key>#denied_<P>@<holder>` y ningún `deny_binding`', async ({
    assert,
  }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    await driver.deny({ type: 'users', uuid: 'u1' }, 'docs:read', org)

    assert.deepEqual(tupleList(tuples), [`user:u1#denied_docs_read@scope:organization|${org.uuid}`])
  })

  test('`removeDeny` lo quita, y re-denegar/re-quitar son no-ops seguros (invariante 6)', async ({
    assert,
  }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    await driver.deny({ type: 'users', uuid: 'u1' }, 'docs:read', org)
    await driver.deny({ type: 'users', uuid: 'u1' }, 'docs:read', org)
    await driver.removeDeny({ type: 'users', uuid: 'u1' }, 'docs:read', org)
    await driver.removeDeny({ type: 'users', uuid: 'u1' }, 'docs:read', org)

    assert.deepEqual(tupleList(tuples), [])
  })

  test('un permiso fuera del catálogo sigue siendo 422 en las dos escrituras', async ({ assert }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)

    await rejects(
      assert,
      () => driver.deny({ type: 'users', uuid: 'u1' }, 'no:existe', org),
      { status: 422, code: 'E_AUTHZ_UNKNOWN_PERMISSION' }
    )
    await rejects(
      assert,
      () => driver.removeDeny({ type: 'users', uuid: 'u1' }, 'no:existe', org),
      { status: 422, code: 'E_AUTHZ_UNKNOWN_PERMISSION' }
    )
    assert.deepEqual(tupleList(tuples), [])
  })

  test('`listDenies` lee la forma NUEVA (si no, un deny vivo sería invisible)', async ({
    assert,
  }) => {
    const { driver, tree } = factsDriver()
    const org = orgScope()
    const other = orgScope()
    await tree.attach(org, APP_SCOPE)
    await tree.attach(other, APP_SCOPE)
    const subject = { type: 'users', uuid: 'u1' }

    await driver.deny(subject, 'docs:read', org)
    await driver.deny(subject, 'docs:write', other)

    assert.deepEqual(await driver.listDenies(subject, org), [{ permission: 'docs:read', scope: org }])
    assert.sameDeepMembers(await driver.listDenies(subject), [
      { permission: 'docs:read', scope: org },
      { permission: 'docs:write', scope: other },
    ])
  })

  test('`listScopes` no lista un scope donde el deny gana (si no lo viera, sería fail-open)', async ({
    assert,
  }) => {
    const { driver, tree } = factsDriver()
    const orgA = orgScope()
    const orgB = orgScope()
    await tree.attach(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE)
    const subject = { type: 'users', uuid: 'u1' }
    await driver.grant(subject, 'org-editor', orgA, { expiresAt: null })
    await driver.grant(subject, 'org-editor', orgB, { expiresAt: null })

    await driver.deny(subject, 'docs:read', orgB)

    assert.deepEqual(await driver.listScopes(subject, 'docs:read'), [orgA])
  })

  test('`purgeScope` se lleva los denies y el enlace del scope, y NO la arista `parent`', async ({
    assert,
  }) => {
    const { driver, tree, tuples } = factsDriver()
    const org = orgScope()
    await tree.attach(org, APP_SCOPE)
    await driver.onScopeAttached!(org, APP_SCOPE)
    const subject = { type: 'users', uuid: 'u1' }
    await driver.grant(subject, 'org-editor', org, { expiresAt: null })
    await driver.deny(subject, 'docs:read', org)

    await driver.purgeScope(org)

    assert.deepEqual(
      tupleList(tuples),
      [`scope:app#parent@scope:organization|${org.uuid}`],
      'la arista es lo ÚLTIMO y la borra `detached`, no la purga (S6)'
    )
  })
})

/**
 * **3b-2c contra el servidor REAL.** Lo de arriba fija la FORMA (cuántas
 * requests, qué tuplas); esto fija la SEMÁNTICA, que es lo único que
 * demuestra que el Check único responde lo que responde el contrato. Todo el
 * camino es el del paquete: `syncAuthzCatalog` con la proyección del driver,
 * `scopes.attached` para el árbol, `grant`/`deny`/`revoke`/`removeDeny` para
 * los hechos y `authorize`/`authorizeMany` para preguntar. Ni una tupla a
 * mano.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2c — un solo Check contra el servidor real', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    /** Store con el modelo (c2), catálogo sincronizado (con proyección) y árbol en el store. */
    async function factsStore() {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-authorize-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const driver = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
          roles: [
            { slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] },
            { slug: 'unit-lead', scopeType: 'unit', permissions: ['docs:read', 'docs:write'] },
          ],
        },
        { projection: driver.catalogProjection() }
      )
      const orgA = orgScope()
      const orgB = orgScope()
      const unit = unitScope()
      await tree.attach(orgA, APP_SCOPE)
      await tree.attach(orgB, APP_SCOPE)
      await tree.attach(unit, orgA)
      await driver.onScopeAttached(orgA, APP_SCOPE)
      await driver.onScopeAttached(orgB, APP_SCOPE)
      await driver.onScopeAttached(unit, orgA)
      return { driver, tree, orgA, orgB, unit }
    }

    /**
     * **Corrección de 3b-2a encontrada aquí.** La proyección del catálogo
     * (A5) se juzgó contra un doble en memoria, y el doble aceptaba un `Read`
     * cuyo objeto era solo el tipo (`role:`) sin `user`. El servidor REAL lo
     * rechaza con un 400 («the object type field is required and both the
     * object id and user cannot be empty»), así que `syncAuthzCatalog` con
     * proyección era un 503 en cuanto tocaba un store de verdad. Se lee por
     * cada comodín de holder, que es exactamente la forma de las tuplas de
     * (c2), y el espejo sigue convergiendo (incluidas las de un rol que el
     * catálogo ya no lista).
     */
    test('la proyección del catálogo converge contra el servidor real', async ({ assert }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-projection-${Date.now()}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const driver = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      const client = new OpenFgaClient({ apiUrl, storeId: store.id })
      const permits = async () => {
        const out: string[] = []
        for (const holder of Object.values(HOLDERS)) {
          const page = await client.read({ user: `${holder}:*`, object: 'role:' })
          out.push(...(page.tuples ?? []).map((t: any) => `${t.key.user}#${t.key.relation}@${t.key.object}`))
        }
        return out.sort()
      }
      const sync = (permissions: string[]) =>
        syncAuthzCatalog(
          {
            permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
            roles: [{ slug: 'org-editor', scopeType: 'organization', permissions }],
          },
          { projection: driver.catalogProjection() }
        )

      await cleanAuthzTables()
      await sync(['docs:read', 'docs:write'])
      const roleUuid = await roleUuidOf('org-editor')
      assert.lengthOf(await permits(), 6, '2 permisos × 3 holders')

      // Quitar un permiso del rol son deletes, no una reescritura del modelo.
      await sync(['docs:read'])
      assert.deepEqual(await permits(), [
        `admin:*#permits_docs_read@role:${roleUuid}`,
        `integration:*#permits_docs_read@role:${roleUuid}`,
        `user:*#permits_docs_read@role:${roleUuid}`,
      ])
    })

    test('un grant concede en su scope y HACIA ABAJO, nunca en hermanos ni hacia arriba (invariante 1)', async ({
      assert,
    }) => {
      const { driver, orgA, orgB, unit } = await factsStore()
      const u1 = { type: 'users', uuid: '01a00000-0000-7000-8000-0000000000u1'.replace('u1', '01') }

      assert.isFalse(await driver.authorize(u1, 'docs:read', orgA), 'sin grant, nada')

      await driver.grant(u1, 'org-editor', orgA, { expiresAt: null })

      assert.isTrue(await driver.authorize(u1, 'docs:read', orgA))
      assert.isTrue(await driver.authorize(u1, 'docs:read', unit), 'la unit hereda de su org')
      assert.isFalse(await driver.authorize(u1, 'docs:read', orgB), 'nunca a hermanos')
      assert.isFalse(await driver.authorize(u1, 'docs:read', APP_SCOPE), 'nunca hacia arriba')
      assert.isFalse(
        await driver.authorize(u1, 'docs:write', orgA),
        'el catálogo acota lo que el rol concede'
      )

      // Y la enumeración dice lo mismo que la decisión.
      assert.deepEqual(await driver.listScopes(u1, 'docs:read'), [orgA])

      await driver.revoke(u1, 'org-editor', orgA)
      assert.isFalse(await driver.authorize(u1, 'docs:read', orgA), 'revocar quita, y hacia abajo también')
      assert.isFalse(await driver.authorize(u1, 'docs:read', unit))
    })

    test('el deny explícito gana en la cadena y quitarlo restaura (invariante 2)', async ({
      assert,
    }) => {
      const { driver, orgA, unit } = await factsStore()
      const u1 = { type: 'users', uuid: '01a00000-0000-7000-8000-000000000002' }
      await driver.grant(u1, 'org-editor', orgA, { expiresAt: null })

      await driver.deny(u1, 'docs:read', unit)
      assert.isFalse(await driver.authorize(u1, 'docs:read', unit), 'el deny del hijo gana')
      assert.isTrue(await driver.authorize(u1, 'docs:read', orgA), 'y no sube al padre')
      assert.deepEqual(await driver.listDenies(u1), [{ permission: 'docs:read', scope: unit }])
      assert.deepEqual(await driver.listScopes(u1, 'docs:read'), [orgA])

      // Un deny ARRIBA bloquea abajo (se hereda por `parent` dentro del modelo).
      await driver.deny(u1, 'docs:read', orgA)
      assert.isFalse(await driver.authorize(u1, 'docs:read', orgA))
      assert.deepEqual(await driver.listScopes(u1, 'docs:read'), [])

      await driver.removeDeny(u1, 'docs:read', orgA)
      await driver.removeDeny(u1, 'docs:read', unit)
      assert.isTrue(await driver.authorize(u1, 'docs:read', unit), 'quitar el deny restaura')
      assert.deepEqual(await driver.listDenies(u1), [])
    })

    test('una asignación caducada no concede, sin scheduler (invariante 3)', async ({ assert }) => {
      const { driver, orgA, unit } = await factsStore()
      const u1 = { type: 'users', uuid: '01a00000-0000-7000-8000-000000000003' }

      await driver.grant(u1, 'org-editor', orgA, { expiresAt: new Date(Date.now() - 60_000) })
      assert.isFalse(await driver.authorize(u1, 'docs:read', orgA))
      assert.isFalse(await driver.authorize(u1, 'docs:read', unit))

      await driver.grant(u1, 'org-editor', orgA, { expiresAt: new Date(Date.now() + 600_000) })
      assert.isTrue(await driver.authorize(u1, 'docs:read', orgA), 'vigente sí concede')
    })

    test('holders polimórficos: el mismo uuid con otro type no se cruza (invariante 4)', async ({
      assert,
    }) => {
      const { driver, orgA } = await factsStore()
      const uuid = '01a00000-0000-7000-8000-000000000004'
      await driver.grant({ type: 'users', uuid }, 'org-editor', orgA, { expiresAt: null })

      assert.isTrue(await driver.authorize({ type: 'users', uuid }, 'docs:read', orgA))
      assert.isFalse(await driver.authorize({ type: 'admins', uuid }, 'docs:read', orgA))
    })

    test('`authorizeMany` responde por scope lo mismo que `authorize`, en un solo lote', async ({
      assert,
    }) => {
      const { driver, orgA, orgB, unit } = await factsStore()
      const u1 = { type: 'users', uuid: '01a00000-0000-7000-8000-000000000005' }
      await driver.grant(u1, 'org-editor', orgA, { expiresAt: null })
      await driver.deny(u1, 'docs:read', unit)

      const scopes = [orgA, orgB, unit, orgA, APP_SCOPE]
      const many = await driver.authorizeMany(u1, 'docs:read', scopes)
      const one = []
      for (const scope of scopes) one.push(await driver.authorize(u1, 'docs:read', scope))

      assert.deepEqual(many, [true, false, false, true, false])
      assert.deepEqual(many, one, 'authorizeMany y authorize no pueden discrepar')
    })

    test('un permiso desconocido y un scope que el store no conoce son `false`, no un 503', async ({
      assert,
    }) => {
      const { driver, orgA } = await factsStore()
      const u1 = { type: 'users', uuid: '01a00000-0000-7000-8000-000000000006' }
      await driver.grant(u1, 'org-editor', orgA, { expiresAt: null })

      // Sin el memo esto sería `can_no_existe`: 400 del servidor ⇒ 503.
      assert.isFalse(await driver.authorize(u1, 'no:existe', orgA))
      assert.deepEqual(await driver.authorizeMany(u1, 'no:existe', [orgA]), [false])
      // Un scope que nadie colgó del árbol no tiene tuplas: `false`, y sin
      // preguntarle al resolutor del consumidor.
      assert.isFalse(await driver.authorize(u1, 'docs:read', orgScope()))
    })

    test('`purgeScope` deja el scope a cero en el store (hechos y denies de la forma nueva)', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const { driver, orgA, unit } = await factsStore()
      const u1 = { type: 'users', uuid: '01a00000-0000-7000-8000-000000000007' }
      await driver.grant(u1, 'unit-lead', unit, { expiresAt: null })
      await driver.deny(u1, 'docs:write', unit)
      assert.isTrue(await driver.authorize(u1, 'docs:read', unit))

      await driver.purgeScope(unit)

      assert.isFalse(await driver.authorize(u1, 'docs:read', unit), 'purgado, no concede')
      const client = new OpenFgaClient({ apiUrl, storeId: stores[stores.length - 1] })
      const left = await client.read({ object: `scope:unit|${unit.uuid}` })
      assert.deepEqual(
        (left.tuples ?? []).map((t: any) => t.key.relation),
        ['parent'],
        'la arista `parent` es lo único que sobrevive: la borra `detached` al final (S6)'
      )
      // Y el scope de arriba no se ha tocado.
      const u2 = { type: 'users', uuid: '01a00000-0000-7000-8000-000000000008' }
      await driver.grant(u2, 'org-editor', orgA, { expiresAt: null })
      assert.isTrue(await driver.authorize(u2, 'docs:read', orgA))
    })
  })
}

/* ══ 3b-2e · E1 — el barrido del rol local en `moved` ═══════════════════════ */

/**
 * **Decisión del dueño del 2026-08-30, opción (1).** En `facts` el modelo (c2)
 * no tiene `owner`, así que `authorize` no vuelve a decidir con el árbol de
 * HOY si un rol LOCAL sigue siendo visible: un `role_binding` concede mientras
 * su scope alcance al que pregunta. El invariante 18 decía «mover la unit
 * fuera del owner retira lo concedido SIN ESCRIBIR»; en este driver eso deja
 * de ser cierto y es un **fail-open**.
 *
 * La decisión es barrer en `moved`: el paquete borra las aristas
 * `scope#binding` de los roles locales cuyo owner ya no es ancestro del scope
 * donde cuelga la asignación — y **solo** esas. El criterio de aceptación es
 * un caso de **paridad entre drivers**: el mismo `moved` en `database` y en
 * `facts` ⇒ la misma respuesta de `authorize`.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2e · E1 — el barrido del rol local en `moved`', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    /**
     * Un rol LOCAL escrito directamente en el catálogo (que es local y de la
     * plataforma), sin pasar por `defineScopedRole`: E1 tiene que estar verde
     * ANTES de que E4 abra esa puerta en este driver.
     */
    async function defineLocalRole(
      slug: string,
      scopeType: string,
      ownerKey: string,
      permissions: string[],
      reproject?: () => Promise<unknown>
    ): Promise<string> {
      const uuid = uuidv7()
      const now = new Date()
      await withAuthzCatalogWrite(async (trx) => {
        await trx.table('authz_roles').insert({
          uuid, slug, name: slug, scope_type: scopeType, rank: 10,
          owner_scope_key: ownerKey, created_at: now, updated_at: now,
        })
        for (const permission of permissions) {
          const row: any = await trx.from('authz_permissions').where('slug', permission).select('uuid').first()
          await trx.table('authz_role_permissions').insert({ uuid: uuidv7(), role_uuid: uuid, permission_uuid: row.uuid, created_at: now })
        }
      })
      invalidateAuthzCatalog()
      // La proyección del catálogo (`role:<uuid>#permits_<P>`) es del store: un
      // rol escrito por fuera del sync no la tiene, y en `facts` un rol sin
      // proyección no concede NADA. Se rehace con un re-sync (el espejo es del
      // catálogo ENTERO, no del spec). Que `defineScopedRole` la mantenga por
      // sí solo es trabajo de E4.
      if (reproject) await reproject()
      return uuid
    }

    /**
     * El MISMO catálogo y el MISMO árbol para los dos drivers: `database` lee
     * el árbol con `resolveChain` y `openfga` lo tiene como hechos en el
     * store. Lo que se compara es la respuesta de `authorize`.
     */
    async function pair() {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-sweep-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const fga = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      const sync = () =>
        syncAuthzCatalog(
          {
            permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
            roles: [
              { slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] },
              { slug: 'unit-editor', scopeType: 'unit', permissions: ['docs:write'] },
            ],
          },
          { projection: fga.catalogProjection() }
        )
      await sync()
      const sql = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })

      const orgA = orgScope()
      const orgB = orgScope()
      const unit = unitScope()
      for (const [child, parent] of [[orgA, APP_SCOPE], [orgB, APP_SCOPE], [unit, orgA]] as const) {
        await tree.attach(child, parent)
        await fga.onScopeAttached!(child, parent)
      }
      /** Mueve el subárbol en los DOS drivers, como haría `manager.scopes.moved`. */
      const move = async (child: any, parent: any) => {
        await tree.move(child, parent)
        await fga.onScopeMoved!(child, parent)
      }
      return { fga, sql, tree, orgA, orgB, unit, move, sync }
    }

    test('PARIDAD: sacar la unit del owner del rol local retira lo concedido en los DOS drivers, y devolverla lo restaura', async ({
      assert,
    }) => {
      const { fga, sql, orgA, orgB, unit, move, sync } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      await defineLocalRole('lead', 'unit', `organization|${orgA.uuid}`, ['docs:read'], sync)

      // La unit cuelga de orgA, que es el owner: el rol local concede.
      await sql.grant(alice, 'lead', unit, { expiresAt: null })
      await fga.grant(alice, 'lead', unit, { expiresAt: null })
      assert.isTrue(await sql.authorize(alice, 'docs:read', unit), 'database: concede dentro del owner')
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'facts: concede dentro del owner')

      // La unit se va a orgB: el owner deja de estar en su cadena.
      await move(unit, orgB)
      assert.isFalse(await sql.authorize(alice, 'docs:read', unit), 'database: fuera del owner no concede')
      assert.isFalse(
        await fga.authorize(alice, 'docs:read', unit),
        'facts: fuera del owner tampoco (si concede, es el fail-open del hallazgo 2 del 2c)'
      )

      // Y vuelve: el invariante 18 dice que se restaura.
      await move(unit, orgA)
      assert.isTrue(await sql.authorize(alice, 'docs:read', unit), 'database: de vuelta, restaura')
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'facts: de vuelta, restaura')
    })

    test('y SOLO esas: un rol GLOBAL no se toca, y un rol local se conserva en los scopes que NO salieron del owner', async ({
      assert,
    }) => {
      const { fga, sql, tree, orgA, orgB, unit, move, sync } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      const otra = unitScope()
      await tree.attach(otra, orgA)
      await fga.onScopeAttached!(otra, orgA)
      await defineLocalRole('lead', 'unit', `organization|${orgA.uuid}`, ['docs:read'], sync)

      for (const driver of [sql, fga] as const) {
        // Un rol GLOBAL de nivel unit y el rol LOCAL, los dos en la unit que se mueve.
        await driver.grant(alice, { slug: 'unit-editor', scopeType: 'unit' }, unit, { expiresAt: null })
        await driver.grant(alice, 'lead', unit, { expiresAt: null })
        // Y el mismo rol local en OTRA unit que se queda donde está.
        await driver.grant(alice, 'lead', otra, { expiresAt: null })
      }
      assert.isTrue(await fga.authorize(alice, 'docs:write', unit), 'precondición: el global concede')
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'precondición: el local concede')

      await move(unit, orgB)

      for (const [name, driver] of [['database', sql], ['facts', fga]] as const) {
        assert.isTrue(await driver.authorize(alice, 'docs:write', unit), `${name}: el rol GLOBAL no se toca`)
        assert.isFalse(await driver.authorize(alice, 'docs:read', unit), `${name}: el local sale con el subárbol`)
        assert.isTrue(
          await driver.authorize(alice, 'docs:read', otra),
          `${name}: el local sigue vivo donde el owner SIGUE en la cadena`
        )
      }
    })

    test('el barrido es por SUBÁRBOL movido, no por nodo: los descendientes del nodo movido también cambian de cadena', async ({
      assert,
    }) => {
      const { fga, sql, tree, orgA, orgB, unit, move, sync } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      const sub = unitScope()
      await tree.attach(sub, unit)
      await fga.onScopeAttached!(sub, unit)
      await defineLocalRole('lead', 'unit', `organization|${orgA.uuid}`, ['docs:read'], sync)

      // La asignación cuelga del NIETO, no del nodo que se mueve.
      await sql.grant(alice, 'lead', sub, { expiresAt: null })
      await fga.grant(alice, 'lead', sub, { expiresAt: null })
      assert.isTrue(await sql.authorize(alice, 'docs:read', sub))
      assert.isTrue(await fga.authorize(alice, 'docs:read', sub))

      await move(unit, orgB)

      assert.isFalse(await sql.authorize(alice, 'docs:read', sub), 'database: el nieto también salió del owner')
      assert.isFalse(await fga.authorize(alice, 'docs:read', sub), 'facts: el barrido tiene que bajar el subárbol entero')
    })

    /**
     * **3b-8 · A3 — el `moved` REINTENTADO también barre.** El relay reintenta
     * (una pasada que muere tras el `Write` de la arista y antes del barrido
     * vuelve a entregar el mismo `moved`), y el reintento cae en el atajo
     * idempotente de `reparent` (la arista ya es la pedida). Hasta 3b-8 ese
     * atajo se saltaba `sweepLocalRoleBindings`: el rol local de la org A
     * seguía concediendo en el subárbol de la org B para siempre, con el
     * relay en verde.
     */
    test('un `moved` cuyo primer intento escribió la arista y murió ANTES del barrido: el reintento corre el barrido igual (invariante 18)', async ({
      assert,
    }) => {
      const { fga, sql, tree, orgA, orgB, unit, sync } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      await defineLocalRole('lead', 'unit', `organization|${orgA.uuid}`, ['docs:read'], sync)
      await sql.grant(alice, 'lead', unit, { expiresAt: null })
      await fga.grant(alice, 'lead', unit, { expiresAt: null })
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'precondición: dentro del owner concede')

      // El primer intento: la arista queda escrita en el store (lo que hace
      // `reparent` en su `Write`) y el proceso muere antes del barrido.
      await tree.move(unit, orgB)
      const unitObject = `scope:unit|${unit.uuid}`
      await (fga as any).client.write({
        writes: [{ user: `scope:organization|${orgB.uuid}`, relation: 'parent', object: unitObject }],
        deletes: [{ user: `scope:organization|${orgA.uuid}`, relation: 'parent', object: unitObject }],
      })

      // El REINTENTO del relay: la arista ya es la pedida (atajo idempotente).
      await fga.onScopeMoved!(unit, orgB)

      assert.isFalse(await sql.authorize(alice, 'docs:read', unit), 'database: fuera del owner no concede')
      assert.isFalse(
        await fga.authorize(alice, 'docs:read', unit),
        'facts: el reintento del `moved` tiene que barrer igual — si concede, el rol de la org A vive en el subárbol de la B (3b-8 · A3)'
      )

      // Y la vuelta, también por el camino del reintento, restaura.
      await tree.move(unit, orgA)
      await (fga as any).client.write({
        writes: [{ user: `scope:organization|${orgA.uuid}`, relation: 'parent', object: unitObject }],
        deletes: [{ user: `scope:organization|${orgB.uuid}`, relation: 'parent', object: unitObject }],
      })
      await fga.onScopeMoved!(unit, orgA)
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'facts: de vuelta, el reintento restaura la arista de visibilidad')
    })
  })
}

/* ══ 3b-2g · R1 — el barrido por NIVEL ═════════════════════════════════════ */

/**
 * **Decisión del dueño del 2026-08-30 (2), R1: se ARREGLA.** El modelo (c2)
 * tampoco conoce el NIVEL (`scope_type`) de un rol, así que cambiar el nivel
 * de un rol retira lo concedido en `database` —donde `declaredRoleAt` se
 * evalúa en cada pregunta— y **sigue concediendo** en `facts`. Es una
 * divergencia sin justificación: no compra nada.
 *
 * Se cierra con el MISMO mecanismo aprobado para el owner (barrer la arista
 * `scope#binding`), disparado desde `projectCatalogRole`, que es el hook de
 * «una escritura de catálogo cambió este rol». Consecuencia conceptual, que
 * se documenta y no se esconde: **la arista `scope#binding` significa «el rol
 * es visible aquí», no «esta asignación existe»** (el hecho de la asignación
 * es el `assignee`, que el barrido no toca).
 *
 * Criterio de aceptación: **paridad entre drivers** — el mismo cambio de
 * `scope_type` en `database` y en `facts` ⇒ la misma respuesta de `authorize`.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2g · R1 — el barrido por NIVEL', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    /** El mismo catálogo y el mismo árbol para los dos drivers (patrón de E1). */
    async function pair() {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-level-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const fga = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
          roles: [
            { slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] },
            { slug: 'unit-editor', scopeType: 'unit', permissions: ['docs:write'] },
          ],
        },
        { projection: fga.catalogProjection() }
      )
      const sql = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })

      const orgA = orgScope()
      const orgB = orgScope()
      const unit = unitScope()
      for (const [child, parent] of [[orgA, APP_SCOPE], [orgB, APP_SCOPE], [unit, orgA]] as const) {
        await tree.attach(child, parent)
        await fga.onScopeAttached!(child, parent)
      }
      const move = async (child: any, parent: any) => {
        await tree.move(child, parent)
        await fga.onScopeMoved!(child, parent)
      }
      return { fga, sql, tree, orgA, orgB, unit, move }
    }

    /** Un rol LOCAL a `ownerKey`, escrito a mano y proyectado en los dos drivers. */
    async function localRole(
      drivers: Array<Partial<AuthorizationDriver>>,
      slug: string,
      scopeType: string,
      ownerKey: string,
      permissions: string[]
    ): Promise<string> {
      const uuid = uuidv7()
      const now = new Date()
      await withAuthzCatalogWrite(async (trx) => {
        await trx.table('authz_roles').insert({
          uuid, slug, name: slug, scope_type: scopeType, rank: 10,
          owner_scope_key: ownerKey, created_at: now, updated_at: now,
        })
        for (const permission of permissions) {
          const row: any = await trx.from('authz_permissions').where('slug', permission).select('uuid').first()
          await trx.table('authz_role_permissions').insert({ uuid: uuidv7(), role_uuid: uuid, permission_uuid: row.uuid, created_at: now })
        }
      })
      invalidateAuthzCatalog()
      for (const driver of drivers) await driver.projectCatalogRole?.(uuid)
      return uuid
    }

    /**
     * El NIVEL declarado de un rol, cambiado a mano en `authz_roles` (la única
     * vía: la API de delegación no cambia el nivel a propósito, 3E · P1). El
     * escritor rehace la proyección derivada del driver, igual que ya tenía
     * que invalidar el memo — en `database` es un no-op.
     */
    async function retype(
      drivers: Array<Partial<AuthorizationDriver>>,
      roleUuid: string,
      scopeType: string
    ): Promise<void> {
      await withAuthzCatalogWrite(async (trx) => {
        await trx.from('authz_roles').where('uuid', roleUuid).update({ scope_type: scopeType, updated_at: new Date() })
      })
      invalidateAuthzCatalog()
      for (const driver of drivers) await driver.projectCatalogRole?.(roleUuid)
    }

    test('PARIDAD: cambiar el NIVEL de un rol local retira lo concedido en los DOS drivers, y devolverlo lo restaura', async ({
      assert,
    }) => {
      const { fga, sql, orgA, unit } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      const lead = await localRole([fga, sql], 'lead', 'unit', `organization|${orgA.uuid}`, ['docs:read'])

      await sql.grant(alice, 'lead', unit, { expiresAt: null })
      await fga.grant(alice, 'lead', unit, { expiresAt: null })
      assert.isTrue(await sql.authorize(alice, 'docs:read', unit), 'database: el nivel casa, concede')
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'facts: el nivel casa, concede')

      // El rol pasa a declararse para `organization`: la asignación sigue en
      // un scope `unit` y deja de contar.
      await retype([fga, sql], lead, 'organization')
      assert.isFalse(await sql.authorize(alice, 'docs:read', unit), 'database: el rol ya no existe en ese nivel')
      assert.isFalse(
        await fga.authorize(alice, 'docs:read', unit),
        'facts: tampoco (si concede, es el fail-open R1 del lote 2e)'
      )

      // Y vuelve a coincidir: se restaura, sin volver a conceder el grant.
      await retype([fga, sql], lead, 'unit')
      assert.isTrue(await sql.authorize(alice, 'docs:read', unit), 'database: vuelve a contar')
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'facts: vuelve a contar')
    })

    test('PARIDAD con un rol GLOBAL: no hace falta cadena para decidir el nivel, y las asignaciones de OTRO rol no se tocan', async ({
      assert,
    }) => {
      const { fga, sql, orgA, unit } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      const unitEditor: any = await db.from('authz_roles').where('slug', 'unit-editor').select('uuid').first()

      for (const driver of [sql, fga] as const) {
        await driver.grant(alice, { slug: 'unit-editor', scopeType: 'unit' }, unit, { expiresAt: null })
        await driver.grant(alice, { slug: 'org-editor', scopeType: 'organization' }, orgA, { expiresAt: null })
      }
      assert.isTrue(await fga.authorize(alice, 'docs:write', unit))
      assert.isTrue(await fga.authorize(alice, 'docs:read', unit), 'heredado de la organización')

      await retype([fga, sql], String(unitEditor.uuid), 'app')

      for (const [name, driver] of [['database', sql], ['facts', fga]] as const) {
        assert.isFalse(await driver.authorize(alice, 'docs:write', unit), `${name}: el rol ya no se declara para unit`)
        assert.isTrue(await driver.authorize(alice, 'docs:read', unit), `${name}: el otro rol no se toca`)
      }
    })

    test('y el barrido del owner no lo resucita: tras un `moved` dentro del owner la asignación de nivel equivocado sigue sin conceder', async ({
      assert,
    }) => {
      const { fga, sql, orgA, unit, move, tree } = await pair()
      const alice = { type: 'users', uuid: uuidv7() }
      const otra = orgScope()
      await tree.attach(otra, orgA)
      await fga.onScopeAttached!(otra, orgA)
      const lead = await localRole([fga, sql], 'lead', 'unit', `organization|${orgA.uuid}`, ['docs:read'])

      await sql.grant(alice, 'lead', unit, { expiresAt: null })
      await fga.grant(alice, 'lead', unit, { expiresAt: null })
      await retype([fga, sql], lead, 'organization')
      assert.isFalse(await fga.authorize(alice, 'docs:read', unit), 'precondición: el barrido por NIVEL quitó la arista')

      // El subárbol se mueve DENTRO del owner: el barrido de E1 reescribe las
      // aristas de los roles locales cuyo owner sigue en la cadena. Con la
      // regla única (nivel + owner) no puede reescribir esta.
      await move(unit, otra)
      assert.isFalse(await sql.authorize(alice, 'docs:read', unit), 'database: sigue sin contar')
      assert.isFalse(
        await fga.authorize(alice, 'docs:read', unit),
        'facts: el barrido del owner NO puede resucitar una arista que el nivel prohíbe'
      )
    })
  })
}

/* ══ 3b-2e · E4 — `purgeRole` soportado en `openfga` ════════════════════════ */

/**
 * Hasta 3b el driver `openfga` decía «no sé purgar un rol» NO declarando
 * `purgeRole`, y por eso `defineScopedRole` era 500 `E_AUTHZ_UNSUPPORTED`
 * antes de escribir (3E · P4): un rol local que nada puede borrar deja
 * muertos `deleteScopedRole` y `scopes.detached` para siempre.
 *
 * Con (c2) sí se enumera: el binding apunta a su rol (`role_binding#role`), así
 * que los bindings de un rol se leen filtrando por `user: role:<uuid>` — y la
 * arista `scope#binding` dice de qué scope cuelga cada uno.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2e · E4 — `purgeRole` y la API de delegación', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    async function world() {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-purgerole-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const driver = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
          roles: [
            { slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read', 'docs:write'] },
          ],
        },
        { projection: driver.catalogProjection() }
      )
      const manager = new AuthorizationManager({
        default: 'openfga',
        drivers: { openfga: () => driver },
        holderTypes: HOLDERS,
        scopes: { resolveChain: resolveChainFrom(tree), acceptScopeDriftRisk: true },
        delegablePermissions: ['docs:read', 'docs:write'],
        warnOnOptInSecurity: false,
      } as any)
      const orgA = orgScope()
      const unit = unitScope()
      const otra = unitScope()
      for (const [child, parent] of [[orgA, APP_SCOPE], [unit, orgA], [otra, orgA]] as const) {
        await tree.attach(child, parent)
        await driver.onScopeAttached!(child, parent)
      }
      const admin = { type: 'users', uuid: uuidv7() }
      await driver.grant(admin, { slug: 'org-admin', scopeType: 'organization' }, orgA, { expiresAt: null })
      return { driver, manager, tree, orgA, unit, otra, admin }
    }

    test('`defineScopedRole` deja de negarse Y el rol CONCEDE de verdad (la proyección se mantiene)', async ({
      assert,
    }) => {
      const { driver, manager, orgA, unit, admin } = await world()
      const alice = { type: 'users', uuid: uuidv7() }

      const lead = await manager.defineScopedRole(admin, orgA, {
        slug: 'lead',
        scopeType: 'unit',
        rank: 10,
        permissions: ['docs:write'],
      })
      assert.equal(lead.owner, `organization|${orgA.uuid}`)

      await driver.grant(alice, { uuid: lead.uuid }, unit, { expiresAt: null })
      assert.isTrue(
        await driver.authorize(alice, 'docs:write', unit),
        'un rol definido por la API tiene que CONCEDER: sin proyección, en `facts` no concede nada'
      )
      assert.isFalse(await driver.authorize(alice, 'docs:read', unit), 'y solo lo que vincula')
    })

    test('`updateScopedRole` que quita un permiso deja de conceder al instante', async ({ assert }) => {
      const { driver, manager, orgA, unit, admin } = await world()
      const alice = { type: 'users', uuid: uuidv7() }
      const lead = await manager.defineScopedRole(admin, orgA, {
        slug: 'lead', scopeType: 'unit', rank: 10, permissions: ['docs:read', 'docs:write'],
      })
      await driver.grant(alice, { uuid: lead.uuid }, unit, { expiresAt: null })
      assert.isTrue(await driver.authorize(alice, 'docs:read', unit))

      await manager.updateScopedRole(admin, lead.uuid, { permissions: ['docs:write'] })

      assert.isFalse(await driver.authorize(alice, 'docs:read', unit), 'el catálogo manda también en `facts`')
      assert.isTrue(await driver.authorize(alice, 'docs:write', unit))
    })

    test('`purgeRole` se lleva las asignaciones de TODOS los scopes, los vínculos y la fila; recrear el slug no revive nada', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const { driver, manager, orgA, unit, otra, admin } = await world()
      const alice = { type: 'users', uuid: uuidv7() }
      const bob = { type: 'users', uuid: uuidv7() }
      const lead = await manager.defineScopedRole(admin, orgA, {
        slug: 'lead', scopeType: 'unit', rank: 10, permissions: ['docs:write'],
      })
      await driver.grant(alice, { uuid: lead.uuid }, unit, { expiresAt: null })
      await driver.grant(bob, { uuid: lead.uuid }, otra, { expiresAt: null })
      assert.isTrue(await driver.authorize(alice, 'docs:write', unit))
      assert.isTrue(await driver.authorize(bob, 'docs:write', otra))

      assert.typeOf(driver.purgeRole, 'function', 'el driver `facts` sí sabe purgar un rol')
      await driver.purgeRole!(lead.uuid)

      assert.isFalse(await driver.authorize(alice, 'docs:write', unit))
      assert.isFalse(await driver.authorize(bob, 'docs:write', otra))
      assert.lengthOf(await db.from('authz_roles').where('uuid', lead.uuid).select('uuid'), 0, 'la fila del rol')
      assert.lengthOf(
        await db.from('authz_role_permissions').where('role_uuid', lead.uuid).select('uuid'),
        0,
        'y sus vínculos'
      )
      // Cero en el store: ni bindings, ni proyección del rol.
      const client = new OpenFgaClient({ apiUrl, storeId: stores[stores.length - 1] })
      const left = await client.read({ user: `role:${lead.uuid}`, object: 'role_binding:' })
      assert.lengthOf(left.tuples ?? [], 0, 'ningún binding apunta ya al rol')

      // Y el slug vuelve a existir con otro uuid: nada resucita.
      const otroLead = await manager.defineScopedRole(admin, orgA, {
        slug: 'lead', scopeType: 'unit', rank: 10, permissions: ['docs:write'],
      })
      assert.notEqual(otroLead.uuid, lead.uuid)
      assert.isFalse(await driver.authorize(alice, 'docs:write', unit), 'alice no resucita con el slug')
      await driver.grant(bob, { uuid: otroLead.uuid }, otra, { expiresAt: null })
      assert.isTrue(await driver.authorize(bob, 'docs:write', otra))
      assert.isFalse(await driver.authorize(alice, 'docs:write', unit))
    })

    test('uuid desconocido ⇒ 422 E_AUTHZ_UNKNOWN_ROLE; mal formado ⇒ 422 E_AUTHZ_INVALID_IDENTITY', async ({
      assert,
    }) => {
      const { driver } = await world()
      await rejects(assert, () => driver.purgeRole!(uuidv7()), { status: 422, code: 'E_AUTHZ_UNKNOWN_ROLE' })
      await rejects(assert, () => driver.purgeRole!('lead'), { status: 422, code: 'E_AUTHZ_INVALID_IDENTITY' })
    })
  })
}

/* ══ 3b-2e · E2 — capacidades declaradas y el literal aprobado ══════════════ */

/**
 * El cruce 6 del panel 2 aprobó **un literal exacto** para lo que el README
 * puede prometer del modo `facts`, y PROHIBIÓ el titular «sin SQL en el camino
 * caliente» a secas. Esto lo fija: la promesa es «un solo `Check` en
 * `authorize`», y las cinco lecturas de membresía siguen usando `resolveChain`.
 */
test.group('facts · 3b-2e · E2 — el README promete el literal del cruce 6 y nada más', () => {
  test('el literal aprobado está, con las cinco lecturas nombradas', async ({ assert }) => {
    const readme = await readFile(new URL('../README.md', import.meta.url), 'utf-8')
    assert.include(readme, 'In `facts` mode, `authorize` is a **single `Check`** against OpenFGA')
    assert.include(readme, 'it does not consult your tree (`resolveChain`)')
    assert.include(
      readme,
      '`hasRole`, `listRoles`, `listRoleScopes`, `listSubjects` and `listScopes` **do** use `resolveChain`'
    )
    assert.include(readme, '`grant` and `deny` use it too, to validate that the scope exists')
  })

  test('el titular PROHIBIDO no se vende: «no SQL in the hot path» solo aparece para desmentirlo', async ({
    assert,
  }) => {
    const readme = await readFile(new URL('../README.md', import.meta.url), 'utf-8')
    assert.include(readme, '"no SQL in the hot path" is not a claim this package makes')
    // Y no hay ninguna otra aparición del titular suelto.
    const claims = readme.match(/no SQL in the hot path/g) ?? []
    assert.lengthOf(claims, 1)
  })

  test('las capacidades declaradas del driver son las de la tabla del README', async ({ assert }) => {
    const facts = new OpenFgaAuthorizationDriver({
      apiUrl: 'http://127.0.0.1:9',
      storeId: '01ARZ3NDEKTSV4RRFFQ69G5FAV',
      holderTypes: HOLDERS,
      acceptScopeDriftRisk: true,
      logger: { warn: () => {} },
    })
    assert.deepEqual(facts.capabilities, {
      hierarchyFacts: true,
      singleCheckAuthorize: true,
      roleInheritanceNative: false,
      listObjectsInherited: false,
      purgeRole: true,
      countRoleAssignments: true,
      canonicalScopeReads: false,
      // 3b-3b: sabe ser el ORIGEN de una migración (`enumerateFacts`).
      enumerateFacts: true,
      // L-2: `false` y no puede ser otra cosa (una tupla no entra en una trx SQL).
      transactionalWrites: false,
    })
    // Ya no hay una segunda columna que comparar: desde 3b-2k · K2 el driver
    // `openfga` declara SIEMPRE esto (el modo `resolver`, que declaraba lo
    // contrario en cinco de las siete, se borró). La otra cara de cada
    // capacidad la da `database`, abajo.
    // Una vista por prototipo declara lo MISMO que su original (si no, el
    // gate del manager dependería de por dónde llegue el driver).
    assert.deepEqual(facts.withClock(() => new Date()).capabilities, facts.capabilities)
    assert.deepEqual(new DatabaseAuthorizationDriver({}).capabilities, {
      hierarchyFacts: false,
      singleCheckAuthorize: false,
      roleInheritanceNative: false,
      listObjectsInherited: false,
      purgeRole: true,
      countRoleAssignments: true,
      canonicalScopeReads: true,
      // 3b-3b: sus hechos SON `authz_*`, el esquema publicado del paquete, y
      // el destino los lee de ahí; no hay método de puerto que traer.
      enumerateFacts: false,
      // L-3: `true` por defecto (la escritura real en la transacción del
      // llamante); un despliegue con pool 1 declara `false` en las opciones.
      transactionalWrites: true,
    })
    assert.equal(new DatabaseAuthorizationDriver({ transactionalWrites: false }).capabilities.transactionalWrites, false)
    const database = new DatabaseAuthorizationDriver({})
    assert.deepEqual(database.withClock(() => new Date()).capabilities, database.capabilities)
  })
})

/* ══ 3b-2e · E5 — los LÍMITES declarados, cada uno con su caso ══════════════ */

/**
 * El cruce 9 del panel dejó tres cotas declaradas y una **sin medir**: la
 * profundidad. Los ~23 que citaba eran de un modelo MÁS SIMPLE; (c2) añade
 * saltos TTU (`binding`, la resta de `can_<P>`), así que había que medirla
 * aquí. Se mide contra el servidor real y el número vive en
 * `FACTS_MAX_RESOLVE_DEPTH`.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2e · E5 — los límites del modelo (c2), medidos', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    /**
     * Una cadena de `hops` saltos con el grant en la RAÍZ y el árbol en el
     * store. Con `siblings > 0` cuelga además ese número de HOJAS del
     * penúltimo nodo, o sea a la MISMA profundidad que `nodes[hops]`: sirven
     * para preguntar N veces por la misma cota en un solo `batchCheck`.
     */
    async function chainStore(hops: number, siblings = 0) {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-depth-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const driver = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
          roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
        },
        { projection: driver.catalogProjection() }
      )
      const root = orgScope()
      await tree.attach(root, APP_SCOPE)
      await driver.onScopeAttached!(root, APP_SCOPE)
      let parent: any = root
      const nodes: any[] = [root]
      for (let i = 0; i < hops; i++) {
        const node = unitScope()
        await tree.attach(node, parent)
        await driver.onScopeAttached!(node, parent)
        nodes.push(node)
        parent = node
      }
      const leaves: any[] = []
      for (let i = 0; i < siblings; i++) {
        const leaf = unitScope()
        await tree.attach(leaf, nodes[nodes.length - 2])
        await driver.onScopeAttached!(leaf, nodes[nodes.length - 2])
        leaves.push(leaf)
      }
      const alice = { type: 'users', uuid: uuidv7() }
      await driver.grant(alice, 'org-editor', root, { expiresAt: null })
      return { driver, nodes, alice, leaves }
    }

    /**
     * **3b-8 · E5 — la contención del `:8101` compartido no es el borde de
     * profundidad, y el caso ya no los confunde.** Medido (sonda del 3b-8,
     * con 24 bucles de `batchCheck` en paralelo como carga): el veredicto de
     * PROFUNDIDAD del servidor es un error CON NOMBRE y determinista —
     * `authorization_model_resolution_too_complex` · «resolution depth
     * exceeded» (1/300 a 23 saltos en frío, 100/100 a 24)— mientras que bajo
     * carga lo que llega es OTRO error, `deadline_exceeded` («context
     * deadline exceeded», 200/200 a cualquier profundidad con el servidor
     * saturado). El caso afirmaba «a 22 nada falla» sin mirar el PORQUÉ del
     * fallo, así que la carga de cualquier vecino del `:8101` lo ponía rojo.
     * Desde 3b-8 la evidencia sobre la cota es SOLO el veredicto del
     * servidor; la contención se reintenta ACOTADA (4 intentos con espera) y
     * si persiste el caso falla IGUAL, nombrando la saturación — jamás un
     * skip, y el 22 no se toca.
     */
    function depthVerdict(error: unknown): boolean {
      let current: any = error
      for (let depth = 0; current && depth < 6; depth++) {
        const raw = `${current.input_error ?? ''} ${current.apiErrorCode ?? ''} ${current.message ?? ''}`
        if (/resolution_too_complex|resolution depth exceeded/i.test(raw)) return true
        current = current.cause
      }
      return false
    }

    /** Reintenta SOLO la contención del servidor compartido; el veredicto de profundidad no se reintenta jamás. */
    async function despiteContention<T>(run: () => Promise<T>, attempts = 4): Promise<T> {
      for (let attempt = 1; ; attempt++) {
        try {
          return await run()
        } catch (error: any) {
          if (error?.status !== 503 || depthVerdict(error) || attempt >= attempts) throw error
          await new Promise((resolve) => setTimeout(resolve, 1_000 * attempt))
        }
      }
    }

    test('3b-8 · E5: el veredicto de PROFUNDIDAD se distingue de la CONTENCIÓN, con las formas medidas contra el servidor', ({ assert }) => {
      // Las dos formas LITERALES que respondió el :8101 (sonda del 3b-8):
      // el veredicto determinista de profundidad y el error de saturación.
      // El caso viejo las contaba IGUAL contra la cota, y por eso la carga
      // de cualquier vecino del servidor compartido lo ponía rojo.
      const profundidad = {
        status: 503,
        cause: { input_error: 'authorization_model_resolution_too_complex', message: 'resolution depth exceeded' },
      }
      const contencion = {
        status: 503,
        cause: { internal_error: 'deadline_exceeded', message: 'context deadline exceeded' },
      }
      assert.isTrue(depthVerdict(profundidad), 'el veredicto de profundidad SÍ es evidencia sobre la cota')
      assert.isFalse(
        depthVerdict(contencion),
        'la contención del servidor compartido NO es evidencia sobre la cota (3b-8 · E5): contarla dejaba el caso intermitente'
      )
      // Y la forma del Check único (el axios error con apiErrorCode) también.
      assert.isTrue(depthVerdict({ status: 503, cause: { apiErrorCode: 'authorization_model_resolution_too_complex', message: '' } }))
    })

    test(`la cadena de ${FACTS_MAX_RESOLVE_DEPTH} saltos SÍ decide: en el borde exacto la herencia resuelve`, async ({
      assert,
    }) => {
      const { driver, nodes, alice } = await chainStore(FACTS_MAX_RESOLVE_DEPTH)
      assert.lengthOf(nodes, FACTS_MAX_RESOLVE_DEPTH + 1)
      assert.isTrue(
        await despiteContention(() => driver.authorize(alice, 'docs:read', nodes[nodes.length - 1])),
        'en el borde exacto la herencia sigue resolviéndose'
      )
    }).timeout(120_000)

    test(`CASO NEGATIVO: a ${FACTS_MAX_RESOLVE_DEPTH + 2} saltos el servidor no puede resolver, y eso es 503 — jamás un \`false\` silencioso`, async ({
      assert,
    }) => {
      // +2 y no +1 a propósito: a `+1` (23 saltos) el borde es
      // PROBABILÍSTICO —medido: 24 de 25 veces resuelve— y un caso apoyado
      // ahí sería flaky en el artefacto publicado. A +2 falla siempre.
      const { driver, nodes, alice } = await chainStore(FACTS_MAX_RESOLVE_DEPTH + 2)
      // Fail-closed, pero RUIDOSO: un `false` aquí sería indistinguible de
      // «no tiene permiso» y mandaría a buscar un rol mal configurado. Es la
      // cara fea de la cota (un DoS al alcance de quien pueda anidar scopes),
      // y `database` no la tiene: el mismo árbol es legal en un driver y una
      // caída en el otro.
      await rejects(
        assert,
        () => driver.authorize(alice, 'docs:read', nodes[nodes.length - 1]),
        { status: 503, code: 'E_AUTHZ_BACKEND_UNAVAILABLE' }
      )
      // Y por debajo de la cota, la misma pregunta responde (la contención
      // del servidor compartido se reintenta; 3b-8 · E5).
      assert.isTrue(await despiteContention(() => driver.authorize(alice, 'docs:read', nodes[FACTS_MAX_RESOLVE_DEPTH])))
    }).timeout(120_000)

    /**
     * **Lote 3b-4 · C4 — «22 y no otro», clavado por ARRIBA.**
     *
     * El par de casos de arriba (positivo a 22, negativo a 22+2) sujeta un
     * INTERVALO, no un punto: con `FACTS_MAX_RESOLVE_DEPTH = 23` la suite
     * seguía verde 3 corridas de 3 (tester Fase 3b · M12b). El +2 está ahí
     * porque el borde a +1 es **probabilístico**, así que la forma de
     * clavarlo no es una tirada: son REPETICIONES.
     *
     * Medido contra el `:8101` con el `--resolve-node-limit` por defecto,
     * sobre 50 hojas a la misma profundidad:
     *
     *   profundidad 22 → 200 de 200 resuelven (0 errores, 4 lotes)
     *   profundidad 23 → entre 6 y 13 errores por lote de 50 (y 15/100 en
     *                    otra corrida; el tester midió 1/25)
     *   profundidad 24 → 100 de 100 fallan
     *
     * La propiedad, dicha con precisión, es **«la mayor profundidad que
     * resuelve DE FORMA FIABLE»**. Se comprueba con 10 lotes de 50 por lado
     * (500 resoluciones): en la cota las 500 tienen que resolver, y un salto
     * más tiene que fallar **al menos una vez**. Con la tasa de fallo más
     * baja jamás medida (4 %) la probabilidad de un verde falso es
     * 0,96^500 ≈ 1e-9; con la de esta máquina es indistinguible de cero.
     *
     * Y mata las dos direcciones: con la constante a 23 el lado (a) se pone
     * rojo (a 23 no resuelven las 500); con la constante a 20 o 21 el lado
     * (b) se pone rojo (a 21 o 22 no falla nunca).
     */
    test(`la cota es ${FACTS_MAX_RESOLVE_DEPTH} y NO ${FACTS_MAX_RESOLVE_DEPTH + 1}: un salto más deja de resolver de forma FIABLE (500 repeticiones por lado, no una tirada)`, async ({
      assert,
    }) => {
      const ROUNDS = 10
      const SIBLINGS = FGA_MAX_BATCH_CHECK // 50: un `batchCheck` por ronda

      // (a) EN la cota: las 500 resuelven. Ni una excepción, ni un `false`.
      // La CONTENCIÓN del `:8101` compartido no es evidencia sobre la cota
      // (3b-8 · E5): se reintenta acotada, y solo el veredicto de
      // profundidad del servidor cuenta como «no resolvió».
      const edge = await chainStore(FACTS_MAX_RESOLVE_DEPTH, SIBLINGS)
      let unresolved = 0
      for (let round = 0; round < ROUNDS; round++) {
        try {
          const answers = await despiteContention(() =>
            edge.driver.authorizeMany(edge.alice, 'docs:read', edge.leaves)
          )
          assert.deepEqual(
            answers,
            Array(SIBLINGS).fill(true),
            `a ${FACTS_MAX_RESOLVE_DEPTH} saltos la ronda ${round} tenía que resolver entera`
          )
        } catch (error: any) {
          // La contención que agota sus reintentos también FALLA el caso
          // (jamás un skip), pero con su causa a la vista, no como cota.
          if (!depthVerdict(error)) throw error
          unresolved += 1
        }
      }
      assert.equal(
        unresolved,
        0,
        `a ${FACTS_MAX_RESOLVE_DEPTH} saltos ${unresolved} de ${ROUNDS} lotes NO resolvieron: la cota ` +
          `publicada está por ENCIMA de la real (el borde de arriba es probabilístico, así que una ` +
          `corrida verde no la sostiene). FACTS_MAX_RESOLVE_DEPTH tiene que ser la mayor profundidad ` +
          `que resuelve SIEMPRE.`
      )

      // (b) DOS saltos más (MAX+2): el servidor NO resuelve NUNCA — es la cota
      //     DETERMINISTA. MAX+1 es el borde PROBABILÍSTICO (a 23 resuelve
      //     entre un 74 % y un 96 % de las veces), así que NO se asierta por
      //     corrida: una tirada en la que las 500 resuelvan es CONSISTENTE con
      //     «MAX es la mayor profundidad FIABLE» —23 es inestable, no la cota—
      //     y exigir que 23 falle al menos una vez era una aserción flaky en
      //     el artefacto publicado (la misma clase que 3G · Y1). Lo que SÍ es
      //     determinista, y guarda contra publicar una cota demasiado baja o
      //     un cambio de `--resolve-node-limit` del servidor: a MAX+2 el
      //     servidor no resuelve en NINGUNA ronda (resolver ahí es el fallo).
      const over = await chainStore(FACTS_MAX_RESOLVE_DEPTH + 2, SIBLINGS)
      let verdicts = 0
      let contended = 0
      for (let round = 0; round < ROUNDS; round++) {
        let resolved = false
        try {
          await despiteContention(() => over.driver.authorizeMany(over.alice, 'docs:read', over.leaves))
          resolved = true
        } catch (error: any) {
          assert.equal(error.status, 503, 'pasado el techo es 503, jamás un `false` silencioso')
          // Un 503 de CONTENCIÓN que agotó sus reintentos no dice nada de la
          // cota: no suma, y si fue toda la medida, el assert final lo canta.
          if (!depthVerdict(error)) {
            contended += 1
            continue
          }
          assert.equal(error.code, 'E_AUTHZ_BACKEND_UNAVAILABLE')
          verdicts += 1
        }
        assert.isFalse(
          resolved,
          `a ${FACTS_MAX_RESOLVE_DEPTH + 2} saltos el servidor RESOLVIÓ: la cota real subió ` +
            `(¿el servidor cambió de --resolve-node-limit?) y FACTS_MAX_RESOLVE_DEPTH se quedó por debajo.`
        )
      }
      assert.isAbove(
        verdicts,
        0,
        `a ${FACTS_MAX_RESOLVE_DEPTH + 2} saltos las ${ROUNDS} rondas se quedaron en CONTENCIÓN ` +
          `(${contended}/${ROUNDS}, deadline_exceeded): la medida no vale con el :8101 saturado, repite ` +
          `con el servidor tranquilo.`
      )
    }).timeout(300_000)

    test(`\`authorizeMany\` pasa del tope de ${FGA_MAX_BATCH_CHECK} checks por lote sin truncar ni desordenar`, async ({
      assert,
    }) => {
      const { driver, nodes, alice } = await chainStore(3)
      // 120 scopes: el SDK trocea a 50 por request. Lo que no puede pasar es
      // que la posición 51 traiga la respuesta de otra pregunta (L0.14) ni
      // que el lote se corte en silencio.
      const fuera = Array.from({ length: 60 }, () => orgScope())
      const scopes = [...Array.from({ length: 60 }, (_, i) => nodes[i % nodes.length]), ...fuera]
      assert.isAbove(scopes.length, FGA_MAX_BATCH_CHECK * 2)

      const many = await driver.authorizeMany(alice, 'docs:read', scopes)
      assert.lengthOf(many, scopes.length, 'una respuesta por posición, sin truncar')
      assert.deepEqual(many, [...Array(60).fill(true), ...Array(60).fill(false)])
    }).timeout(120_000)
  })
}

/* ══════════════════════════════════════════════════════════════════════════
 * **3b-2i · (c2r)** — «un scope cuya cadena no llega a la raíz `app` no
 * concede nada en `facts`, igual que en `database`».
 *
 * Es el cierre del 🔴 1 del auditor R2: `scopes.detached` de un nodo
 * INTERMEDIO funcionaba como un `removeDeny` masivo de todo su subárbol —el
 * deny seguía escrito, pero el camino por el que se heredaba se podía
 * romper—, y las tres barreras del `within` no lo veían porque la operación
 * era legal (el actor manda en SU division).
 *
 * En `facts` un doble en memoria no prueba nada: todo esto se mide contra el
 * servidor REAL, con los dos drivers respondiendo sobre el MISMO catálogo y
 * el MISMO árbol. Lo que se afirma es PARIDAD, no un valor concreto.
 * ══════════════════════════════════════════════════════════════════════════ */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2i — (c2r): sin cadena a la raíz no se concede', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    const CATALOG_2I = {
      permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
      roles: [
        { slug: 'app-editor', scopeType: 'app', permissions: ['docs:read'] },
        { slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read'] },
        { slug: 'unit-editor', scopeType: 'unit', permissions: ['docs:write'] },
      ],
    }

    /**
     * El árbol del auditor: `app ← orgA ← div ← unit`, más una `orgIntact`
     * colgada de `app` que sirve de control (lo que NO se toca sigue
     * concediendo). Los dos drivers, el mismo catálogo, el mismo árbol.
     */
    async function pair() {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-rooted-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const tree = memoryScopeTree()
      const fga: any = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      // El sync con proyección es lo que escribe el marcador de raíz: aquí no
      // hay ni una tupla a mano, todo el montaje es el camino del paquete.
      const sync = () => syncAuthzCatalog(CATALOG_2I as any, { projection: fga.catalogProjection() })
      await sync()
      const sql: any = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })
      const raw = new OpenFgaClient({
        apiUrl,
        storeId: store.id!,
        authorizationModelId: model.authorization_model_id,
      })

      const orgA = orgScope()
      const orgIntact = orgScope()
      const div = orgScope()
      const unit = unitScope()
      const attach = async (child: any, parent: any) => {
        await tree.attach(child, parent)
        await fga.onScopeAttached(child, parent)
      }
      await attach(orgA, APP_SCOPE)
      await attach(orgIntact, APP_SCOPE)
      await attach(div, orgA)
      await attach(unit, div)

      const manager = (name: string, driver: any) =>
        new AuthorizationManager({
          default: name,
          drivers: { [name]: () => driver },
          scopes: { resolveChain: resolveChainFrom(tree), acceptScopeDriftRisk: true },
          requireWithin: true,
          requireActor: true,
          warnOnOptInSecurity: false,
        } as any) as any

      /** La misma pregunta a los dos drivers: lo que se compara es la PAREJA. */
      const ask = async (subject: any, permission: string, scope: any) => ({
        facts: await fga.authorize(subject, permission, scope),
        database: await sql.authorize(subject, permission, scope),
      })
      /** El mismo hecho en los dos drivers (el catálogo y el árbol ya son comunes). */
      const both = async (run: (driver: any) => Promise<unknown>) => {
        await run(fga)
        await run(sql)
      }

      return {
        fga, sql, raw, tree, sync, ask, both, attach,
        orgA, orgIntact, div, unit,
        mf: manager('facts', fga),
        ms: manager('database', sql),
      }
    }

    const holder = () => ({ type: 'users', uuid: uuidv7() })

    /**
     * **I3 — la reproducción del auditor, de punta a punta.** Lo que cambia
     * NO es que `detached` se cierre (sigue siendo una operación legal sobre
     * SU division, y las otras dos barreras siguen respondiendo 422): lo que
     * cambia es que romper la cadena ya no concede.
     */
    test('I3 · `scopes.detached` de un nodo INTERMEDIO ya no borra los denies de su subárbol (el 🔴 1)', async ({
      assert,
    }) => {
      const h = await pair()
      const alice = holder()
      await h.both(async (d) => {
        await d.grant(alice, 'unit-editor', h.unit, { expiresAt: null })
        await d.deny(alice, 'docs:write', h.orgA)
      })

      assert.deepEqual(
        await h.ask(alice, 'docs:write', h.unit),
        { facts: false, database: false },
        'precondición: el deny de la org gana sobre el grant de la unit (invariante 2)'
      )

      // Las tres barreras del `within`, sin cambiar: el actor manda en la
      // DIVISION y no puede tocar la organization de arriba.
      const w = { within: h.div, actor: alice }
      await rejects(
        assert,
        () => h.mf.removeDeny(alice, 'docs:write', h.orgA, w),
        { status: 422, code: 'E_AUTHZ_NOT_WITHIN' },
        'removeDeny sobre la org'
      )
      await rejects(
        assert,
        () => h.mf.grant(alice, 'org-admin', h.orgA, w),
        { status: 422, code: 'E_AUTHZ_NOT_WITHIN' },
        'grant en la org'
      )
      // Y ésta SÍ se le permite, como antes: es su division.
      await h.mf.scopes.detached(h.div, w)
      await h.ms.scopes.detached(h.div, w)
      await h.tree.detach(h.div)

      assert.deepEqual(
        await h.ask(alice, 'docs:write', h.unit),
        { facts: false, database: false },
        'PARIDAD: la unit ya no alcanza `app`, así que no concede en NINGÚN driver'
      )

      // Y el deny sigue escrito: no se ha reparado borrando nada de la org.
      const left = await h.raw.read({ object: `scope:organization|${h.orgA.uuid}` })
      assert.include(
        (left.tuples ?? []).map((t: any) => `${t.key.user}#${t.key.relation}`),
        `users:${alice.uuid}#denied_docs_write`.replace('users:', 'user:'),
        'el deny de la organization sigue en el store: lo que se restauró es el CAMINO'
      )
    }).timeout(60_000)

    /**
     * **I4 (filas A y B de la paridad)** — lo que el arreglo podía romper:
     * el camino feliz y, sobre todo, el grant en la RAÍZ, que es el que muere
     * si el marcador no está.
     */
    test('I4 · A/B — grant local, heredado 2 saltos, en la RAÍZ, y nunca hacia arriba ni a hermanos', async ({
      assert,
    }) => {
      const h = await pair()
      const bob = holder()
      const carol = holder()
      const dave = holder()
      await h.both(async (d) => {
        await d.grant(bob, 'unit-editor', h.unit, { expiresAt: null })
        await d.grant(carol, 'org-admin', h.orgA, { expiresAt: null })
        await d.grant(dave, 'app-editor', APP_SCOPE, { expiresAt: null })
      })

      // A · grant local.
      assert.deepEqual(await h.ask(bob, 'docs:write', h.unit), { facts: true, database: true })
      assert.deepEqual(await h.ask(bob, 'docs:write', h.orgA), { facts: false, database: false })
      // A · heredado DOS saltos (orgA → div → unit) y nunca a un hermano.
      assert.deepEqual(await h.ask(carol, 'docs:read', h.orgA), { facts: true, database: true })
      assert.deepEqual(await h.ask(carol, 'docs:read', h.unit), { facts: true, database: true })
      assert.deepEqual(await h.ask(carol, 'docs:read', h.orgIntact), { facts: false, database: false })
      assert.deepEqual(await h.ask(carol, 'docs:read', APP_SCOPE), { facts: false, database: false })
      // B · el grant en la RAÍZ decide en `app` y baja hasta la unit. Si el
      // marcador de raíz faltara, esto sería `false` en `facts` y `true` en
      // `database`: es el caso que vigila el modo de fallo de (c2r).
      assert.deepEqual(await h.ask(dave, 'docs:read', APP_SCOPE), { facts: true, database: true })
      assert.deepEqual(await h.ask(dave, 'docs:read', h.unit), { facts: true, database: true })
    }).timeout(60_000)

    /**
     * **I4 (filas C y D)** — el subárbol desgajado deja de conceder ENTERO,
     * la parte intacta del árbol no se entera, y recolgarlo lo restaura.
     */
    test('I4 · C/D — detachar el intermedio apaga el subárbol (los tres sujetos), la org intacta sigue, y recolgar restaura', async ({
      assert,
    }) => {
      const h = await pair()
      const bob = holder()
      const carol = holder()
      const dave = holder()
      await h.both(async (d) => {
        await d.grant(bob, 'unit-editor', h.unit, { expiresAt: null })
        await d.grant(carol, 'org-admin', h.orgA, { expiresAt: null })
        await d.grant(dave, 'app-editor', APP_SCOPE, { expiresAt: null })
      })
      assert.deepEqual(await h.ask(dave, 'docs:read', h.unit), { facts: true, database: true })

      // C · el dueño de la division la borra.
      await h.fga.purgeScope(h.div)
      await h.fga.onScopeDetached(h.div)
      await h.sql.purgeScope(h.div)
      await h.tree.detach(h.div)

      assert.deepEqual(await h.ask(bob, 'docs:write', h.unit), { facts: false, database: false })
      assert.deepEqual(await h.ask(carol, 'docs:read', h.unit), { facts: false, database: false })
      assert.deepEqual(await h.ask(dave, 'docs:read', h.unit), { facts: false, database: false })
      // Control: lo que no se tocó sigue igual en los dos drivers.
      assert.deepEqual(await h.ask(carol, 'docs:read', h.orgA), { facts: true, database: true })
      assert.deepEqual(await h.ask(dave, 'docs:read', h.orgIntact), { facts: true, database: true })

      // D · reparación: el consumidor recuelga la unit de la organization.
      await h.tree.attach(h.unit, h.orgA)
      await h.fga.onScopeMoved(h.unit, h.orgA)
      assert.deepEqual(await h.ask(bob, 'docs:write', h.unit), { facts: true, database: true })
      assert.deepEqual(await h.ask(carol, 'docs:read', h.unit), { facts: true, database: true })
      assert.deepEqual(await h.ask(dave, 'docs:read', h.unit), { facts: true, database: true })
    }).timeout(60_000)

    /**
     * **I5 — el modo de fallo del marcador, declarado.** Sin
     * `scope:app#rooted` el store entero deniega. Es fail-CLOSED (no es una
     * fuga) pero es una caída total, así que tiene que estar escrita y tiene
     * que arreglarse sola con un `syncAuthzCatalog`.
     */
    test('I5 · sin el marcador de raíz el store DENIEGA todo (fail-closed, nunca un 503), y el sync lo repone', async ({
      assert,
    }) => {
      const h = await pair()
      const dave = holder()
      await h.fga.grant(dave, 'app-editor', APP_SCOPE, { expiresAt: null })
      assert.isTrue(await h.fga.authorize(dave, 'docs:read', h.unit), 'precondición')

      await h.raw.deleteTuples(factsRootTuples(HOLDERS))

      // Ni un throw ni un 503: `false` en toda la jerarquía, empezando por la raíz.
      assert.isFalse(await h.fga.authorize(dave, 'docs:read', APP_SCOPE), 'la raíz tampoco')
      assert.isFalse(await h.fga.authorize(dave, 'docs:read', h.orgA))
      assert.isFalse(await h.fga.authorize(dave, 'docs:read', h.unit))

      await h.sync()
      assert.isTrue(await h.fga.authorize(dave, 'docs:read', APP_SCOPE), 'el sync repone el marcador')
      assert.isTrue(await h.fga.authorize(dave, 'docs:read', h.unit))
    }).timeout(60_000)

    /**
     * **I7 — lo que (c2r) SÍ cierra del cruce 3, y lo que NO.** El ciclo
     * COLGADO del árbol (un nodo con dos padres, `app` y un descendiente
     * suyo) sigue siendo fail-open y lo fija su propio caso más arriba: la
     * mitigación sigue siendo el anti-ciclos del paquete. Lo que (c2r) cierra
     * es el ciclo HUÉRFANO, que antes concedía dentro de sí mismo.
     */
    test('I7 · un ciclo `parent` HUÉRFANO (que no cuelga de `app`) ya no concede dentro de sí mismo', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-orphan-cycle-${Date.now()}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const client = new OpenFgaClient({
        apiUrl,
        storeId: store.id,
        authorizationModelId: model.authorization_model_id,
      })
      const role = 'role:0192f000-0000-7000-8000-000000000001'
      const x = 'scope:organization|0192f000-0000-7000-8000-0000000000aa'
      const y = 'scope:unit|0192f000-0000-7000-8000-0000000000bb'
      const binding = 'role_binding:unit|0192f000-0000-7000-8000-0000000000bb|0192f000-0000-7000-8000-000000000001'
      await client.writeTuples([
        // El marcador está donde tiene que estar: en la raíz. El ciclo NO
        // cuelga de ella, y ésa es toda la diferencia.
        ...factsRootTuples(HOLDERS),
        { user: 'user:*', relation: 'permits_docs_read', object: role },
        { user: role, relation: 'role', object: binding },
        { user: 'user:u1', relation: 'assignee', object: binding },
        { user: binding, relation: 'binding', object: y },
        // X ↔ Y, y nada más: el ciclo está huérfano.
        { user: x, relation: 'parent', object: y },
        { user: y, relation: 'parent', object: x },
      ])

      const context = { current_time: new Date().toISOString() }
      const started = Date.now()
      const inside = await client.check({ user: 'user:u1', relation: 'can_docs_read', object: y, context })
      const up = await client.check({ user: 'user:u1', relation: 'can_docs_read', object: x, context })
      assert.isFalse(inside.allowed, 'ni en su propio scope: el ciclo no alcanza la raíz')
      assert.isFalse(up.allowed, 'ni hacia arriba dentro del ciclo (esto es lo que (c2r) cierra)')
      assert.isBelow(Date.now() - started, 5_000, 'y sigue respondiendo en milisegundos')
    }).timeout(60_000)
  })
}

/* ══ 3b-2k · K2 — `openfga:provision` publica el modelo `facts` ═════════════
 *
 * Hasta 2.2 el comando publicaba el modelo del modo `resolver`, que solo tenía
 * `role_binding` y `deny_binding` y ninguna relación por permiso. El modelo
 * (c2r) declara CUATRO por permiso, así que provisionar necesita la lista — y
 * un store provisionado sin ella no puede responder a nada, que es la razón
 * de que el comando se niegue en vez de crearlo.
 * ════════════════════════════════════════════════════════════════════════ */

test.group('facts · 3b-2k · K2 — de dónde salen los permisos del modelo', () => {
  test('permissionsOfCatalogs junta TODOS los catálogos, sin duplicados y en orden estable', async ({
    assert,
  }) => {
    const { permissionsOfCatalogs } = await import('../commands/openfga_provision.js')
    const config = {
      catalogs: [
        async () => ({ permissions: [{ slug: 'docs:write' }, { slug: 'docs:read' }], roles: [] }),
        // Un catálogo perezoso, y un permiso que ya declaraba el primero: el
        // modelo no puede llevar la relación dos veces.
        () => ({ permissions: [{ slug: 'billing:read' }, { slug: 'docs:read' }], roles: [] }),
      ],
    }
    assert.deepEqual(await permissionsOfCatalogs(config), ['billing:read', 'docs:read', 'docs:write'])
  })

  test('CASO NEGATIVO: sin `catalogs` (o con catálogos sin permisos) la lista es vacía, que es lo que hace al comando negarse', async ({
    assert,
  }) => {
    const { permissionsOfCatalogs } = await import('../commands/openfga_provision.js')
    assert.deepEqual(await permissionsOfCatalogs({}), [])
    assert.deepEqual(await permissionsOfCatalogs(undefined), [])
    assert.deepEqual(await permissionsOfCatalogs({ catalogs: [async () => ({ roles: [] })] }), [])
  })
})

if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-2k · K2 — el store provisionado responde `can_<P>`', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    test('provisionOpenFgaStore escribe el modelo (c2r) con los permisos que se le pasan: `can_<P>` existe y el `deny_binding` del modo viejo NO', async ({
      assert,
    }) => {
      const { provisionOpenFgaStore } = await import('../src/openfga.js')
      const { OpenFgaClient } = await import('@openfga/sdk')
      const { storeId, modelId } = await provisionOpenFgaStore(
        apiUrl,
        `provision-facts-${Date.now()}`,
        HOLDERS,
        ['docs:read']
      )
      stores.push(storeId)
      const client = new OpenFgaClient({ apiUrl, storeId, authorizationModelId: modelId })

      // La relación que `authorize` pregunta EXISTE: el servidor responde
      // (false, porque no hay tuplas) en vez de rechazar la relación.
      const answered = await client.check({
        user: 'user:u1',
        relation: 'can_docs_read',
        object: 'scope:organization|0192f000-0000-7000-8000-0000000000b1',
        context: { current_time: new Date().toISOString() },
      })
      assert.isFalse(answered.allowed)

      // Y el tipo del modo viejo no está: preguntar por él es un error del
      // servidor, no un `false`. Es la prueba de que se publicó (c2r) y no el
      // modelo que `openFgaAuthorizationModel` escribía hasta 3b-2k.
      let caught: any = null
      try {
        await client.check({
          user: 'user:u1',
          relation: 'denied',
          object: 'deny_binding:app|0192f000-0000-7000-8000-0000000000b2',
        })
      } catch (error) {
        caught = error
      }
      assert.isNotNull(caught, 'el modelo (c2r) no declara `deny_binding`')
    }).timeout(60_000)
  })
}

/* ════════════════════════════════════════════════════════════════════════
 * 3b-8 — las correcciones del /code-review de fin de fase (Grupo A + C2)
 *
 * Cada caso reproduce el ESCENARIO DE FALLO del hallazgo, contra el servidor
 * real y —donde aplica— comparando con el driver `database` en paralelo
 * (paridad, invariante 18 dixit): un doble en memoria no prueba nada en
 * modo `facts`.
 * ════════════════════════════════════════════════════════════════════════ */

if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 3b-8 — code-review de fin de fase (A1/A4/A5/C2)', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    /** Un store real limpio con el modelo (c2r) y su driver sobre `tree`. */
    async function freshStore(tree: any) {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `facts-3b8-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS)
      )
      const fga = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      return fga
    }

    /**
     * **A1 — `authz:catalog:sync` reescribe la proyección derivada.** El
     * README (§ OpenFGA) promete que tras cambiar el catálogo «authz:catalog:sync
     * rewrites the derived projection»: es el camino de RECUPERACIÓN
     * documentado. Hasta 3b-8 el comando llamaba a `syncCatalogs` sin la
     * proyección del driver activo, así que en `facts` un permiso quitado
     * del catálogo SEGUÍA concediendo y un rol nuevo no concedía nada.
     * Aquí se ejercita el MISMO camino del comando (`catalogSyncOptions`
     * sobre el driver activo + `syncCatalogs`).
     */
    test('A1: el camino del CLI (`catalogSyncOptions` + `syncCatalogs`) proyecta el catálogo en `facts` — un rol nuevo concede y un permiso quitado deja de conceder', async ({
      assert,
    }) => {
      const tree = memoryScopeTree()
      const fga = await freshStore(tree)
      await cleanAuthzTables()
      const org = { type: 'organization', uuid: uuidv7() }
      await tree.attach(org, APP_SCOPE)
      await fga.onScopeAttached!(org, APP_SCOPE)

      // La decisión PURA: con un driver que declara proyección, el sync la
      // lleva; con uno que no (`database`), va sin ella; --keep-links manda.
      const sinEspejo = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })
      assert.isDefined(
        catalogSyncOptions(fga, undefined).projection,
        'el sync del CLI tiene que llevar la proyección del driver activo (3b-8 · A1)'
      )
      assert.isUndefined(catalogSyncOptions(sinEspejo, undefined).projection)
      assert.equal(catalogSyncOptions(fga, true).prune, 'none')
      assert.equal(catalogSyncOptions(fga, undefined).prune, 'links')

      // Y el camino ENTERO del comando, contra el servidor: sync v1.
      const v1 = {
        permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
        roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read', 'docs:write'] }],
      }
      await syncCatalogs([async () => v1], catalogSyncOptions(fga, undefined))
      const alice = { type: 'users', uuid: uuidv7() }
      await fga.grant(alice, 'org-editor', org, { expiresAt: null })
      assert.isTrue(
        await fga.authorize(alice, 'docs:write', org),
        'un rol recién sincronizado por el CLI tiene que CONCEDER en facts (sin proyección no concede nada)'
      )

      // v2 quita docs:write del rol: el camino de recuperación documentado.
      const v2 = {
        permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
        roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
      }
      await syncCatalogs([async () => v2], catalogSyncOptions(fga, undefined))
      assert.isFalse(
        await fga.authorize(alice, 'docs:write', org),
        'un permiso QUITADO del catálogo y re-sincronizado por el CLI no puede seguir concediendo (fail-open del hallazgo A1)'
      )
      assert.isTrue(await fga.authorize(alice, 'docs:read', org), 'y el que sigue en el catálogo, concede')
    }).timeout(60_000)

    /**
     * **A4 — `revoke`/`removeDeny` sobre un scope que el árbol YA NO conoce
     * cubren las ortografías de las que el uuid puede ser alias.** Es el
     * mismo bug que 3b-2h cerró en `scopes.detached` (invariante 17), un
     * call-site más allá: sin cadena con la que canonizar, la ortografía del
     * llamante a secas + `onMissingDeletes: Ignore` hacía del delete un no-op
     * SILENCIOSO. Paridad con `database`, que compartía el patrón
     * (`canonicalOrSelf` + WHERE por una sola ortografía).
     */
    test('A4: revocar (y quitar un deny) por el ALIAS sin guiones —y por el 8-4-4-16, cierre-2 · 🟠 R1— de un scope ya borrado del árbol borra los hechos canónicos — en los DOS drivers', async ({
      assert,
    }) => {
      const tree = memoryScopeTree()
      const fga = await freshStore(tree)
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }],
          roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
        },
        { projection: fga.catalogProjection() }
      )
      const sql = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })
      // 🟠 R1 (cierre-2 del lote A): `canonicalScopeTargets` reusa `scopeSpellings`,
      // que solo expandía el alias SIN guiones; con `8-4-4-16` (que PG funde igual,
      // A2) el delete seguía siendo un no-op SILENCIOSO y el hecho canónico volvía a
      // conceder al restaurar el scope. La regla es ahora la de las particiones.
      const forms: Array<[string, (uuid: string) => string]> = [
        ['sin guiones (3b-8 · A4)', (u) => u.replace(/-/g, '')],
        ['8-4-4-16 (cierre-2 · 🟠 R1)', (u) => u.slice(0, 23) + u.slice(24)],
      ]
      for (const [label, form] of forms) {
        const org = { type: 'organization', uuid: uuidv7() } // uuid CANÓNICO, con guiones
        const alias = { type: 'organization', uuid: form(org.uuid) }
        await tree.attach(org, APP_SCOPE)
        await fga.onScopeAttached!(org, APP_SCOPE)

        const alice = { type: 'users', uuid: uuidv7() }
        const bea = { type: 'users', uuid: uuidv7() }
        for (const driver of [sql, fga] as const) {
          await driver.grant(alice, 'org-editor', org, { expiresAt: null })
          await driver.deny(bea, 'docs:read', org)
        }

        // La fila del consumidor se borra ANTES de avisar (el orden soportado
        // de 3F · S1): ya no hay cadena con la que canonizar.
        await tree.detach(org)
        for (const driver of [sql, fga] as const) {
          await driver.revoke(alice, 'org-editor', alias)
          await driver.removeDeny(bea, 'docs:read', alias)
        }

        // El scope se restaura con el MISMO uuid (AA4: los hechos despiertan
        // con el scope): lo revocado tiene que SEGUIR revocado.
        await tree.attach(org, APP_SCOPE)
        await fga.onScopeAttached!(org, APP_SCOPE)
        assert.isFalse(
          await sql.authorize(alice, 'docs:read', org),
          `${label} · database: el revoke por alias tiene que haber borrado la fila canónica (si concede, fue un no-op silencioso)`
        )
        assert.isFalse(
          await fga.authorize(alice, 'docs:read', org),
          `${label} · facts: el revoke por alias tiene que haber borrado el assignee canónico (si concede, fue un no-op silencioso — 3b-8 · A4)`
        )
        assert.deepEqual(
          await sql.listDenies(bea, org),
          [],
          `${label} · database: el removeDeny por alias tiene que haber borrado el deny canónico`
        )
        assert.deepEqual(
          await fga.listDenies(bea, org),
          [],
          `${label} · facts: el removeDeny por alias tiene que haber borrado el deny canónico`
        )
      }
    }).timeout(60_000)

    /**
     * **🟡 C2-2 / C2-3 del re-ataque al cierre-2 (cierre-3 del lote A, decisión
     * del dueño 2026-10-15 (3)) — contra los DOS drivers reales.** Consumidor
     * con ids de scope de TEXTO (el árbol en memoria compara byte a byte, como
     * una columna `varchar`): un tenant crea y borra `unit:<32 hex de la
     * víctima>` (o `8-4-4-16`), y sin cadena el fan-out de `revoke`/`removeDeny`
     * (`canonicalScopeTargets`) y el de `scopes.detached` arrastraban a la
     * canónica — la unit VIVA de otro tenant—: en `database`, `purgeScope`
     * borraba su deny con la herencia del org intacta (fail-open cross-tenant);
     * en `facts`, además su arista `parent` (DoS). Ahora una ortografía que el
     * resolutor conoce VIVA se descarta. Se observa por `authorize`: el deny de
     * alice sigue (hereda del org y NO concede), el grant de bea sigue (concede:
     * en `facts` eso prueba también que la arista `parent` sigue, porque
     * `can_<P>` exige `rooted`). Mutante (sin contraste con el resolutor) ⇒
     * rojo en las dos formas que PG funde, en los dos drivers.
     */
    test('cierre-3 · C2-2/C2-3: revoke/removeDeny/detached por un alias SIN cadena cuya canónica es un scope VIVO de otro tenant no tocan a la víctima — conserva deny, hechos y arista parent — en los DOS drivers', async ({
      assert,
    }) => {
      const tree = memoryScopeTree()
      const fga = await freshStore(tree)
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }],
          roles: [
            { slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] },
            { slug: 'unit-editor', scopeType: 'unit', permissions: ['docs:read'] },
          ],
        },
        { projection: fga.catalogProjection() }
      )
      const sql = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })
      const managerOver = (driver: any) =>
        new AuthorizationManager({
          default: 'd',
          drivers: { d: () => driver },
          scopes: { resolveChain: resolveChainFrom(tree), acceptScopeDriftRisk: true },
          warnOnOptInSecurity: false,
        } as any)
      const forms: Array<[string, (uuid: string) => string]> = [
        ['32 hex sin guiones (clase preexistente, 3b-2h)', (u) => u.replace(/-/g, '')],
        ['8-4-4-16 (cierre-2)', (u) => u.slice(0, 23) + u.slice(24)],
      ]
      for (const [label, form] of forms) {
        const org = { type: 'organization', uuid: uuidv7() }
        const victim = { type: 'unit', uuid: uuidv7() } // VIVA, de otro tenant
        await tree.attach(org, APP_SCOPE)
        await fga.onScopeAttached!(org, APP_SCOPE)
        await tree.attach(victim, org)
        await fga.onScopeAttached!(victim, org)
        const alice = { type: 'users', uuid: uuidv7() } // hereda del org, denegada en la víctima
        const bea = { type: 'users', uuid: uuidv7() } // hecho directo en la víctima
        for (const driver of [sql, fga] as const) {
          await driver.grant(alice, 'org-editor', org, { expiresAt: null })
          await driver.deny(alice, 'docs:read', victim)
          await driver.grant(bea, 'unit-editor', victim, { expiresAt: null })
          assert.isFalse(await driver.authorize(alice, 'docs:read', victim), `${label}: de partida, el deny bloquea`)
          assert.isTrue(await driver.authorize(bea, 'docs:read', victim), `${label}: de partida, el hecho concede`)
        }

        // El atacante: su `unit:<alias>` no existe (la creó y la borró, o nunca
        // la tuvo); sin cadena, la canónica del alias ES la víctima.
        const alias = { type: 'unit', uuid: form(victim.uuid) }
        assert.isNull(await resolveChainFrom(tree)(alias), `${label}: el alias no resuelve`)
        for (const driver of [sql, fga] as const) {
          await driver.revoke(bea, 'unit-editor', alias)
          await driver.removeDeny(alice, 'docs:read', alias)
          await managerOver(driver).scopes.detached(alias)
        }

        assert.isFalse(
          await sql.authorize(alice, 'docs:read', victim),
          `${label} · database: ROJO (C2-2) si purgeScope/removeDeny por el alias se llevó el deny de la víctima VIVA (fail-open cross-tenant)`
        )
        assert.isFalse(
          await fga.authorize(alice, 'docs:read', victim),
          `${label} · facts: ROJO (C2-3) si removeDeny por el alias se llevó el deny de la víctima VIVA`
        )
        assert.isTrue(
          await sql.authorize(bea, 'docs:read', victim),
          `${label} · database: ROJO (C2-3) si revoke/purgeScope por el alias se llevó el hecho de la víctima VIVA`
        )
        assert.isTrue(
          await fga.authorize(bea, 'docs:read', victim),
          `${label} · facts: ROJO (C2-2) si se fue el assignee o la arista parent de la víctima VIVA (DoS)`
        )
        assert.deepEqual((await sql.listDenies(alice, victim)).map((d) => d.permission), ['docs:read'], `${label} · database: el deny sigue escrito`)
        assert.deepEqual((await fga.listDenies(alice, victim)).map((d) => d.permission), ['docs:read'], `${label} · facts: el deny sigue escrito`)
      }
    }).timeout(60_000)

    /**
     * **A5 — el anti-ciclos mira también el árbol DEL STORE.** El del
     * consumidor no basta: una outbox aplicada en desorden (un `moved`
     * aparcado + el move inverso posterior) deja el store con una arista que
     * el árbol del consumidor ya no tiene, y la arista nueva —legal para el
     * consumidor— cierra un ciclo REAL en el store. FGA lo evalúa sin
     * quejarse y la herencia se vuelve bidireccional (cruce 3): fail-open
     * mudo. `storeChain` del barrido solo lanzaba DESPUÉS de escribir y no
     * deshacía nada.
     */
    test('A5: una arista legal para el consumidor que cerraría un ciclo EN EL STORE es 422 E_AUTHZ_SCOPE_CYCLE y no se escribe', async ({
      assert,
    }) => {
      const tree = memoryScopeTree()
      const fga = await freshStore(tree)
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }],
          roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
        },
        { projection: fga.catalogProjection() }
      )
      // El árbol del CONSUMIDOR de hoy: org bajo app, unit bajo org.
      const org = { type: 'organization', uuid: uuidv7() }
      const unit = { type: 'unit', uuid: uuidv7() }
      await tree.attach(org, APP_SCOPE)
      await tree.attach(unit, org)

      // El árbol del STORE, desactualizado por una outbox en desorden: un
      // `moved` viejo dejó a la ORG colgando de la UNIT.
      await (fga as any).client.write({
        writes: [
          { user: 'scope:app', relation: 'parent', object: `scope:unit|${unit.uuid}` },
          { user: `scope:unit|${unit.uuid}`, relation: 'parent', object: `scope:organization|${org.uuid}` },
        ],
        deletes: [],
      })

      // El relevo del cambio nuevo: `unit → org`. Para el consumidor es
      // legal (org no desciende de unit EN SU árbol); para el store cierra
      // `unit → org → unit`.
      await rejects(
        assert,
        () => fga.onScopeMoved!(unit, org),
        { status: 422, code: 'E_AUTHZ_SCOPE_CYCLE' },
        'la arista que cierra un ciclo en el STORE (3b-8 · A5)'
      )

      // Y NO se escribió: la unit sigue sin esa arista (su padre es app, del
      // write de arriba) y la herencia no es bidireccional.
      const left = await (fga as any).client.read(
        { object: `scope:unit|${unit.uuid}`, relation: 'parent' },
        {}
      )
      const padres = (left.tuples ?? []).map((t: any) => t.key.user)
      assert.deepEqual(padres, ['scope:app'], 'el ciclo no aterrizó en el store')
    }).timeout(60_000)

    /**
     * **C2 — `purgeScope` purga también la arista `scope#binding` de un rol
     * que `authz_roles` ya no declara en ese nivel.** El barrido de
     * `detached` no es atómico con el catálogo: un rol cuya fila se borró (o
     * cambió de `scope_type`) entre el commit y la purga dejaba una arista
     * que el paso 1 no borra (solo mira los roles del nivel) y que la
     * demostración de cero SÍ cuenta ⇒ `E_AUTHZ_PURGE_INCOMPLETE` para
     * siempre ⇒ `detached` bloqueado.
     */
    test('C2: una arista `scope#binding` de un rol que el catálogo ya no declara no bloquea la purga para siempre', async ({
      assert,
    }) => {
      const tree = memoryScopeTree()
      const fga = await freshStore(tree)
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }],
          roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
        },
        { projection: fga.catalogProjection() }
      )
      const org = { type: 'organization', uuid: uuidv7() }
      await tree.attach(org, APP_SCOPE)
      await fga.onScopeAttached!(org, APP_SCOPE)
      const alice = { type: 'users', uuid: uuidv7() }
      await fga.grant(alice, 'org-editor', org, { expiresAt: null })
      await fga.deny(alice, 'docs:read', org)

      // La arista huérfana: un rol cuya fila ya no está en `authz_roles`
      // (purgado, o con el `scope_type` cambiado entre el commit y el
      // barrido). El paso 1 de la purga no la ve; el residuo sí.
      const fantasma = uuidv7()
      const key = `organization|${org.uuid}`
      await (fga as any).client.write({
        writes: [
          { user: `role_binding:${key}|${fantasma}`, relation: 'binding', object: `scope:${key}` },
        ],
        deletes: [],
      })

      // Hasta 3b-8 esto era E_AUTHZ_PURGE_INCOMPLETE en TODOS los intentos:
      // no había camino que borrara esa arista, y `detached` quedaba
      // bloqueado para siempre (solo reconcile lo desatascaba).
      await fga.purgeScope(org)

      const restante = await (fga as any).client.read({ object: `scope:${key}` }, {})
      assert.deepEqual(
        (restante.tuples ?? [])
          .map((t: any) => `${t.key.user}#${t.key.relation}`)
          .filter((s: string) => !s.endsWith('#parent')), // la arista `parent` la borra `detached`, no la purga (S6)
        [],
        'la purga demuestra cero de verdad: ni denies, ni aristas de binding — tampoco las de roles retirados'
      )
      // Y es idempotente: repetirla no lanza.
      await fga.purgeScope(org)
    }).timeout(60_000)
  })
}

/* ══════════════════════════════════════════════════════════════════════════
 * **Fase 4-1 · el modelo FUSIONADO (facts + relations)**
 *
 * `openFgaFactsModel` emite ADEMÁS los `type_definitions` de `group` y de los
 * tipos de objeto de una config de relaciones ReBAC, en el MISMO modelo y el
 * MISMO store que `facts`. El lote es ADITIVO: sin config el modelo es el de
 * hoy byte a byte, `authorize` de `roles/` no se toca y 0 tuplas de relaciones
 * se escriben. Aquí solo se juzga el GENERADOR y su gate de bytes (unitario,
 * como A1/A3); `check`/`relate`/el puerto y el driver son 4-2/4-3/4-4.
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * `[user, admin, integration, group#member, … with not_expired]` — los holders
 * y el userset del grupo, sin condición y CON la condición de caducidad
 * (R-15, 2.4.0-alpha.2: la tupla de relación caduca como `assignee`).
 */
const HOLDERS_OR_GROUP = [
  { type: 'user' },
  { type: 'admin' },
  { type: 'integration' },
  { type: 'group', relation: 'member' },
  { type: 'user', condition: 'not_expired' },
  { type: 'admin', condition: 'not_expired' },
  { type: 'integration', condition: 'not_expired' },
  { type: 'group', relation: 'member', condition: 'not_expired' },
]

/** La config de relaciones del literal de la §1 del plan: `group` + un `document`. */
const RELATIONS = {
  objectTypes: [
    {
      type: 'document',
      relations: [
        { name: 'owner' },
        { name: 'editor', includes: ['owner'] }, // includes sin `from` (v1)
        { name: 'viewer', includes: ['editor'] },
      ],
    },
  ],
}

/** El `type_definition` de `group` (usersets), medido contra el `:8101`. */
const GROUP_DEF = {
  type: 'group',
  relations: { member: { this: {} } },
  metadata: { relations: { member: { directly_related_user_types: HOLDERS_OR_GROUP } } },
}

/** El `type_definition` de `document` (owner ⊆ editor ⊆ viewer, con usersets). */
const DOCUMENT_DEF = {
  type: 'document',
  relations: {
    owner: { this: {} },
    editor: { union: { child: [{ this: {} }, computed('owner')] } },
    viewer: { union: { child: [{ this: {} }, computed('editor')] } },
  },
  metadata: {
    relations: {
      owner: { directly_related_user_types: HOLDERS_OR_GROUP },
      editor: { directly_related_user_types: HOLDERS_OR_GROUP },
      viewer: { directly_related_user_types: HOLDERS_OR_GROUP },
    },
  },
}

/** El modelo FUSIONADO = el de `facts` de hoy + `group` + `document`, EN ESE ORDEN. */
const EXPECTED_FUSED = {
  ...EXPECTED,
  type_definitions: [...EXPECTED.type_definitions, GROUP_DEF, DOCUMENT_DEF],
}

test.group('facts · 4-1 — el generador FUSIONA relaciones (group + tipos de objeto)', () => {
  test('openFgaFactsModel(H, P, RELATIONS) es el literal FUSIONADO de la §1: `facts` + `group` + `document`', ({
    assert,
  }) => {
    assert.deepEqual(openFgaFactsModel(HOLDERS, PERMISSIONS, RELATIONS), EXPECTED_FUSED)
  })

  test('ADITIVIDAD: sin config de relaciones (u omitida) el modelo es EXACTAMENTE el de hoy, byte a byte', ({
    assert,
  }) => {
    // El lote no puede mover el modelo `facts`: las 5 suites de la Fase 3b lo
    // comparan contra este literal.
    assert.deepEqual(openFgaFactsModel(HOLDERS, PERMISSIONS), EXPECTED)
    assert.deepEqual(openFgaFactsModel(HOLDERS, PERMISSIONS, undefined), EXPECTED)
    // Y añadir relaciones NO reescribe los tipos de `facts`, solo APENDE.
    const fused = openFgaFactsModel(HOLDERS, PERMISSIONS, RELATIONS)
    assert.deepEqual(fused.type_definitions.slice(0, EXPECTED.type_definitions.length), EXPECTED.type_definitions)
    assert.deepEqual(fused.conditions, EXPECTED.conditions)
  })

  test('varios tipos de objeto que COMPARTEN un nombre de relación (`document#viewer` y `folder#viewer`) son legales', ({
    assert,
  }) => {
    // Dos tipos distintos con `viewer` son la misma relación LÓGICA en tipos
    // distintos de FGA: no colisionan (solo colisionan con `facts`, ⚪4/F-04).
    const model = openFgaFactsModel(HOLDERS, PERMISSIONS, {
      objectTypes: [
        { type: 'document', relations: [{ name: 'viewer' }] },
        { type: 'folder', relations: [{ name: 'viewer' }] },
      ],
    })
    const types = model.type_definitions.map((t: any) => t.type)
    assert.deepEqual(types.slice(-3), ['group', 'document', 'folder'])
  })
})

/**
 * **Lote D · D-29 y el literal del DENY** (plan 2.5 · D1). Un tipo SIN `deny` genera el modelo de 2.4.0-alpha.10
 * byte a byte — también cuando la config pasa por `defineRelationsConfig` (la copia congelada no añade claves) —, y
 * un tipo con `deny` ('read' o 'write': las dos fases publican el MISMO modelo) genera `X = base but not denied_X` y
 * `denied_X = this ∨ denied_P` por cada `P` que incluye a `X` (cierre ASCENDENTE: corte de camino, D5).
 */
const DENY_DEF = {
  type: 'document',
  relations: {
    owner: { difference: { base: { this: {} }, subtract: computed('denied_owner') } },
    denied_owner: { union: { child: [{ this: {} }, computed('denied_editor')] } },
    editor: { difference: { base: { union: { child: [{ this: {} }, computed('owner')] } }, subtract: computed('denied_editor') } },
    denied_editor: { union: { child: [{ this: {} }, computed('denied_viewer')] } },
    viewer: { difference: { base: { union: { child: [{ this: {} }, computed('editor')] } }, subtract: computed('denied_viewer') } },
    denied_viewer: { this: {} },
  },
  metadata: {
    relations: {
      owner: { directly_related_user_types: HOLDERS_OR_GROUP },
      denied_owner: { directly_related_user_types: HOLDERS_OR_GROUP },
      editor: { directly_related_user_types: HOLDERS_OR_GROUP },
      denied_editor: { directly_related_user_types: HOLDERS_OR_GROUP },
      viewer: { directly_related_user_types: HOLDERS_OR_GROUP },
      denied_viewer: { directly_related_user_types: HOLDERS_OR_GROUP },
    },
  },
}

test.group('lote D · D-29 / DENY_DEF — el opt-in del deny en el generador', () => {
  test('D-29 · un tipo SIN deny pasado por defineRelationsConfig genera EXACTAMENTE EXPECTED_FUSED (la copia congelada no añade claves)', ({ assert }) => {
    const config = defineRelationsConfig({ objectTypes: RELATIONS.objectTypes, holderTypes: Object.keys(HOLDERS) })
    assert.deepEqual(openFgaFactsModel(HOLDERS, PERMISSIONS, { objectTypes: config.objectTypes }), EXPECTED_FUSED)
    assert.deepEqual(Object.keys(config.objectTypes[0]), ['type', 'relations'], 'sin `deny` la copia congelada lleva SOLO las dos claves de alpha.10')
  })

  test("DENY_DEF · un tipo con deny (en 'read' Y en 'write': las dos fases publican el MISMO modelo) genera el literal del corte de camino; group y facts no cambian", ({ assert }) => {
    for (const deny of ['read', 'write'] as const) {
      const config = defineRelationsConfig({ objectTypes: [{ ...RELATIONS.objectTypes[0], deny }], holderTypes: Object.keys(HOLDERS) })
      const model = openFgaFactsModel(HOLDERS, PERMISSIONS, { objectTypes: config.objectTypes })
      assert.deepEqual(model, { ...EXPECTED, type_definitions: [...EXPECTED.type_definitions, GROUP_DEF, DENY_DEF] }, deny)
    }
  })

  test("D-18 · una relación de 44 caracteres en un tipo con deny ⇒ 422 (denied_<rel> no cabe en los 50 de FGA) en defineRelationsConfig Y en el generador; 43 entra; en un tipo SIN deny una de 50 sigue valiendo", ({ assert }) => {
    const r43 = 'r'.repeat(43)
    const r44 = 'r'.repeat(44)
    const r50 = 'r'.repeat(50)
    assert.doesNotThrow(() => defineRelationsConfig({ objectTypes: [{ type: 'document', deny: 'write', relations: [{ name: r43 }] }] }))
    const caught = (() => {
      try {
        defineRelationsConfig({ objectTypes: [{ type: 'document', deny: 'write', relations: [{ name: r44 }] }] })
        return null
      } catch (e) {
        return e as any
      }
    })()
    assert.equal(caught?.status, 422)
    assert.include(String(caught?.message), '43')
    assert.doesNotThrow(() => defineRelationsConfig({ objectTypes: [{ type: 'document', relations: [{ name: r50 }] }] }))
    assert.throws(() => openFgaFactsModel(HOLDERS, PERMISSIONS, { objectTypes: [{ type: 'document', deny: 'read', relations: [{ name: r44 }] }] }), /denied_/)
  })
})

/**
 * **El gate de bytes FUSIONADO — el hueco que cerró el auditor.** Hoy
 * `factsModelBytes`/`assertFactsModelPublishable` medían SOLO el modelo
 * `facts`, así que un `defineRelationsConfig` podía empujar el modelo por
 * encima del techo de 262.144 B en silencio y dejar el store sin poder
 * regenerarse. El gate ahora mide el modelo FUSIONADO. Caso unitario de DOS
 * caras (rebasa ⇒ 500; justo por debajo ⇒ publica; al 80 % ⇒ avisa),
 * self-calibrado para no clavar cifras frágiles que un cambio de modelo
 * volvería mentira.
 */
test.group('facts · 4-1 — el gate de bytes mide el modelo FUSIONADO (dos caras)', () => {
  const realistic = (n: number) => Array.from({ length: n }, (_, i) => `recurso${i}:leer`)
  const docTypes = (n: number) => ({
    objectTypes: Array.from({ length: n }, (_, k) => ({
      type: `document${k}`,
      relations: [
        { name: 'owner' },
        { name: 'editor', includes: ['owner'] },
        { name: 'viewer', includes: ['editor'] },
      ],
    })),
  })

  test('los tipos de relaciones CUENTAN para el techo: un catálogo bajo techo en `facts` rebasa al FUSIONAR relaciones', ({
    assert,
  }) => {
    // Base de permisos que en `facts`-solo cabe (bajo el techo): sin relaciones
    // NO lanza. Es la prueba del hueco del auditor: lo que rebasa es la FUSIÓN.
    const base = realistic(460)
    const factsOnly = factsModelBytes(openFgaFactsModel(HOLDERS, base))
    assert.isBelow(factsOnly, FACTS_MODEL_MAX_BYTES, 'la base tiene que caber en `facts`-solo')
    assert.doesNotThrow(() => assertFactsModelPublishable(HOLDERS, base))

    // Se buscan los tipos que hacen rebasar (self-calibrado, sin cifra mágica).
    let over = 0
    while (factsModelBytes(openFgaFactsModel(HOLDERS, base, docTypes(over))) <= FACTS_MODEL_MAX_BYTES) {
      over += 1
      assert.isBelow(over, 200, 'la base no rebasa ni con 200 tipos: recalibra')
    }

    // (a) REBASA ⇒ 500 E_AUTHZ_MODEL_TOO_LARGE nombrando los bytes REALES y el techo.
    const fusedBytes = factsModelBytes(openFgaFactsModel(HOLDERS, base, docTypes(over)))
    let caught: any
    try {
      assertFactsModelPublishable(HOLDERS, base, undefined, docTypes(over))
      assert.fail('el gate del modelo fusionado tenía que rebasar el techo')
    } catch (error) {
      caught = error
    }
    assert.equal(caught.status, 500)
    assert.equal(caught.code, 'E_AUTHZ_MODEL_TOO_LARGE')
    assert.include(caught.message, String(fusedBytes))
    assert.include(caught.message, String(FACTS_MODEL_MAX_BYTES))

    // (b) JUSTO POR DEBAJO ⇒ publica (devuelve los bytes fusionados, no lanza).
    const belowConfig = docTypes(over - 1)
    const belowModel = openFgaFactsModel(HOLDERS, base, belowConfig)
    const belowBytes = factsModelBytes(belowModel)
    assert.isAtMost(belowBytes, FACTS_MODEL_MAX_BYTES)
    const report = assertFactsModelPublishable(HOLDERS, base, undefined, belowConfig)
    assert.equal(report.bytes, belowBytes, 'el gate reporta los bytes del modelo FUSIONADO, no los de `facts`-solo')
    assert.isAbove(report.bytes, factsOnly, 'el fusionado pesa MÁS que `facts`-solo (los tipos de relaciones cuentan)')
  })

  test('al 80 % del techo con relaciones incluidas: avisa UNA vez por el canal de log', ({ assert }) => {
    const base = realistic(360)
    let types = 0
    while (factsModelBytes(openFgaFactsModel(HOLDERS, base, docTypes(types))) < FACTS_MODEL_MAX_BYTES * 0.8) {
      types += 1
      assert.isBelow(types, 200, 'no se alcanza el 80 % ni con 200 tipos: recalibra')
    }
    const config = docTypes(types)
    const bytes = factsModelBytes(openFgaFactsModel(HOLDERS, base, config))
    assert.isAtLeast(bytes, FACTS_MODEL_MAX_BYTES * 0.8)
    assert.isBelow(bytes, FACTS_MODEL_MAX_BYTES)

    const warnings: string[] = []
    const report = assertFactsModelPublishable(HOLDERS, base, (m) => warnings.push(m), config)
    assert.equal(report.bytes, bytes)
    assert.lengthOf(warnings, 1)
    assert.include(warnings[0], String(FACTS_MODEL_MAX_BYTES))
  })
})

/**
 * **⚪4 + F-04 a nivel de MODELO.** Un tipo de objeto de relaciones que duplica
 * un tipo o una familia reservados de `facts`, o una relación que choca con un
 * permiso del catálogo, ⇒ 422 del PAQUETE (con `status`+`code`), generado por
 * el generador ANTES de tocar el servidor — no el 400 opaco de FGA. Es la
 * pieza que, en el store compartido, hace que un `role_binding` de relaciones
 * ni siquiera se pueda DECLARAR (cierre por construcción del 🔴 del auditor).
 */
test.group('facts · 4-1 — ⚪4 (tipo/familia reservados) + F-04 (permiso↔relación)', () => {
  function relThrows(permissions: string[], config: any): any {
    let caught: any = null
    try {
      openFgaFactsModel(HOLDERS, permissions, config)
    } catch (error) {
      caught = error
    }
    if (caught === null) throw new Error('openFgaFactsModel tenía que lanzar y no lanzó')
    return caught
  }

  test('⚪4 · un objectType que DUPLICA un tipo reservado de `facts` (o `group`, o un holder) ⇒ 422 E_AUTHZ_RELATION_CONFIG', ({
    assert,
  }) => {
    // `role_binding` es el que cierra el 🔴: si se pudiera declarar, el driver
    // de relaciones podría componer el id de un binding real.
    for (const reserved of ['role_binding', 'scope', 'role', 'deny_binding', 'group', 'user']) {
      const caught = relThrows(PERMISSIONS, { objectTypes: [{ type: reserved, relations: [{ name: 'viewer' }] }] })
      assert.equal(caught.status, 422, reserved)
      assert.equal(caught.code, 'E_AUTHZ_RELATION_CONFIG', reserved)
      assert.include(caught.message, reserved)
    }
  })

  test('⚪4 · una relación con el nombre de una relación PROPIA del modelo (`parent`/`rooted`/`assignee`) ⇒ 422', ({
    assert,
  }) => {
    for (const relation of ['parent', 'rooted', 'assignee', 'binding', 'ancestor', 'role']) {
      const caught = relThrows(PERMISSIONS, { objectTypes: [{ type: 'document', relations: [{ name: relation }] }] })
      assert.equal(caught.status, 422, relation)
      assert.equal(caught.code, 'E_AUTHZ_RELATION_CONFIG', relation)
      assert.include(caught.message, relation)
    }
  })

  test('⚪4 · una relación que empieza por una familia derivada (`can_`/`denied_`/`permits_`) ⇒ 422', ({
    assert,
  }) => {
    const caught = relThrows(PERMISSIONS, {
      objectTypes: [{ type: 'document', relations: [{ name: 'can_thing' }] }],
    })
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_RELATION_CONFIG')
    assert.include(caught.message, 'can_')
  })

  test('F-04 · una relación con el nombre de un PERMISO del catálogo ⇒ 422 nombrando el permiso', ({
    assert,
  }) => {
    // Un permiso `viewer` proyecta la relación `viewer` en `scope`/`role_binding`;
    // una relación `viewer` en `document`. En el store compartido el generador
    // exige que los dos espacios sean disjuntos: renombra uno.
    const caught = relThrows(['viewer'], {
      objectTypes: [{ type: 'document', relations: [{ name: 'viewer' }] }],
    })
    assert.equal(caught.status, 422)
    assert.equal(caught.code, 'E_AUTHZ_RELATION_CONFIG')
    assert.include(caught.message, 'viewer')
    assert.include(caught.message, "el permiso 'viewer'")
  })

  test('validación estructural: include a una relación de OTRO tipo, y tipo duplicado, ⇒ 422', ({
    assert,
  }) => {
    const badInclude = relThrows(PERMISSIONS, {
      objectTypes: [{ type: 'document', relations: [{ name: 'viewer', includes: ['owner'] }] }],
    })
    assert.equal(badInclude.code, 'E_AUTHZ_RELATION_CONFIG')
    assert.include(badInclude.message, 'owner')

    const dupType = relThrows(PERMISSIONS, {
      objectTypes: [
        { type: 'document', relations: [{ name: 'viewer' }] },
        { type: 'document', relations: [{ name: 'owner' }] },
      ],
    })
    assert.equal(dupType.code, 'E_AUTHZ_RELATION_CONFIG')
    assert.include(dupType.message, 'document')
  })
})

/**
 * El modelo fusionado se ESCRIBE contra el `:8101` (un doble en memoria no
 * prueba que FGA lo acepte) y el gate de bytes se contrasta con el número que
 * reporta el servidor (delta 0). Y la SEMÁNTICA mínima de la fusión: en UN
 * store, `facts` (`can_<P>`) y las relaciones (`viewer` vía userset e includes)
 * responden a la vez sin cruzarse.
 */
if (openFgaTestUrl) {
  const apiUrl: string = openFgaTestUrl

  test.group('facts · 4-1 — el :8101 acepta el modelo FUSIONADO y lo mide igual', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    test('OpenFGA acepta el modelo FUSIONADO (group + document) y devuelve un authorization_model_id (201)', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `fused-${Date.now()}` })
      stores.push(store.id!)
      const client = new OpenFgaClient({ apiUrl, storeId: store.id })
      const model = await client.writeAuthorizationModel(openFgaFactsModel(HOLDERS, PERMISSIONS, RELATIONS))
      assert.isString(model.authorization_model_id)
      assert.isNotEmpty(model.authorization_model_id)
    })

    test('factsModelBytes del modelo FUSIONADO cuenta LOS MISMOS bytes que el servidor (delta 0)', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `fused-size-${Date.now()}` })
      stores.push(store.id!)
      const client = new OpenFgaClient({ apiUrl, storeId: store.id })
      // Un modelo fusionado que REBASA el techo: el servidor reporta su tamaño.
      const config = {
        objectTypes: Array.from({ length: 40 }, (_, k) => ({
          type: `document${k}`,
          relations: [
            { name: 'owner' },
            { name: 'editor', includes: ['owner'] },
            { name: 'viewer', includes: ['editor'] },
          ],
        })),
      }
      const model = openFgaFactsModel(
        HOLDERS,
        Array.from({ length: 460 }, (_, i) => `recurso${i}:leer`),
        config
      )
      let reported: number | null = null
      try {
        await client.writeAuthorizationModel(model)
      } catch (error: any) {
        reported = Number(/limit: (\d+) bytes/.exec(String(error?.message))?.[1] ?? NaN)
      }
      assert.isNotNull(reported, 'el modelo fusionado tenía que rebasar para que el servidor diga su cuenta')
      assert.equal(factsModelBytes(model), reported)
    })

    test('SEMÁNTICA fusionada en UN store: `viewer` resuelve por userset e includes, y `can_<P>` de `facts` sigue respondiendo', async ({
      assert,
    }) => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `fused-sem-${Date.now()}` })
      stores.push(store.id!)
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS, RELATIONS)
      )
      const client = new OpenFgaClient({
        apiUrl,
        storeId: store.id,
        authorizationModelId: model.authorization_model_id,
      })
      const role = 'role:0192f000-0000-7000-8000-000000000001'
      const binding = 'role_binding:app|0192f000-0000-7000-8000-000000000001'
      await client.writeTuples([
        // --- relaciones (ReBAC) ---
        { user: 'user:alice', relation: 'member', object: 'group:eng' },
        { user: 'group:eng#member', relation: 'viewer', object: 'document:d1' }, // userset
        { user: 'user:bob', relation: 'owner', object: 'document:d1' }, // owner ⊆ viewer (includes)
        // --- facts (roles) EN EL MISMO store ---
        { user: 'user:*', relation: 'rooted', object: 'scope:app' },
        { user: 'user:*', relation: 'permits_docs_read', object: role },
        { user: role, relation: 'role', object: binding },
        { user: 'user:carol', relation: 'assignee', object: binding },
        { user: binding, relation: 'binding', object: 'scope:app' },
      ])

      const viaUserset = await client.check({ user: 'user:alice', relation: 'viewer', object: 'document:d1' })
      assert.isTrue(viaUserset.allowed, 'un miembro del grupo es viewer del documento (userset)')
      const viaIncludes = await client.check({ user: 'user:bob', relation: 'viewer', object: 'document:d1' })
      assert.isTrue(viaIncludes.allowed, 'un owner es viewer por includes (owner ⊆ editor ⊆ viewer)')
      const notViewer = await client.check({ user: 'user:carol', relation: 'viewer', object: 'document:d1' })
      assert.isFalse(notViewer.allowed, 'carol no tiene relación con el documento')

      const facts = await client.check({
        user: 'user:carol',
        relation: 'can_docs_read',
        object: 'scope:app',
        context: { current_time: new Date().toISOString() },
      })
      assert.isTrue(facts.allowed, '`can_<P>` de facts sigue respondiendo en el store fusionado')
      const factsAlice = await client.check({
        user: 'user:alice',
        relation: 'can_docs_read',
        object: 'scope:app',
        context: { current_time: new Date().toISOString() },
      })
      assert.isFalse(factsAlice.allowed, 'una relación ReBAC NO concede en `facts` (espacios disjuntos)')
    })
  })

  /**
   * **La PROFUNDIDAD de `can_<P>` sigue en 22 sobre el modelo FUSIONADO**, con
   * 500 repeticiones por lado (10 lotes de 50), no una tirada — el borde a 23
   * es probabilístico (patrón 3b-4 · C4). Que un tipo de relación CON usersets
   * (`group`/`document`) en el mismo modelo NO baje los 22: `can_<P>` nunca
   * recorre esos tipos (viven disjuntos de `scope`).
   */
  test.group('facts · 4-1 — profundidad `can_<P>` intacta sobre el FUSIONADO (500 reps)', (group) => {
    const stores: string[] = []
    group.each.teardown(async () => {
      const { OpenFgaClient } = await import('@openfga/sdk')
      while (stores.length) {
        await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore()
      }
    })

    function depthVerdict(error: unknown): boolean {
      let current: any = error
      for (let depth = 0; current && depth < 6; depth++) {
        const raw = `${current.input_error ?? ''} ${current.apiErrorCode ?? ''} ${current.message ?? ''}`
        if (/resolution_too_complex|resolution depth exceeded/i.test(raw)) return true
        current = current.cause
      }
      return false
    }
    async function despiteContention<T>(run: () => Promise<T>, attempts = 4): Promise<T> {
      for (let attempt = 1; ; attempt++) {
        try {
          return await run()
        } catch (error: any) {
          if (error?.status !== 503 || depthVerdict(error) || attempt >= attempts) throw error
          await new Promise((resolve) => setTimeout(resolve, 1_000 * attempt))
        }
      }
    }

    /** Una cadena de `hops` sobre el modelo FUSIONADO, con `siblings` hojas a la cota. */
    async function fusedChainStore(hops: number, siblings = 0) {
      const { OpenFgaClient } = await import('@openfga/sdk')
      const store = await new OpenFgaClient({ apiUrl }).createStore({
        name: `fused-depth-${Date.now()}-${stores.length}`,
      })
      stores.push(store.id!)
      // El modelo del store es el FUSIONADO: facts + group + document.
      const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
        openFgaFactsModel(HOLDERS, PERMISSIONS, RELATIONS)
      )
      const tree = memoryScopeTree()
      const driver = new OpenFgaAuthorizationDriver({
        apiUrl,
        storeId: store.id!,
        modelId: model.authorization_model_id,
        holderTypes: HOLDERS,
        resolveChain: resolveChainFrom(tree),
        acceptScopeDriftRisk: true,
        logger: { warn: () => {} },
      })
      await cleanAuthzTables()
      await syncAuthzCatalog(
        {
          permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
          roles: [{ slug: 'org-editor', scopeType: 'organization', permissions: ['docs:read'] }],
        },
        { projection: driver.catalogProjection() }
      )
      const root = orgScope()
      await tree.attach(root, APP_SCOPE)
      await driver.onScopeAttached!(root, APP_SCOPE)
      let parent: any = root
      const nodes: any[] = [root]
      for (let i = 0; i < hops; i++) {
        const node = unitScope()
        await tree.attach(node, parent)
        await driver.onScopeAttached!(node, parent)
        nodes.push(node)
        parent = node
      }
      const leaves: any[] = []
      for (let i = 0; i < siblings; i++) {
        const leaf = unitScope()
        await tree.attach(leaf, nodes[nodes.length - 2])
        await driver.onScopeAttached!(leaf, nodes[nodes.length - 2])
        leaves.push(leaf)
      }
      const alice = { type: 'users', uuid: uuidv7() }
      await driver.grant(alice, 'org-editor', root, { expiresAt: null })
      return { driver, nodes, alice, leaves }
    }

    test(`la cota es ${FACTS_MAX_RESOLVE_DEPTH} y NO ${FACTS_MAX_RESOLVE_DEPTH + 1} también en el FUSIONADO (500 reps por lado): un tipo de relación con usersets no baja los 22`, async ({
      assert,
    }) => {
      const ROUNDS = 10
      const SIBLINGS = FGA_MAX_BATCH_CHECK

      const edge = await fusedChainStore(FACTS_MAX_RESOLVE_DEPTH, SIBLINGS)
      let unresolved = 0
      for (let round = 0; round < ROUNDS; round++) {
        try {
          const answers = await despiteContention(() =>
            edge.driver.authorizeMany(edge.alice, 'docs:read', edge.leaves)
          )
          assert.deepEqual(answers, Array(SIBLINGS).fill(true), `ronda ${round} en la cota tenía que resolver entera`)
        } catch (error: any) {
          if (!depthVerdict(error)) throw error
          unresolved += 1
        }
      }
      assert.equal(
        unresolved,
        0,
        `a ${FACTS_MAX_RESOLVE_DEPTH} saltos ${unresolved}/${ROUNDS} lotes NO resolvieron sobre el FUSIONADO: ` +
          `los tipos de relaciones estarían bajando la profundidad de \`can_<P>\``
      )

      // Pasada la cota, el veredicto de PROFUNDIDAD del servidor es la ÚNICA
      // evidencia (3b-8 · E5): la CONTENCIÓN (`deadline_exceeded`) del `:8101`
      // compartido no cuenta —se reintenta acotada y, si persiste, se nombra—.
      // Se mide a MAX+2 (24), que NO resuelve NUNCA: es la cota DETERMINISTA.
      // MAX+1 (23) es el borde PROBABILÍSTICO (resuelve entre un 74 % y un
      // 96 % de las veces), así que exigir que a 23 falle «al menos una de
      // 500» era una aserción flaky en el artefacto publicado (misma clase que
      // 3G · Y1): una corrida en la que las 500 resuelvan a 23 es CONSISTENTE
      // con «22 es la mayor profundidad FIABLE» —23 es inestable, no la cota—,
      // no una regresión. A MAX+2, RESOLVER es el fallo (la cota real subió).
      const over = await fusedChainStore(FACTS_MAX_RESOLVE_DEPTH + 2, SIBLINGS)
      let verdicts = 0 // veredictos de profundidad (evidencia real de la cota)
      let contended = 0 // rondas que se quedaron en contención tras reintentar
      for (let round = 0; round < ROUNDS; round++) {
        let resolved = false
        try {
          await despiteContention(() => over.driver.authorizeMany(over.alice, 'docs:read', over.leaves))
          resolved = true
        } catch (error: any) {
          assert.equal(error.status, 503, 'pasado el techo es 503, jamás un `false` silencioso')
          if (depthVerdict(error)) {
            assert.equal(error.code, 'E_AUTHZ_BACKEND_UNAVAILABLE')
            verdicts += 1
          } else {
            contended += 1 // la contención NO es evidencia de la cota (3b-8 · E5)
          }
        }
        assert.isFalse(
          resolved,
          `a ${FACTS_MAX_RESOLVE_DEPTH + 2} saltos el servidor RESOLVIÓ sobre el FUSIONADO: la cota real ` +
            `subió (¿un tipo de relación, o el servidor cambió de --resolve-node-limit?) y ` +
            `FACTS_MAX_RESOLVE_DEPTH se quedó por debajo.`
        )
      }
      assert.isAbove(
        verdicts,
        0,
        `a ${FACTS_MAX_RESOLVE_DEPTH + 2} saltos las ${ROUNDS} rondas se quedaron en CONTENCIÓN ` +
          `(${contended}/${ROUNDS}, deadline_exceeded) sobre el FUSIONADO: la medida no vale con el :8101 ` +
          `saturado, reinícialo y corre esta suite sola.`
      )
    }).timeout(300_000)
  })
}
