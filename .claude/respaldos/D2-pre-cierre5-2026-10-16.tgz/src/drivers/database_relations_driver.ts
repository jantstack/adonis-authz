/**
 * Driver `database` del puerto `RelationsDriver` — ReBAC sobre SQL propio
 * (Fase 4, lote 4-3).
 *
 * Los hechos de relación viven en la tabla `authz_relations` (una fila por
 * tupla, INSERT/DELETE-ONLY, decisión (c) del dueño). **La caducidad (R-15,
 * 2.4.0-alpha.2)** es la columna `expires_at` (NULL = no caduca), con los
 * MISMOS tres estados de `expiresAt` que `grant` (invariante 10), caducidad
 * ESTRICTA (`expires_at > now`, la que vence ahora ya no cuenta), el MISMO
 * codec por dialecto que `authz_assignments` (`sqlExpiryCodec`, 2.5-B · K2) y
 * el reloj inyectable `withClock` (2.5 · J1). **Renovar la caducidad es
 * delete+insert, nunca UPDATE** (decisión (c) del juez: un solo trigger por
 * evento, menos superficie de divergencia de motor; observable: la fila cambia
 * de `uuid`). La resolución de `check`/`membersOf`/`listObjects` —includes de
 * un nivel y usersets de grupos anidados— es una **CTE recursiva por dialecto**
 * (mismo patrón que `sql_descendants.ts`) que solo recorre hechos VIGENTES, y
 * el cruce de particiones lo defiende, además, el trigger
 * `relationPartitionTrigger` (defensa en profundidad para el escritor «a mano»;
 * el corte primario es la columna `partition_key` en cada consulta).
 *
 * Pureza: este módulo vive en `drivers/` y NO importa `openfga` (regla 3 de
 * `check_purity.mjs`) ni el `manager`. Consume solo el puerto (`../types.js`),
 * los errores, la gramática compartida (`../identity.js`), el guard SQL y el
 * TIPO de la config de relaciones (`../relations/define_relations_config.js`).
 */
import db from '@adonisjs/lucid/services/db'
import { v7 as uuidv7 } from 'uuid'
import {
  AuthorizationBackendTimeoutError,
  AuthorizationConfigError,
  InvalidIdentityError,
  MembersOfDenyLimitError,
  UnsupportedDialectError,
  UnsupportedOperationError,
  WriteConflictError,
} from '../errors.js'
import { assertPartition, assertSubject, assertExpiresAt, partitionKey } from '../identity.js'
import { relationPartitionTrigger, relationPartitionTriggerDrops } from '../relation_partition_trigger.js'
import { isClock, systemClock } from '../clock.js'
import type { Clock } from '../clock.js'
import { resolveGrantExpiry, sameInstant } from '../expiry.js'
import { sqlExpiryCodec } from '../shared/sql_expiry.js'
import type { ExpiryCodec } from '../shared/sql_expiry.js'
import { guardSql, isDeadlock, isUniqueViolation, withDeadline } from '../shared/backend_guard.js'
import { assertCallerTransaction } from '../shared/transaction_guard.js'
import { isRelUserset } from '../types.js'
import type {
  RelObject,
  RelSubject,
  RelationObjectsPage,
  RelationSubjectsPage,
  RelationPage,
  RelationTuple,
  RelationTuplePage,
  RelationsDriver,
  RelationsDriverCapabilities,
  RelationTransactionOptions,
  RelationWriteOptions,
  RelationDenyOptions,
  RelationDecision,
  ScopeRef,
  SubjectRef,
} from '../types.js'
import {
  assertRelationDeclared,
  assertObjectTypeDeclared,
  assertUsersetSubject,
  assertRelationDenyable,
  assertDenySubject,
  assertDenyNoExpiry,
  cutPathAllows,
  decideFrom,
  deniableAbove,
  deniedRelationOf,
  storedRelationKind,
  denyPhaseOf,
  relationsDown,
  RELATION_DENY_PREFIX,
} from '../relations/define_relations_config.js'
import { assertCheckManyObjects, distinctObjects, expandByPosition } from '../relations/check_many.js'
import type { RelationsConfig } from '../relations/define_relations_config.js'

const DEFAULT_TIMEOUT_MS = 5_000
/**
 * **Cota de candidatos de `membersOf` cuando el objeto tiene un deny vigente** (lote D · cierre 1 de D1, 🟡 4): con deny
 * cada candidato se juzga con un `check` (una CTE por candidato). Pasada ⇒ 500 `E_AUTHZ_MEMBERS_DENY_LIMIT`, nunca una
 * lista parcial. En «Limits» del README, atada a esta constante (`scope_depth.spec`).
 */
export const RELATIONS_MEMBERS_DENY_CHECK_MAX = 1_000
const RELATIONS_TABLE = 'authz_relations'
/** Longitud máxima del id de un objeto/holder de relación (columna `varchar(64)`). */
const RELATION_ID_MAX = 64
/** El tipo BUILT-IN portador de usersets (declarado por el generador, no por el consumidor). */
const GROUP_TYPE = 'group'
const GROUP_MEMBER = 'member'
/**
 * L-4b: lo que lleva `subject_relation` un HOLDER. Cadena vacía y no NULL
 * porque el UNIQUE `authz_rel_tuple_uq` incluye la columna y NULL ≠ NULL en
 * los tres motores (con NULL, dos `relate` concurrentes del mismo holder
 * confirmaban DOS filas). Cadena vacía y no un centinela (`'-'`) porque la
 * gramática de una relación (`[a-z0-9._-]{1,50}`) no admite la vacía: ningún
 * userset puede colisionar con ella.
 */
const HOLDER_RELATION = ''
/** Tamaño de página por defecto y tope de `enumerateRelations` (origen de reconcile). */
const DEFAULT_ENUMERATE_LIMIT = 100
const MAX_ENUMERATE_LIMIT = 1_000

/** Formato de id de relación: minúsculas, dígitos y `._-`; sin separadores del store. */
const RELATION_ID_FORMAT = /^[a-z0-9_.-]+$/

/**
 * Metadatos SQL por dialecto: el carácter de cita de identificadores y cómo se
 * castea un literal a texto en el ANCLA de la CTE (MySQL/PG exigen que la
 * columna del término no-recursivo y la del recursivo tengan el MISMO tipo, o
 * la CTE recursiva no compila; SQLite es laxo pero el CAST no le molesta).
 */
interface DialectMeta {
  quote: '"' | '`'
  /** Castea `expr` a un texto lo bastante ancho para casar con las columnas de la tabla. */
  text(expr: string): string
  /** Hint de MySQL para no cortar la recursión a 1000 iteraciones (como en `sql_descendants`). */
  hint: string
}

const DIALECTS: Record<string, DialectMeta> = {
  postgres: { quote: '"', text: (e) => `CAST(${e} AS varchar(64))`, hint: '' },
  sqlite3: { quote: '"', text: (e) => `CAST(${e} AS text)`, hint: '' },
  'better-sqlite3': { quote: '"', text: (e) => `CAST(${e} AS text)`, hint: '' },
  mysql: { quote: '`', text: (e) => `CAST(${e} AS CHAR(64))`, hint: '/*+ SET_VAR(cte_max_recursion_depth = 50000) */ ' },
  mysql2: { quote: '`', text: (e) => `CAST(${e} AS CHAR(64))`, hint: '/*+ SET_VAR(cte_max_recursion_depth = 50000) */ ' },
}

// La DDL del trigger de partición vive en el módulo PURO
// `../relation_partition_trigger.js` (sin dependencia del servicio `db`, para
// que lo importe también el espejo del esquema, cargado antes de bootear la
// app). Se re-exporta aquí por comodidad del consumidor del driver.
export { relationPartitionTrigger, relationPartitionTriggerDrops }

export interface DatabaseRelationsDriverOptions {
  /** Nombre de la conexión Lucid (default: la primaria). */
  connection?: string
  /** Deadline de cada consulta en ms (default 5000): vencido ⇒ 503. */
  timeoutMs?: number
  /**
   * Reloj de pared que DECIDE la caducidad (R-15, 2.5 · J1): `expires_at > now`
   * en cada lectura y los tres estados de `expiresAt` en `relate`. Default
   * `systemClock`; en producción lo aplica el `RelationsManager` con `clock`
   * (`withClock`). Los sellos (`created_at`) NO lo usan: son auditoría, no
   * decisiones (2.5-B · K5), y llevan el reloj del sistema.
   */
  now?: Clock
  /**
   * Lo que este despliegue DECLARA sobre `{ transaction }` (L-4, panel
   * `{trx}`; la misma opción que `DatabaseDriverOptions.transactionalWrites`
   * de roles, L-3). Default `true`: `relate`/`unrelate`/`purgeObject`/
   * `purgeSubject` escriben dentro de la transacción ABIERTA del llamante
   * (`TransactionClientContract` de Lucid de la conexión de ESTE driver —la
   * de `connection`, o la primaria—, `assertCallerTransaction`), «los dos o
   * ninguno». Eso **exige pool ≥ 2**: la autoridad (la barrera del freeze del
   * `RelationsManager`) se lee por la conexión del motor mientras el llamante
   * sostiene la suya, y con pool 1 (SQLite `:memory:`) la barrera sale 503
   * `E_AUTHZ_BACKEND_TIMEOUT` a `freezeTimeoutMs` — fail-closed, nunca un
   * bypass, pero un 503 tardío. Un despliegue con pool 1 declara `false` aquí
   * y la puerta 1 del manager responde 500 `E_AUTHZ_UNSUPPORTED` al instante
   * y con cero sentencias.
   */
  transactionalWrites?: boolean
}

interface RelationRow {
  uuid: string
  partition_key: string
  object_type: string
  object_uuid: string
  relation: string
  subject_type: string
  subject_uuid: string
  /**
   * L-4b: `''` = holder, con valor = userset. La columna es `NOT NULL DEFAULT ''`
   * para que el UNIQUE `authz_rel_tuple_uq` defienda también al holder (NULL ≠
   * NULL en los tres motores). El driver NUNCA escribe NULL; en LECTURA tolera
   * una fila vieja con NULL (backfill no aplicado) y la trata como holder.
   */
  subject_relation: string
  subject_partition: string | null
  /** R-15: la caducidad (NULL = no caduca), escrita/leída por `ExpiryCodec`. */
  expires_at: unknown
  created_at: Date
}

/**
 * El driver `database` de relaciones. Toda consulta pasa por `guardSql`: un
 * fallo del cliente SQL sale como `AuthorizationBackendError` (503), nunca como
 * el error crudo de knex (invariante 5).
 */
export class DatabaseRelationsDriver implements RelationsDriver {
  /**
   * Lo que declara (cada valor tiene su cara en `runRelationsDriverContract`):
   *  - `singleCheckRelations`: `check` es UNA consulta (la CTE resuelve includes
   *    + usersets anidados en un round-trip).
   *  - `listObjectsInherited: false`: los `list*` no abren un subárbol (invariante 7).
   *  - `usersetSubjects`: `listSubjects` incluye los usersets directos (`group#member`).
   *  - `membersOfNative`: la membresía TRANSITIVA la resuelve la CTE recursiva.
   *  - `enumerateRelations: true` (4-5): es ORIGEN de `authz:reconcile` de
   *    relaciones — enumera los hechos DIRECTOS de la partición (`authz_relations`),
   *    paginados por la PK, sin filtrar ni derivar (invariante 7 + higiene de
   *    reconcile): la caña la ve el destino tal cual la escribió el origen.
   *  - `listObjectsTruncation: false`: sin tope de servidor, `listObjects` es exhaustiva.
   *  - `injectableClock: true` (R-15): `withClock(now)` fija el reloj que decide
   *    la caducidad (`expires_at > now`), como el driver `database` de roles.
   *  - `transactionalWrites: true` (L-4, default): las cuatro escrituras van
   *    por la transacción ABIERTA del llamante (`#writer()`,
   *    `assertCallerTransaction` contra la conexión de este driver). Lo que
   *    NO viaja por ella: la barrera del freeze y F-05 (autoridad). Un
   *    despliegue con pool 1 lo declara `false` (ver las opciones).
   */
  readonly capabilities: Readonly<RelationsDriverCapabilities>
  /**
   * Con `transactionalWrites: false` declarado por el despliegue, un
   * `{ transaction }` que llegara igual (un llamante que se salta el manager)
   * se rechaza aquí también: no se ignora en silencio.
   */
  readonly #transactionalWrites: boolean

  readonly #config: RelationsConfig
  readonly #connectionName?: string
  readonly #timeoutMs: number
  readonly #now: Clock
  /** Inyectable para probar el dialecto ajeno sin servidor. */
  readonly #database: { connection(name?: string): any; primaryConnectionName?: string }
  #expiryCodec?: ExpiryCodec

  constructor(
    config: RelationsConfig,
    options: DatabaseRelationsDriverOptions = {},
    database: { connection(name?: string): any; primaryConnectionName?: string } = db
  ) {
    this.#config = config
    this.#connectionName = options.connection
    this.#timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS
    this.#now = options.now ?? systemClock
    this.#database = database
    this.#transactionalWrites = options.transactionalWrites ?? true
    this.capabilities = Object.freeze({
      singleCheckRelations: true,
      listObjectsInherited: false,
      usersetSubjects: true,
      membersOfNative: true,
      enumerateRelations: true,
      listObjectsTruncation: false,
      injectableClock: true,
      transactionalWrites: this.#transactionalWrites,
      // Lote D · D1: el deny vive en la MISMA tabla (`relation = 'denied_<rel>'`) y TODA lectura lo honra SIEMPRE
      // (D8: también en un tipo sin opt-in —una fila deny es un hecho—).
      relationDenies: true,
      // Cierre 2 de D2 · 🟠 N1: renovar (otra caducidad) es delete + insert en UNA transacción (`#upsert`): ningún
      // instante sin la tupla, así que una membresía que transporta un deny se renueva sin ventana.
      atomicRenewal: true,
    })
  }

  /**
   * Vista de este driver con OTRO reloj de pared (R-15, paridad con
   * `AuthorizationDriver.withClock`): misma conexión, config y deadline; solo
   * cambia el `now` que decide la caducidad. El driver no tiene estado propio
   * (la conexión es del servicio `db`), así que la vista es una instancia nueva.
   */
  withClock(now: Clock): RelationsDriver {
    if (!isClock(now)) {
      throw new AuthorizationConfigError(`withClock: now debe ser una función () => Date (llegó ${typeof now})`)
    }
    return new DatabaseRelationsDriver(
      this.#config,
      { connection: this.#connectionName, timeoutMs: this.#timeoutMs, now, transactionalWrites: this.#transactionalWrites },
      this.#database
    )
  }

  /* ── Infraestructura ──────────────────────────────────────────────────── */

  #connection(): any {
    return this.#database.connection(this.#connectionName)
  }

  /** La clave de partición (D4: `partitionKey` de `identity.ts`, la ÚNICA puerta hacia `partition_key`). */
  #keyOf(partition: ScopeRef): string {
    return partitionKey(partition)
  }

  /** El codec de `expires_at` por dialecto (K2): se decide una vez por driver, sin consulta. */
  get #expiry(): ExpiryCodec {
    this.#expiryCodec ??= sqlExpiryCodec(this.#connection())
    return this.#expiryCodec
  }

  /**
   * El predicado SQL de VIGENCIA (R-15, caducidad ESTRICTA): sin caducidad o
   * con caducidad FUTURA — la que vence en `now` ya no cuenta. Para el SQL
   * crudo de las CTEs (`q` cita el identificador; la binding es `bind(now)`
   * del codec, con UN solo `now` por operación, 2.5-B · K9).
   */
  #activeSql(q: (name: string) => string, alias: string): string {
    return `(${alias}.${q('expires_at')} IS NULL OR ${alias}.${q('expires_at')} > ?)`
  }

  /** El mismo predicado, para el query builder. */
  #whereActive(query: any, at: Date): any {
    const bound = this.#expiry.bind(at)
    return query.where((b: any) => b.whereNull('expires_at').orWhere('expires_at', '>', bound))
  }

  #dialectMeta(): DialectMeta {
    const connection = this.#connection()
    const name: string = connection?.dialect?.name ?? connection?.client?.driverName ?? 'desconocido'
    const meta = DIALECTS[name]
    if (!meta) {
      throw new UnsupportedDialectError(
        `DatabaseRelationsDriver: dialecto '${name}' sin observación en la suite ` +
          `(hoy: PostgreSQL, MySQL 8 y SQLite). La CTE recursiva del check no se declara igual en dos ` +
          `motores; impleméntala a mano para este motor.`
      )
    }
    return meta
  }

  #sql<T>(operation: string, fn: () => Promise<T>): Promise<T> {
    return guardSql('database-relations', operation, this.#timeoutMs, fn)
  }

  #raw(operation: string, text: string, bindings: unknown[]): Promise<any> {
    return this.#sql(operation, () => this.#connection().rawQuery(text, bindings))
  }

  /** La conexión de quien ESCRIBE: la declarada, o la primaria de Lucid (`undefined` con un `db` doble sin ella). */
  #ownerConnection(): string | undefined {
    return this.#connectionName ?? this.#database.primaryConnectionName
  }

  /**
   * Por dónde escribe `operation` (L-4, el MISMO patrón que `writer()` del
   * driver de roles, L-3): la transacción ABIERTA del llamante si llegó en
   * `options.transaction` —validada contra la conexión de ESTE driver por
   * `assertCallerTransaction`: otra conexión, un `QueryClient` o el `db`
   * entero son 500 `E_AUTHZ_CONFIG` ANTES de tocar nada—, o la conexión del
   * driver. `external` dice cuál de los dos.
   *
   * Solo la ESCRITURA va por ella (y la lectura «¿ya existe?» de `relate`,
   * que forma parte de la misma escritura: un `relate` y su renovación en la
   * misma transacción tienen que verse). La AUTORIDAD no: la barrera del
   * freeze la lee el `RelationsManager` por la conexión del motor, y F-05 y la
   * gramática cortan antes de llegar aquí.
   */
  #writer(operation: string, options: RelationTransactionOptions | undefined): { client: any; external: boolean } {
    if (options?.transaction === undefined || options.transaction === null) {
      return { client: this.#connection(), external: false }
    }
    if (!this.#transactionalWrites) {
      throw new UnsupportedOperationError(
        'transactionalWrites',
        operation,
        'database',
        'Este despliegue declara transactionalWrites: false en las opciones del driver de relaciones (pool 1): ' +
          '{ transaction } no se admite. Quita la opción (exige pool ≥ 2) o no pases transaction.'
      )
    }
    const trx = assertCallerTransaction(`database-relations.${operation}`, options.transaction, {
      connection: this.#ownerConnection(),
    })
    return { client: trx, external: true }
  }

  /**
   * Una sentencia que falla DENTRO de la transacción del llamante no se
   * absorbe (L-4, paridad con `poisoned()` de roles): en PostgreSQL la
   * transacción ya está ABORTADA (toda sentencia posterior es `25P02` hasta
   * el rollback) y en REPEATABLE READ una relectura no vería al ganador. Así
   * que un choque del UNIQUE de `authz_relations` (dos `relate` del mismo
   * hecho en dos transacciones abiertas) y un **deadlock** (dos transacciones
   * que escriben dos relaciones en orden cruzado: el motor elige una víctima y
   * la deshace —PG `40P01`, MySQL `1213`—) salen como **409
   * `E_AUTHZ_WRITE_CONFLICT`** —«envenena tu transacción: haz rollback y
   * reintenta»—; un deadline vencido sigue siendo el 503
   * `E_AUTHZ_BACKEND_TIMEOUT` que ya clasificó `#sql`, y cualquier otro fallo,
   * su 503. Nunca una segunda sentencia sobre una transacción que puede estar
   * abortada. (Medido por motor en `tests/relations_database.spec.ts`.)
   */
  #poisoned(operation: string, error: unknown): never {
    if (isUniqueViolation(error)) {
      throw new WriteConflictError(
        `database-relations.${operation}: la tupla la escribió otra transacción mientras la tuya estaba abierta ` +
          '(choque del UNIQUE dentro de tu transacción). No se puede absorber ahí dentro: la transacción queda ' +
          'envenenada (en PostgreSQL, abortada). Haz rollback y reintenta.',
        { cause: error }
      )
    }
    if (isDeadlock(error)) {
      throw new WriteConflictError(
        `database-relations.${operation}: el motor detectó un DEADLOCK con otra transacción y eligió la tuya ` +
          'como víctima (dos transacciones escribiendo las mismas tuplas en orden cruzado). La transacción queda ' +
          'envenenada (PostgreSQL la aborta; MySQL la deshace entera). Haz rollback y reintenta.',
        { cause: error }
      )
    }
    throw error
  }

  /* ── Validación de identidad (defensa en profundidad) ─────────────────── */

  /** El objeto es `{ type, id }` bien formado (F-05 —tipo/relación declarados— la aplica `assertRelationDeclared` en las SIETE operaciones: L-0 en `relate`/`unrelate`, alpha.3 en purgas y lecturas). */
  #assertObject(object: RelObject): void {
    if (!object || typeof object !== 'object') {
      throw new InvalidIdentityError(`Objeto de relación inválido: llegó ${typeof object}`)
    }
    this.#assertId('el tipo de objeto', object.type, RELATION_ID_MAX)
    this.#assertId(`el id del objeto '${object.type}'`, object.id, RELATION_ID_MAX)
  }

  #assertId(kind: string, value: unknown, max: number): void {
    if (typeof value !== 'string' || value.length === 0 || value.length > max || !RELATION_ID_FORMAT.test(value)) {
      throw new InvalidIdentityError(
        `${kind} inválido: se esperaba una cadena de 1-${max} caracteres en minúsculas, dígitos y '._-' ` +
          `(llegó ${JSON.stringify(value)})`
      )
    }
  }

  /**
   * Valida el sujeto (holder o userset) y devuelve sus columnas. L-4b: el
   * holder lleva `relation: ''` (NUNCA NULL): es lo que hace que el UNIQUE
   * `authz_rel_tuple_uq` lo defienda (`'' = ''`, mientras que NULL ≠ NULL).
   */
  #subjectColumns(subject: RelSubject, partitionKey: string): {
    type: string
    uuid: string
    relation: string
    partition: string | null
  } {
    if (isRelUserset(subject)) {
      // alpha.3 · F-05 también en el USERSET del sujeto (la misma función que
      // el manager): `{ object: { type: 'role_binding' }, relation: 'role' }`
      // como sujeto de una purga/lectura no toca ni nombra un binding real.
      // B3 (lote B): y solo `group#member` — la fila de otro userset era INERTE.
      assertUsersetSubject(this.#config, subject)
      this.#assertObject(subject.object)
      this.#assertId(`la relación del userset '${subject.object.type}'`, subject.relation, RELATION_ID_MAX)
      // El userset comparte la partición de la tupla (el manager así lo exige);
      // se materializa en `subject_partition` para que el trigger lo defienda.
      return { type: subject.object.type, uuid: subject.object.id, relation: subject.relation, partition: partitionKey }
    }
    assertSubject(subject)
    return { type: subject.type, uuid: subject.uuid, relation: HOLDER_RELATION, partition: null }
  }

  /**
   * El WHERE por `subject_relation`. Para un userset, su relación exacta. Para
   * un HOLDER (`''`), **tolerante a NULL**: una fila vieja con NULL (alpha.1
   * sin el backfill de L-4b) sigue siendo el mismo hecho, y si `unrelate`/
   * `purgeSubject` no la vieran seguiría concediendo tras retirarla
   * (fail-open); el «¿ya existe?» de `relate` también la encuentra, así que
   * renovar su caducidad la sustituye por una fila con `''`.
   */
  #whereSubjectRelation(b: any, relation: string): void {
    if (relation === HOLDER_RELATION) b.where('subject_relation', HOLDER_RELATION).orWhereNull('subject_relation')
    else b.where('subject_relation', relation)
  }

  /* ── Expansión de includes (un nivel, hacia ABAJO desde la relación) ──── */

  /** `down*(R)` — desde el lote D, la función ÚNICA de la config (`relationsDown`), la misma que el doble y el oráculo. */
  #expandDown(objectType: string, relation: string): string[] {
    return relationsDown(this.#config, objectType, relation)
  }

  /**
   * **Lo que una lectura con deny tiene que traer para `R`** (lote D · D5/D8): los grants de `down*(R)` y los denies de
   * `up*(down*(R))` (almacenados como `denied_<rel>`). SIEMPRE, también en un tipo sin opt-in (D8: una fila deny es un
   * hecho; si el tipo retiró el opt-in con denies vivos, `database` sigue denegando). Sin filas `denied_*` la respuesta
   * es la de 2.4.0-alpha.10 (el corte no tiene nada que cortar).
   */
  #readRelations(objectType: string, relation: string): string[] {
    return [...this.#expandDown(objectType, relation), ...deniableAbove(this.#config, objectType, relation).map(deniedRelationOf)]
  }

  /** Reparte las relaciones leídas de un objeto en grants y denies (nombre PÚBLICO). */
  #split(relations: Iterable<string>): { allowed: Set<string>; denied: Set<string> } {
    const allowed = new Set<string>()
    const denied = new Set<string>()
    for (const r of relations) {
      if (r.startsWith(RELATION_DENY_PREFIX)) denied.add(r.slice(RELATION_DENY_PREFIX.length))
      else allowed.add(r)
    }
    return { allowed, denied }
  }

  /* ── Escrituras ───────────────────────────────────────────────────────── */

  async relate(
    subject: RelSubject,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    options?: RelationWriteOptions
  ): Promise<void> {
    // L-0 · F-05 en el DRIVER (la MISMA función que el manager): la red para
    // quien entra por `manager.driver()` o por `reconcileRelations`. Corta
    // ANTES de pedir la conexión. En `database` la tabla es propia (inocuo),
    // pero el 422 es el MISMO que en `openfga`, donde el store es compartido.
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertObject(object)
    this.#assertId(`la relación de '${object.type}'`, relation, RELATION_ID_MAX)
    // R-15 (defensa en profundidad; el manager ya lo validó): los tres estados.
    assertExpiresAt(options?.expiresAt)
    await this.#upsert('relate', subject, relation, object, partition, options?.expiresAt, options)
  }

  /**
   * **`deny` = la tupla `denied_<rel>`, por el MISMO camino idempotente que `relate`** (lote D · D1): F-05 sobre el
   * nombre PÚBLICO, la puerta de escritura del opt-in (fase `'write'`, D10), ni `group` ni `*`, y SIN caducidad (D3:
   * `expiresAt` ⇒ 422; un deny escrito a mano con caducidad se rehace permanente). Por la transacción del llamante si
   * llega (L-4, como `relate`).
   */
  async deny(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef, options?: RelationDenyOptions): Promise<void> {
    assertRelationDeclared(this.#config, object, relation)
    assertRelationDenyable(this.#config, object, relation)
    assertDenyNoExpiry(options)
    assertPartition(partition)
    this.#assertObject(object)
    assertDenySubject(subject)
    await this.#upsert('deny', subject, deniedRelationOf(relation), object, partition, null, options)
  }

  /** `removeDeny`: borra la tupla `denied_<rel>`. Sobre CUALQUIER tipo declarado (D8/R2-4 b). No-op si no está. */
  async removeDeny(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef, options?: RelationDenyOptions): Promise<void> {
    assertRelationDeclared(this.#config, object, relation)
    assertDenyNoExpiry(options)
    assertPartition(partition)
    this.#assertObject(object)
    await this.#deleteTuple('removeDeny', subject, deniedRelationOf(relation), object, partition, options)
  }

  /** El check-then-delete-insert idempotente de `relate`/`deny` sobre la relación ALMACENADA. */
  async #upsert(
    operation: string,
    subject: RelSubject,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    requested: Date | null | undefined,
    options: RelationTransactionOptions | undefined
  ): Promise<void> {
    const partitionKey = this.#keyOf(partition)
    const s = this.#subjectColumns(subject, partitionKey)
    const codec = this.#expiry
    const now = this.#now()
    // L-4: por la transacción del llamante si llegó (`#writer`, juzgada AQUÍ,
    // después de F-05 y la gramática y antes de la primera sentencia).
    const { client, external } = this.#writer(operation, options)
    // El check-then-delete-insert idempotente. Con transacción EXTERNA corre
    // tal cual sobre ella (el trigger de partición dispara en ESE INSERT,
    // dentro de la trx del consumidor; NUNCA se abre una interna: la fila
    // confirmaría sola y sobreviviría al rollback del llamante). Sin ella, en
    // una transacción INTERNA de la conexión del driver (la atomicidad
    // trigger+insert de 4-3). Cada sentencia lleva su deadline (`#sql`).
    const write = async (trx: any) => {
      const existing: Array<{ uuid: string; expires_at: unknown }> = await this.#sql(`${operation}.select`, () =>
        trx
          .from(RELATIONS_TABLE)
          .where('partition_key', partitionKey)
          .where('object_type', object.type)
          .where('object_uuid', object.id)
          .where('relation', relation)
          .where('subject_type', s.type)
          .where('subject_uuid', s.uuid)
          .where((b: any) => this.#whereSubjectRelation(b, s.relation))
          .select('uuid', codec.select('expires_at'))
          .limit(1)
      )
      const current = existing[0]
      const previous = current ? codec.fromDb(current.expires_at) : null
      // Los tres estados (invariante 10): omitido preserva la VIGENTE (una
      // caducada revive sin caducidad), null la quita, Date la fija.
      const expiresAt = resolveGrantExpiry(previous, requested, now)
      if (current) {
        // Idempotente (invariante 6): la misma caducidad no reescribe nada.
        if (sameInstant(previous, expiresAt)) return
        // **INSERT/DELETE-ONLY (decisión (c))**: cambiar la caducidad es
        // BORRAR la fila e INSERTAR otra —nunca un UPDATE—; la fila nueva
        // tiene otro `uuid`, que es lo que lo hace observable. Dentro de la
        // trx del llamante, el rollback devuelve la fila (y la caducidad) VIEJA.
        await this.#sql(`${operation}.delete`, () => trx.from(RELATIONS_TABLE).where('uuid', current.uuid).delete())
      }
      await this.#sql(`${operation}.insert`, () =>
        trx.table(RELATIONS_TABLE).insert({
          uuid: uuidv7(),
          partition_key: partitionKey,
          object_type: object.type,
          object_uuid: object.id,
          relation,
          subject_type: s.type,
          subject_uuid: s.uuid,
          subject_relation: s.relation,
          subject_partition: s.partition,
          expires_at: codec.toDb(expiresAt),
          // Sello de auditoría, no decisión (2.5-B · K5): reloj del SISTEMA
          // (con el reloj inyectado en 2099 un TIMESTAMP de MySQL reventaría).
          created_at: systemClock(),
        } satisfies RelationRow)
      )
    }
    if (external) {
      try {
        await write(client)
      } catch (error) {
        this.#poisoned(operation, error)
      }
      return
    }
    await this.#sql(operation, () => client.transaction(write))
  }

  async unrelate(
    subject: RelSubject,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    options?: RelationWriteOptions
  ): Promise<void> {
    // L-0 · F-05 también al RETIRAR (paridad con `openfga`).
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertObject(object)
    this.#assertId(`la relación de '${object.type}'`, relation, RELATION_ID_MAX)
    await this.#deleteTuple('unrelate', subject, relation, object, partition, options)
  }

  /** El DELETE de UNA tupla (relación ALMACENADA): `unrelate` y `removeDeny`. Un `unrelate` nunca toca `denied_*` (D-04). */
  async #deleteTuple(
    operation: string,
    subject: RelSubject,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    options: RelationTransactionOptions | undefined
  ): Promise<void> {
    const partitionKey = this.#keyOf(partition)
    const s = this.#subjectColumns(subject, partitionKey)
    const { client, external } = this.#writer(operation, options)
    try {
      await this.#sql(operation, () =>
        client
          .from(RELATIONS_TABLE)
          .where('partition_key', partitionKey)
          .where('object_type', object.type)
          .where('object_uuid', object.id)
          .where('relation', relation)
          .where('subject_type', s.type)
          .where('subject_uuid', s.uuid)
          .where((b: any) => this.#whereSubjectRelation(b, s.relation))
          .delete()
      )
    } catch (error) {
      if (external) this.#poisoned(operation, error)
      throw error
    }
  }

  /* ── Lecturas ─────────────────────────────────────────────────────────── */

  /**
   * **F-05 en las LECTURAS y las PURGAS del driver** (2.4.0-alpha.3, cierre
   * del 🔴 1 / 🟠 2 del auditor; la MISMA función y el mismo orden que L-0 en
   * `relate`/`unrelate`): PRIMERA línea, antes de pedir la conexión. En
   * `database` la tabla es propia (inocuo), pero el 422 es el MISMO que en
   * `openfga`, donde `purgeObject(role_binding)` borraba el binding real y
   * `listSubjects(assignee, role_binding)` enumeraba sus asignados por el
   * camino de `manager.driver()`. `check`/`listSubjects` validan el par;
   * `listObjects`/`purgeObject` el tipo; `purgeSubject` el userset.
   */
  async check(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef): Promise<boolean> {
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertObject(object)
    const partitionKey = this.#keyOf(partition)
    const s = this.#subjectColumns(subject, partitionKey)
    // Lote D · D5: los grants de `down*(R)` Y los denies de `up*(down*(R))`, en UNA consulta sobre la misma CTE
    // `principal` (el deny también viaja por `group#member`, anidado, y una membresía caducada no lo transporta);
    // el CORTE se decide en `cutPathAllows`, la función ÚNICA de la config.
    const relations = this.#readRelations(object.type, relation)
    const meta = this.#dialectMeta()
    const q = (name: string) => `${meta.quote}${name}${meta.quote}`

    const at = this.#expiry.bind(this.#now())
    const { cte, bindings: cteBindings } = this.#principalCte(meta, q, s, partitionKey, at)
    const relPlaceholders = relations.map(() => '?').join(', ')
    const sql =
      cte +
      ` SELECT ${meta.hint}DISTINCT r.${q('relation')} AS ${q('relation')} FROM ${q(RELATIONS_TABLE)} r ` +
      `JOIN principal p ON r.${q('subject_type')} = p.p_type AND r.${q('subject_uuid')} = p.p_uuid ` +
      `AND COALESCE(r.${q('subject_relation')}, '') = p.p_rel ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = ? AND r.${q('object_uuid')} = ? ` +
      `AND r.${q('relation')} IN (${relPlaceholders}) AND ${this.#activeSql(q, 'r')}`
    const bindings = [...cteBindings, partitionKey, object.type, object.id, ...relations, at]
    const rows = rowsOf(await this.#raw('check', sql, bindings))
    const { allowed, denied } = this.#split(rows.map((row: any) => String(row.relation)))
    return cutPathAllows(this.#config, object.type, relation, allowed, denied)
  }

  /**
   * **`checkMany` = UNA consulta** (plan 2.5 · lote A, P4-8): la MISMA CTE
   * `principal` de `check` (el sujeto y sus grupos, transitivo, solo vigentes)
   * y un `SELECT DISTINCT object_type, object_uuid` sobre los hechos de la
   * partición que casan con CUALQUIER objeto distinto del lote —agrupados por
   * TIPO, porque los `includes` se expanden por tipo (`#expandDown`)—, con
   * UN solo `now` para todo el lote (`at`). Después se reparte por posición
   * (`[a, a, b]` ⇒ `[x, x, y]`). F-05 y la gramática del id, POR ÍTEM, antes
   * de la consulta (defensa en profundidad: el manager ya lo hizo).
   */
  async checkMany(subject: RelSubject, relation: string, objects: RelObject[], partition: ScopeRef): Promise<boolean[]> {
    const { distinct, index, facts } = await this.#readMany('checkMany', subject, relation, objects, partition)
    const answers = distinct.map((object) => {
      const { allowed, denied } = this.#split(facts.get(`${object.type}:${object.id}`) ?? [])
      return cutPathAllows(this.#config, object.type, relation, allowed, denied)
    })
    return expandByPosition(index, answers)
  }

  /**
   * **`decideMany` = la consulta de `checkMany`** (lote D · D9): los grants de `down*(R)` y los denies de
   * `up*(down*(R))` de cada objeto distinto, con UN `now` y en UNA consulta, y la regla AMPLIA de `decideFrom` (la
   * misma función que el doble y `openfga` cuando alinea su `batchCheck`). Tope, `[]` y F-05 por ítem como `checkMany`.
   */
  async decideMany(subject: RelSubject, relation: string, objects: RelObject[], partition: ScopeRef): Promise<RelationDecision[]> {
    const { distinct, index, facts } = await this.#readMany('decideMany', subject, relation, objects, partition)
    const answers = distinct.map((object) => {
      const { allowed, denied } = this.#split(facts.get(`${object.type}:${object.id}`) ?? [])
      return decideFrom(this.#config, object.type, relation, allowed, denied)
    })
    return index.map((at) => answers[at])
  }

  /**
   * **`checkMany`/`decideMany` = UNA consulta** (plan 2.5 · lote A, P4-8; lote D): la MISMA CTE `principal` de
   * `check` (el sujeto y sus grupos, transitivo, solo vigentes) y un `SELECT DISTINCT object_type, object_uuid,
   * relation` sobre los hechos de la partición que casan con CUALQUIER objeto distinto del lote —agrupados por TIPO,
   * porque los `includes` se expanden por tipo— con grants Y denies (`#readRelations`), con UN solo `now` para todo
   * el lote. F-05 y la gramática del id, POR ÍTEM, antes de la consulta (defensa en profundidad).
   */
  async #readMany(
    operation: string,
    subject: RelSubject,
    relation: string,
    objects: RelObject[],
    partition: ScopeRef
  ): Promise<{ distinct: RelObject[]; index: number[]; facts: Map<string, string[]> }> {
    assertCheckManyObjects(objects, operation)
    for (const object of objects) {
      assertRelationDeclared(this.#config, object, relation)
      this.#assertObject(object)
    }
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const s = this.#subjectColumns(subject, partitionKey)
    const { distinct, index } = distinctObjects(objects)
    const meta = this.#dialectMeta()
    const q = (name: string) => `${meta.quote}${name}${meta.quote}`
    const at = this.#expiry.bind(this.#now())
    const { cte, bindings: cteBindings } = this.#principalCte(meta, q, s, partitionKey, at)
    // Un grupo por TIPO de objeto: `(object_type = ? AND object_uuid IN (…) AND relation IN (<grants y denies del tipo>))`.
    const byType = new Map<string, string[]>()
    for (const object of distinct) {
      const ids = byType.get(object.type) ?? []
      ids.push(object.id)
      byType.set(object.type, ids)
    }
    const groups: string[] = []
    const groupBindings: unknown[] = []
    for (const [type, ids] of byType) {
      const relations = this.#readRelations(type, relation)
      groups.push(
        `(r.${q('object_type')} = ? AND r.${q('object_uuid')} IN (${ids.map(() => '?').join(', ')}) ` +
          `AND r.${q('relation')} IN (${relations.map(() => '?').join(', ')}))`
      )
      groupBindings.push(type, ...ids, ...relations)
    }
    const sql =
      cte +
      // ⚪ A8 (auditor del lote A): el hint de MySQL va ANTES de DISTINCT (como en
      // `listObjects`); detrás, el optimizador lo ignora y a > 1000 niveles de
      // anidación `checkMany` era `ERROR 3636` (503) donde `check` respondía.
      ` SELECT ${meta.hint}DISTINCT r.${q('object_type')} AS object_type, r.${q('object_uuid')} AS object_uuid, ` +
      `r.${q('relation')} AS relation ` +
      `FROM ${q(RELATIONS_TABLE)} r ` +
      `JOIN principal p ON r.${q('subject_type')} = p.p_type AND r.${q('subject_uuid')} = p.p_uuid ` +
      `AND COALESCE(r.${q('subject_relation')}, '') = p.p_rel ` +
      `WHERE r.${q('partition_key')} = ? AND (${groups.join(' OR ')}) AND ${this.#activeSql(q, 'r')}`
    const bindings = [...cteBindings, partitionKey, ...groupBindings, at]
    const rows = rowsOf(await this.#raw(operation, sql, bindings))
    const facts = new Map<string, string[]>()
    for (const row of rows) {
      const key = `${row.object_type}:${row.object_uuid}`
      const list = facts.get(key) ?? []
      list.push(String(row.relation))
      facts.set(key, list)
    }
    return { distinct, index, facts }
  }

  async listObjects(
    subject: RelSubject,
    relation: string,
    objectType: string,
    partition: ScopeRef,
    _page?: RelationPage
  ): Promise<RelationObjectsPage> {
    assertRelationDeclared(this.#config, { type: objectType }, relation)
    assertPartition(partition)
    this.#assertId('el tipo de objeto', objectType, RELATION_ID_MAX)
    const partitionKey = this.#keyOf(partition)
    const s = this.#subjectColumns(subject, partitionKey)
    // Lote D · D-15: `listObjects` RESTA (la misma regla de corte que `check`, objeto a objeto).
    const relations = this.#readRelations(objectType, relation)
    const meta = this.#dialectMeta()
    const q = (name: string) => `${meta.quote}${name}${meta.quote}`

    const at = this.#expiry.bind(this.#now())
    const { cte, bindings: cteBindings } = this.#principalCte(meta, q, s, partitionKey, at)
    const relPlaceholders = relations.map(() => '?').join(', ')
    const sql =
      cte +
      ` SELECT ${meta.hint}DISTINCT r.${q('object_uuid')} AS ${q('object_uuid')}, r.${q('relation')} AS ${q('relation')} ` +
      `FROM ${q(RELATIONS_TABLE)} r ` +
      `JOIN principal p ON r.${q('subject_type')} = p.p_type AND r.${q('subject_uuid')} = p.p_uuid ` +
      `AND COALESCE(r.${q('subject_relation')}, '') = p.p_rel ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = ? ` +
      `AND r.${q('relation')} IN (${relPlaceholders}) AND ${this.#activeSql(q, 'r')}`
    const bindings = [...cteBindings, partitionKey, objectType, ...relations, at]
    const rows = rowsOf(await this.#raw('listObjects', sql, bindings))
    const byObject = new Map<string, string[]>()
    for (const row of rows) {
      const id = String(row.object_uuid)
      const list = byObject.get(id) ?? []
      list.push(String(row.relation))
      byObject.set(id, list)
    }
    const objects: RelObject[] = [...byObject]
      .filter(([, rels]) => {
        const { allowed, denied } = this.#split(rels)
        return cutPathAllows(this.#config, objectType, relation, allowed, denied)
      })
      .map(([id]): RelObject => ({ type: objectType, id }))
      .sort((a: RelObject, b: RelObject) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
    return { objects }
  }

  async listSubjects(
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    _page?: RelationPage
  ): Promise<RelationSubjectsPage> {
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertObject(object)
    return this.#directSubjects('listSubjects', relation, object, partition, _page)
  }

  /** Los sujetos DIRECTOS vigentes de UNA relación almacenada (`listSubjects`; `listDenies` con `denied_<rel>`). */
  async #directSubjects(
    operation: string,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    _page?: RelationPage
  ): Promise<RelationSubjectsPage> {
    const partitionKey = this.#keyOf(partition)
    // DIRECTOS del relation EXACTO (invariante 7): ni transitivo (eso es
    // `membersOf`) ni derivado por includes. `usersetSubjects: true` ⇒ los
    // usersets (`group#member`) salen junto con los holders. Solo VIGENTES (R-15).
    const now = this.#now()
    const rows: any[] = await this.#sql(operation, () =>
      this.#whereActive(
        this.#connection()
          .from(RELATIONS_TABLE)
          .where('partition_key', partitionKey)
          .where('object_type', object.type)
          .where('object_uuid', object.id)
          .where('relation', relation),
        now
      ).select('subject_type', 'subject_uuid', 'subject_relation')
    )
    const subjects: RelSubject[] = rows.map((row: any) => this.#rowToSubject(row))
    return { subjects }
  }

  /**
   * **`listDenies`** (lote D · D1): los sujetos con deny DIRECTO de `relation` sobre `object` —hechos, como
   * `listSubjects` sobre la relación almacenada `denied_<rel>`; no resta ni deriva—. Sobre CUALQUIER tipo declarado
   * (D8/R2-4 b: con el opt-in retirado, los denies vivos se siguen pudiendo listar y borrar).
   */
  async listDenies(relation: string, object: RelObject, partition: ScopeRef, page?: RelationPage): Promise<RelationSubjectsPage> {
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertObject(object)
    return this.#directSubjects('listDenies', deniedRelationOf(relation), object, partition, page)
  }

  /**
   * **`denyPhase` — ¿admite este driver escrituras de deny en el tipo?** (lote D · D2, R2-5): la fase del opt-in EN
   * LA CONFIG DE ESTE DRIVER (`'write'`, `'read'` o `null`). F-05 estricto del par (422), cero sentencias: es
   * configuración. La llama `reconcileRelations` en la fase de plan cuando el origen trae denies.
   */
  async denyPhase(object: { type: string }, relation: string): Promise<'read' | 'write' | null> {
    assertRelationDeclared(this.#config, object, relation)
    return denyPhaseOf(this.#config, object.type) ?? null
  }

  /**
   * Membresía TRANSITIVA de un objeto-grupo: todos los HOLDERS que son `member`
   * directa o a través de grupos anidados (usersets `group#member`). CTE
   * recursiva hacia ABAJO por los usersets. DISTINTA de `listSubjects` (hechos
   * directos): en un grupo con `member(g1#member, g2)`, `membersOf(g2)` trae a
   * los holders de g1 y `listSubjects(member, g2)` solo el userset `g1#member`.
   */
  async membersOf(
    object: RelObject,
    relation: string,
    partition: ScopeRef,
    _page?: RelationPage
  ): Promise<RelationSubjectsPage> {
    // Cierre-2 · 🟡 3: F-05 (par, ESTRICTA) también en `membersOf`, la octava
    // operación del puerto; antes solo `#assertObject` (gramática).
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertObject(object)
    const partitionKey = this.#keyOf(partition)
    const relations = this.#expandDown(object.type, relation)
    const meta = this.#dialectMeta()
    const q = (name: string) => `${meta.quote}${name}${meta.quote}`
    const relPlaceholders = relations.map(() => '?').join(', ')
    const at = this.#expiry.bind(this.#now())
    const active = this.#activeSql(q, 'r')

    // `grp`: los grupos alcanzables por usersets desde (object, RS) —directos y
    // anidados—. Ancla de UN solo SELECT (MySQL no mezcla UNION ALL con la
    // recursión): los usersets directos del objeto para cualquier rel de RS.
    // Solo hechos VIGENTES en los cuatro tramos (R-15): una membresía caducada
    // no lleva a nadie dentro.
    const sql =
      `WITH RECURSIVE grp(g_uuid) AS ( ` +
      `SELECT r.${q('subject_uuid')} FROM ${q(RELATIONS_TABLE)} r ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = ? AND r.${q('object_uuid')} = ? ` +
      `AND r.${q('relation')} IN (${relPlaceholders}) AND r.${q('subject_type')} = '${GROUP_TYPE}' ` +
      `AND r.${q('subject_relation')} = '${GROUP_MEMBER}' AND ${active} ` +
      `UNION ` +
      `SELECT r.${q('subject_uuid')} FROM ${q(RELATIONS_TABLE)} r ` +
      `JOIN grp ON r.${q('object_uuid')} = grp.g_uuid ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = '${GROUP_TYPE}' ` +
      `AND r.${q('relation')} = '${GROUP_MEMBER}' AND r.${q('subject_type')} = '${GROUP_TYPE}' ` +
      `AND r.${q('subject_relation')} = '${GROUP_MEMBER}' AND ${active} ` +
      `) ` +
      // Holders directos del objeto para RS, UNION holders directos de cualquier grupo de `grp`.
      `SELECT ${meta.hint}${q('subject_type')} AS ${q('subject_type')}, ${q('subject_uuid')} AS ${q('subject_uuid')} ` +
      `FROM ${q(RELATIONS_TABLE)} r ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = ? AND r.${q('object_uuid')} = ? ` +
      `AND r.${q('relation')} IN (${relPlaceholders}) AND COALESCE(r.${q('subject_relation')}, '') = '' AND ${active} ` +
      `UNION ` +
      `SELECT r.${q('subject_type')}, r.${q('subject_uuid')} FROM ${q(RELATIONS_TABLE)} r ` +
      `JOIN grp ON r.${q('object_uuid')} = grp.g_uuid ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = '${GROUP_TYPE}' ` +
      `AND r.${q('relation')} = '${GROUP_MEMBER}' AND COALESCE(r.${q('subject_relation')}, '') = '' AND ${active}`
    const bindings = [
      // grp ancla
      partitionKey, object.type, object.id, ...relations, at,
      // grp recursiva
      partitionKey, at,
      // holders directos del objeto
      partitionKey, object.type, object.id, ...relations, at,
      // holders de los grupos
      partitionKey, at,
    ]
    const rows = rowsOf(await this.#raw('membersOf', sql, bindings))
    const candidates: SubjectRef[] = rows.map(
      (row: any): SubjectRef => ({ type: String(row.subject_type), uuid: String(row.subject_uuid) })
    )
    // **Lote D · `membersOf` RESTA** (juez ronda 2: «listObjects y membersOf restan»; D8: siempre, con o sin opt-in).
    // Si el objeto tiene alguna fila `denied_*` vigente, cada candidato se juzga con `check` —el MISMO corte de camino
    // que el resto de lecturas, un `check` por candidato—; sin filas deny, cero consultas de más (la respuesta y el coste
    // de 2.4.0-alpha.10). Coste declarado: O(miembros) consultas cuando el objeto tiene denies.
    const denied: unknown[] = await this.#sql('membersOf.denies', () =>
      this.#whereActive(
        this.#connection()
          .from(RELATIONS_TABLE)
          .where('partition_key', partitionKey)
          .where('object_type', object.type)
          .where('object_uuid', object.id)
          .whereIn('relation', deniableAbove(this.#config, object.type, relation).map(deniedRelationOf)),
        this.#now()
      )
        .select('uuid')
        .limit(1)
    )
    if (denied.length === 0) return { subjects: candidates }
    // **Cierre 1 de D1 · 🟡 4 del auditor**: con deny, N `check` en serie sin cota ni deadline total era una
    // amplificación barata para quien puede escribir un deny (disponibilidad, no concesión). Cota DECLARADA
    // (`RELATIONS_MEMBERS_DENY_CHECK_MAX`, «Limits» del README) ⇒ 500 ANTES del primer `check`, nunca una lista parcial;
    // y deadline TOTAL sobre el bucle (`timeoutMs` del driver) ⇒ 503 `E_AUTHZ_BACKEND_TIMEOUT`, el bucle se para.
    if (candidates.length > RELATIONS_MEMBERS_DENY_CHECK_MAX) {
      throw new MembersOfDenyLimitError(
        `membersOf(${object.type}, '${relation}'): el objeto tiene un deny vigente y ${candidates.length} candidatos; con deny ` +
          `cada candidato se juzga con un check y la cota es ${RELATIONS_MEMBERS_DENY_CHECK_MAX} ` +
          `(RELATIONS_MEMBERS_DENY_CHECK_MAX). No se devuelve una lista parcial: pregunta check por sujeto, o retira el deny.`
      )
    }
    let expired = false
    const loop = (async () => {
      const subjects: RelSubject[] = []
      for (const candidate of candidates) {
        if (expired) break
        if (await this.check(candidate, relation, object, partition)) subjects.push(candidate)
      }
      return subjects
    })()
    const subjects = await withDeadline(loop, this.#timeoutMs, () => {
      expired = true
      return new AuthorizationBackendTimeoutError('database-relations', 'membersOf', this.#timeoutMs)
    })
    return { subjects }
  }

  /* ── Purga (invariante 11): el DELETE demuestra el cero ───────────────── */

  async purgeObject(object: RelObject, partition: ScopeRef, options?: RelationTransactionOptions): Promise<void> {
    // alpha.3 · F-05 (solo el TIPO: una purga no nombra relación), PRIMERA línea.
    // Cierre-2: la función de TIPO, no la estricta con relación opcional.
    assertObjectTypeDeclared(this.#config, object)
    assertPartition(partition)
    this.#assertObject(object)
    const key = partitionKey(partition)
    // L-4: por la transacción del llamante si llegó — la purga borra y
    // REVIERTE con ella (tras un rollback todo lo purgado está de vuelta).
    const { client, external } = this.#writer('purgeObject', options)
    try {
      await this.#sql('purgeObject', () =>
        client
          .from(RELATIONS_TABLE)
          .where('partition_key', key)
          .where('object_type', object.type)
          .where('object_uuid', object.id)
          .delete()
      )
    } catch (error) {
      if (external) this.#poisoned('purgeObject', error)
      throw error
    }
  }

  async purgeSubject(subject: RelSubject, partition: ScopeRef, options?: RelationTransactionOptions): Promise<void> {
    // alpha.3 · F-05 del USERSET (una purga por sujeto no nombra objeto), PRIMERA línea.
    if (isRelUserset(subject)) assertRelationDeclared(this.#config, subject.object, subject.relation)
    assertPartition(partition)
    const key = partitionKey(partition)
    const s = this.#subjectColumns(subject, key)
    const { client, external } = this.#writer('purgeSubject', options)
    try {
      await this.#sql('purgeSubject', () =>
        client
          .from(RELATIONS_TABLE)
          .where('partition_key', key)
          .where('subject_type', s.type)
          .where('subject_uuid', s.uuid)
          .where((b: any) => this.#whereSubjectRelation(b, s.relation))
          .delete()
      )
    } catch (error) {
      if (external) this.#poisoned('purgeSubject', error)
      throw error
    }
  }

  /* ── ORIGEN de reconcile (4-5): enumera los hechos directos ───────────── */

  /**
   * **`enumerateRelations` — el ORIGEN de `authz:reconcile` de relaciones**
   * (4-5). Devuelve los hechos DIRECTOS de la partición (`authz_relations`),
   * paginados por la PK (`uuid`, cursor que AVANZA), sin derivar por
   * includes/usersets (el modelo del destino lo recompone): el destino recibe
   * los hechos tal cual y decide qué escribe (invariante 7 + la higiene de
   * reconcile — **la caducada LLEGA con su `expiresAt`**, R-15, para contarse
   * en `skipped`; filtrarla aquí la haría desaparecer sin rastro). Hasta
   * 2.5.0 barría las DOS ortografías del uuid de partición (🟡2); desde D4
   * (plan 2.5 · lote A) la ortografía sin guiones es 422 en la puerta y las
   * filas viejas se canonizan con la receta del README, así que la clave es
   * una.
   *
   * **Filtra por TIPOS DECLARADOS** (⚪3, paridad con `openfga`): el driver
   * `openfga` descarta de su enumeración todo `object_type` que no sea `group`
   * ni un tipo de `defineRelationsConfig`; el de `database` NO lo hacía y
   * devolvía TODA fila. Como `reconcileRelations` escribe `to.relate(...)`
   * DIRECTO (salta el manager/F-05), una fila `object_type='role_binding'`
   * sembrada a mano habría migrado al store compartido y reabierto la escalada.
   * Con el filtro ambos drivers censan lo mismo y el chokepoint no deja residuo
   * por el camino de reconcile.
   */
  async enumerateRelations(partition: ScopeRef, page?: RelationPage): Promise<RelationTuplePage> {
    assertPartition(partition)
    const wanted = new Map<string, ScopeRef>()
    wanted.set(partitionKey(partition), partition)
    return this.#enumerateRows('enumerateRelations', wanted, page)
  }

  /**
   * **`enumerateRelationsMany` — K particiones en UNA consulta** (2.4.0-alpha.8
   * · C1; panel relay 2, analista §8, juez 7.1). El mismo SELECT que
   * `enumerateRelations` con `partition_key IN (todas las ortografías de
   * todas las particiones)`, orden total por `uuid` y el mismo cursor
   * (estable: reanudar con él ve cada tupla exactamente una vez, sea cual
   * sea K). Cada tupla viene con la partición PEDIDA a la que pertenece: la
   * primera referencia de cada clave es la que viaja en `tuple.partition`
   * (desde D4, plan 2.5 · lote A, la ortografía sin guiones es 422: una
   * partición es UNA clave). Sin particiones es 500 con
   * cero consultas (paridad con `openfga`: un barrido para nadie no es un
   * éxito vacío). Hasta alpha.7 el manager caía a su respaldo —K consultas y
   * un cursor que perdía tuplas al reanudar (C2)—; sin capacidad nueva: con
   * los dos drivers publicados nativos y el respaldo ruidoso, no hay nada que
   * declarar.
   */
  async enumerateRelationsMany(partitions: ScopeRef[], page?: RelationPage): Promise<RelationTuplePage> {
    if (!Array.isArray(partitions) || partitions.length === 0) {
      throw new AuthorizationConfigError(
        'enumerateRelationsMany: sin particiones no hay nada que enumerar (y una consulta para nadie no es un éxito vacío). ' +
          'Pasa al menos una partición.'
      )
    }
    const wanted = new Map<string, ScopeRef>()
    for (const partition of partitions) {
      const key = partitionKey(partition)
      if (!wanted.has(key)) wanted.set(key, partition)
    }
    return this.#enumerateRows('enumerateRelationsMany', wanted, page)
  }

  /**
   * La consulta de `enumerateRelations`/`enumerateRelationsMany`: los hechos
   * directos de las claves de partición pedidas, filtrados por tipos
   * declarados, ordenados por `uuid` y paginados (`limit + 1` para saber si
   * hay más; el cursor es el último `uuid` de la página). `wanted` mapea cada
   * clave (ortografía) a la partición PEDIDA que viaja en la tupla.
   */
  async #enumerateRows(operation: string, wanted: Map<string, ScopeRef>, page?: RelationPage): Promise<RelationTuplePage> {
    const partitionKeys = [...wanted.keys()]
    const declaredTypes = [GROUP_TYPE, ...this.#config.objectTypes.map((t) => t.type)]
    const limit = Math.max(1, Math.min(page?.limit ?? DEFAULT_ENUMERATE_LIMIT, MAX_ENUMERATE_LIMIT))
    const after = page?.after
    const rows: RelationRow[] = await this.#sql(operation, () => {
      let q = this.#connection()
        .from(RELATIONS_TABLE)
        .whereIn('partition_key', partitionKeys)
        .whereIn('object_type', declaredTypes)
        .orderBy('uuid', 'asc')
        .limit(limit + 1)
      if (after) q = q.where('uuid', '>', after)
      return q.select(
        'uuid',
        'partition_key',
        'object_type',
        'object_uuid',
        'relation',
        'subject_type',
        'subject_uuid',
        'subject_relation',
        this.#expiry.select('expires_at')
      )
    })
    const hasMore = rows.length > limit
    const pageRows = hasMore ? rows.slice(0, limit) : rows
    const tuples: RelationTuple[] = pageRows.map((row) => ({
      subject: this.#rowToSubject(row),
      // Lote D · D2: `denied_<rel>` sale como `{ relation: <rel>, kind: 'deny' }` (punto de paso único,
      // `storedRelationKind`); hasta D2 salía la relación almacenada y el reconcile la contaba como no declarada.
      ...storedRelationKind(String(row.relation)),
      object: { type: String(row.object_type), id: String(row.object_uuid) },
      // La partición canónica PEDIDA: el barrido de ortografías ya la unificó.
      partition: wanted.get(String(row.partition_key))!,
      expiresAt: this.#expiry.fromDb(row.expires_at),
    }))
    const cursor = hasMore ? String(pageRows[pageRows.length - 1].uuid) : undefined
    return cursor ? { tuples, cursor } : { tuples }
  }

  /* ── Helpers privados ─────────────────────────────────────────────────── */

  /**
   * La CTE `principal`: el conjunto de identidades `(p_type, p_uuid, p_rel)` que
   * el SUJETO «es» —él mismo (holder ⇒ `p_rel = ''`; userset ⇒ su relación) más
   * cada `group#member` del que es miembro, transitivamente (grupos anidados)—.
   * Un `check`/`listObjects` casa un hecho directo del objeto contra cualquiera
   * de esas identidades. Devuelve el `WITH RECURSIVE …` (sin el SELECT final) y
   * sus bindings.
   */
  #principalCte(
    meta: DialectMeta,
    q: (name: string) => string,
    s: { type: string; uuid: string; relation: string },
    partitionKey: string,
    at: unknown
  ): { cte: string; bindings: unknown[] } {
    // L-4b: el holder ya viene con `''`; el `COALESCE(subject_relation, '')`
    // del JOIN es la tolerancia a una fila vieja con NULL.
    const baseRel = s.relation
    // Solo membresías VIGENTES suben por la recursión (R-15): una `member`
    // caducada no convierte al sujeto en miembro de nada.
    const cte =
      `WITH RECURSIVE principal(p_type, p_uuid, p_rel) AS ( ` +
      `SELECT ${meta.text('?')}, ${meta.text('?')}, ${meta.text('?')} ` +
      `UNION ` +
      `SELECT ${meta.text(`'${GROUP_TYPE}'`)}, r.${q('object_uuid')}, ${meta.text(`'${GROUP_MEMBER}'`)} ` +
      `FROM ${q(RELATIONS_TABLE)} r ` +
      `JOIN principal p ON r.${q('subject_type')} = p.p_type AND r.${q('subject_uuid')} = p.p_uuid ` +
      `AND COALESCE(r.${q('subject_relation')}, '') = p.p_rel ` +
      `WHERE r.${q('partition_key')} = ? AND r.${q('object_type')} = '${GROUP_TYPE}' ` +
      `AND r.${q('relation')} = '${GROUP_MEMBER}' AND ${this.#activeSql(q, 'r')} )`
    return { cte, bindings: [s.type, s.uuid, baseRel, partitionKey, at] }
  }

  /** `''` (L-4b) o NULL (fila vieja sin backfill) ⇒ holder; con valor ⇒ userset. */
  #rowToSubject(row: any): RelSubject {
    if (row.subject_relation === null || row.subject_relation === undefined || row.subject_relation === HOLDER_RELATION) {
      return { type: String(row.subject_type), uuid: String(row.subject_uuid) }
    }
    return { object: { type: String(row.subject_type), id: String(row.subject_uuid) }, relation: String(row.subject_relation) }
  }
}

/**
 * Forma del resultado crudo por cliente: pg `{ rows }`, sqlite `rows[]`,
 * mysql2 `[rows[], fields[]]` (2.5 · J3).
 */
function rowsOf(result: any): any[] {
  if (Array.isArray(result)) {
    return result.length === 2 && Array.isArray(result[0]) && Array.isArray(result[1]) ? result[0] : result
  }
  return result?.rows ?? []
}
