/**
 * Driver `openfga` del puerto `RelationsDriver` — ReBAC sobre el MISMO store y
 * `modelId` que el driver `facts` de roles (Fase 4, lote 4-4).
 *
 * Store COMPARTIDO (decisión del dueño / juez §2): las relaciones ReBAC viven
 * en el modelo FUSIONADO (`facts` + `group` + los tipos de objeto del
 * consumidor), así que `relate`/`unrelate` son `Write`/delete de tuplas del
 * mismo store, `check` es UN solo `Check` (el modelo resuelve includes +
 * usersets del lado del servidor) y `list*` van por `ListObjects`/`Read`.
 *
 * **La partición va en el ID del objeto y del userset**, no en el modelo:
 * `document:<scopeKey(partition)>|<uuid>`, `group:<scopeKey(partition)>|<uuid>#member`.
 * El cruce de particiones se corta por comparación de string —aquí NO hay
 * trigger como en `database`, así que F-05 (en el manager) + la comparación de
 * string son la ÚNICA defensa de tenant—. El id lleva DOS `|` cuando la
 * partición es un scope no-raíz (`document:unit|<partUuid>|<objUuid>`), así que
 * el parseo es CANÓNICO desde la DERECHA (⚪5, el mismo cuidado que
 * `parseBindingId`): partición = todo menos el ÚLTIMO segmento; el id del
 * objeto es el último y no contiene `|`.
 *
 * **La frontera del 🔴 (F-05) NO vive aquí**: la cierra el `RelationsManager`
 * ANTES de tocar el driver (un `object.type` no declarado ⇒ 422) junto con ⚪4
 * (un tipo reservado no se puede declarar). Si a este driver se le llama en
 * DIRECTO con `object.type: 'role_binding'` (la salida `manager.driver()`, de
 * plataforma), compondría el id de un binding real y escalaría — por eso el
 * caso-exploit del auditor se cierra en el manager, y el runner publica el
 * caso para que un driver de terceros que no lo cumpla NO pase el contrato.
 *
 * Pureza: vive detrás del subpath `@jantstack/adonis-authz/openfga`
 * (`src/openfga.ts`), como el driver `facts` de roles: es lo único que puede
 * tocar `@openfga/sdk` (peer opcional). La abstracción no filtra: ningún error
 * del SDK escapa (todo va por `#guard`, que clasifica a 503/timeout).
 */
import {
  OpenFgaClient,
  ConsistencyPreference,
  ClientWriteRequestOnMissingDeletes,
  ClientWriteRequestOnDuplicateWrites,
} from '@openfga/sdk'
import type { ClientBatchCheckItem, ConsistencyPreference as ConsistencyPreferenceType } from '@openfga/sdk'
import {
  AuthorizationBackendError,
  AuthorizationBackendTimeoutError,
  AuthorizationConfigError,
  InvalidIdentityError,
  PurgeIncompleteError,
  RenewalRacedError,
  RenewalUnsafeError,
  UnsupportedOperationError,
  markPartialWrite,
} from '../errors.js'
import { assertPartition, assertSubject, assertRelationId, assertExpiresAt, partitionKey } from '../identity.js'
import { isClock, systemClock } from '../clock.js'
import type { Clock } from '../clock.js'
import { isActiveExpiry, resolveGrantExpiry, sameInstant, toExpiryDate } from '../expiry.js'
import { isRelUserset } from '../types.js'
import type {
  RelObject,
  RelSubject,
  RelationObjectsPage,
  RelationSubjectsPage,
  RelationPage,
  RelationTuple,
  RelationTuplePage,
  RelationsDriver,
  RelationsDriverCapabilities,
  RelationTransactionOptions,
  RelationWriteOptions,
  RelationDenyOptions,
  RelationDecision,
  ScopeRef,
  SubjectRef,
} from '../types.js'
import type { HolderTypeMap } from './openfga_driver.js'
import { alignBatchResults } from './openfga_driver.js'
import { FGA_MAX_BATCH_CHECK, canonicalRewrite, factsRelationRewrites } from './openfga_facts.js'
import { assertCheckManyObjects, distinctObjects, expandByPosition } from '../relations/check_many.js'
import {
  assertFgaObjectId,
  FACTS_EXPIRY_CONDITION,
  FACTS_GROUP_TYPE,
  FACTS_GROUP_MEMBER_RELATION,
} from './openfga_facts.js'
import {
  assertRelationDeclared,
  assertObjectTypeDeclared,
  assertUsersetSubject,
  assertRelationDenyable,
  assertDenySubject,
  assertDenyNoExpiry,
  denyPhaseOf,
  deniedRelationOf,
  storedRelationKind,
  hasDenyTypes,
  relationsDown,
  RELATION_DENY_PREFIX,
  RELATION_USERSET_RELATION,
  RELATION_USERSET_TYPE,
} from '../relations/define_relations_config.js'
import { relationDeleteOrder, relationOrderClass } from '../relations/tuple_order.js'
import type { RelationOrderView } from '../relations/tuple_order.js'
import { isServerWriteLimit, isTimeoutLike, withDeadline } from '../shared/backend_guard.js'
import type { RelationsConfig } from '../relations/define_relations_config.js'

export const DEFAULT_TIMEOUT_MS = 5_000
/**
 * **Tope de operaciones por `Write` en FGA** — `--max-tuples-per-write` del servidor, default 100. MEDIDO en v1.19.0
 * (`openfga-dev`, lote D · cierre 1 de D1): 100 deletes en un `Write` entran; 101 —o 50 writes + 51 deletes— es 400
 * «The number of write operations exceeds the allowed limit of 100» y NO se aplica nada (el `Write` es transaccional).
 * Es también la frontera de la purga atómica (`#purgeByFilters`): una purga que cabe aquí es UN `Write`, sin estado
 * intermedio; con más membresías de grupo que esto, el residuo es una fila DECLARADA (README, «Deny on relations»).
 * **Requisito del despliegue: `--max-tuples-per-write` ≥ 100** (README, «Limits»). Un servidor con el tope MÁS BAJO
 * responde 400 `exceeded_entity_limit` al primer `Write` que lo pase, y ése puede no ser el primero de la purga (con
 * tope 50 y `[3 allows][60 membresías][40 denies]` el `Write` de 3 ya se aplicó): el driver lo dice como **500
 * `E_AUTHZ_CONFIG`** nombrando el requisito —no como un 503 que parece transitorio: repetida, la purga vuelve a pedir
 * un `Write` de más de lo que el servidor admite y no termina nunca— y, si ya borró algo, **marcado como escritura
 * parcial** (`indeterminate: true`, invariante 13). Cierre 2 de D1 · ⚪ N3 del auditor (la letra anterior, «503 sin
 * haber borrado nada», era falsa con varios `Write`). Uno con el tope más alto no cambia nada (el driver sigue partiendo
 * en 100). Sin opción para bajarlo: la cota es del servidor y el remedio es su arranque.
 */
export const RELATIONS_PURGE_WRITE_MAX = 100
/** Tamaño de página de `Read` (máximo del servidor). */
const READ_PAGE_SIZE = 100
/**
 * Cota de páginas de una enumeración por `Read`. Un `continuation_token` que
 * no avanza (servidor roto, proxy, caché) sería un bucle que ningún deadline
 * corta (el deadline es por llamada). Mismo patrón que el driver de roles.
 */
const MAX_READ_PAGES = 10_000
/**
 * El tope de `ListObjects` del servidor por defecto (`OPENFGA_LIST_OBJECTS_MAX_RESULTS`).
 * `ListObjects` NO devuelve señal de truncado ni `continuation_token`: corta al
 * tope y calla. La única forma honesta de detectar el corte es comparar el
 * número de resultados con el tope CONFIGURADO del servidor —de ahí la opción
 * `listObjectsMaxResults`—: si vuelven `>= tope`, no se puede prometer que la
 * lista esté completa ⇒ `truncated: true` (lección S16/L0.7: nunca una lista
 * parcial MUDA). Ponerlo por debajo del tope real del servidor daría un
 * truncado FALSO (el servidor devolvió todo); por encima, se perdería el corte.
 */
const DEFAULT_LIST_OBJECTS_MAX = 1_000
/**
 * **B4 (plan 2.5 · lote B): el corte EFECTIVO de `ListObjects` del servidor**.
 * Pasado, el servidor devuelve lo que llevaba resuelto con 200 y SIN señal
 * (analista M4, medido): la segunda forma —además del tope— de una lista
 * parcial muda. El driver mide cada llamada con un reloj MONÓTONO y, si duró
 * ≥ `LIST_OBJECTS_DEADLINE_RATIO` × el corte configurado, señala
 * `truncated: true` (la MISMA señal que el tope). **El corte efectivo es el
 * MENOR de dos** (cierre 2 del lote B · 🟠 N1, medido por el auditor contra
 * OpenFGA v1.19.0): `--listObjects-deadline` (3 s por defecto) si ≠ 0 y, si es
 * 0, `--request-timeout` (3 s por defecto) — `list_objects.go` solo pone su
 * propio timeout cuando el deadline ≠ 0 y, si no, hereda el ctx del
 * interceptor de `--request-timeout`, que corta igual con un 200 mudo (con
 * `--request-timeout=30ms`: `200 objects 0 of 40000`). «Sin deadline» no
 * existe: el servidor siempre corta en alguno. **El corte efectivo es el MENOR
 * de `--listObjects-deadline` (si ≠ 0), `--request-timeout` y, por HTTP,
 * `--http-upstream-timeout` (5 s por defecto en el gateway)** (⚪ N10, cierre 3
 * del lote B: el tercer corte, no medido para `ListObjects`, también cuenta);
 * declara ESE menor en `listObjectsDeadlineMs` — y nunca por encima del
 * `timeoutMs` del cliente: la señal tiene que poder saltar antes de que el
 * cliente corte (500 al construir si no).
 */
export const DEFAULT_LIST_OBJECTS_DEADLINE_MS = 3_000
export const LIST_OBJECTS_DEADLINE_RATIO = 0.9

/**
 * **SOLO TESTS** (⚪ 9 del cierre 1 del lote B): la clave —un símbolo— bajo la que
 * un test inyecta la fuente del reloj MONÓTONO en ms con el que `#listObjectsPage`
 * mide cada `ListObjects` (default `performance.now`). Fuera del tipo publicado
 * `OpenFgaRelationsDriverOptions` y NO re-exportada por `/openfga`: un
 * `monotonic: () => 0` en producción apagaría la señal del deadline, y una opción
 * con ese poder no viaja en la superficie pública. No es el reloj de pared
 * (`now`, que decide la caducidad): una ventana se mide con un reloj que no
 * salta (2E · H3), y así el caso del deadline corre sin `sleep`.
 */
export const MONOTONIC_CLOCK: unique symbol = Symbol('OpenFgaRelationsDriver.monotonic')

/**
 * Ignora duplicados en el `Write` de una tupla que NO estaba (idempotencia de
 * dos `relate` concurrentes idénticos). Cambiar la caducidad de una que SÍ
 * está es delete+write (R-15): FGA no admite reescribir la condición de una
 * tupla existente y un `Ignore` la dejaría con la caducidad vieja en silencio.
 */
const IGNORE_DUPLICATE_WRITES = {
  conflict: { onDuplicateWrites: ClientWriteRequestOnDuplicateWrites.Ignore },
}
/** Ignora deletes de tuplas ya ausentes (re-unrelate no-op seguro, invariante 6). */
const IGNORE_MISSING_DELETES = {
  conflict: { onMissingDeletes: ClientWriteRequestOnMissingDeletes.Ignore },
}

export interface OpenFgaRelationsDriverOptions {
  apiUrl: string
  storeId: string
  /** Pin del model FUSIONADO; si se omite, FGA usa el último del store. */
  modelId?: string
  /** Holders del consumidor: morph name → tipo FGA. El MISMO mapa del driver de roles. */
  holderTypes: HolderTypeMap
  /** Deadline de cada llamada en ms (default 5000): vencido ⇒ 503. */
  timeoutMs?: number
  /** Consistencia pedida al servidor (default `higher_consistency`, como el driver de roles). */
  consistency?: 'higher_consistency' | 'minimize_latency'
  /**
   * El tope de `ListObjects` del servidor (`OPENFGA_LIST_OBJECTS_MAX_RESULTS`).
   * Default 1000 (el default de OpenFGA). Cuando `listObjects` recibe `>= este`
   * resultados, señala `truncated: true`. Ponlo igual que el del servidor.
   */
  listObjectsMaxResults?: number
  /**
   * **El corte EFECTIVO de `ListObjects` del servidor** (default 3 000 ms =
   * `DEFAULT_LIST_OBJECTS_DEADLINE_MS`; B4). Una llamada que dure ≥ 0,9 × este
   * valor (`LIST_OBJECTS_DEADLINE_RATIO`) se señala `truncated: true`: pasado
   * su corte el servidor responde 200 con la lista parcial y sin señal. **Es
   * el MENOR de `--listObjects-deadline` (si ≠ 0) y `--request-timeout`**
   * (cierre 2 del lote B · 🟠 N1, medido por el auditor contra OpenFGA v1.19.0:
   * con `--listObjects-deadline=0` el `--request-timeout`, 3 s por defecto,
   * sigue cortando con un 200 mudo — `0` NO es «sin deadline»). Entero > 0;
   * `Infinity` (la receta del cierre 1 para el deadline 0), `NaN`, ≤ 0 o no
   * entero ⇒ 500 `E_AUTHZ_CONFIG` al construir: el servidor siempre corta en
   * alguno de los dos y una lista muda es justo lo que B4 existe para impedir.
   * `0` es el valor del SERVIDOR, no del driver (aquí significaría «todo
   * truncado»). **El corte efectivo es el MENOR de los TRES**: `--listObjects-deadline`
   * (si ≠ 0), `--request-timeout` y, por HTTP, `--http-upstream-timeout` (5 s por
   * defecto en el gateway; ⚪ N10, cierre 3 del lote B): declara ese menor. Los
   * DOS primeros a 0 no se soportan: lo que hace entonces el gateway no está
   * medido para `ListObjects`, y el paquete no promete «sin deadline» sobre
   * nada que no haya medido. **Y nunca por encima de `timeoutMs`** (el deadline
   * del cliente, 5 s por defecto): la señal tiene que poder saltar antes de que
   * el cliente corte, así que `listObjectsDeadlineMs > timeoutMs` es 500 al
   * construir (`Number.MAX_SAFE_INTEGER` era «sin deadline» con otro nombre).
   */
  listObjectsDeadlineMs?: number
  /** Dónde avisar de tuplas del store que el driver no puede parsear. */
  logger?: { warn(message: string): void }
  /**
   * Reloj de pared que DECIDE la caducidad (R-15, 2.5 · J1): el `current_time`
   * de cada `Check`/`ListObjects` (la condición `not_expired` se evalúa contra
   * él), el filtro en cliente de `listSubjects` y los tres estados de
   * `expiresAt` en `relate`. Default `systemClock`; en producción lo aplica el
   * `RelationsManager` con `clock` (`withClock`).
   */
  now?: Clock
}

/** Una tupla leída del store: la clave y, si la lleva, su caducidad (`valid_until`). */
interface StoredRelationTuple {
  user: string
  relation: string
  object: string
  validUntil: Date | null
}

export class OpenFgaRelationsDriver implements RelationsDriver {
  /**
   * Lo que declara (cada valor tiene su cara en `runRelationsDriverContract`):
   *  - `singleCheckRelations: true`: `check` es UN solo `Check` (el modelo
   *    resuelve includes + usersets del lado del servidor).
   *  - `listObjectsInherited: false`: `list*` no abren el subárbol de
   *    particiones (invariante 7); `ListObjects` sí resuelve la derivación del
   *    modelo (includes/usersets), que es «directos + derivados», no herencia
   *    de scopes.
   *  - `usersetSubjects: true`: `listSubjects` (`Read`) trae los usersets
   *    directos (`group#member`) junto con los holders.
   *  - `membersOfNative: false`: la membresía TRANSITIVA sería `ListUsers`, que
   *    trunca al tope del servidor; se declara 500 `E_AUTHZ_UNSUPPORTED`, jamás
   *    un userset enumerado a medias (par de `purgeRole` de la 3b).
   *  - `enumerateRelations: true` (4-5): es ORIGEN de `authz:reconcile` de
   *    relaciones — lee el store ENTERO (`Read({})`, la única forma de ver todo
   *    sin filtro por user u objeto: un `Read` por tipo-solo sin user es un 400)
   *    y devuelve SOLO las tuplas de relación de la partición (tipo declarado o
   *    `group`), descartando las de `facts` (scope/role/role_binding).
   *  - `listObjectsTruncation: true`: `ListObjects` trunca al tope del servidor
   *    y este driver lo SEÑALA (medido contra el `:8103` de tope 3) — y desde
   *    B4 (plan 2.5) también cuando la llamada roza el DEADLINE del servidor
   *    (≥ 0,9 × `listObjectsDeadlineMs`), la otra forma de lista parcial muda.
   *  - `injectableClock: true` (R-15): `withClock(now)` fija el reloj que viaja
   *    como `current_time` y filtra `listSubjects`, como el driver de roles.
   */
  readonly capabilities: RelationsDriverCapabilities = Object.freeze({
    singleCheckRelations: true,
    listObjectsInherited: false,
    usersetSubjects: true,
    membersOfNative: false,
    enumerateRelations: true,
    listObjectsTruncation: true,
    injectableClock: true,
    // Lote D · D1: el deny es la relación `denied_<rel>` del modelo fusionado (`X = … but not denied_X`); el corte lo
    // evalúa el SERVIDOR en `check`/`batchCheck`/`ListObjects` (una lista cortada es un subconjunto: fail-closed).
    relationDenies: true,
    // Cierre 2 de D2 · 🟠 N1: `false` EXPLÍCITO — FGA no reemplaza la misma clave en un `Write` (M5): `relate` renueva
    // con DOS (delete, write). Por eso NIEGA renovar una membresía que transporta un deny (409
    // `E_AUTHZ_RENEWAL_UNSAFE`, cero escrituras) y marca parcial la renovación permitida cuyo 2.º `Write` falla.
    atomicRenewal: false,
    // L-2/L-5 (panel `{trx}`, (C)): `false` EXPLÍCITO, y no puede ser otra
    // cosa — una tupla no entra en una transacción SQL: el store es otro
    // servicio y no hay 2PC, así que «los dos o ninguno» con la transacción
    // del consumidor es una promesa que este driver no puede hacer, y no la
    // hace. `{ transaction }` es 500 `E_AUTHZ_UNSUPPORTED` por llamada, en el
    // `RelationsManager` (puerta 1) Y en el driver (`#rejectTransaction`,
    // para quien entre por `manager.driver()` o por `reconcileRelations`),
    // con CERO llamadas al store (L-5 lo fija contra el `:8101` con espía
    // sobre el cliente). La alternativa que SÍ existe es para el ÁRBOL de
    // scopes: `scopes.outbox` encola en tu transacción y `authz:scopes:relay`
    // aplica. Para las RELACIONES no hay outbox (el panel la descartó:
    // fail-open medido durante el lag); el consumidor lee esta capacidad y
    // ajusta (usa `database` para lo que tenga que ir en su transacción, o
    // `requireTransactionalWrites` para fallar al arrancar).
    transactionalWrites: false,
  })

  private readonly client!: OpenFgaClient
  readonly #config: RelationsConfig
  readonly #options: OpenFgaRelationsDriverOptions
  readonly #now: Clock
  readonly #holderTypes: HolderTypeMap
  readonly #fgaToMorph: Record<string, string>
  readonly #timeoutMs: number
  readonly #consistency: ConsistencyPreferenceType
  readonly #listObjectsMax: number
  readonly #listObjectsDeadlineMs: number
  readonly #monotonic: () => number
  readonly #logger: { warn(message: string): void }
  /**
   * **Las relaciones `denied_*` que declara el modelo que sirve este driver** (lote D · D-31): se lee UNA vez por
   * proceso (`readAuthorizationModel` del `modelId` fijado —D14 lo exige con un tipo con deny—) y se comparte con
   * las vistas `withClock`. Un fallo al leerla no se memoriza (503 y se reintenta en la siguiente).
   */
  #modelMemo: { denied?: Promise<Set<string>> } = {}

  readonly diagnostics = { unparseableTuples: 0 }

  constructor(config: RelationsConfig, options: OpenFgaRelationsDriverOptions) {
    this.#config = config
    this.#options = options
    this.#now = options.now ?? systemClock
    this.#holderTypes = options.holderTypes
    this.#fgaToMorph = Object.fromEntries(Object.entries(options.holderTypes).map(([morph, fga]) => [fga, morph]))
    this.#timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS
    this.#consistency =
      options.consistency === 'minimize_latency'
        ? ConsistencyPreference.MinimizeLatency
        : ConsistencyPreference.HigherConsistency
    this.#listObjectsMax = options.listObjectsMaxResults ?? DEFAULT_LIST_OBJECTS_MAX
    const deadline = options.listObjectsDeadlineMs ?? DEFAULT_LIST_OBJECTS_DEADLINE_MS
    // 🟠 N1 (cierre 2 del lote B): `Infinity` se RETIRA. Con `--listObjects-deadline=0`
    // el `--request-timeout` del servidor sigue cortando con un 200 mudo
    // (medido, v1.19.0), así que «sin deadline» era una receta para la lista
    // parcial muda que B4 impide. Solo un entero > 0: el corte efectivo.
    if (!(Number.isInteger(deadline) && deadline > 0)) {
      throw new AuthorizationConfigError(
        `OpenFgaRelationsDriver: listObjectsDeadlineMs debe ser un entero > 0 en ms: el corte EFECTIVO de ListObjects ` +
          `de tu servidor, que es --listObjects-deadline si no es 0 y, si es 0, --request-timeout (3 s por defecto; ` +
          `medido en OpenFGA v1.19.0: con el deadline a 0 el request-timeout corta igual con un 200 mudo). El servidor ` +
          `siempre corta en alguno de los dos; declara el menor. No hay «sin deadline» (Infinity ya no se admite) ` +
          `(llegó ${String(options.listObjectsDeadlineMs)}); default ${DEFAULT_LIST_OBJECTS_DEADLINE_MS}.`
      )
    }
    // ⚪ N10 (cierre 3 del lote B): la señal tiene que poder SALTAR antes de que
    // el cliente corte. Un deadline declarado por encima del `timeoutMs` del
    // cliente (5 s por defecto) nunca alcanza su umbral 0,9 × D —el cliente
    // aborta con 503 antes— y, si el servidor corta ANTES que D, la lista muda
    // pasa como completa (`Number.MAX_SAFE_INTEGER` era «sin deadline» con otro
    // nombre y pasaba `Number.isInteger`). Guarda por construcción, sin tope
    // arbitrario: D ≤ timeoutMs del cliente, o 500.
    if (deadline > this.#timeoutMs) {
      throw new AuthorizationConfigError(
        `OpenFgaRelationsDriver: listObjectsDeadlineMs (${deadline}) no puede ser mayor que el timeoutMs del cliente ` +
          `(${this.#timeoutMs}): la señal tiene que poder saltar antes de que el cliente corte. Con un deadline por encima ` +
          `del timeout el umbral 0,9 × listObjectsDeadlineMs nunca se alcanza (el cliente aborta con 503 antes) y, si el ` +
          `servidor corta antes, la lista parcial muda pasa como completa. Declara el corte EFECTIVO del servidor —el MENOR ` +
          `de --listObjects-deadline (si ≠ 0), --request-timeout y, por HTTP, --http-upstream-timeout— y un timeoutMs ≥ a él.`
      )
    }
    this.#listObjectsDeadlineMs = deadline
    // ⚪ 9 (cierre 1 del lote B): el reloj monótono inyectable SOLO entra por el
    // símbolo (no está en el tipo publicado); la clave de texto `monotonic` de
    // alpha.2 ya no gobierna nada y se rechaza (L5: una opción inerte no cae en
    // silencio en el default).
    if ((options as unknown as Record<string, unknown>).monotonic !== undefined) {
      throw new AuthorizationConfigError(
        `OpenFgaRelationsDriver: 'monotonic' no es una opción pública (era SOLO TESTS); el reloj monótono se inyecta ` +
          `por el símbolo MONOTONIC_CLOCK del módulo del driver, que no se exporta por '/openfga'.`
      )
    }
    const monotonic = (options as unknown as Record<symbol, unknown>)[MONOTONIC_CLOCK]
    if (monotonic !== undefined && typeof monotonic !== 'function') {
      throw new AuthorizationConfigError(`OpenFgaRelationsDriver: [MONOTONIC_CLOCK] debe ser una función () => number (llegó ${typeof monotonic})`)
    }
    this.#monotonic = (monotonic as (() => number) | undefined) ?? (() => performance.now())
    this.#logger = options.logger ?? console
    // **D14** (decisión del dueño 2026-10-14; auditor R2-2): con algún tipo con opt-in del deny (en cualquier fase), el
    // `modelId` FIJADO es obligatorio. Sin él cada `Check` evalúa contra el ÚLTIMO modelo del store, y un
    // `openfga:provision` desde un proceso viejo (sin `denied_*`) haría que este pod concediera sobre objetos denegados
    // sin enterarse; con él, la guarda D-31 lee ESE modelo una vez y es 500 si no declara el deny.
    if (hasDenyTypes(config) && !options.modelId) {
      throw new AuthorizationConfigError(
        `OpenFgaRelationsDriver: la config de relaciones declara deny en ${config.objectTypes
          .filter((t) => t.deny !== undefined)
          .map((t) => `'${t.type}' (${t.deny})`)
          .join(', ')} y el driver no tiene modelId fijado (D14). Con deny activo cada pod tiene que evaluar contra un modelo ` +
          `CONOCIDO que declare denied_<rel>: publica el modelo (openfga:provision), fija OPENFGA_MODEL_ID en TODA la flota ` +
          `y despliega. Sin el pin, un modelo republicado sin denied_* haría conceder sobre objetos denegados.`
      )
    }
    this.client = new OpenFgaClient({
      apiUrl: options.apiUrl,
      storeId: options.storeId,
      authorizationModelId: options.modelId,
      baseOptions: { timeout: this.#timeoutMs },
      retryParams: { maxRetry: 0 },
    })
  }

  /**
   * Vista de este driver con OTRO reloj de pared (R-15, paridad con
   * `AuthorizationDriver.withClock`): MISMO cliente (store, modelo, deadline),
   * solo cambia el `now` que decide la caducidad. Se construye una instancia
   * nueva y se le presta el cliente (el espía de «1 Check» envuelve
   * `client.check` de la instancia base y tiene que seguir viéndolo).
   */
  withClock(now: Clock): RelationsDriver {
    if (!isClock(now)) {
      throw new AuthorizationConfigError(`withClock: now debe ser una función () => Date (llegó ${typeof now})`)
    }
    const view = new OpenFgaRelationsDriver(this.#config, { ...this.#options, now })
    ;(view as unknown as { client: OpenFgaClient }).client = this.client
    // La guarda D-31 es del PROCESO: la vista comparte la lectura del modelo.
    view.#modelMemo = this.#modelMemo
    return view
  }

  /** El `context` de todo `Check`/`ListObjects`: la condición `not_expired` se evalúa contra este instante (un `now` por operación). */
  #checkContext(at: Date): { current_time: string } {
    return { current_time: at.toISOString() }
  }

  /** La clave de partición (D4: `partitionKey` de `identity.ts`, la ÚNICA puerta hacia el id del store). */
  #keyOf(partition: ScopeRef): string {
    return partitionKey(partition)
  }

  /* ── Clasificación de fallos (la abstracción no filtra) ─────────────────── */

  /**
   * **El MISMO criterio que el driver de roles** (`guardBackendErrors`,
   * `openfga_driver.ts`; cierre-2 de alpha.3, ⚪ 5 del re-ataque): un
   * deadline TOTAL PROPIO por llamada (`withDeadline`, `timeoutMs`) que es lo
   * que dice «venció el deadline» —503 `E_AUTHZ_BACKEND_TIMEOUT`, indeterminado—,
   * y para lo que el cliente lanza por su cuenta el `isTimeoutLike` ESTRICTO
   * de `backend_guard.ts` (`ECONNABORTED`/`ETIMEDOUT`/`.timeout` numérico/
   * `KnexTimeoutError`, por la cadena de `cause`). Hasta el cierre-2 este
   * driver duplicaba la función con una rama por SUBSTRING del mensaje
   * (`/timeout/i`): un error que decía «no es timeout» salía como timeout con
   * `indeterminate: true` sin haber borrado nada, y el docblock afirmaba en
   * falso «mismo criterio que roles».
   */
  async #guard<T>(operation: string, fn: () => Promise<T>): Promise<T> {
    const fail = (error: unknown): Error => {
      // Un error del paquete (422/500 ya clasificado) se propaga tal cual.
      if (error instanceof InvalidIdentityError || error instanceof PurgeIncompleteError) return error
      if (isTimeoutLike(error)) {
        return new AuthorizationBackendTimeoutError('openfga-relations', operation, this.#timeoutMs, error)
      }
      return new AuthorizationBackendError('openfga-relations', operation, error)
    }
    let pending: Promise<T>
    try {
      pending = fn()
    } catch (error) {
      throw fail(error)
    }
    return withDeadline(
      pending.catch((error: unknown) => {
        throw fail(error)
      }),
      this.#timeoutMs,
      () => new AuthorizationBackendTimeoutError('openfga-relations', operation, this.#timeoutMs)
    )
  }

  /* ── D-31: el modelo FIJADO tiene que declarar el deny de los tipos con opt-in ─────────────────────────── */

  /** Las relaciones `<tipo>#denied_<rel>` que declara el modelo que sirve este driver (memo por proceso). */
  #modelDenied(): Promise<Set<string>> {
    if (!this.#modelMemo.denied) {
      const memo = this.#modelMemo
      memo.denied = this.#guard('readAuthorizationModel', async () => {
        const response: any = this.#options.modelId
          ? await this.client.readAuthorizationModel()
          : await this.client.readLatestAuthorizationModel()
        const definitions = response?.authorization_model?.type_definitions
        if (!Array.isArray(definitions)) {
          throw new Error('la respuesta de ReadAuthorizationModel no trae type_definitions; no se toma por «sin deny»')
        }
        // Cierre 1 de D1 · ⚪ 7: no basta con que EXISTA `denied_<rel>`: `<rel>` tiene que RESTARLO.
        // Cierre 2 de D1 · ⚪ N4: tampoco basta con la FORMA. En un tipo CON opt-in, `<rel>` y `denied_<rel>` tienen que
        // ser EXACTAMENTE las reglas que genera el paquete para ese tipo (`factsRelationRewrites`, la fuente única del
        // generador), por igualdad estructural tras `canonicalRewrite`: un modelo a mano con `denied_editor: [user]` (sin
        // `or denied_viewer`, el cierre del corte de camino) restaba bien y CONCEDÍA `editor` a un owner con deny en
        // `viewer`, donde `database` niega. En un tipo SIN opt-in (D8: opt-in retirado con el modelo aún publicado) no hay
        // regla del paquete con la que comparar: cuenta la forma de ⚪ 7 (`difference` con `subtract` = `denied_<rel>`),
        // que es lo que `decideMany` necesita para saber qué deny preguntar.
        const out = new Set<string>()
        for (const definition of definitions) {
          const relations = definition?.relations ?? {}
          const spec = this.#config.objectTypes.find((t) => t.type === definition?.type)
          const expected = spec && spec.deny !== undefined ? factsRelationRewrites(spec) : undefined
          for (const name of Object.keys(relations)) {
            if (!name.startsWith(RELATION_DENY_PREFIX)) continue
            const relation = name.slice(RELATION_DENY_PREFIX.length)
            const base = relations[relation]
            const ok = expected
              ? sameRewrite(base, expected[relation]) && sameRewrite(relations[name], expected[name])
              : base?.difference?.subtract?.computedUserset?.relation === name
            if (ok) out.add(`${definition.type}#${name}`)
          }
        }
        return out
      }).catch((error: unknown) => {
        // Un fallo (503) NO se memoriza: la siguiente lo vuelve a intentar.
        if (memo.denied === pending) memo.denied = undefined
        throw error
      })
      const pending = memo.denied
    }
    return this.#modelMemo.denied!
  }

  /**
   * **D-31 · un tipo con opt-in y un modelo FIJADO sin `denied_<rel>` ⇒ 500 al USARLO** (juez ronda 2 §2, H3 b):
   * un pod con la config nueva y el pin a un modelo viejo (o republicado por un proceso viejo) concedería sobre un
   * objeto denegado —la resta la hace el servidor con el modelo que el pod fija—. Antes de la primera request de
   * cualquier operación sobre esos tipos se comprueba (una lectura del modelo por proceso) y, si falta, 500
   * `E_AUTHZ_CONFIG` nombrando las relaciones: ruidoso en vez de conceder. Tipos sin opt-in: sin coste.
   */
  async #assertModelDeny(types: Iterable<string>): Promise<void> {
    const wanted: string[] = []
    for (const type of new Set(types)) {
      if (denyPhaseOf(this.#config, type) === undefined) continue
      const spec = this.#config.objectTypes.find((t) => t.type === type)
      for (const relation of spec?.relations ?? []) wanted.push(`${type}#${deniedRelationOf(relation.name)}`)
    }
    if (wanted.length === 0) return
    const declared = await this.#modelDenied()
    const missing = wanted.filter((name) => !declared.has(name))
    if (missing.length > 0) {
      throw new AuthorizationConfigError(
        `OpenFgaRelationsDriver: la config declara deny y el modelo que sirve este driver (modelId ` +
          `${this.#options.modelId ?? '(último)'}) NO declara ${missing.join(', ')} —o la declara pero <rel> o denied_<rel> no son las reglas que genera el paquete (but not y el cierre del corte de camino)— (D-31). Con ese modelo el servidor no ` +
          `resta el deny: un pod así concedería sobre objetos denegados. Republica el modelo desde la config actual ` +
          `(openfga:provision) y fija el modelId nuevo en TODA la flota antes de desplegar.`
      )
    }
  }

  /* ── Composición y parseo de ids (⚪5: partición por string en el id) ────── */

  /** `<type>:<scopeKey(partition)>|<objectUuid>`. */
  #objectId(objectType: string, partitionKey: string, objectUuid: string): string {
    // R-16 (defensa en profundidad, paridad con `database`): el `object.id` con
    // la gramática estricta ANTES de componer. Un `|`/`#`/`:`/espacio dentro se
    // escribía (solo se medía la longitud) y luego se perdía en el parseo por
    // el último `|` —invisible en enumeración y `reconcile`—. `manager.driver()`
    // salta el manager, así que el driver aplica la MISMA regla que él.
    assertRelationId(`el id del objeto '${objectType}'`, objectUuid)
    const id = `${objectType}:${partitionKey}|${objectUuid}`
    assertFgaObjectId(objectType, id)
    return id
  }

  /**
   * El `user` FGA de un sujeto: holder ⇒ `<fgaType>:<uuid>`; userset ⇒
   * `<type>:<scopeKey(partition)>|<objUuid>#<relation>`. El userset comparte la
   * partición de la tupla (el manager lo exige).
   */
  #subjectUser(subject: RelSubject, partitionKey: string): string {
    if (isRelUserset(subject)) {
      // alpha.3 · F-05 también en el USERSET del sujeto (la misma función que
      // el manager): `role_binding:<key>|<R>#role` como `user` de un `Read`/
      // `Check`/`Write` no se compone nunca. B3 (lote B): y solo `group#member`
      // — otro userset era un 400 del servidor (503 mal clasificado).
      assertUsersetSubject(this.#config, subject)
      const object = this.#objectId(subject.object.type, partitionKey, subject.object.id)
      return `${object}#${subject.relation}`
    }
    const fgaType = this.#holderTypes[subject.type]
    if (!fgaType) {
      throw new InvalidIdentityError(
        `Holder type '${subject.type}' no está en holderTypes del driver openfga de relaciones ` +
          `(declarados: ${Object.keys(this.#holderTypes).join(', ') || 'ninguno'}).`
      )
    }
    return `${fgaType}:${subject.uuid}`
  }

  /**
   * **Parseo CANÓNICO del id de un objeto de relación** (⚪5): a partir de
   * `<type>:<scopeKey>|<objUuid>`, separa `type` (antes del primer `:`),
   * `partitionKey` (todo menos el ÚLTIMO segmento tras el `:`) y `objectUuid`
   * (el último segmento, que no contiene `|`). Es el MISMO parseo-desde-la-
   * derecha que `parseBindingId`: `lastIndexOf('|')` corta el objeto de la
   * clave de partición (que tiene 1 parte `app` o 2 `<tipo>|<uuid>`). `null` si
   * el id no tiene la forma que este driver escribe.
   */
  #parseObjectId(fullId: string): { type: string; partitionKey: string; objectUuid: string } | null {
    const colon = fullId.indexOf(':')
    if (colon <= 0) return null
    const type = fullId.slice(0, colon)
    const rest = fullId.slice(colon + 1)
    const cut = rest.lastIndexOf('|')
    if (cut < 0) return null
    const partitionKey = rest.slice(0, cut)
    const objectUuid = rest.slice(cut + 1)
    if (!partitionKey || !objectUuid) return null
    return { type, partitionKey, objectUuid }
  }

  /** Un `user` del store de vuelta a `RelSubject`: userset (`…#rel`) o holder (`<fga>:<uuid>`). */
  #userToSubject(user: string): RelSubject | null {
    const hash = user.indexOf('#')
    if (hash >= 0) {
      const parsed = this.#parseObjectId(user.slice(0, hash))
      const relation = user.slice(hash + 1)
      if (!parsed || !relation) return null
      return { object: { type: parsed.type, id: parsed.objectUuid }, relation }
    }
    const colon = user.indexOf(':')
    if (colon <= 0) return null
    const morph = this.#fgaToMorph[user.slice(0, colon)]
    const uuid = user.slice(colon + 1)
    if (!morph || !uuid || uuid === '*' || uuid.includes('|')) return null
    return { type: morph, uuid }
  }

  /* ── Escrituras ─────────────────────────────────────────────────────────── */

  /**
   * `relate` con los tres estados de `expiresAt` (R-15, invariante 10). Se LEE
   * primero la tupla exacta (un `Read` por clave, como `grant` de roles):
   *  - ausente ⇒ un `Write` (con la condición `not_expired` si caduca);
   *  - presente con la caducidad que toca ⇒ no-op (idempotente, invariante 6);
   *  - presente con OTRA ⇒ delete + write en DOS llamadas (FGA no admite
   *    delete+write de la misma clave en un `Write`, ni reescribir su
   *    condición): entre ambas la tupla NO está. Para un allow eso solo
   *    quita (fail-closed, la misma ventana que el `grant` de roles); para una
   *    membresía `group:*#member` que TRANSPORTA un deny, CONCEDERÍA — desde el
   *    cierre 2 de D2 (🟠 N1) esa renovación es 409 `E_AUTHZ_RENEWAL_UNSAFE`
   *    con cero escrituras (`#carriedDeny`), y si el 2.º `Write` de una
   *    renovación permitida falla el error va marcado PARCIAL (`markPartialWrite`).
   */
  /**
   * **`{ transaction }` se rechaza también AQUÍ** (L-5, defensa en
   * profundidad como F-05 en L-0): la puerta 1 vive en el `RelationsManager`,
   * pero `manager.driver()` y `reconcileRelations` entran por el driver; sin
   * esta guarda un `{ transaction }` por ahí escribiría la tupla en el store
   * IGNORANDO la transacción — una escritura que finge ir en tu transacción y
   * que tu rollback no deshace, que es exactamente el fail-open que
   * `transactionalWrites: false` declara no poder evitar. Primera línea de
   * las cuatro escrituras, antes de F-05, del `Read` y del `Write`: CERO
   * llamadas al cliente.
   */
  #rejectTransaction(operation: string, options: RelationTransactionOptions | undefined): void {
    if (options?.transaction === undefined || options.transaction === null) return
    throw UnsupportedOperationError.transactionalDriver(`relations.${operation}`, 'openfga', 'relations')
  }

  async relate(
    subject: RelSubject,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    options?: RelationWriteOptions
  ): Promise<void> {
    this.#rejectTransaction('relate', options)
    // L-0 · F-05 en el DRIVER (defensa en profundidad, la MISMA función que el
    // manager): `manager.driver()` y `reconcileRelations` entran por aquí, y en
    // el store COMPARTIDO un tipo no declarado (`role_binding`) compondría el
    // id exacto de un binding de roles. Corta ANTES del `Read` y del `Write`.
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    assertExpiresAt(options?.expiresAt)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    const user = this.#subjectUser(subject, partitionKey)
    const key = { user, relation, object: objectId }
    const now = this.#now()
    await this.#assertModelDeny([object.type])
    const current = await this.#readTuple('relate', key)
    const previous = current ? current.validUntil : null
    const expiresAt = resolveGrantExpiry(previous, options?.expiresAt, now)
    if (current && sameInstant(previous, expiresAt)) return
    const tuple = expiresAt
      ? { ...key, condition: { name: FACTS_EXPIRY_CONDITION, context: { valid_until: expiresAt.toISOString() } } }
      : key
    if (current) {
      // Cierre 2 de D2 · 🟠 N1 (decisión del dueño 2026-10-15 (9)): una membresía que TRANSPORTA un deny no se renueva
      // con dos `Write` — entre el delete y el write el sujeto quedaría sin el deny y concedería. 409, CERO escrituras.
      // Cierre 3 de D2 · ⚪ C2-4: una membresía YA VENCIDA no conecta nada (el deny ya no alcanza al sujeto por ella), así
      // que no hay ventana que proteger: se reescribe sin comprobar portadora (hasta el cierre 3 era un 409 espurio).
      const guarded = object.type === RELATION_USERSET_TYPE && isActiveExpiry(previous, now)
      const membership = `${objectId}#${relation}@${user}`
      if (guarded) {
        const carried = await this.#carriedDeny(objectId, partitionKey, now)
        if (carried !== null) throw RenewalUnsafeError.carrier(membership, carried)
      }
      await this.#guard('relate', () => this.client.write({ deletes: [key] }, IGNORE_MISSING_DELETES))
      // Cierre 2 de D2 · 🟠 N1 (b): el delete YA entró — si el write falla, la escritura es PARCIAL (invariante 13: el
      // manager notifica `indeterminate: true`); hasta el cierre era un 503 «sin escribir» con la tupla borrada.
      try {
        await this.#guard('relate', () => this.client.write({ writes: [tuple] }, IGNORE_DUPLICATE_WRITES))
      } catch (error) {
        // Cierre 3 de D2 · 🟡 C2-3: la membresía quedó BORRADA. Si entre la comprobación y el delete entró un deny en el
        // grupo (TOCTOU), ese deny ya no alcanza al sujeto —y no lo alcanzará hasta que la membresía se reescriba—: el
        // error parcial lo NOMBRA (`carriedDeny`) con la receta. Mejor esfuerzo: si la re-lectura también falla, se dice.
        if (guarded && error !== null && typeof error === 'object') {
          annotateRacedDeny(error, membership, await this.#recheckCarried(objectId, partitionKey, now))
        }
        throw error !== null && typeof error === 'object' ? markPartialWrite(error) : error
      }
      // Cierre 3 de D2 · 🟡 C2-3: la RE-COMPROBACIÓN. Un deny que entró entre `#carriedDeny` y los dos `Write` no alcanzó
      // al sujeto durante la ventana; la renovación se aplicó (el estado final es correcto) y el error lo dice, marcado
      // parcial (el manager notifica `indeterminate: true`). La ventana NO se cierra (FGA no tiene una primitiva para
      // serializar `deny` contra la renovación): deja de ser muda. README «Every other renewal stays two `Write`s».
      if (guarded) {
        const recheck = await this.#recheckCarried(objectId, partitionKey, now)
        if (recheck.deny !== null) throw markPartialWrite(RenewalRacedError.raced(membership, recheck.deny))
        if (recheck.error !== undefined) {
          const error = recheck.error
          throw error !== null && typeof error === 'object'
            ? markPartialWrite(annotateRacedDeny(error, membership, recheck, true))
            : error
        }
      }
      return
    }
    await this.#guard('relate', () => this.client.write({ writes: [tuple] }, IGNORE_DUPLICATE_WRITES))
  }

  /**
   * **¿Transporta el grupo un deny vivo?** (cierre 2 de D2 · 🟠 N1): el `#member` de `group` —o el de un grupo que lo
   * contiene, transitivamente (`group:G#member@group:H#member`: los miembros de H heredan los denies de G)— es sujeto de
   * una tupla `denied_*` de la partición, en algún tipo con opt-in del deny. Devuelve la primera que encuentra (para la
   * letra) o `null`. Coste: por cada grupo del cierre hacia arriba, un `Read` por `user` + tipo (el filtro que FGA admite:
   * `user` y `object` tipo) por cada tipo con deny, y uno de sus padres. Solo corre en una RENOVACIÓN de membresía.
   */
  async #carriedDeny(groupObjectId: string, partitionKey: string, now: Date): Promise<string | null> {
    const denyTypes = this.#config.objectTypes.filter((t) => denyPhaseOf(this.#config, t.type) !== undefined).map((t) => t.type)
    if (denyTypes.length === 0) return null
    const seen = new Set([groupObjectId])
    const queue = [groupObjectId]
    while (queue.length > 0) {
      const userset = `${queue.shift()!}#${RELATION_USERSET_RELATION}`
      for (const type of denyTypes) {
        for (const t of await this.#readAll('relate', { user: userset, object: `${type}:` })) {
          if (t.relation.startsWith(RELATION_DENY_PREFIX) && t.object.startsWith(`${type}:${partitionKey}|`)) {
            return `${t.object}#${t.relation}@${t.user}`
          }
        }
      }
      for (const parent of await this.#readAll('relate', { user: userset, relation: RELATION_USERSET_RELATION, object: `${RELATION_USERSET_TYPE}:` })) {
        // Cierre 3 de D2 · ⚪ C2-4: una arista de anidación VENCIDA no transporta nada (no conecta en FGA).
        if (!isActiveExpiry(parent.validUntil ?? null, now)) continue
        if (!seen.has(parent.object)) {
          seen.add(parent.object)
          queue.push(parent.object)
        }
      }
    }
    return null
  }

  /** `#carriedDeny` tras los dos `Write` (🟡 C2-3): nunca lanza; un fallo de la re-lectura viaja en `error`. */
  async #recheckCarried(groupObjectId: string, partitionKey: string, now: Date): Promise<{ deny: string | null; error?: unknown }> {
    try {
      return { deny: await this.#carriedDeny(groupObjectId, partitionKey, now) }
    } catch (error) {
      return { deny: null, error }
    }
  }

  /**
   * La tupla EXACTA de una clave (un `Read` por clave completa), con su caducidad si la lleva.
   * ⚪ N5 (cierre 2 del lote B): un 200 sin `tuples` NO es «no existe» — hasta el cierre `?? []` lo
   * vendía así y `relate` escribía a ciegas (una caducidad vigente que no se ve no se preserva).
   * Es 503, como `#readAll`: exhaustivo-o-ruidoso también en la lectura de UNA clave.
   */
  async #readTuple(
    operation: string,
    key: { user: string; relation: string; object: string }
  ): Promise<StoredRelationTuple | null> {
    const response = await this.#guard(operation, () => this.client.read(key, { consistency: this.#consistency }))
    if (!Array.isArray(response?.tuples)) {
      throw new AuthorizationBackendError(
        'openfga-relations',
        operation,
        new Error(`la respuesta del Read de la clave no trae 'tuples'; no se toma por «no existe»`)
      )
    }
    const found = response.tuples.map((t) => t.key as any).find(
      (k) => k?.user === key.user && k?.relation === key.relation && k?.object === key.object
    )
    if (!found) return null
    return { ...key, validUntil: toExpiryDate(found.condition?.context?.valid_until) }
  }

  async unrelate(
    subject: RelSubject,
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    options?: RelationWriteOptions
  ): Promise<void> {
    this.#rejectTransaction('unrelate', options)
    // L-0 · F-05 también al RETIRAR: un `unrelate(alice, assignee, role_binding)`
    // sería un revoke de roles por la puerta de relaciones.
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    const user = this.#subjectUser(subject, partitionKey)
    await this.#assertModelDeny([object.type])
    await this.#guard('unrelate', () =>
      // Re-unrelate no-op seguro: borrar una tupla ausente se ignora.
      this.client.write({ deletes: [{ user, relation, object: objectId }] }, IGNORE_MISSING_DELETES)
    )
  }

  /**
   * **`deny` = UN `Write` de la tupla `denied_<rel>`** (lote D · D1): sin caducidad (D3), así que no hay renovación
   * ni ventana —un re-deny idéntico lo ignora el servidor (`on_duplicate: ignore`)—; una tupla de deny escrita a mano
   * CON condición devuelve 409 y, desde el cierre 1 de D2 (🟡 4), sale como 500 `E_AUTHZ_CONFIG` con la receta
   * (`AuthorizationConfigError.conditionalDeny`; hasta entonces era un 503 que se repetía para siempre). Antes del `Write`: la
   * puerta de `{ transaction }` (L-5), F-05 sobre el nombre PÚBLICO, la puerta del opt-in (fase `'write'`), sin
   * caducidad, la partición, `*`, el sujeto y la guarda del modelo (D-31). CERO llamadas si algo de eso falla.
   */
  async deny(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef, options?: RelationDenyOptions): Promise<void> {
    this.#rejectTransaction('deny', options)
    assertRelationDeclared(this.#config, object, relation)
    assertRelationDenyable(this.#config, object, relation)
    assertDenyNoExpiry(options)
    assertPartition(partition)
    assertDenySubject(subject)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    const user = this.#subjectUser(subject, partitionKey)
    await this.#assertModelDeny([object.type])
    const key = { user, relation: deniedRelationOf(relation), object: objectId }
    try {
      await this.#guard('deny', () => this.client.write({ writes: [key] }, IGNORE_DUPLICATE_WRITES))
    } catch (error: any) {
      // Cierre 1 de D2 · 🟡 4: el 409 de una clave que ya existe CON condición (medido en v1.19.0: «already exists with
      // a different condition») no es una caída. Se confirma RELEYENDO la tupla (no por el texto del mensaje): si está y
      // lleva condición, 500 con la receta; si no, el 503 de siempre.
      if (error?.status === 503 && error?.cause?.statusCode === 409) {
        const found = await this.#guard('deny', () => this.client.read(key, { consistency: this.#consistency }))
        if (Array.isArray(found?.tuples) && found.tuples.some((t: any) => t?.key?.condition)) {
          throw AuthorizationConfigError.conditionalDeny('deny', `${key.object}#${key.relation}@${key.user}`)
        }
      }
      throw error
    }
  }

  /**
   * **`removeDeny` = UN delete de `denied_<rel>`** (no-op si no está). Sobre CUALQUIER tipo declarado (D8/R2-4 b):
   * `Write` con delete no valida la relación contra el modelo (medido en v1.19.0), así que un deny vivo de un tipo
   * que retiró el opt-in se puede borrar. Ojo: quitar un deny CONCEDE (filas declaradas S8–S10).
   * **La guarda D-31 SÍ corre aquí para los tipos CON opt-in** (letra corregida en el cierre 1 de D1, ⚪ 5 del auditor:
   * la decisión 4 del informe decía que no): con el opt-in vivo y un modelo fijado sin `denied_*` ⇒ 500 antes del
   * delete. Con el opt-in RETIRADO no hay guarda (el tipo no está en la config con `deny`) y el delete borra de verdad
   * (medido por el auditor: `listDenies` de 1 a 0 y `check` vuelve a `true` con el modelo viejo) — retirar es reversible.
   */
  async removeDeny(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef, options?: RelationDenyOptions): Promise<void> {
    this.#rejectTransaction('removeDeny', options)
    assertRelationDeclared(this.#config, object, relation)
    assertDenyNoExpiry(options)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    const user = this.#subjectUser(subject, partitionKey)
    await this.#assertModelDeny([object.type])
    await this.#guard('removeDeny', () =>
      this.client.write({ deletes: [{ user, relation: deniedRelationOf(relation), object: objectId }] }, IGNORE_MISSING_DELETES)
    )
  }

  /* ── Lecturas ───────────────────────────────────────────────────────────── */

  /**
   * **F-05 en las LECTURAS y las PURGAS del driver** (2.4.0-alpha.3, cierre
   * del 🔴 1 / 🟠 2 del auditor; la MISMA función y la misma posición que
   * L-0 en `relate`/`unrelate` y que L-5 con `{ transaction }`): PRIMERA
   * línea (tras `#rejectTransaction` en las purgas), CERO llamadas al
   * cliente. Reproducido contra el `:8101` en el store compartido:
   * `purgeObject({ type: 'role_binding', id: R }, S)` componía
   * `role_binding:<scopeKey>|<R>` —byte a byte el binding real— y
   * `#purgeByFilter` lo borraba con demostración de cero (`authorize` de
   * `true` a `false`); `listSubjects('assignee', role_binding)` enumeraba sus
   * asignados. `check`/`listSubjects` validan el par; `listObjects`/
   * `purgeObject` el tipo; `purgeSubject` el userset.
   */
  /** `check` = UN solo `Check` (el modelo resuelve includes + usersets). */
  async check(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef): Promise<boolean> {
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    const user = this.#subjectUser(subject, partitionKey)
    const context = this.#checkContext(this.#now())
    await this.#assertModelDeny([object.type])
    const response = await this.#guard('check', () =>
      this.client.check({ user, relation, object: objectId, context }, { consistency: this.#consistency })
    )
    return response.allowed === true
  }

  /**
   * **`checkMany` = un `batchCheck` por cada `FGA_MAX_BATCH_CHECK` objetos
   * DISTINTOS** (plan 2.5 · lote A, P4-8; con el tope del manager, 50, es
   * UNA request), alineado por `correlationId` y NUNCA por posición
   * (`correlateBatchResults`, la misma función que el driver de roles: el
   * SDK reparte y concatena según llegan). El `current_time` viaja en CADA
   * ítem y es el MISMO para todo el lote (un `now`). Un `error` en UN ítem
   * (`input_error`, `internal_error`…) es una caída parcial del backend ⇒
   * 503 para todo el lote, jamás `false` (invariante 5). F-05 y la gramática
   * del id POR ÍTEM antes de componer nada (defensa en profundidad).
   */
  async checkMany(subject: RelSubject, relation: string, objects: RelObject[], partition: ScopeRef): Promise<boolean[]> {
    assertCheckManyObjects(objects)
    for (const object of objects) assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const user = this.#subjectUser(subject, partitionKey)
    const { distinct, index } = distinctObjects(objects)
    const context = this.#checkContext(this.#now())
    await this.#assertModelDeny(distinct.map((object) => object.type))
    const checks: ClientBatchCheckItem[] = distinct.map((object, i) => ({
      user,
      relation,
      object: this.#objectId(object.type, partitionKey, object.id),
      context,
      correlationId: String(i),
    }))
    const answers: boolean[] = new Array(distinct.length)
    for (let start = 0; start < checks.length; start += FGA_MAX_BATCH_CHECK) {
      const chunk = checks.slice(start, start + FGA_MAX_BATCH_CHECK)
      const response = await this.#guard('checkMany', () =>
        this.client.batchCheck({ checks: chunk }, { consistency: this.#consistency })
      )
      // A10: alineación por id + «error ⇒ 503 / ausente ⇒ 500» en UNA función, la del driver de roles.
      const results = alignBatchResults('openfga-relations', 'checkMany', chunk, response.result)
      results.forEach((r, i) => {
        answers[Number(chunk[i].correlationId)] = r.allowed === true
      })
    }
    return expandByPosition(index, answers)
  }

  /**
   * **`decideMany` = un `batchCheck` con `R` y los `denied_<m>` de las relaciones FUENTE de `down*(R)`** (lote D ·
   * D9, juez ronda 2 §4): por el cierre ascendente del modelo (`denied_X = this ∨ denied_P`), `denied_<fuente>`
   * cubre todo `up*(down*(R))` — en el retículo del contrato, 2 ítems por objeto (`R` y `denied_owner`). Mismo
   * `current_time` en TODOS los ítems (un `now` por lote), alineado por `correlationId` (`alignBatchResults`, la
   * misma función que `checkMany` y roles), troceado por `FGA_MAX_BATCH_CHECK`, y un `error` en UN ítem ⇒ 503 para
   * todo el lote (nunca `none`: S15). La decisión sale de `decideFrom`, la regla ÚNICA (la misma que `database` y el
   * doble). En un tipo sin opt-in se pregunta el deny solo si el modelo que sirve el driver lo declara (opt-in
   * retirado con el modelo aún publicado, D8); si no, cada posición es `allow` o `none` (no hay deny posible).
   */
  async decideMany(subject: RelSubject, relation: string, objects: RelObject[], partition: ScopeRef): Promise<RelationDecision[]> {
    assertCheckManyObjects(objects, 'decideMany')
    for (const object of objects) assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    this.#assertPinnedForDecideMany()
    const partitionKey = this.#keyOf(partition)
    const user = this.#subjectUser(subject, partitionKey)
    const { distinct, index } = distinctObjects(objects)
    const context = this.#checkContext(this.#now())
    await this.#assertModelDeny(distinct.map((object) => object.type))
    const declared = await this.#modelDenied()
    const checks: ClientBatchCheckItem[] = []
    const plan: Array<{ object: RelObject; sources: string[] }> = []
    distinct.forEach((object, i) => {
      const objectId = this.#objectId(object.type, partitionKey, object.id)
      const down = relationsDown(this.#config, object.type, relation)
      const type = this.#config.objectTypes.find((t) => t.type === object.type)
      const sources = down.filter((name) => {
        const includes = type?.relations.find((r) => r.name === name)?.includes ?? []
        return includes.length === 0 && declared.has(`${object.type}#${deniedRelationOf(name)}`)
      })
      plan.push({ object, sources })
      // `correlationId` del servidor: `^[\w\d-]{1,36}$` (sin `:`): `a<i>` para R, `d<i>-<k>` para la fuente k.
      checks.push({ user, relation, object: objectId, context, correlationId: `a${i}` })
      sources.forEach((source, k) => {
        checks.push({ user, relation: deniedRelationOf(source), object: objectId, context, correlationId: `d${i}-${k}` })
      })
    })
    const allowed = new Map<string, boolean>()
    for (let start = 0; start < checks.length; start += FGA_MAX_BATCH_CHECK) {
      const chunk = checks.slice(start, start + FGA_MAX_BATCH_CHECK)
      const response = await this.#guard('decideMany', () =>
        this.client.batchCheck({ checks: chunk }, { consistency: this.#consistency })
      )
      const results = alignBatchResults('openfga-relations', 'decideMany', chunk, response.result)
      results.forEach((r, i) => allowed.set(chunk[i].correlationId!, r.allowed === true))
    }
    // D9, por posición: `allow` si el `Check` de R concede (el servidor ya aplicó el corte); si no, `deny` si alguno
    // de los `denied_<fuente>` alcanza al sujeto (su cierre cubre up*(down*(R))); si no, `none`. Es `decideFrom` con el
    // corte ya evaluado en el servidor (los dos drivers y el doble responden la misma tabla: casos D9 de la COMÚN).
    const answers = plan.map(({ sources }, i): RelationDecision => {
      if (allowed.get(`a${i}`)) return 'allow'
      return sources.some((_, k) => allowed.get(`d${i}-${k}`)) ? 'deny' : 'none'
    })
    return index.map((at) => answers[at])
  }

  /**
   * **`decideMany` exige `modelId` FIJADO, con o sin tipos con deny** (lote D · cierre 1 de D1, 🟡 3 del auditor; D14
   * extendido a la primitiva de cadena). `decideMany` decide qué `denied_*` preguntar con el memo del modelo
   * (`#modelDenied`), y `check` lo resta el SERVIDOR con el modelo que evalúa: sin pin, el memo es el «último» del
   * momento de la primera lectura y el servidor evalúa con el último de AHORA. Republicado un modelo con deny (flota con
   * dos configs, reactivación del opt-in), `check` daba `false` por el deny y `decideMany` respondía `none` —la cadena
   * del llamante seguía subiendo y concedía por el padre: fail-open en la primitiva—. Con el pin, memo y `Check` son
   * del MISMO modelo. 500 `E_AUTHZ_CONFIG` con cero llamadas, ANTES de leer nada.
   */
  #assertPinnedForDecideMany(): void {
    if (this.#options.modelId) return
    throw new AuthorizationConfigError(
      `OpenFgaRelationsDriver.decideMany: exige modelId FIJADO (D14, también sin tipos con deny). decideMany decide qué ` +
        `denied_<rel> preguntar con el modelo que leyó una vez, y sin pin el servidor evalúa check con el ÚLTIMO modelo del ` +
        `store: tras republicar un modelo con deny respondería 'none' donde check responde false, y la cadena del llamante ` +
        `concedería por el padre. Receta: provision (openfga:provision) → fijar modelId (OPENFGA_MODEL_ID) en TODA la flota ` +
        `→ desplegar. No se ha llamado al servidor.`
    )
  }

  /**
   * **`denyPhase` — ¿admite este driver escrituras de deny en el tipo?** (lote D · D2, R2-5). La fase del opt-in EN
   * LA CONFIG DE ESTE DRIVER y, con opt-in, el modelo FIJADO comprobado con la MISMA guarda D-31 que `deny` (500 si
   * no declara `denied_<rel>`). F-05 estricto del par, antes de nada (422, cero llamadas). La llama
   * `reconcileRelations` en la fase de plan cuando el origen trae denies: un destino `openfga` sin `'write'` en el
   * tipo, o con un pin a un modelo sin el deny, NIEGA la pasada antes de la primera escritura (jamás `skipped`).
   */
  async denyPhase(object: { type: string }, relation: string): Promise<'read' | 'write' | null> {
    assertRelationDeclared(this.#config, object, relation)
    const phase = denyPhaseOf(this.#config, object.type)
    if (phase === undefined) return null
    await this.#assertModelDeny([object.type])
    return phase
  }

  /** `listDenies` = `Read` por `(object, denied_<rel>)`: los denies DIRECTOS (hechos). Cualquier tipo declarado (D8). */
  async listDenies(relation: string, object: RelObject, partition: ScopeRef, _page?: RelationPage): Promise<RelationSubjectsPage> {
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    const now = this.#now()
    const tuples = await this.#readAll('listDenies', { object: objectId, relation: deniedRelationOf(relation) })
    const subjects: RelSubject[] = []
    for (const t of tuples) {
      if (t.validUntil && t.validUntil.getTime() <= now.getTime()) continue
      const subject = this.#userToSubject(t.user)
      if (subject) subjects.push(subject)
      else this.#warnUnparseable('listDenies', t.user)
    }
    return { subjects }
  }

  /**
   * **El envoltorio ÚNICO de `ListObjects`** (plan 2.5 · lote B · B4; linaje L8,
   * 5.ª iteración ⇒ M8: propiedad universal «toda enumeración que se puede
   * cortar devuelve `truncated` o lanza»). `ListObjects` corta de DOS formas,
   * las dos con 200 y sin `continuation_token` ni bandera: (1) al tope del
   * servidor (`listObjectsMaxResults`): `>= tope` resultados CRUDOS ⇒ no se
   * puede prometer la lista completa; (2) al DEADLINE del servidor
   * (`--listObjects-deadline`, 3 s por defecto): pasado, devuelve lo que
   * llevaba resuelto (analista M4, medido). La (2) se detecta midiendo la
   * llamada con el reloj MONÓTONO (`monotonic`, `performance.now`): si duró
   * ≥ `LIST_OBJECTS_DEADLINE_RATIO` × `listObjectsDeadlineMs`, `truncated`. Es
   * una señal conservadora a propósito (una llamada lenta pero completa sale
   * como truncada; una cortada JAMÁS como completa). Todo `ListObjects` del
   * driver pasa por aquí — la guardia de superficie (columna `truncation`) lo
   * sondea con las dos causas y un mutante por cada una. Las enumeraciones por
   * `Read` (`listSubjects`, `enumerateRelations`, las purgas) no se cortan:
   * `#readAll` agota el token o lanza 503 («exhaustivo o ruidoso»).
   */
  async #listObjectsPage(request: { user: string; relation: string; type: string; context: { current_time: string } }): Promise<{
    raw: string[]
    truncated: boolean
    elapsedMs: number
  }> {
    const started = this.#monotonic()
    const response = await this.#guard('listObjects', () => this.client.listObjects(request, { consistency: this.#consistency }))
    const elapsedMs = this.#monotonic() - started
    // 🟡 4 (cierre 1 del lote B): un 200 sin `objects` (un proxy, una caché, un
    // cuerpo vacío) NO es una lista completa vacía: es una enumeración que no
    // se puede prometer ⇒ 503, como `#readAll` con una respuesta sin `tuples`.
    // Hasta el cierre `response.objects ?? []` la vendía como `{ objects: [] }`
    // sin `truncated` — la lista «completa» muda que M8 prohíbe.
    if (!Array.isArray(response?.objects)) {
      throw new AuthorizationBackendError(
        'openfga-relations',
        'listObjects',
        new Error(`la respuesta de ListObjects no trae 'objects'; no se toma por vacía (sería una lista completa muda)`)
      )
    }
    const raw: string[] = response.objects
    const byCap = raw.length >= this.#listObjectsMax
    const byDeadline = elapsedMs >= LIST_OBJECTS_DEADLINE_RATIO * this.#listObjectsDeadlineMs
    return { raw, truncated: byCap || byDeadline, elapsedMs }
  }

  /**
   * `listObjects` = `ListObjects` (resuelve includes + usersets del lado del
   * servidor) + FILTRO por partición + señal de TRUNCADO (`#listObjectsPage`:
   * tope o deadline, B4). El filtro por partición se aplica DESPUÉS (los ids
   * llevan la partición), así que en un store con varias particiones el tope
   * se consume entre todas — otra razón para señalar el truncado y no callar
   * (documentado en el README).
   */
  async listObjects(
    subject: RelSubject,
    relation: string,
    objectType: string,
    partition: ScopeRef,
    _page?: RelationPage
  ): Promise<RelationObjectsPage> {
    assertRelationDeclared(this.#config, { type: objectType }, relation)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const user = this.#subjectUser(subject, partitionKey)
    const context = this.#checkContext(this.#now())
    await this.#assertModelDeny([objectType])
    const { raw, truncated } = await this.#listObjectsPage({ user, relation, type: objectType, context })
    const objects: RelObject[] = []
    for (const full of raw) {
      const parsed = this.#parseObjectId(full)
      if (!parsed || parsed.type !== objectType) {
        this.#warnUnparseable('listObjects', full)
        continue
      }
      if (parsed.partitionKey !== partitionKey) continue // otra partición: no cruza
      objects.push({ type: objectType, id: parsed.objectUuid })
    }
    objects.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
    return truncated ? { objects, truncated: true } : { objects }
  }

  /**
   * `listSubjects` = `Read` por `(object, relation)` — hechos DIRECTOS del
   * relation EXACTO (invariante 7): ni transitivo (eso es `membersOf`) ni
   * derivado por includes. `usersetSubjects: true` ⇒ los usersets
   * (`group#member`) salen junto con los holders.
   */
  async listSubjects(
    relation: string,
    object: RelObject,
    partition: ScopeRef,
    _page?: RelationPage
  ): Promise<RelationSubjectsPage> {
    assertRelationDeclared(this.#config, object, relation)
    assertPartition(partition)
    const partitionKey = this.#keyOf(partition)
    const objectId = this.#objectId(object.type, partitionKey, object.id)
    // `Read` devuelve tuplas ESCRITAS, no evaluadas: la caducidad se filtra en
    // cliente con el MISMO reloj del driver (R-15, estricta: la que vence en
    // `now` ya no cuenta), como las enumeraciones del driver de roles.
    const now = this.#now()
    const tuples = await this.#readAll('listSubjects', { object: objectId, relation })
    const subjects: RelSubject[] = []
    for (const t of tuples) {
      if (t.validUntil && t.validUntil.getTime() <= now.getTime()) continue
      const subject = this.#userToSubject(t.user)
      if (subject) subjects.push(subject)
      else this.#warnUnparseable('listSubjects', t.user)
    }
    return { subjects }
  }

  /**
   * **`membersOf` ⇒ 500 `E_AUTHZ_UNSUPPORTED`** (cara `whenFalse`): la
   * membresía TRANSITIVA de un grupo sería `ListUsers`, que trunca al tope del
   * servidor sin señal fiable. No hay userset transitivo enumerable aquí; se
   * dice con 500 nombrándolo, jamás un userset a medias. Es el análogo del par
   * `purgeRole` de la 3b. (El método existe en el prototipo para que el manager
   * lo despache, pero la capacidad `membersOfNative: false` lo corta antes.)
   */
  async membersOf(): Promise<RelationSubjectsPage> {
    throw new UnsupportedOperationError(
      'membersOf',
      'la membresía transitiva de un grupo',
      'openfga',
      `En 'openfga' la transitiva sería 'ListUsers', que trunca al tope del servidor sin señal fiable. ` +
        `Usa el driver 'database' (CTE recursiva) o 'listSubjects' para los hechos directos.`
    )
  }

  /* ── ORIGEN de reconcile (4-5): las tuplas de relación de la partición ──── */

  /**
   * **`enumerateRelations` — el ORIGEN de `authz:reconcile` de relaciones**
   * (4-5). Lee el store ENTERO (`Read({})`) —la única forma de ver todo sin un
   * filtro por `user` u `object`, que un `Read` por tipo-solo sin user
   * rechazaría con 400— y devuelve SOLO las tuplas de relación de la partición
   * pedida: tipo `group` o un tipo declarado en la config, DESCARTANDO las de
   * `facts` (`scope`/`role`/`role_binding`, que no llevan la partición en el id
   * con la forma `<key>|<uuid>` de relaciones —o cuyo tipo no está declarado—).
   *
   * `truncated`/paginación: `enumerateRelations` agota el `Read` (exhaustivo,
   * como `listSubjects`/`purge*`), así que devuelve TODO en una página sin
   * cursor —el reconcile itera hasta que no hay cursor—. Es el ORIGEN de una
   * migración: una tupla que no llegara aquí desaparecería sin rastro — por eso
   * la CADUCADA también llega, con su `expiresAt` (R-15), para que el destino
   * la cuente en `skipped`.
   *
   * **Coste: O(tuplas del store) por PASADA** (2.4.0-alpha.6): es un barrido
   * entero por llamada, sea cual sea el tamaño de la partición (medido: 5 000
   * tuplas ⇒ 50 páginas ≈ 170 ms; 15 000 ⇒ 151 páginas ≈ 0,5 s). Para K
   * particiones usa `enumerateRelationsMany`: UN barrido en vez de K.
   */
  async enumerateRelations(partition: ScopeRef, _page?: RelationPage): Promise<RelationTuplePage> {
    assertPartition(partition)
    return this.#sweep([partition], 'enumerateRelations')
  }

  /**
   * **`enumerateRelationsMany` — K particiones en UN barrido** (2.4.0-alpha.6;
   * panel relay, analista §3: con 3 particiones 1,4 s → 0,46 s). MISMA
   * semántica que `enumerateRelations` por cada partición pedida —exhaustiva,
   * sin filtrar la caducada, todo en una página sin cursor— y cada tupla
   * viene con SU `partition` (la referencia que pasó el llamante, casada por
   * `scopeKey` ENTERA), de modo que el llamante reparte por `partition`.
   * Reparte un solo `Read({})` paginado del store entero.
   *
   * **Lo que este método NO hace, a propósito: un `Read` por PREFIJO de id.**
   * OpenFGA no tiene prefix-match: `Read({ object: 'document:unit|<uuid>|' })`
   * responde **200 con cero tuplas** (medido por el panel, auditor 🔴 3) — en
   * el ORIGEN de una migración eso es «esta partición está vacía» en silencio,
   * y en una purga, «demostrado cero» sin haber borrado nada. El único filtro
   * legal es `{}`; la partición se decide comparando la CLAVE entera del id
   * parseado desde la derecha (`#parseObjectId`), así que `app` no arrastra a
   * `appliance|…`, `org|U` no arrastra a `organization|U` y cada ortografía del
   * uuid es su propia partición. La suite espía el FILTRO de cada `read`.
   *
   * **Exhaustivo o ruidoso**: una página con cero tuplas y token de
   * continuación NO es el fin; un token que se repite, más de
   * `MAX_READ_PAGES` páginas o una respuesta sin `tuples` son 503
   * `E_AUTHZ_BACKEND_UNAVAILABLE` (`#readAll`); una tupla que no se entiende
   * se cuenta en `diagnostics.unparseableTuples` y se avisa. Sin particiones
   * es 500 `E_AUTHZ_CONFIG` con cero lecturas: no hay «éxito vacío».
   */
  async enumerateRelationsMany(partitions: ScopeRef[], _page?: RelationPage): Promise<RelationTuplePage> {
    if (!Array.isArray(partitions) || partitions.length === 0) {
      throw new AuthorizationConfigError(
        'enumerateRelationsMany: sin particiones no hay nada que enumerar (y un barrido del store para nadie no es un éxito vacío). ' +
          'Pasa al menos una partición.'
      )
    }
    for (const partition of partitions) assertPartition(partition)
    return this.#sweep(partitions, 'enumerateRelationsMany')
  }

  /** El barrido: UN `Read({})` paginado del store entero, repartido por la clave ENTERA de partición. */
  async #sweep(partitions: ScopeRef[], operation: string): Promise<RelationTuplePage> {
    // La primera referencia de cada clave es la que viaja en `tuple.partition`
    // (dos ortografías del mismo uuid son dos claves, como en `enumerateRelations`).
    const wanted = new Map<string, ScopeRef>()
    for (const partition of partitions) {
      const key = this.#keyOf(partition)
      if (!wanted.has(key)) wanted.set(key, partition)
    }
    const relationTypes = new Set<string>([FACTS_GROUP_TYPE, ...this.#config.objectTypes.map((t) => t.type)])
    const all = await this.#readAll(operation, {})
    const tuples: RelationTuple[] = []
    for (const key of all) {
      const parsed = this.#parseObjectId(key.object)
      // No es una tupla de relación (facts: scope/role/role_binding, o un tipo
      // no declarado): no la migra este puerto.
      if (!parsed || !relationTypes.has(parsed.type)) continue
      const partition = wanted.get(parsed.partitionKey)
      if (partition === undefined) continue // otra partición: no cruza (clave ENTERA, nunca prefijo)
      const subject = this.#userToSubject(key.user)
      if (!subject) {
        this.#warnUnparseable(operation, key.user)
        continue
      }
      tuples.push({
        subject,
        // Lote D · D2: `denied_<rel>` ⇒ `{ relation: <rel>, kind: 'deny' }` (`storedRelationKind`, punto de paso único).
        ...storedRelationKind(key.relation),
        object: { type: parsed.type, id: parsed.objectUuid },
        partition,
        expiresAt: key.validUntil,
      })
    }
    return { tuples }
  }

  /* ── Purga (invariante 11): borra y DEMUESTRA cero, o lanza ─────────────── */

  /**
   * Borra TODAS las tuplas del objeto (cualquier relación) y demuestra cero.
   * Hasta 2.5.0 barría las DOS ortografías del uuid de partición (🟡2);
   * desde D4 (plan 2.5 · lote A) la ortografía sin guiones es 422 en la
   * puerta y la clave es una. Si tras borrar quedan tuplas ⇒ 500
   * `E_AUTHZ_PURGE_INCOMPLETE`.
   */
  async purgeObject(object: RelObject, partition: ScopeRef, options?: RelationTransactionOptions): Promise<void> {
    this.#rejectTransaction('purgeObject', options)
    // alpha.3 · F-05 (solo el TIPO: una purga no nombra relación), antes de componer el id.
    // Cierre-2: la función de TIPO, no la estricta con relación opcional.
    assertObjectTypeDeclared(this.#config, object)
    assertPartition(partition)
    const objectId = this.#objectId(object.type, this.#keyOf(partition), object.id)
    const progress = { deleted: 0 }
    try {
      await this.#purgeByFilters('purgeObject', [[{ object: objectId }, `objeto ${objectId}`]], progress)
    } catch (error) {
      throw this.#partialIfDeleted(error, progress)
    }
  }

  /**
   * Borra TODAS las tuplas cuyo SUJETO es este subject en la partición, en
   * cualquier tipo de objeto declarado, y demuestra cero. `Read` exige un
   * filtro de objeto (un `Read` solo por `user` es un 400 del servidor), así
   * que se recorre cada tipo declarado (`group` + los del consumidor) con
   * `Read({ user, object: '<type>:' })`.
   */
  async purgeSubject(subject: RelSubject, partition: ScopeRef, options?: RelationTransactionOptions): Promise<void> {
    this.#rejectTransaction('purgeSubject', options)
    // alpha.3 · F-05 del USERSET (una purga por sujeto no nombra objeto), antes de nada.
    if (isRelUserset(subject)) assertRelationDeclared(this.#config, subject.object, subject.relation)
    assertPartition(partition)
    if (!isRelUserset(subject)) assertSubject(subject)
    const user = this.#subjectUser(subject, this.#keyOf(partition))
    const types = [FACTS_GROUP_TYPE, ...this.#config.objectTypes.map((t) => t.type)]
    const progress = { deleted: 0 }
    try {
      await this.#purgeByFilters(
        'purgeSubject',
        types.map((type) => [{ user, object: `${type}:` }, `sujeto ${user} en '${type}'`] as const),
        progress
      )
    } catch (error) {
      throw this.#partialIfDeleted(error, progress)
    }
  }

  /**
   * **Una purga que muere a MEDIAS es indeterminada** (invariante 13,
   * 2.4.0-alpha.3, cierre del 🟡 6 del auditor). La purga NO es un `Write`:
   * son N `Read`+`deleteTuples` (ortografías × tipos, y lotes de
   * `RELATIONS_PURGE_WRITE_MAX`), y un 503 que no es timeout —o el 500
   * `E_AUTHZ_PURGE_INCOMPLETE` de la demostración de cero— puede llegar
   * después de haber borrado parte. Si YA se borró al menos una tupla, el
   * error se marca (`markPartialWrite`, `src/errors.ts`: una propiedad, la
   * clase y el `code` no cambian) y el `RelationsManager` notifica
   * `onRelationWrite` con `indeterminate: true` ANTES de propagarlo — «puede
   * haber ocurrido», como con el deadline. Si no se borró nada, el error va
   * tal cual: «esa escritura no ocurrió» sigue siendo verdad. En `database`
   * la purga es UN `DELETE` y no necesita la marca.
   */
  #partialIfDeleted(error: unknown, progress: { deleted: number }): unknown {
    if (progress.deleted > 0 && error !== null && typeof error === 'object') return markPartialWrite(error)
    return error
  }

  /**
   * **Lee TODOS los filtros, borra en un `Write` si cabe —y si no, en ORDEN GLOBAL: allows → membresías → denies— y
   * RE-LEE cada filtro para demostrar cero (o lanza)** (lote D · D-16/D-26/S3; cierre 1 de D1, 🟠 1 del auditor; el
   * orden S6 de roles, invariante 6). La propiedad: **una purga cortada a medias no concede nada que no concedieran el
   * estado inicial o el final** —con la única excepción DECLARADA de abajo—.
   *
   *  - **Cabe en `RELATIONS_PURGE_WRITE_MAX` (100) ⇒ UN solo `Write`**: FGA lo aplica de forma transaccional (medido:
   *    101 es 400 y no se aplica nada), así que NO hay estado intermedio que cortar.
   *  - **No cabe ⇒ tres clases, cada una en sus propios `Write`, en el orden de BORRADO del punto de paso ÚNICO
   *    `relationDeleteOrder`** (`src/relations/tuple_order.ts`; cierre 1 de D2 · 🟠 1: el mismo que el reconcile): (1) los allows sobre objetos que no son
   *    `group` —quitar un allow solo resta (D-12, monotonía)—; (2) las MEMBRESÍAS `group:*#member@<sujeto>` —una membresía
   *    TRANSPORTA allows y denies a la vez: borrarla antes que un allow directo deja ese allow sin el deny que lo cortaba
   *    (🟠 1: con el orden «solo prefijo» de alpha.3-dev, `group:g#member@U` caía en el lote 1 y `doc:V#viewer@U` en el 2;
   *    cortada entre los dos, U CONCEDÍA sobre V; la gemela `purgeSubject(g#member)` con la arista anidada
   *    `group:h#member@group:g#member`)—, en UN `Write` PROPIO si caben (ordenadas por objeto, las portadoras de deny al
   *    final: el reparto no depende del `Read`); (3) los `denied_*`, al final —quedan denies de MÁS, nunca de menos—.
   *  - **Residuo DECLARADO**: con MÁS de 100 membresías del sujeto no caben en un `Write`, y una que transporta un deny
   *    puede caer en un lote anterior a otra que transporta un allow (fila con caso en `relations_openfga.spec`, frase en
   *    el README). No se niega la purga antes de borrar (invariante 11: una purga no espera; un 500 dejaría al sujeto de
   *    baja con TODO su acceso): sale marcada como parcial (`indeterminate: true`) y se repite.
   *
   * `purgeObject` pasa por aquí igual: sobre un objeto que no es `group` no hay membresías (allows → denies); sobre
   * `group:g` todo son membresías de g, y cada miembro queda dentro o fuera de g —su estado inicial o el final—.
   * `progress.deleted` cuenta lo que YA se borró (un lote que falla no borró nada) para la marca de escritura parcial
   * (invariante 13).
   */
  async #purgeByFilters(
    operation: string,
    filters: ReadonlyArray<readonly [{ user?: string; relation?: string; object: string }, string]>,
    progress: { deleted: number }
  ): Promise<void> {
    const read: Array<{ filter: { user?: string; relation?: string; object: string }; what: string; keys: StoredRelationTuple[] }> = []
    for (const [filter, what] of filters) read.push({ filter, what, keys: await this.#readAll(operation, filter) })
    for (const batch of purgeWrites(read.flatMap((r) => r.keys))) {
      try {
        await this.#guard(operation, () =>
          this.client.deleteTuples(
            batch.map((k) => ({ user: k.user, relation: k.relation, object: k.object })),
            IGNORE_MISSING_DELETES
          )
        )
      } catch (error) {
        // Cierre 2 de D1 · ⚪ N3: el 400 del tope de operaciones por `Write` del SERVIDOR no es una caída (503
        // reintentable): es un despliegue con `--max-tuples-per-write` < `RELATIONS_PURGE_WRITE_MAX`. 500 con la letra;
        // la marca de escritura parcial la pone `#partialIfDeleted` si ya se aplicó un `Write` anterior.
        if (isServerWriteLimit(error)) throw purgeWriteLimitError(operation, batch.length, progress.deleted, error)
        throw error
      }
      progress.deleted += batch.length
    }
    // Demostración de cero: re-lee tras borrar (invariante 11), solo los filtros que tenían algo.
    for (const { filter, what, keys } of read) {
      if (keys.length === 0) continue
      const residue = await this.#readAll(operation, filter)
      if (residue.length > 0) {
        throw new PurgeIncompleteError(
          `${operation}: quedan ${residue.length} tuplas de ${what} tras el borrado ` +
            `(${residue.slice(0, 3).map((k) => `${k.user}#${k.relation}@${k.object}`).join('; ')}). ` +
            `No se confirma la purga.`
        )
      }
    }
  }

  /* ── Helpers ────────────────────────────────────────────────────────────── */

  /**
   * **El envoltorio ÚNICO de `Read`** (B4, la otra mitad de la propiedad
   * universal): TODAS las tuplas que casan con el filtro, paginando `Read`
   * hasta agotar el `continuation_token`. `Read` no tiene tope de resultados
   * (a diferencia de `ListObjects`), así que es exhaustivo — por eso las purgas,
   * `listSubjects` y `enumerateRelations(Many)` van por aquí, no por
   * `ListObjects` — y cuando NO puede serlo, lanza 503 en vez de devolver una
   * página corta: una respuesta sin `tuples`, un token que se repite (el
   * servidor no avanza; una página vacía con token cae aquí) o más de
   * `MAX_READ_PAGES` páginas. La guardia de superficie (columna `truncation`)
   * sondea las cinco operaciones que entran por aquí con un mutante que
   * «termina» en la página vacía.
   */
  async #readAll(
    operation: string,
    filter: { user?: string; relation?: string; object?: string }
  ): Promise<StoredRelationTuple[]> {
    const keys: StoredRelationTuple[] = []
    let continuationToken: string | undefined
    const seenTokens = new Set<string>()
    let pages = 0
    do {
      const response = await this.#guard(operation, () =>
        this.client.read(filter, {
          pageSize: READ_PAGE_SIZE,
          continuationToken,
          consistency: this.#consistency,
        })
      )
      pages += 1
      // «Exhaustivo o ruidoso» (alpha.6): una respuesta que no trae `tuples`
      // no se entiende — no es una página vacía. Un 200 sin forma en el ORIGEN
      // de una migración sería «no hay nada» en silencio.
      if (!Array.isArray(response?.tuples)) {
        throw new AuthorizationBackendError(
          'openfga-relations',
          operation,
          new Error(`la respuesta del Read (página ${pages}) no trae 'tuples'; no se toma por vacía`)
        )
      }
      for (const tuple of response.tuples) {
        const key: any = tuple?.key
        if (!key?.user || !key?.relation || !key?.object) {
          this.#warnUnparseable(operation, JSON.stringify(key ?? null))
          continue
        }
        // Con su caducidad (R-15): quien la lee decide si filtra (`listSubjects`),
        // la emite (`enumerateRelations`) o la ignora (`purge*` borra TODO).
        keys.push({
          user: key.user,
          relation: key.relation,
          object: key.object,
          validUntil: toExpiryDate(key.condition?.context?.valid_until),
        })
      }
      continuationToken = response.continuation_token || undefined
      if (continuationToken) {
        if (seenTokens.has(continuationToken)) {
          throw new AuthorizationBackendError(
            'openfga-relations',
            operation,
            new Error(`el continuation_token se repite (página ${pages}); el servidor no avanza`)
          )
        }
        if (pages >= MAX_READ_PAGES) {
          throw new AuthorizationBackendError(
            'openfga-relations',
            operation,
            new Error(`más de ${MAX_READ_PAGES} páginas sin agotar el Read`)
          )
        }
        seenTokens.add(continuationToken)
      }
    } while (continuationToken)
    return keys
  }

  #warnUnparseable(operation: string, detail: string): void {
    this.diagnostics.unparseableTuples += 1
    this.#logger.warn(
      `authz(openfga-relations): tupla no parseable en ${operation} (${detail}); ` +
        `se ignora en la enumeración (total: ${this.diagnostics.unparseableTuples})`
    )
  }
}

// Cierre-2 de alpha.3 (⚪ 5 del re-ataque): la clasificación de timeout es la
// de `src/shared/backend_guard.ts` —`isTimeoutLike`: `KnexTimeoutError`,
// `.timeout` numérico, `ECONNABORTED`/`ETIMEDOUT`, por la cadena de `cause`—,
// la MISMA que importa el driver de roles. Hasta el cierre-2 este fichero
// duplicaba la función con una rama por SUBSTRING del mensaje (`/timeout/i`),
// de modo que un 400 de validación de FGA o el cuerpo de un 502 que mencionara
// la palabra salía como 503 `E_AUTHZ_BACKEND_TIMEOUT` con `indeterminate: true`
// sin haber borrado nada (medido por el auditor: `alpha3-cierre-parcial.ts` B).

/** Igualdad ESTRUCTURAL de dos reglas de reescritura (D-31, cierre 2 de D1 · ⚪ N4); una ausente nunca es igual. */
function sameRewrite(served: unknown, generated: unknown): boolean {
  if (served === undefined || generated === undefined) return false
  return JSON.stringify(canonicalRewrite(served)) === JSON.stringify(canonicalRewrite(generated))
}

/** La LETRA del 500 de N3 (fijada por `relations_openfga.spec`, «⚪ N3 · …»). */
function purgeWriteLimitError(operation: string, size: number, deleted: number, cause: unknown): AuthorizationConfigError {
  const sdk = (cause as { cause?: { apiErrorMessage?: unknown } } | null)?.cause?.apiErrorMessage
  return new AuthorizationConfigError(
    `OpenFgaRelationsDriver: ${operation}: el servidor OpenFGA rechazó un Write de ${size} tuplas por su tope de ` +
      `operaciones por Write (exceeded_entity_limit${typeof sdk === 'string' ? `: «${sdk}»` : ''}). El driver parte las ` +
      `purgas en RELATIONS_PURGE_WRITE_MAX = ${RELATIONS_PURGE_WRITE_MAX} y exige --max-tuples-per-write ≥ ` +
      `${RELATIONS_PURGE_WRITE_MAX} en el servidor (OPENFGA_MAX_TUPLES_PER_WRITE; el default es ${RELATIONS_PURGE_WRITE_MAX}). ` +
      `No es transitorio: repetida, la purga vuelve a fallar igual. ` +
      (deleted > 0
        ? `Ya se habían borrado ${deleted} tuplas en Write anteriores: la purga quedó A MEDIAS (escritura parcial).`
        : 'No se borró nada.'),
    { cause }
  )
}

/**
 * **Los `Write` de una purga, en orden** (lote D · cierre 1 de D1, 🟠 1; ver `#purgeByFilters`): uno solo si todo cabe
 * en `RELATIONS_PURGE_WRITE_MAX`; si no, en el orden de BORRADO del punto de paso ÚNICO `relationDeleteOrder`
 * (`src/relations/tuple_order.ts`, cierre 1 de D2 · 🟠 1: el MISMO que usa el reconcile) — allows sobre objetos que no
 * son `group`, luego las membresías `group:*#member` (las portadoras de deny al final, ordenadas por objeto y sujeto) y
 * al final los `denied_*` —, con CADA CLASE en sus PROPIOS `Write` (con ≤ 100 membresías, uno). Pura: la tabla de verdad
 * del caso la juzga contra el servidor, y la PROPIEDAD la juzga sin servidor la guardia de superficie
 * (`GS · P · openfga.purge.order`, cierre 2 de D1 · ⚪ N2), con los mutantes de orden en el corredor publicado
 * (`npm run check:guard-mutants`). Exportada solo para eso: no sale por `/openfga`.
 */
export function purgeWrites<K extends { user: string; relation: string; object: string }>(keys: readonly K[]): K[][] {
  if (keys.length === 0) return []
  if (keys.length <= RELATIONS_PURGE_WRITE_MAX) return [[...keys]]
  const view = (k: K): RelationOrderView => ({ deny: k.relation.startsWith(RELATION_DENY_PREFIX), object: k.object, user: k.user })
  const ordered = relationDeleteOrder(keys, view)
  const chunks = (list: K[]): K[][] => {
    const out: K[][] = []
    for (let i = 0; i < list.length; i += RELATIONS_PURGE_WRITE_MAX) out.push(list.slice(i, i + RELATIONS_PURGE_WRITE_MAX))
    return out
  }
  // Cada CLASE en sus propios `Write`: una membresía nunca comparte lote con el último allow ni con el primer deny.
  const runs: K[][] = []
  let previous: string | undefined
  for (const k of ordered) {
    const cls = relationOrderClass(view(k))
    if (cls !== previous) runs.push([])
    runs[runs.length - 1].push(k)
    previous = cls
  }
  return runs.flatMap(chunks)
}

/**
 * **El error de una renovación en dos `Write` NOMBRA el deny que entró en la ventana** (cierre 3 de D2 · 🟡 C2-3). Sobre
 * el error que se propaga (su clase y su `code` no cambian): `carriedDeny` = el deny que la re-comprobación encontró, y la
 * letra con la receta; si la re-comprobación también falló, lo dice (`carriedDenyUnknown: true`). `applied` = la
 * renovación SÍ se aplicó y lo que falló es solo la re-comprobación. Un error congelado se propaga tal cual.
 */
function annotateRacedDeny<E extends object>(
  error: E,
  membership: string,
  recheck: { deny: string | null; error?: unknown },
  applied = false
): E {
  let note: string | null = null
  const target = error as any
  try {
    if (recheck.deny !== null) {
      target.carriedDeny = recheck.deny
      note =
        ` — Cierre 3 de D2 (C2-3): la membresía ${membership} quedó BORRADA y un deny concurrente (${recheck.deny}) que ` +
        'entró en el grupo durante la renovación ya NO alcanza al sujeto por ella, y no lo alcanzará hasta que la ' +
        'membresía se reescriba. Receta: vuelve a escribirla (relate: ya no existe, así que es UN Write) o retira y ' +
        'reescribe ese deny después.'
    } else if (recheck.error !== undefined) {
      target.carriedDenyUnknown = true
      note = applied
        ? ` — Cierre 3 de D2 (C2-3): la renovación de ${membership} SE APLICÓ, pero la re-comprobación de un deny ` +
          'concurrente en su grupo falló: no se sabe si un deny entró en la ventana entre los dos Write. Receta: lista los ' +
          'denies del grupo (listDenies) y revisa las decisiones de ese sujeto en esa ventana.'
        : ` — Cierre 3 de D2 (C2-3): la membresía ${membership} quedó BORRADA y la re-comprobación de un deny concurrente ` +
          'en su grupo también falló. Receta: vuelve a escribir la membresía (relate) y lista los denies del grupo.'
    }
    if (note !== null && typeof target.message === 'string') target.message += note
  } catch {
    // Un error congelado no admite la nota: se propaga el original (la clase y el `code` no cambian).
  }
  return error
}
