# Fase 3b · Lote 3b-0b — correcciones del auditor sobre el 3b-0 (tester por incorporar)

> Auditor sobre `2613916`: **APTA CON CORRECCIONES**, sin 🔴 ni 🟠. Por la regla de parada no bloquea la fase, **pero estos cuatro 🟡 son sobre el código que el 3b-0 acaba de añadir** (no deuda heredada), así que se cierran aquí y no en 3b-1. Evidencia y scripts: `fase-3b-verificacion-auditor-0.md` y `…/scratchpad/v12/` (`z1_despertar.ts`, `z2_prune.ts`, `z3_detached.ts`, `z4_dormido.ts`).
>
> **Confirmado por medición** (no hay que tocarlo): quitar la policy de rango de `detached` fue eliminar una protección accidental —el atacante solo tenía que elegir un scope *sin* roles locales para lograr lo mismo—, y a cambio se cerraron dos ataques. Con `requireWithin: true`/`'non-root'` sigue cerrado en los cinco caminos, alias del uuid incluido.

## Respuestas a sus dos preguntas (decididas)

1. **¿`pruneOrphanRoles` público o detrás de una fachada de plataforma?** **Público, pero con un seguro contra el accidente real.** El peligro medido no es que alguien lo llame a mano: es un `resolveChain` **filtrado por el tenant de la petición** (patrón normal en multi-tenant) o sin contexto, que devuelve `null` para todo y convierte una pasada con `--force` en un borrado del catálogo local entero. Se cierra con una cota, no con ceremonia.
2. **¿`authz:reconcile` barrerá los hechos de scopes que ya no resuelven?** **Sí** — entra en el Lote 3b-3 como parte del contrato de `reconcile` (`--to=database` y `--to=openfga` reportan y, con `--prune`, borran los hechos cuyo scope no resuelve). Con eso, el hallazgo 2 queda cerrado ahí y aquí basta la línea en el CHANGELOG.

## Bloqueantes

| # | Hallazgo | Decisión |
|---|---|---|
| **AA1** 🟡 | La premisa **«un rol dormido no concede, no es membresía y no se puede asignar» es FALSA** y está publicada en tres sitios (`README.md:252`, `CLAUDE.md:121`, docblock de `manager.ts:1096-1101` + el del comando) — y es **la justificación escrita de purgar sin actor y sin rango**. Medido en el caso (c): con un descendiente vivo cuya cadena pasa por el owner, el rol concede, es membresía, se enumera por los seis caminos y **se puede asignar** por slug y por uuid. | (a) Corregir la frase en los tres sitios: *dormido = no visible desde ningún scope vivo cuya cadena **no** pase por el owner*; un descendiente vivo que aún lo ve **sí** lo usa. (b) `pruneOrphanRoles`/`--dry-run` **marca** los huérfanos que todavía conceden (`stillGranting: true`, contando asignaciones vigentes) y el comando los lista aparte con un aviso. (c) Caso que fija los dos lados: huérfano sin descendiente vivo ⇒ no concede; con descendiente vivo ⇒ concede y el barrido lo marca. |
| **AA2** 🟡 | **Purga en masa por resolutor ciego**: con `requireActor: true` y `requireWithin: true`, `pruneOrphanRoles({force:true})` no lanza, no mide rango y no audita; con un `resolveChain` filtrado por tenant, `orphans = todos` y `--force` se lleva el catálogo local completo (medido: 2 de 2 roles vivos borrados). | Cota de seguridad: si **todos** los owners distintos resultan huérfanos, o si los huérfanos superan el **50 %** de los roles locales, ⇒ 500 `E_AUTHZ_MASS_PURGE_REFUSED` nombrando el ratio y exigiendo `allowMassPurge: true` (`--allow-mass-purge` en el comando). Es exactamente la firma de un resolutor ciego. Documentar el método como **API de plataforma** junto a `driver()` en README y `CLAUDE.md`. Casos: ratio 100 % ⇒ rechazado; con la bandera ⇒ purga; ratio bajo ⇒ purga sin bandera. |
| **AA3** 🟡 | **TOCTOU en el barrido**: resuelve todos los owners en un bucle y purga en otro; un `attached`/restore concurrente durante la pasada borra un rol cuyo owner **ya resuelve** (medido: `filas de "lead3" (owner VIVO en el momento de la purga): 0`). | Re-resolver el owner **justo antes** de cada `purgeRole` (resolutor fresco); si resuelve, se salta y se cuenta en el reporte (`skipped: [{ role, reason: 'owner-came-back' }]`). Caso con resolutor que devuelve `null` la primera vez y la cadena después. |
| **AA4** 🟡 | **Resurrección**: los hechos del nieto sobreviven al `detached` del ancestro y vuelven a conceder si el owner se restaura con el mismo uuid — en 3G el rol se llevaba sus asignaciones. Es coherente con el invariante 11, pero el CHANGELOG marca el lote *breaking* y no lo menciona. | Línea explícita en CHANGELOG y README: `scopes.detached` purga **el scope exacto**; los hechos de descendientes cuya ruta pasaba por él sobreviven y **vuelven a conceder si el scope se restaura**; la limpieza de esos hechos es de `authz:reconcile` (3b-3). Caso que lo fija (hoy solo lo mide el script del auditor). |

## Obligatorias (rápidas)

| # | Qué |
|---|---|
| AB1 | ⚪ `src/manager.ts:1334` sigue aconsejando «vigila `truncated`», campo borrado en este lote. |
| AB2 | ⚪ `readLocalRoles()` sin cota: leer **todos** los roles locales en una consulta. Añadir `maxLocalRoles` (default 10 000) ⇒ 500 si se supera, coherente con el resto de cotas del paquete. |
| AB3 | ⚪ Purga parcial: si un `purgeRole` falla a mitad, los anteriores ya están borrados. Está asumido en el docblock, pero con AA1 significa revocación parcial de permisos vivos: el reporte debe decir **qué** se purgó antes del fallo (`purged: CatalogRoleRef[]`, no solo un contador). |
| AB4 | CHANGELOG «Lot 3b-0b»; `CLAUDE.md` invariante 18 con la definición corregida de «dormido». |

## Entrega
`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-3b-lote-0b-informe.md` incremental. Sin commits.
