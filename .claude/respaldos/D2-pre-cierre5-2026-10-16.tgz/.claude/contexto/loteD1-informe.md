# Lote D · sublote D1 (núcleo del deny) — informe del implementador · 2026-10-15

**Árbol `main` sobre `493c649`** (= `v2.5.0-alpha.2`). Único agente que muta el árbol; **sin commit, sin tocar `version`,
sin push**. Entorno: Node 22.23.2 (`nvm use 22`), `postgres18`, `mysql84`, OpenFGA **`:8090`** (`openfga-dev`, reiniciado
antes de cada suite), `openfga-tiny` `:8103` levantado SOLO para S16 y **borrado** al terminar (`docker ps -a` ⇒ 0).
Brief: `loteD-coordinador.md` parte «D1». Lo de D2 (reconcile con `kind`, guarda de `provision`, runbook, rollback, L9 de
linaje) NO se tocó (ver §6).

Decisiones del coordinador aplicadas tal cual: D3 (sin caducidad, `expiresAt` ⇒ 422, D-19 reescrito, S1/S2/S7/D-25 no
aplican), D5 (corte de camino), D8 (`database` honra siempre), D9 (`decideMany` amplio con las garantías de `checkMany`,
P-2 y su gemelo), D10 (dos fases), D14, D15 (`relationDenies?`), S12 por camino, el deny transportado por membresía con
caducidad. `EXPECTED_FUSED` y `migration_stub.spec` **sin tocar** (D-29: verdes sin cambio; `git diff` no los toca).

---

## 0 · Rojos observados por pieza

Método: (a) la guardia de superficie con el código del deny ya en `src/` y SIN filas — el rojo literal que pide el punto
11; (b) para cada pieza de semántica, el caso nuevo corrido contra el código SIN la pieza (un mutante de «retirada»: la
línea del lote D quitada o devuelta a su forma de alpha.2), en una copia del árbol (`scratchpad/d1/mutrun.py`,
`piece_mutants.json`, log `piece_mut.log`). Los casos se escribieron después de `src/` en esta sesión, así que el «rojo
antes» que se puede EXHIBIR es ese: el del caso contra el código sin la pieza (declarado aquí, no escondido).

| Pieza | Rojo observado |
|---|---|
| **Guardia L1 (punto 11)** | `deny`/`removeDeny`/`listDenies`/`decideMany` en `src/` y el manifiesto sin tocar ⇒ **13 rojos** en `guard_surface.spec` (`scratchpad/d1/red-guard.log`): G-0 en las TRES capas («RelationsManager / DatabaseRelationsDriver / OpenFgaRelationsDriver tiene operaciones SIN fila … deny, removeDeny, listDenies, decideMany»), G-0 «el servicio» («lo que sirve el contenedor expone operaciones sin fila: deny, removeDeny, listDenies, decideMany»), G-R «clasificación obligatoria» (🟡 E: «manager.deny: operación SIN CLASIFICAR — añádela a PORT_WRITES o a PORT_READS», ×4 capas × 4 ops), G-R «no hay forma de invocar manager.deny — añade la entrada en INVOKE», y los dos repros del inventario (🟡 3 / 🟡 C) con las cuatro operaciones de más. El doble nació rojo igual al declarar `relationDenies: true` en el FULL de la guardia. Tras la fila: G-M rojo («celdas con sonda SIN mutante … manager.deny.f05, …») hasta escribir los 39 mutantes nuevos, y 12 `find` de mutantes viejos dejaron de casar por el refactor (`#upsert`/`#deleteTuple`/`#readMany`/la guarda del modelo) — corregidos uno a uno. |
| config (D10, D-18, D-29) | `deny: true` aceptado ⇒ rojo «D10 · deny: 'read' y 'write' entran…»; sin la cota de 43 ⇒ rojo «D-18»; la copia congelada que pierde `deny` ⇒ 22 rojos (DENY_DEF, T1 en openfga, D-17); una clave `deny: undefined` en los tipos sin deny ⇒ rojo «D-29 · … EXPECTED_FUSED». Y el caso de B2 «`deny: true` en el tipo ⇒ clave desconocida» se puso rojo con la pieza (esperado: la clave ya existe) ⇒ reescrito (§1). |
| generador (D5 en el modelo) | `denied_X = this` sin cierre ascendente (semántica CAMINO del tester) ⇒ 10 rojos (DENY_DEF, D-05, D-06, D-07, D-08, D9 en openfga…); `X` sin `but not` ⇒ 20 rojos (T1 y todo el deny en openfga). |
| `check`/`checkMany`/`listObjects`/`decideMany` de `database` (D5/D8) | la SQL de alpha.2 (sin leer `denied_*`) ⇒ 17 rojos (D-05, D-06…D-11, D-01, D8…); `listObjects` sin corte ⇒ D-05 + D8; `membersOf` sin resta ⇒ D-15b. |
| regla única (`cutPathAllows`/`decideFrom`) | CORTE-INV (el corte con `down*` en vez de `up*`, mutante del auditor 🟠 5) ⇒ 19 rojos en dobles y `database`; `decideMany` ESTRECHO (`deny` solo si `R ∈ D`, H2) ⇒ 5 rojos (D9 fila 35, D-05, D8). |
| `openfga` (D-26/S3, D-31, D14, D9, S12, S15, S13) | purga en orden del `Read` ⇒ «D-26 / S3 … ROJO (S3): la purga cortada dejó un allow VIVO sin su deny»; sin la guarda del modelo ⇒ D-31; sin la comprobación del pin ⇒ D14; `decideMany` estrecho (`denied_R` en vez de las fuentes: el conflicto del juez §4) ⇒ D9 + D-05 + PARIDAD del puente; S12 por camino ⇒ 1 rojo por camino (+ S15 en `decideMany`); `context` por ítem ⇒ S13. |
| manager (D-17, D-19, D-20, D-28, D9 de terceros) | sin la puerta del opt-in ⇒ D-17 (el driver la re-aplica, pero ya con llamadas); sin `assertDenyNoExpiry` ⇒ D-19; sin `assertDenySubject` ⇒ D-17 (`*` da `E_AUTHZ_INVALID_IDENTITY`); capacidad abierta ⇒ D-28 (×2); sin validar la respuesta ⇒ «decideMany frente a un driver de TERCEROS»; el evento con `operation: 'relate'` ⇒ D-20. |
| doble (`principalOf`) | sin grupos en el principal ⇒ 13 rojos (D-13, D-05, M6…). |

**Casos EXISTENTES que el lote puso rojos** (justificados, punto 5 c): (1) `capabilities.spec` «alpha.4 · D-4 … las claves
de RELACIONES» ×2 — la lista literal gana `relationDenies` (clave nueva, D15) ⇒ actualizada. (2) `relations.spec` B2
«`deny: true` en el TIPO (la clave que el lote D introducirá) ⇒ clave desconocida» — el propio caso anunciaba el lote D;
reescrito: `denny` ⇒ clave desconocida (con `deny` ya en la lista blanca) y `deny: true` ⇒ 422 de VALOR nombrando las dos
fases. (3) `relations_harness.spec` ×3 — el conteo deja de ser un número (H9): núcleo 29 + cara `true` 22 / cara `false` 1.
(4) `guard_surface.spec` ⚪11 (el doble tiene 14 operaciones con tupla, no 10) y 🟡E (el repro usaba `deny` como operación
SIN clasificar; ahora `deny` está clasificada — el repro pasa a `listObjectsForSubject` del lote C). (5) La sonda
`openfga.purge*.write` de la guardia: «tras borrar» era «la 2.ª `read`»; con el orden global la purga lee TODOS sus
filtros antes de borrar ⇒ la sonda pasa a «la primera `read` DESPUÉS de un `deleteTuples`» (la misma propiedad).
R-02, R-09 y la paridad de `listObjects` del BRIDGE **no** se pusieron rojos (no escriben denies). `EXPECTED_FUSED` y
`migration_stub.spec` tampoco.

---

## 1 · Piezas (ficheros, casos, mutantes)

### 1.1 Config — `src/relations/define_relations_config.ts`
- `RelationObjectTypeSpec.deny?: RelationDenyPhase` (`'read' | 'write'`, D10); `RELATIONS_SPEC_KEYS.objectType` + `'deny'`
  (la guardia de TIPO de B2 lo exige en compilación). Otro valor (incluido `true`) ⇒ 422 `E_AUTHZ_RELATION_CONFIG` con las
  dos fases y la secuencia de despliegue. Cota `DENIABLE_RELATION_NAME_MAX = 50 − 'denied_'.length = 43` solo en tipos con
  `deny` (D-18). La copia congelada solo añade `deny` si se declaró (D-29: un tipo sin deny se congela con las DOS claves
  de alpha.10).
- **Punto de paso ÚNICO del grafo de `includes`** (analista §4.1): `relationsDown`, `relationsUp`, `deniableAbove`
  (`up*(down*(R))`), y la regla ÚNICA: `cutPathAllows` (D5) y `decideFrom` (D9), que usan `database`, el doble y (para la
  forma) `openfga`; `#expandDown` del driver `database` y `expandDown` del doble delegan en `relationsDown`.
- Guardas compartidas por las cuatro capas: `assertRelationDenyable` (solo fase `'write'`; `group` y tipos sin/con fase
  1 ⇒ 422 `E_AUTHZ_RELATION_NOT_DENYABLE`), `assertDenySubject` (`*` ⇒ 422, antes de la gramática), `assertDenyNoExpiry`
  (clave `expiresAt` presente ⇒ 422 `E_AUTHZ_DENY_EXPIRY_UNSUPPORTED`, con la razón M5), `denyPhaseOf`, `hasDenyTypes`,
  `deniedRelationOf`, `RELATION_DENY_PREFIX`. Exportados por la raíz: `DENIABLE_RELATION_NAME_MAX`, `RELATION_DENY_PREFIX`,
  el tipo `RelationDenyPhase`, y los errores `RelationNotDenyableError`, `RelationDenyExpiryError` (`src/errors.ts`).
- Casos: `relations.spec` («D10 · …», «relationsDown / … filas 35 y 43»), `openfga_facts.spec` («D-18 · …»).

### 1.2 Tipos — `src/types.ts`
`RelationRef.operation` y `RelationWriteEvent.operation` + `'deny' | 'removeDeny'` (con la frase de R2-14 en el
docblock); `RelationDenyOptions` (trx + actor, SIN `expiresAt`); `RelationDecision`; `RelationsDriverCapabilities.
relationDenies?: boolean` (opcional, D15) y la clave en `RELATIONS_DRIVER_CAPABILITY_KEYS` (normalizada a `false`); el
puerto gana `deny?`, `removeDeny?`, `listDenies?`, `decideMany?` (opcionales; obligatorios con la capacidad: lo juzga el
manager con 500).

### 1.3 Generador — `src/drivers/openfga_facts.ts`
Tipo con `deny` (en las DOS fases: el modelo es el mismo): `X = difference{base, subtract: denied_X}`, `denied_X = this ∨
denied_P` por cada `P` que incluye a `X` (cierre ascendente), con los mismos `directly_related_user_types` (holders y
`group#member`, con y sin `not_expired`). Sin `deny`: el literal de alpha.10 (D-29). Cota de 43 también en
`assertRelationsConfigPublishable` (defensa en profundidad). Medido: el modelo con `document` en `deny` publica (201) y
la fila 35 da `owner/editor/viewer = F`, `denied_owner = T` (`.claude/reproducciones/d1_model.ts`). Caso «DENY_DEF · …»
(literal nuevo) y «D-29 · un tipo SIN deny pasado por defineRelationsConfig genera EXACTAMENTE EXPECTED_FUSED».

### 1.4 Manager — `src/relations/manager.ts`
`deny` (puerta trx → freeze → F-05 → capacidad → opt-in → sin caducidad → id → actor → partición → `*` → sujeto →
`assertWrite` con `'deny'` → `#write` → `#notify`), `removeDeny` (igual SIN la puerta del opt-in: cualquier tipo
declarado), `listDenies` (F-05 → capacidad → partición → id), `decideMany` (tope/`[]` con `decideMany` en el mensaje →
F-05 e id POR ÍTEM → capacidad → partición → sujeto → valida la respuesta: una decisión por posición sin huecos, o 500
`E_AUTHZ_INTERNAL` nombrando el driver), `#assertDenies` (D-28: sin `relationDenies === true` o sin el método ⇒ 500
`E_AUTHZ_UNSUPPORTED` con cero llamadas, después de F-05).

### 1.5 Driver `database` — `src/drivers/database_relations_driver.ts`
- `relationDenies: true`. `relate`/`deny` comparten `#upsert` (el check-then-delete-insert idempotente sobre la relación
  ALMACENADA; `deny` escribe `denied_<rel>` con `expires_at = NULL` y rehace permanente un deny escrito a mano con
  caducidad); `unrelate`/`removeDeny` comparten `#deleteTuple` (un `unrelate` nunca toca `denied_*`, D-04).
- `check`: UNA consulta sobre la CTE `principal` que trae `DISTINCT relation` para `down*(R) ∪ denied_{up*(down*(R))}`
  (`#readRelations`) y decide con `cutPathAllows` — **SIEMPRE** (D8: también en un tipo sin opt-in). `checkMany` y
  `decideMany` comparten `#readMany` (UNA consulta, un `now`, F-05 por ítem); `listObjects` trae `(object, relation)` y
  aplica el corte por objeto (D-15); `listDenies` = `#directSubjects` sobre `denied_<rel>`; `membersOf` RESTA: si el
  objeto tiene alguna fila `denied_*` vigente, un `check` por candidato (sin filas deny, cero consultas de más). Las purgas
  no cambian (un `DELETE` que arrastra los `denied_*`).

### 1.6 Driver `openfga` — `src/drivers/openfga_relations_driver.ts`
- `relationDenies: true`. **D14**: con un tipo con `deny` y sin `modelId` ⇒ 500 `E_AUTHZ_CONFIG` al construir.
- **D-31**: `#modelDenied()` lee el modelo (fijado; o el último si no hay tipos con deny) UNA vez por proceso, memo
  compartido con las vistas `withClock`, un fallo no se memoriza; `#assertModelDeny(types)` antes de la primera request
  de `relate`/`unrelate`/`check`/`checkMany`/`listObjects`/`decideMany`/`deny` sobre un tipo con opt-in ⇒ 500
  `E_AUTHZ_CONFIG` nombrando las `denied_<rel>` que faltan. Tipos sin opt-in: coste cero.
- `deny` = UN `Write` de `denied_<rel>` (`on_duplicate: ignore`; sin `Read`, sin caducidad, sin ventana); `removeDeny` =
  UN delete (`on_missing: ignore`), sobre cualquier tipo declarado — medido: `Read`/delete con una relación que el modelo
  no declara responden 200 en v1.19.0, así que no hace falta la guarda del modelo ahí; `listDenies` = `#readAll` por
  `(object, denied_<rel>)` (exhaustivo o 503; columna `truncation` de la guardia).
- `decideMany` = un `batchCheck` con `R` y `denied_<fuente>` por cada relación FUENTE de `down*(R)` (sin `includes`) que el
  modelo declara; un `current_time` para todo el lote; `correlationId` `a<i>` / `d<i>-<k>` (el servidor exige
  `^[\w\d-]{1,36}$`: con `:` respondía error — visto en el primer verde fallido); troceado por 50; `alignBatchResults` (un
  `error` ⇒ 503 total). `check`/`checkMany`/`listObjects` sin cambio de forma: la resta la hace el servidor.
- **Purgas en ORDEN GLOBAL** (`#purgeByFilters`): leer todos los filtros → borrar todos los allows → todos los `denied_*`
  → demostrar cero por filtro; marca de escritura parcial intacta.

### 1.7 Doble — `src/testing/relations_contract.ts`
`check` reescrito sobre el PRINCIPAL (la misma idea que la CTE: el sujeto y sus `group#member` vigentes, transitivo) +
`cutPathAllows`; con `relationDenies: true` trae `deny`/`removeDeny`/`listDenies`/`decideMany` con las mismas guardas;
`membersOf` resta. `contractDenyRelationsConfig()` (exportada en `/testing`): `document` `'write'`, `workspace` `'read'`,
`note` sin opt-in; `contractRelationsConfig()` NO cambia. El espía del runner cuenta también `deny`/`removeDeny` (escrituras)
y `checkMany`/`decideMany`/`listDenies`/`membersOf` (lecturas) y **no envuelve un método opcional ausente** (si no,
`typeof driver.checkMany === 'function'` mentía sobre el MÍNIMO).

### 1.8 Runner — la cara `true` del par `relationDenies` (22 casos) y la `false` (D-28)
D-05 (T1: las 192 de `check` contra la tabla LITERAL del tester + un oráculo escrito a mano sobre el retículo, que tiene que
reproducirla; `checkMany`, `decideMany` y `listObjects` sobre los mismos 64 objetos; D-12 monotonía sobre lo observado;
S16: con tope, la página es un subconjunto y `truncated` solo si hay concedidos de más), D-06…D-11 (las seis filas con
nombre), D-01/02/03, D-04, D-13, D-14, D-15b (`membersOf`), D-16, S8–S10 (filas declaradas), D-17, D-19 (reescrito por
D3), D-20 (eventos/`assertWrite`/`requireActor`), D9 (filas 35/43, Nóminas, `checkMany` indistinguible), D9 garantías
(50/51/`[]`/F-05 por ítem/id inválido, cero llamadas), P-2 (+ gemelos `check`/`checkMany`), D-30, M6 (deny transportado
por membresía con caducidad: T−1 ms ⇒ deny, T ⇒ allow; con reloj inyectado o en tiempo real; + S13 un `now` por lote en
`decideMany`). Corre sobre los dos dobles, `database` (4 modos), `openfga` (`:8090`) y `:8103` (S16).

### 1.9 Casos específicos fuera del runner
- `relations_openfga.spec` grupo «lote D · D1 · deny en openfga contra el servidor real»: D14, D-31 (+ memo una vez por
  proceso, compartido con la vista), S11 (fila declarada: pod con el modelo viejo concede), **S12 por camino**, S15, D-24
  (UN `Check` con deny + includes + userset anidado), D-26/S3 (purga cortada tras el 1.er lote de 100: el primer lote son
  solo allows, el deny sobrevive, la víctima no concede, error marcado parcial), D8 en openfga (opt-in retirado con el modelo
  aún publicado: `check` F, `listDenies`/`removeDeny` funcionan, `decideMany` ⇒ deny, `deny()` ⇒ 422).
- `relations_database.spec` grupo «lote D · D8»: opt-in retirado (`check`/`checkMany`/`listObjects` siguen restando,
  reversible por `removeDeny`), una fila `denied_*` a mano en un tipo que nunca tuvo opt-in (`note`) también resta; y «sin
  filas denied_* la respuesta es la de alpha.10» (config con y sin deny, mismas respuestas).
- `relations_bridge.spec` grupo «lote D · D1 · el deny en el PUENTE»: PARIDAD de las **37 filas PAR** (check v/e/o y
  `decideMany`) en el store compartido; D-22 (deny de relación no toca `roles.authorize`/`hasRole`; deny de rol no toca
  `relations.check`); D-23 (deny sobre una relación usada en un userset, en paridad).
- `relations.spec`: D10, la regla única, `decideMany` frente a terceros (5 respuestas malas ⇒ 500), D-28 con un driver
  que miente sobre la capacidad y con la clave ausente.
- `openfga_facts.spec`: D-29, DENY_DEF, D-18. `scope_depth.spec`: la fila de «Limits» atada a `DENIABLE_RELATION_NAME_MAX`.
- `relations_events_docs.spec`: F3 (tabla con `deny`/`removeDeny` y la frase R2-14), F10 («all thirteen operations»), y
  «la letra del deny … cita casos que EXISTEN» (cada `*"…"*` de la sección del README es un caso).

### 1.10 Guardia de superficie (punto 6/11)
Manifiesto: 16 filas nuevas (4 ops × 4 capas; `deny`/`removeDeny` escrituras con las seis columnas en el manager; en
`openfga` `write`/`truncation` `na: signature` para los dos `Write` sueltos y para `decideMany`; `listDenies` con sonda de
`truncation`), `PORT_WRITES` + `deny`/`removeDeny`, `PORT_READS` + `listDenies`/`decideMany`. Spec: `INVOKE` y
`F05_VARIANTS` de las cuatro (decideMany con la variante en la posición 1), la config del contrato CON deny para TODAS las
sondas (las de antes pasan ahora por el corte y por D-31), el cliente FGA falso sirve el modelo con deny y `fgaDriver` fija
`modelId` (D14). Mutantes: **39 nuevos** (manager 17 —con `decideMany.f05.first-only`—, database 8, openfga 10, double 4),
y 11 viejos ampliados con las celdas nuevas que su guarda compartida también mata (`manager.write.partial`,
`double.partition.grammar`, `identity.dashless.D4`/`misdashed.A2` +16 celdas, los cuatro `userset.B3`,
`openfga.readAll.truncation`, `database.checkMany.f05/partition` — `#readMany` es punto de paso de `checkMany` Y
`decideMany`); 12 `find` reescritos por el refactor. **151 / 151 muertos** (de 112).

### 1.11 Letra
README: sección «Deny on relations (2.5.0)» (dos fases, rollout, D14/D-31, 43, la tabla del corte con los casos, D8,
`decideMany` con la frase literal del juez, P-2, Nóminas, filas declaradas S8–S11), F-05 «all thirteen operations», la
tabla de eventos con `deny`/`removeDeny` y «a handler that treats everything that is not `unrelate` as an addition grants
too much», la fila de «Limits» (43) y `checkMany / decideMany` en la del tope. CHANGELOG `## [Unreleased]` encima de
`## [2.5.0-alpha.2]` (problema → decisión → qué NO), sin tocar los bloques de alpha.1 y alpha.2.

---

## 2 · Cuatro líneas de cierre por pieza grave

**(P1) `check` con corte de camino (D5) en los dos drivers y el doble.**
- (a) *Gemelos*: roles ↔ relaciones — el deny de roles ya cortaba por modelo (`can_P = (P but not denied_P) and rooted`);
  relaciones adopta la misma forma `but not` en el modelo y, en `database`, la regla única `cutPathAllows`.
  `check` ↔ `checkMany` ↔ `listObjects` ↔ `membersOf` ↔ `decideMany`: los cinco honran el deny con la MISMA regla (T1 sobre
  los cuatro primeros, D-15b sobre `membersOf`). Manager ↔ driver ↔ doble: la regla vive en la config, no en tres copias.
- (b) *Tabla de verdad*: T1, 64 estados × 3 preguntas = 192 celdas (§3), fuente = la tabla literal del tester, cruzada
  con un oráculo escrito a mano; ejecutada en 2 dobles + `database` ×4 + `openfga` `:8090` + `:8103`; 37 filas PAR en el
  puente celda a celda.
- (c) *Casos existentes rojos*: ninguno de semántica (R-02, R-09, paridad de `listObjects`: verdes); el B2 reescrito y el
  conteo, justificados en §0.
- (d) *Linaje*: L1 (guardia: filas nuevas que nacieron rojas) y el candidato L9 «inversión del signo» del tester (S-filas
  cubiertas en §3); no es la 3.ª iteración de ninguno.

**(P2) `decideMany` (D9 + P-2).**
- (a) *Gemelos*: `checkMany` (mismo tope, `[]`, F-05 por ítem, un `now`, 503 total, validación de terceros, orden) — las
  dos comparten `#readMany` en `database` y `alignBatchResults` en `openfga`; `check`/`checkMany` como gemelos de P-2;
  roles: **no aplica** (`authorizeMany` responde booleano y la cadena de roles la recorre el paquete con el árbol, no el
  llamante).
- (b) *Tabla de verdad*: §3 (`check` × deny en `up*(down*(R))` ⇒ allow/deny/none), ejecutada sobre los 64 estados × 3
  preguntas (192 decisiones) en cada harness y en el puente (37 filas × 3).
- (c) *Casos existentes rojos*: ninguno.
- (d) *Linaje*: R2-1 (🔴 del auditor) cerrado con la primitiva + la frase; no es iteración de un linaje abierto.

**(P3) Purgas de `openfga` en orden global (D-16/D-26/S3).**
- (a) *Gemelos*: roles — `purgeScope` en `facts` ya borra con orden fijo (estructura, hechos, denies: «denies de MÁS, nunca
  de menos»); relaciones adopta la misma propiedad. `database`: no aplica (un `DELETE`, atómico). `purgeObject` ↔
  `purgeSubject`: los dos por `#purgeByFilters` (un solo punto).
- (b) *Tabla de verdad*: corte × orden — {corte tras lote 1 de 2} × {orden global, orden del Read}: global ⇒ víctima F,
  deny vivo, parcial marcado; Read ⇒ víctima T (fail-open) — la segunda fila es el mutante `fga.purge.read-order`, rojo.
- (c) *Casos existentes rojos*: la sonda `openfga.purge*.write` de la guardia (definición de «tras borrar»), §0.
- (d) *Linaje*: invariante 6/11 (S6); no es una iteración nueva.

**(P4) D14 + D-31 (el modelo fijado tiene que declarar el deny).**
- (a) *Gemelos*: roles — B8 ya lee el modelo FIJADO para el verificador; aquí la misma lectura, memorizada por proceso y
  compartida con `withClock`. Manager ↔ driver: la guarda es del driver (es el único que ve el modelo); el manager no la
  necesita. `database`: no aplica (no hay modelo).
- (b) *Tabla de verdad*: {tipo con deny, sin} × {modelId fijado, no} × {modelo con `denied_*`, sin}: con deny y sin pin ⇒
  500 al construir; con deny, pin y modelo sin `denied_*` ⇒ 500 al usar con 0 Write/Check; con deny, pin y modelo con ⇒
  responde; sin deny ⇒ sin coste ni pin obligatorio (casos D14 y D-31; S11 es la fila declarada del pod con código viejo).
- (c) *Casos existentes rojos*: ninguno (la guardia ganó `modelId` en `fgaDriver` y `readAuthorizationModel` en el falso).
- (d) *Linaje*: H3/R2-2; no es 3.ª iteración.

**(P5) S12 por camino.**
- (a) *Gemelos*: `check` ↔ `checkMany` ↔ `decideMany` ↔ `listObjects` — un caso, cuatro caminos, un mutante por camino;
  roles: los caminos de roles no cambian en D1 (su `Check` ya clasifica por `#guard`) — no aplica en este lote.
- (b) *Tabla de verdad*: §3 (camino × {con context, sin context}).
- (c) *Casos existentes rojos*: ninguno.
- (d) *Linaje*: R2-13 / M6; no es iteración.

---

## 3 · Tablas de verdad

**T1 resumida** (64 estados; columnas v/e/o; la tabla entera es `T1_EXPECTED` en `src/testing/relations_contract.ts`,
idéntica a la del tester §2.2 — comprobado por script: 64/64 filas, 37/37 PAR, mapeo de subconjuntos exacto):

| A \ D | ∅ | v | e | e,v | o | o,v | o,e | o,e,v |
|---|---|---|---|---|---|---|---|---|
| ∅ | FFF | FFF | FFF | FFF | FFF | FFF | FFF | FFF |
| v | TFF | FFF | TFF | FFF | TFF | FFF | TFF | FFF |
| e | TTF | FFF | FFF | FFF | TTF | FFF | FFF | FFF |
| e,v | TTF | FFF | TFF | FFF | TTF | FFF | TFF | FFF |
| o | TTT | FFF | FFF | FFF | FFF | FFF | FFF | FFF |
| o,v | TTT | FFF | TFF | FFF | TFF | FFF | TFF | FFF |
| o,e | TTT | FFF | FFF | FFF | TTF | FFF | FFF | FFF |
| o,e,v | TTT | FFF | TFF | FFF | TTF | FFF | TFF | FFF |

Filas con nombre: 34 (o / v ⇒ FFF), 35 (o / e ⇒ FFF), 43 (o,v / e ⇒ TFF), 37 (o / o ⇒ FFF), 45 (o,v / o ⇒ TFF), 11 (v / e
⇒ TFF). Observado: igual en 2 dobles, `database` (sqlite, sqlite-file, pg, mysql), `openfga` `:8090` y `:8103`.

**`decideMany` (D9)**, por objeto:

| `check(s, R, o)` | deny vivo en alguna relación de `up*(down*(R))` | decisión |
|---|---|---|
| T | — (da igual) | `allow` (fila 43 en viewer) |
| F | sí | `deny` (fila 35 en viewer; Nóminas) |
| F | no | `none` |
| error en un ítem | — | **503 para todo el lote** (S15) |

**S12 por camino** (`openfga`, tuplas del caso C de M6: allow fijo + deny por membresía CONDICIONAL viva):

| camino | con `context` | sin `context` (espía) | mutante que lo mata |
|---|---|---|---|
| `check` | F | 503 | `fga.S12.check.error-false` |
| `checkMany` | [F] | 503 | `fga.S12.checkMany.error-false` |
| `decideMany` | [deny] | 503 | `fga.S12.decideMany.error-none` (mata también S15) |
| `listObjects` | [] | 503 | `fga.S12.listObjects.error-empty` |

**Filas S del tester (§5) en D1**: S3 ✓ (D-26), S8/S9/S10 ✓ (declaradas, caso + README), S11 ✓ (declarada, caso +
README), S12 ✓, S13 ✓ (un `now` por lote en `decideMany`; el deny no caduca, el borde T−1/T es el de la membresía que lo
transporta), S14 ✓ (columna `partition` de las cuatro operaciones + D-30), S15 ✓, S16 ✓ (`:8103`), S18 ✓ (B2 + D10). S1,
S2, S7 no aplican (D3). S4, S5, S6, S17 son de D2.

---

## 4 · Decisiones mías a ratificar (con la alternativa descartada)

1. **Nombres de las fases (D10): `deny: 'read' | 'write'`; `deny: true` ⇒ 422 nombrando las dos.** Descartadas: `true` =
   fase 2 (el interruptor único que R2-2 tumbó, con otro nombre) y `true` = fase 1 (ambiguo: el lector cree que ya
   escribe); un objeto `{ phase }` (más superficie que validar sin ganar nada).
2. **Config del contrato con deny APARTE** (`contractDenyRelationsConfig`: `document` 'write', `workspace` 'read', `note`
   sin opt-in), `contractRelationsConfig` intacta. Descartada: meter `deny` en la de siempre (habría movido el modelo que
   publican todos los harness y los casos de antes; D-29 pide lo contrario). La guardia de superficie sí usa la del deny
   para TODAS sus sondas.
3. **D-28 manda sobre el analista**: `decideMany` sin `relationDenies` ⇒ 500 `E_AUTHZ_UNSUPPORTED`. Descartado
   («cada posición allow/none»): sin capacidad no hay tri-estado que prometer y el consumidor que la use para una cadena
   tiene que enterarse.
4. **La guarda D-31 cubre `relate`/`unrelate`/`check`/`checkMany`/`listObjects`/`decideMany`/`deny`, no
   `removeDeny`/`listDenies`/`listSubjects`/purgas** — medido que `Read`/delete con una relación que el modelo no declara
   responden 200 en v1.19.0, así que retirar el opt-in sigue siendo reversible. Descartado: guardarlo todo (haría
   irreversible el retiro con un modelo nuevo).
5. **`decideMany` de `openfga` en un tipo SIN opt-in pregunta el deny solo si el MODELO servido lo declara** (memo del
   modelo, una lectura por proceso; sin pin —solo posible sin tipos con deny— el memo puede quedar rancio: declarado).
   Descartado: preguntar siempre `denied_*` (error por ítem ⇒ 503 contra un modelo sin la relación) o nunca (D8 roto con
   el opt-in retirado).
6. **`deny` en `openfga` = un `Write` sin `Read`** (`on_duplicate: ignore`): un deny escrito a mano CON condición da 409
   ⇒ 503 (ruidoso, el deny sigue). En `database` el mismo caso se rehace permanente (delete+insert en una transacción).
   Divergencia en un estado que el paquete no produce; declarada.
7. **`expiresAt` PRESENTE (incluso `undefined`/`null`) ⇒ 422** (`'expiresAt' in options`). Descartado: aceptar `null`
   como «permanente» (abriría la puerta a que una versión futura lo lea distinto sin decisión).
8. **Orden del embudo**: la capacidad DESPUÉS de F-05 (como `membersOf`) y `*` ANTES de la gramática del sujeto (sale con
   `E_AUTHZ_RELATION_NOT_DENYABLE`, no con `E_AUTHZ_INVALID_IDENTITY`).
9. **`decideMany` reutiliza `CheckManyBatchError` / `E_AUTHZ_CHECK_MANY_BATCH`** (el mensaje nombra la operación).
   Descartado: un `code` nuevo (más superficie; «las MISMAS garantías»).
10. **`membersOf` de `database` resta con un `check` por candidato, solo si el objeto tiene una fila `denied_*`** (cero
    coste sin denies). Descartado por ahora: la CTE que arrastra la relación (analista §4.4) — más SQL por motor y sin la
    medición de 1 000 miembros que pedía el juez (§6).
11. **El oráculo de T1 es la tabla LITERAL + una fórmula escrita a mano**, no `cutPathAllows` (un mutante de la regla
    viviría). D-12 (monotonía) va DENTRO de D-05 sobre las respuestas observadas, no como caso aparte.
12. **El doble se reescribió sobre el principal** (como la CTE): `check(g#member, …)` ahora sube por los grupos de los que
    `g#member` es miembro, igual que `database` (antes el doble no lo hacía; ningún caso lo fijaba).
13. **Purga de `openfga`: leer TODOS los filtros antes de borrar** (orden global, auditor S2b). Precio: las claves de
    todos los tipos de un `purgeSubject` en memoria a la vez.

---

## 5 · Cifras (4 modos + 3 gates, EN SECUENCIA, `:8090` reiniciado antes de cada suite; `scratchpad/d1/final/summary.log`)

| Modo / gate | Resultado | Δ sobre alpha.2 |
|---|---|---|
| `npm run build` | rc 0 (purity + typecheck + tsc) | — |
| `npm test` (`:memory:` + OpenFGA `:8090`) | **1874** passed, 2 skipped (91 s) | +140 |
| `test:sqlite-file` | **1902** passed, 2 skipped (105 s) | +140 |
| `test:pg` | **1999** passed, 1 skipped (150 s) | +140 |
| `test:mysql` | **2001** passed, 1 skipped (158 s) | +140 |
| `check:guard-mutants` | **151 / 151** muertos (base verde 222 casos) | 112 → 151 |
| `check:flag-mutants` | **36 / 36** muertos, 2 pending (los de D2) | = |
| `cutover-runbook` sqlite-file / pg | verde ×2 (2 pasos pending, los de D2) | = |

Los skipped son los mismos de la partida (ninguno nuevo).

Partida (alpha.2): 1734 / 1762 / 1859 / 1861 (2/2/1/1 skipped); guard-mutants 112/112; flag-mutants 36/36; runbook ×2.
Mutantes por pieza (fuera del corredor publicado, `scratchpad/d1/piece_mutants.json` + `s13_mut.json`): **30 / 30
muertos**. S16 contra `:8103` (tope 3): `relations_openfga.spec` 94/94 y el puente, verde; contenedor borrado.

---

## 6 · Lo no hecho, y lo de D2 afectado por D1

**No hecho en D1 (con razón):**
- **R2-11 (techo de bytes + opt-in ⇒ 500 sin requests)**: el gate de bytes ya mide el modelo FUSIONADO con las `denied_*`
  (`assertFactsModelPublishable` llama al mismo generador), pero no escribí el caso nombrado ni la cifra M1 (+598 B por
  tipo de 3 relaciones) en «Limits»: no estaba en la lista D1 del brief.
- **Medición de `membersOf` con deny en PG/MySQL (1 000 miembros, 3 niveles)**: no hecha; la implementación es la simple
  (decisión 10) con el coste escrito.
- **Ejes T1-b del tester** (las 37 PAR con el deny transportado por grupo, anidado, sujeto userset): cubiertos por casos
  sueltos (D-13, D-14, D-23, M6), no por barrido.
- **`CLAUDE.md`** (mapa de `relations/`, invariantes del deny de relaciones, la capacidad `relationDenies`): no tocado —
  lo dejo al coordinador para que no choque con la letra que fije D2.
- Sin casos `skip` ni `pending` nuevos.

**D2 afectado por D1 (no roto en la suite, pero hay que saberlo):**
- **`authz:relations:reconcile` con denies en el origen**: `enumerateRelations` de los dos drivers devuelve hoy las filas
  `denied_<rel>` con `relation: 'denied_viewer'` y SIN `kind`; el plan las ve como relación NO declarada (F-05) ⇒
  `skipped.undeclared` en el origen (o `extra` en el destino, sin poda). Es ruidoso (exit ≠ 0), no silencioso, pero una
  migración `database → openfga` hoy **no lleva los denies**: **alpha.3 no debe publicarse sin D2** (reconcile con
  `kind`, puerta por driver destino, orden denies→allows).
- **`openfga:provision`** publica el modelo con `denied_*` desde la config (la copia congelada lleva `deny`), pero no tiene
  aún la guarda de `--allow-drop-deny` (D2): quitar `deny` de la config y republicar apaga los denies en `openfga` (en
  `database` no: D8).
- Los dos pasos `pending` del runbook (opt-in en dos fases; rollback prohibido) siguen `pending`; la guardia L9 de linaje y
  S4/S5/S6/S17 son de D2.

---

## Estado del árbol

(ver abajo: `git status --short` y `git diff --stat`)

```
 M CHANGELOG.md
 M README.md
 M index.ts
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_facts.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/relations/check_many.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/testing/main.ts
 M src/testing/relations_contract.ts
 M src/types.ts
 M tests/capabilities.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/guard_surface.spec.ts
 M tests/openfga_facts.spec.ts
 M tests/relations.spec.ts
 M tests/relations_bridge.spec.ts
 M tests/relations_contract.spec.ts
 M tests/relations_database.spec.ts
 M tests/relations_events_docs.spec.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/scope_depth.spec.ts

 CHANGELOG.md                             |  73 +++
 README.md                                |  80 +++-
 index.ts                                 |  11 +-
 src/drivers/database_relations_driver.ts | 266 +++++++++--
 src/drivers/openfga_facts.ts             |  38 +-
 src/drivers/openfga_relations_driver.ts  | 276 +++++++++++-
 src/errors.ts                            |  28 ++
 src/relations/check_many.ts              |  10 +-
 src/relations/define_relations_config.ts | 235 +++++++++-
 src/relations/manager.ts                 | 142 +++++-
 src/testing/main.ts                      |   2 +
 src/testing/relations_contract.ts        | 738 ++++++++++++++++++++++++++++--
 src/types.ts                             |  61 ++-
 tests/capabilities.spec.ts               |   5 +
 tests/fixtures/guard_manifest.ts         |  46 +-
 tests/fixtures/guard_mutants.json        | 749 ++++++++++++++++++++++++++++---
 tests/guard_surface.spec.ts              |  59 ++-
 tests/openfga_facts.spec.ts              |  64 +++
 tests/relations.spec.ts                  |  85 +++-
 tests/relations_bridge.spec.ts           | 118 +++++
 tests/relations_contract.spec.ts         |   2 +
 tests/relations_database.spec.ts         |  62 +++
 tests/relations_events_docs.spec.ts      |  42 +-
 tests/relations_harness.spec.ts          |  39 +-
 tests/relations_openfga.spec.ts          | 226 +++++++++-
 tests/scope_depth.spec.ts                |   4 +
 26 files changed, 3249 insertions(+), 212 deletions(-)
```
