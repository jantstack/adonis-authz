# Panel «tenencia» (7.º informe de COGNITIV, 2026-10-14) — postura del coordinador, para que el panel la ataque

Informe: `cognitiv-informe-7-tenencia.md`. Cinco peticiones aditivas al motor de relaciones. Verificado contra alpha.10:
- Roles ya hace deny en OpenFGA con `can_P = P but not denied_P` (`openfga_driver.ts:143,881`): patrón probado para P1.
- La partición va DENTRO del id del objeto (`document:<scopeKey>|<uuid>`, `openfga_relations_driver.ts:302`): un `Read`
  por sujeto + tipo devuelve tuplas de todas las particiones ⇒ P2 directo es factible sin recorrer el store.
- `config.clock` ya llega al `RelationsManager` desde el provider (`authz_provider.ts:59`): P5 es documentación.
- `batchCheck` ya existe en roles con 503 por ítem: P4 pequeño.
- OpenFGA no tiene metadatos por tupla: P3 como almacenamiento exigiría tabla SQL auxiliar ⇒ dos escrituras no atómicas (linaje L2).

Postura (a refutar):
| # | Decisión propuesta |
|---|---|
| P1 | SÍ. Deny LITERAL por relación (no sube por `includes`), como el deny de roles es por permiso. Sin comodín `*`. `kind: 'deny'` en enumerate/reconcile; purgas lo borran; evento `relation_denied`/`relation_deny_removed`; caducidad estricta. Bump de modelo FGA. |
| P2 | SÍ, solo tuplas DIRECTAS (sin usersets). `capabilities.listObjectsForSubject` por driver; sin soporte ⇒ `E_AUTHZ_UNSUPPORTED`, nunca `[]`. |
| P3 | NO almacenar `meta`. SÍ exportar la clave canónica estable de la tupla (`relationKey(...)`) para la tabla del consumidor. |
| P4 | SÍ. Tope 50 ⇒ 422; duplicados permitidos (misma respuesta por posición); un 503 por ítem ⇒ 503 total. |
| P5 | SÍ: sección README «Testing expiry from your app» + helper de testing si hace falta. |
Versión 2.5 (minor: `list*` omiten denegados). Orden: P5 → P4 → P1 → P2 → P3-clave. Rechazar: `*`, herencia de carpetas, `meta` interpretado.
Preguntas que el panel debe cerrar: las 5 de §9 del informe, y: ¿el deny en relaciones y el deny de roles comparten algo (código, tabla, familia FGA) o son independientes? ¿Qué linaje de `linajes.md` toca cada pieza y cuál es su punto de paso único?
