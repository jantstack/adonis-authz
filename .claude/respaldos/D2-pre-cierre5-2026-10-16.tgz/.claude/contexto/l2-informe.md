# L-2 · La capacidad `transactionalWrites` y las dos puertas, en los DOS puertos — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `938ee01` (= L-1 commiteado, árbol limpio al empezar). Árbol principal, SIN commits (los
> hace el dueño). Alcance: el lote L-2 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-2 y §2
> «La semántica de la capacidad»), decisión firmada del dueño «2026-09-01 (3)». **Pieza PURA**: todos los
> casos nuevos corren con dobles en memoria y el runner; las cuatro suites completas se corrieron para
> verificar que nada se rompe (y algo se rompió a propósito: abajo, «un caso de L-1 que cambió»).

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l2-rojo-*.log`, `l2-verde-*.log`, `l2-mutante-*.log`, `suite-*.log`). Los mutantes se plantaron con `perl`
sobre una copia de respaldo y se restauraron en el MISMO comando (`grep -rc MUTANT src tests providers
commands index.ts` = 0 al final).

## La decisión que gobierna el lote, y una que tuve que tomar yo

**`transactionalWrites: true` significa EXACTAMENTE «los dos o ninguno con TU transacción»**, jamás «no se
pierde»; no hay valor intermedio. Dos puertas en vez de «falla al construirse»: (1) por llamada, siempre
activa — `{ transaction }` a un driver `false` ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrando driver y operación, cero
llamadas al driver; (2) por config, opt-in — `requireTransactionalWrites: true` + driver `false` ⇒ 500
`E_AUTHZ_CONFIG` al RESOLVER. Implementado tal cual, en `roles/` y en `relations/`.

**La que tomé yo: el ORDEN entre la puerta 1 y la barrera del freeze.** El juez no lo fija. Puse la puerta 1
**ANTES** de la barrera (y de la identidad, y del actor): una llamada con `{ transaction }` a un driver que
no la soporta **no puede entrar nunca**, y responderle 503 `E_AUTHZ_FROZEN` «reintentable» sería decirle
«vuelve luego» a algo que no va a entrar jamás. Consecuencia observable: **un caso de L-1 cambió de
letra** (abajo). Ningún bypass: nada se escribe por ninguno de los dos caminos y al cliente del llamante
sigue sin preguntársele nada (`liar.reads() === 0` se mantiene).

## Pieza 1 · El contrato: tipos, capacidad y docblock «encolar ≠ escribir»

- `src/types.ts`:
  - **`WriteOptions.transaction?: unknown`** (base de `ScopedWriteOptions`/`GrantOptions`/`DenyOptions` y
    de `ScopeTreeWriteOptions`), con el docblock que separa las TRES semánticas: en `grant`/`revoke`/
    `deny`/`removeDeny` **ESCRIBE** (puerta de capacidad); en `scopes.*` **ENCOLA** (outbox, no pasa por la
    puerta); en la API de delegación **no se admite** (§1.4: `withAuthzCatalogWrite` es el serializador del
    catálogo, invariante 14). Y lo que NUNCA viaja por ella: la autoridad (L-1), pool ≥ 2. El docblock de
    `ScopeTreeWriteOptions.transaction` gana el párrafo «encolar ≠ escribir» en voz alta.
  - **`AuthorizationDriverCapabilities.transactionalWrites: boolean`** y
    **`RelationsDriverCapabilities.transactionalWrites: boolean`**, mismo nombre, con la forma aprobada por
    el juez (§2) y las dos puertas escritas.
  - **`RelationTransactionOptions { transaction? }`** (nuevo); `RelationWriteOptions` lo extiende
    (`relate`/`unrelate`); **`purgeObject`/`purgeSubject` reciben `options?: RelationTransactionOptions`**
    en el puerto y en el manager (hasta hoy no tenían opciones; el juez los lista como receptores en L-4).
  - El puerto de roles: **`revoke`/`deny`/`removeDeny` reciben `options?: WriteOptions`** (como `grant` ya
    hacía) y el manager se lo pasa: sin eso L-3 no tendría por dónde recibir la transacción. Aditivo: un
    driver que no declare el parámetro sigue siendo asignable.
- Los CUATRO drivers reales declaran **`transactionalWrites: false`** con su porqué en el comentario
  (`database` ×2: «hasta L-3/L-4»; `openfga` ×2: «no puede ser otra cosa: una tupla no entra en una
  transacción SQL»).
- `src/errors.ts`: `UnsupportedOperationError.transactional(operation, driver, port)` (la letra de la
  puerta 1, con la salida: «usa `database` o declara `requireTransactionalWrites`») y
  `UnsupportedOperationError.transactionalCatalog(operation)` (la delegación). Mismo `code`/`status` y misma
  clase que el precedente (`membersOf`, `purgeRole`).
- `src/define_config.ts`: **`requireTransactionalWrites?: boolean`** (raíz) y
  **`relations.requireTransactionalWrites?: boolean`** (anula el raíz para el puerto de relaciones; si falta,
  se hereda — misma regla que `requireActor`).
- `index.ts`: **exporta `assertCallerTransaction`** y los tipos `CallerTransaction`/`CallerTransactionOwner`
  (lo pendiente de L-1), y `RelationTransactionOptions`.

## Pieza 2 · Puerta 1 (por llamada) en el puerto de ROLES

`src/manager.ts`: `#assertTransactionalWrite(options, operation)` como PRIMERA línea de
`grant`/`revoke`/`deny`/`removeDeny` (antes de `#writeOptions`, o sea antes de la barrera): con
`transaction` presente resuelve el driver y, si `capabilities?.transactionalWrites !== true`, lanza
`UnsupportedOperationError.transactional(op, config.default, 'roles')`. Un driver sin `capabilities` cuenta
como `false`. `scopes.*` no pasa por aquí (encolar). Y `#assertNoTransaction` en las tres de la delegación.

**Caso** (`tests/manager.spec.ts`, grupo «L-2 · {transaction} — … (puerto de roles)», ×2 dobles: con
`transactionalWrites: false` y sin `capabilities`): las cuatro escrituras con `{ transaction: <forma de un
trx de Lucid> }` ⇒ 500 `E_AUTHZ_UNSUPPORTED`, el mensaje nombra `'fake'`, la operación, la capacidad y
`requireTransactionalWrites`; `calls = []`; `onWrite` no se dispara; y SIN `transaction` la misma llamada
llega al driver. Rojo literal (`l2-rojo-puertas.log`):
```
ℹ AssertionError: ROJO: grant (caps=false) aceptó { transaction } sin que el driver declare transactionalWrites (debería haber lanzado)
```
Casos de control (verdes desde el principio, es lo que fijan): «encolar ≠ escribir» — `scopes.attached` con
`{ transaction }` sobre un driver `false` NO pasa por la puerta y llega a `onScopeAttached`; «puerta
abierta» — con un doble `transactionalWrites: true`, `grant`/`deny` llegan al driver y **el driver recibe
`options.transaction` tal cual** (lo que haga con ella es L-3). Y la delegación: `defineScopedRole`/
`updateScopedRole`/`deleteScopedRole` con `{ transaction }` ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrando
`withAuthzCatalogWrite`, también con un driver capaz, cero llamadas (rojo antes: el fake sin `purgeRole`
llegaba al 500 de P4, «necesita 'purgeRole'» — o sea la comprobación no existía).

## Pieza 3 · Puerta 1 en el puerto de RELACIONES

`src/relations/manager.ts`: `#assertTransactional(options, op)` como PRIMERA línea de
`relate`/`unrelate`/`purgeObject`/`purgeSubject` (antes de la barrera y de F-05); nombra al driver con
`options.driverName` (nueva opción; el provider pasa la clave de `relations.drivers`; default
`'relations'`). `purge*` ganan el tercer parámetro y lo pasan al driver.

**Caso** (`tests/relations.spec.ts`, grupo «L-2 · … (puerto de relaciones)»): doble `false` envuelto en un
Proxy que anota las CUATRO escrituras; las cuatro con `{ transaction }` ⇒ 500 nombrando `'openfga'`
(`driverName`), la operación y `requireTransactionalWrites`; cero llamadas; sin `onRelationWrite`; sin
`transaction` entra. Rojo literal:
```
ℹ AssertionError: ROJO: relate aceptó { transaction } sin que el driver declare transactionalWrites (debería haber lanzado)
```
Control «puerta abierta» (doble `true`): las cuatro llegan y el driver recibe `options.transaction`; rojo
antes SOLO en `purge*` (`expected undefined to equal { from: … }`): hasta L-2 `purgeObject`/`purgeSubject`
no aceptaban opciones, así que la transacción no tenía por dónde llegar — es la pieza del contrato que L-4
necesita.

**Mutante M1** (`l2-mutante-puerta1.log`: las dos puertas 1 devuelven sin comprobar) ⇒ **6 failed**:
`manager.spec` (roles), `relations.spec` (relations), `contract.spec` ×2 («database» y «database (sin
listDenies)»: `debería haber rechazado`), `relations_contract.spec` ×2 (full y mínimo:
`relate: debería haber lanzado: expected undefined to equal 500`). Restaurado.

## Pieza 4 · Puerta 2 (al RESOLVER) en el puerto de ROLES

`src/manager.ts` · `driver()`: `#assertTransactionalWritesRequired(driver)` justo después de aplicar el
reloj y ANTES de cachear: con `config.requireTransactionalWrites === true` y `capabilities?.transactionalWrites
!== true` ⇒ `AuthorizationConfigError` nombrando el driver y lo que declara (`false` / «nada (sin
capabilities)»). Como no se cachea, TODA resolución falla igual: lecturas, escrituras y `manager.driver()`.

**Caso** (`manager.spec`, «puerta 2 …»): con el flag, `driver()` ⇒ 500 `E_AUTHZ_CONFIG` nombrando `'fake'`,
`transactionalWrites` y `requireTransactionalWrites`; **`authorize` (una lectura) y `grant` sin
`transaction` también** ⇒ 500 (el despliegue no arranca); `calls = []`; sin el flag el mismo driver resuelve
(opt-in); con un doble `true` resuelve. Rojo literal:
```
ℹ AssertionError: ROJO: driver() (caps=false) aceptó { transaction } sin que el driver declare transactionalWrites (debería haber lanzado)
```

## Pieza 5 · Puerta 2 en el puerto de RELACIONES (`config.relations`)

Para relaciones «resolver el driver» es construir el `RelationsManager` (`buildRelationsManager` del
provider): la puerta va en el **constructor** (`options.requireTransactionalWrites`), junto al gate de
`clock`. `providers/authz_provider.ts` pasa `relations.requireTransactionalWrites ??
config.requireTransactionalWrites` y `driverName: driverKey`.

**Casos**: `relations.spec` («puerta 2 …»): `new RelationsManager(dobleFalse, config, {
requireTransactionalWrites: true, driverName: 'openfga' })` lanza 500 `E_AUTHZ_CONFIG` nombrando
`'openfga'`; también con un driver sin `capabilities`; sin flag construye; con doble `true` construye. Rojo:
```
ℹ AssertionError: false: ROJO (false): el RelationsManager se construyó con requireTransactionalWrites: true sobre un driver que no la declara: expected undefined to equal 500
```
`relations_service.spec` («L-2 · requireTransactionalWrites en config.relations»): por el provider,
`relations.requireTransactionalWrites: true` + `database` (doble `false`) ⇒ 500 nombrando `'database'`; el
flag del RAÍZ se hereda (mismo 500); `relations.requireTransactionalWrites: false` anula el raíz `true`;
`relations.default: 'openfga'` con doble `true` resuelve; sin bandera resuelve. Rojo:
```
ℹ AssertionError: ROJO: relations.requireTransactionalWrites resolvió un driver de relaciones sin transactionalWrites con requireTransactionalWrites: true
```

**Mutante M2** (`l2-mutante-puerta2.log` + `l2-mutante-puerta2-relations.log`: las dos puertas 2
apagadas) ⇒ **7 failed** en la primera corrida (`manager.spec`, `relations.spec`, `relations_service.spec`,
`contract.spec` ×2, `relations_contract.spec` ×2) y, repetido solo contra el runner de relaciones tras la
corrección de `driverName` (abajo), **2 failed**:
```
ℹ AssertionError: requireTransactionalWrites: true sobre un driver que declara false tenía que lanzar al construir: expected undefined to equal 500
```
Restaurado.

## Pieza 6 · Los DOS runners: el par, sus caras y el guard «true sin whenTrue Y false sin whenFalse»

**`runAuthorizationDriverContract`** (`src/testing/contract.ts`):
- La capacidad de harness **`transactions` (placeholder desde 2.5, sin un solo caso) se renombra
  `transactionalWrites`** — un nombre, no dos (pre-release; dicho en el CHANGELOG). `tests/contract.spec.ts`
  (`CAPABILITIES_TODAY`), `contract_harness.spec.ts` (`NONE`) y el snippet del README actualizados.
- `caseFor('transactionalWrites', { whenFalse })` al final de los pares, registrado en **TODOS los
  niveles** (es composición del manager sobre `driver.capabilities`: un driver de terceros `core` la
  observa igual). La cara `false`: espía Proxy sobre el driver del harness, `managerOver({}, spied)`, las
  cuatro escrituras con `{ transaction }` ⇒ 500 nombrando `harness.name` y la operación, `touched = []`,
  sin `transaction` entra (`grant` + `authorize` true); y la puerta 2: `managerOver({
  requireTransactionalWrites: true }, spied)` ⇒ `driver()`, `authorize` y `grant` son 500 `E_AUTHZ_CONFIG`.
  Comprueba además que el driver declara lo que el harness declara (`notEqual(…, true)`). `whenTrue`
  **ausente a propósito** (L-3: escritura + rollback ⇒ `authorize` false y cero filas): declarar `true` hoy
  lanza al cerrar el grupo.
- **El guard gana la segunda cara**: `BOTH_FACES_REQUIRED = {'transactionalWrites'}` y la regla se saca a
  una función PURA exportada, `uncoveredCapabilities(capabilities, covered)` — una capacidad `true` sin caso
  queda sin cubrir (como siempre) **y una de ese conjunto queda sin cubrir con cualquier valor**. No se
  generaliza a todos los pares porque los de nivel (`listDenies: false` en un harness `core`) no registran
  nada y ahí `false` es legítimo. El mensaje del guard imprime ahora el valor real (`'transactionalWrites:
  false'`), no siempre `true`.

**`runRelationsDriverContract`** (`src/testing/relations_contract.ts`): `caseFor('transactionalWrites', {
whenTrue, whenFalse })` — el runner ya exige las dos caras como FUNCIONES en el código y el teardown exige
cobertura; la `whenTrue` de hoy **lanza al registrar** con el porqué («no tiene caso todavía (L-4) —
declara lo observable hoy»), que es un fallo, no un skip. La `whenFalse`: las cuatro escrituras con
`{ transaction }` por `state.manager` ⇒ 500 nombrando `harness.name` y la operación, `state.writes() === 0`
(el espía cuenta ahora también `purgeObject`/`purgeSubject`), sin `transaction` entra, y `new
RelationsManager(state.base, …, { requireTransactionalWrites: true, driverName })` lanza 500
`E_AUTHZ_CONFIG`. `freshManager` pasa `driverName: harness.name` (lo que haría el provider).

**Corrección a mitad, dicha:** la primera vez que corrió `relations_contract.spec` con la puerta activa
(dentro de la corrida del mutante M2) el caso falló por MI runner, no por el mutante: `freshManager` no
pasaba `driverName` y el mensaje decía `'relations'` en vez del nombre del harness. Corregido; el runner
en verde (`l2-verde-relations-contract.log`, 40/40) y M2 repetido contra él (2 failed, arriba).

**Los conteos literales, re-anclados** (`tests/contract_harness.spec.ts`; rojo literal en
`l2-rojo-harness.log`: `expected [ …(41) ] to have a length of 40 but got 41`, `66/65`, `83/82`, `76/75`):

| nivel / cara | antes | ahora |
|---|---|---|
| core | 40 | **41** |
| 2.0 | 53 | **54** |
| 2.1 (`listDenies: true`) | 71 | **72** |
| 2.1 sin `listDenies` | 65 | **66** |
| 2.2 (`listDenies: true`) | 82 | **83** |
| 2.2 sin `listDenies` | 77 | **78** |
| 2.2 con `purgeRole` + reloj | 86 | **87** |
| 2.1 con reloj | 75 | **76** |
| relaciones (`EXPECTED_CASES`) | 19 (7 capacidades) | **20 (8)** |

Caso nuevo en `contract_harness.spec`: la cara `false` se registra en core y en 2.2; `transactionalWrites:
true` se rechaza al registrar en core y en 2.2 (`/'transactionalWrites: true'/`); y la regla del guard en
puro: `uncoveredCapabilities(NONE, todo-menos-transactionalWrites)` ⇒ `['transactionalWrites']` (con `false`),
lo mismo con `true`, `[]` si está cubierta, y con `exhaustiveLists: false` + nada cubierto ⇒ solo ella
(ningún otro par exige su cara `false`). En `relations_harness.spec`: FULL con `transactionalWrites: true`
se rechaza al registrar; la cara `false` (título `transactionalWrites:false … CERO llamadas …
E_AUTHZ_CONFIG`) está en FULL y en MÍNIMO; `covered.size === 8`.

**Mutante de conteo**: el propio rojo de arriba es «cambiar el número esperado ⇒ rojo» (40 contra 41, 19
contra 20). **Mutante M3a** (`l2-mutante-cara-roles.log`: la cara `whenFalse` de roles renombrada, o sea
ausente) ⇒ `contract_harness.spec` **7 failed**, todos con
```
ℹ Error: [contrato harness-de-prueba] declara 'transactionalWrites: false' pero el contrato no tiene caso para ese valor todavía. Declara lo observable hoy.
```
y, con el mismo mutante, `contract.spec` **muere al importar** con `[contrato database] declara
'transactionalWrites: false' …` (`l2-mutante-caras.log`) — el runner FALLA con `false` sin `whenFalse`.
**Mutante M3b** (`l2-mutante-cara-relations.log`: la cara `whenFalse` de relaciones ausente) ⇒
`relations_harness.spec` **5 failed**:
```
ℹ Error: [contrato harness-de-conteo] la capacidad 'transactionalWrites' no declara sus dos caras (whenTrue Y whenFalse): una cara ausente es un skip disfrazado.
```
Restaurados.

## Un caso de L-1 que cambió de letra (`tests/freeze.spec.ts`, 🟠 8)

Los dos casos de L-1 que metían `{ actor, transaction: liar|trx }` en `grant`/`revoke`/`deny`/`removeDeny`
para demostrar que la barrera no se lee por el cliente del llamante esperaban 503 `E_AUTHZ_FROZEN`. Con
`transaction` DECLARADA y la puerta 1 delante de la barrera, y con el `spyDriver()` del worker sin
capacidades (= `false`), esas cuatro llamadas son ahora **500 `E_AUTHZ_UNSUPPORTED`** (rojo en la primera
corrida completa: `expected 'E_AUTHZ_UNSUPPORTED' to equal 'E_AUTHZ_FROZEN'`, `suite-sqlite.log` de
entonces). Lo que los casos protegen no cambia y se sigue afirmando: cero llamadas al driver y
`liar.reads() === 0`. Los reescribí para afirmar las DOS cosas: las de hechos CON `transaction` ⇒ 500 de la
puerta (nombrando `transactionalWrites`), y las MISMAS cuatro SIN `transaction` ⇒ 503 `E_AUTHZ_FROZEN`
reintentable (la barrera); las tres del árbol con `transaction` siguen siendo 503 (encolar no pasa por la
puerta). En el caso del snapshot (PG/MySQL/`sqlite-file`): `grant`/`deny` sin `transaction` y
`scopes.moved` con ella ⇒ 503 con «authz:unfreeze»; `grant`/`deny` con `{ transaction: trx }` ⇒ 500. Cuando
un driver declare `true` (L-3) la puerta se abre y ahí vuelve a mandar la barrera — dicho en el comentario.

## Docs

- **CHANGELOG** (`[Unreleased] — 2.4.0-alpha.2`, sección «Lot L-2», antes de L-1): problema → decisión (la
  capacidad, las dos puertas, 500 y no 422 por precedente) → tipos y «enqueueing ≠ writing» → runners y
  conteos → exportación → **qué NO se hace** (ningún driver escribe aún en la trx del llamante; la receta
  por dirección es de L-6). El rename `transactions` → `transactionalWrites` del harness, declarado.
- **README**: fila `transactionalWrites` en la tabla de capacidades (con «enqueueing ≠ writing»); las
  entradas de `E_AUTHZ_UNSUPPORTED` y `E_AUTHZ_CONFIG` en la tabla de errores; el snippet del harness. La
  receta por dirección de `openfga`, la frase del freeze ampliada y el límite de `resolveChain` son L-6.

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, corridas a fichero)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ ·
`npm run build` ✔ (`l2-build.log`).

| modo | base (L-1) | ahora | log |
|---|---|---|---|
| `npm test` (SQLite memoria) | 1028 | **1046 passed (1046)** | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1036 | **1054 passed (1054)** | `suite-sqlite-file.log` |
| `npm run test:pg` | 1130 | **1149 passed (1149)** | `suite-pg.log` |
| `npm run test:mysql` | 1130 | **1149 passed (1149)** | `suite-mysql.log` |

+18 en SQLite (`manager.spec` +5, `relations.spec` +3, `relations_service.spec` +1, `contract_harness` +1,
`relations_harness` +1, `contract.spec` +3 —«database», «database (sin listDenies)», «openfga»—,
`relations_contract.spec` +2, `relations_database.spec` +1, `relations_openfga.spec` +1); +19 en PG/MySQL
(el harness «database (árbol SQL)» suma uno más). Aditivo: ningún caso existente cambió de resultado salvo
los dos de L-1 reescritos y dichos arriba. Cero rojas transitorias en las cuatro corridas finales. Stores
del `:8101` al terminar: `{"stores":[]}`. `MUTANT` = 0.

## Ficheros tocados

- `src/types.ts` — `WriteOptions.transaction` (docblock encolar ≠ escribir), `transactionalWrites` en las dos
  interfaces, `RelationTransactionOptions`, `purge*`/`revoke`/`deny`/`removeDeny` con `options` en el puerto.
- `src/errors.ts` — `UnsupportedOperationError.transactional` / `.transactionalCatalog`.
- `src/manager.ts` — puerta 1 (`#assertTransactionalWrite`, `#assertNoTransaction`), puerta 2
  (`#assertTransactionalWritesRequired` en `driver()`), `options` al driver en `revoke`/`deny`/`removeDeny`.
- `src/relations/manager.ts` — puerta 1 (`#assertTransactional`), puerta 2 (constructor), `driverName`,
  `purge*` con opciones.
- `src/define_config.ts` — `requireTransactionalWrites` (raíz y `relations`).
- `providers/authz_provider.ts` — pasa el flag heredado y `driverName`.
- `src/drivers/{database,openfga}_driver.ts`, `src/drivers/{database,openfga}_relations_driver.ts` —
  `transactionalWrites: false`.
- `src/testing/contract.ts` — rename, par, `BOTH_FACES_REQUIRED`, `uncoveredCapabilities`.
- `src/testing/relations_contract.ts` — par (dos caras), espía con `purge*`, `driverName`.
- `index.ts` — `assertCallerTransaction` + tipos; `RelationTransactionOptions`.
- Tests: `manager.spec` (+5), `relations.spec` (+3), `relations_service.spec` (+1), `contract_harness.spec`
  (conteos + 1), `relations_harness.spec` (conteos + 1), `contract.spec` (rename), `freeze.spec` (dos casos
  de L-1 reescritos + literal de capacidades), y el campo nuevo en todos los literales de
  `RelationsDriverCapabilities`/capacidades de roles (`relations_*`, `openfga_facts`).
- `README.md`, `CHANGELOG.md`.

## Lo que NO hice, y por qué

- **Ningún driver escribe en la transacción del llamante**: `database` (roles) es L-3, `database`
  (relations) es L-4, y `openfga` contra el `:8101` es L-5. Por eso los CUATRO declaran `false` y la cara
  `whenTrue` no existe en roles (declarar `true` lanza) y lanza al registrar en relaciones. L-3/L-4 tienen
  que: poner `true` en el driver, llamar `assertCallerTransaction` con SU conexión, poblar la cara
  `whenTrue` en su runner y **flipar los dos casos de L-1 de `freeze.spec`** si su worker pasa a un driver
  `true` (hoy es `spyDriver()`, sin capacidades; no los toca).
- **No generalicé el guard «las dos caras» a todos los pares de roles**: los pares de nivel dejan `false`
  sin caso en `core` a propósito. El conjunto `BOTH_FACES_REQUIRED` es la lista de los que sí; hoy uno.
- **La receta por dirección, la frase del freeze ampliada, el límite de `resolveChain` y la reescritura de
  `roadmap-2.0.md:103`** son L-6. El README solo ganó la fila de la capacidad, las dos entradas de errores
  y el snippet.
- **`purgeRole`/`syncAuthzCatalog`/`relayScopeChanges` no reciben `transaction`** (§1.4); la delegación lo
  rechaza activamente porque hereda el campo de `WriteOptions` y un campo declarado no puede ignorarse.
- **No validé la FORMA de la transacción en la puerta 1** (eso es `assertCallerTransaction`, en el driver,
  L-3/L-4): la puerta decide por la capacidad; `{ transaction: 42 }` a un driver `false` es el mismo 500.
- **No toqué `CLAUDE.md`** (el CHANGELOG y el README llevan el detalle).
