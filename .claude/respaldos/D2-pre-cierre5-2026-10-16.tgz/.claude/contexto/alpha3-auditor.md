# `2.4.0-alpha.3` — informe del AUDITOR (adversarial) sobre el diff sin commitear

**Base:** HEAD `7e21c46` (`2.4.0-alpha.2`), 18 ficheros tocados + `tests/relations_events_docs.spec.ts`.
**Alcance leído:** `CLAUDE.md` (inv. 5, 6, 11, 13, 14), `decisiones-dueno-2026-08-28.md` §2026-09-02 (2) y (2b),
`alpha3-tester-casos.md`, `alpha3-informe.md`, el diff entero, y el código que el diff NO toca pero del que
depende (`src/drivers/openfga_relations_driver.ts`, `database_relations_driver.ts`, `src/drivers/openfga_facts.ts`,
`src/freeze.ts`, `src/identity.ts`, `src/manager.ts:3237-3293`).

**Escala** (equivalencia con la del encargo): CRÍTICO = 🔴 · ALTO = 🟠 · MEDIO = 🟡 · BAJO = ⚪.

**Reproducciones ejecutables** (no tocan `src/` ni `tests/`):
- `/home/jose/proyectos/Personal/adonis-authz/.claude/reproducciones/alpha3-auditor.ts`
  (`node --import @poppinss/ts-exec .claude/reproducciones/alpha3-auditor.ts`)
- `/home/jose/proyectos/Personal/adonis-authz/.claude/reproducciones/alpha3-f05-purge.ts`
  (`OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec .claude/reproducciones/alpha3-f05-purge.ts`)

Sanidad previa: `--files=relations.spec.ts` ⇒ 35/35 verde. No audito sobre un árbol roto.

---

## Veredicto en una línea

**NO APTA para publicar como `2.4.0-alpha.3`**: un CRÍTICO reproducido contra el `:8101` (el puerto de
relaciones borra asignaciones de rol REALES del store compartido por `purgeObject`, la misma escritura que
este lote acaba de reescribir) y dos ALTOS (una fuga de enumeración por el mismo agujero, y `assertWrite`
sigue siendo fail-open por la mitad que H2 no miró).

---

## Hallazgos, por severidad

### [CRÍTICO 1] `F-05` no cubre `purgeObject`: el puerto de relaciones DESTRUYE asignaciones de rol reales del store compartido

- **Escenario** (precondición → acción → resultado):
  - Precondición: despliegue documentado de `openfga` — driver de roles `facts` y driver de relaciones en el
    **MISMO store** (`openfga_relations_driver.ts:1-6`: «sobre el MISMO store y `modelId` que el driver `facts`
    de roles»). `user:U` tiene el rol `R` en `organization:S` y `authorize(U, read, organization:S) === true`.
    El consumidor expone la purga de relaciones con el `object.type` tomado de la petición (un
    `DELETE /objects/:type/:id/keys`, que es exactamente el caso de uso «relations como almacén de llaves»
    con el que COGNITIV levantó este lote).
  - Acción: `authz.relations.purgeObject({ type: 'role_binding', id: R }, { type: 'organization', uuid: S }, { actor })`.
  - Resultado: `RelationsManager.purgeObject` **no llama a `#assertDeclared`**, así que el tipo reservado pasa;
    `OpenFgaRelationsDriver.#objectId` compone `role_binding:organization|S|R`, que es **byte a byte** el id que
    devuelve `factsBindingObject(scopeKey, roleUuid)` (`openfga_facts.ts:735-738`); `#purgeByFilter` lee y borra
    TODAS sus tuplas (`role`, `assignee`, `scope#binding`) y **demuestra cero**. `authorize` pasa de `true` a
    `false`. Y el lote emite, encima, un `RelationWriteEvent` limpio (`operation: 'purgeObject'`) que un SOC
    leerá como una purga rutinaria de relaciones según la tabla nueva del README:566-573.
- **Evidencia:** VERIFICADO Y REPRODUCIDO contra el `:8101` real
  (`.claude/reproducciones/alpha3-f05-purge.ts`). Salida literal:
  ```
  ANTES  · authorize(user:U, read, organization:S) = true
  (a) relate role_binding ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422 (F-05 corta)
  (c) purgeObject(role_binding:R) ⇒ NO LANZÓ. eventos: [{"operation":"purgeObject","object":{"type":"role_binding",...}}]
  DESPUÉS · authorize(user:U, read, organization:S) = false
  tuplas del binding que quedan: 0
  ```
  Líneas exactas: `src/relations/manager.ts:392-407` (`purgeObject` valida `assertScope` + `#assertObjectId` +
  `#assertActor`, **nunca `#assertDeclared`**) frente a `:313` y `:338` (donde `relate`/`unrelate` sí lo llaman);
  `src/drivers/openfga_relations_driver.ts:601-610` (`purgeObject` compone el id sin `assertRelationDeclared`,
  que en ese fichero solo aparece en `:387` y `:431`). El corte del `relate` en la misma corrida es la prueba
  de que la defensa existe y de que la purga se la salta. Ni `assertWrite` la ve (D-1: las purgas no pasan por
  el gate, decisión de este lote) ni `requireActor` la para (el actor legítimo del tenant vale).
- **Alcance exacto:** solo `openfga` (store compartido). En `database` el daño es nulo: `purgeObject` borra en
  `authz_relations` y los hechos de roles viven en `authz_assignments`. Los `denied_<P>` NO son alcanzables
  (son relaciones del tipo `scope`, cuyo id `scope:<key>` no tiene la forma `<tipo>:<partición>|<id>` que
  compone el driver), así que esto es destrucción/DoS de autorización e integridad cruzada entre puertos y
  entre scopes — **no** una escalada por quitar un deny. `purgeSubject` no es vector (su filtro de objeto se
  limita a los tipos declarados + `group`).
- **Steelman del defensor:** «F-05 nació para que un `relate` no FABRICARA un binding; una purga solo borra, y
  borrar es fail-closed. Además el lote no introduce esto: `purgeObject` nunca tuvo F-05.» → **No me convence.**
  (i) El propio docblock del driver (`openfga_relations_driver.ts:21-27`) dice que el caso-exploit «se cierra en
  el manager» — y no está cerrado en la mitad de la superficie; (ii) el invariante 11 trata las purgas como la
  operación que MÁS disciplina de identidad necesita, y este mismo lote añade `requireActor` a las purgas
  argumentando literalmente «un borrado masivo de llaves es la escritura que más actor necesita» — el mismo
  argumento exige F-05, y se aplicó solo uno de los dos; (iii) «borrar es fail-closed» vale para el permiso
  borrado, no para el tenant vecino cuyo estado de autorización se destruye sin catálogo, sin `within`, sin
  rango y sin resolver de scopes; (iv) el lote reescribió estas dos funciones enteras y publicó una sección de
  README sobre ellas: es la revisión en la que tocaba verlo.
- **Mitigación mínima:** llamar a `assertRelationDeclared` con el tipo (sin relación) en `purgeObject` del
  manager y en `#objectId` del driver de relaciones — el mismo 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN`, cero
  llamadas al backend, cero eventos.

### [ALTO 2] `F-05` tampoco cubre las LECTURAS: `listSubjects` enumera los asignados de un `role_binding` real

- **Escenario:** mismas precondiciones que el CRÍTICO 1 → `authz.relations.listSubjects('assignee',
  { type: 'role_binding', id: R }, { type: 'organization', uuid: S })` → devuelve los holders asignados a ese rol
  en ese scope, por el puerto de relaciones, sin catálogo, sin `within`, sin `requireActor` (las lecturas no lo
  tienen) y sin visibilidad de rol (inv. 18).
- **Evidencia:** VERIFICADO Y REPRODUCIDO (misma corrida):
  `(b) listSubjects(assignee, role_binding:R) ⇒ FUGA: [{"type":"user","uuid":"01a06358-…"}]`.
  `src/relations/manager.ts:367-376` (solo `assertScope` + `#assertObjectId`) y
  `src/drivers/openfga_relations_driver.ts:504-526`. Igual `check` (`manager.ts:350-354`) y `listObjects`
  (`:356-365`). Es el invariante 7 y el 4 leídos desde otro puerto.
- **Steelman:** «es una lectura, y quien puede llamar al puerto de relaciones ya está autenticado». → No me
  convence: el paquete separa puertos precisamente para que el almacén de llaves de un tenant no responda
  preguntas del motor de roles de otro; el `objectId` lleva la partición, así que la respuesta es de un scope
  concreto que el llamante elige.
- **Mitigación mínima:** el mismo `assertRelationDeclared` de tipo en `check`/`listObjects`/`listSubjects`
  (manager y driver). Con eso el CRÍTICO 1 y este caen juntos.

### [ALTO 3] `assertWrite` sigue siendo fail-open: H2 cerró el thenable y dejó abierto el «gate que DEVUELVE un veredicto»

- **Escenario:** el consumidor escribe el gate como se escribe una policy en TS —
  `relations: { assertWrite: (ref) => allowedTypes.has(ref.object.type) }` — creyendo que `false` deniega.
  Compila bajo `--strict` (un retorno cualquiera es asignable a `void`, exactamente el mismo agujero de tipos
  que H2 documenta para `async`). El manager llama al gate, ignora el `false` y **la escritura entra**.
- **Evidencia:** VERIFICADO Y REPRODUCIDO. `.claude/reproducciones/alpha3-auditor.ts` caso A1:
  `A1 assertWrite=>false : llamado=1 ESCRITURA ENTRÓ=true`. Compilación comprobada aparte con el `tsc` del
  repo (`--strict`): `assertWrite: (ref) => allow.has(ref.id)` y `(ref) => ref.id` compilan las dos, con la
  firma-propiedad y con la firma-método. Línea: `src/relations/manager.ts:276-282` — la guarda solo mira
  `typeof result === 'object' && typeof result.then === 'function'`.
- **Steelman:** «el docblock dice “LANZA para rechazarla”, y `assertWrite` es del consumidor». → No me
  convence: es palabra por palabra el argumento que el lote RECHAZÓ para el caso `async` (el docblock también
  decía “síncrono y puro”, y aun así se cerró con 500 porque «un gate de policy que no rechaza nada, en
  silencio» es inaceptable). El retorno de un booleano es más frecuente que el `async` y produce el mismo
  fail-open. Cerrar la mitad de un fail-open y publicar la sección de README que dice que está cerrado es peor
  que no tocarlo.
- **Mitigación mínima:** en `#assertWrite`, `if (result !== undefined) throw AuthorizationConfigError.…` —
  una condición que cubre el thenable, el booleano, el objeto y la función thenable (MEDIO 4) de una vez.

### [MEDIO 4] La detección del thenable de H2 se esquiva con un thenable que no es `typeof 'object'`

- **Escenario:** `assertWrite` devuelve una FUNCIÓN con `.then` (lo que hace una librería de policy que
  devuelve un *lazy promise*/*task*): `typeof result === 'object'` es `false`, no se lanza el 500, y el
  rechazo asíncrono se pierde igual que en alpha.2.
- **Evidencia:** VERIFICADO Y REPRODUCIDO. Caso A2: `A2 assertWrite=>thenable FUNCIÓN : error=ninguno
  ESCRITURA ENTRÓ=true` (contra el control A3, `async` ⇒ `E_AUTHZ_CONFIG` 500 y no entra).
  `src/relations/manager.ts:278`.
- **Steelman:** «nadie devuelve una función thenable». → Medio convence; por eso es MEDIO y no ALTO. Pero la
  corrección es la misma línea que el ALTO 3, así que no cuesta nada.
- **Mitigación mínima:** la del ALTO 3.

### [MEDIO 5] Un `onRelationWrite` que no resuelve CUELGA la escritura para siempre (y con `{ transaction }`, la trx del llamante)

- **Escenario:** sink de auditoría que hace un `fetch` a un colector sin timeout (o cualquier promesa que no
  resuelve) → `relate()` **no vuelve nunca** aunque la tupla ya esté escrita; con `{ transaction }` la trx del
  llamante queda abierta sosteniendo su conexión, y como `{ transaction }` exige pool ≥ 2 (inv. 14), unas
  cuantas peticiones así dejan al motor sin conexión y la barrera del freeze empieza a dar 503
  `E_AUTHZ_BACKEND_TIMEOUT` a todo el mundo. Fail-closed, pero es una caída total del camino de escritura
  provocada por un sink.
- **Evidencia:** VERIFICADO Y REPRODUCIDO. Caso B: `B hook que cuelga : TIMEOUT 1500ms: relate NO volvió | la
  tupla YA está escrita=true`. `src/relations/manager.ts:201-207` (`#notify` con `await` y sin deadline) y
  `:326`, `:347`, `:406`, `:422`. **Es NUEVO en este lote para relaciones**: en alpha.2 el hook era
  fire-and-forget y no podía bloquear (`onRelationWrite?.(…)` sin `await`).
- **Steelman:** «es paridad literal con `#notify` de roles (`manager.ts:3276`), que lleva así desde D2; y el
  `await` es justo lo que pedía H1/D2 para no perder el rechazo». → Me convence a medias: la paridad es real
  y el `await` es correcto, pero el lote convierte un hook no bloqueante en bloqueante sin decir en el
  CHANGELOG que ahora tu sink está en el camino crítico de la escritura y dentro de tu transacción. No pido
  rediseño; pido una frase y, si acaso, un deadline.
- **Mitigación mínima:** una línea en el README/CHANGELOG («el sink corre DENTRO de tu transacción y su latencia
  es latencia de la escritura: no hagas E/S sin deadline ahí»), o un `Promise.race` con `freezeTimeoutMs`.

### [MEDIO 6] Una purga que muere a MEDIAS borra tuplas y NO emite evento — la frase publicada es falsa ahí

- **Escenario:** `openfga.purgeSubject` recorre `ortografías × tipos declarados` con un `#purgeByFilter`
  por combinación, y `purgeObject` recorre las dos ortografías; cada uno son varios `Read`+`deleteTuples`
  independientes. Si el backend cae (503 que **no** es timeout) o el `PurgeIncompleteError` (500) salta en la
  segunda iteración, la primera **ya borró**. El manager solo notifica con
  `AuthorizationBackendTimeoutError`, así que hay borrado real con **cero** eventos.
- **Evidencia:** VERIFICADO en código + REPRODUCIDO con un driver que falla tras borrar. Caso F:
  `F purga a medias (503 no-timeout) : borró=1 error=E_AUTHZ_BACKEND_UNAVAILABLE EVENTOS=0`.
  `src/relations/manager.ts:181-190` (solo `instanceof AuthorizationBackendTimeoutError`);
  `src/drivers/openfga_relations_driver.ts:601-610` y `:619-635` (los bucles).
  Lo que el lote PUBLICA y aquí no se cumple: `README.md` «A 503 that is not a timeout, a 422 …, an
  `assertWrite` that throws and the freeze emit **nothing** and call nothing: **that write did not happen**» y
  `src/types.ts:1543-1550` («esa escritura no ocurrió y no hay evento»). En `database` la frase SÍ es cierta
  (una sola `DELETE … whereIn(partitionKeys)`, `database_relations_driver.ts:726-746` y `:748-…`).
- **Steelman:** «es la misma regla de roles y el invariante 13 solo habla del deadline». → No me convence del
  todo: en roles la escritura es un `Write` atómico; aquí la purga son N requests, así que el «no ocurrió» es
  una promesa que el driver no puede sostener. Regla del paquete: lo publicado se cumple o se reescribe.
- **Mitigación mínima:** reescribir la frase para las purgas de `openfga` («una purga no es atómica: un fallo
  a mitad puede haber borrado parte y NO emite evento; la demostración de cero es por filtro»), o emitir
  `indeterminate: true` también cuando la purga de `openfga` falla después de la primera iteración.

### [BAJO 7] `purgeSubject` no valida su SUJETO en el manager (asimetría con el propio H3)

- **Escenario:** `purgeSubject({ type: 'user', uuid: 'A#B|evil' }, partition)` o `purgeSubject({}, partition)`
  atraviesan el manager sin 422; contra un driver de terceros (o el doble publicado) se llama al backend y el
  `RelationWriteEvent` se emite con el sujeto envenenado — el rastro que H3 acaba de limpiar para el `actor`.
- **Evidencia:** VERIFICADO Y REPRODUCIDO (con el doble del propio paquete). Casos D1/D2/D3:
  `D1 … error=NINGUNO eventos=1 subject={"type":"user","uuid":"A#B|evil"}`, `D2 … subject={}`,
  `D3 … userset NO declarado (role_binding) … eventos=1`. `src/relations/manager.ts:409-423`: no hay
  `#assertSubject`. Los DOS drivers del paquete lo salvan (`database_relations_driver.ts:409`,
  `openfga_relations_driver.ts:622`), por eso es BAJO y no ALTO — pero el contrato publicado dice que las
  identidades mal formadas mueren en el manager (inv. 5), y el runner no juzga esto.
- **Steelman:** «el driver valida». → Convence para el daño, no para el contrato: el mismo argumento valía
  para el `actor` y se cerró en el manager en este lote.
- **Mitigación mínima:** `this.#assertSubject(subject, partition)` en `purgeSubject`, junto al `#assertActor`.

### [BAJO 8] El evento no es una copia defensiva: aliasing del `object`/`partition`/`actor` del llamante

- **Escenario:** el sink guarda el evento; el llamante (o el propio sink) muta después `object.id` →
  el registro de auditoría cuenta otra cosa. Con `#notify` ahora `await`eado, un sink hostil que mutase
  `event.partition.uuid` cambiaría la constante que el llamante reutiliza en su siguiente `relate`.
- **Evidencia:** VERIFICADO Y REPRODUCIDO. Caso G: `G aliasing del evento : el evento guardado dice
  object.id=MUTADO-DESPUES`. `src/relations/manager.ts:324` (`{ ...ref, … }` es copia superficial).
- **Steelman:** «paridad con `AuthzWriteEvent`, y el sink es código del consumidor». → Convence; por eso BAJO.
- **Mitigación mínima:** ninguna obligatoria; si acaso, una frase en el docblock de `RelationWriteEvent`.

### [BAJO 9] El `actor` viaja al evento con los campos de MÁS que traiga

- **Escenario:** `actor: { type:'user', uuid: U, admin: true }` (un objeto de sesión pasado entero) →
  `assertSubject` valida `type`/`uuid` y no poda nada; el evento lleva `admin: true` al log de auditoría.
- **Evidencia:** VERIFICADO Y REPRODUCIDO. Caso E2: `actor en evento={"type":"user","uuid":"…","admin":true}`.
  `src/relations/manager.ts:164-166`. Paridad exacta con roles (`manager.ts:1518`).
- **Mitigación mínima:** ninguna; se documenta que el `actor` se copia por referencia, sin poda.

### [BAJO 10] `actor: null` es 422 de identidad, no «sin actor» — cambio de comportamiento no anunciado

- **Escenario:** `relate(…, { actor: user ?? null })` con `requireActor: false`. En alpha.2 no pasaba nada
  (solo se miraba la presencia). En alpha.3, `options.actor !== undefined` ⇒ `assertSubject(null)` ⇒ 422
  `E_AUTHZ_INVALID_IDENTITY`. Fail-closed y correcto, pero es breaking y el CHANGELOG solo anuncia como
  breaking el `requireActor` de las purgas.
- **Evidencia:** VERIFICADO Y REPRODUCIDO. Caso E1: `E1 actor: null : error=E_AUTHZ_INVALID_IDENTITY eventos=0`.
  `src/relations/manager.ts:258-265`.
- **Mitigación mínima:** una línea en el CHANGELOG (o tratar `null` como ausente, que es lo que hace `#actorOf`
  dos métodos más abajo — hoy los dos no coinciden).

### [BAJO 11] El invariante 13 no lo juzga NINGÚN runner publicado (respuesta al punto 6 del encargo)

- **Escenario:** un driver de terceros que clasifique su deadline como `AuthorizationBackendError` genérico
  (o que no tenga deadline) pasa el contrato entero y **jamás** produce un `indeterminate: true`. El consumidor
  cree tener la garantía porque `CLAUDE.md` la lista como invariante y la cabecera dice «los verifica
  `src/testing/contract.ts`».
- **Evidencia:** VERIFICADO: `grep -n "indeterminate" src/testing/relations_contract.ts` ⇒ 0;
  `src/testing/contract.ts` ⇒ 0 (el de roles tampoco lo juzga: es paridad, no regresión). Lo que R-17 y el par
  `transactionalWrites` ampliado juzgan del EVENTO es del `RelationsManager`, o sea del paquete: verde
  trivialmente para cualquier driver. Lo que sí sigue juzgando al DRIVER en ese par es la parte vieja
  (rollback ⇒ `check` sin cambio + censo de tuplas, `relations_contract.ts:1106-1290`), y eso sí sostiene la
  veracidad de `transactional: true` — la ampliación no añade ni quita garantía del driver.
- **Steelman:** «`indeterminate` está fuera del runner por decisión explícita (informe §4) y roles hace lo
  mismo». → Convence como decisión; no convence la frase de `CLAUDE.md`. Es letra, no código.
- **Mitigación mínima:** una frase en el invariante 13 diciendo que el runner no lo juzga y que un driver de
  terceros debe lanzar `AuthorizationBackendTimeoutError` en su deadline para cumplirlo.

### [BAJO 12] `relations.requireActor: false` sobre un raíz `true` es una degradación SILENCIOSA (D-5)

- **Escenario:** raíz `requireActor: true` (el consumidor decidió que toda escritura lleva autor) +
  `relations: { requireActor: false }` heredado de una plantilla → las cuatro escrituras de relaciones dejan de
  exigir autor y **nadie avisa**. El aviso `warnOnOptInSecurity` de roles no cubre este flag.
- **Evidencia:** VERIFICADO en código: `providers/authz_provider.ts:53` (`relations.requireActor ?? config.requireActor`)
  y `src/define_config.ts` (docblock de `relations.requireActor`). Documentado en README:640 en los tres
  sentidos, así que es explícito, no accidental.
- **Steelman:** «es el mismo patrón de `requireTransactionalWrites` y lo pidió D-5». → Convence. BAJO.
- **Mitigación mínima:** extender el aviso de construcción a este caso concreto (raíz `true` + puerto `false`).

---

## Lo que intenté y NO se rompió

- **Un hook que lanza en el evento `indeterminate` NO esconde el 503.** `#write` → `#notify` → `try/catch` →
  `#logHookFailure`; el `AuthorizationBackendTimeoutError` se propaga intacto, el evento sale con
  `indeterminate: true` y el fallo del sink queda registrado. Medido: caso C ⇒
  `error propagado=E_AUTHZ_BACKEND_TIMEOUT status=503 eventos=1 indeterminate=true logs=1`.
- **Un sink no puede deshacer, abortar ni reordenar una escritura.** Lanzar (sync o async) se traga y se
  registra; no hay camino desde `#notify` de vuelta al driver. La única influencia es el aliasing (BAJO 8).
- **`assertWrite: async` (H2) está bien cerrado** para el caso publicado: 500 `E_AUTHZ_CONFIG` antes del driver,
  cero llamadas, cero eventos, y la promesa descartada no sale como `unhandledRejection` (caso A3).
- **El orden de las guardas de `relate`/`unrelate` es fail-closed y correcto:** puerta 1 de `{ transaction }` →
  freeze → F-05 → id del objeto → actor → scope → sujeto → `expiresAt` → `assertWrite` → driver. `assertWrite`
  corre DESPUÉS de F-05 y del `requireActor`, como se publica, y un rechazo no toca el backend.
- **La barrera del freeze sigue delante de las CUATRO escrituras** y su 503 no emite evento (correcto: no hubo
  escritura). Un `E_AUTHZ_WRITE_CONFLICT` (409) dentro de `{ transaction }` tampoco emite (correcto).
- **`transactional` está AUSENTE, nunca `false`**, y `{ transaction: undefined | null }` cuentan como sin
  transacción, en las cuatro; una escritura rechazada por la puerta 1 o por `assertCallerTransaction` no
  notifica (lo fija el runner ampliado, y lo confirmé leyéndolo).
- **`requireActor` alcanza de verdad a las cuatro** y el `actor: {}` sale como 422 de identidad, no como
  «actor requerido» (el orden validar→exigir es el correcto).
- **F-05 en `relate`/`unrelate` sigue intacto en el manager Y en los dos drivers** (medido: el `relate` contra
  `role_binding` da 422 en la misma corrida en la que la purga entra).
- **Inyección por el `object.id`/`partition`**: `assertRelationId` + `assertFgaObjectId` + el parseo canónico
  desde la derecha aguantan; no conseguí componer un `scope:<key>` real (los denies viven ahí y quedan fuera
  de alcance) ni un id con `|`/`:`/`#`.
- **Cableado del provider (D-4/D-5):** `relations.assertWrite`/`onRelationWrite`/`requireActor` llegan al
  singleton; `hooks` no los declara; un manager construido a mano se comporta igual **si** se le pasan las
  mismas opciones (el README dice explícitamente que `manager.driver()` se salta los tres, README:640 + :285).
- **Dependencias:** el lote no añade ninguna; `@openfga/sdk` y `@adonisjs/*` no cambian de versión.

---

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿El CRÍTICO 1 es de este lote o se saca a un lote propio?** Es anterior a alpha.3, pero está en las dos
   funciones que este lote reescribió, y publicar ahora una sección de README que describe la semántica de
   `purgeObject` sin decir que acepta tipos reservados fija la letra sobre el agujero. Mi recomendación:
   cerrarlo aquí (una línea en el manager + una en el driver) porque el arreglo es más corto que el informe.
2. **¿`assertWrite` pasa a rechazar TODO retorno distinto de `undefined`?** Es una línea y cierra el ALTO 3 y
   el MEDIO 4. El coste es que un consumidor que hoy devuelve algo por accidente pasa de fail-open silencioso
   a 500 ruidoso — que es exactamente la decisión que ya se tomó para el caso `async`.
3. **La frase del MEDIO 6** («esa escritura no ocurrió y no hay evento») ¿se reescribe para las purgas de
   `openfga`, o se emite `indeterminate` cuando una purga multi-request falla después de la primera pasada?
