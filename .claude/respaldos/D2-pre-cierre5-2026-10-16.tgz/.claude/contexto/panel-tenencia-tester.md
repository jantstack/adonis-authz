# Panel «tenencia» (7.º informe de COGNITIV) — tester de contrato

> Entrada: `cognitiv-informe-7-tenencia.md`, postura `panel-tenencia-coordinador.md`. Leídos: `CLAUDE.md` (invariantes
> 1–18, «Cómo se decide un cambio» 1–10), `linajes.md`, README §Semantics / §Relations / §capabilities / §Custom drivers,
> `src/testing/relations_contract.ts`, `tests/relations*.spec.ts`, `src/relations/{manager,reconcile}.ts`, los dos drivers
> de relaciones. Solo lectura; nada editado fuera de este fichero.
>
> Marcas: **HOY** = tiene test hoy (archivo:línea) · **PROP** = se puede testear, propongo cómo · **NO-OBS** = no
> observable con la infraestructura actual (digo qué faltaría) ⇒ no se promete.

## 0 · Lo que he corrido (sqlite `:memory:`, specs sueltos, resultado real)

| spec | resultado |
|---|---|
| `tests/relations_contract.spec.ts` (runner común × 2 dobles) | 44/44 verde |
| `tests/relations_harness.spec.ts` (conteos del runner: `EXPECTED_CASES = 22`, `CAPABILITY_KEYS = 8`) | 9/9 verde |
| `tests/relations_database.spec.ts` | 47/47 verde |
| `tests/relations_reconcile.spec.ts` | 23/23 verde |
| `tests/relations.spec.ts` | 50/50 verde |

OpenFGA (`:8101` y el segundo con tope 3, `:8103`) no lo he corrido (fuera de lo permitido). Todo lo que digo de
`openfga` sale del código y de los specs, no de una medición mía.

## 1 · Hallazgos que cambian la postura del coordinador (lo que se puede medir)

1. **Un deny LITERAL rompe la monotonía de `includes`, y eso se puede medir.** Hoy R-02 (`relations_contract.ts:555`)
   fija «relate(editor) ⇒ check(viewer)». Con deny literal, un `owner` con `deny(viewer)` da `check(owner)=true`,
   `check(viewer)=false`: un dueño que no puede ver. La analogía con roles no aguanta, porque los permisos de rol no
   tienen `includes` (el deny de roles es por permiso porque no hay nada que subir). La tabla T1 (§3) enumera los
   27 estados. **Solo la semántica «sube» (la del informe) mantiene la propiedad
   `check(owner) ⇒ check(editor) ⇒ check(viewer)`.** Decida lo que decida el panel, la propiedad entra como caso
   exhaustivo (64 estados, §2.P1 caso P1-M) y la rama elegida queda fijada por su nombre.
2. **Renovar la caducidad de un deny en `openfga` abre una ventana fail-OPEN.** `relate` en openfga renueva con dos
   `Write` (delete y luego write; `openfga_relations_driver.ts:405-437`, comentario «FGA no admite delete+write de la
   misma clave en un Write»). Para un allow esa ventana es fail-closed (está documentado). Para un deny es lo
   contrario: entre las dos llamadas el deny no existe y `check` concede. Se puede observar con un espía que se
   detiene entre el delete y el write y lanza un `check` en medio (PROP, caso P1-R2). Con el patrón de `relate`
   copiado, ese caso sale **rojo**. Se lo paso al arquitecto y al auditor: la decisión es de diseño, pero sin este
   caso nadie lo ve.
3. **`reconcile` fusiona allow y deny si la clave no lleva el tipo.** `tupleKey` (`reconcile.ts:54`) es
   `partición|objeto#relación@sujeto` y se usa como clave de `Map` (`reconcile.ts:411-413`). Un allow y un deny del
   mismo hecho (que pueden convivir) colisionan: gana el último `set`, y uno de los dos ni se migra ni se poda. Hay
   además tres peligros fail-open en la migración: (a) un origen de terceros que no marca `kind` hace que sus denies
   se migren como allows; (b) un destino sin capacidad de deny recibe denies y los cuenta como `skipped`, cuando
   saltarse un deny es conceder; (c) `--prune` borra un deny sobrante con `to.unrelate`, que no lo toca. Todo esto
   tiene casos en §2.P1 (P1-K*) y la tabla T3.
4. **L1 (F-05) va por su 5.ª iteración si P1–P4 entran como parche.** El caso que cubre «las ocho» operaciones en
   `database` es una lista escrita a mano (`relations_database.spec.ts:554-599`). `deny`, `removeDeny`,
   `listDenies`, `checkMany` y `listObjectsForSubject` no aparecerían ahí y ese caso **seguiría verde**. M8 lo
   prohíbe: hace falta una guardia de superficie por reflexión **antes** de la primera operación nueva (§6).
5. **P5 no es solo documentación: la línea del provider no tiene test.** `authz_provider.ts:59` (`clock:
   config.clock`) no la cubre ningún caso: `grep clock` sobre los specs que usan `buildRelationsManager` solo
   encuentra un comentario (`relations_service.spec.ts:148`). Si se borra esa línea, por grep, nada se pone rojo.
   Es una entrada inerte del linaje L5. Hace falta un caso (P5-1).
6. **El gemelo de roles dice que `listSubjects` NO resta denies.** En roles, `listScopes` (una lista de decisión)
   resta el deny, mientras que `listSubjects`/`hasRole` (membresía) no (README semántica 2, «un deny NO afecta a
   hasRole», `contract.ts:1173`). El informe pide que `listSubjects` y `membersOf` de relaciones omitan a los
   denegados: eso es **asimetría entre gemelos** y cambia el invariante 7 («hechos DIRECTOS vigentes») para
   relaciones. Las dos ramas se pueden verificar, con costes muy distintos en openfga (T2).

## 2 · Por petición: (a) verificabilidad e invariantes, (b) casos con nombre, (f) mutantes

Convención de nombres: la de la suite (`ID · frase en presente; ⇒ resultado`). «COMÚN» = va a
`runRelationsDriverContract` y lo corren 2 dobles + `database` (TEST_DB) + `openfga` (`:8101` y `:8103`). «DB» /
«FGA» = spec del driver. «BRIDGE» = paridad `relations_bridge.spec.ts`. «REC» = `relations_reconcile_contract.ts` /
`relations_reconcile*.spec.ts`. Cada caso lleva el mutante que debe matar.

### P1 · Deny en relaciones

**(a) Verificable.** Es verificable con cambios: hay que decidir cuatro ramas (literal/sube, comodín, deny en
`group`, `listSubjects` resta o no) y añadir un par de capacidad `relationDenies`.

Invariantes en riesgo:
- **inv. 3** (caducidad estricta, R-15): con un deny, la expiración estricta en T es fail-OPEN en T. La propiedad
  sigue siendo cierta, pero cambia de signo y hay que nombrarla.
- **inv. 5**: un deny en una relación no declarada debe ser 422 con cero llamadas.
- **inv. 6**: idempotencia de `deny` y `removeDeny`. Además, en openfga una purga a medias tiene que dejar denies de
  más, nunca de menos.
- **inv. 7**: los `list*` dan hechos directos (T2).
- **inv. 10**: tres estados de `expiresAt` en el deny.
- **inv. 13**: `indeterminate` en `deny`/`removeDeny`.
- **inv. 6-trx / L2**: `{transaction}`.
- **inv. 14 / L3**: freeze.
- **README semántica 2**: el deny no afecta a `hasRole`, y tampoco a `authorize` desde relaciones.
- **R-02**: monotonía de `includes`.
- **R-13**: `RelationRef.operation` es un tipo publicado `'relate' | 'unrelate'`.

**(b) Casos con nombre**, uno por rama de cada decisión abierta:

| id | caso | dónde | mutante que mata |
|---|---|---|---|
| P1-1 | `deny gana sobre el allow directo; removeDeny lo restaura` | COMÚN | `check` sin el NOT EXISTS / sin `but not` |
| P1-2 | `deny antes del allow también bloquea: el orden de escritura no importa` | COMÚN | deny que solo se evalúa si es más reciente que el allow |
| P1-3 | `deny repetido no se duplica: un solo removeDeny lo levanta` | COMÚN | UNIQUE sin `kind` / insert sin el «¿ya existe?» |
| P1-4 | `relate y deny del MISMO hecho conviven; unrelate NO levanta el deny y removeDeny NO quita el allow` | COMÚN | DELETE de `unrelate`/`removeDeny` sin filtro por `kind` |
| P1-5 | `removeDeny y re-removeDeny sin deny son no-ops seguros` | COMÚN | lanzar 404 / 503 por ausente |
| P1-6a | **rama SUBE**: `un deny en viewer bloquea al owner y al editor en check(viewer), check(editor) y check(owner)` | COMÚN | conjunto de denies con `expandDown` (dirección equivocada) o literal |
| P1-6b | **rama LITERAL** (si gana): `un deny en viewer NO bloquea check(owner) ni check(editor); sí check(viewer) aunque el sujeto sea owner` | COMÚN | conjunto de denies = `expandUp` |
| P1-6c | `un deny en owner NO bloquea check(viewer) de un owner` (rama SUBE; en LITERAL también es cierto) | COMÚN | deny que se propaga hacia abajo |
| P1-6d | `owner con deny(editor): check(viewer) es <T en LITERAL y SUBE>`, sin depender del camino | COMÚN + BRIDGE | modelo FGA con `viewer = this or can_editor` (las includes sobre la relación EFECTIVA ⇒ semántica dependiente del camino, y openfga ≠ database) |
| P1-M | `monotonía: en los 64 estados de {allow, deny} × {owner, editor, viewer} sin caducidad, check(owner) ⇒ check(editor) ⇒ check(viewer)` (exhaustivo) | COMÚN | cualquier semántica no-SUBE (este caso **es** la decisión: con LITERAL se escribe como su negación documentada, `existe un estado en el que owner ⇏ viewer`) |
| P1-7 | `deny a un userset (group#member) bloquea a sus miembros, también anidados` | COMÚN | CTE del deny sin la recursión de `principal` |
| P1-8 | `deny directo bloquea aunque el sujeto sea miembro de un grupo con allow` | COMÚN | deny evaluado solo en el camino directo |
| P1-9 | `una membresía caducada deja de transportar el deny: el allow directo vuelve a conceder en T` | COMÚN (`injectableClock:true`) | `principal` del deny sin `active` (el deny sigue vivo por una membresía muerta: fail-closed de más, pero rompe la paridad) |
| P1-10 | `check de un USERSET como sujeto: deny(u) no bloquea check(group#member) aunque u sea miembro` | COMÚN | resta de denies de los miembros a su grupo |
| P1-11 | `deny caducado no bloquea: T−1 ms bloquea, T y T+1 conceden (estricto) en check/listObjects/checkMany` | COMÚN (`injectableClock:true`) | `expires_at >= now` en el deny |
| P1-12 | `deny en tres estados: omitido preserva el vigente (caducado ⇒ revive SIN caducidad), null lo hace permanente, Date lo fija` | COMÚN | `resolveGrantExpiry` sin aplicar a deny |
| P1-R1 | `renovar la caducidad de un deny es delete+insert dentro de UNA transacción (la fila cambia de uuid) y nunca hay instante sin deny` | DB | UPDATE / dos transacciones |
| P1-R2 | `renovar la caducidad de un deny NO abre ventana: un check lanzado entre las dos llamadas al cliente sigue en false` | FGA (espía con barrera) | el patrón delete-then-write de `relate` (**hoy sería rojo**, hallazgo 2) |
| P1-13 | `listObjects omite los objetos con deny vivo` | COMÚN | `listObjects` sin la resta |
| P1-14 | `listObjects omite los denegados aunque el sujeto tenga más denies que el tope del backend` (gemelo de `listScopes resta el deny…`, `contract.ts`) | COMÚN, con dientes en `:8103` | resta en cliente por un `Read` de denies que se pagina mal |
| P1-15a | **rama `listSubjects` RESTA**: `listSubjects y membersOf omiten a un holder con deny vivo, también por grupo` | COMÚN (membersOf: DB) | — |
| P1-15b | **rama `listSubjects` NO RESTA** (gemelo de roles): `listSubjects sigue dando el hecho directo de un sujeto denegado: es membresía, no acceso` | COMÚN | resta accidental |
| P1-15c | (cualquier rama) `listSubjects sigue listando el USERSET con allow aunque un miembro tenga deny` | COMÚN | — |
| P1-16 | `listDenies(object) da los denies DIRECTOS vigentes del objeto, holders y usersets, completos (1.200)` | COMÚN | filtrar caducados mal / truncar |
| P1-17a | **rama SIN comodín**: `deny a '*' ⇒ 422 E_AUTHZ_INVALID_IDENTITY con cero llamadas` | COMÚN | aceptar `*` |
| P1-17b | **rama comodín SOLO deny**: `deny('*') bloquea a todo holder; relate('*') ⇒ 422 (nunca un enlace público)` | COMÚN | comodín aceptado en `relate` |
| P1-18 | `deny sobre el tipo built-in group (excluir a alguien de un grupo) ⇒ <422 | soportado>` (decisión que el informe no menciona; elegir una) | COMÚN | — |
| P1-19 | `purgeObject borra allows Y denies del objeto (dos ortografías del uuid de partición)` | COMÚN | DELETE con filtro `kind = allow` |
| P1-20 | `purgeSubject borra los denies del sujeto; purgeSubject(group#member) quita el deny del grupo` | COMÚN | idem |
| P1-21 | `purge de openfga que muere a medias deja denies de MÁS: allows primero, denies al final (espía que falla tras el 1.er deleteTuples ⇒ check sigue false, indeterminate: true)` | FGA | orden deny→allow |
| P1-22 | `un deny NO afecta a roles.authorize ni a hasRole; un deny de rol NO afecta a relations.check` | BRIDGE (store compartido) | modelo que cruza `denied_*` de scope con `denied_*` de tipo de relación |
| P1-23 | `F-05: deny/removeDeny/listDenies sobre role_binding ⇒ 422 con CERO llamadas y CERO eventos, en manager Y driver` | COMÚN + guardia (§6) | olvidar `assertRelationDeclared` en la operación nueva |
| P1-24 | `freeze: deny/removeDeny ⇒ 503 E_AUTHZ_FROZEN, cero llamadas` | COMÚN (vía manager) | `#assertNotFrozen` ausente (L3) |
| P1-25 | `transactionalWrites:true · deny/removeDeny con { transaction } + rollback ⇒ CERO filas (censo)`; `false · 500 E_AUTHZ_UNSUPPORTED cero llamadas` | COMÚN (par existente, ampliar) | L2 |
| P1-26 | `deny/removeDeny que vencen el deadline notifican indeterminate: true antes del 503` | COMÚN / DB / FGA (socket mudo) | `#write` no usado |
| P1-27 | `onRelationWrite: deny ⇒ operation 'deny', removeDeny ⇒ 'removeDeny', con actor y expiresAt; requireActor alcanza a las dos` | COMÚN | evento sin `operation` nuevo |
| P1-28a/b | **rama `assertWrite` VE el deny**: `assertWrite recibe { operation: 'deny' }` / **rama NO lo ve**: `assertWrite NO se llama en deny/removeDeny (declarado)` | COMÚN | — |
| P1-29 | `defineRelationsConfig: el deny se modela con el prefijo YA reservado denied_ (una relación declarada 'viewer_denied' no colisiona)` | unitario | sufijo `_denied` (colisión con nombres de usuario válidos hoy) |
| P1-30 | `una relación cuyo nombre + 'denied_' pasa del límite de FGA ⇒ 422 al definir, no un 400 al publicar` | unitario + FGA | sin cota de longitud (PROP: medir el límite real contra `:8101`) |
| P1-31 | `capabilities.relationDenies:false · deny/removeDeny/listDenies ⇒ 500 E_AUTHZ_UNSUPPORTED nombrándolos, cero llamadas; jamás un deny ignorado` | COMÚN (cara false; doble MÍNIMO) | deny que devuelve void sin escribir |
| P1-32 | `un check de openfga con deny + includes + userset anidado sigue siendo UN Check` | FGA (espía) | resta en cliente con un segundo request |

**(f) Mutantes estructurales que no puede matar un caso suelto** (van como filas de tabla de verdad):
- dirección de la expansión del deny (`expandDown` en vez de `expandUp`): T1;
- `includes` sobre la relación efectiva en el modelo FGA: T1, fila *;
- `>=` en la caducidad del deny: T1, eje caducidad.

### P2 · `listObjectsForSubject` sin partición

**(a) Verificable** en `database`. En `openfga` es verificable con espía del filtro `Read` (`{user, object:
'<type>:'}`) contra `:8101`. Un `Read` por usuario y tipo es legal (lo que da 400 es tipo sin `user`, README
§sweep), pero hay que **medirlo** antes de prometerlo: NO-OBS hasta que exista el caso FGA.

Invariantes en riesgo:
- **inv. 7** (exhaustivo o ruidoso): un `[]` silencioso con la capacidad a `false` sería el defecto.
- **R-05** (aislamiento de partición): aquí el cruce entre particiones es deliberado, así que tiene que ser solo del
  propio sujeto.
- **R-15**: los `Read` de openfga traen tuplas escritas y la caducidad se filtra en cliente con el reloj del driver.

Hay una decisión que el coordinador no ve: «solo directas» ¿incluye lo derivado por `includes` (como R-09: directos
+ derivados) o solo la relación exacta?

| id | caso | dónde | mutante |
|---|---|---|---|
| P2-1 | `lo compartido con un holder en dos particiones sale entero y cada objeto con SU partición` | COMÚN | filtro por partición residual |
| P2-2a | **rama includes**: `listObjectsForSubject(viewer) incluye el objeto donde el sujeto es editor (como R-09)` | COMÚN | filtro `relation = ?` |
| P2-2b | **rama exacta**: `… NO incluye el de editor` | COMÚN | — |
| P2-3a | **rama solo directas** (coordinador): `un objeto compartido con un grupo del que el sujeto es miembro NO aparece` (declarado) | COMÚN | — |
| P2-3b | **rama usersets**: `… SÍ aparece, también anidado` | COMÚN | — |
| P2-4 | `una tupla caducada no aparece (T−1 ms sí, T no)` | COMÚN (`injectableClock`) | filtro de caducidad ausente en el `Read` de openfga |
| P2-5 | `un objeto con deny vivo no aparece, también por deny a un grupo del sujeto` | COMÚN | resta solo del deny directo |
| P2-6 | `subject = userset ⇒ 422 (un userset vive en una partición; sin partición no tiene sentido)` | COMÚN | aceptar userset y cruzar particiones |
| P2-7 | `options.partitions acota; partitions: [] ⇒ 422 (nunca «sin filtro»)` | COMÚN | `[]` tratado como ausente (devolvería TODO) |
| P2-8 | `purgeSubject en una partición no toca lo compartido en otra; purgeObject de la dueña lo retira` | COMÚN | purga sin partición |
| P2-9 | `paginación: renovar la caducidad entre dos páginas no duplica ni pierde el objeto` | DB (INSERT/DELETE-ONLY cambia el uuid) | cursor por `uuid` de fila (la fila renovada salta al final y sale dos veces) |
| P2-10 | `paginación: un insert entre páginas no desplaza ni pierde lo ya paginado (cursor por clave natural)` | COMÚN | cursor por OFFSET |
| P2-11 | `capabilities.listObjectsForSubject:false ⇒ 500 E_AUTHZ_UNSUPPORTED nombrándolo, cero llamadas; nunca []` | COMÚN (cara false) | `[]` |
| P2-12 | `F-05: objectType role_binding ⇒ 422 cero llamadas` | COMÚN + guardia | L1 |
| P2-13 | `openfga: el filtro de cada read es {user, object: '<type>:'} y el número de reads es ceil(tuplas del sujeto/100), no el del store` | FGA (espía) | `Read({})` del store entero (correcto, pero viola la promesa de coste) |
| P2-14 | `dos ortografías del uuid de partición salen como DOS particiones (o una canónica): elegir y fijar` | DB | — |

### P3 · Metadatos por tupla (postura: no almacenar; exportar la clave estable)

**(a) Verificable** en las dos ramas; la del coordinador es mucho más barata de probar.

Si se almacena `meta` en openfga (tabla SQL auxiliar), son dos escrituras no atómicas (L2): la ventana
«tupla sin meta / meta sin tupla» solo se observa con un espía que falla entre las dos. Para cerrarla haría falta
otro reconcile de la tabla auxiliar.

Riesgo de la clave: `tupleKey` ya existe y es privada en `reconcile.ts:54`. **El gemelo exige que la clave pública y
la de reconcile sean la MISMA función** (punto de paso único). Si son dos, divergen, como en L6.

| id | caso | dónde | mutante |
|---|---|---|---|
| P3-1 | `relationKey es determinista e INYECTIVA: dos tuplas distintas (sujeto, relación, objeto, partición, kind) ⇒ dos claves` (exhaustivo sobre un dominio pequeño, incluidos holder vs userset con el mismo uuid y tipos distintos con el mismo uuid, inv. 4) | unitario | clave sin `kind` / sin `subject_relation` / sin tipo del holder |
| P3-2 | `relationKey no cambia al renovar la caducidad (aunque database cambie el uuid de la fila)` | COMÚN | clave = uuid de fila |
| P3-3 | `relationKey de un deny ≠ la del allow del mismo hecho` | unitario | sin `kind` |
| P3-4 | `reconcile usa relationKey (identidad de función, no copia)` | guardia (import por identidad, patrón `command_flags.spec` R1) | segunda implementación |
| P3-5 | `ortografías de partición: <una o dos claves> (fijar; lo coherente con check es dos)` | unitario | — |
| P3-6 | (si se almacena) `meta omitido conserva, null borra, objeto sustituye sin merge; > 2 KB ⇒ 422; meta no influye en check; purge y reconcile la llevan` | COMÚN | merge parcial |

### P4 · `checkMany`

**(a) Verificable, y barato.** Invariante en riesgo: **inv. 5** (un `error` por ítem de un `batchCheck` es 503, nunca
`false`; precedente de roles: «authorize: error en un check de rol ⇒ 503»).

| id | caso | dónde | mutante |
|---|---|---|---|
| P4-1 | `checkMany equivale a N check, posición a posición, en un estado con allow, deny, caducado, userset e includes` | COMÚN | — (oráculo = `check`) |
| P4-2 | `el orden de la respuesta es el de la petición aunque los ids vengan en orden inverso al de la BD` (patrón F,T,F,T) | COMÚN | mapear las filas de SQL por índice |
| P4-3 | `un error en UN ítem del batchCheck ⇒ 503 para todos, sin booleanos parciales` | FGA (espía que inyecta `error`) | `error ⇒ false` |
| P4-4a | **rama duplicados permitidos**: `[a, a, b] ⇒ [x, x, y]` | COMÚN | correlationId = id del objeto (FGA rechaza o la alineación lanza, `openfga_driver.ts:260`) |
| P4-4b | **rama duplicados ⇒ 422** | COMÚN | — |
| P4-5 | `50 objetos responde; 51 ⇒ 422 con cero llamadas; [] ⇒ <[] sin llamadas | 422> (fijar)` | COMÚN | `>` vs `>=` en el tope |
| P4-6 | `F-05 por ÍTEM: un role_binding entre 20 documentos ⇒ 422 para toda la llamada, CERO llamadas` | COMÚN + guardia | solo se valida `objects[0]` |
| P4-7 | `objetos de tipos mezclados: <permitido | 422> (fijar)` | COMÚN | — |
| P4-8 | `database: checkMany es UNA consulta (espía de knex)`; `openfga: UN batchCheck por cada 50` | DB / FGA | N consultas (correcto pero sin la promesa de coste; no va a la COMÚN) |
| P4-9 | `capabilities.checkManyNative:false ⇒ el manager cae a N check secuenciales con la misma respuesta y el primer error propaga` | COMÚN (doble MÍNIMO) | respaldo que traga errores |

### P5 · Reloj inyectable

**(a) Verificable. Hoy no tiene caso** (hallazgo 5).

| id | caso | dónde | mutante |
|---|---|---|---|
| P5-1 | `config.clock llega a authz.relations: con el reloj fijado en T, una tupla con expiresAt = T no concede por el singleton` | `relations_service.spec` (buildRelationsManager) | borrar `clock: config.clock` (`authz_provider.ts:59`) — **hoy sobrevive** (por grep) |
| P5-2 | `withClock del helper devuelve una VISTA: el singleton sigue con su reloj (no fuga entre peticiones)` | servicio | helper que muta el reloj global |
| P5-3 | `el reloj inyectado decide también deny, checkMany y listObjectsForSubject (borde T−1/T/T+1)` | COMÚN (`injectableClock:true`) | un método nuevo que llama a `systemClock` |
| P5-4 | `config.clock sobre un driver sin withClock ⇒ 500 E_AUTHZ_CONFIG` | ya existe en el manager (`manager.ts:115`) | — |
| P5-doc | `el README «Testing expiry from your app» compila` (patrón de los casos de docs `relations_events_docs.spec`) | docs | ejemplo desactualizado |

## 3 · (c) Tablas de verdad

### T1 · deny × allow × relación preguntada (`owner ⊆ editor ⊆ viewer`), sin caducidad, holder directo

`incl*(viewer)={viewer,editor,owner}`, `incl*(editor)={editor,owner}`, `incl*(owner)={owner}`.
Concede si `A ∈ incl*(Q)` y no está bloqueado. LITERAL bloquea si `D = Q`. SUBE bloquea si `Q ∈ incl*(D)`. CAMINO es
el mutante FGA: `Q = this_Q or can_<inferior>`.

Con A = owner (concede las tres):

| D \ Q | viewer L / S / CAMINO | editor L / S / CAMINO | owner L / S / CAMINO | ¿monótono? L / S |
|---|---|---|---|---|
| viewer | F / F / F | **T** / F / T | **T** / F / T | **no** / sí |
| editor | T / T / **F** | F / F / F | T / F / T | sí / sí (CAMINO: no) |
| owner | T / T / F | T / T / F | F / F / F | sí / sí (CAMINO: no) |

Filas adicionales, con la misma salida para L y S: A = viewer y D = editor ⇒ `check(viewer) = T` en las dos; A = editor
y D = viewer ⇒ `check(editor) = F` en S, `T` en L. La fila (A = owner, D = editor, Q = viewer) separa CAMINO de las
otras dos: es la que convierte una diferencia del modelo FGA en un rojo del BRIDGE.

Ejes adicionales (cada uno multiplica la fila base A=viewer, D=viewer, Q=viewer):

| deny vía | allow vía | deny caduca en T | consulta en | resultado |
|---|---|---|---|---|
| directo | directo | no | — | F |
| directo | directo | sí | T−1 / T / T+1 | F / T / T |
| grupo (miembro vivo) | directo | no | — | F |
| grupo (membresía caduca en T) | directo | no | T−1 / T | F / T |
| directo | grupo | no | — | F |
| grupo anidado (g1 ⊂ g2, deny a g2) | directo | no | — | F |
| sin deny | directo | — | — | T |
| directo, después `removeDeny` | directo | — | — | T |
| directo, después `unrelate` | directo | — | — | F (allow fuera) — y `listDenies` sigue con el deny |
| deny antes / después del allow | directo | — | — | F / F |

### T2 · qué devuelve cada lectura con un deny vivo (u con allow directo en viewer)

| deny | `check` | `listObjects` | `checkMany` | `listObjectsForSubject` | `listSubjects` rama RESTA / NO RESTA | `membersOf` (DB) RESTA / NO | coste openfga de RESTA |
|---|---|---|---|---|---|---|---|
| ninguno | T | incluye | T | incluye | u / u | u / u | 0 |
| directo a u | F | omite | F | omite | — / u | — / u | `Read` de denies del objeto |
| a `g#member`, u ∈ g | F | omite | F | omite | — / u | — / u | **un Check por sujeto listado** (1.200 sujetos ⇒ 1.200 checks en batch) |
| a u, allow a `g#member` | F | omite | F | — (rama directas) | `g#member` / `g#member` | — / u | idem |

La rama NO RESTA conserva el inv. 7 y el gemelo de roles, y es la única barata en openfga. La rama RESTA es
verificable, pero el caso «1.200 vuelven enteras» pasa a costar 1.200 checks: el coste de prueba sube y hay riesgo de
503 por ítem.

### T3 · reconcile × deny

| origen declara deny | destino declara deny | tupla | `kind` en la tupla enumerada | resultado exigido | exit |
|---|---|---|---|---|---|
| sí | sí | deny vivo | `'deny'` | `to.deny(...)`, contado en `written.denies` | 0 |
| sí | sí | deny caducado | `'deny'` | `skipped.expired` | 0 |
| sí | sí | deny + allow del mismo hecho | ambos | DOS escrituras (clave con `kind`) | 0 |
| sí | **no** | deny vivo | `'deny'` | **500 antes de escribir nada** (saltarse un deny es conceder) | ≠0 |
| no (terceros, sin `kind`) | sí | — | ausente ⇒ allow | se migra como allow; caso que fija que un driver que DECLARA `relationDenies:true` y no marca `kind` **no pasa el runner** | — |
| sí | sí | deny en destino y no en origen, `--prune` | — | `to.removeDeny` (no `unrelate`) | 0 |
| sí | sí | orden | — | denies **antes** que allows; con `--prune`, allows sobrantes **antes** que denies sobrantes; una pasada que muere a medias (espía) nunca deja un allow sin su deny | ≠0 si muere |
| sí | sí | `--dry-run` | — | denies a escribir/borrar = deriva | ≠0 |

### T4 · `checkMany` × error por ítem × tamaño × capacidad

| nº objetos | duplicados | ítem con `error` | ítem undeclared | capacidad nativa | resultado |
|---|---|---|---|---|---|
| 0 | — | — | — | — | `[]` sin llamadas **o** 422 (fijar) |
| 1..50 | no | no | no | sí / no | `boolean[]` = N × `check` |
| 1..50 | sí | no | no | sí / no | por posición (rama A) / 422 (rama B) |
| 1..50 | — | sí | no | sí | 503 total, sin booleanos |
| 1..50 | — | sí (el `check` k lanza) | no | no (respaldo) | 503, los check posteriores no se esperan |
| 1..50 | — | — | sí | — | 422 total, cero llamadas |
| 51 | — | — | — | — | 422, cero llamadas |

### T5 · `listObjectsForSubject` × capacidad × `partitions` × sujeto

| capacidad | `partitions` | sujeto | resultado |
|---|---|---|---|
| false | cualquiera | cualquiera | 500 `E_AUTHZ_UNSUPPORTED`, cero llamadas |
| true | ausente | holder | todas las particiones del holder |
| true | `[A]` | holder | solo A |
| true | `[]` | holder | 422 |
| true | ausente / `[A]` | userset | 422 |
| true | `[A]` con A mal formada | holder | 422 `E_AUTHZ_INVALID_IDENTITY` |

## 4 · (d) Suite COMÚN vs. específico de driver

| va a la COMÚN (`runRelationsDriverContract`, con su par de capacidad) | específico |
|---|---|
| P1-1…16, 17a/b, 18, 19, 20, 23–25, 27, 28, 31, P1-M (64 estados) | **FGA**: P1-R2 (ventana al renovar), P1-21 (orden de purga multi-request), P1-26 con socket mudo, P1-30 (límite de longitud medido), P1-32 (un Check), P2-13 (filtro del `Read`), P4-3 (error por ítem en `batchCheck`), P4-8 (un batchCheck por 50) |
| P1-14 con dientes: el runner ya corre contra `:8103` (tope 3, `relations_openfga.spec.ts:94-121`); el caso siembra `tope + 2` objetos denegados más 2 permitidos y exige exactamente los 2 sin `truncated` falso | **DB**: P1-R1 (delete+insert atómico, uuid nuevo), CTE: el deny por la MISMA `principal` (un caso con grupos anidados a 3 niveles en los tres motores pg/mysql/sqlite), UNIQUE con `kind` en los tres motores (gemelo de L-4b: dos `deny` concurrentes ⇒ una fila), P2-9, P2-14, P4-8 |
| P2-1…8, 10–12; P3-2; P4-1, 2, 4–7, 9; P5-3 | **BRIDGE** (paridad database = openfga con el mismo reloj): T1 completa, P1-6d, P1-22, P4-1 |
| Nuevas capacidades, con sus DOS caras cada una: `relationDenies`, `listObjectsForSubject`, `checkManyNative` (y `relationMeta` solo si P3 almacena). El doble FULL las declara `true` y el MÍNIMO `false`, como hoy | **unitario**: P1-29/30, P3-1/3/5, T3 sobre dobles |

Coste: **medio-alto**. La COMÚN pasa de 22 a ~55 casos por driver × 5 instancias (2 dobles, database, `:8101`,
`:8103`). La infraestructura existe: el doble, los espías (`fga_spy`), `withClock`, el segundo servidor. Lo nuevo es
el doble con deny y el espía con barrera para P1-R2.

## 5 · (e) Gemelos

| par | caso que fija la paridad | estado |
|---|---|---|
| roles `deny` ↔ relaciones `deny` | P1-1/2/3/5 copian los cuatro casos de roles por nombre (`contract.ts:774,1316,1330,1222`); P1-15b, el de `hasRole`. **Asimetrías que hay que declarar, no esconder**: el deny de relaciones caduca y admite usersets; el de roles no | PROP |
| roles `listScopes` resta ↔ relaciones `listObjects` resta | P1-14 con el mismo `:8103` | PROP |
| manager ↔ driver | toda guarda (F-05, `{transaction}`, freeze, `expiresAt`) en las dos capas, con `manager.driver()` llamado en directo (patrón `relations_database.spec.ts:554`) | PROP, y guardia §6 |
| manager ↔ driver ↔ comando `authz:relations:reconcile` | T3 por el **kernel** (`exec(['--dry-run'])`, regla 7 «toda salida dice qué rama corrió»): una línea distinta y un exit propio para «N denies migrados», «destino sin deny: rechazado», «denies sobrantes podados» | PROP |
| `enumerateRelations` ↔ reconcile | `enumerateRelations` devuelve los denies con `kind: 'deny'` **sin filtrar caducados** (R-15) y el censo de `relations_reconcile_contract.ts` busca cada deny en el destino por `listDenies`, no por `listSubjects` | PROP (el contrato de reconcile pasa de 11 casos a ~15) |
| `relationKey` público ↔ `tupleKey` de reconcile | P3-4 por identidad | PROP |
| `checkMany` ↔ `check` | P4-1 con `check` como oráculo | PROP |
| `listObjectsForSubject` ↔ `listObjects` por partición | propiedad: para cada partición P, `filtrar(listObjectsForSubject, P) = listObjects(P)` (rama includes + directas) | PROP |
| receta por dirección del README (`deny` restrictivo, `removeDeny` permisivo) | caso de docs | PROP |

## 6 · Guardia de superficie para L1 (obligatoria por M8 antes de añadir operaciones)

Hoy L1 tiene la guardia «pendiente». Las operaciones nuevas serían su 5.ª iteración. Propuesta verificable: un spec
que

1. enumera por reflexión `Object.getOwnPropertyNames(RelationsManager.prototype)` y los métodos de los dos drivers;
2. para cada método público tiene una fila en una tabla `{ método → sonda con role_binding }`. Si falta la fila, el
   spec da rojo.
3. Cada sonda exige 422 con cero llamadas al cliente o a la conexión y cero eventos.
4. Mutante por entrada: quitar `assertRelationDeclared` de cada método nuevo ⇒ rojo.

Mismo patrón que «cierre alpha.10 · R1» de `command_flags.spec.ts:980`.

## 7 · (g) Casos EXISTENTES que se pondrían rojos

| caso | por qué | ¿correcto? |
|---|---|---|
| `relations_harness.spec.ts`: `EXPECTED_CASES = 22`, `CAPABILITY_KEYS = 8` | casos y capacidades nuevos | sí: se actualiza el literal con el desglose en el comentario (como hasta ahora) |
| `relations_harness.spec.ts:201`: el contrato de reconcile registra 11 | casos de deny en reconcile | sí |
| `openfga_facts.spec.ts:4300-4342`: literal `DOCUMENT_DEF`/`EXPECTED_FUSED` | el modelo gana `denied_*`/`can_*` | sí, si es deliberado. Si el deny es **opt-in por relación**, este literal sigue verde (buen control: el modelo de quien no usa deny no cambia) |
| `openfga_facts.spec.ts:4372+`: gate de bytes fusionado, y las cifras del README «24 tipos de tres relaciones» | bytes por relación con deny | sí. Hay que volver a medir; la cifra del README es falsa hasta entonces (riesgo de L8) |
| `relations_events_docs.spec.ts:196` (F10, «all eight operations») y F3 (tabla de `operation`) | más operaciones y eventos | sí, y obliga a reescribir la letra |
| `migration_stub.spec.ts:37` («ocho tablas») | solo si el deny va en tabla aparte; con una columna `kind`, no | depende del diseño. Columna ⇒ migración y receta en §Upgrading, con UNIQUE `authz_rel_tuple_uq` + `kind` |
| R-09 (`relations_contract.ts:622`), `listObjects: el mismo conjunto` (BRIDGE:396), R-02 | **ninguno se pone rojo**: no escriben denies | correcto. Ningún caso actual afirma un `listObjects` que un deny falsifique. El cambio observable es solo para quien escriba denies (por eso basta un minor) |
| `relations_database.spec.ts:554` («las ocho») | **no se pone rojo y queda incompleto** | **no es correcto**: es la razón de §6 |

## 8 · Lo que NO se puede observar con un test y no debe prometerse

- **NO-OBS:** que `ListObjects` de openfga con `but not` no devuelva parciales por el *deadline* del servidor
  (`listObjectsDeadline`): sin tope alcanzado no hay señal. La señal `truncated` solo cubre el corte por número. Para
  observarlo haría falta un servidor con un deadline de pocos ms y una carga que lo dispare de forma determinista;
  hoy no existe. No se promete «exhaustivo» en `listObjects` con deny en openfga, solo «exhaustivo o `truncated`
  por tope».
- **NO-OBS:** el desfase de reloj entre procesos al expirar un deny (cada proceso decide con su reloj). Se promete el
  borde con un reloj; el desfase se documenta.
- **NO-OBS:** la estabilidad de los `continuation_token` de openfga ante escrituras concurrentes es del servidor.
  Se puede observar un caso (P2-10), no prometer una garantía.
- **NO-OBS:** el «ahorro» de P2 y P4 en latencia. Lo que se promete es el **número de requests** (espía), no
  milisegundos.
- **NO-OBS:** la atomicidad tupla+meta en openfga (P3 almacenado). No hay 2PC; solo se observa la ventana con un
  espía y no se puede cerrar. Es un argumento más para la postura del coordinador en P3.
- **No prometer** «el deny se comporta como el de roles». Difiere en `includes`, caducidad y usersets. Se promete lo
  que fijen los casos con nombre.

## 9 · Veredicto por petición

| # | casos nuevos | invariantes en riesgo | coste de prueba | veredicto |
|---|---|---|---|---|
| P1 | ~35 + P1-M exhaustivo + T1/T3 | 3 (cambia de signo), 5, 6, 7, 10, 13, L1, L2, L3, R-02, R-13 | alto (doble con deny, espía con barrera, `:8103`, 3 motores, bridge, reconcile) | **verificable con cambios**: decidir LITERAL/SUBE (T1 muestra que LITERAL rompe la monotonía), `listSubjects` resta o no, deny en `group`, comodín; guardia §6 antes; P1-R2 es un rojo de diseño |
| P2 | ~14 | 7, R-05, R-15 | medio (en FGA hay que medir el `Read` por user+tipo) | **verificable con cambios**: fijar includes, usersets, `partitions: []`, cursor |
| P3 | 4 (clave) / +6 (si se almacena) | 4, 6; L2 si se almacena | bajo (clave) / alto (meta en FGA) | clave: **verificable**; meta en openfga: **verificable solo con ventana declarada** |
| P4 | ~9 | 5 | bajo | **verificable**: fijar `[]`, duplicados y tipos mezclados |
| P5 | 4 | 3; L5 (entrada inerte) | bajo | **verificable**; hoy la línea del provider no tiene caso (P5-1 es obligatorio, no opcional) |

Orden de prueba que propongo (igual al del coordinador, más una pieza al principio): **guardia L1 (§6)** → P5-1 → P4
→ P1 (con T1 decidida primero) → P2 → P3-clave.
