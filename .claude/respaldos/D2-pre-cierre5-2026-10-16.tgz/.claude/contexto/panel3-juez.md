# Panel 3 · JUEZ — el `freeze()` de `authz:reconcile`

**Fecha:** 2026-08-31 · **Árbol:** `/home/jose/proyectos/Personal/adonis-authz` (solo lectura + este
informe) · **Insumos:** `panel3-analista.md`, `panel3-auditor.md`, `panel3-tester.md`,
`CLAUDE.md`, `decisiones-dueno-2026-08-28.md`, `fase-3b-auditor-final.md`.
**Lecturas de código propias** (para arbitrar, no para opinar): `manager.ts:392-419` y `:857`,
`openfga_driver.ts:2644-2702` y `:2876-2893`, `README.md:607-619`, `CLAUDE.md` invariante 14.

---

## Veredicto

**Recomendación:** **B ejecutada entera + E-analista** (79/100 contra los criterios de abajo; B sola
saca 83, y explico abajo por qué no gano nada quedándome ahí). En una frase: **se reescribe la
promesa hoy —porque hoy es falsa y la regla dura del paquete no admite otra cosa— y se construye el
mecanismo que la vuelve cierta donde puede serlo, con el número que lo justifica ya medido: +0,14 ms
p50 por `grant`/`deny`/`revoke` y 0 ms por `authorize`.**

**Con estos injertos de las opciones perdedoras:**

| Injerto | De dónde viene | Por qué entra |
|---|---|---|
| `--dry-run` **no congela** | auditor 🟡 8 | Gratis (no escribe nada) y hoy es un outage latente |
| `freeze()` devuelve **token/fence**; `unfreeze(token)` solo levanta el suyo | auditor 🟠 4 | Sin esto, un `reconcile` anidado descongela la flota entera: A1.3 medido |
| La frase del README **enumera qué NO congela**: `syncAuthzCatalog`, `manager.driver()`, el árbol del consumidor | auditor 🟠 5 | Medido: las tres escriben con el motor congelado |
| La promesa publicada es «**otro proceso recibe 503**», jamás «ninguna escritura entra en la ventana» | tester A4 | La segunda no es falsificable con destino OpenFGA. Nunca |
| **Testigo de ventana con `readChanges({startTime})`** en la dirección cuyo origen es el store | **E-auditor** | Es la única pieza que cubre el hueco que la foto consistente SQL no alcanza, y ya está medida |
| **`report.frozen: { durable, lapsed, leaseMs, fence }`**; `lapsed: true` ⇒ la pasada no se certifica y el comando sale ≠ 0 | analista §2.4 | Es lo que convierte «esperemos que nadie escribiera» en un booleano publicado |
| La línea de reporte de la 2.ª pasada, **con la frase del tester y sin la conclusión de D** | tester §2 | «Te dice si el destino coincide con el origen AHORA; no dice si la 1.ª pasada fue limpia, y no puede» |
| «*a maintenance window of **seconds***» (README:615) corregido a la medida | analista §2.1 | 0,136 ms/hecho ⇒ **≈136 s** al tope declarado de 1 000 000. Es otra promesa incumplida, en el mismo párrafo |

**NO se injerta:** el **tombstone de revoke en `authz_*`** de E-auditor (motivo en «afirmaciones
descartadas»: es la única pieza de E-auditor sin una sola medida, y es tabla publicada).

**Condiciones para proceder** (las tres, en este orden):

1. **El 🔴 3 del auditor se arregla PRIMERO y en su propio lote, antes de mergear 3b a `main`.**
   No depende de esta decisión y bloquea el merge por sí solo. Dictamen completo abajo.
2. **El cutover entra en el alcance** como `authz:freeze` / `authz:unfreeze` (comandos de operador,
   `--lease-ms`), con `reconcile` corriendo dentro. **Si el dueño lo deja fuera, E-analista pierde y
   la recomendación pasa a B sola.** No es un extra: es la condición que sostiene la relación
   coste/beneficio de E.
3. **La pregunta de negocio** (§6). Si no se contesta, se procede con B + E-analista; el motivo está
   escrito y es un precedente firmado, no una preferencia mía.

---

## Criterios (declarados antes de puntuar)

| # | Criterio | Peso | Qué mide |
|---|---|---|---|
| 1 | **Cómo falla** | 25 | Abierto/cerrado, permanencia del fallo, y si el fallo es detectable |
| 2 | **Honestidad de lo publicado** | 20 | Regla dura: *lo publicado se cumple o se reescribe*. Una promesa que queda incumplida descalifica |
| 3 | **Verificabilidad con mutante** | 20 | Regla vigente: *una garantía que no se puede poner en rojo con un mutante no es una garantía*. Cuenta también en qué motores |
| 4 | **Coste medido** | 15 | Latencia por escritura/lectura, código, refactor. Solo números medidos |
| 5 | **Coste en la suite PUBLICADA** (`src/testing/`) | 12 | Lo que le cuesta a un driver de terceros; y si la promesa queda fuera del contrato |
| 6 | **Reversibilidad** | 8 | Deshacerlo, ¿es un párrafo o una migración de esquema publicada? |

## Tabla de puntuación

| Criterio (peso) | A (durable sin lease) | B | C | D | **E-analista** | **E-auditor** | **B+E-an (recomendada)** |
|---|---|---|---|---|---|---|---|
| Cómo falla (25) | 3 · cerrado de FLOTA permanente tras `SIGKILL`; abierto en las esquinas | 4 · abierto siempre, como hoy | 3 · A + una bandera que apaga la garantía | **0** · abierto **y en verde** | 8 · cerrado en la pasada, acotado a `leaseMs`, y el fence lo delata | 5 · no previene; lo que afirma es verdad | **9** |
| Honestidad (20) | 2 · deja la frase falsa con promesa fuerte | **10** | 4 · dos frases, gana la fuerte | 1 · certifica limpio sobre una pérdida | 9 | 8 | **10** |
| Verificabilidad (20) | 6 | **10** · 4/4 motores, cero infra | 5 | **0** · el tester la puso en rojo | 8 · 3/4 motores + fence falsificable | 4 · `readChanges` sí; el tombstone no existe | **9** |
| Coste medido (15) | 7 | **10** · cero | 5 | 8 | 7 · +0,14 ms p50/escritura, 0/lectura | 5 · tombstone sin medir | 7 |
| Suite publicada (12) | 3 | **10** · cero | 2 | 6 | 4 | 6 | 4 |
| Reversibilidad (8) | 4 | **8** | 3 | 7 | 4 | 5 | 4 |
| **Total** | **41** | **83** | **38** | **27** | **73** | **55** | **79** |

**Leo mi propia tabla en voz alta, porque el resultado incomoda:** contra criterios de ingeniería
puros **B gana (83 vs 79)**. La diferencia son 4 puntos, por debajo de la precisión de mis propias
notas, y —esto es lo importante— **ningún criterio de la tabla pesa la pregunta que de verdad
decide**: cuál de los dos costes prefiere pagar el dueño. Por eso no recomiendo B a secas. Recomiendo
B **completa** (que es la mayor parte del trabajo y se hace pase lo que pase) **más** el mecanismo,
y declaro explícitamente qué respuesta del dueño devuelve la victoria a B sola (§6).

**Descalificaciones directas, sin puntuación que las salve:**

- **D queda fuera como garantía.** Tres panelistas la rompieron por caminos independientes y con
  medidas coincidentes: analista `m5` (el `revoke` sale `w=0 u=0 del=0 extra=1` ⇒ el criterio
  literal no lo ve), auditor D1.a/D1.c/D2.b (`clean=true` sobre una pérdida, PG **y** MySQL, dígito a
  dígito), tester D5 (el detector certifica limpia su propia ventana). La regla del paquete —*una
  garantía que no se puede poner en rojo con un mutante no es una garantía*— aquí se aplica al revés
  y es peor: **la garantía se pone en rojo con un mutante, y el mutante es el comportamiento real.**
  Sobrevive únicamente como línea de reporte, con la frase del tester.
- **C queda fuera.** La bandera es la parte peligrosa: existe para no pagar **0,14 ms p50** a cambio
  de apagar una garantía de seguridad. Con esos números no hay trade-off que la justifique, y el
  tester midió que multiplica la matriz de casos por dos ramas de config.
- **A «tal cual» queda fuera** por el mismo motivo que el auditor le clava en 🟠 6.1 y que el
  analista mide: un `SIGKILL` deja la fila puesta y la flota entera sin escribir hasta que un humano
  la borre a mano. Cambiar un 🟠 por un incidente de disponibilidad indefinido no es un arreglo.
  **E-analista existe exactamente para eso**, y su recuperación está medida: **2 527 ms con lease de
  3 000 ms, sin que nadie limpie nada.**

---

## Los tres puntos que el encargo marca como innegociables

### 1 · El 🔴 3 del auditor (dos barridos separados) — **independiente, misma tanda, y va PRIMERO**

**Verificado por mí en el código, no aceptado del informe.** `openfga_driver.ts:2644-2702`
(`readSourceFacts`) hace dos recorridos consecutivos —`authz_assignments` y luego `authz_denies`— y
`eachRow` (`:2876-2893`) construye cada página desde la conexión global (`build(db)`), **sin
transacción que abarque los dos**. El hueco entre barridos es el tiempo de pasear `authz_assignments`
entera por lotes de 100. El auditor lo reprodujo contra OpenFGA real + PG (`d3_mitad_de_transaccion.ts`):
un offboarding completo (`revoke` + `removeDeny`, dos escrituras de UNA operación de negocio) que cae
en ese hueco deja el destino con **el rol sin su deny**, concediendo `docs:write`, y el reporte dice
`written=13 extra=0 skipped={} clean=true`.

**Dictamen, punto por punto:**

- **¿Es independiente de A/B/C/D/E?** **Sí, completamente.** El arreglo es local, es SQL, y no
  coordina nada entre procesos: los dos barridos dentro de una sola transacción de lectura repetible
  (PG: `BEGIN ISOLATION LEVEL REPEATABLE READ`; MySQL/InnoDB: REPEATABLE READ ya es el default, basta
  abrir la transacción; SQLite: una transacción de lectura). Ni el freeze durable ni la detección a
  posteriori lo tocan.
- **¿Va en la misma tanda?** **Sí, y bloquea el merge de 3b a `main` por sí solo**, con
  independencia de lo que se decida sobre el freeze. Es el único hallazgo de todo el panel en el que
  la migración **no pierde un permiso: fabrica uno** que ni el estado anterior ni el posterior
  concedían, con `clean=true`. Es una escalada, no una deriva, y el operador no tiene ni un motivo
  para desconfiar del verde.
- **¿Con qué prioridad respecto a la decisión del freeze?** **Antes.** Dos razones: (a) es
  fail-open de fabricación, la clase de defecto que la Fase 3b entera existe para cerrar; (b) **le
  quita a A/E su argumento más fuerte**, cosa que el propio auditor anticipó en su pregunta abierta
  4. Cuantifico el efecto: con la foto consistente, el peor resultado de la ventana deja de ser «un
  estado que nunca existió» y pasa a ser «el estado consistente de `t0`», o sea la deriva recuperable
  que el 🟠 3 original ya describía. Eso baja el riesgo de una categoría entera **sin pagar 0,14 ms
  por escritura**, y hay que hacerlo aunque el dueño decida B.
- **Lo que el arreglo NO cierra, y hay que escribirlo:** cubre la dirección cuyo origen es `authz_*`
  (`--to=openfga`). En la dirección contraria el origen es el store y las páginas de
  `enumerateFacts` (`Read` paginado) **tampoco son una foto consistente**: la misma composición de
  media transacción es posible ahí y no hay `REPEATABLE READ` que valga. **Ese es exactamente el
  hueco donde el injerto de E-auditor (`readChanges({startTime})`) aporta valor real**: no lo
  previene, pero lo detecta y nombra la tupla. Una dirección se cierra, la otra se instrumenta.

### 2 · El agujero que las cuatro comparten: el **cutover** — **entra en el alcance**

Analista §3.1 (agujero 4) y auditor §2 llegaron a él por caminos distintos y coinciden: `manager.ts:857`
envuelve **solo `target.reconcile()`**, y la ventana peligrosa no acaba cuando acaba la pasada, sino
cuando el último worker ha recargado `config.default`. Eso son minutos u horas y lo decide un humano.
Convergencia de dos panelistas independientes ⇒ le doy el peso máximo.

**Dictamen: entra**, en la forma barata que el analista ya dimensionó: `authz:freeze --reason
--lease-ms` y `authz:unfreeze [--fence]` como **comandos de operador**, con `authz:reconcile`
corriendo dentro de una ventana que abre y cierra el operador (y que renueva su propio lease). El
`withFrozenWrites` interno de `reconcile` sigue existiendo para quien no use los comandos.

**Consecuencia de declararlo fuera, dicha sin adornos:** E-analista cerraría la ventana de **minutos**
(la pasada) y dejaría abierta la de **horas** (el cutover) — es decir, se pagaría una fila en la
migración publicada, un refactor de `#writeOptions` a `async` y +0,14 ms por escritura para cerrar la
parte *menos* peligrosa del problema. **En ese escenario B gana limpiamente y mi recomendación
cambia a B**, con el README diciendo en el mismo párrafo que la ventana no termina con la pasada.
Esto no es un matiz: es la condición nº 2.

### 3 · `--dry-run` congela hoy — **defecto, se arregla en la misma tanda que el 🔴 3**

**Verificado:** `manager.ts:857` hace `return this.withFrozenWrites(...)` sin mirar `options.dryRun`.
El README (línea 611) publica `--dry-run` como *«the verifier, and it is read-only by contract…
Run it in CI or in a cron»*.

**Dictamen: se arregla, y con independencia de la decisión del freeze.**

- **Hoy** el daño está acotado: el freeze es de proceso, así que un `--dry-run` en un job de CI
  congela su propio proceso y nada más. Es un defecto latente, no un incidente.
- **El día que el freeze sea durable** (E, o C), ese mismo código convierte un job de CI apuntado a
  producción en un **outage global de escrituras** durante lo que tarde el volcado del destino
  entero — minutos, por §2.1. El auditor tiene razón: es gratis y hay que hacerlo.
- **Es gratis en el sentido literal**: `--dry-run` no escribe, así que no tiene nada que proteger.
  El único contraargumento posible —que congelar estabiliza sus números— no se sostiene: los números
  de un verificador read-only no son una garantía de nada, y el precio es un mecanismo de
  indisponibilidad global disparado por un cron.
- **Caso que lo fija:** con `dryRun: true`, un `grant` concurrente **entra**; con `dryRun: false`,
  503 `E_AUTHZ_FROZEN`. Mutante que muere: `withFrozenWrites` incondicional.

---

## Conflictos entre panelistas, resueltos

**C1 · «A es cara y difícil de probar» (coordinador, y el analista al enunciar A) vs. el tester.**
→ **El tester tiene razón, y la medida es suya.** El caso multiproceso A2 existe, es determinista
(el padre congela, el hijo arranca después: sin `sleep`, sin carrera), reusa un patrón que **ya está
en el repo** (`tests/expiry_timezone.spec.ts` + `helpers/expiry_child.ts`), el helper son ~50 líneas
y cuesta **1 s**. Y mata el mutante `modulo` —un freeze que se vende como compartido y es de
proceso, o sea *el defecto exacto que A viene a arreglar*— que **ningún otro caso mata**.
→ **Con el matiz que el propio tester midió y que nadie puede ignorar:** A2 **no corre en `npm test`**
(SQLite `:memory:`; un segundo proceso no puede abrir esa base) y ahí el mutante `modulo` queda
**verde, 3 passed**. Resolución: «A es probable» es cierto; «A es probable en la configuración por
defecto» es falso. ⇒ **Gate por motor obligatorio en CI** y una línea que lo diga.
→ Sobre «cara»: en runtime, nadie tenía razón (0,14 ms p50, +7 % sobre un `grant` de 2,0 ms en PG,
+3 % p50 en MySQL, **0 en `authorize`**). En **mantenimiento** el tester tiene razón otra vez y con
cicatriz: un freeze que se escapa de un caso envenena todos los siguientes (le pasó: A3 mató a A4).
⇒ limpieza explícita en el teardown de cada grupo; `cleanAuthzTables()` no toca `authz_freeze`.

**C2 · «+0,016 ms colgándose de la consulta que ya existe» (analista §4.1, y así lo recoge el
enunciado del panel) vs. el auditor («ojo con `catalogRevalidate: { everyMs }`: sería una ventana
acotada de freeze que todavía no aplica»).**
→ **No es contradicción: los dos llegan al mismo sitio, y el enunciado del panel se quedó con el
número equivocado.** El analista ya lo escribe en §1.2: la consulta la hace el `CatalogCache`
**dentro del driver**, y `#assertNotFrozen` vive en el manager **antes de validar identidad**
(comportamiento publicado). Aprovechar esa consulta exige o bajar el chequeo al driver o aceptar un
freeze **de una escritura de retraso**. Ninguna vale. Y con `{ everyMs }` la fila **ni se lee**
(medido: `grant` pasa de 4 SQL a 3).
→ **Resolución con número:** la colocación correcta es la fila `id=2` de `authz_catalog_version`
(no `id=1`: con `FOR UPDATE` sostenido, la renovación en `id=1` esperó **816 ms (PG) / 805 ms
(MySQL)** y habría hecho caducar el lease; en `id=2`, **10 ms / 12 ms**). Pero la **consulta es
propia y sin memo**, así que **el número que se publica y se defiende es +0,14 ms p50 (PG) / +0,11
(MySQL), no +0,016**. Que quede escrito así en el diseño.

**C3 · Auditor: «A es un fail-closed de flota; un `SIGKILL` la deja sin escribir hasta que un humano
borre la fila» vs. analista: «vuelve sola en 2 527 ms».**
→ **Los dos tienen razón sobre objetos distintos y hay que decirlo así**: el auditor sobre **A a
secas** y sobre el **TTL fijo** (y ahí su crítica es correcta y el analista la suscribe: no hay valor
bueno de TTL porque duración de la pasada y tolerancia a la parada son magnitudes independientes);
el analista sobre **el lease renovado**, que es otra cosa y está medido en **dos procesos reales**.
E-analista no es «A con un parche»: es la única variante en la que el modo de fallo del auditor está
acotado por construcción.

**C4 · Auditor 🟠 6.3: «el renovador corre en el mismo event loop que el volcado de 1 M tuplas; una
pausa de GC se come la renovación ⇒ freeze caducado + migración viva = el peor de los dos mundos»
vs. analista §2.4.**
→ **El auditor tiene razón en el mecanismo, y quien lo midió fue el analista** (`m11_fence.ts`:
lease 400 ms, 1 200 ms de bucle bloqueado ⇒ `until_ms - now = -813 ms`, «un worker HTTP ya puede
escribir: true»). Nadie lo refuta.
→ **Resolución, y es condicional:** el ataque queda neutralizado **si y solo si el fence se publica**
—renovación condicional `WHERE fence = ? AND until_ms > now`, `report.frozen.lapsed`, y `lapsed=true`
⇒ la pasada **no se certifica** y el comando sale ≠ 0—. **Sin esa línea en el reporte, el auditor
gana el punto y E-analista es A con más piezas.** Es la misma jugada que el paquete ya hace con
`drift.deadRelay`, `report.factsFrom` y el censo: no prometer lo imposible, medirlo y decirlo.
Carga de la prueba: quien implemente E debe traer el caso «el lease caducó ⇒ `lapsed=true` ⇒ exit ≠ 0»,
con reloj inyectado y sin `sleep`.

**C5 · Analista §3.1 (agujero 4, el cutover) vs. auditor §2 (el agujero de las cuatro).**
→ **No hay conflicto: hay convergencia independiente**, y por eso lo he metido en el alcance (§2 de
los innegociables) en vez de dejarlo como nota.

**C6 · Tester: «B no toca ningún invariante; `CLAUDE.md:498` ya dice la verdad» vs. A/E, que sí lo
tocan.**
→ **Verificado y correcto**: `CLAUDE.md` dice literalmente *«el estado vive en el manager RAÍZ, así
que alcanza a las vistas de `forRequest()`»* — la descripción exacta del alcance real. **La frase
falsa vive solo en el README:615.** Consecuencia contable para E: hay que **reescribir esa línea de
`CLAUDE.md`**, que es un invariante documentado. Coste pequeño, pero se anota y no se descubre a
mitad del lote.

**C7 · Analista ❓1: «¿es invariante declarado que `authz_*` esté compartida entre el comando ace y
los workers?» — lo resuelvo yo, y quita una de sus tres condiciones de cambio de opinión.**
→ **Sí, es invariante declarado.** `CLAUDE.md`, invariante 14: *«El catálogo que decide es el de la
BD (versión compartida)… El memo la contrasta antes de servir… Un sync en otro proceso se ve en la
siguiente pregunta de todos»*. Si el comando y los workers no compartieran esa base, **el invariante
14 ya sería falso hoy**, con `--to=openfga` y con `database`. Y la fila `id=2` cuelga literalmente
de la fila que ese invariante nombra. ⇒ **No hace falta preguntárselo al dueño.**

---

## Afirmaciones descartadas por falta de evidencia

- **Coordinador (opción D): «segunda pasada que escribe cero ⇒ nadie escribió durante la primera».**
  No es que falte evidencia: **hay evidencia en contra, triple e independiente** (analista `m5`;
  auditor D1.a/D1.c/D2.b en PG y MySQL; tester D1/D5). Descartada como garantía, definitivamente.
- **Coordinador (D, variante `skipped`): «`clean` ya lo cubriría».** Descartada con medida: el
  analista muestra `skipped={"expired":1}` en **tres pasadas seguidas sin que nadie escriba**
  (`m12`) — ruido estacionario; y el auditor añade `unknown-scope`/`unknown-role` en la misma
  categoría. Una señal que en un despliegue vivo está roja casi siempre no es una señal.
- **E-auditor: «el único trozo de estado nuevo que E necesita es un tombstone de revoke, y es
  barato».** **Descartada por falta de evidencia**, y es la única pieza de todo el informe del
  auditor que no trae número: no hay medida del coste por `revoke`/`removeDeny`, ni política de
  retención, ni purga, ni el efecto de meter **una tabla nueva en el esquema publicado** (stub de
  migración, `runMigrationContract`, drivers de terceros). Enfrente, E-analista trae un prototipo
  ejecutado en dos procesos con `SIGKILL` y cinco magnitudes. No se injerta hasta que se mida.
- **E-auditor: `readChanges({ startTime })` como *garantía*.** La salida está medida y trae el
  `TUPLE_OPERATION_DELETE`, así que **la pieza es real y se injerta** — pero **como AVISO en el
  reporte, no como garantía**: nadie midió la **retención del changelog** de OpenFGA, la
  granularidad de `startTime`, ni su comportamiento sobre un store al tope declarado. Publicar
  «si el testigo sale vacío, la pasada fue limpia» antes de medir esas tres cosas sería exactamente
  la clase de promesa optimista que este panel existe para cortar.
- **Auditor 🟠 6.2: «~40 s de verificación y ~3,5 min de migración» / analista §2.1: «≈136 s».**
  Las dos son **extrapolaciones lineales** desde muestras pequeñas (820 tuplas / 200 y 1 000 hechos)
  al tope declarado de 1 000 000. Nadie ha corrido una pasada a escala. Se aceptan como **orden de
  magnitud (minutos, no segundos)** —que es lo que hace falta para tumbar el TTL fijo y para
  corregir el README— y **no** como cifra publicable. Marcadas 🟡.
- **Tester: «el refactor no rompe nada: 587 passed, 1 failed».** Medido, pero **solo en SQLite
  `:memory:`**. No hay corrida de la suite completa con el refactor en PG, MySQL ni con OpenFGA real.
  ❓ Condición de implementación, no motivo para descartar.
- **Analista: «el `setInterval` va `unref()`» y «~60 líneas».** 🟡 prototipado, no medido en el
  paquete. Trivial, pero no cuenta como coste verificado.
- **Auditor 🟠 6.4: «cualquier código de aplicación con la vista en la mano, en JS o con un `as any`,
  congela el motor entero».** Cierto y medido (A1.4), pero **no cambia el veredicto**: el paquete ya
  documenta `manager.driver()` como «la salida explícita de las barreras» y la superficie es la
  misma que hoy. Se anota como riesgo residual, no como hallazgo que decida.

---

## Riesgos que quedan aunque se implemente la ganadora

1. **La ventana barrera↔escritura no se cierra jamás** (tester A4): entre el `SELECT` del freeze y la
   escritura hay un hueco, y cerrarlo exigiría atomicidad entre una fila SQL y un `Write` a OpenFGA.
   **Imposible.** Por eso la frase publicada es «otro proceso recibe 503» y nunca «ninguna escritura
   entra en la ventana». Este riesgo no se mitiga: se escribe.
2. **El catálogo, `manager.driver()` y el árbol del consumidor siguen escribiendo con el motor
   congelado** (auditor 🟠 5, medido: `syncAuthzCatalog` cambió el catálogo y `authorize` pasó de
   `true` a `false` con el freeze puesto). Se enumeran por su nombre en el README. En `--to=openfga`
   la pasada copia **también** la proyección del catálogo, leída con una foto distinta de la de los
   hechos: un sync a mitad deja el destino mezclando dos versiones.
3. **La garantía no es observable en `npm test`** (SQLite `:memory:`), que es lo que se corre por
   defecto: el mutante `modulo` queda verde ahí. Mitigado con gate por motor en CI, **no eliminado**.
4. **Promesa global, verificación local** (tester §5): el freeze es del **manager**, la suite
   publicada juzga **drivers**, y `MigrationContractHarness` no tiene manager, ni segundo escritor,
   ni segundo proceso, ni forma de exigir un motor. Un tercero leerá la promesa y correrá un contrato
   que **nunca** la comprueba. Es la misma forma que el hallazgo original. **Se declara en el README
   con esas palabras**: la garantía es del manager de este paquete, no la hereda ni la verifica un
   driver de terceros.
5. **`scopes.detached` durante el freeze** (auditor 🟡 7): en el orden soportado «la fila ya no
   existe», el 503 convierte un rechazo en **divergencia permanente** (hechos huérfanos que
   resucitan con el uuid) y no hay quien reintente: la outbox es del árbol, no de los hechos.
   Acotado a la duración de la ventana; hay que decidir si el operador drena antes de congelar.
6. **El relay no drena con el freeze puesto** (auditor 🟡 9): la ventana de «árbol viejo» **crece**
   con la duración del freeze, y `drift.pendingRelay` reporta una cola que no puede drenarse.
   Informativo, no accionable, durante la ventana.
7. **El origen que es un STORE sigue sin foto consistente** (§1 de los innegociables): el arreglo del
   🔴 3 cubre una dirección; la otra queda **instrumentada** (`readChanges`), no cerrada.
8. **Dos `authz:reconcile` simultáneos**: hoy no se excluyen (A1.3 medido) y con la fila compartida
   el primero que termina levantaría la barrera del otro. Lo cierra el token/fence — que por eso es
   injerto obligatorio y no opcional.

---

## §6 · La pregunta de negocio (la formulo; la contesta el dueño)

> **Con `authz:reconcile` en curso y un freeze durable con lease renovado de `L` segundos: si el
> proceso de la migración muere sin ejecutar su `finally` (`SIGKILL`, OOM del contenedor, evicción
> del pod), toda ESCRITURA del motor —`grant`, `deny`, `revoke`, `removeDeny`, los tres `scopes.*` y
> la API de delegación— responde 503 `E_AUTHZ_FROZEN` **reintentable** durante como mucho `L`
> segundos (medido: 2 527 ms con `L` = 3 000; el default propuesto es `L` = 15 s con renovación cada
> 5 s), y `authorize` NO se ve afectado en ningún momento —las lecturas nunca se congelan—.
> **¿Es ese coste peor que el estado de hoy, en el que un `revoke` aceptado con 200 durante la pasada
> no llega al destino, el reporte dice `clean=true`, y tras el cutover el usuario conserva
> permanentemente el permiso que se le retiró?**

| Respuesta del dueño | Gana | Qué se implementa |
|---|---|---|
| **«Peor la parada de 15 s»** | **B** (83/100) | El bloque común completo (abajo) + `freeze()` se **renombra** a `freezeThisProcess()`. El analista tiene razón: una API llamada `freeze()` que congela un solo worker es la misma promesa incumplida, en otro sitio |
| **«Peor el `revoke` perdido»** | **B + E-analista** (79/100) | El bloque común + la fila `id=2`, el lease renovado, el fence publicado y los comandos `authz:freeze`/`authz:unfreeze` |
| **Si no contesta** | **B + E-analista** | Motivo abajo |

**Por qué el default es B + E-analista, y no es una preferencia mía:**

1. **Precedente firmado que no re-litigo.** Decisión del dueño del 2026-08-31 (2), al aceptar (c2r):
   *«conceder de menos durante segundos es un problema de disponibilidad, no de seguridad, y esa
   asimetría es la que manda aquí»*. Aquí la asimetría es **idéntica**: `L` segundos de 503
   reintentable en escrituras administrativas frente a un fail-open permanente e invisible. La
   respuesta ya está dada en otro expediente del mismo paquete.
2. **Lo que la parada NO toca es lo que COGNITIV compró.** El motivo de toda la fase es un PDP que
   decide sin la BD de la aplicación; `authorize` no se congela ni un milisegundo, y el coste de A/E
   en el camino de lectura es **cero, medido**. Lo que se aplaza son `grant`/`revoke` administrativos.
3. **Calendario, y esto caduca.** Las dos ramas son breaking: B renombra una API pública, E añade una
   fila a la migración publicada. Hoy `2.0.0` no está publicado (`2.0.0-alpha.1` en el árbol) y
   **las dos son gratis**. Después, añadir el freeze durable es migración de esquema publicada +
   cambio de comportamiento observable = **major**. Entre dos opciones defendibles, se elige ahora la
   que no se puede añadir barata después.

---

## Plan de ejecución, en orden

**Lote 1 — se hace pase lo que pase, y bloquea el merge de 3b a `main`:**

1. **🔴 3**: los dos barridos de `readSourceFacts` en una transacción de lectura repetible. Caso: el
   escenario `d3_mitad_de_transaccion.ts` del auditor, ya ejecutable, con el destino devolviendo
   `docs:write = false`.
2. **`--dry-run` no congela** (`manager.ts:857`). Caso: `dryRun: true` ⇒ el `grant` concurrente entra;
   `dryRun: false` ⇒ 503.
3. **B completa**: README:615 reescrito (la frase falsa fuera, con `assert.notInclude` al estilo de
   `scope_outbox.spec.ts:1800`), «*window of seconds*» corregido a la medida, la ventana del
   **cutover** nombrada, el escenario del hallazgo convertido en **caso que fija el comportamiento**
   (lo mejor de B, según el tester), y la bandera de reconocimiento **solo para la pasada que
   escribe** —nunca para `--dry-run`, o el verificador deja de correrse— exigiendo repetir a mano el
   driver destino (patrón `--allow-mass-delete`).
4. La **línea de reporte de la 2.ª pasada**, con la frase del tester y sin la conclusión de D.
5. **`CLAUDE.md`** coherente (invariante del alcance del freeze) y **CHANGELOG** con el *porqué*.

**Lote 2 — E-analista, condicionado a §6 y a la condición 2:** fila `id=2` de
`authz_catalog_version` (`reason`, `until_ms`, `holder`, `fence`), `freeze(reason, { leaseMs })` con
token y renovación condicional `unref()`, `#assertNotFrozen` sin memo, `unfreeze(token)`,
`report.frozen: { durable, lapsed, leaseMs, fence }` con `lapsed=true` ⇒ exit ≠ 0, los comandos
`authz:freeze`/`authz:unfreeze`, el testigo `readChanges({startTime})` como aviso en la dirección
cuyo origen es el store, y **cinco casos**: congela-a-otro-proceso (gateado a pg/mysql/sqlite-file,
con la nota de CI), recupera-tras-`SIGKILL`-en-≤`leaseMs`, `lapsed=true`-cuando-el-lease-caducó,
`unfreeze` ajeno no levanta el mío, y `--dry-run` no congela. Teardown explícito de la fila de freeze
en cada grupo.

---

## Lo que preguntaría al humano antes de implementar

Solo dos cosas, y las dos cambian la decisión:

1. **La pregunta de §6**, tal como está formulada. Si no llega respuesta, se procede con B +
   E-analista por el precedente del 2026-08-31 (2).
2. **¿El cutover entra en el alcance de esta tanda** (comandos `authz:freeze`/`authz:unfreeze`)**?**
   Es un «sí» o un «no» de alcance, no de arquitectura. **Si es «no», la recomendación pasa a B
   sola** y el lote 2 no se escribe.

Lo que **no** hace falta preguntar y el panel dejó abierto: si `authz_*` compartida entre el comando
y los workers es invariante declarado. **Lo es** (`CLAUDE.md`, invariante 14) — resuelto en C7.
