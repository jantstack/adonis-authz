# Decisiones del dueño del paquete — 28-08-2026

Respuestas de José a las tres preguntas del juez (`panel-2026-08-28-juez.md`) y consecuencias.

## 1. ¿Segundo consumidor? → **SÍ, puede haber más consumidores reales**

> "Por eso es el momento de corregir y hacer todos los cambios necesarios, antes de que haya más dependencias."

Consecuencias:
- `http/` (F) **entra** al paquete (deja de ser ➡️ consumidor). Nace sin aceptar `role`.
- `relations/` se diseña contra **dos casos**: llaves de COGNITIV + "compartir documento estilo Drive" (`document` + `viewer/editor/owner` + `group#member`).
- **Hoy no hay consumidores ⇒ romper es gratis.** Fases 0+1 se publican como **2.0.0**, no como 1.2 con flags. Sin `flatScopeFallback`, sin `requireWithin=false`, sin deprecaciones. Luego `catalog/` = 2.1, `relations/` = 2.2.
- III.6.2 queda contestada: **sí puede ser breaking**.

## 2. Binding id FGA por uuid de rol → **profundizar; quiere eficiencia en ambos drivers**

Recomendación dada (ver conversación): **sí, hacerlo en 2.0 sin comando de migración** (no hay stores en producción).
- `role_binding:<scopeKey>|<roleUuid>`, parseo desde la derecha. Elimina `encodeSlug`/`decodeSlug` (no inyectivo, exploit L0.8a) y la ambigüedad de `parseBindingId`.
- El driver `database` ya trabaja por `role_uuid`: no cambia.
- `rolesGranting(permissionUuid, chain)` filtra por `owner_scope_key IN chain OR 'global'` ⇒ mismo número de checks que hoy con roles por tenant.
- **Eficiencia**: memo del catálogo (`permissionSlug → {uuid, rolesByScopeType}`) invalidado en `syncAuthzCatalog` — quita 2 SQL por `authorize` en ambos drivers; nunca cachear decisiones. Fusionar los dos `batchCheck` (denies + roles) en uno. Corregir N7 (correlación por `correlation_id`) antes de `authorizeMany`.
- **Rechazado**: meter rol→permiso en el modelo FGA (rompe "catálogo local siempre", sin equivalente en `database`).

## 3. Retirar `appAccess({ role })` → **pidió recomendación**

Recomendación dada: **retirar en 2.0 sin escape**.
- Tipo solo acepta `{ permission }`; `role` ⇒ error TS + throw 500 con mensaje de migración.
- `hasRole` se queda como consulta de membresía, con caso de contrato que fija que el deny no lo afecta. No hacerlo "deny-aware".
- Receta en CHANGELOG: crear permiso, vincularlo al rol, usar `{ permission }`.
- Sobrecarga `hasRole(s, { slug, scopeType }, scope)` (hoy filtra solo por slug: bug medido).
- Regla nueva para `CLAUDE.md`: ningún PEP del paquete acepta `role`; toda decisión pasa por `authorize`.

## Pendiente de confirmación del dueño
- [ ] ¿OK a publicar Fases 0+1 como 2.0.0?
- [ ] ¿OK al binding id por uuid sin comando de migración?
- [ ] ¿OK a retirar `appAccess({ role })` sin escape?

## Panel 2 (modo `facts`) — veredicto del juez, 28-08-2026
Ver `panel2-2026-08-28-juez.md`. **Posible con cambios**: modelo (c2) del analista + 8 mitigaciones; 10,5 d en Fase 3b (2.2), tras `catalog/`.
`facts` es **22 % más lento** que resolver+batch único en topología de 3 niveles (4,59 vs 3,76 ms). Motivo real: PDP que no toca la BD de la app.
Recomendación: hacer hoy la opción C (contrato + resolver optimizado, 2,5 d); `facts` condicionado a:
- [ ] ¿Reescribir la regla "el catálogo es local siempre" (proyección derivada en FGA)? Si no ⇒ facts se rechaza.
- [ ] ¿COGNITIV exige PDP que decida sin la BD de la app? Si no ⇒ facts no vale la pena.
- [ ] Nº de permisos previsto (techo ~720 por 262 KB de modelo).
- [ ] Profundidad máxima real del árbol (≤8 ⇒ facts nunca gana; ~23 techo de FGA).
- [ ] ¿Acepta outbox en su BD + verify --full en cron?

## DECISIÓN FINAL (28-08-2026, tarde) — el dueño confirma ir por lo recomendado
Requisito real: **simetría** — todo en un driver o todo en otro, migración idempotente y bidireccional.
- ✅ Regla del catálogo reescrita: propiedad local siempre; un driver PUEDE mantener proyección derivada (reconstruible por comando, vigilada por reconcile --dry-run, nunca leída como catálogo).
- ✅ Driver `openfga` = **solo modo `facts`** (se elimina `resolver`). Dos configuraciones, no tres.
- ✅ Modelo FGA = variante (c2) del analista (catálogo por wildcard de usuario en `role`, `role_binding:<scopeKey>|<roleUuid>`, `scope#parent`, `can_P = P but not denied_P`).
- ✅ `scopes.attached/moved/detached` **obligatorio** en ambos drivers desde 2.0; `purgeScope` en el puerto.
- ✅ Las 8 mitigaciones del juez (panel2): anti-ciclos en el paquete, `moved` = Read + 1 Write atómico, outbox opcional + gate de construcción, detached hechos-primero, validación nombres/longitudes/reservados/familias, HIGHER_CONSISTENCY por defecto, import sin `Ignore`, context siempre.
- ✅ `authz:reconcile --to=openfga|database [--dry-run]` como ÚNICA primitiva de migración/verificación. Idempotente, reanudable, nunca silenciosa.
- ✅ Las tres pendientes anteriores quedan confirmadas: 2.0.0 breaking; binding id por uuid sin comando de migración; retirar `appAccess({role})`.
- Orden: Fase 0 → Fase 1 (L0) → Fase 2 (primitivas) → Fase 3 `catalog/` → Fase 3b `facts` + reconcile → Fase 4 `relations/` → Fase 5 consolidación.
- Garantías exigidas: cada pieza con su test rojo→verde; suite completa verde (SQLite + OpenFGA); revisión de tester-contrato y auditor-seguridad sobre el diff antes de cerrar cada fase.

---

## Decisión del 2026-08-30 · La visibilidad del rol local en modo `facts` (bloqueaba 3b-2e)

**Problema medido** (hallazgo 2 del informe del lote 3b-2c): en `facts`, `authorize` no vuelve a decidir la visibilidad de un rol **local** con el árbol de hoy, porque el modelo (c2) no tiene `owner`. Consecuencia: mover una unit fuera de la organización dueña de un rol local **dejaría de retirar lo concedido**, y el invariante 18 («se retira al instante y sin escribir») deja de ser cierto en este driver. Hoy es inalcanzable —sin `purgeRole` no hay `defineScopedRole` en `openfga`— pero **3b-2e lo abre**.

**Opciones puestas al dueño y elegida: (1) barrer en `moved`.**

| # | Opción | Veredicto |
|---|---|---|
| **1** | **Barrer en `moved`**: al mover un subárbol, el paquete borra las aristas `scope#binding` de los roles **locales** cuyo owner ya no es ancestro del scope. | **ELEGIDA.** El resultado observable vuelve a coincidir entre los dos drivers, que es el motivo de toda la fase. Precio aceptado: deja de ser «sin escribir» y hereda el lag del relay, ya aceptado como 🟠 en el cruce 4. |
| 2 | Declararlo como divergencia (`localRoleOwnerRevocation: false` + caso negativo + `reconcile` lo reporta). | Descartada: honesta y barata, pero rompe la simetría entre drivers, que es justo lo que se está construyendo. |
| 3 | Meter `owner` en el modelo (c2). | Descartada: (c2) no puede expresar «el scope donde cuelga el binding desciende del owner» sin otro salto TTU, y el techo de profundidad (~23) **no está medido sobre (c2)**. |

**Consecuencias obligatorias para 3b-2e**, todas con caso:
1. `scopes.moved` en `facts` barre las aristas `scope#binding` de roles locales cuyo owner deja de ser ancestro — **y solo esas**: un rol **global** no se toca, y un rol local cuyo owner sigue siendo ancestro tampoco.
2. El barrido es **por subárbol movido**, no solo por el nodo: los descendientes del nodo movido también cambian de cadena.
3. Caso de paridad explícito **entre drivers**: el mismo `moved` en `database` y en `facts` ⇒ **la misma respuesta** de `authorize`. Esa igualdad es el criterio de aceptación, no el detalle de implementación.
4. La ventana del relay se documenta como fail-open temporal **con esas palabras** (misma regla que 2d), y `authz:reconcile` (3b-3) la reporta como drift.
5. El invariante 18 se reescribe: «se retira al instante y sin escribir» pasa a «se retira; en `database` sin escribir, en `facts` con una escritura que el relay aplica — y `reconcile` la reconcilia si el relay se perdió».

---

## Decisión del 2026-08-30 (2) · R1 y R2, las dos raíces que dejan rojo al juez contra `facts`

Contexto: el lote 3b-2e puso el juez a correr contra el modo `facts` y dejó rojos que **no son fallos del harness sino divergencias reales entre drivers** (`fase-3b-lote-2e-informe.md`). R3 se cerró en el lote 2f. Quedan R1 y R2. El dueño delegó la decisión en el coordinador («como recomiendes»), sobre estas dos recomendaciones:

### R1 · (c2) no conoce el NIVEL del rol ⇒ **SE ARREGLA**

Cambiar el `scope_type` de un rol retira lo concedido donde ya no aplica en `database`, y en `facts` seguiría concediendo. Es una divergencia de comportamiento **sin justificación**: no compra nada a cambio. Se cierra con el **mismo mecanismo aprobado el 30-08 para el owner** (barrer aristas `scope#binding`), asumiendo su consecuencia conceptual, que se documenta: la arista `scope#binding` pasa a significar **«el rol es visible aquí»** y no «esta asignación existe». Criterio de aceptación: el mismo **caso de paridad entre drivers**, no el detalle de implementación.

### R2 · El árbol del store decide sin la cadena del consumidor ⇒ **SE DECLARA como capacidad, con caso negativo**

Tres consecuencias medidas: (a) un scope cuya cadena está rota sigue concediendo por su propio binding; (b) un resolutor caído ya no hace lanzar a `authorize`; (c) un alias del uuid no encuentra sus hechos (fail-**closed**, pero rompe la igualdad).

**No se cierra**, y el motivo es que (b) **es** la propiedad que el dueño compró: «`authorize` sobrevive a la caída de la BD del consumidor y no la toca por request» (cruce 2 del panel 2, motivo (a); PDP autónomo para COGNITIV). Cerrar R2 sería volver a meter `resolveChain` en el camino caliente de `authorize`, es decir, deshacer la fase entera. Se declara con capacidad + **caso negativo por cada una de las tres consecuencias** (nunca un skip), va al README con esas palabras, y `authz:reconcile` (3b-3) reporta (a) como drift.

**Condición que el coordinador se impone:** antes de escribir la divergencia en el README, el **auditor de seguridad** intenta romperla — si encuentra que (a) o (c) son explotables más allá de lo descrito, R2 se reabre y deja de ser una declaración.

---

## CORRECCIÓN del 2026-08-31 · R2 **NO se declara: se arregla**

La decisión de arriba («R2 se declara como capacidad») se tomó con la condición explícita de que el auditor intentara romperla antes de escribirla en el README. **La rompió.** Informe: `fase-3b-auditor-r2.md` (899 líneas, siete reproducciones ejecutables contra el `:8101` con el driver `database` corriendo en paralelo sobre el mismo catálogo y el mismo árbol).

**Por qué la recomendación era errónea, en una frase:** describí la consecuencia (a) como *conservación* («un scope huérfano sigue concediendo lo que ya concedía») y lo medido es *adquisición* — un `false` se vuelve `true`, y quien lo consigue está **al otro lado de la barrera `within`** que el paquete vende como frontera multi-tenant. Eso no es una divergencia declarable: es una escalada.

| # | Hallazgo | Estado |
|---|---|---|
| **🔴 1** | `scopes.detached` de un nodo intermedio = `removeDeny` masivo. Con `app ← orgA (deny) ← D ← U`: `removeDeny(A)` 422 y `grant(A)` 422 (las barreras funcionan), pero `detached(D, {within: D})` **OK** ⇒ `authorize` pasa a `facts=true` / `database=false`. El deny sigue escrito; se rompió el camino por el que se heredaba. | **Cambio de modelo.** Un scope cuya cadena no llega a la raíz debe **dejar de conceder** en `facts`, como en `database`. Se diseña antes de implementar. |
| **🔴 2** | El «fail-open temporal de segundos» del relay es **permanente** y lo pone cualquier tenant: `attached(C,P)` encolado + borrar `P` antes del relevo ⇒ 422 al relevar ⇒ `relayScopeChanges` para en el primer fallo (`manager.ts:579`) y `pending()` devuelve siempre esa fila primero (`scope_outbox.ts:165`). Sin skip, sin dead-letter, sin tope de `attempts`. Falsea la frase del README del 2d. | **Bug con arreglo conocido.** Lote 3b-2h. |
| **🟠 3** | El alias del uuid es fail-**OPEN** en ESCRITURA (en lectura sí es fail-closed, que es lo que decía (c)): con la fila ya borrada —el orden soportado de `detached`— `canonicalScope` no tiene con qué canonizar y usa la ortografía del llamante ⇒ `purgeScope` **demuestra cero sobre un objeto que no existe** y devuelve OK, el scope real conserva `parent` y `binding`, y `authorize` dice `true` para siempre. | **Bug con arreglo conocido.** Lote 3b-2h. |
| **🟠 4** | Dos escritores del árbol ⇒ nodo con **dos padres** ⇒ cruce de tenants (un `org-admin` de B con `docs:write` sobre una unit de A), irreparable con `moved` (500 drift) y sobrevive a `purgeScope`. La consecuencia está medida; el disparador (dos relays concurrentes: `pending()` sin lease, lote de 100 sin releer) **no** se reprodujo de punta a punta. | Lote 3b-2h, junto con el lease del relay. |
| **🟡 5** | Con el resolutor caído, `facts` concede y **no se puede revocar**: `authorize=true` mientras `revoke`/`deny`/`purgeScope`/`list*` son 503. | Amplía la redacción de (b); no la reabre. |

**(b) sigue en pie y no se discute**: que `authorize` sobreviva a la caída de la BD del consumidor **es** la propiedad que el dueño compró (cruce 2 del panel 2, PDP autónomo para COGNITIV). Lo que cae es la idea de que (a) y (c) fueran su precio inevitable: no lo son.

**Lo que NO se rompió** (información, no hueco): escribir sobre scopes desconocidos (422), inventar nodos en el store (`grant` sigue 422), aristas ilegales y ciclos (422 en manager y driver), el alias con la fila viva, `purgeScope` con cadena rota e identidad canónica, la inyectividad de `holderTypes`.

---

## Decisión del 2026-08-31 (2) · El arreglo del 🔴 1 = modelo **(c2r)**, y el lag del relay pasa a fail-CLOSED

Diseño medido en `fase-3b-diseno-r1.md` (735 líneas, contra el `:8101`). **No hay conflicto entre la propiedad central de la fase y la seguridad del modelo**, que era el riesgo que se temía: el arreglo cabe en **una relación más**.

```
type scope
  define rooted: [user:*, admin:*, integration:*] or rooted from parent   # NUEVO
  define can_<P>: (<P> but not denied_<P>) and rooted                     # CAMBIA
```
Más **una tupla en todo el store** (`scope:app#rooted@<holder>:*` por holder type). **Cero tuplas por scope**: la outbox y el relay no llevan entradas nuevas.

| Criterio | Medido |
|---|---|
| Cierra el escenario del auditor | ✅ `facts=false` = `database=false`, paridad (el deny sigue escrito) |
| **`Check` único** (cruce 6, promesa central) | ✅ intacto: `{check:1, batchCheck:0}`, `resolveChain` 0, sin tocar `factsAuthorize` |
| Coste | +0,13 ms p50 a 3 saltos (ruido); +0,27–0,41 a 20 |
| **Techo de profundidad** | ✅ **no se mueve**: 22 sólido / 23 probabilístico / 24 nunca, en las 5 variantes |
| Techo de tamaño | 721 → **691** permisos (−4,2 %); `factsModelBytes` sigue con delta 0 |
| Qué se rompe | 4 casos de 667. **Ninguno del juez** (suite entera corrida con el modelo cambiado) |

**Alternativas descartadas con el dato que las tumba:** `flat` (cuesta 83 permisos más de techo, y su única ventaja —ser DSL legal— la tiene también la anidada, verificado con `@openfga/syntax-transformer`); `matRooted` (obliga a `detached` a desmarcar el subárbol: **es el bug que se arregla, movido de sitio**); segundo `Check` (no la tumba la latencia sino el cruce 6: `singleCheckAuthorize` dejaría de ser cierto y `authorizeMany` pasaría a 2N items); lápidas en `detached` (solo cubre ese camino; un scope nunca notificado seguiría concediendo, medido).

### La decisión que traía el diseño, tomada por el coordinador

Con (c2r), **durante el lag del relay un scope recién creado deja de conceder** (`facts=false` / `database=true`): el fail-open del lag **cambia de signo a fail-CLOSED**.

**Se acepta, y es lo correcto.** Un paquete de autorización que concede de más en una ventana es exactamente el defecto que los lotes 2d y 2h acaban de perseguir; conceder de menos durante segundos es un problema de disponibilidad, no de seguridad, y esa asimetría es la que manda aquí. Además la ventana es **cero sin outbox** (verificado en `manager.ts`) y casi cero drenando la cola tras el commit.

**Consecuencias obligatorias:** el README dice hoy lo contrario y hay que reescribirlo — el lag pasa a describirse como *«un scope recién creado puede tardar N segundos en conceder»*, con la receta de drenar la cola tras el commit; y va al CHANGELOG como **breaking** de comportamiento observable.

---

## Decisión del 2026-08-31 (3) · `stillGranting` pasa al puerto (breaking para drivers de terceros)

**Problema** (destapado por el lote 2i, existente desde 3b-0b): `pruneOrphanRoles().stillGranting` se calcula contando `authz_assignments`, así que con el driver `openfga` en modo `facts` —donde los hechos no viven en esa tabla— es **siempre `false`**. Su contrato publicado dice *«falso ⇒ este rol seguro que no concede»*, y se lee **justo antes de un borrado destructivo**: hoy el barrido de huérfanos declara seguro borrar un rol que puede estar concediendo.

**Opciones puestas al dueño y elegida: (1) método nuevo en el puerto.**

| # | Opción | Veredicto |
|---|---|---|
| **1** | **`stillGranting` se le pregunta al driver** (método nuevo en `AuthorizationDriver`). | **ELEGIDA.** Es la única que hace el campo verdadero en los dos drivers. Precio aceptado: **breaking del puerto**, con su capacidad y su caso — y el público afectado es justo el de la suite de contrato publicada, así que la suite tiene que cubrirlo. |
| 2 | Quitar el campo. | Descartada: más barata y también honesta, pero pierde el aviso que el 3b-0b metió para que una purga no se llevara roles vivos. |
| 3 | Devolver `undefined` en `openfga`. | Descartada como destino final —deja el barrido sin red en el driver donde más falta hace—, **pero es el fallback obligatorio** para un driver de terceros que no implemente el método nuevo: «no lo sé» nunca puede degradar a `false`. |

**Consecuencias obligatorias:**
1. El método es **opcional en el puerto**; un driver que no lo implemente hace que `stillGranting` sea **`undefined`**, nunca `false`. Caso negativo que lo fije.
2. `pruneOrphanRoles` **no puede tratar `undefined` como «no concede»**: con `undefined` el rol se marca como no demostrable y el comando lo lista aparte, como ya hace con los que sí conceden.
3. Capacidad declarada con caso, y entrada en la suite de contrato publicada (`src/testing/contract.ts`), que es lo que un driver de terceros usa para saber qué le exigen.
4. CHANGELOG como **breaking del puerto**.

---

## Decisión del 2026-08-31 (3b) · El `freeze()`: opción **B + E-analista** (panel 3, veredicto del juez)

Pregunta de negocio formulada por el juez y contestada por el dueño: *«¿qué es peor — ~2,5 s de 503 en escrituras administrativas tras un `SIGKILL` (`authorize` nunca se congela), o un `revoke` aceptado con 200 que no llega al destino, permanente y con `clean=true`?»* — **Respuesta del dueño: «la parada no me pesa si garantiza el trabajo»** ⇒ gana la corrección ⇒ **B + E-analista** (`panel3-juez.md`, 79/100; B sola 83 contra criterios de ingeniería puros, y el juez lo dice en voz alta — la diferencia la decide esta respuesta).

- **B entera**: el README deja de prometer lo que el código no hace; la frase de ~608 se reescribe HOY.
- **E-analista**: freeze **durable** colgado de la fila `authz_catalog_version` que toda escritura ya lee (coste medido: **+0,14 ms p50 por escritura, 0 en `authorize`** — el +0,016 del memo NO es defendible por frescura), con **lease renovado** (no TTL: tras `SIGKILL`, la app vuelve a escribir sola en ~2,5 s, medido en dos procesos) y **fence publicado** en el reporte (`lapsed=true` cuando el lease se perdió a mitad).
- **El cutover entra en alcance**: `authz:freeze` / `authz:unfreeze` de operador — el intervalo entre la última pasada y el cambio de `default` es donde ocurre la pérdida, y sin esto E pierde su sentido (condición explícita del juez).
- Descalificadas: **D** (27/100, rota por tres panelistas: el detector se certifica limpio sobre la pérdida que él mismo causa), **C** (bandera que apaga una garantía para ahorrar 0,14 ms), **A a secas** (`SIGKILL` ⇒ flota sin escribir hasta intervención humana).
- Ya cerrados aparte (lote 3b-6, independientes de esta decisión): la foto consistente del origen y `--dry-run` sin congelar.

---

## Decisión del 2026-08-31 (4) · El roadmap se completa ENTERO, con los dos drivers, sin condicionarlo a COGNITIV

Palabras del dueño: *«Lo ideal es que construyamos todo con los dos drivers y bien... sin importar si COGNITIV lo necesita o no.»*

**Lo que cambia:** la variable que gobernaba la Fase 4 («¿hay un segundo consumidor real?», anotada en RETOMAR.md y en el cruce 10 del panel 2) **queda revocada como puerta**. El paquete se construye completo por mérito propio:

- **Fase 4 · `relations/` (2.4)** se hace, con los DOS drivers al mismo nivel de exigencia que todo lo anterior (rojo→verde, mutantes, juez, tester+auditor por fase), después de cerrar y publicar la 3b.
- **Fase 5 · `http/`** y **Fase 6 · consolidación** siguen en el plan tal cual.
- La respuesta pendiente de COGNITIV (¿acceso a espacios o ReBAC de objetos?) **deja de decidir SI se construye** — pasa a ser insumo de DISEÑO: un caso de uso real de primera mano para la API de `relations/`, si llega a tiempo.

**Lo que no cambia:** el orden (primero cerrar la 3b: lote 3b-7 en curso → `/code-review` → merge a `main` → `2.3.0-alpha` a npm), el circuito de verificación, y la regla de parada.

**Matiz del dueño (mismo día):** *«COGNITIV es el primer cliente. Pero no debemos condicionarnos por ellos, debemos terminar... pero obviamente atendiendo lo que ellos quieren.»*

Operativamente:
- **El roadmap se termina entero** — el alcance no lo decide COGNITIV.
- **COGNITIV es el primer cliente y se le atiende como tal**: sus reportes de integración y bugs tienen prioridad sobre avanzar fase (un cliente bloqueado se atiende antes que una fase nueva); sus casos de uso reales alimentan el diseño (la pregunta de `relations/` sigue en pie como insumo); y las versiones se cortan pensando en que ellos integren (por eso `2.3.0-alpha` sale en cuanto cierre la 3b, sin esperar a la 4).
- Lo que NO hacen: decidir el alcance, recortar fases, ni bajar el listón de verificación.

---

## Decisión del 2026-09-01 · Publicar TODO junto al final, no la 2.3 por separado

Palabras del dueño: *«publiquemos cuando tengamos todo, porque vienen cosas más pequeñas»*, y *«ve con la siguiente fase»*.

- **No se publica la `2.3.0-alpha` ahora.** La 2.3 (facts+reconcile, en `main`) y la 2.4 (relations, en `main` salvo ⚪4) salen en UN release cuando cierren las piezas pequeñas restantes.
- **Orden de trabajo**: (1) micro-lote ⚪4 —cableado del singleton `RelationsManager` de servicio + `openfga:provision` con los tipos de relación—, que cierra la Fase 4; (2) **Fase 5 · `http/` (`resourceAccess`)**; (3) Fase 6 · consolidación; luego el release conjunto.
- Consecuencia: COGNITIV recibe el instalable más tarde, aceptado por el dueño a cambio de un release único y completo.

---

## Decisión del 2026-09-01 (2) · El reorg de módulos de la Fase 6 SE HACE ahora, con revisión

Pregunta: ¿reorganizar `src/` en carpetas de módulo (`roles/`/`relations/`/`catalog/`/`http/`) + migraciones por módulo antes del release, o diferirlo? Es cosmético (API pública sin cambios) pero toca decenas de imports internos, el grafo de `check_purity`, el mapa de `CLAUDE.md` y el stub de migración que un test fija.

**Elegido por el dueño: HACERLO AHORA, como lote propio con revisión.** Acepta el retraso del release y el riesgo, a cambio de la estructura definitiva desde la v2.0.

**Cómo se ejecuta** (decisión del coordinador sobre la forma de la revisión):
- Va DESPUÉS de la parte de docs de la Fase 6 (ambos mutan `main`; en secuencia).
- La garantía de un refactor sin cambio de comportamiento NO es mutación (no hay comportamiento nuevo que mutar): es **(a) la suite entera verde en los 5 modos** (mismo nº de casos: si baja, un fichero movido dejó de cubrir algo), **(b) `check:purity` verde** con el grafo actualizado, **(c) la superficie pública IDÉNTICA** —los exports de `index.ts` y de cada subpath byte a byte antes/después— y **(d) el mapa de código de `CLAUDE.md` actualizado**. Se captura mecánicamente el diff de exports; si no es vacío, el reorg cambió la API y está mal.
- El stub de migración y su espejo (`migration_stub.spec`) son el punto más frágil: si las migraciones se separan por módulo, el test que las fija columna a columna tiene que seguir verde.

---

## CORRECCIÓN del 2026-09-01 · R-15 (caducidad de relaciones) — se difirió sobre una SUPOSICIÓN, y COGNITIV la pide

**Lo que pasó:** el coordinador recomendó dejar R-15 fuera de la 2.4 («una relación tipo *viewer* rara vez caduca sola; si COGNITIV lo necesita, en 2.6»), el dueño aceptó por default («como recomiendes»), y el diferimiento fue al encargo del lote 4-3 como «default del dueño» **sin pasar por este registro**. Fue una decisión tomada sobre una suposición del coordinador, no sobre un dato del cliente.

**Lo que dice el dato:** COGNITIV verificó `2.4.0-alpha.1` contra sus 9 requisitos y **la caducidad en la tupla es el requisito #5** (❌ por diferida). La suposición era falsa para el primer cliente. Con el principio firmado el 2026-08-31 («COGNITIV es el primer cliente y se le atiende»), R-15 no debió diferirse sin preguntarles.

**Estado:** los dos ❌ de COGNITIV son R-15 (#5) y `{trx}` (#6). Para `{trx}` el juez dejó el gatillo explícito («si COGNITIV necesita `relate()` atómico ⇒ se adelanta para los dos puertos») y **acaba de dispararse** (su «llave + `pdp_version` en la misma trx» es ese caso). Ambos son aditivos y no rompen nada publicado.

**Decisión del dueño (2026-09-01, «SÍ, ARRANCA CON ESO»):** se adelantan R-15 y `{trx}` como **`2.4.0-alpha.2`**, para que COGNITIV verifique 9/9. R-15 se implementa directo (ya especificado por el juez de la Fase 4); `{trx}` pasa primero por panel (analista + auditor + juez) sobre la cuestión de la outbox en `openfga` —una tupla no entra en una trx SQL— y va en LOS DOS puertos (roles y relations).

**Corrección del dueño (2026-09-01, panel `{trx}`):** *«No te tienes que basar en el código de COGNITIV. Tiene que funcionar ya sea si el cliente quiere usar un driver o el otro, y que él sea el que ajuste según lo quiera manejar.»*

- El analista del panel usó «COGNITIV despliega `database`» como criterio. **Se retira como criterio**: es un dato del cliente, no del paquete. Reafirma el principio ya firmado (no acoplarse a ningún consumidor; COGNITIV atiende, no decide alcance).
- La decisión de `{trx}` se sostiene POR SÍ MISMA para los dos drivers: cada driver **declara** lo que puede (capacidad con caso negativo) y **el consumidor ajusta**. Si `openfga` rechaza `{trx}`, es porque una tupla no entra en una trx SQL y el paquete lo dice honestamente — no porque «el cliente actual no lo usa».
- Las mediciones (resurrección, signo del lag, pool 1, los tres bugs de hoy) siguen valiendo: son propiedades del paquete.

---

## Decisión del 2026-09-01 (3) · `{trx}` — veredicto del panel (C) y las dos decisiones del dueño

**Veredicto del juez (`panel-trx-juez.md`, 90/100): (C)** — `{trx}` REAL en `database` para los dos puertos (roles y relations), **rechazo ACTIVO en `openfga`** (500 `E_AUTHZ_UNSUPPORTED` por llamada, precedente `membersOf`/`purgeRole`; más `requireTransactionalWrites: true` opt-in en config ⇒ 500 `E_AUTHZ_CONFIG` al resolver). Gana **por el paquete**, no por ningún consumidor: una tupla no entra en una transacción SQL y no hay 2PC. Capacidad `transactionalWrites: true` significa EXACTAMENTE «los dos o ninguno», jamás «no se pierde»; sin valor intermedio. (A) outbox de hechos: 20,5 (fail-open medido, resurrección). (B): 43,5 (firma que miente: en `facts` las escrituras tocan cero filas SQL). (D) 74,5 se INJERTA como receta por dirección. (E) 42,5 descalificada (un provisional de 30 s es indistinguible de una caducidad legítima y el siguiente `grant` lo «preserva»).

**Contradicción central resuelta a favor del auditor:** «leer por la trx del llamante» (lote 3b-7) ES el agujero 🟠 8 — un snapshot anterior al freeze lo salta. Regla: **la ESCRITURA va por tu transacción; la AUTORIDAD (freeze, validación) NUNCA**. El juez verificó que `readFreezeRow` corre bajo `guardSql` con deadline ⇒ con pool 1 es **503 fail-closed, no un cuelgue** — mata el spike T-0 del analista.

**Decisión (1) del dueño: SÍ, pool ≥ 2 DECLARADO para `{ transaction }`.** La autoridad va por conexión propia; `{transaction}` exige pool ≥ 2 y se documenta como requisito; en pool 1 es 503 fail-closed, nunca bypass ni cuelgue. Es un cambio de despliegue para quien hoy use `scopes.*` con `{transaction}` en SQLite `:memory:` (pool 1/1) — aceptado y va al CHANGELOG como breaking de despliegue.

**Decisión (2) del dueño: SÍ, (F) se registra como pregunta abierta para 3.0** — «`authz_*` como log durable de hechos también en `facts`, con el store como proyección reconstruible» (51,5; no compite hoy). Cero trabajo ahora.

**Hallazgos de HOY que bloquean (todos van ANTES de `{trx}`):** 🔴 2 F-05 solo en el manager, los drivers no re-validan y el docblock de `types.ts` lo publica (L-0); 🟠 8 freeze vía trx del llamante + 🟠 9 outbox ignora `connection` + 🟠 J1 `relations/` y el comando de reconcile de relaciones sin barrera de freeze (L-1).

**Lotes, en orden:** L-0 (F-05 con dientes) → L-1 (conexión/barrera) → L-2 (capacidad) → {L-3 roles, L-4 relations, en secuencia, L-4 después de R-15 ✓} → L-5 (openfga rechaza) → L-6 (docs) → `2.4.0-alpha.2`.

**Decisión del dueño (2026-09-02, L-4):** el UNIQUE de `authz_relations` que solo defendía usersets (NULL ≠ NULL en `subject_relation` para holders) **se cierra AHORA**, micro-lote L-4b antes de L-6, con `subject_relation NOT NULL DEFAULT ''` + backfill — la única opción con paridad en los tres motores (índice parcial no existe en MySQL; `NULLS NOT DISTINCT` es solo PG 15+). Receta `ALTER` en el CHANGELOG para quien migró la alpha.1.

## 2026-09-02 (2) · `2.4.0-alpha.3` — el feedback de COGNITIV T2, por la FORMA entera («arranca»)

COGNITIV verificó la alpha.2 en consumo real (relations/ como almacén de llaves) y reportó: (1) el provider
no cablea `assertWrite`/`onRelationWrite` del `RelationsManager` y `defineConfig` no los expone
(`requireActor` SÍ está cableado: su frase era inexacta); (2) `RelationWriteEvent` no lleva `transactional`
(paridad con L-3); (3) arista de membresía `group#member` hardcoded (menor, para 2.7); docs: `assertWrite`
síncrono/puro/sin actor en el README. El barrido de la FORMA («¿qué tiene el evento de roles que el de
relaciones no?») encontró dos huecos más: el invariante 13 (`indeterminate` al vencer el deadline) NO se
cumple en relaciones (cero menciones en `src/relations/manager.ts`), y `purgeObject`/`purgeSubject` no
emiten evento alguno.
**Decisión:** alpha.3 con #1 + #2 + los dos huecos del barrido + la línea de docs; #3 al backlog de 2.7.
**Metodología: la versión LIGERA** — sin panel (no hay decisión de arquitectura ni nada que medir: se
aplican invariantes existentes y el precedente L-3), pero con tester-contrato ANTES (lista de casos de la
forma completa), implementador rojo→verde con mutantes, auditor sobre el diff, verificación propia en 4 modos.
Respuesta a COGNITIV: corregirles lo de `requireActor` y contarles los dos huecos extra.

### 2026-09-02 (2b) · alpha.3: hallazgos del tester y decisiones de forma (tomadas por el coordinador, por precedente de roles)

El tester (`alpha3-tester-casos.md`) confirmó con línea los cuatro huecos y añadió cuatro propios, todos en
alcance: **H1 🔴** `onRelationWrite` sin `await`/`try-catch` (un sink que lanza tumba un `relate` ya escrito;
roles lo protege en `#notify`); **H2 🔴** un `assertWrite` `async` es bypass silencioso (la promesa se descarta
y la escritura entra) ⇒ se cierra con 500 `E_AUTHZ_CONFIG` al detectar el thenable, fail-closed; **H3 🟠** el
`actor` de relaciones no se valida (roles sí) ⇒ `assertIdentity`; **H4 🟠** el README de L-6 ya prometía
`transactional: true` en relaciones y era falso ⇒ se hace verdad y se sujeta con caso.
Decisiones de forma (rutinarias, reversibles, con precedente; el dueño puede revertirlas a sabiendas):
**D-1** un evento por purga (`purgeObject`/`purgeSubject`, objetivo + partición, sin conteo); **D-2** la forma del
evento ESPEJA `AuthzWriteEvent` (campos opcionales `transactional?`/`indeterminate?`, no unión discriminada: el
lote es de paridad); **D-3** `actor`/`requireActor` alcanzan a las purgas (BREAKING solo para quien ya exigía
actor: más estricto, fail-closed); **D-4** hooks en `relations.*` de `defineConfig`, un solo home; **D-5**
`relations.requireActor ?? config.requireActor` (mismo patrón que `requireTransactionalWrites`).

### 2026-09-02 (2c) · alpha.3: veredicto del auditor NO APTA ⇒ lote de cierre (decisiones por precedente)

`alpha3-auditor.md`: **🔴 1** F-05 no cubre `purgeObject`/`purgeSubject` ni las lecturas (`listSubjects`/`check`/
`listObjects`): por el puerto de relaciones se borra un `role_binding` real del store compartido `openfga`
(reproducido: `authorize` pasa de true a false, 0 tuplas), con evento de auditoría limpio. Pre-existente de la
alpha.2; la forma de L-0 «un call-site más allá». **🟠 2** ídem lecturas. **🟠 3** `assertWrite` que DEVUELVE un
veredicto (boolean) compila y la escritura entra (fail-open; mismo argumento que H2). 🟡 4 thenable-función esquiva
la guarda `typeof object`; 🟡 5 hook que no resuelve cuelga la escritura y la trx del llamante (nuevo: alpha.2 era
fire-and-forget); 🟡 6 purga a medias en `openfga` borra y no emite («did not happen» falso). ⚪: `purgeSubject`
sin validar sujeto; evento sin copia defensiva; `actor: null` ⇒ 422 sin anunciar; `relations.requireActor: false`
sobre raíz `true` sin aviso; invariante 13 fuera de los runners (también en roles).
**Decisiones (coordinador, por precedente L-0 / fail-closed / paridad):** 🔴1+🟠2 ⇒ `assertRelationDeclared` de TIPO
en las purgas y las tres lecturas, en el manager Y en los dos drivers (defensa en profundidad, como L-0), con caso
contra el `:8101` que reproduce el exploit y lo ve 422. 🟠3+🟡4 ⇒ `assertWrite` rechaza TODO retorno distinto de
`undefined` con 500 `E_AUTHZ_CONFIG` (una condición). 🟡5 ⇒ NO se añade deadline al hook (roles tampoco; sería una
decisión de diseño nueva): se PUBLICA la frase «el sink está en el camino crítico y dentro de tu transacción» con
caso de letra. 🟡6 ⇒ una purga multi-request que falla tras la primera pasada emite `indeterminate: true`
(invariante 13: «puede haber ocurrido»), y la frase «did not happen» se reescribe para `openfga`. ⚪ ⇒ `purgeSubject`
valida su sujeto; copia defensiva del evento; `actor: null` como BREAKING en el CHANGELOG; aviso de la anulación
en README. El invariante 13 en los runners queda REGISTRADO para 2.6 (afecta a roles también: lote propio).

### 2026-09-02 (2d) · alpha.3: re-ataque del auditor NO APTA por una regresión del cierre ⇒ cierre-2

`alpha3-auditor-cierre.md`: todo lo del primer informe está cerrado de verdad (repros contra el `:8101`). Nuevo:
**🟠 1 regresión** — `assertRelationDeclared(config, object, relation?)` con `if (relation === undefined) return`
compartido por las siete operaciones apagó F-05 en `relate`/`unrelate` sin relación (antes 422 con cero llamadas;
ahora `openfga` 503, dobles escriben, `database` lo salva su driver: los dos drivers responden distinto). **🟡 2**
`listSubjects` sin relación devuelve la unión de relaciones (misma raíz). **🟡 3** `membersOf` sin F-05 (manager y
`database`; un driver de terceros con `membersOfNative` reabriría el 🟠 2 original). ⚪: `markPartialWrite` lanza
`TypeError` sobre un error congelado (sustituiría al 503); el driver de relaciones clasifica timeout por substring del
mensaje y su docblock dice en falso «mismo criterio que roles»; el paso de las lecturas a lanzar 422 no está en
BREAKING; el deber de marcar «parcial» sin juez queda diferido (2.6+).
**Decisiones (coordinador):** dos funciones, no un opcional — `assertRelationDeclared(config, object, relation)`
ESTRICTA (relación ausente ⇒ 422, como antes) para `relate`/`unrelate`/`check`/`listSubjects`/`membersOf`, y
`assertObjectTypeDeclared(config, type)` para `purgeObject`/`listObjects` (+ el userset del sujeto); `listSubjects`
exige relación (cierra 🟡 2); `membersOf` con F-05 en manager y `database` (🟡 3); `markPartialWrite` tolera errores
congelados sin sustituir el 503; el driver clasifica timeout por `instanceof AuthorizationBackendTimeoutError` (mismo
criterio que roles, docblock verdadero); «las lecturas lanzan 422 con relación no declarada» a BREAKING.

## 2026-09-09 · `2.4.0-alpha.4` — informe COGNITIV de cambio de driver («arranca»)

Panel acotado (analista/tester/auditor, sin juez; `panel-alpha4-*.md`, síntesis en `panel-alpha4-sintesis.md`).
Decisiones: (1) 🔴 nuevo — `commands/main.ts` pasa a loader de ace válido (`ListLoader` sobre las nueve clases;
sin `commands.json` ni assembler); (2) `openfga:provision` **opción B** (`boot()` en `prepare()` sin `start()`, guarda
de estado, exit 1 si no hay config) — NO `startApp: true`; (3) casos que EJECUTAN los comandos por el kernel de ace
(harness `AppFactory` en proceso, `kernel.exec` no relanza, stub HTTP local); (4) `capabilities()` en los dos managers
vía `driver()` (pasa la puerta 2 a propósito; jamás resolver por otro camino ni tocar `#driver`), copia congelada y
normalizada (`undefined`→`false`, nunca `undefined`), `AuthorizationDriverCapabilities` exportado; (5) README
`sqlScopeEdges` multi-tabla con la trampa (la concatenación ingenua omite aristas entre tablas y `--prune` las borra),
solo docs; helper `composeScopeEdges` + caso ejecutable ⇒ 2.6; (6) ⚪ provisión: validar el modelo antes de crear el
store. Sin breaking. Auditor sobre el diff antes de publicar. Pregunta a COGNITIV: cómo tienen registrados los comandos.
**Adenda 2026-09-09 (COGNITIV responde):** registran nuestros comandos con un envoltorio propio en `adonisrc.ts`
(`new ListLoader(Object.values(m))`), porque el barrel no era loader. Verificado contra ace: el kernel llama
`getMetaData()` sobre el namespace del módulo y NO desenvuelve `default` (core/commands tampoco exporta uno) ⇒ su
sugerencia «exportad un default» es incorrecta; lo correcto son `getMetaData`/`getCommand` nombrados. Y el arreglo
ROMPE su envoltorio (`ListLoader` serializa cada entrada; las funciones nuevas no tienen `serialize`) ⇒ nota de
migración en CHANGELOG/README con caso de letra: quitar el envoltorio y registrar el módulo directamente.

## 2026-09-09 (2) · Panel relay/outbox (2º informe COGNITIV) — veredicto del juez y decisiones del dueño

Panel completo (analista/auditor/tester → juez; `panel-relay-{analista,auditor,tester,juez}.md`). Las cuatro
observaciones de COGNITIV son exactas. Veredicto del juez (92–96/100):
1. **Recibo y filtro**: `enqueue` devuelve id (`void | {id}` covariante; `scopes.*` ⇒ `{ queued: ids[] }`); `only`
   = subconjunto de ids EN EL PUERTO + sonda de dependencia contra la cola ENTERA (0,69 ms) ⇒ `deferred` si una
   pendiente anterior comparte clave (equivale al cierre transitivo: el último eslabón comparte clave por definición);
   `remaining`/`dead` nunca filtrados; SIN filtro por tenant/`organization` (indecidible para `detached`). Medido:
   4 507 ms → 19 ms con backlog ajeno de 500.
2. **Aparcado / `requeue`**: un 503 del backend NO consume intento (por naturaleza del error); **decisión del dueño:
   desdoblar lo fijado en `scope_outbox.spec.ts:1136`** — lo aparcado TAPONA por clave lo que concede o recuelga
   (`attached`/`moved`) y sigue dejando pasar lo que retira (`detached`, invariante 11). El juez sube a 🔴 el statu
   quo (padre viejo permanente = la escalada que el outbox existe para evitar; vivo hoy en COGNITIV con relay inline).
   `authz:scopes:requeue --id` con sonda anti-reversión en el MANAGER (se niega si hay aplicada posterior con la misma
   clave); **decisión del dueño: `--force` existe solo en el comando ace, con diff impreso, jamás por HTTP**;
   `attempts = maxAttempts − 1` tras requeue (sin migración). R2a es PRERREQUISITO de R1.
3. **Lease**: no se toca (por pasada). Respuesta a COGNITIV con número: 13 ms por pasada de una entrada; con `only`
   la conexión extra se sostiene 19 ms en vez de 4 507.
4. **`enumerateRelations`**: límite declarado en alpha.5 (O(store), no disparable por petición de tenant); barrido
   único para K particiones en 2.5; `Read` por prefijo PROHIBIDO (200 con cero tuplas, en silencio, medido).
5. **Profundidad 22**: tabla de límites del README atada a la constante + gate opt-in por CONFIG (canal nuevo, no
   `capabilities`: booleana por doctrina), declarado PARCIAL (no ve la altura del subárbol movido).
Sin pedirlo: escritor único NO observado (mutante `Set` de proceso vivo en 4 motores) ⇒ caso multiproceso;
`GET_LOCK` recortado a 64 chars falla como `busy` en silencio ⇒ hash con transición (dos locks); reporte global
enumera actividad ajena ⇒ el consumidor no debe devolverlo por HTTP (README); `runScopeOutboxContract` en `/testing`.
Lotes: R2a (aparcado+503) → R1 (`only`+recibo) → R2b (`requeue`) → R0 docs+profundidad → contrato outbox + multiproceso
+ GET_LOCK ⇒ `2.4.0-alpha.5` (aditivo); barrido de `enumerateRelations` ⇒ 2.5. **«Arranca» del dueño 2026-09-09**; en dos implementadores SECUENCIALES: (I) R2a+R1, (II) R2b+R0+garantías; auditor sobre el diff; verificación 4 modos.

**Adenda 2026-09-10 (coordinador, tras el lote I):** (1) `dead` sigue siendo lista GLOBAL también con `only` (cambiar
el tipo según haya filtro rompería lectores; aviso en README); (2) un id desconocido en `only` sale en `report.missing`,
no 500 (en la receta inline un id ya aplicado por otra pasada es normal; `only: []` sí es 500); (3) las dos aserciones
Z1 (`scopes.detached()` ⇒ `{ queued: [] }` en vez de `undefined`) son consecuencia directa del recibo decidido;
(4) `index.ts` exporta ahora los tipos del puerto `ScopeOutbox` (hueco preexistente, aditivo); (5) el PRECIO del tapón
por clave —una aparcada `attached(X, org)` congela todo `attached`/`moved` bajo `org` hasta que un humano actúe
(`requeue`, lote II)— va escrito en el README y en la respuesta a COGNITIV.

### 2026-09-10 (2) · alpha.5: auditor NO APTA (dos 🟠 en el tapón por clave) ⇒ cierre (decisiones del coordinador)

`alpha5-auditor.md`: 🟠 1 la contaminación de un aplazamiento POR APARCADO congela también las purgas (`detached`
tras un `attached` aplazado ⇒ `deferred` para siempre; regresión frente a alpha.4; el README prometía «a purge never
waits»); 🟠 2 el censo de aparcadas está acotado por `limit` (101 aparcadas + `--limit 50` ⇒ tapón ciego, el
`attached` cuelga del padre viejo). Decisiones: (1) el bloqueo por clave lleva ORIGEN — si el origen transitivo es
un aparcado afecta solo a `attached`/`moved`; si es un fallo real de la pasada afecta a todo (3b-2h intacto);
(2) las claves aparcadas se leen COMPLETAS siempre (`deadKeys?()` opcional con fallback paginando). 🟡 cerrados por
baratos: diff de `--force` con «… y N más»; README «no reencoles tras reconciliar»; el orden con una outbox de
terceros descansa en que `pending()` devuelva la cola entera ordenada por id ⇒ deber del puerto + caso en el
contrato. Declarados y no tocados: un 503 eterno no converge (precio de «503 no consume intento»); `maxDepth`
parcial; `only` con ids ajenos aplica en orden (enumeración, no escalada).

## 2026-09-10 (3) · `2.4.0-alpha.6` — cerrar lo diferido de alpha.5 que se puede cerrar («arranca»)

Decisión del dueño: cerrar HOY (vía ligera; diseño ya hecho por el panel relay) (1) el barrido ÚNICO de
`enumerateRelations` en el driver `openfga` de relaciones (K particiones = un barrido; prefijo PROHIBIDO; si no puede
enumerar exhaustivamente falla ruidoso) y (2) la exención de la purga bajo `only` (la sonda hereda el ORIGEN del
bloqueo: aparcado ⇒ el `detached` pasa). NO se retira el nombre viejo del `GET_LOCK` (versión de transición por
diseño; siguiente). Implementador + auditor sobre el diff + verificación 4 modos + publish del dueño.

## 2026-09-10 (4) · Panel relay 2 (3er informe COGNITIV) — veredicto del juez y decisiones

`panel-relay2-{analista,auditor,tester,juez}.md`. Decisiones: (1) **raíz `app` exenta como clave** en los TRES sitios
(`#changeKeys`, lista de `#dependencyOf`, lista de `requeueScopeChanges`), por REF (`isRootRef`), en el manager, también
para el bloqueo por fallo (ningún par cuyo único cruce sea `app` necesita orden: medido por los tres); casos A-1/2/3/8 +
negativos, O-07 desdoblado (15→16), `CLAUDE.md` corregido. **Dueño: variante B SÍ** — el censo de aparcadas siembra solo la
clave del HIJO (solo en `#parkedKeys`, jamás en `#changeKeys`: mataría la protección de 1136 en el respaldo de la sonda).
(2) **Supersede NO** (95/100): requisito traducido = `authz:reconcile` acotado por subárbol/tenant con `--dry-run` (2.5);
injerto `supersededBy` read-only en `dead[]` si es barato. (3) **`requeue { apply }`** con cuatro condiciones: sin lease
propio, PASA el freeze, excluyente con `force` (500 juntos), `only` interno = ids reencolados; lease tomado ⇒ `busy`, cero
reencoladas, exit ≠ 0; `--apply` explícito. Prerrequisito X-1: opción desconocida ⇒ 500 (hoy `{ apply: true }` se ignora
en silencio). (4) **Edad**: `queue.{oldestPendingAt, pendingAgeMs}` globales también bajo `only`, `createdAt?` opcional en
`PendingScopeTreeChange`, reloj inyectable (`clock.spec` hace grep de `Date.now()`), reusa el `pending(1)` del final,
`--max-age` con exit ≠ 0; `parkAfterMs` NO (🔴: se autobloquea con el censo). (5) **`enqueue` sin trx ⇒ 500** solo con
`requireTransaction: true` (opt-in; el default rompe el contrato publicado); mensaje que nombra S5; **dueño: se anuncia
default en 2.5** (y el contrato pasará la trx en `ctx()`). (6) Bug del cursor del respaldo de `enumerateRelationsMany`
🟠, PRIMERO: C2 el respaldo falla ruidoso al reanudar; C1 nativo en `database`; sin capacidad nueva. (7) Menores: `origin`
en `entries`; `deadCount` siempre + **coordinador: bajo `only`, `dead` lleva ids sin `lastError` por DEFECTO**
(`deadDetail: 'full'` opt-in) — fail-closed sin esperar a saber si COGNITIV devuelve el reporte por HTTP (se les pregunta
igual); trx cerrada ⇒ `E_AUTHZ_CONFIG` (`isCompleted`); `waitForLeaseMs` default 0, pool ≥ 2; 422 de profundidad sin nombrar
servidor/constante en el mensaje público (detalle a `details`), doc `maxDepth = N + 1` con caso ejecutable.
Lotes: **alpha.8 aditiva** en dos implementadores secuenciales: I = C2/C1 cursor + X-1 + A (raíz + variante B) + B
(`apply`, `waitForLeaseMs`, freeze); II = edad + `requireTransaction` + menores + docs. Auditor sobre el diff; 4 modos.

## 2026-09-11 · Informes 4 y 5 de COGNITIV — TRES 🔴 en `2.4.0-alpha.8` ⇒ `alpha.9` urgente

Copias en `cognitiv-informe-4-flags.md`, `cognitiv-informe-5-cutover.md`, `cognitiv-respuesta-alpha8.md`.
**Verificado por mí contra el código, los tres son exactos:**
1. **🔴 BANDERAS INERTES (17 en 7 comandos).** `@adonisjs/ace` `defineFlag(name, options)` hace
   `{ name, flagName: dashCase(name), ...options }` y luego `Object.defineProperty(this, flag.name, …)`
   (`node_modules/@adonisjs/ace/build/index.js:377-383` y `:677`): pasar `name: 'dry-run'` en las OPCIONES pisa el
   nombre de la PROPIEDAD ⇒ el valor cae en `this['dry-run']` y `this.dryRun` es `undefined`. La opción para
   renombrar la bandera es `flagName`; sin ninguna, `dashCase(propiedad)` ya da el guion. Efectos medidos por
   COGNITIV: **`authz:reconcile --dry-run` ESCRIBE** (463 tuplas en un store vacío y rama de ÉXITO: el verificador
   read-only por contrato no lo es), **`authz:relations:reconcile` migra 0 y reporta éxito** (`--partition-type`/
   `--partition-uuid` inertes ⇒ siempre `{app,null}`), `--max-age`/`--batch-size`/`--wait-lease-ms`/
   `--fail-on-shadows`/`--lease-ms` ignorados; `--allow-mass-delete`/`--allow-mass-purge` fallan al lado seguro.
2. **🔴 `authz:reconcile --prune` BORRA las tuplas de RELACIÓN de un store compartido.** No es de banderas:
   `familyOfTuple` (`src/drivers/openfga_driver.ts:3450`) tiene `return 'facts'` como catch-all, así que toda tupla
   de `relations/` cae en `extra` y con `--prune` en `deletes`. Medido: 523 → 463 tuplas, «sobran 60, borradas 60»,
   exit 0, y el seguro de borrado masivo no salta (el origen sí tiene hechos).
3. **🔴 corolario: `clean = false` PARA SIEMPRE** con store compartido (`skipped['extra-fact']` nunca vacío) ⇒ el
   verificador de CI que el CHANGELOG promete verde no existe ahí.
**Punto ciego que lo permitió** (nuestro, y es la lección de alpha.4 a medio cerrar): `commands.spec.ts` ejecuta
comandos por el kernel de ace pero **nunca con banderas**, y el reconcile de hechos nunca se probó contra un store
CON relaciones. Los casos que ponen `cmd.dryRun = true` a mano no ven nada.
**Plan:** (A) banderas: quitar `name:` de las opciones (o `flagName:`), con guardia ESTÁTICA + casos que ejecuten
cada comando con `['--<flag>=<v>']` por el kernel y afirmen el EFECTO, no la propiedad — sin panel, es mecánico y
urgente; (B) store compartido: panel (analista/auditor/tester) porque choca con una propiedad publicada («reconcile
borra la basura de un modelo anterior») y hay que decidir qué tipos gobierna el reconcile de hechos.

### 2026-09-11 (2) · Store compartido — panel (auditor + analista, sin juez: coinciden) y decisión del coordinador

`panel-shared-store-{auditor,analista}.md`. **Agravantes que el informe de COGNITIV no decía, medidos por el analista:**
(i) con `--prune` la pasada destructiva reporta **`clean = true` y exit 0** (borra justo lo que causaba el `extra-fact`);
(ii) **`group`** —el tipo de usersets que el generador emite SIEMPRE— también cae, así que cualquier despliegue con
relaciones pierde sus grupos. Y el auditor: **`deny_binding` de 2.2 NO es basura inerte** — `enumerateFacts` la lee y
emite como deny (3b-8 · A2) en `--to=database` y en la pasada de mantenimiento, así que tratarla como «ajena» haría que
el mismo driver la considere propia por un lado y ajena por otro, perdiendo la cura del store migrado desde 2.2.
**Decisión (coordinador; los dos panelistas coinciden, no hace falta juez):**
1. `familyOfTuple` **sin catch-all**: lista blanca EXPLÍCITA y congelada de los cuatro tipos que el reconcile de hechos
   gobierna —`scope`, `role`, `role_binding`, `deny_binding`— en una constante PROPIA del módulo con el porqué escrito.
   **NO reutilizar `RESERVED_FACTS_TYPES`** (`identity.ts:329`): incluye `group` y reproduciría el bug — mutante
   obligatorio. Lo que no está en la lista es `foreign`: sale ANTES de `deletes.push` y de `phases[...]`.
2. **La clasificación de BORRADO no lee nada en runtime** (ni `relations.config`, ni el modelo publicado, ni tablas):
   el precedente de fallback permisivo vive en la misma función (`openfga_driver.ts:2492`) y copiarlo devolvería el
   borrado masivo justo cuando no hay `relations.config`, que es el caso de COGNITIV.
3. **`foreign` es campo propio** del reporte (`{ tuples, types, relations?, unknown? }`), FUERA de `skipped` (por eso
   `clean` vuelve a poder ser `true` en store compartido) y fuera de `details`; `phases` NO crece (tipo publicado).
   `relations.config`, si está, se usa SOLO para partir el reporte en `relations`/`unknown`, jamás para decidir borrado.
4. **No se toca `relations/`**: el defecto simétrico NO existe (medido: `relations:reconcile --prune` borró 7 de 7
   sobrantes y dejó hechos/árbol/catálogo idénticos; ya usa lista blanca — es el patrón que copiamos).
5. **Residuo DECLARADO** (🟠 3 del auditor, 🟡 del analista): tras la corrección, las tuplas de un tipo de relación NO
   declarado (o retirado de `relations.config`) no las barre nadie y resucitan si el tipo se re-declara. Va al README
   como límite y al roadmap 2.5 (¿`authz:relations:reconcile --prune-undeclared`?). NO se hace un `--prune-foreign`.
6. Se corrigen en el MISMO lote la frase publicada de `CLAUDE.md` («se lee y se borra aunque ya no se pueda escribir»)
   y el docblock de `readEveryTuple`.
Coste medido del parche: `--prune` borra 0, store intacto, `clean = true`, y es MÁS rápido (43 → 27 ms); `deny_binding`
de 2.2 y `role_binding` con id de 1.x SIGUEN borrándose (2 de 2). No breaking.

## 2026-09-13 · Sexto informe de COGNITIV (acuse de alpha.9 + cinco detalles) ⇒ `2.4.0-alpha.10`

Copia en `cognitiv-informe-6-acuse.md`. COGNITIV instaló alpha.9, reensayó el cutover ida y vuelta, retiró su reparto de
familias y usa `report.foreign`; los dos avisos de alpha.9 no les alcanzan. **Verificado por el coordinador:**
1. **Letra falsa**: la pasada de MANTENIMIENTO (`--to=<activo>` sin `--from`) imprime «no escribe ni borra un solo hecho» y
   con `--prune` borra los de scopes que ya no resuelven (medido: «sobran 3, borradas 3»). README `:1033` igual. 🟠 (letra
   falsa sobre una operación destructiva; «lo publicado se cumple o se reescribe»).
2. **`authz:unfreeze` éxito con ventana CADUCADA** (`commands/authz_unfreeze.ts:24-26`): `freezeStatus()` descarta la fila
   vencida (`if (!freezeIsLive) return null`) ⇒ `noop` ⇒ `success`. Distinguible: `releaseFreeze` pone `freeze_reason` a null
   al levantar, así que una ventana que CADUCÓ deja la fila con motivo y `untilMs` en el pasado. 🟠: el último paso del
   cutover no delata escrituras que el motor nuevo no vio.
3. **`leaseMs: null` en la ventana de operador ADOPTADA** (`src/manager.ts:~767`) aunque tenga `untilMs`. Solo REPORTE: la
   certificación está bien (`#tokenLapsed` lee `untilMs` de la fila). 🟡.
4. **`authz:reconcile --to=<driver activo> --from=<otro>`** lee el origen sin objeción (`manager.ts:~2088`: con `--from`
   manda el operador, regla 3b-5) y **re-escribe en el store vivo los roles revocados desde el cutover** (siguen en
   `authz_assignments`, que dejó de escribirse), con o sin `--prune`; el seguro de borrado masivo no salta (origen no vacío).
   🔴 por efecto (resucita revocaciones), aunque requiere operador: la dirección del día del cutover sigue «funcionando» después.
5. **`--partition-type=app --partition-uuid=<org>`** es pareja completa y cae en la raíz en silencio
   (`commands/authz_relations_reconcile.ts`): la variante que el cierre de alpha.9 no cazó. 🟡.
**Decisión (coordinador, vía ligera + auditor sobre el diff; el guard de 4 es simétrico al seguro de borrado masivo ya
auditado):** (1) frase verdadera en comando y README con caso de letra; (2) `unfreeze` lee también la fila CADUCADA
(método nuevo del manager, sin cambiar `freezeStatus()`) ⇒ exit ≠ 0 nombrando cuándo venció y qué significa; «nunca hubo /
ya levantada» sigue siendo éxito; (3) `leaseMs`/`untilMs` reales en la ventana adoptada; (4) **en el MANAGER** (no solo el
comando): `reconcile({ to, from })` con `to === config.default` y `from !== to` ⇒ 500 `E_AUTHZ_STALE_SOURCE_REFUSED` antes
de leer nada, salvo `allowStaleSource: true` (`--allow-stale-source`); `--dry-run` NO lanza, lo marca en el reporte
(precedente `massPurge`); el mensaje nombra el riesgo (resucitar revocaciones) y la dirección correcta (mantenimiento sin
`--from`); **BREAKING** documentado; (5) `--partition-type=app` con `--partition-uuid` ⇒ exit ≠ 0.
Pendiente del dueño (condición de COGNITIV para fijar cutover real en producción): **qué hace falta para `2.4.0` estable**.

### 2026-09-13 (2) · Piloto de auditoría de SISTEMA (M4) — encuentra 1 🔴 y 2 🟠 publicados desde alpha.1

`panel-metodologia-auditor.md` (repro `.claude/reproducciones/sistema-m4.spec.ts`). Sobre alpha.9 publicada, sin diff,
~15-20 min de agente: **S1 🔴** `authz:relations:reconcile --to=openfga` tras el cutover elige `database` por descarte, no
pasa por `manager.reconcile`, resucita comparticiones retiradas y con `--prune` borra las nuevas — el GEMELO de la dirección
rancia que alpha.10 estaba cerrando SOLO en roles; **S2 🟠** ventana de operador caducada/levantada ⇒ `reconcile` toma
freeze propio, se certifica y pone a NULL la fila del operador, y el `lastFreezeStatus()` previsto en alpha.10 no lo ve;
**S3 🟠** el runbook de cutover no menciona `relations/`. Más 5 🟡 (S5/S6/S7 «la salida miente» en el relay; S4, S8).
**Decisión (coordinador):** S1, S2, S3 y S5-S7 se añaden al lote alpha.10 EN CURSO (intersectan sus piezas 1 y 2: sin esto
alpha.10 habría repetido el patrón); S4 y S8 al siguiente. **Nueva regla para los cierres: listar los GEMELOS** de cada
rojo/naranja (roles ↔ relaciones; comando ↔ función exportada ↔ manager) con caso o «no aplica porque…».
**Evidencia para el panel de metodología:** M4 vale (encontró lo que 15 rondas por diff no vieron) con el caveat del auditor
(el primer M4 recoge lo acumulado; repetido igual se vuelve teatro ⇒ rotar perspectiva). Patrones que ninguna M1..M6 cubría:
**asimetría entre gemelos** y **salidas que no dicen qué rama corrió**.

### 2026-09-13 (3) · Retrospectiva contrafactual del analista — corrige el diagnóstico del coordinador

`panel-metodologia-analista.md`. **34 defectos graves** entre alpha.1 y alpha.10 (no 7). Correcciones medidas:
- **No se mudaron a la frontera**: de los 12 que encontró COGNITIV, **9 nacieron antes de alpha.1**; siempre estuvieron en
  capas que nadie EJECUTABA. Quién los encuentra sí cambió (alpha.2: todos nosotros; alpha.9–10: todos COGNITIV).
- **P2 del coordinador es falso tal como estaba escrito**: el diff de alpha.8 (`b5868d8`) AÑADIÓ tres banderas inertes y el
  auditor dio APTA; y los auditores sí encontraron 6 defectos viejos fuera del diff. Lo que falta es EJECUTAR el sistema por
  su puerta real y recorrer lo que hace el operador.
- **Los «círculos» son LINAJES**: 6 linajes (F-05, puerta `{transaction}`, barrera del freeze, tapón del relay, entrada inerte
  silenciosa, origen rancio del reconcile), de 2 a 5 iteraciones, explican 17 de 34. El del origen rancio seguía abierto en
  el propio lote alpha.10 (guard sobre `from` en vez del origen resuelto) ⇒ corregido en caliente con forma estructural.
- **Contrafactual**: M4 9,0 · M3 7,0 · M1 6,0 · M5 5,5 · M2 3,0 · **M6 0** (ya es el mutante obligatorio). Ninguna cubre 11/34.
  Propone **M7 guardia estructural** (enumerar por reflexión las entradas que alcanzan cada guarda; falla si alguna no tiene
  caso o exención firmada; ya hay tres en el repo que funcionan) = 11,0, y **M8 regla de tres** (el 3er defecto de un linaje
  no se parchea: arreglo estructural).
- **APTA no es un buen gate**: las 5 veces que un auditor dio APTA final (alpha.3, 4, 6, 8, 9) la ronda siguiente trajo
  graves, casi todos publicados desde antes de esa APTA.
- **`latest` (1.1.0, desde 07-29) trae el loader de comandos inválido y el TypeError de `openfga:provision`** (verificado:
  `git show v1.1.0:commands/main.ts` sin `getMetaData`).
- Dos tests más que CODIFICABAN el defecto: `tests/reconcile.spec.ts:~994`, `tests/freeze.spec.ts:~306` ⇒ pasados al lote alpha.10.
- Error de cita del coordinador: el commit de alpha.9 cita `alpha9-auditor.md`, inexistente ⇒ creado como puntero.
**Aplicado ya (coordinador):** M8 sobre el linaje abierto (guard de alpha.10 sobre el origen RESUELTO en los dos puertos, con
tabla de verdad parametrizada y mutante estructural). Resto de adopción: tras el juez.
**Pendiente del dueño:** ¿`npm deprecate` también de `1.1.0` (latest)?; ¿el ensayo de COGNITIV sobre el tarball de la RC es
condición de la estable?

### 2026-09-13 (4) · Veredicto del juez del panel de metodología

`panel-metodologia-juez.md` (texto listo para `CLAUDE.md` y nueve cambios al documento de metodología de COGNITIV).
**Diagnóstico final:** los «círculos» son LINAJES (6 explican 17/34): cada arreglo tapa un punto de llamada y decide A MANO
hasta dónde llega. **Se adopta**, por puntuación (defectos evitados 35 · ceremonia/falsa seguridad 25 · verificabilidad 20
· coste 20): **M7 guardia de superficie** (78; cobertura demostrada por MUTANTE que mata cada entrada, no por presencia —5/27
presencias medidas eran decorativas—; absorbe M2); **M1 runbook ejecutable con los pasos sacados de M5 (estados)** (70; la
tabla de pasos es la FUENTE y el README se ajusta a ella); **M3 tabla de verdad al cerrar rojos/naranjas** (67); **M4
auditoría de sistema periódica, rotando perspectiva, NUNCA como gate** (62,5); **M8 regla de tres** (59); **M5 estados**
con la peor instancia de todo precio declarado (59); **listar gemelos** y **la salida dice qué rama corrió** con caso de
letra (58). **Descalificadas:** M4 como gate APTA (5/5 APTA seguidas de grave), M1 copiado del README, M2 por presencia, M6
tal cual (0 decorativos reales, tres lecturas falsas; queda solo como línea del cierre).
**Condición:** piloto de M7 sobre F-05 y el origen del reconcile, tope 3 h, ANTES del resto.
**Orden:** registro de linajes → cerrar alpha.10 → mutantes de banderas → piloto M7 → resto de M7 / M5 → runbook M1 → RC
(≈19-29 h).
**Criterio de `2.4.0` estable (sustituye «M1 + M4 APTA»):** M1 verde en los motores que lo soportan (no `:memory:`) · M7
sin entradas sin mutante, exenciones firmadas por el dueño · pasada M4 sobre la RC contando hallazgos con repro (no un APTA)
· ensayo de COGNITIV sobre el tarball exacto de la RC con plazo cerrado · **cualquier grave, de linaje registrado o no,
reabre la RC.**
**Riesgos que quedan aunque se adopte todo:** 6/34 no los cubre ninguna medida; entradas que nadie concibió; exenciones que
se vuelven sello; M4 que se vuelve teatro sin rotar; scripts de mutantes que mienten (el tester se equivocó dos veces).

### 2026-09-13 (5) · Decisiones del dueño sobre el veredicto de metodología

1. **El ensayo de COGNITIV sobre el tarball exacto de la RC es CONDICIÓN de `2.4.0` estable, con plazo cerrado** (si vence
   sin rojos, se publica; un grave reabre la RC).
2. **El dueño FIRMA cada exención de la guardia de superficie (M7)**, con motivo escrito en una línea; su firma queda
   registrada. No es «cero exenciones».
3. **`npm deprecate` de `1.1.0` y de las alphas 4–8.** Al preparar los comandos el coordinador verificó que el alcance real
   es MAYOR: el loader de comandos inválido está en TODA versión anterior a `2.4.0-alpha.4` (1.0.0, 1.0.1, 1.1.0 y
   2.4.0-alpha.1–3 verificados por `git show <tag>:configure.ts|commands/main.ts`; 1.0.2 y 2.0.0-alpha.1 sin tag local,
   mismo linaje), y las 4–8 tienen los fallos destructivos ⇒ **toda versión < 2.4.0-alpha.9 es defectuosa en los comandos**.
   Se presenta al dueño el conjunto completo (dos rangos + `2.0.0-alpha.1` explícito, porque `<2.4.0-alpha.4` sin
   `includePrerelease` no la cubre) para que confirme el ensanche; los ejecuta él (sesión npm).

## 2026-09-13 (6) — auditor de alpha.10: APTA con cambios ⇒ cierre en el MISMO lote (coordinador)

Auditor (`alpha10-auditor.md`): 🟠 R1 `reconcileRelations` exportada sin guarda (vía que el README recomienda), 🟡 R2 carrera
comprobar/tomar en `freeze()`, 🟡 R3 `relay --dry-run --only` inexistente dice «outbox vacía», 🟡 R4 guarda de relaciones
compara etiquetas y no drivers, 🟡 R5 guarda lee el `config.default` del proceso, ⚪ higiene. Verificación propia del lote:
1415 / 1441 / 1537 / 1539.
Decisiones del coordinador, aplicando el criterio del dueño («cerrarlo todo en la misma versión») y M8 (L6 es 3.ª iteración):
- R1: la guarda vive en el punto por el que pasan TODAS las vías exportadas de relaciones (no solo docs). Si
  `reconcileRelations` no puede conocer el driver activo, se le exige o sale de la raíz (ruptura aceptable en alpha).
- R2: exclusión de `operator:` dentro del `WHERE` del UPDATE (atómico). R3: `--dry-run` con la misma letra/exit que S6.
- R4: comparar identidad de driver resuelto, no etiquetas. R5: declarado en README/CHANGELOG; sello durable del driver
  activo ⇒ roadmap 2.5.
- Pregunta 2 del auditor: SIN excepción para ventana viva; el runbook verifica ANTES del switch de `default`.
- Higiene ⚪ entera en este cierre. Luego re-ataque del auditor.

## 2026-09-13 (7) — re-ataque del cierre de alpha.10: 0 🔴/🟠, 2 🟡 + 5 ⚪ ⇒ cierre-2 en el mismo lote (coordinador)

Verificación propia del cierre: 1428 / 1454 / 1550 / 1552, build/typecheck/purity 0. Auditor (`alpha10-auditor-cierre.md`).
Criterio del dueño «cerrarlo todo en la misma versión»:
- C1 (dos factories distintas sobre el mismo backend engañan la guarda): DECLARAR el límite en README/CHANGELOG/CLAUDE.md
  como R5; identidad de backend declarada por el driver ⇒ roadmap 2.5.
- C2 (`--only` con más ids que `--limit` dice «no existe»): SÍ distinguir «no está en la cola» de «no evaluado por
  `limit`» en el reporte (campo aditivo) y en la letra/exit, en pasada real y `--dry-run`.
- C3: clasificación del prefijo `operator:` idéntica en SQL (sensible a mayúsculas, sin `LIKE`) y JS, 3 motores.
- C4: holder literal `'?'` sin bucle y con letra verdadera. C5: declarar alcance de la guardia de exports (y recorrer
  objetos anidados si es barato). C6: documentar los dos métodos nuevos del manager y el límite del manager falso.
- C7: fijar la rama del caso TOCTOU; `RelationsReconcileOptions` coherente con la API pública; `README.md:38`.

## 2026-09-14 — `npm deprecate` ejecutado por el dueño (ampliado a todo < alpha.4)
Verificado en el registro: 1.0.0, 1.0.1, 1.0.2, 1.1.0, 2.0.0-alpha.1, 2.4.0-alpha.1–3 ⇒ mensaje del loader roto;
2.4.0-alpha.4–8 ⇒ mensaje de `--dry-run`/`--prune`; alpha.9 y alpha.10 sin marca. El primer comando dio E422 en
consola pero se aplicó entero. `latest` sigue en 1.1.0 (deprecada) hasta la 2.4.0 estable.

## 2026-10-14 — 7.º informe COGNITIV (tenencia, P1–P5): veredicto del panel (pendiente de decisiones del dueño)

Panel: `panel-tenencia-{coordinador,analista,auditor,tester,juez}.md`. Postura del coordinador DESCALIFICADA (24/50): deny
literal por relación rompe `owner ⇒ editor ⇒ viewer` (R-02), y reconcile sin `kind` fusiona allow/deny (escalada fabricada).
Gana el plan del analista con dos cambios del juez (40/50): guardia de superficie de L1 primero; mitigaciones del auditor
como condición de P1. El caso Nóminas NO lo resuelve el paquete (ni checkMany booleano ni tri-estado): `inherits=false`
en el evaluador de COGNITIV.
Lotes: 0 guardia L1 (6–10 h) + A: P5 (caso P5-1 obligatorio, `createTestClock`) + clave pura `relationTupleKey` + `checkMany`
booleano (tope 50, `[]`=422, 503 por ítem = 503 total) ⇒ alpha.11 · C: P2 solo holders/directas con includes resueltos,
cursor `(partition_key, object_uuid)`, índice nuevo ⇒ alpha.12 · D: P1 deny (sube por `includes` cortando el grant,
propia relación, opt-in por tipo, ≤43 chars, sin `*`, deny sobre group = 422, `kind?` + censo en reconcile, purga allows→denies)
⇒ 2.5.0-alpha, SOLO con: respuesta de COGNITIV, lote 0 verde, D2–D5, 4 mediciones (bytes del modelo, latencia `but not`,
ciclos de `includes` —hoy no se rechazan—, ListObjects parcial por deadline).
Preguntas al dueño D1–D6 y a COGNITIV C1–C5 en el fichero del juez.

## 2026-10-14 (2) — ronda 2 del panel tenencia: «la 2.5 de una vez» (veredicto del juez; decisiones del dueño PENDIENTES)

Dueño: el paquete ideal y genérico; el deny bien hecho y ahora. Ronda 2: `panel-tenencia-2-{coordinador,analista,auditor,
tester,juez}.md`. Cinco mediciones hechas contra OpenFGA 1.19 (`:8090`/`:8104`, repetir en `:8101`): M5 FGA rechaza
delete+write de la misma clave ⇒ caducidad del deny forzada a NO en v1; M3 ciclos de `includes` aceptados hoy; M4
`ListObjects` parcial y mudo (contradice README:635); M1/M2 bytes y latencia irrelevantes. Plan ganador (analista +
3 injertos, 44/50): 0 → A → B → D → C → RC, con R (infra del criterio de estable: mutantes de banderas + job
`cutover-runbook`, que HOY NO EXISTEN) en paralelo y condición de la RC. Siguiente estable = 2.5.0 (no habrá 2.4.0).
Total 130–205 h. Decisiones D3–D16 con recomendación en `panel-tenencia-2-juez.md` §«Decisiones del DUEÑO».
Clave: D9 `decideMany` tri-estado AMPLIO igual en los dos drivers (la primitiva de cadena); D10 opt-in en dos fases;
D12 rollback con denies vivos prohibido; D8 `database` honra `denied_*` siempre; D4 uuid sin guiones ⇒ 422 en lote A.
**Decisión del dueño 2026-10-14:** PLAN COMPLETO aprobado (0→A→B→D→C→RC + R; estable = 2.5.0 con deny y P2; 130–205 h).
Porqué: «el paquete ideal y genérico, no para complacer a COGNITIV; que cualquier servicio lo pueda usar y COGNITIV también».
D3–D16: el dueño revisa antes de firmar (pendiente).
**2026-10-14 · D3–D16 FIRMADAS por el dueño según la recomendación del juez** (`panel-tenencia-2-juez.md` §«Decisiones del DUEÑO»):
D3 deny sin caducidad en v1 (`expiresAt` ⇒ 422; temporal a 2.6 si C2) · D4 uuid sin guiones ⇒ 422 en toda operación con
partición, lote A, con receta; ids de objeto/sujeto se declaran byte a byte · D5 corte de camino · **D6 exenciones de la
guardia L1 firmadas: `driver()`, `capabilities()`, `enumerateRelations`, `enumerateRelationsMany` (protegidos por la lista
blanca, no por F-05), `membersOf` de openfga (no implementado); cae la exención si cambia la razón** · D7 entran B6/B7 y
`--prune-undeclared`; resto a 2.6 opt-in · D8 `database` honra `denied_*` siempre · D9 `decideMany` tri-estado amplio en
los dos drivers · D10 opt-in en dos fases · D11 claves desconocidas ⇒ 422 · D12 rollback < 2.5 con denies vivos prohibido ·
D13 el runner exige F-05 al driver directo · D14 `modelId` fijado obligatorio con deny activo · D15 regla de capacidades
opcionales desde 2.5.0 en CLAUDE.md · D16 ensayo de COGNITIV: 7 días naturales. «Arranca»: lote 0 en `main`, lote R en worktree.

## 2026-10-14 (3) — lote R entregado (rama `lote-r` `8b5f6ca`, worktree `../adonis-authz-loteR`); decisiones del coordinador

- `check:flag-mutants` (36 banderas, 52 s, job propio) y `cutover-runbook` (20 pasos + guardia del README, pg + sqlite-file +
  OpenFGA, CI) existen. Sobre HEAD había **9 banderas con mutante vivo** (= 9 banderas sin caso de efecto) ⇒ casos R-1…R-8.
- **F-R1** (`reconcile --to=openfga --prune` arregla el scope muerto pero cuenta sus `assignee` en `skipped.unknown-scope`
  y sale exit 1 «queda algo que esta pasada no arregla sola»): es linaje **L8 letra ≠ efecto** ⇒ SE ARREGLA (no se firma
  como intencional), en el lote A con sus cuatro líneas de cierre; el job `cutover-runbook` queda rojo hasta entonces.
  F-R2 (letra de `--allow-mass-delete`) y F-R3 (error crudo con freeze ajeno) también al lote A.
- Integración: `lote-r` se fusiona en `main` tras commitear el lote 0 (hunks adyacentes en CLAUDE.md «Comandos»).
- Entorno: `:8101` no responde; OpenFGA real = `:8090` (`openfga-dev`). Anotar en RETOMAR.

## 2026-10-14 (4) — auditor del lote 0: 2 🟠 + 5 🟡 + 4 ⚪ ⇒ cierre en el mismo lote (coordinador)

Verificación propia 1548 / 1574 / 1670 / 1672. Auditor (`lote0-auditor.md`): 🟠1 G-X lee `.claude/contexto/` (gitignored)
⇒ en CI la guardia SIEMPRE roja; 🟠2 `na`/`kind: 'platform'` funcionan como exención sin firma (un `relateMany` sin
ninguna guarda pasa la guardia y el corredor); 🟡3 inventario solo del prototipo propio (campos arrow/estáticos/heredados
no se ven); 🟡4 G-X no exige «exactamente cinco» ni ata exención a capa×columna; 🟡5 columna `write` solo prueba timeout;
🟡6 lo que construye el provider no se sondea; 🟡7 sonda F-05 vacía para operación nueva; ⚪8–11.
Decisiones del coordinador:
- 🟠1: la firma D6 vive en un **extracto versionado** (`tests/fixtures/exemptions_d6.json`: id, capa, columna, razón, fecha
  de firma); en local G-X lo cruza con el fichero de decisiones y falla si difieren; en CI falla si el extracto falta.
- 🟠2: **matriz cerrada** de razones `na` válidas por capa×columna; la columna `f05` NUNCA admite `na` (solo `probe` o
  `exempt` firmada); `platform` solo para `driver()`/`capabilities()`; G-R invoca TODOS los métodos del manager y los
  drivers, no solo `PORT_OPERATIONS`. «Freeze en capa driver» queda como `na: doctrine` SOLO en la celda freeze×driver,
  porque es doctrina escrita en CLAUDE.md (`driver()` se salta las barreras del manager), no una exención: la matriz lo fija.
- 🟡3–7 y ⚪8–11: se cierran todos en este cierre (criterio del dueño «todo en el mismo lote»). 🟡5: sonda de escritura
  parcial además del timeout; `openfga.purge*.write` pasa a `probe`. ⚪11: el doble entra en la columna de partición.

## 2026-10-14 (5) — re-ataque del cierre del lote 0: 0 🔴/🟠, 4 🟡 reproducidos + 1 hipotético ⇒ cierre-2 (coordinador)

`lote0-auditor-cierre.md`: 🟡A `INVOKE[op]` puede llamar a OTRO método (una lectura nueva enrutada a `check` pasa);
🟡B se sondea lo que construye `buildRelationsManager`, no el singleton `authz.relations` del contenedor; 🟡C el
inventario no ve accessors de instancia ni objetos-namespace ni Proxy del constructor; 🟡D el cruce local del extracto
no coteja capa/columna; en CI y en worktrees (sin `.claude/contexto`) la única firma es la revisión del diff — límite NO
escrito; 🟡E (hipotético, lote D) `WRITES` es lista fija: una escritura nueva sin evento se clasificaría como lectura.
Decisión (criterio del dueño «todo en el mismo lote»): cierre-2 con 🟡A (Proxy que exige que `INVOKE[op]` acceda a
`t[op]`), 🟡B (el caso «el servicio» resuelve el singleton del contenedor), 🟡C (inventario de accessors de instancia,
namespaces y Proxy devuelto), 🟡D (cruce por capa+columna; límite «en CI y worktrees la firma es la revisión del diff»
ESCRITO en CLAUDE.md y en el extracto; la sonda de una exención ejecuta la operación exenta). 🟡E: regla ya en el lote 0
— `WRITES` derivado de la firma/puerto (o rojo si una operación no está clasificada en ninguna lista), para que `deny`
nazca rojo en el lote D.

## 2026-10-15 — auditor del lote A: «inseguro tal cual en D4» (2 🟠, 5 🟡, 5 ⚪) ⇒ cierre en el mismo lote (coordinador)

`loteA-auditor.md`, repro `loteA-reataque.spec.ts` (3/3 verdes). Decisiones:
- 🟠A1 receta D4 resucita revocaciones (re-clava filas sin guiones que una purga canónica no veía; fusión con caducidad
  más larga) ⇒ **receta FAIL-CLOSED por defecto**: detectar y BORRAR las filas no canónicas (eran concesiones invisibles a
  la purga), listado antes; el re-clavado solo con bandera explícita (`--rekey`) tras revisar el listado; nunca alargar
  una caducidad. README §Upgrading lo dice.
- 🟠A2 D4 incompleto (PG funde otras colocaciones de guiones: 8-4-4-16, etc.) ⇒ 422 para TODO valor que, sin guiones,
  sea 32 hex y no esté exactamente en 8-4-4-4-12; el detector de la receta usa la misma regla.
- 🟡A3 huecos en la respuesta de un driver de terceros (`new Array(n)` pasa `some`) ⇒ 500 en `checkMany` Y en
  `authorizeMany` de roles (gemelo). 🟡A4 lo podado vuelve a `details` y `--dry-run` enseña qué se borrará. 🟡A5
  `createTestClock` desde un módulo LIGERO (sin japa/lucid), re-exportado en `/testing`; el README importa el ligero.
  🟡A6 ruptura declarada en CHANGELOG: una partición de 32 hex que no sea uuid canónico es 422 (los ids de objeto/sujeto
  no). 🟡A7 D13 directo incluye `membersOf` cuando `membersOfNative`; CHANGELOG «nine» corregido.
- ⚪A8 hint MySQL detrás de `DISTINCT` (503 donde `check` da true) ⇒ una línea + caso. ⚪A9 `relationTupleKey` valida
  objeto/relación/sujeto y `kind` OBLIGATORIO (sin default `allow`). ⚪A10 regla «error ⇒ 503» una sola vez; ausente ⇒
  500 coherente. ⚪A11 documentado. ⚪A12 `allowMassDelete` opcional en el tipo; D13 directo prueba tope y `[]`.

## 2026-10-15 (2) — re-ataque del cierre del lote A: 1 🟠 (gemelo en roles), 1 🟡, 2 ⚪ ⇒ cierre-2 (coordinador)

`loteA-auditor-cierre.md`: 🟠R1 el cierre declaró «Roles: no aplica» y SÍ aplica: `scopeSpellings` (roles) solo expande
el alias sin guiones; con la forma 8-4-4-16 y sin cadena (`detached` tras borrar la fila; `revoke`/`removeDeny` con
cadena null) la forma canónica no se purga ⇒ el scope concede para siempre en `facts` (el 🟠 3 de 3b-2h con otra
ortografía). 🟡R3 la receta por defecto (DELETE) vacía las relaciones de un consumidor cuyos ids de partición sean
32 hex no-uuid (población A6), y el README da a entender lo contrario. ⚪R2 `relationTupleKey` aplicado a tuplas
ENUMERADAS del destino: un dato malo del backend ⇒ 422 (invariante 5: no es del llamante) y bloquea el reconcile
incluso con `--dry-run --prune`. ⚪R4 letra (`--rekey` no dice cuál alias borrar; conteo 43/42).
Decisiones:
- R1: `scopeSpellings` adopta `isNonCanonicalUuid` (misma regla en roles y relaciones); sonda `misdashed` en el caso
  3b-2h 🟠 3; corregir «Roles: no aplica» en informe y CLAUDE.md. Es L1/gemelos: cuarta línea de cierre obligatoria.
- R3: la receta tiene TRES ramas: por defecto = SOLO listado + conteos (con gemelo canónico / sin gemelo), sin
  escribir; `--delete` = borra lo no canónico (fail-closed, para uuids mal escritos); `--rekey` = re-clava (para ids
  32-hex que nunca fueron uuid). README nombra las dos poblaciones y cuál rama es la suya; ninguna rama escribe sin
  bandera explícita.
- R2: una tupla del destino fuera de la gramática se clasifica como `extra` con motivo (`invalid-identity`), `--prune`
  la borra, `--dry-run` la lista; nunca 422 por dato del backend.
- R4: letra de `--rekey` (nombra el alias que sobra) y conteos del informe corregidos.
**Cierre-2 del lote A entregado** (1670/1698/1795/1797 según implementador). Pregunta abierta R2 (¿`--prune` borra
también la tupla del destino fuera de gramática relajando el `unrelate` del driver?): decisión del coordinador = NO en
este lote; se lista con línea exacta y exit 1 (fail-closed, sin tocar el contrato R-16 del puerto); «lo que el driver
enumera, su `unrelate` lo borra» ⇒ roadmap 2.6 como decisión de contrato.

## 2026-10-15 (3) — repaso del cierre-2 del lote A (roles): 0 🔴/🟠, 1 🟡 ampliado, 2 ⚪ ⇒ cierre-3 (coordinador)

`loteA-auditor-cierre2.md`: 🟡 `isNonCanonicalUuid` cubre formas que PG NO funde (`-<32hex>`, `a0e-ebc99…`, `--`), y
`scopeSpellings` ahora las expande a la canónica ⇒ con ids de texto elegibles por el usuario, una purga SIN cadena
(`detached` sin `within`, `revoke`/`removeDeny` con cadena null) puede alcanzar un scope VIVO de otro tenant (clase
preexistente desde 3b-2h con 32 hex; el cierre-2 la amplía). ⚪ docblocks falsos («TODAS las formas que PG funde»,
«Quitar nunca concede»); ⚪ R2 dry-run sugiere que la pasada real lo arreglará y no lo hará.
Decisiones: (1) DOS reglas con nombre: `pgFusedSpellings` (solo guiones alineados a grupos de 4 = lo que PG funde de
verdad, documentado) para `scopeSpellings` de roles; `isNonCanonicalUuid` (ancha) para el 422 de particiones — el
espíritu de «una función» era una REGLA por propósito, y aquí hay dos propósitos (fundir ↔ rechazar). (2) Estructural:
en el fan-out sin cadena, se DESCARTA toda ortografía que el resolutor reconozca como scope vivo (cierra también el
caso 32 hex preexistente). Caso por cada una + mutante; docblocks corregidos; letra del dry-run de R2 («no lo arreglará
la pasada real: bórrala a mano»). Es cierre-3 del lote A; sin nueva auditoría salvo mi verificación.


## 2026-10-15 (4) — respuesta de COGNITIV al plan 2.5 (`cognitiv-respuesta-plan25-2026-10-15.md`; análisis en `cognitiv-respuesta-plan25-analisis.md`)

Aceptan plan y calendario; las 13 respuestas confirman D3–D16 (versión fijada exacta; 0/65 tuplas no canónicas en desarrollo,
producción pendiente; `requireTransaction: true` ya en uso; usersets solo `group#member`; `includes` lineales; `truncated` ⇒ 503
en su evaluador; `OPENFGA_MODEL_ID` obligatorio en alpha.3 = D14; deny solo en `tenancy_node`; `decideMany` con las garantías de
`checkMany`). Lote B: solo les toca B7. Tres peticiones: **P-1 `purgePartition`** (operación nueva del puerto, gemela de
`purgeScope`; recomendación del coordinador: panel + lote C como capacidad opcional D15; alternativa 2.6) · **P-2** caso nombrado
«decideMany para un holder de otra partición» ⇒ lote D (ya cierto por construcción) · **P-3** `truncated` en `listObjectsForSubject`
⇒ lote C (cubierto por la propiedad universal de B4). Borrador de respuesta: `plan25-respuesta2-cognitiv.md`.
**PENDIENTE DEL DUEÑO: ¿P-1 en el lote C (alpha.4) o en 2.6?** y enviar el borrador.


## 2026-10-15 (5) — lote B (⇒ `2.5.0-alpha.2`): decisiones del coordinador y pendientes del dueño

Cadena: implementador (`loteB-informe.md`, B1–B9) → auditor APTA con cambios 2🟠/6🟡/6⚪ (`loteB-auditor.md`) → cierre 1
(`loteB-cierre-coordinador.md`, `loteB-informe-cierre.md`) → re-ataque 1🟠 N1/3🟡/4⚪ (`loteB-auditor-cierre.md`) → cierre 2
(`loteB-cierre2-coordinador.md`, `loteB-informe-cierre2.md`) → repaso final 1🟠 N9/3⚪ (`loteB-auditor-cierre2.md`) → cierre 3
(`loteB-cierre3-coordinador.md`, `loteB-informe-cierre3.md`) → repaso corto (`loteB-auditor-cierre3.md`).
**Decisiones del coordinador (sin cambio de alcance, dentro de D7/D11/D13/D15 ya firmadas):** (1) decisión 4 del implementador
RECHAZADA: el plan del reconcile clasifica, el driver solo rechaza; (2) una regla por FILA del destino: toda fila que ningún driver del
paquete borra (`invalid-identity`, `userset-unsupported`, `undeclared`) se lista con `pruned: false`, exit ≠ 0 en los 4 modos y
receta, jamás un throw ni un DELETE de plataforma (extiende la regla del lote A); (3) `Infinity` retirado de `listObjectsDeadlineMs`:
la opción es «el corte EFECTIVO del servidor» (menor de `--listObjects-deadline` ≠ 0, `--request-timeout`, `--http-upstream-timeout`),
entero > 0 y ≤ `timeoutMs` del cliente, si no 500; los dos a 0 = límite declarado, no soportado; (4) guardia de TIPO en compilación
para las listas blancas de config (sin exención); (5) la receta SQL del residuo B3 se ejecuta en `upgrade_recipe.spec` (3 motores);
(6) CLAUDE.md punto 7 precisado: «exit propio» = ≠ 0, la rama se identifica por un prefijo ESTABLE de la línea.
**Precio declarado para consumidores (README §Upgrading):** `timeoutMs < 3000` sin `listObjectsDeadlineMs` ⇒ 500 al construir el
driver openfga (la señal tendría que saltar después de que el cliente corte); pool max 1 (default de knex en todo SQLite) ⇒
`requireTransaction: false` explícito.
**Decisión del dueño 2026-10-15 (6): `purgePartition` ENTRA EN EL LOTE C** (⇒ 2.5.0-alpha.4) como capacidad opcional (D15), con panel
propio dentro del de C (gemelo `purgeScope`, prueba de cero, lotes de deletes en FGA, estados de operación larga —punto 8—).
**Decisión del dueño 2026-10-15 (7): L9 PROMOVIDO** — «clasificación en el punto equivocado» (el driver absorbe lo que el plan debía
clasificar) es linaje con 3 apariciones (R2-5, decisión 4 del lote B, N9 del cierre 3). Propiedad universal: «el PLAN del reconcile
clasifica toda tupla por su motivo ANTES del driver; el driver solo rechaza; ningún catch convierte un 422 en otro bucket». Guardia:
test por reflexión sobre las clases de error 422 del puerto de relaciones que exige clasificador en el plan con bucket + `details`
para cada una (un error nuevo nace rojo con su nombre). **Entra en el lote D** (donde el reconcile se reescribe para el deny).
**PENDIENTE DEL DUEÑO:** (b) las cuatro guardias propuestas tras el análisis de patrones
(paridad guardia ↔ runner; grep `?? []` sobre respuestas del SDK; quinta línea de cierre «residuo persistido»; «no aplica» solo
con evidencia pegada) — ¿entran en CLAUDE.md / lote D?


## 2026-10-15 (8) — L10 PROMOVIDO (decisión del dueño)

«Purga/migración multi-request: el estado intermedio concede» es linaje L10 con 4 iteraciones (3b-2f R3, 3b-6 P1 🔴, D1 🟠 1
purga de `openfga`, D2 🟠 1 reconcile). **Propiedad universal**: ningún estado intermedio de una operación que escribe o borra
relaciones en más de una petición concede algo que no concedían ni el estado inicial ni el final. **Punto de paso único**:
`src/relations/tuple_order.ts` (orden de escritura denies → membresías que transportan deny → resto de membresías → allows; borrado
al revés), usado por la purga de `openfga` y por el reconcile; toda operación nueva multi-request de relaciones pasa por él.
**Guardia**: propiedades `openfga.purge.order` y `relations.reconcile.order` de la guardia de superficie, juzgando la función con el
orden de enumeración del origen invertido, con mutantes en el corredor publicado. Gemelo de roles: `purgeScope` (`openfga.roles.
purgeScope.order`, fijado en D2).

## 2026-10-15 (9) — renovación de una membresía que transporta un deny en `openfga`: RECHAZAR (decisión del dueño)

Re-ataque del cierre 1 de D2, 🟠 N1 (L10, 5.ª aparición): `relate` de `openfga` renueva con dos `Write` (M5) y una membresía de un grupo
con deny vivo desaparece en el hueco (concede; si el 2.º `Write` falla, para siempre). Opciones: rechazar / permitir y declarar /
prohibir caducidad en membresías. **El dueño elige RECHAZAR**: 409 con receta y cero escrituras cuando el grupo es sujeto de algún deny
vivo; el resto de renovaciones sigue, con parcial + evento si el 2.º `Write` falla.

## §2026-10-16 (10) — D2: opción A (negar), B al backlog
Tras el panel «paquete óptimo» (`panel-optimo-*.md`; juez: B 75 / A 60,5 / C 37,5 CON la condición «si COGNITIV no renueva membresías con caducidad en grupos con deny, el camino pasa a A») y la respuesta de COGNITIV del 15-10 (deny solo sobre holder directo, nunca sobre `group`; sin deny temporal en v1; producción con `database`), el dueño decide **A**: en `openfga`, cambiar la caducidad de una membresía que transporta un deny es 409 sin escrituras; en el reconcile la PARTICIÓN afectada recibe cero escrituras con receta (el resto migra); fuera la retención del cierre 4. **B** (ranura `member_alt` + espera G) queda en `backlog-2.6.md`. Razón: el arreglo futuro, cuando OpenFGA resuelva openfga/openfga#2151 (upsert), es más pequeño desde A (renovar con upsert y `atomicRenewal: true`, sin tocar el modelo) que desde B (habría que retirar `member_alt`). El dueño publicó un comentario con la reproducción en #2151 el 2026-10-16.
