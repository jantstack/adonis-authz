# L-4 · `{transaction}` REAL en el driver `database`, puerto de RELACIONES — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `d9b9a13` (= L-3 commiteado, árbol limpio al empezar; `git status` vacío). Árbol principal, SIN
> commits (los hace el dueño). Alcance: el lote L-4 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-4).
> Regla que gobierna (la misma de L-3): **la ESCRITURA va por tu transacción; la AUTORIDAD (freeze, F-05,
> `resolveChain`, partición) NUNCA.** Decisión del dueño: `{ transaction }` exige **pool ≥ 2** (casos gateados a
> `sqlite-file`/PG/MySQL; `:memory:` declara `false` y fija la cara de pool 1).

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l4-rojo-*.log`, `l4-verde-*.log`, `l4-mutante-*.log`, `suite-*.log`).

(Informe INCREMENTAL: se completa pieza a pieza según avanza el lote.)

## Plan de piezas (escrito antes de tocar código)

1. **Driver + runner**: `DatabaseRelationsDriver.relate/unrelate/purgeObject/purgeSubject` escriben por la
   transacción del llamante (`#writer(op, options)` con `assertCallerTransaction` contra la conexión del driver —la
   declarada en `options.connection` o la primaria de Lucid—); `transactionalWrites: true` (default) con la opción
   `DatabaseRelationsDriverOptions.transactionalWrites` para pool 1, como L-3; `#poisoned(op, error)` dentro de la
   trx externa (UNIQUE ⇒ 409, deadlock ⇒ lo que se mida); la cara `whenTrue` de `runRelationsDriverContract`
   (rollback ⇒ `check` sin cambio Y CENSO cero para las cuatro; commit ⇒ aplicado; trx ajena/`db` entero ⇒ 500
   `E_AUTHZ_CONFIG` con cero sentencias) con el hook `transactions` del harness (default Lucid + `authz_relations`).
   Rojo con el driver declarando `true` y escribiendo por su conexión, ANTES del writer. Mutante obligatorio: reabrir
   la transacción interna con la externa presente.
2. **Casos de motor** (`tests/relations_database.spec.ts`, grupo gateado a pool ≥ 2): el trigger de partición
   DENTRO de la trx del llamante; `assertWrite`/F-05/freeze que lanzan ⇒ cero sentencias por la trx; caducidad × trx
   (renovar = delete+insert dentro de la trx; rollback devuelve la caducidad anterior, por censo con `expires_at` y
   `uuid`); choque del UNIQUE de dos `relate` en dos trx externas (medido por motor); **deadlock A→B / B→A** (medido
   por motor); `transactionalWrites: false` declarado; y la cara de `:memory:` (pool 1 ⇒ 503 por la barrera, cero
   sentencias por la trx) en los cuatro modos.
3. **Harness y conteos**: `relations_database.spec.ts` declara `true` en pool ≥ 2 y `false` en `:memory:`;
   `relations_harness.spec.ts` re-anclado (la cara `true` ya registra; el total no se mueve); `openfga` `false`
   explícito (ya lo era); comentarios «hasta L-4» de los dobles actualizados.
4. Docs: README (sección de relaciones + tabla de capacidades + errores), CHANGELOG (sección L-4 antes de L-3),
   docblocks de `types.ts`.

## Pieza 1 · La escritura va por tu transacción (driver) y la cara `whenTrue` del runner ✅

**Código:**
- `src/drivers/database_relations_driver.ts`:
  - `capabilities.transactionalWrites` pasa a **`true`** (default), construida en el constructor a partir de la
    opción nueva **`DatabaseRelationsDriverOptions.transactionalWrites?: boolean`** (default `true`; un despliegue
    con pool 1 declara `false`, como en L-3). `withClock` la propaga a la vista. Con `false` declarado, un
    `{ transaction }` que llegue igual al driver (saltándose el manager) es 500 `E_AUTHZ_UNSUPPORTED` («pool 1»).
  - **`#writer(operation, options)`**: `assertCallerTransaction('database-relations.<op>', options.transaction,
    { connection: this.#connectionName ?? db.primaryConnectionName })` ⇒ `{ client: trx, external: true }` o
    `{ client: this.#connection(), external: false }`. Lo usan `relate` (el «¿ya existe?», el DELETE de la renovación
    y el INSERT), `unrelate`, `purgeObject` y `purgeSubject` (los DELETE). **Con transacción externa `relate` NO
    abre la interna de 4-3**: el check-then-delete-insert corre tal cual sobre la trx del llamante (el trigger de
    partición dispara en ESE INSERT); sin ella, la interna sigue (atomicidad trigger+insert). Cada sentencia lleva
    ahora su deadline (`#sql('relate.select' | 'relate.delete' | 'relate.insert')`), también dentro de la interna
    (antes el `#sql('relate')` envolvía la transacción entera y el `timeout` de knex no se aplicaba a nada).
  - **`#poisoned(operation, error)`**: dentro de la trx externa un fallo no se relee: choque del UNIQUE ⇒ **409
    `E_AUTHZ_WRITE_CONFLICT`**; **deadlock ⇒ 409 `E_AUTHZ_WRITE_CONFLICT`** (nuevo `isDeadlock` en
    `src/shared/backend_guard.ts`: PG `40P01`/`40001`, MySQL `errno 1213`); deadline ⇒ el 503 de `#sql`; otro ⇒
    su 503. Las cuatro escrituras lo aplican solo con `external`.
  - `purgeObject`/`purgeSubject` reciben `options?: RelationTransactionOptions` (el puerto ya lo declaraba, L-2).
- `src/testing/relations_contract.ts`: **`RelationsDriverContractHarness.transactions?: RelationsContractTransactions`**
  (`begin()` ⇒ `{ client, commit, rollback }` y `census(partition)` ⇒ nº de tuplas de la partición), default
  **`lucidRelationsContractTransactions()`** (`db.transaction()` + `authz_relations`; exportado desde `/testing`). La
  cara **`whenTrue`** del par `transactionalWrites` (título `transactionalWrites:true · relate/unrelate/purgeObject/
  purgeSubject con { transaction } + rollback ⇒ check sin cambio Y CERO tuplas nuevas (censo); + commit ⇒ aplicado;
  purge* borran y revierten JUNTOS; …`): para cada una de las cuatro, rollback ⇒ censo intacto + `check` sin
  cambio + mientras la trx está abierta la autoridad (por la conexión del motor) no ve la escritura; commit ⇒ censo
  y `check` cambian; `purgeObject` sobre un objeto con dos sujetos (y otro objeto de control) y `purgeSubject`
  sobre un sujeto con dos objetos (y otro sujeto de control) revierten JUNTOS (censo 3 tras el rollback) y aplican
  juntos (censo 1 tras el commit, el control intacto). Y tres transacciones que no son la del driver (otra
  `connectionName`, `isTransaction: false`, el `db` entero) ⇒ 500 `E_AUTHZ_CONFIG` nombrando la operación, con un
  espía = `[]` y, además, la comprobación de que la trx ajena la juzga el DRIVER (el espía de escrituras del runner
  sube: la puerta 1 dejó pasar). El rollback va en `finally` (lección de L-3). El helper `test` del runner devuelve
  ahora lo que devuelve `api.test` (para `.timeout(30_000)`); el conteo no cambia.
- `tests/relations_database.spec.ts`: `TRANSACTIONAL_WRITES = testEngine() !== 'sqlite'`; el harness lo declara y
  construye el driver con `{ transactionalWrites: TRANSACTIONAL_WRITES }`.

**Rojo literal** (`l4-rojo-censo-sqlite-file.log`; el driver declaraba `true` y `relate` seguía abriendo su
transacción interna por su conexión):
```
ℹ AssertionError: ROJO: la relación sobrevivió al rollback (la escritura NO fue por la transacción del llamante): expected 1 to equal +0
Tests  35 passed, 1 failed (36)
```
**Verde**: `l4-verde-censo-{sqlite-file,pg,mysql}.log` — «Tests 36 passed (36)» en los tres motores.

**MUTANTE OBLIGATORIO** (`l4-mutante-trx-interna-sqlite-file.log`): con la transacción externa presente, `relate`
reabre la INTERNA (`this.#connection().transaction(write)`) en vez de escribir por `client` ⇒ **1 failed**,
exactamente el rojo de arriba (la fila confirmó sola en la interna y sobrevivió al rollback del llamante).
Restaurado desde copia; `grep -c MUTANT` = 0.

## Pieza 2 · Los casos de motor (`tests/relations_database.spec.ts`, grupo «L-4 · … pool ≥ 2») ✅ — y un HALLAZGO del esquema

**El hallazgo, antes que nada (medido en PG y MySQL en la primera corrida, `l4-motor-{pg,mysql}.log` de entonces:
`ROJO: el segundo relate «entró» sobre una tupla que ya escribió otra transacción` y `ROJO: … ENTRÓ: no hubo
deadlock`).** El UNIQUE publicado de `authz_relations` (`authz_rel_tuple_uq`, en `stubs/migration.stub` y en el
espejo) incluye `subject_relation`, que es **`NULL` para un HOLDER**, y en los tres motores dos `NULL` son DISTINTOS en
un índice único. Consecuencia: **el UNIQUE solo defiende las tuplas con USERSET**; dos `relate` concurrentes del mismo
hecho de holder en dos transacciones (el «¿ya existe?» de cada una no ve a la otra) ENTRAN los dos, sin espera, sin
choque y sin deadlock, y confirman **DOS filas iguales**. No es de L-4 (viene de 4-3) y L-4 no lo introduce: lo que L-4
hace es volverlo OBSERVABLE (antes la interna de `relate` era tan corta que la carrera era casi imposible de provocar).
No concede de más (`check` es el mismo `true`; `unrelate`/`purge*` borran las dos por su WHERE), pero rompe la
idempotencia del invariante 6 bajo concurrencia y `listSubjects`/`enumerateRelations` emiten el sujeto DOS veces
(reconcile lo migraría dos veces). **No lo corregí: es un cambio de ESQUEMA publicado** —`subject_relation NOT NULL
DEFAULT ''` (y tocar todos los `IS NULL`/`COALESCE` del driver), o un índice parcial `WHERE subject_relation IS NULL`
(PG y SQLite lo tienen; **MySQL no**: habría que ir por una columna generada), o `UNIQUE NULLS NOT DISTINCT` (solo PG
15+)— con receta `ALTER` para quien ya migró la alpha.1/alpha.2, y eso es decisión del dueño. Lo dejé **medido y
fijado con un caso** (título `HALLAZGO · el UNIQUE de authz_relations NO cubre subject_relation NULL …`: PG/MySQL dos
filas y `listSubjects` ×2; `sqlite-file` el segundo es `SQLITE_BUSY`), y los casos del UNIQUE y del deadlock usan un
sujeto USERSET (`group:g#member`), que es donde el UNIQUE muerde de verdad. Con un holder no hay espera ni deadlock
posible: no hay nada por lo que esperar.

**Casos (7 en pool ≥ 2 + 2 en los cuatro modos; verde en `l4-motor-{sqlite,sqlite-file,pg,mysql}.log`: 38 / 45 / 45 /
45 en `relations_database.spec.ts`):**

1. **El trigger de partición dispara DENTRO de la trx del llamante**: `relate` legítimo por la trx (visible por ella
   antes de confirmar: 1 fila), una fila con userset de OTRA partición insertada a mano POR LA MISMA trx ⇒ el motor la
   rechaza con el mensaje del trigger (`userset no puede pertenecer a otra partición`) en los tres motores. Lo que queda
   de la trx, medido: **PG la deja ABORTADA** —el siguiente `relate` del paquete por esa trx es **503
   `E_AUTHZ_BACKEND_UNAVAILABLE` CLASIFICADO con causa `25P02`**, nunca el error crudo—; **MySQL y SQLite la dejan viva**
   y el siguiente `relate` entra. Rollback ⇒ cero filas (ni la legítima ni la envenenada). Nota honesta: el DRIVER no
   puede producir una fila cross-partición (`#subjectColumns` materializa `subject_partition = partition_key`
   siempre), así que la fila envenenada la inserta el consumidor con `trx.table(...)` —el «caso de driver con
   `knex.raw`» de 4-3, ahora dentro de la trx externa—; lo que es del paquete y se clasifica es lo que viene después.
2. **`assertWrite` / F-05 / freeze que lanzan ⇒ CERO sentencias por la trx** (espía Proxy sobre el `trx` real que
   cuenta `from/table/query/raw/transaction/…`): F-05 por el manager (422 `E_AUTHZ_RELATION_TYPE_UNKNOWN`) y por el
   driver directo, relación no declarada en `unrelate` (422 `E_AUTHZ_RELATION_UNKNOWN`), `assertWrite` que rechaza
   `owner`, y con el freeze durable puesto por el manager de ROLES las CUATRO con `{ transaction }` ⇒ 503
   `E_AUTHZ_FROZEN` reintentable; `spy.statements() === 0` en todos. Tras el `unfreeze`, la MISMA llamada entra POR la
   trx (>0 sentencias), la conexión del motor no la ve hasta el commit, y al confirmar `check` es `true`.
3. **Caducidad × trx** (R-15 cruzada con L-4): `relate` con `T1` confirmado (fila `uuid0`); dentro de la trx `relate`
   con `T2` ⇒ por la trx UNA fila con OTRO uuid y `T2` (delete+insert dentro de la trx), por la conexión del motor
   sigue `uuid0`/`T1`; **rollback ⇒ el censo tiene `uuid0` con `T1`** (la caducidad anterior está de vuelta, no la
   nueva); commit ⇒ fila nueva con `T2`. Verde en los tres motores (MySQL al milisegundo por el codec).
4. **`transactionalWrites: false` declarado** (pool 1): puerta 1 ⇒ 500 nombrando `transactionalWrites` y `'database'`,
   y saltándose el manager (`driver.relate`/`driver.purgeObject` directos) el driver también responde 500 («pool 1»);
   0 sentencias; sin `transaction` entra.
5. **Choque del UNIQUE de dos `relate` (userset) en dos trx externas** — T1 inserta sin confirmar, T2 inserta lo mismo,
   300 ms, T1 confirma. **Medido por motor (dos tiradas en PG/MySQL, `l4-medida-*.log`):**

   | motor | qué hace el INSERT de T2 | error de T2 | ¿T2 viva después? | tiempo |
   |---|---|---|---|---|
   | **PG** | ESPERA en el índice único hasta que T1 confirma; `23505` | **409 `E_AUTHZ_WRITE_CONFLICT`** | **NO: abortada** (`25P02`) | 311 / 315 ms |
   | **MySQL** | ESPERA (S-lock del duplicado) hasta que T1 confirma; `1062` | **409 `E_AUTHZ_WRITE_CONFLICT`** | **SÍ** | 312 / 309 ms |
   | **sqlite-file (WAL)** | NO espera: `SQLITE_BUSY` inmediato (T2 ya tiene snapshot de lectura por el «¿ya existe?» y no sube a escritora) | **503 `E_AUTHZ_BACKEND_UNAVAILABLE`** | SÍ | 302 ms |

   Un solo evento `onRelationWrite` (el de T1); censo = la fila de T1. Mismo comportamiento que en roles (L-3), ahora
   medido sobre `authz_relations` y su UNIQUE de 7 columnas.
6. **DEADLOCK A→B / B→A** (cierra el ❓ 🟡 12 del auditor): T1 escribe `docA`, T2 `docB`; después, a la vez, T1 pide
   `docB` y T2 `docA` (sujeto userset). **Medido por motor:**

   | motor | detección | quién se resuelve primero | error del perdedor | código crudo (cadena de causas) | qué queda de la víctima | tiempo |
   |---|---|---|---|---|---|---|
   | **PG** | tras `deadlock_timeout` (1 s por defecto) | la VÍCTIMA (el ganador sigue esperando sus locks hasta el rollback de la víctima) | **409 `E_AUTHZ_WRITE_CONFLICT`** («DEADLOCK … haz rollback y reintenta») | `40P01` (bajo el 503 de `#sql`) | **ABORTADA** (`25P02`) hasta el rollback | 1012 / 1014 ms |
   | **MySQL** | al instante (InnoDB) | el GANADOR (InnoDB deshace a la víctima al instante y el ganador se libera antes de que el rechazo llegue al event loop) | **409 `E_AUTHZ_WRITE_CONFLICT`** | `errno 1213` | InnoDB deshizo la transacción **ENTERA** de la víctima: su PRIMERA fila (`docA`/`docB`) ya no está ni por su propia conexión (0 filas) | 5 / 12 ms |
   | **sqlite-file** | no hay deadlock posible: T1 sostiene el lock RESERVED | — | el segundo escritor es **503 `E_AUTHZ_BACKEND_UNAVAILABLE`** (`SQLITE_BUSY`) ya en su PRIMERA escritura | `SQLITE_BUSY` | viva | — |

   El caso acepta los DOS órdenes de resolución (es del motor) y no acepta que entren los dos. Tras el rollback de la
   víctima el ganador entra y confirma sus DOS filas (censo = `docA` + `docB`). **Decisión de clasificación: 409, no
   503**: el backend RESPONDIÓ (eligió una víctima y lo dijo), la escritura chocó con otra transacción y la salida es
   «rollback y reintenta» — exactamente la letra de `E_AUTHZ_WRITE_CONFLICT` (invariante 6: «el choque de dos
   escrituras a la vez no es una caída del backend»). Sin `isDeadlock` sería un 503 `E_AUTHZ_BACKEND_UNAVAILABLE` con
   el mensaje «no respondió», que es falso.
7. **HALLAZGO del holder** (arriba): PG/MySQL dos filas y `listSubjects` ×2; sqlite-file `SQLITE_BUSY`; `check` el mismo
   `true`; `unrelate` borra las dos.
8. **(cuatro modos)** El driver declara `true` por defecto, `false` con la opción, y la vista `withClock` declara lo
   MISMO.
9. **(cuatro modos) La cara de `:memory:`**: `freezeTimeoutMs: 400`, el llamante sostiene la única conexión, `relate`
   con `{ transaction: spy(trx) }` y el driver declarando `true` ⇒ en `:memory:` 503 `E_AUTHZ_BACKEND_TIMEOUT` por la
   barrera (SU deadline, no los 60 s del pool), **0 sentencias por la trx**, censo 0, sin evento; en pool ≥ 2 la misma
   escritura entra POR la trx (>0 sentencias) y confirma con ella.

**Mutante de `isDeadlock`** (`l4-mutante-deadlock-{pg,mysql}.log`: `#poisoned` no clasifica el deadlock) ⇒ **1 failed**
en cada motor:
```
ℹ AssertionError: pg: el deadlock es 409 clasificado (El backend de autorización 'database-relations' no respondió (relate.insert)): expected 'E_AUTHZ_BACKEND_UNAVAILABLE' to equal 'E_AUTHZ_WRITE_CONFLICT'
Tests  44 passed, 1 failed (45)
```
(el mismo con `mysql:`). Restaurado; `MUTANT` = 0.

**Corrección a mitad, dicha:** la primera versión del caso del deadlock daba por hecho que la VÍCTIMA se resuelve
primero (así es en PG) y en MySQL fallaba con `ROJO: el primero en resolverse (t1) ENTRÓ` — no porque no hubiera
deadlock (lo había: `1213`), sino porque InnoDB deshace a la víctima al instante y el ganador se resolvió antes. El caso
acepta ahora los dos órdenes y lee el código crudo en la cadena de causas (`409 ← 503 de #sql ← pg/mysql2`), no en
`error.cause.code` directo.

## Pieza 3 · Harness, conteos y comentarios ✅

- `tests/relations_harness.spec.ts`: el caso L-2 pasa a «L-2/L-4»: `transactionalWrites: true` ya NO se rechaza al
  registrar; registra la cara `true` (título `transactionalWrites:true · … (censo) … JUNTOS … E_AUTHZ_CONFIG`) en FULL
  y en MÍNIMO, la `false` no, y **el total no se mueve** (`EXPECTED_CASES = 20`, `covered.size = 8`): el par es UN
  caso por cara. `l4-verde-harness-sqlite.log`: 77/77 (`relations_harness` + `relations_contract` + `relations` +
  `relations_service`).
- Los dobles siguen declarando `false` (`relations_contract.spec`, `relations_harness.spec`, `relations_service.spec`,
  `relations_design_cases.spec`, `relations.spec`, `relations_reconcile.spec`, `freeze.spec`): un doble en memoria no
  escribe en ninguna transacción, así que se le juzga esa cara; el comentario «L-2: `false` hasta L-4» de los siete
  pasa a decirlo. `relations_openfga.spec` fija `false` EXPLÍCITO con su porqué (no puede ser otra cosa; L-5 es el
  rechazo con dientes contra el `:8101`).
- Docblock de `RelationsDriverCapabilities.transactionalWrites` (`types.ts`) reescrito («`database` = true desde L-4»;
  ya no dice «hasta L-4 los dos declaran false»).

## Cómo quedó el harness `database` de relaciones (true/false por motor)

| modo | harness `database (<motor>)` | driver | cara juzgada |
|---|---|---|---|
| `:memory:` (pool 1/1) | `transactionalWrites: false` | `new DatabaseRelationsDriver(config, { transactionalWrites: false })` — lo que un despliegue con pool 1 declara | `whenFalse` (500 al instante, cero llamadas; puerta 2) + la cara honesta de pool 1 en el grupo L-4 de `relations_database.spec.ts` (503 por la barrera, cero sentencias por la trx) |
| `sqlite-file`, PG, MySQL | `transactionalWrites: true` | default (`true`) | `whenTrue` (rollback ⇒ censo cero ×4, commit, invisible sin confirmar, purge* revierten juntos, trx ajena ⇒ 500 sin sentencia) |
| `openfga` (`relations_openfga.spec`) | `transactionalWrites: false` explícito | `false` | `whenFalse` |
| dobles (`full`, `mínimo`, …) | `transactionalWrites: false` | doble en memoria | `whenFalse` |

## Pieza 4 · Docs ✅

- **README**: párrafo nuevo **«Writing relations inside your transaction (2.4.0-alpha.2, lot L-4)»** en la sección
  Relations (la regla, la guarda, pool ≥ 2 y la opción, el trigger dentro de tu trx y lo que queda por motor, la
  caducidad que vuelve con el rollback, el censo del runner y el hook `transactions`, el UNIQUE por motor, el
  deadlock como 409 con lo que hace cada motor, y **el límite del esquema** —el UNIQUE no cubre `subject_relation
  NULL`— dicho en voz alta); «Still not in 2.4» deja de listar `{trx}` en `relate`/`unrelate`; la fila
  `transactionalWrites` de la tabla de capacidades gana el driver de relaciones y su opción; la entrada
  `E_AUTHZ_WRITE_CONFLICT` gana el deadlock (`40P01`/`1213`) y las relaciones; la sección de L-3 enlaza a la de
  relaciones.
- **CHANGELOG** (`[Unreleased] — 2.4.0-alpha.2`, sección «Lot L-4» ANTES de L-3): problema → decisión → lo específico de
  tuplas medido por motor (trigger, caducidad, UNIQUE, deadlock con su clasificación y su mutante, pool ≥ 2, la cara
  `true` del runner y el hook) → **el hallazgo del esquema** con sus tres salidas posibles → **qué NO se hace**.
- Docblocks: `DatabaseRelationsDriverOptions.transactionalWrites`, `#writer`/`#poisoned`, las capacidades del driver,
  `RelationsDriverContractHarness.transactions`, `isDeadlock`.

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, corridas a fichero)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ · `npm run build` ✔
(`l4-build.log`, exit 0).

| modo | base (L-3) | ahora | delta | log |
|---|---|---|---|---|
| `npm test` (SQLite memoria) | 1047 | **1049 passed (1049)** | +2 | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1061 | **1070 passed (1070)** | +9 | `suite-sqlite-file.log` |
| `npm run test:pg` | 1156 | **1165 passed (1165)** | +9 | `suite-pg.log` |
| `npm run test:mysql` | 1156 | **1165 passed (1165)** | +9 | `suite-mysql.log` |

+2 en los cuatro modos (el literal de capacidades del driver de relaciones y la cara de pool 1 de
`relations_database.spec.ts`); +7 más en los motores con pool ≥ 2 (el grupo gateado: trigger, autoridad ⇒ 0
sentencias, caducidad × trx, `false` declarado, UNIQUE, deadlock, hallazgo del holder). El harness `database` de
relaciones cambia de cara (`whenFalse` → `whenTrue`) en pool ≥ 2 sin mover la cuenta; el caso de
`relations_harness.spec` cambia de contenido sin cambiar de número. Aditivo: ningún caso existente cambió de resultado.
Cero rojas transitorias en las cuatro corridas finales: las cuatro suites completas corrieron verdes a la primera
(las rojas de este lote fueron las del rojo→verde y las de la medición del deadlock, dichas arriba). Stores del
`:8101` al terminar: `{"stores":[]}`. `grep -rc MUTANT src tests` = 0. `git status`: 16 ficheros modificados, ninguno
nuevo (el informe vive en `.claude/contexto/`, fuera de git).

## Ficheros tocados

- `src/drivers/database_relations_driver.ts` — opción `transactionalWrites` + capacidad construida en el constructor
  (y propagada por `withClock`), `#ownerConnection`, `#writer`, `#poisoned`, las cuatro escrituras por la trx del
  llamante (`relate` sin transacción interna cuando hay externa; deadline por sentencia), `options` en `purge*`.
- `src/shared/backend_guard.ts` — `isDeadlock`.
- `src/types.ts` — docblock de `RelationsDriverCapabilities.transactionalWrites`.
- `src/testing/relations_contract.ts` — `RelationsContractTransactions`, `lucidRelationsContractTransactions`,
  `harness.transactions`, la cara `whenTrue`, `test()` devuelve el handle. `src/testing/main.ts` — exporta los dos.
- Tests: `tests/relations_database.spec.ts` (harness `true`/`false` por motor + grupo L-4: 7 gateados + 2 en los
  cuatro modos), `tests/relations_harness.spec.ts` (la cara `true` registra; cuentas), comentarios en
  `relations_contract`, `relations_service`, `relations_design_cases`, `relations`, `relations_reconcile`, `freeze`,
  `relations_openfga`.
- `README.md`, `CHANGELOG.md`.

## Lo que NO hice, y por qué

- **No cerré el agujero del UNIQUE con `subject_relation NULL`** (el hallazgo de la pieza 2): es un cambio del esquema
  PUBLICADO con receta `ALTER` y con tres salidas posibles que no son equivalentes entre motores (MySQL no tiene índices
  parciales). Lo medí, lo fijé con un caso que describe el comportamiento de HOY y lo declaré en README y CHANGELOG;
  la decisión es del dueño. Si se decide, lo más portable es `subject_relation NOT NULL DEFAULT ''` + tocar los
  `IS NULL`/`COALESCE(…, '')` del driver (la CTE ya compara con `COALESCE`, así que las lecturas casi no cambian).
- **El trigger no lo dispara el DRIVER** (caso 1): el driver materializa `subject_partition = partition_key` siempre,
  así que no puede producir una fila cross-partición; lo que el caso demuestra es que el trigger dispara DENTRO de la
  trx externa (sobre la fila que inserta el consumidor por ella) y que lo que viene después es clasificado por motor.
- **No hay caso de COMPOSICIÓN con tabla del consumidor** para relaciones (L-3 lo tiene para roles): el mecanismo es el
  mismo (`db.transaction` + escritura del paquete + escritura propia + rollback) y el censo cubre la mitad del paquete.
- **No toqué `openfga`** (L-5) ni el driver de roles (L-3 cerrado). **No toqué `CLAUDE.md`** (si el dueño quiere, la
  fila de `database_relations_driver.ts` del mapa no existe hoy: la del driver de relaciones vive en el bloque de
  `src/relations/`; el CHANGELOG lleva el detalle).
- **No apliqué `isDeadlock` fuera de la trx externa**: un deadlock entre dos transacciones INTERNAS de `relate` sigue
  saliendo como 503 `E_AUTHZ_BACKEND_UNAVAILABLE` (como antes de L-4). Es raro (la interna dura tres sentencias) y
  reclasificarlo sin caso sería suponer; si el dueño lo quiere, es una línea en el camino no-externo con su caso.
- **No subí `version` en `package.json`** (sigue `2.4.0-alpha.1`): el release lo hace el dueño.

Nada del encargo resultó imposible. Lo que contradijo una premisa —«choque del UNIQUE de `authz_relations`» para un
holder— está medido, explicado y fijado, y los casos del UNIQUE y del deadlock se hicieron sobre lo que el UNIQUE sí
cubre (usersets).
