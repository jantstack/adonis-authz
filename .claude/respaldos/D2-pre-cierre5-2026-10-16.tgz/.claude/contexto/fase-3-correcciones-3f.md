# Fase 3 · Lote 3F — cierre (auditor 3E; tester por incorporar)

> Auditor sobre `5b4f3c2`: **APTA CON CORRECCIONES**, sin 🔴 y sin escalada nueva (el ensombrecimiento **no** concede de más: verificado). Lo que hay que arreglar son **dos regresiones que introdujo el propio 3E** (N2, N3), el residuo de la mina (N1) y cuatro frases. Sus scripts están en `…/scratchpad/v8/` (`n1_nivel.ts`, `n3_shadow.ts`, `n4_race.ts`, `n6_actor_sin_within.ts`, `n7_cotas.ts`).

## Respuestas a sus tres preguntas (decididas)

1. **¿`requireActor: true` debe impedir el `detached` de plataforma?** **No.** `scopes.detached` es la operación que limpia **después** de borrar un scope: bloquearla porque el scope ya no existe es contraproducente. Regla: si `resolveChain(scope) === null`, el `detached` **procede** (purga hechos y roles de ese owner) y **se salta la comprobación de rango**, porque el rol ya es invisible e inalcanzable y dejarlo bloquea el slug global para siempre. No abre escalada: si el scope **sí** resuelve, el rango se exige como hasta ahora. El evento lo dice (`reason: 'owner-detached-unknown'`).
2. **¿`descendantsOf` puede degradar en vez de fallar por encima de `maxDescendants`?** **Sí, siempre degradar, nunca tumbar la operación**: en `detached`, purgar el scope exacto y marcar el resultado como parcial (`truncated: true` en el evento y en el valor de retorno); en la comprobación de nivel de `defineScopedRole`, caer a la **regla mínima** (rechazar solo tipos de ancestros) en vez de 503. Declarar `descendantsOf` nunca puede dejarte peor que no declararlo.
3. **¿Un rol local de un tipo que el árbol no conoce debe exigir `descendantsOf`?** **No: se cierra por autoridad, que es la regla que ya tomamos para los globales.** *Una definición más autorizada gana y ensombrece a la menos autorizada*: global > local; y **local de un ancestro > local de un descendiente**. Así el dueño del árbol siempre puede definir su rol aunque un descendiente haya ocupado el nombre, y la mina solo se ensombrece a sí misma. Además el `diff` deja de contar como deriva los roles ensombrecidos por autoridad (los lista, exit 0).

## Bloqueantes

| # | Hallazgo | Decisión |
|---|---|---|
| **S1** 🟡 regresión | (N2) `scopes.detached` con `requireActor: true` sobre un scope **ya borrado** ⇒ 422 `UNKNOWN_SCOPE` y **no purga nada** (rol, asignaciones y denies sobreviven). En 3D funcionaba. | Respuesta 1. Casos: scope desconocido + `requireActor: true` ⇒ purga completa y evento con `reason`; scope **conocido** + actor de rango insuficiente ⇒ sigue 422 (no se abre la puerta de P3); scope desconocido sin `requireActor` ⇒ como hoy. |
| **S2** 🟡 regresión | (N3) Con `descendantsOf` declarado y subárbol > `maxDescendants`: `defineScopedRole` hacia abajo ⇒ 503 y `scopes.detached` ⇒ 503 **sin purgar nada** (peor que no declararlo). | Respuesta 2. Casos: org con más units que la cota ⇒ `define` de un rol de unit **acepta** (regla mínima) y `detached` purga el scope exacto con `truncated: true`; con subárbol por debajo de la cota, comportamiento fuerte de hoy. |
| **S3** 🟡 | (N1) La mina persiste para tipos que no son de un ancestro (inexistente o hermano): ocupa el nombre del dueño del árbol y deja `authz:catalog:diff` en rojo (gate de CI del deploy). | Respuesta 3: (a) `defineScopedRole` desde un **ancestro** del owner de un rol homónimo **no colisiona**: crea el suyo y el del descendiente queda ensombrecido (mismo trato que el global, reportado como `shadowedByAncestor`); (b) el `diff` no cuenta como deriva los roles ensombrecidos por autoridad — los lista y sale 0. Casos: la mina de `n1_nivel.ts` deja de bloquear a `orgA`, y `authz:catalog:diff` sale 0 con la mina puesta. |
| **S4** | (N4) El README dice «the tenant only hurts itself» y lo medido es que dentro de ese subárbol **la plataforma** pierde sus rutas por slug del rol global (5/5). | Corregir la frase en README y CHANGELOG: el ensombrecimiento inutiliza el acceso **por slug** a ese nombre dentro del subárbol **para todos**, incluida la plataforma; la forma que siempre funciona es `{ uuid }`. Caso que lo fija (hoy solo lo mide el auditor). |

## Obligatorias (rápidas)

| # | Qué |
|---|---|
| T1 | (N5) `listRoles` no distingue el local del global homónimo: una línea en el README junto a `shadowedByGlobal` y `shadowedByAncestor` diciendo que la forma sin ambigüedad es `{ uuid }` (o `listRoleRefs` si ya existe). |
| T2 | (N6) Junto a la capacidad `serializedCatalogWrites`: bajo contención del cerrojo el perdedor puede ser **503 `BACKEND_TIMEOUT`** en vez de 422, y 3E alargó la sección crítica del `sync` (`sync.role.locals` por rol + `sync.revalidate`), lo que lo hace más probable en un deploy grande. Documentarlo y, si es barato, sacar esas consultas fuera del cerrojo o hacerlas en lote. |
| T3 | (N7) README: un rol local creado con `database` y un despliegue que pasa a `openfga` deja el scope muerto; la salida (instanciar el driver `database`, purgar, y seguir) está probada por el auditor pero solo documentada para «filas escritas a mano». Escribirla. |
| T4 | (N7 ⚪) `hooks.onWrite` paga un `resolveChain` fresco + vista de catálogo por escritura: documentar el coste junto al hook. |
| T5 | CHANGELOG 2.2 "Lot 3F"; `CLAUDE.md` invariante 18 con la degradación de S2 y la regla de autoridad de S3. |

## Entrega
`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-3-lote-f-informe.md` incremental. Sin commits.
