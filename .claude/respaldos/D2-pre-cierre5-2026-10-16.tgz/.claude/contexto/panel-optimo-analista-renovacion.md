# Panel «paquete óptimo» — analista: causa raíz de la renovación no atómica en OpenFGA (2026-10-16)

Solo lectura sobre el repo. Escrito: este fichero y `.claude/reproducciones/panel-optimo-renovacion.ts`. Se ejecutó contra
`openfga-dev` en `:8090`: OpenFGA v1.19.0, datastore **postgres**, `--request-timeout` 3 s por defecto (`openfga run --help`).
Stores efímeros `panel-optimo-ren-*`; cada corrida termina con «restantes con prefijo 0». No hice docker restart, no corrí
gates y no toqué `src/`, `tests/`, README ni CHANGELOG. El modelo V0 sale del GENERADOR real (`openFgaFactsModel`), así que
no está reescrito a mano.

```
source ~/.config/nvm/nvm.sh && nvm use 22
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-renovacion.ts [fase…]
#   fases: names atom semantics rollout conc hammer grace stress size bench
#   env:   HAMMER_N, CONC_N, BENCH_N, BENCH_ONLY=V0,VA-member,…, CHECKERS
```

## Veredicto en una línea

**La hipótesis del coordinador es correcta a medias.**

- **Correcta:** la causa raíz es la clave idéntica, y una clave distinta para la tupla renovada (dos ranuras) resuelve la familia.
- **Falsa en una parte:** que «escribir la nueva y borrar la vieja en UN `Write`» baste para que nadie vea un estado intermedio.
  - Medido: con el swap en un solo `Write`, entre el **1,4 % y el 1,8 %** de los `Check` concurrentes CONCEDEN a un sujeto denegado.
  - El `Write` es atómico para los escritores, pero un `Check` no lee con una sola foto: hace una lectura de datastore por relación.
- **Lo que funciona:** *make-before-break* en DOS `Write`, con una gracia G entre «escribir la nueva» y «borrar la vieja».
  - Medido: **0 concesiones en ~360 000 `Check`** con G ≥ 5 ms, y 0,02 % con G = 0 bajo carga.
  - Cota demostrable: G ≥ `--request-timeout` del servidor, porque ningún `Check` que responda dura más que eso.
  - Basta la ranura en `group.member`. Su coste en latencia es indistinguible de cero.

---

## 1. Lo que ya existe (verificado en código)

| Pieza | Dónde | Hecho |
|---|---|---|
| Relaciones del modelo | `src/drivers/openfga_facts.ts:997-1064` (`factsRelationTypeDefinitions`, `factsRelationRewrites`) | `group.member = this` con `[holders, group#member]`, con y sin `not_expired`. Con opt-in de deny: `X = (this ∪ includes) but not denied_X` y `denied_X = this ∪ denied_P` (cierre ascendente). **Sin wildcard** en relaciones (`:1004-1013`) y **sin TTU/`from`** (`:829-831`, diferido a 2.6) |
| Renovación en relaciones | `src/drivers/openfga_relations_driver.ts:666-736` | `#readTuple` → con otra caducidad: `#carriedDeny` (409 `E_AUTHZ_RENEWAL_UNSAFE`) → `write({deletes})` → `write({writes})` → `#recheckCarried` (`RenewalRacedError`). Son DOS `Write` |
| Capacidad | `openfga_relations_driver.ts:292` `atomicRenewal: false`; `database_relations_driver.ts:259` `true` | El reconcile la lee en `reconcile.ts:554` |
| Renovación en roles (gemelo) | `src/drivers/openfga_driver.ts:1214-1231` `replaceAssignment` | Delete + write en dos llamadas. Solo es *fail-closed* (el deny de roles va por holder directo, no por grupos), con marca parcial |
| Maquinaria de los cierres 2–4 | `reconcile.ts:1216-1410` (aprox.), `tuple_order.ts:577-739` (`relationWithheldWrites`), `errors.ts:462-515` (`RenewalUnsafeError`, `RenewalRacedError`), `commands/authz_relations_reconcile.ts:159-214` | `renewal-unsafe`, `withheld-by-unsafe-deny`, `carrier-conflict`, `deny-conditional`, RACED |

**M5 vuelve a reproducirse** (fase `atom`, V0):
- delete + write de la misma clave en un `Write` ⇒ **400 `cannot_allow_duplicate_tuples_in_one_request`**;
- `on_duplicate: ignore` con otra condición ⇒ **409 `Aborted` «already exists with a different condition»**.

---

## 2. Qué ofrece OpenFGA oficialmente (verificado en fuente)

- **Write transaccional**: «You can combine both writes and deletes in a single transactional API request… All operations
  in the request will either succeed together or fail together». También dice que no admite la misma tupla en `writes` y
  `deletes`, y pone un tope de 100 por request. Fuentes: <https://openfga.dev/docs/getting-started/update-tuples> y
  <https://openfga.dev/docs/interacting/transactional-writes>.
- **`on_duplicate: "ignore"`** solo ignora duplicados IDÉNTICOS: «if the condition name or parameters are different, this
  is a conflict… 409». **No existe un *upsert* de condición.**
  - El SDK 0.9.6 instalado solo trae `Error | Ignore` (`node_modules/@openfga/sdk/dist/apiModel.d.ts:1906-1936`).
  - En las notas de v1.19 → v1.22.0 (6 oct) no hay ninguna entrada sobre esto (<https://github.com/openfga/openfga/releases>).
  - 🟡 Esto último lo resumí con un fetch, no línea a línea.
- **Consistencia**: `HIGHER_CONSISTENCY` solo salta la caché. No hay *zookie* ni lectura en una sola foto
  (<https://openfga.dev/docs/interacting/consistency>). Que un `Check` no es aislado lo **mido** en §3 (la doc no lo niega ni lo afirma).
- **Tuplas contextuales** (<https://openfga.dev/docs/modeling/token-claims-contextual-tuples>): valen por request y no se
  persisten. Otro proceso no las ve, así que no sirven para serializar una renovación entre pods. **Descartadas.**
- **Parámetros de condición en el request**: la caducidad tiene que vivir en la tupla (es POR tupla), y la condición de una
  tupla no se reescribe (lo de arriba). **Descartadas como mecanismo de renovación.**

---

## 3. Mediciones

### 3.1 Atomicidad del `Write` con dos ranuras (fase `atom`)

- VA: `writes:[group:h#member_alt@user:u (cond nueva)]` + `deletes:[group:h#member@user:u]` en un `Write` STRICT ⇒ **éxito**.
  Tras él queda solo `member_alt` con la condición nueva.
- `Read {user, object}` sin `relation` devuelve las dos ranuras en **una** llamada. La lectura por clave sigue costando un `Read`.
- Un deny condicional pasa a permanente por ranura (`denied_viewer` → `denied_viewer_alt`) en un `Write` ⇒ éxito.

### 3.2 ¿Algún `Check` intermedio concede? (fases `hammer`, `grace`, `stress`)

**Escenario.** U ve X por un allow directo. Deny `denied_viewer@group:g#member`. Se renueva en bucle:
- **directa**: U ∈ G;
- **anidada**: la arista H ⊂ G con U ∈ H.

Mientras tanto, N lectores hacen `Check(U viewer X)` sin parar (HIGHER_CONSISTENCY). Toda concesión es un fail-open.

| Variante | Lectores | Renovaciones | Checks | **Conceden** | Check máx |
|---|---|---|---|---|---|
| V0 de hoy (delete; write) · directa | 4 | 300 | 3 169 | **1 713 (54 %)** | — |
| V0 de hoy · anidada | 4 | 300 | 2 822 | **1 499 (53 %)** | — |
| VA swap en UN `Write` · directa | 4 | 300 | 2 021 / 1 869 | **33 / 27 (1,4–1,6 %)** | 8,8 ms |
| VA swap en UN `Write` · anidada | 4 | 300 | 1 617 | **23 (1,4 %)** | — |
| VB lease, swap en UN `Write` · directa / anidada | 4 | 300 | 2 023 / 1 616 | **110 / 137 (5–8 %)** | — |
| VA swap en UN `Write` · directa / anidada | 24 | 600 | 17 016 / 13 883 | **276 / 256 (1,6–1,8 %)** | 47–55 ms |
| VA make-before-break **G = 0** (dos `Write` seguidos) | 4 | 300 ×2 | 3 335 + 2 849 | 0 | 5,5–6,9 ms |
| VA make-before-break **G = 0** · directa / anidada | 24 | 600 | 29 291 / 24 052 | **6 / 4 (0,02 %)** | 23–34 ms |
| VA make-before-break **G = 5 ms** · d / a | 24 | 600 | 45 182 / 32 384 | **0 / 0** | 37–39 ms |
| VA make-before-break **G = 25 ms** · d / a | 24 | 600 | 79 768 / 59 430 | **0 / 0** | 38–46 ms |
| VA make-before-break **G = 100 ms** · d / a | 24 | 200 | 68 107 / 53 313 | **0 / 0** | 32–38 ms |

En todas las filas `finalGranted: false` y `writeErrors: 0`.

**Mecanismo (inferido, con la medición como evidencia).**
- `member = this ∪ member_alt` se evalúa con DOS lecturas de datastore, una por relación.
- Hay lectura rasgada si un lector lee la ranura nueva ANTES del commit y la vieja DESPUÉS: no ve ninguna, el deny no llega y concede.
- **Swap en un `Write`** (t₁ = t₂): basta con que el `Check` abarque el instante del commit. Por eso el 1,5 % es estable.
- **Make-before-break** (t₁ < t₂): hace falta que el `Check` dure más que el hueco G. Con G = 0 el hueco es un `Write`
  (~3 ms), y bajo carga hay `Check` de 23–34 ms: aparece (0,02 %). Con G mayor que la cola de duración, desaparece.
- VB empeora: más lecturas por `Check` dan más oportunidades de rasgarse.

**Cota demostrable (no empírica): G ≥ `--request-timeout` del servidor** (3 s por defecto; si se configuran los dos, manda
sobre `--http-upstream-timeout`, según `openfga run --help`).
- Un `Check` que tarde más que eso no devuelve decisión: el paquete lo ve como error y responde 503, nunca `true`/`false`.
- Así que ningún `Check` que RESPONDE puede haber leído la ranura nueva antes de t₁ y la vieja después de t₁ + G.
- 🟡 Pendiente medir que el corte del servidor cancela de verdad la resolución con un `--request-timeout` pequeño (contenedor
  aparte, `openfga-tiny`). No lo hice para no tocar Docker más allá de lo permitido.
- **Con `consistency: 'minimize_latency'`** y las cachés del servidor (`check-query-cache`/`check-iterator-cache`), una
  lectura puede venir de una entrada cacheada antes de t₁. Entonces G tiene que cubrir además el TTL de la caché. ❓ No medido.
  El default del driver es `higher_consistency` (`openfga_relations_driver.ts:200`), que no usa la caché.

### 3.3 Corrección semántica con dos ranuras (fase `semantics`, VA con ranuras también en `denied_*`)

| Caso | Resultado |
|---|---|
| S1: una ranura vencida y la otra viva | concede (la unión vale mientras viva alguna) |
| S2: las dos vencidas | niega |
| S3: `owner` en la ranura alt ⇒ `viewer` por `includes` | concede |
| S4: `denied_editor` en la ranura alt | corta `owner` (cierre ascendente) y el `viewer` que deriva de él (false/false) |
| S5: deny en G, U ∈ H (alt), H ⊂ G (alt) | niega. U es member de G (alt∘alt): true |
| S6: allow `k#member` en `viewer` alt, miembro en la primaria | concede. `ListObjects` = `[doc:b]` |
| S7: arista de anidación alt VENCIDA | no transporta el deny ⇒ concede, como hoy (C2-4) |
| `ListUsers doc:a viewer` | `[s1, s3, s7]`: sin duplicados por las dos ranuras y sin los denegados |
| `ListUsers group:g member` | transitiva a través de alt: `[s5]` |

- **Equivalencia en carga**: los mismos 1 249 hechos lógicos (la mitad en la ranura alt) dan las MISMAS respuestas en V0, VA*
  y VB: 130 de 1 000 `Check` concedidos en cada variante y corrida.
- **Wildcard y `parent`/herencia no aplican a relaciones**: el modelo de relaciones no los tiene (`openfga_facts.ts:1004-1013`, `:829-831`).
  - En roles, `scope#parent`, `rooted` y `role#permits_*@holder:*` no llevan condición y nunca se renuevan.
  - El `assignee` de roles se renueva *fail-closed* (`replaceAssignment`): es disponibilidad, no seguridad.

### 3.4 Coste (fases `size` y `bench`)

**Bytes del modelo** (`factsModelBytes` = bytes del servidor; techo 262 144; el servidor aceptó el más grande).
Configuración grande: 3 holders, 4 tipos × 4 relaciones con deny y 50 permisos.

| Variante | Pequeño | Grande |
|---|---|---|
| V0 (hoy) | 1 808 | 36 165 |
| Ranura solo en `group.member` | — | **36 371 (+0,6 %)** |
| + ranuras en allows (VA) | 2 319 | 39 643 (+9,6 %) |
| + ranuras en `denied_*` (VA-full) | 2 761 | 43 251 (+19,6 %) |
| VB lease | 1 939 | — |

**Latencia**, mismas tuplas lógicas (1 249) y orden entrelazado. Dos corridas por fila, en ms p50 · p95.
`Check` n = 1 000; `BatchCheck(20)`, `ListObjects` y `ListUsers` n = 200.

| Variante | Check | BatchCheck(20) | ListObjects | ListUsers |
|---|---|---|---|---|
| V0 | 2,31–2,44 · 4,0–4,5 | 7,4–8,0 · 12,5–13,5 | 3,1–3,3 · 5,0–5,3 | 2,7–2,8 · 4,6–5,2 |
| **VA-member** (solo `group.member`) | **2,29–2,37 · 4,1–4,4** | **7,1–7,7 · 11,3–12,3** | **2,8–3,1 · 4,5–5,3** | **2,5–2,8 · 4,6–5,8** |
| VA-member-allow | 2,51–2,53 · 4,2–4,4 | 8,5–8,8 · 13,7–14,1 | 3,2 · 5,4–5,5 | 2,7 · 4,9–5,1 |
| VA-member-deny | 2,38–2,40 · 4,1 | **10,9–12,1** · 15,9–16,0 | 3,0–3,2 · 5,2–5,6 | 2,6–2,8 · 4,4–4,8 |
| VA-full | 2,44–2,48 · 4,4–4,5 | **11,5–11,9** · 16,6–17,0 | 3,3–3,5 · 5,8–6,5 | 2,8 · 5,0–5,4 |
| VB lease | **3,58–3,59** · 6,1–6,4 | **21,4–21,6** · 27,6–27,9 | 3,8–3,9 · 6,4–6,7 | 3,6–3,7 · 6,8–6,9 |

- **Ranura en `group.member`: coste en ruido.**
- Ranura en allows: +6–15 % en BatchCheck.
- **Ranura en `denied_*`: +50–60 % en BatchCheck**, porque el cierre ascendente multiplica las ramas restadas.
- VB: +50 % en Check y ×2,8 en BatchCheck. **VB queda descartada**: más tuplas, más saltos, más lecturas rasgadas y el doble de latencia.

### 3.5 Renovaciones concurrentes (fase `conc`, VA, swap con escritura STRICT)

Pruebas de 60 + 20 renovaciones:

| Caso | Resultado |
|---|---|
| Dos renovaciones a la vez, sin reintento | una gana; la otra recibe **400 `cannot delete a tuple which does not exist`**. Final: **exactamente una ranura** (60/60) |
| Con relectura + reintento | `ok \| ok-tras-1`; gana el último escritor, una ranura (60/60) |
| Con `ignore/ignore` | la perdedora recibe **409 `Aborted`** («already exists with a different condition» / «one or more tuples to write…»); una ranura |
| Renovación ∥ `unrelate` que borra LAS DOS ranuras con `on_missing: ignore` | final **NINGUNA** (60/60), nunca una resurrección. **Sesgo:** el `unrelate` siempre llegó primero, porque la renovación hace un `Read` antes |

Para make-before-break en dos `Write` la concurrencia está 🟡 **diseñada, no medida**:
- el `Write` 1 con `on_duplicate: error` es un CAS sobre la ranura libre;
- si las dos ranuras están ocupadas, hay una renovación en vuelo: relectura, y 409 `E_AUTHZ_WRITE_CONFLICT` si no cede;
- el `Write` 2 con `on_missing: ignore`, porque si un `unrelate` ya borró, el objetivo se cumplió.

### 3.6 Migración y despliegue (fase `rollout`)

| Medición | Resultado |
|---|---|
| Store de HOY (tuplas en la ranura primaria) evaluado con el modelo NUEVO | correcto: U denegado `false`, U member `true`, W viewer por editor `true`. **Compatible hacia atrás** |
| Store con una membresía en la ranura alt, evaluado con el modelo VIEJO fijado | **`U viewer X` = TRUE (FAIL-OPEN)**; `U member G` = false |
| Modelo viejo: escribir en la ranura alt | 400 `validation_error … relation 'group#member_alt' not found` |
| Modelo viejo: borrar en la ranura alt con `on_missing: ignore` | éxito, y la borra |

**Consecuencia:**
- Un pod con el modelo viejo fijado, o con el código viejo, sobre un store donde ya se escribió una ranura alt, **concede a
  denegados**.
- El código viejo además no ve la alt en `#readTuple`, y su `unrelate` solo borra la primaria: la membresía sobrevive.
- El despliegue no admite flota mixta. Receta: `authz:freeze` → `openfga:provision` → fijar `OPENFGA_MODEL_ID` en TODA la
  flota → desplegar → `authz:unfreeze`. Las escrituras de relaciones ya están bajo la barrera del freeze (L-1).
- La guarda D-31 del driver se extiende a `group`: modelo fijado sin la ranura ⇒ 500 al escribir `group`, con receta. Es el
  mismo patrón que «modelo fijado sin `denied_*`».

### 3.7 Nombre de la ranura (fase `names`)

- El servidor acepta `viewer_alt`, `_viewer`, `Viewer`, `viewer~`, `viewer$` y `.viewer`.
- La gramática de relaciones del consumidor es `^[a-z0-9][a-z0-9._-]*$` (`define_relations_config.ts:77`). Un nombre que
  empiece por `_` **no puede colisionar** con una relación del consumidor ni con un permiso (`PERMISSION_FORMAT`, `identity.ts:450`).
- En `group` el tipo lo posee el generador, así que `member_alt` (o `_member`) es libre.
- Cuidado con la longitud si algún día se ponen ranuras en `denied_X`: `_denied_` + 43 = 51 > 50, y la cota denegable bajaría a 42.

---

## 4. Las alternativas, juzgadas

| | (a) Dos ranuras | (b) Indirección (lease/grant) | (c) Lo que ofrece FGA |
|---|---|---|---|
| Atomicidad del escritor | ✅ un `Write` todo-o-nada | ✅ igual | ❌ no hay upsert de condición (doc + SDK) |
| ¿Concede un `Check` intermedio? | swap en 1 `Write`: **sí, 1,4–1,8 %**. Make-before-break con G ≥ request-timeout: **no** (0 / 360k medidos; cota demostrable) | swap: **sí, 5–8 %**. Make-before-break: igual que (a), pero con más lecturas | tuplas contextuales: no persisten; condiciones: la caducidad es por tupla |
| Deny `but not`, anidación, caducidad, `includes`, ListUsers | ✅ medido (§3.3) | ✅ en Check; ListUsers devuelve objetos `lease` y exige otra resolución | — |
| Latencia | `group.member`: ≈ 0. Allows: +6–15 % BatchCheck. Denies: +50–60 % | +50 % Check, ×2,8 BatchCheck | — |
| Modelo | +0,6 % (solo member) … +19,6 % (todo) | +7 % | — |
| Lectura/export/reconcile | canonizar la ranura → relación lógica; dos vivas ⇒ caducidad = máx, deriva `two-slots` | unir dos tuplas por membresía, ids no deterministas, medias huérfanas | — |

**El *steelman* de (b):** su ventaja real es que las aristas `group:H#member@lease:*` se leen en UNA consulta. Si en el swap
no se borrara la tupla `lease:L₁#holder`, no habría lectura rasgada sin necesidad de G. Pero esa tupla colgante habría que
recogerla después, y recogerla vuelve a necesitar G. Así que acaba en el mismo make-before-break con más tuplas, más saltos,
el doble de latencia y una enumeración que tiene que reconstruir pares. No compensa.

**Descartado sin medir, con razón:** expresar la caducidad en NEGATIVO (`member = base but not member_expired`) haría que la
lectura rasgada viera «no caducado», que es benigno. Pero en FGA `but not` resta al USUARIO, no a la tupla: el vencimiento de
la arista H ⊂ G cortaría también la membresía directa de U en G. Eso rompe la semántica multi-camino.

---

## 5. Recomendación

**Ranura en `group.member` y renovación make-before-break con gracia.**

1. **Modelo.** `group.member = this ∪ member_alt` (`member_alt: this`, con los mismos sujetos), **solo cuando algún tipo
   declara `deny`**. Sin opt-in, el literal no cambia y **D-29 se conserva byte a byte**. No hay ranura en allows ni en `denied_*`.
2. **`relate` de una membresía con otra caducidad.**
   - `Read {user, object}`: un `Read` que devuelve las dos ranuras.
   - `Write` 1: escribe la ranura libre, STRICT (es el CAS).
   - Espera `renewalGraceMs`.
   - `Write` 2: borra la vieja con `on_missing: ignore`.
   - **Sin `#carriedDeny` y sin `#recheckCarried`**: la regla es uniforme, así que no hay TOCTOU que vigilar.
   - Si muere entre los dos `Write`: quedan las dos vivas, la unión es el máximo y no hay fail-open. En un acortamiento, la
     vieja más larga sigue viva, como «no aplicado»: se marca `markPartialWrite` y el manager notifica `indeterminate`.
   - `unrelate` de un grupo borra LAS DOS ranuras en un `Write` con `on_missing: ignore` (medido en §3.5).
3. **`renewalGraceMs`.** Default 3 000 = el `--request-timeout` por defecto. Se valida como `listObjectsDeadlineMs`: «declara
   el del servidor», y con `minimize_latency` hay que sumar el TTL de la caché.
4. **Lecturas.** `#readTuple`, `listSubjects` sobre `group` (`Read {object}` sin `relation`), `#sweep`/`enumerateRelations` y
   `storedRelationKind` canonizan `member_alt` → `member`. Con dos vivas, la caducidad es el máximo y se cuenta la deriva
   `two-slots`. El reconcile la repara borrando la ranura que no casa, también con G.
   - Las purgas no cambian: leen por objeto o por sujeto y ven las dos ranuras.
   - `listDenies` no cambia: no hay ranura en `denied_*`.
5. **`atomicRenewal: true` en `openfga`.** Con eso `held`/`lost` quedan vacíos y caen `renewal-unsafe`,
   `withheld-by-unsafe-deny`, `carrier-conflict` y `RenewalRacedError`.
6. **Deny condicional VIVO en el destino**, que solo existe escrito a mano porque la API no lo produce (D3): **negativa
   simple**, cero escrituras y receta, sin retención. Uno VENCIDO se reescribe permanente en dos `Write` sin ventana: ya no negaba.
7. **Terceros sin `atomicRenewal`.** `runRelationsReconcile` hacia un destino así, con opt-in de deny, ⇒ 500 por adelantado
   (decisión estructural, regla 5d). No se conserva la maquinaria de retención solo por ellos.
8. **Roles.** No hace falta: `replaceAssignment` es *fail-closed*. Una ranura en `assignee` solo quitaría la marca parcial y
   el parpadeo; es opcional y aparte.

**Cuándo NO hacerlo.** Si COGNITIV no tolera unos ~3 s de latencia en la renovación de una membresía y no puede bajar
`--request-timeout`. La salida intermedia sería G empírico (25 ms medidos sin rasgado), pero eso deja de ser una garantía:
lo honesto es documentarlo como probabilístico, y no lo recomiendo.

---

## 6. Qué sobra de los cierres 2–4 y tamaño del cambio (🟡 estimación por lectura, no medida)

**Se borra (src, ~550–600 líneas):**
- `tuple_order.ts:577-739` (`HeldRenewal`, `WithholdInput`, `WithholdPlan`, `relationWithheldWrites`), ~160 líneas.
- `reconcile.ts`: el bloque `renewalUnsafe`/`held`/`denyLost`/`decided`/`withheld*` y `carrier-conflict` (≈ `:1216-1410`,
  más `:149-200`, `:394-460` y `:701-702`), ~230 líneas.
- `openfga_relations_driver.ts`: `#carriedDeny`, `#recheckCarried`, `annotateRacedDeny` y la rama guardada de `relate`, ~110 líneas.
- `errors.ts:462-515`: `RenewalUnsafeError`, `RenewalRacedError` y sus exports, ~55 líneas.
- `commands/authz_relations_reconcile.ts:159-214`: las líneas de esos motivos, ~30.
- Además, las secciones del README y del CHANGELOG `[Unreleased]` de N1, C3-1…C3-4 y RACED.

**Se borra (tests, ~900–1 100 líneas):**
- La dimensión «dos `Write`» y el oráculo de retención de `order_bruteforce.ts`. La fuerza bruta corre solo en modo
  atómico: guard-mutants debería bajar de ~17,5 min a un orden de 10–12 (🟡 sin medir).
- Las filas de dos `Write` de `relations_order_exhaustive.spec.ts`.
- Los casos C2/C3/N1 de `relations_reconcile_deny.spec.ts` y de `relations_reconcile_l9.spec.ts`.
- La barrera N1 de `relations_openfga.spec.ts`.
- Unas 20 entradas `c41.*`/`c4h.*` de `guard_mutants.json` y las filas C3-1/C3-2 de la guardia.
- Los casos «vigencia · C3-1» con las dos caras del contrato.

**Se añade (~250 src y ~400 tests):**
- Generador: ranura condicionada al opt-in de deny, ~20.
- D-31 sobre `group`, ~25.
- `relate` make-before-break, `unrelate` de las dos ranuras, la opción y su validación, ~80.
- Canonización en `#readTuple`, `listSubjects` y `#sweep`, ~50.
- Deriva y reparación `two-slots` en el reconcile, ~40.
- Negativa del deny condicional vivo, ~20.
- `EXPECTED_FUSED` con opt-in.
- Casos:
  - espía de tiempo: `Write` 1 → espera ≥ G → `Write` 2, con reloj o `sleep` inyectado;
  - store legado con el modelo nuevo;
  - modelo fijado sin ranura ⇒ 500;
  - dos ranuras ⇒ canonizar y deriva;
  - concurrencia;
  - las caras del par `atomicRenewal` reescritas.

**Neto: unas −300 líneas de src y unas −600 de tests.** Y lo que más pesa: **D4-1, D4-2 y D4-3 del auditor desaparecen con
la maquinaria que juzgaban**, en vez de pedir un quinto cierre.

**Lo que NO cae:**
- el orden de la transición del reconcile (cierre 1, `relationTransitionOrder`, linaje L10), porque una pasada son muchos `Write`;
- su residuo de grupos mixtos;
- la marca parcial de las purgas.

---

## 7. Impacto en COGNITIV

- **Breaking de despliegue.** Hay que publicar el modelo nuevo y fijarlo en toda la flota antes de que un pod escriba una
  ranura alt (medido: fail-open en caso contrario). La receta es freeze/provision/pin/deploy/unfreeze. Es el mismo deber que D-31 ya impone.
- **Latencia de renovación de membresía:** +G (3 s por defecto) por `relate`. En el reconcile: +G una vez por pasada, con las
  ranuras nuevas por lotes, una espera y los borrados por lotes.
- **API pública sin cambios** salvo: desaparecen `E_AUTHZ_RENEWAL_UNSAFE`, `E_AUTHZ_RENEWAL_RACED` y sus residuos (eran de
  `[Unreleased]`, no estaban publicados), y aparece la opción `renewalGraceMs`.
- Quien lea el store con `manager.driver()` o a mano verá tuplas `member_alt`.

---

## 8. ✅ / 🟡 / ❓

- ✅ **Medido:**
  - M5;
  - el swap con dos claves es atómico para el escritor;
  - el swap en un `Write` concede un 1,4–1,8 % de los `Check`;
  - make-before-break con G ≥ 5 ms: 0 de ~360k;
  - semántica S1–S7 y ListUsers/ListObjects;
  - la latencia de las seis variantes;
  - los bytes del modelo;
  - compatibilidad hacia atrás y el fail-open con el modelo viejo fijado;
  - CAS y concurrencia del swap.
- 🟡 **Diseñado, falta verificar:**
  - que el `--request-timeout` del servidor cancela de verdad un `Check` largo (es la cota demostrable de G);
  - la concurrencia de make-before-break en dos `Write`;
  - la reducción del tiempo de guard-mutants;
  - el tamaño del cambio.
- ❓ **Pendiente:**
  - G con `minimize_latency` y las cachés del servidor activas;
  - si COGNITIV acepta ~3 s en la renovación de membresía.
- ❓ **Decisión del dueño:**
  - (1) negativa por adelantado para terceros sin `atomicRenewal` frente a conservar la maquinaria;
  - (2) ranura también en allows (+6–15 % en BatchCheck) para quitar el parpadeo *fail-closed*: recomiendo NO en v1.

**Hallazgo lateral para el auditor.** «Un `Write` = transaccional» no significa que un lector vea uno de los dos estados.
Toda garantía del paquete que dependa de que un `Check` concurrente vea «antes o después» a través de DOS pares
(objeto, relación) distintos escritos en el mismo `Write` merece un barrido. Las de hoy que revisé quedan a salvo:
- `moved` reescribe la MISMA (objeto, relación) `parent` y se lee en una consulta;
- el `grant` de tres tuplas, si se ve parcial, se ve *fail-closed*.

## Recomendación en una frase

Ranura `member_alt` en `group.member` (solo con opt-in de deny) y renovación make-before-break en dos `Write` con gracia
≥ `--request-timeout`. Eso permite declarar `atomicRenewal: true` en `openfga` y borrar `renewal-unsafe`, retención,
`carrier-conflict` y RACED, en vez de un quinto cierre de D2.

**Siguiente paso:** que el dueño decida (1) aceptar ~3 s de renovación de membresía (o un `--request-timeout` menor) y
(2) negativa para terceros sin `atomicRenewal`. Con eso, un sublote «D2-R» que sustituya los cierres 2–4 por este diseño.
Su primer caso es la barrera temporal (`Write` 1 → G → `Write` 2), y la verificación de la cota con un `openfga-tiny` de
`--request-timeout` corto.
