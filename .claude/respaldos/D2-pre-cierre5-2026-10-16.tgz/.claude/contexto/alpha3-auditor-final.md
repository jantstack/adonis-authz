# `2.4.0-alpha.3` — AUDITOR, pasada FINAL sobre el cierre-2

Pasada acotada a lo que pidió el coordinador: (1) re-ejecución de mis CINCO reproducciones, (2) el `#guard`
nuevo del driver `openfga` de relaciones, (3) llamadores internos afectados por la estrictez, (4) el id en
`purgeObject` con tipo declarado. Nada tocado fuera de `.claude/`.

**Escala:** CRÍTICO = 🔴 · ALTO = 🟠 · MEDIO = 🟡 · BAJO = ⚪. Solo 🔴/🟠 reabren.

**Reproducciones** (`/home/jose/proyectos/Personal/adonis-authz/.claude/reproducciones/`): `alpha3-auditor.ts`,
`alpha3-f05-purge.ts`, `alpha3-cierre-auditor.ts`, `alpha3-cierre-openfga.ts`, `alpha3-cierre-parcial.ts` y la
nueva `alpha3-final-guard.ts` (socket mudo propio + composición del id).

**Sanidad del árbol (medida por mí, no reportada):**
`npm run check:purity` ✔ · `tsc --noEmit -p tsconfig.test.json` ✔ ·
`OPENFGA_TEST_URL=…:8101 npm test` ⇒ **1141/1141** · `TEST_DB=sqlite-file` + `:8101` ⇒ **1165/1165**. Cero ✖.

---

## 1 · Re-ejecución de mis cinco repros (punto 1)

### Cerrado con el cierre-2 — la regresión 🟠 1 y sus dos MEDIOS

```
2e relate(relation: undefined)               ⇒ E_AUTHZ_RELATION_UNKNOWN 422   (antes del cierre-2: NO LANZABA)
2f unrelate(relation: undefined)             ⇒ E_AUTHZ_RELATION_UNKNOWN 422   (antes: NO LANZABA)
2g purgeSubject(userset relation: undefined) ⇒ E_AUTHZ_RELATION_UNKNOWN 422   (antes: NO LANZABA)
O1a relate(relation: undefined) contra :8101 ⇒ E_AUTHZ_RELATION_UNKNOWN 422   (antes: 503 del servidor)
O1b listSubjects(relation: undefined)        ⇒ E_AUTHZ_RELATION_UNKNOWN 422   (antes: la UNIÓN de relaciones)
O1c check / O1d listObjects                  ⇒ E_AUTHZ_RELATION_UNKNOWN 422   (antes: 503)
1a membersOf(role_binding, assignee)         ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422 (antes: {"subjects":[]})
1b membersOf(document, relación no declarada)⇒ E_AUTHZ_RELATION_UNKNOWN 422      (antes: {"subjects":[]})
O1e membersOf en openfga                     ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422 (F-05 ANTES de la capacidad)
3a markPartialWrite(error CONGELADO)         ⇒ ok                             (antes: TypeError que sustituía al 503)
```

**🟠 1 CERRADO** (dos funciones, no un opcional), **🟡 2 CERRADO**, **🟡 3 CERRADO** (y `membersOf` corta por
F-05 *antes* de la capacidad, que es el orden correcto: un tipo no declarado no aprende si el driver la trae),
**⚪ 4 CERRADO**.

**⚪ 5 CERRADO y bien** (`alpha3-cierre-parcial.ts`, contra el `:8101`, con un error cuyo mensaje contiene la
palabra «timeout» — el que antes falseaba la clasificación):

```
B · falla la lectura INICIAL   : E_AUTHZ_BACKEND_UNAVAILABLE 503  partialWrite=undefined  quedan 2  EVENTOS=0
C · falla la lectura de RESIDUO: E_AUTHZ_BACKEND_UNAVAILABLE 503  partialWrite=true       quedan 0  EVENTOS=1 indeterminate=true
```
Antes del cierre-2 los DOS salían como `E_AUTHZ_BACKEND_TIMEOUT` con `indeterminate: true`, incluido el que no
borró nada. Ahora B —«no ocurrió»— emite cero y C —«pudo ocurrir»— emite uno. Es exactamente la frase publicada.

### Sigue cerrado lo de las pasadas anteriores (no hay regresión al revés)

```
(a) relate role_binding ⇒ 422   (b) listSubjects ⇒ 422   (c) purgeObject ⇒ 422
DESPUÉS · authorize(user:U, read, organization:S) = true   ·   tuplas del binding que quedan: 2
O3 · las cinco rutas contra role_binding ⇒ 422, y también por manager.driver()
A1/A2/A3 assertWrite (false / thenable-función / async) ⇒ E_AUTHZ_CONFIG, ENTRÓ=false
D1/D2/D3/D4 ⇒ 422, 0 eventos     E1 actor:null ⇒ 422     5a/5b/5c/5e copia, 5f el sink no muta al llamante
4a error propagado: mismo objeto, E_AUTHZ_PURGE_INCOMPLETE 500, partialWrite NO enumerable, 1 evento indeterminate
```

### Lo que sigue igual por DECISIÓN (no lo reabro)

`B` hook sin deadline (paridad con roles, frase publicada) · `E2` el `actor` viaja con sus campos de más ·
`5d` la copia es de un nivel (`actor.session.ip` sigue aliasado) · `3b`/`3c` marcar es deber del DRIVER y no
hay juez (declarado en `CLAUDE.md`, diferido a 2.6+) · `F` de `alpha3-auditor.ts` es mi driver falso que no
marca: mide el deber, no un fallo del paquete.

---

## 2 · El `#guard` nuevo del driver `openfga` de relaciones (punto 2)

Medido con un **socket mudo propio** (acepta la conexión y no contesta nunca) y contra el `:8101`
(`alpha3-final-guard.ts`):

```
G1 relate       ⇒ E_AUTHZ_BACKEND_TIMEOUT 503 en  704 ms | 1 evento, indeterminate=true, sin transactional
G2 check        ⇒ E_AUTHZ_BACKEND_TIMEOUT 503 en  701 ms | 0 eventos  (una LECTURA no audita)
G3 listSubjects ⇒ E_AUTHZ_BACKEND_TIMEOUT 503 en  702 ms | 0 eventos
G4 purgeObject  ⇒ E_AUTHZ_BACKEND_TIMEOUT 503 en  702 ms | 1 evento, indeterminate=true
G5 el mismo relate con timeoutMs=1600      ⇒ 503 en 1601 ms
G6 "El backend de autorización 'openfga-relations' no respondió en 700 ms (relate)"
G7 unhandledRejection tras destruir el socket: 0
```

Respuestas, una por una:

- **¿Se pisan dos deadlines?** No hay dos *niveles*: el manager (`#write`) **no tiene deadline** —solo clasifica
  y notifica—, y la única otra espera del camino es la barrera del freeze (`freezeTimeoutMs`), que corre ANTES
  del driver, no emite evento y también sale 503 `E_AUTHZ_BACKEND_TIMEOUT`. Dentro del driver sí hay **dos
  relojes con el MISMO valor** compitiendo: el `baseOptions.timeout` del SDK (axios) y el `withDeadline`
  nuevo. Convergen: si gana axios, el error trae `ECONNABORTED` y el `isTimeoutLike` **estricto** de
  `backend_guard.ts` lo clasifica igual ⇒ misma clase, mismo `code`, mismo mensaje. Redundante, no
  contradictorio. Medido: 704 ms para 700 y 1601 ms para 1600 — un solo salto, sin doble espera.
- **¿De dónde sale el valor?** Del **driver**: `options.timeoutMs ?? DEFAULT_TIMEOUT_MS` (5000). No es una
  constante escondida ni `freezeTimeoutMs`; G5 lo demuestra cambiándolo.
- **¿Vuelve a envolver el manager lo que el driver ya clasificó?** No. `#write` re-lanza **el mismo objeto**
  (verificado en 4a: `r.e === original`, `code`/`status` intactos, `partialWrite` no enumerable).
- **¿Las lecturas pasan por `#guard`?** Sí, y su timeout es 503 **sin evento** (G2/G3): correcto —invariante 5
  («el backend no responde ⇒ 503, nunca un `false` silencioso») y las lecturas no se auditan.
- **¿Sigue `maxRetry: 0`?** Sí (`openfga_relations_driver.ts:235`), junto a `baseOptions: { timeout }`.
- **¿Deja `withDeadline` promesas huérfanas?** No: es un `Promise.race` con `finally(clearTimeout)` y el
  `.catch` va enganchado ANTES de la carrera, así que el rechazo tardío queda manejado. Destruí los sockets
  después del deadline para forzar el rechazo tardío: **0 `unhandledRejection`** (G7).

**Residuo (⚪, no nuevo y no reabre):** el deadline es **por llamada**, así que una purga de N requests no
tiene tope global (N × `timeoutMs`); es la misma forma que ya tenía y que tiene el driver de roles.

---

## 3 · Llamadores internos y la estrictez (punto 3)

Grep de todos los call-sites del puerto fuera de `src/relations/manager.ts`, `src/drivers/` y `src/testing/`:

- `src/relations/reconcile.ts:274` (`to.unrelate`) y `:304` (`to.relate`) — **único consumidor interno**. La
  `relation` sale de `enumerateRelations` del origen, que **nunca produce vacío**: en `openfga` `#readAll`
  descarta la tupla sin `key.relation` (y la reporta como no parseable) y en `database` la columna es
  `NOT NULL`. Además esas dos llamadas van al DRIVER, que ya aplicaba `assertRelationDeclared` desde L-0: la
  estrictez no cambia nada para ellas.
- `src/manager.ts:1776` `listSubjects(role, scope)` es el puerto de **roles**, otro método, no afectado.
- `src/http/resource_access_middleware.ts` solo menciona `check` en prosa; no consume el puerto de relaciones.
- No hay bridge roles↔relaciones que llame a `check`/`membersOf` (`grep -rln RelationsManager|RelationsDriver`
  fuera de `relations/`, `testing/`, `drivers/` y `types.ts` ⇒ solo `src/openfga.ts` y `src/define_config.ts`,
  que son re-exportes/tipos).

**Conclusión: ningún llamador interno recibe un 422 que antes no recibía.** El único cambio de comportamiento
es para el CONSUMIDOR, y está anunciado: `CHANGELOG.md:77` **BREAKING «the reads throw»**, nombrando
`check`/`listSubjects`/`listObjects`/`membersOf` — el ⚪ 7 de mi pasada anterior, cerrado.

---

## 4 · El id en `purgeObject` con un tipo DECLARADO (punto 4)

`purgeObject` valida el tipo (`assertObjectTypeDeclared`) **y** el id (`#assertObjectId` ⇒ `assertRelationId`),
y el driver `openfga` lo repite en `#objectId` (`assertRelationId` + `assertFgaObjectId`). Medido:

```
I1 document + id "a|b" / "a#b" / "a:b" / "a b" / "AB" / "" / "../x" ⇒ E_AUTHZ_INVALID_IDENTITY 422
I1 document + id "ok-1_2.3"                                         ⇒ pasa (gramática legal)
I2 partición uuid "a|b" / "a#b" / "a:b"                             ⇒ E_AUTHZ_INVALID_IDENTITY 422
```

Los dos lados de la composición `<tipo>:<scopeKey>|<uuid>` están cerrados: ni el id del objeto ni el uuid de la
partición admiten `|`, `#`, `:`, espacios ni mayúsculas, así que **con un tipo declarado no se puede componer el
id de otro objeto** (y el parseo canónico es desde la derecha, que ya impedía el aliasing por reagrupación).
No encontré ninguna forma de componer `role_binding:…`, `scope:…` ni el id de otra partición.

---

## 5 · Hallazgos nuevos

**Ninguno 🔴 ni 🟠.** Lo único que anoto, y no reabre:

- **⚪ El docblock de `assertObjectTypeDeclared` sigue listando `purgeSubject`** entre las operaciones «solo el
  tipo», cuando su F-05 real es la del userset (`#assertSubject`) — el código es correcto, la frase sobra.
- **⚪ La desviación reportada por el implementador es la correcta:** `listObjects` SÍ nombra relación, así que
  la estricta es lo que le toca; medido (2c/O1d ⇒ 422 con `relation: undefined`, y 422 con relación no
  declarada). Los docblocks ya dicen «las OCHO operaciones».
- **⚪ Residuos de decisión, ya conocidos y documentados:** hook sin deadline, `actor` con campos de más,
  copia de un nivel, deadline por llamada sin tope global, y el deber de `markPartialWrite` sin juez (declarado
  y diferido).

---

## 6 · Veredicto

**APTA para publicar como `2.4.0-alpha.3`.**

El cierre-2 mata la regresión que yo mismo abrí, y la mata por la raíz correcta: dos funciones con
responsabilidades distintas en vez de deducir «solo el tipo» de un `undefined` — que era el error de diseño, no
el síntoma. Verificado con mis propias reproducciones, no con las suyas: F-05 corta ahora en las ocho
operaciones, por el manager y por el driver, incluido `manager.driver()`, y el exploit del store compartido
sigue muerto (`authorize` se queda en `true`, el binding intacto). La clasificación de timeout dejó de
adivinar por substring y el resultado se ve en la pareja B/C de la purga parcial, que es justo la distinción
que el invariante 13 necesita: «no ocurrió» ⇒ cero eventos, «pudo ocurrir» ⇒ uno con `indeterminate`. El
`#guard` nuevo no introduce doble espera observable, no cambia códigos, no audita lecturas y no deja promesas
huérfanas. Ningún llamador interno se rompe y el cambio que sí afecta al consumidor está anunciado como
BREAKING. Suite verde en dos motores con el `:8101` (1141 y 1165), purity y typecheck limpios.

Queda lo que el dueño ya decidió a sabiendas (hook sin deadline, marcado como deber del driver sin juez hasta
2.6+, copia de un nivel). Nada de eso es 🔴 ni 🟠, así que no reabre y no condiciona la publicación.
