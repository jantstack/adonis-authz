# Panel relay 2 — AUDITOR (adversarial) · los tres cambios de COGNITIV del 10-09-2026

> Objetivo: romper los cambios 1 (exentar la raíz `app`), 2 («supersede») y 3 (`requeue --apply`)
> **antes de que existan**, más el 4 (aparcado/alarma por tiempo) y los menores.
> Base: `main`, `13ba731`, `2.4.0-alpha.7`, árbol limpio. Reproducciones nuevas:
> `.claude/reproducciones/relay2-auditor-{1,2,3,4,5}.ts` (sqlite en memoria, dobles sobre
> `AuthorizationManager` + `sqlScopeOutbox` real).

## Veredicto en una línea

**Cambio 1: seguro con dos condiciones** (la exención tiene que llegar al PUERTO o no cierra nada);
**cambio 2 («supersede»): inseguro tal cual — abre un fail-open cruzado MEDIDO**;
**cambio 3 (`apply: true`): seguro solo si no compone con `force` y no toma el lease dos veces**;
**cambio 4 (`parkAfterMs`): no se hace — deshace la decisión (i) del dueño y se autobloquea (medido);
la alarma por EDAD sin aparcar sí.**

---

## Hallazgos (ordenados por severidad)

### 🔴 1 — «Supersede» quita el tapón que protegía al `attached` de en medio: el hijo nuevo queda colgado del padre VIEJO (medido)

- **Escenario**:
  - precondición — cola: `#1 moved(unit → orgA)` **APARCADA** (la unit venía de `orgV`),
    `#2 attached(child, unit)`, `#3 moved(unit → orgB)`. El store dice `unit → orgV`.
  - acción del atacante — ninguna: basta con que el store siga inestable. Supersede marca `#1`
    obsoleta y libera la clave `unit`; la pasada aplica `#2` (id menor) y **falla** en `#3` (503,
    que por la decisión (i) NO consume intento).
  - resultado incorrecto — el store queda `child → unit → orgV → app`: los holders de **orgV** —la
    organización que ya no es dueña— autorizan sobre un scope que se creó dentro de otra. Y como el
    503 no cuenta intento, `dead()` queda **vacío**: cero alarma, indefinidamente.
- **Evidencia**: ✅ medido, `relay2-auditor-3.ts`:
  ```
  [HOY]        ⇒ #2:deferred(parked:1) #3:deferred(depends-on:2)
  [HOY]        cadena de child en el STORE: — (no existe: fail-CLOSED, no concede nada)
  [SUPERSEDE]  ⇒ #5:applied #6:failed(503)
  [SUPERSEDE]  cadena de child en el STORE: child→unit→orgV→app
  [SUPERSEDE·5 pasadas] aparcadas ahora: ninguna · cadena de child: child→unit→orgV→app
  ```
  Código: el tapón que hoy retiene a `#2` es `src/manager.ts:1245` (`parkedKeys`) y el que retiene a
  `#3` es `src/manager.ts:1228` (`blocked`). Supersede vacía los dos para esa clave.
- **Steelman del defensor**: «el estado final que manda es el del último `moved`; aplicarlo y tirar
  el viejo es converger». → **No me convence tal cual**: converge solo si el último se APLICA. El
  cambio se pide precisamente para el caso «el store estuvo caído», que es exactamente el caso en el
  que el superseding falla; y el estado intermedio que hoy no existe (fail-CLOSED, `child` no está en
  el store) pasa a ser un fail-OPEN hacia el tenant anterior. La convergencia sin el tapón no es
  convergencia, es aplicar la mitad que CONCEDE (el mismo patrón del 🔴 1 de 3b-5).
- **Mitigación mínima**: supersede no puede ser «marcar la vieja y seguir en orden de id»: o la
  pasada aplica **primero** el superseding y solo después las de en medio, o la clave sigue taponada
  hasta que el superseding esté `applied`.

### 🔴 2 — Aparcar por TIEMPO se autobloquea: con la cola aparcada en masa, TODA pasada del relay es 500 y el árbol deja de sincronizar (medido)

- **Escenario**: precondición — `parkAfterMs` activo y una caída del store de decenas de minutos en
  un despliegue con tráfico (COGNITIV: cron cada minuto + inline). Acción — nadie; la cola se aparca
  por edad. Resultado — al volver el store, `#parkedKeys` lee el censo COMPLETO
  (`src/manager.ts:1401`) y al alcanzar `PARKED_CENSUS_MAX` (50 000, `src/manager.ts:215`) **niega la
  pasada entera** (`src/manager.ts:1402`). Ninguna pasada vuelve a aplicar nada: los `moved` se
  quedan con el padre VIEJO y **los `detached` no purgan nunca** — fail-open permanente y global,
  autoinfligido, hasta cirugía manual en la tabla.
- **Evidencia**: ✅ medido, `relay2-auditor-5.ts`:
  ```
  [1] relay({ only, limit: 1 }) con 50000 aparcadas ⇒ E_AUTHZ_CONFIG (censo no cabe) en 91 ms
  [2] relay completo ⇒ E_AUTHZ_CONFIG (la cola NO drena: ninguna pasada pasa del censo)
  [3] dead(DEFAULT_RELAY_LIMIT=10000) ve 10000 de 50000: las demás ni se pueden nombrar en requeue
  [4] requeue de 200 ⇒ ok en 490 ms (200 consultas laterApplied)
  ```
  Y por debajo de la cota el daño es el mismo en especie: **todo lo aparcado tapona por clave**
  `attached`/`moved` de todos (`src/manager.ts:1245`), así que aparcar por edad = bloquear a la
  plataforma entera por una causa que es de la plataforma, no de las entradas.
- **Y contradice la decisión (i) del dueño del 2026-09-09**: «un 503 del backend NO consume intento
  … porque `maxAttempts` converge sobre lo IRREPARABLE y medido cinco peticiones AJENAS con el store
  caído aparcaban la entrada de otro» (CLAUDE.md, regla de higiene (i)). `parkAfterMs` reintroduce
  exactamente eso con otro reloj: aparca por una causa **común a todos**. Es el 🟠 4 de mi panel
  anterior, reabierto por la puerta de al lado.
- **El remedio no escala a propósito**: `requeue` ve como mucho `DEFAULT_RELAY_LIMIT` = 10 000
  aparcadas (`src/manager.ts:1563`), es todo-o-nada, cuesta una consulta `laterApplied` por id
  (2,5 ms medidos ⇒ ~25 s para 10 000) y el comando exige `--id` uno a uno. Con la cola aparcada en
  masa el runbook real acaba siendo `--force` (que es la reversión del 🔴 2 de alpha.5).
- **Steelman**: «con `attempts` congelado por el 503, `dead = 0` y la alarma del contrato es ciega
  justo cuando importa (auditor B2 de COGNITIV: 10 pasadas, 0/0)». → **El diagnóstico me convence
  entero; el remedio no**. La ceguera es de la ALARMA, y se arregla en la alarma.
- **Mitigación mínima**: alarma por edad (`oldestPendingAt`/`pendingAgeMs` + exit ≠ 0 del cron)
  **sin tocar `attempts` ni `dead()`**. Aparcar por tiempo: no se hace.

### 🟠 3 — Exentar la raíz solo en `#changeKeys` NO cierra el mutex: la otra mitad vive en el SQL del puerto (medido)

- **Escenario**: precondición — la cola tiene una entrada **pendiente** ajena `attached(orgY, app)`
  con id menor (no hace falta que esté aparcada). Acción — el alta pública de `orgC` releva con su
  recibo (`relayScopeChanges({ only })`), que es la receta inline del README. Resultado — `deferred
  (depends-on:#3)`: el alta no entra, exactamente el mutex que se quería quitar, aunque
  `#changeKeys` ya no devuelva `app`.
- **Evidencia**: ✅ medido, `relay2-auditor-1.ts`:
  ```
  [I.a] APARCADA attached(orgX, app) · alta de orgB con only ⇒ deferred (parked:1)
  [I.b] PENDIENTE ajena attached(orgY, app) (id menor) · alta de orgC con only ⇒ deferred (depends-on:3)
  [II]  earlierPending(mi id, [orgC, APP_SCOPE]) ⇒ #3 attached
  [II]  earlierPending(mi id, [orgC])            ⇒ null
  ```
  La lista de scopes de la sonda **no** sale de `#changeKeys`: se construye a mano en
  `src/manager.ts:1432` (`[change.child, change.parent]`) y la resuelve el SQL de
  `src/scope_outbox.ts:372-399`, que empareja `parent_type='app' AND parent_uuid IS NULL`. Hay
  **tres** sitios independientes que construyen esa lista: `#changeKeys` (`src/manager.ts:1959`),
  `#dependencyOf` (`:1432`) y `requeueScopeChanges` (`:1577`).
- **Por qué es 🟠 y no ⚪**: si el cambio se publica y el mutex sigue ahí, el siguiente paso natural
  del consumidor es apagar la sonda de dependencia — que es literalmente el 🔴 1 de
  `panel-relay-auditor.md` (escalada cruzada medida). Un arreglo que no arregla empuja al arreglo que
  rompe.
- **Steelman**: «lo que medimos son cinco pasadas COMPLETAS del cron con `applied = []`, y eso es la
  cara `parkedKeys`, que sí se cierra con `#changeKeys`». → **Convence a medias**: cierra su síntoma
  medido, pero ellos relevan también inline con `only`, y ahí la mitad `earlierPending` sigue viva.
- **Mitigación mínima**: la exención se decide en UN sitio (un `isRootKey(scope)`) y se aplica a los
  tres; y se decide sobre el REF (`type === APP_SCOPE_TYPE && uuid === null`), nunca comparando la
  cadena `'app'`.

### 🟠 4 — Si «obsoleta» se escribe como `applied_at`, `laterApplied` empieza a mentir y el operador acaba en `--force` (medido)

- **Escenario**: precondición — supersede marca la aparcada `#1 moved(unit→orgA)` con `applied_at`
  (la implementación barata: así desaparece de `dead()` y de `pending()`). Existe otra aparcada
  legítima `#0 attached(child, unit)` que comparte la clave `unit`. Acción — el operador reencola
  `#0`, que es lo correcto. Resultado — `E_AUTHZ_REQUEUE_REFUSED` nombrando `#1` como «aplicada
  posterior»… cuando `#1` **nunca tocó el store**. El diff que lee el operador es falso y la única
  salida que le queda es `--force`, que es la puerta de la reversión real.
- **Evidencia**: ✅ medido, `relay2-auditor-2.ts`:
  ```
  [D] laterApplied(#9) ⇒ #10 moved
  [D] requeue(#0) ⇒ E_AUTHZ_REQUEUE_REFUSED — y #10 NUNCA se aplicó al store (era la «obsoleta»)
  ```
- **Steelman**: «la negativa es la dirección segura: refusar de más no revierte nada». → **No me
  convence**: la dirección segura de un mecanismo cuyo `--force` está documentado como salida deja de
  serlo en cuanto los falsos positivos son rutina. La sonda vale lo que valga su diff.
- **Mitigación mínima**: estado terminal propio (`superseded_by`), jamás `applied_at`; y
  `laterApplied` sigue leyendo solo lo APLICADO de verdad.

### 🟠 5 — `requeue + relay bajo el MISMO lease` es `busy` en verde si se implementa tomando el lease dos veces (medido)

- **Escenario**: precondición — `apply: true` implementado como «tomo `outbox.acquire()`, reencolo y
  llamo a `relayScopeChanges({ only })»`. Acción — el operador ejecuta el comando durante el
  incidente. Resultado — el relay interno vuelve a llamar a `acquire()`, que **no es reentrante**:
  devuelve `null` ⇒ `busy: true`, `applied: []`, `failed: null`. El reporte parece limpio, el
  incidente no se ha cerrado y la entrada se ha quedado en `pending()` con `attempts = max − 1`, así
  que **se vuelve a aparcar en la primera pasada** y contamina su clave otra vez.
- **Evidencia**: ✅ medido en sqlite (`relay2-auditor-4.ts`):
  ```
  [L] acquire() · primero=lease · segundo=NULL (busy)
  [L] relayScopeChanges() con el lease ya tomado ⇒ busy=true, applied=0, failed=null
  ```
  🟡 En PG y MySQL no lo he ejecutado (el `postgres18` local rechazó las credenciales por defecto),
  pero el código dice lo mismo por construcción: `acquire()` abre **otra transacción**
  (`src/scope_outbox.ts:445`) y `pg_try_advisory_xact_lock` es por sesión/transacción, y `GET_LOCK`
  por sesión ⇒ una segunda toma desde otra conexión del pool da 0.
- **Steelman**: «lo haremos pasando el lease al relay». → Entonces `relayScopeChanges` necesita un
  parámetro nuevo de lease, y con él **la barrera del freeze y el `finally` de `release()` cambian de
  dueño**. Es aceptable, pero deja de ser un flag: es firma nueva en una API de plataforma.
- **Mitigación mínima**: `apply: true` no toma lease propio; reutiliza el del relay (relay adquiere,
  requeue va DENTRO) y devuelve `busy` como un fallo del comando (exit ≠ 0), nunca como verde.

### 🟠 6 — `apply: true` NO puede componer con `force`: la reversión del árbol pasa de dos llamadas a una (medido)

- **Escenario**: precondición — aparcada `#1 moved(unit→orgA)` y `#2 moved(unit→orgB)` YA aplicada.
  Acción — `requeueScopeChanges([#1], { force: true })` + `relayScopeChanges({ only: [#1] })`.
  Resultado — el store vuelve a `unit → orgA` **con un solo padre**, así que `assertOneParent` no lo
  delata: el tenant antiguo recupera el acceso (🔴 2 de alpha.5, sigue vivo por diseño detrás de
  `--force`).
- **Evidencia**: ✅ medido, `relay2-auditor-4.ts`:
  ```
  [F] requeue sin force ⇒ E_AUTHZ_REQUEUE_REFUSED (la sonda anti-reversión la caza)
  [F] requeue --force + relay({only}) ⇒ 1 aplicada · driver: moved unit→orgA
  [F] árbol del store: unit→orgA ⇒ REVERTIDO al padre VIEJO (dos llamadas de plataforma)
  ```
  Y ojo: **el camino `only` del relay no tiene sonda anti-reversión** — `#dependencyOf` mira lo
  PENDIENTE (`src/manager.ts:1432`), no lo APLICADO. Toda la protección vive en
  `requeueScopeChanges`. Si `apply: true` se implementa como un atajo que reencola y aplica, hereda
  esa asimetría.
- **Steelman**: «`force` ya existe y solo está en el comando ace». → Cierto hoy; el riesgo es la
  COMPOSICIÓN (`{ force: true, apply: true }` es una firma que invita), y las tres regresiones de la
  Fase 3 fueron por composición de piezas correctas.
- **Mitigación mínima**: `apply` y `force` mutuamente excluyentes en el tipo (dos overloads o 500 si
  llegan juntos), y `apply` solo en el comando ace, como `force`.

### 🟠 7 — `enqueue` sin `{ transaction }` es la fuga S5 en el camino de uso CORRECTO, y hoy es silenciosa

- **Escenario**: precondición — un controlador que abre `trx`, escribe su fila de árbol y llama
  `manager.scopes.moved(child, parent)` **sin** pasar `options.transaction` (la firma lo permite).
  Acción — la `trx` del consumidor hace rollback después. Resultado — la fila de la outbox **ya está
  confirmada** en otra conexión (`src/scope_outbox.ts:299`: `trx ?? on(database)`) y el relay aplica
  al store un cambio de árbol **que en la base del consumidor no ocurrió**: SQL dice un padre y el
  PDP otro, exactamente el S5 que la outbox existe para cerrar.
- **Evidencia**: ✅ código — `src/manager.ts:876/909/974` pasan `transaction: options?.transaction`
  (undefined si no llega) y `src/scope_outbox.ts:299` cae al `db` primario sin decir nada; el relay
  no re-resuelve nada (`#applyScopeChange`, `src/manager.ts:1985`), y en `openfga` el anticiclos se
  mide contra el STORE, no contra el consumidor, así que un `moved` fantasma entra.
- **Steelman**: «hay llamantes legítimos sin transacción: seeders, comandos ace, un controlador sin
  trx». → Convence para el seeder, no para el default. El paquete ya distingue esto en todas partes
  (invariante 6, `assertCallerTransaction`): la seguridad se declara, no se asume.
- **Mitigación mínima**: 500 `E_AUTHZ_CONFIG` por defecto **antes** del INSERT, con opt-in explícito
  (`sqlScopeOutbox({ allowNonTransactionalEnqueue: true })`) para seeders y comandos. Y el mensaje
  tiene que nombrar S5, no «falta un parámetro».

### 🟡 8 — Supersede es una primitiva de BORRADO DE ALARMA que puede accionar otro tenant

- **Escenario**: precondición — `requireWithin` en `true` y dos orgs bajo un mismo grupo (o
  `requireWithin` en **`false`, que es el default**, y entonces cualquiera). Acción — el tenant B
  hace su `moved` rutinario sobre un `child` que aparece en la entrada aparcada del tenant A.
  Resultado — la aparcada de A desaparece de `dead()`, con ella el `exit ≠ 0` del cron y el
  `last_error`: **el único registro durable de que un cambio de árbol nunca se aplicó** lo borra el
  tráfico de otro.
- **Evidencia**: ✅ código (`requireWithin` default `false`, `src/define_config.ts:242`; la
  contención de `moved` se mide contra la cadena de HOY del consumidor, invariante 15) — 🟡 el
  alcance cruzado real depende de la config del consumidor, no lo he medido con `within` activo.
- **Steelman**: «si el estado nuevo es correcto, la alarma vieja sobra». → Convence para la entrada,
  no para la CAUSA: si `#1` se aparcó por `E_AUTHZ_SCOPE_TREE_DRIFT` (dos padres en el store, que el
  driver denuncia y no arregla), la deriva sigue ahí y el aviso se ha ido.
- **Mitigación mínima**: supersede conserva la fila con estado propio y el relay la sigue contando en
  el reporte (`superseded`, con su `last_error`) aunque ya no tapone; y el criterio es **mismo
  `child` canónico**, jamás «comparte clave» (si no, un `attached(otraUnit, orgA)` de cualquiera
  superseda un `moved(unit → orgA)` ajeno).

### 🟡 9 — `report.dead` sigue siendo GLOBAL bajo `only`: enumeración entre tenants (y la petición de COGNITIV se queda corta)

- **Escenario**: el relay inline de un tenant recibe en `report.dead` **todas** las aparcadas de
  todos: id autoincremental, `change` completo (tipo y uuid de hijo y padre) y `error` (el mensaje
  del backend). Si el consumidor devuelve o loguea el reporte por petición, cada escritura de árbol
  de un tenant es una lectura del movimiento de árbol de los demás.
- **Evidencia**: ✅ código — `dead` se lee global (`src/manager.ts:1090`), `deadEntries` sí se filtra
  por `only` (`:1092-1101`) pero el campo `dead` del reporte va entero (`:1314`).
- **Corrección honesta a COGNITIV (su punto 5)**: el **actor NO se filtra en el reporte porque no
  está**: `#deadLetters` proyecta solo `{ id, change, attempts, error }`
  (`RelayedScopeChange`, `src/types.ts:1062`). Quitar `lastError` **no basta**: lo que identifica al
  otro tenant es `change`.
- **Mitigación mínima**: bajo `only`, `dead` = contador (+ las entradas que estén en `only`);
  `remaining` ya es un booleano y está bien así.

### ⚪ 10 — El 422 de profundidad le cuenta al tenant qué backend corres y cómo está tuneado

- **Escenario**: un tenant crea una unit demasiado profunda y recibe un 422 cuyo mensaje nombra
  `openfga`, `FACTS_MAX_RESOLVE_DEPTH (22)` y `OPENFGA_RESOLVE_NODE_LIMIT`
  (`src/manager.ts:2255-2259`). No es un bypass: es fingerprinting del PDP y de su configuración,
  entregado a quien no lo necesita para arreglar su árbol.
- **Evidencia**: ✅ código.
- **Steelman**: «el mensaje es accionable y `maxDepth` es config del propio consumidor». → Convence
  para el operador, no para el usuario final: el consumidor no tiene hoy dónde cortar (un solo
  `message`).
- **Mitigación mínima**: partir el error en `message` público («el scope quedaría a N saltos de la
  raíz y el techo es M») y `details`/docblock para el operador, con el porqué del techo.

### ⚪ 11 — La alarma por edad se mide con el reloj de la app que ESCRIBIÓ la fila

- `created_at` lo pone `options.now` de la outbox (`src/scope_outbox.ts:330`) y la edad la calcularía
  otra instancia con su propio reloj: con dos réplicas desfasadas la alarma se mueve el desfase (o se
  apaga, si la fila queda «en el futuro»). No es explotable por un tenant (no controla `created_at`),
  pero una alarma que es la ÚNICA señal en el hueco del 503 no debería depender de eso.
- **Mitigación mínima**: la edad la calcula la BASE (`min(created_at)` contra `now()` del motor) o se
  documenta el supuesto de reloj.

---

## Lo que intenté y NO se rompió

- **Cambio 1, caso (a) — restauración con el MISMO uuid**: `detached(orgA)` APARCADA +
  `attached(orgA, app)` sigue aplazado **por la clave del HIJO** (`organization|<uuid>`), no por
  `app`, así que la exención no lo abre. Medido (`relay2-auditor-1.ts`, `[III]`: `deferred /
  parked:#5` con la aparcada del `detached` como único origen posible). Tampoco por ortografías:
  `scopeSpellings` encola una fila por ortografía (`src/manager.ts:966-978`) y el `attached` usa
  `chain[0]`, que es una de ellas.
- **Cambio 1, caso (b)** — `moved(unit1 → app)` aparcada + `attached(unit2, app)`: hoy se aplaza
  **solo** por la clave `app` (medido, `[IV]`); los dos cambios no comparten ningún nodo y aplicarlos
  en cualquier orden da el mismo árbol. No encontré ningún par de cambios cuya ÚNICA clave común sea
  `app` y cuyo orden importe: `app` no se mueve, no se purga (422 en `scopes.detached`), nunca es
  hijo (`#assertEdge`), y `#changeKeys(detached)` ni siquiera lleva padre (`src/manager.ts:1960`).
- **Colisión de la clave `'app'`**: no se puede fabricar un scope cuyo `scopeKey` sea `'app'`
  (`{app, uuid}` es 422 en `assertScope`; `scopeKey` da `<tipo>|<uuid>` para todo lo demás,
  `src/identity.ts:225`). La exención por cadena no es explotable — aun así, hazla por REF.
- **El tapón sobrevive a `requeue`**: reencolar una aparcada NO la libera del censo de OTRAS
  aparcadas que comparten clave (`[T]` de `relay2-auditor-4.ts`: `deferred (parked:#2)`). Un
  `apply: true` heredaría ese aplazamiento, que es lo correcto (y lo que hará que el operador pida un
  `--force`: ver 🟠 6).
- **La sonda anti-reversión caza el `requeue` posterior a un supersede**: si la superseding queda
  `applied`, `laterApplied` la ve y `requeue` es `E_AUTHZ_REQUEUE_REFUSED` (`[F]` medido); si la
  supersedida sale de `dead()`, `requeue` la rechaza con «no está aparcada» (todo o nada). Las dos
  variantes cierran; el problema es la de en medio (🟠 4).
- **Aplicar `attached` fuera de orden no deja bindings locales sucios**: `onScopeAttached` pasa por
  el mismo `reparent` que `moved` y **también** barre (`sweepLocalRoleBindings`,
  `src/drivers/openfga_driver.ts:1592/1769`), así que el orden `attached(child, unit)` antes de
  `moved(unit → orgB)` no deja un rol local concediendo fuera de su owner. Intenté ahí una escalada
  por invariante 18 y no salió.
- **Un `detached` no se cuela por la exención de la raíz**: `detached` nunca nombra a `app`, y su
  exención frente a bloqueos de origen «aparcado» ya está medida desde alpha.5/6 (🟠 1 cerrado).

## Condición para cada cambio (o «no se hace»)

**1 · Exentar la raíz `app`.** SÍ, con dos condiciones:
  (a) la exención se aplica a los **tres** constructores de claves/scopes —`#changeKeys`
      (`src/manager.ts:1959`), `#dependencyOf` (`:1432`) y `requeueScopeChanges` (`:1577`)— o el
      mutex sigue vivo bajo `only` (🟠 3, medido); en `#dependencyOf` la lista nunca queda vacía
      (siempre va el hijo).
  (b) se decide sobre el REF, no sobre la cadena `'app'`, y va con un caso que fije que **la clave
      del HIJO sigue ordenando** la restauración `detached`+`attached` del mismo uuid (el caso (a)
      del encargo, hoy verde por el hijo).
  Sobre (c) del encargo —exentar solo para el TAPÓN y no para el aplazamiento por fallo—: es la
  variante más conservadora y **cierra el síntoma que COGNITIV midió** (`parked:` en pasada
  completa), pero no la mitad `earlierPending` de su propio camino inline. Un fallo real bajo la raíz
  contamina una sola pasada, así que dejarlo como está no cuesta casi nada: **recomiendo exentar el
  tapón + la sonda, y dejar el bloqueo por FALLO tal cual**.

**2 · «Supersede».** NO tal cual. Condiciones para que exista:
  (a) la clave se libera **solo cuando el superseding está `applied`** (o la pasada aplica el
      superseding ANTES que las entradas de en medio); mientras tanto, todo lo de en medio sigue
      aplazado — si no, es el 🔴 1 medido;
  (b) el criterio es **mismo `child` canónico y misma familia de op** (`moved`/`attached`), nunca
      «comparte clave», y **jamás cruza un `detached` del mismo child**;
  (c) la supersedida conserva su fila con estado propio (`superseded_by`), **nunca `applied_at`**
      (🟠 4), y sigue saliendo en el reporte con su `last_error` para que la CAUSA no se pierda;
  (d) se registra quién la supersedió (actor), porque puede ser otro tenant (🟡 8).
  Sin (a) y (c), mi respuesta es no se hace: el fail-open que abre es peor que el que cierra —y el
  que cierra («el store conserva el padre viejo indefinidamente») ya tiene remedio publicado,
  `authz:reconcile --to=<driver>`, que recalcula con el árbol de HOY y no reordena nada.

**3 · `requeueScopeChanges(ids, { apply: true })`.** SÍ, con tres condiciones:
  (a) no toma lease propio: el relay adquiere y el requeue va dentro, o es `busy` en verde para
      siempre (🟠 5, medido);
  (b) `apply` y `force` **no componen** (500 si llegan juntos): con las dos, revertir el árbol es una
      sola llamada (🟠 6, medido);
  (c) sigue siendo API de PLATAFORMA con la misma letra que `driver()`/`pruneOrphanRoles`, y el
      `only` interno lo construye el propio método con el id reencolado — nunca el cuerpo de una
      petición. Hoy la única defensa contra «un tenant aplica la aparcada de otro» es **prosa** (no
      hay mecanismo que impida exponerlo por HTTP), y `apply: true` sube el premio de exponerlo: pasa
      de «reordeno la cola» a «escribo el árbol del store de cualquiera». Si se quiere mecanismo y no
      prosa, la vía es la misma que ya existe para el freeze: exigir un token/flag de plataforma en
      la config, no un comentario.

**4 · Aparcado por TIEMPO.** No se hace (🔴 2). **Alarma por edad**: sí, y es lo que arregla su B2:
  `oldestPendingAt` + `pendingAgeMs` + `pending`/`dead` en el reporte, `exit ≠ 0` del cron por umbral,
  sin tocar `attempts` ni `dead()`. Bajo `only` esos números son globales: **son un contador y una
  marca de tiempo, no filtran identidad de nadie** (a diferencia de `dead`, 🟡 9), así que como
  máximo revelan «hay backlog», que es justo lo que se quiere publicar. Que la edad la mida la BASE
  (⚪ 11).

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **Supersede: ¿por qué no `authz:reconcile --to=<driver>`?** Ya recalcula con el árbol de hoy, no
   reordena y es el remedio que el propio `requeue` recomienda en su 500. Si la respuesta es «no
   podemos correr reconcile por tenant», eso es un requisito distinto (reconcile acotado) y no pide
   tocar el orden del relay.
2. **¿`requireWithin` está en `true` en COGNITIV?** De eso depende que el 🟡 8 sea 🟡 o 🟠: con el
   default (`false`) cualquier call-site superseda la entrada de cualquiera.
3. **¿El reporte del relay inline se devuelve o se loguea en la petición?** Si sí, el 🟡 9 sube a 🟠
   antes de añadir nada más al reporte.
