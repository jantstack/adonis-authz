# Fase 3b · Lote 3b-2a — informe del implementador

> Árbol principal, rama `v2/fase-3b`, base `9478c7f`. Sin commits (los hace el dueño).
> Encargo: `.claude/contexto/fase-3b-lote-2-plan.md`, piezas **A1–A6** y nada más.
> Diseño ya validado: `panel2-2026-08-28-juez.md` (cruces 1, 7 y 9).

## Cifras de partida (medidas antes de tocar nada)

```
OPENFGA_TEST_URL=http://localhost:8101 npm test   → 536 passed
```

(las otras tres se miden al final, contra 538 / 704 / 704)

---

## A1 · `openFgaFactsModel(holderTypes, permissions)`

**Casos escritos** (`tests/openfga_facts.spec.ts`):

1. `openFgaFactsModel(HOLDERS, PERMISSIONS)` **deepEqual** contra el literal del plan,
   escrito a mano en el test para 2 permisos (`docs:read`, `docs:write`) y 3 holderTypes
   (`user`, `admin`, `integration`).
2. **Servidor real** (`OPENFGA_TEST_URL`): store nuevo ⇒ `writeAuthorizationModel(modelo)` ⇒
   `authorization_model_id` no vacío; store borrado en el teardown.
3. **Semántica mínima de (c2) contra el servidor real** (no es `authorize`; son tuplas y
   `Check` crudos): grant en `app` concede en la organization hija (invariante 1), un permiso
   que el rol NO vincula no se concede, `denied_docs_read` en el hijo gana (invariante 2), y
   `ancestor` responde `true` sin una sola tupla extra.

**Rojo 1 — el caso no podía pasar porque la función no existía:**

```
ℹ SyntaxError: The requested module '../src/openfga.js' does not provide an export named 'openFgaFactsModel'
 ⁃ (tests/openfga_facts.spec.ts:12:undefined)
```

**Rojo 2 — el servidor RECHAZA un modelo mal generado.** Quitando `roleRelations[r.permits] = { this: {} }`
(el tipo `role` deja de declarar la relación que el TTU de `role_binding` referencia):

```
❯ facts · A1 — el servidor real acepta el modelo (c2) / OpenFGA acepta el modelo generado …
ℹ FgaApiValidationError: FGA API Validation Error: post authorization-models :
  Error undefined relation: permits_docs_read does not appear as a relation in any of the
  directly related user types [type:"role"]
```

**Rojo 3 — la semántica se mide de verdad.** Cambiando `can_<P>` de `difference` a `union`
(el deny dejaría de ganar), con el modelo ACEPTADO por el servidor:

```
❯ … / la semántica de (c2): el catálogo por tuplas concede, el árbol hereda hacia abajo y el deny gana
- false
+ true
ℹ AssertionError: el deny explícito gana (invariante 2): expected true to be false
```

**Verde**: `src/drivers/openfga_facts.ts` (nuevo, **puro: no importa `@openfga/sdk`**) con
`openFgaFactsModel`, `factsRelationsOf`, `factsRelationMap`. Re-exportado por el subpath
`src/openfga.ts`.

**Decisiones donde el plan no lo decía:**

- **Fichero nuevo `src/drivers/openfga_facts.ts` en vez de engordar el driver** (1638 líneas).
  Es pieza pura y testeable sola, que es lo que el plan pide de este sub-lote. NO se ha
  añadido a `OPENFGA_TARGETS` de `check_purity.mjs` (regla 3): la regla existe porque
  `@openfga/sdk` es peer OPCIONAL y este módulo no lo importa, así que un consumidor
  solo-database que lo importara no rompería nada. Está anotado aquí por si el auditor
  prefiere lo contrario.
- **`assertHolderTypes` se ha MOVIDO** del driver a ese módulo (los dos generadores la
  necesitan) y el driver la re-exporta: `@jantstack/adonis-authz/openfga` sigue exportando
  el mismo símbolo. Es un movimiento, no un cambio de comportamiento.
- **`metadata.relations` lleva entrada para TODAS las relaciones**, con
  `directly_related_user_types: []` en las derivadas. El servidor lo acepta (caso 2).
- El orden de las relaciones de `scope` agrupa por permiso (`<P>`, `denied_<P>`, `can_<P>`)
  y deja `ancestor` al final, como el literal del plan.

## A2 · Colisión de familias (S4)

**Casos escritos:**

1. `['docs:read', 'can_docs:read']` ⇒ 422 `E_AUTHZ_INVALID_SLUG` cuyo mensaje nombra la
   relación `can_docs_read` **y los dos permisos**; el cliente espía (que generaría y
   escribiría el modelo, en ese orden) registra **0** escrituras de modelo.
2. Las otras dos familias (`denied_`, `permits_`) y una relación PROPIA del modelo
   (`parent`, de `scope`) colisionan igual.
3. Dos permisos que se proyectan a la misma relación (`docs:write` / `docs_write`) tampoco
   pasan por el generador (la misma regla que `assertNoSlugCollisions` en el núcleo, aquí sin
   depender de que alguien haya validado antes).

**Rojo** (se quitó el bloque `if (other !== undefined) throw …` de `factsRelationMap` antes
de escribir los casos):

```
❯ facts · A2 … / ['docs:read', 'can_docs:read'] ⇒ 422 nombrando los DOS permisos y la relación, y 0 escrituras de modelo
ℹ AssertionError: expected undefined to equal 422
❯ facts · A2 … / las otras dos familias colisionan igual, y también una relación PROPIA del modelo
ℹ AssertionError: docs:read, denied_docs:read: expected undefined to equal 422
❯ facts · A2 … / dos permisos que se proyectan a la MISMA relación (`docs:write` / `docs_write`) tampoco pasan
ℹ AssertionError: expected undefined to equal 422
Tests  3 passed, 3 failed (6)
```

(el modelo AMBIGUO se generaba sin quejarse, que es exactamente el defecto S4)

**Verde**: `factsRelationMap` con un `Map` nombre→origen sembrado con las cinco relaciones
propias del modelo (`role`, `assignee`, `parent`, `binding`, `ancestor`).

**Decisión:** el `Map` es un espacio de nombres **plano**, aunque las relaciones vivan en
tipos distintos (`permits_x` en `role`, `can_x` en `scope`). Es más estricto de lo
estrictamente necesario, pero no rechaza ningún catálogo legal —las cuatro familias tienen
prefijos disjuntos— y lo que sí rechaza es justo lo que `RESERVED_SLUGS` /
`RESERVED_SLUG_PREFIXES` ya prohíben en el núcleo.

## A4 · Cotas de nombre (relación ≤ 50, id de objeto ≤ 256)

**Casos escritos:**

1. Permiso de 43 caracteres ⇒ `permits_<P>` = 51 ⇒ 422 `E_AUTHZ_INVALID_SLUG` nombrando el
   permiso, el prefijo `permits_` y la cota 50.
2. **La misma cota en el `sync`, no en runtime**: `syncAuthzCatalog` con ese permiso ⇒ 422 y
   el catálogo no se escribe.
3. Id de objeto de 256+ caracteres ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` nombrando la cota y el
   tipo (`role`).

**Rojo:**

```
❯ … / un permiso cuyo `permits_<P>` pasa de 50 se rechaza nombrando el permiso y el prefijo que lo desborda
ℹ AssertionError: expected undefined to equal 422
❯ … / la misma cota se aplica en el SYNC, no en runtime: el catálogo no llega a escribirse
ℹ AssertionError: expected 'Slug de permiso inválido: \'aaaaaaaaa…' to include 'permits_'
❯ … / un id de objeto que pasa de 256 no se escribe: 422 E_AUTHZ_INVALID_IDENTITY
ℹ AssertionError: expected undefined to equal 422
```

**Verde**: cota de relación en `factsRelationMap` (nombra permiso + prefijo + cota) y
`assertFgaObjectId` llamada desde `factsCatalogTuples`. Y el mensaje de `assertValidSlug`
(`src/identity.ts`) ahora **nombra el prefijo que desborda** y la relación resultante —el
rechazo por longitud en el sync ya existía desde S13 (`MAX_SLUG_LENGTH` = 42 = 50 − `permits_`),
lo que faltaba era decir por qué.

**Honestidad sobre la cota de id de objeto:** con la gramática publicada es **inalcanzable**
(`role:<uuid>` = 41; el id más largo del motor, `role_binding:<tipo>|<uuid>|<roleUuid>`, son
107). El caso negativo entra por la única puerta real que tiene —las partes salen de la BASE—
pasando un uuid corrupto a `factsCatalogTuples`. No se ha inventado un camino que no existe.

## A3 · Techo del modelo (262.144 bytes) — y una corrección de MEDIDA

**Casos escritos:**

1. Catálogo sintético de **289 permisos** (slugs de 40) ⇒ 500 `E_AUTHZ_MODEL_TOO_LARGE`
   nombrando los bytes (273.049) y el nº de permisos; `authz_permissions` sigue a **0** y la
   proyección hace **0** escrituras: se valida ANTES de escribir.
2. **230 permisos** (≈ 83 % del techo) ⇒ escribe los 230 **y** avisa una vez por el `logger`
   del driver, nombrando el techo y el nº de permisos.
3. Catálogo normal (2 permisos) ⇒ escribe y **no** avisa (`logs` vacío).
4. **Calibración contra el servidor real**: para cuatro formas de catálogo distintas
   (1/3/6 holders, slugs cortos y de 40) el número que calcula el paquete es **exactamente**
   el que OpenFGA reporta al rechazar.

**Rojo:**

```
❯ facts · A3 … / un catálogo que pasa del techo ⇒ 500 E_AUTHZ_MODEL_TOO_LARGE …
ℹ AssertionError: expected undefined to equal 500
❯ facts · A3 … / al 80 % del techo: escribe Y avisa por el canal de log del driver
ℹ TypeError: driver.catalogProjection is not a function
❯ facts · A3 … / un catálogo normal: escribe y NO avisa
ℹ TypeError: driver.catalogProjection is not a function
```

**Verde:** `assertFactsModelPublishable` + la costura `SyncCatalogOptions.projection`
(`src/catalog.ts`) + `OpenFgaAuthorizationDriver.catalogProjection()`.

### Lo que el plan daba por hecho y NO era cierto: cómo se miden esos bytes

El plan dice «techo del modelo: 262.144 bytes (medido, ≈720 permisos)». La primera versión
medía `JSON.stringify(modelo).length`, y **esa medida no sirve**: OpenFGA compara
`proto.Size(AuthorizationModel)` contra `OPENFGA_MAX_AUTHORIZATION_MODEL_SIZE_IN_BYTES`.
Medido contra el `:8101` (v1.19):

| forma | JSON | servidor | razón |
|---|---|---|---|
| 1 holder, slug corto, 1500 permisos | 1.465.312 | 476.164 | 0,325 |
| 3 holders, slug corto, 800 | 863.546 | 290.762 | 0,337 |
| 3 holders, slug de 40, 500 | 829.306 | 472.023 | **0,569** |

La razón **no es constante** (depende de la longitud de los slugs), así que un techo sobre el
JSON o deja pasar lo que el servidor rechaza (fail-open) o rechaza catálogos legales con el
doble de margen. Con el techo puesto sobre el JSON, un catálogo de 400 permisos cortos —que
el servidor acepta— se habría rechazado.

**Decisión:** `factsModelBytes` calcula el tamaño **protobuf exacto** (aritmética de
longitudes: tags de 1 byte, varints, `map<K,V>` como entradas `key=1/value=2`, strings vacíos
y enums 0 que no se serializan, y el id ULID de 26 caracteres que el servidor asigna antes de
medir). El caso 4 de arriba lo contrasta con el servidor: **delta 0** en las cuatro formas.
Con 3 holders y slugs cortos el techo cae en **≈720 permisos**, que es justo la cifra del
plan — lo que confirma que esa era la medida buena.

Sin ese caso contra el servidor, el guardián de A3 habría sido un número inventado.

## A5 · La proyección del catálogo (tuplas `permits_<P>`)

**Casos escritos:**

1. El primer sync escribe **una tupla por (rol, permiso, holder)** con el comodín de USUARIO:
   `user:*#permits_docs_read@role:<uuid>`, etc. (6 tuplas para 1 rol × 2 permisos × 3 holders),
   en **1** `Write`; el informe dice `{ written: 6, deleted: 0, unchanged: 0 }`.
2. **El caso del plan**: quitar 1 permiso de 1 rol con 3 holderTypes ⇒ exactamente **1**
   `Write` con **3 deletes** y **0 writes**, y **0** llamadas a `writeTuples`/`deleteTuples`
   (el patrón que el panel prohíbe en el cruce 8, por no ser atómico dentro de la request).
   No se reescribe el modelo.
3. **Idempotencia**: dos syncs seguidos ⇒ el segundo escribe **0** tuplas y **no llama** al
   servidor (`{ written: 0, deleted: 0, unchanged: 6 }`).
4. Una tupla escrita a mano que el catálogo no respalda se **borra**: el espejo converge. (Es
   el riesgo 4 del panel: con (c2) una sola tupla concede un permiso a un rol globalmente.)

**Rojo** (se dejó primero una `projectCatalog` ingenua: escribir todo, no borrar nada, una
llamada por tupla):

```
❯ … / el primer sync escribe una tupla por (rol, permiso, holder), con el comodín de USUARIO
ℹ AssertionError: expected [] to have a length of 1 but got +0
❯ … / quitar 1 permiso de 1 rol con 3 holderTypes ⇒ exactamente 1 Write con 3 deletes y 0 writes
ℹ AssertionError: expected { written: 3, deleted: +0, …(1) } to deeply equal { written: +0, deleted: 3, …(1) }
❯ … / idempotencia: el segundo sync seguido escribe 0 tuplas y no llama al servidor
ℹ AssertionError: expected { written: 6, deleted: +0, …(1) } to deeply equal { written: +0, deleted: +0, …(1) }
❯ … / una tupla que el catálogo ya no respalda se borra aunque nadie la haya pedido
ℹ AssertionError: expected { written: 3, deleted: +0, …(1) } to deeply equal { written: +0, deleted: 1, …(1) }
```

**Verde:** `OpenFgaAuthorizationDriver.projectCatalog` (diff contra un `Read` por prefijo de
tipo, deletes y writes en el MISMO `client.write` por lote de 100) y la foto del catálogo que
`syncAuthzCatalog` toma dentro de su transacción.

**Decisiones donde el plan no lo decía:**

- **`client.write({ writes, deletes })`, no `writeTuples`.** El plan escribe «exactamente 1
  `writeTuples`», pero en el SDK `writeTuples` **no puede llevar deletes**: la primitiva de UNA
  sola request con deletes+writes es `client.write`. El espía cuenta 1 `write` **y 0**
  `writeTuples`/`deleteTuples`, que es lo que el cruce 8 quiere decir («UN solo `Write`»,
  «queda prohibido `deleteTuples()` + `writeTuples()`»).
- **La proyección corre DESPUÉS del commit de SQL**, no dentro de la transacción: el store no
  participa del commit (no hay 2PC) y la fuente de verdad es `authz_*`. Un fallo ahí deja
  deriva reconstruible (`authz:reconcile`, 3b-3), nunca una concesión que la base no respalde.
  Lo que sí va DENTRO de la transacción es la foto del catálogo (coherente) y la validación de
  publicabilidad (antes de escribir).
- **La foto es del catálogo ENTERO, no del spec**: un espejo solo sabe lo que le sobra
  comparándose con todo. Son 3 consultas más por sync, y solo si hay `projection`.
- Conflictos estrictos: `client.write` va con los defaults del SDK (`on_duplicate: error`,
  `on_missing: error`). Como el diff se calcula sobre una lectura fresca, un duplicado o un
  borrado ausente significan una carrera con otro sync, y eso sale como 503 clasificado en vez
  de taparse — al contrario que el `Ignore` del importador, que era el bug S7.

## A6 · La proyección no se lee como catálogo

**Casos escritos:**

1. Espía: `listRoles`, `rolesInChain` y `authorize` (que pasa por `findPermission`) ⇒ **0**
   lecturas cuyo objeto sea del tipo `role:` y **0** relaciones `permits_*`, ni en `Read` ni en
   `batchCheck`. El caso comprueba además que esas llamadas **sí** leyeron y chequearon algo
   (si no, no probaría nada).
2. Guardia de fuente: en el driver, el tipo `role` solo se usa **una vez** y está dentro de
   `projectCatalog`.

**Rojo** (se metió una lectura de la proyección en `rolesInChain`, que es exactamente el
defecto que la regla prohíbe):

```
❯ … / listRoles, rolesInChain y authorize (findPermission) hacen 0 lecturas sobre el tipo `role`
ℹ AssertionError: {"object":"role:"}: expected 'role:' not to match /^role:/
❯ … / guardia de fuente: el driver solo mira el tipo `role` en la proyección (una vez, y es una escritura)
ℹ AssertionError: expected [ 'FACTS_ROLE_TYPE}:', …(1) ] to have a length of 1 but got 2
```

**Verde:** ningún cambio de código — la propiedad se cumple por construcción y ahora está
FIJADA. `findPermission` sigue leyendo el memo del catálogo (`authz_*`), no el store.

---

## Ficheros tocados

| Fichero | Qué |
|---|---|
| `src/drivers/openfga_facts.ts` | **nuevo**. Modelo (c2), colisión de familias, cotas, tamaño protobuf, tuplas de la proyección, `assertHolderTypes` (movida del driver). Puro: no importa `@openfga/sdk`. |
| `tests/openfga_facts.spec.ts` | **nuevo**. 19 casos: A1 (3, dos contra el servidor real), A2 (3), A3 (4, uno contra el servidor real), A4 (3), A5 (4), A6 (2). |
| `src/drivers/openfga_driver.ts` | `catalogProjection()` + `projectCatalog()`; `assertHolderTypes` re-exportada. |
| `src/catalog.ts` | `SyncCatalogOptions.projection`, validación de publicabilidad ANTES de escribir, foto del catálogo dentro de la transacción, proyección tras el commit, `report.projection`. |
| `src/types.ts` | Puerto `CatalogProjection` + `CatalogProjectionSnapshot`/`Role`/`Report`. |
| `src/errors.ts`, `index.ts` | `ModelTooLargeError` (500, `E_AUTHZ_MODEL_TOO_LARGE`), exportado por la entrada principal. |
| `src/identity.ts` | El 422 por longitud de slug ahora nombra el prefijo que desborda (A4). Sin cambio de cota ni de comportamiento. |
| `src/openfga.ts` | Exporta el material de `facts` por el subpath. |
| `CHANGELOG.md`, `README.md`, `CLAUDE.md` | Entrada del lote, fila del error nuevo, mapa del código. |

## Verificación final

```
npx tsc --noEmit -p tsconfig.json                                  → sin salida (OK)
npm run typecheck (tsconfig.test.json)                             → sin salida (OK)
check:purity                                                       → ✔ (corre en cada npm test)

OPENFGA_TEST_URL=… npm test                    555 passed   (partida 536, +19)
OPENFGA_TEST_URL=… npm run test:sqlite-file    557 passed   (partida 538, +19)
TEST_PG_URL=… OPENFGA_TEST_URL=… npm run test:pg      723 passed   (partida 704, +19)
OPENFGA_TEST_URL=… npm run test:mysql                 723 passed   (partida 704, +19)
```

Las cinco suites existentes siguen verdes **sin un solo cambio de comportamiento** en
`authorize` / `grant` / `list*`: los 19 casos nuevos son todos del material nuevo. El único
cambio en una ruta ya existente es el TEXTO del 422 por longitud de slug (`identity.ts`), que
ningún caso afirmaba.

Ningún store queda en el `:8101`: los tres del `spec` se borran en su teardown y los de las
mediciones manuales se borraron en su propio script (`curl /stores` no lista ningún
`facts-model-*` ni `facts-size-*`).

## Lo que NO he hecho, y por qué

1. **Nada de 3b-2b/2c/2d/2e**, por encargo: no se escriben tuplas de `scope#parent`/`binding`,
   `authorize` sigue siendo el de hoy (cadena + `batchCheck`), no hay outbox, no hay
   capacidades nuevas y **no se ha borrado el modo `resolver`**. El tipo `scope` se GENERA en
   el modelo (es parte de (c2), como dice el plan) pero nadie escribe sus tuplas.
2. **Nadie instala el modelo `facts` en un store.** `openfga:provision` y
   `provisionOpenFgaStore` siguen escribiendo `openFgaAuthorizationModel` (el modelo del modo
   `resolver`). Cambiarlo obliga a decidir qué pasa con el `modelId` pineado y con el catálogo
   que ya está en la base — es 3b-2b/2e. Consecuencia práctica que hay que tener presente: hoy
   la proyección solo funciona contra un store cuyo modelo declare `permits_<P>`, y el único
   sitio donde se escribe ese modelo es la suite.
3. **`authz:catalog:sync` no pasa la proyección.** El comando no toca el manager y hacerlo
   exige resolver el driver y decidir el gate de construcción (`acceptScopeDriftRisk`,
   capacidades) que el plan pone en 3b-2d/2e. La costura está y es una línea cuando toque.
4. **No he tocado `src/testing/contract.ts` ni los conteos de `contract_harness.spec.ts`**: no
   hay capacidad nueva que juzgar todavía (eso es 3b-2e) y el lote tenía que ser aditivo.
5. **No he añadido `src/drivers/openfga_facts` a `OPENFGA_TARGETS` de `check_purity.mjs`.** La
   regla 3 existe porque `@openfga/sdk` es peer opcional y ese módulo no lo importa. Queda
   anotado por si el auditor prefiere cerrarlo igualmente (es una línea en el script).
6. **No he medido el techo de PROFUNDIDAD del modelo (c2)** —los ~23 saltos del cruce 9, que
   el juez marcó como «medición que le falta al panel»—. No es de A1–A6 y necesita `maxDepth`
   en `capabilities`, que es 3b-2e.
7. **No hay ningún `skip`** en lo que he escrito, y no hay capacidad declarada en `false` en
   este lote (las que lo estarán son de 3b-2e).
8. **No he hecho commits.**

## Aviso para el auditor / el tester

- La proyección corre **fuera** de la transacción SQL. Es deliberado (no hay 2PC y la fuente de
  verdad es `authz_*`), pero abre una ventana: `sync` confirmado + `project` caído = catálogo
  nuevo con espejo viejo. Hoy nadie decide con ese espejo (A6, y `authorize` no lo mira), así
  que no concede nada de más; en cuanto 3b-2c haga `authorize` con un solo `Check`, ESA ventana
  sí concede con el catálogo viejo hasta el siguiente `sync`/`reconcile`. Está en la lista de
  lo que `authz:reconcile` tiene que cubrir (3b-3).
- El diff de la proyección se calcula contra una lectura fresca y se escribe con los
  `conflict` estrictos del SDK: **dos `sync` a la vez** contra el mismo store salen como 503
  clasificado, no como escritura silenciosa. No hay cerrojo entre procesos para la parte FGA
  (el de `authz_catalog_version` cubre solo el SQL).
- `factsModelBytes` replica el cálculo de `proto.Size` del servidor. El caso que lo contrasta
  con el `:8101` es lo único que impide que se descalibre: si alguien lo borra, el techo de A3
  vuelve a ser un número inventado.
