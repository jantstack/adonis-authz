# `2.4.0-alpha.10` — informe del implementador (incremental)

Rama `main`, HEAD de partida `7fbc638` (alpha.9 publicada), árbol limpio al empezar (`git status` vacío).
**Sin commits; `version` sin tocar.** Fuente: `cognitiv-informe-6-acuse.md` + decisiones §2026-09-13.

## Estado

- [x] 1 · 🔴 dirección rancia en el manager
- [x] 2 · 🟠 `authz:unfreeze` con ventana caducada
- [x] 3 · 🟡 `leaseMs`/`untilMs` en la ventana adoptada
- [x] 4 · 🟠 letra de la pasada de mantenimiento
- [x] 5 · 🟡 `--partition-type=app --partition-uuid`
- [x] Docs · verificación final (y tres ampliaciones: ver abajo)

## 1 · 🔴 La dirección rancia — en el MANAGER

**Código.** `src/manager.ts` `reconcile()`: tras comprobar que `to` está registrado y ANTES de `factory()`,
`#factsOrigin` y `#durableFreezeContext`: `staleFrom = from !== undefined && from !== to && to === config.default`.
Sin `allowStaleSource` y sin `dryRun` ⇒ 500 **`E_AUTHZ_STALE_SOURCE_REFUSED`** (`StaleSourceRefusedError`,
`src/errors.ts`, exportado en `index.ts`) nombrando la dirección, el riesgo («resucitaría las revocaciones hechas
desde el cutover (y con --prune borraría lo concedido después)»), la salida (mantenimiento sin `--from`) y
`--allow-stale-source`. El reporte lleva **`staleSource: { to, from, allowed }`** siempre que la dirección sea
rancia (dry-run, o pasada levantada con la bandera) — precedente `massDelete`/`massPurge`. `ReconcileOptions.allowStaleSource`
en `src/types.ts`. Comando: bandera `--allow-stale-source` (sin `name:`), el 500 se imprime como error con exit 1
(no stack), y `reconcileLines` imprime aviso y es deriva SOLO en `--dry-run` sin `allowed`.

**Decidido y fijado con caso:** `from === to` sigue siendo el 500 `E_AUTHZ_CONFIG` de 3b-3b (el guard exige `from !== to`).

**Casos** (`tests/reconcile.spec.ts`, grupo «alpha.10 · 1 · la dirección rancia», dobles; `tests/command_flags.spec.ts`,
grupo «alpha.10 · 1 … por el kernel»):
- API: 500 con cero construcciones del origen, cero lecturas, cero llamadas al destino, store vacío, `freezeStatus()` null, letra.
- `allowStaleSource: true` entra y escribe; `staleSource.allowed = true`.
- `dryRun`: no lanza, `staleSource.allowed = false`, `reconcileLines.clean = false` con aviso.
- **Negativo obligatorio**: cutover legítimo (`default` = origen, `--to=<nuevo> --from=<activo>`) escribe y no marca (ni en dry-run).
- Kernel: 1a `--to=destino --from=origen --prune` con `default: 'destino'` ⇒ exit 1, store 0, destino no llamado, letra;
  1b `--allow-stale-source` entra (3 escrituras); 1c `--dry-run` exit 1 sin escribir.
- Servidor real (`:8101`, `3b-5 · 🔴 2`): tras revoke+deny en el despliegue `facts`, `--to=openfga --from=database`
  con y sin `--prune` ⇒ 500 y `authorize(despedido)` sigue `false`; freeze null. Y el dry-run de «el ORIGEN se dice»
  marca `staleSource` y no es limpio.

**Rojo observado** (`runs/p1-rojo.txt`): 3/5 rojos — el caso API no lanzaba (la pasada leía y escribía), sin `staleSource`.
**Verde**: 5/5; kernel 18/18; `reconcile.spec` con `:8101` 82/82; `migration_contract` 8/8.
**Mutantes**: (A) guard desactivado ⇒ API 1 rojo + kernel 1a rojo; (B) comparar `from` con el default ⇒ 4 rojos,
el negativo del cutover legítimo incluido.

**Consecuencias en tests EXISTENTES (no reabren la decisión; son su efecto):**
- `tests/reconcile.spec.ts` «🔴 2» monta `default: 'openfga'` y hacía la migración del día del cutover con
  `from: 'database'` ⇒ ahora lleva `allowStaleSource: true` (comentado).
- **`runMigrationContract` (publicado en `/testing`)**: con UN manager, uno de los dos tramos apunta siempre al
  `config.default` ⇒ el runner pasa `allowStaleSource: true` en los dos tramos y el tipo del harness lo declara.
  Medido: sin ello, 4/8 rojos contra el `:8101`. **Un harness de TERCEROS que construya sus opciones a mano en vez de
  reenviarlas recibirá el 500 en un tramo** — va como BREAKING en el CHANGELOG.
- **Hueco NO cubierto por la decisión (lo reporto, no lo implemento):** con `database` activo, `--to=database` SIN
  `--from` no es mantenimiento (`database` no declara `hierarchyFacts`) y `#factsEnumerator` elige el origen solo
  (el `openfga` registrado): es la MISMA dirección rancia (store congelado tras un rollback → `authz_*` vivas) sin
  `--from` que la delate. La decisión fija `from !== undefined`; cerrarlo es decisión del dueño.

## 2 · 🟠 `authz:unfreeze` con la ventana CADUCADA

**Código.** `manager.lastFreezeStatus()` (nuevo; `freezeStatus()` intacto): lee la fila; motivo `null` ⇒ `null`;
si no ⇒ `FreezeStatus & { expired, checkedAtMs }` (`expired = !freezeIsLive(row, reloj del config)`).
`unfreezePlan(status, fence, nowMs?)` (pura) gana `action: 'expired'`, evaluada ANTES de `--fence` (el incidente es
el mismo lo pida quien lo pida): mensaje con el holder, el motivo, el fence, la hora ISO en que venció, «hace N ms»
(con el reloj del config vía `checkedAtMs`), «las escrituras volvieron a entrar», «escrituras que el motor nuevo no
vio» y la receta (repetir la migración dentro de una ventana sin caducidad). El comando usa `lastFreezeStatus()`,
imprime ERROR, **limpia la fila** con `unfreeze({fence, holder})` (condicional por token: si otro tomó el freeze
entre medias, no toca nada) y sale 1. Decidido y fijado con caso: **el segundo `unfreeze` es éxito** («nada que
levantar»), el aviso se da una vez.

**Decisión de alcance (mía, dentro de la decisión):** `expired` vale para CUALQUIER kind (operator/reconcile/platform),
no solo operador — la decisión no distingue, y una ventana de pasada que caducó también fue un intervalo con
escrituras. El mensaje nombra el holder.

**Casos:** `freeze.spec.ts` — `unfreezePlan` puro con los tres estados (null ⇒ noop, viva ⇒ lift, caducada ⇒ expired
con ISO y letra, y con `--fence` también expired); grupo `lastFreezeStatus()` con reloj inyectado (null → viva
`expired:false` → +120 s `expired:true`, `untilMs` exacto, `freezeStatus()` sigue null → levantada null).
`command_flags.spec.ts` — por el kernel con reloj inyectado: `authz:freeze --reason --lease-ms=60000`, reloj +5 min,
`authz:unfreeze` ⇒ exit 1, letra con `2030-06-15T12:01:00.000Z`, `hace 240000 ms`, «volvieron a entrar»; fila con
`freeze_reason` null; segundo `authz:unfreeze` ⇒ exit ≠ 1.

**Rojo observado** (`runs/p2-rojo.txt`): 3 rojos — el kernel imprimía `[success] No hay ningún freeze vivo: nada que
levantar.` con exit 0 (el síntoma exacto de COGNITIV); el plan puro devolvía `lift`; `lastFreezeStatus` no existía.
**Verde**: 40/40 (`command_flags` + `freeze`). **Mutante** «caducada ⇒ noop»: 2 rojos (kernel + plan puro).

## 3 · 🟡 `leaseMs`/`untilMs` reales en la ventana de operador ADOPTADA

**Código.** `#durableFreezeContext` (rama `operatorAsContext`): `untilMs` = el de la fila; `leaseMs` =
`untilMs − ahora` (lo que le QUEDABA al adoptarla, reloj del config), `null` solo si `untilMs` es `null`.
`FrozenWindow.untilMs?` (solo en la ventana adoptada), `withFrozenWrites` lo pasa; `ReconcileReport.frozen.untilMs?` y
`RelationsReconcileReport.frozen.untilMs?` (opcionales: la ventana propia no lo lleva, su lease se renueva). Salida:
`reconcileLines` añade una línea — `warning` «corrió dentro de la ventana del operador (fence N), que CADUCA el <ISO>
(le quedaban N ms al empezar)…» o `log` «…sin caducidad»; `authz:relations:reconcile` usa `frozenWindowLabel()`
(exportada, pura) con la misma letra.

**Casos:** `reconcile.spec.ts` (grupo 3b-7) — con reloj inyectado: operador `freeze(…, { leaseMs: 60000 })`, +10 s,
`reconcile` del migrador ⇒ `frozen.untilMs = 12:01:00`, `frozen.leaseMs = 50000`, línea con la ISO y sin «sin caducidad»;
y sin lease ⇒ `leaseMs: null`, `untilMs: null`, «sin caducidad». `relations_reconcile_cli.spec.ts` — la línea con
`untilMs` dice «CADUCA el …»; con `untilMs: null`, «sin caducidad». El caso 3b-7 existente (`leaseMs: null` para la
ventana sin caducidad) sigue verde sin tocarlo.

**Rojo observado** (`runs/p3-rojo.txt`): `frozen.untilMs` undefined. **Verde** 76/76 (reconcile + freeze +
relations_reconcile_cli). **Mutante** «`leaseMs: null` fijo» (lo de alpha.9): rojo «expected null to equal 50000».

## 4 · 🟠 La letra de la pasada de MANTENIMIENTO

**Qué borra EXACTAMENTE (leído en `openfga_driver.ts`, `reconcile` + `readOriginFacts`/`wantAssignment`/`wantDeny`).**
En mantenimiento el origen es el propio store (`enumerateFacts`), así que `wanted` = lo que el store tiene MENOS lo que
el recorrido descarta. Toda tupla de familia `facts` del store que no está en `wanted` es `extra`:
- **sin `--prune`**: no se borra (`extra-fact` en `skipped`) — **salvo** la arista `scope#binding` que la regla de
  visibilidad prohíbe (`forbidden`, invariante 18), que se borra siempre y cuenta en `phases.facts.deleted` y
  `drift.roleVisibility`; y se ESCRIBE la `scope#binding` que la regla exige y falta (también familia `facts`).
- **con `--prune`**: se borran además los hechos descartados — `unknown-scope` (scope que ya no resuelve: las 3 tuplas
  de la asignación, lo medido por COGNITIV), `expired` (asignación caducada: `wantAssignment` la descarta), `unknown-role`
  (rol fuera del catálogo), `unknown-holder-type`, `permission-not-in-model` (deny) — y cualquier tupla de familia
  `facts` que `enumerateFacts` no emite o no entiende («los que sobran»). Lo AJENO no (alpha.9 · B).
- Asignaciones y denies: nunca se escriben ni se reescriben (origen = destino, misma caducidad).

**Frase nueva** (comando, 1.ª línea): «…rehace lo derivado (marcador de raíz, proyección del catálogo, árbol y
visibilidad de rol) y no escribe hechos; con --prune borra los de scopes que ya no resuelven, los caducados, los de
roles o permisos que el catálogo o el modelo ya no tienen (y los que sobran).» README `:1033`: «**it writes no fact;
with `--prune` it deletes the facts of scopes that no longer resolve**, the expired ones and those of roles or
permissions the catalog or the model no longer has (and the leftovers) — without `--prune` it deletes no assignment or
deny (only the role-visibility edges invariant 18 forbids) and reports them as `extra-fact`», con la nota histórica sin
repetir la frase falsa. Misma corrección en `CLAUDE.md` (regla 3b-5), docblocks de `commands/authz_reconcile.ts`,
`src/manager.ts` (`#factsOrigin`), `src/types.ts` (`factsOrigin`) y `src/drivers/openfga_driver.ts` (`readOriginFacts`).
Las entradas VIEJAS del CHANGELOG (`:959`, `:1938`) quedan como historia.

**Casos:** letra (`reconcile.spec.ts`, «3b-3a · authz:reconcile (las decisiones del comando)»): la 1.ª línea con y sin
`prune` no contiene «ni borra» y sí «no escribe hechos», «con --prune borra los de scopes que ya no resuelven», «los
caducados», «los que sobran»; el fuente del comando sin «ni borra un solo hecho»; README sin «writes and deletes no fact
at all» y con la frase nueva. Efecto (`:8101`, grupo 3b-5): despliegue `facts`, dos orgs con un grant cada una, se borra
una org de `demo_scopes` sin `detached`; mantenimiento sin `--prune` ⇒ `facts.deleted = 0`, `extra-fact > 0`; con
`--prune` ⇒ `facts.extra = 3`, `facts.deleted = 3` («sobran 3, borradas 3», la cifra de COGNITIV), el assignee de la
org muerta fuera del store, la otra org sigue concediendo, y la salida no dice «ni borra». (Con UNA sola org la pasada
es el origen ciego y el seguro `E_AUTHZ_MASS_RECONCILE_REFUSED` salta — por eso el hecho vivo de control.)

**Rojo observado** (`runs/p4-rojo.txt`): los 2 casos rojos — el efecto borró 3 y la línea decía «ni borra».
**Verde**: `reconcile.spec.ts` con `:8101` 85/85. **Mutante** «restaurar la frase vieja en el comando»: 2 rojos.

## 5 · 🟡 `--partition-type=app --partition-uuid=<x>`

**Código.** `commands/authz_relations_reconcile.ts`: antes de las dos comprobaciones de media pareja, `partitionType ===
'app' && partitionUuid` ⇒ error «la partición raíz no lleva uuid» (con las dos salidas) y exit 1, antes de construir
drivers ni enumerar.

**Caso** (`command_flags.spec.ts`, junto a A-7b/A-7c): A-7d por el kernel — `--partition-type=app --partition-uuid=<x>`
⇒ exit 1, cero particiones enumeradas, letra; negativo en el mismo caso: `--partition-type=app` a secas sale ≠ 1 y
enumera `{ type: 'app', uuid: null }`.

**Rojo observado** (`runs/p5-rojo.txt`): salía `[success] Sin deriva` con exit 0 tras reconciliar la raíz.
**Verde** 20/20. **Mutante** «guard desactivado»: 1 rojo (A-7d).

## Verificación intermedia (piezas 1-5, antes de la AMPLIACIÓN del coordinador)

`npx tsc --noEmit -p tsconfig.json` 0 · `npm run typecheck` 0 · `npm run check:purity` 0 · `npm run build` 0.
Con `OPENFGA_TEST_URL=http://localhost:8101`: `npm test` **1389** (base 1373, +16) · `test:sqlite-file` **1415** (1399) ·
`test:pg` **1511** (1495) · `test:mysql` **1513** (1497). Todo verde, aditivo. Corridas en `scratchpad/runs/final-*.txt`.

## AMPLIACIÓN (coordinador, auditoría de sistema sobre alpha.9)

### A1 · Pieza 1 rehecha ESTRUCTURAL (segunda ampliación: el guard mira el ORIGEN RESUELTO)

**Linaje «origen rancio del reconcile»** (tabla del analista §3.1, completada):

| # | Iteración | Commit | Qué cerró | Qué dejó abierto |
|---|---|---|---|---|
| 1 | 3b-5 (auditor final Fase 3b, 🔴 1 y 2) | `git log` 3b-5 (Fase 3b) | la pasada POR DEFECTO `--to=<activo facts>` leía `authz_*`: ahora lee del propio store (mantenimiento) | `--from` explícito hacia el activo |
| 2 | alpha.10 pieza 1 (primer guard) | sin commit (este lote) | `--to=<activo> --from=<otro>` en `manager.reconcile` | el origen elegido POR DESCARTE (`--to=database` activo sin `--from`) y el puerto de relaciones |
| 3 | auditoría de sistema S1 | publicado desde `2691d83` (Fase 4 lote 6) | — (hallazgo) | `authz:relations:reconcile --to=<activo>` sin `--from` |
| 4 | **alpha.10 estructural (este lote)** | sin commit | **ver abajo** | nada conocido en los dos puertos |

**Cierre estructural.** Roles: el guard es `to === config.default && from !== to && !#isMaintenancePass(to, target, from)`,
y `#isMaintenancePass` es el MISMO predicado que usa `#factsOrigin` para decidir de dónde se leen los hechos (antes era
una condición inline duplicable). O sea: hacia el activo, el único origen resuelto legítimo es el propio `to`; `--from`,
el descarte y `authz_*` se niegan igual. `staleSource.from` es `origin.resolved()` (el origen RESUELTO). Relaciones:
`runRelationsReconcile` exige `toKey`/`fromKey` (origen RESUELTO por el comando) y compara con el activo
`activeRelationsDriverKey(config)` = `relations.default ?? default`, función ÚNICA que usa también el provider.
`relations/` no tiene mantenimiento: hacia el activo NINGÚN origen distinto pasa.

**Tabla de verdad parametrizada** (`reconcile.spec.ts`, 9 filas, dobles): 1 mantenimiento pasa · 2/3 cutover inicial
(`--from` / `authz_*`) pasa · 4/5 vuelta antes de cambiar default (`--from` / descarte) pasa · 6/7 re-ejecutar tras
cambiar default con `--from` NIEGA · **8 `--to=db` activo SIN `--from` (descarte) NIEGA** · 9 destino activo que
reconstruye desde `authz_*` sin `--from` NIEGA. Cada fila «niega» comprueba además: cero lecturas/escrituras, sin
freeze, `dryRun` marca con el origen resuelto y no es limpio, `allowStaleSource` entra. Las filas «pasa» son los
negativos (verdes antes y después; no pueden estar rojas antes). **Mutantes**: sin guard ⇒ 7 rojos (filas 6-9 + 3
casos de API); **estructural «el guard mira `from`»** ⇒ rojas las filas 8 y 9 (sin `--from`) — `runs/p1b-mut-*.txt`.
Contra el `:8101`: fila 8 real (`default: 'database'`, `--to=database --prune` sin `--from` ⇒ 500, `authz_*` intactas,
`dryRun` marca `from: 'openfga'`). Kernel: 1d `--to=<activo>` sin `--from` ⇒ exit 1, «POR DESCARTE».

**Test que CODIFICABA el defecto, dado la vuelta** (`reconcile.spec.ts` «🔴 2», antes `:994`): migraba con el manager
que ya sirve desde `openfga` (`--to=openfga --from=database`). Ahora afirma que esa llamada se NIEGA y hace la migración
legítima con un manager `default: 'database'`. (La versión intermedia con `allowStaleSource: true` se retiró.)
`freeze.spec.ts:~306` (unfreezePlan con `null`): ver A2.

### A2 · S1 — la dirección rancia en RELACIONES

Código: `runRelationsReconcile` (la función del bucle por particiones) lleva el guard; el comando pasa `fromKey` (el
resuelto: `--from` o descarte), `activeKey` de su config, `--allow-stale-source` (sin `name:`), e imprime el 500 como
error con exit 1. `RelationsReconcileReport.staleSource`, `relationsReconcileLines` avisa y es deriva en dry-run.
**BREAKING**: `runRelationsReconcile` exige `toKey` y `fromKey` (sin ellas 500 `E_AUTHZ_CONFIG`) y su primer argumento
necesita `relationsDriverKey()` (nuevo en el manager). `activeRelationsDriverKey()` exportada en `src/define_config.ts`.
Casos (`command_flags.spec.ts`, grupo «alpha.10 · S1»): S1a `--to=openfga` sin `--from`, `default: openfga` ⇒ exit 1, cero
escrituras; S1b con `--prune` ⇒ cero borrados, u-new vive; S1c `relations.default` manda sobre `default`; S1d dry-run
exit 1 + aviso, `--allow-stale-source` entra; negativos: cutover legítimo (`default: database`, `--to=openfga` por
descarte) y vuelta antes de cambiar default pasan; función exportada sin `activeKey` usa el manager y sin claves es 500.
**Rojo**: el repro del auditor S1a/S1b (verde = defecto) estaba VERDE en el árbol antes del cambio (`runs/m4-tras-S1.txt`
lo muestra ya rojo tras él); mutante «sin guard» ⇒ 5 rojos; mutante «activo = `default` ignorando `relations.default`»
⇒ S1c rojo.

### A3 · S2 — la ventana del operador pisada

Decisión (fijada con caso): **`freeze()` no toma el freeze si la fila es una ventana de OPERADOR CADUCADA** ⇒ 503
`E_AUTHZ_OPERATOR_WINDOW_EXPIRED` (nuevo, exportado) nombrando holder, motivo, fence, ISO y la salida (`authz:unfreeze`
la reconoce y limpia; `authz:freeze` la reabre). Está en `freeze()` y no solo en `reconcile`, así que cubre por un solo
punto `reconcile`, `withFrozenWrites`, `runRelationsReconcile` y un `authz:freeze` nuevo. La fila de una PASADA caducada
(kind `reconcile`/`platform`) SÍ se toma encima: es el lease tras un SIGKILL, no evidencia (negativo con caso).
La variante «levantada antes de tiempo» deja motivo NULL (acto explícito del operador): no se detecta por la fila; la
cubre (b). (b) `FrozenWindow.window` / `report.frozen.window = 'operator' | 'own' | 'enclosing'`; `reconcileLines`
imprime SIEMPRE en qué ventana corrió («tomó SU PROPIA ventana … NO había ventana de operador viva» como warning);
`frozenWindowLabel` (relaciones) igual. Los comandos `authz:reconcile`, `authz:relations:reconcile` y `authz:freeze`
imprimen el 503 como error con exit 1.
Casos: kernel S2 (fila de operador por `acquireFreeze` desde «otro proceso», reloj +120 s ⇒ exit 1, ISO, destino no
llamado, fila con el motivo y el fence del operador, `unfreezePlan(lastFreezeStatus())` = `expired`); S2-control (con
ventana viva la salida dice «ventana del operador (fence N)» y no «PROPIA»; sin ventana dice «SU PROPIA ventana … NO había
ventana de operador viva»); gemelo relaciones (503 y rastro intacto; ventana propia ⇒ `window: 'own'` y «ventana PROPIA»);
`freeze.spec` (503 en `freeze()` y `withFrozenWrites`, fila intacta; reconocida se congela; pasada caducada se pisa).
**Rojo**: repro del auditor S2 y S2-control verdes (defecto) antes; ahora rojos (`runs/m4-tras-S2.txt`). Mutantes: sin la
comprobación en `freeze()` ⇒ 3 rojos; sin la línea «PROPIA» ⇒ S2-control rojo. Test existente ajustado:
`freeze.spec` relaciones `deepEqual(report.frozen)` añade `window: 'own'`.

### A4 · S3 — el runbook del cutover y `relations/`

Verificado en código: manda **`relations.default ?? config.default`** (`providers/authz_provider.ts`, ahora vía
`activeRelationsDriverKey`). README: el bloque del runbook añade `authz:relations:reconcile … [--partition-*]` dentro de
la ventana y antes del switch, y un párrafo «Relations move with `config.default`» (cero tuplas ⇒ todo `check` false
mientras `authz:reconcile --dry-run` sale limpio; una pasada por partición; qué clave manda; el guard usa la misma).
También la sección de migración de relaciones (`:645`) y la tabla de errores (`E_AUTHZ_STALE_SOURCE_REFUSED` ampliado,
`E_AUTHZ_OPERATOR_WINDOW_EXPIRED` nuevo). Caso de letra (`reconcile.spec.ts`): el bloque bash de la sección contiene
`authz:relations:reconcile --to=openfga` antes de `authz:unfreeze` y `relations.default`; la sección cita
`relations.default ?? config.default` y «one partition per pass»; `activeRelationsDriverKey` resuelve igual; el provider
la usa. **Rojo** con el README de HEAD (`runs/s3-rojo.txt`).

### A5 · S5/S6/S7 — `authz:scopes:relay`

S5: `--dry-run` con aparcadas ⇒ exit 1 también con pendientes. S6: con `--only`, cada id aplazado se nombra como «NO se ha
aplicado … no ha aterrizado» con exit 1; sin aplicados y con `missing` ⇒ warning con los ids; jamás «La outbox del árbol
está vacía» con `--only`. **Decisión**: un id `missing` NO es exit 1 (puede haberlo aplicado otra pasada concurrente —el
cron—, y la receta inline releva su propio recibo); lo que no aterrizó por aplazamiento sí. S7: `--max-age` inválido ⇒
error y exit 1 ANTES de `relayScopeChanges` («No se ha relevado nada»). Casos por el kernel (dados la vuelta respecto al
repro del auditor: S5 con aparcada+pendiente y control, S6 aplazada y errata, S7 con `-1` y `1.5` y el relay NO llamado).
**Rojo** con el `commands/authz_scopes_relay.ts` de HEAD: los 3 (`runs/relay-rojo-alpha9.txt`).

### A6 · M2 (tercera ampliación) y el aviso del harness

`command_flags.spec.ts` grupo «alpha.10 · M2»: M2-a `authz:relations:reconcile --dry-run` ⇒ 0 escrituras en el destino y
sin la bandera 1; M2-b `authz:reconcile --prune` ⇒ el sobrante se borra y sin la bandera se queda. **Mutante «bandera
inerte»** (`dryRun: false` / `prune: false` en la llamada del comando, la propiedad intacta): M2-a y M2-b rojos
(`runs/m2-mut-inertes.txt`). Aviso verificado con un spec temporal: `exec(['--to=x', '--partition-uuid='])` **relanza**
«Missing value for option "partition-uuid"»; corregido el comentario de `tests/helpers/ace.ts` (regla 2 con la
excepción). Ningún caso de este lote usa valores vacíos.

### A7 · GEMELOS por pieza (regla nueva: caso o «no aplica, porque…»)

| Pieza | Gemelo | Estado |
|---|---|---|
| 1 · origen rancio | `manager.reconcile` (API) | caso (tabla de 9 filas + API) |
| | `authz:reconcile` (comando) | caso kernel 1a/1b/1c/1d |
| | `runRelationsReconcile` (función de relaciones) | caso (S1 función exportada) |
| | `authz:relations:reconcile` (comando) | caso kernel S1a-S1d + negativos |
| | `reconcileRelations` (src/relations, a pelo) | no aplica: no puede ver al manager ni al config (regla 2 de pureza); es el primitivo y `runRelationsReconcile` es su puerta, documentado en el README |
| | `runMigrationContract` / `runRelationsReconcileContract` (`/testing`) | no aplica como defecto: no son despliegues; el primero pasa `allowStaleSource` (con caso: 4/8 rojos sin él), el segundo llama a `reconcileRelations` a pelo |
| | `manager.driver().reconcile(...)` | no aplica: salida documentada de todas las barreras |
| | relay / `requeue --apply` | no aplica: no eligen origen de hechos |
| 2 · unfreeze caducada | `authz:unfreeze` | caso kernel |
| | `manager.unfreeze(token)` | no aplica: condicional por token, lo llama el dueño que sabe si caducó (`lapsed`) |
| | `freezeStatus()` / barrera de escrituras | no aplica: caducada = no congelada por diseño (lease tras SIGKILL); se mantiene |
| | `freeze()` sobre la fila caducada (pisarla) | caso (S2) |
| 3 · lease adoptado | reporte de roles | caso |
| | reporte de relaciones / `frozenWindowLabel` | caso |
| | `withFrozenWrites` (`FrozenWindow`) | cubierto por el caso de relaciones (usa `withFrozenWrites`) |
| 4 · letra mantenimiento | comando, README, CLAUDE.md, docblocks (manager, types, openfga_driver) | caso de letra (comando + README) y de efecto |
| | `authz:relations:reconcile` | no aplica: no tiene pasada de mantenimiento ni afirma no borrar (`--prune` «deletes what the source no longer backs», verdadero) |
| 5 · app + uuid | comando | caso kernel A-7d |
| | `reconcileRelations({ partition: { type:'app', uuid } })` | **caso y arreglo** (500 `E_AUTHZ_CONFIG`; mutante ⇒ rojo) |
| S2 · ventana pisada | `authz:reconcile`, `runRelationsReconcile`, `withFrozenWrites`, `authz:freeze` | un solo punto (`freeze()`): casos kernel S2, gemelo relaciones, `freeze.spec` (freeze + withFrozenWrites) |
| | `pruneOrphanRoles` / relay / requeue | no aplica: no toman freeze, solo pasan la barrera |
| | salida «en qué ventana» | caso en roles (S2-control) y relaciones (`window: 'own'`) |
| S3 · runbook | README runbook + sección de relaciones + tabla de errores | caso de letra |
| S5-S7 · relay | `authz:scopes:requeue --apply` (imprime el relay) | no aplica S6 (no dice «vacía»: compara `applied` con `requeued` y marca no limpio) ni S7 (sin `--max-age`); S5 no aplica (no tiene `--dry-run`) |
| M2 | `--dry-run` relaciones, `--prune` roles | caso de efecto + mutante inerte |

## Verificación FINAL (con las tres ampliaciones)

`npx tsc --noEmit -p tsconfig.json` 0 · `npm run typecheck` 0 · `npm run check:purity` 0 · `npm run build` 0.
Con `OPENFGA_TEST_URL=http://localhost:8101`, en primer plano y en secuencia: **`npm test` 1415** (base 1373, +42) ·
**`test:sqlite-file` 1441** (1399, +42) · **`test:pg` 1537** (1495, +42) · **`test:mysql` 1539** (1497, +42). Todo verde,
sin `skip`. Corridas: `scratchpad/runs/final2-*.txt`. Repro del auditor (`sistema-m4.spec.ts`, verde = defecto) corrido
tras el lote (`runs/m4-final.txt`, copiado a `tests/` y retirado): **7 de 8 ROJOS** = defectos cerrados (S1a, S1b, S2,
S2-control, y los del spec S4/S5/S6 = S5/S7/S6 del informe); sigue VERDE solo su S3 (= S4 del informe: relay `--dry-run`
bajo freeze), fuera de este lote por instrucción.

## Lo que NO se hizo

- Commits y `version` (por instrucción).
- S4 (relay `--dry-run` bajo freeze) y S8 (verificador de relaciones que se traga el error de la config): siguiente lote.
- `runRelationsReconcile` sin claves era un paso libre; ahora es 500: **BREAKING para COGNITIV** si llaman a la función a
  pelo en su bucle (tienen que pasar `toKey`/`fromKey`). Anotado en CHANGELOG.
- No se generalizó la guardia M7 (reflexión) para el linaje: la tabla de verdad parametrizada es el caso; la guardia de
  superficie queda para el lote de metodología.
- La variante «ventana levantada ANTES de tiempo» (motivo NULL) no se detecta por la fila (es un acto explícito del
  operador); la cubre solo la salida («tomó SU PROPIA ventana … NO había ventana de operador viva»).

## Cierre (auditor)

Fuente: `alpha10-auditor.md` («APTA con cambios») + decisiones §2026-09-13 (6). Mismo árbol, sin commits, `version` sin
tocar. Corridas, rojos y mutantes en `scratchpad/cierre/` (`r2-*`, `r3-*`, `r1r4-*`, `mut-*.txt`, `final-*.txt`).
**Repro del auditor antes del cierre: 4/4 VERDES (defectos presentes). Tras el cierre: el spec ya no importa
(`reconcileRelations` no sale de `index.js`: R1 cerrado a nivel de import); con ese import redirigido al primitivo
privado (copia temporal, borrada), 4/4 ROJOS** (`repro-tras-cierre.txt`): R1 `E_AUTHZ_CONFIG` en el control (ya no se
aceptan instancias), R4 500 CONFIG, R2 423 `FREEZE_HELD` (no pisa), R3 nombra `#999` y no dice «vacía».

### R1 · 🟠 `reconcileRelations` sin guard ni freeze — ESTRUCTURAL (3.ª iteración de L6 en relaciones)

**Decisión medida: sacar el primitivo de la raíz; `runRelationsReconcile` es la única vía pública.**
- Medida 1 (pureza): `import type { AuthorizationManager }` en `src/relations/reconcile.ts` ⇒ `check:purity` exit 1
  («el módulo 'relations' importa 'src/manager'», `medida-pureza.txt`). El primitivo NO puede conocer el activo ni
  tomar `withFrozenWrites`.
- Medida 2 (superficie): el `exports` de `package.json` no tiene ningún subpath a `src/relations/`; la raíz (`index.ts`)
  era la ÚNICA puerta del primitivo.
- Descartada «opción obligatoria `active`»: sería otra etiqueta del llamante (exactamente el defecto R4) y seguiría sin
  freeze. Descartado «solo docs»: el linaje exige punto de paso único.
- Código: `index.ts` ya no exporta `reconcileRelations` (los tipos sí). README («from code» ⇒
  `runRelationsReconcile(authorization, { toKey, fromKey, partitions })` desde
  `@jantstack/adonis-authz/commands/authz_relations_reconcile`), sección del barrido y tabla de costes; JSDoc del
  primitivo («PRIMITIVO PRIVADO») y de la función. Roadmap 2.5: valorar subpath propio para la función.
- **Guardia de superficie (M7 del linaje)**: `command_flags.spec` «cierre alpha.10 · R1 · guardia de superficie»
  recorre TODOS los subpaths de `exports` (con el comodín `./commands/*`), importa cada módulo y falla si algún valor
  exportado `===` `reconcileRelations` (identidad, no nombre); `services/relations` (instancia) por fuente.
- Casos: «cierre · R1» (repro invertido: no está en la raíz, README ya no lo recomienda, `runRelationsReconcile({
  partitions, prune })` hacia el activo ⇒ STALE, 0 escrituras, 0 borrados, 0 drivers construidos, sin freeze).
- **Rojo observado**: `r1r4-rojo.txt` (los 2 casos R1 rojos con el export presente). **Mutante** `M1-reexport` (volver
  a exportar en `index.ts`) ⇒ 2 rojos.

### R4 · 🟡 etiquetas en vez de drivers — identidad RESUELTA (y su gemelo en roles)

- `runRelationsReconcile(authorization, { toKey, fromKey, partition|partitions, dryRun?, prune?, allowMassDelete?,
  allowStaleSource?, toConfig?, now? })`: resuelve las factories del config del MANAGER (nuevos
  `manager.relationsDriverKeys()` / `relationsDriverFactory(key)`); mismo driver ⇔ misma clave o misma factory;
  origen = destino ⇒ 500 CONFIG; activo = `manager.relationsDriverKey()` sin override; `from`/`to` instancias o
  `activeKey` ⇒ 500 CONFIG (entrada retirada, L5); ningún driver se construye antes del guard. Clave desconocida ⇒ 500
  CONFIG. El comando resuelve claves y descarte por el MISMO manager (antes: `this.app.config`) y saca 500 CONFIG como
  error con exit 1.
- **Gemelo roles** (encontrado al listar gemelos): `manager.reconcile` comparaba `name === config.default` por etiqueta
  — con `drivers: { activo: f, alias: f }`, `--to=alias --from=viejo` pasaba. Ahora `#sameDriver` (factory) en el guard,
  `#isMaintenancePass`, `#originDriver` (`from === to`) y el descarte de `#factsEnumerator`; la letra dice «la clave
  resuelve la MISMA factory que '<default>'».
- Casos: «cierre · R4 · las etiquetas ya no deciden» (repro invertido a y b + sin claves), **tabla de verdad 24 filas**
  (destino ∈ {activo, alias del activo, otro×2, mismo×2} × dryRun × allowStaleSource: niega/marca/pasa/config, con 0
  drivers construidos y 0 escrituras en las que niegan), «cierre · R4 gemelo roles» (alias STALE sin leer, dry-run marca,
  origen alias ⇒ CONFIG, alias fuera del descarte). Tests existentes ajustados a la firma nueva: 4 de `freeze.spec`
  (L-1 · J1), el gemelo S2 de relaciones, y los kernel A-7/S1/M2-a con `relationsAce` (cablea los tres lectores del
  manager global con un `AuthorizationManager` REAL construido desde el config del fixture).
- **Rojo**: el repro R4 del auditor verde en el árbol de partida (4/4 al empezar). **Mutantes**: `M4a-etiquetas`
  (`sameDriver = a === b`) ⇒ tabla roja; `M4b-activeKey` (aceptar override) ⇒ caso a/b rojo; `M4c-sin-guard` ⇒ 6 rojos
  (S1a-d, R1, tabla); `M4d` (activo ≠ el del manager) ⇒ 6 rojos; `M4r-roles-etiqueta` ⇒ gemelo roles rojo.

### R2 · 🟡 TOCTOU en `freeze()` — exclusión DENTRO del UPDATE

- `src/freeze.ts`: `acquireFreezeOutcome` ⇒ `acquired | held | expired-operator`; la rama «lease vencido» del `WHERE`
  exige `freeze_holder IS NULL OR freeze_holder NOT LIKE 'operator:%'`; la fila se relee solo para redactar; reintento
  acotado a 1 (antes recursión sin tope). `acquireFreeze` queda como envoltorio token|null. `freeze()` ya no hace
  «leo, compruebo, tomo»: una sola lectura de reloj.
- Casos (`freeze.spec`, corren en los 4 modos): «cierre · R2 · TOCTOU con reloj de DOS lecturas» (repro invertido: la
  pasada no toma —423 o 503—, holder, fence y motivo del operador intactos) y «cierre · R2 · la exclusión es ATÓMICA en
  el primitivo» (a T+1 el primitivo devuelve `expired-operator` con la fila idéntica; negativos: pasada vencida y fila
  legada sin holder se toman; viva ⇒ `held`).
- **Rojo** (`r2-rojo.txt`): 2 rojos (la pasada tomaba la fila). **Mutantes**: sin la exclusión en el WHERE ⇒ 2 rojos
  (primitivo + S2 existente); «comprobación fuera del UPDATE» (lo de antes) ⇒ 3 rojos.

### R3 · 🟡 `relay --dry-run --only` — misma letra que S6

- Rama `dryRun` con `--only`: línea por id `missing` (la misma de la pasada que aplica) y, sin pendientes, resumen
  propio `--dry-run: ninguno de los ids pedidos está pendiente (#…)`; «La outbox del árbol está vacía» SOLO sin `--only`.
  Exit: `missing` no es 1 (decisión S6); aparcadas sí.
- Casos: repro invertido por el kernel con el manager REAL y la outbox SQL; **tabla de verdad 12 filas** (--only ×
  pendientes × missing × aparcadas; «missing sin --only» no aplica: el manager nunca lo devuelve).
- **Rojo** (`r3-rojo.txt`): 2 rojos. **Mutantes**: sin el retorno bajo `--only` ⇒ 2 rojos; sin la línea por id ⇒ tabla
  roja (fila pendiente+missing).

### R5 · 🟡 el guard lee el config del PROCESO — declarado

README (bullet de roles y párrafo de relaciones), CHANGELOG («Declared limit»), docblocks
(`StaleSourceRefusedError`, `runRelationsReconcile`) y `roadmap-2.0.md` §2.5 «Sello durable del driver activo».
Caso de letra en `reconcile.spec` «cierre · letra».

### Decisión (6) · sin excepción en ventana viva ⇒ runbook reordenado

Bloque bash: verificación `--from … --dry-run` de roles Y relaciones ANTES del switch; tras el switch solo
`authz:reconcile --to=openfga --dry-run` (mantenimiento, sin `--from`); párrafo «Verify before the switch, never with
`--from` after it». Caso de letra (verificaciones antes del switch, nada con `--from=` después, sin
`--allow-stale-source` en el bloque). **Mutante** `M6` (verificación tras el switch) ⇒ rojo.

### ⚪ Higiene

1. Receta `--from=database --prune` (README): «Run it while `database` is still `config.default`», nombra
   `E_AUTHZ_STALE_SOURCE_REFUSED`, `--allow-stale-source` y el `--dry-run` previo. Caso de letra.
3. `src/errors.ts`: docblock recolocado sobre `StaleSourceRefusedError`. **Guardia**: ningún `*/` seguido de `/**` y
   cada clase del lote con su docblock. Mutante `Mh3` ⇒ rojo.
4. `authz:unfreeze` bajo carrera: la letra la decide el resultado del UPDATE y la fila releída (quitado «venció su
   lease»; «queda limpia» solo si casó). **Tabla de verdad 6 filas** (plan × casó × fila después), cada rama con línea y
   exit propios. Mutante `Mh4` (letras viejas) ⇒ rojo.
5. Fila con motivo y holder NULL: `UNKNOWN_HOLDER = '?'` es su token en `releaseFreeze` (NULL-match). Caso por el
   kernel con la BD: caducada ⇒ exit 1 y la limpia, segunda ⇒ éxito; viva ⇒ sin `--fence` se niega, con `--fence` se
   levanta. Mutante `Mh5` ⇒ rojo.
6. CHANGELOG: quitado «or lifted early» y explicado que esa variante solo la cubre la línea de salida.
7. CHANGELOG «Minor breaking changes of this release, by name»: `unfreezePlan` (unión + 3.er parámetro),
   `report.frozen.window/untilMs`, 503 nuevo de `freeze()`/`withFrozenWrites()`, y las rupturas del cierre
   (`reconcileRelations` fuera de la raíz, opciones de `runRelationsReconcile`).
8. (también) Un solo driver: la letra ya no habla de origen «POR DESCARTE» (sigue negando). Caso + mutante `Mh8`.

### Gemelos por pieza

| Pieza | Gemelo | Estado |
|---|---|---|
| R1/R4 origen rancio | `runRelationsReconcile` (función) | caso R1, R4, tabla 24 filas |
| | `authz:relations:reconcile` (comando) | kernel S1a–S1d + negativos (manager real vía `relationsAce`) |
| | `reconcileRelations` (primitivo) | privado; guardia de superficie + mutante |
| | `manager.reconcile` (roles, API) | caso gemelo roles (alias) + tabla de 9 filas existente |
| | `authz:reconcile` (comando roles) | kernel 1a–1d existentes (pasa por `manager.reconcile`) |
| | `runRelationsReconcileContract` (`/testing`) | no aplica: harness que siembra sus propias particiones uuidv7 en los drivers que le da el test; no expone el primitivo (la guardia recorre `./testing` por identidad) |
| | `runMigrationContract` | no aplica: sin cambios (sigue pasando `allowStaleSource: true`) |
| | relay / `requeue --apply` | no aplica: no eligen origen de hechos |
| R2 toma del freeze | `freeze()` | caso TOCTOU |
| | `acquireFreezeOutcome` ×3 motores | caso primitivo (corre en sqlite-file/pg/mysql) |
| | `withFrozenWrites`, `authz:reconcile`, `authz:relations:reconcile`, `authz:freeze` | un solo punto (`freeze()`): casos S2 existentes siguen verdes |
| | `renewFreeze` / `releaseFreeze` | no aplica: condicionales por token propio, nunca toman una fila ajena |
| R3 relay | `--dry-run` | caso + tabla 12 filas |
| | pasada que aplica (S6) | caso S6 existente |
| | `authz:scopes:requeue --apply` | no aplica: no tiene `--dry-run` y no imprime «vacía» |
| | `manager.relayScopeChanges({ dryRun, only })` | el caso con manager real afirma `missing: [999]` |
| R5 | roles ↔ relaciones (README) | caso de letra con las dos frases + CHANGELOG |
| ⚪4/⚪5 unfreeze | `authz:unfreeze` | tabla 6 filas + caso BD holder NULL |
| | `manager.unfreeze(token)` | cubierto por el caso BD (token `'?'`); devuelve booleano, no redacta |
| | `freezeStatus()` / `lastFreezeStatus()` | publican `'?'` (constante `UNKNOWN_HOLDER`, sin cambio de valor) |
| ⚪8 letra un driver | `manager.reconcile` | caso |
| | `authz:relations:reconcile` con un solo driver | no aplica: ya era «0 candidatos, nómbralo con --from» |

### Cifras (verificación final, en secuencia, `docker restart api-loco-base-openfga-1 && sleep 8` antes de cada suite)

`npx tsc --noEmit -p tsconfig.json` 0 · `npm run typecheck` 0 · `npm run check:purity` 0 · `npm run build` 0.
Con `OPENFGA_TEST_URL=http://localhost:8101` y `TEST_PG_URL` del contenedor: **`npm test` 1428** (1415, +13) ·
**`test:sqlite-file` 1454** (1441, +13) · **`test:pg` 1550** (1537, +13) · **`test:mysql` 1552** (1539, +13). Todo verde,
exit 0. Duraciones: 86 / 88 / 128 / 136 s. Corridas: `scratchpad/cierre/final-*.txt`.
+13 = freeze.spec 2 (R2) · command_flags 8 (R3 ×2, R1, R4 ×2 —sustituyen al caso «función exportada»—, superficie,
⚪4, ⚪5) · reconcile.spec 4 (⚪8, ⚪3, gemelo roles R4, letra runbook/receta/R5). Mutantes: 13 lanzados, 13 matados
(`mut-*.txt`, más `r2-mut-*`, `r3-mut*`).

### Lo que NO se hizo

- Commits y `version`. No toqué el repro del auditor (`alpha10-reataque.spec.ts` ya no importa: usa
  `reconcileRelations` desde `index.js`; para re-atacar hay que importar el primitivo de `src/relations/reconcile.js`).
- La guardia de superficie cubre la raíz y los subpaths para el primitivo de relaciones. Para roles, M7 sigue pendiente.
- Sello durable del driver activo (R5): solo declarado, está en el roadmap 2.5.

## Cierre-2

Fuente: `alpha10-auditor-cierre.md` (re-ataque: 0 🔴/🟠, 🟡 C1–C2, ⚪ C3–C7) + decisiones §2026-09-13 (7). Mismo árbol,
único agente que lo muta, sin commits, `version` sin tocar. Corridas, rojos y mutantes en `scratchpad/cierre2/`
(`repro-inicio.txt`, `c*-rojo.txt`, `mut-*.txt`, `mutantes-resumen.txt`, `final-*.txt`).
**Repro del auditor antes: 7/7 verdes** (5 DEFECTO presentes + 2 CONTROL). **Después: 3 verdes / 4 rojos**
(`repro-tras-cierre2.txt`): los DEFECTO de C2 (×2), C3 y C4 caen; el de C1 sigue verde **a propósito** (límite
DECLARADO, fijado con caso); los 2 CONTROL siguen verdes.

### C1 · 🟡 identidad por referencia de factory — DECLARADO

- Letra: README en los dos puertos (párrafo de relaciones «**Declared limit: identity is the factory reference, not
  the backend.**» con la receta «alias con la MISMA referencia»; bullet de roles junto a R5), CHANGELOG (segundo cierre),
  CLAUDE.md junto a R5, docblocks (`#sameDriver`, `relationsDriverFactory`, `runRelationsReconcile`), `roadmap-2.0.md`
  §2.5 «Identidad de backend declarada por el driver» (junto al sello durable de R5).
- Casos: `command_flags.spec` «cierre-2 · C1 · límite DECLARADO fijado» (repro convertido: misma referencia ⇒ STALE;
  otra arrow sobre el mismo store ⇒ pasa) y su gemelo de roles en `reconcile.spec` («cierre-2 · C1 gemelo roles»). Si 2.5
  trae la identidad de backend, los dos se ponen rojos a la vez que la letra: es lo que se quiere.
- Mutantes: `M-C1b-identidad-backend` (comparar también el texto de la factory) ⇒ rojo; `M-C1-readme-sin-limite` ⇒
  caso de letra rojo.

### C2 · 🟡 `--only` × `--limit`: «no existe» con el id PENDIENTE — `notEvaluated`

- `ScopeRelayReport.notEvaluated` (aditivo, obligatorio en el tipo): ids pedidos que SIGUEN PENDIENTES y la pasada no
  evaluó por `limit`. `missing` queda solo para «no está en la cola». `#relayInputs.unseenOf(seen)`: si hay ids pedidos
  sin ver, UNA lectura `pending(n, undefined, { ids: unseen })` (con `#assertOnlyHonoured`) los separa; misma función en
  `--dry-run`, en la pasada que aplica y en `requeue --apply` (comparten `#drainScopeChanges`); `busy` ⇒ `[]`.
- Comando: línea por id `#<id> está PENDIENTE y esta pasada NO lo evaluó (--dry-run | pasada que aplica): alcanzó
  --limit=N …` + resumen con los ids; **exit 1 en los dos modos**. El resumen «ninguno de los ids pedidos está pendiente»
  y «Ninguno … se ha aplicado» ya no salen si hay `notEvaluated`.
- **Gemelo encontrado al listar gemelos** (misma letra falsa): un id pedido APARCADO más allá del primer lote de `dead`
  (acotado a `batchSize`) era `missing`. `deadEntries` bajo `only` sale del CENSO completo si la lectura se cortó; el
  comando nombra `APARCADO …` los que no están en `report.dead` y sale 1.
- Casos (`command_flags.spec`, kernel + manager REAL + `sqlScopeOutbox`, corren en los 4 modos): **tabla de verdad 16
  filas** (estado del id T ∈ {pendiente, aparcado, aplicado, inexistente} × `--limit` ∈ {1 (T fuera), 10 (T dentro)} ×
  `--dry-run`; T siempre detrás de una pendiente A independiente): bucket del reporte (`missing` / `notEvaluated` /
  `wouldApply`|`applied` / `entries.dead`), letra por id, exit, y `applied_at` real de T. Gemelo: `--batch-size=1` con dos
  aparcadas, en los dos modos.
- **Rojo** (`c2-rojo.txt`, `c2-gemelo-rojo.txt`): «missing ⇔ no está en la cola ([2])» y «el aparcado no es missing».
  **Mutantes**: `M-C2a-missing-todo`, `M-C2b-sin-exit`, `M-C2c-dead-acotado` ⇒ 3 rojos.

### C3 · ⚪ una regla del prefijo `operator:` (SQL y JS, 3 motores)

- `isOperatorHolder(holder)` (`src/freeze.ts`): los 9 primeros caracteres son EXACTAMENTE `operator:`. `freezeKindOf` la
  usa para `operator` (y exige `:` para `reconcile`/`platform`). En el `WHERE` de `acquireFreezeOutcome`,
  `operatorHolderSql()` por motor, sin `LIKE`: SQLite `substr(...) = ?` (sin collation heredada ⇒ BINARY), PG
  `substr(...) COLLATE "C" = ?`, MySQL `CAST(SUBSTRING(...) AS BINARY) = CAST(? AS BINARY)` (la columna es `_ai_ci`).
  Nuevo `isMysqlDialect` en `sql_expiry.ts` (mismo conjunto que el codec).
- Tras el reintento, una fila NO viva ya no es `held` («VIVO»): 503 `AuthorizationBackendError` que nombra la rama
  «contención tras reintento». Con la regla única solo se alcanza con una fila que cambia dos veces entre UPDATE y
  relectura — **y la alcanzan los mutantes `LIKE`** (se ve en `mut-M-C3a-like-*.txt`: la letra dice su rama).
- Caso `freeze.spec` «cierre-2 · C3» (4 modos): 12 holders caducados (`operator:1:ab`, `operator:`, `OPERATOR:`,
  `Operator:`, `opérator:`, `operator`, `operator;`, ` operator:`, `xoperator:`, `reconcile:`, `?`, NULL) ⇒ el primitivo
  hace exactamente lo que dice la clasificación JS; y por el manager `OPERATOR:` caducado se toma. Verde en sqlite, pg,
  mysql y sqlite-file (`freeze-*.txt`).
- **Rojo** (`c3c4-rojo.txt`, con la regla JS nueva y el `LIKE` aún): `"OPERATOR:1:ab": expected 'held' to equal
  'acquired'`. **Mutantes**: `LIKE` en sqlite ⇒ rojo; en **mysql** ⇒ rojo; en **pg ⇒ VIVO — equivalente** (`LIKE` es
  sensible a mayúsculas en PG y `é ≠ e`: PG ya era coherente, que es lo que decía el auditor); MySQL sin `BINARY` ⇒ rojo;
  `freezeKindOf` con el `split` viejo ⇒ rojo. `COLLATE "C"` quitado en PG: equivalente con la collation determinista del
  contenedor (no lanzado; declarado).

### C4 · ⚪ holder LITERAL `'?'`

- `releaseFreeze` con token `'?'`: casa `holder IS NULL OR holder = '?'` (JS y SQL), atado al fence; nunca un holder real.
- `authz:unfreeze`: si el UPDATE no casó y la fila releída es LA MISMA (holder, fence, motivo) ⇒ «la fila NO cambió … el
  UPDATE condicional por su token no casó (rama «token no casa»)», exit 1, en las dos ramas (caducada y levantar); ya no
  afirma «otro proceso la cambió».
- Casos: `freeze.spec` «cierre-2 · C4» (NULL y `'?'` literal casan con su fence; fence viejo no; `'?'` no levanta
  `operator:1:aa`; `'??'`/`''` no casan `'?'`) — en los 4 modos; `command_flags.spec` ⚪ 5 ampliado (repro convertido:
  primera pasada limpia, segunda éxito) y ⚪ 4 ampliado a **8 filas** (+ `lift`/`expired` × casa=false × fila MISMA).
- **Rojo**: `?: casa y limpia: expected false to be true` (`c3c4-rojo.txt`) y `lift/casa=false/después=misma … 'la fila NO
  cambió'` (`c4-letra-rojo.txt`). **Mutantes**: `M-C4a-solo-null` ⇒ 2 rojos; `M-C4b-letra-otro` ⇒ rojo.

### C5 · ⚪ alcance de la guardia de exports

- La guardia por identidad recorre ahora objetos anidados y propiedades propias de funciones/clases (visitados,
  profundidad 6). **Guardia nueva por FUENTE**: ningún `.ts` de `src/`, `commands/`, `services/`, `providers/`, `index.ts`,
  `configure.ts` importa el VALOR de `relations/reconcile.js` salvo `commands/authz_relations_reconcile.ts` y el harness
  declarado `src/testing/relations_reconcile_contract.ts` (estático, dinámico, `import type` excluido).
- **Alcance declarado** (comentario del caso, CLAUDE.md, CHANGELOG): identidad a cualquier profundidad + cualquier
  importador nuevo; un `.bind`/wrapper DENTRO de esos dos ficheros no lo ve ninguna.
- **Mutantes**: `M-C5a-anidado` (`internals.deep.reconcileRelations` en `/testing`) ⇒ las 2 guardias rojas;
  `M-C5b-wrapper` (wrapper en `src/relations/manager.ts`) ⇒ la de fuente roja, la de identidad verde (lo declarado).

### C6 · ⚪ los dos métodos del manager — DECLARADO

README, párrafo de `driver()`: «Grep for `relationsDriverFactory` and `relationsDriverKeys` too» (qué dan, que saltan
`assertWrite`/`requireActor`/freeze/`onRelationWrite`, que no añaden capacidad) y el `Pick<…>` estructural de
`runRelationsReconcile` (un manager que falsea `relationsDriverKey`/`relationsDriverFactory` decide el activo). Docblocks
en `relationsDriverFactory` y `runRelationsReconcile`. Caso de letra; mutante `M-C6-readme-sin-metodos` ⇒ rojo.

### C7 · ⚪ higiene

1. TOCTOU de `freeze.spec`: una rama por reloj determinista — dos lecturas (T−1 primero; `freeze()` lee UNA) ⇒ **423**
   `E_AUTHZ_FREEZE_HELD`; fijo en T+1 ⇒ **503** `E_AUTHZ_OPERATOR_WINDOW_EXPIRED`; fila intacta en las dos. Mutante
   `M-C7a-423-siempre` (el 503 mapeado a 423) ⇒ rojo (antes pasaba).
2. `RelationsReconcileOptions` SÍ se usaba en una firma pública (vía `Omit<…>` en `runRelationsReconcile`), pero
   describía el primitivo: **fuera de la raíz**, y la firma usa el tipo nuevo **`RunRelationsReconcileOptions`** exportado
   junto a la función (`./commands/authz_relations_reconcile`). CHANGELOG (ruptura menor por nombre). Caso de letra;
   mutante `M-C7b-raiz-options` ⇒ rojo.
3. `README.md:38`: la lista de `/openfga` = `OpenFgaAuthorizationDriver`, `OpenFgaRelationsDriver`,
   `provisionOpenFgaStore`, `openFgaFactsModel`, `assertHolderTypes`. El caso de letra comprueba que CADA nombre listado
   es un export de `src/openfga.ts`; mutante `M-C73-readme-38` ⇒ rojo.

### Gemelos por pieza

| Pieza | Gemelo | Estado |
|---|---|---|
| C1 identidad | `runRelationsReconcile` (relaciones) | caso «límite fijado» + letra |
| | `manager.reconcile` / `#sameDriver` (roles) | caso gemelo roles + letra |
| | `authz:relations:reconcile` / `authz:reconcile` (comandos) | no aplica caso propio: resuelven por las mismas dos funciones (casos R4 existentes) |
| C2 `missing`/`notEvaluated` | `--dry-run` | tabla 16 filas |
| | pasada que aplica | tabla 16 filas (+ `applied_at` real) |
| | aparcado más allá de `batchSize` (misma letra) | caso gemelo, dos modos |
| | `requeueScopeChanges({ apply })` | comparte `#drainScopeChanges`/`#relayInputs`: sin caso propio (su `only` son ids recién reencolados, siempre pendientes) |
| | reporte `busy` | `notEvaluated: []` documentado (nada evaluado; lo dice `busy`) |
| | `authz:scopes:requeue` | no aplica: no imprime `missing` |
| C3 regla del prefijo | `acquireFreezeOutcome` ×3 motores | caso 12 holders, 4 modos |
| | `freezeKindOf` → `freezeStatus`/`lastFreezeStatus`/`unfreezePlan`/barrera (`assertNotFrozenRow` «la levanta authz:unfreeze») | misma función; el caso afirma `freezeKindOf` por holder |
| | `renewFreeze`/`releaseFreeze` | no aplica: no clasifican, casan fence + holder del token; el fence sube en cada toma, así que la collation `_ci` de MySQL no puede casar otra fila (en `release` además JS compara con `===` antes) |
| C4 token `'?'` | `releaseFreeze` (primitivo) | caso NULL/literal/controles |
| | `manager.unfreeze` | mismo caso (va por el manager) |
| | `authz:unfreeze` | ⚪ 5 ampliado + ⚪ 4 a 8 filas |
| | `renewFreeze` con `'?'` | no aplica: nadie renueva con `'?'` (solo lo publica `lastFreezeStatus`) |
| C5 guardia | identidad anidada | mutante anidado |
| | importador nuevo | mutante wrapper |
| | roles (M7) | sigue pendiente (declarado en el cierre) |
| C6 | `relationsDriverKey()` | ya estaba en la letra del guard; sin cambio |
| C7.2 | `RelationsReconcileReport` en la raíz | se queda: es el retorno de la función pública |

### Cifras (verificación final, en secuencia, `docker restart api-loco-base-openfga-1 && sleep 8` antes de cada suite)

`npx tsc --noEmit` 0 · `npm run typecheck` 0 · `npm run check:purity` 0 · `npm run build` 0.
Con `OPENFGA_TEST_URL=http://localhost:8101` y `TEST_PG_URL` del contenedor: **`npm test` 1436** (1428, +8) ·
**`test:sqlite-file` 1462** (1454, +8) · **`test:pg` 1558** (1550, +8) · **`test:mysql` 1560** (1552, +8). Todo verde,
exit 0. Duraciones: 85 / 87 / 133 / 138 s. Corridas: `scratchpad/cierre2/final-*.txt`.
+8 = freeze.spec 2 (C3, C4) · command_flags 4 (C2 tabla, C2 gemelo aparcado, C5 fuente, C1 límite fijado) ·
reconcile.spec 2 (letra C1/C6/C7, C1 gemelo roles); casos ampliados sin sumar: TOCTOU (C7.1), ⚪ 4 (8 filas), ⚪ 5
(`'?'` literal), guardia de identidad (anidada). Mutantes: 18 lanzados, 17 matados, 1 vivo equivalente
(`M-C3a-like-pg`, explicado arriba) — `mutantes-resumen.txt`.

### Lo que NO se hizo

- Commits y `version`. No toqué el repro del auditor (`alpha10-cierre-reataque.spec.ts`): tras el cierre-2 da 3 verdes /
  4 rojos, y el DEFECTO de C1 sigue verde por decisión (límite declarado).
- Identidad de backend declarada por el driver (C1) y sello durable del activo (R5): roadmap 2.5.
- La rama «contención tras reintento» de `acquireFreezeOutcome` no tiene caso directo (exige que la fila cambie dos veces
  entre UPDATE y relectura); se observa en los mutantes que rompen la regla única.
- M7 para roles (guardia de superficie del primitivo de roles): sigue pendiente.
- `COLLATE "C"` en PG sin mutante que lo mate (equivalente con collation determinista).
