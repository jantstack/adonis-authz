# Fase 3b — verificación del TESTER (informe final, incremental)

> **Estado: CERRADO.** Escrito de forma incremental durante la sesión, no al final.
> Fecha: 2026-08-31. Worktree aislado clavado en `c0fbad7`.
>
> **En una línea:** 28 mutantes plantados, 23 muertos por la razón correcta, 5
> supervivientes. El más caro: **se puede escribir un driver que pase las 448
> preguntas de `runMigrationContract` y pierda la caducidad de todos los grants
> vivos**. Parche con 4 casos nuevos que matan a 4 de los 5.

## 0. Método

- Worktree de lectura/baseline: `…/scratchpad/wt-tester-3b` (clavado en `c0fbad7`).
- Worktree de MUTACIÓN: `…/scratchpad/wt-mut` (copia; ahí se planta cada mutante).
- Motores: OpenFGA real `http://localhost:8101` (0 stores al empezar), `postgres18`, `mysql84`.
  Base propia por ejecución: `authz_test_<8hex>` (el helper crea una por corrida y la destruye;
  ver el aviso de portabilidad de §1 sobre por qué el prefijo NO se puede cambiar).
- Un mutante = un cambio mínimo en `src/` que rompe UNA propiedad afirmada por CLAUDE.md o
  por el informe de un lote. **Muere** si la suite se pone roja **por esa razón**
  (no por un typecheck, ni por un test de otra propiedad que casualmente pete).

## 1. Baselines (verde de partida)

| corrida | esperado | medido | resultado |
|---|---|---|---|
| `npm test` (sqlite :memory:) | 752 | **752 passed** | ✅ |
| `npm run test:sqlite-file` | 754 | **754 passed** | ✅ |
| `npm run test:pg` (PG 18) | 848 | **848 passed** | ✅ |
| `npm run test:mysql` (MySQL 8.4) | 848 | **848 passed** | ✅ |

Los cuatro verdes, con OpenFGA real en `:8101`. **Nota de higiene**: la suite deja
**1 store huérfano** por corrida contra FGA (`contract-facts-<n>`); no lo borra su
teardown. Cuatro corridas ⇒ 4 stores. Es exactamente el mecanismo por el que se
acumularon los 60 que hincharon el servidor.

**Aviso de portabilidad del harness**: `tests/harness_cleanup.spec.ts:90` y `:161`
afirman `/^authz_test_[0-9a-f]{8}$/` sobre el nombre de base PROVISIONADO. Eso hace
que la suite **falle** (2 casos) si `TEST_PG_URL`/`TEST_MYSQL_URL` nombran una base
base distinta de `authz_test`, que es justo lo que `tests/helpers/app.ts` documenta
como configurable. Lo que el caso quiere fijar es «sufijo único de 8 hex», no el
prefijo literal. Me costó una corrida de PG y otra de MySQL descubrirlo.

## 2. Mutantes (tabla viva)

| # | Qué rompe | Fichero · cambio | Resultado | Quién lo mata |
|---|---|---|---|---|
| M1 | `reconcile --to=database` pierde el `expiresAt` de los grants VIVOS | `database_driver.ts` insert ⇒ `expires_at: null` | 💀 3 casos … **pero SOBREVIVE al contrato de migración** | `reconcile.spec.ts` 1205/1361/1394 |
| M2a | Cara (i): «lo contado y no declarado falla» | `migration_contract.ts` `continue` incondicional | 💀 1 | «una pérdida REAL que no se declara hace fallar el contrato» |
| M2b | Cara (ii): «lo declarado y no contado falla» | idem | 💀 1 | «una pérdida DECLARADA que no ocurre también hace fallar» |
| M2c | Una pérdida sin `changesAnswer` explica CUALQUIER cambio (`=== true` ⇒ `!== false`) | idem | 💀 1 | «un hecho que se pierde EN SILENCIO…» |
| M3 | El tramo de vuelta de `a→b→a` no se ejecuta | `migration_contract.ts` | ✅ **SOBREVIVE** | nadie |
| M4 | `can_<P>` sin `rooted` (invariantes 1 y 9 en `facts`) | `openfga_facts.ts` modelo | 💀 8 | 2i (paridad, ciclos, fail-closed del relay, forma del modelo) |
| M5 | `stillGranting` degrada a `false` cuando no se sabe | `manager.ts` `pruneOrphanRoles` | 💀 1 | `manager.spec.ts:3173` |
| M6 | `scopes.moved` no barre las aristas de roles LOCALES | `openfga_driver.ts` | 💀 5 | paridad 2e·E1 |
| M7 | `projectCatalogRole` no barre la VISIBILIDAD (nivel) | `openfga_driver.ts` | 💀 4 | 2g·R1 |
| M8 | El relay ignora el lease (`acquire`) | `manager.ts` | 💀 2 (1 + typecheck) | 2h·🟠4 |
| M9 | La contaminación del relay deja de ser TRANSITIVA (lo aplazado no contamina) | `manager.ts` | ✅ **SOBREVIVE** | nadie (ver §4.2) |
| M10 | `--dry-run` de `--to=database` SÍ escribe | `database_driver.ts` | 💀 2 | «--dry-run es el verificador» |
| M11 | El ORIGEN (`enumerateFacts`) filtra la caducada | `openfga_driver.ts` | 💀 4 (incl. **el contrato de migración, cara (ii)**) | reconcile + contrato |
| M12 | `FACTS_MAX_RESOLVE_DEPTH = 20` | `openfga_facts.ts` | 💀 1 | E5 caso negativo |
| M12b | `FACTS_MAX_RESOLVE_DEPTH = 23` | idem | ✅ **SOBREVIVE** (3 corridas verdes) | nadie |
| M12c | `FACTS_MAX_RESOLVE_DEPTH = 24` | idem | 💀 2 | E5 caso positivo |

| M13 / M13b | La atomicidad de `grant` en la puerta **degradada** (`writeAssignment`): dos `Write` en vez de uno, y el `assignee` primero | `openfga_driver.ts` | ✅ **SOBREVIVE** | nadie |
| M13c | Lo mismo en la puerta NORMAL (`absent` ⇒ `writeTuples(writeSet(...))`) | idem | 💀 3 | 2f·R3 «un grant nuevo son las TRES tuplas en UNA sola escritura» |
| M14 | El ORDEN de `purgeScope` invertido (denies primero, estructura al final) | `openfga_driver.ts` | 💀 2 | 2f·R3 (orden + entrelazado) |
| M15 | El barrido del owner ignora el NIVEL (composición 2e·E1 × 2g·R1) | `openfga_driver.ts` | 💀 4 | «el barrido del owner no lo resucita» |
| M16 | `detached` sin cadena purga solo la ortografía del llamante (invariante 17) | `manager.ts` | 💀 3 | 2h·🟠3 |
| M17 | La arista `roleVisibility` (fail-OPEN) solo se borra con `--prune` | `openfga_driver.ts` | 💀 1 | «se cierra sin --prune: era fail-OPEN» |
| M18 | `moved` barre por NODO y no por SUBÁRBOL | `openfga_driver.ts` | 💀 1 | «el barrido tiene que bajar el subárbol entero» |
| M19 | `folded-scope` se queda con la caducidad que MENOS dura | `database_driver.ts` | 💀 1 | S15 |
| M20 | `reconcile --to=database` inserta cada fila DOS veces | `database_driver.ts` | 💀 14 | *(el índice UNIQUE del esquema, no una aserción — ver §4.5)* |
| M21 | `reconcile --to=openfga` no repone el marcador de raíz | `openfga_driver.ts` | 💀 10 | 2i + reconcile |
| M22 | Los hechos sobre un scope FANTASMA se migran igual (sin `unknown-scope`) | `database_driver.ts` | 💀 1 | «lo que NO se migra sale contado y con su motivo» |

### Recuento

**28 mutantes plantados · 23 muertos · 5 supervivientes**, más **1 superviviente
parcial** (M1: sobrevive al contrato PUBLICADO y muere en la suite privada del
paquete — que es exactamente el caso que importa, porque el contrato es lo que
corre un driver de terceros).

| superviviente | propiedad que nadie observa |
|---|---|
| **M1** (contra `runMigrationContract`) | la caducidad de un grant VIVO sobrevive a la migración |
| **M3** | el tramo de VUELTA de `a→b→a` se ejecuta |
| **M9** | la contaminación del relay es TRANSITIVA más allá del primer eslabón |
| **M13 / M13b** | `grant` es UNA escritura también por la puerta DEGRADADA (misma propiedad, dos caminos) |
| **M12b** | «22 saltos y no otro»: el par de casos sujeta [22, 23], no 22 |

Cuatro de los cinco los cierra el parche (§5). El quinto (M12b) es redacción de un
título, no cobertura: el intervalo [22, 23] es lo máximo que se puede medir sin
apoyarse en un borde probabilístico, y el comentario del código ya lo dice.

## 3. La pregunta afilada: ¿un driver puede PASAR el contrato de migración y perder datos?

**Sí. Medido.** El caso es `M1`: `reconcile --to=database` escribiendo
`expires_at: null` en cada `insert` — es decir, migrando los grants VIVOS
**como permanentes**.

```
== M1 · database_driver.ts:  expires_at: this.expiry.toDb(target.expiresAt)  ⇒  expires_at: null
$ node bin/test.ts --files=migration_contract
Tests  7 passed (7)          ← las TRES combinaciones en verde
$ node bin/test.ts           ← la suite entera
Tests  749 passed, 3 failed (752)
   ❯ la caducidad viaja con su instante …            (reconcile.spec.ts:1205)
   ❯ la caducidad viaja al MILISEGUNDO …             (reconcile.spec.ts:1361)
   ❯ dos hechos que colapsan en UNA fila …           (reconcile.spec.ts:1394)
```

Es decir: lo caza la suite **privada del paquete**, y **no** lo caza el contrato
**publicado**, que es justo el que un driver de terceros va a correr para
demostrar que su migración no pierde nada.

**Por qué las 448 no lo ven** — y no es un descuido puntual, es estructural:

- **ninguna de las 448 devuelve un `expiresAt`.** `authorize`/`hasRole` son
  booleanos, los tres `list*` devuelven slugs, scopes o sujetos. La caducidad
  solo se observaría con el reloj adelantado, y el contrato **no adelanta ningún
  reloj** (ni tiene gancho para hacerlo: `MigrationContractHarness` no expone
  `injectableClock`).
- **la cara (i) de `expectedLosses` no lo tapa.** Su texto dice que cierra
  precisamente esto («sin esa mitad un driver podría saltarse lo que quisiera
  mientras las 448 respuestas de ESA siembra no cambiaran»), pero lo que compara
  es `Object.keys(report.skipped)` — es decir, **lo que el propio driver declara
  haberse saltado**. Un driver que pierde en silencio no puebla `skipped`, y la
  cara (i) no ve nada. **La cara (i) cierra las omisiones AUTO-DECLARADAS, no las
  silenciosas.** Ese matiz no está escrito en ninguna parte y la frase de
  CLAUDE.md promete más de lo que hay.

**Lo que sí corta bien** (y lo comprobé con mutantes, no de palabra):

| cara | mutante | resultado |
|---|---|---|
| (i) contado ⇒ declarado | M2a (`continue` incondicional) | 💀 |
| (ii) declarado ⇒ contado | M2b | 💀 · y M11 (el origen filtra la caducada) la dispara **de verdad**, no de mentira |
| «una pérdida sin `changesAnswer` no explica nada» | M2c (`=== true` ⇒ `!== false`) | 💀 |

Nota: **el camino POSITIVO de `changesAnswer` no lo ejercita nadie.** La única
pérdida declarada del par del paquete (`expired`) no trae `changesAnswer`, así que
`explainedBy` sale `null` en los tres casos que existen. Un bug en esa rama
—aceptar una pérdida que no corresponde— no se vería.

### ¿Y el `a→b→a`?

**No observa el tramo de vuelta.** Las 448 de esa combinación se le preguntan al
ORIGEN, **al que nadie vacía** entre los dos tramos: quité el `reconcile` de
vuelta entero (M3) y las tres combinaciones siguieron en verde. Lo que esa
combinación puede detectar es lo que la vuelta **destruye** (un `--prune` que se
lleve de más); lo que deja de escribir, no: con el origen ya lleno, «todo
`unchanged`» es la respuesta correcta y un tramo omisivo es indistinguible de uno
bueno. El informe del 3b-3b dice *«sin `--prune` el viaje redondo sería
trivialmente limpio y no demostraría nada»* — con `--prune` tampoco demuestra que
la vuelta escriba.

## 4. Los agujeros de observación, uno a uno

### 4.1 · `runMigrationContract` no ve la pérdida de una caducidad VIVA (M1)

Descrito arriba. **Es el hueco más caro de la fase**: el contrato es la superficie
que se publica en `/testing` con la promesa «migración sin perder nada que no esté
declarado», y la clase de pérdida que no ve es fail-**OPEN** (un permiso temporal
que deja de caducar). Lo cierro en el parche (§5, T4).

### 4.2 · La contaminación del relay NO es transitiva más allá del primer eslabón (M9)

CLAUDE.md: *«El orden se conserva igual porque dos cambios que pueden interactuar
comparten siempre un scope: la contaminación va por clave de scope y es
transitiva»*. Hay un caso que se llama exactamente así
(`tests/scope_outbox.spec.ts:867`, *«la dependencia es transitiva: lo que depende
de un APLAZADO también se aplaza»*) — **y no prueba eso**:

- en ese caso, `attached(hijo,padre)` **FALLA**; sus claves las contamina la rama
  del `catch`;
- `attached(nieto,hijo)` se aplaza porque toca `hijo`, **que falló**.

O sea: mide contaminación desde un **fallo**, un solo eslabón. La transitividad de
verdad —**lo APLAZADO contamina a su vez**— la decide otra línea, la de la rama de
colisión:

```ts
if (collision !== undefined) {
  for (const key of keys) blocked.add(key)   // ← M9: la borré
```

Borrada esa línea, **la suite entera pasa (752/752)**. Con un eslabón más
(`attached(bisnieto,nieto)`) el bisnieto se ADELANTA y se cuelga en el store de un
`nieto` que nunca se escribió: el orden del árbol, que es lo único que la
contaminación defiende, se rompe. Caso nuevo en el parche (§5, T2).

### 4.3 · La atomicidad de `grant` solo está observada en la puerta normal (M13/M13b)

Invariante 6 · 3b-2f · R3: *«las TRES tuplas de un `grant` van en el MISMO
`Write`»*, porque *«un `assignee` sin sus aristas es una asignación que
`listRoles`/`hasRole` enumeran y `authorize` no honra»*.

`grant` tiene **dos** puertas de escritura:

| puerta | cuándo | ¿observada? |
|---|---|---|
| `client.writeTuples(writeSet(...))` (`openfga_driver.ts` ~1020) | camino feliz: la relectura dice `absent` | ✅ `mutations.length === 1` (M13c 💀) |
| `writeAssignment(...)` (~1063) | la relectura del store **no responde** (`unknown`) con `expiresAt` explícito, y tras una carrera cuya relectura tampoco responde | ❌ **nadie** |

Partí la segunda en dos `Write` con el `assignee` PRIMERO (M13b): **752/752 en
verde**. Es la puerta que más se usa justo cuando el store va mal, y deja
exactamente el estado que el invariante prohíbe. Caso nuevo en el parche (§5, T3).

### 4.4 · El techo de «≈691 permisos» no lo afirma ningún test — y con slugs reales son 447

Lo que SÍ está probado, y bien: `factsModelBytes` **cuenta los mismos bytes que el
servidor**, con `assert.equal(factsModelBytes(model), reported)` en cuatro formas
de catálogo (`openfga_facts.spec.ts:224`). Lo verifiqué a mano contra el `:8101`:

```
1 holder, 1500 slugs cortos   → estimador 500228 · servidor "model exceeds size limit: 500228 bytes vs 262144"
3 holders, 500 slugs de 40    → estimador 480115 · servidor "…: 480115 bytes vs 262144"
```

Delta 0. El oráculo del **techo en bytes** es real.

Lo que **no** afirma nadie es el **691**. No aparece en un solo `assert`: vive en
tres comentarios (`openfga_facts.ts:41`, `:56`, `:119`) y en CLAUDE.md. Medido con
el estimador (que acabo de demostrar exacto):

| forma del catálogo | máximo de permisos |
|---|---|
| 1 holder type, slugs `p0`…`pN` (2–4 car.) | **800** |
| 3 holder types, slugs `p0`…`pN` | **691** ← el número del README |
| 1 holder type, slugs `docs:readN` (~11 car.) | **576** |
| 3 holder types, slugs `recursoN:accion` (~15 car.) | **447** |
| 3 holder types, slugs de 40 car. | **272** |

Confirmado contra el servidor real en el borde: con 3 holders y `recursoN:accion`,
**N=447 el servidor ACEPTA (262 137 bytes) y N=448 RECHAZA (262 726)**.

O sea: **691 es la cifra de un catálogo cuyos permisos se llaman `p0`, `p1`, `p2`…**
Ningún catálogo real se parece a eso, y la forma no se dice al lado del número.
Con nombres de permiso normales el techo está en **~450**, un 35 % por debajo. No
es un bug —el gate por bytes es exacto y salta antes de escribir— pero es una cifra
del README que induce a error y **no la sostiene ningún caso**. Recomendación: o se
dice «≈691 con slugs de 2–4 caracteres y 3 holder types», o se publica la tabla.

### 4.5 · Dos oráculos que se aceptan con más margen del que dicen

- **«22 saltos … la cota medida sobre (c2) es esa y no otra»**
  (`openfga_facts.spec.ts:3136`). El par de casos (positivo a 22, negativo a
  `22+2`) sujeta el valor a un **intervalo, no a un punto**:

  | `FACTS_MAX_RESOLVE_DEPTH` | resultado |
  |---|---|
  | 20 | 💀 (el negativo a 22 saltos sí resuelve) |
  | 22 (real) | verde |
  | **23** | **verde, 3 corridas de 3** ✅ superviviente |
  | 24 | 💀 (el positivo a 24 no resuelve) |

  El comentario del código explica honestamente por qué no se apoya en 23 (borde
  probabilístico); el **título del caso**, en cambio, afirma «esa y no otra», y eso
  no es lo que mide. Es cuestión de redacción del título, no de cobertura.

- **M20 (`reconcile` inserta cada fila DOS veces) muere por el índice UNIQUE del
  esquema, no por una aserción.** 14 casos se ponen rojos con un
  `AuthorizationBackendError` genérico («el backend no respondió»), no con un
  «hay filas duplicadas». Funciona como red, pero un driver de terceros sin ese
  índice se queda sin observador: ni el contrato de migración ni `reconcile.spec`
  cuentan filas.

### 4.6 · La regla «cada valor declarado tiene un caso» solo se aplica a los `true`

`src/testing/contract.ts:4417` lanza al cerrar el grupo si una capacidad declarada
**`true`** no registró caso. Una capacidad declarada **`false`** sin `whenFalse`
no la delata nadie: `caseFor` simplemente `return`. Hoy no hay ninguna en esa
situación —revisé las 14 llamadas a `caseFor` una por una— pero la regla escrita
(«un par de capacidad con caso negativo, **jamás un `skip`**») no está hecha
ejecutable por la cara `false`.

### 4.7 · Higiene de stores: la corrida limpia NO gotea; la INTERRUMPIDA sí

Lo medí antes de acusar a nadie: `stores` antes = 1, corrida completa de 754
casos, `stores` después = 1. **Una corrida que termina no deja nada.** El único
store que había (`contract-facts-81`) era mío, de la corrida que maté con
`pkill` al descubrir lo del nombre de base — y ahí está el mecanismo real del
goteo: **el teardown de los grupos no corre si el proceso muere**, y `bin/test.ts`
solo tiene red para la base SQL (`run().finally(app.teardown)`), no para los
stores de FGA. Los 60 acumulados salen de ahí, no del uso normal.
Lo borré: **0 stores en el `:8101` al cerrar**.

## 5. El parche

`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/tests-tester-fase-3b-final.patch`
(`git apply --check` limpio contra `c0fbad7`). Cuatro piezas, tres ficheros, y
**cada una mata a su superviviente**:

### T1 · `a→b→a`: el tramo de vuelta se ejecuta y HACE algo — `src/testing/migration_contract.ts`

- `legDidSomething(report, leg)`: un tramo cuyos cinco contadores
  (`written/updated/unchanged/extra/deleted`) suman **cero** falla. Un
  `reconcile` que no mira nada no es una migración (es el `--from` equivocado, o
  el store equivocado).
- comprobación de **número de tramos** (`a→b→a` son DOS pasadas) ⇒ mata M3.
- el `a→b→a` compara además las 448 contra el **destino intermedio** tras el
  primer tramo (antes solo se preguntaba al origen, y un tramo de ida a medias
  quedaba tapado por la vuelta).
- y el **límite residual, escrito en la cabecera del módulo**: con el origen
  lleno, esa combinación no puede ver un tramo de vuelta OMISIVO. Cerrarlo pide
  un gancho nuevo en el harness («vacía los hechos de este extremo»), que es
  decisión del dueño y **no la tomo yo**.

### T2 · La transitividad al SEGUNDO eslabón — `tests/scope_outbox.spec.ts`

`la transitividad llega al SEGUNDO eslabón: lo que depende de un APLAZADO (no de
un fallo) también se aplaza`. Cuatro entradas encoladas
(`padre`→aplica, `hijo`→**falla**, `nieto`→aplazado, `bisnieto`→**tiene que
aplazarse**) y una aserción de que el bisnieto **no llegó al driver**.
Verificado: verde con el código sano, rojo con M9.

### T3 · La puerta degradada de `grant` — `tests/openfga_facts.spec.ts`

`con la RELECTURA del store caída, el grant sigue siendo UNA sola escritura con
las tres tuplas (la puerta degradada, invariante 6)`. Usa el `factsDriver()` que
ya existe, tumba `client.read` y cuenta `mutations`. Verde con el código sano,
rojo con M13b.

### T4 · El CRUCE DE CADUCIDADES — `src/testing/migration_contract.ts`

Las 448 se quedan en 448 (la cifra publicada no se toca). Se añade **después** de
ellas un cruce de las 13 caducidades vivas/nulas de la siembra, leídas por el
único camino del puerto que las devuelve sin inventar método nuevo: `grant` con
`expiresAt` **omitido** ⇒ `GrantOutcome.previousExpiresAt` (invariante 10,
«omitido preserva»). Es una escritura, sí — idempotente, sin cambio de estado y
posterior a toda medición.

Para que la siembra y el cruce no se separen, los 14 grants pasan a una tabla
(`migrationGrants(seed)`, exportada) de la que tira `plantMigrationFacts`.

Salida con M1 plantado:

```
❯ migration contract […] / 448 preguntas idénticas, openfga → database: …
+ "[b→a] la CADUCIDAD no sobrevivió a la migración: users:…-dc5 mig-lead @ unit|…-e3e
   — antes '2026-08-31T18:49:02.341Z', después 'sin caducidad'. Ninguna de las 448
   preguntas lo ve (no devuelven caducidades) y perderla es fail-OPEN: un permiso
   temporal que ya no caduca."
   … (4 caducidades perdidas, una por grant vivo con `expiresAt`)
Tests  6 passed, 1 failed (7)
```

### Verificación del parche en los cuatro motores

| corrida | sin parche | con parche |
|---|---|---|
| `npm test` (sqlite :memory:) | 752 | **754 passed** ✅ |
| `npm run test:sqlite-file` | 754 | **756 passed** ✅ |
| `npm run test:pg` | 848 | **850 passed** ✅ |
| `npm run test:mysql` | 848 | **850 passed** ✅ |

Y el mutante M1 se comprueba muerto por T4 **en los tres motores SQL**, no solo en
SQLite (importa: el codec de caducidad no es el mismo — `timestamptz` en PG,
`DATETIME(3)` en MySQL):

```
TEST_DB=pg     --files=migration_contract → 6 passed, 1 failed  ("la CADUCIDAD no sobrevivió…")
TEST_DB=mysql  --files=migration_contract → 6 passed, 1 failed  ("la CADUCIDAD no sobrevivió…")
```

`npm run typecheck` limpio.

## 6. Qué intenté romper y NO pude (esto también es información)

Lo pongo porque un informe que solo lista huecos miente sobre el estado real: la
mayoría de lo que ataqué está bien sujeto, y algunos casos son notablemente
buenos.

- **`rooted` (invariantes 1 y 9 en `facts`).** Quitar `and rooted` de `can_<P>`
  pone **8 casos** en rojo, y los mensajes son los correctos: paridad con
  `database`, el nieto que pierde la cadena, el ciclo que no alcanza la raíz, la
  forma del modelo publicado y —esto me gustó— el **fail-CLOSED del lag del
  relay** («hasta el relevo la unit no alcanza `app`, así que no concede»). El
  🔴 1 del auditor R2 está cerrado con observadores, no con prosa.
- **Los dos barridos de `facts` y su COMPOSICIÓN.** Los ataqué por cuatro sitios
  —quitar el barrido de `moved` (M6), quitar el de nivel (M7), hacer que el
  barrido del owner ignore el nivel (M15) y barrer por nodo en vez de por
  subárbol (M18)— y **los cuatro mueren**. El caso
  `openfga_facts.spec.ts:2809` («y el barrido del owner no lo resucita») prueba
  la composición de verdad, con las dos piezas a la vez y no por separado. Es
  justo el patrón que ha mordido a este proyecto y aquí está cubierto.
- **El orden de `purgeScope`** (estructura → hechos → denies). Invertirlo mata 2
  casos, uno de ellos de **entrelazado** con un `grant` concurrente. No es un
  test de orden por el orden: mide la consecuencia.
- **El lease del relay** (`acquire`). Ignorarlo mata el caso de 2h·🟠4 **y** el
  typecheck de la suite. Escritor único, sujeto.
- **`stillGranting` nunca `false`.** Degradarlo a `false` cuando no se sabe mata
  `manager.spec.ts:3173`, con las tres aserciones que hacen falta
  (`isUndefined`, `notStrictEqual(false)` y el contador). Y el reparto en tres
  cubos del comando tiene su propio caso sobre `orphanLines`.
- **`--dry-run` read-only.** Escribir en dry-run mata 2 casos.
- **`enumerateFacts` no filtra.** Filtrar la caducada en el ORIGEN mata 4, y
  entre ellos **la cara (ii) del contrato de migración**, que era su trabajo.
- **`scopeSpellings` en el `detached` sin cadena** (invariante 17, 2h·🟠3):
  volver a la ortografía del llamante mata 3, incluido el que mira el store bajo
  la identidad REAL.
- **La arista de visibilidad fail-OPEN se borra SIN `--prune`** (M17): forzarla a
  `--prune` mata el caso que lo nombra.
- **`folded-scope` se queda con la caducidad que MÁS dura** (M19): invertirlo
  muere.
- **El marcador de raíz en `reconcile --to=openfga`** (M21): no reponerlo mata 10.
- **`unknown-scope`** (M22): migrar un hecho de un scope fantasma muere.
- **El techo del modelo en BYTES.** Es un oráculo de verdad: la estimación
  protobuf del paquete coincide **exactamente** con la que reporta el servidor
  (lo repetí a mano contra el `:8101`, delta 0 en dos formas más). Lo que no está
  sujeto es la cifra derivada de 691 permisos (§4.4), no el mecanismo.
- **«1 `check`, 0 `batchCheck`, 0 `resolveChain`»**: afirmado con aserciones
  exactas, no aceptado. Y aunque la cuenta de requests se mide con el doble en
  memoria —que es lo correcto para contar requests—, la parte que importa
  (`resolveChain` = 0 en `authorize`) se vuelve a medir **contra el `:8101`** en
  la cara `whenTrue` de `singleCheckAuthorize`, con `withChainSpy`. No es un
  doble solo.
- **Las capacidades del driver** están clavadas con `deepEqual` de los ocho
  campos, para los dos drivers, y contra el literal del README. Cambiar una sola
  rompe.
- **Los casos negativos de las seis capacidades del encargo NO son decorativos.**
  Los leí uno a uno: `roleInheritanceNative:false` **cuenta las llamadas al
  resolutor** en las cinco lecturas (no basta con que respondan);
  `listObjectsInherited:false` usa un rol del MISMO nivel a propósito, para que
  el filtro de nivel no tape una enumeración que sí heredara;
  `hierarchyFacts:true` recorre las NUEVE salidas que deberían revocar y exige
  503 en todas antes de afirmar «concede y no se puede revocar»;
  `canonicalScopeReads:false` comprueba además que la ESCRITURA sí canoniza
  (que es la cara fail-OPEN que 2h cerró). Ninguna es un `skip` disfrazado.
- **448 = 168+168+42+24+28+18** está afirmado, descompuesto por tipo **y** sin
  preguntas repetidas (`new Set(ids)`). Ese oráculo no se acepta: se mide.

## 7. Veredicto

**La Fase 3b está probada, con cuatro excepciones nombradas — y una de ellas cae
justo en la pieza más nueva y menos revisada.**

Cuantitativamente: **28 mutantes, 23 muertos (82 %)**, y los 23 murieron **por la
razón correcta** (comprobé el mensaje de cada rojo, no solo el rojo). Los cuatro
motores en verde antes y después del parche: **752 / 754 / 848 / 848** →
**754 / 756 / 850 / 850**.

Lo que sostengo:

1. **`runMigrationContract` NO cumple lo que su propia cabecera promete.** Un
   driver puede perder la caducidad de todos los grants vivos —convertirlos en
   permanentes, que es fail-OPEN— y pasar las tres combinaciones. Y la cara (i)
   de `expectedLosses`, que el texto vende como el corte contra «saltarse lo que
   quiera», solo ve las omisiones que el propio driver **declara** en `skipped`.
   No es un matiz: es la diferencia entre una garantía y un formulario.
   Lo cierra T4.
2. **La combinación `a→b→a` no observa su tramo de vuelta.** Se puede borrar
   entero y todo sigue verde. Lo mitiga T1 (que la vuelta se ejecute y toque
   algo) y lo deja escrito para lo que no puede cerrar sin decisión del dueño.
3. **Un caso se llama «la dependencia es transitiva» y no mide la
   transitividad**: mide un solo eslabón desde un FALLO. La línea que hace
   transitiva la contaminación se puede borrar con la suite entera en verde.
   Lo cierra T2.
4. **La atomicidad de `grant` está observada en una de sus dos puertas.** La otra
   —la degradada, la que se usa cuando el store no deja leer— se puede partir en
   dos `Write` con el `assignee` primero sin que nada proteste. Lo cierra T3.

Y una cifra del README que induce a error sin ser un bug: **«≈691 permisos» es la
medida de un catálogo cuyos permisos se llaman `p0`…`p690`**; con nombres reales
son ~450. Nadie la afirma en un test.

Nada de lo anterior reabre una decisión firmada del dueño ni cambia una respuesta
de `authorize`: son **huecos de observación**, que es lo que me tocaba buscar.
Con el parche aplicado, cuatro de los cinco supervivientes mueren.

---

### Fuera de mi veredicto (para el auditor de seguridad)

No los juzgo, los paso: (a) la cara (i) de `expectedLosses` sólo ve lo
auto-declarado —un driver hostil, no ya descuidado, tiene ahí una puerta; (b) el
cruce de caducidades de T4 se apoya en `grant` con `{}`, que es una ESCRITURA: si
alguien decide que un contrato de verificación no puede escribir, hay que buscar
otro camino (y hoy el puerto no tiene ninguno de solo lectura que devuelva una
caducidad).

### Estado de los recursos al cerrar

- **OpenFGA `:8101`: 0 stores.** Borré el único huérfano (`contract-facts-81`),
  que era mío, de la corrida que interrumpí.
- Bases PG/MySQL: el harness crea `authz_test_<8hex>` por corrida y la destruye;
  no quedó ninguna.
- Repo principal **sin tocar** salvo este informe y el `.patch`. El parche **no
  está aplicado**.
