# Fase 2 · Lote 2D — informe de implementación (2026-08-28)

Rama `v2/fase-0` sobre `bf3fac9` (**sin commits**; el commit lo hace el dueño). Node 22.23.2, OpenFGA `:8101`
(v1.19.0) y servidor efímero tope 3 (`openfga-tiny`, `:8103`, memoria; **eliminado al terminar**). Sin `skip`/`only`
(grep = 0). `npm run typecheck` verde. Todo rojo→verde por pieza con el fallo real anotado (tabla).

## Conteo de tests por configuración

| Momento | `npm test` (SQLite) | `OPENFGA_TEST_URL=:8101` | tope 3 (`:8103`) |
|---|---|---|---|
| HEAD `bf3fac9` | 231 | 309 | — |
| HEAD + parche del tester (`git apply`, sus 2 casos ya pasaban) | 233 | — | — |
| tras F1 | 240 | 319 | — |
| tras F2 | 241 | 321 | — |
| tras F3/F8/F10 | 242 (+2 de `manager.spec` insertados después: 244) | 323 | — |
| tras F4/F5/F6/F7/F9 | 249 | 330 | — |
| **cierre (G1–G5 + docs)** | **250 ✅** | **332 ✅** | **332 ✅** |

Casos del juez: 36 core / 49 en 2.0 / **60** en 2.1 (57 + F1 + F2 + F3; `contract_harness.spec` actualizado).

## Benchmark (`scripts/bench_authorize.mjs`, N=200, warmup 30, `:8101` v1.19.0)

| `authorize` | HEAD `bf3fac9` | Lote 2D | factura |
|---|---|---|---|
| database · TRUE (raíz concede) | p50 0,29 · p95 0,83 ms | p50 **0,38** · p95 0,93 ms | 2 SQL → 3 SQL (1 de versión) |
| database · FALSE | p50 0,19 · p95 0,26 ms | p50 0,24 · p95 0,31 ms | idem |
| openfga · TRUE | p50 2,00 · p95 3,67 ms | p50 **2,35** · p95 3,70 ms | 0 SQL + 1 batchCheck → 1 SQL (versión) + 1 batchCheck |
| openfga · FALSE | p50 0,01 · p95 0,01 ms | p50 0,05 · p95 0,08 ms | 0 → 1 SQL (versión) + 0 |

El coste real del SELECT por PK en SQLite en memoria se ve limpio en los casos FALSE (+0,05 ms); la diferencia de
p50 en openfga·TRUE (+0,35 ms) tiene la p95 idéntica (3,70 vs 3,67) y entra en el ruido del round-trip HTTP local
(el otro implementador midió HEAD en 1,92 p50 / 4,07 p95 en la misma máquina). La spec esperaba ≈ +0,05–0,1 ms:
es lo que mide el caso sin red. `bill()` del bench ahora separa «de catálogo» y «de versión».

> Incidencia: durante F1 otro agente (el implementador original del lote, que se creía muerto) escribió rojos en el
> mismo árbol (`linkByHand` en `src/testing/contract.ts`, grupo «2D · F1/F4» en `tests/catalog_cache.spec.ts`).
> El coordinador decidió que ese agente se detiene y retira sus restos; este informe cubre solo lo mío.

## Baseline

| Momento | `npm test` (SQLite) | `:8101` | tope 3 |
|---|---|---|---|
| HEAD `bf3fac9` + parche del tester (aplicado con `git apply`; sus 2 casos ya pasaban en HEAD) | 233 ✅ | — | — |

Bench HEAD (`scripts/bench_authorize.mjs`, N=200): database TRUE p50 0,29 / p95 0,83 ms · FALSE 0,19 / 0,26 ms;
openfga TRUE p50 2,00 / p95 3,67 ms · FALSE 0,01 / 0,01 ms.

## Piezas

| # | Rojo (fallo real anotado) | Estado |
|---|---|---|
| F2 | `scratchpad/v3/r_within.mjs` (auditor R-L) y `r_sqlite.mjs` R-B: `removeDeny(... { within: orgA })` sobre una unit de B ⇒ ACEPTADO (deny ajeno levantado); `revoke`/`scopes.detached` sin `within` con `requireWithin: true` ⇒ aceptados | ✅ verde: 241 SQLite / 321 `:8101` (juez 59) |
| F3 | `r_sqlite.mjs` R-C: `descendantsOf(deny) === null` ⇒ `authorizedScopes(team)` lista el team bajo la unit denegada (`authorize` = false); `r_sqlite2.mjs` R-F: `descendantsOf` que devuelve una unit de B ⇒ aparece en la lista | ✅ verde: 242 SQLite / 323 `:8101` (juez 60); R-F ahora 503 `E_AUTHZ_RESOLVER_FAILED` |
| F8 | test nuevo `manager.spec` «F8: … corta en cuanto el conteo del tipo supera maxScopes»: con HEAD, `descendantsOf` se llamaba para las 5 orgs antes del 422 y `{ maxScopes: 100 }` superaba el config (4) | ✅ (implementado junto a F3; verde en la misma suite) |
| F10 | tipo nominal + helper: el juez `all` afirma `includesDescendants: true` y `expandExcludedSubtrees` ≡ `{ s : !authorize(s) }` bajo los subárboles | ✅ |
| F4 | test nuevo `catalog_cache.spec` «F4: invalidate() durante una carga en vuelo…»: `loaded === true` tras `view(); invalidate(); await` (la invalidación se perdía) | ✅ verde (249 SQLite) |
| F5 | test nuevo `manager.spec` «F5: authorizeMany valida la respuesta…»: `[true]` para 2 scopes se devolvía tal cual (`expected undefined to equal 500`) | ✅ |
| F6 | `r_sqlite2.mjs` R-I: `org`+`a-1` vs `o`+`rga-1` ⇒ 422 falso `E_AUTHZ_SCOPE_CYCLE`; `parentOf → {app,'X'}` ⇒ cadena `[app]` en silencio; tests nuevos en `hierarchical_resolver.spec` | ✅ |
| F7 | mutante «`authorizeMany` pregunta la posición 0 antes de validar»: con el espía viejo (`value.apply(target)`) el caso del juez pasaba; con `receiver` y sin el filtro de `withAncestorsResolver` muere (`contract.spec`: 65 ✅ / 1 ❌ con el mutante; restaurado) | ✅ |
| F9 | `r_sqlite2.mjs` R-H: vista de `forRequest()` reutilizada tras `tree.move` ⇒ `true` (manager fresco `false`); test nuevo «F9: una vista de forRequest() caduca…» | ✅ |
| G1 | `sql_descendants.spec`: `scopeType: 'Node'` no lanzaba al construir; el mensaje del ciclo no decía «posible ciclo» | ✅ |
| G2 | `openfga_driver.spec` «N scopes ⇒ 1 batchCheck…»: 14 checks con `orgA` repetida (esperados 10) | ✅ |
| G3 | (hecho en F1) `queriesSoFar()` eliminado; `calls === 100 * factsPerAuthorize` | ✅ |
| G4 | `r_sqlite2.mjs` R-J (documental): `driver()` esquiva actor/within/onWrite | ✅ jsdoc + README |
| G5 | `spies.spec` «effectivePermissions … ≤ 2 lecturas de hechos»: database 6 consultas (3 `listRoles` + 3 `listDenies`) | ✅ (250 SQLite) |
| F1 | `scratchpad/2d/r_f1.mjs`: dos managers/dos memos sobre la misma BD; vínculo retirado «por otro proceso» (solo la BD cambia) ⇒ `openfga` A/B `true`, `effectivePermissions` con `docs:write` en AMBOS drivers | ✅ verde: 240 SQLite / 319 `:8101` (caso del juez +1 ⇒ 36/49/**58**) |

### F1 — versión compartida del catálogo

- `authz_catalog_version (id=1, version bigint, updated_at)` en `stubs/migration.stub` (con semilla vía `this.defer`) y
  en `tests/helpers/schema.ts`; `migration_stub.spec` pasa a «seis tablas» y comprueba la semilla.
- `src/catalog_cache.ts`: `readAuthzCatalogVersion()`, `bumpAuthzCatalogVersion({ client? })` (UPDATE; sin fila la
  siembra; carrera resuelta por la PK), `CatalogRevalidate = 'always' | { everyMs }` (default `'always'`).
  `view()`: sin foto o invalidada en proceso ⇒ carga (versión de la fila leída ANTES de las tablas); con foto ⇒
  revalida (1 SELECT por PK bajo `guardSql`, revalidaciones concurrentes comparten promesa); versión distinta ⇒
  recarga reutilizando la versión ya leída. `CatalogView.version`. Se retira `ttlMs`/`catalogTtlMs` (sustituido
  por `{ everyMs }`: una sola perilla; el TTL «cinturón multi-proceso» ya no tiene sentido con la fila compartida).
- `syncAuthzCatalog` llama a `bumpAuthzCatalogVersion({ client: trx })` como último paso de su transacción
  (un sync que falla no la sube: test); el `finally` con `invalidateAuthzCatalog()` se conserva para que el sync
  de ESTE proceso se vea al instante también con `everyMs`. `bumpAuthzCatalogVersion()` NO toca el contador del
  proceso a propósito: es el canal entre procesos puro y así el test lo distingue.
- Drivers: `catalogRevalidate` en ambos; openfga toma UNA foto por operación (`authorize`/`authorizeMany`/
  `listScopes` leían permiso y roles con dos `view()` ⇒ ahora 1 revalidación por pregunta, fijado por espía).
- Juez: `makeTwin?` opcional en el harness (default `twinOf`: vista por prototipo con un `CatalogCache` nuevo si
  el driver expone `catalog`) y caso «el catálogo que decide es el de la base…»: dos managers, dos memos, cambio
  en `authz_*` + `bumpAuthzCatalogVersion()` sin señal en memoria ⇒ el otro responde `false` (`authorize`,
  `authorizeMany`, `effectivePermissions`) y un sync real del harness lo restaura. El «otro proceso» se simula con
  lo único que cruza procesos (la fila): SQLite en memoria no se puede compartir con un proceso hijo.
- Espías: `versionChecks` separado de los hechos (`backendCalls` ya no cuenta la revalidación);
  `calls === 100 * factsPerAuthorize` directo (G3 hecho aquí) y `versionChecks === 100`.

### F2 — `within` en las seis escrituras; `requireWithin: 'non-root'`

- `ScopedWriteOptions` para `revoke`/`removeDeny`/`scopes.*` (antes `WriteOptions`, que aceptaba `within` en JS y lo
  ignoraba). `#assertWithin` (fresco, `assertKnownScope` ⇒ `E_AUTHZ_UNKNOWN_SCOPE` antes que la contención) en
  `grant`/`revoke`/`deny`/`removeDeny`/`detached`; `attached`/`moved` contrastan el PADRE con la cadena que
  `#assertEdge` ya resuelve (devuelve la cadena: cero llamadas extra al árbol).
- `requireWithin?: boolean | 'non-root'`; `'non-root'` ⇒ `within: APP_SCOPE` es 422 `E_AUTHZ_WITHIN_ROOT_FORBIDDEN`
  (`errors.ts`, exportado). Con `true` la raíz sigue valiendo (decisión de la spec; el R-K del auditor con `true`
  sigue «escribiendo» a propósito: es `'non-root'` lo que lo cierra).
- Juez: caso nuevo «within en las otras cuatro escrituras…» (revoke/removeDeny contra el scope, attached/moved
  contra el padre, detached contra el hijo, `within` desconocido, hijo ya fuera del árbol ⇒ UNKNOWN_SCOPE) y el
  caso `requireWithin` **reescrito**: antes afirmaba «`revoke`/`removeDeny` no lo exigen»; con F2 las seis lo
  exigen (esa aserción chocaba con la spec y se invirtió, no se relajó: ahora se afirma el 422 y que nada se
  escribió), más la cara `'non-root'` y la negativa (`false` sigue escribiendo).
- `scopes.detached` con `within` exige que el hijo siga en el árbol (hay que contrastar su cadena): purga antes
  de borrar la fila; sin `within` sigue sin consultar el árbol (S6).

### F3 / F8 / F10 — `authorizedScopes` coherente con `authorize`, acotado antes de pasear, `ExcludedSubtree`

- **Desviación (F3, a mejor):** la spec pedía «`descendantsOf(deny) === null` ⇒ 503» y «verificación de
  pertenencia por `resolveAncestors(candidato)`». Al contrastar cada candidato con su cadena (memoizada por
  request) el deny se aplica **por la cadena** —exactamente la regla de `authorize`— y `descendantsOf` ya no se
  llama para los denies: el `null`-para-deny no existe y no puede filtrar nada. Un candidato cuya cadena no pasa
  por el scope concedente, o que `resolveAncestors` no conoce ⇒ 503 `E_AUTHZ_RESOLVER_FAILED` («los dos
  resolutores describen árboles distintos»). `null` para un grant sigue conservador (`[]`, documentado). Coste:
  ≤ 1 `resolveAncestors` por candidato (espía en el juez), el que la spec aceptó.
- **F8, refinamiento:** la cota cuenta scopes **del tipo pedido** (directos del tipo antes de bajar; conteo
  dentro del bucle, corte inmediato) en vez de `direct.length`/`candidates.size + denies.length`: la fórmula
  literal daba 422 falsos (5 orgs sin units al pedir `unit` con `maxScopes 3`; o un deny que excluye 990 de 1000
  units) y rompía el caso existente del juez «la cota es sobre la RESPUESTA». El objetivo (no pasear todo) se
  cumple: 5 orgs > 4 ⇒ 0 llamadas a `descendantsOf`; units ⇒ ≤ 2 subárboles bajados de 5. `options.maxScopes`
  = `min(llamada, config)`. `#scopeBounds` valida ambas cotas.
- **F10:** `ExcludedSubtree = { scope, includesDescendants: true }`; `authorizedScopes.all.excludedSubtrees` lo
  usa; `manager.expandExcludedSubtrees(excluded, { maxScopes? })` (+ función exportada
  `expandExcludedSubtrees(view, excluded)`): scope + subárbol, `null` de `descendantsOf` ⇒ 503 (restar a medias
  es fail-open), cotas ⇒ 422. En `AuthorizationView`.
- `manager.spec` B3: el test «el maxNodes que recibe el resolutor es maxDescendants» devolvía 4 units aleatorias
  que `resolveAncestors` no conocía ⇒ con F3 sería 503; ahora las units cuelgan de orgA en el árbol (la aserción
  se conserva). Tests nuevos F8 y F10 en `manager.spec`; juez: caso F3 «≡ { s | authorize(s) }» (deny intermedio,
  3 niveles, `descendantsOf` ciego para el deny, cruzado ⇒ 503, fantasma ⇒ 503, ≤ N+1 llamadas al árbol) y F8 en
  el caso de `maxScopes` (por llamada no sube; 0 `descendantsOf` cuando los directos ya superan).

### F4 — invalidación de instancia en vuelo

`CatalogCache.invalidate()` es un bump de `#generation`; `#load` captura la generación antes de leer la fila y
las tablas y la foto queda marcada con ella (`#loadedGeneration`); `#isFresh` exige contador del proceso y
generación de instancia. Test con carga en vuelo para ambas señales (instancia y global).

### F5 — `authorizeMany` valida al driver de terceros

Respuesta que no es array, longitud ≠ scopes, o elemento no booleano ⇒ 500 `E_AUTHZ_INTERNAL` con el nombre del
driver y qué llegó. Una respuesta bien formada pasa intacta.

### F6 — `hierarchicalScopeResolver`

Clave de visitados con `\u001f` (escape explícito); el padre devuelto pasa por `assertScope` ⇒ mal formado (incluido
`{app, uuid}`) ⇒ 503 `E_AUTHZ_RESOLVER_FAILED` del propio resolutor (y a través de un driver, 503, nunca `false`).

### F7 — espía del juez

`value.apply(receiver, args)` y `touched` sin filtro: la vista `Object.create(this)` hereda del Proxy y se ve. El
caso además afirma que el espía VE una llamada válida (contra un espía vacío). Mutante comprobado (tabla).

### F9 — `forRequest({ maxAgeMs })`

`ForRequestOptions.maxAgeMs` (default `DEFAULT_VIEW_MAX_AGE_MS = 30_000`; `0` = sin límite explícito; inválido ⇒
500 `E_AUTHZ_CONFIG`). `#reader()` —por donde pasan TODAS las lecturas, incluidas `authorizeMany`/
`effectivePermissions`/`authorizedScopes`— lanza 500 `E_AUTHZ_VIEW_EXPIRED` (`ViewExpiredError`, exportado) tras
el límite. Escrituras e `isWithin` siguen (resuelven en fresco). Test con `maxAgeMs: 1` + 5 ms y con `Date.now`
parcheado para el default (29 999 ms vale, 30 000 no) y `maxAgeMs: 0` un día después.

### G1 — `sqlDescendantsOf`

Barrera de uuid repetido eliminada (inalcanzable: con profundidad `maxNodes + 1` un ciclo nunca cabe en `maxNodes`
filas; `ScopeCycleError` ya no se importa aquí), mensaje del 422 con «posible ciclo», `scopeType` por
`assertScopeType` (+ nunca `app`) al construir ⇒ 500 `E_AUTHZ_CONFIG`. CLAUDE.md/README sin la promesa «uuid
repetido ⇒ ciclo».

### G2 — `authorizeMany` openfga

Un slot por `scopeKey`: el scope repetido comparte checks, cadena y respuesta; el espía de conteo pasa de 14 a 10.

### G4 — `manager.driver()`

Jsdoc en el manager («salida explícita de las barreras… código de plataforma y tests; nada más por aquí») y README
§Actor. No se renombra: ya se llamaba `driver()` y romperlo no aporta.

### G5 — `effectivePermissions` en dos lecturas

Puerto: `rolesInChain?(subject, chain)` → `{ scope, role }[]` (directos, vigentes, del catálogo). `database`: una
consulta `whereScopeIn(chain)` con join a `authz_roles` (`distinct scope_type, scope_uuid, slug`); `openfga`:
`listBindings` una vez, filtrado por las claves de la cadena y por `roleSlugs(nivel)`. El manager lo usa si existe
(si no, N `listRoles` en paralelo) y lee `listDenies(subject)` UNA vez quedándose con los de la cadena. Espía en
ambos drivers: ≤ 2 lecturas de hechos.

## Desviaciones respecto a la spec (con porqué)

1. **F1 · `ttlMs`/`catalogTtlMs` retirados** en favor de `catalogRevalidate: { everyMs }`: con la fila compartida el
   TTL no aporta nada que la ventana no dé, y dos perillas para lo mismo confunden. El test «con catalogTtlMs el
   memo caduca solo» se reescribió como el test de `everyMs` (misma observación: el cambio ajeno no se ve hasta
   que vence la ventana; el sync de este proceso se ve al instante).
2. **F1 · «otro proceso» en el juez** = cambio en `authz_*` + `bumpAuthzCatalogVersion()` sin señal en memoria.
   Un proceso hijo real no puede compartir la SQLite en memoria de la suite; la fila es lo único que cruza
   procesos y es exactamente lo que deja un sync ajeno (un test unitario prueba que el sync real sube la fila
   en su transacción y que uno que falla no).
3. **F1 · `bumpAuthzCatalogVersion()` no invalida en memoria** (a propósito): es el canal entre procesos puro y así
   los tests distinguen los dos canales; `syncAuthzCatalog` sí hace ambas cosas.
4. **F3 · sin «null para deny ⇒ 503»**: el deny se aplica por la cadena de cada candidato (regla de `authorize`),
   así que `descendantsOf` no se llama para denies y ese `null` no existe. Es más fuerte que lo pedido y
   mantiene la promesa del README. En `expandExcludedSubtrees` (F10) el `null` sí es 503 (restar a medias).
5. **F8 · cota por tipo pedido** en vez de `direct.length`/`candidates.size + denies.length` (ver sección F3/F8):
   la fórmula literal daba 422 falsos y rompía el caso existente «la cota es sobre la RESPUESTA».
6. **G4 · sin renombrar**: `driver()` ya se llamaba así; se documenta (jsdoc + README §Actor) como salida de las
   barreras y no se añade nada más.
7. **F2 · `requireWithin: true` sigue admitiendo `within: APP_SCOPE`** (decisión de la spec: el cierre del comodín es
   `'non-root'`). El R-K del auditor con `true` sigue «escribiendo» a propósito.

## Tests existentes cambiados (nunca relajados)

- Juez «requireWithin: true ⇒ …»: afirmaba «`revoke`/`removeDeny` no lo exigen»; ahora afirma que las seis lo
  exigen (422 + nada escrito) y añade `'non-root'`.
- Juez «all SOLO con excludedSubtrees»: `excludedSubtrees` pasa de `ScopeRef[]` a `ExcludedSubtree[]`
  (`{ scope, includesDescendants: true }`), con la expansión ≡ `{ s : !authorize(s) }`.
- Juez «authorizeMany…»: espía con `receiver` y sin filtrar `withAncestorsResolver`; además exige que el espía
  VEA una llamada válida.
- `manager.spec` B3: las 4 units del caso `maxDescendants` cuelgan ahora del árbol (con F3 serían 503).
- `catalog_cache.spec`: conteos con `versionChecks` aparte (100 revalidaciones por 100 preguntas; openfga
  `queries.length` 3 → 103); el caso negativo sigue (sin bump no se ve) y se añade la cara positiva del bump.
- `spies.spec`: `backendCalls` cuenta solo hechos (catálogo y versión aparte); `queriesSoFar()` eliminado (G3).
- `openfga_driver.spec` «N scopes ⇒ 1 batchCheck»: 14 → 10 checks (G2).
- `migration_stub.spec`: seis tablas + semilla de la versión.

## Hallazgos por el camino

- El otro implementador (detenido) había dejado en `catalog_cache.spec` una aserción de mi primer test con su
  helper `versionReads`; tras su reversión el título había vuelto al viejo con el cuerpo nuevo: se restauró.
- `manager.spec` importa `withTableMissing` de `database_driver.spec`, así que no se puede correr solo
  (`--files`): el juez de un spec suelto falla por «Cannot import japa test file directly». No es de este lote.
- `bumpAuthzCatalogVersion` usa `increment`; sin fila la siembra y resuelve la carrera por PK (no observado con
  dos procesos reales; documentado).

## Archivos tocados

`src/catalog_cache.ts`, `src/catalog.ts`, `src/manager.ts`, `src/types.ts`, `src/errors.ts`, `src/define_config.ts`,
`src/hierarchical_resolver.ts`, `src/sql_descendants.ts`, `src/drivers/database_driver.ts`,
`src/drivers/openfga_driver.ts`, `src/testing/contract.ts`, `index.ts`, `stubs/migration.stub`,
`scripts/bench_authorize.mjs`, `tests/helpers/schema.ts`, `tests/migration_stub.spec.ts`, `tests/catalog_cache.spec.ts`,
`tests/spies.spec.ts`, `tests/manager.spec.ts` (parche del tester + F5/F8/F9/F10), `tests/hierarchical_resolver.spec.ts`,
`tests/sql_descendants.spec.ts`, `tests/openfga_driver.spec.ts`, `tests/contract_harness.spec.ts`, `README.md`,
`CHANGELOG.md` (sección «Lot 2D»), `CLAUDE.md` (invariantes 14–16, mapa, roadmap 2D ✅). Scratchpad:
`scratchpad/2d/r_f1.mjs` (repro F1), `bench_before.txt`/`bench_after.txt`, salidas de cada suite.
