# `2.4.0-alpha.9` · lote A — banderas de ace inertes (`name` pisa la propiedad)

Rama `main`, HEAD de partida `d18af8e` (alpha.8 publicada), árbol limpio al empezar.
**Sin commits; `version` sigue en `2.4.0-alpha.8`.** No se tocó `.claude/contexto/panel-shared-store-*`.

## 0 · Alcance medido (antes de tocar nada)

`grep -rn "name: '" commands/*.ts` ⇒ **18 opciones `name:`** en 7 ficheros (no 17).

**16 son las multi-palabra** y son las INERTES. Los informes 4 y 5 dicen «17», pero la suma de su
propia tabla da **16** (4+4+4+1+1+1+1). Las otras dos —`only` de `authz:scopes:relay` e `id` de
`authz:scopes:requeue`— son de una sola palabra: `dashCase('only') === 'only'`, así que propiedad y
bandera coincidían por casualidad y **funcionaban** (COGNITIV lo verificó). Se quitan igual: es la
misma trampa esperando a que alguien renombre la propiedad.

Fuera de `commands/` no hay ni una declaración de banderas (grep sobre `.ts` del repo sin
`node_modules`/`build`).

## 1 · Las 18, con su bandera pública ANTES y DESPUÉS

Calculado con el mismo `string.dashCase` de `@poppinss/utils/string` que usa ace.

| fichero | propiedad declarada | bandera ANTES | bandera DESPUÉS | propiedad hidratada ANTES | DESPUÉS |
|---|---|---|---|---|---|
| `authz_reconcile.ts` | `dryRun` | `--dry-run` | `--dry-run` | `dry-run` ❌ | `dryRun` ✅ |
| `authz_reconcile.ts` | `allowMassDelete` | `--allow-mass-delete` | `--allow-mass-delete` | `allow-mass-delete` ❌ | `allowMassDelete` ✅ |
| `authz_reconcile.ts` | `batchSize` | `--batch-size` | `--batch-size` | `batch-size` ❌ | `batchSize` ✅ |
| `authz_reconcile.ts` | `maxTuples` | `--max-tuples` | `--max-tuples` | `max-tuples` ❌ | `maxTuples` ✅ |
| `authz_relations_reconcile.ts` | `dryRun` | `--dry-run` | `--dry-run` | `dry-run` ❌ | `dryRun` ✅ |
| `authz_relations_reconcile.ts` | `allowMassDelete` | `--allow-mass-delete` | `--allow-mass-delete` | `allow-mass-delete` ❌ | `allowMassDelete` ✅ |
| `authz_relations_reconcile.ts` | `partitionType` | `--partition-type` | `--partition-type` | `partition-type` ❌ | `partitionType` ✅ |
| `authz_relations_reconcile.ts` | `partitionUuid` | `--partition-uuid` | `--partition-uuid` | `partition-uuid` ❌ | `partitionUuid` ✅ |
| `authz_scopes_relay.ts` | `dryRun` | `--dry-run` | `--dry-run` | `dry-run` ❌ | `dryRun` ✅ |
| `authz_scopes_relay.ts` | `batchSize` | `--batch-size` | `--batch-size` | `batch-size` ❌ | `batchSize` ✅ |
| `authz_scopes_relay.ts` | `waitLeaseMs` | `--wait-lease-ms` | `--wait-lease-ms` | `wait-lease-ms` ❌ | `waitLeaseMs` ✅ |
| `authz_scopes_relay.ts` | `maxAge` | `--max-age` | `--max-age` | `max-age` ❌ | `maxAge` ✅ |
| `authz_scopes_relay.ts` | `only` | `--only` | `--only` | `only` (ok) | `only` ✅ |
| `authz_scopes_requeue.ts` | `id` | `--id` | `--id` | `id` (ok) | `id` ✅ |
| `authz_scopes_requeue.ts` | `waitLeaseMs` | `--wait-lease-ms` | `--wait-lease-ms` | `wait-lease-ms` ❌ | `waitLeaseMs` ✅ |
| `authz_freeze.ts` | `leaseMs` | `--lease-ms` | `--lease-ms` | `lease-ms` ❌ | `leaseMs` ✅ |
| `authz_catalog_diff.ts` | `failOnShadows` | `--fail-on-shadows` | `--fail-on-shadows` | `fail-on-shadows` ❌ | `failOnShadows` ✅ |
| `authz_catalog_prune_orphans.ts` | `allowMassPurge` | `--allow-mass-purge` | `--allow-mass-purge` | `allow-mass-purge` ❌ | `allowMassPurge` ✅ |

**BANDERAS PÚBLICAS QUE CAMBIAN: 0.** Ninguna necesitó `flagName:` explícito. No hubo que PARAR.
(Comparación mecánica ANTES/DESPUÉS sobre `git show HEAD:commands/*.ts` vs el árbol.)

## 2 · Por pieza: rojo → verde → mutante

Fichero nuevo: **`tests/command_flags.spec.ts`** (13 casos). Toda bandera entra por
`exec(['--<bandera>=<valor>'])` por el kernel de ace real (`tests/helpers/ace.ts`: `AppFactory`,
`kernel.exec` no relanza) y se afirma el EFECTO. **Ni un `cmd.<prop> = …` a mano.**

| caso | qué fija | ROJO literal antes del arreglo | verde |
|---|---|---|---|
| **A-G-1** (guardia estática) | ningún `@flags.*` de `commands/` declara `name:` | `expected [ …(18) ] to deeply equal []` | ✅ |
| **A-G-2** (guardia estática) | bandera efectiva === `dashCase(propiedad)` | verde ya (no había `flagName:`); mutante la mata | ✅ |
| **A-G-3** (guardia, vista por ace) | en los flags BOOTEADOS, `flag.name` sin guiones y `flagName === dashCase(name)` | `authz:catalog:diff: el flag 'fail-on-shadows' … expected 'fail-on-shadows' to not include '-'` | ✅ |
| **A-1** `relay --dry-run` (EL CASO de COGNITIV) | dos pendientes ⇒ `applied_at IS NULL` en las dos, driver sin tocar, rama de dry-run en la salida | `expected 1789176158517 to equal null` (las aplicaba) | ✅ |
| **A-2** `relay --limit=1 --max-age=1` | exit ≠ 0 y la letra de la alarma | `expected +0 to equal 1`, con el log «Cabeza de la cola: … (600003 ms)» y ningún error: la alarma no disparaba | ✅ |
| **A-3** `relay --batch-size=7 --wait-lease-ms=250` | llegan a `relayScopeChanges` | `expected undefined to equal 7` | ✅ |
| **A-4** `requeue --id=12 --apply --wait-lease-ms=750` | llega a `requeueScopeChanges` | `expected undefined to equal 750` | ✅ |
| **A-5** `reconcile --to --from --dry-run` | **CERO escrituras en el destino** + la bandera llega al DRIVER + rama de dry-run (y NO «reconciliado») | `el verificador es read-only POR CONTRATO: expected 3 to equal +0` | ✅ |
| **A-6** `reconcile --allow-mass-delete --batch-size=25 --max-tuples=4242` | llegan al manager y al driver | `--allow-mass-delete: expected false to be true` | ✅ |
| **A-7** `relations:reconcile --partition-type=organization --partition-uuid=<uuid>` | la partición que llega al motor (espía sobre `enumerateRelations`) es ESA | `expected { type: 'app', uuid: null } to deeply equal { type: 'organization', … }` | ✅ |
| **A-8** `freeze --reason --lease-ms=60000` | llega a `freeze()` **y** la salida dice «caduca SOLA en 60000 ms» (no «NO caduca sola») | `expected null to equal 60000` | ✅ |
| **A-9** `prune-orphans --force --allow-mass-purge` | llegan a `pruneOrphanRoles` | `expected false to be true` | ✅ |
| **A-10** `catalog:diff --fail-on-shadows` | **exit 1** con un local ensombrecido por el de un ancestro; sin la bandera, exit 0 | `con la bandera inerte el gate seguía verde: expected +0 to equal 1` | ✅ |

**Rojo global antes del arreglo: 12 de 13.** Verde después: 13 de 13.

### Mutantes

1. `name: 'dry-run'` devuelto a `authz:scopes:relay` ⇒ **3 rojos**: `A-1` (el efecto: las dos entradas
   quedan aplicadas), `A-G-1` y `A-G-3` (`el flag 'dry-run' tiene el nombre de la BANDERA donde va el
   de la PROPIEDAD`). Restaurado.
2. `flagName: 'seco'` en la misma (una bandera pública que NO es `dashCase(propiedad)`) ⇒ **3 rojos**:
   `A-G-2`, `A-G-3` (`--seco no es dashCase('dryRun')`) y `A-1`. Restaurado. Sirve para demostrar que
   `A-G-2` no es vacuo.

## 3 · El arreglo

- Quitado `name:` de las 18 opciones (7 ficheros, `-18/+6` líneas). Sin `flagName:` en ninguna.
- **`tests/scope_outbox.spec.ts`: 6 aserciones existentes leían el campo equivocado.** Hacían
  `(Command.flags ?? []).map((f) => f.name ?? f.flagName)` y afirmaban `includeMembers(['dry-run',
  'batch-size', 'wait-lease-ms', 'max-age', 'only', 'id'])`: pasaban en verde **porque** el paquete
  pasaba `name:` en las opciones — o sea, tenían el defecto codificado como expectativa. Eran los
  casos que parecían cubrir las banderas y no cubrían nada. Ahora hay un helper `flagNamesOf(Command)`
  —`flagName`, la bandera PÚBLICA, nunca `name`— con el porqué escrito, y las seis lo usan. Las
  banderas que afirman no cambian.

## 4 · Docs

- **CHANGELOG**: `## [Unreleased] — 2.4.0-alpha.9`, estilo 1.1.0 (problema → decisión → qué NO se
  hace) **empezando por el impacto**: `--dry-run` de los dos reconciles escribía y
  `authz:relations:reconcile` migraba cero reportando éxito; párrafo propio con el aviso de que quien
  haya corrido `authz:reconcile --dry-run` contra un destino en alpha.4…alpha.8 **tiene que ir a mirar
  ese destino**; tabla con las 16 inertes por comando + la nota de `--only`/`--id`; el punto ciego
  cerrado; los mutantes; y el «qué NO hace este lote» (el 🔴 3 de `--prune` / `familyOfTuple` queda
  fuera: es del panel del store compartido).
- **CLAUDE.md**: fila `commands/` ampliada (aditivo, un bloque): la regla `name` vs `flagName`, el
  mecanismo de ace, las 18, «ni un nombre público cambió» y la guardia de
  `tests/command_flags.spec.ts` con la regla «la bandera de verdad por el kernel; `cmd.dryRun = true`
  a mano no detecta nada».

## 5 · Verificación

| comprobación | resultado |
|---|---|
| `npx tsc --noEmit -p tsconfig.json` | ✅ 0 |
| `npm run typecheck` (`tsconfig.test.json`) | ✅ 0 |
| `npm run check:purity` | ✅ verde |
| `npm run build` | ✅ 0 (y `grep "name: '" build/commands/*.js` ⇒ 0 resultados) |

Las cuatro corridas, en PRIMER PLANO y en SECUENCIA, todas con `OPENFGA_TEST_URL=http://localhost:8101`
(`:8101` arriba, `/stores` ⇒ 200):

| suite | base (alpha.8) | ahora | delta |
|---|---|---|---|
| `npm test` (sqlite) | 1351 | **1364** | +13 |
| `npm run test:sqlite-file` | 1377 | **1390** | +13 |
| `npm run test:pg` (`TEST_PG_URL` de `postgres18`) | 1473 | **1486** | +13 |
| `npm run test:mysql` | 1475 | **1488** | +13 |

Las cuatro **PASSED**, 0 fallos, sin `skip`. El delta es exactamente los 13 casos nuevos en los cuatro
motores (ninguno gateado por motor ni por `OPENFGA_TEST_URL`).

Corridas a fichero en el scratchpad de la sesión (`runs/rojo-1.txt`, `rojo-2.txt`, `verde-1.txt`,
`mutante.txt`, `mutante-2.txt`, `sqlite.txt`, `sqlite2.txt`, `sqlitefile.txt`, `pg.txt`, `mysql.txt`,
`antes-despues.txt`).

## 6 · Lo que NO hice

- **No arreglé el 🔴 3 del quinto informe** (`authz:reconcile --prune` borra las tuplas de RELACIÓN de
  un store compartido; `familyOfTuple` con `return 'facts'` de catch-all en
  `src/drivers/openfga_driver.ts`, y el corolario `clean = false` para siempre). Es el lote (B) de la
  decisión del dueño: va a panel porque choca con una propiedad publicada.
- **No hice commits** ni subí `version` (sigue `2.4.0-alpha.8`); no publiqué nada.
- **No toqué el README ni los runbooks**: ningún nombre público de bandera cambió, así que no hay nada
  que corregir ahí (y por eso `--only`/`--id` tampoco se renombran).
- No añadí, renombré ni retiré ninguna bandera, ni cambié la salida de ningún comando más allá de las
  ramas a las que las banderas nunca llegaban.
- No monté el caso de `authz:reconcile --dry-run` contra el `:8101` con un store real: el caso A-5 usa
  un destino doble que **escribe en su store salvo en `--dry-run`** (el borde donde el valor decide la
  escritura, y donde alpha.8 fallaba) y además afirma que la bandera llega al DRIVER. La medición de
  COGNITIV (463 tuplas en un store vacío) queda como evidencia externa; un caso equivalente contra el
  `:8101` sería más fiel y no lo escribí.
- No toqué `.claude/contexto/panel-shared-store-*` (hay 2 ficheros de los agentes de solo lectura en
  paralelo).
