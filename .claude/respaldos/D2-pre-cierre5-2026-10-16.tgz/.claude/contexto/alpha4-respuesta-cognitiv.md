# Respuesta a COGNITIV (informe 09-09) — enviada/para enviar el 2026-09-09, alpha.4 publicada

> Asunto: Re: hallazgos de la prueba real de cambio de driver — defecto aceptado (opción B), uno más grave detrás, y las dos preguntas

Gracias: el informe clasifica bien lo que es del paquete y lo que no, y el diagnóstico de `openfga:provision` es
correcto (confirmado línea a línea contra `@adonisjs/application`). Lo llevamos a panel (analista, auditor, tester)
y esto es lo que salió.

**1 · `openfga:provision` — aceptado, y corregido con la opción B, no la A.** Los tres panelistas midieron lo
mismo: `startApp: true` hace `boot()` **y `start()`**, y `start()` ejecuta los preloads y los hooks `start`/`ready`
de vuestros providers con la base ausente (un `ready()` que toque la base ⇒ `ECONNREFUSED` antes de llegar al
comando), puede ser circular (un preload que importe el servicio de relaciones pide `OPENFGA_STORE_ID`, que es lo
que este comando produce) y arrastra a Lucid pidiendo `Database` del contenedor. `boot()` a mano sin `start()` carga
`config/*` y nada más. Así que el comando arranca «hasta `boot()`»; lo único que exige es que todo `config/*` pueda
importarse. El caso que lo fija ejecuta el comando de verdad por el kernel de ace, sin servidor y contra OpenFGA, y
lo repetimos con Node 24.

**Lo que había debajo, y que vuestro envoltorio tapaba — gracias por la evidencia, cuadra al detalle.**
Confirmado: `@jantstack/adonis-authz/commands` no era un loader de ace válido (ace exige `getMetaData()`/`getCommand()`
en el módulo, como `@adonisjs/core/commands`), así que la línea que `node ace configure` escribe rompía `node ace`
entero; vuestro `new ListLoader(Object.values(m))` es exactamente el parche correcto para la alpha.3, y explica por qué
llegabais a la línea 46 con `startApp: false` intacto (la metadata de `serialize()` es la misma por las dos vías).

Dos precisiones sobre vuestra sugerencia, verificadas contra el código de ace:
- **Un `default` no arregla nada**: `Kernel.boot` llama `loaderInstance.getMetaData()` directamente sobre el
  namespace del módulo y no desenvuelve `default`; `@adonisjs/core/commands` tampoco exporta uno. Lo correcto —y lo
  que hace la alpha.4— son `getMetaData`/`getCommand` nombrados (sobre `ListLoader`, sin `commands.json`).
- **Eso rompe vuestro envoltorio**: `Object.values(m)` pasará a incluir esas dos funciones y `ListLoader` llama
  `serialize()` sobre cada entrada. Al subir a la alpha.4, quitad el envoltorio y registrad el módulo directamente:
  `() => import('@jantstack/adonis-authz/commands')` (lo que `configure` escribe). Va en el CHANGELOG como nota de
  migración, con un caso que fija la frase.

Y se añaden casos que EJECUTAN los comandos por el kernel de ace, que era el punto ciego de la suite (nueve
comandos, nueve helpers juzgados con el config a mano).

**2 · `capabilities()` — sí.** `authorization.capabilities()` (async: resuelve el driver, y por tanto pasa las mismas
puertas que cualquier uso — a propósito, las capacidades son de la instancia) y `relations.capabilities()` (sync).
Devuelven una copia congelada y normalizada (todas las claves presentes, nunca `undefined`). `driver()` sigue
siendo API de plataforma; para leer capacidades, esta es la vía bendecida en el README.

**3 · `sqlScopeEdges` multi-tabla — docs, con una trampa que conviene que conozcáis.** Vuestro `enumerateScopeEdges`
a mano (UNION ALL, cursor por uuid) es la receta correcta y la documentamos. Lo que NO vale es concatenar tres
`sqlScopeEdges`: cada uno hace su `LEFT JOIN` contra su propia tabla y descarta en silencio la fila cuyo padre
está en otra, y un `reconcile --prune` borraría esas aristas del store (subárbol entero denegando). Un helper de
composición verificado por la suite va a 2.6.

Publicada hoy: `2.4.0-alpha.4` con dist-tag `alpha` (`npm i @jantstack/adonis-authz@alpha`), sin breaking de API.
Verificada en SQLite, SQLite-fichero, PostgreSQL 18 y MySQL 8.4 contra OpenFGA, con auditoría sobre el diff; el caso
que ejecuta `openfga:provision` por el kernel de ace pasa en Node 22 y en Node 24. Al subir: quitad el envoltorio
`ListLoader(Object.values(m))` y registrad `() => import('@jantstack/adonis-authz/commands')`; y podéis retirar
vuestro `zz_tmp_openfga_provision.ts`.
