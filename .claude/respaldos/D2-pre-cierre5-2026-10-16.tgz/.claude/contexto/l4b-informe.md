# L-4b · el UNIQUE de `authz_relations` defiende también a los HOLDERS — informe (incremental)

Base: `main` @ `23e292d` (L-4), árbol limpio al empezar. Decisión del dueño (2026-09-02):
`subject_relation NOT NULL DEFAULT ''` + backfill. Logs de cada corrida en el scratchpad
(`/tmp/claude-1000/-home-jose/66ad04a0-…/scratchpad/l4b-*.log` y `suite-*.log`), salida literal citada aquí.
**Sin commits** (los hace el dueño). Ficheros tocados: `stubs/migration.stub`, `tests/helpers/schema.ts`,
`src/relation_partition_trigger.ts`, `src/drivers/database_relations_driver.ts`, `tests/relations_database.spec.ts`,
`tests/migration_stub.spec.ts`, `tests/upgrade_recipe.spec.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`.

## Pieza 1 · El caso se FLIPA y está ROJO antes de tocar nada ✅

`tests/relations_database.spec.ts`, grupo «L-4 · … pool ≥ 2»: el caso `HALLAZGO · el UNIQUE … NO cubre
subject_relation NULL …` pasa a ser `L-4b · el UNIQUE de authz_relations cubre también al HOLDER …`. Mismo
protocolo que el caso del userset (T1 inserta sin confirmar; T2 inserta lo mismo; 300 ms; T1 confirma; T2
se resuelve DESPUÉS) y afirma: `second.ok === undefined`, **exactamente UNA fila**, el perdedor 409
`E_AUTHZ_WRITE_CONFLICT` (PG abortada / MySQL viva) o 503 `SQLITE_BUSY` en sqlite-file, UN evento,
`listSubjects` ×1 **y `enumerateRelations` ×1** (el censo del reconcile), `unrelate` ⇒ 0.

Rojo literal, sin tocar esquema ni driver (`l4b-rojo-pg.log`, `l4b-rojo-mysql.log`):

```
ℹ AssertionError: ROJO: pg: el segundo relate del MISMO hecho de holder ENTRÓ (el UNIQUE no lo defiende); censo = 2 filas: expected true to equal undefined
Tests  44 passed, 1 failed (45)
```
```
ℹ AssertionError: ROJO: mysql: el segundo relate del MISMO hecho de holder ENTRÓ (el UNIQUE no lo defiende); censo = 2 filas: expected true to equal undefined
Tests  44 passed, 1 failed (45)
```

**Honesto:** en `sqlite-file` el caso flipado ya está VERDE antes del cambio (`l4b-rojo-sqlite-file.log`:
`45 passed (45)`): el segundo escritor recibe `SQLITE_BUSY` antes de llegar al índice, así que el defecto
del UNIQUE no era observable ahí por concurrencia. En SQLite el rojo→verde del esquema lo da la pieza 2 (un
segundo INSERT del mismo holder con `''` rechazado por el UNIQUE, que con NULL entraba — caso del grupo del
trigger, en los CUATRO modos, `:memory:` incluido).

## Pieza 2 · El esquema, por motor (stub + espejo + trigger) ✅

- `stubs/migration.stub` y `tests/helpers/schema.ts`: `table.string('subject_relation', 50).notNullable().defaultTo('').collate('utf8mb4_bin')`
  (el MISMO texto en los dos; `migration_stub.spec` K11 sigue comparando columna a columna en los tres motores).
- **Cómo declara CADA motor el default, medido** (`migration_stub.spec`, caso nuevo `L-4b: …`, lee el catálogo del
  motor de la base construida por el STUB; `l4b-stub-{sqlite,sqlite-file,pg,mysql}.log`, 8/8 en los cuatro):

  | motor | tipo según el motor | `column_default` / `dflt_value` | nullable |
  |---|---|---|---|
  | PostgreSQL 18 | `character varying(50)` | `''::character varying` | NO |
  | MySQL 8.4 | `varchar(50)`, collation `utf8mb4_bin` | `''` | NO |
  | SQLite | `varchar(50)` (`PRAGMA table_info`) | `''` (`notnull = 1`) | NO |

  Y el comportamiento, en los tres: una fila insertada SIN la columna es un holder `''` (el default lo pone el
  motor), NULL explícito ⇒ rechazado (NOT NULL), y el MISMO hecho de holder dos veces ⇒ el segundo INSERT lo
  rechaza el UNIQUE (`'' = ''`). El caso también fija el TEXTO del stub (`notNullable().defaultTo('')`) y que su
  trigger inlineado ya no dice `IS NOT NULL` (tres `<> ''`).
- **El trigger de partición cambia con el esquema** (`src/relation_partition_trigger.ts` y la copia inlineada del
  stub): «es userset» es `NEW.subject_relation <> ''`, no `IS NOT NULL`. Con `''` en los holders, `IS NOT NULL`
  dispararía en CADA holder (`subject_partition` NULL ≠ `partition_key`) — lo medí: es el mutante B, abajo. Una
  fila vieja con NULL tampoco dispara (`NULL <> ''` es NULL —falso— en SQLite, PG y MySQL). El caso «un HOLDER …
  NO lo mira el trigger» del grupo del trigger inserta el holder con `''` explícito Y con la columna omitida, y
  hay dos casos nuevos en ese grupo: NULL explícito rechazado, y el mismo holder dos veces rechazado por el UNIQUE.

## Pieza 3 · El driver `database` ✅

`src/drivers/database_relations_driver.ts`:
- `HOLDER_RELATION = ''` (constante con su porqué: `''` y no un centinela porque la gramática de una relación no
  admite la vacía, así que ningún userset colisiona). `#subjectColumns` devuelve `relation: ''` para el holder
  (tipo `string`, ya no `string | null`); `RelationRow.subject_relation: string`. El INSERT de `relate` escribe `''`.
- **Tolerancia a NULL en LECTURA — decisión: SÍ, tolerante.** El backfill es responsabilidad del consumidor y el
  driver no rompe con una fila que no escribió: `check`/`listObjects` ya usaban `COALESCE(subject_relation, '')`
  en el JOIN de la CTE `principal`; `membersOf` pasa de `subject_relation IS NULL` a `COALESCE(…, '') = ''` (dos
  tramos); `#rowToSubject` (`listSubjects`/`enumerateRelations`) trata `''` **o** NULL como holder; y el WHERE
  por sujeto de `relate` («¿ya existe?»), `unrelate` y `purgeSubject` va por `#whereSubjectRelation`: para un
  holder `subject_relation = '' OR subject_relation IS NULL`, para un userset su relación exacta. La razón de
  tolerar también en los BORRADOS es de seguridad: un `unrelate` que no viera la fila vieja la dejaría
  concediendo tras retirarla (fail-open). Medido en la pieza 4 sobre la forma alpha (fila con NULL): `check`
  true, `listSubjects` ×1 como holder, `enumerateRelations` ×1, `membersOf` la cuenta, `relate` del mismo holder
  la ENCUENTRA (no-op, no una segunda fila), `unrelate` y `purgeSubject` la BORRAN.
- Lo que la tolerancia NO cubre, medido y dicho (pieza 4): las ESCRITURAS de holder contra el trigger VIEJO.

Verde del caso flipado tras el cambio (`l4b-motor-{sqlite,sqlite-file,pg,mysql}.log`): **40 / 47 / 47 / 47** en
`relations_database.spec.ts` (era 38 / 45 / 45 / 45: +2 en los cuatro modos, los dos casos de esquema del grupo
del trigger; el caso concurrente se flipa, no se añade).

## Pieza 4 · La receta de migración (alpha.1/alpha.2 → L-4b), EJECUTADA en los tres motores ✅ — con DOS medidas que la corrigieron

README (`### Upgrading from 2.4.0-alpha.2 (before L-4b): authz_relations.subject_relation`, junto a la de R-15) y
CHANGELOG (`### Lot L-4b`, encima de L-4). Tres bloques ```sql marcados `-- L-4b · PostgreSQL|MySQL|SQLite`,
**una sentencia por línea** (los cuerpos de los triggers llevan `;` dentro: cada línea se ejecuta ENTERA, nunca
por un runner que trocea por `;`). `tests/upgrade_recipe.spec.ts`, grupo nuevo «L-4b · la receta …», en los
CUATRO modos (no gateado a PG/MySQL como K14): crea en una base de trabajo la forma alpha (`subject_relation`
nullable + trigger con `IS NOT NULL`, literalmente el de L-4 con `<> ''` → `IS NOT NULL`), siembra holders con
NULL —uno de ellos DOS veces, lo que el índice viejo dejaba pasar—, un userset, ejecuta la receta literal del
README, y compara la columna según el motor con el espejo. `l4b-receta-{sqlite,sqlite-file,pg,mysql}.log`:
1/1, 1/1, 2/2, 2/2.

**Orden final, en los tres motores: (1) trigger, (2) de-duplicado, (3) backfill, (4) ALTER.**

| motor | trigger | ALTER | resultado medido |
|---|---|---|---|
| PG | `CREATE OR REPLACE FUNCTION authz_relations_partition_guard()` (el trigger sigue llamándola) | `ALTER COLUMN … SET DEFAULT '', ALTER COLUMN … SET NOT NULL` | columna = espejo byte a byte (`deepEqual` de `describeAuthzSchema`); NULL explícito rechazado |
| MySQL | `DROP TRIGGER IF EXISTS` ×2 + `CREATE TRIGGER` ×2 | `MODIFY subject_relation varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT ''` | ídem |
| SQLite | `DROP TRIGGER IF EXISTS` ×2 + `CREATE TRIGGER` ×2 | **no hay `ALTER COLUMN`** | la ÚNICA diferencia con el espejo es `nullable` de `subject_relation` (medido: el diff del `describeAuthzSchema` es exactamente esa columna y, con `nullable: false`, es igual al espejo); el UNIQUE ya defiende `'' = ''` y el driver nunca escribe NULL; quien quiera la constraint recrea la tabla con la DDL del stub (dicho en el README) |

De-duplicado (portable, una línea): `DELETE … WHERE subject_relation IS NULL AND CAST(uuid AS CHAR(36)) NOT IN
(SELECT keep FROM (SELECT MIN(CAST(uuid AS CHAR(36))) AS keep … GROUP BY <las 6 columnas del hecho>) AS k)` —
`CAST` porque PG no tiene `MIN(uuid)`, y la tabla derivada `AS k` porque MySQL no deja leer la tabla que se borra
en el mismo DELETE. Sobrevive la fila más antigua (uuid v7 menor); si las dos filas de la carrera tenían
caducidades distintas, sobrevive la primera escrita, no la más larga — los dos son finales legales de esa
carrera y el README lo dice. Sin el de-duplicado el backfill chocaría contra el propio UNIQUE (medido en el
diseño: dos NULL → dos `''` de la misma tupla).

**Medida 1 (cambió el texto del README/CHANGELOG):** con la forma vieja, **las ESCRITURAS de holder del driver
nuevo las rechaza el trigger viejo**: el INSERT lleva `''` y `subject_partition` NULL, `IS NOT NULL` dispara.
Salida literal de la primera corrida (`relate` con caducidad sobre la fila NULL, los tres motores):
```
ℹ AuthorizationBackendError: El backend de autorización 'database-relations' no respondió (relate.insert)
… - authz_relations: un userset no puede pertenecer a otra partición que su tupla (subject_partition=<NULL>, partition_key=unit|…)
```
Es fail-closed y ruidoso (503 `E_AUTHZ_BACKEND_UNAVAILABLE` con el mensaje del trigger en la causa) y la
transacción interna del driver deshace el delete+insert (la fila vieja sigue). El caso lo FIJA (renovación y
holder nuevo rechazados antes de la receta; la misma renovación entra después con `''`) y el README/CHANGELOG
dicen que **la receta va en el MISMO despliegue que el paquete**, no «más tarde»: lecturas y borrados funcionan
mientras tanto, las escrituras de holder no.

**Medida 2 (reordenó la receta):** con el trigger al FINAL (mi primer borrador), **el backfill muere en el
`BEFORE UPDATE` viejo** (`IS NOT NULL` sobre `''`):
```
ℹ SqliteError: UPDATE authz_relations SET subject_relation = '' WHERE subject_relation IS NULL - authz_relations: un userset no puede pertenecer a otra partición que su tupla
ℹ error: UPDATE authz_relations SET subject_relation = '' WHERE subject_relation IS NULL - … (subject_partition=<NULL>, partition_key=unit|…)      ← PG
ℹ Error: UPDATE authz_relations SET subject_relation = '' WHERE subject_relation IS NULL - …                                                          ← MySQL
```
Por eso el trigger va PRIMERO en los tres bloques, y el README/CHANGELOG lo explican.

**Idempotente, medido:** el caso ejecuta la receta ENTERA una segunda vez: mismo esquema, mismo censo, el trigger
sigue rechazando el userset de otra partición.

## Pieza 5 · Los mutantes ✅ (aplicados con `sed`, restaurados por copia y verificados con `diff`; `git status` solo con mis cambios)

- **Mutante A — la columna vuelve a `nullable()` en el espejo y el driver escribe NULL para el holder**
  (`l4b-mutante-null-{pg,mysql}.log`): el caso flipado ROJO con el mismo mensaje de la pieza 1:
  ```
  ℹ AssertionError: ROJO: pg: el segundo relate del MISMO hecho de holder ENTRÓ (el UNIQUE no lo defiende); censo = 2 filas: expected true to equal undefined
  ```
  (ídem `mysql:`), más «NULL explícito lo RECHAZA el motor» rojo. Colateral honesto: 19 failed de 47 — al escribir
  NULL con la CTE `principal` partiendo de `''`, `check` deja de encontrar al holder; el mutante es más fuerte de
  lo necesario, pero el caso OBJETIVO está entre los rojos con su mensaje.
- **Mutante B — el trigger vuelve a `IS NOT NULL`** (`l4b-mutante-trigger-{sqlite,pg,mysql}.log`): el caso «un
  HOLDER (subject_relation = '' desde L-4b, o la columna OMITIDA …) NO lo mira el trigger» ROJO, y con él cada
  `relate` de holder del paquete (`relate.insert` rechazado por el trigger): 24/40 en sqlite, 30/47 en PG/MySQL.
  Es la demostración de que el cambio del trigger no es cosmético.

## Pieza 6 · Paridad y censo ✅

- `openfga` NO se toca (L-5): allí una tupla es única por construcción. El puente y el contrato de reconcile de
  relaciones corren en la suite completa (cifras abajo).
- `enumerateRelations` ya no puede emitir dos veces el mismo holder: lo fija el caso flipado (`×1`) y el caso de la
  receta (el duplicado viejo se emite ×2 HASTA la receta y ×1 después).

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, corridas en SECUENCIA a fichero; el `:8101` no expiró)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ · `npm run build` ✔
(`l4b-tsc.log`, `l4b-build.log`, exit 0).

| modo | base (L-4) | ahora | delta | log |
|---|---|---|---|---|
| `npm test` (SQLite memoria) | 1049 | **1053 passed (1053)** | +4 | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1070 | **1074 passed (1074)** | +4 | `suite-sqlite-file.log` |
| `npm run test:pg` | 1165 | **1169 passed (1169)** | +4 | `suite-pg.log` |
| `npm run test:mysql` | 1165 | **1169 passed (1169)** | +4 | `suite-mysql.log` |

+4 en los cuatro modos, todos aditivos: los dos casos de esquema del grupo del trigger de
`relations_database.spec.ts` (NULL explícito rechazado; el mismo holder dos veces rechazado por el UNIQUE), el
caso `L-4b` de `migration_stub.spec.ts` (el DEFAULT medido por motor) y el caso de la receta ejecutada de
`upgrade_recipe.spec.ts` (ahora también en SQLite). El caso concurrente del holder se FLIPA (±0). `openfga` y el
contrato de reconcile de relaciones siguen verdes dentro de esas cifras. Cero `skip`.

## Lo que NO hice

- No toqué `openfga` ni nada fuera del defecto.
- No hay `NULLS NOT DISTINCT`, ni índice parcial, ni columna generada (decisión del dueño: solo `NOT NULL DEFAULT ''`).
- No hay backfill automático desde el paquete: la migración de datos es del consumidor, con la receta ejecutada
  por la suite; el paquete tolera NULL en lectura pero NO sustituye el paso 4 (el trigger viejo rechaza las
  escrituras de holder hasta que se aplica).
- En SQLite no se recrea la tabla: la columna queda nullable tras la receta (medido como la ÚNICA diferencia) y la
  DDL de recreación se remite al stub.
- No cambié `subject_partition` de los holders (sigue NULL): la alternativa de materializarla también en el
  holder habría hecho transparente la ventana del trigger viejo, pero cambia el significado publicado de la
  columna y no era el encargo.
