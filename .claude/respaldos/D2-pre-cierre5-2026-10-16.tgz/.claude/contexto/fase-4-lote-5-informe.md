# Fase 4 · Lote 4-5 — frontera con dientes + carrera + `reconcile` de relaciones

> Base: `main` @ `07eb374` (4-4 mergeado). Árbol principal, SIN commits (los hace el dueño).
> Plan: `fase-4-juez.md` §4-5 + `fase-4-plan.md` §5 + informes 4-1…4-4.
> Alcance: F-01/F-02 con DIENTES (mutante de conflación) o degradados; F-03/F-04 verdes; la carrera
> `defineRelationsConfig`↔`syncAuthzCatalog`; 🟡3 (config de relaciones persistida bajo el gate de versión);
> el `reconcile` de relaciones con CENSO. Todo medido contra el `:8101`, pg18 y mysql84.

## Las 4 cifras (todas verdes, corridas a fichero, +33 aditivo)

| modo | antes (4-4) | ahora | delta |
|---|---|---|---|
| `npm test` (`:8101`) | 910 | **943** | +33 |
| `test:sqlite-file` (`:8101`) | 915 | **948** | +33 |
| `test:pg` (`:8101`) | 1009 | **1042** | +33 |
| `test:mysql` (`:8101`) | 1009 | **1042** | +33 |

`tsc` (ambos tsconfig), `typecheck`, `check:purity` y `build` limpios. `:8101` a **0 stores** al cerrar.
Desglose del +33: reconcile (20 = 11 doble en memoria + 9 database↔openfga real) + F-01/F-02 con dientes (2) +
F-01/F-02 documentación en database (1) + config persistida/🟡3 (6) + republish/carrera/409 (4 = 2 servidor + 2
stub). El flip de `enumerateRelations` (whenFalse→whenTrue) en los harnesses reales no cambia el conteo.

> **Nota del intermitente conocido (NO regresión de este lote):** en una de las corridas de `npm test` falló 1
> vez el test de profundidad del 4-1 (`facts · 4-1 — profundidad can_<P> … 500 reps`) por el borde
> PROBABILÍSTICO a 23 saltos (las 10 rondas resolvieron limpias, «la cota subió»); es el mismo flaky que 4-2 y
> 4-4 anotaron. Reiniciado el `:8101`, la corrida siguiente dio **943 (todas verdes)**. No toca profundidad
> este lote.

## F-01/F-02 · la frontera roles↔relations CON DIENTES (mutante de conflación, rojo literal)

**Anclados en `openfga` (store COMPARTIDO, donde SÍ hay riesgo real)** — `tests/relations_bridge.spec.ts`,
grupo «4-5 — la frontera roles↔relations CON DIENTES». En verde la frontera se sostiene por CONSTRUCCIÓN
(tipos disjuntos `scope`/`role_binding` ≠ `document`/`group`; relaciones disjuntas `can_<P>`/`assignee` ≠
`viewer`/`member`). El mutante de CONFLACIÓN —«que una mitad LEA las tuplas de la otra»— los pone ROJOS:

- **F-01** (una tupla `document#viewer` NO hace `roles.authorize` true). Mutante en `OpenFgaAuthorizationDriver.authorize`
  (roles LEE las tuplas de relaciones: `client.read({ user, object: 'document:' })` ⇒ true):
  ```
  ❯ … / F-01 · una tupla de relación (document#viewer) NO hace roles.authorize true
  ℹ AssertionError: F-01: una tupla document#viewer no puede conceder can_p0 (la mitad de relaciones NO
    alimenta roles): expected true to be false
  Tests  8 passed, 1 failed (9)
  ```
- **F-02** (un grant de rol NO crea una relación). Mutante en `OpenFgaRelationsDriver.check` (relaciones LEE
  las tuplas de roles: `client.read({ user, object: 'role_binding:' })` ⇒ true):
  ```
  ❯ … / F-02 · un grant de rol NO crea una relación (relations.check sigue false)
  ℹ AssertionError: F-02: un rol no crea una relación (la mitad de roles NO alimenta relaciones):
    expected true to be false
  Tests  8 passed, 1 failed (9)
  ```
Los dos mutantes se aplicaron al driver real, se vio el rojo literal y se RESTAURARON (`grep MUTANTE src/` = 0).

**Degradados a documentación EXPLÍCITA en `database`** (`tests/relations_database.spec.ts`, grupo «F-01/F-02
son decorativos»): los hechos de roles viven en `authz_assignments`/`authz_denies` y los de relaciones en
`authz_relations` —tablas DISJUNTAS—, así que la conflación es **estructuralmente imposible** y un caso
«relate ⇒ authorize false» sería FALSO-VERDE. Se afirma la separación estructural que sí se puede demostrar:
`un relate() de relaciones NO toca la tabla de roles` (deja su fila en `authz_relations` y CERO en
`authz_assignments`). No es una frontera con dientes: es la constancia de que aquí no hace falta.

## F-03/F-04 · confirmados verdes (sembrados en lotes previos)

- **F-03** (regla de pureza 2: `src/relations/` no importa `manager`/`drivers/*`): `check:purity` VERDE
  (`relations` en `KNOWN_MODULES`); fixture explícita en `tests/purity.spec.ts` (`--module relations`).
- **F-04** (colisión permiso↔relación): `tests/openfga_facts.spec.ts` grupo «⚪4 + F-04», 75 passed.

## `reconcile` de relaciones — idempotente, bidireccional, con la lección M1/M3/T4 (CENSO)

Piezas nuevas:
- **`enumerateRelations` REAL en los dos drivers** (capacidad `false`→`true`):
  - `database` (`database_relations_driver.ts`): enumera los hechos DIRECTOS de la partición desde
    `authz_relations`, paginados por la PK (`uuid`, cursor que AVANZA), sin filtrar ni derivar; barre las dos
    ortografías del uuid de partición (🟡2).
  - `openfga` (`openfga_relations_driver.ts`): lee el store ENTERO (`Read({})` —la única forma de ver todo sin
    filtro por user/objeto: un `Read` por tipo-solo sin user es un 400—) y devuelve SOLO las tuplas de relación
    de la partición (tipo `group` o declarado), descartando las de `facts`.
- **`reconcileRelations(...)`** (`src/relations/reconcile.ts`, módulo PURO de `relations/`): lee el ORIGEN por
  `enumerateRelations`, lee el DESTINO ENTERO (para ver lo que SOBRA), aplica `relate` de lo que falta y —con
  `--prune`— `unrelate` de lo sobrante; `--dry-run` reporta lo que HARÍA y la deriva del modelo fusionado
  (`modelDrift`: tipos del origen que la config del destino no declara). Un driver sin `enumerateRelations` ⇒
  500 `E_AUTHZ_UNSUPPORTED` (jamás una migración a ciegas).
- **`runRelationsReconcileContract`** (`src/testing/relations_reconcile_contract.ts`, publicado en `/testing`):
  el juez con **CENSO**. Siembra FIJA (6 hechos: holders directos, includes `editor⊆viewer`, userset directo y
  **userset ANIDADO** `g1#member` de `g2`), migra, y busca CADA hecho en el destino UNO A UNO por
  `listSubjects` DIRECTO —no cruza `report.skipped`, no le pregunta al origen lleno—. Bidireccional (A→B y
  B→A). Corre con doble↔doble (sin servidor) y database↔openfga (contra el `:8101`).

**El rojo del CENSO (lección M1/M3/T4)** — mutante omisivo en `reconcileRelations` (tira los usersets al
escribir), corrido contra el `:8101`: el CONTADOR queda limpio pero el CENSO caza la pérdida, en los DOS
destinos (database y openfga):
```
❯ relations reconcile [doble en memoria] / A→B · migra los 6 hechos y el CENSO los ve todos en el destino
ℹ AssertionError: CENSO: falta el hecho 'userset ANIDADO g1#member de g2' en el destino
  (group:…#member@group:…#member); listSubjects devolvió [vacío]: expected false to be true
```
Restaurado. (Además, un caso propio en `relations_reconcile.spec.ts` demuestra en verde que un origen omisivo
migra con `written` limpio y el censo lo caza — la lección fijada como test permanente.)

## La CARRERA `defineRelationsConfig`↔`syncAuthzCatalog` (contra el `:8101`)

`tests/relations_republish.spec.ts`. **El diseño**: el gate de versión (invariante 14,
`withAuthzCatalogWrite` bloquea la fila de versión) SERIALIZA las escrituras SQL de las dos operaciones —ese es
su propósito, no se pisan—. Lo que SÍ compite por el `modelId` es la REPUBLICACIÓN del modelo fusionado (fuera
de la transacción SQL: no hay 2PC entre la fila y FGA). `republishFusedModel` (`src/relations_config_store.ts`)
lo resuelve leyendo SIEMPRE las **dos mitades persistidas** (permisos del catálogo + tipos de relación de
`authz_relations_config`), así que el modelo publicado NUNCA está mutilado, y fija el `model_id` con un **CAS
con reintento acotado**.

- **AC verde** (`carrera · … el modelo final resuelve can_p0 Y document`): tras dos `republishFusedModel`
  concurrentes, el `model_id` PINADO es consistente, su modelo DECLARA `document`, y sobre él `authorize(p0)`
  sigue true (la mitad de roles) y `relations.check(document#viewer)` resuelve (la mitad de ReBAC). Ninguna
  proyección se pierde. Cualquier rechazo de la contención es 409 (allSettled lo tolera, exige ≥1 ganador).
- **El 409 de la contención que no cede** (`el 409 de la contención que no cede`, stub sin servidor): con el
  CAS forzado a no ganar nunca, `republishFusedModel` reintenta `MAX_PIN_RETRIES` y sale con **409
  `E_AUTHZ_WRITE_CONFLICT`** (nunca un modelo a medias), y el que gana a la primera no reintenta.

## 🟡3 · config de relaciones PERSISTIDA y bajo el gate de versión (invariante 14)

**Tabla nueva `authz_relations_config`** (fila `id=1`: `spec` JSON + `model_id` + `updated_at`), añadida al
`stubs/migration.stub`, al espejo `tests/helpers/schema.ts` (+`AUTHZ_TABLES`, +`cleanAuthzTables`) y a la lista
del `migration_stub.spec.ts` (siete→ocho tablas). El K11 stub↔espejo y las FKs siguen verdes en PG/MySQL; la
receta 1.x→2.x (`upgrade_recipe.spec.ts`) excluye la tabla nueva (como ya excluía `authz_relations`).

**`src/relations_config_store.ts`** (API de PLATAFORMA, exportada por `index.ts`): `saveRelationsConfig(spec)`
valida (⚪4/F-05) y hace UPSERT bajo `withAuthzCatalogWrite` —**sube la versión compartida** (invariante 14: un
sync en otro proceso la ve en su siguiente pregunta)—; `readRelationsConfig()` la recupera VALIDADA. El driver
`openfga` estrena `republishFusedModel(relationsConfig?)`: mide el modelo fusionado (`assertFactsModelPublishable`,
gate del 4-1) y publica permisos del catálogo + los tipos de relación que recibe.

**AC verde + rojo** (`tests/relations_republish.spec.ts`, `tests/relations_persisted_config.spec.ts`):
- Persistencia + invariante 14: `saveRelationsConfig` sube la versión; un proceso SIN `defineRelationsConfig`
  en memoria recupera los tipos de la BASE; una config inválida no ensucia la tabla (5 motores).
- 🟡3 contra el `:8101`: republicar SIN config en memoria conserva `document` (lo lee de la base); el CONTRASTE
  —republicar solo la mitad de roles (`republishFusedModel(undefined)`)— deja caer `document` («modelo de uno,
  tuplas de otro»), que es justo lo que 🟡3 evita.
- **Rojo literal** — mutante en `republishFusedModel` (NO lee la config persistida): tanto 🟡3 como la carrera
  se ponen rojos contra el `:8101`:
  ```
  ❯ … / 🟡3 · republicar SIN defineRelationsConfig en memoria conserva los tipos de relación (los lee de la base)
  ℹ AssertionError: leyó los tipos de la base: expected [] to include 'document'
  ❯ … / carrera · … el modelo final resuelve can_p0 Y document (nada se pierde)
  ℹ AssertionError: el modelo pinado declara document: expected false to be true
  ```
  Restaurado.

## Decisiones de diseño / notas

- **La carrera compite por el MODELO, no por el catálogo SQL.** El gate de versión (invariante 14) serializa
  las escrituras SQL de `syncAuthzCatalog` y `saveRelationsConfig` —así que en `database` no hay carrera SQL
  destructiva (y meterlas concurrentes en el mismo Promise.all las hacía chocar en SQLite con 503, no era el
  fenómeno bajo prueba)—. Lo que carece de 2PC con FGA es la republicación del modelo; ahí vive la
  competencia por el `modelId`, y el CAS + las dos-mitades-persistidas la cierran.
- **`reconcile` de relaciones es POR partición** (mono-tenant: `APP_SCOPE`). El puerto ya tenía
  `enumerateRelations(partition, page?)`; no se tocó su firma. Migrar todas las particiones es iterar por el
  consumidor (una migración de tenant es un caso natural).
- **El wiring del republish en `syncAuthzCatalog`/`openfga:provision`** no se embebe en las internals del sync
  (que es la ruta solo-database y no puede tirar del SDK): la republicación es un PASO de plataforma que ambas
  operaciones invocan (`republishFusedModel`), leyendo las dos mitades de la base. Es el mismo patrón que
  `manager.reconcile` (destino por clave) y `manager.driver()` (salida de plataforma).

## Lo que NO se hizo (queda 4-6)

- **Anexo (R-14 `membersOf` con su par, R-15 caducidad de relación si el dueño la mete en 2.4), el conteo
  LITERAL del juez en `relations_harness.spec.ts` (aserción por cara de capacidad + `assert.throws` de «true
  sin soporte»), las tablas ficticias del consumidor, README honesto (presupuesto compartido, partición, F-05
  como chokepoint, la config persistida y el republish) y CHANGELOG 2.4.** Todo es 4-6.
- **Comando `authz:reconcile` de relaciones (CLI).** Se entregó la pieza de plataforma (`reconcileRelations`)
  con su contrato y su censo; envolverla en un comando `ace` con banderas (`--to`/`--from`/`--dry-run`/`--prune`)
  es cierre de 4-6, junto con el resto de la superficie de comandos.
- **`--dry-run` del reconcile: `modelDrift` compara contra la config del destino EN MEMORIA** (el `toConfig`
  que se le pasa). Vigilar la deriva contra la config PERSISTIDA del destino (leerla de su
  `authz_relations_config`) es trivial —`readRelationsConfig` ya existe— y encaja en el comando de 4-6.

Nada del plan resultó imposible ni contradijo el código. La única desviación de forma (no de fondo) es la de la
carrera: el AC hablaba de «los dos republican el modelo y compiten por el modelId»; la implementación separa la
persistencia SQL (serializada por el gate, invariante 14) de la republicación del modelo (la que de verdad
compite), porque forzar la concurrencia de los dos `syncAuthzCatalog`/`saveRelationsConfig` en SQL era chocar
contra el propio gate (503 de SQLite), no medir la competencia por el `modelId`. El AC —modelId consistente,
ninguna proyección perdida, contención que no cede ⇒ 409— queda cubierto y medido contra el `:8101`.
