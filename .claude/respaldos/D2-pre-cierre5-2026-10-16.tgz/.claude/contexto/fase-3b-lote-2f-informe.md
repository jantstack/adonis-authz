# Fase 3B · lote 2f — R3: el `grant` de (c2) es UNA escritura atómica

**Rama** `v2/fase-3b` · **base** `272e9e7` (lote 2e) · árbol principal, **sin commits**.
**Alcance:** SOLO la raíz **R3** del informe del 2e. R1 (el nivel del rol en (c2)) y R2 (el árbol
del store decide sin la cadena del consumidor) **no se han tocado**: siguen pendientes de decisión
del dueño y sus casos siguen rojos a propósito.

---

## El recuento del juez, antes y después

`AUTHZ_CONTRACT_FACTS=1 OPENFGA_TEST_URL=http://localhost:8101 npm test`

| | Antes (2e) | Después (2f) |
|---|---|---|
| SQLite + árbol en memoria | **742 passed, 5 failed (747)** | **748 passed, 3 failed (751)** |
| PostgreSQL (árbol SQL) | 916 passed, 5 failed (921) | **921 passed, 4 failed (925)** |

**Los cinco rojos de antes, nombrados, y qué son ahora:**

| # | Caso del juez | Raíz | Antes | Ahora |
|---|---|---|---|---|
| 1 | `authorizeMany: … un scope que lanza ⇒ lanza entero` | **R2** | rojo | **rojo** (no se toca) |
| 2 | `dos grant concurrentes … (o falla con 409, nunca con 500/503)` | **R3** | rojo | **VERDE** |
| 3 | `purgeScope concurrente con grant … nunca un estado a medias` | **R3** | rojo | **VERDE** |
| 4 | `paridad entre drivers (3D · N1): … otro nivel no cuenta …` | **R1** | rojo | **rojo** (no se toca) |
| 5 | `scopes.detached purga los HECHOS del scope y SOLO los hechos …` | **R2** | rojo | **rojo** (no se toca) |
| 6 | `un alias del uuid del scope … jamás evade un deny` (solo árbol SQL) | **R2** | rojo | **rojo** (no se toca) |

**Exactamente los dos de R3 menos, y ni uno de R1/R2 tocado.** Ninguno de los rojos que el 2e
atribuyó a R3 resultó ser en realidad de R1/R2: los dos eran el mismo bug del driver y los dos se
han puesto verdes.

Los dos casos de R3 son **carreras**, así que se repitieron aislados para descartar un verde por
suerte: el nº 2, **3 de 3** verdes; el nº 3, **5 de 5** verdes (6 rondas cada ejecución).

---

## Lo que estaba mal, medido

### El síntoma nº 2 — el 503 salía del write de las aristas, no del `assignee`

Salida ROJA literal (SQLite, ronda 0):

```
❯ authorization contract [openfga facts · 2.2] / dos grant concurrentes con caducidades distintas ⇒ UNA sola asignación y la caducidad final es una de las dos; ninguno falla (o falla con 409, nunca con 500/503)

- Expected  - 1
+ Received  + 1

- 409
+ 503

ℹ AssertionError: ronda 0: El backend de autorización 'openfga' no respondió (writeTuples): expected 503 to equal 409
 ⁃ at Object.executor (src/testing/contract.ts:2181:20)
```

**La causa, instrumentando el error del SDK antes de clasificarlo** (parche temporal en
`guardBackendErrors`, ya revertido) — el servidor real, OpenFGA v1.19:

```
[DEBUG_FGA] writeTuples {"status":409,
 "apiErrorMessage":"transactional write failed due to conflict: one or more tuples to write were inserted by another transaction",
 "name":"FgaApiError","responseData":{"code":"Aborted", …}}
[DEBUG_FGA] writeTuples {"status":400,"apiErrorCode":"write_failed_due_to_invalid_input",
 "apiErrorMessage":"cannot write a tuple which already exists: user: 'user:01a054e1-…', relation: 'assignee', object: 'role_binding:app|01a054e1-…'", …}
```

Dos hallazgos:

1. **El 409 de FGA tiene nombre propio**: es el `Aborted` de un `Write` transaccional cuyas tuplas
   escribió otra transacción a la vez. `isDuplicateWrite` ya lo daba por bueno (`statusCode === 409`),
   pero su docblock lo describía como una hipótesis («un 409 se acepta por si una versión del
   servidor lo devuelve así»). Ahora está medido y escrito.
2. **El 503 no salía del `assignee`**: salía del `writeTuples` de las DOS aristas, que el 2c mandaba
   en un request aparte **sin `try/catch`**. `onDuplicateWrites: Ignore` cubre el duplicado, pero no
   el conflicto transaccional; el camino del 409 (releer y re-aplicar, D6) solo protegía al
   `assignee`. Por eso el conflicto en las aristas salía como caída del backend.

### El síntoma nº 3 — el `assignee` sobrevivía a su arista

Salida ROJA literal (SQLite, ronda 0):

```
❯ authorization contract [openfga facts · 2.2] / purgeScope concurrente con grant en el mismo scope ⇒ nunca un estado a medias: o la asignación está entera y concede, o no está; y la purga siguiente demuestra cero

- Expected  - 1
+ Received  + 1

- true
+ false

ℹ AssertionError: ronda 0: authorize coherente: expected false to equal true
 ⁃ at Object.executor (src/testing/contract.ts:2231:16)
```

`listRoles`/`hasRole` decían que la asignación existe y `authorize` decía que no concede.

**El estado final exacto, volcado del servidor real** (parche temporal en el caso del juez, ya
revertido) tras arreglar SOLO la atomicidad del `grant`:

```
DEBUG_RACE {
 "present": true,
 "purge": "purgeScope organization|01a054ec-…: quedan tuplas tras el borrado — role_binding:…(1); scope:…(1)",
 "scope": ["scope:app#parent@scope:organization|01a054ec-…",
           "role_binding:organization|01a054ec-…|01a054ec-…#binding@scope:organization|01a054ec-…"],
 "bindings": ["user:01a054ec-…#assignee@role_binding:organization|01a054ec-…|01a054ec-…"]
}
```

Está el `assignee`, está `scope#binding`… y **falta `role_binding#role`**. Es decir: la atomicidad
del `grant` era necesaria pero **no suficiente**. La segunda mitad del bug estaba en el ORDEN de
`purgeScope`: leía-y-borraba objeto a objeto, y el objeto `role_binding` lleva juntos el `assignee`
(hecho) y la arista `#role` (estructura). El entrelazado que lo producía:

```
t0  purga: lee las aristas del scope
t1  grant: relee la asignación → present
t2  grant: delete del assignee (el replace de una caducidad que cambia)
t3  purga: borra scope#binding
t4  purga: lee role_binding → ve SOLO #role (el assignee ya no está)
t5  grant: write [#role, #binding, assignee]  ← las tres, atómico
t6  purga: borra lo que leyó en t4 → se lleva #role
    ⇒ assignee + #binding vivos, #role muerto ⇒ enumerado y sin conceder
```

---

## El código que lo puso verde

Todo en `src/drivers/openfga_driver.ts` (más el error nuevo en `src/errors.ts` e `index.ts`).

### 1. Las TRES tuplas en UN `Write` (`grant`)

Desaparece el `writeTuples` suelto de las aristas. En su lugar:

```ts
const structure = this.hierarchy === 'facts' ? factsBindingTuples(scopeKey(target), roleUuid) : []
/** El write COMPLETO de una asignación: su estructura y ella. */
const writeSet = (tuple: any) => [...structure, tuple]
```

y `writeSet(...)` es lo que viaja en **todos** los caminos de escritura del `grant`: el primer write,
`writeAssignment` y el write de `replaceAssignment` (el `delete` sigue siendo una llamada aparte
porque FGA no admite delete+write de la misma tuple key en una transacción; el estado intermedio —
sin `assignee` y con aristas— es coherente).

### 2. El choque se resuelve con la RELECTURA, y nunca es un 503

El camino `absent` es ahora un bucle acotado:

```ts
for (let attempt = 0; ; attempt++) {
  try {
    await this.client.writeTuples(
      writeSet(tupleFor(expiresAt)),
      attempt === 0 ? undefined : IGNORE_DUPLICATE_WRITES
    )
    return { existed: false, expiresAt }
  } catch (error) {
    if (!isDuplicateWrite(error)) throw error
    if (attempt >= GRANT_WRITE_ATTEMPTS - 1) throw new WriteConflictError(…, { cause: error })
    const raced = await this.readAssignment(key)
    if (raced.kind === 'present') { /* gana el último escritor: resolveGrantExpiry + replace */ }
    if (raced.kind === 'unknown' || !structure.length) { /* D6 tal cual: receta { expiresAt: null } */ }
    // `absent` con estructura: el choque fue de las aristas. Otra vuelta, dándolas por buenas.
  }
}
```

Tres decisiones, escritas también en el código:

- **Quién chocó lo dice la relectura, no el error**: el `Aborted` de FGA no nombra ninguna tupla.
- **`!structure.length` conserva D6 intacto en modo `resolver`**: ahí el `assignee` es la única tupla
  del write, así que un duplicado con relectura vacía sigue siendo inexplicable y sigue siendo el 503
  con la receta. (Sin esa guarda rompía los dos casos de `openfga — la carrera de grant solo es
  carrera con un duplicado (D6)`; con ella pasan sin tocarlos.)
- **Una contención que no cede en 3 vueltas es 409 `E_AUTHZ_WRITE_CONFLICT`** (clase nueva,
  exportada en `index.ts`, documentada en el README), nunca un 503: el backend respondió.

El límite honesto queda escrito en el código: si entre la relectura y el write con `Ignore` un
tercero escribe la asignación, la suya se queda y esta se pierde en silencio — FGA no tiene
compare-and-set, y es la misma ventana que ya tenía el `replace`, estrechada a dos llamadas seguidas.

### 3. `purgeScope` borra en `facts` con un orden fijo

```ts
//  1. la ESTRUCTURA (`role_binding#role` y `scope#binding`): deterministas
//     (`factsBindingTuples(key, rol)`), se borran a CIEGAS ⇒ 0 lecturas.
//  2. los HECHOS (`assignee`), releyendo cada objeto.
//  3. los `denied_<P>` del scope, los ÚLTIMOS.
await deleteKeys(roles.flatMap((r: any) => factsBindingTuples(key, r.uuid)))
for (const object of objects) { if (object === scopeObject) continue
  await deleteKeys((await purgeable(object)).filter((k) => !isStructure(k))) }
await deleteKeys((await purgeable(scopeObject)).filter((k) => k.relation.startsWith(FACTS_DENIED_PREFIX)))
```

Por qué ese orden y no otro (razonado en el comentario del método):

- Con el `grant` atómico, **ningún hueco** deja un `assignee` sin aristas: el grant que aterriza
  antes de (2) pierde su asignación ahí (cero, coherente) y el que aterriza después se queda ENTERO
  con las aristas que él mismo escribió (concede, coherente).
- **Los denies, los últimos**: una purga que muere a medias tiene que dejar denies de MÁS, nunca de
  menos (invariante 2). Entre (1) y (3) lo que queda del scope es inerte, no permisivo.
- **(2) y (3) borran SOLO lo suyo**: una arista que un grant concurrente reescribió no se toca
  —sería volver a huerfanar su asignación—; queda como residuo, y el residuo es exactamente lo que la
  demostración de cero reporta (500 `E_AUTHZ_PURGE_INCOMPLETE`, que el caso del juez ya tolera).
- **La arista `parent` sigue sin tocarse** (S6, cruce 9) y el modo `resolver` conserva su bucle de
  siempre (una lectura + un borrado por objeto): ni una lectura de más.

**Coste:** las lecturas de la purga no cambian (la fase 1 no lee: las dos aristas son deterministas).

---

## Los casos nuevos, y el rojo de cada uno

Grupo nuevo en `tests/openfga_facts.spec.ts`:
**`facts · 3b-2f · R3 — el grant es UN solo Write atómico`** (4 casos, el doble en memoria de
`factsDriver()`, que es el que cuenta requests; la semántica de la carrera la demuestran los dos
casos del juez contra el servidor real de `:8101`).

1. **`un grant nuevo son las TRES tuplas en UNA sola escritura`** — ROJO antes de tocar el driver:

```
ℹ AssertionError: una sola escritura: writeTuples, writeTuples: expected [ { kind: 'writeTuples', …(2) }, …(1) ] to have a length of 1 but got 2
```

2. **`cambiar la caducidad es delete + write, y el write LLEVA las aristas`** — ROJO antes:

```
  Array [
+   "writeTuples",
    "deleteTuples",
    "writeTuples",
  ]
ℹ AssertionError: expected [ 'writeTuples', 'deleteTuples', …(1) ] to deeply equal [ 'deleteTuples', 'writeTuples' ]
```

3. **`un segundo holder en el mismo scope: las aristas ya estaban y el choque NO es un 503`** — este
   **pasaba ya** antes de implementar (el 2c mandaba las aristas con `Ignore` en su propio write), así
   que se provocó el rojo con un **mutante** (`attempt === 0 ? undefined : IGNORE_DUPLICATE_WRITES`
   → `undefined`, es decir «nunca doy por buenas las aristas que ya estaban»):

```
ℹ WriteConflictError: grant: 3 intentos y el store sigue en conflicto sobre role_binding:organization|…. Reintenta la escritura.
 ⁃ at OpenFgaAuthorizationDriver.grant (src/drivers/openfga_driver.ts:1364:17)
```

   Mutante revertido; el caso vuelve a verde. Es el caso que defiende el camino MÁS común que hay
   (un segundo asignado del mismo rol en el mismo scope) de convertirse en un 503.

4. **`purgeScope borra la ESTRUCTURA primero, los assignee después y los denied_<P> al final`** —
   también verde de nacimiento contra el código ya arreglado, así que **mutante** (restaurar el orden
   del 2e: los hechos primero, la estructura al final):

```
  Array [
-   "deleteTuples:binding+role",
-   "deleteTuples:assignee",
-   "deleteTuples:denied_docs_read",
+   "deleteTuples:assignee+role",
+   "deleteTuples:binding+denied_docs_read",
  ]
```

   Mutante revertido. (El orden ya estaba demostrado por el caso nº 3 del juez, que quedó ROJO con el
   `grant` atómico y SIN el reorden — ver la tabla de abajo —; este caso lo fija en un test rápido y
   determinista para que un refactor no lo deshaga.)

### Rojo→verde por pieza (las dos piezas se midieron por separado)

| Estado del árbol | `dos grant concurrentes` | `purgeScope concurrente` | Suite `facts` |
|---|---|---|---|
| 2e (base) | rojo (503) | rojo (incoherente) | 742/5 |
| + `grant` atómico y 409 | **verde** | rojo (incoherente: falta `#role`) | 744/6 * |
| + orden de `purgeScope` | **verde** | **verde** | 748/3 |

\* los 6 de esa fila incluyen los 2 casos de D6 que la primera versión rompía en modo `resolver`; se
arreglaron con la guarda `!structure.length` **sin tocar esos tests**.

---

## Verificación

```
npx tsc --noEmit -p tsconfig.json    ✓ (sin salida)
npm run typecheck                    ✓
npm run check:purity                 ✓ el paquete no depende de ningún proyecto consumidor
npm run build                        ✓
```

| Suite | Antes (3b-2e) | Después (3b-2f) |
|---|---|---|
| `npm test` (SQLite memoria + OpenFGA) | 660 | **664** |
| `npm run test:sqlite-file` | 662 | **666** |
| `npm run test:pg` | 834 | **838** |
| `npm run test:mysql` | 834 | **838** |

**+4 / +4 / +4 / +4** (los cuatro casos del grupo nuevo), **ni un caso existente en rojo** y sin
`skip` en ninguna parte.

**No quedan stores huérfanos en el `:8101`**: 0 stores creados en la fecha de este lote tras todas
las ejecuciones (el servidor conserva 58 de días anteriores, ajenos a este lote).

---

## Documentación tocada

- **`CLAUDE.md`** — invariante 6 (*Escrituras idempotentes*): «**y una escritura es UNA escritura**»
  — las tres tuplas del `grant` en `facts` en el mismo `Write`, el orden fijo de `purgeScope`, y el
  choque de dos escrituras como 409 `E_AUTHZ_WRITE_CONFLICT` y nunca como 503. Nada más: R1 y R2 no
  se documentan porque no se han decidido.
- **`README.md`** — fila nueva en la tabla de errores (`E_AUTHZ_WRITE_CONFLICT`, 409).
- **`CHANGELOG.md`** — «Lot 3b-2f», con las tres piezas y la nota de que las otras dos raíces siguen
  abiertas.
- **`src/drivers/openfga_driver.ts`** — el docblock de `isDuplicateWrite` ya no dice «un 409 se acepta
  por si una versión del servidor lo devuelve así»: dice qué ES el 409, medido contra el servidor.

---

## Lo que NO hice, y por qué

1. **R1 y R2, intactas.** Piden decisión del dueño (la del nivel del rol cambia el significado de la
   arista `scope#binding`; la del árbol del store toca `authorize`, `authorizeMany` y la canonización
   del uuid). Sus tres casos siguen rojos **a propósito** y el harness sigue registrándose solo con
   `AUTHZ_CONTRACT_FACTS=1`.
2. **No toqué `revoke`.** Las aristas son estructura compartida por todos los holders del mismo rol en
   el mismo scope: `revoke` sigue llevándose solo el `assignee` y dejando el enlace inerte (2c).
3. **No metí el `delete` de `replaceAssignment` en el `Write`**: FGA no admite delete+write de la misma
   tuple key en una transacción. El estado intermedio (sin `assignee`, con aristas) es coherente:
   `listRoles` y `authorize` dicen las dos que no.
4. **No añadí reintentos genéricos al resto de escrituras** (`revoke`/`deny`/`removeDeny`/proyección).
   Un `Aborted` ahí sigue saliendo como 503. Es la misma familia de problema, pero no es R3 y no tiene
   ningún caso del juez que lo pida: convertirlo entero sería un lote, no un arreglo.
