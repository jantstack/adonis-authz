# Lote B — cierre 1: decisiones del coordinador sobre `loteB-auditor.md` (2026-10-15)

Verificación PROPIA del coordinador sobre el árbol del implementador (gana sobre el informe): build/typecheck/purity ok;
**1698 / 1726 / 1823 / 1825** (2/2/1/1 skipped); guard-mutants **111/111**; flag-mutants 36/36; runbook VERDE sqlite-file y pg.
Cuadra con §5 del informe. Auditor: APTA con cambios, 0 🔴, 2 🟠, 6 🟡, 6 ⚪. Todo lo de abajo ENTRA en este cierre salvo lo marcado.

## Respuestas a las dos preguntas del auditor
1. **Residuo B3 del lado DESTINO en `--prune`: a `details` con `pruned: false` y la receta; NUNCA un throw, NUNCA un DELETE por
   vía de plataforma.** Es la misma regla que el coordinador fijó en el lote A para toda tupla del destino fuera de gramática
   («se listan, exit ≠ 0, se borran a mano»; roadmap 2.6 como decisión de contrato). Una regla, no dos.
2. **Decisión 4 RECHAZADA** (como pide el auditor). `RelationUsersetUnsupportedError` deja de heredar de `RelationUnknownError`;
   `relateOrSkip` NO la traga; el residuo se clasifica en el PLAN (`planPartition`, `assertUsersetSubject` sobre `tuple.subject`,
   con o sin `toConfig`) con contador propio (`skipped.invalid` o `skipped['userset-unsupported']`, decidir y escribir) y entrada
   en `details` (`side: 'origen'`, `reason: 'userset-unsupported'`, receta). Mismos números en `--dry-run` y real. Es la dirección
   de R2-5 (lote D): el plan clasifica, el driver no absorbe.

## Lo que entra (por hallazgo)
| # | Qué exige el cierre | Nota del coordinador |
|---|---|---|
| 🟠 1 | Residuo del destino en `--prune` ⇒ `extra` + `details` (`side: 'destino'`, `reason: 'userset-unsupported'`, `pruned: false`, receta); exit ≠ 0 con la línea del residuo; cero throw, cero escritura parcial. Caso `--prune` hacia `database` con residuo sembrado por SQL (los 3 motores). Letra §Upgrading punto 6 corregida. | Tabla de verdad: {origen, destino} × {dry-run, real} × {prune, sin prune} ⇒ bucket, `details`, exit, línea. |
| 🟠 2 | Clasificación en el plan (arriba). Caso dry/real/dry2 con línea de letra, y `clean` del verificador: **un residuo del origen NO deja el verificador rojo para siempre sin decir la causa**: la línea nombra el residuo, el lado y la receta. | Decidir si `clean=false` con residuo listado es correcto (sí: hay algo que hacer a mano) pero la LETRA tiene que decir qué. |
| 🟡 3 | Letra del 500 de B6: «`{ transaction }` por el manager exige pool ≥ 2; con pool max 1 (default de knex en TODO SQLite) usa `requireTransaction: false`». README §Upgrading 9 y párrafo de `requireTransaction` con «pool max 1», no `:memory:`. Caso de letra. | Si es barato, detectar el pool 1 al construir la outbox sobre SQLite y dar el 500 con esa letra ANTES del 503 (medir; si no, solo letra). |
| 🟡 4 | `#listObjectsPage`: `!Array.isArray(response?.objects)` ⇒ 503, mutante en la columna `truncation`. **Roles: el mismo `Array.isArray` en las TRES lecturas** (`:3285`, `:3400`, `:3493`) con caso (una respuesta `{}` ⇒ 503, y `purgeScope` no «demuestra» cero con ella). Línea (a) de B4 reescrita con la verdad. | Es la propiedad universal de M8 («toda enumeración que se puede cortar devuelve `truncated` o lanza») aplicada al gemelo de roles: entra, no se aplaza. |
| 🟡 5 | B3 en el runner PUBLICADO (`src/testing/relations_contract.ts`): manager y driver directo ⇒ 422 con el `code` y cero llamadas en `relate`/`check`/`listObjects`/`purgeSubject`; recuento de casos actualizado; §Upgrading punto 2 (D13). | |
| 🟡 6 | Punto de paso único en roles: la validación de claves también en el constructor de `AuthorizationManager` (o en el provider: elegir el que cubra `new AuthorizationManager(cfg)` Y el provider) + caso. **Entrada en la guardia: guardia de TIPO en compilación**, no prosa: `const _exhaustive: Record<Exclude<keyof AuthorizationConfig, KnownRootKey>, never> = {}` (y por nivel: `scopes`, `hooks`, `openfga`, `relations`; en relaciones: raíz de la spec, `objectTypes[i]`, `relations[j]`, `database`). Un campo nuevo del tipo sin entrar en la lista blanca ROMPE `typecheck`. Es la reflexión sobre tipos que §6 decía que no existía. | Sin exención: no hace falta firma del dueño. |
| 🟡 7 | Config persistida pre-2.5 que ya no valida (clave desconocida o ciclo): línea PROPIA y exit propio en `authz:relations:reconcile` («la config persistida en `authz_relations_config` NO valida en 2.5: <motivo>; re-guárdala con `saveRelationsConfig(defineRelationsConfig(...))` o `openfga:provision`»), distinta de «la lectura falló». §Upgrading con el paso. Caso por el kernel con fila sembrada. | Tabla B5 pasa a 4 filas: leída / null / no valida / lectura falla. |
| 🟡 8 | README: qué hacer con `--listObjects-deadline=0` (aceptar `listObjectsDeadlineMs: Infinity` ⇒ solo señal por tope; caso) y una línea en «Third-party drivers»: el runner no juzga el deadline. | Verificar en la referencia oficial de OpenFGA (`openfga run --help` del contenedor `:8090`: `docker exec openfga-dev openfga run --help \| grep -i deadline`) si 0 desactiva; escribir lo medido. |
| ⚪ 9 | `monotonic` fuera del tipo publicado (opción interna por símbolo o segundo parámetro de test). | |
| ⚪ 10 | Guardia por fuente: un solo `client.listObjects` y dentro de `#listObjectsPage` (patrón C5). | |
| ⚪ 11 | Letra de `purgeObject` en B3 precisada (es el objeto de la TUPLA; se lleva sus comparticiones legítimas) o quitada. | |
| ⚪ 12 | **Receta SQL de B3 ejecutada en `upgrade_recipe.spec` en los 3 motores** (condición del coordinador aunque 🟠 1/2 se cierren: una receta no ejecutada es letra sin efecto, L8). | |
| ⚪ 13 | `database: true` (valor no objeto en clave conocida) ⇒ 422, no silencio (es L5). `includes: {}` ⇒ 422, no TypeError. `saveRelationsConfig(configYaDefinida)` ⇒ 422 con pista «parece una config ya definida; pasa la spec». | |
| ⚪ 14 | Frase del precio en «Limits»: con el default (3 000 ms) toda `ListObjects` ≥ 2 700 ms sale `truncated`; quien lo trate como 503 paga ese p99. | |

## Decisiones §4 ratificadas por el coordinador
1, 3 (con 🟡 5), 6 (con letra), 7 (con ⚪ 9), 8 (con letra), 9 (con 🟡 4), 10, 11, 12, 13: ratificadas. 2: condicionada (🟡 6).
**4: rechazada.** 5: condicionada (⚪ 12 obligatoria). 14: la hace el coordinador al cerrar.

## Reglas del cierre
Mismo método (rojo → verde → mutante), cuatro líneas de cierre para 🟠 1 y 🟠 2 (y 🟡 4 por el gemelo de roles), CHANGELOG
`[Unreleased]` ampliado, README §Upgrading corregido. Verificación final 4 modos + 3 gates. Informe: `loteB-informe-cierre.md`
(§ por hallazgo: qué se hizo, caso, mutante, rojo observado; tabla de verdad del reconcile con residuo; cifras; lo no hecho).
