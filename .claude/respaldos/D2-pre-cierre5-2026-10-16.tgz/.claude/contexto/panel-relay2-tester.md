# Panel relay 2 — TESTER (verificabilidad)

`@jantstack/adonis-authz` `2.4.0-alpha.7`, `main`, commit `13ba731`, árbol limpio.
Informe de entrada: `.claude/contexto/cognitiv-informe-2026-09-10.md` (3 bloqueantes + 7 menores).
Informe anterior mío: `panel-relay-tester.md`.

**No he tocado `src/`, `commands/` ni `tests/`.** Los prototipos y el árbol mutado viven en el
scratchpad de la sesión (`/tmp/claude-1000/-home-jose/66ad04a0-.../scratchpad/`): `r2_lib.ts` (patrón
`spyDriver`/`memoryQueue`/`managerWith` copiado de `tests/scope_outbox.spec.ts:204-260,1520`),
`r2_rojo1.ts`, `r2_rojo3.ts`, `r2_rojo4.ts`, y `mut1/` (copia completa del paquete con `node_modules`
enlazado, para correr mutantes sin tocar el repo).

---

## 0 · El hallazgo del lote, medido antes que nada

**La raíz `app` como clave de bloqueo NO es observable por la suite de hoy.**

Apliqué en `mut1/` el cambio 1 completo (exención de la raíz en los TRES sitios: `#changeKeys`,
`#dependencyOf` y `requeueScopeChanges`) y corrí la suite entera:

```
$ node --import @poppinss/ts-exec bin/test.ts --files="scope_outbox"
[suite] motor SQL: sqlite (:memory:)
 PASSED
Tests  100 passed (100)

$ node --import @poppinss/ts-exec bin/test.ts        # suite completa
[suite] motor SQL: sqlite (:memory:)
 PASSED
Tests  1026 passed (1026)
 Time  12s
```

Control, mutante «exentar TODAS las claves» (`#changeKeys` ⇒ `[]`):

```
Tests  82 passed, 18 failed (100)      # tests/scope_outbox.spec.ts
```

Lectura, y es la que ordena todo el informe:

- el mecanismo de contaminación por clave **sí** está cubierto (18 rojos con el mutante total);
- **la raíz como clave no lo está: cero casos existentes mueren.** No hay nada que «desdoblar» —hay
  que **añadir**—, y peor: el cambio 1 se puede implementar **mal** (exención en uno solo de los tres
  sitios) y la suite seguiría verde en los cuatro motores. Los casos nuevos de §1 son la única red.

---

## 1 · Exentar la raíz `app` como clave (bloqueante 1)

### 1.1 El ROJO, reproducido

`scratchpad/r2_rojo1.ts` (`memoryQueue`, `maxAttempts: 5`, driver que rechaza el alta de A con 422;
diez pasadas completas del cron). Salida real (`r1.out`):

```json
"A": {
  "idA": 0, "idB": 1,
  "driverVioElAltaDeB": 0,
  "appliedPorPasada": [[],[],[],[],[],[],[],[],[],[]],
  "motivoDeB": [
    "deferred/depends-on:0","deferred/depends-on:0","deferred/depends-on:0",
    "deferred/depends-on:0","deferred/depends-on:0",
    "deferred/parked:0","deferred/parked:0","deferred/parked:0",
    "deferred/parked:0","deferred/parked:0"
  ],
  "dead": [0]
}
```

Exacto lo que midió COGNITIV: **cinco pasadas con `applied = []`** (y las cinco siguientes también,
ya con el tapón de aparcado). El alta del tenant B —el registro público— no llega nunca al store, y
el motivo cambia de forma pero no de efecto.

Y **tres superficies más**, en la misma corrida:

```json
"B": {   // la llamada que hace el tenant tras su commit
  "applied": [], "driver": [],
  "entries": [[1, "deferred", "depends-on:0"]]
},
"C": {   // la variante fail-open del informe: un `moved` aparcado bajo la org
  "motivosDeM2": ["deferred/depends-on:0","deferred/depends-on:0","deferred/parked:0","deferred/parked:0"],
  "driver": []
},
"D": {   // NUEVO, no está en el informe de COGNITIV
  "veredicto": { "ok": false, "code": "E_AUTHZ_REQUEUE_REFUSED", "status": 500,
    "message": "…reencolar reaplicaría un cambio ANTERIOR a otro ya APLICADO sobre la misma clave de scope…" }
}
```

**El bloque D es un hallazgo nuevo**: el alta aparcada del tenant A **no se puede reencolar** porque
otro tenant se dio de alta bajo `app` después. La sonda anti-reversión (`laterApplied`, `manager.ts:1577`)
usa las mismas claves y produce un conflicto FALSO: la salida documentada del incidente (`authz:scopes:requeue`)
está cerrada por el mismo mutex. Si el cambio 1 se hace solo en `#changeKeys`, **D sigue rojo**.

### 1.2 Los tres sitios (y por qué un caso por sitio, no uno global)

| # | Sitio | Línea | Qué mutexea si NO se exime | Caso que lo caza |
|---|---|---|---|---|
| S1 | `#changeKeys` | `src/manager.ts:1959` | `blocked` y `parkedKeys` de la pasada COMPLETA | 1-A, 1-C |
| S2 | `#dependencyOf` (scopes → `earlierPending`) | `src/manager.ts:1432` | la sonda de `only`: el SQL casa `parent_type='app'` aunque `#changeKeys` ya no lo diga | **1-B** |
| S3 | `requeueScopeChanges` (scopes → `laterApplied`) | `src/manager.ts:1577` | la anti-reversión: conflicto falso entre altas de tenants distintos | **1-D** |

Sin 1-B y 1-D, «exentar la raíz» es verde y COGNITIV sigue con el mutex en su camino real (`only`
tras el commit) y sin salida del incidente.

### 1.3 Casos nuevos

Fichero: `tests/scope_outbox.spec.ts`, grupo nuevo `alpha.8 · la raíz no es clave de bloqueo`.
Harness: `memoryQueue()` + `spyDriver()` + `managerWith()` para el comportamiento; `sqlScopeOutbox()`
real (4 motores) para S2/S3, que es donde vive el SQL.

| id | dado → cuando → entonces | Harness | Aserción | Rojo hoy | Mutante que lo mata |
|----|---|---|---|---|---|
| **A-1** 🔑 | dado `attached(orgA, app)` APARCADA y `attached(orgB, app)` pendiente → cuando 5 pasadas completas → entonces el alta de B **se aplica en la primera** | `memoryQueue({maxAttempts:5})` | `report.applied.map(id)` = `[idB]` en la pasada 1; `calls` incluye `attached orgB → app`; `entries` de B = `applied` | ✅ (arriba: `deferred/parked:0` ×10) | quitar la exención de S1 |
| **A-2** | ídem con `only: [idB]` (la llamada del tenant tras su commit) → entonces `applied = [idB]`, cero `deferred` | `memoryQueue` **y** `sqlScopeOutbox` | `entries` = `[[idB,'applied',undefined]]` | ✅ (bloque B) | exención solo en S1 ⇒ vuelve `depends-on` |
| **A-3** 🔑 | dado `attached(orgA, app)` aparcada y `attached(orgB, app)` APLICADA después → cuando `requeueScopeChanges([idA])` → entonces **entra** (`requeued = [idA]`, `overrides = []`) | `sqlScopeOutbox({maxAttempts:2})` | no lanza; `pending()` trae `idA` con `attempts = max−1` | ✅ (bloque D: 500 `E_AUTHZ_REQUEUE_REFUSED`) | exención solo en S1/S2 |
| **A-4** (inverso) | dado `detached(orgA)` que **FALLA** y después `attached(orgA, app)` con el MISMO uuid → entonces el `attached` sigue `deferred depends-on:<detached>` | `memoryQueue` | `entries` = `[[d,'failed',…],[a,'deferred','depends-on:'+d]]`; `calls` sin `attached orgA` | 🟡 verde hoy y verde después (fija que la exención **no** se lleva por delante la clave del HIJO) | exención por `op` en vez de por clave (p. ej. «los `attached` bajo app no bloquean»): rojo |
| **A-5** (inverso) | dado `attached(unitX, orgA)` que falla → entonces `attached(unitY, orgA)` sigue `deferred` | ya cubierto por el mutante total | — | — | — |
| **A-6** (borde) | dado `moved(unit1, app)` y `attached(unit2, app)` → entonces **los dos se aplican**, en orden de id, cero `deferred` | `memoryQueue` | `applied` = ambos; `calls` = `[moved unit1 → app, attached unit2 → app]` | ✅ | S1 sin exención |
| **A-7** (borde) | dado `moved(unit1, app)` y `moved(unit1, orgB)` (MISMA unit) → entonces la segunda sigue `deferred` por la clave `unit\|1` | `memoryQueue` | `entries[1].reason` = `depends-on:<id0>` | 🟡 | exención que filtre por `op === 'moved'` o que vacíe la lista de claves |
| **A-8** (puerto, S2) | `sqlScopeOutbox`: dado dos `attached` bajo `app` → cuando el manager releva con `only:[el segundo]` → entonces **cero** llamadas a `earlierPending` con `APP_SCOPE` | espía sobre `outbox.earlierPending` | el array de `scopes` de la llamada no contiene `{type:'app'}` | ✅ | exención solo en S1 |
| **A-9** (letra) | el README y el docblock de `relayScopeChanges` dicen por qué la raíz no es clave (**no se mueve, no se purga, no se recuelga**) y **nombran los tres 422 que lo sostienen** | `readFile` sobre README | `assert.include` de la frase | ✅ | borrar la frase |

**Justificación de solidez (y su ancla en la suite)**: la exención es correcta *si y solo si* la raíz no
puede ser hijo de ningún cambio. Eso ya lo fija `tests/manager.spec.ts:1315-1317`
(`attached(APP_SCOPE, …)`, `moved(APP_SCOPE, …)`, `detached(APP_SCOPE)` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY`)
y `tests/scope_outbox.spec.ts:422`. **A-9 debe citarlos**: son la premisa, no un detalle.

### 1.4 Casos existentes que cambian

Medido: **ninguno se rompe** (§0). Lo que sí hay que TOCAR, por letra o por sentido:

| Fichero:línea | Qué dice hoy | Qué hacer |
|---|---|---|
| `CLAUDE.md:742` | «Los casos usan el manager con un driver espía y claves INDEPENDIENTES (**la raíz `app` también es clave: dos `attached` bajo `app` se contaminan entre sí**)» | **Frase FALSA tras el cambio.** Reescribir: la raíz NO es clave; los casos del contrato siguen usando claves independientes por otra razón (aislamiento del caso) |
| `src/testing/scope_outbox_contract.ts:418` (**O-07**) y su comentario `:424` («Independiente de verdad: no comparte NINGUNA clave (**ni la raíz**)») | el `detached(other)` independiente se construyó a propósito para no tocar `app` | **Desdoblar en O-07a/O-07b**: (a) tal cual (fallo aplaza lo que comparte clave de NODO); (b) **nuevo**: dos `attached` bajo `app`, el primero falla, el segundo **se aplica** — es el deber del puerto+manager que el cambio 1 crea. Sube `EXPECTED_CASES` de 15 a 16 en `tests/scope_outbox_harness.spec.ts:70` (y las tres aserciones `:76,:77,:84`) |
| `tests/scope_outbox.spec.ts:1969` | `earlierPending(d, [APP_SCOPE])` ⇒ devuelve `a`, «la raíz se busca como padre con uuid nulo» | **Decisión de diseño con consecuencia de test.** Si la exención vive en el MANAGER (mi recomendación), esta aserción sigue verde pero pasa a describir una capacidad **que nadie usa**: anotarla («el puerto sabe buscar por la raíz; el manager ya no se lo pide — ver A-8») o borrar esa línea. Si la exención se mete en el SQL del puerto, **este caso se pone ROJO y hay que reescribirlo** |
| `tests/scope_outbox.spec.ts:2297` | `laterApplied(b, [APP_SCOPE], 10)` ⇒ devuelve `e`, «la raíz como padre con uuid nulo» | idéntico al anterior, para S3 |

**Recomendación de tester**: exención en el MANAGER (los tres sitios), puerto intacto. Motivo: el
puerto es contrato de terceros y una outbox de terceros que ya filtre por la raíz seguiría siendo
válida; y así `1969`/`2297` no se pierden como cobertura del SQL de la sonda, que sigue siendo real
para cualquier scope no raíz.

**Coste**: 9 casos nuevos + 1 desdoble del contrato (+1 `EXPECTED_CASES`) + 4 retoques de letra.
**Bajo** (harness existente, sin infra nueva). Verificable en los 4 motores con el mismo test (A-2,
A-3 y A-8 contra `sqlScopeOutbox` real; el resto es en memoria y motor-agnóstico).

**Veredicto: verificable.** Con la advertencia de §0: sin A-2/A-3/A-8 el lote se cierra en verde con
el mutex vivo en el camino que le importa a COGNITIV.

---

## 2 · Supersede de un `moved` aparcado por un `moved` posterior de la misma unit

### 2.1 Lo que el plan no dice y hay que fijar antes de escribir el test

Tres subespecificaciones, y cada una es un caso distinto:

1. **¿`superseded` es un estado del REPORTE, de la OUTBOX, o los dos?** Si solo es del reporte, la
   entrada sigue en `dead()` y el comando sigue saliendo ≠ 0 para siempre. Si es de la outbox, hace
   falta o una columna nueva (`superseded_by`/`superseded_at`) o reutilizar `applied_at` —y
   reutilizar `applied_at` es **mentira auditable**: `authz_scope_outbox` es también el registro de
   qué se propagó (stub, docblock). Mi lectura: **estado propio en el puerto** (`supersede(ids, byId)`
   opcional) + `ScopeRelayEntryStatus` amplía a `'superseded'`.
2. **¿Quién supersedea: la pasada del relay o `requeue`?** El enunciado dice «un `moved` posterior de
   la misma unit». Si lo hace la pasada, entonces el `dead` deja de ser inmutable **dentro del lease**
   y hay que decidir el orden respecto de `#parkedKeys` (el censo se lee ANTES del bucle,
   `manager.ts:1177`): una entrada superseded en el minuto 2 de la pasada seguiría taponando en el
   censo del minuto 1. **Caso obligatorio.**
3. **¿Un `moved` posterior supersedea un `attached` aparcado de la misma unit?** No: `attached` y
   `moved` no son intercambiables en `facts` (`onScopeAttached` vs `onScopeMoved` + `sweepLocalRoleBindings`).
   **Caso negativo obligatorio.**

### 2.2 Casos

Fichero: `tests/scope_outbox.spec.ts`, grupo nuevo. Harness: `memoryQueue` para el comportamiento,
`sqlScopeOutbox` para el puerto (los 4 motores).

| id | dado → cuando → entonces | Aserción | Rojo hoy | Mutante |
|----|---|---|---|---|
| **S-1** 🔑 | dado `moved(unit, orgB)` APARCADA y `moved(unit, orgC)` pendiente → cuando relay → entonces la posterior **se aplica** y la aparcada queda `superseded` | `calls = ['moved unit → orgC']`; `entries` trae `[old,'superseded','superseded-by:'+new]`; `dead()` **ya no** la ofrece | ✅ hoy: la posterior sale `deferred parked:<old>` (tapón R2a) | supersede que aplica la VIEJA (orden invertido) |
| **S-2** 🔑 (orden) | dado `moved(unit,orgB)` aparcada, `attached(child, unit)` pendiente **en medio**, `moved(unit,orgC)` pendiente detrás → cuando relay → entonces se aplica **primero** el `moved` posterior y **después** el `attached` | `calls` deepEqual `['moved unit → orgC','attached child → unit']` | ✅ (hoy los dos `deferred`) | aplicar por id (el `attached` es anterior) ⇒ el hijo cuelga de un padre que aún no se recolgó: rojo |
| **S-3** (negativo) | dado `moved(unitA,…)` aparcada y `moved(unitB,…)` posterior (OTRA unit) → entonces **nada** se supersedea; la aparcada sigue en `dead()` y la posterior se aplica si no comparte clave | `dead()` = `[old]`; `entries` sin `superseded` | 🟡 | supersede por `op` en vez de por `scopeKey(child)` |
| **S-4** (negativo) | dado `attached(unit, orgA)` **aparcada** y `moved(unit, orgB)` posterior → entonces **NO** supersedea: la posterior sigue `deferred parked:` | `entries[1].reason` empieza por `parked:` | 🟡 | supersede que mira solo el hijo y no el `op` |
| **S-5** (borde) | dado `moved(unit,orgB)` aparcada y `detached(unit)` posterior aplicada → entonces la aparcada queda `superseded` (una purga la deja sin sentido) **o** se declara que no — hay que **decidirlo** y fijarlo | el que se decida | ❓ subespecificado | el contrario |
| **S-6** (idempotencia) | dos pasadas seguidas → la segunda no vuelve a marcar ni a reportar `superseded` de la misma | `entries` de la 2ª pasada vacío para ese id | 🟡 | `supersede` no persistente |
| **S-7** (interacción con requeue) 🔑 | dado una aparcada ya `superseded` → cuando `requeueScopeChanges([id])` → entonces **500 nombrándola**: una superseded no se reencola (es exactamente la reversión que `laterApplied` niega) | `E_AUTHZ_REQUEUE_REFUSED` o un `E_AUTHZ_CONFIG` con la letra | ✅ | permitir el requeue ⇒ revierte el árbol |
| **S-8** (censo) | dado 1 aparcada superseded → entonces **deja de sembrar `parkedKeys`** en la MISMA pasada en que se supersedea, y su clave no aplaza a nadie más | `entries` de una tercera entrada de esa clave = `applied` | ✅ | leer el censo antes y no recalcular |
| **S-9** (letra) | `authz:scopes:relay` sale **0** si lo único que había aparcado quedó superseded (hoy sale ≠ 0 mientras exista un `dead`) | `relayLines`/exit code | ✅ | — |

### 2.3 Invariantes existentes en riesgo

| Invariante | Test que lo cubre hoy | Riesgo |
|---|---|---|
| `ScopeRelayEntryStatus` es una unión de 4 (`applied\|deferred\|failed\|dead`) | `src/types.ts:1087`; `tests/scope_outbox.spec.ts:1845` compara `entries` con `deepEqual` de tuplas | ⚠️ **`1845` se pone ROJO** si el orden o el conteo de `entries` cambia. Hay que releerlo tras el cambio |
| «Aparcar no es olvidar: el relay la reporta en TODAS las pasadas y el comando sale ≠ 0» | `scope_outbox.spec.ts:1104`, `:1147`, y `commands.spec.ts` (exit ≠ 0) | ⚠️ **`superseded` es una excepción a esa frase.** Hay que desdoblar `:1147` («la reporta en cada pasada») en (a) aparcada viva (b) aparcada superseded, y corregir CLAUDE.md §(ii) y el README |
| Anti-reversión del requeue (`laterApplied`) | `scope_outbox.spec.ts:2050`, `:2271` | S-7 es su hermano: sin él, `--force` sobre una superseded revierte |
| El tapón por clave de lo aparcado (R2a) | `:1210`, `:1282` | S-8 lo modifica **dentro** de la pasada |

**Coste**: 9 casos + 1 desdoble (`:1147`) + revisar `:1845` + puerto nuevo (método opcional +
capacidad + par en `runScopeOutboxContract` ⇒ `EXPECTED_CASES` 15 → 17) + migración de columna si se
persiste. **ALTO.** Es el cambio más caro de los tres y el único que toca el esquema.

**Veredicto: verificable con cambios.** Antes de escribir un test hay que cerrar las tres preguntas
de §2.1 (sobre todo la 1: reporte vs outbox). Con «estado solo del reporte» el incidente **no se
cierra** y S-9 es imposible.

---

## 3 · `requeueScopeChanges(ids, { apply: true })`

### 3.1 El ROJO (P14), reproducido

`scratchpad/r2_rojo3.ts`. Salida real (`r3.out`):

```json
"A": {
  "dead": [0],
  "requeue": {
    "requeued": [0],
    "attemptsTrasRequeue": [[0,1],[1,0]],
    "leasesQueTomaElRequeue": 0,
    "hayApplyTrue": "requeueScopeChanges(ids, { force? }) — no existe `apply`"
  },
  "pasadaOnlyDelTenant": {
    "applied": [],
    "entries": [[1,"deferred","depends-on:0"]],
    "driver": []
  },
  "pasadaCompleta": { "applied": [0,1], "driver": ["attached unit→org","attached child→unit"] },
  "leasesTotales": 4
}
```

Confirmado punto por punto: el requeue devuelve la entrada con su **id original (0, menor)** y
`attempts = maxAttempts − 1 = 1`; **toma 0 leases**; y la siguiente pasada `only` del tenant sale
`deferred/depends-on:0`. Hace falta un `relay` completo detrás.

Y el detalle que **no está en el informe** (`r3.out`, bloque B):

```json
"B": { "lanzo": null, "driverTrasApplyTrue": [], "siguenPendientes": [0,1], "leasesTomados": 0,
       "nota": "`apply` se IGNORA en silencio: la opción no existe y el objeto de opciones no se valida" }
```

`requeueScopeChanges(ids, { apply: true })` **hoy no lanza: se ignora**. Lo mismo vale para
`relayScopeChanges({ waitForLeaseMs })` (punto 9): las opciones son un objeto literal sin validación
(`manager.ts:1070`, `:1538`). En TypeScript el consumidor lo vería (exceso de propiedad en literal),
en JS o con un `as any` no. **Caso de letra obligatorio en los dos puntos** (ver §10-b).

Y el negativo ya funciona hoy (bloque C): con una aplicada posterior que comparte clave,
`{ apply: true }` sigue dando `E_AUTHZ_REQUEUE_REFUSED` (500) y **cero llamadas al driver** — porque
`apply` se ignora. El caso R-4 de abajo tiene que seguir verde **por la razón correcta** después del
cambio.

### 3.2 Casos

Fichero: `tests/scope_outbox.spec.ts`, grupo `alpha.5 · R2b` (ampliado) + `commands.spec.ts` para `--apply`.

| id | dado → cuando → entonces | Aserción | Rojo hoy | Mutante |
|----|---|---|---|---|
| **R-1** 🔑 | dado una aparcada cuya causa el operador arregló → cuando `requeueScopeChanges([id], { apply: true })` → entonces **se aplica en la misma llamada** | `calls` incluye el cambio; `pending()` vacío para ese id; `applied` del reporte devuelto | ✅ (bloque A/B) | `apply` que solo reencola |
| **R-2** 🔑 (lease) | ídem, con espía sobre `outbox.acquire` → entonces **exactamente UNA** adquisición en toda la llamada | `leases.length` antes/después = +1 | ✅ (hoy 0 en requeue + 1 por cada relay ⇒ 2 llamadas del operador) | requeue que llama a `relayScopeChanges()` por dentro sin compartir lease ⇒ 2 |
| **R-3** 🔑 (dependientes) | dado la aparcada #0 y su dependiente #1 pedidos **en la misma llamada** (`requeueScopeChanges([0], { apply: [0,1] })` o `{ apply: true, only: [1] }` — **hay que definir la superficie**) → entonces se aplican **los dos, en orden de id**, bajo el mismo lease | `calls` deepEqual en orden; `entries` = dos `applied` | ✅ | aplicar solo la reencolada ⇒ #1 sigue `depends-on` |
| **R-4** (anti-reversión) | dado una aparcada con una APLICADA posterior de su clave → cuando `{ apply: true }` → entonces **500 `E_AUTHZ_REQUEUE_REFUSED`, cero filas tocadas, cero llamadas al driver** | como `:2050`, más `assert.deepEqual(calls, [])` | 🟡 verde hoy **por accidente** (`apply` se ignora) | implementar `apply` *antes* de la sonda ⇒ rojo. **Este es el mutante que importa**: el orden sonda→requeue→aplicar |
| **R-5** (todo o nada) | dado dos ids, uno no aparcado → entonces 500, **cero** reencoladas y **cero** aplicadas | `pending()` y `calls` intactos | 🟡 | `apply` que aplica lo que sí pudo |
| **R-6** (la causa sigue rota) | dado `{ apply: true }` y el driver que sigue fallando (fallo de ENTRADA) → entonces la entrada vuelve a `dead()` **en esa misma llamada** (`attempts` pasa de `max−1` a `max`) y el reporte lo dice | `dead()` = `[id]`; el reporte trae `failed` | ✅ | `apply` que no cuenta el intento ⇒ grifo de aplazamiento |
| **R-7** (503) | ídem con el store caído → entonces `transient: true`, `attempts` se queda en `max−1`, sigue **pendiente**, no vuelve a `dead()` | `pending()[0].attempts === max−1` | ✅ | clasificar el 503 como fallo de entrada |
| **R-8** (freeze) | dado el freeze durable adquirido → cuando `{ apply: true }` → entonces **503 y no aplica** (hoy `requeue` **no** pasa por la barrera a propósito: `manager.ts:1533`) | `E_AUTHZ_BACKEND_*`/frozen | ✅ | reencolar+aplicar sin barrera = escritura de árbol durante el cutover |
| **R-9** (plataforma) | `{ apply: true }` sigue siendo API de plataforma: sin actor, sin `within`, **y el README dice que no se expone por HTTP** | `readFile` + docblock | 🟡 | — |
| **R-10** (comando) | `authz:scopes:requeue --id N --apply` existe, y **sin** `--apply` el comportamiento es el de hoy | `flags` `includeMembers` (`scope_outbox.spec.ts:2314` es aditivo, no rompe); salida por entrada | ✅ | — |
| **R-11** (letra) | una opción desconocida (`{ apply: 'yes' }`, `{ appply: true }`) **no se ignora**: 500 `E_AUTHZ_CONFIG` | `rejects` | ✅ (hoy silencio) | — |

### 3.3 Invariantes en riesgo

- **`requeue` no pasa por la barrera del freeze** (`manager.ts:1531-1534`, escrito a propósito: «no
  escribe en el backend»). Con `apply: true` **sí escribe** ⇒ R-8 es obligatorio, y la frase del
  docblock deja de ser cierta. Sin R-8 el cambio abre un bypass del cutover.
- **El lease es del relay** (`3b-2h · 🟠 4`, `:2460` «dos pasadas a la vez ⇒ `busy`»). R-2 es el que
  impide que `apply` sea «llamar a `relayScopeChanges` por dentro» y acabe en `busy` contra sí mismo
  cuando el operador lo corre desde un cron que ya tiene el lease. **Caso extra R-2b**: con el lease
  ya tomado por otro proceso, `{ apply: true }` **no reencola** (o reencola y dice `busy` sin
  aplicar) — hay que decidirlo y fijarlo; el silencio aquí deja una entrada reencolada que nadie
  aplica y con `attempts = max−1`, o sea que la siguiente pasada la aparca otra vez.
- `entries`/`ScopeRelayReport` como tipo de retorno de `requeueScopeChanges`: hoy devuelve
  `ScopeRequeueReport` (`{requeued, overrides, forced}`). Con `apply` hay que **componer** los dos
  reportes o devolver el del relay dentro. Cambio de superficie ⇒ tocar `commands/authz_scopes_requeue.ts`
  y `requeueLines` (puro, ya con test en `:2330`).

**Coste**: 11 casos + 1 decisión de superficie (R-3) + 1 de concurrencia (R-2b). **MEDIO.**
Verificable en los 4 motores; el lease de verdad (PG advisory / MySQL GET_LOCK) ya tiene el multiproceso
en `tests/scope_outbox_multiprocess.spec.ts` — R-2b debería ir **ahí**, no en proceso.

**Veredicto: verificable con cambios** (definir la superficie de R-3 y la política de R-2b).

---

## 4 · Edad de la cola (bloqueante 3)

### 4.1 El ROJO (B2 del auditor de COGNITIV), reproducido

`scratchpad/r2_rojo4.ts` (driver que lanza `AuthorizationBackendError`, 10 pasadas). Salida real (`r4.out`):

```json
{
  "resumen": [
    "p1: applied=0 dead=0 transient=true attempts=0",  … (idéntico p2..p10)
    "p10: applied=0 dead=0 transient=true attempts=0"
  ],
  "clavesDelReporte": ["applied","busy","dead","deferred","dryRun","entries","failed","failures","missing","remaining","wouldApply"],
  "tieneEdad": false,
  "camposDeUnaEntrada": ["id","change","status","reason","attempts"],
  "camposDePending": ["id","change","actor","attempts"]
}
```

Diez pasadas, `attempts` clavado en 0, `dead` en 0, y **ninguna clave del reporte habla de tiempo**.
La única alarma del contrato (`dead` ≠ 0 ⇒ exit ≠ 0) es ciega exactamente aquí. Confirmado.

### 4.2 `created_at` existe en la TABLA pero NO en el PUERTO

- `stubs/scopes_outbox_migration.stub`: `table.timestamp('created_at').notNullable()` ✅
- `src/scope_outbox.ts:330`: se escribe con el reloj **inyectable** (`options.now`, `:275`) ✅
- `src/scope_outbox.ts:210-227` (`rowToPending`): **no lo devuelve** ❌
- `src/types.ts:1044-1059` (`PendingScopeTreeChange`): `id`, `change`, `attempts?`, `lastError?`, `actor?` — **no hay `createdAt`** ❌

⇒ **Hay que añadirlo al puerto** (`createdAt?: Date`, opcional: un driver de terceros que no lo traiga
deja el reporte **sin** `oldestPendingAt`, jamás con `now` — «no lo sé» no puede degradar a «edad 0»,
que es el mismo patrón de `stillGranting`/`countRoleAssignments`, invariante 18) **o** un método
opcional `oldestPending?(): Promise<Date | null>` (una consulta `min(created_at)`, más barata que
paginar). Mi recomendación: **`createdAt` en `PendingScopeTreeChange` Y `oldestPending?()`** — el
primero para `entries`, el segundo para la alarma global sin leer la cola.

### 4.3 Propuesta sobre `only` (la pregunta del enunciado)

**`oldestPendingAt` siempre de la COLA ENTERA**, como `remaining` y `dead`, y con nombre que lo diga:
`queue: { oldestPendingAt, pendingAgeMs, pending }`. Razones: (a) es una alarma de PLATAFORMA, y bajo
`only` el tenant no ve el backlog que le importa al operador; (b) ya existe la regla escrita «el
reporte no se devuelve por HTTP» y `remaining`/`dead` ya son globales — hacerlo per-`only` inventa una
tercera política; (c) la edad de «lo mío» es trivialmente calculable por el consumidor con el recibo.
**Y con un caso que lo fije en las dos formas** (con y sin `only`, mismo valor).

### 4.4 Casos

| id | dado → cuando → entonces | Harness | Aserción | Rojo hoy | Mutante |
|----|---|---|---|---|---|
| **E-1** 🔑 | dado una pendiente encolada a T0 y el store caído → cuando 10 pasadas a T0+10 min → entonces `report.queue.oldestPendingAt === T0` y `pendingAgeMs === 600000` con `attempts = 0` y `dead = 0` | `sqlScopeOutbox({ now })` con reloj inyectado + `config.clock` | igualdad exacta (sin `sleep`) | ✅ | leer `new Date()` ⇒ **también rojo en `tests/clock.spec.ts`** |
| **E-2** | ídem bajo `only: [otra entrada]` → entonces el MISMO `oldestPendingAt` (global) | ídem | igualdad con E-1 | ✅ | filtrarlo por `only` |
| **E-3** (borde) | cola vacía → entonces `oldestPendingAt` **ausente** (`undefined`), nunca `now` ni `null` interpretable como 0 | — | `assert.isUndefined` | ✅ | default a `now` = alarma que nunca salta |
| **E-4** (borde) | solo hay APARCADAS (`dead`) → entonces `oldestPendingAt` ausente: lo aparcado ya tiene su alarma | — | `assert.isUndefined` + `dead.length = 1` | ✅ | contar `dead` en la edad ⇒ alarma duplicada permanente |
| **E-5** (borde) | una outbox de TERCEROS sin `createdAt` ni `oldestPending` → entonces el reporte sale **sin** el campo y no revienta | doble `makeScopeOutbox` mínimo | `isUndefined` + pasada verde | 🟡 | degradar a `Date.now()` |
| **E-6** 🔑 (skew) | dado `sqlScopeOutbox({ now: () => futuro })` (dos réplicas con relojes desviados; `created_at` lo sella el CLIENTE, `scope_outbox.ts:330`) → entonces `pendingAgeMs >= 0` y nunca negativo | reloj inyectado | `isAtLeast(0)` | ✅ (hoy no existe; con la resta cruda saldría negativa) | quitar el `Math.max(0, …)` |
| **E-7** (`parkAfterMs`) | dado `parkAfterMs: 60_000` y una entrada de 61 s que falla por 503 → entonces **se APARCA** (sale por `dead()`) aunque `attempts = 0` | reloj inyectado + `memoryQueue` | `dead()` = `[id]`; `attempts` sigue 0 | ✅ | aparcar por edad **sin** fallo (ver E-8) |
| **E-8** 🔑 (inverso de E-7) | dado `parkAfterMs: 60_000` y una entrada de 61 s **que se aplica bien** → entonces **se aplica**, no se aparca | ídem | `applied` = `[id]` | ✅ | aparcar por edad a secas ⇒ una cola parada 2 min por un despliegue aparcaría todo lo sano: **fail-dangerous** |
| **E-9** (borde exacto) | edad == `parkAfterMs` exacto ⇒ **no** aparca (estricto `>`), edad = `+1 ms` ⇒ aparca | reloj inyectado | dos aserciones | ✅ | `>=` |
| **E-10** (comando/letra) | `authz:scopes:relay` imprime la edad y **sale ≠ 0** si supera un umbral opt-in; sin umbral, solo informa | `relayLines` (función pura, patrón de `requeueLines`) | exit code | ✅ | exit ≠ 0 por edad sin umbral ⇒ cron rojo permanente |

### 4.5 Invariantes en riesgo

| Invariante | Test | Riesgo |
|---|---|---|
| **La hora de pared se lee SOLO en `src/clock.ts`** | `tests/clock.spec.ts:38` (grep sobre `src/**`, `src/testing` excluido) | 🔴 **Cualquier `Date.now()`/`new Date()` que se cuele en `manager.ts` o `scope_outbox.ts` para calcular la edad pone ROJA la suite.** La edad se calcula con `this.#config.clock ?? systemClock` y con `options.now` en el puerto. Es una red que ya existe: úsala, no la esquives |
| «un 503 NO consume intento» (R2a) | `:1348`, `:1407`, `:1435`, `:1458`, `:1476` | E-7/E-8 **no** deben tocarlo: `parkAfterMs` es una vía **adicional** de convergencia, no una reclasificación del 503. Si `parkAfterMs` acaba contando intentos, `:1348` se pone rojo — y eso es correcto: sería la regresión |
| `EXPECTED_CASES = 15` (`tests/scope_outbox_harness.spec.ts:70`) | ídem | +1 o +2 pares de capacidad nuevos (`queueAge`, `parkAfterMs`) |

**Coste**: 10 casos + campo opcional en el puerto + par(es) de capacidad en el contrato. **MEDIO.**
Mismo test en los 4 motores (el reloj es inyectable en los dos lados). Sin `sleep` en ninguno.

**Veredicto: verificable.** `oldestPendingAt` es **barato** y cierra el bloqueante; `parkAfterMs` es
el que trae los bordes peligrosos (E-8 es el caso que decide si es seguro).

---

## 5–10 · Los menores

### 5 · `origin: 'parked' | 'pending' | 'failed'` en `entries`

`ScopeRelayEntry` (`src/types.ts:1108-1114`) = `{id, change, status, reason?, attempts?}`. Medido
(`r4.out`: `camposDeUnaEntrada`). El dato **ya existe** en el manager (`blocked: Map<key,{id,parked}>`,
`manager.ts:1162`) y solo se serializa a prosa en `deferred[].error`.

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **O-1** | aplazada por APARCADO ⇒ `entry.origin === 'parked'` y `reason` empieza por `parked:` | deepEqual de la tupla | ✅ | `origin` derivado del prefijo de `reason` (frágil) ⇒ hay que derivarlo de `blocked`, no del texto |
| **O-2** | aplazada por FALLO real de la pasada ⇒ `origin === 'failed'` | ídem | ✅ | — |
| **O-3** 🔑 | aplazada bajo `only` por una anterior **pendiente de verdad** ⇒ `origin === 'pending'` (no `failed`) — es justo la distinción de `#blockOriginOf` (alpha.6) | `:2866` es su hermano | ✅ | colapsar `pending` y `failed` en uno |
| **O-4** | transitivo a dos saltos (`:2802`) ⇒ el `origin` es el de la CAUSA RAÍZ, no el del eslabón | ídem | ✅ | propagar el del eslabón |

**Afecta a `tests/scope_outbox.spec.ts:1845`** (`deepEqual` de `[id,status,reason]`): si `entries`
crece un campo, ese caso sigue verde (compara proyecciones), pero **hay que ampliarlo** para que el
campo nuevo no quede sin juez. **Coste: bajo (4 casos).** **Veredicto: verificable.**

### 6 · `dead` bajo `only`

**Corrección factual al informe de COGNITIV**: `report.dead` es global (`manager.ts:1090`, antes de
mirar `only`) y trae `{id, change, attempts, error}` — **el `actor` NO viaja** (`#deadLetters`,
`manager.ts:1965-1974`, lo descarta). Lo que fuga a un tenant son **ids, uuids de scope ajenos,
`attempts` y `lastError`**. `deadEntries` sí se filtra (`:1092`).

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **D-1** 🔑 | dado 2 aparcadas ajenas y 1 propia → cuando `only:[la propia]` → entonces `report.dead` trae **los ids de las tres** (la alarma no se estrecha) pero **sin `error`** de las ajenas | `dead.map(d=>d.error)` = `[undefined, undefined, 'la mía']` | ✅ | omitir `dead` entero bajo `only` ⇒ la alarma se pierde |
| **D-2** (inverso) | sin `only` ⇒ `dead` completo con `error` | `:1104` ya cerca | 🟡 | filtrar siempre |
| **D-3** | `deadEntries` (en `entries`) sigue filtrado por `only`, con `reason` | `:1813` | 🟡 | — |
| **D-4** (letra) | el README dice qué campos son seguros de devolver y cuáles no | `readFile` | ✅ (hoy solo «no lo devuelvas por HTTP») | — |

**Coste: bajo (4 casos).** **Veredicto: verificable.** Nota de diseño para el arquitecto: «omitir»
`dead` bajo `only` **rompe la única alarma** que tiene un consumidor que solo hace pasadas `only`;
«redactar» (ids sí, detalles no) conserva la alarma. D-1 fija la segunda.

### 7 · `enqueue` sin `{ transaction }` ⇒ 500 antes del INSERT (P13)

Hoy: `clientOf` (`src/scope_outbox.ts:298-301`) llama `assertCallerTransaction`, que con
`transaction === undefined` **devuelve `undefined` sin quejarse** (`src/shared/transaction_guard.ts:59`)
y se cae a `on(database)` ⇒ **escribe fuera de la unidad de trabajo**. La mitigación entera (invariante
del rollback) depende de esa trx.

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **T-1** 🔑 | dado `sqlScopeOutbox({ requireTransaction: true })` (opt-in; **breaking si es default**) → cuando `enqueue(change, {})` → entonces **500 `E_AUTHZ_CONFIG` y CERO filas** | `rejects` + `select count(*)` = 0 | ✅ (hoy inserta) | validar después del INSERT |
| **T-2** (inverso) | con `{ transaction: trx }` ⇒ encola y el rollback no deja nada | `:496` ya lo cubre | 🟡 | — |
| **T-3** 🔑 (compatibilidad) | los usos internos que **no** llevan trx (el relay no encola; `manager.scopes.*` sí propaga el `context`) siguen funcionando; y con la opción apagada el comportamiento es el de hoy | correr `scope_outbox.spec.ts` entero con la opción apagada | 🟡 | poner el gate por default ⇒ **rompe `:444`, `:470`, `:490`, `:620`, `:630`, `:1949`, `:2271` y casi todo `sqlScopeOutbox` usado sin trx en los tests** |

⚠️ **T-3 es el caso caro**: medí que la mayoría de los casos del puerto encolan sin transacción
(`outbox.enqueue({…}, {})`), y **el `ctx()` del contrato publicado NUNCA lleva transacción**
(`src/testing/scope_outbox_contract.ts:293`: `(actor) => actor ? { actor } : {}`). Con el gate **por
defecto** se ponen rojos decenas de casos de `scope_outbox.spec.ts` **y los 15 del juez del puerto**
—que es el que corren los TERCEROS contra su propia outbox—: sería un breaking del contrato
publicado, no solo de nuestra suite. **Recomendación: opción opt-in** (`requireTransaction`, default `false` en 2.4, `true` en
2.5 con nota de breaking) ⇒ coste **bajo**; como default inmediato, coste **alto**.

**Veredicto: verificable; el coste depende enteramente de si es default.**

### 8 · Transacción ya cerrada ⇒ `E_AUTHZ_CONFIG`

Hoy una trx confirmada/revertida pasa las cuatro guardas (`transaction_guard.ts:61-88`: tiene `.from`,
`.table`, `isTransaction === true`, la conexión correcta) y explota **dentro** de `guardSql` ⇒ 503
`E_AUTHZ_BACKEND_UNAVAILABLE` «no respondió (enqueue)», que culpa al backend de un error del llamante.

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **C-1** 🔑 | dado `const trx = await db.transaction(); await trx.commit()` → cuando `enqueue(change, { transaction: trx })` → entonces **500 `E_AUTHZ_CONFIG`** nombrando «ya confirmada/revertida», **antes** de la sentencia | `rejects` + espía de consultas = 0 | ✅ (hoy 503) | comprobar `isCompleted()` **después** de la query |
| **C-2** | ídem con `rollback()` | ídem | ✅ | — |
| **C-3** (inverso) | trx **abierta** ⇒ encola, sin coste extra medible | `:519` | 🟡 | `isCompleted()` mal leído ⇒ rompe todo `:496`/`:519` |
| **C-4** (paridad) | la misma guarda en el resto de `{ transaction }` (roles L-3, relaciones L-4): **o se hace en `assertCallerTransaction` y vale para las tres, o hay que decir por qué no** | `database_transaction.spec.ts` | ✅ | ponerlo solo en la outbox |

**C-4 es el que decide el sitio**: `assertCallerTransaction` es compartido; arreglarlo ahí es 1 línea y
3 puertos. **Coste: bajo (4 casos).** **Veredicto: verificable.**

### 9 · `enumerateRelationsMany` nativo en `database` (o capacidad)

Estado medido: `enumerateRelationsMany` existe en el puerto (`src/types.ts:2110`), en `openfga`
(`openfga_relations_driver.ts:646`) y con **respaldo** en el manager (`relations/manager.ts:582`:
si el driver no lo trae, K llamadas). **No hay capacidad declarada**:
`RelationsDriverCapabilities` (`src/types.ts:1889-1925`) lista `enumerateRelations` pero **no**
`enumerateRelationsManyNative`. `database_relations_driver` no lo implementa.

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **M-1** (capacidad, barato) | `driver.capabilities().enumerateRelationsManyNative` es `true` en `openfga` y `false` en `database` | `capabilities.spec.ts` (patrón existente) | ✅ | declararlo `true` sin implementarlo ⇒ lo caza el par de capacidad del runner |
| **M-2** 🔑 (coste, si se implementa) | dado 3 particiones y N tuplas en `database` → cuando `enumerateRelationsMany` → entonces **UNA** consulta (espía sobre el cliente Lucid) y salida **byte a byte** igual a 3 × `enumerateRelations` | espía de consultas + `deepEqual` de las tres proyecciones | ✅ | implementarlo como 3 consultas ⇒ M-2 rojo, M-3 verde: por eso el espía es obligatorio |
| **M-3** (equivalencia) | la reanudación por cursor da el mismo conjunto que sin cursor | patrón `relations_openfga.spec.ts:999` portado | ✅ | — |
| **M-4** (borde) | `partitions: []` ⇒ 500 (paridad con `openfga`, `openfga_relations_driver.ts:649`) | `rejects` | 🟡 | devolver página vacía = «éxito vacío», el mismo bug del prefijo |

**Coste: bajo si es solo capacidad (1 caso); medio si se implementa (4).** **Veredicto: verificable.**
Nota: M-2 es **verificable sin OpenFGA** (es `database`), lo cual es una ventaja: hoy la única medida
del barrido único vive contra el `:8101` (`relations_openfga.spec.ts:999`).

### 10 · `waitForLeaseMs`, letra del 422 y `maxDepth = N + 1`

**(a) `waitForLeaseMs`.** Hoy `acquire()` ⇒ `null` ⇒ `busy` inmediato (`manager.ts:1130-1145`).

| id | Caso | Harness | Aserción | Rojo | Mutante |
|---|---|---|---|---|---|
| **W-1** 🔑 (orden, sin reloj) | dado el relay A con el lease tomado y B llamando con `waitForLeaseMs: 5000` → cuando A suelta (barrera explícita, **no** `sleep`) → entonces **B entra y aplica**, `busy === false` | `acquire` instrumentado con una promesa que el test resuelve | ✅ | `waitForLease` que hace un solo reintento inmediato |
| **W-2** (cota) | `waitForLeaseMs: 0` con el lease tomado ⇒ `busy` **inmediato** (comportamiento de hoy, que no puede cambiar) | espía de intentos = 1 | 🟡 | default distinto de 0 ⇒ **rompe `:2460`** («dos pasadas a la vez ⇒ `busy`»), que es el caso que hay que releer |
| **W-3** (vencimiento) | lease que nunca cede + `waitForLeaseMs: 50` ⇒ `busy` y **no** cuelga; el número de intentos está acotado y es observable | reloj/contador inyectado | ✅ | espera sin techo |
| **W-4** 🔑 (entre procesos) | el caso de verdad va a `tests/scope_outbox_multiprocess.spec.ts` + `helpers/relay_child.ts` (pg/mysql): el hijo con `waitForLeaseMs` entra cuando el padre suelta | infra **ya existente** | ✅ | cerrojo de proceso ⇒ verde en proceso, rojo aquí (mismo patrón que (vi) de CLAUDE.md) |

⚠️ **`:2460` («dos pasadas a la vez: la segunda no aplica NADA y lo dice `busy`») es el invariante en
riesgo**: si `waitForLeaseMs` trae un default > 0, ese caso se vuelve flaky o rojo. **Default 0
obligatorio**, y W-2 es quien lo fija.

**Coste: medio** (W-4 necesita PG/MySQL, pero la infra ya existe). **Veredicto: verificable.**

**(b) Letra del 422 sin nombrar el servidor.** Hoy `manager.ts:2255-2260` mete
`OPENFGA_RESOLVE_NODE_LIMIT`, `FACTS_MAX_RESOLVE_DEPTH` y `facts de openfga` **en el mensaje que
recibe el tenant**.

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **L-1** 🔑 | el mensaje del 422 **no** contiene `OPENFGA`, `openfga` ni `FACTS_` | `assert.notInclude` ×3 sobre `error.message` | ✅ | dejar una de las tres |
| **L-2** (inverso) | el mensaje **sí** dice lo accionable para el tenant: la profundidad alcanzada, `scopes.maxDepth` y «no se ha escrito ni encolado nada» | `assert.include` (ya en `scope_depth.spec.ts:154-155`) | 🟡 | vaciar el mensaje «por seguridad» |
| **L-3** | el detalle del servidor **sí** viaja al operador: log/`onWrite`/README, no al 422 | espía de logger o `readFile` | ✅ | — |

⚠️ **`tests/scope_depth.spec.ts:143-156` cambia**: hay que añadir los `notInclude`. Es aditivo.

**(c) `maxDepth = N + 1`.** La cadena incluye `app` (`chain.length > maxDepth`, `manager.ts:2254`) y
`scope_depth.spec.ts:129` ya fija el borde («con `maxDepth: 22` un hijo a 22 saltos ENTRA»).

| id | Caso | Aserción | Rojo | Mutante |
|---|---|---|---|---|
| **N-1** | el README dice, con un ejemplo numérico, que **N niveles bajo la raíz necesitan `maxDepth = N + 1`**, y la línea está en la tabla de límites | `readFile` + `include`, atado a la constante como `scope_depth.spec.ts:95-120` | ✅ | quitar el ejemplo |
| **N-2** (letra ejecutable) | un árbol de exactamente N=3 niveles con `maxDepth: 3` ⇒ **422**, con `maxDepth: 4` ⇒ entra | dos `rejects`/`queued` | 🟡 | — |

**N-2 vale más que N-1**: convierte la documentación en un caso. **Coste: bajo (5 casos entre b y c).**
**Veredicto: verificable.**

**(d) Opciones desconocidas, transversal a 3 y 9.** Medido (`r3.out`, bloque B): `{ apply: true }` hoy
**se ignora en silencio**. Caso **X-1**: `relayScopeChanges`/`requeueScopeChanges` con una opción
desconocida ⇒ 500 `E_AUTHZ_CONFIG` nombrándola. Sin esto, un consumidor en JS que llame
`{ waitForLeaseMs }` contra una versión vieja cree que espera y no espera — y el síntoma es un `busy`
que achacará a otra cosa. **Coste: 1 caso. Rojo hoy.**

---

## Tabla resumen

| # | Punto | Casos nuevos | Casos existentes que cambian | Invariantes en riesgo | Coste | Veredicto |
|---|---|---|---|---|---|---|
| **1** | Exentar la raíz `app` | **9** | 0 rojos (medido) · 4 retoques: `CLAUDE.md:742`, contrato `:418` (desdoble ⇒ `EXPECTED_CASES` 15→16), `spec:1969`, `spec:2297` | ninguno se rompe; la premisa la sostiene `manager.spec.ts:1315-1317` | **bajo** | **verificable** (con A-2/A-3/A-8 o el mutex sigue vivo) |
| **2** | Supersede de `moved` | **9** | desdoblar `spec:1147`; releer `spec:1845`; contrato +2 (`EXPECTED_CASES` 15→17); posible migración | «aparcar no es olvidar»; `ScopeRelayEntryStatus`; tapón R2a; anti-reversión | **alto** | **verificable con cambios** (3 preguntas abiertas en §2.1) |
| **3** | `requeue { apply: true }` | **11** | `spec:2314` aditivo; `requeueLines` (`:2330`); superficie de `ScopeRequeueReport` | 🔴 `requeue` NO pasa por el freeze (`manager.ts:1533`); el lease único (`spec:2460`) | **medio** | **verificable con cambios** (definir R-3 y R-2b) |
| **4** | Edad de la cola | **10** | contrato +1/+2 pares; puerto `+createdAt?`/`oldestPending?` | 🔴 `clock.spec.ts` (grep de `new Date()`); «un 503 no consume intento» | **medio** | **verificable** (`oldestPendingAt` barato; `parkAfterMs` trae E-8) |
| **5** | `origin` en `entries` | 4 | ampliar `spec:1845` | — | bajo | verificable |
| **6** | `dead` bajo `only` | 4 | — (corrección factual: el `actor` no fuga) | la alarma de `dead` si se omite | bajo | verificable |
| **7** | `enqueue` sin trx ⇒ 500 | 3 | **decenas** si el gate es default | la mitigación del rollback | bajo (opt-in) / **alto** (default) | verificable |
| **8** | Trx cerrada ⇒ `E_AUTHZ_CONFIG` | 4 | — | paridad de los 3 puertos con `{transaction}` | bajo | verificable |
| **9** | `enumerateRelationsMany` | 1 (capacidad) / 4 (nativo) | — | — | bajo/medio | verificable |
| **10a** | `waitForLeaseMs` | 4 | 🔴 releer `spec:2460` | el escritor único | medio | verificable |
| **10b** | 422 sin servidor + `maxDepth=N+1` | 5 | `scope_depth.spec.ts:143-156` (aditivo) | — | bajo | verificable |
| **10d** | opción desconocida ⇒ 500 | 1 | — | — | bajo | verificable |

**Total: ~64 casos nuevos**, +3 casos del contrato del puerto (`EXPECTED_CASES` 15 → 18), 2 campos
opcionales de puerto, 1 método opcional, 1 posible migración (punto 2). Sin infraestructura nueva:
todo cabe en `tests/scope_outbox.spec.ts`, `src/testing/scope_outbox_contract.ts`,
`tests/scope_outbox_multiprocess.spec.ts` (W-4, R-2b), `tests/scope_depth.spec.ts` (10b),
`tests/capabilities.spec.ts` (9) y `tests/commands.spec.ts` (R-10, E-10).

---

## Lo que NO es verificable con la infraestructura de hoy

1. **La edad REAL entre réplicas con relojes desviados.** `created_at` lo sella el **cliente**
   (`scope_outbox.ts:330`, `options.now`), no la base. Con dos procesos y NTP desviado la edad puede
   salir negativa o inflada, y **ningún test puede observar el skew de verdad** (el reloj inyectado
   solo simula). Lo observable es la **defensa** (E-6: nunca negativa) y lo declarable es la letra:
   «la edad es del reloj de quien encoló». Alternativa que sí sería observable: sellar `created_at`
   con el reloj del SERVIDOR (`CURRENT_TIMESTAMP`) — pero eso rompe la inyectabilidad y por tanto
   E-1/E-9. **Es un trade-off que el arquitecto tiene que resolver, no yo.**
2. **El mutex de `app` con concurrencia real de tenants.** Los casos A-* miden la decisión del relay,
   no la carrera. La carrera (dos altas simultáneas con el store caído) solo se observa con dos
   procesos y `sqlScopeOutbox` en PG/MySQL — la infra existe
   (`scope_outbox_multiprocess.spec.ts`, `helpers/relay_child.ts`) pero **hoy no hay ningún caso de
   ese fichero sobre `parkedKeys`**, y montarlo cuesta más que los 9 casos de §1. Lo dejo declarado,
   no propuesto.
3. **`superseded` como estado del árbol del store.** Que la aparcada superseded **no** deje deriva se
   demuestra de verdad contra el `:8101` (leer la arista `#parent` real), no con el driver espía. El
   grupo contra servidor real existe (`spec:3285`) pero exige `OPENFGA_TEST_URL`; sin él, S-1/S-2 son
   sobre el espía y **no** prueban que el árbol quede bien. Con `memoryScopeTree` + `sqlScopeTree`
   (`src/testing/scope_tree.ts`) se cubre la mitad SQL, no la del store.
4. **El coste del lease bajo `waitForLeaseMs`** (cuántas conexiones quedan ocupadas esperando): es una
   propiedad de pool, y `pool_concurrency.spec.ts` mide otra cosa. Observable solo como número en un
   log, no como aserción. Lo diría en el README, no en un test.
5. **Invariante 13 sobre el relay** (una escritura de árbol que vence el deadline es indeterminada):
   sigue sin runner publicado (⚪ 11 del auditor, `roadmap-2.0.md` Diferido 2.6+). Ninguno de los diez
   puntos lo toca, pero `{ apply: true }` (R-6/R-7) es la primera vez que un COMANDO escribe árbol
   fuera de una pasada de relay: si algún día se juzga el 13, R-6/R-7 son sus hermanos.

---

## Anexo · Cómo reproducir

```
cd /tmp/claude-1000/-home-jose/66ad04a0-.../scratchpad
node --import @poppinss/ts-exec r2_rojo1.ts   # mutex de `app` (bloques A/B/C/D)  -> r1.out
node --import @poppinss/ts-exec r2_rojo3.ts   # P14 requeue + `{apply:true}` ignorado -> r3.out
node --import @poppinss/ts-exec r2_rojo4.ts   # B2: 10 pasadas, attempts 0, sin edad -> r4.out

cd mut1                                        # copia del paquete, node_modules enlazado
node --import @poppinss/ts-exec bin/test.ts --files="scope_outbox"   # baseline 100/100
#   con la exención de `app` en los 3 sitios: 100/100 y 1026/1026 (suite completa)
#   con `#changeKeys => []`:                   82/100 (18 rojos)
```
