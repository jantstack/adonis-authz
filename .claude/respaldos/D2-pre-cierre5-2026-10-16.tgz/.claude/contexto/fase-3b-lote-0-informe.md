# Fase 3b · Lote 3b-0 — «simplificar antes de añadir» (Z1, Z2, Z3, D7)

> Rama `v2/fase-3b`, base `9675e64`, árbol limpio al empezar. **Sin commits.**
> Node 22.23.2 · motores: OpenFGA `:8101`, PostgreSQL 18 (`postgres18`), MySQL 8.4 (`mysql84`).
> Informe incremental: se fue escribiendo a la vez que el lote.

## 0. Titular

`scopes.detached` vuelve a purgar **hechos y solo hechos** (invariante 11). Todo lo que la Fase 3 le
había colgado encima —policy de rango por rol, enumeración de descendientes para roles, degradación,
`truncated`/`reason`, `ScopeDetachOutcome`, la dependencia de `purgeRole`— **se ha borrado**. La
limpieza de los roles cuyo owner desaparece pasa a un comando de plataforma nuevo,
`authz:catalog:prune-orphans`.

**Métrica del lote: −344 líneas netas** en el árbol versionado (+391 / −735 en los ficheros tocados,
más 56 líneas nuevas del comando `commands/authz_catalog_prune_orphans.ts`, sin versionar todavía).
Desglose:

| Familia | + | − | Neto |
|---|---:|---:|---:|
| `src/` + `index.ts` | 221 | 462 | **−241** |
| `tests/` | 127 | 291 | **−164** |
| `CLAUDE.md` / `README.md` / `CHANGELOG.md` | 101 | 41 | +60 |
| `commands/main.ts` | 1 | 0 | +1 |
| **Total versionado** | **450** | **794** | **−344** |

Código de producción y suite: **−405 líneas**. Lo único que crece es la documentación (que además
tenía que borrar tres párrafos de promesas que ya no son ciertas) y el comando nuevo.

---

## 1. Z1 — el rol dormido

### 1.1 Qué se ha borrado

En `src/manager.ts`:

- **`#purgeRolesOwnedBy`** (≈ 60 líneas con su docblock): leía los roles del owner y del subárbol,
  decidía `truncated`, aplicaba la policy de rango y purgaba rol a rol.
- **`#assertAboveOwnedRoles`** (≈ 50 líneas con su docblock): la policy de rango de 3G · W1, con su
  memo por owner, su `resolveChain` por owner distinto y su bandera `skipped`.
- La llamada a `#descendantsOrDegrade` desde `detached`, la llamada a `#optional(driver, 'purgeRole',
  'scopes.detached')`, y los campos `reason`/`truncated` del evento `scope_purged`.
- El campo `declared` de `#descendantsOrDegrade` (solo lo consumía `detached`).
- El import de `readRolesOwnedBy`.

En `src/types.ts`:

- **`ScopeDetachOutcome`** entero (−32 líneas). **Decisión: desaparece, no se simplifica.** Un
  `{ purgedRoles, truncated, reason? }` sin roles que purgar es un objeto de tres campos que siempre
  vale lo mismo; y un tipo exportado que nadie puede usar para decidir nada es deuda. `scopes.detached`
  vuelve a `Promise<void>`, que es lo que era hasta 3E. Se retira también de `index.ts`.
- Los campos `reason` y `truncated` de `AuthzWriteEvent` (−24 líneas): solo salían en `scope_purged`.
- El comentario de `AuthzCatalogWriteEvent.actor` deja de hablar del actor «que arrastra
  `scopes.detached`»: ahora el único `role_purged` sin actor es el de `prune-orphans`.

En `src/catalog_cache.ts`: `readRolesOwnedBy(ownerKeys)` → **`readLocalRoles()`** (−20 líneas netas):
sin la lista de owners, sin el troceado en lotes de 500 para el `IN` y sin el re-ordenado tras
concatenar los lotes. Se conserva lo que importa: se lee de la BASE (no del memo con ventana) y el
orden es estable por uuid (3F · U5).

### 1.2 Lo que NO se ha tocado, y por qué

**La comprobación de colisión (`#assertNoRoleCollision`) se queda como está.** La pieza pedía «que
los roles cuyo owner no resuelve dejen de bloquearla», y lo medí antes de tocar nada
(`scratchpad/z0_bloqueo.ts`, sobre el driver `database`, con la fila de `u1` borrada del árbol):

| caso | hoy |
|---|---|
| (a) define `lead@unit` en `u2`, **hermano** del owner huérfano | **entra** (no bloquea) |
| (b) define `lead@unit` en `orgA`, **ancestro** del owner huérfano | **entra** (no bloquea) |
| (c) define `jefe@team` en `t1`, descendiente VIVO cuya ruta sigue pasando por `u1` | 422 `E_AUTHZ_CATALOG_CONFLICT` («es un ancestro») |
| (d) `syncAuthzCatalog` mete el global `lead@unit` | **entra**, lo reporta como `shadowedByGlobal` (3E · P1 b) |
| (e) `deleteScopedRole` del huérfano | 422 `E_AUTHZ_UNKNOWN_SCOPE` ← **esto es lo que había que arreglar** |

La razón es estructural: el conjunto `ancestors` con el que `#assertNoRoleCollision` decide sale de
la cadena **ya resuelta** del owner nuevo, así que un homónimo solo bloquea cuando su owner está en
esa cadena — es decir, **cuando es VISIBLE desde el owner nuevo**, que es exactamente el conjunto que
`roleVisible` usaría para responder `E_AUTHZ_AMBIGUOUS_ROLE`. Un rol *dormido de verdad* nunca cae
ahí. Y el caso (c) es el único donde un huérfano bloquea, precisamente porque **ahí no está dormido**:
es el árbol incoherente de D4 (`t1` conserva su ruta materializada por `u1`), donde el rol sí concede
y sí es membresía. Ignorarlo habría creado una ambigüedad real en `t1` — dos `jefe@team` visibles, con
toda ruta por slug muerta ahí abajo — para arreglar un bloqueo que el barrido de Z2 resuelve
deterministamente y sin ambigüedad. **Se dejó como está a propósito: la regla que ya corría es la
correcta, y hacerla «más permisiva» era el fail-open.**

**El sync tampoco se toca**, por la misma medición (d) y porque no bloquea nada: escribe el global y
reporta. Además, darle un `resolveChain` a `syncAuthzCatalog` significaría resolver el árbol **dentro
de la transacción que sostiene el cerrojo de `authz_catalog_version`** — exactamente lo que el
re-chequeo de M2 evita a propósito («un abrazo mortal con un pool de 1»). El ruido de
`shadowedByGlobal` por un huérfano lo quita `prune-orphans`.

**D4 queda resuelto por «irrelevante», no por «cierto».** Hacer cierta la frase («un rol cuyo owner no
resuelve no es visible en ninguna parte») exigiría un `resolveChain` por rol dentro de `authorize` y
dentro del SQL de `whereVisibleAssignmentIn`: inaceptable y fuera de lote. Lo que se ha hecho es
quitarle todo peso: la única pieza que decidía algo apoyada en esa premisa era
`#assertAboveOwnedRoles`, y ya no existe. Está escrito así en `CLAUDE.md` y en el `CHANGELOG`.

### 1.3 Rojo → verde

El «rojo» de Z1 es el caso nuevo `3b-0 · Z1` de `tests/manager.spec.ts`. Contra el código de
`9675e64` (con `git stash push -- src index.ts commands`):

```
❯ manager — roles locales a un scope (3B · B3) / 3b-0 · Z1: scopes.detached purga los HECHOS…
ℹ RankExceededError: El actor no tiene ningún rol vigente en la cadena de ese scope (rank 0),
  así que no puede tocar los roles locales que hay ahí: hace falta rank mayor que el del rol.
 ⁃ at AuthorizationManager.#assertAboveRole (src/manager.ts:1442:13)
Tests  1 failed (1)
```

Verde con el lote aplicado. El caso fija: `detached` con un **alias del uuid** purga los hechos con la
identidad canónica; purga también los denies; **no toca el nieto**; el rol del owner y el del subárbol
**siguen en el catálogo** con `descendantsOf` declarado; no se notifica ningún `role_purged`; y el rol
se puede volver a asignar y concede. Un actor de rank 0 hace todo eso, porque purgar hechos lo
gobierna `within` (invariante 15) y no el rango.

---

## 2. Z2 — `authz:catalog:prune-orphans`

- **Motor**: `AuthorizationManager.pruneOrphanRoles({ force? })` ⇒
  `{ orphans: Array<{ role, owner, permissions }>, purged, dryRun }`.
  Lee **todos** los roles locales de la base (`readLocalRoles`), resuelve **un `resolveChain` por owner
  distinto** (memoizado) con el resolutor FRESCO, y los que devuelven `null` son los huérfanos. Con
  `force`, cada uno se purga con el `purgeRole` del puerto (atómico: asignaciones + vínculos + fila +
  versión, vía `withAuthzCatalogWrite` dentro del driver) y se notifica `role_purged` **sin actor**.
- **Comando**: `commands/authz_catalog_prune_orphans.ts`, `--dry-run` por defecto (`--force` para
  borrar), registrado en `commands/main.ts`. Imprime rol, uuid, rank, owner y permisos.
- **Es de plataforma**: sin actor y sin rango, como el `purgeRole` de último recurso que el README ya
  prometía. Esa es la decisión de diseño del lote: la limpieza deja de colgar de una escritura que
  dispara un TENANT sobre un scope que ya no resuelve, que es lo que metía el rango en la ecuación.
- **Fail-closed relevante**: sin `scopes.resolveChain` en el config ⇒ 500 `E_AUTHZ_CONFIG` **antes de
  leer nada**. Sin árbol solo existe `app`, así que TODO owner local «no resolvería» y una pasada con
  `--force` se llevaría el catálogo local entero. Tiene su aserción en el caso `3b-0 · Z2`.
- Un driver sin `purgeRole` (openfga hasta 3b) ⇒ 500 `E_AUTHZ_UNSUPPORTED` antes de leer nada
  (caso `whenFalse` del juez).
- **Rojo → verde**: contra `9675e64`, `TypeError: authz.pruneOrphanRoles is not a function`.

El caso `3b-0 · Z2` fija además: idempotencia (segunda pasada `purged: 0`), que la lista sale de la
BASE y no del memo con `{ everyMs }` (un rol confirmado por «otro proceso» aparece), el orden estable
por uuid, el owner correcto por rol en el evento, que el rol de un owner VIVO no se toca, y que el
`(slug, nivel)` liberado deja entrar un global del deploy sin ensombrecer a nadie.

---

## 3. Z3 — la prueba de que sobraba

**Ningún caso se puso rojo por una razón de seguridad.** Todo lo que se borró dejó de aplicar porque
la superficie que juzgaba no existe.

### 3.1 Casos del juez borrados (`src/testing/contract.ts`)

| Caso | Por qué deja de aplicar |
|---|---|
| `'2.2'` **`scopes.detached purga también los roles LOCALES cuyo owner es ese scope (3D · M4)`** | Juzgaba justo lo contrario de lo que ahora es cierto. **Sustituido** por `scopes.detached purga los HECHOS del scope y SOLO los hechos (invariante 11)…`, que fija la superficie nueva: hechos purgados, catálogo intacto, rol dormido (no concede, no es membresía, no se asigna) y `pruneOrphanRoles` como salida en dos tiempos. |
| `'2.2'` **composición 3G · W4 (i)** — `detached` de un ancestro desconocido con `descendantsOf` y descendientes vivos | Toda su tesis es «el rango se mide en la cadena del owner de cada rol». Ya no hay rango que medir en `detached` ni roles que purgar: el ataque que juzgaba (destruir el rol rank 80 de una unit viva) es **imposible por construcción**, no por una comprobación. |
| `'2.2'` **composición 3G · W4 (ii)** — cota superada ⇒ degrada, pero el rango corre sobre el scope exacto | Compone `truncated` con la policy de rango de `detached`. Las dos piezas se han borrado. La degradación que queda (`#descendantsOrDegrade`) ya solo alimenta la regla de NIVEL, que tiene su caso propio (3F · S2) y el de composición W4 (iii). |
| `'2.2'` **composición 3G · W4 (iv)** — `descendantsOf` que falla purga solo lo demostrable | Igual: `detached` ya no enumera nada ni purga roles, así que «degradar nunca da más poder que enumerar» no tiene sujeto. |
| `'2.2'` `sin purgeRole…` (`whenFalse`) puntos (3) y (4) | **Editado, no borrado.** Fijaban que `scopes.detached` de un scope con roles locales era 500 y que la salida era borrar la fila a mano. Ahora `detached` no necesita `purgeRole`: purga los hechos con normalidad y deja el rol. En su lugar se juzga eso, y que la operación que **sí** lo necesita (`pruneOrphanRoles`) lo diga con 500 sin tocar nada. **El callejón sin salida de 3B/3E desaparece del todo.** |

**Sigue verde y sin tocar el caso 3G · W4 (iii)** (`defineScopedRole` que ensombrece con el subárbol
por encima de la cota): ahí sí siguen componiéndose dos reglas vivas —la regla de nivel degradada y el
rango sobre el ensombrecido—, así que se queda como único caso de composición.

### 3.2 Casos de `tests/manager.spec.ts` borrados

| Caso | Por qué |
|---|---|
| `3E · P2/P3 (auditor A2/A3/A4)` | **Sustituido** por `3b-0 · Z1` + `3b-0 · Z2`, que conservan sus dos piezas todavía vigentes: la identidad **canónica** del alias (ahora sobre los hechos, que es donde vive) y la lectura **de la BASE** en vez del memo con ventana (ahora en `prune-orphans`), con el orden estable por uuid y el owner por rol en el evento. Lo que se pierde es lo que juzgaba la policy de rango de `detached`. |
| `3F · S1 (auditor N2)` | Su tesis: «el `detached` de un scope que el árbol ya no conoce purga igual, saltándose el rango y diciéndolo». Sin rango y sin `reason`, lo único que queda es «purga los hechos», que ya está en el grupo `manager.scopes` y en el juez desde 2.0. |
| `3G · W1 (auditor P1)` | El rango por rol en la cadena del owner. Borrado con la policy. |
| `3G · W2 (auditor P2)` | `truncated: true` / `reason` con `purgedRoles: 0`. Borrado con el valor de retorno. |
| `3F · S2 (auditor N3)` | **Recortado**, no borrado: se queda la mitad que sigue viva (la regla de NIVEL degrada a la mínima con la cota superada y con un `descendantsOf` que falla, y lo que la regla mínima sí cierra sigue cerrado). Se borra la mitad de `scopes.detached` (partes 2 y 3). |

`tests/contract_harness.spec.ts` actualizado: `withPurge` pasa de `scoped + 8` a `scoped + 5` y los
casos `composición (3G · W4…)` de 4 a 1, con el porqué escrito en el propio comentario del test.

### 3.3 Un cambio de comportamiento que hay que decir en voz alta

Con `requireWithin: false` (config opt-in que el paquete ya avisa por consola), **un actor sin rango
en un tenant ajeno puede ahora purgar los HECHOS de un scope de ese tenant que tenga roles locales**;
antes la policy de rango de `detached` lo paraba con 422. No es una capacidad nueva: el mismo llamante
ya podía hacerlo con cualquier scope **sin** roles locales (lo midió el propio auditor en `x6` y en
`y3` §C, y lo cita en el steelman de D4 como «un martillo mayor y documentado»). Lo que había era una
protección **accidental e inconsistente** —dependía de que el scope resultara tener roles locales—
sobre una operación cuya barrera diseñada es `within` (invariante 15). Con `requireWithin: true` /
`'non-root'` la puerta está cerrada igual que antes (422 `E_AUTHZ_NOT_WITHIN` o
`E_AUTHZ_UNKNOWN_SCOPE`). Y a cambio se cierra un canal: ver §5, `x6`/`y3` §C.

---

## 4. D7 y documentación

- **D7**: `src/types.ts` tenía dos docblocks seguidos de `ScopeDescendantsResolver` y el viejo
  contradecía al nuevo sobre qué se espera al pasarse de `maxNodes`. **Queda uno**, reescrito: incluye
  el contrato de W2 que sí sigue siendo cierto (el consumidor es la autoridad sobre su tabla) menos la
  parte de `scopes.detached`, y dice explícitamente que `detached` ya no lo llama.
- **`CLAUDE.md`**: invariante 18 reescrito (el párrafo de M4/P2/P3/S1/S2/W1/W2 → un párrafo «rol
  dormido + barrido de plataforma» con el porqué de la simplificación y con D4 declarado irrelevante);
  mapa de `src/manager.ts`, `src/catalog_cache.ts` y `commands/` actualizado; entrada de 3b-0 en el
  roadmap.
- **`README.md`**: fuera `ScopeDetachOutcome` (dos sitios), fuera el párrafo de la policy de rango de
  `detached` y los tres bullets de la purga del subárbol; entra «When a scope disappears, its roles
  fall asleep — and the platform sweeps them» con el comando y un párrafo «Why it is not
  `scopes.detached`'s job». Corregidas las dos filas de la tabla de errores
  (`E_AUTHZ_RANK_EXCEEDED`, `E_AUTHZ_UNSUPPORTED`) y la receta del cambio de driver (ya no hay
  congelación de hechos). `prune-orphans` añadido al bloque de comandos.
- **`CHANGELOG.md`**: entrada `Lot 3b-0` con problema → decisión → qué NO se hace y por qué, marcada
  **breaking** (`scopes.detached` ⇒ `void`, `ScopeDetachOutcome` retirado del export público).

---

## 5. Verificación

### 5.1 Suites (todas verdes, sin skip ni only)

| Suite | Resultado |
|---|---|
| `npm test` (SQLite memoria) | **414 passed** |
| `OPENFGA_TEST_URL=http://localhost:8101 npm test` | **516 passed** |
| `npm run test:sqlite-file` | **416 passed** |
| `TEST_PG_URL=… OPENFGA_TEST_URL=:8101 npm run test:pg` | **684 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` | **684 passed** |
| Tope 3 (`openfga-tiny` :8103, `LIST_*_MAX_RESULTS=3`, memoria) | **516 passed** |
| `npm run typecheck` / `npm run build` / `check:purity` | verdes |

(El contenedor `openfga-tiny` se borró al terminar. Las bases `authz_test_*` que dejaron los scripts
del auditor se borraron: 0 en PostgreSQL, 0 en MySQL.)

### 5.2 Scripts del auditor (`v8`, `v9`, `v10`, más `v6/repro5_resiste`)

Copiados al scratchpad (`…/scratchpad/{v6,v7,v8,v9,v10}`), **los originales no se han tocado**.
`v7` hizo falta porque `n4_race` lanza su proceso hijo desde ahí. Motor `pg` + `:8101`.
**Ninguno muestra un ataque que funcione.**

**`v8/n1_nivel`** — idéntico a 3G: la regla de nivel con y sin `descendantsOf`, el dueño del árbol
recupera el nombre, el sync entra entero.
```
    unit (el del OWNER) = {...}
    organization (ANCESTRO) -> 422 E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER
    app (la RAÍZ) -> 422 E_AUTHZ_INVALID_IDENTITY
  (2) CON descendantsOf: galaxia/proyecto -> 422 E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER
    orgA (dueño del árbol) define SU n-galaxia@galaxia = {...}
```

**`v8/n2_p4`** — el driver sin `purgeRole`. Cambia una línea, **a mejor**:
```
    openfga: deleteScopedRole(heredado) -> 500 E_AUTHZ_UNSUPPORTED
    openfga: scopes.detached(U1) [el scope entero] = undefined      <-- antes: 500
  filas de heredado tras los intentos: 1
  ¿siguen los HECHOS del scope? authorize = false                  <-- antes: true
```
El callejón que 3B abrió y 3E cerró «por la otra punta» ya no existe: los hechos se purgan con
cualquier driver.

**`v8/n3_shadow`** — sin cambios (5/5 slugs globales muertos por slug dentro del subárbol ocupado,
`effectivePermissions(holderLocal) = ["docs:read"]`, sin escalada, y la limpieza los devuelve).

**`v8/n4_race`** (dos procesos reales, PG) — sin cambios:
```
  A/B (dos define): siempre 1 fila y 1 ganador? true · perdedor 422 CATALOG_CONFLICT exacto? true
```

**`v8/n5_indeleteable`**, **`v8/n6_actor_sin_within`**, **`v8/n7_cotas`** — el rol huérfano sobrevive
(`filas de ocupa: 1`, `filas de v5: 1`, `filas de purga: 1`) y los **hechos** se purgan
(`asignaciones: 0`, `denies vivos: 0`). Es la semántica nueva, medida. La salida documentada (el
`purgeRole` a mano, y ahora `prune-orphans`) sigue funcionando.

**`v9/x1c_detached`** — el ataque de P1, ya sin superficie:
```
    ATAQUE: scopes.detached(orgA, {actor: adminU1}) = undefined
  filas de "caro": 1 · asignaciones: 0
  la unit sigue viva: 3 elementos
```

**`v9/x1b_detached`** — igual: `filas de "caro": 1` tras el ataque. (El proceso no termina solo: el
script no llama a `process.exit`; salió todo por pantalla.)

**`v9/x4_truncated`** — la conclusión que imprime el script («el retorno dijo truncated:false») ya no
tiene sujeto: no hay retorno. Lo observable es lo mismo que en 3G para los HECHOS —`detached(orgB)`
purga `orgB`, no `unitB1`, invariantes 7 y 11— y lo que el script llamaba «el rol del subárbol sigue
vivo» ahora tiene una salida determinista que antes dependía de que `descendantsOf` contestara:
`authz:catalog:prune-orphans`.

**`v9/x6_canal` y `v10/y3` §C — el canal lateral de W2 se cierra**:
```
    scopes.detached(a1,   {actor: forasteroB}) = undefined
    scopes.detached(orgA, {actor: forasteroB}) = undefined
    detached(scope INEXISTENTE del árbol, actor forasteroB) = undefined
```
En 3G la respuesta era `{"purgedRoles":0,"truncated":true,"reason":"owner-detached-unknown"}`, que
revelaba «el árbol no conoce este scope». Ahora no devuelve nada: **cero bits**. (Y ningún 422 que
nombre catálogo ajeno: X5 sigue en pie, no hay mensaje que nombrar.)

**`v10/y1_owner_desconocido` — el hallazgo D4, desactivado**:
```
    la otra puerta: deleteScopedRole(forastero, caro) -> 422 E_AUTHZ_UNKNOWN_SCOPE
    ATAQUE: scopes.detached(u1, {actor: forastero rank 0}) = undefined
  filas de "caro": 1 · asignaciones: 0
```
Antes el forastero de rank 0 **destruía** el rol de rank 40 (`purgedRoles: 1`). Ahora no puede: la
fila sigue. Lo que hace es purgar los hechos de `u1`, que es la puerta que gobierna `within`.

**`v10/y2_w3`** — D1, D2 y D3 **siguen abiertos tal cual** (son del lote 3b-1, no de este): §A el
fail-open de `#shadowedBelow` con `chain === null`, §B la sombra que aparece con `scopes.moved`, §C
el dueño del árbol que no puede ensombrecer al squatter de más rango y la plataforma que sí. Ninguno
empeora. W3 por la puerta directa sigue cerrado:
```
    control: defineScopedRole(pobre rank 10, orgA, critico@unit rank 5) -> 422 E_AUTHZ_RANK_EXCEEDED
    orgAdmin (rank 50, DUEÑO del árbol) define su mina@unit -> 422 E_AUTHZ_RANK_EXCEEDED
    la PLATAFORMA (rank 100) sí ensombrece = {...,"rank":60}
```

**`v10/y3` §A/§B** — la carrera sigue teniendo exactamente los dos finales legales y un solo ganador:
```
  x8  E_AUTHZ_CATALOG_CONFLICT | OK  ->  base: unit#40
  x4  OK | E_AUTHZ_CATALOG_CONFLICT  ->  base: organization#5
  (B) mismo owner: filas: 1 en 2/2
```

**`v6/repro5_resiste`** — **22 barreras, 22 `ok`, 0 `ROTO`** (rango, deny en ancestro, `assignableAt`,
tenant hermano, raíz, globales inmutables, actor ausente…).

Los scripts que mueren a mitad (`v9/x1_detached_mentira` (c), `v9/x3_degrada` §5, `v9/x5_reparacion`,
`v10/y2_w3` §D, `v10/y3` §C final) lo hacen por **defectos propios ya declarados por el auditor en
3G** —un `deleteScopedRole` con el objeto del rol donde va el uuid, y `defineScopedRole` con un actor
sin el permiso efectivo en esa cadena—, agravados en algunos por que el bloque «control» que los
precede ahora **no lanza** (antes era 422 y el script seguía con el estado intacto). Ninguno esconde
un ataque: en todos, el estado observado antes de morir es el correcto.

---

## 6. Estado y lo que queda para 3b-1

- Lote **cerrado y verde** en los cuatro modos + `:8101` + tope 3. Sin commits (los hace el dueño).
- **Desaparecen** de la lista del auditor, por construcción: **D5** (`reason` que significaba dos
  cosas) y **D6** (el coste O(owners) sin cota de `scopes.detached`). **D4** queda resuelto como
  «irrelevante» y con la frase corregida en los tres sitios que la publicaban. **D7** hecho.
- Siguen abiertos y son del lote 3b-1: **D1** (la frase de X1 sobre la reparación por
  ensombrecimiento), **D2** (`#shadowedBelow` con `chain === null` trata «no demostrable» como «no hay
  sombra»), **D3** (escribir W3 como comprobación de escritura y no como invariante) y **T-3b**.
  Aviso para D2: la corrección natural («si no se puede demostrar, rechaza») convierte un rol
  **dormido** en un bloqueo de slug; con Z1 hay ahora una respuesta mejor y ya escrita —el que no
  resuelve no ensombrece, y si estorba se barre con `prune-orphans`—, así que conviene decidir D2
  contra esa opción y no contra «rechazar siempre».
