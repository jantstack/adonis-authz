# Fase 0 · Desbloqueo del juez — plan con criterios de aceptación

> Rama `v2/fase-0`. Objetivo: que el juez de contrato (`src/testing/contract.ts`) pueda crecer sin romper a drivers de terceros, que pruebe el invariante 1 (herencia) de verdad, y que la CI vea lo que hoy no ve. **No cambia el comportamiento de ningún driver**: solo infraestructura de test, CI y casos que pasan hoy (o que hoy pasan en falso y deben pasar de verdad).
>
> Regla de garantía: cada pieza se entrega con (1) el test que la demuestra, (2) `npm test` + `npm run typecheck` en verde, (3) `OPENFGA_TEST_URL=http://localhost:8101 npm test` en verde. Las piezas se marcan ✅ en la tabla final con el número de tests antes/después.

## Estado de partida (medido 2026-08-28)
- `npm test`: 40/40 · con OpenFGA: 67/67.
- El resolutor de ancestros por defecto es plano (`tipo ≠ app → [app]`): **ningún test inyecta `resolveAncestors`**, así que el invariante 1 solo se prueba con cadenas de longitud 2. Casos 9, 15, 16 pasan en falso en un modelo con árbol real; 10, 11, 14, 18, 19 fallarían.
- `listSubjects`/`listScopes` usan `includeMembers`/`notInclude` (`contract.ts` ≈ líneas 228-229, 245-246): un `list*` que enumere herencia pasaría.
- Invariante 8 (`rank` no se evalúa) sin ningún test. Re-deny sin aserción de no-duplicado.
- `check:purity` no corre en `npm test` ni en el job `test`.
- El harness openfga crea un store por test y **nunca lo borra** (92 acumulados en `:8101`).
- CI: un solo OpenFGA (`v1.18.1`, `:8090`, defaults). Sin `MAX_RESULTS` pequeño no se puede reproducir el truncamiento de L0.7.

## Piezas

### F0.1 · Firma del harness con `level` y `capabilities` y árbol
```ts
export interface DriverCapabilities {
  hierarchyFacts: boolean        // el driver materializa el árbol como hechos propios (2.2)
  transactions: boolean          // acepta {trx} externa (2.x)
  truncationSignal: boolean      // los list* lanzan si el backend trunca (L0.7)
  singleCheckAuthorize: boolean  // authorize = 1 llamada al backend (facts)
  injectableClock: boolean       // acepta now() inyectado (Fase 2.5)
}
export interface ContractScopeTree {
  attach(child: ScopeRef, parent: ScopeRef): Promise<void>
  move(child: ScopeRef, newParent: ScopeRef): Promise<void>
  detach(child: ScopeRef): Promise<void>
  ancestorsOf(scope: ScopeRef): Promise<ScopeRef[] | null>   // null = desconocido
  edges(): AsyncIterable<{ child: ScopeRef; parent: ScopeRef }>
}
export interface DriverContractHarness {
  name: string
  level?: 'core' | '2.0'                 // default 'core': solo los casos de 1.x
  capabilities: DriverCapabilities
  seedCatalog(catalog: CatalogSpec): Promise<void>
  makeTree(): Promise<ContractScopeTree> // default exportado: memoryScopeTree()
  makeDriver(tree: ContractScopeTree): Promise<AuthorizationDriver>
  cleanup(): Promise<void>
}
```
- Orden en `group.each.setup`: `cleanup → seedCatalog → makeTree → makeDriver(tree)`.
- `memoryScopeTree()` exportado desde `src/testing/main.ts`: `Map` hijo→padre; `ancestorsOf` sube hasta `app`; `attach` de un hijo ya existente = `move`; `detach` borra el nodo y sus descendientes del mapa; anti-ciclo: `attach/move` lanzan si `parent ∈ descendientes(child)` o `child.type === 'app'` (es el árbol de TEST el que garantiza ser árbol; el paquete lo hará en Fase 1/3b).
- Los harness de `tests/contract.spec.ts` inyectan `resolveAncestors: (s) => tree.ancestorsOf(s).then(r => r ?? [APP_SCOPE])` a ambos drivers (hoy el driver no entiende `null`; L0.3 es Fase 1).
- `level`: los casos nuevos de esta fase se registran con `level: '2.0'`; un harness sin `level` corre solo los 19 originales (reescritos sobre `tree`, que es transparente para él).
- **Regla de capacidades**: por cada capacidad, la suite tiene un par de casos `{ whenTrue, whenFalse }`; **jamás un `skip`**. En esta fase se implementa el mecanismo (`caseFor('truncationSignal', { true: ..., false: ... })`) y se registran los pares que ya son observables (ver F0.4). Capacidades cuyos pares llegan en fases posteriores quedan documentadas como "pendiente de Fase N" en un comentario, sin caso vacío.
- Ambos harness declaran hoy: `{ hierarchyFacts: false, transactions: false, truncationSignal: false, singleCheckAuthorize: false, injectableClock: false }`. (openfga con `truncationSignal:false` es la verdad de hoy; L0.7 la cambia en Fase 1 con su par rojo→verde.)
- **Aceptación**: `npm test` y con OpenFGA en verde; `tsc` en verde; el harness `database` sin `level` sigue pasando; un harness de tercero escrito contra la firma 1.1 **no compila** (es 2.0: breaking documentado en CHANGELOG bajo "Unreleased").

### F0.2 · Los 8 casos dependientes del árbol reescritos sobre `tree`
Casos 9 (scope aislado), 10 (herencia app→org), 11 (deny cercano), 14 (hasRole herencia), 15 (listSubjects otherScope), 16 (listScopes), 18 (listRoles), 19 (listRoleScopes): cada `orgScope()` usado como scope real se registra con `await tree.attach(org, APP_SCOPE)` antes de usarse. Helper `const org = await orgUnder(tree, APP_SCOPE)`.
- **Aceptación**: los 8 pasan en ambos drivers; **prueba de que ya no pasan en falso**: con `memoryScopeTree` sustituido por un árbol vacío (`ancestorsOf → null → [APP_SCOPE]`... no: → `[]`), el caso 10 **falla** (demostración manual documentada en el informe del implementador, no como test permanente).

### F0.3 · Casos nuevos del núcleo (`level: '2.0'`) — todos verdes hoy en ambos drivers
| # | Caso (dado → cuando → entonces) |
|---|---|
| N1 | árbol `app→org→unit`, grant `editor@app` → `authorize(docs:write, unit)` → `true` (herencia de 2 niveles) |
| N1b | grant `org-editor@org` → `authorize(unit)` `true`; `authorize(app)` `false`; org hermana `false` |
| N2 | deny `docs:write@org` con grant en app → `unit` `false`, org hermana `true`, `app` `true`; `docs:read` en `unit` sigue `true` |
| N4 | grant `org-editor@orgA`, `unit` bajo `orgA`, `authorize(unit)=true` → `tree.move(unit, orgB)` → `authorize(unit)=false`, `authorize(orgA)=true`, **sin otra escritura** |
| N5 | grant `org-editor@orgB`, `unit` bajo `orgA`, `false` → `move(unit, orgB)` → `true` |
| N6 | grant `editor@app` → `move(unit, orgB)` → `authorize(unit)` sigue `true` |
| I8 | rol `rank:100` sin `docs:write` y rol `rank:0` con él; holder solo con el de rank 100 → `false`; solo con el de rank 0 → `true` (`rank` es metadata; el catálogo del contrato añade los dos roles) |
| I6b | `deny` dos veces → `removeDeny` una vez → `authorize` `true` (re-deny no duplica) |
| I7set | `listSubjects` y `listScopes` con **igualdad de conjunto** (`deepEqual` ordenado), sustituyendo `includeMembers`/`notInclude` en los casos 15 y 16 |
- **Aceptación**: 9 casos nuevos verdes en ambos drivers. Deferidos con nota en el código: N7/N8 (`detached` purga: necesita `purgeScope`, Fase 1), N9 (ciclo lanza en el paquete: Fase 1), A1–A6/B1–B2 (Fase 3b).

### F0.4 · Pares de capacidad observables hoy
- `truncationSignal:false` (ambos): `database` con 1.200 asignaciones directas del mismo holder → `listScopes` devuelve **1.200** y no lanza. Para `openfga` el mismo caso **con el servidor default** (1.000 de tope) devolvería 1.000 en silencio: ese es el defecto L0.7 y **no se codifica como comportamiento aceptado**; en su lugar el par `false` del openfga queda como "pendiente de L0.7" y el caso de 1.200 solo se registra para drivers con `truncationSignal:false` **y** sin backend externo (`capabilities.remoteBackend` no existe: se resuelve con un flag de harness `exhaustiveLists: true` para database). Documentar la decisión en el código.
- `hierarchyFacts:false` (ambos): **B1** — tras `tree.attach(unit, orgA)`, el driver responde según `resolveAncestors` (el árbol del consumidor), es decir el caso N1 mismo. No añade caso: se anota que N1 **es** el par `false`.
- Resto de capacidades: pares en su fase (transactions 2.5, singleCheckAuthorize 3b, injectableClock 2.5).

### F0.5 · Espías de backend (`tests/helpers/spies.ts`)
- `withFailing(obj, method, fn)` genérico (eleva `withFailingRead` de `contract.spec.ts`).
- `countCalls(obj, methods[])` → `{ counts, restore }` para knex (`db.connection().client`... o sobre el driver: `driver['client']` para FGA y un wrapper de `db` para SQL). Mínimo viable: contador sobre el cliente FGA (`check`, `batchCheck`, `read`, `write`, `listObjects`) y sobre `resolveAncestors` inyectado.
- **Aceptación**: un test en `tests/manager.spec.ts` o nuevo `tests/spies.spec.ts` que use el contador de `resolveAncestors` para afirmar que `authorize` con cadena de 3 lo llama **exactamente 1 vez** en ambos drivers (documenta el coste actual; en Fase 2 el memo lo bajará y este test cambiará conscientemente).

### F0.6 · Teardown de stores OpenFGA
- El harness openfga guarda los `storeId` que crea y los borra en `group.teardown` (`DELETE /stores/:id` vía SDK `deleteStore`). También los grupos `regrant-*`.
- **Aceptación**: `curl :8101/stores | jq '.stores|length'` antes y después de `OPENFGA_TEST_URL=... npm test` da el mismo número. Script one-shot `scripts/openfga_prune_stores.mjs --prefix contract- --prefix regrant- --prefix authz-contract` para limpiar los 92 acumulados (ejecutarlo una vez y documentarlo).

### F0.7 · `check:purity` en `npm test` y en el job `test`
- `package.json`: `"test": "npm run check:purity && node --import @poppinss/ts-exec bin/test.ts"`.
- `scripts/check_purity.mjs`: añadir regla 2 preparada para módulos: ningún archivo bajo `src/<modulo>/` importa `src/manager.js` ni `src/drivers/*` salvo lista blanca (`src/types.js`, `src/errors.js`, utilidades en `src/shared/`). Hoy no hay módulos: la regla se implementa con una lista de módulos vacía y un test (`tests/purity.spec.ts`) que la ejercita con un fixture temporal en el scratchpad para demostrar que detecta la violación.
- **Aceptación**: `npm test` falla si se introduce `from '#config/x'` en `src/` (demostrado con fixture, no dejado en el repo).

### F0.8 · CI: segundo OpenFGA con `MAX_RESULTS=3`
- Job `openfga`: levantar dos contenedores (`:8090` default, `:8091` con `-e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3 -e OPENFGA_LIST_USERS_MAX_RESULTS=3`), esperar healthz de ambos, correr `npm test` dos veces (`OPENFGA_TEST_URL=:8090` y `:8091 OPENFGA_LIST_MAX_RESULTS=3`).
- `tests/contract.spec.ts` lee `OPENFGA_LIST_MAX_RESULTS` y lo expone al harness (`harness.limits.listMaxResults`), para que en Fase 1 el par de `truncationSignal` sepa cuántas tuplas necesita.
- Subir la imagen a `openfga/openfga:v1.19.0` (la local) en los dos.
- **Aceptación**: con el segundo servidor local (`docker run -d -p 8103:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3 -e OPENFGA_DATASTORE_ENGINE=memory openfga/openfga:v1.19.0 run`) la suite pasa 67+N/67+N. Verificado por el tester en panel 2 con `=3`: 67/67; con `=1` fallan 3 (no usar 1).

### F0.9 · CHANGELOG "Unreleased (2.0.0)" y README
- CHANGELOG: sección `## [Unreleased] — 2.0.0` con "Breaking: firma de `runAuthorizationDriverContract` (…)" y la lista de lo que entra en Fase 0. Estilo del 1.1.0: problema → decisión → qué NO se hace.
- README: **no se toca** (sigue prometiendo de más hasta Fase 1; decisión del juez).

## Lo que NO entra en Fase 0
- Ningún cambio en `src/drivers/*`, `src/manager.ts`, `src/catalog.ts` que altere comportamiento (L0 es Fase 1).
- `scopes.*`, `purgeScope`, anti-ciclos en el paquete, memo de catálogo, batch único, `reconcile`, modo `facts`.
- Tocar el README.

## Entrega
El implementador deja `.claude/contexto/fase-0-informe.md` con: tabla pieza × estado × tests antes/después × comando con el que se verificó; la demostración de F0.2 (caso 10 falla con árbol vacío); conteo de stores antes/después; y cualquier desviación del plan con su porqué. **No hace commits** (los hace el dueño tras la revisión).
