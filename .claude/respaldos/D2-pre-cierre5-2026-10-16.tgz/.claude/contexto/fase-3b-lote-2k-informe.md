# Fase 3b · Lote 2k — informe (incremental)

**Rama** `v2/fase-3b` · **HEAD de partida** `28595ec` · árbol principal, sin commits (los hace el dueño).

El lote cierra el 3b-2 en dos mitades y en este orden: **K1** deja verde el juez contra `facts`
declarando las dos divergencias que quedaban; **K2** borra el modo `resolver`.

---

# K1 · Dejar verde el juez contra `facts`

## Recuento del juez ANTES de K1

| Suite | Sin `AUTHZ_CONTRACT_FACTS` | Con `AUTHZ_CONTRACT_FACTS=1` |
|---|---|---|
| `npm test` (SQLite memoria) | 703 | **790 passed, 1 failed (791)** |
| `npm run test:sqlite-file` | 705 | — |
| `npm run test:pg` | 879 | **965 passed, 2 failed (967)** |
| `npm run test:mysql` | 879 | — |

Los rojos, literales, con `AUTHZ_CONTRACT_FACTS=1 OPENFGA_TEST_URL=http://localhost:8101`:

### R2-b · SQLite y PostgreSQL (`/tmp/…/k1-base-sqlite.log`, `k1-base-pg.log`)

```
❯ authorization contract [openfga facts · 2.2] / authorizeMany: idéntico a N authorize por
  posición (duplicados, desconocidos, denegados); vacío ⇒ [] sin backend ni árbol; un scope que
  lanza ⇒ lanza entero

Compared values have no visual difference.

ℹ AssertionError: debería haber rechazado

 ⁃ at Assert.fail (node_modules/@japa/assert/build/index.js:48:77)
 ⁃ at rejectsWith (src/testing/contract.ts:429:10)
 ⁃ at async Object.executor (src/testing/contract.ts:2161:9)
```

### R2-c · solo con el árbol SQL (PostgreSQL, `k1-base-pg.log`)

```
❯ authorization contract [openfga facts (árbol SQL) · 2.2] / un alias del uuid del scope
  (mayúsculas, guiones quitados) jamás evade un deny: o el árbol no lo conoce (false, nada, 422 al
  escribir) o resuelve al scope canónico (el deny casa y los hechos se escriben bajo la forma
  canónica)

- Expected  - 1
+ Received  + 1

- true
+ false

ℹ AssertionError: sin guiones: lo concedido sigue concedido: expected false to be true

 ⁃ at Assert.isTrue (node_modules/@japa/assert/build/index.js:117:19)
 ⁃ at Object.executor (src/testing/contract.ts:1515:16)
```

## Qué se hizo, pieza a pieza

Los dos están **decididos como divergencias declarables** (decisión del dueño del 2026-08-30 (2),
R2 (b) y (c); la CORRECCIÓN del 2026-08-31 dejó fuera (a) —cerrada por el modelo (c2r) en 2i— y la
cara de **escritura** de (c) —cerrada en 2h—). Se convierten en **pares de capacidad con caso
negativo**, nunca en un `skip`.

### Pieza 1 · R2-b sale del caso general y pasa al par `hierarchyFacts`

- `src/testing/contract.ts`: el caso general `authorizeMany` deja de afirmar «un scope que lanza ⇒
  lanza entero» para todo driver (el título también cambia). Esa afirmación pasa **íntegra** a la
  cara `whenFalse` del par `hierarchyFacts`, en un caso propio
  (*«authorizeMany con un scope cuyo árbol lanza: 503 E_AUTHZ_RESOLVER_FAILED entero, jamás un
  array parcial»*), y la cara `whenTrue` estrena su contrario, que **no es más laxo**: exige la
  respuesta EXACTA que da el árbol del store (*«… RESPONDE con el árbol del store (no hay 503)»*).
- La cara `whenTrue` del par crece con el **🟡 5 del auditor**, que era lo que faltaba decir: con el
  resolutor caído el modo es **grant-only** — `authorize` responde `true` mientras `hasRole`,
  `listRoles`, `listRoleScopes`, `listSubjects`, `listScopes`, `revoke`, `deny`, `removeDeny` y
  `purgeScope` son 503. **Concede y no se puede revocar.** El caso cierra comprobando que con el
  árbol de vuelta `revoke` vuelve a funcionar: la ventana es la caída, no un estado pegado.

### Pieza 2 · R2-c pasa a la capacidad nueva `canonicalScopeReads`

- **Capacidad nueva en el puerto** (`src/types.ts`, `AuthorizationDriverCapabilities`) y en la suite
  publicada (`src/testing/contract.ts`, `DriverCapabilities`): *las LECTURAS canonizan la ortografía
  del scope contra el árbol del consumidor antes de buscar los hechos*. `true` en `database` y en
  `openfga` modo `resolver`; `false` en `facts`.
- El caso general del alias deja de afirmar la media línea que divergía
  (`authorize(docs:write, alias)` ⇒ `true`) y conserva todo lo demás (el alias **nunca** concede lo
  denegado, las escrituras caen sobre los hechos canónicos).
- El par nuevo juzga las dos caras **en todos los motores**, no solo en PG/MySQL: en vez de depender
  de que la columna del árbol funda las dos ortografías, el caso parchea `tree.chainOf` para que las
  funda (`withAliasFused`), que es exactamente lo que hace una columna `uuid` de PostgreSQL o una
  collation `*_ci` de MySQL. Así el par tiene dientes también con el árbol en memoria.
- La cara `false` fija además que **la ESCRITURA sí canoniza** (`grant`/`revoke`/`deny`/`removeDeny`/
  `purgeScope`), que es la mitad que era fail-**open** y que cerró 3b-2h (🟠 3 del auditor R2). Sin
  eso, la capacidad se leería como «en `facts` la ortografía da igual», que es falso y peligroso.

### Pieza 3 · declaración, recuentos y documentación

- `src/drivers/database_driver.ts` y `src/drivers/openfga_driver.ts` declaran
  `canonicalScopeReads` (`true` / `!facts`); `tests/openfga_facts.spec.ts` fija las tres
  declaraciones literales.
- `tests/contract.spec.ts`: `CAPABILITIES_TODAY.canonicalScopeReads = true`, el harness `facts` la
  declara `false`. El docblock que enumeraba «lo que sigue rojo» dice ahora qué se cerró y cómo.
- `tests/contract_harness.spec.ts`: `NONE` la declara `false` y los recuentos literales del juez
  suben (ver abajo).
- README, CHANGELOG y `CLAUDE.md`: las dos divergencias, con las palabras del auditor y sin
  eufemismos.

## Rojo→verde por pieza: los mutantes

Los dos casos que ya estaban rojos son la prueba de las caras `whenTrue`/`whenFalse` que los
sustituyen sobre `facts`. Para las caras que **no** estaban rojas se provocó el rojo con mutantes y
se restauró el código (los tres restaurados; `git diff` limpio de mutantes).

### Mutante M1 — `factsAuthorize`/`factsAuthorizeMany` vuelven a pasar por el árbol del consumidor

```ts
// en src/drivers/openfga_driver.ts
const mutantChain = await this.chain(scope, 'authorize')
if (!mutantChain) return false
scope = mutantChain[0]
```

```
❯ [openfga facts · 2.2] / `authorize` no consulta el árbol del consumidor (0 resolveChain) …
ℹ AssertionError: y sin preguntarle al árbol del consumidor ni una vez: expected 1 to equal +0
❯ [openfga facts · 2.2] / el árbol vive en el backend: con el resolutor del consumidor caído el modo
  es *grant-only* — `authorize` responde `true` y NADA se puede revocar (…)
ℹ ScopeResolverError: El resolutor de ancestros de scopes falló (authorize)
 ⁃ at async OpenFgaAuthorizationDriver.factsAuthorize (src/drivers/openfga_driver.ts:1195:25)
❯ [openfga facts · 2.2] / authorizeMany con un scope cuyo árbol lanza: RESPONDE con el árbol del
  store (no hay 503), porque la decisión no pasa por el resolutor
ℹ ScopeResolverError: El resolutor de ancestros de scopes falló (authorize)
 ⁃ at async OpenFgaAuthorizationDriver.factsAuthorizeMany (src/drivers/openfga_driver.ts:1288:27)
❯ [openfga facts · 2.2] / un alias del uuid que el árbol funde con la fila canónica NO encuentra sus
  hechos: `authorize` es false (fail-CLOSED) donde la forma canónica concede — pero las ESCRITURAS
  sí canonizan
ℹ AssertionError: fail-CLOSED: no encuentra sus hechos: expected true to be false
Tests  363 passed, 4 failed (367)
```

### Mutante M2 — la caída del resolutor deja de ser 503 y cae a un árbol plano

```ts
// en src/drivers/backend_guard.ts · resolveChain
if (isAuthzError(error)) throw error
return [scope, APP_SCOPE]   // en vez de `throw new ScopeResolverError(operation, error)`
```

```
❯ [database · 2.2] / un resolutor de ancestros que lanza ⇒ 503 E_AUTHZ_RESOLVER_FAILED, nunca false
❯ [database · 2.2] / authorizeMany con un scope cuyo árbol lanza: 503 E_AUTHZ_RESOLVER_FAILED
  entero, jamás un array parcial
ℹ AssertionError: debería haber rechazado
❯ [database (sin listDenies) · 2.2] / (los dos mismos)
❯ [openfga facts · 2.2] / el árbol vive en el backend: … modo *grant-only* …
ℹ AssertionError: debería haber rechazado
❯ [openfga · 2.2] / (los dos mismos)
Tests  360 passed, 7 failed (367)
```

Es el mutante que prueba las **dos** caras nuevas: la `whenFalse` de `hierarchyFacts` (el 503 que se
movió del caso general) y la mitad «nada se puede revocar» de la `whenTrue`.

### Mutante M3 — la lectura de `database` usa la ortografía del LLAMANTE, no `chain[0]`

```ts
// en src/drivers/database_driver.ts · authorize
const chain = [scope, ...chain0.slice(1)]   // en vez de la cadena canónica del resolutor
```

```
❯ [database · 2.2] / un alias del uuid que el árbol funde con la fila canónica encuentra sus hechos:
  `authorize` responde lo mismo que sobre la forma canónica

- Expected  - 1
+ Received  + 1

- true
+ false

ℹ AssertionError: con canonicalScopeReads: true la lectura usa chain[0] (invariante 17): expected
  false to be true
 ⁃ at <anonymous> (src/testing/contract.ts:4097:20)
Tests  365 passed, 2 failed (367)
```

## Recuento del juez DESPUÉS de K1

| Suite | Sin `AUTHZ_CONTRACT_FACTS` | Con `AUTHZ_CONTRACT_FACTS=1` |
|---|---|---|
| `npm test` (SQLite memoria) | 703 → **709** | 791 (1 rojo) → **799 passed (799)** |
| `npm run test:sqlite-file` | 705 → **711** | — → **801 passed (801)** |
| `npm run test:pg` | 879 → **889** | 967 (2 rojos) → **979 passed (979)** |
| `npm run test:mysql` | 879 → **889** | — → **979 passed (979)** |
| **tope 3** (`:8103`, `AUTHZ_CONTRACT_FACTS=1`) | — | **799 passed (799)** |

**Cero rojos con `AUTHZ_CONTRACT_FACTS=1` en SQLite, PostgreSQL y MySQL**, que es lo que pedía K1.

De dónde salen los casos nuevos: **2 por harness** (uno del par `canonicalScopeReads`, que se
registra en todos los niveles; otro del par `hierarchyFacts`, que estrena una segunda cara por lado
en `'2.1'`). Sin `facts` hay 3 harness en SQLite (+6) y 5 en PG/MySQL (+10); con `facts`, 4 (+8) y 6
(+12). Ningún caso se perdió: las dos afirmaciones que se movieron viajaron enteras a la cara
`whenFalse` de su par.

Recuentos literales del juez en `tests/contract_harness.spec.ts` (la regla «tocarlo al añadir
casos»): core 39 → **40**, `'2.0'` 52 → **53**, `'2.1'` 69 → **71** (sin `listDenies` 63 → **65**,
con reloj 73 → **75**), `'2.2'` 79 → **81** (sin `listDenies` 74 → **76**, con reloj 83 → **85**).

**El rojo intermitente del lote 2h no reapareció**: la pasada de tope 3 salió a fichero desde la
primera vez (`k1-tope3.log`) y dio 799/799.

**Stores**: cero huérfanos en el `:8101` — el `:8101` tiene 58 stores de lotes anteriores
(`tester-*`, `audit*`, `atk*`…, todos previos a este lote) y **ninguno** con prefijo `contract`, que
es el que crea esta suite. El `openfga-tiny` del tope 3 se borró (`docker rm -f`).

## Comprobaciones de K1

`npx tsc --noEmit -p tsconfig.json`, `npm run typecheck`, `npm run check:purity` y `npm run build`:
todos verdes. Comentarios y mensajes en español; código y API en inglés.

---

# K2 · Borrar el modo `resolver`

K2 se hizo **con K1 verde** (los recuentos de arriba son de antes de tocar nada de esto).

## Qué se borró, pieza a pieza

### El modo, la opción y el gate

- `OpenFgaDriverOptions.hierarchy` **desaparece**. El driver `openfga` **es** `facts`: pasarla es
  error de TypeScript y no existe en tiempo de ejecución.
- `driver.capabilities` deja de ser un getter que mira el modo: es constante
  (`hierarchyFacts`/`singleCheckAuthorize`/`purgeRole`/`countRoleAssignments` `true`,
  `roleInheritanceNative`/`listObjectsInherited`/`canonicalScopeReads` `false`).
- El constructor deja de **retirar métodos** (`purgeRole` y `countRoleAssignments` ya no se borran
  con `Object.defineProperty`), y `assertScopeDriftGuarded` pierde el parámetro del modo: el gate
  aplica SIEMPRE. Con él cambia el mensaje (ya no dice «con hierarchy: 'facts'») y el stub publicado
  `config/authorization.ts`, que ahora firma `acceptScopeDriftRisk: true` y dice cuándo cambiarlo por
  la outbox — sin eso, **el stub que el paquete publica no construiría**.

### El camino muerto

- **La expansión de cadena**: `checksFor` (el `batchCheck` N×M de denies + roles por nivel) y las
  ramas de `authorize`/`authorizeMany` que lo usaban. `authorize` es hoy tres líneas: memo del
  catálogo y `factsAuthorize`.
- **El tipo `deny_binding`**, entero: el objeto, su lectura (`legacyDenies`), su rama en
  `deniedScopeKeys`, su rama en `purgeScope` —que deja de ser O(permisos) por scope: ya no consulta
  `authz_permissions`— y su valor en el tipo de `parseBindings`.
- **La guarda `!structure.length`** de `grant` (ver «lo que cambia de comportamiento»).
- **`openFgaAuthorizationModel`**, el generador del modelo viejo.

### Lo que quedó huérfano al quitarlos, y también se borró

- **`openfga:import`** entero: el comando (`commands/openfga_import.ts`, 93 líneas), la función
  `importAuthzFactsToOpenFga`, sus tipos `ImportFactsOptions`/`ImportFactsResult`, y sus utilidades
  privadas `readPages`, `tupleId`, `tupleOf`, `FactTuple`, `IMPORT_BATCH_SIZE`. **Es la decisión más
  gorda del lote y no estaba en la lista del encargo, así que va explicada**: el importador escribe
  `role_binding#assignee` y `deny_binding#denied`, tipos que el modelo (c2r) **no declara**. Dejarlo
  no habría sido «una limpieza incompleta»: habría sido publicar un comando que llena un store que el
  servidor rechaza y que no concede nada — un roto silencioso, justo lo que la regla del lote prohíbe.
  Su sustituto declarado es `authz:reconcile` (3b-3). Con él se van `StoreNotEmptyError` /
  `E_AUTHZ_STORE_NOT_EMPTY` (no tenían otro usuario) y los imports `sqlExpiryCodec` y
  `APP_SCOPE_DB_UUID` del driver.
- El parámetro `permissionUuid` de `denyTuple`, que solo servía para componer el id del `deny_binding`.

### `openfga:provision` publica el modelo `facts`

`provisionOpenFgaStore(apiUrl, name, holderTypes, permissions)` gana el cuarto argumento y escribe
`openFgaFactsModel`. El comando resuelve los `catalogs` del config (son funciones: no toca la base) y
**sale ≠ 0 si no hay ninguno**, porque un modelo (c2r) sin permisos no puede responder a nada y
descubrirlo en el primer `authorize` sería peor.

### Un harness, no dos

`AUTHZ_CONTRACT_FACTS` **desaparece**. Existía porque había DOS harness openfga sobre el mismo
servidor —el del modo `resolver` y el de `facts`, este último escondido mientras (b) y (c) estaban
rojas—. Con K1 verde y el modo viejo borrado queda **uno**, llamado `openfga` (u `openfga (árbol
SQL)` en PG/MySQL), y corre siempre que haya `OPENFGA_TEST_URL`, sin variable que lo esconda.

## Lo que CAMBIA de comportamiento (no solo se borra)

Dos cosas, y las dos van al CHANGELOG como breaking:

1. **El `grant` que choca con un duplicado y cuya relectura no ve nada.** En `resolver` el `assignee`
   era la ÚNICA tupla del write, así que un duplicado inexplicable salía como **503 con la receta
   `{ expiresAt: null }`**. Con la estructura de (c2) sí tiene explicación —otro holder ya tenía ese
   rol en ese scope, el caso más común que hay— así que se repite el write dando el duplicado por
   bueno, y una contención que no cede en tres vueltas es **409 `E_AUTHZ_WRITE_CONFLICT`**. El 503
   con la receta sigue donde sigue aplicando: cuando **la relectura FALLA**.
2. **Un rol borrado a mano de `authz_*`.** La MEMBRESÍA falla cerrado en los dos drivers (filtran por
   el catálogo local), pero `authorize` en `openfga` **sigue concediendo** hasta que se rehace la
   proyección: el mapa permiso→rol que decide está en el store (`role:<uuid>#permits_<P>`), no en la
   fila que acabas de borrar. El deber ya estaba escrito en `CLAUDE.md` (`projectCatalogRole` es el
   hook de «una escritura de catálogo cambió este rol»); lo que estaba mal era el README, que
   prometía lo contrario («it fails closed in every read»). Corregido, y el caso del juez lo fija en
   las dos mitades — incluido que tras `projectCatalogRole` deniega y el HECHO sigue en el store.

## Casos que desaparecen, agrupados por motivo

**26 casos netos**, y el reparto cuadra exactamente con la caída de las cifras (abajo).

| # | Motivo | Casos | Dónde |
|---|---|---|---|
| 1 | **Juzgaban el modo `resolver`** (su premisa ya no existe) | **13** | ver lista |
| 2 | **Se van con `openfga:import`** (el comando borrado) | **6** | `contract.spec.ts`, grupo «openfga:import — sin Ignore, con reconcile (S7)» |
| 3 | **La entrada `openfga` de `spies.spec.ts`** | **8** | grupo `espías [openfga]` entero |
| — | *Añadidos* en el mismo lote (contención que no cede ⇒ 409; los tres de `openfga:provision`) | **−4** | `openfga_driver.spec.ts`, `openfga_facts.spec.ts` |
| | **Neto** | **23** | |

**Los 13 del motivo 1, uno a uno:**

- `openfga_facts.spec.ts` (5):
  1. «en modo `resolver` NO se escribe el marcador: ese modelo no tiene `rooted`»
  2. «por defecto (modo `resolver`, el de hoy) NO se escribe ninguna arista: el lote es aditivo»
  3. «en modo `resolver` (el default) NADA cambia: sigue siendo el batchCheck de la cadena»
  4. «en modo `resolver` el grant escribe SOLO el assignee (el lote es aditivo)»
  5. «CASO NEGATIVO: en modo `resolver` el driver sigue diciendo que no sabe purgar, y
     `defineScopedRole` se niega ANTES de escribir»
- `scope_outbox.spec.ts` (1):
  6. «en modo `resolver` (el default) el gate no aplica: el árbol no está en el store»
- `openfga_driver.spec.ts` (7), los dos grupos enteros:
  - «openfga — un solo batchCheck por authorize (2A · A2)» (4 casos: denies y roles en la misma
    request; el deny gana; ninguno allowed ⇒ false; sin rol que conceda ⇒ 0 llamadas)
  - «openfga — authorizeMany en un solo batchCheck (2B · B6)» (3 casos: N scopes ⇒ 1 llamada; sin
    rol que conceda ⇒ 0 llamadas; un `error` en el lote ⇒ 503 entero)

**Y un harness del juez entero.** El de `openfga` en modo `resolver` (**85 casos** en `'2.2'` con su
declaración: `purgeRole: false`, `countRoleAssignments: false`, `serializedCatalogWrites: false`,
`injectableClock: true`). En SQLite era uno; en PG/MySQL eran dos (`openfga` y `openfga (árbol
SQL)`). Lo sustituye el de `facts`, que ya corría.

**La cuenta cierra**: SQLite 799 − 85 (un harness) − 26 (casos borrados) + 3 (los de
`openfga:provision`) = **691**. PostgreSQL 979 − 2×85 − 26 + 3 = **786**. Ni un caso desaparece sin
motivo, y los 26 son 27 borrados menos el caso negativo nuevo del 409.

**Lo que NO se perdió, y dónde vive ahora:**

- Las cuatro afirmaciones del grupo «un error por check en batchCheck es 503 (D1)» que hablaban de
  `authorize`: se reescribieron sobre `authorizeMany` (que sigue usando `batchCheck`) y sobre el
  `Check` suelto. La regla —un `error` por check NO se lee como `allowed: false`— se juzga igual.
- El grupo de `purgeScope` («lee por objeto exacto… verifica cero»): sigue, con los objetos de
  (c2r) —los `role_binding` del nivel y el propio `scope:<key>`— en vez de un `deny_binding` por
  permiso.
- «los denies de listScopes se leen enteros: 205 de ruido no esconden el relevante»: sigue, con el
  ruido en la forma de (c2r) (`scope:<key>#denied_<P>`).
- El caso del generador del modelo con `holderTypes` colapsado: sigue, apuntando a
  `openFgaFactsModel`, que es el único generador que queda.
- Lo que medía la entrada `openfga` de `spies.spec.ts` **no se perdió, cambió de sitio**: las
  requests por primitiva en `facts` (`{check: 1, batchCheck: 0}`, `resolveChain: 0`, el `batchCheck`
  de N items, el memo del catálogo) las cuenta `openfga_facts.spec.ts` con un store en memoria y
  espías; «`authorize` no consulta el árbol» y «la membresía sí» son los pares
  `singleCheckAuthorize` y `roleInheritanceNative` del juez contra el `:8101`; «el resolutor caído
  no tumba la decisión, y todo lo demás sí» es el par `hierarchyFacts` (K1). Está escrito en el
  propio fichero, no solo aquí.

## Líneas quitadas

| Fichero | + | − |
|---|---|---|
| `src/drivers/openfga_driver.ts` | 152 | 622 |
| `commands/openfga_import.ts` | — | **93 (borrado entero)** |
| `src/errors.ts` (`StoreNotEmptyError`) | 0 | 11 |
| `src/openfga.ts` (exports) | 6 | 11 |
| `tests/contract.spec.ts` | 104 | 321 |
| `tests/openfga_driver.spec.ts` | 131 | 232 |
| `tests/openfga_facts.spec.ts` | 51 | 130 |
| `tests/spies.spec.ts` | 23 | 38 |
| `tests/scope_outbox.spec.ts` | 10 | 21 |

De las 152 altas del driver, **5 son de K1** (la capacidad `canonicalScopeReads`); el resto son
docblocks reescritos. El diff completo del lote (K1 + K2) son **961 altas y 1.482 bajas** en 23
ficheros más uno borrado.

## Rojo→verde por pieza (K2)

K2 es un lote de BORRADO, así que el rojo no hay que provocarlo: sale solo al quitar la rama que lo
tapaba. Estos son los rojos literales que aparecieron y lo que los puso verdes.

### El gate del árbol pasa a aplicar SIEMPRE

Rojo (`npm test` tras quitar el modo, antes de firmar los harness):

```
❯ openfga — un backend inalcanzable se nota / authorize lanza un error del PAQUETE, no del SDK, con status 503
ℹ AssertionError: expected ScopeDriftUnguardedError{ …(5) } to be an instance of AuthorizationBackendError
 ⁃ at Object.executor (tests/contract.spec.ts:172:12)
```

Verde: cada montaje que construye el driver sin manager firma `acceptScopeDriftRisk: true` (el gate
es del CONFIG, 3b-2e · E3), **y el stub publicado también** — sin eso el `config/authorization.ts`
que el paquete publica no arrancaría. El caso «sin outbox y sin `acceptScopeDriftRisk` el driver NO
se construye» pasa a construirse con `build({})`, que hasta este lote era el modo `resolver` y no
lanzaba nada: es el mismo caso, ahora sin escapatoria.

### `authorize` deja de tener lote, y el `check` no estaba doblado

```
❯ openfga — ids de binding por uuid (3A · A1) / ningún id que el driver genera contiene `~` …
ℹ AuthorizationBackendError: El backend de autorización 'openfga' no respondió (check)
 ⁃ at async OpenFgaAuthorizationDriver.factsAuthorize (src/drivers/openfga_driver.ts:819:22)
```

Cuatro casos más del grupo «context y consistency (S17, S11)» cayeron por lo mismo. Verde: los dobles
del cliente implementan `check` además de `batchCheck`, y las aserciones dicen lo que hoy es cierto —
`authorize` es un `check` de `can_<P>`; la MEMBRESÍA y `authorizeMany` siguen siendo `batchCheck`—.
El literal del cruce 6 no se toca.

### `purgeScope` deja de leer un `deny_binding` por permiso

```
❯ openfga — purgeScope demuestra cero o lanza / lee por objeto exacto cada rol del nivel y cada permiso …
 ❯ 838 ┃      assert.deepEqual(
```

Verde: los objetos son los `role_binding` del nivel **y el propio `scope:<key>`**; los borrados pasan
de 255 a 259 (250 `assignee` + 5 del scope + las DOS aristas de estructura por rol, que se borran a
ciegas — 3b-2f · R3). El caso lo dice.

### El `grant` que choca con un duplicado

```
❯ openfga — la carrera de grant solo es carrera con un duplicado (D6) / duplicado + relectura vacía +
  expiresAt omitido ⇒ 503 con la receta { expiresAt: null } y ninguna escritura
ℹ AssertionError: debería haber lanzado
```

Verde: el caso pasa a afirmar lo que la estructura de (c2) hace —repetir el write dando el duplicado
por bueno, `existed: false`, y las llamadas `['read','writeTuples','read','writeTuples']`— y se le
suma un **caso negativo nuevo**: una contención que no cede en tres vueltas es 409
`E_AUTHZ_WRITE_CONFLICT`, jamás un 503.

### El rol borrado a mano del catálogo

```
❯ openfga — un rol retirado del catálogo deja una tupla huérfana / rol borrado del catálogo: la tupla
  sigue en el store pero authorize deniega

- Expected  - 1        - false
+ Received  + 1        + true

ℹ AssertionError: expected true to be false
 ⁃ at Object.executor (tests/contract.spec.ts:398:14)
```

Verde: el caso dice ahora las DOS mitades —la membresía falla cerrado, la decisión sigue concediendo
hasta que se rehace la proyección— y comprueba que tras `projectCatalogRole(uuid)` deniega y el
HECHO sigue en el store. El README decía lo contrario y se corrigió.

### La proyección del catálogo (A5) ya cuenta con el marcador de raíz

```
❯ facts · A5 — la proyección del catálogo (tuplas permits_<P>) / el primer sync escribe una tupla por
  (rol, permiso, holder), con el comodín de USUARIO
ℹ AssertionError: expected [ { …(2) }, { …(2) } ] to have a length of 1 but got 2
```

Ese grupo corría en el modo `resolver`, donde `ensureFactsRoot` no escribía nada. Verde: el grupo
separa los `Write` del catálogo de los del marcador (`catalogWrites`/`projected`), que tienen su
propio grupo.

### La pieza que K2 ESTRENA sí necesitó mutante

`openfga:provision` publicando el modelo `facts` es lo único que K2 añade en vez de quitar, y no
tenía caso propio (ningún comando de ace lo tiene en esta suite). Se le puso uno, en dos mitades, y
se probó con un mutante:

- La lista de permisos sale de los `catalogs` del config. Se extrajo a
  `permissionsOfCatalogs(config)` —exportada, y no un método privado— **precisamente para que se
  pueda juzgar sin montar un comando de ace**, que es lo que dejaba a esta pieza sin caso.
- **Mutante**: `provisionOpenFgaStore` publica `openFgaFactsModel(holderTypeMap, [])` (ignora los
  permisos) y `permissionsOfCatalogs` devuelve sin ordenar.

```
❯ facts · 3b-2k · K2 — de dónde salen los permisos del modelo / permissionsOfCatalogs junta TODOS los
  catálogos, sin duplicados y en orden estable
- "billing:read"  - "docs:read"   |   + "docs:read"  + "billing:read"
ℹ AssertionError: expected [ 'docs:write', 'docs:read', …(1) ] to deeply equal [ 'billing:read', 'docs:read', …(1) ]

❯ facts · 3b-2k · K2 — el store provisionado responde `can_<P>` / provisionOpenFgaStore escribe el
  modelo (c2r) con los permisos que se le pasan: `can_<P>` existe y el `deny_binding` del modo viejo NO
ℹ FgaApiValidationError: FGA API Validation Error: post check : Error invalid relation:
  relation 'scope#can_docs_read' not found
Tests  92 passed, 2 failed (94)
```

El caso positivo comprueba además que el tipo `deny_binding` **no está** en el modelo publicado
(preguntar por él es un error del servidor, no un `false`): es la prueba directa de que se publica
(c2r) y no lo que escribía `openFgaAuthorizationModel`. Los tres mutantes se restauraron.

## Cifras DESPUÉS de K2

`AUTHZ_CONTRACT_FACTS` ya no existe: hay una sola columna, y el harness `openfga` que corre con
`OPENFGA_TEST_URL` **es** el de `facts`.

| Suite | Antes del lote (HEAD `28595ec`) | Con `AUTHZ_CONTRACT_FACTS=1` tras K1 | Tras K2 |
|---|---|---|---|
| `npm test` (SQLite memoria) | 703 | 799 | **691 passed (691)** |
| `npm run test:sqlite-file` | 705 | 801 | **693 passed (693)** |
| `npm run test:pg` | 879 | 979 | **786 passed (786)** |
| `npm run test:mysql` | 879 | 979 | **786 passed (786)** |
| **tope 3** (`:8103`) | — | 799 | **691 passed (691)** |

**Cero rojos en los cinco.** Los logs: `k2z-sqlite.log`, `k2z-sqlitefile.log`, `k2z-pg.log`,
`k2z-mysql.log`, `k2z-tope3.log`.

`npx tsc --noEmit -p tsconfig.json`, `npm run typecheck`, `npm run check:purity` y `npm run build`:
verdes. Además se pasó `tsc --noUnusedLocals --noUnusedParameters` sobre `src/` para cazar lo que el
borrado dejara huérfano: salieron `APP_SCOPE_DB_UUID`, `sqlExpiryCodec` y el parámetro
`permissionUuid` de `denyTuple`, y los tres se quitaron. Lo que quedó y **no** se tocó, porque no
era del modo `resolver` y ya estaba muerto en `28595ec`: el import `scopeKey` de
`database_driver.ts`, el `const test` de `contract.ts:487` y `factsQueries` en
`catalog_cache.spec.ts`.

**El rojo intermitente del lote 2h no reapareció** en ninguna de las diez pasadas completas de este
lote (cinco en K1, cinco en K2), todas a fichero desde la primera vez.

**Stores**: cero huérfanos míos en el `:8101` (los 58 que hay son de lotes anteriores —`tester-*`,
`audit*`, `atk*`—; ninguno con prefijo `contract`, `provision`, `facts` ni `spies`). El
`openfga-tiny` del tope 3 se borró.

---

# Lo que NO hice, y por qué

1. **No hay commits.** Los hace el dueño; el árbol queda con 23 ficheros modificados y
   `commands/openfga_import.ts` borrado.
2. **Borré `openfga:import`, que no estaba en la lista del encargo.** Razón arriba: con (c2r) sus
   tuplas no existen en el modelo, así que dejarlo era publicar un comando que llena un store que no
   concede nada — un roto silencioso. Va en el CHANGELOG como breaking, con la receta de migración
   provisional y el nombre de su sustituto (`authz:reconcile`, 3b-3).
3. **No reescribí la entrada `openfga` de `spies.spec.ts`: la quité.** Sus tres casos centrales
   («authorize resuelve ancestros exactamente 1 vez», «si el resolutor falla, authorize no cae a un
   false silencioso», «authorizeMany resuelve cada scope una vez») son FALSOS de `facts` por
   construcción, y hacerlos correr exigía además espejar el árbol del test en el store y proyectar
   el catálogo —que es exactamente lo que hace el harness del juez—. La evidencia equivalente existe
   y está enumerada, en el propio fichero y arriba. **Lo que se pierde de verdad**: `openfga` deja de
   tener caso propio para «100 authorize leen el catálogo una vez» y «`forRequest()` resuelve cada
   scope una vez» *en ese fichero*; el primero sí lo tiene en `catalog_cache.spec.ts` (reescrito a
   `check`), el segundo solo lo cubre `database`. Es la mayor pérdida de cobertura del lote y no la
   escondo.
4. **La rama de error del comando `openfga:provision`** (`this.exitCode = 1` + el mensaje) no tiene
   caso: la suite no tiene harness de comandos de ace y ningún comando lo tiene. Lo que sí se juzga
   —y con mutante— es la pieza que decide, `permissionsOfCatalogs`, extraída y exportada
   precisamente para eso; la rama que queda sin caso son dos líneas sobre `slugs.length === 0`.
5. **No construí `authz:reconcile`** (es 3b-3) ni ninguna migración sustituta: el README dice, con
   pasos, qué hacer mientras tanto.
6. **No re-medí las cotas** (profundidad 22, techo de 691 permisos): K2 no toca el modelo (c2r), solo
   quién lo publica; sus casos siguen corriendo contra el `:8101` y pasan.
7. **No pasé el auditor ni el tester sobre este diff.** El lote 2k no lo pedía, pero conviene decirlo:
   K1 declara dos divergencias en el README —una de ellas *grant-only con el resolutor caído*— y K2
   borra una superficie publicada; las dos son cosas que este proyecto suele mandar a revisar antes
   de cerrar fase.
8. **No toqué el rojo intermitente del 2h**: no reapareció, así que no hay nada que nombrar.
