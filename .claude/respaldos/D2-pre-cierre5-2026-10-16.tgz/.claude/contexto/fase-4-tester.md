# Fase 4 · `relations/` — verificación del TESTER (informe incremental)

> Rol: verificador. Pregunta única: **¿se puede poner en ROJO cada promesa del plan con un test?**
> Base leída: `main` @ `76c5846`. Plan evaluado: `.claude/contexto/fase-4-plan.md`.
> Listón: el de 3b (28 mutantes, «un test que pasa sin la implementación no prueba nada»).
> **No** juzgo arquitectura ni seguridad (eso es del arquitecto/auditor). Juzgo observabilidad.

---

## VEREDICTO (una línea)

**Verificable con cambios, NO tal cual.** El plan tiene buen instinto de contrato (expresa 19 casos
`dado→cuando→entonces` y reconoce que `check_purity` no aísla la frontera semántica), pero **le falta el
mecanismo por el que el juez ejecuta un `RelationsDriver`** (puerto separado, sin gancho en el harness ni
nivel en `ContractLevel`), **deja 3 de sus promesas sin caso enumerado**, **no tiene ni un caso de carrera**
para el conflicto `defineRelationsConfig`↔`syncAuthzCatalog` que él mismo describe, y **cubre el trigger solo
en INSERT** dejando UPDATE colgado de una decisión pendiente. Cuatro de las seis preguntas del encargo salen
con hueco medido.

---

## 1 · Los ~34 casos: cuántos existen de verdad

El plan **enumera 19 casos discretos**, no 34:

| grupo | casos NOMBRADOS | núcleo | anexo | negativo (dentro) |
|---|---|---|---|---|
| R-01…R-12 | 12 | 12 | 0 | R-01(sin relate), R-05, R-11, R-12 |
| R-13…R-15 | 3 | 0 | 3 (R-13, R-14, R-15) | — |
| F-01…F-04 | 4 | — | — | F-01, F-02 |
| **enumerados** | **19** | 12 | 3 | — |

Los **~15 restantes hasta 34 NO están escritos**, solo aludidos: gate de bytes del modelo fusionado
(«rebasa ⇒ 500» + «80 % avisa» = 2, marcados como NO-contrato), profundidad probabilística (1), `reconcile`
de relaciones (`enumerateRelations` origen + destino + `--dry-run` deriva ≈ 2-3), y las **caras de las
capacidades** (`usersetSubjects`, `membersOfNative`, `enumerateRelations`, truncado de `listObjects`). El
reparto que el propio plan publica — **«18 núcleo / 12 anexo / 4 negativos»** (§6 lote 4-6) — **no cuadra con
lo enumerado**: los núcleo enumerados son 12 (no 18) y los anexo 3 (no 12). El 18/12/4 es aspiracional;
incluye casos que el plan nunca redacta. **Cuantitativo: el plan documenta el 56 % (19/34) de lo que promete
contar.** No es descalificador —la Fase 4 tiene 6 lotes para escribirlos— pero el juez `'2.4'` no puede fijar
un número hasta que existan, y ver punto 6.

### Promesas del plan SIN caso enumerado (lista para el juez)
1. **`reconcile` de relaciones idempotente y bidireccional** (lote 4-5 AC): no hay un R-/F- que lo observe;
   es la lección M1/M3 de 3b (un tramo de vuelta omisivo es indistinguible de uno bueno con el origen lleno).
   Sin un caso equivalente a T1/T4 del parche 3b, un `reconcile --to` de relaciones puede **perder tuplas o
   su `subject_relation`/partición en silencio** y ninguna de las 19 lo ve.
2. **Gate `assertFactsModelPublishable` sobre el modelo FUSIONADO** (§0.1): el plan lo marca «no es caso de
   comportamiento, es gate». Correcto que es unitario, pero **es una promesa dura** («si no, un
   `defineRelationsConfig` empuja sobre el techo y el store no regenera — la avería de 3b-2a»). Necesita su
   caso: `rebasa ⇒ 500 nombrando bytes` **y** el negativo `justo por debajo ⇒ publica`. Hoy
   `factsModelBytes` mide solo `facts` (verificado, `openfga_facts.ts`); el gate del modelo fusionado **no
   existe** y el plan no lo cuenta como caso del recuento.
3. **Carrera `defineRelationsConfig` ↔ `syncAuthzCatalog`** por el `modelId` (ver punto 5): CERO casos.

---

## 2 · La frontera roles↔relations (F-01…F-04): ¿matan un mutante o son decorativas?

El plan **acierta** al desmontar el boceto: `check_purity` regla 2 aísla el **bundle** (`src/relations/` no
importa `manager`/`drivers/*`), NO la frontera **semántica**. Pero al escribirla como casos hay un problema de
LISTÓN 3b («falla si se quita la feature»):

| caso | ¿lo pone en ROJO un mutante plausible? | veredicto |
|---|---|---|
| **F-01** `relate(viewer)` ⇒ `roles.authorize` sigue `false` | En `database`: `authorize` lee `authz_assignments`, las relaciones `authz_relations` — **tablas disjuntas, consultas disjuntas**. Ningún cambio *mínimo* de una línea real hace que `authorize` lea `authz_relations`. **Pasa en verde SIN ninguna implementación de frontera**: prueba que dos subsistemas no relacionados no se relacionan, que es el estado por defecto. | 🟡 **decorativo en `database`**; con teeth solo en `openfga` (modelo compartido) |
| **F-02** `roles.grant` ⇒ `relations.check` sigue `false` | Simétrico a F-01. Mismo problema. | 🟡 **decorativo en `database`** |
| **F-03** `src/relations/` no importa `manager`/`drivers/*` | `purity.spec.ts` ya existe y `relations` ∈ `KNOWN_MODULES`. Un import prohibido lo pone rojo. | ✅ real |
| **F-04** permiso y relación con el MISMO nombre no colisionan | En `openfga` viven en UN modelo; `factsRelationMap` reserva `<P>/can_/denied_/permits_` en tipos `role`/`scope`; las relaciones en `document`/`group`. **Un refactor que acerque los espacios lo rompe** → un mutante que mapee una relación a una familia de permiso lo pone rojo. | ✅ **el único con teeth de verdad** |

**Conclusión:** los cuatro F **NO bastan** para «fijar la frontera» con el rigor de 3b. F-03 y F-04 son
buenos; **F-01/F-02 son verdes-por-construcción en `database`** y solo prueban algo en `openfga`, donde el
modelo es uno solo. Para que F-01/F-02 no sean decorativos hay que **anclarlos al `openfga` con un mutante de
conflación** (p. ej. `factsRelationMap` incluyendo un tipo de objeto, o el generador emitiendo la relación de
objeto también como `can_<P>`) y **verlos rojos**, exactamente como el par [22,23] de 3b se ancló con
mutantes. Tal como el plan los redacta, un implementador podría dejarlos pasar sin frontera.

---

## 3 · El contrato en AMBOS drivers: el hueco de MECANISMO (el más grave)

El plan dice «cada feature se expresa como caso del contrato que el juez observa en AMBOS drivers (paridad)».
Pero:

- El puerto de relaciones es **`RelationsDriver`, SEPARADO de `AuthorizationDriver`** (§2, decisión de
  higiene). El juez publicado es `runAuthorizationDriverContract`, cuyo harness solo sabe
  `makeDriver(tree) → AuthorizationDriver` (verificado, `contract.ts:219`). **No hay `makeRelationsDriver`,
  no hay `RelationsDriver` en el harness, y `ContractLevel = 'core'|'2.0'|'2.1'|'2.2'` es una unión CERRADA**
  (`contract.ts:203`, `LEVEL_RANK` en `:451`). **El plan nunca decide** si:
  - (a) nace un `runRelationsDriverContract` separado (segundo juez, segundo `*_harness.spec`), o
  - (b) se pliega en `runAuthorizationDriverContract` a nivel `'2.4'` con un campo `makeRelationsDriver` nuevo.
  Sin esa decisión, «el juez observa en ambos drivers» **no es todavía un mecanismo**, es una intención. Es
  la pregunta central del encargo (3) y **está sin resolver en el plan**.

- **`membersOf` — asimetría sin par ejecutable.** El plan lo trata como capacidad `membersOfNative` (solo
  `database`) con «caso negativo del lado que no la tiene» — que es EXACTAMENTE el patrón correcto (3b-2e·E2,
  el mismo de `purgeRole`/`countRoleAssignments`). **PERO**: `membersOf` **no está en la interfaz del puerto**
  (§2 lista `relate/unrelate/check/listObjects/listSubjects/purgeObject/purgeSubject` — no `membersOf`). Una
  capacidad `true` sin **método en el puerto que llamar** no tiene qué observar en la cara `whenTrue`; el
  juez la registraría vacía. Para que `membersOfNative` sea un par de verdad hay que **añadir `membersOf` como
  método OPCIONAL del puerto** (como `purgeRole`/`countRoleAssignments` lo son en `AuthorizationDriver`) y
  poblar **las dos caras**: `whenTrue` (database lo llama y demuestra), `whenFalse` (openfga → la ruta que lo
  pide → 500 `E_AUTHZ_UNSUPPORTED` nombrándolo, **nunca un `skip`**). El mecanismo actual **lo exige**: el
  guard de `contract.ts:4415` solo obliga a que un `true` tenga `whenTrue`; **una cara `whenFalse` ausente
  se salta en SILENCIO** (`caseFor` hace `return` — es el hueco 4.6 que yo mismo documenté en 3b). Así que
  si el plan no puebla `whenFalse` de `membersOfNative`, la asimetría queda **sin juez del lado openfga** y
  es un skip disfrazado. El plan lo prevé conceptualmente (R-14) pero **no lo aterriza en el puerto ni en el
  par de dos caras**. Además no desambigua `membersOf` de `listSubjects(member, group)` — si son la misma
  pregunta, R-14 no prueba capacidad nueva.

- **R-10 (truncado de `listObjects` en openfga) topa con un hueco REAL de hoy:** la capacidad
  `truncationSignal` tiene su cara `whenTrue` **SIN caso** («ningún driver del paquete trunca»,
  `contract.ts:4357`). `listObjects` vía `ListObjects` del servidor **sí trunca al tope** (a diferencia de los
  `list*` actuales, que usan `Read` paginado exhaustivo). Entonces R-10 sería **la primera vez que se ejerce
  la cara `whenTrue` de un par de truncado** — y el plan lo marca en su propio apéndice como **`❓ por
  verificar`** («el coste real de `ListObjects` truncado con el tope 3»). Es decir: **R-10 es una promesa
  cuya observabilidad el plan aún no ha medido.** Verificable, pero hoy es 🟡, no ✅, y necesita una
  **capacidad NUEVA** (el truncado de `listObjects` no es el `truncationSignal` de los `list*`) con su caso
  `whenTrue` que afirme la señal, contra el `:8101` de tope 3.

**Regla del encargo cumplida a medias:** el plan SÍ entiende «capacidad asimétrica ⇒ par con caso negativo,
nunca skip» (lo cita), pero **no lo hace ejecutable** para `membersOfNative` (falta método en puerto + cara
`whenFalse`) ni para el truncado de `listObjects` (falta la capacidad y su `whenTrue`).

---

## 4 · El trigger de partición: tres motores SÍ, INSERT sí, UPDATE NO

Lo bueno (evita el error de 2.5): el plan **midió la DDL divergente en los tres motores** (SQLite `RAISE`,
PG función plpgsql + `CREATE TRIGGER`, MySQL `SIGNAL 45000`) y el rechazo cross-partición en los tres. El
AC del lote 4-3 corre `R-01…R-12` en **SQLite + PG + MySQL** y exige «insert cross-partición ⇒ error de
motor clasificado». Eso **no repite** el error de los 8 defectos de motor de 2.5 **para INSERT**.

Lo que falta:
- **UPDATE sin caso.** §3.2 admite: se probó `BEFORE INSERT`; una tupla puede UPDATE-arse (renovar
  caducidad) ⇒ haría falta `BEFORE UPDATE` también. La salida propuesta (insert/delete-only) es **una
  decisión pendiente** (§6.c). **Si el dueño elige UPDATE, no hay ni un caso que lo cubra en los tres
  motores** — y sería justo el tipo de divergencia (¿el trigger `BEFORE UPDATE` de MySQL con `SIGNAL` se
  comporta igual que el `RAISE` de SQLite en UPDATE?) que 2.5 sacó. **El plan no cierra este hueco; lo
  aplaza.** Recomendación de verificador: si se va a insert/delete-only, **añadir un caso que PRUEBE que
  `authz_relations` rechaza/omite el UPDATE** (que la vía de renovar caducidad es delete+insert), para que
  la decisión sea observable y no un comentario.
- **El trigger NO es observable por el puerto.** Un `relate` legítimo pasa por el driver; el trigger defiende
  contra un **escritor raw a mano** de `authz_relations`. Eso **no** se prueba con la suite de contrato (que
  va por el puerto): necesita un caso en `database_driver.spec.ts` con `knex.raw` insertando cross-partición,
  en los tres motores. El plan lo ubica bien (lote 4-3) pero conviene marcarlo explícito: **es un caso de
  driver, no de contrato**, y por eso NO cuenta para la paridad ni para el juez `'2.4'`.
- **Dialecto ajeno ⇒ throw** (`E_AUTHZ_UNSUPPORTED_DIALECT`, patrón `sql_descendants.ts`): tiene AC. ✅ bien.

---

## 5 · Concurrencia multiproceso: CERO casos para la carrera que el plan describe

El plan **describe** el conflicto (§0.4): «todo `syncAuthzCatalog` Y todo `defineRelationsConfig` republican
el modelo entero y re-pinean `modelId`, y el gate de bytes es conjunto». Eso es una **superficie de carrera
de lost-update**: dos procesos republican el modelo fusionado; el que confirma segundo puede **borrar los
tipos de relación del otro** (o su `assertFactsModelPublishable` medir un modelo que el otro ya cambió), y
con invariante 14 el `modelId` re-pineado tiene que quedar consistente con `authz_catalog_version`.

**Grep del plan por `concurren|carrera|race`: 0 resultados de caso.** Las tres únicas menciones de
concurrencia son de coste/coordinación, no de contrato. La suite de contrato de HOY tiene **3 casos de
carrera** (`contract.ts:2229/2266/2315`: dos grant, purgeScope×grant, syncAuthzCatalog×authorize). El plan
**no propone el análogo**: `defineRelationsConfig` concurrente con `syncAuthzCatalog` ⇒ el `modelId` final es
consistente, **ninguno de los dos pierde su proyección** (ni las relaciones ni los permisos), y una
contención que no cede sale como `409`, nunca como un modelo mutilado. **Es exactamente la clase de bug
(carrera) que ha mordido esta fase**, y el plan la nombra como coste pero no la pone bajo un juez.
**Hueco confirmado, alto valor.**

---

## 6 · El conteo del juez `'2.4'`: el plan lo reconoce pero NO lo aterriza

`tests/contract_harness.spec.ts` **fija números LITERALES por nivel** que se rompen si se añade un solo
caso: `core=40`, `'2.0'=53`, `'2.1'=71` (65 sin listDenies, 75 con reloj), `'2.2'=82` (77 sin denies, 86 con
reloj, 87 con purgeRole). Añadir `'2.4'` obliga, como MÍNIMO, a:

1. **Extender la unión `ContractLevel`** (`contract.ts:203`) — hoy cerrada en `'2.2'`. (Nota: el plan salta
   de `'2.2'` a **`'2.4'`**; **no existe `'2.3'`** — 3b metió todo bajo `'2.2'`. El plan no justifica el
   salto de nombre; conviene que el juez lo fije para que `--from`/`--to` y la doc no mientan.)
2. **`LEVEL_RANK`** (`:451`) con `'2.4'` y su orden.
3. Un **bloque nuevo de aserciones literales en `contract_harness.spec.ts`** para `'2.4'` (número base + cada
   par de capacidad nueva con sus dos caras y su `assert.throws` de «true sin nivel se rechaza»).
4. Registrar las **capacidades nuevas** (`usersetSubjects`, `membersOfNative`, `enumerateRelations`, el
   truncado de `listObjects`) en el baseline `NONE` de `DriverCapabilities` **y** en el guard de
   `contract.ts:4415`, cada una con `whenTrue` **y** `whenFalse` poblados (la cara `false` NO es opcional en
   la práctica: un skip silencioso si falta).

El plan menciona «juez `'2.4'`» (lote 4-6 AC) y en el apéndice admite **`❓ el número exacto de casos del juez
'2.4' (el boceto estima 34)`**. Es decir: **reconoce que hay que actualizar el conteo, pero NO lo fija, NO
menciona `contract_harness.spec.ts` ni sus aserciones literales, y NO enumera los pares de capacidad nuevos
que hay que declarar.** Para un verificador, «estima 34» **no es un conteo del juez**: es un número sin
aserción, justo lo que 3b·§4.4 criticó del «691». **El juez `'2.4'` no está especificado; está estimado.**

---

## Tabla de veredictos por pregunta del encargo

| # | Pregunta | Veredicto |
|---|---|---|
| 1 | ¿Los ~34 cubren lo que dicen? | 🟡 **19/34 enumerados**; el split 18/12/4 no cuadra; 3 promesas sin caso (reconcile, gate fusionado, carrera) |
| 2 | ¿Bastan F-01…F-04? | 🟡 **No**: F-03/F-04 con teeth; **F-01/F-02 decorativos en `database`** (verdes sin frontera), solo prueban algo en `openfga`; hay que anclarlos con mutante de conflación |
| 3 | ¿Contrato en ambos drivers? | ❌ **Hueco de mecanismo**: puerto separado sin `makeRelationsDriver`, `ContractLevel` cerrado; `membersOf` fuera del puerto ⇒ par sin cara ejecutable; R-10 usa una cara de truncado hoy VACÍA |
| 4 | ¿Trigger tres motores + INSERT/UPDATE? | 🟡 **INSERT sí en los tres** (no repite 2.5); **UPDATE sin caso**, colgado de decisión pendiente; el trigger es caso de driver, no de contrato |
| 5 | ¿Carrera config↔catálogo? | ❌ **CERO casos** para una carrera que el propio plan describe; alto valor |
| 6 | ¿Conteo del juez? | 🟡 **Reconocido, no aterrizado**: «estima 34» sin aserción; no menciona `contract_harness.spec` ni los pares nuevos |

---

## Lo que el plan debe añadir para ser VERIFICABLE (lista accionable para el juez)

1. **Decidir el mecanismo del juez de relaciones** (segundo runner vs nivel `'2.4'` con `makeRelationsDriver`)
   ANTES de contar casos. Es prerequisito de todo lo demás.
2. **`membersOf` como método OPCIONAL del puerto** + par `membersOfNative` con **cara `whenFalse` poblada**
   (openfga → 500 nombrándolo). Y desambiguar de `listSubjects`.
3. **Capacidad NUEVA para el truncado de `listObjects`** con su `whenTrue` que afirma la señal contra el
   `:8101` de tope 3 (no reusar `truncationSignal`, cuya `whenTrue` sigue sin caso). Medir R-10 de verdad.
4. **Anclar F-01/F-02 al `openfga`** con un mutante de conflación de espacios de nombre y verlos ROJOS; si no
   se puede plantar tal mutante, admitir que son verdes-por-construcción y bajarlos a documentación.
5. **Caso de carrera** `defineRelationsConfig` ↔ `syncAuthzCatalog` (consistencia de `modelId`, ninguna
   proyección se pierde, 409 si no cede) — análogo a `contract.ts:2315`.
6. **Caso de UPDATE del trigger en los tres motores** si NO se adopta insert/delete-only; y si se adopta, un
   caso que pruebe que la vía de renovar caducidad es delete+insert (decisión observable).
7. **Caso(s) de `reconcile` de relaciones** con la lección M1/M3/T4 de 3b: que un tramo omisivo o una pérdida
   de `subject_relation`/partición **se vea roja** (no basta preguntar al origen lleno).
8. **Gate del modelo FUSIONADO** como caso unitario con las dos caras («rebasa ⇒ 500 nombra bytes» / «justo
   por debajo ⇒ publica»); hoy `factsModelBytes` mide solo `facts`.
9. **Fijar el conteo del juez `'2.4'`** en `contract_harness.spec.ts` con aserciones literales por cara de
   capacidad, y justificar el salto de nombre `'2.2'→'2.4'`.

**No he mutado el árbol. No he creado stores en `:8101`** (esta verificación fue de lectura de plan + código;
las mediciones de comportamiento las hará cada lote con sus mutantes, como en 3b).
