# Sublote D2 · cierre 4 — informe del implementador (2026-10-16)

Brief: `loteD2-cierre4-coordinador.md`. Origen: `loteD2-auditor-cierre3.md` (NO APTA; C3-1…C3-4). Árbol: `main` sobre
`75353fe`, con D2 + cierres 1–4 SIN commit. Sin `npm version`, sin push, sin sellado; CHANGELOG solo bajo `[Unreleased]`
(`git diff HEAD -- CHANGELOG.md`: 0 líneas borradas).

Principio aplicado (coordinador): si el reconcile no puede escribir un deny —o la membresía que lo transporta—, el destino
queda **igual o más restrictivo que el origen en TODO instante futuro**. Mecanismo: punto de paso ÚNICO y puro
`relationWithheldWrites` (`src/relations/tuple_order.ts`), que usan `planPartition` y la fuerza bruta.

Reproducción del auditor (`.claude/reproducciones/loteD2-auditor-cierre3.ts`, `:8090`) contra el árbol final:

| repro | antes (cierre 3) | ahora |
|---|---|---|
| C3-1 openfga | dry/real `written 1`, `[renewal-unsafe]`; `destAfterOldExpiry TRUE` | dry y real `written 0, updated 0, [renewal-unsafe, withheld-by-unsafe-deny]`; `destJustAfter false`, **`destAfterOldExpiry false`**; 2.ª pasada (ya vencida la vieja) `written 2`, niega |
| C3-1 database (control) | `updated 1`, false | igual: `written 1, updated 1, []`, `destAfterOldExpiry false` |
| C3-2 | dry `written 2, []` ≠ real `written 1, [deny-conditional]`; destino CONCEDE | dry **=** real `written 0, [deny-conditional, withheld-by-unsafe-deny]`; `destAfter false` |
| C3-3 | — | sin cambio (503 parcial `carriedDenyUnknown`, nunca éxito) |
| C3-4 (frontera) | T-1 409 / T reescrita | igual |

---

## 1 · 🟠 C3-1 — `renewal-unsafe` por extensión ya no deja una concesión diferida

**Qué.**
- `planPartition` marca cada `renewal-unsafe` como **extensión** (la del origen es posterior o `null`) o **acortamiento**,
  y llama a `relationWithheldWrites({ candidates, deletes, held, lost, context })`:
  - *deny perdido* (extensión retenida; deny `deny-conditional`): los sujetos por debajo (grafo unión) pierden los denies
    que alcanzaba. Se retiene: un allow nuevo **o que se alarga** que ese deny corta (predicado `cuts` con `toConfig`)
    y cuyo sujeto alcanzan por un camino que NO pasa por la causa; una membresía que les da un grupo con un allow así;
    con `--prune`, el borrado de un deny (o de una membresía que solo transporta denies) que los protegía.
  - *concesión conservada* (acortamiento retenido): todo allow nuevo que cuelga del grupo (o de uno de encima) y toda
    membresía nueva que añade un grupo encima (con allows) o sujetos debajo.
  - **Cascada**: una membresía retenida que transporta OTRO deny es a su vez un deny perdido (hasta punto fijo).
  - **Conflicto**: lo que no se puede retener sin conceder (una membresía SOBRANTE que concede algo y cuyo borrado
    quitaría protección) ⇒ la pasada se NIEGA con cero escrituras: motivo nuevo de `DenyRefusal`, **`carrier-conflict`**,
    con su receta (resolver antes la causa).
- Residuo nuevo **`withheld-by-unsafe-deny`** (plan; `RELATION_RESIDUES`, L9): una línea por tupla
  `retenida (withheld-by-unsafe-deny) destino:` con la causa y la FECHA desde la que escribirla concedería; deriva.
- La línea `renewal-unsafe` dice ahora las dos caducidades y la fecha de divergencia (y lo preexistente: si el destino ya
  concedía algo que solo ese deny cortaba, concede desde esa fecha — receta antes).
- Contexto del ORDEN = inicial ∪ final REAL (sin escrituras retenidas ni denies perdidos ausentes).

**Ficheros.** `src/relations/tuple_order.ts` (`relationWithheldWrites`, `HeldRenewal`, `WithholdInput`, `WithholdPlan`),
`src/relations/reconcile.ts`, `commands/authz_relations_reconcile.ts`, `src/testing/relations_reconcile_contract.ts`.

**Casos.**
- Contrato publicado (`runRelationsReconcileContract`, `denies: true`, por dirección; «doble · deny» y
  «database ↔ openfga · deny» contra el servidor): **«vigencia · C3-1 …»** = la reproducción del auditor; sin
  `atomicRenewal` ⇒ dry y real `written 0, updated 0, [renewal-unsafe, withheld-by-unsafe-deny]`, ninguna escritura llega
  al driver, niega en `now` **y tras la caducidad vieja con `withClock`** (sin sleeps); con `atomicRenewal` (database) ⇒
  `written 1, updated 1, []` y niega igual (control). Runner `denies: true`: 20 → **22** casos.
- L9: `RESIDUE_FIXTURES['withheld-by-unsafe-deny']` (dry y real, el allow nunca llega al driver).
- Guardia `relations.reconcile.order`: fila **C3-1** (doble sin atomicRenewal) comprobada también en el HORIZONTE
  (`to.withClock(old + 1 s)`, cada prefijo k = 0…n); fila **C3-2** (abajo).

**Mutantes.** `c41.plan.withhold-off` (el plan calcula y escribe igual) MUERTO; `c41.order.withhold-off`,
`.cascade-off`, `.deletes-off`, `.conflict-as-withheld`, `.shortening-as-extension` MUERTOS por la fuerza bruta con
horizonte (`unsafeWithoutResidue` > 0: 42 178 / 5 653 / 1 980 / 2 402 / 6 480 en E1-reduced 300k dos Write).
`c41.order.without-ignored` (más conservador) muere solo por cifras fijadas (0 sin residuo): declarado.

## 2 · 🟡 Horizonte temporal en la fuerza bruta (y lo que midió)

**Qué** (`tests/helpers/order_bruteforce.ts · bruteForceVigencia`):
- **8 estados** por tupla (destino ausente/vencida/viva(+1 h) × origen ausente/misma/más larga(+2 h)/**más corta (+30 min)**).
- Plan derivado con `liveInDestination` + **`relationWithheldWrites` (la misma función)** + `deny-conditional` en el plan
  sin atomicRenewal (**C3-2 en el universo**: un deny del destino con caducidad que cambia, o vencido, no se reescribe).
- **Cada prefijo y el estado final se juzgan en `now`, `+30 min` y `+1 h`**, cada tupla con SU caducidad (la del destino
  si la pasada no la tocó; la del origen si la escribió/renovó; ∞ para un deny escrito). Prefijo: nada fuera de
  inicial(t) ∪ origen(t) ni a un denegado en los dos, salvo ciclo declarado. Final: nada que el origen niegue en t salvo
  lo que el inicial ya concedía en t (`preexisting`, solo con `renewal-unsafe`/`deny-conditional` que lo declara; sin
  él, cuenta como rojo). Retenidos/negados (`refused`) contados.

**Hallazgo nuevo medido por el horizonte (también en destino ATÓMICO):** las renovaciones iban todas en la fase 4. Una
pasada cortada antes de ellas dejaba, al vencer la caducidad más corta, una membresía que en ese instante es una salida
(o entrada) aplicada fuera del orden de precedencias, o un allow que debía acortarse todavía concediendo (19 686 pares sin
residuo en E1-reduced 300k atómico). **Arreglo** (`relationTransitionOrder`): una renovación de MEMBRESÍA entra en el grafo
de la fase 3 como la entrada (alarga) o salida (acorta) que es en el horizonte (`op: 'renew'` sin cambio) y cuenta como
`changing`; una renovación de ALLOW que acorta va con los borrados de la fase 2. Campo nuevo opcional
`RelationTransition.shortening`; el plan pasa `plan.shortening`.
Coste declarado: más pares con CICLO (residuo de orden avisado, «orden SIN garantía») en destinos atómicos, porque las
renovaciones participan en el grafo.

**Cifras** (semilla 20261016; tamaños de muestra SIN cambio; spec por defecto ~35–60 s):

| universo | modo | combinaciones | sin residuo | ciclo | conceden | inherentes | renewal-unsafe | deny-cond. | retenidas | negadas | preexist. |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **E1-reduced EXHAUSTIVO** | atómico | 33 554 432 | **0** | 993 024 | 105 696 | 26 496 | 0 | 0 | 0 | 0 | 0 |
| **E1-reduced EXHAUSTIVO** | dos Write | 33 554 432 | **0** | 82 728 | 15 264 | 5 976 | 20 054 016 | 25 165 824 | 29 136 880 | 2 487 456 | 4 253 713 |
| E1-reduced 300k | atóm./dos W | 600 000 | 0 / 0 | 18 004 / 1 442 | 1 972 / 287 | 454 / 108 | 0 / 358 414 | 0 / 449 968 | 0 / 521 213 | 0 / 44 655 | 0 / 75 962 |
| E1 300k | atóm./dos W | 600 000 | 0 / 0 | 4 435 / 386 | 457 / 54 | 110 / 18 | 0 / 420 257 | 0 / 674 688 | 0 / 914 035 | 0 / 63 333 | 0 / 83 557 |
| U2 30k | atóm./dos W | 60 000 | 0 / 0 | 866 / 6 | 14 / 0 | 0 / 0 | 0 / 71 536 | 0 / 180 012 | 0 / 243 863 | 0 / 12 864 | 0 / 11 006 |
| E3 30k | atóm./dos W | 60 000 | 0 / 0 | 3 215 / 48 | 16 / 1 | 2 / 0 | 0 / 86 613 | 0 / 134 671 | 0 / 262 521 | 0 / 15 084 | 0 / 9 798 |
| guardia 50k | atóm./dos W | 100 000 | 0 / 0 | 2 985 / 235 | 326 / 53 | 80 / 24 | 0 / 59 798 | 0 / 74 725 | 0 / 86 516 | 0 / 7 457 | 0 / 12 557 |

`malformed` = 0 en todas. El exhaustivo (~5 min por destino) va gateado: `AUTHZ_ORDER_VIGENCIA_EXHAUSTIVE=1`, cifras fijadas.
**Residuo nuevo declarado:** (a) `preexisting` — concesión que el destino YA daba antes de la pasada por un camino que solo
el deny perdido cortaba (la línea `renewal-unsafe`/`deny-conditional` da la fecha y la receta); (b) `refused` — la pasada
se niega (`carrier-conflict`); (c) más ciclos de orden (avisados). Densidad: el universo es denso en denies con caducidad
y renovaciones de portadoras; en la vida real `deny-conditional` solo existe escrito a mano en FGA.

**Spec** (`tests/relations_order_exhaustive.spec.ts`): grupo reescrito, cifras POR MODO; caso literal nuevo: sin
retención ⇒ el estado FINAL concede en el horizonte; con renovaciones al final (orden del cierre 3) ⇒ un destino atómico
concede en un prefijo. **Guardia** `relations.order.exhaustive`: título (vigencia + horizonte) y cifras por modo;
manifiesto + 14 `expectRed` actualizados.

**Mutantes.** `c4h.order.renewals-flat` (toda renovación como entrada) MUERTO (19 686 sin residuo atómico);
`c4h.plan.shortening-not-passed` MUERTO (caso nuevo en `relations_reconcile_deny.spec`: renovación que ACORTA un allow
antes de que salga la membresía portadora; cortada en cada k, ningún prefijo concede en la caducidad nueva, reloj
inyectado); `c4h.order.renewals-not-changing` muere solo por cifras (0 sin residuo en la muestra; la versión conservadora
se queda): declarado.

## 3 · 🟡 C3-2 — deny condicional decidido en el PLAN

**Qué.** En un destino sin `atomicRenewal`, un deny del destino CON caducidad —vivo con otra, o **VENCIDO** (antes caía en
`denyWrite` y fallaba en la pasada)— que el origen tiene es `deny-conditional` **del plan** (dry == real), no se reescribe,
cuenta para la puerta como deny presente (honrar) y sus allows se RETIENEN. `RELATION_RESIDUES['deny-conditional'].where`
= `'plan'`: ya no queda ninguna excepción al punto 2 (L9 lo fija: `[]`). El `catch` de la pasada desaparece: un driver que
declara `atomicRenewal` y aun así responde el 500 `conditionalDeny` contradice su capacidad ⇒ se propaga (los allows van
después de los denies: no se escribió ninguno).

**Casos.** `relations_reconcile_deny.spec` (🟡 4 → C3-2: doble que imita openfga; dry y real `[deny-conditional,
withheld-by-unsafe-deny]`, `written 0`, cero llamadas a `deny`; driver con atomicRenewal que lanza ⇒ 500 propagado);
`relations_openfga.spec` **«🟡 C3-2 (cierre 4 de D2)»** contra el servidor (deny condicional VENCIDO escrito con el SDK:
dry == real `written 0`, el destino sigue negando); L9 fixture `deny-conditional` (dry == real, sin `deny` al driver);
guardia: fila **C3-2** del reconcile. Caso preexistente 🟡 4 de `relations_openfga.spec` (deny condicional vivo): pasa sin
cambios.

**Mutante.** `c42.plan.conditional-in-pass` MUERTO (4 rojos).

## 4 · ⚪ C3-3 — código propio para la renovación que SÍ se aplicó

`RenewalRacedError` (409 **`E_AUTHZ_RENEWAL_RACED`**, exportado en `index.ts`; `carriedDeny`, `renewalApplied: true`,
marcado parcial), con receta que dice explícitamente que NO se aplique la de `E_AUTHZ_RENEWAL_UNSAFE` (reabriría la
ventana). `RenewalUnsafeError.raced` eliminado (sin publicar); `E_AUTHZ_RENEWAL_UNSAFE` = siempre cero escrituras.
README (sección y tabla de errores) y CHANGELOG. Caso: `relations_openfga.spec` C2-3 afirma el código nuevo, la clase y la
letra. Mutante `c43.raced.same-code` MUERTO.

## 5 · ⚪ C3-4 — `purgeScope` de roles en openfga, parcial

`OpenFgaAuthorizationDriver.purgeScope`: contador de `Write` de borrado aplicados; los pasos (estructura → hechos → denies
→ demostrar cero) en `#purgeScopeSteps`; un fallo con `progress.deleted > 0` ⇒ `markPartialWrite` (el manager ya notifica
`indeterminate`, rama de C2-5). Incluye el 500 `PURGE_INCOMPLETE` tras borrar. Caso (`openfga_driver.spec`, grupo
purgeScope, cliente falso): fallo en el 3.er lote ⇒ 503 marcado parcial; fallo en el 1.º ⇒ sin marca. Mutante
`c44.roles.purgeScope-no-partial` MUERTO.

---

## Mutantes

A mano sobre copia (`scratchpad/c4/mutants.py`, `scratchpad/c4/mutants.log`): **13 / 13 muertos** (dos de ellos solo por
cifras fijadas, dicho arriba). En el corredor de la guardia, nuevos: `rec.plan.withhold-off`, `order.withhold.off`,
`order.renewals.horizon-flat` ⇒ **3/3 muertos** (`--only`); corredor completo: ver Verificación.

## Ficheros tocados en el cierre 4

`src/relations/tuple_order.ts`, `src/relations/reconcile.ts`, `src/errors.ts`, `index.ts`,
`src/drivers/openfga_relations_driver.ts`, `src/drivers/openfga_driver.ts`, `commands/authz_relations_reconcile.ts`,
`src/testing/relations_reconcile_contract.ts`, `tests/helpers/order_bruteforce.ts`,
`tests/relations_order_exhaustive.spec.ts`, `tests/guard_surface.spec.ts`, `tests/fixtures/guard_manifest.ts`,
`tests/fixtures/guard_mutants.json`, `tests/relations_reconcile_deny.spec.ts`, `tests/relations_reconcile_l9.spec.ts`,
`tests/relations_harness.spec.ts`, `tests/relations_openfga.spec.ts`, `tests/openfga_driver.spec.ts`, `README.md`,
`CHANGELOG.md`.

## Verificación

Yo, en primer plano/segundo plano pero en SECUENCIA (`scratchpad/c4/verify.sh`; `docker restart openfga-dev && sleep 8`
antes de cada suite con OpenFGA). Node 22, `OPENFGA_TEST_URL=http://localhost:8090`, `TEST_PG_URL`/`TEST_MYSQL_URL` con
las contraseñas de `postgres18`/`mysql84`. Logs en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/c4/`.

| paso | resultado |
|---|---|
| `npm run build` (purity + typecheck + tsc) | exit 0 |
| `npm test` (`:memory:` + OpenFGA) | **2046 passed, 3 skipped (2049)** (antes 2037). La 1.ª corrida dio 1 timeout en el contrato D-05 de openfga (192 checks; sin relación con el cierre, pasa en los otros tres motores); repetida: verde (`memory2.log`) |
| `test:sqlite-file` | **2074 passed, 3 skipped (2077)** |
| `test:pg` | **2171 passed, 2 skipped (2173)** |
| `test:mysql` | **2173 passed, 2 skipped (2175)** |
| `cutover-runbook` sqlite-file / pg | VERDE / VERDE (2 verdes, 0 rojos) |
| `check:flag-mutants` | **37 / 37 muertos**, 1 pendiente (`--prune-undeclared`), VERDE |
| `check:guard-mutants` | **181 / 181 muertos**, 0 vivos (962 s; antes 178) |
| exhaustivo vigencia+horizonte E1-reduced | 2 × 33 554 432, 0 sin residuo, 0 malformados (~5 min por destino) |
| mutantes a mano (cierre 4) | **13 / 13 muertos** |
| reproducción del auditor (C3-1…C3-4) | arriba |

Incidencia corregida durante la verificación: la 1.ª versión de C3-4 movió los pasos de `purgeScope` a un método privado
`#purgeScopeSteps`; el runbook (paso 11, relay) lo llama sobre un driver envuelto en Proxy ⇒ «Receiver must be an instance
of class». Ahora es una función LOCAL (comentado); el `find` del mutante `roles.purgeScope.denies-first` se re-indentó
(sigue muerto). Nada queda corriendo en segundo plano.

## No hecho / declarado

- La retención es CONSERVADORA (grafo unión, relaciones ignoradas sin `toConfig`): puede retener de más (ruidoso, con
  receta; nunca concede). El universo denso de la fuerza bruta da muchas retenciones y ~7 % de pasadas negadas en dos
  Write; en producción la causa (renovación de portadora que alarga hacia openfga, o deny condicional escrito a mano) es rara.
- `preexisting`: una concesión que el destino ya daba ANTES de la pasada por un camino que solo el deny perdido cortaba no
  se corrige (habría que borrar un allow que el origen tiene); se declara con fecha en la línea `renewal-unsafe` /
  `deny-conditional`.
- Desfase de relojes paquete/servidor FGA (⚪ del auditor): sin cambio.
- `CLAUDE.md`, `linajes.md`, `RETOMAR.md`: le tocan al coordinador (mapa: `relationWithheldWrites`, residuo
  `withheld-by-unsafe-deny`, `carrier-conflict`, `RenewalRacedError`, `RelationTransition.shortening`).
