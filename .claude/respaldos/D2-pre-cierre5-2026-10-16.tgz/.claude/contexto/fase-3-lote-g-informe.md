# Fase 3 · Lote 3G — informe (cierre de la Fase 3)

> Rama `v2/fase-0`, sobre `ae3a7a8` (árbol limpio al empezar). **Sin commits.**
> Spec: `.claude/contexto/fase-3-correcciones-3g.md` (W1–W4, X1–X6) + piezas del tester del 3F
> reenviadas por el coordinador (Y1–Y3, informe `fase-3-verificacion-tester-3f.md`, parche
> `.claude/contexto/tests-tester-fase-3f.patch`).
> Método: rojo→verde por pieza, ejecutando primero el script del auditor que corresponde
> (`…/scratchpad/v9/`) y pegando su salida literal antes y después; typecheck + `npm test` +
> `OPENFGA_TEST_URL=:8101 npm test` tras cada pieza. Motor de los scripts: **PostgreSQL 18**.

## Resumen

| # | Qué | Estado |
|---|---|---|
| **W1** 🟠 | El rango de `scopes.detached` se mide **por rol, en la cadena del owner de cada uno**; solo se salta para los roles cuyo propio owner tampoco resuelve | ✅ |
| **W2** 🟡 | `truncated: true` (y `reason`, aunque `purgedRoles` sea 0) cuando el scope no resuelve y nada llega por debajo; contrato de `descendantsOf` escrito en el puerto | ✅ |
| **W3** 🟡 | Ensombrecer exige **rango**, no solo posición (`defineScopedRole` y `updateScopedRole`) | ✅ |
| **W4** ⚠️ | Cuatro casos de **composición** en el juez (`since('2.2')`), cada uno con sus dos caras | ✅ |
| **X1–X6** | Degradación documentada · policy de rango con `below = []` · `--fail-on-shadows` + punto ciego de `classifyHomonyms` · `CLAUDE.md` coherente · el 422 de rango sin fuga · CHANGELOG/README | ✅ |
| **Y1** 🟠 | La carrera ancestro↔descendiente tiene **dos finales legales**: parche del tester aplicado y verificado en PG y MySQL con los escenarios A y D | ✅ |
| **Y2** | El caso de S1 con **dos** roles y un actor de rank 5 (mata el mutante «purga solo el primero») | ✅ |
| **Y3** | El mensaje de `AMBIGUOUS_ROLE` ya no manda a buscar un exit ≠ 0 que no va a salir | ✅ |

Desviaciones: ninguna sobre lo pedido. Los nueve 🟡/⚪ restantes del tester quedan anotados al final
(«A la Fase 3b»), como pidió el coordinador.

---

## W1 · El rango se mide por ROL, en la cadena de su owner (auditor P1 · 🟠)

**Decisión aplicada** (respuesta 1 de la spec): el rango se mide en la cadena del **owner de cada rol
a purgar** —igual que `deleteScopedRole`— y la comprobación solo se salta para los roles cuyo
**propio owner** tampoco resuelve.

**Rojo de partida** (`v9/x1c_detached.ts`, PG, sin tocar el script):

```
rol "caro" rank 40, owner = unitU1 · atacante adminU1 rank 20

=== control (árbol completo): las dos puertas de P3 ===
    scopes.detached(u1,   {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 20 en el owner del rol) no puede tocar 'caro' (rank 40): …
    scopes.detached(orgA, {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 0 en el owner del rol) no puede tocar 'caro' (rank 40): …
  filas de "caro": 1

=== la plataforma borra la FILA de la org; la unit conserva su ruta ===
  resolveChain(orgA) = null
  resolveChain(u1)   = unit → organization → app   <-- unit VIVA con cadena completa
  descendantsOf(orgA) = 1 nodo VIVO
  authorize(holder, docs:read, U1) ANTES del ataque = true   <-- el rol SIGUE concediendo
    ATAQUE: scopes.detached(orgA, {actor: adminU1}) = {"purgedRoles":1,"truncated":false,"reason":"owner-detached-unknown"}
  filas de "caro": 0 · asignaciones: 0
  authorize(holder, docs:read, U1) DESPUÉS = false
```

**Verde** (mismo script, sin tocarlo):

```
=== control (árbol completo): las dos puertas de P3 ===
    scopes.detached(u1,   {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 20 en el owner del rol) no puede tocar 'caro' (rank 40): …
    scopes.detached(orgA, {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 20 en el owner del rol) no puede tocar 'caro' (rank 40): …
  filas de "caro": 1

=== la plataforma borra la FILA de la org; la unit conserva su ruta ===
  resolveChain(orgA) = null
  resolveChain(u1)   = unit → organization → app   <-- unit VIVA con cadena completa
  descendantsOf(orgA) = 1 nodo VIVO
  authorize(holder, docs:read, U1) ANTES del ataque = true   <-- el rol SIGUE concediendo
    ATAQUE: scopes.detached(orgA, {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 20 en el owner del rol) no puede tocar 'caro' (rank 40): …
  filas de "caro": 1 · asignaciones: 1
  authorize(holder, docs:read, U1) DESPUÉS = true
  la unit sigue viva: 3 elementos
```

Nótese el control: el segundo 422 pasa de decir «rank 0» a «rank 20». **Es la corrección, no un
efecto colateral**: antes el rango se medía en la cadena del scope NOTIFICADO (donde el admin de la
unit no vale nada) y ahora en la del owner del rol (donde vale 20). Es lo mismo que ya hacía
`deleteScopedRole`, y por eso las tres puertas responden ahora igual.

**Código**: `src/manager.ts` — `scopes.detached` resuelve la cadena del hijo UNA vez (sustituye a
`canonicalScope`, que era la misma llamada) y se la pasa a `#purgeRolesOwnedBy`;
`#assertAboveOwnedRoles(driver, actor, roles)` pierde el parámetro `scope`, memoiza por clave de
owner un `resolveChain` + `#rolesAlong`, aplica `#assertAboveRole` a cada rol y devuelve `true` si se
saltó alguno. Todo antes de purgar nada (nada a medias, sin cambios).

**Casos** (`tests/manager.spec.ts` → `3G · W1 (auditor P1)`), los cuatro de la spec:
(a) el escenario exacto de `x1c` ⇒ 422 y el rol de rank 40 sobrevive **y sigue concediendo**;
(b) con el owner de cada rol también fuera del árbol ⇒ se purgan (S1 intacta) con `reason`;
(c) mezcla de uno saltable y uno no ⇒ 422 y **no se purga ninguno**;
(d) el control con el árbol completo sigue en 422, y el mensaje demuestra que el rango se midió en la
cadena del owner (`assert.include(..., 'rank 30')`, que en la cadena del scope notificado sería 0).

---

## W2 · El canal deja de decir «purga completa» cuando no puede demostrarlo (auditor P2)

**Decisión aplicada** (respuesta 2): el puerto **no le exige nada** a `descendantsOf` sobre un scope
que `resolveChain` ya no conoce —puede devolver los hijos o `null`—, así que si el scope no resuelve
**y** por debajo no llega nada, `truncated: true` siempre, y `reason` presente aunque
`purgedRoles === 0`.

**Rojo de partida** (`v9/x4_truncated.ts`, con el helper publicado `descendantsFrom`):

```
    resolveChain(orgB)  = null
    descendantsOf(orgB) = null   <-- coherente: no conoce el scope
    scopes.detached(orgB, {actor: orgAdmin}) = {"purgedRoles":0,"truncated":false}
    filas de 'huerfano' (owner b1): 1 · asignaciones vivas: 1
    authorize(holder,docs:read,B1) = true
```

**Verde**:

```
    scopes.detached(orgB, {actor: orgAdmin}) = {"purgedRoles":0,"truncated":true,"reason":"owner-detached-unknown"}
    filas de 'huerfano' (owner b1): 1 · asignaciones vivas: 1
    authorize(holder,docs:read,B1) = true
```

(El rol de la unit hija sigue vivo — eso es lo que el invariante 18 ya promete cuando el subárbol no
se alcanza; lo que cambia es que **el resultado lo dice**.)

**Código**: `#purgeRolesOwnedBy` recibe la cadena del scope y calcula
`truncated = declared && (!enumerated || (scope desconocido && below.length === 0))`; el `reason` sale
con `scope desconocido || algún rango saltado`, también en la rama de cero roles.
**Puerto**: docblock nuevo de `ScopeDescendantsResolver` con el contrato (`src/types.ts`), y
`ScopeDetachOutcome.truncated`/`.reason` reescritos.

**Casos**: `3G · W2 (auditor P2)` en `manager.spec` (las dos caras: el scope desconocido con
`descendantsFrom` ⇒ `truncated: true` + `reason` con 0 purgados; el subárbol enumerable ⇒
`{ purgedRoles: 1, truncated: false }` sin `reason`) y el caso `3F · S1`, cuya aserción pasa de
`truncated: false` a `truncated: true` — **es el arreglo de P2, no una relajación**.

---

## W3 · Ensombrecer exige RANGO, no solo posición (auditor P3′)

**Decisión aplicada** (respuesta 3): *sobre un rol solo actúa quien lo supera en rango*, también para
ensombrecerlo.

**Rojo de partida** (`v9/x2_autoridad.ts` + `v9/x5_reparacion.ts`):

```
=== pero SÍ puede definir un homónimo desde el ANCESTRO (3F · S3) ===
    defineScopedRole(pobre, orgA, 'critico@unit' rank 1) = {"uuid":"…","slug":"critico",…,"rank":1}
=== efecto sobre el rol de rank 40 (dentro de U1) ===
    hasRole(holder,'critico',U1)  -> 422 E_AUTHZ_AMBIGUOUS_ROLE …
    grant(otro,'critico',U1)      -> 422 E_AUTHZ_AMBIGUOUS_ROLE …
    listSubjects('critico',U1)    -> 422 E_AUTHZ_AMBIGUOUS_ROLE …
=== ¿puede el dueño de la unit reparar? (x5) ===
    deleteScopedRole(adminU1 rank20 en la unit, sombra) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 0 en el owner del rol) …
    catalogInSync = true  (exit 0 => CI VERDE)
```

**Verde** (`x2`, mismo script):

```
=== pero SÍ puede definir un homónimo desde el ANCESTRO (3F · S3) ===
    defineScopedRole(pobre, orgA, 'critico@unit' rank 1) -> 422 E_AUTHZ_RANK_EXCEEDED: defineScopedRole: por debajo de este owner ya hay un rol local 'critico' de nivel 'unit' con rank MAYOR O IGUAL al tuyo (tu rank a…
    evento.shadowedByAncestor = undefined
=== efecto sobre el rol de rank 40 (dentro de U1) ===
    hasRole(holder,'critico',U1) = true
    grant(otro,'critico',U1) = {"existed":false,"expiresAt":null}
    listSubjects('critico',U1) = 2
```

Y `x5_reparacion.ts` **ya no llega a plantar la sombra**: muere en su línea 44 con
`422 E_AUTHZ_RANK_EXCEEDED` (la llamada no está envuelta en su helper `show`). La pregunta que hacía
—«¿quién puede reparar esto?»— deja de tener sujeto: el daño no se puede causar.

**Código**: `#assertNoRoleCollision` comprueba primero lo que se juzga sin tocar el árbol (los 422
hacia arriba) y delega la detección de sombras en `#shadowedBelow`, que ahora también usa
`updateScopedRole`; `#assertAboveShadowed(actorRank, shadowed, operation)` es el guardián nuevo, en
`defineScopedRole` (tras `#assertRank`) y en `updateScopedRole` (tras `#assertAboveRole`).
El 422 **no nombra el rank ni el owner del ensombrecido** (un ancestro no ve lo que hay debajo: misma
regla que `AMBIGUOUS_ROLE`, 3E · Q2), y el caso lo fija con `assert.notInclude`.

**Casos**: `3G · W3 (auditor P3′)` en `manager.spec` — rank 10 no ensombrece un rank 40 (sin escribir,
sin filtrar el rank ajeno, y el slug del descendiente sigue vivo); rank 50 sí, con
`shadowedByAncestor` en el evento; el ensombrecido sigue operándose por `{ uuid }` y `authorize` no
direcciona por slug; y `updateScopedRole` de un rol que ensombrece a otro de más rango es 422 para
quien supera a la sombra pero no al ensombrecido.

**Comentario corregido**: el de `catalog.ts` (§ sync) ahora dice que hacia abajo ensombrecer exige
rango. La frase «un tenant no puede crear ambigüedad a propósito» que citaba el auditor ya no existía
en el árbol (3F la había reescrito).

---

## W4 · Los casos de composición (la causa de las tres regresiones)

Cuatro casos nuevos en el juez (`src/testing/contract.ts`, `since('2.2')`, bajo el par de capacidad
`purgeRole`), **cada uno con sus dos caras**:

| | Composición | Las dos caras |
|---|---|---|
| **(i)** | `detached` de un ancestro desconocido + `requireActor` + `descendantsOf` + roles de descendientes VIVOS de distinto rango | 422 y **ninguno** purgado (ni el de rank 10) · con el owner de cada rol también fuera del árbol, purga con `reason` |
| **(ii)** | cota superada (degradación) **y** actor con rango insuficiente | 422 y no se purgan **ni los hechos** · con rango suficiente, purga el scope exacto con `truncated: true` |
| **(iii)** | `define` que ensombrece **y** supera la cota a la vez | la regla de nivel degrada (el `team@team` entra) pero el rango sobre el ensombrecido se exige igual (422 sin escribir) · con rango, entra y reporta `shadowedByAncestor` |
| **(iv)** | `detached` de un scope desconocido cuyo `descendantsOf` **lanza** | purga solo el rol de ese owner (sin rango que medir), **jamás** el del descendiente vivo, y lo dice (`truncated`) · con el resolutor sano, ese mismo descendiente exige rango: *degradar nunca da más poder que enumerar* |

(i), (ii) y (iv) usan `localRole()` (escritura a mano) y viven junto al `detached` de 3D · M4; (iii)
necesita `defineScopedRole` y vive bajo `listDenies`, como el resto de la delegación.
Conteo del juez: `'2.2'` con `purgeRole: true` pasa de **79 a 83**
(`tests/contract_harness.spec.ts` actualizado, con un `filter(/^composición \(3G · W4/)` que exige
los cuatro).

---

## X1–X6

| # | Qué se hizo |
|---|---|
| **X1** | Documentada la degradación **entera**: relaja la regla de nivel a la mínima, **el propio actor puede provocarla** creando más hijos que `maxDescendants` (o con la réplica caída), se acepta a sabiendas (la regla mínima no concede nada) y la mina residual la repara **autoridad + rango**. En `#assertLevelUnderOwner`, `#descendantsOrDegrade`, README §Scoped roles e invariante 18. Comportamiento **sin cambios**: `v9/x3_degrada.ts` §1–§4 da exactamente lo mismo antes y después (verificado con `git stash`). |
| **X2** | La policy de rango corre con `below = []`: caso (ii) de W4 — con la cota superada y un rol local en el scope exacto, 422 y no se purga nada. (El caso del auditor en `x6` —un scope SIN roles locales— sigue purgando los HECHOS: eso no lo gobierna el rango sino `within`, y así está documentado.) |
| **X3** | `authz:catalog:diff --fail-on-shadows` (flag del comando + `runCatalogDiff({ failOnShadows })`), documentado como el gate opt-in de CI. Y `classifyHomonyms` deja de hacer `continue` cuando el grupo tiene un global: la pareja de locales se clasifica igual, así que una **contradicción** entre dos locales vuelve a verse. Caso nuevo en el test del diff (secciones 4 y 5); verificado que **mata** el mutante (reponer el `continue` deja el caso en rojo). |
| **X4** | `CLAUDE.md` §18: la línea de resumen decía «colisión con global/ancestro/descendiente ⇒ 422» y contradecía al propio invariante trece líneas más abajo. Ahora: «colisión hacia ARRIBA ⇒ 422 y hacia ABAJO ensombrecimiento por AUTORIDAD **con rango**». |
| **X5** | `#assertAboveRole` con `actorRank === 0` responde sin nombrar slug ni rank: el 422 era enumeración del catálogo de otro tenant (`x6_canal.ts` lo medía). Verde abajo. |
| **X6** | `CHANGELOG.md` «Lot 3G» (con el breaking de W3 y el de la carrera) y README §Scoped roles: rango para ensombrecer, contrato de `descendantsOf`, `truncated`, `--fail-on-shadows`, y el conteo del juez (82 de 83). |

`v9/x6_canal.ts` antes → después:

```
    scopes.detached(a1, {actor: forasteroB}) -> 422 … El actor (rank 0 en el owner del rol) no puede tocar 'secreto-de-a' (rank 49): …
    scopes.detached(a1, {actor: forasteroB}) -> 422 … El actor no tiene ningún rol vigente en la cadena de ese scope (rank 0), así que no puede tocar los roles locales que hay ahí: …
```

---

## Y1–Y3 (tester 3F)

### Y1 · La carrera ancestro↔descendiente tiene DOS finales legales (🟠 de contrato)

Parche del tester aplicado (`README.md`, `src/catalog_cache.ts`, `src/testing/contract.ts` con
`git apply`; los dos hunks de `tests/manager.spec.ts` a mano, porque mis casos nuevos habían movido el
contexto). **Verificado por mí**, con un retraso temporal inyectado en el `define` del ANCESTRO
(hook retirado después; `src/testing/contract.ts` verificado byte a byte contra la copia post-parche):

| escenario | aserción vieja (`assert.lengthOf(ok, 1)`) | con el parche |
|---|---|---|
| **A** — 500 ms al ancestro · PG | ❌ `245 passed, 2 failed` (los dos harness) | ✅ `247 passed` |
| **D** — 2 ms al ancestro · PG | ❌ `246 passed, 1 failed` (en el filo, un harness) | ✅ `247 passed` |
| **A** — 500 ms al ancestro · MySQL | ❌ `245 passed, 2 failed` | ✅ `247 passed` |
| **D** — 2 ms al ancestro · MySQL | ❌ `246 passed, 1 failed` | ✅ `247 passed` |

Mensaje literal del rojo: `AssertionError: … exactamente un ganador (["ok","ok"]): expected [ … ] to
have a length of 1 but got 2`. Confirmo el diagnóstico: **la regla de autoridad no es conmutativa** y
el final depende de quién confirme. El parche acepta los dos finales y los afirma fuerte (lo que hay
en la base es exactamente lo confirmado uuid a uuid; nunca dos con el mismo owner; si son dos, el que
convive es el del ancestro y el slug es 422 dentro del subárbol), y añade la promesa fuerte donde sí
es cierta (dos `define` del **mismo owner** ⇒ exactamente uno y 422 para el perdedor).
`CLAUDE.md` §18 corregido en el mismo sentido («la unicidad **del MISMO owner** se DEFIENDE…»), que
era la otra frase que afirmaba de más.

### Y2 · El caso de S1, con dos roles y un actor sin rango

Encajado en el caso `3F · S1` (no en los míos de W1, que atacan la otra puerta: `detached` del
ANCESTRO). Ahora `deleteScopedRole` del rol rank 40 por el actor rank 5 sigue siendo 422 y, con la
fila del scope borrada, ese mismo actor obtiene `reason: 'owner-detached-unknown'`,
`purgedRoles: 2` y **los dos** roles fuera: muere el mutante «purga solo el primero» y se distingue
«se salta la comprobación» de «la comprobación pasa».

### Y3 · El mensaje de `AMBIGUOUS_ROLE`

`catalog_cache.ts`: «`authz:catalog:diff` los lista **como deriva**» → «los lista (3F · S3: los
ensombrecidos por autoridad NO son deriva y salen con exit 0)», fijado con
`assert.notInclude(ambiguo.message, 'como deriva')`.

---

## Verificación

| Ejecución | Resultado |
|---|---|
| `npm run typecheck` · `npm run build` | ✅ (purity + tsc + stubs) |
| `npm test` (SQLite `:memory:`) | ✅ **422 passed** |
| `OPENFGA_TEST_URL=:8101 npm test` | ✅ **524 passed** |
| `npm run test:sqlite-file` + `:8101` | ✅ **526 passed** |
| `npm run test:pg` + `:8101` | ✅ **695 passed** |
| `npm run test:mysql` + `:8101` | ✅ **695 passed** |
| tope 3 (`openfga-tiny` `:8103`) | ✅ **524 passed** (contenedor borrado) |

**Los seis scripts de `v9/` y los siete de `v8/`, ejecutados TAL CUAL al cierre** (salidas completas
en `…/scratchpad/g/*.out`):

| script | resultado |
|---|---|
| `x1c_detached` | ✅ el ataque es 422; el rol rank 40 sobrevive y `authorize` sigue en `true` |
| `x2_autoridad` | ✅ el rank 3 ya no ensombrece; el slug del descendiente sigue vivo (`hasRole = true`, `listSubjects = 2`). Al no existir la sombra, el script muere después en su propia línea de «reparación» (`TypeError: … reading 'uuid'`, busca una segunda fila `critico` que ya no hay) |
| `x3_degrada` | ⚠️ §1–§4 **idénticos a `ae3a7a8`** (la degradación no cambia; X1 la documenta). §5 muere con `422 PERMISSION_NOT_DELEGABLE` **también en `ae3a7a8`** (verificado con `git stash`): defecto del script —el actor no tiene rol en `orgB`—, no una regresión |
| `x4_truncated` | ✅ `{"purgedRoles":0,"truncated":true,"reason":"owner-detached-unknown"}` |
| `x5_reparacion` | ✅ el script muere al plantar la sombra (`422 RANK_EXCEEDED`): el daño ya no se puede causar |
| `x6_canal` | ✅ el 422 ya no nombra `'secreto-de-a' (rank 49)` |
| `n1_nivel` | ✅ N1 sigue cerrada: el dueño del árbol define su `n-galaxia@galaxia` (rank 50 sobre un rank 2) y el sync entra entero |
| `n2_p4` | ✅ igual que en 3F (driver sin `purgeRole`: 500 antes de escribir, y la salida documentada funciona) |
| `n3_shadow` | ✅ idéntico (el ensombrecimiento no concede nada: `effectivePermissions = ["docs:read"]`) |
| `n4_race` | ✅ 8 carreras en PG: 1 fila, 1 ganador y 422 exacto en las 8 |
| `n5_indeleteable` | ✅ igual; el `detached` sin actor ahora añade `reason` (W2) |
| `n6_actor_sin_within` | ✅ purga completa; `reason` también en los casos de 0 roles |
| `n7_cotas` | ✅ `{"purgedRoles":3,"truncated":true}`, sin 503 |

Ningún script muestra un ataque que funcione ni una regresión de lo ya cerrado.

Higiene: `docker rm -f openfga-tiny` ejecutado; las bases `authz_test_*` las borra el harness en
`teardown()`; el hook temporal de la carrera se retiró y `src/testing/contract.ts` quedó idéntico a la
copia post-parche del tester.

## Archivos tocados

`src/manager.ts`, `src/types.ts`, `src/catalog.ts`, `src/catalog_cache.ts` (parche del tester),
`src/testing/contract.ts`, `commands/authz_catalog_diff.ts`, `tests/manager.spec.ts`,
`tests/contract_harness.spec.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`. Sin commits.

---

## A la Fase 3b (los nueve 🟡/⚪ del tester 3F, §6 de su informe)

No entran en este lote; se anotan para que los recoja el plan de 3b:

1. `runCatalogDiff` solo imprime las sombras del catálogo **#1**.
2. `classifyHomonyms` con un global + dos locales anidados (cobertura, más allá del punto ciego que sí se cerró en X3).
3. `shadowedByAncestor` repetido con owners `a > b > c`.
4. La aserción relajada de «subárboles disjuntos».
5. Falta un caso de `truncated: true` con **0** purgados en el juez (hoy solo en `manager.spec`, W2).
6. T2/T4 sin oráculo.
7. El contador de `sync.role.locals`.
8. R7 (`purgeRole` y los vínculos: el garante es el `CASCADE` del esquema, sin oráculo propio).
9. Degradación silenciosa (una señal explícita cuando `descendantsOf` degrada en `defineScopedRole`, como `truncated` en `detached`).
