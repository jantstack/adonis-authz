# Plan 2.5 · lote 0 — re-ataque del auditor a la guardia de superficie L1

Objeto: `git diff 0fbee6e` sin commitear en `main` (guardia `tests/guard_surface.spec.ts`, manifiesto
`tests/fixtures/guard_manifest.ts`, mutantes `tests/fixtures/guard_mutants.json`, corredor `scripts/check_guard_mutants.mjs`,
F-05 en el doble, reescritura de `relations_reconcile.spec`). Repro: `.claude/reproducciones/lote0-reataque.spec.ts`
(**verde = defecto**, 7/7 verdes, medido en una copia del árbol en scratch; nunca en el working tree). Todo en `:memory:`,
sin `:8090`.

## Veredicto en una línea

**Inseguro tal cual.** Hoy no hay ningún agujero de F-05 en runtime: las 8 operaciones están cubiertas y los mutantes
mueren por la razón correcta. El problema es la guardia. (1) En CI no puede ponerse verde. (2) Una operación nueva sin
ninguna guarda la pasa entera, con el corredor incluido, tocando solo el manifiesto. Y eso es exactamente lo que harán
los lotes A/C/D.

## Hallazgos (ordenados por severidad)

### 🟠 1 · G-X lee un fichero que git ignora: en CI la guardia es roja siempre, y el arreglo obvio la vacía
- **Escenario.** Precondición: `.claude/contexto/` está en `.gitignore` (línea 5). Acción: `actions/checkout`, luego
  `npm test` (jobs `test`/`engines`) y `node scripts/check_guard_mutants.mjs` (job `guard-mutants`). Resultado:
  `ENOENT … decisiones-dueno-2026-08-28.md` y el caso G-X sale rojo. El corredor se para en la línea base
  («la guardia NO está verde sin mutar») y sale con exit 1. Su `copyTree` salta en silencio un fichero que no existe.
- **Evidencia.** ✅ Medido en una copia sin `.claude/`: `Tests 111 passed, 1 failed (112)` con ENOENT. Lo reproduce el
  caso 🟠1 de la repro. Código: `guard_surface.spec.ts`, en G-X, `readFileSync(new URL('../.claude/contexto/…'))` sin
  fallback. «Verificación en los 4 modos» del informe se hizo con `.claude/` presente.
- **Steelman del defensor.** «Nunca ha corrido en CI. Se arregla en una línea: versionar el fichero o tolerar su
  ausencia como hace `reconcile.spec.ts:2093` (`.catch(() => null)`).» **No me convence.** Versionarlo rompe la
  convención «contexto fuera de git». Tolerar la ausencia deja G-X sin cruzar nada justo en CI, que es donde se decide
  publicar (CLAUDE.md, punto 9). Las dos salidas cambian lo que G-X garantiza: es una decisión, no un retoque.
- **Mitigación mínima.** Un extracto firmado y versionado (p. ej. `tests/fixtures/d6-signed.json`). En local, un caso
  comprueba que el extracto coincide byte a byte con el párrafo D6 del fichero de decisiones. En CI, G-X lee el
  extracto y **falla** (no se salta) si no está.

### 🟠 2 · `na` y `kind: 'platform'` son exenciones sin firma: una operación nueva sin ninguna guarda pasa la guardia y el corredor
- **Escenario.** Precondición: el lote A añade `RelationsManager.relateMany(items, partition)`, que llama a
  `#driver.relate` sin F-05, sin freeze, sin actor y sin evento, y `checkMany` sin F-05. Acción: dos filas en el
  manifiesto, `row('manager', 'relateMany', 'platform', { f05: SIG, trx: SIG, … })` y lo mismo para `checkMany`. No
  se toca nada más. Resultado: guardia **112/112 verde** y corredor **89/89 muertos**. La 5.ª vuelta de F-05 entra con
  la guardia en verde.
- **Evidencia.** ✅ Medido: guardia y corredor completos en una copia con esas dos edits. Lo reproduce el caso 🟠2.
  Hay tres causas en el código:
  - La coherencia de G-M solo prohíbe `na: read` en una fila `write` y sondas de escritura en una `read`. No restringe
    `na` en la columna `f05` (ni en `partition`), y una fila `platform` o `view` no tiene restricción ninguna.
  - Las celdas `na` no exigen mutante (`cellsNeedingMutant` solo cuenta las celdas con `probe`), así que el corredor
    no las ve.
  - El meta-caso de G-R («lo que notifica = las filas `write`») itera `PORT_OPERATIONS`, no los métodos del manager,
    así que una escritura con nombre nuevo no se invoca nunca.

  Ya hay un uso real del mecanismo. El tester (§4.4) propuso firmar «freeze en la capa driver» como exención, D6 firmó
  cinco y no esa, y el manifiesto la mete como `na: 'doctrine'`, fuera del alcance de G-X.
- **Steelman del defensor.** «Una fila `platform` con todo `SIG` para un método que recibe tuplas salta a la vista en
  review.» **No me convence.** L1 son cuatro iteraciones que pasaron review. La guardia existe para no depender de eso,
  y el propio manifiesto anuncia que las filas siguientes «entran SIN tocar el spec (solo esta tabla …)»: el sitio
  rutinario de edición es justo el que no está acotado.
- **Mitigación mínima.**
  - Una matriz cerrada de qué `(capa, columna)` admite cada razón `na`: `f05` nunca `na` salvo en `withClock`;
    `doctrine` solo en `freeze` de los drivers; `double` solo en la capa `double`.
  - `platform` solo para `driver`/`capabilities`.
  - G-R invoca **todo** método del manager con entrada válida, no solo `PORT_OPERATIONS`.

### 🟡 3 · El inventario por reflexión solo ve el prototipo propio: campos de clase, estáticos y herencia se escapan
- **Escenario.** Acción: se añade a `RelationsManager` un campo de clase
  `relateFast = async (s, r, o, p) => this.#driver.relate(s, r, o, p)` y **ninguna fila**. Resultado: guardia verde.
  «Un método nuevo sin fila nace rojo» no vale para campos. Lo mismo para un `static` o un símbolo como clave. Si un
  refactor mueve operaciones a una clase base, G-0 da «stale» y lo natural es borrar la fila: la operación heredada
  pierde la sonda.
- **Evidencia.** ✅ `prototypeOperations` = `Object.getOwnPropertyNames(klass.prototype)`. Medido con el caso 🟡3. El
  repo ya usa campos de instancia (`OpenFgaRelationsDriver.diagnostics`, `client`).
- **Steelman del defensor.** «El estilo del repo son métodos.» Me convence a medias. Por eso baja a 🟡: hace falta un
  estilo inusual, pero el coste de cerrarlo es mínimo.
- **Mitigación mínima.** Inventario = nombres propios de una instancia construida (los que sean función) ∪ toda la
  cadena de prototipos hasta `Object.prototype` ∪ estáticos.

### 🟡 4 · G-X no fija «exactamente cinco» ni ata cada exención a su capa y columna
- **Escenario.** Acción, tres edits:
  - se añade `'D6-membersOf-double': { operation: 'membersOf' }` a `SIGNED_EXEMPTIONS`;
  - `double.membersOf.f05` pasa a `exempt` con sonda `whitelist`;
  - se quita F-05 del `membersOf` del doble.

  G-M exige tocar el manifiesto de mutantes, porque el `find` ya no casa: se re-apunta la celda al mutante de `relate`.
  Resultado: guardia verde y corredor 88/88. El mutante que el tester fijó para G-X, «añadir una exención sin firma»,
  sobrevive.
- **Evidencia.** ✅ Medido; es el caso 🟡4. G-X solo comprueba que el texto D6 contiene `` `<operation>` ``, y
  «`` `membersOf` `` de openfga» contiene `` `membersOf` ``. No hay `length === 5`, y la capa solo se comprueba para
  `membersOf.f05` en manager/database. `D6-enumerateRelations` también vale en la columna `partition` aunque la firma
  es «no por F-05».
- **Steelman del defensor.** «Hay que editar tres ficheros, incluido el de mutantes.» Por eso es 🟡 y no 🟠. 🟠 2 lo
  consigue con menos.
- **Mitigación mínima.** `SIGNED_EXEMPTIONS` con `layer` y `column` explícitos, `Object.keys(...).length === 5`
  afirmado y cruzado con el extracto de 🟠 1.

### 🟡 5 · La columna `write` (invariante 13) solo sondea el timeout: la escritura parcial queda fuera y `openfga.purge*.write` está mal clasificada
- **Escenario.** Acción: en `#write` del manager se anula la rama `|| isPartialWrite(error)` y en `openfga` se
  neutraliza `#partialIfDeleted`. Resultado: guardia verde. Las celdas `openfga.purgeObject.write` y
  `openfga.purgeSubject.write` dicen `na: signature` («la firma no recibe esa entrada»), pero el driver tiene un deber
  de invariante 13: marcar la purga parcial (CLAUDE.md lo exige incluso a terceros).
- **Evidencia.** ✅ Medido; es el caso 🟡7. La única sonda que lo juzga es `relations_openfga.spec.ts`, que necesita
  `OPENFGA_TEST_URL`.
- **Steelman del defensor.** «Lo cubre el job con OpenFGA real.» Es cierto en CI con FGA. Pero la guardia dice ser el
  sitio del invariante 13 y lo clasifica como «no aplica».
- **Mitigación mínima.** Sonda de purga parcial con el `fakeFgaClient` que ya existe (`read` con tuplas, primer
  `deleteTuples` OK, siguiente `read` lanza): `isPartialWrite` en el driver y `indeterminate: true` en el manager.

### 🟡 6 · Lo que construye el provider no se sondea
- **Escenario.** Un envoltorio futuro en el provider (subclase o Proxy de `RelationsManager` que llama a `driver()`)
  cumple las dos aserciones del caso «el servicio» (`instanceOf` y `driver() === inyectado`) y escribe
  `role_binding` sin F-05.
- **Evidencia.** ✅ Es el caso 🟡6: en proceso, la subclase pasa las dos aserciones y escribe `role_binding`.
- **Steelman del defensor.** «Hoy el provider construye `new RelationsManager`.» Cierto, por eso es 🟡.
- **Mitigación mínima.** Correr las filas `manager` también sobre la instancia que devuelve `buildRelationsManager`.

### 🟡 7 · Una operación nueva puede tener una sonda F-05 vacía, y «filas nuevas sin tocar el spec» es letra falsa
- **Escenario y evidencia.** ✅ por código. `F05_VARIANTS[op] ?? []`: una fila nueva con entrada en `INVOKE` y sin
  variantes da una sonda `f05` que no afirma nada y queda verde. Hoy solo lo detecta el corredor (mutante vivo), y
  mientras siga 🟠 1 ese job es rojo por otra causa. Además, el manifiesto y el informe dicen que `checkMany`, `deny`…
  entran tocando solo la tabla, y es falso: hay que tocar `INVOKE` y `F05_VARIANTS` del spec (linaje L8, letra ≠
  efecto).
- **Mitigación mínima.** Si una celda `f05` es `probe` y no tiene variantes, rojo. Y corregir la frase.

### ⚪ 8 · La sonda de partición de `enumerateRelationsMany` usa un array de un solo elemento
- `assertScope(partitions[0])` en vez del bucle, con el mutante re-apuntado (que G-M exige), deja la guardia verde y el
  corredor 88/88 (caso ⚪5). Hoy lo salva `scopeKey` en los drivers del paquete; con D4 y un driver de terceros, no.
  Mitigación: sondear con `[P, BAD]` y `[P, DASHLESS]`.

### ⚪ 9 · La búsqueda en `exports` es por nombre
- Una función exportada llamada `purgeObject` (arrow en un objeto exportado, sin `prototype` y sin «relation» en el
  nombre) no se clasifica. El tester pedía «toda función que reciba un objeto de relación». La heurística es
  inevitable; declararla como límite.

### ⚪ 10 · La reescritura del caso de `relations_reconcile.spec` conserva lo que probaba, pero la letra contradice CLAUDE.md
- Las cuatro aserciones (`unchanged 1`, `extra 1`, `deleted 1`, `undeclared 3`) y la regla del planificador (decide
  `toConfig`) se conservan: **no se relaja**. Pero el comentario llama «RESIDUO DECLARADO de CLAUDE.md» a la tupla y
  afirma que `--prune` la barre. CLAUDE.md dice que ese residuo «no lo barre nadie». Con un destino real
  (configuración nueva, lista blanca en `enumerateRelations`) ni siquiera sale como `extra`. El caso modela un destino
  con la configuración vieja. Hay que corregir la letra.

### ⚪ 11 · D4 en el doble
- La columna `partition` del doble es `na: double`. Cuando el lote A cambie `DASHLESS_PARTITION`, el doble publicado
  seguirá aceptando la partición sin guiones y ninguna celda lo dirá. Conviene anotarlo en el lote A.

## Lo que intenté y NO se rompió

- **Mutantes: el `find` casa una vez y el rojo es por la razón correcta.** Corrí el corredor con `--only` en `:memory:`
  sobre cinco celdas: `manager.purgeSubject.f05`, `database.purgeObject.partition` (multi-fichero, con `scopeKey`),
  `openfga.purgeSubject.f05` y `openfga.membersOf.unsupported` (las dos con cliente FGA falso) y `double.relate.f05`.
  Las cinco mueren, cada una por la guarda quitada (no por un fallo de carga). El corredor completo da 89/89 en la línea
  base del árbol de prueba. G-M es fuerte: editar una línea guardada pone rojo el cruce. Lo vi en los casos 4 y 5, que
  solo pasaron al re-apuntar el mutante.
- **`expectRed`.** Exige que el caso **nombrado** salga rojo; los colaterales se informan pero no cuentan. Si el spec no
  carga, los casos aparecen como SIN-CASO y se cuentan como vivos (es seguro). No encontré mutantes equivalentes
  contados como muertos. Los de `partition` de los drivers matan la guarda compartida de `scopeKey` (declarado en
  `note`), no la línea propia de cada operación, que queda como defensa en profundidad sin mutante.
- **`withClock`.** Si devolviera un Proxy que se salta las guardas, lo cazarían las sondas `f05`/`trx`/`partition` y
  la de lista blanca, que corren también sobre la vista (db, openfga y doble).
- **Métodos `_x`.** Se ven (no hay filtro). Los `#x` no son superficie.
- **Reclasificar una escritura existente** como lectura o `platform`: G-R lo pone rojo.
- **`DASHLESS_PARTITION`.** En manager, `database` y `openfga`, cambiar la constante cambia la expectativa (`isNull` +
  llegó al backend ⇄ 422 + cero backend), no la forma.
- **H8/D13.** F-05 en el doble no rompe ningún uso legítimo del repo (suites verdes según el informe). Quien siembre
  tuplas no declaradas en el doble se rompe, y el CHANGELOG lo declara. La mitad del runner («driver directo») queda
  diferida al lote A, también declarado.
- **G-X lee el fichero real** de decisiones, no una copia. Solo funciona en local (🟠 1).

## Preguntas abiertas para el arquitecto

1. ¿Qué fuente de la firma D6 se versiona para CI (🟠 1)? ¿Un extracto con checksum contra el fichero local, o el
   fichero mismo?
2. «Freeze en la capa driver»: el tester la propuso como exención y D6 no la firmó. ¿Se acepta como `na: doctrine` (y
   entonces la matriz de 🟠 2 la permite en esa celda y solo ahí), o se lleva al dueño para firmarla como sexta?
