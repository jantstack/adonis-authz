# Lote R (plan 2.5) — informe del implementador (2026-10-14)

**Rama `lote-r`, worktree `/home/jose/proyectos/Personal/adonis-authz-loteR`** (base `main` = `0fbee6e`). Un commit al final;
`main` sin tocar. Entorno medido: Node 22.23.2 (`nvm use 22`), `postgres18` (base `authz_test_r_<hex>`, borrada al terminar:
0 huérfanas), OpenFGA **`:8090`** (`openfga-dev`; **`:8101` NO responde en esta máquina** —`curl /healthz` falla—, así que todo
lo de OpenFGA se midió contra `:8090`, compartido con las suites del otro agente; no se reinició ningún contenedor).

## Qué existe ahora (antes del lote: nada de esto)

| Pieza | Fichero | Qué hace |
|---|---|---|
| Mutante «bandera inerte» | `tests/helpers/ace.ts` (hook `inertFlagMutant`, ref-counted) | Con `AUTHZ_INERT_FLAG=<comando>#<propiedad>` deja esa bandera inerte SOLO alrededor de `kernel.exec`: multi-palabra ⇒ `flag.name = flag.flagName` (exactamente alpha.8: el valor cae en `this['dry-run']`); una palabra (`to`, `force`, `prune`…) ⇒ `this['to__inert']`, porque ahí «reintroducir `name:`» es un mutante EQUIVALENTE (`name === flagName`, el caso benigno que señaló el tester). La guardia estática A-G no lo ve (mira fuente y flags en reposo): solo muere un caso de EFECTO. Mutante que no aplica ⇒ lanza (ruidoso). Ref-count porque dos `exec` se solapan cuando un caso muere por timeout de Japa (medido con `--url`). |
| Enumeración por reflexión | `tests/helpers/list_flags.ts` | Los flags BOOTEADOS del loader `commands/main.ts`: 36 banderas en 10 comandos (34 del tester + los dos `--allow-stale-source` de alpha.10). |
| Gate 1 | `scripts/check_flag_mutants.mjs` + `scripts/flag_mutants.manifest.json` · `npm run check:flag-mutants` | Base verde obligatoria (si no, exit 2 y no mide); un mutante por bandera sobre `tests/commands.spec.ts` + `tests/command_flags*.spec.ts` (leídos del disco; `--files` de Japa casa el nombre EXACTO); tabla bandera × comando × caso que la mató; vivo sin exención ⇒ exit 1; exención rancia ⇒ exit 1; no aplica / suite rota ⇒ exit 2; `pending` = banderas futuras (`--allow-drop-deny` lote D, `--prune-undeclared` lote C) listadas sin romper y juzgadas en cuanto existan. `--only=`, `--json=`, `--verbose`. |
| Casos que faltaban | `tests/command_flags_r.spec.ts` (R-1…R-8) | Los 9 mutantes vivos medidos: `provision --url` (ya moría por A-4 de `commands.spec`, que el script no incluía por el filtro), `--store-id` y `--name` SIN servidor (el stub mudo dice URL y cuerpo), `catalog:sync --keep-links` (vínculo en `authz_role_permissions`), `requeue --force` (opciones al manager), `reconcile --from` y `relations:reconcile --from` con **tres drivers** (la receta del tester: sin descarte posible; el destino LEE una página porque la resolución del origen es perezosa), `relations --prune` (tupla sobrante borrada/no), `relations --allow-mass-delete` (seguro levantado ⇒ borra). |
| Hijo por fase | `tests/helpers/cutover_child.ts` | `bootApp({ reuse })` + manager REAL de la fase (dos drivers de roles, dos de relaciones, `demo_scopes`, outbox SQL, reloj inyectado) registrado en el contenedor global como **Proxy al manager vigente, renovado en cada `exec`** (cada `node ace` de producción es un proceso: sin esto `authz:freeze` dejaba `#heldFreeze` en memoria y el reconcile «corría dentro» en vez de leer la fila; la ventana CADUCADA no se habría visto). IPC por `fork`: `exec` (kernel de ace), `clock`, `seed`, `questions` (las 448), `relate/check/enumerateRelations`, `storeDump`, `freezeRow`, `acquirePassFreeze`, `detach`, `deleteScopeRow`, `authzCensus`. Deadline FGA 20 s (`CUTOVER_RUNBOOK_FGA_TIMEOUT_MS`) porque el servidor es compartido. |
| Gate 2 | `tests/cutover_runbook.spec.ts` + `scripts/cutover_runbook.mjs` · `npm run cutover-runbook` | Un caso con pasos numerados (abajo), tope por orden 30 s, hallazgos acumulados que ponen rojo al final sin cortar el recorrido, `pending` para D; y el caso «docs con dientes»: cada `node ace …` del bloque bash de «The cutover window» del README tiene su paso (mismo comando; valores LITERALES iguales, `<…>`/`"…"`/`$VAR` comodín; corchetes = opcionales). Sin `.skip`: en `:memory:` o sin OpenFGA no registra nada salvo `CUTOVER_RUNBOOK_REQUIRED=1`, que registra un caso ROJO. El script valida motor y `/healthz`, exige ≥ 2 casos, 0 rojos, 0 skips y presupuesto (`CUTOVER_RUNBOOK_BUDGET_MS`, 60 s). |
| CI | `.github/workflows/ci.yml` | Jobs nuevos `flag-mutants` (sin servicios) y `cutover-runbook` (matriz `pg` + `sqlite-file`, servicio postgres 18 + contenedor OpenFGA 1.19). |
| Docs | `CLAUDE.md` «Comandos» (los dos gates, cómo se corren) y punto 9 (nombra los comandos); nota de `:8101` → `:8090` | `package.json`: `check:flag-mutants`, `cutover-runbook`. |

## Rojos observados (rojo primero)

1. **Script de mutantes sobre HEAD, primer operador** (reintroducir `name:` en ejecución): 36 mutantes, **19 vivos**, 33,7 s. 16 de
   los 19 eran banderas de UNA palabra: mutante equivalente. Corregido el operador (`__inert`): **9 vivos** (`--url`,
   `--store-id`, `--name`, `--keep-links`, `requeue --force`, `reconcile --from`, `relations --from/--prune/--allow-mass-delete`),
   que coinciden con las 7 «sin caso» + presencias del tester (menos las que alpha.10 ya cerró: `relations --dry-run` muere por
   S1d, `reconcile --prune` por M2-b, `--only` por S6, `--fence` por ⚪ 5). `--url` estaba vivo solo porque el filtro `--files`
   de Japa casa el NOMBRE EXACTO y `commands.spec` no entraba: ahora los ficheros se leen del disco.
2. **Demo del bug de alpha.8 a mano**: `name: 'dry-run'` en `commands/authz_reconcile.ts` ⇒ `npm run check:flag-mutants` sale **2**
   antes de medir: «la suite BASE no está verde (4 rojos)» (A-G-1, A-G-3, A-5, alpha.10 · 1c). Con `--only=authz:reconcile#dryRun`
   también 2: la reflexión ya no encuentra la propiedad `dryRun` (la ve como `dry-run`). Restaurado con `git checkout`.
3. **Runbook**: la primera pasada completa paró en el paso 13 (ver F-R1). La guardia del README salió roja cada vez que el
   recorrido se cortaba antes de ejecutar una línea (p. ej. 7 de 7 sin paso con el paso 0 roto).
4. **Demo «paso del README borrado»**: quitando los DOS `authz:reconcile --to=openfga --dry-run` del paso 13, el caso «docs con
   dientes» sale rojo nombrando exactamente `node ace authz:reconcile --to=openfga --dry-run`. (La primera versión del
   comparador solo miraba NOMBRES de bandera y un `--to=database` respaldaba un `--to=openfga`: ahora compara valores literales.)

## Estado final de los gates

**Mutantes de banderas (`:memory:`, sin OpenFGA): 36/36 muertos, 0 vivos, 0 exenciones, 2 pendientes.** Base 79 casos / 1,2 s.
Tiempo: **52,1 s solo** (36 corridas × ~1,2 s + enumeración); 33,7 s con 71 casos base y antes de los casos R; **66,7 s con el
runbook de pg y la suite entera corriendo a la vez**. El juez asumió ~29 s (medida del tester con 34 banderas sobre un árbol más
pequeño): aquí es ~50 s; cabe en un job propio, no en `npm test`.

| comando | bandera | lo mata |
|---|---|---|
| openfga:provision | --url · --store-id · --name | A-4 (commands) · R-1 · R-2 |
| authz:catalog:diff | --fail-on-shadows | A-10 |
| authz:catalog:sync | --keep-links | R-3 |
| authz:catalog:prune-orphans | --force · --allow-mass-purge | A-9 · A-9 |
| authz:scopes:relay | --dry-run · --limit · --batch-size · --only · --wait-lease-ms · --max-age | A-1 (3) · A-2 (2) · A-3 · S6 (5) · A-3 · A-2 (2) |
| authz:scopes:requeue | --id · --force · --apply · --wait-lease-ms | R-4 (2) · R-4 · A-4 · A-4 |
| authz:reconcile | --to · --from · --dry-run · --prune · --allow-mass-delete · --allow-stale-source · --batch-size · --max-tuples | 10 casos · R-5 · A-5 (2) · M2-b · A-6 · alpha.10 · 1b · A-6 · A-6 |
| authz:relations:reconcile | --to · --from · --dry-run · --prune · --allow-mass-delete · --allow-stale-source · --partition-type · --partition-uuid | 11 casos · R-6 · S1d (2) · R-7 (2) · R-8 · S1d · A-7 (3) · A-7 (3) |
| authz:freeze | --reason · --lease-ms | A-8 (2) · A-8 (2) |
| authz:unfreeze | --fence | cierre · ⚪ 5 |
| openfga:provision | --allow-drop-deny | **pendiente (lote D)** |
| authz:relations:reconcile | --prune-undeclared | **pendiente (lote C)** |

**Runbook: 20 pasos en verde + 2 `pending` en pg Y en sqlite-file; guardia del README verde (7 líneas, 42 invocaciones por el
kernel); el caso sale ROJO por UN hallazgo (F-R1, abajo).** Tiempos: sqlite-file **9 s de suite / 14,2 s de job**; pg **13 s /
19,3 s** (bajo carga del otro agente). Dentro del presupuesto de 60 s del script (el tester pedía 30 s de suite: se cumple).
Ejecutado: `TEST_DB=sqlite-file OPENFGA_TEST_URL=http://localhost:8090 npm run cutover-runbook` y lo mismo con `TEST_DB=pg
TEST_PG_URL=…/authz_test_r`. (mysql no se ejecutó: el job de CI lleva pg + sqlite-file, como pide el punto 10.)

Pasos (M5 × comandos; `*` = línea del README): 0 `openfga:provision --url --name` (modelo con `rooted`, `can_`/`denied_`/
`permits_`, `document`, `group`) · **ANTES (database)**: 1 `catalog:sync` + `catalog:diff` (versión +1) · 2 siembra
(`runMigrationContract`: 7 nodos, 6 holders, 14 grants, 6 denies + relaciones en org A (viewer, member de group, group#member
editor) y org B) · 3 `reconcile --to=openfga --from=database --dry-run` ⇒ DERIVA, 0 tuplas · 4 `freeze --reason`\* ⇒ fila
`operator:` sin caducidad, **otro proceso** (`freeze_child`) 503 `E_AUTHZ_FROZEN` · 5 `relations:reconcile … --partition-* --dry-run`\*
⇒ exit 1, 0 tuplas de relación · 6 `relations:reconcile` A y B\* ⇒ store = origen por partición · 7 `reconcile --to=openfga
--from=database`\* ⇒ «dentro de la ventana del operador», **448 respuestas iguales** · 8 `--prune` sobre el store COMPARTIDO ⇒
relaciones intactas, «ajenas» · 9 verificadores con `--from … --dry-run`\* en verde · 10 `unfreeze`\* ⇒ fila limpia, el otro proceso
escribe · **DESPUÉS (openfga)**: 11 revoke, deny, `scopes.detached` + `authz:scopes:relay` purga del store · 12 **REPETIDA rancia**:
`--from=database` con y sin `--prune` y relaciones ⇒ refusadas, store idéntico, la revocación sigue · 13 mantenimiento
`--to=openfga --dry-run`\* y `--prune` tras borrar una fila del árbol sin `detached` (**F-R1**) · 14 **CADUCADA**: reloj −10 min,
`freeze --lease-ms=60000`, reloj 0 ⇒ el otro proceso escribe, `reconcile` 503 «CADUCÓ el», fila conserva el rastro, `unfreeze` exit 1
con hora ISO y limpia, segundo `unfreeze` éxito · 15 ventana ADOPTADA con lease ⇒ «CADUCA el» · 16 **ABORTADA**: freeze de una pasada
muerta con lease vivo ⇒ reconcile `E_AUTHZ_FREEZE_HELD`, `unfreeze` exit 1 «--fence=N», `--fence=N` levanta; con lease vencido la
pasada lo pisa («SU PROPIA ventana») · 17 vuelta ANTES del switch: `--to=database --from=openfga --prune`, relaciones por partición,
verificador, 448 iguales, `unfreeze` · **VUELTA (database)**: 18 paridad 448 y la revocación en `authz_*` · 19 **REPETIDA rancia con
database activo**: `--to=database` sin `--from`, con `--from=openfga`, relaciones ⇒ refusadas, censo intacto (el «paso 16 sin
decisión» del tester: alpha.10 lo decidió y aquí queda fijado) · 20/21 `pending` lote D.

## Hallazgos (repro = el paso del runbook; ninguno se arregla en R: son `src/`)

- **F-R1 (🟡, punto 7 — la salida miente de rama).** `authz:reconcile --to=openfga --prune` con `openfga` ACTIVO (mantenimiento)
  y una fila de `demo_scopes` borrada sin `detached`: la pasada BORRA las 4 tuplas del scope muerto («borradas 4», el store ya no
  las tiene, el `--dry-run` siguiente es «Sin deriva») y a la vez cuenta los 2 `assignee` en `skipped.unknown-scope`
  (`openfga_driver.ts:3078` anota y descarta ANTES de que `--prune` los borre como sobrantes), así que `reconcileLines` lo hace deriva
  ⇒ «Queda algo que esta pasada no arregla sola: repítela cuando lo hayas resuelto», **exit 1 sobre una pasada que sí lo arregló**.
  Cierre probable: con `prune`, lo que se descarta por `unknown-scope` y se borra no es `skipped` (o `reconcileLines` no lo cuenta
  como deriva cuando `deleted` lo cubre), con tabla de verdad `prune × unknown-scope × dryRun`. Hasta entonces el job
  `cutover-runbook` está ROJO por esto: un gate que tolera lo que encuentra es ceremonia. Decisión del dueño: arreglarlo (lote 0/A,
  pequeño) o firmar que el exit 1 es intencional (entonces el paso pasa a afirmarlo y el README tiene que decirlo).
- **F-R2 (🟡, punto 7).** `authz:relations:reconcile --prune --allow-mass-delete` con origen vacío: BORRA (efecto correcto) pero la
  letra de `relationsReconcileLines` con `massDelete: true` sigue siendo «--prune borraría N … En una pasada real es 500
  E_AUTHZ_MASS_RECONCILE_REFUSED; si de verdad quieres vaciar el destino, --allow-mass-delete» y exit 1, aunque YA vació con la
  bandera. R-8 afirma el EFECTO y deja la letra documentada.
- **F-R3 (⚪, punto 7, gemelos).** `authz:reconcile` con un freeze VIVO de otra pasada (423 `E_AUTHZ_FREEZE_HELD`) sale como error
  crudo (`cmd.error`), mientras `authz:relations:reconcile` lo imprime como letra con exit 1 (lo captura). Asimetría comando↔gemelo.
- **⚪ harness.** `kernel.exec` relanza lo que ace rechaza al parsear (ya documentado) Y un caso que muere por timeout de Japa deja
  su `exec` en vuelo: cualquier instrumentación por estado compartido alrededor de `exec` tiene que contar referencias.
- **⚪ entorno.** Una corrida del runbook se colgó sin salida (antes de los topes por orden; no reproducido después). Con tope de
  30 s por orden y 5 s por parada de hijo el job nunca se queda colgado; un deadline FGA de 5 s dio 503 bajo la carga del otro
  agente sobre `:8090` (ampliado a 20 s en el hijo).

## Qué queda `pending` para D (ganchos en `tests/cutover_runbook.spec.ts`, pasos 20 y 21, y en el manifiesto)

- `pending(20)`: opt-in del deny en dos fases — fase 1 ⇒ `deny` 422; fase 2 (modelo con `denied_*`) ⇒ deny vivo y `check = false`
  en los dos drivers; siembra de denies directos y por grupo; censo con `listDenies`. Se activa convirtiéndolo en `step(…)` con sus
  `exec` por el kernel y, si entra en el README, su línea en el bloque bash.
- `pending(21)`: rollback prohibido con denies vivos — retirar el opt-in ⇒ `openfga:provision` exit 1 / 500 salvo
  `--allow-drop-deny`; la vuelta a `database` no deja un deny sin honrar.
- Manifiesto: `openfga:provision --allow-drop-deny` (D) y `authz:relations:reconcile --prune-undeclared` (C) como `pending`: cuando
  existan se juzgan solas (y sin caso de efecto el gate se pone rojo).

## Verificación

`tsc`/`typecheck` ✔ · `check:purity` ✔ · `build` ✔ · `npm test` (`:memory:`, sin OpenFGA) **1175/1175** ✔ · kernel specs en
`sqlite-file` 79/79 ✔ · `command_flags_r` 8/8 en `:memory:` y `sqlite-file` ✔ · `check:flag-mutants` 36/36 ✔ (52 s) ·
`cutover-runbook` sqlite-file y pg: 20 pasos + guardia README ✔, caso rojo por F-R1. No se corrió la suite completa en pg/mysql
(el otro agente la corre en `main` contra las mismas bases; `ace.ts` solo cambia con `AUTHZ_INERT_FLAG` puesto).

Sin cambios en `src/`, `commands/`, README ni CHANGELOG (no hay cambio de semántica del paquete; el runbook del README se afirma
tal cual). Ficheros nuevos: `scripts/check_flag_mutants.mjs`, `scripts/flag_mutants.manifest.json`, `scripts/cutover_runbook.mjs`,
`tests/command_flags_r.spec.ts`, `tests/cutover_runbook.spec.ts`, `tests/helpers/cutover_child.ts`, `tests/helpers/list_flags.ts`.
Modificados: `tests/helpers/ace.ts`, `.github/workflows/ci.yml`, `package.json`, `CLAUDE.md`.
