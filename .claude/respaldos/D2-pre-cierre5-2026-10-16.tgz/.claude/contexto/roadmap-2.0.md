# Roadmap 2.0 de `@jantstack/adonis-authz` — fases, contenido, entregable y versión

> Consolidado 2026-08-28 a partir de los dos paneles (juez 1 y juez 2) y las decisiones del dueño
> (`decisiones-dueno-2026-08-28.md`). Estimaciones en días de trabajo efectivo. Cada fase cierra con
> el mismo circuito de garantías: test rojo→verde por pieza · typecheck · `npm test` · OpenFGA `:8101` ·
> OpenFGA tope 3 · revisión de `tester-contrato` (ejecutando criterios) + `auditor-seguridad` (diff) +
> `/code-review` · correcciones · verificación final · commit del dueño.

| Fase | Nombre | Días | Versión | Estado |
|---|---|---|---|---|
| 0 | Desbloqueo del juez | 2 | — | ✅ `4d807d3` |
| 1 | L0 · lote de seguridad + `scopes.*` | ~8 | **2.0.0** | siguiente |
| 2 | Primitivas de motor + optimización | ~4 | 2.1 | |
| 2.5 | Infra de test restante (reloj, PG/MySQL) | 1,5 | — | |
| 3 | `catalog/` · roles por scope | 4,5 | 2.2 | |
| 3b | Driver `openfga` = `facts` + `reconcile` | ~10 | 2.3 | |
| 4 | `relations/` · ReBAC | ~10,5 | 2.4 | |
| 5 | `http/` · `resourceAccess` | 2,5 | 2.5 | |
| 6 | Consolidación modular + docs | 2,5 | 2.5 | |
| — | `2.4.0-alpha.2` · R-15 (caducidad en la tupla de relación) + `{trx}` en los dos puertos (panel `{trx}`, veredicto (C)) | ~6 | **2.4.0-alpha.2** | ✅ lotes R-15, L-0…L-5, L-4b, L-6; pendiente commit y release del dueño |
| — | Diferido (deny con caducidad, `from`) | 2+ | 2.6+ | |
| | **Total** | **~52** | | |

---

## Fase 0 · Desbloqueo del juez — ✅ hecha
Juez con `level`/`capabilities` (par obligatorio, `true` sin par lanza), `ContractScopeTree` (herencia probada con árbol real de 3 niveles), 7 casos 2.0 + 3 core nuevos, `list*` por igualdad de conjunto, `check:purity` en `npm test`, CI con segundo OpenFGA (tope 3), teardown de stores. Sin cambios en drivers. 40→70 / 67→110 tests.

## Fase 1 · L0: lote de seguridad + `scopes.*` — **2.0.0** (breaking)
Cierra los defectos presentes reproducidos en 1.1.0. Ningún flag de compatibilidad (no hay consumidores).
- **L0.1** `whereScopeIn([])`: lectura ⇒ vacío sin ir a BD; escritura ⇒ lanza.
- **L0.2** `holderTypes` inyectivo, verificado en el constructor del driver openfga.
- **L0.3** `UnknownScopeError`: `resolveAncestors → null` ⇒ `authorize` false, `grant/deny/hasRole` 422; sin resolutor y con roles de tipo ≠ `app` ⇒ lanza en la primera llamada. Desaparece el default plano `[APP_SCOPE]`.
- **L0.4** `expiresAt`: `undefined` preserva caducidad vigente, `null` la quita, expirada revive (sin romper el juez: verificado).
- **L0.5** `assertIdentityComponent` en el manager (422): uuid vacío/`undefined`/con `#`, tipos no declarados, longitudes contra columnas. Cierra `user:undefined` y el 400→503 disfrazado.
- **L0.6** `appAccess({ role })` **retirado** (tipo + throw con receta); `hasRole(s, {slug, scopeType}, scope)`; caso que fija que el deny NO gobierna `hasRole`.
- **L0.7** Enumeraciones openfga por `Read` paginado (`listBindings`, denies de `listScopes`, `listSubjects`): cierra el fail-open de denies truncados. Par `truncationSignal:true` rojo→verde con el servidor de tope 3.
- **L0.8a** `assertValidSlug` en drivers en `grant/deny/revoke/removeDeny` y al leer bindings (cierra `removeDeny('docs~read')`); exportada con 422; longitudes ≤ 50/256, reservados (`parent`, `binding`, `ancestor`, `role`, `assignee`), familias (`can_`, `denied_`, `permits_`).
- **L0.9** `syncAuthzCatalog(catalog, { prune: 'links' })` + `authz:catalog:diff` (el sync ya no deja privilegios zombi).
- **L0.10** `{type:'app', uuid≠null}` ⇒ 422 en ambos drivers.
- **L0.11** Catálogo SQL caído ⇒ `AuthorizationBackendError` 503 en ambos drivers; resolutor que lanza ⇒ 503.
- **L0.13** `timeout` configurable ⇒ 503 (hoy `authorize` se cuelga).
- **L0.14** `batchCheckAll` correlaciona por `correlation_id`, no por posición.
- **L0.15/16** uuid centinela en tipo ≠ app ⇒ 422; `parseBindingId` registra ids no parseables.
- **`context` en TODOS los checks** (incluidos denies) y `HIGHER_CONSISTENCY` por defecto.
- **`scopes.attached/moved/detached`** en el manager + `purgeScope` en el puerto (ambos drivers) + **anti-ciclos y validación de existencia en el paquete** (N7, N8, N9 del tester pasan a core).
- Import openfga sin `onDuplicateWrites: Ignore` (delete+write ante condición distinta; falla si el store no está vacío sin `--reconcile`) — precursor de `reconcile`.
- Pendientes de Fase 0: regex de pureza (template literal, comentarios), test de symlink, test del script de prune.
- CHANGELOG 2.0.0 completo (problema → decisión → qué NO se hace). README honesto (las 5 promesas falsas corregidas).

## Fase 2 · Primitivas de motor + optimización — 2.1 (aditivo)
- `GrantOptions.within` + `isWithin()` (contención en la cadena; `requireWithin` sin flag: obligatorio cuando se declara).
- `authorizedScopes(subject, permission, scopeType) → none | some{scopes} | all{excludedSubtrees}` — nunca `all` con denies vivos; sin `descendantsOf` o `maxScopes` superado ⇒ lanza. Excepción explícita al invariante 7.
- `descendantsOf` como puerto del consumidor + `sqlDescendantsOf({table, uuidColumn, parentColumn, maxNodes})` opt-in (por dialecto o throw).
- `hierarchicalScopeResolver({ parentOf, maxDepth: 64 })` anti-ciclos, cota que lanza.
- `memoizeAncestors` (memo de una llamada, solo lectura, instanciado por request por el consumidor).
- `effectivePermissions(subject, scope)` (composición; resta denies) — prerrequisito de `catalog/`.
- `authorizeMany` (composición + `authorizeMany?` opcional; openfga = batchCheck).
- `actor` + `requireActor` en `AuthzWriteEvent`/`GrantOptions`.
- **Optimización**: memo del catálogo invalidado en `syncAuthzCatalog` + un solo `batchCheck` (denies + roles). Medido: 6,35 → 3,76 ms p50.

## Fase 2.5 · Infra de test restante — sin release
- Reloj inyectable (`now()` en ambos drivers y en `context.current_time`).
- Harness multi-motor (`TEST_DB=sqlite|pg|mysql`) con pool ≥ 2 (la máquina ya tiene pg18/mysql84). Sin esto no hay `{trx}` ni cobertura real de lo que el README anuncia.

## Fase 3 · `catalog/` — roles globales o locales a un scope — 2.2
- `authz_roles.owner_scope_key` (`'global'` reservado; `unique(slug, scope_type, owner_scope_key)`); identidad externa = uuid siempre.
- Resolución por `owner ∈ chain(scope) ∪ global`; colisión local/global ⇒ throw; grant de rol local fuera de su contenedor ⇒ throw.
- **Binding id FGA por uuid de rol** `role_binding:<scopeKey>|<roleUuid>` (sin comando de migración: no hay stores en producción).
- `purgeRole` (revocar todo + borrar, misma trx), `defineScopedRole(actor, ownerScope, spec)` con policy (`permissions ⊆ effectivePermissions(actor)`, `⊆ delegablePermissions`, `0 < rank < actorRank`), globales inmutables, `onCatalogWrite`.
- `assignableAt` como control de composición (nunca de evaluación); `authz:catalog:diff` falla en CI.
- +20 casos de contrato (colisión en ambas direcciones, bordes de rank y slug, `purgeRole` con descendientes, deny × rol local, migración de datos).

## Fase 3b · Driver `openfga` = `facts` único + `reconcile` — 2.3
"Todo en un driver o todo en otro." Se elimina el modo `resolver`.
- Modelo (c2): `role#permits_P@<holder>:*`, `role_binding#assignee/role`, `scope#parent/binding`, `can_P = P but not denied_P`, `ancestor`. Generador desde el catálogo; `syncAuthzCatalog` publica modelo y pinea `modelId`; techo de 262 KB (~720 permisos) validado con aviso al 80 %.
- `authorize` = 1 `Check` (+ memo de catálogo para el invariante 5). `hasRole`/`list*` siguen usando `resolveAncestors` — declarado en capacidades (`singleCheckAuthorize`, `roleInheritanceNative:false`, `listObjectsInherited:false`, `maxDepth`, `catalogInModel`) con casos A1–A6.
- `scopes.*` en facts: `attached` (1 tupla), `moved` = `Read` padre + **un `Write` atómico** (deletes+writes; >1 padre ⇒ lanza), `detached` = hechos primero demostrando cero, arista al final.
- `grant` = 3 tuplas idempotentes; renovar = delete+write que lanza si falla el 2.º paso.
- **Outbox** opcional (`scopes.outbox` + `authz:scopes:relay` + stub) y **gate**: el driver no se construye sin outbox ni `acceptScopeDriftRisk: true`.
- **`authz:reconcile --to=openfga|database [--dry-run] [--force]`**: única primitiva de migración/verificación; idempotente, reanudable (lotes ≤ 100 con cursor), nunca silenciosa (`written/deleted/updated/skipped{razón}`); `--dry-run` = verify (aristas + catálogo + hechos, con detección de ciclos y sobrantes).
- `manager.freeze()` durante la migración (escrituras 503 reintentable, lecturas siguen; `finally` descongela).
- Contrato de migración (`MIGRATION_FIXTURE` + 448 preguntas, `report.skipped` contado, pérdidas declaradas: expiradas, ms en MySQL, scopes fantasma, collation).
- README: qué promete `facts` exactamente y qué obligaciones tiene el consumidor (árbol en dos sitios, backup coordinado, permiso nuevo = modelo nuevo).

## Fase 4 · `relations/` — ReBAC genérico — 2.4
- Puerto: `relate/unrelate/check/listObjects(lote)/listSubjects/purgeObject/purgeSubject`, `partition: ScopeRef` obligatoria (`APP_SCOPE` válido para mono-tenant).
- Modelo declarativo (`defineRelationsConfig`): `includes` (sin `from` en v1), usersets de un nivel con `usersetsOf`; `membersOf` en opciones del driver `database` (no en el puerto común).
- **Partición en los ids de objeto Y de userset** (`unit:<partitionKey>|<uuid>#member`): "userset de otra partición ⇒ throw" por comparación de string, sin `scopeOf`.
- Driver `database` (`authz_relations`, `{trx}` externa, `relationPartitionTrigger` por dialecto o throw) y driver `openfga` (fusión de modelo con `facts`, purgas exhaustivas que lanzan si no demuestran cero).
- `assertWrite` puro en el manager (obligatorio aquí, opcional en `roles/`), `actor` en `onRelationWrite`.
- Frontera por construcción: regla de grafo en `check_purity` (ya preparada) + casos "tupla viewer no hace `roles.authorize` true" y viceversa.
- ~34 casos (18 núcleo / 12 anexo / 4 negativos) + tablas ficticias del consumidor. Diseñado contra dos casos: llaves COGNITIV y "compartir documento estilo Drive".

## Fase 5 · `http/` — `resourceAccess` — 2.5
- `resourceAccess({ resource, param, containerParam, permission, readPermission })` con `load(ctx, id) → {scope} | null` y `gate(ctx)` del consumidor; orden 401 → 403 ability → 404 contenedor → 404 recurso (mismo cuerpo) → `authorize`; `AuthorizationBackendError` nunca disfrazado; **prohibido `role`**; sin segundo `authorize`.
- Harness `fakeCtx` (orden de respuestas, `next` con contador, propagación) + 12 casos.

## Fase 6 · Consolidación modular + docs — 2.5
- Estructura definitiva de módulos (`roles/`, `relations/`, `catalog/`, `http/`) sin mover el export raíz; `configure` interactivo; stubs y migraciones separadas por módulo.
- README de módulos, guía de upgrade 1.x → 2.x, CHANGELOG consolidado.

## 2.4.0-alpha.2 · R-15 + `{trx}` en los dos puertos — ✅ hecho (2026-09-01/02; panel `{trx}` → veredicto (C), 90/100)
Adelantado por decisión del dueño (`decisiones-dueno-2026-08-28.md`, «2026-09-01 (3)»): COGNITIV verificó 7/9 y los dos ❌ eran la caducidad en la tupla de relación y `{trx}`. Encuadre del dueño: *cada driver declara lo que puede y el cliente ajusta*; ningún consumidor es criterio.
- **R-15** · `relate(…, { expiresAt })` con los tres estados del invariante 10, caducidad estricta, `authz_relations.expires_at` (`DATETIME(3)`), `with not_expired` en el modelo fusionado, `withClock` en los dos drivers de relaciones, `skipped.expired`/`updated` en el reconcile de relaciones. Receta `ALTER` en el README.
- **`{trx}` = capacidad `transactionalWrites`** en las DOS interfaces de capacidades, que significa EXACTAMENTE «los dos o ninguno con TU transacción», jamás «no se pierde». **Dos puertas, no «falla al construirse»**: puerta 1 por llamada (`{ transaction }` a un driver `false` ⇒ **500 `E_AUTHZ_UNSUPPORTED`** nombrando driver, operación y las dos salidas, cero llamadas al driver) y puerta 2 opt-in (`requireTransactionalWrites: true` ⇒ **500 `E_AUTHZ_CONFIG` al RESOLVER** el driver: el despliegue no arranca, sin inutilizar un driver que solo está registrado). La frase «el manager falla al construirse si el driver no la soporta» la tumbaron los dos panelistas (L-2): haría `openfga` inconstruible en cualquier app que lo tenga registrado, y el driver se resuelve perezosamente y por nombre.
- **`database` la cumple de verdad** en roles (L-3) y relaciones (L-4): la ESCRITURA va por la trx del llamante (`assertCallerTransaction` contra SU conexión), la AUTORIDAD (freeze, catálogo, `resolveChain`, F-05, `assertWrite`) nunca; juzgado por CENSO en `sqlite-file`/PG/MySQL; choque del UNIQUE o deadlock dentro de la trx ⇒ 409 que envenena la trx (PG abortada, MySQL viva, sqlite-file `SQLITE_BUSY` 503), medido por motor. **Exige pool ≥ 2** (decisión del dueño): con pool 1 es 503 a `freezeTimeoutMs`, nunca cuelgue ni bypass; `:memory:` declara `false`.
- **`openfga` rechaza con dientes** (L-5): `false` explícito, el driver re-valida (`manager.driver()` no es salida), medido contra el `:8101` con espía; paridad que fija la asimetría a propósito. Lo que ofrece es la **receta por dirección** del README (permisivo tras el commit, restrictivo antes/dentro): no compone y el paquete no la automatiza (L-6, con caso).
- **Agujeros de HOY cerrados antes** (L-0, L-1): F-05 en los DOS drivers de relaciones y en `reconcileRelations`; la barrera del freeze la lee el MOTOR (un snapshot del llamante no la salta; deadline TOTAL con la espera del pool); `sqlScopeOutbox` juzga de quién es la transacción; relaciones bajo la misma barrera y su reconcile bajo ventana durable. **L-4b**: `subject_relation NOT NULL DEFAULT ''` (el UNIQUE defendía solo usersets).
- **Descartado con número** (juez): (A) outbox de hechos — fail-open 1,16 s mediana / 2,28 s cola, 131,5 entradas/s no paralelizables (38 s para 5.000), aparcado irreparable, resurrección medida; (B) firma que miente (cero filas SQL en `facts`); (E) provisional de 30 s indistinguible de una caducidad legítima.
- Informes: `r15-informe.md`, `l0..l5-informe.md`, `l4b-informe.md`, `l6-informe.md`; el veredicto en `panel-trx-juez.md`.

## 2.5 · Pendientes del panel relay (`2.4.0-alpha.5`, decisiones del dueño del 2026-09-09 (2))
- **`authz:reconcile` acotado por SUBÁRBOL/tenant, con `--dry-run`** (panel relay 2, cuestión 3, decisión del dueño
  2026-09-10 (4)): es el requisito TRADUCIDO del «supersede» de COGNITIV (una aparcada superada por un `moved` posterior del
  mismo hijo), que se decidió NO hacer en ninguna forma (fail-open medido por el auditor). Hoy el remedio es el reconcile
  entero (`--to=<driver>`), que recalcula con el árbol de HOY; falta poder decir «solo este subárbol».
- **`sqlScopeOutbox({ requireTransaction })` pasa a default `true`** (panel relay 2, cuestión 6; dueño: anunciado en alpha.8
  en README y CHANGELOG). PRERREQUISITO: que el `ctx()` del contrato publicado (`runScopeOutboxContract`) pase la
  transacción del harness (`transactions.begin()`), con su par de capacidad; sin eso el default no puede cambiar sin poner
  en rojo a todo tercero. Valorar entonces un gate en el MANAGER (`scopes.requireOutboxTransaction`, injerto del juez)
  para implementaciones de terceros del puerto: hoy la opción vive en la outbox porque el manager no la construye.
- ~~`createdAt` como par de capacidad del juez de la outbox~~ — **HECHO en alpha.8 (lote II)**: el juez lo decidió como
  «campo opcional que degrada, par en 2.5»; la spec del lote lo pidió como par y así está (17 casos por harness).
- ~~Barrido ÚNICO de `enumerateRelations` para K particiones~~ — **HECHO en `2.4.0-alpha.6`** (`enumerateRelationsMany`,
  `reconcileRelations({ partitions })` —privado desde el cierre de alpha.10; la vía pública es `runRelationsReconcile`—; informe `alpha6-informe.md`).
- **Retirar el lock VIEJO de MySQL** (`scopeOutboxLockNames().legacy`, el nombre recortado a 64): en alpha.5
  `acquire()` toma los dos para que un rolling deploy con alpha.4 no se pise. Al retirarlo, dos tablas con los mismos
  64 primeros caracteres dejan de compartir lease (hoy lo comparten en el viejo, a propósito). Un caso en MySQL.
- **Barrido de lo NO declarado en `relations/`: `authz:relations:reconcile --prune-undeclared`** (residuo DECLARADO del
  lote B de `2.4.0-alpha.9`; 🟠 3 del auditor del panel del store compartido y 🟡 del analista). Desde alpha.9 el
  reconcile de HECHOS respeta todo tipo de objeto que no sea suyo, así que las tuplas de un tipo de relación que el
  consumidor **quita o renombra** en `relations.config` **no las barre nadie**: `enumerateRelations` filtra por lista
  blanca, `reconcileRelations --prune` por tanto no las ve, y `unrelate`/`purgeObject` son 422 por F-05 — y
  **resucitan** (vuelven a conceder) si el tipo se re-declara. Antes se limpiaban por accidente, con el defecto que
  borraba también las vivas. Hoy la salida documentada (README) es declarar el tipo y correr
  `authz:relations:reconcile --prune`. Lo que falta es un barrido propio, con su nombre y su `--force`. **Descartado a
  propósito**: un `--prune-foreign` en el reconcile de hechos (borrado masivo de datos de otro dueño, accionable desde
  CI) y cualquier clasificación de borrado que lea la config en runtime.
- **Canal `driver.limits?.maxScopeChainDepth`** (juez, cuestión 5; pregunta 3 al dueño): que el driver DECLARE su
  techo y `scopes.maxDepth` lo tome por defecto. Hoy el mando es solo del config.
- **Sello durable del driver activo** (🟡 R5 del auditor de alpha.10; decisión del coordinador §2026-09-13 (6)). El guard
  de la dirección rancia (`manager.reconcile` y `runRelationsReconcile`) lee `config.default` /
  `relations.default ?? default` del PROCESO que ejecuta la pasada: un Job/pod de migración arrancado con otro entorno
  (p. ej. sin `AUTHZ_DRIVER`) cree que el activo es otro y el guard queda apagado en silencio — el 🔴 4 de COGNITIV por la
  puerta del entorno. Hoy está DECLARADO (README en los dos puertos + CHANGELOG de alpha.10). Para 2.5: sellar el driver
  activo en la fila `id=2` de `authz_catalog_version` (o una hermana) al cambiar de `default` —¿quién lo escribe: el
  provider al arrancar, un `authz:cutover` explícito?— y que el guard compare con el sello, con qué hacer si el sello y el
  config del proceso discrepan (¿500 nombrando ambos?). Requiere panel: toca la migración publicada y el arranque.
- **Identidad de backend declarada por el driver** (🟡 C1 del re-ataque del auditor al cierre de alpha.10; decisión del
  coordinador §2026-09-13 (7)). El guard de la dirección rancia compara la REFERENCIA de la factory (`#sameDriver`,
  `runRelationsReconcile`): dos factories distintas que construyen el mismo store (`openfga: () => new OpenFga…(…)`,
  `fga: () => new OpenFga…(…)` con el mismo `OPENFGA_STORE_ID`) pasan. Hoy DECLARADO (README ×2, CHANGELOG, CLAUDE.md,
  docblocks). Para 2.5: que el driver declare una identidad de backend (`capabilities.backendId` o un método barato que
  no escriba) y que el guard compare esa identidad sin construir de más —¿construir antes del guard es aceptable si el
  constructor no hace I/O?—; va junto al sello durable del driver activo (mismo panel).
- **Retirar `runRelationsReconcile` de `commands/` a una entrada propia** (cierre alpha.10 · R1): hoy la única vía pública
  de código para reconciliar relaciones vive en `@jantstack/adonis-authz/commands/authz_relations_reconcile` (arrastra
  `@adonisjs/core/ace`). Valorar un subpath `./relations/reconcile` que exporte SOLO la función con guard y ventana.

## Diferido (2.6+)
- **`composeScopeEdges` / `parentTable`+`parentScopeType` en `sqlScopeEdges` + caso EJECUTABLE E-2** (panel alpha.4, 2026-09-09; pregunta 2 de COGNITIV):
  un árbol repartido en varias tablas NO se cubre concatenando `sqlScopeEdges` (cada uno hace `LEFT JOIN` contra su propia tabla y descarta en silencio la fila cuyo
  padre vive en otra; `--prune` borraría esas aristas ⇒ subárbol entero denegando). En alpha.4 solo docs (README + E-1 de letra, «receta no verificada por la suite»).
  Para 2.6: helper de composición con cursor compuesto y/o `parentTable`, dos tablas nuevas en el espejo de `tests/helpers/schema.ts`, ×4 motores, y decidir antes
  `onMissingParent: 'skip' | 'throw'` (convertir el silencio en ruido vale más que el helper). Regla de tres: hoy un consumidor, ya resuelto por él.
- **Caso de EJECUCIÓN de los tres comandos sin guarda pre-base** (`authz:unfreeze`, `authz:catalog:prune-orphans`, `authz:scopes:relay`; tester alpha.4 · C-4):
  van directos a `services/main.js` (manager del contenedor GLOBAL de la suite, no de la app fixture) ⇒ el harness de `tests/helpers/ace.ts` sería bicéfalo y hay que
  escribirlo como lo que es («no revienta y llega a su lógica», no end-to-end), ~1-2 s ×4 motores. Los otros seis sí se ejecutan por el kernel desde alpha.4 (C-3).
- Deny con caducidad (precondición: `context` en todos los checks ✅ Fase 1), `from` en `relations/`, modelos Lucid de solo lectura (documentación). (`listDenies` se hizo en 2.1 · 2B; `{trx}` y R-15 en `2.4.0-alpha.2`.)
- **Invariante 13 en los runners publicados (roles Y relaciones)** (⚪ 11 del auditor de alpha.3, decisión 2026-09-02 (2c)): hoy `indeterminate: true` lo juzga solo el manager del paquete (casos C1/C3/C4/E5 y el parcial del cierre), así que un driver de terceros que clasifique su deadline como `AuthorizationBackendError` genérico —o que no tenga deadline, o cuya purga multi-request no marque `markPartialWrite`— pasa el contrato entero sin producir jamás un `indeterminate`. Falta un par de capacidad (o un hook del harness que provoque el deadline/el fallo a medias de forma portable) en `runAuthorizationDriverContract` y `runRelationsDriverContract`. Lote propio: toca los dos puertos y el conteo de los dos harnesses.

## Preguntas registradas para 3.0
- **(F) · `authz_*` como log durable de hechos también en `facts`, con el store como proyección reconstruible** (51,5/100 en el panel `{trx}`; decisión (2) del dueño, 2026-09-01 (3)). Es la ÚNICA vía por la que `openfga` podría llegar a tener `{trx}` de verdad; su precio es derogar «los hechos viven en el PDP» (firmado el 28-08) y aun así no daría «los dos o ninguno» en el PDP (el store sigue siendo una proyección con lag). Cero trabajo ahora.

## Backlog 2.7 (feedback COGNITIV T2, 2026-09-02)

- **Arista de membresía configurable en `relations/`**: `#principalCte` del driver `database`
  (`src/drivers/database_relations_driver.ts`, constantes `GROUP_TYPE='group'`/`GROUP_MEMBER='member'`)
  solo expande recursivamente `group#member`. Genérico: declarar en `defineRelationsConfig` qué pares
  `(tipo, relación)` son aristas de membresía, y que el modelo `openfga` fusionado las declare igual
  (paridad entre drivers, caso en `runRelationsDriverContract`). Workaround actual: usar `group` como
  tipo. No bloquea a COGNITIV; lo pidieron «sin prisa». Requiere panel: toca el puerto y el modelo.

- ~~2.5 · `only` y la exención de la purga~~ — **HECHO en `2.4.0-alpha.6`** (la sonda hereda el ORIGEN; `alpha6-informe.md`).

- **2.5 · reconcile de relaciones con K particiones: reporte parcial** (🟡 3 auditor alpha.6): si el `relate` de la
  partición 2 revienta, la 1 queda escrita, la 3 sin tocar y la excepción se lleva el reporte (sin contadores ni marca
  de escritura parcial). Fail-closed y reparable re-ejecutando (medido), pero el operador no ve qué quedó a medias.
  Arreglo: reporte por partición con `partial: true` y lo escrito hasta el fallo. ⚪: contar en el reporte las tuplas
  de particiones NO pedidas que el barrido vio (olvidar un tenant en `partitions[]` es silencioso hoy).

- ~~Retirar el lock viejo de MySQL~~ HECHO en alpha.7 (2026-09-10; sin consumidores que lo necesitaran). Guardia (cierre alpha.6): `SCOPE_OUTBOX_LEGACY_LOCK_UNTIL = '2.4.0-alpha.6'` + caso en `scope_outbox.spec.ts` que se pone en rojo al subir la versión sin poner `SCOPE_OUTBOX_TAKES_LEGACY_LOCK = false`. No es un pendiente: el bump lo exige.
