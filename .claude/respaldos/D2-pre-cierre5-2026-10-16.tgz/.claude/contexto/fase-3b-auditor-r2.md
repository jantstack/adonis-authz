# Auditoría adversarial de R2 — ¿se declara o se reabre?

**Encargo:** antes de escribir en el README que los dos drivers no responden igual en las tres
situaciones de R2, intentar demostrar que la declaración se queda corta. Concretamente: ¿(a) y (c)
son explotables MÁS ALLÁ de lo descrito? ¿Existe un camino por el que un actor sin privilegio
consiga, gracias a R2, algo que no consigue en `database`?

**Método:** commit `bd28e1b`, worktree de solo lectura, copia propia en scratchpad con
`node_modules` enlazado. Todo lo que se afirma aquí está **medido contra el OpenFGA real del
`:8101`** (modelo (c2) publicado por `openFgaFactsModel`, store nuevo por script, borrado en el
`finally`) y contra el driver `database` sobre el MISMO catálogo y el MISMO árbol, en la misma
ejecución, para que la comparación sea de paridad y no de memoria. Un caso usa el árbol SQL sobre
PostgreSQL 18 (base propia `auditor_r2_<sufijo>`, destruida al terminar). **Cero stores huérfanos**
en el `:8101` al acabar (comprobado enumerando: 0 con el prefijo `auditor-r2`), cero bases
`auditor_r2*` y ninguna base `authz_test*` tocada.

---

## Veredicto en una línea

**R2 se reabre como REDACCIÓN: no se puede declarar con esas palabras.** La divergencia sigue
siendo aceptable como capacidad —(b) es la propiedad comprada y no se discute—, pero (a) está
descrita como «un scope huérfano sigue concediendo» y lo que hace de verdad es **borrar los denies
de todo un subárbol a petición de un actor que tiene prohibido tocarlos**, y (c) está descrita como
fail-**closed** cuando el mismo mecanismo es fail-**open** en el camino de escritura. Además,
dos hallazgos de la COMPOSICIÓN (outbox del 2d) son bugs a arreglar con independencia de dónde viva
el árbol: uno convierte el «fail-open temporal de segundos» en **permanente y provocable a
voluntad**, y otro cruza tenants.

| # | Hallazgo | Clas. | ¿Reabre? |
|---|---|---|---|
| 1 | `scopes.detached` de un nodo intermedio es una primitiva de BORRADO DE DENIES para su subárbol | 🔴 | Sí — reabre la redacción de (a) |
| 2 | Un tapón en la outbox congela el árbol del store **para siempre** y lo pone cualquier tenant | 🔴 | Sí — bug a arreglar (2d) |
| 3 | El alias del uuid es fail-**OPEN** en `purgeScope`/`detached` cuando la fila ya no existe | 🟠 | Sí — desmiente la frase de (c) |
| 4 | Dos escritores del árbol dejan un nodo con DOS padres ⇒ herencia cruzada entre tenants | 🟠 | Bug a arreglar (2b/2d) |
| 5 | Con el resolutor caído, `facts` concede y **no se puede revocar** | 🟡 | No — amplía la redacción de (b) |

---

## Hallazgos

### 🔴 1 · `scopes.detached` de un nodo intermedio borra los denies de todo su subárbol

**Escenario (precondición → acción → resultado incorrecto)**

- **Precondición.** `app ← organization A ← division D ← unit U`. La plataforma escribe un
  **deny explícito** de `docs:write` a alice en `A` (invariante 2). Alice tiene un rol de nivel
  `unit` en `U` que vincula `docs:write`. Con `requireWithin: true`, alice manda en `D`
  (`within: D`, que es lo que su sesión le da).
- **Acción.** Alice no puede acercarse al deny —medido: `removeDeny(alice,'docs:write', A, {within: D})`
  ⇒ **422 `E_AUTHZ_NOT_WITHIN`**, `grant(...A...)` ⇒ **422 `E_AUTHZ_NOT_WITHIN`**—. Lo que sí puede
  hacer, porque el invariante 15 contrasta `scopes.detached` **contra el hijo**, es
  `scopes.detached(D, { within: D, actor: alice })` ⇒ **OK**.
- **Resultado.** `authorize(alice, 'docs:write', U)` pasa de `false` a **`true`** en `facts`
  (en `database` sigue `false`). El deny **sigue escrito** en el store (`scope:organization|A
  #denied_docs_write@user:alice`, leído tras la operación): lo que se rompió es el camino por el
  que se heredaba. Es decir: **`scopes.detached` de un nodo intermedio es, en `facts`, un
  `removeDeny` masivo sobre el subárbol, ejecutable por quien tiene prohibido el `removeDeny`.**

**Salida literal**

```
El actor manda en la DIVISION (within: div). ¿Qué puede hacer?
  removeDeny(docs:write, org)  → 422 E_AUTHZ_NOT_WITHIN
  deny/grant en la org         → 422 E_AUTHZ_NOT_WITHIN
  scopes.detached(div)         → OK (purgada)

Después de detachar SU division:
  authorize(alice, docs:write, unit)      facts=true  database=false *** FACTS FAIL-OPEN ***
```

**Evidencia** ✅ medido (`repro/a1_deny_bypass.ts` y `repro/a2_escalada_within.ts`, abajo).
Mecanismo en código: `openfga_driver.ts:1151` `factsAuthorize` decide con un `Check` sobre
`scope:<key>` y no llama al resolutor; `openfga_driver.ts:1973` `onScopeDetached` borra **solo** la
arista `parent` del nodo, y a propósito no toca las de sus hijos; `purgeScope`
(`openfga_driver.ts:2165`) purga los hechos del scope EXACTO, incluidos sus `denied_<P>`. Resultado
compuesto: el nodo se va, sus denies se van con él, y sus descendientes se quedan colgando de un
nodo inerte con sus bindings intactos.

**Por qué esto NO es lo que dice (a).** La frase aprobada —«un scope cuya cadena está rota sigue
concediendo por su propio binding»— describe **conservación** de acceso: el lector concluye «como
mucho, un scope zombi que ya no existe conserva lo que ya tenía». Lo medido es **adquisición**: una
respuesta que era `false` pasa a `true`, y la operación que lo consigue está **al otro lado de la
barrera de contención que el paquete vende como su frontera multi-tenant**. Son dos declaraciones
de riesgo distintas, y solo la segunda permite al consumidor decidir.

**Steelman del defensor.** «Alice ha destruido su propia division; la unit queda huérfana y la app
debería devolver 404 antes de preguntar. Además el paquete ya dice que hay que notificar `detached`
por CADA nodo». → **No me convence, por tres razones.** (i) El propio paquete documenta que un
descendiente vivo con la ruta materializada rota es «lo normal con rutas materializadas o con un
borrado en dos pasos» (invariante 18, AA4), o sea que el estado no es patológico sino esperado;
(ii) `database` es robusto ante ese mismo descuido (invariante 9: cadena rota ⇒ `false`) y `facts`
lo convierte en escalada — la asimetría es justo lo que R2 declara, pero con la mitad de la
consecuencia escrita; (iii) la consecuencia documentada hoy de no notificar todos los nodos es
«lo verá `authz:reconcile`», y `authz:reconcile` **no existe** (es 3b-3): a día de hoy nada lo
detecta ni lo repara.

**Mitigación mínima sugerida.** Una línea de redacción (abajo) + que `detached` deje de ser O(1)
solo en apariencia: o el paquete exige el subárbol (y lo dice), o el README dice con estas palabras
que **un `detached` incompleto convierte un deny heredado en un permiso indenegable**.

---

### 🔴 2 · Un tapón en la outbox congela el árbol del store para siempre, y lo pone cualquier tenant

**Escenario**

- **Precondición.** La configuración OBLIGATORIA de `facts`: `scopes.outbox` declarada (sin ella el
  driver no se construye) y `authz:scopes:relay` por cron. Un actor que puede crear y borrar sus
  propios scopes (un admin de tenant cualquiera).
- **Acción, toda ella legítima.** `scopes.attached(P, org)` → `scopes.attached(C, P)` →
  `scopes.detached(P)` y borrar la fila de `P` **antes** de que pase el relay. Al relevar,
  `attached(C, P)` llama a `assertEdge` → `knownScope(P)` → `P` ya no resuelve ⇒ **422
  `E_AUTHZ_UNKNOWN_SCOPE`**. `relayScopeChanges` **para en el primer fallo** (`manager.ts:579`) y
  `sqlScopeOutbox.pending()` devuelve siempre lo no aplicado **ordenado por id ascendente**
  (`scope_outbox.ts:165`): la entrada envenenada es la cabecera de la cola **en todas las pasadas
  siguientes**. No hay `--skip`, ni dead-letter, ni tope de `attempts`.
- **Resultado.** A partir de ese instante **ningún cambio del árbol llega al store, de ningún
  tenant**. Medido, tres pasadas después: una unit nueva colgada de una organization con deny
  explícito **nunca recibe su arista `parent`**, así que el deny nunca la alcanza —
  `authorize` = `true` en `facts`, `false` en `database`— y un `scopes.detached` posterior nunca
  purga: el scope borrado **sigue concediendo**.

**Salida literal**

```
relay #2 (con el tapón):
  applied: 1  failed: attached → El scope organization:01a0…b9 no existe para el resolutor de
  remaining: true
relay #3 (una pasada más, como haría el cron):
  applied: 0  failed: attached  remaining: true

La unit nueva cuelga de una org con deny explícito para alice:
  authorize(alice, docs:write, unit)             facts=true  database=false *** FACTS FAIL-OPEN ***
  aristas de la unit en el store: binding→role_binding:unit|…  (ninguna arista parent)

Y tampoco se purga lo que se borra: scopes.detached(unit) queda en la cola
  authorize(alice, docs:write, unit) tras borrarla  facts=true  database=false *** FACTS FAIL-OPEN ***

  cola pendiente: [{"id":3,"op":"attached","attempts":3},{"id":4,"op":"detached","attempts":0},
                   {"id":5,"op":"attached","attempts":0},{"id":6,"op":"detached","attempts":0}]
```

**Evidencia** ✅ medido (`repro/b1_relay_poison.ts`). Hay al menos **tres** secuencias ordinarias
que producen el mismo tapón, porque `assertEdge` se re-valida contra el árbol del consumidor **en
el momento del relevo**, no en el del encolado: (i) el padre del cambio encolado se borra;
(ii) el consumidor recoloca el padre bajo el hijo antes del relevo (`E_AUTHZ_SCOPE_CYCLE`);
(iii) el nodo acaba con dos padres en el store (hallazgo 4) y salta `E_AUTHZ_SCOPE_TREE_DRIFT`.

**Por qué importa para R2.** La aceptación de R2 descansa en una frase del README que este hallazgo
falsea: *«the shorter your relay cycle the shorter the window»*. La ventana **no está acotada por
el ciclo del relay**: un tenant la pone en infinito en dos peticiones, y mientras dura, la
respuesta de `authorize` es la del árbol congelado. Un DoS cuyo modo de fallo es «todo el mundo
conserva el acceso que tenía» no es un problema de disponibilidad, es un fail-open.

**Steelman del defensor.** «Para en el primer fallo A PROPÓSITO —adelantar un cambio dejaría un
árbol que nunca existió— y sale con `exitCode = 1` (`commands/authz_scopes_relay.ts:95`), así que un
supervisor se entera; el operador arregla la causa y reintenta». → **Me convence la MITAD.** El
diseño de parar es correcto y el exit≠0 es real. Lo que no se sostiene es «arregla la causa»: la
causa es una fila que el tenant ya borró y que no va a volver; las únicas salidas son resucitar a
mano una fila de negocio del consumidor o marcar `applied_at` a mano en la tabla de la cola —
ninguna de las dos está documentada, ninguna es una API del paquete—. Y el precio de la espera no
lo paga el operador: lo paga la autorización, en dirección abierta y en silencio para el que
pregunta.

**Mitigación mínima sugerida.** Que el relay pueda **saltar y aparcar** una entrada irreparable
(dead-letter con reporte), o que el cambio se valide contra el árbol del ENCOLADO y no contra el de
hoy; y mientras tanto, decir en el README que una entrada atascada convierte el fail-open temporal
en permanente.

---

### 🟠 3 · El alias del uuid es fail-OPEN en `purgeScope`/`scopes.detached`

**Escenario**

- **Precondición.** Árbol del consumidor en SQL con columna `uuid` nativa (PostgreSQL) o
  `char(36) *_ci` (MySQL): el motor funde `01a0…-…` con `01a0……` sin guiones, y `assertScope`
  acepta las dos formas (la gramática del uuid es `[a-z0-9_.-]+`; el alias por MAYÚSCULAS sí muere
  en la puerta, el de guiones no). Un controlador normal:
  `await Unit.query().where('id', params.id).delete()` y después
  `authorization.scopes.detached({ type: 'unit', uuid: params.id })`.
- **Acción.** El atacante manda `params.id` **sin guiones**. El `DELETE` acierta (PG funde el
  alias). El `detached` llega con el alias y **la fila ya no existe**, así que
  `canonicalScope` (`backend_guard.ts:228`) y el manager (`manager.ts:497`) no tienen con qué
  canonizar y usan **la forma del llamante** — camino explícitamente soportado
  («el consumidor puede haber borrado ya su fila»).
- **Resultado.** `purgeScope` **demuestra cero sobre un objeto que no existe** y devuelve OK
  (invariante 11 satisfecho en el vacío); `onScopeDetached` borra la arista `parent` de un objeto
  que no existe. En el store quedan intactos `scope:unit|<canónico>#parent@…` y
  `…#binding@role_binding:…`, y `authorize` sobre la identidad canónica sigue diciendo **`true`**
  para siempre. `database` responde `false` (invariante 9). **Control medido:** el mismo `detached`
  con la forma canónica sí purga y los dos drivers dicen `false`.

**Salida literal (PostgreSQL 18)**

```
el árbol (PG) funde los dos: chain(alias)[0] = {"type":"unit","uuid":"01a055db-e222-…"}

1) Antes de borrar nada:
  authorize(… unit canónica)   facts=true  database=true  PARIDAD
  authorize(… unit ALIAS)      facts=false database=true  *** FACTS FAIL-CLOSED ***   ← esto es (c)

2) fila borrada; chain(canónica) = null
   scopes.detached({ unit, uuid: ALIAS }) — ni lanza ni avisa
3) Lo que quedó en el store bajo la identidad REAL:
    parent→scope:organization|…  |  binding→role_binding:unit|…
  authorize(… unit canónica)   facts=true  database=false *** FACTS FAIL-OPEN ***
4) CONTROL — el mismo detached con la forma canónica:
  authorize(… unit canónica)   facts=false database=false PARIDAD
```

**Evidencia** ✅ medido (`repro/c1_alias_fail_open.ts`, `TEST_DB=pg`).

**Por qué desmiente la frase de (c).** La declaración dice «un alias del uuid de un scope no
encuentra sus hechos (esto es fail-**closed**, pero rompe la igualdad entre drivers)». Eso es cierto
del camino de LECTURA. Del camino de ESCRITURA es exactamente al revés: el mismo alias, en
`revoke`/`removeDeny`/`purgeScope`/`scopes.detached` con el scope ya borrado, es fail-**open**, y en
`facts` fail-open significa «concede para siempre», no «deja basura». El comentario de
`manager.ts:491-495` demuestra que este alias ya se cerró una vez (3E · P2) resolviéndolo «UNA vez,
aquí»; lo que no se vio es que la canonización solo funciona **mientras la fila está viva**, y
`detached` es precisamente la operación que admite que ya no lo esté.

**Steelman del defensor.** «Un consumidor que pasa un uuid con otra ortografía que la de su tabla
tiene un bug suyo; el paquete no puede adivinar». → **No me convence del todo.** Es verdad que la
entrada la elige el consumidor, pero (i) el paquete ya decidió que este alias concreto es
responsabilidad suya y lo cerró en los demás caminos, (ii) `purgeScope` está vendido con
«demostración de cero o 500 `E_AUTHZ_PURGE_INCOMPLETE`» y aquí la demostración es vacía y silenciosa,
y (iii) en `database` el mismo bug del consumidor no concede nada. Como mínimo, la demostración de
cero debería no poder ser vacía, o el README debe decir que la identidad del `detached` la fija el
llamante cuando la fila ya no está.

**Mitigación mínima sugerida.** Normalizar el uuid del scope (quitar guiones / forma canónica única)
antes de componer `scope:<key>`, o rechazar un `detached` sin cadena cuyo uuid no esté en forma
canónica 8-4-4-4-12.

---

### 🟠 4 · Dos escritores del árbol dejan un nodo con DOS padres: herencia cruzada entre tenants

**Escenario**

- **Precondición.** Dos aplicaciones del árbol **concurrentes** sobre el mismo store. En la
  configuración obligatoria de `facts` el único escritor es `authz:scopes:relay`, y **ni el puerto
  `ScopeOutbox` ni `relayScopeChanges` ni el comando exigen un escritor único**: `pending()` es un
  `SELECT … WHERE applied_at IS NULL ORDER BY id` sin `FOR UPDATE SKIP LOCKED` ni lease, y una
  pasada trabaja sobre un lote de hasta 100 filas que NO vuelve a releer.
- **Acción.** Dos `reparent` concurrentes del mismo hijo hacia padres distintos: los dos leen
  `current = []` y los dos escriben (`openfga_driver.ts:1999`; el `Write` es atómico pero no hay
  read-modify-write atómico).
- **Resultado.** El nodo queda con **dos aristas `parent`** y (c2) hereda por las dos ramas:
  medido, un `org-admin` de la organization B —que no tiene ningún poder en A— obtiene
  `docs:write` sobre una **unit del tenant A**. En `database`, `false`. Además el nodo queda
  **irreparable con el paquete**: `moved` ⇒ 500 `E_AUTHZ_SCOPE_TREE_DRIFT` (`assertOneParent`) y
  `purgeScope` no toca la arista `parent` a propósito, así que el cruce sobrevive a la purga.

**Salida literal**

```
dos escritores concurrentes: fulfilled, fulfilled
padres en el store: scope:organization|01a0…ef + scope:organization|01a0…ef
Mallory es org-admin de su PROPIA organization B. ¿Qué ve en la unit del tenant A?
  authorize(mallory, docs:write, unit de A)   facts=true  database=false *** FACTS FAIL-OPEN ***
reparar con moved: 500 E_AUTHZ_SCOPE_TREE_DRIFT
purgeScope(unit): OK (pero no toca la arista parent)
  authorize tras purgeScope                   facts=true  database=false *** FACTS FAIL-OPEN ***
```

**Evidencia** ✅ la CONSECUENCIA está medida (`repro/f1_dos_padres.ts`, `repro/e1_negativos.ts` §4).
❓ El DISPARADOR por dos pasadas del relay **no lo he reproducido de punta a punta**: lo he leído en
el código (sin lease, lote de 100 sin releer) y he provocado la concurrencia llamando dos veces al
driver a la vez, que es exactamente lo que hacen dos workers. Un segundo efecto del mismo hueco, que
tampoco he medido y que es peor por silencioso: un worker que trabaja sobre un lote **rancio**
re-aplica un `attached` viejo después de que otro haya aplicado el `moved` nuevo, y ahí el árbol
queda **revertido con UN solo padre**, o sea sin `assertOneParent` que lo delate.

**Steelman del defensor.** «Esto es 2b/2d, no R2, y nadie corre dos relays». → El primer punto es
cierto y lo digo yo mismo; el segundo no: un `CronJob` de Kubernetes con `concurrencyPolicy: Allow`
(el default), dos réplicas, o una pasada que dura más que su intervalo bastan, y el paquete no dice
en ninguna parte que no se pueda.

**Mitigación mínima sugerida.** Documentar el relay como **escritor único** y/o que
`sqlScopeOutbox.pending()` tome las filas con `FOR UPDATE SKIP LOCKED`.

---

### 🟡 5 · Con el resolutor caído, `facts` concede y no se puede revocar

**Escenario.** Precondición: la BD/replica/pool del consumidor no responde (su `resolveChain`
lanza). Acción: nada, es un incidente. Resultado medido:

```
Con el resolutor CAÍDO:
  authorize(docs:write, unit)   facts=true                      database=503 E_AUTHZ_RESOLVER_FAILED
  revoke(unit-editor, unit)     facts=503 E_AUTHZ_RESOLVER_FAILED  database=503 …
  deny(docs:write, unit)        facts=503 E_AUTHZ_RESOLVER_FAILED  database=503 …
  purgeScope(unit)              facts=503 E_AUTHZ_RESOLVER_FAILED  database=503 …
  listRoles(unit)               facts=503 E_AUTHZ_RESOLVER_FAILED  database=503 …
```

**Evidencia** ✅ medido (`repro/d1_resolver_down.ts`).

Esto **no reabre nada**: (b) es la propiedad comprada y no se discute. Lo que sí hace es responder
la pregunta del encargo —«¿(b) amplifica a (a)/(c)?»— con un **sí acotado**: durante la caída del
árbol el modo entra en estado *solo-concede*. Es la ventana exacta en la que un defensor quiere
revocar (una credencial filtrada, un empleado despedido) y no puede, mientras el PDP sigue
diciendo `true`. En `database` todo se para junto, que es peor para la disponibilidad y mejor para
la contención. Va a la redacción de (b), no a la lista de bugs.

---

## Lo que intenté y NO se rompió

Medido en `repro/e1_negativos.ts` y en los controles de los demás scripts:

1. **Escribir sobre un scope que el árbol no conoce**: `grant` y `deny` ⇒ 422
   `E_AUTHZ_UNKNOWN_SCOPE`. No hay forma de sembrar hechos bajo una clave inventada.
2. **Inventar un nodo en el store** con `attached(hijoDesconocido, padreConocido)`: se escribe la
   arista (el hijo no tiene por qué existir aún), pero **no sirve de nada**: `grant` sobre él sigue
   siendo 422 y `authorize` `false`. No es un punto de apoyo.
3. **Aristas ilegales**: `attached(app, org)` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY`; padre desconocido ⇒
   422 `E_AUTHZ_UNKNOWN_SCOPE`; ciclo ⇒ 422 `E_AUTHZ_SCOPE_CYCLE`. La barrera anti-ciclos del
   paquete aguanta también llamando al driver a pelo.
4. **Alias del uuid con la fila VIVA**: `grant`/`deny`/`revoke`/`removeDeny`/`purgeScope` canonizan
   por `chain[0]` y aciertan; en lectura el alias es fail-**closed** en `facts` (`false`) — la (c)
   declarada, sin sorpresas.
5. **`purgeScope` con la cadena rota pero identidad canónica**: purga bien y los dos drivers
   convergen a `false` (control del §3, paso 4). O sea: (a) **sí** sobrevive a `purgeScope` solo si
   la purga se dirige a otra clave (alias) o si nunca se dirige (tapón del relay).
6. **`authorizeMany` con resolutor caído**: responde en vez de lanzar. Es el hallazgo 1 del 2e, ya
   declarado; no encontré forma de convertirlo en concesión de más allá de lo que (b) ya implica.
7. **Cruzar `type` + `uuid` de holders**: `assertHolderTypes` exige inyectividad y lanza al
   construir. No pude fundir dos morph names en un tipo FGA.
8. **Sembrar un binding que `purgeScope` no alcance por su cuenta**: el filtro
   `authz_roles WHERE scope_type = scope.type` deja fuera los bindings de un rol al que le
   cambiaron el nivel — pero eso es **R1**, ya decidido «se arregla», y no conseguí llegar ahí sin
   pasar por el cambio de catálogo. **Aviso para quien implemente R1:** el barrido que R1 propone
   debe correr también en la escritura de catálogo, porque `purgeScope` **no** puede recoger esos
   bindings (ni siquiera los ve para la demostración de cero).

---

## Preguntas abiertas para el arquitecto

Solo las que cambian el veredicto:

1. **¿`scopes.detached` es por nodo o por subárbol?** Hoy es por nodo, y eso convierte un descuido
   del consumidor en la escalada del hallazgo 1. Si la respuesta es «por nodo, y el consumidor debe
   notificar todos», el README tiene que decir la consecuencia **con la palabra deny**, no con la
   palabra drift.
2. **¿El relay puede aparcar una entrada irreparable?** Si la respuesta es no, el hallazgo 2 se
   queda como fail-open permanente provocable por un tenant, y entonces la frase «the shorter your
   relay cycle the shorter the window» no puede aparecer en el README.
3. **¿El relay es escritor único?** Si lo es, dilo en el puerto y en el comando; si no lo es,
   `pending()` necesita lease.

---

## La redacción que yo pondría en el README

Sustituye al literal previsto para R2. Está en inglés porque el README lo está; lo que importa es
que las tres frases digan la consecuencia, no el mecanismo.

> **In `hierarchy: 'facts'`, `authorize` decides with the tree that lives in the store — it never
> calls your `resolveChain`.** That is the property you are buying: a PDP that answers when your
> database does not. It has three consequences, and the two drivers do **not** answer the same in
> any of them. They are declared, each with a negative contract case; they are not scheduled fixes.
>
> **(a) A scope whose chain is broken keeps deciding — and it decides *without the denies it used
> to inherit*.** Invariant 9 (*unknown scope = does not exist*) is enforced by `resolveChain`, and
> `authorize` no longer calls it, so a scope your tree can no longer reach keeps granting through
> its own bindings. The part that costs is the other half: every `denied_<P>` that reached it from
> above stops applying, so **an answer that was `false` becomes `true`**. Detaching an intermediate
> node is therefore a *deny-removal primitive for its whole subtree*, and `scopes.detached` is
> contained against **the node itself** — a tenant who is forbidden to touch the deny (422
> `E_AUTHZ_NOT_WITHIN` on `removeDeny`) can delete the node under it and get the same effect
> (measured; in `database` the same operation denies everything below, chain `null`). **Notify
> `scopes.detached` for every node of the subtree, not just its root.** Until `authz:reconcile`
> exists, nothing finds the ones you missed.
>
> **(b) A resolver that is down no longer makes `authorize` throw — and it can no longer make it
> stop, either.** This is the property, and it is one-sided: while your tree is unavailable
> `authorize` keeps answering `true`, but `revoke`, `deny`, `removeDeny`, `purgeScope` and every
> `list*` are 503 `E_AUTHZ_RESOLVER_FAILED`, because they all canonicalise against your tree. The
> mode is *grant-only* until your database comes back — plan your incident response around that. In
> `database`, everything stops together.
>
> **(c) A uuid alias does not find its facts on the read path — and finds the wrong ones on the
> write path.** `authorize` composes `scope:<type>|<uuid>` from the caller's spelling without
> canonicalising, so the same id written differently (no dashes, which PostgreSQL's `uuid` column
> and MySQL's `*_ci` collation fold into the same row) answers `false` where `database` answers
> `true`: fail-**closed**, but not equal. The write path is the opposite: `revoke`, `removeDeny`,
> `purgeScope` and `scopes.detached` canonicalise **only while the row still exists**; once you have
> deleted it — the supported order for `detached` — there is nothing to canonicalise with, and they
> operate on the caller's spelling. A purge then reports success having deleted nothing (its
> proof-of-zero is proven over an object that does not exist) and the real scope **keeps granting
> for ever**, where `database` would answer `false`. Pass scope uuids exactly as your table stores
> them.
>
> And one correction to *The tree outbox*: the relay lag is **not** bounded by your relay cycle.
> The relay stops at the first failure and the queue is strictly ordered, so a single change that
> can no longer be applied — its parent scope was deleted before the pass, its edge would now close
> a cycle — **blocks every later change indefinitely**, for every tenant. While it is blocked the
> store keeps deciding with the frozen tree: new scopes never inherit their denies and deleted
> scopes are never purged. It exits non-zero, so watch it; there is no automatic skip.

---

## Reproducciones ejecutables

Todo esto corrió desde una copia del worktree con `node_modules` enlazado desde el repo principal
(el worktree no trae `node_modules`):

```bash
cp -a <worktree> /tmp/atk && rm -f /tmp/atk/.git
ln -s <repo>/node_modules /tmp/atk/node_modules
mkdir -p /tmp/atk/repro   # y dentro los ficheros de abajo
cd /tmp/atk
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/a2_escalada_within.ts
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/b1_relay_poison.ts
PGPW=$(docker inspect postgres18 --format '{{range .Config.Env}}{{println .}}{{end}}' | grep POSTGRES_PASSWORD | cut -d= -f2)
TEST_DB=pg TEST_PG_URL="postgres://postgres:$PGPW@127.0.0.1:5432/auditor_r2" \
  OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/c1_alias_fail_open.ts
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/d1_resolver_down.ts
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/f1_dos_padres.ts
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/e1_negativos.ts
```

Todos los scripts borran su store en el `finally` y la app destruye su base al hacer `teardown()`.

### `repro/harness.ts`

```ts
/**
 * Harness del auditor R2 — driver `openfga` modo `facts` contra el servidor
 * REAL (:8101) + driver `database` sobre el mismo catálogo y el mismo árbol.
 * Todo por import DINÁMICO: `services/db.js` exige la app booteada primero.
 */
export const HOLDERS = { users: 'user', admins: 'admin' }

export const CATALOG: any = {
  permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }, { slug: 'billing:read' }],
  roles: [
    { slug: 'editor', scopeType: 'app', permissions: ['docs:read', 'docs:write'] },
    { slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read', 'docs:write', 'billing:read'] },
    { slug: 'unit-editor', scopeType: 'unit', permissions: ['docs:write'] },
  ],
}

const apiUrl = process.env.OPENFGA_TEST_URL ?? 'http://localhost:8101'
const stores: string[] = []

export async function setup(options: { tree?: any; makeTree?: (db: any) => Promise<any>; catalog?: any } = {}) {
  const { bootApp } = await import('../tests/helpers/app.js')
  const app = await bootApp()
  const { createAuthzSchema, createDemoScopesTable, createScopeOutboxTable, cleanAuthzTables } = await import('../tests/helpers/schema.js')
  await createAuthzSchema(app.db)
  await createDemoScopesTable(app.db)
  await createScopeOutboxTable(app.db)
  await cleanAuthzTables()
  const catalog = options.catalog ?? CATALOG
  const { syncAuthzCatalog } = await import('../src/catalog.js')
  await syncAuthzCatalog(catalog)

  const { OpenFgaAuthorizationDriver, openFgaFactsModel } = await import('../src/openfga.js')
  const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
  const { memoryScopeTree, resolveChainFrom } = await import('../src/testing/main.js')

  const { OpenFgaClient } = await import('@openfga/sdk')
  const store = await new OpenFgaClient({ apiUrl }).createStore({
    name: `auditor-r2-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
  })
  stores.push(store.id!)
  const model = await new OpenFgaClient({ apiUrl, storeId: store.id }).writeAuthorizationModel(
    openFgaFactsModel(HOLDERS, catalog.permissions.map((p: any) => p.slug))
  )

  const tree = options.tree ?? (options.makeTree ? await options.makeTree(app.db) : memoryScopeTree())
  const facts: any = new OpenFgaAuthorizationDriver({
    apiUrl,
    storeId: store.id!,
    modelId: model.authorization_model_id,
    holderTypes: HOLDERS,
    resolveChain: resolveChainFrom(tree),
    hierarchy: 'facts' as const,
    acceptScopeDriftRisk: true,
    logger: { warn: () => {} },
  })
  await syncAuthzCatalog(catalog, { projection: facts.catalogProjection() })
  const sql: any = new DatabaseAuthorizationDriver({ resolveChain: resolveChainFrom(tree) })
  const raw = new OpenFgaClient({ apiUrl, storeId: store.id!, authorizationModelId: model.authorization_model_id })

  const attach = async (child: any, parent: any) => {
    await tree.attach(child, parent)
    await facts.onScopeAttached(child, parent)
  }
  const move = async (child: any, parent: any) => {
    await tree.move(child, parent)
    await facts.onScopeMoved(child, parent)
  }

  return {
    app, db: app.db, tree, facts, sql, raw, attach, move, storeId: store.id!, apiUrl,
    async teardown() {
      while (stores.length) {
        try { await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore() } catch {}
      }
      await app.teardown()
    },
  }
}

export function report(name: string, factsAnswer: boolean, sqlAnswer: boolean) {
  const flag = factsAnswer === sqlAnswer ? 'PARIDAD' : factsAnswer ? '*** FACTS FAIL-OPEN ***' : '*** FACTS FAIL-CLOSED ***'
  console.log(`  ${name.padEnd(56)} facts=${String(factsAnswer).padEnd(5)} database=${String(sqlAnswer).padEnd(5)} ${flag}`)
}
```

### `repro/a1_deny_bypass.ts` — hallazgo 1 (medida limpia)

```ts
import { setup, report } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup()
const { APP_SCOPE } = await import('../src/types.js')
try {
  const alice = { type: 'users', uuid: uuidv7() }
  const org = { type: 'organization', uuid: uuidv7() }
  const div = { type: 'organization', uuid: uuidv7() }
  const unit = { type: 'unit', uuid: uuidv7() }

  await h.attach(org, APP_SCOPE)
  await h.attach(div, org)
  await h.attach(unit, div)

  for (const d of [h.facts, h.sql]) {
    await d.grant(alice, 'unit-editor', unit)
    await d.deny(alice, 'docs:write', org)
  }

  console.log('\n1) Estado inicial: grant en la unit, deny en la organization')
  report('authorize(alice, docs:write, unit)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))

  console.log('\n2) El dueño de la DIVISION la borra: scopes.detached(div)')
  await h.facts.purgeScope(div)
  await h.facts.onScopeDetached(div)
  await h.sql.purgeScope(div)
  await h.tree.detach(div)

  console.log(`   chain(unit) para el consumidor = ${JSON.stringify(await h.tree.chainOf(unit))}`)
  report('authorize(alice, docs:write, unit)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))

  console.log('\n3) El deny sigue escrito en el store (no se borró nada de la org):')
  const t = await h.raw.read({ object: `scope:organization|${org.uuid}` })
  console.log('   ', (t.tuples ?? []).map((x: any) => `${x.key.user} #${x.key.relation}`).join(' | ') || '(ninguna)')
} finally {
  await h.teardown()
}
```

### `repro/a2_escalada_within.ts` — hallazgo 1 con `requireWithin: true`

```ts
import { setup, report } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup()
const { APP_SCOPE } = await import('../src/types.js')
const { AuthorizationManager } = await import('../src/manager.js')
const { resolveChainFrom } = await import('../src/testing/main.js')

const call = async (run: () => Promise<any>) => {
  try { return `OK (${String(await run())})` } catch (e: any) { return `${e.status} ${e.code}` }
}

try {
  const alice = { type: 'users', uuid: uuidv7() }
  const org = { type: 'organization', uuid: uuidv7() }
  const div = { type: 'organization', uuid: uuidv7() }
  const unit = { type: 'unit', uuid: uuidv7() }
  await h.attach(org, APP_SCOPE)
  await h.attach(div, org)
  await h.attach(unit, div)
  for (const d of [h.facts, h.sql]) {
    await d.grant(alice, 'unit-editor', unit)
    await d.deny(alice, 'docs:write', org)
  }

  const mk = (name: string, driver: any) => new AuthorizationManager({
    default: name, drivers: { [name]: () => driver },
    scopes: { resolveChain: resolveChainFrom(h.tree), acceptScopeDriftRisk: true },
    requireWithin: true, requireActor: true, warnOnOptInSecurity: false,
  } as any) as any
  const mf = mk('facts', h.facts)
  const ms = mk('database', h.sql)

  const w = { within: div, actor: alice }
  console.log('\nEl actor manda en la DIVISION (within: div). ¿Qué puede hacer?')
  console.log('  removeDeny(docs:write, org)  →', await call(() => mf.removeDeny(alice, 'docs:write', org, w)))
  console.log('  deny/grant en la org         →', await call(() => mf.grant(alice, 'org-admin', org, w)))
  console.log('  scopes.detached(div)         →', await call(async () => { await mf.scopes.detached(div, w); return "purgada" }))

  await ms.scopes.detached(div, w)
  await h.tree.detach(div)
  console.log('\nDespués de detachar SU division:')
  report('authorize(alice, docs:write, unit)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))
} finally {
  await h.teardown()
}
```

### `repro/b1_relay_poison.ts` — hallazgo 2

```ts
import { setup, report, HOLDERS } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup()
const { APP_SCOPE } = await import('../src/types.js')
const { AuthorizationManager } = await import('../src/manager.js')
const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
const { resolveChainFrom } = await import('../src/testing/main.js')

try {
  const outbox = sqlScopeOutbox()
  const manager: any = new AuthorizationManager({
    default: 'facts',
    drivers: { facts: () => h.facts },
    holderTypes: HOLDERS,
    scopes: { resolveChain: resolveChainFrom(h.tree), outbox },
    warnOnOptInSecurity: false,
  } as any)

  const alice = { type: 'users', uuid: uuidv7() }
  const org = { type: 'organization', uuid: uuidv7() }

  await h.tree.attach(org, APP_SCOPE)
  await manager.scopes.attached(org, APP_SCOPE)
  console.log('relay #1:', JSON.stringify(await manager.relayScopeChanges()))
  await h.facts.deny(alice, 'docs:write', org)
  await h.sql.deny(alice, 'docs:write', org)

  // El tapón: `attached(hijo, padre)` encolado y el PADRE borrado antes del relevo.
  const padre = { type: 'organization', uuid: uuidv7() }
  const hijo = { type: 'unit', uuid: uuidv7() }
  await h.tree.attach(padre, org)
  await manager.scopes.attached(padre, org)
  await h.tree.attach(hijo, padre)
  await manager.scopes.attached(hijo, padre)
  await manager.scopes.detached(padre)
  await h.tree.detach(padre)

  console.log('\nrelay #2 (con el tapón):')
  const r2 = await manager.relayScopeChanges()
  console.log('  applied:', r2.applied.length, ' failed:', r2.failed && `${r2.failed.change.op} → ${r2.failed.error.slice(0, 90)}`)
  console.log('  remaining:', r2.remaining)

  const unit = { type: 'unit', uuid: uuidv7() }
  await h.tree.attach(unit, org)
  await manager.scopes.attached(unit, org)
  console.log('\nrelay #3 (una pasada más, como haría el cron):')
  const r3 = await manager.relayScopeChanges()
  console.log('  applied:', r3.applied.length, ' failed:', r3.failed && r3.failed.change.op, ' remaining:', r3.remaining)

  await h.facts.grant(alice, 'unit-editor', unit)
  await h.sql.grant(alice, 'unit-editor', unit)

  console.log('\nLa unit nueva cuelga de una org con deny explícito para alice:')
  report('authorize(alice, docs:write, unit)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))

  const edges = await h.raw.read({ object: `scope:unit|${unit.uuid}` })
  console.log('  aristas de la unit en el store:', (edges.tuples ?? []).map((t: any) => `${t.key.relation}→${t.key.user}`).join(', ') || '(ninguna)')

  console.log('\nY tampoco se purga lo que se borra: scopes.detached(unit) queda en la cola')
  await manager.scopes.detached(unit)
  await h.tree.detach(unit)
  const r4 = await manager.relayScopeChanges()
  console.log('  relay #4 applied:', r4.applied.length, ' failed:', r4.failed && r4.failed.change.op)
  await h.sql.purgeScope(unit)
  report('authorize(alice, docs:write, unit) tras borrarla', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))

  const rows = await h.db.from('authz_scope_outbox').select('id', 'op', 'attempts').whereNull('applied_at').orderBy('id')
  console.log('\n  cola pendiente:', JSON.stringify(rows))
} finally {
  await h.teardown()
}
```

### `repro/c1_alias_fail_open.ts` — hallazgo 3 (necesita `TEST_DB=pg`)

```ts
import { setup, report } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup({
  makeTree: async (db) => (await import('../tests/helpers/sql_scope_tree.js')).sqlScopeTree(db),
})
const { APP_SCOPE } = await import('../src/types.js')
const { AuthorizationManager } = await import('../src/manager.js')
const { resolveChainFrom } = await import('../src/testing/main.js')

try {
  const alice = { type: 'users', uuid: uuidv7() }
  const org = { type: 'organization', uuid: uuidv7() }
  const unit = { type: 'unit', uuid: uuidv7() }
  const alias = { type: 'unit', uuid: unit.uuid.replaceAll('-', '') }

  await h.attach(org, APP_SCOPE)
  await h.attach(unit, org)
  await h.facts.grant(alice, 'unit-editor', unit)
  await h.sql.grant(alice, 'unit-editor', unit)

  console.log(`\nscope canónico : unit:${unit.uuid}`)
  console.log(`alias del uuid : unit:${alias.uuid}`)
  console.log(`el árbol (PG) funde los dos: chain(alias)[0] =`, JSON.stringify((await h.tree.chainOf(alias))?.[0]))

  console.log('\n1) Antes de borrar nada:')
  report('authorize(alice, docs:write, unit canónica)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))
  report('authorize(alice, docs:write, unit ALIAS)', await h.facts.authorize(alice, 'docs:write', alias), await h.sql.authorize(alice, 'docs:write', alias))

  const managerFacts: any = new AuthorizationManager({
    default: 'facts', drivers: { facts: () => h.facts },
    scopes: { resolveChain: resolveChainFrom(h.tree), acceptScopeDriftRisk: true },
    warnOnOptInSecurity: false,
  } as any)
  const managerSql: any = new AuthorizationManager({
    default: 'database', drivers: { database: () => h.sql },
    scopes: { resolveChain: resolveChainFrom(h.tree), acceptScopeDriftRisk: true },
    warnOnOptInSecurity: false,
  } as any)

  await h.db.from('demo_scopes').where('uuid', alias.uuid).delete()   // PG funde el alias: borra la fila real
  console.log('\n2) fila borrada; chain(canónica) =', JSON.stringify(await h.tree.chainOf(unit)))
  console.log('   scopes.detached({ unit, uuid: ALIAS }) — ni lanza ni avisa:')
  await managerFacts.scopes.detached(alias)
  await managerSql.scopes.detached(alias)
  console.log('   → purgeScope devolvió OK (demostración de cero sobre `scope:unit|<alias>`)')

  console.log('\n3) Lo que quedó en el store bajo la identidad REAL:')
  const left = await h.raw.read({ object: `scope:unit|${unit.uuid}` })
  console.log('   ', (left.tuples ?? []).map((t: any) => `${t.key.relation}→${t.key.user}`).join(' | ') || '(nada)')

  report('authorize(alice, docs:write, unit canónica)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))

  console.log('\n4) CONTROL — el mismo detached con la forma canónica:')
  await managerFacts.scopes.detached(unit)
  report('authorize(alice, docs:write, unit canónica)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))
} finally {
  await h.teardown()
}
```

### `repro/f1_dos_padres.ts` — hallazgo 4

```ts
import { setup, report } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup()
const { APP_SCOPE } = await import('../src/types.js')
try {
  const mallory = { type: 'users', uuid: uuidv7() }
  const orgA = { type: 'organization', uuid: uuidv7() }   // tenant víctima
  const orgB = { type: 'organization', uuid: uuidv7() }   // tenant del atacante
  const unit = { type: 'unit', uuid: uuidv7() }           // unit del tenant A
  await h.attach(orgA, APP_SCOPE)
  await h.attach(orgB, APP_SCOPE)
  await h.tree.attach(unit, orgA)

  // Dos pasadas del relay a la vez sobre la misma cola (sin lease en el puerto).
  const r = await Promise.allSettled([
    h.facts.onScopeAttached(unit, orgA),
    h.facts.onScopeAttached(unit, orgB),
  ])
  console.log('dos escritores concurrentes:', r.map((x) => x.status).join(', '))
  const parents = await h.raw.read({ object: `scope:unit|${unit.uuid}`, relation: 'parent' })
  console.log('padres en el store:', (parents.tuples ?? []).map((t: any) => t.key.user.slice(0, 30)).join(' + '))

  await h.facts.grant(mallory, 'org-admin', orgB)
  await h.sql.grant(mallory, 'org-admin', orgB)
  console.log('\nMallory es org-admin de su PROPIA organization B. ¿Qué ve en la unit del tenant A?')
  report('authorize(mallory, docs:write, unit de A)', await h.facts.authorize(mallory, 'docs:write', unit), await h.sql.authorize(mallory, 'docs:write', unit))

  try { await h.facts.onScopeMoved(unit, orgA) } catch (e: any) { console.log('\nreparar con moved:', e.status, e.code) }
  try { await h.facts.purgeScope(unit); console.log('purgeScope(unit): OK (pero no toca la arista parent)') } catch (e: any) { console.log('purgeScope:', e.status, e.code) }
  report('authorize tras purgeScope', await h.facts.authorize(mallory, 'docs:write', unit), await h.sql.authorize(mallory, 'docs:write', unit))
} finally {
  await h.teardown()
}
```

### `repro/d1_resolver_down.ts` — hallazgo 5

```ts
import { setup, report } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup()
const { APP_SCOPE } = await import('../src/types.js')
try {
  const alice = { type: 'users', uuid: uuidv7() }
  const org = { type: 'organization', uuid: uuidv7() }
  const unit = { type: 'unit', uuid: uuidv7() }
  await h.attach(org, APP_SCOPE)
  await h.attach(unit, org)
  await h.facts.grant(alice, 'unit-editor', unit)
  await h.sql.grant(alice, 'unit-editor', unit)
  report('authorize (resolutor sano)', await h.facts.authorize(alice, 'docs:write', unit), await h.sql.authorize(alice, 'docs:write', unit))

  const boom = () => { throw new Error('el árbol del consumidor no responde') }
  const factsDown: any = h.facts.withChainResolver(boom)
  const sqlDown: any = h.sql.withChainResolver(boom)

  const answer = async (d: any, run: (d: any) => Promise<any>) => {
    try { return String(await run(d)) } catch (e: any) { return `${e.status} ${e.code}` }
  }
  const ops: Array<[string, (d: any) => Promise<any>]> = [
    ['authorize(docs:write, unit)', (d) => d.authorize(alice, 'docs:write', unit)],
    ['revoke(unit-editor, unit)', (d) => d.revoke(alice, 'unit-editor', unit)],
    ['deny(docs:write, unit)', (d) => d.deny(alice, 'docs:write', unit)],
    ['purgeScope(unit)', (d) => d.purgeScope(unit)],
    ['listRoles(unit)', (d) => d.listRoles(alice, unit)],
  ]
  console.log('\nCon el resolutor CAÍDO:')
  for (const [name, run] of ops) {
    console.log(`  ${name.padEnd(30)} facts=${(await answer(factsDown, run)).padEnd(22)} database=${await answer(sqlDown, run)}`)
  }
} finally {
  await h.teardown()
}
```

### `repro/e1_negativos.ts` — lo que no se rompió + la carrera de los dos padres

```ts
import { setup, report } from './harness.js'
import { v7 as uuidv7 } from 'uuid'

const h = await setup()
const { APP_SCOPE } = await import('../src/types.js')
const call = async (label: string, run: () => Promise<any>) => {
  try { console.log(`  ${label.padEnd(52)} OK ${JSON.stringify(await run()) ?? ''}`.slice(0, 160)) }
  catch (e: any) { console.log(`  ${label.padEnd(52)} ${e.status} ${e.code}`) }
}

try {
  const alice = { type: 'users', uuid: uuidv7() }
  const org = { type: 'organization', uuid: uuidv7() }
  const orgB = { type: 'organization', uuid: uuidv7() }
  const unit = { type: 'unit', uuid: uuidv7() }
  const fantasma = { type: 'unit', uuid: uuidv7() }
  await h.attach(org, APP_SCOPE)
  await h.attach(orgB, APP_SCOPE)
  await h.attach(unit, org)

  console.log('\n1) Escrituras sobre un scope que el árbol NO conoce:')
  await call('grant en scope desconocido', () => h.facts.grant(alice, 'unit-editor', fantasma))
  await call('deny en scope desconocido', () => h.facts.deny(alice, 'docs:write', fantasma))
  await call('authorize en scope desconocido (facts)', () => h.facts.authorize(alice, 'docs:write', fantasma))

  console.log('\n2) Aristas ilegales:')
  await call('attached(app, org)', () => h.facts.onScopeAttached(APP_SCOPE, org))
  await call('attached(unit, fantasma)  [padre desconocido]', () => h.facts.onScopeAttached(unit, fantasma))
  await call('moved(org, unit)          [ciclo]', () => h.facts.onScopeMoved(org, unit))

  console.log('\n3) attached de un HIJO que el árbol no conoce (nodo inventado en el store):')
  await call('attached(fantasma, org)', () => h.facts.onScopeAttached(fantasma, org))
  await call('grant sobre ese nodo inventado', () => h.facts.grant(alice, 'unit-editor', fantasma))
  console.log('   authorize sobre el nodo inventado (facts):', await h.facts.authorize(alice, 'docs:write', fantasma))

  console.log('\n4) CARRERA: dos `attached` del MISMO hijo a padres distintos, a la vez')
  const huerfano = { type: 'unit', uuid: uuidv7() }
  await h.tree.attach(huerfano, org)
  const r = await Promise.allSettled([
    h.facts.onScopeAttached(huerfano, org),
    h.facts.onScopeAttached(huerfano, orgB),
  ])
  console.log('   resultados:', r.map((x) => x.status).join(', '))
  const parents = await h.raw.read({ object: `scope:unit|${huerfano.uuid}`, relation: 'parent' })
  console.log('   padres en el store:', (parents.tuples ?? []).map((t: any) => t.key.user).join(' + ') || '(ninguno)')
  if ((parents.tuples ?? []).length > 1) {
    await h.facts.grant(alice, 'unit-editor', huerfano)
    await h.facts.deny(alice, 'docs:write', orgB)
    console.log('   con DOS padres, un deny en el padre ajeno alcanza al hijo:', !(await h.facts.authorize(alice, 'docs:write', huerfano)))
    await call('moved(huerfano, org) con dos padres', () => h.facts.onScopeMoved(huerfano, org))
  }
} finally {
  await h.teardown()
}
```

---

## Higiene

- Stores del `:8101` con prefijo `auditor-r2` al terminar: **0** (enumerado con `GET /stores`).
- Bases `auditor_r2*` en `postgres18` al terminar: **ninguna**. No se tocó ninguna `authz_test*`.
- No se modificó ni un fichero del worktree ni del repo principal salvo este informe.
