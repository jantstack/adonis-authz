# Fase 3 · Lote 3D — Auditor de seguridad, verificación adversarial de cierre

> Contra el código real en `v2/fase-0`, HEAD `56094ac` (`git diff f563465..56094ac`). **No se tocó
> ni un archivo del repo.** Reproducciones en
> `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/v7/`:
> `r1_shadow.ts`, `r2_effective.ts`, `r3_varios.ts`, `r4_global.ts`, `r5_resiste.ts` (los cinco de v6
> adaptados a la API nueva), `a1_ambiguo.ts`, `a2_lock.ts` + `a2_child.ts`, `a2b_stale.ts`,
> `a3_detached.ts`, `a4_uuid_within.ts`, `a5_openfga.ts`, `a6_varios.ts`, `a7_cerrojo.ts`.
> Motores: **PostgreSQL 18** (árbol SQL `sqlScopeTree`, tipo `uuid` nativo), **MySQL 8.4** y
> **OpenFGA `:8101`**. Suite completa `TEST_DB=pg` + `OPENFGA_TEST_URL=:8101`: **674 passed (674)**
> — coincide con el informe del lote. Residuos: 0 bases propias, 0 stores propios (queda
> `authz_test_3462fb64` en MySQL, que **no es mía**: la dejo intacta por si es del agente que mide en
> paralelo).

## Veredicto en una línea

**APTA CON CORRECCIONES**: los cuatro hallazgos bloqueantes (V1, V2, V3 🔴/🟠 y la contención de V4)
están **cerrados y demostrados** —incluida la carrera de M2 con la ventana *garantizada*, dos procesos
reales, en PG y MySQL—; no encontré ningún 🔴 nuevo ni ningún camino que conceda de más. Lo que queda
abierto es la **otra mitad de V4/V5**: la mina de slug sigue viva (un actor de rank 2 tumba el
`syncAuthzCatalog` de la plataforma para siempre) y la promesa de M4 «un rol cuyo owner sale del árbol
no sobrevive» se rompe en silencio con un **alias del uuid del scope** (los hechos se canonizan, los
roles no) y con el memo de ventana. Todo es 🟠/🟡 de disponibilidad e higiene, ninguno de autorización.

---

## Misión 1 · Prueba de cierre: los cinco `repro*.ts`, adaptados y re-ejecutados

Adaptaciones hechas (API nueva): `RoleQuery` acepta `{ uuid }`, las tres escrituras de delegación
toman `ScopedWriteOptions`, `roleVisible` lanza 422 con más de un rol visible. Donde el script v6 moría
en el primer 422 (era su forma de "ganar"), el v7 captura el error y **sigue** hasta el final del
ataque: así se distingue *«el paquete lo rechaza»* de *«mi script ya no compila»*.

| # | Hallazgo (antes) | Resultado ANTES (`f563465`) | Resultado AHORA (`56094ac`, PG) | Estado |
|---|---|---|---|---|
| **V1** 🔴 | `#rolesAlong` por slug ⇒ `effectivePermissions` miente y `defineScopedRole` delega lo que el actor no tiene | `effectivePermissions(pepe) = ['billing:write']` con `authorize = false`; `authorize(titere,'billing:write') = true` | `effectivePermissions = ['docs:read']` = `{p \| authorize(p)}`; la delegación de `billing:write` ⇒ 422 `E_AUTHZ_PERMISSION_NOT_DELEGABLE`; delegar `docs:read` (que sí tiene) sigue funcionando; el rank del actor es el suyo (rank 10 ⇒ `rank: 10` ⇒ 422 `RANK_EXCEEDED`) | ✅ **cerrado** |
| **V2-A/C** 🔴 | dos `define` concurrentes ⇒ dos homónimos permanentes | `define(orgA) = fulfilled` + `define(U1) = fulfilled`, 2 filas, `authorize(currante,'billing:write') = true` | 1 sola fila; el perdedor 422 `E_AUTHZ_CATALOG_CONFLICT`. **Dos procesos `node` reales** (PG) y **ventana garantizada** con memo de ventana (PG y MySQL): 1 fila, 422 siempre | ✅ **cerrado** |
| **V2-B** 🔴 | `define` vs `syncAuthzCatalog` ⇒ el local tapa al global | `sync = fulfilled` + `define = fulfilled`, `authorize(nuevo,'docs:write') = true` | `define = rejected E_AUTHZ_CATALOG_CONFLICT`, queda solo el global; con ventana garantizada y dos procesos, igual, en PG y MySQL | ✅ **cerrado** |
| **V3** 🟠 | `grant`/`hasRole`/`listSubjects` por slug asignan el rol de otro tenant tras un `moved` | `rol realmente asignado: … <-- ES EL DE B`, `authorize(victima,'billing:write') = true` | `grant`/`hasRole`/`listSubjects` por slug ⇒ 422 `E_AUTHZ_AMBIGUOUS_ROLE` **antes de escribir** (0 asignaciones); `{ uuid }` asigna el correcto; `authorize` responde igual; `revoke` por slug quita los dos; tras purgar el homónimo el slug vuelve a funcionar. Idéntico en `openfga` | ✅ **cerrado** |
| **V4** 🟠 | la API de delegación es una escritura sin `within` | `currante` (solo rol raíz) creó un rol dentro de `orgB` con `requireWithin:'non-root'` | 422 `E_AUTHZ_WITHIN_REQUIRED`. Las **diez** entradas de escritura exigen `within` con `true` y con `'non-root'` (tabla completa abajo) | ⚠️ **parcial** — la contención sí; el *squatting* de slug que el propio V4 (b) señalaba, **no** (🟠 A1) |
| **V5** 🟡 | rol cuyo owner desaparece: indeleteable + bloquea el slug global | `deleteScopedRole ⇒ 422 E_AUTHZ_UNKNOWN_SCOPE`, `la fila del rol sigue: 1` | con `scopes.detached(owner)` canónico: `422 E_AUTHZ_UNKNOWN_ROLE`, `la fila sigue: 0` | ⚠️ **parcial** — se rompe con un **alias del uuid** (🟡 A2), con el memo de ventana (🟡 A2 bis) y no alcanza a los **descendientes** (🟡 A4) |
| **V6** 🟡 | README decía «el motor nunca evalúa el actor» | — | README §Actor: «for these six writes the engine never evaluates it — **but the delegation API of 2.2 does**» + «It must come from the session, never from the request body» | ✅ cerrado (documental) |
| **V7** ⚪ | higiene (`owner_scope_key='app'`, `assignable_at` largo, `permissions: []`) | — | `'app'`/basura ⇒ 500 `E_AUTHZ_INTERNAL`; `permissions: []` ⇒ 422; `assignableAt` que no cabe ⇒ 422 al escribir | ✅ cerrado |
| **r5** — 23 barreras que YA resistían | verdes | **las 23 siguen en 422 antes de escribir** (delegación arriba/lados/raíz, permiso ajeno, lista blanca, `assignableAt`, rank =/0/no entero/por encima, sin actor, actor mal formado, **C2** en el owner y en un ancestro, roles ajenos, globales inmutables, `update` re-subiendo un permiso perdido o denegado, `grant` fuera del owner y en scope desconocido) | ✅ sin regresión |

**Falsos positivos de mi propio arnés** (los declaro para que no cuenten como hallazgo): en `r1` llamé
`listRoleScopes(subject, 'lead', 'unit')` cuando la firma es `(subject, scopeType)` — el `[]` era mío,
no del paquete; en `a5_openfga` llamé `authorizeMany(subject, [permisos], scope)` cuando la firma es
`(subject, permission, scopes[])` — el 422 `E_AUTHZ_INVALID_SLUG` era mío. Ningún otro resultado de
esta auditoría depende de un error de script.

---

## Misión 2 · Hallazgos nuevos (ordenados por severidad)

### 🟠 A1 · La mina de slug sigue abierta: un actor de rank 2 bloquea el catálogo GLOBAL para siempre y tumba el `syncAuthzCatalog` entero

- **Escenario**: `subU9` es admin de una unit (rank 9, un permiso delegable, `within` = su unit: la
  configuración más estricta lo permite) → `defineScopedRole(subU9, unitU9, { slug: 'admin',
  scopeType: 'unit', … })` ✅ y `{ slug: 'operador', scopeType: 'organization' }` ✅ (¡un rol de nivel
  **por encima** de su owner: no es visible en ningún sitio, no concede nada, **solo ocupa el nombre**)
  → (a) el dueño del árbol, `orgA`, no puede definir SU `admin@unit`: 422 `E_AUTHZ_CATALOG_CONFLICT`
  «es un descendiente»; (b) el siguiente deploy de la plataforma, `syncAuthzCatalog` con un global
  `admin@unit`, responde 422 y **revierte el catálogo completo** — el rol nuevo del deploy
  (`nuevo-rol-del-deploy`, sin relación con el conflicto) **no entra**.
- **Evidencia**: ✅ `a1_ambiguo.ts` §(1) en PG, salida literal: `subU9 define "admin@unit" … = {…}` ·
  `orgA … -> 422 E_AUTHZ_CATALOG_CONFLICT: … es un descendiente` · `la PLATAFORMA sincroniza un global
  "admin@unit" -> 422 … colisiona con un rol LOCAL` · `¿el resto del deploy entró? false`. Código:
  `src/catalog.ts:262-278` (el sync aborta si hay CUALQUIER local homónimo, y es todo-o-nada),
  `src/manager.ts:#assertNoRoleCollision` (rechaza al ancestro por el descendiente),
  `src/manager.ts:1019` (`#parseScopedRoleSpec` solo prohíbe el nivel `app`: nada exige que el
  `scopeType` esté al nivel del owner o por debajo).
- **Steelman del defensor**: *«no es escalada, es disponibilidad; el mensaje del 422 nombra al owner y
  la plataforma tiene `manager.driver().purgeRole(uuid)` para limpiar»* → **me convence a medias**: es
  cierto que no concede nada y que hay salida, pero (1) el auditor ya lo listó en V4 (b) y el lote
  marca M3 ✅ sin cerrarlo, (2) la corrección se dispara en **producción, en el deploy**, y el
  bloqueo lo provoca el actor de MENOR privilegio del sistema, (3) `permissions: []` se cerró
  precisamente por ser *squatting con forma de spec* (N3) y esta variante —un permiso real, un nivel
  imposible— es exactamente lo mismo con un permiso de adorno.
- **Mitigación mínima**: exigir que `spec.scopeType` sea el nivel del owner o uno por debajo (mata la
  variante «rol de nivel imposible»), y que el sync **no aborte el catálogo entero** por una colisión
  con un local (reportar y seguir, o un `--force` que renombre/purgue el local nombrándolo).

### 🟡 A2 · `scopes.detached` con un alias del uuid del scope purga los HECHOS pero NO los roles: la mina de V5 vuelve, en silencio

- **Escenario**: árbol SQL con `uuid` nativo de PG (el del propio harness, `demo_scopes`). El rol
  `alias@unit` tiene `owner_scope_key = 'unit|01a04e1a-1bc2-…'` (canónico). El consumidor notifica
  `scopes.detached({ type:'unit', uuid:'01a04e1a1bc2756aa929b7c84d23c830' })` — el **mismo** scope sin
  guiones, que PG resuelve a la misma fila y el paquete acepta (`assertScope` solo exige minúsculas y
  el juego de caracteres) → `purgeScope` **sí** canoniza (`canonicalOrSelf`) y borra las asignaciones;
  `#purgeRolesOwnedBy` **no**: busca por `scopeKey(child)` tal cual llegó, no encuentra nada y **no
  purga el rol**. El consumidor borra su fila: `deleteScopedRole ⇒ 422 E_AUTHZ_UNKNOWN_SCOPE`, la fila
  del rol sigue, y `syncAuthzCatalog` de un global `alias@unit` ⇒ 422 para siempre.
- **Evidencia**: ✅ `a3_detached.ts` §(b) en PG, salida literal: `¿el árbol resuelve el alias? true ·
  chain[0]: 01a04e1a-1bc2-…` · `filas de "alias" tras el detached por alias: 1` · `asignaciones …: 0` ·
  `deleteScopedRole … -> 422 E_AUTHZ_UNKNOWN_SCOPE` · `fila del rol "alias": 1` · `sync global
  "alias@unit" -> 422 E_AUTHZ_CATALOG_CONFLICT`. Código: `src/manager.ts:395` (`#purgeRolesOwnedBy(driver,
  child, …)` con el `child` **crudo**) y `:413` (`catalog.rolesOwnedBy(scopeKey(scope))`) frente a
  `src/drivers/database_driver.ts:979` (`purgeScope` → `canonicalOrSelf`). Con `within`, la cadena
  canónica ya se resolvió en `#assertWithin` (`manager.ts:511`) y **se tira**.
- **Variante (mismo defecto, otra vía)**: la lista de roles a purgar sale del **memo**, no de la base.
  Con `catalogRevalidate: { everyMs }` (config legal y documentada), un rol que otro proceso acaba de
  confirmar no está en la foto y **no se purga**: ✅ `a6_varios.ts` §(iv), `fila de "tardio" tras el
  detached del proceso con memo de ventana: 1`. M2 aprendió a releer la BASE dentro de la transacción;
  M4 no.
- **Steelman**: *«invariante 17 dice que la identidad canónica la fija el resolutor; un consumidor que
  pasa un alias ya está fuera de contrato»* → **no me convence**: el propio invariante 17 existe porque
  el paquete **no** confía en eso y canoniza él (`chain[0]`) en *todos* los hechos; aquí hay dos
  comportamientos distintos **dentro del mismo método** (hechos sí, roles no) y el fallo es silencioso
  —ni error ni evento—, que es justo lo que V5 costaba de detectar.
- **Mitigación mínima**: resolver la cadena una vez en `scopes.detached` y pasar `chain[0]` tanto a
  `#purgeRolesOwnedBy` como a `purgeScope` (y leer los roles del owner con la vista revalidada).

### 🟡 A3 · `scopes.detached` es ahora una escritura de CATÁLOGO sin policy de rank: un rank 5 destruye lo que `deleteScopedRole` le niega

- **Escenario**: `orgA` (rank 50) crea `caro@unit` (rank 40) con owner `unitU1`; `subU1` es admin de
  `unitU1` con rank 5 y `within = unitU1` (config `requireWithin:'non-root'`, `requireActor:true`) →
  `deleteScopedRole(subU1, caro)` ⇒ **422 `E_AUTHZ_RANK_EXCEEDED`** (correcto) → `scopes.detached(unitU1,
  { within: unitU1, actor: subU1 })` ⇒ **OK**: `caro` y todos los roles del scope desaparecen, junto con
  todos los hechos. El árbol del consumidor **sigue teniendo la unit** (el paquete no comprueba que el
  scope se haya ido de verdad).
- **Evidencia**: ✅ `a3_detached.ts` §(a) en PG: `subU1: deleteScopedRole(caro) -> 422
  E_AUTHZ_RANK_EXCEEDED` · `subU1: scopes.detached(U1) [misma within] = undefined` · `filas de "caro"
  tras el detached: 0` · `¿U1 sigue en el árbol del consumidor? true`. Código: `src/manager.ts:378-400`
  (ni `#assertAboveRole` ni actor obligatorio; `AuthzCatalogWriteEvent.actor` pasó a opcional en 3D).
- **Steelman**: *«`scopes.*` es la API del árbol, la usa la plataforma; `within` es la contención y el
  daño no sale del scope del actor»* → **me convence a medias**: es verdad que no hay escalada ni cruce
  de tenant, pero el invariante 15 invita explícitamente a que `within` venga de la **sesión del
  tenant** (es decir, a exponer `scopes.*` a un admin de scope), y desde 3D esa llamada destruye
  objetos de catálogo que la API de delegación protege con rank. Dos puertas, una con cerradura.
- **Mitigación mínima**: o `scopes.detached` exige rank mayor que el del rol que va a purgar (como
  `deleteScopedRole`), o el README dice en una línea que `scopes.detached` es operación de plataforma y
  **no** debe colgarse de una sesión de tenant.

### 🟡 A4 · M4 no alcanza a los descendientes: `detached(padre)` deja huérfanos e indeleteables los roles de los hijos

- **Escenario**: `unitU2` cuelga de `unitU1`; `nieto@unit` tiene owner `unitU2`. El consumidor borra el
  subárbol y notifica `scopes.detached(unitU1)` (lo natural: notifica el nodo que borró) → los roles de
  `unitU1` se purgan, los de `unitU2` **no** → `deleteScopedRole(nieto)` ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE`,
  la fila sobrevive y el global `nieto@unit` queda bloqueado para siempre. Es **V5, intacto**, un nivel
  más abajo.
- **Evidencia**: ✅ `a3_detached.ts` §(c): `filas de "nieto" (owner U2): 1` · `¿U2 sigue en el árbol?
  false` · `deleteScopedRole(nieto) … -> 422 E_AUTHZ_UNKNOWN_SCOPE` · `sync global "nieto@unit" -> 422
  E_AUTHZ_CATALOG_CONFLICT`.
- **Steelman**: *«`purgeScope` siempre fue del scope EXACTO (invariante 11) y el consumidor debe
  notificar un `detached` por nodo»* → **me convence a medias** para los hechos (está escrito), **no**
  para el texto de 3D: el invariante 18 promete «**un rol cuyo owner sale del árbol no sobrevive**», y
  con un `detached` del padre sobrevive. O se purga el subárbol, o la promesa se escribe con la letra
  pequeña.
- **Mitigación mínima**: bajar la promesa a «los roles cuyo owner es ESE scope» en `CLAUDE.md`/README, o
  purgar por prefijo del subárbol con `descendantsOf` cuando el consumidor lo tenga.

### 🟡 A5 · Ambigüedad irreversible para el tenant: 422 permanente sobre su propio slug, sin API para salir

- **Escenario**: el tenant B (admin rank 90) define `lead@unit` con **rank 89** owner `unitU1`; la
  plataforma transfiere `unitU1` al tenant A (admin rank 10, operación legítima) → en A: `grant`/
  `hasRole` por slug ⇒ 422 `AMBIGUOUS`; `deleteScopedRole(leadB)` ⇒ 422 `RANK_EXCEEDED` (89 > 10);
  `defineScopedRole` de un `lead@unit` de repuesto ⇒ 422 `CATALOG_CONFLICT`; `updateScopedRole
  {slug:'lead2'}` ⇒ 422 `INVALID_IDENTITY` (**el propio mensaje del error de ambigüedad aconseja
  «renombra uno de ellos» y la API prohíbe renombrar**). Solo queda `{ uuid }` (funciona) o la
  plataforma.
- **Evidencia**: ✅ `a1_ambiguo.ts` §(2) en PG, las cinco líneas anteriores literales; `authorize` sigue
  respondiendo `true` y `grant` por `{ uuid }` funciona.
- **Steelman**: *«fail-closed, `{ uuid }` es la forma exacta y el diseño dice que la ambigüedad se
  resuelve en lectura»* → **me convence** como decisión de seguridad; **no** como experiencia
  operativa: el tenant queda con un 422 permanente en su propio scope y el paquete no le da ninguna
  salida (ni renombrar, ni purgar, ni «desambiguar por owner»).
- **Mitigación mínima**: una frase en README («si dos homónimos se juntan por un `moved`, solo la
  plataforma puede deshacerlo: `driver().purgeRole`») y quitar del mensaje el consejo de renombrar.

### 🟡 A6 · Los 422 nombran identificadores de OTRO tenant

- **Escenario**: `secreto-de-b@unit` existe solo en el tenant B. El admin de A hace `grant(x,
  'secreto-de-b', unitA1)` → 422 con el mensaje: *«… es local a `organization|01a04e1e-…-742cbd07940b` y
  ese scope no está dentro»* — que es la **clave de scope del tenant B**. Igual `AMBIGUOUS_ROLE`
  (uuids y owners de los dos roles) y `CATALOG_CONFLICT` («es un descendiente (`unit|…`)»).
- **Evidencia**: ✅ `a6_varios.ts` §(i), salida literal, y `src/drivers/database_driver.ts:80-88`
  (`visibleRoleOrFail` imprime `named.map(r => r.owner)`, **todos** los homónimos, visibles o no).
- **Steelman**: *«son mensajes para el operador, y el consumidor no debe reenviar `error.message` al
  tenant»* → **me convence a medias**: el paquete pone los identificadores ahí precisamente para que
  alguien los lea, y un 422 es lo que un framework devuelve tal cual al cliente por defecto. Basta con
  no listar los owners que el llamante **no** puede ver.
- **Mitigación mínima**: en `visibleRoleOrFail`, listar solo los owners que están en la cadena del
  scope preguntado (los demás: «y N más fuera de este árbol»).

### ⚪ A7 · Coste del cerrojo de M2 (medido) — correcto, pero conviene saberlo

- Con la fila `authz_catalog_version` bloqueada 12 s por otra transacción: `grant`, `deny` y
  `authorize` **siguen respondiendo** (los hechos no pasan por el cerrojo, tal como dice el informe), y
  la API de delegación de otro proceso muere a los 5 s con **503 `E_AUTHZ_BACKEND_TIMEOUT`
  (`catalog.lock`)** sin escribir nada (`fila del rol "bloqueado": 0`). ✅ `a7_cerrojo.ts`.
- Consecuencia: un `syncAuthzCatalog` grande (todo-o-nada, con el cerrojo tomado) convierte en 503 toda
  llamada concurrente a `define/update/delete/purgeRole`. Es fail-closed y con deadline acotado; solo
  hay que documentarlo junto a `revalidate`.
- **No encontré deadlock**: el orden de bloqueo es único (versión → filas de `authz_*`) y `purgeScope`
  —el único que toma filas de hechos en masa— **no** toca la fila de versión
  (`database_driver.ts:974-1000`); `define || detached` en dos procesos terminó sin bloqueo
  (`a2_lock.ts` §3).

### ⚪ A8 · Higiene del cambio de contrato

- `AuthzWriteEvent.role` pasa de `string` a `RoleQuery`: un sink de auditoría que filtraba por slug deja
  de casar en silencio (declarado breaking en el CHANGELOG; lo cito porque es una **pérdida de
  auditoría**, no solo de tipos). Y los `role_purged` que arrastra `scopes.detached` pueden ir **sin
  actor** (`AuthzCatalogWriteEvent.actor` opcional): la purga de un rol de rank 40 puede quedar
  registrada sin autor.
- `#assertNoRoleCollision` en modo `con-árbol` resuelve la cadena de **cada** homónimo del catálogo:
  con N tenants usando el mismo slug (`admin`, `viewer`…) cada `define` cuesta N `resolveChain`. Es
  fuera de la transacción y no bloquea, pero escala con el número de tenants (✅ por código,
  `src/manager.ts:#assertNoRoleCollision`; no medido con N grande).
- El mensaje de `AmbiguousRoleError` aconseja «renombra uno de ellos»; `updateScopedRole` responde 422 a
  `slug`. Contradicción entre el error y la API (ver A5).

---

## Lo que intenté y NO se rompió

- **Ambigüedad como arma**: no se puede **tapar un rol global** (define local con global homónimo ⇒ 422;
  sync global con local homónimo ⇒ 422, también con la ventana garantizada y dos procesos, PG y MySQL);
  no se puede crear ambigüedad **entre tenants disjuntos** sin un `moved` de la plataforma; con la
  ambigüedad viva, `authorize`/`authorizeMany`/`listScopes`/`effectivePermissions`/`listRoles` **siguen
  respondiendo** y coinciden entre sí (holder con los dos homónimos asignados: `authorize` = unión, y
  `effectivePermissions` = exactamente eso); `revoke` por slug **quita los dos** (no deja hechos vivos
  inalcanzables) y `deny`/`removeDeny` ni se enteran (van por permiso). Igual en `openfga`.
- **`{ uuid }` (M1 c)**: uuid de **otro tenant** ⇒ 422 `ROLE_NOT_VISIBLE` (también en la raíz, también
  en `openfga`); uuid de un **permiso** ⇒ 422 `UNKNOWN_ROLE`; uuid de otro **nivel** ⇒ 422
  `ROLE_NOT_VISIBLE`; inexistente ⇒ 422; **mayúsculas**, con **espacios**, `null`, `''`, mezclado con
  `slug` ⇒ 422 `INVALID_IDENTITY`; `hasRole`/`listSubjects` por uuid ajeno ⇒ `false`/`[]` (no lanzan:
  invariante 5); `deleteScopedRole`/`updateScopedRole` de un rol ajeno ⇒ 422 `RANK_EXCEEDED`; de un
  global ⇒ 422 `ROLE_IMMUTABLE`; de un uuid de permiso ⇒ 422 `UNKNOWN_ROLE`. Un global sí se concede
  donde toca (correcto).
- **M3, las nueve escrituras** (`a4_uuid_within.ts`, matriz completa con `requireWithin: 'non-root'` y
  `true`): `grant`, `revoke`, `deny`, `removeDeny`, `scopes.attached`, `scopes.moved`,
  `scopes.detached`, `defineScopedRole`, `updateScopedRole`, `deleteScopedRole` — **todas** 422
  `E_AUTHZ_WITHIN_REQUIRED` sin `within`; `within` de otro tenant ⇒ 422 `E_AUTHZ_NOT_WITHIN`;
  `within: APP_SCOPE` ⇒ 422 `E_AUTHZ_WITHIN_ROOT_FORBIDDEN` solo con `'non-root'` (con `true` se acepta,
  como está documentado). Nada escrito en ninguno de los rechazos.
- **M2 en serio**: dos procesos `node` reales (PG) y, sobre todo, la **ventana garantizada** (memo de
  ventana calentado, el homónimo confirmado desde otro proceso mientras el primero espera) en **PG y
  MySQL**, en las tres formas: local vs local ancestro, local vs **global del sync**, y local vs local
  **descendiente** (este último cae en el rechazo genérico «el catálogo cambió mientras se validaba»,
  que es fail-closed y reintentable). Siempre **una** fila.
- **M4 en `openfga`**: `scopes.detached` de un scope con roles locales ⇒ **500 `E_AUTHZ_UNSUPPORTED`
  sin tocar nada** (`hasRole` sigue `true`, la fila del rol sigue, `authorize` sigue `true`); un scope
  **sin** roles locales se purga con normalidad. Tal como dice el informe.
- **Las 23 barreras de `repro5`** (delegación hacia arriba/lados/raíz, lista blanca, `assignableAt`,
  rank en sus cuatro formas, actor, **C2** —deny en el owner y en un ancestro—, roles ajenos, globales
  inmutables, `update` re-subiendo un permiso perdido/denegado, `grant` fuera del owner y en scope
  desconocido): **todas siguen en 422 antes de escribir**.
- **Regresiones**: suite completa `TEST_DB=pg` + OpenFGA `:8101` ⇒ **674/674** (incluye L0.3, K1 con
  árbol SQL, F1, F2, N1, C2, la escalera de rank y los casos nuevos del juez). El único fallo que vi
  (`harness_cleanup`) fue por **mi** `TEST_PG_URL` con base `authz_suite`: con el nombre estándar, verde.
- `authz:catalog:diff` **sí** reporta la ambigüedad (`rol AMBIGUO … owners=global, organization|…,
  unit|…`) y `inSync: false`.

## Preguntas abiertas para el arquitecto

1. **¿El `scopeType` de un rol local puede estar por encima de su owner?** Hoy sí, y es la forma más
   limpia de la mina de A1 (un rol que jamás será visible, solo ocupa el nombre global).
2. **¿`syncAuthzCatalog` debe abortar el catálogo entero por una colisión con un rol LOCAL?** Es la
   diferencia entre «un tenant molesta» y «un tenant para el deploy».
3. **¿`scopes.detached` es API de plataforma o puede colgar de una sesión de tenant?** De la respuesta
   depende si A3 es un fallo o una nota del README; el invariante 15 sugiere hoy lo segundo y el código
   no lo defiende.
4. **¿La promesa «un rol cuyo owner sale del árbol no sobrevive» se mantiene** (y entonces hay que
   canonizar el scope, releer de la base y bajar por el subárbol) **o se acota por escrito** al scope
   exacto y canónico?
