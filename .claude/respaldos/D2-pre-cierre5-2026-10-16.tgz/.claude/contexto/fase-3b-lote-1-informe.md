# Fase 3b · Lote 3b-1 — deuda heredada de la Fase 3 (informe incremental)

> Base: `6bdf946` (rama `v2/fase-3b`, árbol limpio). Lote **pequeño y de honestidad**: cierra
> promesas que el paquete publica y no sostiene, y devuelve oráculo a lo que se quedó sin él.
> **Ninguna feature nueva.** Un solo cambio de comportamiento (T-3b · 1/2/3, el diff), marcado.
>
> Baseline medido al empezar: `npm test` **422** (`:8101` no se midió antes de empezar; los tres casos
> nuevos de D1–D3 corren también ahí, y el total con `:8101` tras D1–D3 es **527**).

---

## D1 🟡 — la reparación por ensombrecimiento exige superar el rango DEL SQUATTER

**El problema.** X1 publicaba, en tres sitios, que el daño residual de la degradación de
`descendantsOf` «es reparable por AUTORIDAD + RANGO: un ancestro con rango por encima define el
suyo y lo ensombrece». El ancestro **dueño del árbol** puede no tener ese rango: `rank` es metadata
del consumidor (invariante 8) y nada obliga a que decrezca con la profundidad.

**Rojo primero.** El caso nuevo, escrito con la frase publicada (`orgAdmin` rank 50, dueño de
`orgA`, ensombrece el `mina@unit` rank 59 que ocupó el actor de la unit):

```
❯ 3b-1 · D1 … el DUEÑO del árbol no puede …
ℹ RankExceededError: defineScopedRole: por debajo de este owner ya hay un rol local 'mina' de
  nivel 'unit' con rank MAYOR O IGUAL al tuyo (tu rank aquí es 50) …
 ⁃ at AuthorizationManager.#assertAboveShadowed (src/manager.ts:1589:13)
```

**Qué se hizo.** La frase corregida en `README.md`, `CLAUDE.md` (invariante 18) y el docblock de
`#assertLevelUnderOwner` (`src/manager.ts`), más una entrada de CHANGELOG. Lo que ahora dice:
ensombrecer repara **solo si se supera el rango del squatter**; con ranks no monótonos (rank 60 en
una unit bajo el org-admin rank 50 que es dueño de ese árbol) el dueño se lleva 422
`E_AUTHZ_RANK_EXCEEDED` por las **dos** puertas (`defineScopedRole` y `deleteScopedRole`) y
`scopes.detached` **no es una tercera** (desde 3b-0 · Z1 purga hechos y no mira el catálogo). Lo
que sí es siempre cierto: el recurso es la **plataforma**, y lo tiene por construcción —
`#assertRank` acota todo rank local por debajo del techo global, y `driver().purgeRole` no mide
rango.

**Caso**: *3b-1 · D1* en `tests/manager.spec.ts` — la plataforma (rank 100) crea `unit-boss` rank 60
en la unit, el boss ocupa `mina@unit` rank 59, el dueño del árbol (rank 50) se estrella por las dos
puertas, `detached` no toca el catálogo, y la plataforma sí ensombrece (evento con
`shadowedByAncestor`) y sí purga.

---

## D2 🟡 — la ventana de `#shadowedBelow` con `resolveChain(owner) === null`

**El problema.** `#shadowedBelow` resuelve el owner de cada homónimo en fresco y, si la cadena es
`null`, el rol **no entra en la lista de ensombrecidos**: «no demostrable» se trata como «no hay
sombra», así que W3 es fail-open en esa ventana.

**Decisión (del dueño, confirmada al implementar): NO rechazar; documentar la ventana.** No la
tomé contra «rechazar siempre», sino contra la opción nueva: desde 3b-0 · Z1 un rol cuyo owner no
resuelve está **dormido** y la salida es `prune-orphans`. Rechazar aquí convertiría un rol dormido
en un **bloqueo de `(slug, nivel)`** —exactamente la mina que Z1 quitó, y verificada viva: el caso
*3b-0 · Z3 (tester)* afirma que un rol dormido **no** bloquea el homónimo del hermano ni el del
ancestro— y lo haría por una condición que el llamante no ve ni puede corregir. No encontré datos
que lo desmientan, así que se implementa la decisión del dueño.

**Rojo primero.** El caso escrito con la promesa publicada de W3 (que el `define` del atacante sea
422 dentro de la ventana):

```
❯ 3b-1 · D2 … la VENTANA de W3 está documentada, no cerrada …
ℹ AssertionError: debería haber rechazado
 ⁃ at rejects (tests/manager.spec.ts:2186:12)
```

**Qué se hizo.** La ventana escrita en el docblock de `#shadowedBelow`, en `README.md` y en
`CLAUDE.md` (invariante 18), con lo que la acota: (a) el mismo atacante logra la **misma**
denegación **yendo primero**, sin trampa —W3 solo protege a los roles que YA existen—; (b) nadie
pierde permisos (`authorize` no direcciona por slug); (c) la sombra sale en `authz:catalog:diff`
como `shadowedByAncestor` (y `--fail-on-shadows` la cuenta como deriva); (d) un ancestro con rango
la borra, y la plataforma siempre (D1).

**Caso**: *3b-1 · D2* en `tests/manager.spec.ts` — control con el árbol respondiendo (422), el
mismo `define` con el owner oculto (entra, rank 5), la sombra permanente al volver el árbol
(`hasRole` ⇒ 422 `E_AUTHZ_AMBIGUOUS_ROLE`, `authorize` sigue en `true`), la **víctima** no la
repara (rank 60 en su unit, 0 en la cadena del owner de la sombra), el diff la lista, el dueño del
árbol sí la borra, y la mitad honesta: el mismo atacante **yendo primero** deja al descendiente con
un 422 `E_AUTHZ_CATALOG_CONFLICT` sin usar ninguna ventana.

---

## D3 🟡 — «sobre un rol solo actúa quien lo supera en rango» no es un invariante

**El problema.** 3G escribió esa regla en `CLAUDE.md`, `README.md` y `CHANGELOG.md` como si fuera un
invariante del sistema. Es una **comprobación de escritura**: «ensombrece» es función del árbol de
HOY y `scopes.moved` crea sombras sin juzgar ningún rango.

**Qué se hizo.** Reescrita como comprobación de escritura en `CLAUDE.md` (invariante 18),
`README.md` y `CHANGELOG.md`, nombrando `scopes.moved` como la vía, y añadida al docblock de
`scopes.moved` y al de `#assertAboveShadowed` en `src/manager.ts`.

**Caso**: *3b-1 · D3* en `tests/manager.spec.ts` — `lejano@unit` rank 40 bajo `orgB`; `pobre`
(rank 10 en `orgA`) define su homónimo rank 5 **legalmente y sin sombra**; el consumidor mueve la
unit a `orgA` y lo notifica; el slug pasa a 422 `E_AUTHZ_AMBIGUOUS_ROLE` (`hasRole` y `grant`),
`authorize` sigue concediendo, el dueño del subárbol movido **no** puede reparar (422
`E_AUTHZ_RANK_EXCEEDED`: su rango se mide en la cadena del owner de la sombra) y el diff lo lista
como `shadowedByAncestor`.

**D4–D7** ya estaban hechos en 3b-0/0b (D4 con la corrección de la premisa en AA1, D5/D6 con la
superficie que Z1 borró, D7 con el docblock duplicado).

### Estado tras D1–D3

| Comando | Antes | Ahora |
|---|---|---|
| `npm run typecheck` | ✅ | ✅ |
| `npm test` | 422 | ✅ **425** |
| `OPENFGA_TEST_URL=…:8101 npm test` | — | ✅ **527** |

---

## T-3b — los nueve del tester (`fase-3-verificacion-tester-3f.md` §6)

| # | Hueco | Qué se hizo |
|---|---|---|
| **1** | `runCatalogDiff` solo imprime las sombras del catálogo #1 | **Arreglado** (cambio de comportamiento del diff, ver abajo) + caso |
| **2** | `classifyHomonyms` hace `continue` con un global en el grupo | **Ya estaba cerrado en 3G · X3** y tiene caso vivo: lo comprobé antes de tocar nada |
| **3** | `shadowedByAncestor` repetido con owners anidados | **Arreglado**: una línea por ensombrecido + caso |
| **4** | Aserción perdida en «subárboles disjuntos» | **Devuelta** (dos líneas: `ambiguousRoles` y `catalogInSync`) |
| **5** | Falta caso de `truncated: true` con 0 roles | **Sin sujeto tras 3b-0** (comprobado) |
| **6** | Contador de `sync.role.locals` | **Oráculo nuevo** en `tests/spies.spec.ts` |
| **7** | T2 (503 de quien espera en el cerrojo) | **Oráculo nuevo** en `tests/catalog_cache.spec.ts` (PG/MySQL) |
| **7** | T4 (coste de `onWrite`) | **Oráculo nuevo** en `tests/spies.spec.ts` |
| **8** | R7 sin oráculo | Ya declarado y confirmado por el tester; no se toca |
| **9** | Degradación de S2 silenciosa | Ya escrito en 3b-0b · AB1 (`truncated` se borró; lo que se vigila es la cota) |

### 1 y 3 · el diff (**cambio de comportamiento**, `src/catalog.ts`)

**Rojo primero** (dos catálogos, la sombra la causa un rol del catálogo #2):

```
❯ catálogo / 3b-1 · T-3b … runCatalogDiff acumula las sombras de TODOS los catálogos …
ℹ AssertionError: y la del catálogo #2: expected 'catálogo #1: DIFERENCIAS\n  permiso a…'
  to include 'rol local ENSOMBRECIDO por un global …'
```

- **`runCatalogDiff`** acumula `shadowedByGlobal`/`shadowedByAncestor` sobre **todos** los índices con
  deduplicación y formatea una sola vez. `formatShadowedRoles` pasa a aceptar
  `Pick<CatalogDiff, 'shadowedByGlobal' | 'shadowedByAncestor'>` (cualquier argumento anterior lo
  sigue cumpliendo). `scopedRoles` se sigue tomando del índice 0: lee la BASE y no depende del spec
  (3E · Q6), y así queda dicho en el comentario.
- **`classifyHomonyms`** deja de iterar parejas y emite **una entrada por rol ensombrecido**,
  nombrando al ensombrecedor **más autorizado** (el ancestro más alto de la cadena del ensombrecido,
  que es el orden que fijó 3F · S3). Con `a > b > c` pasa de 3 líneas a 2. La pareja contradictoria
  (cada owner ancestro del otro) sigue yendo a `ambiguousRoles`, que es la única deriva.

**Caso**: *3b-1 · T-3b (§6.1 y §6.3)* en `tests/manager.spec.ts`, grupo `catálogo`.

### 4 · la aserción de «subárboles disjuntos»

Devuelta en el caso que ya existía: además de `shadowedByAncestor` vacío, ahora se afirma
`ambiguousRoles` vacío y `catalogInSync` — que es lo que el caso se llama a sí mismo («legal»).

### 5 · `truncated: true` con 0 roles — **sin sujeto**

`grep -rn truncated src/ commands/ tests/ index.ts` ⇒ **una sola línea**, y es el comentario de
`src/manager.ts` que explica que el campo se borró con `ScopeDetachOutcome` en 3b-0 · Z1. No hay
retorno que lo lleve ni operación que lo produzca: el hueco desapareció con la superficie que lo
tenía. Queda escrito aquí en vez de inventarle un caso.

### 6 · el contador de `sync.role.locals`

3F · T2 sacó del cerrojo la búsqueda de homónimos locales (una consulta en lote en vez de una por
rol del spec) porque la sección crítica alargada hace probable el 503 de los `defineScopedRole`
concurrentes. Nadie lo medía. Caso nuevo en `tests/spies.spec.ts`: con cuatro roles homónimos en el
spec, las consultas a `authz_roles` que **excluyen** al owner global son exactamente **1**. Un
mutante «una por rol» da 4 y muere.

### 7 · T2 — el 503 de quien ESPERA en el cerrojo (oráculo nuevo, PG/MySQL)

`tests/catalog_cache.spec.ts`: una `withAuthzCatalogWrite` sostiene el cerrojo (avisa desde dentro de
`fn`, que corre DESPUÉS de `lockCatalogForWrite`, así que la ventana no depende de ningún `sleep`) y
otra entra con `timeoutMs: 300`. Se afirma que **no entra** en la sección crítica, que el error es
503 `E_AUTHZ_BACKEND_TIMEOUT`, que el mensaje dice `catalog.lock` (no es un 503 genérico) y que **no
escribió**: la única subida de versión es la de la primera. En SQLite no hay `FOR UPDATE` y el caso lo
dice en vez de fingir. El `soltar()` va en un `finally`: si la aserción se rompe, la primera
transacción tiene que terminar igual o cuelga la suite entera.

**Mutante** (`lockCatalogForWrite` sin cerrojo): `2 failed` — muere con este caso («la segunda
escritura no entró en la sección crítica») y con el que ya vigilaba el `FOR UPDATE`.

### 7 · T4 — el coste de `hooks.onWrite` (oráculo nuevo)

`tests/spies.spec.ts`, medido: `grant`/`revoke` sin hook = **1** `resolveChain`; con hook = **2**; y
dentro de una vista de `forRequest()` —donde dos lecturas comparten **1**— la escritura con hook
sigue costando **2**. Es exactamente lo que el README promete desde 3F · T4 («un `resolveChain`
FRESCO, no el memo, más una vista de catálogo por escritura»).

---

## ⚪ heredados de 3b-0/0b

### M13 · la canonización que hace el DRIVER en `purgeScope`

Dos oráculos, porque el que faltaba tenía que valer **en todos los motores**:

- `tests/database_driver.spec.ts` — un resolutor que funde el alias sin guiones con la fila
  canónica (lo que hace el tipo `uuid` de PG). Los hechos se escriben bajo `chain[0]`;
  `purgeScope(alias)` **purga la forma canónica**; un scope que el árbol no conoce se purga tal cual
  y no arrastra nada; y **sin resolutor** el alias no puede llevarse los hechos del canónico. Corre en
  los cuatro modos.
- `src/testing/contract.ts` — el caso del alias (2.5-B · K1) gana las dos caras de `purgeScope`
  (rama `known`: purga lo canónico, deny incluido; rama desconocida: no toca nada). **Cero casos
  nuevos**: solo aserciones, así que el conteo del juez no se mueve.

### M14 · el contrato `null` de `descendantsFrom`

Caso nuevo en `tests/scope_tree.spec.ts`: scope desconocido ⇒ `null` (nunca `[]`), hoja conocida ⇒
`[]` (que no es lo mismo), la raíz siempre se conoce, la cota justa cabe y pasarse **lanza** en vez
de truncar. Es la distinción de la que cuelga la degradación de `#descendantsOrDegrade` (3F · S2) y
la copia cualquier driver de terceros que use el helper publicado.

### ⚪3 · el 500 de `pruneOrphanRoles` era invisible sin `:8101`

La cara `whenFalse` del par `purgeRole` solo corre con OpenFGA. Añadido al caso que ya existía en
`tests/manager.spec.ts` («un driver sin `purgeRole`…»): con el driver `database` sin `purgeRole`,
`pruneOrphanRoles()`, `{force}` y `{force, allowMassPurge}` son 500 `E_AUTHZ_UNSUPPORTED`, el mensaje
nombra `purgeRole` y `pruneOrphanRoles`, y —medido con `countQueries`— **cero consultas**: lo dice
antes de leer los roles locales.

### ⚪4 · la fuga no determinista del teardown en PostgreSQL — **encontrada y cerrada**

**Lo que se descartó, midiendo.** Una corrida completa de `test:pg` (+ `:8101`) con un muestreo del
catálogo `pg_database` cada 0,4 s: **máximo 2 bases simultáneas**, y **0** al terminar. Los caminos
que crean bases (`bootApp` de la suite, el hijo de `load_without_sdk`, los dos de
`harness_cleanup`, los `openScratchDatabase` de `migration_stub` y `upgrade_recipe`) tienen todos su
`finally`/`teardown` y ya los vigila `harness_cleanup.spec` (K13). La suite **no** fuga.

**La causa, reproducida.** Los scripts que viven FUERA de la suite: `bootApp()` … `process.exit(0)`,
que es el patrón de **todos** los `.ts` de `.claude/reproducciones/` (y de mis propias sondas).
`process.exit` no espera a ninguna promesa, así que `teardown()` no corre:

```
db:authz_test_8b13bfb3
db:authz_test_4c5a162d
db:authz_test_de0527e5
--- bases tras 3 scripts ---
authz_test_8b13bfb3 · authz_test_4c5a162d · authz_test_de0527e5      <-- 3 scripts = 3 bases
```

Eso explica las dos mitades del informe de 3b-0b: **8 huérfanas** (≈ 8 ejecuciones de scripts) y
**dos re-ejecuciones aisladas de la suite que no lo reproducen** (la suite nunca fue la que fugaba).

**Cerrada.** `bootApp` registra un guard **síncrono** en `process.on('exit')` —lo único que corre
tras un `process.exit()`— que destruye lo que provisionó con `spawnSync` de
`tests/helpers/drop_database.mjs` (que se niega a borrar un nombre sin el sufijo `_<8 hex>` del
harness) y **avisa por stderr**, para que una fuga no vuelva a ser silenciosa. En `sqlite-file` borra
el directorio temporal (`fs.rmSync` ya es síncrono); en `sqlite` no hay nada que fugar; un hijo con
`reuse` no lo registra (comparte la base del padre). El `teardown()` normal lo desregistra.

Medido después del arreglo: dos scripts con `process.exit(0)` ⇒ **0 bases** (y dos avisos en
stderr). **Caso**: *3b-1 (⚪ 4)* en `tests/harness_cleanup.spec.ts`, con hijo
`tests/helpers/exit_without_teardown.ts`. **Mutante** (guard desactivado): el caso muere
(`process.exit() sin teardown dejó 'authz_test_…' en el servidor pg`).

Es harness, no paquete: `src/`, `commands/` y `index.ts` no cambian por esto.

---

## Cierre

### Suites (todas con `OPENFGA_TEST_URL=http://localhost:8101` salvo la primera y el tope 3)

| Comando | Antes (baseline `6bdf946`) | Ahora |
|---|---|---|
| `npm run typecheck` | ✅ | ✅ |
| `npm test` | 422 | ✅ **432** |
| `npm test` + `:8101` | — | ✅ **534** |
| `npm run test:sqlite-file` + `:8101` | — | ✅ **536** |
| `npm run test:pg` + `:8101` | — | ✅ **702** |
| `npm run test:mysql` + `:8101` | — | ✅ **702** |
| tope 3 (`:8103`, `npm test`) | — | ✅ **534** |

Bases de test al terminar: **0** en PostgreSQL y **0** en MySQL (comprobado en el servidor).
Contenedor `openfga-tiny` eliminado. Sin `skip`/`only`, sin commits, **ninguna aserción relajada**
(las únicas líneas `-` de `tests/` son la reescritura de una sola aserción del caso «subárboles
disjuntos», que pasa de una comprobación a tres).

**El conteo de casos del juez no se mueve**: lo que se añadió a `src/testing/contract.ts` son
aserciones dentro de un caso que ya existía (M13), así que `contract_harness.spec` sigue cuadrando
sin tocarlo.

### Superficie tocada

```
 CHANGELOG.md                  |  89 +++      (sección Lot 3b-1: D1/D2/D3 + el diff + los costes + los oráculos + la fuga)
 CLAUDE.md                     |  24 +-       (invariante 18: D1, D2, D3; mapa: catalog.ts y tests/)
 README.md                     |   6 +-       (X1 corregido, la ventana de D2, la regla como comprobación de escritura, el diff)
 src/catalog.ts                |  52 +-       (T-3b 1 y 3: acumular sombras, una línea por ensombrecido)
 src/manager.ts                |  58 +-       (docblocks: #assertLevelUnderOwner, scopes.moved, #shadowedBelow, #assertAboveShadowed)
 src/testing/contract.ts       |  14 +        (M13 en el caso del alias; 0 casos nuevos)
 tests/catalog_cache.spec.ts   |  62 +        (T2: el 503 de quien espera en el cerrojo)
 tests/database_driver.spec.ts |  52 +-       (M13 en los cuatro modos)
 tests/harness_cleanup.spec.ts |  41 +-       (⚪4: process.exit() sin teardown no deja residuo)
 tests/helpers/app.ts          |  66 +        (guard síncrono de salida en bootApp)
 tests/helpers/drop_database.mjs   (nuevo)    (lo único que se puede hacer en process.on('exit'))
 tests/helpers/exit_without_teardown.ts (nuevo) (hijo del caso ⚪4)
 tests/manager.spec.ts         | 244 +        (D1, D2, D3, T-3b 1/3/4, ⚪3)
 tests/scope_tree.spec.ts      |  28 +-       (M14)
 tests/spies.spec.ts           | 100 +        (T-3b 6: sync.role.locals; T4: coste de onWrite)
```

### Lo que NO se hizo, y por qué

- **D2 no rechaza.** Es la decisión del dueño y no encontré datos para desmentirla: rechazar
  convierte un rol **dormido** en un bloqueo de `(slug, nivel)` —la mina que 3b-0 · Z1 quitó, y que
  el caso *3b-0 · Z3 (tester)* afirma viva— por una condición que el llamante no ve. La ventana queda
  **documentada y fijada con un caso**, con su mitad honesta (el mismo atacante gana yendo primero).
- **T-3b 5** (`truncated: true` con 0 roles) no tiene caso porque no tiene sujeto: el campo se borró
  en 3b-0 · Z1 y `grep` lo confirma.
- **T-3b 8** (R7) sigue sin oráculo: está declarado por el 3F y **confirmado por el tester** como
  mutante equivalente bajo el esquema actual; cerrarlo pide infraestructura nueva (FKs desactivadas o
  espiar el SQL) y es una decisión de diseño de la suite, no deuda de este lote.
- **Nada de features.** El único cambio de comportamiento es el del **diff** (observabilidad: más
  sombras y menos ruido), marcado arriba y en el CHANGELOG. `authorize` y las escrituras responden
  exactamente lo mismo que en `6bdf946`.
