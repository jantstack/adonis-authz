# Plan 2.5 · LOTE 0 — guardia de superficie L1 por reflexión (informe del implementador)

Rama `main`, HEAD de partida `0fbee6e`, árbol limpio al empezar. **Sin commits; `version` sin tocar** (`2.4.0-alpha.10`).
Fuente: `panel-tenencia-2-juez.md` §«Plan final por lotes» fila 0 y D4/D6/D13; `panel-tenencia-2-tester.md` §3 (lote 0)
y §4 (G-0, G-F05-*, G-L2/L3/W/ACT-*, G-R, G-M, G-X) y H8/H11; `panel-tenencia-2-auditor.md` R2-7;
`decisiones-dueno-2026-08-28.md` §2026-10-14 (2) (D6 firmada). Otro agente trabaja en el worktree hermano
`adonis-authz-loteR` (rama `lote-r`): no se ha tocado.

Entorno medido: `:8101` **no responde** (`curl localhost:8101/healthz` vacío) ⇒ las suites corren con
`OPENFGA_TEST_URL=http://localhost:8090` (contenedor `openfga-dev`, OpenFGA 1.19, reiniciado con `docker restart` + 8 s
antes de cada suite). Node 22.23.2 (`nvm use 22`). PG `postgres18`, MySQL `mysql84`.

## Estado

- [x] 1 · Guardia por reflexión (manager, dos drivers, vistas `withClock`, doble `makeRelationsDriver`, `exports`) + manifiesto
- [x] 2 · Corredor de mutantes `scripts/check_guard_mutants.mjs` + `tests/fixtures/guard_mutants.json` (89 mutantes, 94 celdas)
- [x] 3 · Lista a mano de «las ocho operaciones» (`relations_database.spec.ts`) sustituida (−1 caso, declarado)
- [x] 4 · Columna «partición canónica» (D4): rama actual «se acepta», preparada para el 422 del lote A
- [x] 5 · Rojo primero (G-0 con un método nuevo; H8 en el doble; G-M sin manifiesto) → verde → mutantes muertos
- [x] 6 · Gemelos en roles: enumerados, no implementados (es otro lote)
- [x] 7 · `linajes.md` L1, CLAUDE.md (tests, scripts, comandos, punto 6), CHANGELOG (Unreleased), job `guard-mutants` en CI
- [x] Verificación en los 4 modos + `tsc`, `typecheck`, `check:purity`, `build` (cifras abajo)
- [x] **Cierre-2** (re-ataque `lote0-auditor-cierre.md`, decisiones §2026-10-14 (5)): 🟡A–🟡E cerrados; sección «Cierre-2» al final (cifras vigentes: 1590 / 1616 / 1712 / 1714, 94/94 mutantes, 154 casos de la guardia)
- [x] **Cierre del auditor** (`lote0-auditor.md`, decisiones §2026-10-14 (4)): 🟠1, 🟠2, 🟡3–7, ⚪8–11 cerrados en el mismo lote; sección «Cierre (auditor)» al final (las cifras de §3 y §9 son las de la PRIMERA entrega; las vigentes están allí: 1583 / 1609 / 1705 / 1707, 93/93 mutantes)

## Ficheros

| Fichero | Qué |
|---|---|
| `tests/fixtures/guard_manifest.ts` (nuevo) | La TABLA operaciones × columnas (`GUARD_MANIFEST`), las cinco exenciones firmadas (`SIGNED_EXEMPTIONS`), las razones cerradas de «no aplica» (`NA_REASONS`), la expectativa de D4 (`DASHLESS_PARTITION`), la clasificación de `exports` (`SURFACE_CLASSES`, `NON_SURFACE_CLASSES`, `NON_SURFACE_FUNCTIONS`), `cellTitle`/`cellId` y el tipo `GuardMutant` |
| `tests/guard_surface.spec.ts` (nuevo) | La guardia: G-0 (inventario por reflexión = filas; vistas `withClock`; doble; `exports`; servicio), un caso por celda con sonda (4 capas), G-R, G-M, G-X. **112 casos** |
| `tests/fixtures/guard_mutants.json` (nuevo) | 89 mutantes (`id`, `cells`, `file`, `find`/`replace` o `edits[]` multi-fichero, `expectRed`, `note`) |
| `scripts/check_guard_mutants.mjs` (nuevo) | El corredor: copia del árbol en `mkdtemp` (+ symlink de `node_modules`), línea base verde, un mutante cada vez, `--reporters=ndjson`, exige rojo EN los `expectRed`, restaura; `--db`, `--only`, `--json`, `--keep`; `npm run check:guard-mutants` |
| `src/testing/relations_contract.ts` | **D13/H8**: el doble `makeRelationsDriver` aplica F-05 por sí mismo (ocho operaciones + userset del sujeto), con las MISMAS dos funciones que los drivers |
| `tests/relations_database.spec.ts` | La lista a mano «cierre alpha.3 · purgeObject/purgeSubject(userset)/check/…» (56 líneas) sustituida por un comentario que apunta a la guardia |
| `package.json` | script `check:guard-mutants` (sin tocar `version`) |
| `.github/workflows/ci.yml` | job `guard-mutants` (matriz `sqlite` / `sqlite-file`), añadido AL FINAL (si el lote R añade `cutover-runbook` también al final habrá un conflicto trivial) |
| `CLAUDE.md` | fila `tests/` (la guardia, el manifiesto, los mutantes, D4, `na` cerradas, hallazgo `scopeKey`), fila `scripts/` (el corredor), «Comandos» (`npm run check:guard-mutants`), punto 6 (nombra los cuatro ficheros) |
| `.claude/contexto/linajes.md` | L1: punto de paso único = la guardia (5.ª iteración: el doble); M7 hecho; historial |
| `CHANGELOG.md` | `[Unreleased]`: el único cambio observable (F-05 en el doble) y el porqué |

## 1 · La guardia: qué enumera y qué exige

**Inventario por reflexión (G-0)**, dentro de `bootApp()` (medido por el tester: el manager y el driver `database` no se
importan sin app):

1. `Object.getOwnPropertyNames(RelationsManager.prototype)` − `constructor` ⇒ 12: `driver`, `capabilities`, `relate`,
   `unrelate`, `check`, `listObjects`, `listSubjects`, `purgeObject`, `purgeSubject`, `membersOf`, `enumerateRelations`,
   `enumerateRelationsMany`.
2. `DatabaseRelationsDriver.prototype` ⇒ 11 (las 10 del puerto + `withClock`); `OpenFgaRelationsDriver.prototype` ⇒ 11.
3. **Vistas (H11)**: `driver.withClock(now)` tiene que ser `instanceof` la misma clase, con EXACTAMENTE los mismos nombres
   en su prototipo y las mismas `capabilities`; y **cada sonda de las filas del driver corre sobre la base Y sobre la
   vista** (`[base, vista withClock]` en las tres capas de driver, el doble incluido).
4. **Doble `makeRelationsDriver`** (D13): las funciones propias del objeto con capacidades completas ⇒ 10 (`relate`,
   `unrelate`, `check`, `listObjects`, `listSubjects`, `purgeObject`, `purgeSubject`, `membersOf`, `enumerateRelations`,
   `withClock`).
5. **`exports`**: se recorre `package.json#exports` por identidad a profundidad 6 (el mismo recorrido que la guardia de
   `reconcileRelations` en `command_flags.spec`); toda CLASE cuyo prototipo tenga ≥ 1 nombre del puerto
   (`PORT_OPERATIONS`) tiene que ser una de `SURFACE_CLASSES` (con filas) o estar en `NON_SURFACE_CLASSES` con razón
   (hoy: las tres del puerto de ROLES, que comparten `listSubjects`); toda FUNCIÓN con «relation» en el nombre tiene que
   ser `makeRelationsDriver` o estar en `NON_SURFACE_FUNCTIONS` con razón (26 clasificadas). Un wrapper nuevo exportado
   nace rojo con su ruta (`src/openfga.ts#…`).
6. **Servicio**: `services/relations.ts` resuelve `container.make('authz.relations')` (por fuente, como en
   `command_flags.spec`) y `buildRelationsManager(config)` devuelve un `RelationsManager` cuyo `driver()` es el inyectado.

**La tabla (manifiesto)**: 44 filas × 6 columnas. Celda = `probe` (sonda + mutante), `na` (razón del conjunto cerrado
`read` / `signature` / `doctrine` / `double`) o `exempt` (una de las cinco firmadas, con su sonda sustituta).

| Capa | Filas | `f05` | `trx` | `freeze` | `write` | `actor` | `partition` |
|---|---|---|---|---|---|---|---|
| manager | `relate` `unrelate` `purgeObject` `purgeSubject` | ✔ | ✔ puerta 1 | ✔ | ✔ | ✔ | ✔ |
| manager | `check` `listObjects` `listSubjects` `membersOf` | ✔ | read | read | read | read | ✔ |
| manager | `enumerateRelations` `enumerateRelationsMany` | EX D6 → lista blanca | read | read | read | read | ✔ |
| manager | `driver` / `capabilities` | EX D6 (identidad / copia congelada) | sig | sig | sig | sig | sig |
| database | 4 escrituras | ✔ | ✔ `#writer` (2 caras) | doctrina | sig | sig | ✔ |
| database | `check` `listObjects` `listSubjects` `membersOf` | ✔ | sig | doctrina | sig | sig | ✔ |
| database | `enumerateRelations(Many)` | EX D6 → lista blanca | sig | doctrina | sig | sig | ✔ |
| database | `withClock` | vista: la tabla entera re-corrida sobre ella | | | | | |
| openfga | 4 escrituras | ✔ | ✔ `#rejectTransaction` | doctrina | sig | sig | ✔ |
| openfga | `check` `listObjects` `listSubjects` | ✔ | sig | doctrina | sig | sig | ✔ |
| openfga | `membersOf` | EX D6 (500 con cero llamadas) | sig | doctrina | sig | sig | sig (sin argumentos) |
| openfga | `enumerateRelations(Many)` | EX D6 → lista blanca | sig | doctrina | sig | sig | ✔ |
| openfga | `withClock` | vista | | | | | |
| double | 8 operaciones | ✔ (D13) | double | double | sig | sig | double |
| double | `enumerateRelations` | EX D6 → lista blanca | sig | double | sig | sig | double |
| double | `withClock` | vista | | | | | |

**Sondas por columna** (una entrada mínima que solo esa guarda corta; cada rojo nombra capa·operación·columna·variante):

- `f05`: variantes `type` (`role_binding`) / `relation` (`document#assignee`) / `undefined` / `userset`
  (`role_binding#assignee` como sujeto), según la firma; 422 con el `code` exacto (`E_AUTHZ_RELATION_TYPE_UNKNOWN` /
  `E_AUTHZ_RELATION_UNKNOWN`); manager: cero llamadas al driver (Proxy espía) y cero eventos; `database`: cero accesos a
  la conexión Y cero sentencias (`countQueries`); `openfga`: cero llamadas al cliente (cliente FALSO que cuenta: sin
  servidor, porque la guarda corta antes de componer una request).
- `trx`: manager `{ transaction: {} }` sobre `transactionalWrites: false` ⇒ 500 `E_AUTHZ_UNSUPPORTED`; `database` dos
  caras: `transactionalWrites: false` ⇒ 500 `E_AUTHZ_UNSUPPORTED`, y `true` con una trx que no es la abierta del
  llamante (`isTransaction: false`) ⇒ 500 `E_AUTHZ_CONFIG`, **cero sentencias** en las dos; `openfga` ⇒ 500 con cero
  llamadas.
- `freeze`: otro manager (`AuthorizationManager` de roles) sostiene `freeze()` ⇒ 503 `E_AUTHZ_FROZEN` reintentable, cero
  llamadas, cero eventos; y el ORDEN: `role_binding` + congelado ⇒ 503 (la barrera va antes que F-05).
- `write`: driver espía que lanza `AuthorizationBackendTimeoutError` ⇒ secuencia `['event:true', 'caught']` (el
  `indeterminate: true` ANTES del 503).
- `actor`: `requireActor: true` sin actor ⇒ 422 `E_AUTHZ_ACTOR_REQUIRED`; `actor: { uuid: 'A#B' }` ⇒ 422
  `E_AUTHZ_INVALID_IDENTITY`; cero llamadas, cero eventos.
- `partition` (D4): `{ type: 'unit', uuid: 'A#B' }` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` con cero backend; y el uuid de 32
  hex SIN guiones según `DASHLESS_PARTITION` (hoy `'accepted'`: resuelve, llega al backend, y en las escrituras del
  manager el evento lleva la partición TAL COMO la pasó el llamante).
- G-R: cada lectura del manager con entrada válida ⇒ cero escrituras del driver y cero eventos; y «lo que notifica es
  exactamente el conjunto `write` del manifiesto» (meta-mutante: reclasificar una escritura como lectura ⇒ rojo aquí y
  en la coherencia de G-M).
- G-M: toda celda con sonda tiene ≥ 1 mutante; cada mutante nombra celdas existentes, su `find` casa EXACTAMENTE una
  vez en su fichero (un refactor que mueva la guarda pone rojo el cruce en `npm test`) y `expectRed` = títulos canónicos.
- G-X: las exenciones usadas = las cinco firmadas, cada una sobre SU operación, y el párrafo de D6 de
  `decisiones-dueno-2026-08-28.md` nombra cada una; y `membersOf` solo está exenta en `openfga` (en manager y
  `database` tiene F-05 con sonda).

## 2 · Rojo primero (observado, `lote0-runs/rojo-1.txt`)

Se añadió a `RelationsManager` un método de prueba `checkMany()` sin fila, se corrió la guardia con el manifiesto de
mutantes VACÍO y el doble sin F-05. **98 verdes / 14 rojos, todos con nombre:**

```
✖ GS · G-0 · RelationsManager: cada método público tiene su fila
  ROJO (G-0): RelationsManager tiene operaciones SIN fila en tests/fixtures/guard_manifest.ts — añade una fila
  'manager' con sus seis celdas para: checkMany
✖ GS · G-0 · exports …: RelationConfigError, RelationTypeUnknownError, RelationUnknownError,
  assertRelationsConfigPublishable, factsRelationMap, factsRelationTypeDefinitions, factsRelationsOf,
  buildRelationsManager, AuthzRelationsReconcile, relationsReconcileLines, relationsConfigOf   (11 sin clasificar)
✖ GS · double.relate · f05 … double.membersOf · f05, double.enumerateRelations · f05   (9: H8, el doble ENTRÓ)
✖ GS · G-M · … celdas con sonda SIN mutante: manager.relate.f05, … (94)
✖ GS · G-M · hay un manifiesto de mutantes de verdad
✖ GS · G-X · … (la firma de D6 va partida en dos líneas: la búsqueda era por línea)
```

Se quitó `checkMany`, se clasificaron las 11 funciones (ninguna recibe tuplas: errores, generadores del modelo, el
provider, el comando, el formateador), G-X pasó a leer el párrafo entero, el doble recibió F-05 y se escribió el
manifiesto de mutantes ⇒ **112/112 verde** (`lote0-runs/verde-1.txt`). Las 98 celdas de manager/`database`/`openfga` fueron
verdes desde la primera corrida, también sobre las vistas `withClock`: las guardas existentes aguantan la tabla.

## 3 · Mutantes (`lote0-runs/mutantes-memory.{txt,json}`, `lote0-runs/mutantes-sqlite-file.{txt,json}`)

**89 mutantes / 94 celdas con sonda — 89 muertos en `:memory:` (76 s) y 89 muertos en `sqlite-file` (77 s).** Cero
vivos, cero «no casa». Por capa: manager 36, `database` 23, `openfga` 22, doble 8. Línea base verde (112 casos) antes
de mutar, en los dos motores. Tres mutantes matan además un colateral (declarado, no es ruido): `manager.driver.identity`
(también el caso «el servicio» afirma `driver()` por identidad), `database.purgeSubject.f05` y `openfga.purgeSubject.f05`
(quitan la línea compartida del userset —`#subjectColumns` / `#subjectUser`—, que también defiende la variante `userset`
de `relate`).

Qué es cada mutante: «quitar la guarda en esa entrada». Dónde la guarda de una entrada son VARIAS líneas del mismo
camino, el mutante las quita todas y lo dice en `note` (G-M no lo exige; el informe sí):

- **`purgeSubject` · f05** (`database`, `openfga`): la primera línea Y la del userset compartido. Quitar solo la primera
  deja el mutante vivo (la compartida lo salva).
- **Partición en los drivers (19 mutantes)**: la línea `assertScope(partition)` propia de la operación, **más
  `scopeKey` (`src/identity.ts`)** —por donde se compone TODA clave y que llama a `assertScope`— y, en purgas y
  enumeraciones, `scopeSpellings` dentro de `#partitionSpellings`. **Medido: quitar solo la línea propia deja el
  mutante VIVO** (`database.purgeObject.partition` en la primera corrida de humo). Es decir: en los drivers la línea
  propia es defensa en profundidad y **el punto de paso real de la gramática de la partición es `scopeKey`/
  `assertScope`**. Dato para el lote A (D4): el 422 del uuid sin guiones puesto en `assertScope` cubre manager, drivers,
  purgas y enumeraciones a la vez; la columna de la guardia lo verifica en las 29 celdas de partición cambiando
  `DASHLESS_PARTITION`.
- Exenciones con sonda: `driver()` (devolver un Proxy ⇒ rojo), `capabilities()` (copia mutable ⇒ rojo),
  `enumerateRelations(Many)` (quitar `.whereIn('object_type', declaredTypes)` en `database` ⇒ rojas las 4 celdas de
  manager+driver; quitar `relationTypes.has(parsed.type)` en el barrido de `openfga` ⇒ rojas las 2), `membersOf` de
  `openfga` (tocar el cliente antes del 500 ⇒ rojo).
- `double.relate.f05` mata también `double.enumerateRelations.f05` (sin F-05 en `relate` el doble siembra
  `role_binding` y la enumeración lo devuelve).

Diseño del corredor: jamás muta el working tree (copia en `mkdtemp`, `node_modules` enlazado; regla de revisiones no
concurrentes); corre SOLO el spec de la guardia con `--reporters=ndjson` y lee `test:end` (`errors.length > 0`);
exige rojo en TODOS los títulos de `expectRed` (no «algún caso»); un título no ejecutado es `SIN-CASO`; el cruce G-M
del árbol mutado se pone rojo siempre (su trabajo) y no cuenta como colateral. ~0,9 s por mutante.

## 4 · D4 · columna «partición canónica» — preparada, no cambiada

`DASHLESS_PARTITION: DashlessExpectation = 'accepted'` en el manifiesto. Las 29 celdas `partition` (manager 10,
`database` 10, `openfga` 9) afirman HOY: gramática rota ⇒ 422 con cero backend; uuid de 32 hex sin guiones
⇒ entra tal cual (en `openfga`, `scopeSpellings` barre las dos ortografías en purgas/enumeraciones, como ya estaba). En
el lote A, cambiar la constante a `{ status: 422, code: 'E_AUTHZ_INVALID_IDENTITY' }` (o el código que se decida) hace
que las 29 celdas esperen el 422 con cero backend y **el caso no cambia de forma**; los mutantes de la columna ya
apuntan a `assertScope`/`scopeKey`, que es donde el 422 tiene que vivir (hallazgo de §3). Lo que NO hace este lote:
el 422, la receta de canonización (E2 del tester) y `checkMany` (R2-7: entra como fila `manager.checkMany` con sus
seis celdas cuando exista; la guardia nacerá roja al añadir el método, como se demostró con el método de prueba).

## 5 · Exenciones (D6, firmadas) — G-X

| Id | Operación | Razón (cae la exención si cambia) | Sonda sustituta |
|---|---|---|---|
| `D6-driver` | `manager.driver()` | salida documentada: devuelve el driver CRUDO | identidad (`===` con el inyectado) |
| `D6-capabilities` | `manager.capabilities()` | copia congelada, sin backend | `Object.isFrozen` + contenido |
| `D6-enumerateRelations` | `enumerateRelations` (manager, `database`, `openfga`, doble) | lista blanca de tipos declarados, no F-05 | fila `role_binding` sembrada no sale (`database`: filas reales; `openfga`: `Read` falso con `role_binding` y `scope`) |
| `D6-enumerateRelationsMany` | `enumerateRelationsMany` (manager, `database`, `openfga`) | idem | idem |
| `D6-membersOf-openfga` | `openfga.membersOf` | no implementado: sin argumentos, siempre 500 | 500 `E_AUTHZ_UNSUPPORTED` con cero llamadas |

«Freeze en la capa del driver» NO es exención: es `na: doctrine` (CLAUDE.md, auditor 🟠 5 de 3b-7: el freeze no congela
`manager.driver()`; la barrera es del manager), razón del conjunto cerrado. Lo mismo `na: signature` (la firma del driver
no recibe `actor` ni emite eventos; `openfga.membersOf` no recibe partición) y `na: double` (el doble no escribe en
transacciones —declara `transactionalWrites: false` y el runner juzga esa cara— ni canoniza).

## 6 · Gemelos

- **Roles tiene lista a mano equivalente**: `tests/freeze.spec.ts:271` «la barrera cubre las siete escrituras» enumera a
  mano 8 escrituras (`grant`, `revoke`, `deny`, `removeDeny`, `scopes.attached/moved/detached`, `defineScopedRole`) y
  deja fuera `updateScopedRole`, `deleteScopedRole`, `pruneOrphanRoles`, `relayScopeChanges`, `requeueScopeChanges`
  y `reconcile`, que también pasan por `#assertNotFrozen` (9 puntos de llamada en `src/manager.ts`). Es la misma forma
  de L3 que L1 tenía en relaciones. `database_transaction.spec.ts` (L-3) enumera «las cuatro escrituras» del
  `{ transaction }` de roles. **No se implementa en este lote**: `linajes.md` (columna M7 de L6: «Roles: pendiente») y el
  plan del juez lo dejan para el lote R («resto de M7»). El patrón para copiar es este: manifiesto de
  `AuthorizationManager` × {freeze, trx, `#write`, actor, `within`} con exenciones firmadas.
- **`reconcile` ↔ `relations:reconcile`**: no aplica aquí (la guardia de superficie del primitivo `reconcileRelations`
  ya existe en `command_flags.spec`, cierre alpha.10 · R1/C5; G-0·exports la complementa clasificando
  `runRelationsReconcile` y `AuthzRelationsReconcile`).
- **Comando ↔ manager ↔ función**: la guardia cubre manager y drivers; los comandos no exponen operaciones de tupla.
- **Runner publicado (D13)**: el doble aplica F-05 (hecho); el **caso nuevo en el runner** «driver llamado en DIRECTO
  debe cortar F-05» (que juzga a drivers de terceros) NO va en este lote porque mueve `EXPECTED_CASES` de
  `relations_harness.spec` (criterio del tester §3: «ningún conteo del runner cambia» en el lote 0) ⇒ lote A, con el
  desglose de conteos que ese lote ya reescribe.

## 7 · Casos existentes tocados

- `relations_database.spec.ts`: **−1** (la lista a mano; borrado declarado). El resto del grupo L-0 (relate/unrelate con
  tipo/relación no declarados, CONTROL) se queda: son casos de letra del 422 por motor, no inventario.
- **Un caso existente se puso rojo por el cierre de H8, justificado** (primera corrida de `npm test` con `:8090`:
  `Tests 1547 passed, 1 failed (1548)`; el log quedó sobrescrito por la corrida final, el rojo decía:
  `RelationTypeUnknownError: El tipo de objeto 'folder' no está declarado en defineRelationsConfig (F-05)` en
  `src/testing/relations_contract.ts:269` (el `relate` del doble) desde `tests/relations_reconcile.spec.ts:331`):
  `relations_reconcile.spec.ts` «una tupla no declarada que ya estuviera en el destino NO cuenta como respaldada» sembraba
  `folder` DIRECTAMENTE en el doble construido con la config actual (que no declara `folder`) — justo lo que el doble sin
  F-05 permitía y un driver real no. El escenario legítimo es el RESIDUO DECLARADO de CLAUDE.md (tupla escrita cuando el
  tipo SÍ estaba declarado y retirado después): el caso construye ahora el doble con la config VIEJA (`sourceConfig`,
  declara `folder`) y el reconcile corre con la ACTUAL (`toConfig`). Mismas aserciones (`extra = 1`, `deleted = 1`,
  `skipped.undeclared = 3`, `check(stray) = false`). Está anunciado en el CHANGELOG («a harness that seeded undeclared
  tuples straight into the double breaks on purpose»).
- Ningún otro caso existente se puso rojo (tester §7: «si sale rojo algo existente es un agujero real»): el único agujero
  real fue H8 (el doble), cerrado en el doble.
- Cuatro líneas del punto 5 para H8: (a) gemelos: §6; (b) tabla de verdad: la del manifiesto (44 × 6); (c) casos
  existentes rojos: ninguno; (d) linaje: L1, 5.ª iteración ⇒ estructural (la guardia), anotado en `linajes.md`.

## 8 · Lo que la guardia NO cubre (declarado)

- Funciones exportadas que reciban tuplas con un nombre sin «relation» (el recorrido clasifica por nombre de función y
  por operaciones de prototipo en clases; un `makeDriverX()` que devuelva un objeto con `relate` no se ve por reflexión
  sin invocarlo). Mitigación: la regla de `NON_SURFACE_FUNCTIONS` obliga a clasificar lo nuevo con «relation», y una
  clase nueva se ve por prototipo.
- `na: doctrine` en los drivers es una decisión escrita, no una sonda: si algún día el freeze debe alcanzar
  `manager.driver()`, se cambia la celda a `probe` y nace roja hasta tener sonda y mutante.
- El corredor exige que el caso NOMBRADO se ponga rojo, no que sea el ÚNICO rojo (los colaterales se listan).

## 9 · Cifras

Secuencia (`lote0-runs/suites-progress.txt`, colas en `lote0-runs/suite-*.tail.txt`), cada suite tras `docker restart openfga-dev && sleep 8`
con `OPENFGA_TEST_URL=http://localhost:8090` (`healthz` = `SERVING` antes de cada una; **`:8101` no responde**, anotado) y
`TEST_PG_URL` con la contraseña de `postgres18`:

| Modo | Resultado | Antes (alpha.10, RETOMAR) | Δ |
|---|---|---|---|
| `npm test` (sqlite `:memory:`) | **1548 passed (1548)**, 2 min | 1437 | +111 |
| `npm run test:sqlite-file` | **1574 passed (1574)**, 2 min | 1463 | +111 |
| `npm run test:pg` (`authz_test_d9b0b876`, destruida) | **1670 passed (1670)**, 2 min | 1559 | +111 |
| `npm run test:mysql` (`authz_test_346aa2e2`, destruida) | **1672 passed (1672)**, 3 min | 1561 | +111 |

+111 = 112 casos de la guardia − 1 (la lista a mano), **idéntico en los cuatro modos** (la guardia no depende del motor:
la columna `trx` de `database` sondea sus dos caras construyendo el driver con la opción, no con el pool). Ningún conteo del
runner cambia (`relations_harness.spec` intacto).

`npx tsc --noEmit` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ · `npm run build` ✔ (purity + typecheck + tsc + stubs).

Mutantes: `npm run check:guard-mutants` ⇒ **89/89 muertos** en `:memory:` (76 s) y `-- --db sqlite-file` ⇒ **89/89** (77 s)
(`lote0-runs/mutantes-*.{txt,json}`). Línea base 112/112 verde en los dos antes de mutar.

Primera corrida de `npm test` (antes de adaptar el caso del reconcile, §7): 1547/1548.

## 10 · Para el lote A (lo que este lote deja preparado)

- `DASHLESS_PARTITION` ⇒ `{ status: 422, code: … }`: 29 celdas cambian de expectativa sin cambiar de forma. El sitio del
  422: `assertScope` (identity.ts) — medido en §3: es el punto de paso real en los drivers (`scopeKey`/`scopeSpellings`).
- `checkMany`: al añadir el método, G-0 nace rojo con su nombre (demostrado con el método de prueba); fila
  `managerRead('checkMany')` (o escritura, según firma) + `INVOKE.checkMany` + `F05_VARIANTS.checkMany` en el spec +
  mutantes.
- D13, segunda mitad: el caso del runner «driver llamado en directo corta F-05» (mueve `EXPECTED_CASES`).
- Receta de canonización (E2 del tester) y reescritura de `relations_database.spec.ts:206/229/252`, `relations_openfga.spec.ts:1069`.

## Cierre (auditor) — `lote0-auditor.md`, decisiones del coordinador §2026-10-14 (4)

Mismo árbol sin commitear sobre `0fbee6e`, `version` sin tocar. El cierre lo empezó un agente que murió al cortarse la
sesión; este cierre partió de un inventario de lo que ya estaba en el diff y en el spec ANTES de tocar nada.

### Tabla hecho/pendiente al retomar (medida sobre el diff + `tests/guard_surface.spec.ts`, 147/147 en `:memory:`)

| # | Hallazgo | Estado encontrado | Dónde |
|---|---|---|---|
| 🟠1 | extracto versionado de D6; G-X sin `.claude/` | **hecho** (faltaba la demo) | `tests/fixtures/exemptions_d6.json`; spec `loadExtract`/`exemptionViolations`/`d6Violations`; caso invertido 🟠1 |
| 🟠2 | matriz cerrada de `na`; `f05` nunca `na`; `platform` solo `driver()`/`capabilities()`; G-R sobre TODO el inventario | **hecho** (faltaba la demo `relateMany ⇒ ROJA`) | manifiesto `NA_MATRIX`/`PLATFORM_OPERATIONS`/`VIEW_OPERATIONS`; spec `manifestViolations`, G-R meta-caso por `surfaceOperations`, G-R «todo método de los drivers se invoca»; caso invertido 🟠2 |
| 🟡3 | inventario con campos arrow, estáticos y heredados | **hecho** | spec `surfaceOperations` (cadena de prototipos, descriptores de instancia que son función, símbolos, `static x`); caso invertido 🟡3 |
| 🟡4 | exactamente cinco, atadas a capa×columna | **hecho** | `SIGNED_EXEMPTIONS` con `layers`/`column`; spec `FIVE_SIGNED`, `exemptionViolations` (una por capa firmada, columna firmada); caso invertido 🟡4 |
| 🟡5 | sonda de escritura PARCIAL; `openfga.purge*.write` ⇒ `probe` | **hecho** | manifiesto `driverWrite('openfga','purgeObject', P)`/`purgeSubject`; spec columna `write` del manager con dos caras (`deadline`/`parcial`) + control; `probeOpenFga` columna `write` con `fakeFgaClient.failOn` (2.º `read` cae tras `deleteTuples`) + control (cae antes) + composición con el manager; mutantes `manager.write.partial`, `openfga.purge.partial`; caso invertido 🟡5 |
| 🟡6 | lo que construye el provider se sondea | **hecho** | spec `MANAGER_BUILDS` (`new RelationsManager` y `buildRelationsManager`), todas las sondas de las filas `manager` corren por las dos vías; caso «el servicio» exige prototipo EXACTO; mutante `provider.wrapped`; caso invertido 🟡6 |
| 🟡7 | sonda F-05 nunca vacía; letra «filas nuevas sin tocar el spec» | **hecho** | spec `f05VariantsOf` (rojo con receta), caso G-M «toda fila con f05 en sonda tiene variantes»; cabecera del manifiesto corregida; caso invertido 🟡7 |
| ⚪8 | `*Many` con ≥ 2 particiones, la mala nunca en `[0]` | **hecho** | `INVOKE.enumerateRelationsMany = [P2, part(v)]`; caso invertido ⚪8 |
| ⚪9 | `exports` por identidad; límite declarado | **hecho** | spec `surfaceByIdentity`; manifiesto («Límite declarado») |
| ⚪10 | letra del caso de `relations_reconcile.spec` | **PENDIENTE** | seguía llamando «residuo declarado» a la tupla y diciendo que `--prune` la barre (CLAUDE.md:387 dice «no las barre nadie») |
| ⚪11 | el doble en la columna `partition` | **hecho** | `doubleOp(…, partition: P)`, `probeDouble` columna `partition`; mutante `double.partition.grammar`; caso invertido ⚪11 |

Pendiente además: la verificación final (ninguna cifra del cierre existía), la repro del auditor sobre el árbol cerrado, los
conteos rancios en `CHANGELOG.md` y `linajes.md` (89/94/112), el comentario del corredor («el spec lee `.claude/contexto`»)
y esta sección.

### Piezas cerradas en esta pasada

- **⚪10** (`tests/relations_reconcile.spec.ts`, «una tupla no declarada que ya estuviera en el destino…»): mismas cuatro
  aserciones (`unchanged 1`, `extra 1`, `deleted 1`, `undeclared 3`, `check(stray) = false`); solo cambia la LETRA. Lo que
  el caso modela es un destino cuyo DRIVER sigue construido con la config vieja (`sourceConfig`, declara `folder`) mientras
  el reconcile corre con `toConfig` —la ventana en que un despliegue rota la config antes que el store—: ahí la tupla sale
  en la enumeración del destino, es `extra` y `--prune` la borra. **NO es** el residuo declarado de CLAUDE.md, que es el
  destino YA bajo la config nueva, cuya lista blanca OCULTA la tupla en `enumerateRelations` (ni `extra` ni `--prune`;
  «no las barre nadie»; `--prune-undeclared`, D7, lote D). El comentario lo dice ahora con esas palabras.
- `scripts/check_guard_mutants.mjs`: el comentario de `COPY` ya no dice que el spec lee `.claude/contexto`; el fichero de
  decisiones se copia SI EXISTE y en CI vale el extracto solo (el código no cambia: `copyTree` ya saltaba lo ausente).
- `CHANGELOG.md` `[Unreleased]`: 93 mutantes / 105 celdas, extracto versionado, matriz de `na`, inventario completo,
  escritura parcial. `linajes.md` L1: idem.
- La repro del auditor (`.claude/reproducciones/lote0-reataque.spec.ts`, caso 🟠2) tenía un `find` del manifiesto que ya no
  casaba tras el cierre (`enumerateRow('manager', 'enumerateRelations', P)` ⇒ sin `P`): corregido para que siga siendo
  ejecutable; nada más de la repro se tocó.

### Repro del auditor sobre el árbol cerrado (copia en el scratchpad, nunca en `tests/`; verde = defecto)

`Tests 1 passed, 6 failed (7)` — **seis de siete ROJOS**, cada uno con los casos de la guardia que lo cazan:

| Caso | Resultado | Casos de la guardia que se pusieron rojos en la copia mutada |
|---|---|---|
| 🟠1 checkout sin `.claude/contexto` | ROJO: `expected [] to deeply equal [ Array(1) ]` — la guardia entera VERDE sin el fichero de decisiones | — (es lo que se quería) |
| 🟠2 `relateMany`/`checkMany` como `platform` todo `na: signature` | ROJO | «G-R · las escrituras del manifiesto son exactamente las que el manager (todo su inventario) escribe o notifica», «el manifiesto es coherente: toda `na` está admitida por NA_MATRIX…», «🟠2 · …» |
| 🟡3 `relateFast` como campo de clase sin fila | ROJO | «RelationsManager: cada método público tiene su fila…», «el servicio: … prototipo exacto, misma superficie…», «G-R · las escrituras del manifiesto son exactamente…» |
| 🟡4 sexta exención `D6-membersOf-double` + F-05 quitado del doble + mutante re-apuntado | ROJO (8 rojos) | G-M «cada mutante nombra celdas…», «el manifiesto es coherente…», G-X «EXACTAMENTE las cinco firmadas…», «la exención de membersOf es SOLO de openfga…», 🟠1, 🟠2, 🟡4, ⚪11 |
| ⚪5 `assertScope(partitions[0])` + mutante re-apuntado | ROJO | «GS · manager.enumerateRelationsMany · partition» |
| 🟡6 subclase in-proceso que escribe por `driver()` | **VERDE por construcción**: el caso no corre la guardia; afirma que una subclase de `RelationsManager` puede llamar a `driver()`, cosa que ninguna guardia puede impedir en proceso. Lo que el auditor señalaba —que «el servicio» solo afirmaba `instanceOf` + identidad— está cerrado por otro lado: el caso exige prototipo EXACTO, las filas `manager` se sondean sobre la instancia del provider, el mutante `provider.wrapped` (el provider devuelve esa subclase) muere con 6 rojos + el caso «el servicio», y el caso invertido 🟡6 demuestra que la sonda F-05 sobre el envoltorio es roja | — |
| 🟡7 `#write` sin `isPartialWrite` + `openfga` sin `markPartialWrite` | ROJO | «GS · manager.{relate,unrelate,purgeObject,purgeSubject} · write», «GS · openfga.{purgeObject,purgeSubject} · write», G-M «cada mutante nombra celdas…» (el `find` de `manager.write.partial` ya no casa) |

Los siete están en la suite como casos invertidos (grupo «GS · cierre del auditor del lote 0 (repros invertidos)»: 🟠1, 🟠2,
🟡3, 🟡4, 🟡5, 🟡6, 🟡7, ⚪8, ⚪11), como funciones PURAS (`manifestViolations`, `exemptionViolations`, `surfaceOperations`,
`f05VariantsOf`) sobre tablas mutadas en memoria, sin copiar el árbol.

**Demostraciones de §(4):**
- 🟠1 · **`.claude/` ausente ⇒ `npm test` verde**: copia del árbol hecha con `git ls-files -co --exclude-standard` sin
  `.claude/` (= `actions/checkout` + lo no commiteado) ⇒ `npm test` **1313 passed (1313)** (sin `OPENFGA_TEST_URL`, como el
  job `test` de CI). **Sexta exención ⇒ rojo**: repro 🟡4 (dinámica, 8 rojos) + caso invertido 🟡4 (G-X nombra «EXACTAMENTE
  cinco» y `D6-membersOf-double`; y una celda del doble con la firma de `openfga` dice «no para 'double'»). Sin extracto ⇒
  rojo (`loadExtract`: «falta el extracto VERSIONADO»).
- 🟠2 · **`relateMany` del auditor sin guardas ⇒ guardia ROJA** (repro 🟠2: 3 rojos, arriba). Matriz: `f05` nunca `na`
  (solo la vista `withClock`, que no recibe tupla); `platform` solo `driver`/`capabilities`; `na: doctrine` solo
  `freeze` × {`database`, `openfga`}; `na: double` solo `trx`/`freeze` del doble; `na: read` solo lecturas del manager;
  `na: signature` en `write` × `openfga` solo `relate`/`unrelate`. G-R invoca TODO el inventario del manager (lo que no
  está en `INVOKE` es rojo) y exige `INVOKE` para todo método de los drivers.

### Mutantes (`npm run check:guard-mutants`)

**93 mutantes / 105 celdas con sonda — 93 muertos en `:memory:` (74 s) y 93 muertos en `sqlite-file` (73 s); 0 vivos, 0
«no casa»**; línea base 147/147 verde en los dos. Los cuatro nuevos del cierre: `manager.write.partial` (quita
`|| isPartialWrite(error)` de `#write` ⇒ 4 celdas `write` del manager + colateral las 2 de `openfga.purge*.write` por la
composición con el manager), `openfga.purge.partial` (quita `markPartialWrite` de `#partialIfDeleted` ⇒ 2), `double.partition.grammar`
(`scopeKeyOf` vuelve a la plantilla sin `assertScope` ⇒ 9 celdas `partition` del doble), `provider.wrapped` (el provider
devuelve una subclase que escribe por `driver()` ⇒ 6 celdas de `manager.relate` sobre esa instancia + colateral «el
servicio»). Colaterales nuevos declarados: los 19 mutantes de `partition` de los drivers quitan `scopeKey`/`assertScope`
(`identity.ts`) y ahora ponen rojas TAMBIÉN las 9 celdas `partition` del doble (⚪11: el doble canoniza por `scopeKey`);
`database/openfga.purgeSubject.f05` (línea compartida del userset) matan además la variante `userset` de
`relate`/`unrelate`/`check`/`listObjects`; `manager.driver.identity` mata «el servicio» y el caso invertido 🟡6.

### Cuatro líneas de cierre (CLAUDE.md punto 5) para 🟠1 y 🟠2

- (a) **Gemelos.** Roles: la guardia de superficie de `AuthorizationManager` sigue sin existir (§6 de arriba; lote R «resto
  de M7»); cuando se haga, hereda estas cuatro piezas —extracto versionado de sus exenciones, matriz cerrada de `na`,
  inventario por `surfaceOperations` (es una función del spec, reutilizable) y G-R por inventario—. `reconcile` ↔
  `relations:reconcile`: no aplica (sin exenciones ni `na`). Comando ↔ manager ↔ función: la clasificación de `exports` ya
  cubre comando y provider (`buildRelationsManager` sondeado).
- (b) **Tabla de verdad.** 🟠1, G-X = f(extracto ∈ {ausente, 5 firmadas, ≠5 o difiere}, decisiones ∈ {ausente, presente
  y coincide, presente y difiere}): ausente×* ⇒ rojo «falta el extracto»; 5×ausente ⇒ verde (CI); 5×coincide ⇒ verde;
  5×difiere ⇒ rojo nombrando id y fragmento; ≠5×* ⇒ rojo «EXACTAMENTE cinco». Las nueve celdas tienen caso (G-X ×3 + 🟠1
  invertido + repro dinámica). 🟠2, celda = f(razón `na`, capa, tipo de fila, columna, operación): la propia `NA_MATRIX`
  es la tabla (11 reglas, 6 columnas × 4 capas × 4 tipos); fuera de ella ⇒ rojo con la celda y, en `f05`, la frase «NUNCA
  admite na». Ninguna fila con fuente «lo que hace hoy»: cada regla cita su doctrina (CLAUDE.md, D6, invariante 13).
- (c) **Casos existentes que el cierre puso rojos.** Ninguno de las suites existentes (⚪10 cambia solo un comentario). La
  guardia pasa de 112 a 147 casos: 6 G-0 + 105 celdas (94 de la primera entrega + 9 `partition` del doble, ⚪11, + 2
  `write` de las purgas de `openfga`, 🟡5) + 20 G-R (6 manager + meta-caso + 6 `database` + 6 `openfga` + «todo método de
  los drivers se invoca») + 4 G-M (+ «coherente con NA_MATRIX», + «variantes F-05») + 3 G-X (reescritos sobre el extracto)
  + 9 casos invertidos del cierre. Títulos que cambiaron (y que `expectRed` sigue nombrando por `cellTitle`): los de G-0
  (inventario) y «el servicio».
- (d) **Linaje.** L1 (F-05), ya estructural desde la primera entrega; el cierre no parchea una iteración más: refuerza el
  punto de paso único (la tabla) para que no se pueda esquivar por `na`, por `platform`, por campo de clase, por el
  provider ni por un fichero fuera de git. No es la 3.ª iteración de ningún otro linaje (L2–L6 no se tocan).

### Cifras (árbol cerrado; secuencia, `docker restart openfga-dev && sleep 8` antes de cada suite, `OPENFGA_TEST_URL=http://localhost:8090`, `TEST_PG_URL` con la contraseña de `postgres18`; `:8101` sigue sin responder)

| Modo | Resultado | Primera entrega | Δ |
|---|---|---|---|
| `npm test` (sqlite `:memory:`) | **1583 passed (1583)** | 1548 | +35 |
| `npm run test:sqlite-file` | **1609 passed (1609)** | 1574 | +35 |
| `npm run test:pg` | **1705 passed (1705)** | 1670 | +35 |
| `npm run test:mysql` | **1707 passed (1707)** | 1672 | +35 |

+35 = 147 − 112 casos de la guardia, idéntico en los cuatro modos. `npx tsc --noEmit` ✔ · `npm run typecheck` ✔ ·
`npm run check:purity` ✔ · `npm run build` ✔. Logs en el scratchpad de la sesión
(`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/logs/`: `suite-*.txt`, `suites-progress.txt`,
`mutantes-{memory,sqlite-file}.{txt,json}`, `repro*.txt`, `ci-npm-test.txt`).

### Preguntas abiertas del auditor

1. Fuente de la firma para CI ⇒ el extracto versionado (`exemptions_d6.json`), cruzado en local byte a byte con el párrafo
   D6 (fragmento literal `d6` + fecha de la sección + conjunto de operaciones nombradas). Decidido por el coordinador §(4).
2. «Freeze en la capa driver» ⇒ `na: doctrine`, y la matriz lo admite SOLO en `freeze` × {`database`, `openfga`}; no es una
   sexta exención. Decidido por el coordinador §(4).

## Cierre-2 (re-ataque del auditor) — `lote0-auditor-cierre.md`, decisiones del coordinador §2026-10-14 (5)

Mismo árbol sin commitear sobre `0fbee6e`, `version` sin tocar. Punto de partida verificado: 1583 / 1609 / 1705 / 1707 y
93/93 mutantes. Repro `.claude/reproducciones/lote0-cierre-reataque.spec.ts` corrida en una COPIA del árbol en el scratchpad:
**4 passed (4)** = los cuatro defectos reproducidos (`logs-repro-cierre.txt`). Método por pieza: rojo observado (árbol mutado
en el scratchpad) → verde → mutante o demo dinámica; los cuatro repros invertidos en la suite (grupo «GS · cierre-2 del auditor
del lote 0 (repros invertidos)»: 🟡A, 🟡B, 🟡C, 🟡D, 🟡E) como funciones PURAS (`probeInvoke` con tabla inyectable,
`serviceViolations`, `surfaceOperations`/`objectOperations`/`assertNotProxy`, `d6Violations` con capa y columna,
`classificationViolations`).

### Piezas

| # | Qué había | Qué hay ahora | Dónde | Demostración |
|---|---|---|---|---|
| 🟡A | `INVOKE[op]` era la única puerta entre la fila y el método y nadie comprobaba que llamara a SU método | **`probeInvoke(op, target, …)`**: toda sonda (celdas de las 4 capas, G-R por fila, G-R meta, G-R de drivers, sondas de exención) corre sobre un **Proxy del objetivo que registra qué propiedades toca** y exige que el conjunto de métodos tocados sea EXACTAMENTE `{op}` (ni otro, ni dos); si no, `ProbeMisroutedError`, que `catching` NO se traga | spec: `probeInvoke`, `ProbeMisroutedError`, `catching`; `INVOKE.driver`/`.capabilities` para que las sondas sustitutas también ejecuten SU operación | `scratchpad/mutA` (árbol con el `probeMany` del auditor: fila `managerRead`, `INVOKE.probeMany → t.check`, variantes, mutantes de `check` extendidos, y clasificado como lectura para aislar la pieza): **5 rojos**, todos con «INVOKE.probeMany tiene que invocar 'probeMany' y solo 'probeMany' … y tocó [check]» (`GS · manager.probeMany · f05/partition`, `G-R · manager.probeMany`, G-R meta, clasificación); el BYPASS sigue verde (es el defecto del manager mutado, no de la guardia). `check_guard_mutants --only manager.check.f05,manager.check.partition` sobre ese árbol, que el auditor vio «2 muertos / 2»: ahora **exit 1 «la guardia NO está verde sin mutar»** (el job `guard-mutants` de CI cae) |
| 🟡B | Se sondeaba `buildRelationsManager`, no lo que sirve el contenedor | **`MANAGER_BUILDS` tiene una tercera vía**: `AuthzProvider.register()` real sobre un `Container` de `@adonisjs/fold` con una `app` mínima (`config.get('authorization')`) y `container.make('authz.relations')` — lo mismo que `services/relations.ts`; las filas `manager` se sondean TAMBIÉN sobre lo servido. «El servicio» resuelve el singleton del contenedor, exige prototipo exacto, no-Proxy, mismo inventario (`serviceViolations`) y que sea singleton | spec: `resolveService`, `serviceViolations`, `serviceConfig`, caso «el servicio» | mutante **`provider.closure.wrapped`** (`providers/authz_provider.ts:97`, el closure del singleton devuelve una subclase que escribe por `driver()`): **muerto** en los dos motores (6 rojos = las seis celdas de `manager.relate` sobre lo que el contenedor sirve, +1 colateral «el servicio»). `provider.wrapped` (el de dentro de `buildRelationsManager`) sigue muerto |
| 🟡C | El inventario solo contaba descriptores de instancia con `value` función; getters de instancia, namespaces y un Proxy del constructor no se veían | **`objectOperations`**: accessors de instancia (`get`/`set`, por nombre, sin evaluar), funciones y objetos PLANOS recursivos (`admin.relate`, `admin.nested.purge`; profundidad 3, con guarda de ciclos); el doble se inventaría con la misma función; **`assertNotProxy`** (`util.types.isProxy`) en G-0 sobre el manager, los dos drivers, sus vistas `withClock`, el doble y su vista, y en `serviceViolations`. **Límite declarado, con caso y escrito en el manifiesto**: un campo público cuyo valor es INSTANCIA DE UNA CLASE (`client`, el SDK de openfga) no se recorre; un namespace así sería una clase nueva (si se exporta la ve G-0·exports por su prototipo; si no, no es superficie publicada); con los drivers publicados no es vector porque `client` es el SDK y `diagnostics`/`capabilities` son objetos planos sin funciones (medido) | spec: `isPlainObject`, `objectOperations`, `surfaceOperations`, `assertNotProxy`; manifiesto: cabecera «Lo que el inventario ve y lo que NO» | `scratchpad/mutC` (getter `relateRaw` + `admin.relate` del auditor): **6 rojos**, el primero G-0 «operaciones SIN fila … para: relateRaw, admin.relate». `scratchpad/mutCproxy` (el constructor devuelve un Proxy que sirve `hidden`): **51 rojos**, el primero «new RelationsManager(…) es un Proxy»; los demás son el propio Proxy rompiendo los campos privados (`#driver`) del manager: con esta base de código un Proxy del constructor ni siquiera funciona |
| 🟡D | El cruce local no cotejaba capa ni columna; la sonda `whitelist` sondeaba la enumeración aunque la exención fuera de `check`; el límite «en CI y worktrees la firma es el diff» no estaba escrito | **`d6Violations(extract, decisions, table)`** coteja además: columna = `f05` (D6 son exenciones «de la guardia L1», F-05); capas = las que la firma nombra («de openfga» ⇒ `['openfga']`) o, si no nombra ninguna, TODAS las capas de la tabla que tienen la operación; y el fragmento nombra la operación. **La sonda de cada exención EJECUTA la operación exenta**: `whitelist` siembra en `P` e invoca `probeInvoke(op)` (database, manager y doble), `unsupported`/`identity`/`frozen-copy` van por `probeInvoke(op)`, y `assertWhitelistOp` hace rojo un `whitelist` sobre algo que no sea `enumerateRelations(Many)`. **El límite está ESCRITO** en CLAUDE.md punto 6 y en la cabecera del extracto (que pasa de array a `{ cabecera, signedAt, exemptions }`), y un caso lo lee («el LÍMITE está escrito»); fuera de CI, sin fichero de decisiones, G-X avisa por `console.warn` | spec: `d6Violations`, `probeWhitelistSql(…, op)`, `assertWhitelistOp`, `loadExtractFile`; `tests/fixtures/exemptions_d6.json`; CLAUDE.md punto 6; el corredor y la repro copian `CLAUDE.md` al árbol temporal | `scratchpad/mutD` (la sexta exención del auditor: extracto + manifiesto + `FIVE_SIGNED` + `lengthOf(6)` + mutante re-apuntado, **sin fichero de decisiones**): **2 rojos**, `GS · double.check · f05` («'check' no es una enumeración y una exención sobre ella no tiene sonda que la justifique») + el caso invertido 🟡D. Caso invertido: ensanchar `layers` de `enumerateRelationsMany` con `double` ⇒ rojo «capas [manager, database, openfga]»; `membersOf` con `['openfga','double']` ⇒ rojo «la firma nombra la capa»; `column: 'trx'` en `driver()` ⇒ rojo «la columna es 'f05'» |
| 🟡E | `WRITES` era una lista fija del spec; `deny` del lote D entraría como lectura | **`PORT_WRITES`/`PORT_READS` en el manifiesto (clasificación OBLIGATORIA)**; `PORT_OPERATIONS` se DERIVA de las dos y `WRITES` del spec de `PORT_WRITES`. Caso «G-R · clasificación obligatoria»: todo el inventario por reflexión de las 4 capas (menos plataforma/vista/estáticos/símbolos, que juzga G-0) está en una de las dos listas o rojo con su nombre; las listas son disjuntas; el `kind` de cada fila coincide; y la clasificación se cruza con el COMPORTAMIENTO: `database` ejecuta INSERT/UPDATE/DELETE exactamente en `PORT_WRITES` (`countQueries`), `openfga` llama a `write`/`deleteTuples` exactamente en ellas (cliente falso con una tupla sembrada de otro documento, para que las purgas borren y `relate` no sea no-op) | manifiesto: `PORT_WRITES`, `PORT_READS`, `PORT_OPERATIONS`; spec: `classificationViolations`, caso G-R | `scratchpad/mutE` (`deny` de prueba en el manager, sin clasificar, sin fila, sin INVOKE): **6 rojos** — G-0 «SIN fila … para: deny», «no hay forma de invocar manager.deny», y la clasificación: «manager.deny: operación SIN CLASIFICAR — añádela a PORT_WRITES o a PORT_READS de tests/fixtures/guard_manifest.ts (G-R deriva de ahí qué es escritura: sin clasificación una escritura nueva pasaría por lectura, sin freeze, sin puerta trx y sin actor)». Quitado. Caso invertido: `deny` en el inventario ⇒ exactamente `manager.deny`/`database.deny`; `check` en las dos listas ⇒ rojo; fila `relate` con `kind: 'read'` ⇒ rojo |

### Repro del auditor sobre el árbol cerrado (copia en el scratchpad, `repro-cierre2-closed.txt`; verde = defecto)

**`Tests 4 failed (4)`** — los cuatro ROJOS: 🟡A (`GS · manager.probeMany · f05/partition`, `G-R · manager.probeMany`, G-R meta y clasificación rojos; el repro esperaba verlos verdes), 🟡B (8 rojos con el envoltorio en el closure: las seis celdas de `manager.relate` sobre el contenedor + «el servicio» + G-M porque el `find` de `provider.closure.wrapped` ya no casa), 🟡C (6 rojos), 🟡D (en CI 2 rojos; en local 3: además el cruce D6). Dos ajustes a la repro para que siga siendo ejecutable, nada más: el `json` del extracto trabaja sobre `{ cabecera, exemptions }` y `TREE` copia `CLAUDE.md` (sin él la guardia sería roja por el caso del límite y no por la regresión); lo dice su cabecera.

### Mutantes

**94 mutantes / 105 celdas con sonda — 94 muertos en `:memory:` (77 s) y 94 muertos en `sqlite-file` (77 s); 0 vivos, 0 «no casa»**;
línea base **154/154** verde en los dos (`logs/mutantes2-{memory,sqlite-file}.{txt,json}`). El nuevo: `provider.closure.wrapped`.
El corredor copia ahora también `CLAUDE.md` (sin él, el caso del límite dejaba la línea base roja: medido en la primera corrida).

### Cuatro líneas de cierre (CLAUDE.md punto 5) para 🟡A–🟡E

- (a) **Gemelos.** Roles: la guardia de `AuthorizationManager` sigue siendo del lote R («resto de M7»); cuando nazca hereda las
  cinco piezas tal cual —`probeInvoke` (ya es una función del spec con tabla inyectable), lo que sirve el contenedor como
  `authz.manager` por el MISMO `AuthzProvider.register`, `objectOperations`/`assertNotProxy`, el cruce de firma por capa y
  columna y una clasificación obligatoria de su puerto—. `reconcile` ↔ `relations:reconcile`: no aplica (sin sondas ni
  exenciones). Comando ↔ manager ↔ función: 🟡B cierra justo esa cadena para relaciones (provider → contenedor → servicio).
- (b) **Tabla de verdad.** 🟡A: `probeInvoke` = f(métodos tocados): `{op}` ⇒ pasa; `∅` ⇒ rojo «ningún método»; `{otro}` ⇒ rojo
  nombrando el otro; `{op, otro}` ⇒ rojo nombrando los dos (las cuatro filas en el caso invertido). 🟡D: `d6Violations` =
  f(fragmento nombra capa ∈ {sí, no}, capas del extracto ∈ {= esperadas, ≠}, columna ∈ {f05, otra}): 2×2×2, las seis filas
  rojas tienen caso (ensanchar, nombrada+otra, columna) y las dos verdes son el extracto real con y sin fichero. 🟡E:
  `classificationViolations` = f(op ∈ PORT_WRITES, op ∈ PORT_READS, kind de la fila): (no, no) ⇒ rojo «SIN CLASIFICAR»;
  (sí, sí) ⇒ rojo «en las dos»; (sí, no)+`read` o (no, sí)+`write` ⇒ rojo «la fila es … y el puerto dice …»; y el eje
  comportamiento (escribe ∈ {sí, no} × clasificada ∈ {write, read}) con sus dos diagonales rojas en el caso G-R. Ninguna fila
  con fuente «lo que hace hoy»: `PORT_WRITES` cita el puerto (`RelationsDriver`) y la matriz `NA_MATRIX` no cambia.
- (c) **Casos existentes que el cierre-2 puso rojos.** Ninguno de las suites existentes. La guardia pasa de 147 a **154**
  (+1 «el LÍMITE está escrito», +1 «G-R · clasificación obligatoria», +5 invertidos 🟡A–🟡E). Títulos que cambiaron (ningún
  `expectRed` los nombra): los cuatro de G-0 (inventario) y «el servicio». Colaterales nuevos en el corredor: ninguno (los 93
  anteriores conservan los suyos; `provider.closure.wrapped` tiene el mismo colateral que `provider.wrapped`).
- (d) **Linaje.** L1, estructural desde la primera entrega; el cierre-2 no parchea una iteración más: cierra las cinco vías de
  esquivar la tabla POR LA PROPIA GUARDIA (sonda, contenedor, reflexión, firma, clasificación). No es la 3.ª iteración de
  ningún otro linaje. `linajes.md` L1 actualizado.

### Cifras (árbol cerrado-2; secuencia, `docker restart openfga-dev && sleep 8` antes de cada suite, `OPENFGA_TEST_URL=http://localhost:8090`, `TEST_PG_URL` con la contraseña de `postgres18`; `:8101` sigue sin responder)

| Modo | Resultado | Cierre-1 | Δ |
|---|---|---|---|
| `npm test` (sqlite `:memory:`) | **1590 passed (1590)** | 1583 | +7 |
| `npm run test:sqlite-file` | **1616 passed (1616)** | 1609 | +7 |
| `npm run test:pg` (`authz_test_c1b48c9e`, destruida) | **1712 passed (1712)** | 1705 | +7 |
| `npm run test:mysql` (`authz_test_a031a703`, destruida) | **1714 passed (1714)** | 1707 | +7 |

+7 = 154 − 147 casos de la guardia, idéntico en los cuatro modos. `npx tsc --noEmit` ✔ · `npm run typecheck` ✔ ·
`npm run check:purity` ✔ · `npm run build` ✔. Logs: `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/logs/`
(`suite2-*.txt`, `suites2-progress.txt`, `mutantes2-{memory,sqlite-file}.{txt,json}`, `static2-*`), demos en `scratchpad/demos/demos.log`
(árboles `mutA`, `mutC`, `mutCproxy`, `mutD`, `mutE`), repro en `scratchpad/repro-cierre2-closed.txt`.
