# Fase 3b · Lote 3b-2d — outbox del árbol y gate de construcción

> Base: `cb2bc82` (3b-2c cerrado, 5 suites verdes, 601/603/769/769). Encargo:
> `.claude/contexto/fase-3b-lote-2-plan.md` §3b-2d. **NO entra 2e** (capacidades, límites,
> `purgeRole` soportado, borrado del modo `resolver`).
>
> El problema que se mitiga está medido, no supuesto: `panel2-2026-08-28-juez.md` cruce 4
> (S5) y `panel2-2026-08-28-seguridad.md` §S5. El paquete escribe el árbol en FGA dentro de
> la transacción del consumidor y un `rollback` posterior **no** la deshace: SQL dice un
> padre y FGA otro, FGA es el PDP en `facts`, y la aplicación —que lista y audita contra
> SQL— no puede ver la escalada. **No es mal uso: el uso correcto fuga.**

Método: rojo→verde por pieza, con la salida ROJA pegada y la comprobación de que falla
**por la razón correcta**. Sin `skip` en ninguna parte.

---

## Pieza 1 · El gate de construcción del driver `facts`

**El caso.** `tests/scope_outbox.spec.ts`, grupo «3b-2d · el gate de construcción del driver
`facts`»: cinco casos, uno por rama —sin outbox y sin bandera ⇒ lanza; con outbox ⇒
construye; sin outbox pero con la bandera ⇒ construye; un valor «truthy» que no es `true`
⇒ lanza; modo `resolver` (el default) ⇒ el gate no aplica.

**Rojo** (`node --import @poppinss/ts-exec bin/test.ts --files scope_outbox.spec.ts`):

```
❯ 3b-2d · el gate de construcción del driver `facts` / sin outbox y sin `acceptScopeDriftRisk`
  el driver `facts` NO se construye: 500 E_AUTHZ_SCOPE_DRIFT_UNGUARDED

ℹ AssertionError: facts a pelo: debería haber lanzado: expected null to not equal null
 ⁃ at rejects (tests/scope_outbox.spec.ts:54:10)
 ⁃ at async Object.executor (tests/scope_outbox.spec.ts:64:19)

❯ 3b-2d · el gate de construcción del driver `facts` / `acceptScopeDriftRisk` tiene que ser
  el booleano `true` literal: nada de valores «truthy»

ℹ AssertionError: una cadena no es una aceptación: debería haber lanzado: expected null to not equal null

Tests  3 passed, 2 failed (5)
```

Falla por la razón correcta: **el driver `facts` se construye tan campante sin ninguna
garantía sobre el árbol** (`caught` es `null`, no un error de otro código). Los tres casos
que ya pasaban en rojo son los que deben pasar también en verde (construir con outbox, con
la bandera y en modo `resolver`): están para que el gate no se implemente como «`facts`
siempre lanza».

**El código que lo puso verde.**

- `src/errors.ts` — `ScopeDriftUnguardedError`, **500** / `E_AUTHZ_SCOPE_DRIFT_UNGUARDED`.
  500 y al CONSTRUIR, no al escribir: descubrir esto en la primera escritura de un tenant es
  tarde, y un puerto opcional que nadie declara no mitiga nada.
- `src/drivers/openfga_driver.ts` — `OpenFgaDriverOptions.outbox?` y
  `.acceptScopeDriftRisk?`, y la función exportada `assertScopeDriftGuarded(hierarchy,
  options)`, llamada desde el constructor justo después de fijar `this.hierarchy`.
- `index.ts` — exporta el error nuevo (lo exigió el guard de `tests/purity.spec.ts`
  «index.ts exporta TODOS los errores de src/errors.ts», que se puso rojo solo).

**Decisiones donde el plan era ambiguo.**

1. **`acceptScopeDriftRisk` exige el booleano `true` literal**, no un valor «truthy». Es una
   firma, y `acceptScopeDriftRisk: process.env.ACCEPT` (una cadena vacía o no) no es una
   firma. Mismo criterio que el `requireWithin: true | 'non-root'` del config.
2. **El driver recibe la outbox pero no la usa.** Quien encola es el manager (es suyo
   `scopes.*`). En el driver la outbox es solo la EVIDENCIA del gate — igual que
   `resolveChain`, que el consumidor pasa a los dos sitios. Está documentado en el
   docblock de la opción, y el agujero que deja (declararla en el driver y no en el
   config) queda anotado en «lo que NO hice».
3. **Los tests de `facts` que ya existían firman la bandera.** `tests/openfga_facts.spec.ts`
   construye el driver a pelo, sin manager ni transacción del consumidor: ahí el gate no
   tiene nada que proteger. Cuatro construcciones tocadas (`treeDriver`, `factsDriver` y
   dos inline contra el `:8101`), con el comentario que dice por qué. **41 casos existentes
   se pusieron rojos con el gate**: no es una rotura, es el gate haciendo su trabajo sobre
   montajes que efectivamente no tenían outbox.

Verde: **606** casos en `npm test` (601 de partida + 5).

---

## Pieza 2 · El puerto `scopes.outbox` en el manager

**El caso.** Grupo «3b-2d · con outbox, `manager.scopes.*` encola en vez de escribir»: seis
casos. Que `attached`/`moved`/`detached` encolen y **no toquen el driver**; que lo encolado
lleve la identidad CANÓNICA (invariante 17) y no el alias del llamante; que `detached` no
purgue ni audite todavía; que la transacción y el actor viajen en el contexto; que **sin**
outbox nada cambie; y que las validaciones (ciclo, padre fantasma, `within`, raíz) sigan
yendo PRIMERO, sin dejar intención encolada.

**Rojo:**

```
❯ … / `attached` encola el cambio y NO toca el driver
+   "attached unit:01a05360-d664-734b-a0bb-ba00fee18ea5 → organization:01a05360-…"
ℹ AssertionError: el driver no se toca: la arista la aplicará el relay: expected [ Array(1) ] to deeply equal []

❯ … / `moved` encola, y con la identidad CANÓNICA del árbol (invariante 17)
+   "moved unit:01a05360d6657619a353f8e453eeea9a → organization:01a05360d6657619a353f6e6d321ca24"
ℹ AssertionError: expected [ Array(1) ] to deeply equal []

❯ … / `detached` encola: NO purga, NO borra la arista y NO audita todavía
+   "purgeScope unit:01a05360-d666-758b-b0a9-0d56df21a7cd",
+   "detached unit:01a05360-d666-758b-b0a9-0d56df21a7cd",
ℹ AssertionError: la purga la hace el relay, no la transacción del tenant: expected [ …(2) ] to deeply equal []

Tests  7 passed, 4 failed (11)
```

Falla por la razón correcta: **la outbox declarada se ignora por completo** y el manager
escribe en el driver dentro de la transacción del consumidor, exactamente el montaje que
fuga. Nótese el segundo caso: el driver recibe el ALIAS sin guiones
(`unit:01a05360d665…`), que es lo que se encolaría si no se canonizara al encolar — una
rama nueva en el store días más tarde.

**El código que lo puso verde.**

- `src/types.ts` — `ScopeTreeChange`, `PendingScopeTreeChange`, `ScopeOutboxContext`, el
  puerto **`ScopeOutbox`** (`enqueue`/`pending`/`markApplied`/`markFailed`) y
  `ScopeTreeWriteOptions` (`ScopedWriteOptions` + `transaction?: unknown`).
- `src/define_config.ts` — `scopes.outbox?: ScopeOutbox`, con el docblock que dice lo que
  arregla y lo que NO arregla.
- `src/manager.ts` — `#outbox()`; las tres notificaciones encolan y `return` antes del
  driver; `#assertEdge` pasa a devolver `{ chain, child }` con el **hijo canónico** (dos
  call-sites, `attached` y `moved`); `detached` resuelve la cadena en fresco ANTES de
  encolar, con la fila del consumidor todavía viva.

**Decisiones donde el plan era ambiguo.**

1. **Con outbox el manager NO toca el driver.** Es la única lectura que mitiga: si además
   escribiera, el rollback seguiría dejando la escalada. La consecuencia es que `detached`
   deja de purgar y de auditar en el acto — se hacen al relevar—, y está en el test y en el
   docblock.
2. **La outbox es del MANAGER, no del driver, y vale para todos los drivers.** `scopes.*`
   es API del manager y ahí es donde hay que interceptar. Además la escritura del driver
   `database` tampoco va en la transacción del consumidor (usa su propia conexión), así que
   la mitigación también le sirve. Es aditivo: sin `scopes.outbox` declarada, cero cambios.
3. **La transacción viaja por `ScopeTreeWriteOptions.transaction`, tipada `unknown`.** El
   paquete no conoce la BD del consumidor ni puede: la pasea hasta su `enqueue`. Se añadió
   una interfaz NUEVA en vez de tocar `ScopedWriteOptions` para no meter una opción de
   transacción en `grant`/`deny`/la delegación, donde hoy no significa nada.
4. **La identidad se canoniza AL ENCOLAR.** Al relevar, un `detached` ya no resolvería (la
   fila del consumidor se borró) y un alias abriría una segunda rama. Por eso `#assertEdge`
   devuelve ahora el hijo canónico y `detached` resuelve en fresco antes de encolar.

Verde: **612** (+6).

---

## Pieza 3 · `sqlScopeOutbox` y el stub de migración

**El caso.** Grupo «3b-2d · sqlScopeOutbox — el puerto sobre Lucid»: siete casos. Ida y
vuelta de los tres `op` con la identidad intacta y en ORDEN de encolado; `markApplied` lo
saca de pendientes y `markFailed` lo deja con el intento y la causa; `pending(limit)` acota;
**encolar dentro de una transacción que hace `rollback` no deja nada** y con `commit` sí;
el actor se guarda y sin él la fila no inventa autor; una identidad mal formada es 422
antes del INSERT. Más el grupo del espejo stub↔harness.

**Rojo:**

```
ℹ Error: Cannot find module '/home/jose/proyectos/Personal/adonis-authz/src/scope_outbox.js'
  imported from /home/jose/proyectos/Personal/adonis-authz/tests/scope_outbox.spec.ts
```

Rojo honesto pero pobre —«la pieza no existe»—; el rojo con contenido de esta pieza es el
de la 5 (el mutante), donde se ve que sin el `transaction` la escalada vuelve.

Segundo rojo, ya con la implementación puesta, del espejo stub↔harness:

```
❯ 3b-2d · el stub de la outbox y la tabla con la que se prueba coinciden / la migración
  publicada declara `authz_scope_outbox` con las columnas que lee `sqlScopeOutbox`
ℹ AssertionError: expected [] to deeply equal [ 'authz_scope_outbox' ]
```

Causa real, no cosmética: el stub usaba `createTable(this.tableName, …)`, así que el nombre
de la tabla no era legible desde el texto de la migración —el mismo parser que vigila
`stubs/migration.stub`—. Se cambió el stub al literal, como el publicado.

**El código que lo puso verde.**

- `src/scope_outbox.ts` — `sqlScopeOutbox({ table?, connection?, timeoutMs?, now? }, db?)`.
  `enqueue` escribe por `context.transaction` cuando llega (y comprueba que parezca un
  cliente de Lucid: 500 `E_AUTHZ_CONFIG` si no, en vez de escribir fuera de la transacción
  sin decir nada). `pending` lee `applied_at IS NULL` en orden de `id`. Las filas aplicadas
  se MARCAN, no se borran. Todo bajo `guardSql` (503 con deadline, como el resto).
- `stubs/scopes_outbox_migration.stub` — la migración de `authz_scope_outbox`, con las
  decisiones de motor de 2.5 · J3 (identidad `varchar(64)` `utf8mb4_bin`).
- `tests/helpers/schema.ts` + `bin/test.ts` — la tabla en el harness (`createScopeOutboxTable`,
  `cleanScopeOutbox`), espejo vigilado por el test del stub.
- `index.ts` — exporta `sqlScopeOutbox` y `SqlScopeOutboxOptions`.

**Decisiones donde el plan era ambiguo.**

1. **Se publica una implementación, no solo el puerto.** El plan pedía «el puerto y un stub
   de migración». Un stub de migración sin nada que lea esas columnas es un stub que nadie
   puede comprobar, y sobre todo: **la demostración del rollback exige una outbox SQL de
   verdad** (hay que encolar dentro de una transacción y hacerla caer). `sqlScopeOutbox` es
   lo que hace demostrable la pieza. El contrato sigue siendo el puerto, y está escrito así
   en los tres sitios (README, `define_config`, el propio stub).
2. **`configure` NO publica el stub.** La outbox es opt-in; publicar una tabla que la
   mayoría no usará es imponer la tabla que el plan dice explícitamente no imponer. El
   README dice que se copia a mano y dónde está.
3. **Las filas aplicadas se marcan, no se borran.** La cola es también el registro de qué
   se propagó y cuándo, que es lo que hace no-silencioso al relay. La purga es del
   consumidor.
4. **El reloj es el inyectable del paquete.** El primer intento usaba `new Date()` y lo cazó
   `tests/clock.spec.ts` (grep sobre `src/`); se pasó a `systemClock` con `now?` en las
   opciones, como todo lo demás (2.5 · J1).

Verde: **620** (+8).

---

## Pieza 4 · `relayScopeChanges` y el comando `authz:scopes:relay`

**El caso.** Grupo «3b-2d · `authz:scopes:relay` — drenar la outbox contra el driver»: siete
casos. Aplicar en ORDEN los tres `op` (y en `detached`, hechos primero y arista al final);
auditar `scope_purged` **con el actor** al relevar; **reanudable** (falla el `moved`, se
marca, se para, el `detached` NO se adelanta, y la siguiente pasada retoma); `dryRun`;
500 `E_AUTHZ_CONFIG` sin outbox; 500 si la outbox no marca lo aplicado (nada de bucles);
`limit` que corta. Más dos casos del comando (registrado en `commands/main.ts`, con nombre,
descripción, `startApp` y las tres banderas).

**Rojo:**

```
❯ … / aplica en ORDEN y marca lo aplicado …           ℹ TypeError: manager.relayScopeChanges is not a function
❯ … / el `detached` que releva SÍ audita `scope_purged` … ℹ TypeError: manager.relayScopeChanges is not a function
❯ … / REANUDABLE: si una falla, se marca, se PARA …    ℹ TypeError: manager.relayScopeChanges is not a function
❯ … / `dryRun`: dice lo que aplicaría …                ℹ TypeError: manager.relayScopeChanges is not a function
❯ … / sin `scopes.outbox` declarada, relevar es 500 …  ℹ AssertionError: expected undefined to equal 500
❯ … / una outbox que no marca lo aplicado NO deja al relay dando vueltas: 500 …
                                                       ℹ AssertionError: expected undefined to equal 500
❯ … / `limit` corta la pasada …                        ℹ TypeError: manager.relayScopeChanges is not a function
Tests  19 passed, 7 failed (26)
```

Falla por la razón correcta: **no hay quien drene**, así que con outbox declarada los
cambios se quedan en la cola para siempre (que es peor que no tener outbox: fail-**closed**
permanente en vez de fail-open temporal).

**El código que lo puso verde.**

- `src/types.ts` — `RelayedScopeChange` y `ScopeRelayReport`
  (`applied` / `failed` / `remaining` / `dryRun` / `wouldApply`), y `actor?` en
  `PendingScopeTreeChange`.
- `src/manager.ts` — `relayScopeChanges({ limit?, batchSize?, dryRun? })`,
  `#applyScopeChange` y `#positive`; constantes `DEFAULT_RELAY_BATCH` (100) y
  `DEFAULT_RELAY_LIMIT` (10 000).
- `src/scope_outbox.ts` — `pending` devuelve también el `actor` de la fila.
- `commands/authz_scopes_relay.ts` + `commands/main.ts`.

**Decisiones donde el plan era ambiguo.**

1. **Para en el primer fallo, no salta al siguiente.** El orden del árbol importa: aplicar
   el `detached` de un nodo cuyo `moved` no ha entrado deja el store con un árbol que nunca
   existió. Se marca `markFailed`, se reporta y se sale con código ≠ 0; la siguiente pasada
   retoma exactamente ahí. Está medido en el caso «REANUDABLE».
2. **El reporte dice QUÉ, no cuánto.** Mismo criterio que `pruneOrphanRoles` (`purged:
   CatalogRoleRef[]`, no un contador): la pasada no es atómica y un número no permite
   retomar nada.
3. **Es API de PLATAFORMA, junto a `driver()`.** Se salta `requireActor`/`requireWithin` a
   propósito: la policy ya se juzgó al ENCOLAR, con el árbol y la sesión de aquel momento.
   Documentado como «no se expone por HTTP», igual que `prune-orphans`.
4. **Cota contra la outbox rota.** Una implementación que no marque lo aplicado devolvería
   el mismo pendiente para siempre. El relay lleva un `Set` de ids vistos y denuncia con
   500 `E_AUTHZ_CONFIG` en cuanto uno se repite, en vez de dar vueltas o «arreglarlo» solo.
5. **`--dry-run` no es el default** (a diferencia de `prune-orphans`): `prune-orphans`
   BORRA y por eso pide confirmación humana; el relay PROPAGA lo que el consumidor ya
   confirmó, y su default útil es drenar. `--dry-run` está para mirar la cola.
6. **El `scope_purged` diferido conserva el actor.** Por eso el puerto puede devolver
   `actor` en `pending` y `sqlScopeOutbox` lo guarda: la auditoría no debe perder al autor
   por haber pasado por una cola.
7. **Del comando se testea lo que se puede sin app Adonis**: que esté exportado (sin eso
   `node ace configure` no lo registra y el comando no existe), su nombre, `startApp` y las
   tres banderas. El `run()` resuelve el manager con un import dinámico de
   `../services/main.js`, que sin app no arranca; un primer intento de ejercitarlo con un
   `Proxy` no probaba nada y se retiró en vez de dejar un test decorativo.

Verde: **632** (+12, con los dos del comando).

---

## Pieza 5 · **La demostración**: el rollback, contra el servidor real

Esta es la pieza que el encargo dice que decide si el lote vale. Grupo «3b-2d · el rollback
del consumidor, contra el servidor real», con el `:8101`, el modelo (c2) publicado, el
catálogo sincronizado con su proyección y el árbol del consumidor en la tabla SQL
`demo_scopes` (`sqlScopeTree`, PG/MySQL/SQLite). Todo por el camino del paquete.

Montaje: `orgA`, `orgB`, `unit` bajo `orgA`; un holder con `org-editor` (que da `docs:read`)
en `orgB` y en ningún otro sitio. De partida, `authorize(holderB, 'docs:read', unit)` es
`false`.

**Caso 1 — SIN outbox.** Dentro de `db.transaction`: `scopes.moved(unit, orgB)` (el paquete
escribe la arista en FGA), el consumidor recuelga su fila, y algo posterior falla ⇒
`rollback`.

- `demo_scopes` vuelve a decir que la unit es de `orgA` — la base del consumidor está intacta.
- `manager.authorize(holderB, 'docs:read', unit)` ⇒ **`true`**.

Esa es la escalada, y es persistente e invisible: ninguna consulta a la base del consumidor
puede enseñarla. **Este montaje es exactamente el que el gate de la pieza 1 rechaza**, y en
el test se firma `acceptScopeDriftRisk: true` a propósito para poder enseñar lo que pasa.

**Caso 2 — CON outbox.** El mismo guion, con `{ transaction: trx }`. Tras el rollback: la
cola está vacía, `relayScopeChanges()` no aplica nada, y `authorize` sigue siendo `false`.

**Caso 3 — CON outbox y COMMIT.** SQL dice ya `orgB`; **antes del relay `authorize` sigue
respondiendo con el árbol viejo** (aserción explícita: esa es la forma exacta del riesgo 🟠
aceptado); tras `relayScopeChanges()` —que reporta `['moved']`— las dos versiones del árbol
coinciden.

**Rojo.** Los tres casos se escribieron sobre piezas ya verdes, así que el rojo honesto aquí
es el **mutante**: se anuló la rama de la outbox en `scopes.moved`
(`if (outbox && false)`) y se volvió a correr.

```
❯ 3b-2d · con outbox … / `moved` encola, y con la identidad CANÓNICA …
ℹ AssertionError: expected [ Array(1) ] to deeply equal []
❯ 3b-2d · `authz:scopes:relay` … / aplica en ORDEN y marca lo aplicado …
ℹ AssertionError: nada ha llegado al driver todavía: expected [ Array(1) ] to deeply equal []
❯ 3b-2d · `authz:scopes:relay` … / REANUDABLE …
ℹ AssertionError: expected [ 'attached', 'detached' ] to deeply equal [ 'attached' ]
❯ 3b-2d · el rollback del consumidor, contra el servidor real / CON outbox: el mismo guion …
ℹ AssertionError: SIN ESCALADA: el árbol de FGA sigue siendo el que la base del consumidor
  confirma: expected true to be false
❯ 3b-2d · el rollback del consumidor, contra el servidor real / CON outbox y COMMIT …
ℹ AssertionError: durante el lag del relay FGA todavía responde con el árbol viejo:
  expected true to be false
Tests  26 passed, 5 failed (31)
```

Es el rojo que importa: **quitada la outbox del camino, la escalada del caso 1 reaparece en
el caso 2** («expected true to be false» sobre el aserto «SIN ESCALADA»). El mutante se
revirtió y las 31 volvieron a verde.

**Un tropiezo del harness, no del código.** Los tres casos daban `Test timeout` al principio.
Causa: la suite por defecto corre SQLite en memoria con **pool 1/1**
(`tests/helpers/app.ts:188`), y una lectura del árbol por fuera mientras la transacción tiene
la única conexión se espera para siempre. Se resolvió haciendo que el `resolveChain` del test
lea por el cliente ACTIVO (la trx mientras dura). **No cambia la semántica**: el consumidor
notifica ANTES de recolgar su fila, así que dentro de la transacción el árbol dice todavía lo
mismo que dirá el commit. Queda anotado porque es una trampa que volverá a morder a quien
escriba tests con transacciones en esta suite.

**Sin stores huérfanos**: `group.each.teardown` borra cada store; comprobado contra el
`:8101` tras las cuatro suites — **0 stores creados hoy**.

Verde: **632**.

---

## Pieza 6 · README (y `CLAUDE.md`)

`README.md`, sección nueva **«The tree outbox, and the temporary fail-open you are
accepting»** dentro de *The scope tree*, más el gate en *Driver options*, la fila
`E_AUTHZ_SCOPE_DRIFT_UNGUARDED` en la tabla de errores y `authz:scopes:relay` en la lista de
comandos.

Lo que pidió el dueño, literal:

> Between your commit and the relay pass there is a lag of **seconds during which FGA decides
> with the old tree**. That is a **temporary fail-open**: after a `moved`, the **old tenant
> keeps access** to the moved subtree; after an `attached`, **inherited denies do not apply**
> to the new node. There is no two-phase commit […] This is the structural price of keeping
> the tree in two places, it is an accepted 🟠 risk of `hierarchy: 'facts'` […]

Y el diagnóstico entero, sin suavizar: *«what is left is a persistent escalation your own
database cannot show you […] This is not misuse; correct use leaks.»*

**Hay un test que lo sujeta.** `3b-2d · el README dice el riesgo con SUS palabras` comprueba
las cinco frases. El documento que este paquete sustituye vendía esto como «cambios del
árbol fuera del servicio» —es decir, mal uso—, y sin un test la frase se suaviza en la
siguiente pasada de estilo.

`CLAUDE.md`: bullet nuevo en las reglas de higiene (el mecanismo completo, el gate, el riesgo
🟠 y la prohibición del `--fix` de `verify`, S18), fila de `src/scope_outbox.ts` en el mapa y
`authz:scopes:relay` en la fila de `commands/`.

Verde: **633** (+1).

---

## Cifras finales

| Suite | Partida | Ahora | Δ |
|---|---|---|---|
| `npm test` (SQLite en memoria) | 601 | **633** | +32 |
| `npm run test:sqlite-file` | 603 | **635** | +32 |
| `npm run test:pg` | 769 | **801** | +32 |
| `npm run test:mysql` | 769 | **801** | +32 |

Las cuatro en verde, con `OPENFGA_TEST_URL=http://localhost:8101`. **+32 en las cuatro**: no
hay ningún caso que dependa del motor. Ningún caso existente se puso rojo por una regresión
(los 41 de `openfga_facts.spec.ts` que el gate tumbó son montajes sin outbox, y firman la
bandera; ver pieza 1).

```
npx tsc --noEmit -p tsconfig.json     ✔
npm run typecheck                     ✔  (tsconfig.test.json)
npm run check:purity                  ✔
```

Sin un solo `skip`. Todos los errores nuevos llevan `status` + `code`
(`E_AUTHZ_SCOPE_DRIFT_UNGUARDED` 500; el resto reutiliza `E_AUTHZ_CONFIG` 500 y
`E_AUTHZ_INVALID_IDENTITY` 422). Comentarios y mensajes en español, API en inglés.

## Ficheros

Nuevos: `src/scope_outbox.ts`, `commands/authz_scopes_relay.ts`,
`stubs/scopes_outbox_migration.stub`, `tests/scope_outbox.spec.ts`.
Tocados: `src/types.ts`, `src/manager.ts`, `src/define_config.ts`, `src/errors.ts`,
`src/drivers/openfga_driver.ts`, `index.ts`, `commands/main.ts`, `bin/test.ts`,
`tests/helpers/schema.ts`, `tests/openfga_facts.spec.ts`, `README.md`, `CLAUDE.md`.

---

## Lo que NO hice, y por qué

1. **Nada de 3b-2e.** No hay capacidades (`singleCheckAuthorize`, `roleInheritanceNative`,
   `listObjectsInherited`), no se ha tocado `purgeRole: false` ni el 500 de
   `defineScopedRole` en `openfga`, y el camino `resolver` sigue entero y es el default.
   Estaba excluido por escrito.
2. **`authz:scopes:verify` no existe** (es 3b-3). Y cuando exista: **read-only por
   contrato**, sin `--fix` — un `--fix` sería un mecanismo de concesión (hallazgo S18 del
   auditor, aceptado por el juez como restricción preventiva). Escrito en `CLAUDE.md` para
   que el lote que lo implemente se lo encuentre.
3. **`configure` no publica el stub de la outbox.** Es opt-in y el plan dice explícitamente
   que el paquete no impone tabla. Se copia a mano; el README dice dónde está. El
   `copy:stubs` del build sí lo empaqueta (`cp stubs/*.stub`).
4. **No hay reintento con backoff ni bloqueo entre relays concurrentes.** Dos
   `authz:scopes:relay` a la vez sobre la misma cola pueden intentar el mismo cambio (el
   `pending` de `sqlScopeOutbox` no bloquea filas). Las escrituras del árbol del driver
   `facts` son convergentes —`reparent` lee y sustituye la arista entera, `detached` es
   idempotente—, así que el daño esperable es trabajo repetido y un `markFailed` espurio, no
   un árbol malo; pero **no está medido** y no lo declaro seguro. Lo honesto hoy: **un solo
   relay**. Un `SELECT … FOR UPDATE SKIP LOCKED` en `pending` es la salida natural y es del
   consumidor (o de un lote posterior), porque el puerto no la impone.
5. **El gate no puede cazar una outbox declarada en el driver pero no en el config.** El
   driver comprueba SU opción `outbox`; quien encola es el manager, que lee
   `config.scopes.outbox`. Pasar la instancia solo al driver deja el gate contento y la
   mitigación apagada. Es el mismo patrón que ya tiene `resolveChain` (va a los dos sitios) y
   está documentado en el docblock de la opción y en el README («pass the same
   `scopes.outbox` instance you put in the config»), pero **es un agujero real** y lo digo
   aquí en vez de fingir que el gate es total. Cerrarlo de verdad pide que el manager sepa la
   `hierarchy` del driver, y eso es la pieza de **capacidades de 3b-2e**: ahí es donde
   corresponde, no aquí.
6. **La outbox no cubre `grant`/`revoke`/`deny`/`removeDeny`.** El hallazgo S5 es del ÁRBOL
   (`scopes.*`), que es el único hecho que el paquete escribe a partir de una transacción del
   consumidor que él no controla. Un `grant` dentro de una transacción que hace rollback
   deja un hecho de más, que es un problema distinto (y menor: se ve en las enumeraciones,
   contra las que la aplicación sí puede auditar). Extenderla sería otro lote y otro debate.
7. **No he tocado el `CHANGELOG.md`** ni he hecho commits: los hace el dueño.
8. **`relayScopeChanges` no reporta cuántos quedan, solo si quedan** (`remaining: boolean`).
   Contar exige un `COUNT` que el puerto no pide y que en una cola grande no es gratis; un
   «al menos N» habría sido un número que engaña. El comando dice «vuelve a ejecutar».
