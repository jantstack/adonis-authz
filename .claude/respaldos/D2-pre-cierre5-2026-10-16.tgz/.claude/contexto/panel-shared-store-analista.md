# Panel «store compartido» — analista: viabilidad, forma mínima y coste

**Fecha** 2026-09-11 · **Base** `main`, `2.4.0-alpha.8`, commit `d18af8e` · **Servidor** OpenFGA
**v1.19.0** en `http://localhost:8101` (el mismo que el consumidor) · **Motor SQL** sqlite `:memory:`
(harness de la suite) · **Scripts y salidas** en el scratchpad
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`medir.ts`, `medir_legado.ts`, `medir_simetrica.ts`, `salida-hoy.json`, `salida-parche.json`,
`patched/` = copia de `src/` con el arreglo). **No se ha tocado un solo fichero del repo salvo este
documento**; los stores creados se han borrado (0 vivos al terminar, comprobado).

**Veredicto en una frase:** el arreglo es **una lista blanca de tipos de objeto propios**
(`scope`/`role`/`role_binding`/`deny_binding`) aplicada en el bucle de `reconcile` del driver
`openfga`, **~15 líneas, no breaking, medido**: hoy `--prune` borra **60 de 60** tuplas de relación y
`--dry-run` da `clean=false` para siempre; con la lista blanca borra **0**, conserva el barrido de la
basura de 2.2/1.x (**2 de 2**) y `clean` vuelve a `true`. La simétrica **no existe**: el reconcile de
relaciones ya filtra por tipo y **no toca un hecho** (medido).

---

## 0 · Reproducción del defecto (control)

Store compartido montado por la vía real (driver `database` → `authz:reconcile` → 372 tuplas de
hechos; luego `OpenFgaRelationsDriver.relate` × 60 en la partición de una organización):

| | tuplas antes | `--dry-run` | `--prune` | tuplas después |
|---|---|---|---|---|
| **hoy (`d18af8e`)** | 432 (`scope` 173, `role` 39, `role_binding` 160, **`document` 40, `space` 10, `group` 10**) | `extra 60`, `skipped {extra-fact: 60}`, **`clean=false`**, 27 ms | `deleted 60`, `massDelete=false`, **`clean=true`**, 43 ms | **372** — las 60 de relación, borradas |

Dos cosas que el informe del consumidor no dice y agravan el cuadro:

1. **La pasada destructiva reporta VERDE.** Con `--prune` el `skipped['extra-fact']` desaparece
   (porque ya las borró), así que `reconcileLines` da `clean=true` y el comando sale 0
   (`commands/authz_reconcile.ts:165-176`). El operador no tiene ni la señal de que ha pasado algo.
2. **`group` también cae.** No solo los tipos del consumidor: el tipo `group` —que emite SIEMPRE el
   generador de relaciones (`src/drivers/openfga_facts.ts:809`, `factsRelationTypeDefinitions`)— se
   lleva las 10 tuplas de userset. Un `viewer` concedido a un grupo se evapora igual.

---

## 1 · Inventario de tipos de objeto: quién gobierna qué

### Los del reconcile de HECHOS (✅ verificado en código)

| tipo de objeto | quién lo compone | dónde |
|---|---|---|
| `scope:<scopeKey>` | árbol (`#parent`), marcador de raíz (`#rooted`), aristas `#binding`, denies (`#denied_<P>`) | `openfga_facts.ts:650`, `:669`, `:680`, `:706`, `:776`, `:790` |
| `role:<uuid>` | proyección del catálogo (`#permits_<P>`) | `openfga_facts.ts:214`, `factsCatalogTuples:622` |
| `role_binding:<scopeKey>\|<roleUuid>` | la asignación (`#assignee`) y su arista `#role` | `openfga_facts.ts:718`, `:735`, `:752` |
| `deny_binding:<scopeKey>\|<permissionUuid>` | **obsoleto** (modo `resolver`, 2.2). Ya no se escribe, pero `enumerateFacts` **lo sigue leyendo y emitiendo como deny** (3b-8 · A2) y `--prune` lo barre | CLAUDE.md:752, README:1082, CHANGELOG:1606 |

No hay más: un barrido de todas las formas `tipo:<…>` del CHANGELOG devuelve exactamente
`scope`, `role`, `role_binding`, `deny_binding` (los ids de 1.x cambiaban el **id**, no el tipo:
`role_binding:<scopeKey>|<slug>` sigue siendo `role_binding`). Los holder types **nunca** son objeto,
solo `user`; medido: el store real solo contiene los tipos de la tabla.

### Los de `relations/` (✅ verificado en código)

- `group` — **siempre**, lo emite el generador, no lo declara el consumidor (`openfga_facts.ts:809-812`).
- un tipo por `objectTypes[].type` de `defineRelationsConfig` (`src/relations/define_relations_config.ts:62`),
  con id `<type>:<scopeKey(partición)>|<uuid>` (`openfga_relations_driver.ts:301-309`).

### ¿Puede haber solape? **No, por construcción — y está demostrado en dos capas**

1. **Declaración**: `defineRelationsConfig` y `assertRelationsConfigPublishable`
   (`openfga_facts.ts:871`) rechazan con 422 `E_AUTHZ_RELATION_CONFIG` un `objectType` que esté en
   `RESERVED_FACTS_TYPES` ∪ holderTypes.
2. **Runtime**: F-05 (`assertRelationDeclared`/`assertObjectTypeDeclared`) impide que el puerto de
   relaciones escriba o purgue sobre un tipo de `facts` — y el docblock recuerda que sin esa guarda
   `relate(evil,'assignee',{type:'role_binding',id:<roleUuid>},S)` **fabricaba un binding real**
   (escalada medida contra el `:8101`) y `purgeObject({type:'role_binding'})` **borraba el binding**.

### ¿Dónde está escrito hoy cuáles son «los suyos»? **En ningún sitio como conjunto.**

Está **implícito** en el catch-all de `familyOfTuple` (`src/drivers/openfga_driver.ts:3450-3455`):

```ts
if (tuple.relation === FACTS_ROOTED_RELATION) return 'root'
if (…FACTS_ROLE_TYPE… && …FACTS_PERMITS_PREFIX…) return 'catalog'
if (…FACTS_SCOPE_TYPE… && …FACTS_PARENT_RELATION…) return 'tree'
return 'facts'          // ← «todo lo demás es mío», que es el defecto
```

Lo más parecido a la lista es `RESERVED_FACTS_TYPES` (`src/identity.ts:329-331`), **y es una trampa**:
contiene `group`, que es de RELACIONES. Reutilizarla tal cual como lista blanca reproduce el bug para
los usersets. ⚠️ **Son dos conjuntos distintos con nombres parecidos**: `RESERVED_FACTS_TYPES` =
«nadie puede declarar esto»; la lista nueva = «esto lo gobierna el reconcile de hechos».

---

## 2 · Forma mínima de la corrección

### (c) Filtrar el `Read` por tipo — **DESCARTADA: no se puede.** (✅ medido hoy, v1.19.0)

```
POST /stores/<id>/read {"tuple_key":{"object":"document:"}}                 → 400 validation_error
POST /stores/<id>/read {"tuple_key":{"object":"document:","relation":"…"}}  → 400 validation_error
POST /stores/<id>/read {"tuple_key":{"object":"document:","user":"user:u1"}} → 200 (1 tupla)
POST /stores/<id>/read {}                                                   → 200 (todas)
```
> `the 'tuple_key' field was provided but the object type field is required and both the object id and user cannot be empty`

Confirma la medición del panel anterior. El filtro por tipo **exige `user`**, y el reconcile no puede
enumerar los users (son justo lo que busca). Además el volcado entero es **requisito**: es la única
forma de ver lo que sobra, incluida la basura de otro modelo (CLAUDE.md:373). El coste de leer lo
ajeno es el que ya se paga; lo que cambia es qué se hace con ello. *(Dato de coste: las tuplas ajenas
consumen el cupo de `maxTuples` — `readEveryTuple`, `openfga_driver.ts:3295-3325`.)*

### (a) Lista blanca de tipos PROPIOS — **recomendada**

Regla: `objectTypeOf(tuple.object) ∈ {scope, role, role_binding, deny_binding}` ⇒ es mía (clasifica
`familyOfTuple` como hoy); **si no ⇒ AJENA: ni se borra, ni es `extra`, ni entra en `skipped`**.

- Conserva **intacto** el barrido de la basura propia: `deny_binding` y los ids 1.x son tipos PROPIOS
  (medido abajo, 2 de 2 borradas).
- **Fail-safe**: no depende de que nadie cablee nada. Vale igual por `manager.reconcile` que por
  `driver.reconcile` directo (que es API de plataforma publicada) y aunque las relaciones las escriba
  **otro proceso con otra config**.
- Cambio de comportamiento: una tupla de un tipo **desconocido** (ni mía ni de relaciones declaradas)
  deja de borrarse con `--prune`. **Ninguna promesa publicada la cubre** (README:1082 habla de los
  restos del importador viejo, que son `deny_binding` y `role_binding`), así que no es breaking de
  contrato; sí es un cambio observable y hay que escribirlo en el CHANGELOG.

### (b) Pasarle al reconcile los tipos de `relations.config` — **sí, pero solo para el REPORTE**

Viable y barato: `manager.reconcile` ya compone `ReconcileSource` (`src/manager.ts:1958-1969`) y
tiene `this.#config.relations?.config` a mano (`src/define_config.ts:291`); sería un campo opcional
más (`relationTypes?: readonly string[]`). El driver de hechos **hoy no conoce** la config de
relaciones (solo `openfga:provision` la usa para fusionar el modelo, `openfga_driver.ts:302-323`).

**Pero como REGLA DE BORRADO es fail-dangerous**, y por eso no puede ser la primaria: si el operador
corre el reconcile por un camino que no cablea `relations.config` (driver directo, un segundo
servicio, un config a medias), las tuplas de relación vuelven a caer en «desconocido» y `--prune` las
borra otra vez. La seguridad no puede depender de que alguien se acuerde de pasar una config.

Su valor real es **distinguir en el reporte** lo ajeno-declarado de lo desconocido. Medido: con solo
(a), el censo sale mezclado —`foreign.types = ['document','legacy_thing']`—; con (b) se parte en
`relations: 5` / `unknown: 1`.

### ¿Hace falta un tercer cubo? **Sí, pero salen solos de (a) + (b): son tres, no cuatro**

| cubo | criterio | `--prune` | ¿deriva? | ¿reporte? |
|---|---|---|---|---|
| **propio vivo** | tipo propio y forma actual | como hoy | como hoy | como hoy |
| **propio obsoleto** (`deny_binding` 2.2, ids 1.x) | **mismo criterio**: el tipo es propio | **borra** (hoy y mañana) | `extra` de la fase `facts` | igual |
| **ajeno** (relaciones declaradas) | tipo ∈ `relations.config` | **jamás** | **no** | `foreign.relations` |
| **desconocido** | ni propio ni declarado | **jamás** | **no** (pero se avisa) | `foreign.unknown` + línea `warning` |

Lo importante: **«conocido pero obsoleto» no necesita cubo propio** — la clasificación es por TIPO y
`deny_binding` es un tipo del paquete. Eso es lo que hace que (a) sea de 15 líneas y no de 100.

---

## 3 · El reporte

**Sí: `foreign` FUERA de `skipped`.** Es la condición para que `clean` pueda volver a ser `true`
(`commands/authz_reconcile.ts:165`: `drifting = Object.keys(report.skipped).filter(r => r !== 'expired')`).
Meterlo en `skipped` con otro nombre repetiría el bug del 3b-8 · B2 (`expired` clavando el exit 1).

Forma propuesta — **campo opcional de nivel superior**, no una quinta fase:

```ts
/** Tuplas del store cuyo tipo de objeto NO gobierna esta pasada (store compartido). */
foreign?: {
  tuples: number
  types: string[]          // orden estable
  relations?: number       // solo si llegó relations.config (opción b)
  unknown?: number
}
```

⚠️ **No ampliar `phases`**: está publicado como `Record<'root'|'catalog'|'tree'|'facts', ReconcileCounts>`
(`src/types.ts:871`) y añadir una clave rompe a cualquier driver de terceros que lo construya.
`foreign` opcional ⇒ `--to=database` y los drivers de terceros simplemente no lo traen, y
`reconcileLines` lo trata como 0 (mismo patrón que `drift.tooDeep`).

**Qué debe imprimir el comando** (líneas de `reconcileLines`, nivel `log`/`warning`, nunca `error`):

- siempre que `foreign.tuples > 0`:
  `ajenas: 60 tupla(s) de tipos que esta pasada NO gobierna (document, group, space) — store COMPARTIDO con otro subsistema: no se tocan ni con --prune.`
- con `--prune` **y** tuplas ajenas, una línea explícita de que el seguro actuó (es la que convierte
  el verde silencioso de hoy en una afirmación):
  `--prune ha respetado 60 tupla(s) ajenas.`
- si hay `unknown > 0` (opción b activa), un `warning` aparte: son tuplas que **nadie** reclama —
  basura de un modelo anterior de OTRO subsistema o un tipo que se quitó de `relations.config`—, y
  el paquete ya no las barre: hay que mirarlas a mano.

---

## 4 · La simétrica: ¿`authz:relations:reconcile` borra hechos? **NO. Medido.**

Store compartido (3 tuplas de relación comunes + 7 que sobran en el destino + 12 de hechos) y
`reconcileRelations({from: database, to: openfga, partition: org, prune: true})`:

| | `scope` | `role` | `role_binding` | `document` |
|---|---|---|---|---|
| antes | 3 | 1 | 6 | 10 |
| después | **3** | **1** | **6** | 3 |

`report = { written 0, updated 0, deleted 7, unchanged 3, extra 0, massDelete false }`, 25 ms. Borró
**exactamente** las 7 de relación que sobraban; **ni un hecho**.

Y no es suerte: hay **dos** cierres, los dos verificados en código.

1. **La enumeración ya filtra por tipo** — `openfga_relations_driver.ts:666-673`:
   `const relationTypes = new Set([FACTS_GROUP_TYPE, ...config.objectTypes.map(t => t.type)])` y
   `if (!parsed || !relationTypes.has(parsed.type)) continue`. O sea: `relations/` **ya hace** lo que
   le falta a `facts/`. La capacidad lo declara por escrito (`:169-175`: «descartando las de `facts`
   (scope/role/role_binding)»).
2. **El borrado no puede componer un id ajeno** — `toDelete` sale del destino ENUMERADO
   (`src/relations/reconcile.ts:399`) y se aplica con `to.unrelate(...)`, que pasa por F-05 y compone
   `<type>:<scopeKey>|<id>`.

**Coste de la simétrica: CERO.** No hay nada que arreglar. Lo único que corresponde es **documentar**
la asimetría (hoy parece casual y es deliberada) y, si acaso, extraer el criterio a una sola función
compartida para que no se separen.

🟡 **Hueco menor de la simétrica, para la lista, no para alpha.9**: un tipo que el consumidor QUITA de
`relations.config` deja tuplas que `#sweep` ya no enumera ⇒ `--prune` de relaciones **nunca** las
barre (y `unrelate` sería 422). Es el equivalente relacional del `deny_binding`, y `relations/` no
tiene su barrido. Hoy caen en el cubo «desconocido» del reconcile de hechos… que a partir de este
arreglo tampoco las tocará. **Nadie las limpia**: hay que decirlo en el README o darles un barrido
propio (fase 2.5+).

---

## 5 · Coste medido: hoy vs con la corrección

Mismo escenario, mismo servidor, stores nuevos (`salida-hoy.json` / `salida-parche.json`):

| | store antes | `--dry-run` | `--prune`: borradas | `clean` (dry) | store después | ms (dry / prune) |
|---|---|---|---|---|---|---|
| **hoy** | 432 | `extra 60`, `skipped{extra-fact:60}` | **60** | **false** | **372** (💥 relaciones perdidas) | 27 / 43 |
| **parcheado (a)** | 432 | `extra 0`, `skipped {}`, `foreign {tuples:60, types:[document,group,space]}` | **0** | **true** | **432** (intacto) | 22 / 27 |

**El arreglo es más RÁPIDO**, no más lento: 60 entradas menos en el diff y 0 `deleteTuples`
(−19 % en dry-run, −37 % en la pasada con `--prune`; medidas de una tirada, el orden de magnitud es
lo que importa). No añade ni una request: la clasificación es una `Set.has` sobre un `indexOf(':')`
por tupla.

### La prueba que decide: ¿sigue barriendo la basura PROPIA?

Store con un modelo viejo (`deny_binding`, `legacy_thing`), 1 tupla de cada, + 1 `role_binding` con
**id de 1.x** (`role_binding:organization|<uuid>|org-editor`), + 5 tuplas de relación vivas, + los
hechos legítimos:

| | `deny_binding` | `role_binding` (1.x) | `document` (ajena) | `legacy_thing` (desconocida) | `deleted` |
|---|---|---|---|---|---|
| **hoy** | borrada | borrada | **borradas (5)** | borrada | 8 |
| **parcheado** | **borrada** | **borrada** | **intactas (5)** | **intacta** | 2 |

O sea: la propiedad publicada («un store escrito por la versión anterior se limpia en una pasada»,
README:1082) **se conserva entera**, y lo único que cambia además de lo ajeno es que la basura de un
tipo que el paquete nunca escribió deja de borrarse — que es exactamente lo que queremos.

**Breaking o no:** ❌ no rompe el puerto (campo opcional), ❌ no rompe `phases`, ❌ no cambia ningún
código de error, ❌ no cambia la semántica de `--prune` sobre lo propio. ✅ Sí cambia el comportamiento
observable sobre tuplas de tipos que el paquete no escribe (a mejor) y el valor de `clean` en un store
compartido (a `true`). Va en el CHANGELOG como **fix**, no como breaking.

---

## 6 · Plan por lotes para `2.4.0-alpha.9`

Premisa: la alpha.9 ya lleva el arreglo de banderas (`--dry-run` & cía., informe 5 §1/§2/§4). Este
panel es el §3, que **no es de banderas** y es el que el consumidor tiene prohibido por escrito.

**Camino crítico: S1.** Todo lo demás cuelga de la clasificación; S1 solo desbloquea el cutover del
consumidor si va junto con las banderas (sin `--dry-run` real no hay verificador).

| # | lote | dificultad | qué queda demostrable |
|---|---|---|---|
| **S1** | `OWN_FACTS_OBJECT_TYPES` + `objectTypeOf` + `isOwnFactsTuple` en `openfga_facts.ts` (junto a los `FACTS_*_TYPE`, **no** en `identity.ts`: allí está `RESERVED_FACTS_TYPES`, que incluye `group`, y confundirlas es el bug); el `continue` en el bucle de `reconcile` (`openfga_driver.ts:2578`) y `report.foreign` | **trivial** (~15 líneas + tipo) | un store compartido sobrevive a `--prune` y `--dry-run` da `clean=true` |
| **S2** | Tests: (i) `--prune` con N relaciones ⇒ 0 borradas y `foreign.tuples=N`; (ii) `deny_binding` + `role_binding` de 1.x ⇒ **sí** se borran; (iii) `group` explícitamente en el caso (i); (iv) `clean=true` en `--dry-run`; (v) la lista blanca **no** es `RESERVED_FACTS_TYPES` (un caso que falle si alguien la sustituye) | **fácil** | la regresión queda clavada, incluido el mutante «reutiliza RESERVED_FACTS_TYPES» |
| **S3** | `reconcileLines`: línea de ajenas + la de `--prune ha respetado N` | **fácil** | el operador ve que el store es compartido; la pasada destructiva deja de ser un verde mudo |
| **S4** | (opcional, opción b) `ReconcileSource.relationTypes` desde `manager.reconcile` (`config.relations.config.objectTypes` + `group`) y partición `relations`/`unknown` + `warning` para `unknown` | **fácil-medio** (toca puerto + manager) | el reporte distingue «ajena declarada» de «nadie la reclama» |
| **S5** | Docs: CHANGELOG (fix), README (§ del store compartido: «cada subsistema gobierna sus tipos; el otro no se toca ni con `--prune`»), CLAUDE.md (matizar «lee el destino ENTERO y borra la basura de un modelo anterior» ⇒ **la basura PROPIA**; nota de la simétrica y del hueco 🟡 del §4) | **medio** (redacción, es donde está la promesa) | la narrativa deja de prometer lo que ya no hace |

### Qué **NO** hacer

- ❌ **No** filtrar el `Read` por tipo: **400 medido** hoy contra v1.19.0, y además el volcado entero
  es requisito del algoritmo.
- ❌ **No** tocar `src/relations/reconcile.ts` ni el driver de relaciones: **medido**, ya es correcto.
  Cualquier cambio ahí es riesgo sin beneficio.
- ❌ **No** añadir una quinta clave a `phases` (tipo publicado).
- ❌ **No** contar `foreign` como deriva ni meterlo en `skipped` (repetiría el `expired` del 3b-8 · B2:
  exit 1 clavado para siempre).
- ❌ **No** añadir un `--prune-foreign` / `--prune-unknown` «por si acaso»: sería un mecanismo de
  borrado masivo de datos de otro dueño accionable desde CI. Si alguna vez hace falta, es un comando
  propio, con su nombre y su `--force` (2.5+).
- ❌ **No** usar `RESERVED_FACTS_TYPES` como lista blanca (lleva `group`).

---

## Decisiones pendientes (❓ las que no son mías)

1. **¿Entra (b) en alpha.9 o se queda en (a)?** (a) sola ya cierra el 🔴. (b) mejora el reporte y
   toca el puerto (`ReconcileSource`). **Mi recomendación: (a) en alpha.9, (b) en la misma alpha solo
   si el consumidor dice que necesita distinguir `unknown` para su runbook de cutover.**
2. **¿El aviso de `unknown` debe tumbar el exit?** Mi posición: **no** (es deriva de otro dueño, no
   nuestra), pero es una decisión del dueño porque afecta al verde de CI.
3. **El hueco 🟡 del §4** (tipos retirados de `relations.config` que nadie barre): ¿README ahora o
   lote propio en 2.5?

**Siguiente paso concreto:** implementar **S1 + S2** (trivial/fácil, ~15 líneas y 5 casos) contra el
`:8101`, con el caso del `deny_binding` **en el mismo commit** — es lo que demuestra que la lista
blanca no se lleva por delante la propiedad publicada de limpiar un store de la versión anterior.
