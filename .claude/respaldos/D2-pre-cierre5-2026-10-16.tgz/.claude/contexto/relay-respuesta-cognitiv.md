# Respuesta a COGNITIV (2º informe 09-09) — alpha.5 publicada el 2026-09-10

> Asunto: Re: 2.4.0-alpha.4 verificada — las cuatro observaciones aceptadas (con una corrección), la respuesta del
> lease con número, y un aviso sobre el relay inline HOY

Gracias por la verificación y por retirar el envoltorio y la sugerencia del `default`. Las cuatro observaciones son
exactas y las llevamos a panel completo (analista, auditor, tester, juez). Resultado:

**1 · Saber si «mi» cambio se aplicó — aceptado.** `enqueue` devolverá su id y `scopes.attached/moved/detached`
devuelven `{ queued: ids[] }` (plural: `detached` encola una fila por ortografía). `relayScopeChanges({ only: ids })`
aplica SOLO esas entradas y reporta por entrada (`applied` / `deferred` / `failed` / `dead`). Medido con 500
entradas ajenas por delante: **4 507 ms → 19 ms**. Dos cosas que NO hará, y por qué: no filtra por
`organization` (la outbox no sabe de tenants, y `detached` de una fila ya borrada no pertenece a ninguna), y una
entrada `only` que dependa de una pendiente anterior de la misma clave de scope sale `deferred`, nunca se aplica
fuera de orden — nuestro auditor midió contra OpenFGA que aplicar el `attached` de una unit antes del `moved` de su
org deja al editor de la org ANTIGUA autorizando sobre la unit nueva.

**2 · Aparcado — aceptado, y era peor de lo que visteis.** Con relay inline, **cinco peticiones de CUALQUIER
tenant** con el store caído aparcan la entrada de otro (va antes en la cola), y al volver el store sus dependientes
se aplican sin ella: el árbol del store se queda con el padre viejo de forma permanente. Está vivo hoy con la
receta del README. Cambios: un 503 del backend NO consume intento (solo cuenta lo que es un fallo de la entrada);
una entrada aparcada TAPONA lo que concede o recuelga (`attached`/`moved`) y sigue dejando pasar lo que retira
(`detached`); y `authz:scopes:requeue --id` en el paquete, con una sonda anti-reversión obligatoria — reencolar
un cambio con una entrada aplicada POSTERIOR sobre la misma clave revierte el árbol en silencio (medido), así que
se niega, con `--force` solo en el comando ace y con el diff impreso. Nunca por HTTP: es plataforma, como `driver()`.
El precio de ese tapón, para que lo sepáis al operar: una entrada aparcada bajo una org congela los `attached`/`moved`
de esa org hasta que un humano la reencole o la descarte (`authz:scopes:requeue`); las purgas siguen pasando.
**Mientras llega la alpha.5**: mantened el relay por cron además del inline, y vigilad `dead` en cada pasada.

**3 · `enumerateRelations` O(store) — límite declarado ahora, mejora en 2.5.** Confirmado: lee el store entero y
filtra por partición (partición de 5 000 y de 10 tuplas cuestan lo mismo, 151 páginas). La salida «por prefijo de
id» NO existe: OpenFGA devuelve **200 con cero tuplas** en silencio — sería un reconcile que copia nada y lo llama
éxito. Lo que sí: un barrido único para K particiones (1,4 s → 0,46 s con tres) en 2.5, y la nota en el README de
que la purga de partición y el reconcile de llaves no deben dispararse desde una petición de tenant.

**4 · Profundidad 22 — con una corrección.** Sí está en el README (§ «The scope-chain depth ceiling (facts)»), en
prosa; lo que falta es la tabla de límites y una línea donde se diseña el árbol. Se añaden, atadas a la constante, y
un gate opt-in por config que rechaza con 422 al colgar el nivel que pasa del techo (parcial: no ve la altura de un
subárbol que se mueve). Medido: la profundidad no afecta a otros tenants (fail-closed para el propio árbol).

**Lease — no cambia, y el número dice por qué.** Una pasada de una entrada sostiene el lease **13 ms** (p95 17). Lo
que os obligó a subir el pool no es el lease, es la pasada larga con backlog ajeno (4,5 s); con `only` pasa a 19 ms.
El lease por lote perdería el escritor único (el estado de aplazamiento es de pasada) y el fence con caducidad es
peor porque OpenFGA no tiene escritura condicionada. Acortad la pasada, medid el pool después.

**Y una advertencia sobre el reporte del relay**: es global (ids, uuids de scope, `actor`, `lastError` de toda la
cola). No lo devolváis en la respuesta HTTP de una petición de tenant; devolved solo lo de vuestros ids.

Publicada: `2.4.0-alpha.5` con dist-tag `alpha` (`npm i @jantstack/adonis-authz@alpha`), sin migración ni breaking del
puerto para terceros (`enqueue` puede seguir devolviendo `void`). Dos cambios de superficie que os tocan: `scopes.attached/
moved/detached` devuelven `{ queued: ids[] }` (antes `void`), y `relayScopeChanges({ only: queued })` es la llamada que
hacéis tras el commit. Verificada en SQLite, SQLite-fichero, PostgreSQL 18 y MySQL 8.4 contra OpenFGA, con auditoría en
tres rondas (la última cazó dos huecos del propio cierre antes de publicar). Un límite declarado hasta 2.5: bajo `only`, un
`detached` cuya clave tenga una entrada anterior sin aplicar espera a una pasada completa — mantened el cron. El barrido
único de `enumerateRelations`, 2.5.

---

# Adenda (alpha.6, 2026-09-10) — para enviar junto con lo anterior o después

> Asunto: 2.4.0-alpha.6 publicada — los dos límites que os declaré «hasta 2.5» ya no existen

Publicada `2.4.0-alpha.6` (`npm i @jantstack/adonis-authz@alpha`), aditiva sobre la alpha.5:
- **`enumerateRelations` ya no es O(store) por partición.** Un solo barrido del store reparte por partición:
  `reconcileRelations({ partitions: [...] })` (y el nuevo método opcional del puerto `enumerateRelationsMany`)
  enumera origen y destino UNA vez para K particiones. Medido con 5 000 tuplas y tres particiones contra OpenFGA:
  150 lecturas / ~530 ms → 50 lecturas / ~190 ms, mismo resultado byte a byte. Sigue la regla de no dispararlo
  desde una petición de tenant, pero ahora un reconcile de llaves de todas vuestras organizaciones cuesta un barrido.
- **Bajo `only` la purga también pasa.** Un `detached` detrás de una cadena bloqueada solo por un aparcado se aplica
  en la misma pasada inline; ya no hace falta esperar a la pasada completa para eso (mantened el cron igualmente:
  sigue siendo el que ve `dead`).
Y `2.4.0-alpha.7` (mismo día) retira el nombre viejo del lock de MySQL: no os afecta (PostgreSQL), y deja el
paquete sin ninguna transición pendiente. Instalad directamente `@alpha` (= alpha.7).
