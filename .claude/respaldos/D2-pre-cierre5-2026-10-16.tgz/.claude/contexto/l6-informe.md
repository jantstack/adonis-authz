# L-6 · Docs del tramo `{trx}`, con dientes — informe (incremental, para `2.4.0-alpha.2`)

> Base: `main` @ `6a05884` (= L-5 commiteado, árbol limpio al empezar; `git status` vacío). Árbol principal, SIN
> commits (los hace el dueño). Alcance: el lote L-6 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-6, §1.3,
> §6.2, §6.3). Regla que gobierna: **lo publicado se cumple o se reescribe** — cada frase corresponde a un caso o a
> una medida de `l0..l5-informe.md`, `l4b-informe.md` o `r15-informe.md`; donde un lote contradijo al plan, gana el lote.

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l6-rojo-docs.log`, `l6-receta-{sqlite,sqlite-file,pg,mysql}.log`, `l6-mutante-automatiza*.log`, `suite-*.log`).
Los mutantes se plantaron con `perl` sobre copia de respaldo y se restauraron en el MISMO comando (`grep -rc MUTANT src` = 0).

(Informe INCREMENTAL: se completa pieza a pieza.)

## Pieza 1 · Los casos nuevos, ROJOS antes de tocar una línea de docs ✅

### 1a · `tests/trx_docs.spec.ts` (nuevo, sin servidor ni base) — tres grupos

1. **El grep con dientes** (patrón del grep de L-5 sobre el código, ahora sobre lo publicado): (a) ninguna línea del README
   que diga «atómico/atomic» y hable de `openfga`/FGA/tuple/store habla a la vez de la transacción del consumidor
   (`{ transaction }`, `your transaction`, `caller's/consumer's transaction`, `transactionalWrites: true`, «both or
   neither»); y el grep tiene que ver ALGO (las líneas del `Write` atómico de FGA —invariante 6— y de `purgeRole` existen);
   (b) la sección `#### \`openfga\`: the recipe by direction` existe, **no contiene «atómico/atomic» en ninguna forma**, y
   dice con estas palabras: `This is not "both or neither"`, `fail-closed`, `it does not compose`, `The package does not
   automate it`.
2. **La LETRA del 500 de la puerta** (patrón `freeze.spec.ts` 3b-7): `UnsupportedOperationError.transactional` nombra la
   operación, el driver, `transactionalWrites: false`, «una tupla no entra en una transacción SQL», «No se ha tocado el
   driver», las DOS salidas (`usa el driver 'database' para los hechos|las relaciones`, `requireTransactionalWrites: true en
   config/authorization.ts` —y `relations.requireTransactionalWrites` solo en el puerto de relaciones—), «falle al ARRANCAR»
   y «Sin { transaction } la misma llamada entra»; `transactionalDriver` (L-5) empieza por la MISMA letra y añade
   «Rechazado por el DRIVER», «manager.driver() no es una salida», `scopes.outbox`/`authz:scopes:relay` y «para hechos y
   relaciones no hay outbox»; `transactionalCatalog` nombra `withAuthzCatalogWrite` e «invariante 14». **Lo que LANZA el
   manager es esa letra byte a byte** (roles con un doble `false`; relaciones con el doble de `/testing` y
   `driverName: 'openfga'`). Y el README la documenta: «the message names the driver and the operation, nothing was
   called», «the way out is the `database` driver or `requireTransactionalWrites`», «entering through `manager.driver()`
   is not a way out».
3. **La letra de L-6**: la frase del freeze ampliada (§6.3: `does NOT freeze` sigue, `never through your transaction`, `a
   snapshot taken before the freeze does not skip it`, `as long as your transaction`, `requires a pool of at least 2`); el
   límite de `resolveChain` (§6.2: `The tree is judged against the state before your transaction`, `notify
   \`authorization.scopes.*\` first`, `a \`ScopeChainResolver\` that closes over your transaction`, `E_AUTHZ_UNKNOWN_SCOPE`);
   la limitación para terceros (`a guarantee of this package's \`database\` driver`, `the runner requires the census`,
   `cannot prove that a third-party driver`).

**Rojo literal** (`l6-rojo-docs.log`, antes de tocar el README): **4 passed, 5 failed (9)** —
```
ℹ AssertionError: el README tiene la sección «#### `openfga`: the recipe by direction» con cuerpo: expected +0 to be above 239
ℹ AssertionError: expected '# @jantstack/adonis-authz…' to include 'entering through `manager.driver()` i…'
ℹ AssertionError: expected '…' to include 'a snapshot taken before the freeze do…'
ℹ AssertionError: expected '…' to include 'The tree is judged against the state …'
ℹ AssertionError: expected '…' to include 'a guarantee of this package\'s `datab…'
```
Los 4 verdes de salida son los de la LETRA del código (`errors.ts` ya la tiene desde L-2/L-5: aquí se fija para que nadie
la suavice) y el grep global (hoy el README no ofende: lo que fija es que no vuelva a ofender).

### 1b · `tests/contract.spec.ts`, grupo «L-6 · la receta por dirección de openfga» (`@l6`, contra el `:8101`)

1. **El paquete NO automatiza la receta**: `grant`/`revoke`/`deny`/`removeDeny` con `{ transaction: trx }` (la
   transacción REAL de Lucid, envuelta en un Proxy que anota `after(...)`) sobre el driver `openfga` real ⇒ 500
   `E_AUTHZ_UNSUPPORTED` nombrando `'openfga'` y la operación, **cero hooks registrados en la transacción** (el paquete no se
   cuelga de `after('commit')` para escribir después), cero llamadas al cliente FGA (espía de L-5) dentro de la
   transacción, y tras el commit sigue cero: nada aterriza, `onWrite` vacío, `authorize` false.
   **Mutante «automatiza»** (puerta 1 del manager apagada + `rejectTransaction` del driver registra
   `transaction.after('commit', …)` y devuelve en vez de lanzar): en `sqlite-file` (`l6-mutante-automatiza-sqlite-file.log`)
   ```
   ℹ AssertionError: ROJO: grant con { transaction } NO lanzó sobre openfga (¿automatizó la receta o escribió en línea?): expected undefined to equal 500
   Tests  1 passed, 1 failed (2)
   ```
   y en `:memory:` (`l6-mutante-automatiza.log`) el mismo caso cae por **timeout**: el driver mutado sigue hacia la barrera
   del freeze y el llamante sostiene la única conexión (la cara de pool 1). Restaurado; `MUTANT` = 0.
2. **La receta MEDIDA y su límite** (`l6-receta-{sqlite,sqlite-file,pg,mysql}.log`, 2/2 en los cuatro modos):
   - **Permisiva (`grant`) DESPUÉS del commit** con `trx.after('commit')`: rollback ⇒ el grant no se escribe
     (cero `write` en el espía), `authorize` false, la fila del consumidor sin tocar ⇒ **fail-CLOSED**; commit ⇒ concedido
     con la fila (Lucid espera a los hooks `after:commit` en `commit()`).
   - **HALLAZGO medido, al README**: lo que el handler de `after('commit')` lanza **Lucid lo TRAGA** (`catch {}` en
     `TransactionClient.commit()`): un `grant` que falla ahí (422 por rol desconocido en el caso) falla en silencio y
     `db.transaction` resuelve sin lanzar. Fail-closed, pero sin que nadie se entere.
   - **Restrictiva (`revoke`) ANTES/DENTRO, en línea**: rollback del consumidor ⇒ revocado igual aunque su fila siga
     diciendo «con acceso» ⇒ **fail-CLOSED**, y **reparable** (volver a conceder lo restaura).
   - **HALLAZGO medido, al README**: «dentro» exige **pool ≥ 2 también con `openfga`** — la escritura va al store, pero la
     barrera del freeze se lee por la conexión del motor. En `:memory:` un `revoke` en línea DENTRO de `db.transaction`
     es **503 `E_AUTHZ_BACKEND_TIMEOUT` por la barrera** (con `freezeTimeoutMs: 400`, < 5 s: SU deadline, no los 60 s del
     pool) y no revoca nada; la receta con pool 1 es «ANTES de abrir la transacción». El caso hace «dentro» en
     `sqlite-file`/PG/MySQL y «antes» en `:memory:`, y afirma el 503 de «dentro» en `:memory:` (primera corrida en
     `:memory:`: `Error: Test timeout` con el `revoke` dentro y el `freezeTimeoutMs` por defecto de 5 s — de ahí salió).
   - **NO COMPONE**: intención «grant y después revoke del MISMO hecho en la misma transacción» (final esperado: sin
     acceso) ⇒ la receta aplica el revoke antes/dentro (no-op: el hecho no existe todavía) y el grant tras el commit ⇒
     `authorize` **true**. Medido en los cuatro modos; es la frase del juez (§1.3) anclada al resultado. Su «rojo» es el
     de una medición: voltear la aserción a `false` ⇒ rojo (no hay código del paquete que lo haga componer, y eso es
     exactamente lo que el README dice).

**Mutantes del spec de docs** (`l6-mutante-grep.log`, `l6-mutante-letra.log`; restaurados por copia, `MUTANT` = 0):
- **M-grep** — una frase en la receta («With `openfga` the recipe is effectively atomic with your transaction») ⇒ **2 failed**:
  `el README promete atomicidad de openfga con la transacción del consumidor en: README.md:<n>` y `la receta por dirección no
  puede decir «atómico» de ninguna forma`.
- **M-letra** — la salida `database` desaparece del mensaje de la puerta (`errors.ts`: `Salidas: usa el driver 'database' …, o` ⇒
  `Salida:`) ⇒ **1 failed**: `roles · la letra lleva «usa el driver 'database' para los hechos»: expected 'grant: se pidió
  escribir en la transa…' to include …`.

## Pieza 2 · README — una sola sección para `{ transaction }`, y cada frase con su caso ✅

**Estructura.** La sección de L-3 (`### Writing facts inside your transaction`) estaba INCRUSTADA en medio de
`#### The tree outbox…` (entre el párrafo de las dos reglas de L-1 y «The relay is resumable»), y la de L-4 vivía en
Relations repitiendo la mitad. Las dos se funden en **`### Writing inside your transaction (2.4.0-alpha.2)`** (nueva h3 tras
«What a scope that is not attached grants», antes de «Identity is validated»), con cinco h4. El párrafo de las dos reglas de
L-1 sigue en la outbox (es de `scopes.*`) y enlaza a la sección; el de L-4 en Relations queda como puntero + la parte de
L-4b (esquema), que no se mueve. Anclajes `#writing-facts-inside-your-transaction-240-alpha2-lot-l-3` (tres) reescritos a
`#writing-inside-your-transaction-240-alpha2`; `grep` = 0 huérfanos.

| Frase del README (sección/h4) | Caso o medida que la sostiene |
|---|---|
| Tabla «what `{ transaction }` means» (escribe / escribe / encola / rechazado; `database` sí, `openfga` 500) | L-2 (docblock «encolar ≠ escribir», control `scopes.attached` no pasa por la puerta; delegación ⇒ 500), L-3/L-4 (`whenTrue`), L-5 (500 con espía) |
| «exactly *both or neither* … never *not lost* … no intermediate value»; «not portable between drivers … the suite pins that asymmetry on purpose» | juez §1.1/§2; L-5 pieza 5 (paridad, `relations_bridge.spec`) |
| `requireTransactionalWrites` ⇒ «does not start», reads included, driver solo registrado no se inutiliza | L-2 pieza 4/5; L-5 «ARRANQUE» (factory de `openfga` = 0) |
| **The rule**: lo que va por la trx (INSERT/UPDATE/DELETE + «¿ya existe?») y lo que nunca (freeze, catálogo, `resolveChain`, F-05, `assertWrite`), «before the first statement … spies … counts zero»; el snapshot no decide; «until 2.4.0-alpha.2 the barrier *was* read through the caller's transaction» | L-3 pieza 1 (`writer()`; re-grant en la misma trx = caso 2) y `freeze.spec` caso 3 (`spy.statements() === 0`); L-4 caso 2; L-1 🟠 8 (tres motores) |
| **pool ≥ 2**; 503 `E_AUTHZ_BACKEND_TIMEOUT` a `freezeTimeoutMs` «pool wait included; knex's own `acquireConnectionTimeout` would have made it 60 s»; cero sentencias; la opción `transactionalWrites: false` en los dos drivers; «also applies to `scopes.*`» (breaking L-1); frozen ⇒ 503 `E_AUTHZ_FROZEN` antes de la primera sentencia | L-1 (60 007 ms medidos; caso de pool 1 con `elapsed < 5000`); L-3 caso 7 y L-4 caso 9 (cara de `:memory:`); L-3/L-4 caso 4 (`false` declarado); L-3 pieza 3 |
| «yours and the driver's» + `assertCallerTransaction` exportado + lo que pasaba antes de L-1 | L-1 🟠 9 (dos casos); L-3 caso 3 (otra conexión REAL) y `whenTrue` (tres transacciones ajenas ⇒ 500, espía = `[]`); L-2 exporta |
| «by census and not by the answer … four writes of each port … SQLite (file), PostgreSQL and MySQL … `purgeObject`/`purgeSubject` delete and revert *together* … uncommitted write invisible» | L-3 pieza 1 (92/92 ×3), L-4 pieza 1 (36/36 ×3, censo 3 tras rollback) |
| `transactional: true` en el evento; `trx.after('commit')` para la última palabra | L-3 pieza 2 (decisión `onWrite`; caso 1 «el evento `revoked` lleva `transactional: true`») |
| **Tabla por motor** (UNIQUE: PG espera/23505/409/abortada; MySQL 1062/409/viva; sqlite-file BUSY inmediato/503) | L-3 caso 5 (324/329/309 ms) y L-4 caso 5 (311/312/302 ms) |
| Deadline: PG `pg_cancel_backend`/abortada, MySQL `KILL QUERY`/viva, SQLite no puede | L-3 caso 6 (430/423/7 ms) |
| Deadlock: PG `deadlock_timeout` 1 s, víctima abortada, ganador espera; InnoDB al instante y deshace la trx ENTERA; SQLite no puede | L-4 caso 6 (1012/1014 ms PG; 5/12 ms MySQL) |
| Trigger de partición dentro de la trx: PG abortada + siguiente `relate` 503 clasificado `25P02`; MySQL/SQLite viva | L-4 caso 1 |
| `SQLITE_BUSY` snapshot (una trx que leyó antes de que otro escritor confirmara) | L-3 pieza 3 caso 3 en `sqlite-file` (BUSY_SNAPSHOT) |
| «never issues a second statement … `onWrite` publishes nothing for the loser» ; mutante que relee falla distinto por motor | L-3 caso 5 (UN evento) + mutante `poisoned` (PG 2 failed / MySQL 1 failed) |
| Caducidad de relación revierte a la anterior (uuid viejo, `expires_at` viejo) | L-4 caso 3 |
| **`resolveChain`**: 422 `E_AUTHZ_UNKNOWN_SCOPE`, «the tree is judged against the state before your transaction», dos recetas (resolutor sobre `trx`; `scopes.*` first, con outbox encola) | juez §6.2; L-3 «lo que NO hice» (el 422 se declara); la receta es documentación (ver «hallazgo» abajo: la frase «the package's own suite does that» NO tenía caso y se reescribió) |
| **La receta por dirección** (tabla permisiva/restrictiva), «This is not "both or neither"», «Its limit: it does not compose», «The package does not automate it», Lucid traga el `after('commit')`, «"Inside" needs a pool of at least 2 even with `openfga`» | juez §1.3 (injerto de (D)) + el grupo L-6 de `contract.spec` (pieza 1b, cuatro modos) |
| La letra del 500 y la del driver («entering through `manager.driver()` is not a way out»; outbox solo para el árbol; «no outbox» para hechos y relaciones «measured as fail-open … numbers in the changelog») | `errors.ts` (L-2/L-5) fijado por `trx_docs.spec`; juez §Tabla (A) = 20,5 |
| **Third-party drivers**: garantía del driver `database` del paquete; el runner exige el censo (hook `transactions`) pero «cannot prove that a third-party driver's write really lives and dies with the transaction it is handed»; la cara `true` solo en pool ≥ 2 | juez §1.2 y §6.5; L-3/L-4 (`TRANSACTIONAL_WRITES = testEngine() !== 'sqlite'`) |
| **Freeze (sección de `authz:reconcile`)**: «`{ transaction }` neither shortens nor skips the window»: «a snapshot taken before the freeze does not skip it», «as long as your transaction», lo que NO congela sin cambios | juez §6.3; L-1 🟠 8 (los tres motores); `freeze.spec` 3b-7 sigue verde (su letra no cambia) |
| Migraciones: «runs **both** recipes below, **in this order** — `expires_at` first, then `subject_relation` — in the **same deploy**» | R-15 P1 (receta) y L-4b pieza 4 (medida 1: las escrituras de holder las rechaza el trigger viejo hasta el paso 4; orden trigger → dedup → backfill → ALTER por la medida 2) |
| Tabla de errores: `E_AUTHZ_UNSUPPORTED` gana «the `openfga` drivers raise it themselves too, so `manager.driver()` is not a way out»; `E_AUTHZ_WRITE_CONFLICT` y la fila de capacidades reenlazadas | L-5 pieza 2/4 |

**Grep «atomic» del README tras la reescritura**: las líneas con la palabra son las de siempre (`purgeRole` «atomically», el
`Write` atómico de `moved` en `openfga` —invariante 6—, «Changing an expiry is not atomic» de openfga, «no atomicity between a
SQL row and an external store» del freeze, «The set is not atomic» de prune-orphans, y la receta «is not atomic» del CHANGELOG
no cuenta: solo README). Ninguna habla a la vez de la transacción del consumidor; la sección nueva no usa la palabra.

## Pieza 3 · CHANGELOG — cabecera consolidada `[Unreleased] — 2.4.0-alpha.2` ✅

Reestructurado con script (nada borrado): la cabecera antigua «· relation expiry (R-15)» y su cuerpo pasan a ser la sección
`### R-15 · expiry on the relation tuple` al FINAL del bloque (orden cronológico inverso, como el resto: L-6, L-5, L-4b, L-4,
L-3, L-2, L-1, L-0, R-15). La cabecera nueva, estilo 1.1.0:
- **The problem**: 7/9 de COGNITIV, los dos ❌ (#5 caducidad, #6 `{trx}` «la llave y su `pdp_version` en la misma trx»), el
  encuadre del dueño («cada driver declara, el cliente ajusta») y la pregunta del panel (una tupla no entra en una trx SQL).
- **The decision**: (C) con capacidad + dos puertas; la regla (escritura por tu trx, autoridad nunca); pool ≥ 2; censo en
  tres motores; lo medido por motor (409 que envenena: PG abortada, MySQL viva, sqlite-file BUSY; deadline ⇒
  `indeterminate` + `transactional`); los tres agujeros de HOY cerrados antes (L-0/L-1); la receta por dirección y el grep.
- **What is NOT done, and why — with the numbers**: **(A)** con sus cifras del panel (fail-open **1,16 s mediana / 2,28 s
  cola**; **131,5 entradas/s no paralelizables** ⇒ **38 s para 5.000**; aparcado irreparable —la pasada de mantenimiento no
  escribe ni borra un hecho—; **resurrección** medida —grant encolado + revoke en línea no-op + relay ⇒ `true` para
  siempre, `database` `false`—; la base del consumidor como escritor privilegiado del PDP); **(B)** cero filas SQL en
  `facts`; **(E)** provisional de 30 s indistinguible de una caducidad; `resolveChain` sin la trx (422, y por qué no se
  cambia el puerto); la delegación; la ventana del freeze tan larga como la trx (§6.3); la cara `true` solo en pool ≥ 2;
  `package.json` sin subir.
- **BREAKING, grouped**: despliegue (pool ≥ 2 en `scopes.*`, `freezeTimeoutMs`); puerto/tipos (`transaction` en
  `WriteOptions`/`RelationTransactionOptions`, `options` en `revoke`/`deny`/`removeDeny`/`purge*`, `transactionalWrites`
  OBLIGATORIA con dos caras, rename `transactions` → `transactionalWrites` del harness, hooks `transactions`,
  `FreezeSqlOptions.client` fuera, `assertCallerTransaction` exportado); comportamiento (`openfga` rechaza también en
  directo; F-05 en los drivers + `skipped.undeclared` exit ≠ 0; relaciones bajo el freeze; 409 sin relectura dentro de la
  trx); esquema (`expires_at`, `subject_relation NOT NULL DEFAULT ''`, las dos recetas en orden y en el mismo despliegue).
- **Deferred and registered**: (F) como pregunta de 3.0 (decisión (2) del dueño); `from`, deny con caducidad, modelos de
  solo lectura siguen en 2.6+.
- `### Lot L-6` con problema → decisión → los tres casos con su mutante → **hallazgos corregidos** → qué NO se hace.

## Pieza 4 · `roadmap-2.0.md` ✅

- Tabla: fila nueva «`2.4.0-alpha.2` · R-15 + `{trx}` … ✅ lotes R-15, L-0…L-5, L-4b, L-6»; la fila «Diferido» pierde `{trx}` y
  `listDenies` (hallazgo: `listDenies` se hizo en 2.1 · 2B y seguía listado como diferido); total ~46 → ~52.
- Sección nueva «## 2.4.0-alpha.2 · R-15 + `{trx}` en los dos puertos — ✅ hecho»: la línea ~103 reescrita como pidió el juez
  («falla al construirse» ⇒ **500 `E_AUTHZ_UNSUPPORTED` por llamada + 500 `E_AUTHZ_CONFIG` al resolver con
  `requireTransactionalWrites`**, con el porqué de los dos panelistas), lo que `database` cumple, lo que `openfga` rechaza y
  ofrece, los agujeros de hoy, L-4b, y lo descartado con número.
- «## Diferido (2.6+)» sin `{trx}`; «## Preguntas registradas para 3.0» con **(F)** (51,5; decisión (2) del dueño; la única
  vía a `{trx}` real en `openfga`; su precio; cero trabajo ahora).

## Pieza 5 · `CLAUDE.md` (conciso, aditivo) ✅

- Cabecera: «publicado v1.1.0; en el árbol 2.0.0-alpha.1» era falso (hallazgo) ⇒ «publicado `2.4.0-alpha.1` (2026-09-01); en
  el árbol `2.4.0-alpha.2` sin release».
- Invariante 6: «con `{ transaction }` la escritura va por la trx del LLAMANTE; la autoridad, nunca» (qué va, qué no, censo,
  409 que envenena por motor, `openfga` rechaza en manager Y driver, la receta no compone ni se automatiza).
- Invariante 13: `transactional: true` junto a `indeterminate` (L-3) y lo medido por motor con el deadline.
- Invariante 14: la fila del freeze la lee el MOTOR (L-1 🟠 8), el bypass del snapshot, el deadline TOTAL (60 s de knex),
  pool ≥ 2 como decisión del dueño.
- Regla de higiene nueva «`{ transaction }` es una CAPACIDAD declarada con dos puertas, exige pool ≥ 2 y `openfga` la
  rechaza»: significado exacto, puerta 1/puerta 2 (no «falla al construirse»), las TRES semánticas, `openfga` re-valida, sin
  outbox de hechos (con las cifras de (A)), paridad, las dos caras obligatorias en los runners, terceros, y dónde viven los
  dientes de las docs.
- Mapa: `backend_guard.ts` (+`isUniqueViolation`/`isDeadlock`), fila nueva **`src/shared/transaction_guard.ts`**, `errors.ts`
  (la letra de `{ transaction }`), `define_config.ts` (`freezeTimeoutMs`, `requireTransactionalWrites` raíz y `relations`),
  `freeze.ts` (sin `client`, `freezeSql`, `assertNotFrozenRow`), `database_driver.ts` (`writer()`/`poisoned()`, la opción),
  fila nueva para **los drivers de relaciones + `src/relations/`** (R-15, L-0, L-1, L-2, L-4, L-4b, L-5), `testing/contract.ts`
  (el par con dos caras, hooks), `tests/` (`helpers/fga_spy.ts`, `database_transaction.spec`, grupos L-4/L-5/L-6,
  `trx_docs.spec`; conteos de `contract_harness` a los literales de hoy: 41/54/72/66/83/78/87/88/76 — el mapa decía 40/53/71/81).
- Estado del roadmap: Fase 4 ✅ (`2.4.0-alpha.1`), 5 ✅, 6/6b ✅, y `2.4.0-alpha.2` ✅ con R-15 y los lotes L-0…L-6 en una línea.
