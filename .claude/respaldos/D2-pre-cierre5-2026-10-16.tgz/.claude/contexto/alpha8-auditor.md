# `2.4.0-alpha.8` (lotes I + II, sin commitear) — AUDITOR sobre el diff

> Contra mis condiciones de `panel-relay2-auditor.md` («Condición para cada cambio») y ataque a lo
> NUEVO. Base: `13ba731` + el árbol sucio (`git diff HEAD --stat`: 23 ficheros, +2784/−143).
> Reproducciones: `relay2-auditor-{1..5}.ts` **re-ejecutadas** y `relay2-auditor-{6,7}.ts` nuevas;
> además `relay-auditor-{5,7,9}.ts` de alpha.5 como regresión. Motor: sqlite en memoria (PG local
> con credenciales que no tengo; lo que no pude medir va marcado).

## Veredicto: **APTA**

Mis dos 🔴 y mis tres 🟠 del panel están cerrados o honrados como «no se hace». Lo nuevo deja tres
🟡 y cinco ⚪; **ninguno reabre**. Los 🟡 los dejo dichos porque dos de ellos apagan en silencio una
alarma o una limpieza que el propio lote acaba de añadir.

---

## 1 · Mis condiciones, una por una

| Condición (panel relay 2) | Estado | Evidencia |
|---|---|---|
| **1(a)** exención en los TRES constructores | ✅ **cerrada** | `#changeScopes` (`src/manager.ts:2232`) alimenta `#changeKeys`, `#dependencyOf` (`:1604`) y `requeueScopeChanges` (`:1818`). Medido: el mutex cae por las DOS caras (`relay2-auditor-1.ts` [I.a] `parked` y [I.b] `earlierPending`: `deferred` → **`applied`**). |
| **1(b)** por REF y la clave del HIJO sigue ordenando | ✅ **cerrada** | `#isRootRef` (`:2239`) compara `type === APP_SCOPE_TYPE && uuid === null`, jamás la cadena. `relay2-auditor-1.ts` [III]: `detached(orgA)` APARCADA + `attached(orgA, app)` sigue `deferred/parked:#5`. O-07b lo fija en el contrato publicado, **con su negativo** (bajo un padre NO raíz sí contamina). |
| **2** supersede: (a) liberar solo al aplicar, (b) por child, (c) nunca `applied_at`, (d) actor | ✅ **honrada: NO se hace** | Decisión del dueño 2026-09-10 (4)(2), 95/100. Mi 🔴 1 (`relay2-auditor-3.ts`: `child→unit→orgV` cuando el superseding falla) no tiene dónde reproducirse. El requisito se tradujo a `reconcile` acotado (2.5), que no reordena nada: es la salida que yo mismo señalaba. |
| **3(a)** un solo lease | ✅ **cerrada** | `#acquireLease` una vez en `requeueScopeChanges` (`:1787`) y `#drainScopeChanges` compartido. Medido (`relay2-auditor-7.ts`): `[1] requeued=1 · relay.applied=1 · busy=false` — el incidente se cierra en UNA llamada; `[2]` con el lease ocupado: `requeued=0`, `relay.busy=true`, la aparcada intacta con `attempts=5`; `[3]` con `waitForLeaseMs` entra a los 306 ms. Mi 🟠 5 (busy en verde) no se reproduce. |
| **3(b)** `apply` ⊥ `force` | ✅ **cerrada** | 500 antes de nada (`:1750`); medido `relay2-auditor-6.ts` [X]. |
| **3(c)** plataforma + `only` interno del propio método | ✅ **cerrada en lo mecánico** | `only` = `wanted`, y `wanted` solo contiene ids que salieron de `dead()` (todo-o-nada, `:1805`): **no se puede colar un id no aparcado**. Sigue siendo prosa que no se exponga por HTTP, como `driver()`/`pruneOrphanRoles` (ver ⚪ 4). |
| **4** `parkAfterMs` no; alarma por edad sí, número/timestamp | ✅ **honrada** | `parkAfterMs` no existe; `queue.{oldestPendingAt,pendingAgeMs}` + `--max-age`. Mi 🔴 2 (`PARKED_CENSUS_MAX` ⇒ 500 en toda pasada, `relay2-auditor-5.ts`) sigue siendo alcanzable **solo** si alguien aparca en masa a mano: nada del lote lo hace. |
| **🟠 7** `enqueue` sin trx | 🟡 **parcial y declarada** | El mecanismo existe y nombra S5 (`src/scope_outbox.ts:335`), pero **el default es `false`** y el flip a 2.5 es decisión del dueño (4)(5) con motivo válido (el contrato publicado encola sin trx en `ctx()`). Medido: con la outbox por defecto, `scopes.attached` sin trx **encola en silencio** (`relay2-auditor-6.ts` [T], filas 2 → 3). Ver ⚪ 3. |
| **🟡 9** `dead` bajo `only` | 🟡 **parcial** | `deadCount` + `dead[]` sin `error`. Lo que yo señalaba —«quitar `lastError` no basta: lo que identifica al otro tenant es `change`»— sigue igual: medido, `dead[0].change` trae tipo y uuid de hijo y padre ajenos (`[Q]`). No reabre (era 🟡). |

### Ataque 1: ¿existe el par donde `app` es el ÚNICO cruce y el orden importa?

**No lo encontré, y lo busqué por los cuatro sitios donde el orden significa algo:**

1. **Ortografías / restauración** — cubierto por la clave del hijo (medido, [III]); `scopeSpellings`
   encola una fila por ortografía y `attached` usa `chain[0]`, que es una de ellas.
2. **`detached(org)` (sin padre en `#changeKeys`) + `attached(org', app)` con OTRO uuid** — no comparten
   nodo: aplicarlos en cualquier orden da el mismo árbol; `app` no se purga (422 en `scopes.detached`),
   no se mueve y nunca es hijo (`#assertEdge`).
3. **Anti-ciclos** — un ciclo necesita dos entradas que nombren un nodo común; `app` no puede estar en
   un ciclo (nunca es hijo), así que ningún ciclo se cierra por la raíz.
4. **El BARRIDO de bindings locales** (`moved(unit1 → app)` frente a `attached(unit2, app)`, el caso que
   me pediste): **conmutan**, incluso con `unit2` colgando de `unit1` en el store. `reparent` llama a
   `sweepLocalRoleBindings(childKey)` **en las dos operaciones** (`src/drivers/openfga_driver.ts:1592`
   → `:1769`/`:1735` (los dos `reparent`)), y cada barrido recorre SU subárbol con el árbol del store de AHORA. Orden A
   (mover primero): el barrido de `unit1` alcanza a `unit2` con la cadena vieja y el `attached`
   posterior lo rehace; orden B: `unit2` se barre con su cadena nueva y el barrido de `unit1` ya no lo
   ve. Mismo estado final — y si la segunda entrada FALLA, el store queda **consistente consigo mismo**
   en los dos órdenes (las aristas y los bindings dicen lo mismo), que es lo que importa: ningún
   binding queda concediendo desde una cadena que el store no tiene. Medido en [IV] que ahora se aplica;
   ❓ el barrido en sí **no lo he medido contra el `:8101`** (razonado sobre el código; ver ⚪ 5).

### Ataque 2: variante B (tapón solo por la clave del HIJO)

Las dos preguntas, medidas:

- `moved(unit → orgA)` APARCADA + `attached(child, unit)` ⇒ **sigue `deferred/parked`**
  (`relay2-auditor-3.ts` [HOY], `relay2-auditor-2.ts` [A]): mi 🔴 1 sigue protegido, porque `unit` es
  la clave del HIJO de la aparcada y `attached(child, unit)` la nombra (al COMPARAR van las dos claves).
- `moved(unit → orgB)` posterior de la MISMA unit ⇒ **`deferred/parked`** (`relay2-auditor-2.ts` [C]):
  **no hay supersede por la puerta de atrás**.
- Lo que SÍ se relaja es lo que la variante busca: `moved(otra → orgB)` detrás de una aparcada
  `moved(unit → orgB)` ahora **entra** (`relay2-auditor-6.ts` [C]) — dos aristas distintas que conmutan.

### Ataque 8: ¿reabre algo de alpha.5/6/7?

Re-ejecutados: `relay-auditor-9.ts` ⇒ **`deferred/parked:101`** (el censo sigue COMPLETO tras mover
`#parkedKeys` a `#relayInputs`: mi 🟠 2 de alpha.5 no reabre); `relay-auditor-7.ts` ⇒ el `detached` a un
salto **se aplica y purga** (🟠 1 de alpha.5 intacto, ahora con `origin: 'parked'` explícito);
`relay-auditor-5.ts` ⇒ «sin reversión». `only`+sonda, tapón, `laterApplied`, freeze y `GET_LOCK` sin
tocar; el tri-estado `failed > pending > parked` conserva la decisión (solo `'parked'` exime a la purga:
`:1402` y `:1443`) y solo añade información al reporte. `maxDepth` sigue PARCIAL y su letra se corrigió
(«N niveles ⇒ `maxDepth = N`», que era falsa en el informe de COGNITIV).

---

## 2 · Hallazgos nuevos (ninguno reabre)

### 🟡 1 — `waitForLeaseMs`: deadline con reloj de PARED y espera con `setTimeout` REAL ⇒ con `config.clock` fijo la pasada no termina NUNCA (medido)

- **Escenario**: precondición — `config.clock` inyectado y constante (el doble normal: `() => new
  Date(FIJO)`, publicado en `define_config.ts:189`) y otra pasada con el lease. Acción — una pasada con
  `waitForLeaseMs: 200`. Resultado — `#acquireLease` calcula `deadline = #wallMs() + 200` con un reloj
  que **no avanza**, así que `while (#wallMs() < deadline)` es siempre cierto: sondea cada 25 ms para
  siempre. La petición no responde y el bucle sobrevive a quien la lanzó.
- **Evidencia**: ✅ medido (`relay2-auditor-6.ts` [W]): con reloj real, `busy` en 206 ms; con reloj fijo,
  **sigue vivo a los 2000 ms** y solo termina cuando otro suelta el lease. Código: `src/manager.ts:1277-1281`.
- **Y la otra cabeza: `waitForLeaseMs` no tiene TOPE** (`#waitMs`, `:1286`, solo exige entero ≥ 0):
  `86_400_000` se acepta; con el lease ocupado es la petición colgada 24 h.
- **Steelman del defensor**: «`config.clock` es para caducidad, y en producción el reloj avanza; además el
  README ya exige pool ≥ 2». → **Me convence para el riesgo de seguridad** (no es alcanzable por un
  atacante: ni el reloj ni el flag vienen de una petición) **y no para el defecto**: el paquete tiene la
  regla escrita de que una DURACIÓN se mide con reloj MONÓTONO (invariante 14, `{ everyMs }`), y aquí se
  midió con el de pared. Por eso es 🟡 y no bloquea.
- **Mitigación mínima**: contar SONDEOS (`Math.ceil(waitForLeaseMs / RELAY_LEASE_POLL_MS)`) o medir con
  el monótono, y un techo declarado en la tabla «Limits».

### 🟡 2 — `--max-age` no distingue «cola vacía» de «no sé la edad»: con una outbox sin `createdAt` la alarma queda apagada en silencio

- **Escenario**: precondición — outbox de terceros (o una tabla del consumidor sin `created_at`) ⇒
  `PendingScopeTreeChange.createdAt` ausente. Acción — el operador arma el cron con `--max-age=300000`
  creyendo que ya tiene la alarma del B2. Resultado — `#queueOf` devuelve `{ null, null }` **igual que
  con la cola vacía** (`src/manager.ts:1257`), y `queueAgeLines` sale sin líneas y con `exceeded: false`
  (`commands/authz_scopes_relay.ts:26`): con el store caído durante horas, exit 0 y **ni una línea**.
- **Evidencia**: ✅ código; el propio docblock lo dice («cola vacía, solo aparcadas, **o una outbox de
  terceros sin `createdAt`**») y elige callar en los tres casos.
- **Steelman**: «es el patrón `stillGranting`: no lo sé ⇒ `null`, jamás `0`». → **A medias**: ese patrón
  exige además que **el comando lo liste APARTE y avise**, que es justo lo que hace `prune-orphans` con
  los huérfanos sin conteo. Aquí «no lo sé» se presenta como «todo bien».
- **Mitigación mínima**: el reporte ya tiene con qué distinguirlo — `remaining === true &&
  pendingAgeMs === null` ⇔ hay cabeza sin fecha: un `warning` («tu outbox no trae `createdAt`: `--max-age`
  no puede alarmar»), y con `--max-age` explícito, exit ≠ 0.

### 🟡 3 — El 422 limpió el `message` pero `details` es propiedad ENUMERABLE: viaja en cualquier `JSON.stringify(error)`

- **Escenario**: precondición — el consumidor devuelve el error tal cual (`response.status(e.status).send(e)`,
  un `logger` que serializa el error al cuerpo, un handler que hace `JSON.stringify`). Acción — un tenant
  crea una unit demasiado profunda. Resultado — recibe
  `{"name":"ScopeDepthLimitError","status":422,"code":"…","details":{"depth":2,"maxDepth":1,"why":"el modelo facts del driver openfga …","server":"… OPENFGA_RESOLVE_NODE_LIMIT …"}}`:
  exactamente la fuga que el lote quería cerrar, una propiedad más allá.
- **Evidencia**: ✅ medido (`relay2-auditor-6.ts` [D]): `message` ya NO nombra openfga; `Object.keys(error)`
  incluye `details`. Código: `src/errors.ts:529`.
- **Steelman**: «el handler por defecto de Adonis solo renderiza `message`». → Cierto para el handler por
  defecto, y por eso es 🟡 y no 🟠; pero `details` se creó **para el log**, y el patrón «devuelvo el error»
  es común. La propiedad no debería depender de qué handler tenga el consumidor.
- **Mitigación mínima**: `Object.defineProperty(this, 'details', { enumerable: false, value: details })`
  (sigue legible desde el log) o un `toJSON()` que lo omita — **el patrón ya está en el mismo fichero**, `markPartialWrite` lo usa (`src/errors.ts:170`); y un caso que afirme
  `JSON.stringify(error)` sin `openfga`.

### ⚪ 1 — Variante B abre un camino al ciclo que solo ataja el driver

Con el tapón sembrado solo por el hijo, una aparcada `moved(X → Y)` ya no retiene un `moved(Y → Z)`
pendiente cuando `Z` cuelga de `X`; si más tarde se reencola la aparcada, la arista cerraría un ciclo
REAL. No es fail-open: lo rechaza el anticiclos contra el árbol del STORE (`storeChain`,
`src/drivers/openfga_driver.ts:1748`, 3b-8 · A5) con 422 y la entrada vuelve a aparcarse. 🟡 razonado, no
medido contra el `:8101`. **Lo que pido es una línea de docblock**: la seguridad de la variante B
descansa en ese guard; quien lo «simplifique» reabre un fail-open mudo.

### ⚪ 2 — El censo (hasta 50 000 filas) se lee ahora ANTES del lease

`#relayInputs` corre antes de `#acquireLease` (`src/manager.ts:1122` vs `:1152`), así que N pasadas
concurrentes que van a salir `busy` pagan cada una el censo completo, en paralelo (antes iba dentro del
lease). Coste puro, y solo con `dead ≥ batchSize`; se nota justo en el incidente.

### ⚪ 3 — `requireTransaction: false` es seguridad opt-in y NO entra en `warnOnOptInSecurity`

El aviso por config existe para `requireWithin`/`requireActor` con esta misma forma («lo sé y lo asumo»).
`requireTransaction` cierra la fuga S5 —la razón de existir de la outbox— y se queda apagado sin decir
nada; quien no lea el CHANGELOG de una alpha se queda con el agujero. Una línea en el mismo aviso hasta
el flip de 2.5.

### ⚪ 4 — «No se expone por HTTP» sigue siendo PROSA, y `apply` sube el premio

`relayScopeChanges`/`requeueScopeChanges` se saltan `requireActor`/`requireWithin` a propósito y nada
impide cablearlos a una ruta. Con `apply: true` la llamada pasa de «reordeno la cola» a «escribo el árbol
del store». No pido mecanismo hoy (es la misma frase que `driver()` y `pruneOrphanRoles`), pero si algún
día se quiere, la vía ya existe en el paquete: un flag de plataforma en el config, como el freeze.

### ⚪ 5 — Lo que no pude medir

`sweepLocalRoleBindings` bajo los nuevos órdenes (necesita el `:8101`; no lo toqué porque la suite del
coordinador corre en paralelo) y el lease en PG/MySQL (credenciales del `postgres18` local). Para el lease
el código es concluyente igualmente: `acquire()` abre **otra transacción** (`src/scope_outbox.ts:491`) y
tanto `pg_try_advisory_xact_lock` como `GET_LOCK` son por sesión ⇒ no reentrante desde otra conexión del
pool, que es lo que hace que «un solo lease» sea la única forma correcta.

---

## 3 · Lo que intenté y NO se rompió

- **Colar un id no aparcado en el `only` interno de `apply`**: imposible, `wanted` se valida contra
  `dead()` con todo-o-nada antes de tocar nada (`:1805`).
- **Dejar el lease colgado con una sonda que se niega**: `#requeueHeld` lanza dentro del `try` y el
  `finally` suelta; medido (`relay2-auditor-6.ts` [A]: el `acquire()` siguiente entra).
- **Opciones desconocidas** (`{ onlyy }`, `{ waitForLease }`): 500 `E_AUTHZ_CONFIG` en los dos métodos
  (X-1), medido — y con eso el `{ apply: true }` que alpha.7 ignoraba en silencio ya no existe.
- **Trx de OTRA conexión / cerrada / `QueryClient` con `requireTransaction: true`**: los tres son 500
  `E_AUTHZ_CONFIG` **antes del INSERT**, y el orden de los cuatro chequeos es el correcto
  (`assertCallerTransaction` gana a `requireTransaction`, así que el mensaje nombra la causa real).
  Medido con dobles sobre el guard.
- **Reventar el tapón desde `requeue`**: sigue sin poder (`relay2-auditor-4.ts` [T]; ahora aplica porque
  la otra aparcada solo tapona por SU hijo, que es la variante B, no un agujero).
- **`apply` bajo freeze**: la barrera se llama antes del outbox y del lease (`:1762`); su suite lo fija
  (R-8) y el orden del código lo confirma.
- **Hacer que la exención de la raíz deje pasar una purga fuera de orden**: `detached` nunca nombra `app`.

## 4 · Preguntas abiertas (ninguna mueve el veredicto)

1. ¿Se anuncia en el CHANGELOG que `--max-age` **no puede alarmar** sin `createdAt`? Es la única forma
   de que el 🟡 2 no muerda a un consumidor con outbox propia mientras no se implemente el aviso.
2. ¿COGNITIV devuelve o loguea el reporte del relay en la petición? Si sí, el `change` de `dead[]` (🟡
   residual del panel) sube a 🟠 y toca resumirlo a contador bajo `only`.
