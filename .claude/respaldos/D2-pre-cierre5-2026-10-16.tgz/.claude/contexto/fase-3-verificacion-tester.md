# Fase 3 (`catalog/`, lotes 3A + 3B) — verificación del tester de contrato

Worktree aislado `…/.claude/worktrees/agent-afd37ef3897c82a1e`, `git checkout --detach f563465`
(3B) sobre `710cd6f` (3A) sobre `7a28cdf` (cierre 2.5). Node 22.23.2, `npm ci` limpio,
`npm run typecheck` limpio. Motores: OpenFGA `:8101`, PostgreSQL 18 (`postgres18`),
MySQL 8.4 (`mysql84`), SQLite memoria/fichero. Contenedor `authz-tester-tiny` en `:8103`
(`MAX_RESULTS=3`) creado y **borrado** al terminar.

Método: no se lee, se ejecuta. 8 combinaciones de suite + tope 3, **24 mutantes** en `src/`
por pieza (cada uno aplicado sobre una copia prístina, verificando que el mutante cambia el
árbol, suite completa, restauración), y auditoría del diff `7a28cdf..f563465` buscando
aserciones relajadas.

---

## 1. Suites — estado real medido

### 1.1 Árbol tal como está en `f563465`

| Modo | sin `:8101` | con `:8101` |
|---|---|---|
| `sqlite` (memoria) | **384** ✅ | **484** ✅ |
| `sqlite-file` (pool 2..5) | **386** ✅ | **486** ✅ |
| `pg` (PG 18, base `authz_test_<hex>`) | **466** ✅ | **643** ✅ |
| `mysql` (MySQL 8.4) | **466** ✅ | **643** ✅ |
| tope 3 (`:8103`, `MAX_RESULTS=3`) | — | **484** ✅ |

Todas exit 0, sin skip, sin only. Los números esperados por el informe de 3B (sqlite 384 /
484, pg y mysql 643 con FGA) **casan exactamente**. `sqlite-file` da +2 sobre `sqlite`
(`pool_concurrency`, K16) y pg/mysql sin FGA dan 466 —el informe no los declaraba— por los
harnesses de árbol SQL.

### 1.2 Residuos

- PostgreSQL: `select count(*) … datname like 'authz_test%'` ⇒ **0**.
- MySQL: `show databases like 'authz\_test%'` ⇒ **0**.
- OpenFGA `:8101`: **60 stores antes y 60 después** de mis ~20 ejecuciones ⇒ la suite deja
  **0 stores**. Los 60 preexistentes (`audit-*`, `trunc*`, `tester-facts*`, `steal*`,
  `phantom*`, `demo-*`…) son de sesiones manuales anteriores; no los toco (el auditor está
  usando el mismo motor).
- Contenedor `:8103`: `docker rm -f authz-tester-tiny` ejecutado. Ninguna base existente tocada.

---

## 2. Mutantes en `src/` — tabla pieza × mutante × motor × resultado

Leyenda: **MUERTO n** = la suite falla, con n tests rojos. **VIVO** = la suite pasa entera
con el defecto dentro.

### 2.1 Lote 3A

| Pieza | Mutante (en `src/`) | sqlite+FGA | pg+FGA | mysql+FGA | Resultado |
|---|---|---|---|---|---|
| A1 | `parseBindingId` vuelve a parsear **por conteo** de partes (2 ⇒ `app`, 3 ⇒ `<tipo>\|<uuid>`) | 484 ✅ | 643 ✅ | — | **VIVO — equivalente** |
| A1 | El binding de `grant` vuelve a llevar el **slug** (`docs~read`), y `parseBindingId` lo acepta | MUERTO 84 | — | — | MUERTO |
| A1 | El **importador** considera suyos los ids 1.x (no los cuenta como `extra`) | MUERTO 1 | — | — | MUERTO |

**A1-conteo es un mutante equivalente, no un hueco de test.** Con la gramática de hoy
(`assertScope` prohíbe `|` en tipo y uuid) un `scopeKey` tiene **siempre** 1 o 2 partes, así
que «parsear desde la derecha» y «contar partes» coinciden para **todo** id que la gramática
admite — incluidos los negativos del unitario (`a|b|c|d`, `app|editor`, `app|Editor`,
`organization|x#y|editor`, `app|`). La promesa del CHANGELOG/README «se parsea desde la
derecha» no es observable hoy y **solo lo será cuando un `scopeKey` crezca de partes** (3b,
modo `facts`). No pido test: pido que quede escrito que es una decisión estructural sin
oráculo hasta 3b, para que nadie «simplifique» a conteo en 3b creyendo que la suite lo cubre.

### 2.2 Lote 3B — B2 (visibilidad por owner)

| Mutante | sqlite+FGA | pg+FGA | mysql+FGA | Resultado |
|---|---|---|---|---|
| `database.authorize` **sin el filtro de owner** en SQL (rol local de A concede en B) | MUERTO 2 | — | MUERTO 3 | MUERTO |
| `openfga.checksFor` **sin `isRoleVisibleWith`** en `rolesGranting` | MUERTO 1 | — | — | MUERTO |
| Visibilidad **por conjunto** de la cadena en vez de **por nivel** (`chainKeysFrom` ⇒ `keys.map(() => keys)`) | 484 ✅ | 643 ✅ | 643 ✅ | **VIVO — hueco real** |
| `database.authorize` sin `r.scope_type = a.scope_type` (desviación 3 del lote) | 484 ✅ | 643 ✅ | — | **VIVO — hueco menor** |

- **Hueco 1 (cerrado por mí, §5).** La desviación 2 del informe («por NIVEL, no por conjunto»)
  **no tenía ningún caso**: el mutante pasa las 484 / 643 / 643 en los dos drivers y en los
  tres motores. Es exactamente el escenario que anticipaba el encargo: recolgar A por debajo
  del scope de la asignación.
- **Hueco 2 (abierto, menor).** La desviación 3 («`database` exige además que el rol esté
  declarado para el nivel de la asignación, como ya hacía `openfga`») afirma **paridad entre
  drivers** y nada la observa. Solo es alcanzable con una fila escrita a mano (`grant` ya lo
  impide), así que el riesgo real es bajo, pero la frase del informe hoy es una promesa sin
  juez. Coste de cerrarlo: ~8 líneas con `linkByHand` + una asignación a mano de nivel cruzado.

**Respuesta a «¿algún caso 2.2 pasa con un driver que ignore el owner?» — sí, casi todos.**
Con `database.authorize` ciego al owner, de los **8 casos `since('2.2')`** que se registran
por harness falla **1** (el primero, «un rol local de la organization A concede en A y sus
units…»). Pasan los 7 restantes, incluidos «dos tenants definen el mismo slug», «deny × rol
local» y «defineScopedRole…» — porque esos tocan rutas de LECTURA (`hasRole`/`listRoles`/
`listSubjects`), que filtran por `roleVisible` en otro punto del código. La regla de
`authorize` (que es la que decide accesos) cuelga de **un solo caso por harness** en cada
driver. No es un defecto, pero sí una concentración de riesgo que conviene saber.

### 2.3 Lote 3B — B3 (policy de `defineScopedRole`), regla a regla

| Regla anulada | sqlite+FGA | Resultado |
|---|---|---|
| Lista blanca `delegablePermissions` | MUERTO 3 | MUERTO |
| Permiso **ajeno** (no efectivo para el actor) | MUERTO 4 | MUERTO |
| Actor con **deny** del permiso (**C2**, lavado vía títere) | MUERTO 3 | MUERTO |
| `rank ≥ rank del actor` | MUERTO 4 | MUERTO |
| **Techo global** (`Math.min(actorRank, topGlobalRank)` ⇒ `actorRank`) | MUERTO 1 | MUERTO |
| **Globales inmutables** (`RoleImmutableError` desactivado) | MUERTO 2 | MUERTO |
| **Colisión con un descendiente** (desviación 4 del lote) | MUERTO 2 | MUERTO |
| Owner resuelto con el **memo** de la vista en vez de en fresco (**C3**) | MUERTO 1 | MUERTO |
| Lo efectivo del actor medido **solo en el owner**, no en su cadena | MUERTO 3 | MUERTO (con mi parche; ver §4.2 nº 7) |

**Las 9 reglas de la policy están observadas.** Es la pieza mejor cubierta del lote.

### 2.4 Lote 3B — B4 / B5 / B6 / B7

| Pieza | Mutante | sqlite+FGA | Resultado |
|---|---|---|---|
| B4 | `database.purgeRole` **no borra los vínculos** | MUERTO 3 | MUERTO **por la FK del espejo**, no por una aserción |
| B4 | `database.purgeRole` deja las asignaciones de **los demás scopes** | MUERTO 2 | MUERTO **por la FK del espejo** |
| B4 | `openfga.purgeRole` **escribe** (borra la fila del rol) antes del 500 | MUERTO 1 | MUERTO |
| B5 | `assignableAt` **evaluado en `authorize`** (ambos drivers) | MUERTO 9 | MUERTO |
| B5 | `grant` **sin** `assertRoleAssignableAt` | MUERTO 3 | MUERTO |
| B6 | El sync **pisa un local homónimo** (colisión desactivada + lookup sin owner) | MUERTO 2 | MUERTO |
| B6 | El prune de vínculos **deja de estar acotado** al rol del spec (poda homónimos) | MUERTO 2 | MUERTO |
| B7 | `defineScopedRole` **sin bump** de la versión compartida | MUERTO 1 | MUERTO (caso twin) |

**Hueco 3 (abierto, medio).** Los dos mutantes de `purgeRole` mueren por
`SQLITE_CONSTRAINT_FOREIGNKEY` en el `DELETE` del rol, **no** porque el caso del juez observe
que quedaron 0 filas. Y aquí hay algo peor, que encontré comparando el stub con el espejo:

| Tabla / columna | `stubs/migration.stub` (publicado) | `tests/helpers/schema.ts` (espejo) |
|---|---|---|
| `authz_role_permissions.role_uuid` | `onDelete('CASCADE')` | **sin `onDelete`** (NO ACTION) |
| `authz_assignments.role_uuid` | `onDelete('RESTRICT')` | **sin `onDelete`** (NO ACTION) |

`migration_stub.spec` (K11) compara tipo/longitud/precisión/nulabilidad/collation por
`information_schema`, pero **no compara acciones de FK** (`grep referential_constraints` /
`delete_rule` ⇒ 0 en el espejo y en el spec). Consecuencia concreta: sobre el esquema
**publicado**, un `purgeRole` que olvide los vínculos **no falla** (el CASCADE los limpia) y
el caso del juez lo dejaría pasar. Lo que hoy mata al mutante es una diferencia accidental
entre el esquema de test y el real.

Recomendación (dos líneas cada una, no bloqueante para 3C pero sí antes de 3b):
1. En el caso `purgeRole` `whenTrue`, afirmar el cero explícitamente sobre el puerto público:
   tras `purgeRole`, `listSubjects(slug, S) === []` **para cada scope donde había asignación**
   (ya se hace para dos: bastaría comprobar además que el slug recreado no resucita a `alice`
   en `unitA1`), o exponer un conteo en el harness.
2. Alinear `onDelete` entre stub y espejo, o extender K11 a `delete_rule`. Es deuda anterior
   a la Fase 3, pero la Fase 3 es la primera que **depende** de ella.

---

## 3. El juez

| Comprobación | Resultado |
|---|---|
| `contract_harness.spec.ts` **se ejecuta** (es un `.spec.ts` de la suite) | ✅ en las 8 combinaciones |
| Conteos literales 36 core / 49 (2.0) / 66 (2.1) / **73** (2.2) | ✅ tal cual en `f563465` |
| **67** sin `listDenies` en 2.2 · **77** con `injectableClock` | ✅ |
| `core ⊂ 2.0 ⊂ 2.1 ⊂ 2.2` | ✅ verificado por inclusión de títulos, encadenado en dos tests |
| `purgeRole: true` por debajo de `'2.2'` ⇒ se rechaza al registrar | ✅ dos asertos (`'2.1'` y sin nivel) |
| `listDenies: true` por debajo de `'2.1'` ⇒ se rechaza | ✅ |
| Cara `listDenies: false` de 2.2 (`defineScopedRole`/`updateScopedRole` ⇒ 500) | ✅ caso registrado y ejecutado |
| Par `purgeRole` `false` ⇒ 500 sin dejar nada a medias | ✅ y observa el catálogo con un `CatalogCache` nuevo |
| ¿Algún caso 2.2 pasa con un driver ciego al owner? | **Sí: 7 de 8** (ver §2.2) |

Tras mi parche los literales pasan a **74 / 68 / 78** y `primitives.length + 8`; el parche los
actualiza en el mismo commit.

---

## 4. Huecos

### 4.1 Aserciones relajadas respecto a `7a28cdf` — ninguna

- `src/testing/contract.ts`: **cero** líneas de aserción borradas en el diff completo.
- `tests/`: se borran 2 tests (`parseBindingId rechaza lo que no tiene 2 o 3 partes válidas`,
  `un id no parseable se registra y se cuenta…`) y ambos vuelven **reforzados** (12 asertos el
  primero; el segundo suma el id 1.x). Los contadores cambian **hacia arriba**
  (`unparseableBindings` 2 ⇒ 3, `warnings` 2 ⇒ 3). Las 10 aserciones borradas son literales
  con slug en el id, sustituidas por sus equivalentes con uuid. **Sin relajaciones.**

### 4.2 Los 12 huecos de `panel-2026-08-28-tester.md` §4

| # | Hueco del panel | Estado |
|---|---|---|
| 1 | Colisión **en ambas direcciones** (global→local y local→sync crea global) | ✅ `manager.spec.ts` grupo B3 «colisiones…» (global, ancestro, descendiente, hermanas) **y** líneas 844-848 + 2161-2170 (el sync y el `diff` rechazan con 422 y nada escrito) |
| 2 | `owner_scope_key = 'global'` reservado | ✅ caso `since('2.2')` «la clave de owner 'global' está reservada» (un scope de **tipo** `global` produce `global\|<uuid>`, nunca `global`) |
| 3 | Bordes de rank 0 / `=` actor / actor−1 | ✅ `manager.spec.ts:2066-2103`: 0, −1, `=50`, 51, no entero, actor con rank 0, techo global 100 ⇒ 99 ok / 100 ⇒ 422, y `rank 49` (actor−1) **acepta** |
| 4 | Bordes de slug 42 / 43 | 🟡 el borde de `assertValidSlug` está fijado (`manager.spec.ts:450-451, 484`: 42 pasa, 43 y 101 ⇒ 422) pero **desde el sync**, no desde `defineScopedRole`. El cableado de `defineScopedRole` a `assertValidSlug` sí está observado (`slug: 'Lead'` y `'parent'` ⇒ 422 `E_AUTHZ_INVALID_SLUG`). Riesgo bajo; no lo cierro |
| 5 | `purgeRole` con **descendientes** y con **denies** | ✅ el caso `whenTrue` monta `unitA1 → unitA1x`, asigna en ambos, deja un deny y otro rol, y afirma que solo cae el purgado — pero ver el hueco 3 de §2.4 sobre **cómo** muere el mutante |
| 6 | **Deny × rol local** | ✅ caso `since('2.2')` dedicado (invariante 2 en el módulo nuevo) |
| 7 | `effectivePermissions` **heredado de app** | ❌ → ✅ **era un hueco real**: ningún test delegaba un permiso que el actor solo tiene por un rol global de nivel `app`. Cerrado en §5 |
| 8 | Test de **migración de datos** (no de columnas) | ✅ `upgrade_child.ts` inserta un rol 1.x **antes** de la receta y `upgrade_recipe.spec` afirma `owner_scope_key = 'global'` y que el sync lo reconoce con el mismo uuid (PG y MySQL) |
| 9-11 | Binding id: 4 partes se parsea / 3 sigue global / 5 se descarta **con log** | ✅ el diseño final no llegó a 4 partes; el unitario de `parseBindingId` cubre 1, 2 y 4 partes, y `un id no parseable se registra y se cuenta` afirma `unparseableBindings = 3` **y** 3 warnings (nunca silencio) |
| 12 | Pin de regresión de `listSubjects` cruzando tenants | ✅ promovido a caso del juez: «dos tenants definen el mismo slug (lead@unit)…» |

**11 de 12 cubiertos; el 7 estaba abierto y lo cierro. El 4 queda 🟡 documentado.**

### 4.3 Promesas nuevas del README (§Scoped roles) sin test

Recorrí la sección entera contra la suite:

| Promesa | Estado |
|---|---|
| Regla única en ambos drivers; fuera del owner no concede, no es membresía, no se asigna | ✅ |
| Mover la unit fuera retira / volverla restaura, **sin escribir** | ✅ |
| «sibling organizations may share a slug» | ✅ |
| «an actor whose roles have rank 0 delegates nothing» | ✅ |
| Colisión con global / ancestro / **descendiente** | ✅ |
| Owner en fresco (C3), owner con identidad canónica | ✅ |
| `hooks.onCatalogWrite` con actor; un hook que lanza no revierte | ✅ |
| Sin `listDenies`: `defineScopedRole` **y** `updateScopedRole` ⇒ 500; `deleteScopedRole` no | ✅ |
| `assignableAt`: composición sí, evaluación jamás | ✅ (y discriminante, §4.4) |
| `'global'` reservado, ningún scope lo produce | ✅ |
| `assignable_at` corrupto ⇒ 500, nunca «cualquier nivel» | ✅ |
| **`owner_scope_key` corrupto ⇒ 500 `E_AUTHZ_INTERNAL`** (tabla de errores del README) | ❌ **sin test**: `#ownerOf` lanza `AuthorizationInternalError` si la clave no es un scope, y nada lo ejecuta. Coste: 4 líneas (escribir a mano `owner_scope_key = 'basura'` y llamar `updateScopedRole`) |
| **`updateScopedRole` «never slug, level or owner»** | ❌ **sin test**: `#parseScopedRoleChanges` **ignora en silencio** claves desconocidas. Un consumidor que pase `{ slug: 'otro' }` cree que renombra y no pasa nada. La promesa es de silencio, y el silencio no está fijado. Coste: 3 líneas |
| «a no-op change writes and notifies nothing» | ✅ |
| «un store con ids 1.x no es leído por 2.2» + `--reconcile`/`--prune` | ✅ |

### 4.4 La desviación «`assignableAt` por permiso»: ¿discriminante en ambos sentidos?

**Sí, en los dos sentidos y en los dos drivers.** Medido:

- Sentido «no se evalúa»: el mutante que lo mete en `authorize` (`rolesGranting` filtrado en
  openfga + cadena filtrada en `database`) muere con **9 tests rojos**.
- Sentido «sí se compone»: el mutante que vacía `assertRoleAssignableAt` (el `grant` de ambos
  drivers) muere con **3 tests rojos** (los 3 harnesses del caso B5).
- Y en el manager, la cara `defineScopedRole`/`updateScopedRole` la cubre `manager.spec.ts`
  («al de unit tampoco se le puede AÑADIR después», con el aserto de que el rol conserva solo
  `docs:write`).

El caso del juez además fija el **positivo del positivo**: un rol de `organization` sí puede
llevar `org:settings` y se asigna con normalidad. Es un caso bien construido.

### 4.5 Resumen de huecos abiertos

| # | Hueco | Gravedad | Coste |
|---|---|---|---|
| H1 | Visibilidad **por nivel vs por conjunto** sin caso | **alta** (mutante VIVO en 3 motores × 2 drivers) | **CERRADO** en §5 |
| H2 | `effectivePermissions` heredado de `app` en la policy | media (decisión de producto sin oráculo) | **CERRADO** en §5 |
| H3 | `purgeRole`: el cero lo demuestra la FK del **espejo**, y stub≠espejo en `onDelete` | media | bajo (2 asertos + alinear stub/espejo o extender K11) |
| H4 | `database.authorize` sin `r.scope_type = a.scope_type` (paridad de drivers, desviación 3) | baja | bajo (`linkByHand` + fila a mano) |
| H5 | `owner_scope_key` corrupto ⇒ 500 (promesa del README) | baja | muy bajo |
| H6 | `updateScopedRole` ignora `slug`/`scopeType`/`owner` **en silencio** | baja | muy bajo |
| H7 | Bordes de slug 42/43 desde `defineScopedRole` | muy baja | muy bajo |
| — | `parseBindingId` «desde la derecha» no es observable (mutante equivalente) | informativo | no procede hasta 3b |

---

## 5. Parche

`…/.claude/contexto/tests-tester-fase-3.patch` (137 líneas; 3 ficheros, +87/−5). Aplica sobre
`f563465`. Cierra H1 y H2.

**1. `src/testing/contract.ts` — caso nuevo `since('2.2')` (H1).**
«La visibilidad se decide POR NIVEL, no por el conjunto de la cadena». Monta
`app → orgA → unitA1`, define `lead@unit` con owner `orgA`, asigna a `alice` en `unitA1`,
y **recuelga el árbol** (`unitA1` a la raíz, `orgA` bajo `unitA1`, `unitA2` bajo `orgA`).
Entonces `chain(unitA2) = [unitA2, orgA, unitA1, app]`: el owner **sigue en la cadena de la
pregunta** pero está **por debajo** de la asignación. Afirma `authorize`, `hasRole`,
`listRoles`, `listScopes` y `listRoleScopes` en falso, y el **inverso** que lo hace
significativo: con el árbol nuevo, una asignación dentro del owner (`unitA2`) sí concede hacia
abajo (`unitA2x`), y la de `unitA1` sigue sin revivir.

**2. `tests/contract_harness.spec.ts`.** 73 ⇒ **74**, 67 ⇒ **68**, 77 ⇒ **78**,
`primitives.length + 7` ⇒ `+ 8`, con el comentario actualizado.

**3. `tests/manager.spec.ts` — test nuevo (H2).** «Lo efectivo del actor se mide en TODA la
cadena del owner»: un actor cuyo único rol es global y de nivel `app` (`superadmin`) delega
`billing:read` en `orgA` (lo tiene solo heredado) — y las dos direcciones que lo hacen valer:
`app:manage`, que también tiene heredado, **no** se delega porque no está en la lista blanca,
y un `deny` de `billing:read` **en el owner** vuelve a cerrarlo (C2 hacia arriba).

**Prueba de que los tests prueban algo (rojo sin la feature):**

| Test nuevo | Mutante | Resultado |
|---|---|---|
| «por nivel, no por conjunto» | `chainKeysFrom` ⇒ `keys.map(() => keys)` | **MUERTO 3** — `[database · 2.2]`, `[database (sin listDenies) · 2.2]` y `[openfga · 2.2]` |
| «efectivo en toda la cadena del owner» | `defineScopedRole` mide solo en el owner (`chain.slice(0,1)`) | **MUERTO 3** (el nuevo + colisiones + C3) |

**Suites con el parche (todas exit 0, sin skip):**

| Modo | sin `:8101` | con `:8101` |
|---|---|---|
| `sqlite` | **387** | **488** |
| `sqlite-file` | **389** | **490** |
| `pg` | **470** | **649** |
| `mysql` | **470** | **649** |
| tope 3 (`:8103`) | — | **488** |

`npm run typecheck` limpio. `check:purity` verde (va dentro de `npm test`). Residuos: 0 bases
en PG/MySQL, 0 stores nuevos en `:8101`, contenedor `:8103` borrado.

---

## 6. Veredicto

### **APTA CON CORRECCIONES** para cerrar la Fase 3.

**Por qué APTA.** El lote 3B es, con diferencia, el mejor cubierto de las fases que he
verificado: **22 de 24 mutantes mueren**, las **9 reglas** de la policy de delegación tienen
cada una su caso (incluidas C2 y C3, que eran hallazgos del auditor), `assignableAt` es
discriminante en los dos sentidos y en los dos drivers, el par de capacidad `purgeRole` está
bien construido con caso negativo, los conteos del juez son literales y se ejecutan, y
**11 de los 12 huecos** que el panel §4 anticipó están cerrados — incluido el que parecía más
caro (el test de migración de **datos**, no de columnas). El diff **no relaja ni una sola
aserción** respecto a `7a28cdf`: los dos tests que desaparecen vuelven más fuertes.

**Por qué CON CORRECCIONES.** Tres cosas, en orden de importancia:

1. **Obligatoria — ya hecha, falta aplicarla.** La desviación 2 del informe («por nivel, no por
   conjunto») era una decisión de diseño **sin oráculo**: el mutante que la revierte pasa las
   484 / 643 / 643 en los dos drivers y en los tres motores. Una desviación documentada que
   ninguna prueba distingue es una promesa, no un hecho. El parche de §5 la convierte en hecho;
   **la Fase 3 no debería cerrarse sin aplicarlo** (o sin un caso equivalente).
2. **Recomendada antes de 3b.** El «todo o nada» de `purgeRole` lo demuestra hoy una FK del
   **espejo de tests** que **no coincide** con la del stub publicado (`CASCADE` vs sin
   `onDelete`), y K11 no compara acciones de FK. Sobre el esquema real, un `purgeRole` que
   olvide los vínculos pasaría. Dos asertos de cero en el caso `whenTrue` + alinear stub/espejo.
3. **Menores, para el mismo commit o el siguiente.** H4 (paridad `r.scope_type = a.scope_type`,
   afirmada en el informe y sin juez), H5 y H6 (dos promesas explícitas del README sin test,
   ~7 líneas entre las dos), H7.

Y una nota que no es corrección sino aviso para 3b: la regla de owner en `authorize` cuelga de
**un solo caso por harness**, y «`parseBindingId` desde la derecha» es hoy **inobservable**
(mutante equivalente). Ambas cosas se vuelven críticas cuando el modo `facts` cambie la forma
del `scopeKey`.
