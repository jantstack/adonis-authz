# Fase 3b · Lote 3b-2 — el modo `facts` (plan por sub-lotes)

> Base: `9478c7f` (3b-1b cerrado, 5 suites verdes). Diseño **ya decidido y medido**: modelo **(c2)** del panel 2 (`panel2-2026-08-28-juez.md`, tabla de 12 cruces; 53/53 invariantes contra OpenFGA v1.19 real). **No se rediseña: se implementa.**
> Decisión del dueño (`decisiones-dueno-2026-08-28.md`): driver `openfga` = **solo** modo `facts`; el modo `resolver` de hoy **se elimina**. Regla del catálogo reescrita: propiedad local siempre, pero un driver **puede** mantener una proyección derivada si es reconstruible, `reconcile` la cubre y nunca se lee como catálogo.

## Estado de partida (medido en el código, no supuesto)

`src/drivers/openfga_driver.ts` (1638 líneas) es **hoy** el modo `resolver`: el modelo (`openFgaAuthorizationModel`, `:251`) tiene solo `role_binding#assignee` y `deny_binding#denied`; **no existe el tipo `scope` ni el tipo `role`**, no hay opción `hierarchy`, y la jerarquía la resuelve el paquete (`this.chain(scope)` → `resolveChain` del consumidor) expandiendo la cadena a un `batchCheck` de N×M items (`authorize`, `:962`). El modo `facts` **no es una variante**: es un modelo nuevo, una escritura nueva y un `authorize` nuevo.

## Modelo destino (c2) — literal, no se negocia

```
type user / admin / integration                      # los holderTypes del consumidor
type role                                            # id = roleUuid
  define permits_<P>: [user:*, admin:*, integration:*]      # catálogo por tuplas, editable en runtime
type role_binding                                    # id = <scopeKey>|<roleUuid>
  define role: [role]
  define assignee: [<holders> with not_expired]
  define <P>: assignee and permits_<P> from role
type scope                                           # id = 'app' | '<tipo>|<uuid>'
  define parent: [scope]
  define binding: [role_binding]
  define <P>: <P> from binding or <P> from parent
  define denied_<P>: [<holders>] or denied_<P> from parent
  define can_<P>: <P> but not denied_<P>
  define ancestor: parent or ancestor from parent    # isWithin/descendantsOf nativos, 0 tuplas
```

---

## 3b-2a · El generador del modelo y la proyección del catálogo (**este lote**)

Nada de `authorize` todavía. Pieza pura, testeable sola, sin tocar el camino caliente.

| # | Pieza | Criterio de aceptación (rojo→verde) |
|---|---|---|
| **A1** | `openFgaFactsModel(holderTypes, permissions)` genera el modelo (c2) completo, con las cuatro familias de relación por permiso: `<P>`, `can_<P>`, `denied_<P>`, `permits_<P>` | Caso que compara el modelo generado con el literal de arriba para 2 permisos y 3 holderTypes; y el modelo **se escribe sin error contra el servidor real** (`OPENFGA_TEST_URL`) |
| **A2** | **Colisión de familias (S4, bloqueante del juez).** Con cuatro familias, dos permisos distintos pueden generar el mismo nombre de relación (`can_x` desde el permiso `can_x` y desde `x`). Se detecta con un `Map` nombre→origen y **lanza 422**, nunca se escribe un modelo ambiguo | Caso: permisos `['docs:read', 'can_docs:read']` ⇒ 422 nombrando **los dos** permisos y la relación en conflicto; 0 llamadas a `writeAuthorizationModel` |
| **A3** | **Techo del modelo: 262 144 bytes** (medido, ≈720 permisos). Validado en `syncAuthzCatalog` **antes** de escribir, con **aviso al 80 %** por el canal de eventos/log ya existente | Caso con un catálogo sintético que pasa del techo ⇒ 500 `E_AUTHZ_MODEL_TOO_LARGE` nombrando bytes y nº de permisos; caso al 80 % ⇒ escribe **y** avisa; caso normal ⇒ escribe y **no** avisa |
| **A4** | **Cotas de nombre**: relación ≤ **50** chars, id de objeto ≤ **256**. Un permiso cuyo `permits_<P>`/`denied_<P>` pase de 50 se rechaza en `sync` (no en runtime), nombrando el permiso y el prefijo que lo desborda | Caso negativo por cada cota, con su `status`+`code` |
| **A5** | **Proyección del catálogo**: `syncAuthzCatalog` escribe las tuplas `role:<uuid>#permits_<P>@<holder>:*` para cada par (rol, permiso) del catálogo, y **borra** las que sobran, en un `Write` por lote. Quitar un permiso de un rol = **deletes**, no reescritura del modelo | Espía: quitar 1 permiso de 1 rol con 3 holderTypes ⇒ exactamente **1** `writeTuples` con 3 deletes y 0 writes. Caso de idempotencia: `sync` dos veces seguidas ⇒ el segundo escribe **0** tuplas |
| **A6** | La proyección **nunca se lee como catálogo** (regla del dueño): ningún camino de lectura del driver consulta `role:*#permits_*` para responder qué permisos tiene un rol | Test de arquitectura/espía: `listRoles`/`rolesInChain`/`findPermission` hacen **0** `read` sobre el tipo `role` |

**Fuera de este sub-lote:** `scope`/`parent`/`binding` (3b-2b), `authorize` de un solo `Check` (3b-2c), outbox (3b-2d), capacidades y borrado del modo `resolver` (3b-2e). El tipo `scope` **se genera ya** en A1 (es parte del modelo), pero **nadie escribe sus tuplas todavía** y `authorize` sigue siendo el de hoy: el lote es aditivo y las 5 suites tienen que seguir verdes tal cual.

## 3b-2b · El árbol como hechos
`hierarchy: 'facts'` en las opciones; `scopes.attached/moved/detached` escriben `scope#parent`. **Anti-ciclos en el paquete** (FGA acepta el ciclo y responde en 3 ms — fail-open mudo): `child ≠ app`, `newParent` existe, `child ∉ ancestros(newParent)` ⇒ 422 sin escribir. `moved` = `Read` del padre + **UN** `Write` con deletes+writes (espía: exactamente 1 `writeTuples`); `Read` con >1 padre ⇒ lanza, nunca "arregla". `detached`: **hechos primero demostrando cero, arista al final** (S6).

## 3b-2c · `authorize` de un solo `Check`
`can_<P>` sobre `scope:<key>`; memo de catálogo obligatorio (invariante 5: permiso desconocido ⇒ `false`, no 400→503). Espía: **1** `check`, **0** `batchCheck`, **0** `resolveChain`. `authorizeMany` = 1 `batchCheck` de N items (uno por scope), no N×M.

## 3b-2d · Outbox y gate de construcción
`scopes.outbox?` + `authz:scopes:relay`. El driver `facts` **se niega a construirse** sin outbox y sin `acceptScopeDriftRisk: true`. El lag del relay va **literal** en el README como fail-open temporal, no como "cambios fuera del servicio".

## 3b-2e · Capacidades, límites y borrado del `resolver`
`singleCheckAuthorize: true`, `roleInheritanceNative: false`, `listObjectsInherited: false`, cada una con **caso negativo** (nunca un skip). `purgeRole` pasa a **soportado** (con `scope#binding` sí se enumera): se retira el 500 y la capacidad `purgeRole: false`, y `defineScopedRole` deja de negarse. Se borra el camino `resolver`.

## Aceptación del lote 3b-2 completo
Los 83 casos del juez pasan contra `facts` con árbol SQL en PG y MySQL; 5 modos verdes; tester en worktree (mutantes por pieza) + auditor sobre el árbol principal (**nunca en paralelo**) + `/code-review`; correcciones; commit.
