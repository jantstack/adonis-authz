# Panel 2 · 28-08-2026 — Auditor de seguridad contra `propuesta-jerarquia-hechos-2026-08-28.md`

> Entradas: `CLAUDE.md`, `propuesta-jerarquia-hechos-2026-08-28.md`, `panel-2026-08-28-juez.md`.
> Informe anterior (`panel-2026-08-28-seguridad.md`) **no se repite**: aquí solo hay hallazgos de la
> propuesta nueva (modo `facts`, `scopes.*`, `enumerateEdges`, migración, `authz:scopes:verify`).
>
> **Todo lo marcado ✅ se ejecutó** contra `http://localhost:8101` (OpenFGA **v1.19.0**, datastore
> postgres, defaults de fábrica) en un store temporal `authz-panel2-sec`
> (`01M14AV07HK7GDBNCY218Q7A20`), **borrado al terminar** (`HTTP 204`, verificado: ya no aparece en
> `/stores`). Modelo construido a mano según el borrador de la propuesta (§ "Modelo FGA generado en
> modo facts"). El paquete **no se modificó**.

## Veredicto en una línea

**Inseguro tal cual**: el modelo borrador no ata la asignación al scope (un `grant` concede en TODOS
los scopes donde el rol esté vinculado, reproducido), FGA evalúa ciclos de `parent` sin quejarse
convirtiendo la herencia en bidireccional (reproducido), y el drift SQL↔tuplas no es un riesgo
operativo sino una **fuga incondicional**: el rollback de la transacción del consumidor no deshace la
escritura en FGA. Modo `facts` es viable, pero no con el diseño escrito.

---

## Hallazgos (ordenados por severidad)

### 🔴 S1 · El modelo borrador **no ata la asignación al scope**: un `grant` concede en todos los scopes donde el rol esté vinculado

- **Escenario**: catálogo con rol `auditor` vinculado (tupla `scope:<key>#docs_write_role@role:auditor`)
  en `organization|P` y en `organization|Q` (lo normal con catálogo global: una tupla por scope) →
  el admin de P hace `grant(user:UZ, 'auditor', organization|P)`, que en el borrador es
  `role:auditor#assignee@user:UZ` → **UZ tiene `docs:write` también en `organization|Q`**, y en
  cualquier otro scope donde el rol esté vinculado.
- **Evidencia**: ✅ reproducido. Tuplas `user:UZ#assignee@role:RX`,
  `role:RX#docs_write_role@scope:organization|P`, `role:RX#docs_write_role@scope:organization|Q`;
  `Check(user:UZ, can_docs_write, scope:organization|P)` → `allowed:true` y
  `Check(user:UZ, can_docs_write, scope:organization|Q)` → **`allowed:true`**. En el borrador
  (`propuesta:60-71`) la única tupla que expresa "UZ tiene el rol" es `role#assignee`, que **no lleva
  scope**: el scope solo aparece en la tupla de catálogo. Con un catálogo global la conclusión es
  "un grant = acceso global".
- **Steelman del defensor**: "el borrador dice explícitamente que la codificación del catálogo es la
  *incógnita central* y ofrece la opción (c) `role_binding:<scopeKey>|<roleUuid>`". → **No me
  convence del todo**: la propuesta plantea (a)/(b)/(c) como alternativas de *eficiencia del
  catálogo*, no advierte que (a) y (b) **rompen el invariante 1 y el 4 de facto**. Solo (c) —que es
  el diseño de hoy— conserva la semántica; y (c) obliga a un salto TTU extra
  (`scope#has_binding` → `role_binding#assignee`) que hay que probar contra el límite de
  profundidad de S9 antes de aprobar nada. Que la única opción válida sea la que ya existe cambia el
  coste de la fase.
- **Mitigación mínima**: fijar por contrato que el objeto que porta la asignación **debe** contener
  el scopeKey; prohibir cualquier codificación en la que dos scopes compartan el objeto de asignación.

### 🔴 S2 · FGA **no detecta** ciclos de `parent`: los evalúa y la herencia pasa a ser bidireccional (invariante 1)

- **Escenario**: árbol `app ← organization|A ← unit|A1`; un `moved(app, unit|A1)` erróneo (o un
  `attached` con padre mal calculado, o el drift de S5) escribe `scope:app#parent@scope:unit|A1` →
  cualquier grant en `organization|A` concede **en la raíz `app` y por tanto en todo el sistema**.
- **Evidencia**: ✅ reproducido. Antes del ciclo `Check(user:U1, can_docs_write, scope:app)` =
  `false`; tras escribir la arista, **`true`**, en **7 ms** (no hay bucle, no hay deadline, no hay
  error: FGA corta la recursión y responde). Idéntico con un ciclo de dos nodos
  (`scope:Y#parent@scope:X` + `scope:X#parent@scope:Y`): un grant en X concede en Y. Un `deny` dentro
  del ciclo también se propaga a todo el ciclo (`Check(U1, can_docs_write, scope:X)` = `false` tras
  denegar en Y) — la contaminación va en las dos direcciones.
- **Steelman del defensor**: "el consumidor no crea ciclos; su árbol es un árbol". → **No me
  convence**: en modo `facts` el árbol de FGA no es el árbol del consumidor, es una *copia* mantenida
  por llamadas sueltas (`scopes.moved`) sujetas a drift (S5), a reintentos y a import (S7). El punto
  del hallazgo es que **FGA no es una segunda línea de defensa**: acepta la arista y responde `true`
  sin señal alguna. La única barrera sería `verify`, que corre después.
- **Mitigación mínima**: `scopes.moved/attached` deben **rechazar en el paquete** (antes de escribir)
  cualquier arista cuyo `parent` esté en la cadena de `resolveAncestors(child)` o cuyo `child` sea la
  raíz `app`; y `verify` debe reportar ciclos, no solo diferencias de aristas.

### 🔴 S3 · `moved` en dos requests: una ventana pierde el deny heredado, la otra cruza tenants

- **Escenario A (delete → write)**: `unit|A1` se queda **sin padre** durante la ventana. Un holder con
  grant DIRECTO en `unit|A1` y `deny` de ese permiso en `organization|A` pasa de `false` a **`true`**
  hasta que entre el segundo request. Fail-open puro.
- **Escenario B (write → delete)**: `unit|A1` queda con **dos padres**. Todos los holders con rol en
  `organization|B` obtienen acceso a `unit|A1`, que pertenece a `organization|A`. Si el segundo
  request falla, el estado es permanente y **`enumerateEdges` no lo ve como error** (el árbol SQL
  tiene un padre; FGA tiene dos: `verify` sí lo detecta, pero solo cuando corra).
- **Evidencia**: ✅ reproducido el efecto B: tras escribir
  `scope:organization|B#parent@scope:unit|A1` (con `organization|A` todavía como padre),
  `Check(user:U9, can_docs_write, scope:unit|A1)` = `true` para un usuario cuyo único rol está en
  `organization|B`. ✅ Y **FGA sí permite hacerlo atómico**: un `Write` con `deletes` y `writes` en la
  misma request se aplica o falla entero (verificado: un `delete` de tupla inexistente **abortó** el
  `write` que iba en la misma request → `scope:atomico` no quedó escrito). El diseño escrito no lo
  exige, y el driver de hoy hace `deleteTuples()` + `writeTuples()` en **dos** llamadas
  (`openfga_driver.ts:516-521`), que es exactamente el patrón peligroso.
- **Steelman del defensor**: "es un instante de milisegundos". → **No me convence**: (1) el segundo
  request puede fallar y entonces no son milisegundos sino para siempre; (2) el escenario A es
  fail-open de un deny, y el contrato dice "nunca se traduce una caída a un false" — aquí se traduce
  una caída a un **true**; (3) el arreglo es gratis (una sola request).
- **Mitigación mínima**: `moved` = **un único `Write`** con `deletes` + `writes`; prohibido el patrón
  de dos llamadas. Caso de contrato: matar el proceso entre las dos llamadas debe ser imposible por
  construcción.

### 🔴 S4 · Colisión de nombres de relación por **familias de prefijos**: el generador la colapsa en silencio y anula el deny

- **Escenario**: el catálogo del consumidor contiene `docs:write` y **`can_docs_write`** (slug
  perfectamente válido: `CATALOG_SLUG_FORMAT` en `catalog.ts:23` admite `_`). El generador produce
  para el primero `{docs_write, docs_write_role, denied_docs_write, can_docs_write}` y para el segundo
  `{can_docs_write, can_docs_write_role, denied_can_docs_write, can_can_docs_write}`: la clave
  `can_docs_write` se define **dos veces**. Al construirse como objeto JS, la segunda gana **antes de
  serializar** → FGA nunca ve el duplicado y publica el modelo sin una queja. Resultado:
  `can_docs_write` deja de ser `docs_write but not denied_docs_write` y pasa a ser la relación del
  *otro* permiso.
- **Acción del atacante**: un usuario con el rol que concede el permiso inocuo `can_docs_write`
  y **con un deny explícito de `docs:write`** llama a un endpoint protegido por `docs:write`.
- **Resultado**: `authorize` = **true**. Se salta el deny y se salta el catálogo.
- **Evidencia**: ✅ reproducido de punta a punta. El modelo con la clave duplicada literal en el JSON
  sí lo rechaza FGA (`duplicate map key "can_docs_write"`), pero **el camino real** (objeto JS →
  `JSON.stringify`) colapsa la clave y el modelo se publica (`01M14B2HPXE9S96M5NP7Q8977S`). Con ese
  modelo: `user:U2` tiene `denied_docs_write` en `organization|A` (verificado: `denied_docs_write` en
  `unit|A1` = `true`), no tiene `docs_write` (`false`), y sin embargo
  `Check(user:U2, can_docs_write, scope:unit|A1)` = **`allowed:true`**.
- **Steelman del defensor**: "la propuesta ya dice que el sync debe rechazar la colisión
  `docs:write` vs `docs_write`". → **No me convence**: la propuesta (`:75`) contempla **una** colisión
  (la del encoding `:`→`_`) y la familia real son cuatro: `X` vs `can_X`, `X` vs `denied_X`, `X` vs
  `X_role`, y `X` vs `Y` donde `encode(X)==encode(Y)`. Y el fallo es **silencioso**: no hay error de
  FGA en el que apoyarse, la última definición gana.
- **Mitigación mínima**: el generador construye el mapa de relaciones con un `Map` y **lanza** al
  detectar una clave repetida; el sync valida que ningún slug del catálogo, tras encodear, colisione
  con `can_*`, `denied_*` ni `*_role` de otro slug.

### 🔴 S5 · Drift: el rollback de la transacción del consumidor **no deshace** la escritura en FGA

- **Precondición**: `scopes.moved(unit|A1, organization|B)` se llama "dentro de la trx del consumidor
  y antes del commit" (propuesta, problema 1).
- **Acción**: cualquier statement posterior de esa transacción falla (una constraint, una validación,
  un timeout de pool, un deploy). No hace falta un crash: basta un `rollback`.
- **Resultado**: SQL sigue diciendo `unit|A1 ∈ organization|A`; FGA dice `organization|B`. En modo
  `facts` **FGA es el PDP**: todos los holders con rol en `organization|B` tienen acceso a una unidad
  del tenant A, y la aplicación (que lista y audita contra SQL) **no puede verlo**. La ventana no es
  "el hueco entre dos operaciones": es **desde el rollback hasta la próxima corrida de `verify`**.
- **Evidencia**: ✅ el mecanismo de escalada está verificado (S3-B: dos padres ⇒ `true` cruzado; y la
  variante de un solo padre nuevo es idéntica). 🟡 el orden exacto de la llamada depende de cómo lo
  implemente el consumidor — pero **las dos alternativas fallan**:
  - *notify-then-commit* (la que propone el documento): fuga en cada rollback, como arriba.
  - *commit-then-notify*: la excepción del paquete llega **después** del commit ⇒ el nodo existe en
    SQL sin arista en FGA ⇒ huérfano ⇒ los denies heredados del ancestro **no aplican** mientras los
    grants directos del nodo sí. Fail-open dirigido al deny.
- **¿Llega `verify` a tiempo?** No, y encima es caro: ✅ `Read` **no admite filtrar solo por
  relación** (`{"tuple_key":{"relation":"parent","object":"scope:"}}` →
  `"the object type field is required and both the object id and user cannot be empty"`), así que
  `verify` o escanea **todo el store** paginando (con `--request-timeout` de 3 s por request) o hace
  **un `Read` por nodo** del árbol. En ambos casos la cadencia realista es de minutos u horas: la
  ventana de escalada es del orden de la cadencia del cron, no de milisegundos.
- **¿Lo cierra un outbox en la BD del consumidor?** Lo **acota**, no lo cierra. Con outbox
  (intención escrita en la misma trx + relay a FGA) desaparece la fuga por rollback y la ventana pasa
  a ser el lag del relay (segundos). Pero durante ese lag FGA responde con el árbol **viejo**, y la
  dirección del error importa: para `attached` el retraso es fail-closed en los grants y **fail-open
  en los denies heredados**; para `moved`, el tenant **antiguo conserva el acceso** durante todo el
  lag. Un outbox no puede arreglar eso porque FGA no sabe que está desactualizado.
- **Steelman del defensor**: "`verify` es la red y el problema 1 está declarado y aceptado". →
  **No me convence como está redactado**: el documento lo presenta como "cambios del árbol fuera del
  servicio (UPDATE a mano, seeders, fixtures)", es decir *mal uso*. El hallazgo es que el **uso
  correcto** también fuga, sin crash, con un simple rollback.
- **Mitigación mínima (responde P5)**: el paquete **sí** debe proveer el outbox —tabla de stub +
  puerto `enqueueScopeChange` + comando relay `authz:scopes:relay`— porque es la única forma de que
  la escritura en FGA herede la atomicidad de la trx del consumidor; y `verify` debe ser **una
  segunda línea que reporta**, jamás un reparador automático (ver S18).

### 🔴 S6 · `detached` a medias: borrar la arista antes de terminar la purga deja grants **indenegables**

- **Escenario**: se borra `organization|A` con 4.000 grants/denies en su subárbol. La purga va en
  chunks (✅ límite verificado: **100 operaciones por `Write`**, `exceeded_entity_limit`), sin
  transacción común. Si el orden es "borro la arista → purgo" y la purga muere en el chunk 3 de 40,
  los grants supervivientes quedan en nodos **huérfanos**: el `deny` que el operador tenía puesto en
  `organization|A` ya no se hereda porque ya no hay arista.
- **Resultado**: holders con acceso vivo a scopes "borrados", inmunes a los denies del ancestro y sin
  UI que los muestre (en SQL el nodo ya no existe).
- **Evidencia**: ✅ límite de 100 y no-atomicidad entre requests verificados; ✅ la pérdida de deny
  por falta de arista es el mismo mecanismo de S3-A. 🟡 el orden concreto lo fija la implementación.
- **Steelman del defensor**: "el paquete lanza y `verify` lo detecta". → **A medias**: `verify`
  compara **aristas**, y aquí la arista está correctamente ausente en ambos lados; lo que sobra son
  **hechos**, que ningún verificador de la propuesta mira.
- **Mitigación mínima**: `detached` purga **primero** los hechos (con conteo demostrado a cero) y la
  arista **al final**, en ese orden; y un `authz:facts:verify` que reporte hechos sobre scopes que
  `enumerateEdges` no conoce.

### 🔴 S7 · Import idempotente con `onDuplicateWrites: Ignore`: la condición **no es parte de la clave** ⇒ caducidades que se evaporan y padres que se acumulan

- **Escenario 1 (caducidad)**: el store no está vacío (re-import, migración `resolver → facts`,
  restore). Existe `user:UX#assignee@role:R` **sin condición** (grant permanente de una era
  anterior). El import lee de SQL el mismo grant, ahora **con `expiresAt`**, y escribe la misma clave
  con `condition: not_expired`. FGA responde `cannot write a tuple which already exists`; el
  importador lo **ignora por diseño** (`openfga_driver.ts:339-341`) y la tupla **conserva la
  condición vieja**: el acceso sigue siendo permanente y el conteo del import dice que se importó.
- **Escenario 2 (aristas, el nuevo)**: el import de aristas de `enumerateEdges` escribe
  `scope:child#parent@scope:nuevoPadre`. Si el store ya tenía `scope:child#parent@scope:viejoPadre`,
  **la clave es distinta** (el padre va en el campo `user`) ⇒ no hay duplicado que ignorar ⇒ **el
  nodo queda con dos padres** ⇒ cruce de tenants (S3-B), y el import reporta éxito.
- **Evidencia**: ✅ escenario 1 reproducido literalmente: tras el segundo write, `Read` devuelve
  `"condition": null` y `Check` con `current_time` de hoy = `allowed:true` pese a un `valid_until` de
  2020. ✅ escenario 2 es aritmética de claves + el multi-padre ya reproducido.
- **Steelman del defensor**: "el import exige ventana y store vacío". → **No me convence**: el
  documento vende el import como **idempotente** ("re-ejecutar no duplica",
  `openfga_driver.ts:264`), y `resolver → facts` es explícitamente un import **sobre un store
  poblado** (`propuesta:81`: "resolver ↔ facts: solo aristas").
- **Mitigación mínima**: el import falla si el store no está vacío salvo `--reconcile`, y el modo
  reconcile hace **delete+write** de las claves que difieren en condición y **borra** las aristas que
  `enumerateEdges` no reporta; los conteos distinguen `written` / `ignored` / `conflicting`.

### 🟠 S8 · P4 · `scopes.*` opcional en `database` es un agujero **diferido** al cambio de driver

- **Escenario**: el consumidor desarrolla en `database` y, siguiendo el texto de la propuesta
  ("recomendación: llamar siempre", `:46`), **no** llama a `scopes.*` porque no le hace falta. Un año
  después cambia a `openfga` `facts` y corre `openfga:import`. El import siembra las aristas de
  `enumerateEdges` en el momento de la migración, pero a partir de ahí **cada nodo nuevo nace sin
  arista**.
- **Acción**: se crea `unit|A9` bajo `organization|A`; un holder tiene grant directo en `unit|A9` y
  el operador tiene un `deny` de ese permiso puesto en `organization|A`.
- **Resultado**: en `database` respondía `false`; en `facts` responde **`true`** — el deny heredado no
  existe porque no hay arista. La regresión aparece **solo** donde hay deny, que es la parte que nadie
  prueba.
- **Evidencia**: ✅ mecanismo (nodo huérfano ⇒ sin herencia) reproducido; ✅ el `database` driver no
  necesita las aristas (`database_driver.ts:50-56` lee el árbol de `resolveAncestors` en cada
  `authorize`), así que **nada falla en desarrollo**.
- **Steelman del defensor**: "por eso la recomendación es llamarlo siempre". → **No me convence**:
  una recomendación no es un mecanismo, y aquí el castigo por ignorarla no se paga en el momento de
  ignorarla sino en la migración, meses después, en forma de deny perdido.
- **Respuesta a P4**: **sí puede ser opcional, pero no gratis**. Condición mínima: el driver `facts`
  se **niega a servir** hasta que exista un sello de bootstrap coherente (p. ej. una tupla
  `scope:app#hierarchy_generation@marker:<n>` escrita por el import y comparada con un contador que
  el consumidor incrementa en cada `scopes.*`); o, más barato, `authz:scopes:verify` como **gate de
  arranque** del driver `facts` (falla ⇒ el manager no construye el driver). Sin una de las dos, el
  "cambio de driver es migración de hechos, no reescritura" del `CLAUDE.md` se cumple en la API y se
  incumple en la semántica.

### 🟠 S9 · Límite de profundidad de FGA: **el subárbol profundo deja de responder** (503) y no hay equivalente en `database`

- **Escenario**: árbol con más de ~23 saltos de `parent` (jerarquías de expedientes, BOM, ubicaciones
  geográficas, o un atacante que solo tenga permiso para **crear sub-unidades anidadas**).
- **Resultado**: `Check` devuelve `authorization_model_resolution_too_complex` (HTTP 400) → el guard
  del driver lo convierte en `AuthorizationBackendError` (503) → **todo el subárbol deja de
  autorizar**, para todos los holders, indefinidamente. Es fail-closed, pero es una **denegación de
  servicio persistente creable por un usuario de bajo privilegio**.
- **Evidencia**: ✅ medido con una cadena de 60 nodos: profundidad 20/21/22/23 → `allowed:true`;
  profundidad 24, 25, 26, 30 y 60 → `authorization_model_resolution_too_complex`. Corte entre 23 y 24
  con `--resolve-node-limit` por defecto (25, verificado en `openfga run --help`). ✅ **No** hay
  fail-open asociado: con grant a 1 salto y deny a 31, el `Check` de `can_docs_write` **falla** en vez
  de conceder (el `difference` no devuelve `true` con la rama del deny rota).
- **Steelman del defensor**: "nadie tiene árboles de 24 niveles". → **Parcialmente**: cierto para
  `organization/unit`, falso en cuanto la opción (c) del catálogo añada saltos TTU por nivel (cada
  `has_binding → assignee` consume presupuesto) y falso si el consumidor modela ubicaciones o
  expedientes. Y el punto duro es otro: **`database` no tiene ese límite**, así que un árbol legal en
  un driver es un 503 en el otro. Eso rompe "el mismo juez para los dos drivers".
- **Mitigación mínima**: `maxDepth` declarado en `capabilities`, verificado por `authz:scopes:verify`
  (profundidad máxima observada en `enumerateEdges`) y **caso negativo del contrato**: árbol de
  N+1 niveles ⇒ el modo `facts` debe declararse incapaz, no descubrirse en producción.

### 🟠 S10 · Catálogo como tuplas por scope: un cambio de catálogo deja de ser atómico y **no tiene verificador**

- **Escenario**: se quita `docs:write` del rol `auditor` (con la corrección L0.9 `prune:'links'`, que
  en SQL es transaccional). En `facts` eso obliga a borrar `scope:<key>#docs_write_role@role:auditor`
  en **cada scope** donde el rol esté vinculado (opciones (a)/(c) del borrador). Con 3.000 tenants son
  30 requests de 100 deletes, sin transacción común.
- **Resultado**: si falla en el request 12, en 1.800 tenants el permiso **sigue concedido** mientras
  el SQL dice que ya no. Es exactamente el N1 ("privilegio zombi") del informe anterior, pero ahora
  **con estado duplicado y parcial**, y `authz:scopes:verify` **solo compara aristas**: no mira las
  tuplas de catálogo.
- **Evidencia**: ✅ límite de 100 ops/Write y no-atomicidad entre requests verificados; 🟡 el número
  de tuplas depende de la opción de catálogo que se elija (con (a) descartada, ver S-nota, son
  O(scopes × vínculos)).
- **Nota verificada que descarta la opción (a)**: **el wildcard de objeto no existe en FGA**:
  `scope:*#docs_write_role@role:R` → `"the 'object' field cannot reference a typed wildcard"`. La
  opción "una tupla con `scope:*`" del borrador (`:73`) es **imposible**, no cara. (Y el wildcard de
  sujeto sí existe pero está bien contenido: `user:*` en `denied_docs_write` fue rechazado porque el
  modelo no lo declara como tipo permitido — el import no puede colar un `user:*` accidental salvo
  que el generador lo declare.)
- **Steelman del defensor**: "el catálogo cambia en deploys, no en runtime". → **No con `catalog/`
  (2.1)**: la propuesta dice explícitamente que con roles por tenant "el catálogo cambia en runtime
  sin redeploy" (`:73`). Entonces el camino no atómico se recorre **en caliente**.
- **Mitigación mínima**: el verificador debe cubrir **los tres conjuntos** (aristas, catálogo, hechos)
  o el diseño no es auditable; y el sync de catálogo en `facts` debe ser reintentable e idempotente
  con marca de generación.

### 🟠 S11 · La caché de `Check` está **fuera del control del paquete**: hasta 10 s de fail-open tras un `revoke`/`deny`

- **Escenario**: el operador arranca OpenFGA con `--check-query-cache-enabled` (recomendado en
  cualquier despliegue con carga). Un `deny` o `revoke` recién escrito **no se ve** durante el TTL.
- **Resultado**: hasta **10 s** (default) en los que `authorize` sigue diciendo `true` tras revocar.
  Con `database` esto no existe.
- **Evidencia**: ✅ leído de `openfga run --help` en el binario del `:8101`:
  `--check-query-cache-enabled` (default **false** en esta instancia, por eso no lo reproduje aquí),
  `--check-query-cache-ttl` default **10s**, y textualmente *"turns Check and ListObjects into
  eventually consistent APIs. If the request's consistency is HIGHER_CONSISTENCY, this cache is not
  used"*. ✅ `"consistency":"HIGHER_CONSISTENCY"` aceptado por el `Check` del `:8101`.
- **Steelman del defensor**: "es config del operador, no del paquete". → **No me convence**: el
  paquete publica un contrato ("quitar el deny restaura", "re-revoke es no-op seguro") que una flag
  del servidor invalida en silencio. El paquete **puede** protegerse: enviar `HIGHER_CONSISTENCY`.
- **Respuesta a "¿`HIGHER_CONSISTENCY` lo cierra del todo?"**: cierra la ventana **dentro de FGA**
  (caché y réplicas), y por tanto cierra `grant`+`authorize` y `revoke`+`authorize` en el mismo
  request. **No cierra** la ventana de S5 (drift SQL↔FGA), que es de otra naturaleza, ni la ventana
  de las dos llamadas de `grant` (`delete`+`write`, `openfga_driver.ts:490-521`), donde `authorize`
  responde `false` legítimamente.
- **Mitigación mínima**: `consistency: HIGHER_CONSISTENCY` **por defecto** en todo `Check` que
  participe de una decisión, con opt-out explícito y documentado como "acepto N segundos de
  fail-open".

### 🟠 S12 · `{type:'app', uuid:X}` colapsa a la raíz ⇒ `attached` **reparenta el `app`**

- **Escenario**: `scopeKey` devuelve `'app'` para cualquier scope de tipo `app`, ignorando el uuid
  (`openfga_driver.ts:86`). Un consumidor que construya `ScopeRef` desde una fila/param
  (`{type: row.scope_type, uuid: row.uuid}`) puede llamar
  `scopes.attached({type:'app', uuid:'A9'}, organization|A)` creyendo que cuelga un "app tenant" de
  una organización.
- **Resultado**: se escribe `scope:app#parent@scope:organization|A` ⇒ **la raíz pasa a heredar de la
  organización** ⇒ cualquier grant en esa organización concede en `app` y, por la herencia hacia
  abajo, en **todo el sistema**.
- **Evidencia**: ✅ el efecto está reproducido en S2 (la arista `scope:app#parent@…` convirtió un
  `Check` sobre `scope:app` de `false` a `true`); ✅ el colapso de `{app, uuid}` está en el código
  (`:86`) y el juez ya lo aceptó como 422 en 2.0 (L0.10). Lo nuevo es la **magnitud**: en modo
  `resolver` era una confusión de scope; en `facts` es reparentar la raíz.
- **Steelman del defensor**: "L0.10 ya lo cierra con 422 en ambos drivers". → **Me convence**,
  siempre que L0.10 entre **antes** que el modo `facts` y que la validación esté en el **manager**
  (que es donde vive `scopes.*`), no solo en los drivers.
- **Mitigación mínima**: dependencia explícita `facts` → L0.10; y `attached/moved` rechazan `app`
  como `child`.

### 🟡 S13 · Límites de longitud: un catálogo/árbol legal en `database` es **impublicable** en `facts`

- **Escenario**: permiso con slug de más de ~46 caracteres (p. ej.
  `expediente.sancionador:autorizar_prorroga_excepcional`) ⇒ la relación generada `can_<slug>` supera
  50 chars ⇒ **el modelo entero se rechaza** ⇒ `syncAuthzCatalog` en `facts` no puede publicar nada.
  Análogamente, un `scopeKey` largo (tipo + uuid) supera el id de objeto.
- **Evidencia**: ✅ relación de 64 chars →
  `relations_invalid_pattern: value does not match regex pattern "^[^:#@\s]{1,50}$"`. ✅ objeto de 300+
  chars → `invalid TupleKey.Object: value does not match regex pattern "^[^\s]{2,256}$"`. ✅ dato
  colateral: los nombres de relación **sí admiten `.` y `|`** (probado: relación `docs.write`
  publicada sin problema) — el encoding `:`→`_` de la propuesta es una elección, no una obligación, y
  es justamente la que produce las colisiones de S4.
- **Steelman del defensor**: "se valida en el sync". → **Me convence si se valida en `database`
  también**; si solo se valida en `facts`, la divergencia se descubre el día de la migración.
- **Mitigación mínima**: `assertValidSlug` con límite de longitud **en el núcleo** (ambos drivers) y
  `scopeKey` con longitud máxima verificada en el manager.

### 🟡 S14 · Nombres reservados: un permiso llamado `parent` **invalida el modelo entero**

- **Escenario**: el catálogo incluye el permiso `parent` (o `assignee` en un tipo donde colisione).
  El generador produce un `scope#parent` que es a la vez la relación de jerarquía y una relación
  derivada.
- **Resultado**: ✅ FGA rechaza el modelo completo:
  `invalid_authorization_model: the 'scope#parent' relation is referenced in at least one tupleset and thus must be a direct relation`.
  El sync de catálogo queda **bloqueado para todo el sistema** por un slug; y si el sync escribe SQL
  primero y publica después, el SQL queda con un permiso que FGA no conoce ⇒ `authorize` de ese
  permiso → 400 → **503** (verificado: `invalid relation: relation 'scope#can_docs_write' not found`).
- **Steelman del defensor**: "es fail-closed y ruidoso". → **Me convence como severidad**, pero es
  una DoS trivial de provocar (un slug en un config) y hoy no hay lista de reservados.
- **Mitigación mínima**: lista de slugs reservados (`parent`, `assignee`, y los prefijos de S4)
  rechazada por `assertValidSlug` en el núcleo, no en el driver.

### 🟡 S15 · Mayúsculas/collation: el mismo deny bloquea en `database`+MySQL y **no** en `facts`

- **Escenario**: `deny(U, 'docs:write', {type:'Unit', uuid:'A1'})` (el type viene de un modelo con
  otra capitalización) y `authorize(U, 'docs:write', {type:'unit', uuid:'A1'})`.
- **Resultado**: FGA distingue mayúsculas (✅ verificado: `Read` de `scope:Unit|A1` devuelve 0 tuplas
  cuando las tuplas están en `scope:unit|A1`); MySQL con collation `*_ci` **no** distingue ⇒ en
  `database` el deny bloquea y en `facts` no. Migrar de uno a otro **cambia respuestas** sin que
  ningún conteo lo note.
- **Steelman del defensor**: "el consumidor no debe mezclar capitalizaciones". → **Me convence a
  medias**; el problema es que el contrato de migración ("mismas respuestas para un set fijo de
  preguntas", `propuesta:82`) **no lo detectará** salvo que el set incluya un caso con capitalización
  mixta.
- **Mitigación mínima**: normalizar/rechazar en el manager (`SubjectRef.type`, `ScopeRef.type`) y un
  caso del contrato de migración con capitalización mixta. Responde parcialmente a P3: **la migración
  no es sin pérdida** si el motor SQL es case-insensitive.

### 🟡 S16 · `listObjects` **no comparte el límite de profundidad** del `Check` ⇒ el listado dice sí donde la decisión da 503, y enumera la herencia

- **Escenario**: mismo árbol profundo de S9.
- **Resultado**: ✅ `ListObjects(user:U1, can_docs_write, scope)` devolvió **63 objetos** incluyendo
  `scope:d60`, mientras `Check(user:U1, can_docs_write, scope:d31)` devolvía
  `authorization_model_resolution_too_complex`. El listado y la decisión **se contradicen**.
- **Segundo efecto**: ese mismo `ListObjects` devuelve **todo el subárbol heredado**, no las
  asignaciones directas. Si `listScopes`/`authorizedScopes` se implementan sobre él en modo `facts`,
  el **invariante 7** ("los `list*` no enumeran herencia") se rompe por construcción, y con él vuelve
  el 🔴 E1 del informe anterior.
- **Steelman del defensor**: "en `facts` `listScopes` se implementará con `Read`, como decidió el
  juez". → **Me convence si se escribe como restricción explícita**; hoy la propuesta no dice nada de
  los `list*` en modo `facts`, y `ListObjects` es la implementación obvia.
- **Mitigación mínima**: prohibir `ListObjects` en la ruta de los `list*` del contrato; declararlo en
  `capabilities`.

### 🟡 S17 · Un solo `Check` mezcla deny y grant ⇒ **el `context` es obligatorio siempre**, y su ausencia es 400 (o 500)

- **Escenario**: hoy el driver consulta los denies **sin `context`** (`openfga_driver.ts:441-445`) y
  se lo puede permitir porque las tuplas de deny no llevan condición. En `facts` hay **un único
  `Check`** que atraviesa deny y grant: si el `context` falta y hay **cualquier** tupla condicionada
  en el camino, FGA falla la petición entera.
- **Evidencia**: ✅ `Check` sin `context` sobre una relación con tupla condicionada →
  `failed to evaluate relationship condition: 'not_expired' … is missing context parameters
  '[current_time]'` (400 → 503 por el guard). ✅ Peor en enumeración: `ListObjects` sin `context`
  devuelve **`Internal Server Error`** (500) — un error interno del backend cruzando la abstracción
  como 500 y no como 503.
- **Steelman del defensor**: "el driver siempre pone el `context`". → **Me convence para el camino
  feliz**; el hallazgo es que en `facts` deja de haber margen: la bomba del "deny con caducidad"
  (riesgo 9 del juez) pasa de afectar a una consulta a **tumbar la decisión completa**.
- **Mitigación mínima**: el `context` se construye en un único punto del driver y un caso del
  contrato lo fija ("cualquier `Check` del modo `facts` lleva `current_time`").

### 🟡 S18 · `verify` / `enumerateEdges` como **oráculo** y como vector

- **Escenario A (coste/oráculo)**: `verify` necesita el árbol entero de las dos fuentes.
  `enumerateEdges` obliga al consumidor a exponer una lectura **de todo el árbol, sin tenant**, que
  antes no existía; si alguien la cablea a una ruta (o el comando corre en CI con salida a logs), el
  diff imprime `type|uuid` de **todos** los tenants. No es escalada, es fuga de identificadores y de
  la topología comercial (cuántas unidades tiene cada cliente).
- **Escenario B (el peligroso)**: si `verify` gana un `--fix` que reescribe FGA desde
  `enumerateEdges`, entonces **`enumerateEdges` se convierte en el mecanismo de concesión**: un bug
  (o un `WHERE` sin filtro, o un tenant que devuelve aristas ajenas) reescribe la jerarquía de
  autorización de todo el sistema en una sola corrida, sin revisión.
- **Evidencia**: ✅ el coste está medido (S5: `Read` no filtra por relación sin object id/user).
  🟡 el resto es diseño: `--fix` no está en la propuesta, pero es el paso siguiente evidente.
- **Steelman del defensor**: "es un comando de operador, ya tiene acceso al store". → **Me convence
  para A**, no para B: "tiene acceso" no es lo mismo que "una corrida rutinaria reescribe el árbol".
- **Mitigación mínima**: `verify` **read-only** por contrato; si algún día hay `--fix`, que exija un
  plan aprobado (fichero de diff firmado por la corrida anterior) y tope de aristas.

### ⚪ S19 · El reloj de la caducidad es el del **cliente**

`current_time` lo pone la app (`checkContext()`, `openfga_driver.ts:116-118`). Un servidor con reloj
atrasado —o un pod con NTP roto— **revive todas las asignaciones caducadas** a la vez. FGA no tiene
tiempo propio en las condiciones. No cambia con `facts`, pero en `facts` es el **único** mecanismo de
expiración que queda (invariante 3). Mitigación mínima: caso de contrato con reloj inyectable
(Fase 2.5) + aviso en la doc de que la caducidad es tan fiable como el NTP del PDP.

### ⚪ S20 · Las tuplas **sobreviven** al cambio de modelo ⇒ resurrección al re-añadir un permiso

✅ Verificado: publiqué un modelo **sin** `docs_write_role` y `Read` siguió devolviendo
`role:R#docs_write_role@scope:organization|A`. Si el catálogo quita un permiso (y con él las
relaciones del modelo) pero nadie borra las tuplas, **volver a añadir el permiso resucita los
vínculos y los grants viejos**. Con `prune:'links'` (L0.9) en SQL esto queda asimétrico: SQL limpio,
FGA sucio. Mitigación mínima: el sync en `facts` borra las tuplas de las relaciones que deja de
publicar, o el import/verify las reporta como huérfanas.

### ⚪ S21 · Errores en vuelo contra el modelo viejo: fail-closed, pero **503, no `false`**

✅ Verificado en las dos direcciones: `Check` con `modelId` viejo sobre una relación nueva →
`validation_error: invalid relation ... not found` (400); `Check` con el modelo nuevo sobre una
relación retirada → lo mismo. El guard lo traduce a 503, que es correcto (nunca fail-open) pero
significa que **publicar un catálogo con un permiso nuevo y no repuntar el `modelId` deja ese permiso
en 503 para todos**. Y si el modo `facts` deja de consultar el catálogo local en `authorize`, se
pierde el estado "permiso desconocido ⇒ `false`" del invariante 5: pasaría a ser 503. Mitigación
mínima: en `facts`, `authorize` sigue resolviendo el permiso contra el catálogo local **antes** de
tocar FGA (memo incluido), exactamente como hoy (`openfga_driver.ts:433-434`).

---

## Lo que intenté y NO se rompió

1. **Wildcard de objeto para el catálogo** — imposible, y bien: `scope:*` como objeto →
   `"the 'object' field cannot reference a typed wildcard"`. (Mata la opción (a) de la propuesta.)
2. **Colar un `user:*` accidental** — el modelo lo impide si no lo declara:
   `"the typed wildcard 'user:*' is not an allowed type restriction for 'scope#denied_docs_write'"`.
   Un import no puede fabricar un wildcard de sujeto contra un modelo bien generado.
3. **Bucle infinito / deadline por ciclo** — FGA **no** entra en bucle: responde en ~7 ms. El
   problema del ciclo es semántico (S2), no de disponibilidad.
4. **Fail-open por límite de profundidad** — probé grant a 1 salto + deny a 31 saltos: el `Check`
   **falla** (400) en vez de conceder. El `difference` no devuelve `true` con la rama del deny rota.
5. **Colisión `organization|X` vs `organization|X|…`** — no la conseguí: `scopeKey` solo produce
   dos componentes y `SCOPE_COMPONENT_FORMAT` (`openfga_driver.ts:67`) prohíbe `|` y `~` en ambos.
   Con `|` prohibido, `tipo|uuid` es inyectivo. **La única no-inyectividad viva es `app` con uuid**
   (S12). Ojo: `:` sí está permitido en los componentes y no rompe nada porque FGA parte el objeto en
   el **primer** `:` (probé `scope:organization|A` sin incidentes) — pero si algún día el id de objeto
   pasa a tener tres partes (opción (c): `role_binding:<scopeKey>|<roleUuid>`), la inyectividad
   depende otra vez de que la validación corra: es la decisión de "parseo desde la derecha" del juez.
6. **`#` en el id de scope** — bloqueado por la misma regex; no logré fabricar un userset accidental
   (`scope:foo#parent`) desde un `ScopeRef`.
7. **Atomicidad del `Write`** — dentro de una request, FGA es todo-o-nada (verificado con un delete
   fallido que abortó el write que lo acompañaba). El `moved` **puede** ser atómico (S3): el diseño
   solo tiene que exigirlo.
8. **Ids con espacios** — rechazados por regex; un uuid con espacio no llega a escribirse.
9. **Herencia hacia arriba en un árbol sano** — `Check(U1, can_docs_write, scope:app)` con el grant en
   `organization|A` = `false`. El modelo del borrador **sí** implementa "solo hacia abajo" mientras el
   grafo sea acíclico.
10. **Deny heredado en un árbol sano** — deny en `organization|A` bloquea en `unit|A1` y no toca a los
    hermanos. Correcto.

---

## Respuesta a P6 (qué NO se puede hacer, desde seguridad)

1. **No se puede confiar en FGA como validador del árbol.** Acepta ciclos, multi-padre y aristas a
   nodos inexistentes, y responde `true` sin señal. Toda la validación estructural tiene que vivir en
   el paquete, antes de escribir. Corolario: `facts` **no reduce** la superficie de confianza, la
   traslada.
2. **No se puede expresar el catálogo con una sola tupla.** El wildcard de objeto no existe
   (verificado). El catálogo global cuesta O(scopes × vínculos) tuplas, y su mantenimiento no es
   atómico (S10).
3. **No se puede tener atomicidad entre la BD del consumidor y FGA.** No hay 2PC. Lo mejor alcanzable
   es un outbox (atomicidad con la trx + convergencia eventual): elimina la fuga por rollback, no
   elimina la ventana de decisión obsoleta.
4. **No se puede sostener "escrituras idempotentes" (invariante 6) con `onDuplicateWrites: Ignore`**:
   la condición no forma parte de la clave (verificado). O se hace delete+write o la idempotencia es
   mentira para todo lo que lleve caducidad.
5. **No se puede soportar profundidad arbitraria.** ~23 saltos con los defaults; el `database` driver
   no tiene techo. Es una **diferencia de capacidad**, no un detalle de tuning: hay que declararla.
6. **No se puede mantener el invariante 7 si los `list*` se implementan con `ListObjects`** (enumera
   la herencia completa, verificado).
7. **No se puede garantizar que la migración conserve respuestas** entre motores con collation
   distinta (S15) ni cuando el store de destino no está vacío (S7).
8. **No se puede prometer "un solo `Check`" y a la vez "tres estados distinguibles"** si se elimina la
   consulta al catálogo local: un permiso desconocido dejaría de ser `false` y pasaría a ser 503
   (S21). El SQL del camino caliente se reduce, no desaparece.

## Respuesta a P4 (¿`scopes.*` opcional en `database`?)

**Sí, opcional — pero solo si el modo `facts` se niega a arrancar sin una jerarquía demostrada.**
Ver S8. El agujero no se abre al no llamarlo: se abre en el instante del cambio de driver, y se
manifiesta **solo en los denies heredados**, que es la mitad del contrato que menos se prueba. Gate
mínimo: `authz:scopes:verify` como precondición de construcción del driver `facts` (falla ⇒ el
manager no construye), más un sello de generación que el consumidor incremente en cada `scopes.*`.

---

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿Cuál es la codificación definitiva de la asignación?** Si no es `role_binding:<scopeKey>|<uuid>`
   (o equivalente con el scope en el objeto), S1 hace inviable el modo `facts`. Y si es esa,
   ¿cuántos saltos TTU consume `scope → has_binding → role_binding#assignee → user` y cuánta
   profundidad de árbol queda por debajo del límite de 25? **Hay que medirlo antes de estimar.**
2. **¿`scopes.moved` se compromete a un único `Write`** (deletes+writes en la misma request)? Si no,
   S3 queda abierto y no es mitigable por el consumidor.
3. **¿Entra el outbox en el paquete (P5)?** Si la respuesta es "verify basta", quiero que el
   documento diga con letra grande que **un rollback de la trx del consumidor deja escalada
   persistente en FGA** — no es un caso de mal uso.
4. **¿`authz:scopes:verify` cubrirá también catálogo y hechos**, o el diseño acepta dos de los tres
   conjuntos sin verificador (S6, S10)?
5. **¿El modo `facts` mantiene la consulta del catálogo local en `authorize`?** De ello depende que el
   invariante 5 siga en pie (S21) y que el eslogan "un solo `Check`, sin SQL en el camino caliente"
   sea cierto o no.

---

## Tabla de cierre

| # | Hallazgo | Sev | Evidencia | Rompe | Mitigación mínima |
|---|---|---|---|---|---|
| S1 | La asignación no lleva scope: grant = acceso en todo scope con el rol vinculado | 🔴 | ✅ reproducido | Inv. 1, 4 | Scope obligatorio en el objeto de asignación (opción c) |
| S2 | FGA evalúa ciclos de `parent` sin error ⇒ herencia hacia arriba | 🔴 | ✅ reproducido (7 ms, `true` en `app`) | Inv. 1 | Anti-ciclo en el paquete + ciclos en `verify` |
| S3 | `moved` en dos requests: sin padre (deny perdido) o dos padres (cruce de tenants) | 🔴 | ✅ reproducido; ✅ el `Write` atómico existe | Inv. 1, 2 | `moved` = un único `Write` |
| S4 | Colisión `can_*`/`denied_*`/`*_role`: clave duplicada colapsada en JS ⇒ deny anulado | 🔴 | ✅ reproducido (`allowed:true` con deny) | Inv. 2, 5 | `Map` + lanzar; validar las 4 familias |
| S5 | Rollback del consumidor no deshace FGA ⇒ escalada persistente e invisible | 🔴 | ✅ mecanismo; 🟡 orden de llamada | Inv. 1 | Outbox en el paquete; `verify` read-only |
| S6 | `detached` a medias: grants supervivientes sin ancestro ⇒ indenegables | 🔴 | ✅ límite 100/req; 🟡 orden | Inv. 2 | Purgar hechos primero, arista al final |
| S7 | Import `Ignore`: la condición no es clave ⇒ caducidad perdida; aristas acumuladas | 🔴 | ✅ reproducido | Inv. 3, 6 | `--reconcile` con delete+write y borrado de aristas |
| S8 | P4: `scopes.*` opcional ⇒ al migrar, denies heredados desaparecen | 🟠 | ✅ mecanismo | Inv. 2 | `verify` como gate de arranque del driver `facts` |
| S9 | Profundidad > ~23 ⇒ 503 permanente; `database` no tiene techo | 🟠 | ✅ medido (23 ok / 24 error) | Juez único | `maxDepth` en `capabilities` + caso negativo |
| S10 | Catálogo por tuplas: cambio no atómico, sin verificador | 🟠 | ✅ límites; 🟡 volumen | Inv. 6 | Verificar los tres conjuntos |
| S11 | Caché de `Check` del servidor ⇒ hasta 10 s de fail-open tras revoke | 🟠 | ✅ flags del `:8101` | Inv. 2 | `HIGHER_CONSISTENCY` por defecto |
| S12 | `{app, uuid}` colapsa ⇒ `attached` reparenta la raíz | 🟠 | ✅ efecto reproducido | Inv. 1 | L0.10 antes de `facts`; `app` no puede ser hijo |
| S13 | Relación ≤ 50 y objeto ≤ 256 ⇒ catálogo legal en SQL, impublicable en FGA | 🟡 | ✅ reproducido | Juez único | Longitudes en el núcleo |
| S14 | Permiso `parent` ⇒ modelo inválido, sync bloqueado | 🟡 | ✅ reproducido | Disponibilidad | Lista de reservados en `assertValidSlug` |
| S15 | Case-sensitivity FGA vs collation CI ⇒ la migración cambia respuestas | 🟡 | ✅ verificado en FGA | P3 | Normalizar en el manager + caso de migración |
| S16 | `ListObjects` ignora el límite de profundidad y enumera la herencia | 🟡 | ✅ reproducido (63 objetos) | Inv. 7 | Prohibir `ListObjects` en los `list*` |
| S17 | Sin `context` ⇒ 400 (y 500 en list) con un único `Check` que mezcla deny y grant | 🟡 | ✅ reproducido | Inv. 5 | `context` en un único punto + caso de contrato |
| S18 | `verify`/`enumerateEdges` como oráculo; `--fix` sería vector de concesión | 🟡 | ✅ coste; 🟡 diseño | — | `verify` read-only por contrato |
| S19 | La caducidad depende del reloj del cliente | ⚪ | ✅ código | Inv. 3 | Reloj inyectable + doc |
| S20 | Tuplas huérfanas sobreviven al cambio de modelo ⇒ resurrección | ⚪ | ✅ reproducido | Inv. 6 | Borrar tuplas de relaciones retiradas |
| S21 | Modelo desfasado ⇒ 503 en vez de `false` (fail-closed, pero rompe los 3 estados) | ⚪ | ✅ reproducido | Inv. 5 | Mantener el catálogo local en `authorize` |

**Store temporal `01M14AV07HK7GDBNCY218Q7A20` borrado (HTTP 204, comprobado). El paquete no se tocó.**
