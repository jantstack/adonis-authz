# Fase 4 · `relations/` (ReBAC) — AUDITORÍA ADVERSARIAL DE CIERRE (atacante)

> Base: `main` @ `2691d83` (Fase 4 lote 6 mergeada). Solo lectura sobre el árbol.
> Reproducido contra el `:8101` real (OpenFGA v1.19). Stores creados (`audit4f_*`) borrados; `:8101` a **0
> stores** al cerrar. Insumos leídos: `fase-4-auditor.md` (mi 🔴 original), `fase-4-juez.md`, informes de
> lote 4-1…4-6 (secciones ABIERTO/DECLARADO), `fase-3b-auditor-final.md`/`-r2.md` (los patrones), `CLAUDE.md`,
> `src/relations/*`, `src/drivers/*relations*`, `src/relations_config_store.ts`, `src/identity.ts`,
> `src/drivers/openfga_facts.ts`, `commands/authz_relations_reconcile.ts`, `commands/openfga_provision.ts`.

## Veredicto en una línea

**Se puede cerrar la fase — seguro con reservas.** El 🔴 original (F-05) **AGUANTA contra el código real**: el
manager corta `relate(role_binding)` con 422 y el binding legítimo queda intacto (reproducido). Ninguno de los
caminos que saltan el manager (reconcile directo, `manager.driver()`) reabre la escalada **con los dos drivers
publicados**. Lo que encontré son **dos 🟡 y dos ⚪** —divergencia de validación, seguro de borrado masivo que
falta, y superficies de defensa en profundidad—: ninguno es un 🔴/🟠 EXPLOTABLE, así que **por la regla de
parada van al PLAN, no reabren la fase**. Recomiendo arreglar los dos 🟡 antes de etiquetar 2.4 (son
regresiones de estándares que el propio paquete ya ganó), pero no bloquean el cierre.

---

## El 🔴 cerrado — RE-VERIFICADO, aguanta

- ✅ `RelationsManager.#assertDeclared` (`src/relations/manager.ts:82`) lanza `RelationTypeUnknownError` (422)
  para `object.type` no declarado y `RelationUnknownError` para relación no declarada, ANTES de tocar el
  driver. `role_binding`/`scope`/`role` NO se pueden declarar (`defineRelationsConfig` los rechaza contra
  `RESERVED_FACTS_TYPES`, `src/relations/define_relations_config.ts:129`). El par ⚪4+F-05 cierra la colisión
  **por construcción**, como dijo el juez: el id `role_binding:...` nunca lo compone el driver de relaciones.
- ✅ Reproducido contra `:8101` el caso-exploit por el manager: `relate(evil, assignee, {role_binding, id},
  APP_SCOPE)` ⇒ 422 y `check(evil, can_p0, app)` sigue `false`. El `tests/relations_bridge.spec.ts` ya lo
  ancla rojo→verde en el store COMPARTIDO; lo confirmé leyéndolo y con mi propio store.
- **Caminos que saltan el manager (los que el encargo pidió atacar):**
  - `manager.driver().relate(...)` — salta F-05 a propósito (salida de plataforma documentada). Es el «ROJO»
    del bridge spec: escala. Aceptado: es la misma puerta que `driver()` de roles.
  - `reconcileRelations` (`src/relations/reconcile.ts:151`) escribe con `to.relate(...)` DIRECTO al driver,
    saltándose F-05 (lo confesó 4-6 punto 4). **No reabre la escalada con los drivers publicados** porque el
    ORIGEN filtra: `OpenFgaRelationsDriver.enumerateRelations` (`openfga_relations_driver.ts:426`) descarta
    todo tipo que no sea `group` o un tipo declarado, así que jamás emite `role_binding`. Ver ⚪3 para el
    residuo (el driver `database` NO filtra igual).

---

## Hallazgos (ordenados por severidad)

### 🟡 1 · El driver `openfga` de relaciones NO valida `object.id` (solo la longitud) — divergencia con `database`, invisibilidad de enumeración y pérdida silenciosa en `reconcile`

- **Escenario:** el consumidor pasa un `object.id` con un `|` (id que no sanea, columna que lo permita) →
  `manager.relate(evil, viewer, {type:'document', id:'a|b'}, APP_SCOPE)`. El manager NO valida `object.id`
  (`manager.relate` solo hace `#assertDeclared` del tipo+relación, `assertScope`, `#assertSubject` — nunca un
  `assertId` del id del objeto). El driver `openfga` solo comprueba **longitud** (`assertFgaObjectId`,
  `openfga_facts.ts:587`, único chequeo: `id.length > 256`). La tupla se escribe y `check` la **honra**
  (`check=true`), pero al parsear de vuelta (`#parseObjectId`, corte por el ÚLTIMO `|`) la partición sale
  MAL: `document:app|a|b` ⇒ `partitionKey='app|a'`, así que `listObjects` la FILTRA
  (`openfga_relations_driver.ts:350`) y `enumerateRelations` la DESCARTA (`:427`). Resultado: una relación que
  concede pero que **no se ve en `listObjects`, ni en la enumeración, ni migra** — y `authz:relations:reconcile`
  la pierde **sin rastro**, justo lo que el docblock del propio `enumerateRelations` promete que no pasa
  («una tupla que no llegara aquí desaparecería sin rastro», `:414`).
- **Evidencia:** ✅ medido contra `:8101` (mi `inject.ts`, store `audit4f_*` borrado). Salida literal:
  ```
  relate object.id="a|b"     => ACEPTADO, check=true      ← pero NO aparece en listObjects
  relate object.id="a:b"     => RECHAZADO ...BackendError  (503, no 422)
  relate object.id="a#viewer"=> RECHAZADO ...BackendError  (503, no 422)
  relate object.id="*"        => ACEPTADO, check=true
  relate object.id="a b"     => RECHAZADO ...BackendError  (503, no 422)
  listObjects app = [{document,"*"},{document,"plain"}]     ← "a|b" NO está
  ```
  El driver `database` (`database_relations_driver.ts:196`, `RELATION_ID_FORMAT=/^[a-z0-9_.-]+$/`, ≤64)
  **rechaza `a|b` con 422**. O sea: **divergencia de paridad** (openfga acepta lo que database prohíbe) y
  **violación del invariante de higiene** de `CLAUDE.md`/`identity.ts` («la gramática la aplica el manager y,
  por defensa en profundidad, cada driver»): en relaciones+openfga NO se aplica al `object.id`. Además los
  caracteres estructurales (`:`,`#`,` `,`@`) salen como **503 `AuthorizationBackendError`** (FGA los rechaza
  con 400) cuando por invariante 5 una entrada malformada es **422**, no un «backend no respondió».
- **Por qué NO es 🔴/🟠:** el prefijo de tipo va FIJO al tipo declarado (`document:`), así que `object.id` no
  puede fabricar un `role_binding:`/`scope:` (no cruza a roles) y la re-composición de `check` es consistente
  con la de `relate`, así que no cruza tenants (fail-CLOSED para aislamiento: pierde/oculta un grant, no lo
  fabrica). Es el patrón 3b PERO al revés de signo (pérdida silenciosa, no escalada silenciosa).
- **Steelman del defensor:** «`object.id` siempre es un uuid del propio consumidor, no entrada de usuario.» →
  **No me convence del todo.** El paquete VENDE «cada driver aplica la gramática por defensa en profundidad» y
  `database` la aplica; que `openfga` no lo haga es una promesa incumplida, y basta un consumidor que use un id
  no-uuid (los casos de diseño del propio 4-6 usan ids como `realdoc`) para que la enumeración/migración pierda
  datos en cuanto uno lleve un `|`.
- **Mitigación mínima:** `manager.relate`/`unrelate` validan `object.id` (y el `subject.object.id` del userset)
  con la MISMA gramática estricta que `database` (`assertId`, sin `|`/`#`/`:`/`@`/espacios), 422 antes del
  driver; caso de paridad en los dos drivers.

### 🟡 2 · `reconcileRelations --prune` no tiene seguro de borrado masivo (regresión del que roles ganó en 3b)

- **Escenario:** operador corre `authz:relations:reconcile --to=openfga --from=database --prune` con el
  `--from` EQUIVOCADO (o una partición sin tuplas en el origen). `reconcileRelations`
  (`src/relations/reconcile.ts:133,153`) calcula `toDelete = destTuples.filter(t => !sourceByKey.has(...))`;
  con origen vacío eso es **TODO el destino**, y con `prune` lo borra. No hay
  `E_AUTHZ_MASS_RECONCILE_REFUSED` ni `--allow-mass-delete` ni aviso de purga masiva —nada—; el CLI
  (`commands/authz_relations_reconcile.ts:56`) sale `clean` (exit 0) en una pasada real aunque `deleted` sea
  el store entero.
- **Evidencia:** ✅ leído en código. `reconcileRelations` NO comprueba `sourceTuples.length === 0` en ningún
  punto; el CLI solo marca deriva por `modelDrift` y por `dryRun`. Contrasta con roles, donde `CLAUDE.md`
  (regla de higiene de reconcile) exige «`--prune` con `authz_*` sin una sola fila de hechos es 500
  `E_AUTHZ_MASS_RECONCILE_REFUSED` … `--allow-mass-delete` es la salida humana» (patrón de AA2/3b-0b, 3b-8·B1).
- **Por qué NO es 🔴/🟠:** borrar tuplas de relación = quitar accesos = **fail-closed** para autorización; es
  herramienta de PLATAFORMA (sin actor, no expuesta por HTTP). Es data-loss/disponibilidad, no escalada.
- **Steelman:** «Es de plataforma; el operador sabe lo que hace.» → **No me convence:** ese seguro existe en
  roles PRECISAMENTE porque el `resolveChain`/`--from` ciego es un error anticipado y destructivo; relaciones
  lo perdió sin justificación. Un `--dry-run` previo lo enseñaría, pero el seguro duro es lo que evita el
  vaciado en la pasada real.
- **Mitigación mínima:** `reconcileRelations` refuerza el mismo seguro que roles: origen con 0 tuplas (o N
  leídas y N descartadas) + `prune` ⇒ 500 `E_AUTHZ_MASS_RECONCILE_REFUSED` salvo `allowMassDelete: true`
  (`--allow-mass-delete`); `--dry-run` lo marca sin lanzar. Caso en `relations_reconcile_contract`.

### ⚪ 3 · `DatabaseRelationsDriver.enumerateRelations` NO filtra por tipos declarados (openfga sí) — residuo del chokepoint F-05 en el reconcile

- **Escenario:** el reconcile escribe `to.relate(...)` DIRECTO, saltándose F-05 (§4-6·4). El ORIGEN `openfga`
  se protege filtrando tipos no declarados; el ORIGEN `database` NO: `enumerateRelations`
  (`database_relations_driver.ts:503`) hace `whereIn partition_key` y devuelve **toda** fila de
  `authz_relations`, sin filtrar `object_type`. Si en `authz_relations` hubiera una fila con
  `object_type='role_binding'`, `reconcile --from=database --to=openfga` la migraría con `to.relate` (sin
  F-05) al store COMPARTIDO ⇒ `role_binding:<key>|<uuid>#assignee@evil` ⇒ escalada en `roles.authorize`.
- **Evidencia:** ✅ leído en código. La divergencia es real (openfga filtra en `:426`, database no).
- **Por qué es ⚪ y no más:** una fila `role_binding` en `authz_relations` **no la puede poner un consumidor**:
  el manager la corta con F-05, y meterla requiere `manager.driver().relate()` o escritura a mano —ya nivel
  plataforma, que también podría escribir al store openfga directamente—. No es una escalada NUEVA sobre la
  capacidad ya existente. Pero es la superficie que el juez nombró (§8: «un camino de escritura futuro que
  salte F-05 reabre la escalada») y hoy el reconcile+database la deja entreabierta por composición.
- **Steelman:** «Nadie puede sembrar `role_binding` en `authz_relations`.» → **Me convence a medias:** cierto
  hoy, pero la defensa en profundidad barata es que `database.enumerateRelations` filtre por tipos declarados
  IGUAL que openfga, y que el reconcile embude sus writes por una validación F-05 (no por `to.relate` crudo).
- **Mitigación mínima:** `database.enumerateRelations` descarta tipos no declarados (paridad con openfga) y/o
  `reconcileRelations` valida cada tupla contra la config del destino (F-05) antes de `to.relate`.

### ⚪ 4 · El 🟡3 (republicar sin config mutila el modelo) quedó cerrado en `syncAuthzCatalog` pero NO en `openfga:provision`; y `republishFusedModel` no tiene llamador en producción

- **Escenario:** `openfga:provision` / `provisionOpenFgaStore` (`openfga_driver.ts:307`, `commands/openfga_provision.ts:69`)
  publican `openFgaFactsModel(holderTypes, permissions)` **SIN** la config de relaciones. Re-provisionar un
  store que YA tiene relaciones configuradas + tuplas republica un modelo facts-only, **tira el tipo
  `document`** y orfana toda tupla de relación (`check` ⇒ error/`false`).
- **Evidencia:** ✅ leído. El fix de 4-5 (`relations_config_store.republishFusedModel`, que lee la config
  PERSISTIDA de `authz_relations_config`) cierra la carrera `defineRelationsConfig`↔`syncAuthzCatalog` y el
  republish-sin-config **por esa vía** —bien—, pero `provision` es OTRA vía de republicación que no se
  actualizó. Además, `grep` confirma que `republishFusedModel` (driver y store) **no tiene ningún llamador en
  `commands/`/`services/`/`providers/`** — solo en tests: el wiring de republicación fusionada está incompleto
  (coherente con lo que 4-6 punto 7 declaró ABIERTO: «el `RelationsManager` de servicio NO se cableó»).
- **Por qué ⚪:** fail-CLOSED (las relaciones dejan de resolver; no concede de más), y provisionar sobre un
  store vivo es semi-operador-error. Pero es «el modelo de uno y las tuplas de otro» que el encargo pregunta.
- **Mitigación mínima:** `provisionOpenFgaStore`/`openfga:provision` leen `authz_relations_config` y emiten el
  modelo FUSIONADO (o rehúsan republicar si el store ya tiene tipos de relación no incluidos); documentar que
  la republicación fusionada de plataforma va SIEMPRE por `republishFusedModel`.

---

## Lo que intenté y NO se rompió

- **Reabrir el 🔴 por el manager.** `relate(evil, assignee, {role_binding}, S)` ⇒ 422 y el `can_p0` del binding
  legítimo intacto. F-05 + ⚪4 cierran por construcción (verificado en código y contra `:8101`).
- **Reabrir el 🔴 por `reconcileRelations` con origen `openfga`.** El `enumerateRelations` de openfga filtra
  `group`+tipos declarados y descarta `role_binding`/`scope`/`role`: un origen envenenado no existe por ahí.
- **Cruce de particiones por alias del uuid (dashless↔dashed).** Fail-CLOSED: `check`/`listObjects` componen
  con la ortografía del llamante (mismo comportamiento que la divergencia (c) de roles); dos uuids distintos
  dan strings distintos. Y `purge*` de AMBOS drivers barre las DOS ortografías (`#partitionSpellings`,
  `scopeSpellings`), así que el 🟡2 de mi auditoría original (residuo de purga por alias) está **cerrado** —lo
  heredó bien, no como en 3b-3b—.
- **Cruce de particiones / a roles por inyección de `object.id`.** El prefijo de tipo va fijo al tipo declarado
  y FGA rechaza los caracteres estructurales (`:`/`#`/`@`/espacio) con 400; el `|` sí entra pero es fail-CLOSED
  (invisibilidad, no cruce) — es el 🟡1, no un 🔴.
- **Type de objeto que colisiona con un tipo de `facts`.** `defineRelationsConfig` lo rechaza (422) contra
  `RESERVED_FACTS_TYPES` y `RESERVED_SLUGS`/`RESERVED_SLUG_PREFIXES` (⚪4 de mi auditoría original, **cerrado**
  y con paridad: rige en la config, agnóstica de driver, y el generador lo re-chequea).
- **Wildcard de usuario por `subject.uuid`.** `assertSubject` valida el uuid (sin `*`); un userset compone
  `<obj>#<relation>` con la relación declarada. No hay inyección de `user:*`.
- **DoS del catálogo por muchos tipos de relación.** El gate de bytes mide el modelo FUSIONADO
  (`assertFactsModelPublishable(..., relations)` en `republishFusedModel`): rebasar es 500 antes de publicar,
  fail-closed. No lo empujé al techo (coste de `:8101`), pero el gate está donde debe.

---

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

Ninguna cambia el veredicto de cierre. Para el plan:

1. **¿Se valida `object.id` en el manager (🟡1)?** Es la única que roza «una tupla que concede y no se ve», y
   la que rompe paridad con `database`. Barata y recomendada antes de 2.4.
2. **¿`reconcileRelations` recupera el seguro de borrado masivo de roles (🟡2)?** Regresión de un seguro ya
   ganado; recomendada antes de 2.4.
3. **¿`provision` y el wiring de republicación fusionada leen la config persistida (⚪4)?** Puede ir con el
   cableado del singleton de relaciones que 4-6 dejó pendiente.

---

## Redacción exacta para el PLAN (cerrar los dos 🟡)

> **R-16 (validación de `object.id`, ambos drivers, paridad):** `relate`/`unrelate`/`check`/`listObjects`/
> `listSubjects`/`purge*` validan `object.id` (y `subject.object.id` del userset) con la gramática estricta de
> relaciones (`/^[a-z0-9_.-]+$/`, ≤64), **en el `RelationsManager` ANTES del driver** ⇒ 422
> `E_AUTHZ_INVALID_IDENTITY`. Motivo: el manager solo valida tipo+relación (F-05), y `openfga` solo mide la
> longitud del id (`assertFgaObjectId`), así que un `object.id` con `|` se escribe y `check` lo honra pero
> `listObjects`/`enumerateRelations` lo pierden (parse por el último `|`), lo que hace desaparecer la tupla de
> la migración —lo que el propio `enumerateRelations` promete que no pasa— y diverge de `database`, que lo
> rechaza. Caso de paridad + caso de que un `object.id` inválido es 422 (no 503) en los dos drivers.

> **R-17 (seguro de borrado masivo en `reconcileRelations`):** `--prune` con un ORIGEN de 0 tuplas utilizables
> ⇒ 500 `E_AUTHZ_MASS_RECONCILE_REFUSED` antes de borrar nada, salvo `allowMassDelete: true`
> (`--allow-mass-delete`); `--dry-run` lo marca sin lanzar. Paridad con el seguro de `authz:reconcile` de roles
> (`CLAUDE.md`, higiene de reconcile). Caso: `reconcile(from=vacío, to=lleno, prune)` ⇒ 500 y el destino
> intacto; con `--allow-mass-delete` vacía y lo reporta.
