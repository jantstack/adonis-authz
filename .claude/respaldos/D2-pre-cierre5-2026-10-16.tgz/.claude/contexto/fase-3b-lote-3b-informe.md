# Fase 3b · Lote 3b — `authz:reconcile --to=database` y el **contrato de migración**

> Base: `047dc9d` (lote 3a), rama `v2/fase-3b`, **árbol principal**, sin commits.
> Encargo: `.claude/contexto/fase-3b-plan.md` §«Lote 3b-3», la dirección
> inversa y la GARANTÍA. Contexto leído entero: `CLAUDE.md`,
> `fase-3b-lote-3a-informe.md` (decisiones y límites incluidos),
> `decisiones-dueno-2026-08-28.md`, `panel2-2026-08-28-juez.md` (cruces 4 y 9 y
> el requisito 3 de la tabla del dueño) y `src/testing/contract.ts`.

Es el último lote de código de la Fase 3b. El 3a hizo que la migración
existiera; éste hace que se pueda **creer**.

## Resumen

| Pieza | Estado |
|---|---|
| B1 · `authz:reconcile --to=database` (hechos por `Read` paginado; el árbol NO se migra) | ✅ |
| B2 · El reporte en las dos direcciones, nunca silencioso | ✅ |
| B3 · `runMigrationContract` — siembra fija, **448** preguntas, 3 combinaciones, `expectedLosses` | ✅ |
| B4 · La entrada de contrato y la capacidad que el 3a dejó (`enumerateFacts`, con sus dos caras) | ✅ |
| B5 · El límite del volcado: **cerrado declarándolo** con cota (`maxTuples`) y error propio | ✅ |
| El contrato **falla de verdad** cuando debe (tres mutantes distintos) | ✅ |
| Bug encontrado por el contrato y arreglado: los hechos de la RAÍZ no se migraban | ✅ |
| 4 motores + `:8101` + tope 3 | ✅ |

**Cifras**: `sqlite` **752** (partía de 720) · `sqlite-file` **754** (722) ·
`pg` **848** (815) · `mysql` **848** (815) · tope 3 (`:8103`, memoria)
**752 passed**. +32 casos en `sqlite` (+33 en PG/MySQL, donde el juez corre además con el árbol SQL y el par `enumerateFacts` se registra una vez más).
`npx tsc --noEmit -p tsconfig.json`, `npm run typecheck`, `npm run check:purity`
y `npm run build` verdes. **Cero stores huérfanos en el `:8101`**: de los 50 que
quedan, ninguno es de hoy (47 del 28-08, 2 del 29-08 y 1 del 26-08).

---

## Lo que se decidió antes de escribir código

### 1. Qué se migra en la vuelta, y qué NO

`--to=database` migra **los hechos y solo los hechos**.

- **El ÁRBOL no se migra.** Lo dice el encargo y lo confirma el código: el
  driver `database` lo lee de las tablas del consumidor en **cada pregunta**
  (`resolveChain`), y ésas son su fuente de verdad. Copiarlo a algún sitio
  sería inventar una segunda copia y con ella una deriva que hoy no existe.
- **El CATÁLOGO tampoco.** Es propiedad local siempre (regla de higiene del
  paquete), ya vive en `authz_*` y ningún driver es su fuente.

Consecuencia visible: `phases.root`, `phases.catalog` y `phases.tree` son
**cero** en esa dirección. Eso es una **respuesta**, no un hueco, y tiene su
caso (y su mutante). El árbol sí se USA: para decidir qué hecho es migrable
(`unknown-scope`) y bajo qué identidad CANÓNICA se escribe cada fila
(invariante 17).

### 2. El origen es un PUERTO, y quién lo ocupa se dice en voz alta

La vuelta necesita leer los hechos del store. Se añade
`AuthorizationDriver.enumerateFacts?({ limit, after })` — método **opcional**
del puerto, con **capacidad `enumerateFacts`** (B4). Contrato: ≤ `limit` por
página, orden total y estable, cursor opaco que tiene que **avanzar**, y
**no filtra nada**: una asignación caducada tiene que LLEGAR con su
`expiresAt` para que el destino la cuente en `skipped`. Filtrarla en el origen
la haría desaparecer sin dejar rastro en ningún contador, que es exactamente
lo que una migración no puede hacer (y hay un mutante que lo demuestra, M2).

`database` declara **`enumerateFacts: false` a propósito**: sus hechos SON
`authz_assignments`/`authz_denies`, el esquema **publicado** del paquete, y el
destino los lee de ahí (es lo que hace `openfga.reconcile` desde el 3a). No es
«no sabe»: es que no hace falta un método de puerto para leer una tabla
documentada. Eso deja el par con sus **dos caras ocupadas por drivers reales**,
que es la condición que `src/testing/contract.ts` exige para admitir una
capacidad.

**Quién es el ORIGEN** (regla determinista y ruidosa, nunca «el que haya»):

- `--from=<driver>` manda (registrado, ≠ destino, y con `enumerateFacts`);
- sin `--from`: candidatos = registrados ≠ destino que implementen el método.
  **Exactamente uno** ⇒ ése; **ninguno** ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrando
  `enumerateFacts`; **más de uno** ⇒ 500 `E_AUTHZ_CONFIG` pidiendo `--from`,
  porque de dónde salen los hechos decide lo que queda escrito.

Nunca «cero hechos» en silencio: un origen mudo y un `--prune` detrás vacían el
destino. La resolución es **perezosa** (se hace en la primera llamada a
`source.facts`), así que `--to=openfga` no construye ningún origen — y el
mutante M6 enseña que hacerlo con avidez rompe la ida entera.

### 3. B5 — el límite del 3a: **se cierra declarándolo**

El 3a lo dejó escrito: «el volcado del destino entra en memoria» y
«reanudable = idempotente y se repite». **Decisión: dejarlo declarado con su
cota y su error**, no fingir que se cierra.

El motivo de que el volcado exista no es pereza: reconciliar exige comparar
contra el estado **entero** del destino, porque «lo que sobra» es la mitad del
trabajo (las aristas que ya nadie respalda, el nodo con dos padres, la basura de
otra versión). Sin foto entera no hay `extra` ni `deleted`.

Lo que se añade:

- `ReconcileOptions.maxTuples` (`--max-tuples`), default
  `DEFAULT_RECONCILE_MAX_TUPLES = 1_000_000`;
- **500 `E_AUTHZ_RECONCILE_TOO_LARGE`** *antes de escribir nada*, nombrando la
  cota y la salida, en las **dos** direcciones (el volcado del store en
  `--to=openfga`, y el volcado de `authz_*` **y** los hechos del origen en
  `--to=database`);
- y la frase escrita en README/CHANGELOG/CLAUDE.md: **no hay migración por
  particiones en esta versión**, y «reanudable» sigue significando *idempotente
  y se repite*, no un cursor persistido.

Antes de esto la cota existía (`MAX_READ_PAGES` × 100) pero salía como
`AuthorizationInternalError` con un mensaje sobre páginas, que no es algo que
alguien pueda leer en producción y actuar.

---

## B1/B2 · `--to=database` — la vuelta

**Casos**: `tests/reconcile.spec.ts`, grupo
`3b-3b · reconcile --to=database (servidor real)` (13) y
`3b-3b · manager.reconcile: el ORIGEN` (7). Contra el `:8101` real y con el
árbol SQL del harness (`demo_scopes`), o sea PostgreSQL y MySQL de verdad.

🔴 **Rojo literal** (antes de escribir una línea de implementación):

```
❯ 3b-3b · reconcile --to=database (servidor real) / enumerateFacts: los hechos del ORIGEN salen paginados, con su caducidad y con el cursor avanzando
ℹ TypeError: fga.enumerateFacts is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / la base vacía no concede NADA, y una pasada de reconcile la pone a la par del driver openfga
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / el ÁRBOL no se migra en esta dirección: lo lee el driver database del consumidor
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / idempotencia: la SEGUNDA pasada escribe cero
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / --dry-run es el verificador: mismo recorrido, CERO escrituras (y no hay --fix)
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / la caducidad viaja con su instante: distinta en el destino ⇒ `updated`, igual ⇒ `unchanged`
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / lo que NO se migra sale contado y con su motivo
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / --prune borra las filas que el store ya no respalda; sin él solo se reportan
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / --prune con el ORIGEN vacío se niega (store ciego), y --allow-mass-delete es la salida
ℹ TypeError: database.reconcile is not a function
❯ 3b-3b · reconcile --to=database (servidor real) / la cota del volcado es un 500 con nombre, no un OOM (B5)
  Comparing two different types of values. Expected string but received undefined.
Tests  720 passed, 10 failed (730)
```

**Verde con**:

| Fichero | Qué |
|---|---|
| `src/types.ts` | `ReconcileFact` / `ReconcileFactPage` / `ReconcileFactsEnumerator`; `ReconcileSource.facts?`; `AuthorizationDriver.enumerateFacts?`; capacidad `enumerateFacts`; `ReconcileOptions.maxTuples` y `DEFAULT_RECONCILE_MAX_TUPLES` |
| `src/reconcile.ts` (**nuevo**) | Las piezas PURAS compartidas por las dos direcciones: `reconcileBatchSize`, `reconcileMaxTuples`, `RECONCILE_MAX_DETAILS`, `emptyReconcilePhases`, `sumReconcilePhases`. Fuera de los drivers porque `database` no puede importar de `openfga` (arrastraría el SDK) y porque duplicar la normalización es la forma más barata de que las dos direcciones cuenten distinto |
| `src/errors.ts` | `ReconcileTooLargeError` (500 `E_AUTHZ_RECONCILE_TOO_LARGE`) |
| `src/drivers/openfga_driver.ts` | `enumerateFacts(page)`; `readEveryTuple(maxTuples)`; el arreglo del centinela de la raíz (abajo) |
| `src/drivers/database_driver.ts` | `reconcile(source, options)` (+~300 líneas), `eachReconcileRow`, `assignmentKey`/`denyKey`/`longerExpiry`/`reconcileRowLabel`, y `fromDbScopeUuid` **exportada** |
| `src/manager.ts` | `reconcile({ to, from?, … })` + `#factsEnumerator` (la regla del origen, perezosa) |
| `commands/authz_reconcile.ts` | `--from`, `--max-tuples`, y el aviso del origen ciego adaptado a la dirección |

### Lo que cada caso fija, con el mutante que lo pone rojo

**(a) Paridad.** Base vacía ⇒ `authorize` falso; una pasada ⇒ las seis
preguntas responden **lo mismo** que el driver `openfga` (herencia hacia abajo y
deny explícito incluidos).

**(b) El árbol no se migra.**

```
== M16-arbol-migrado   (la vuelta "migra" también el árbol y lo cuenta como fase suya)
❯ 3b-3b · reconcile --to=database (servidor real) / el ÁRBOL no se migra en esta dirección: lo lee el driver database del consumidor
ℹ AssertionError: expected { written: +0, updated: +0, …(3) } to deeply equal { written: +0, updated: +0, …(3) }
Tests  49 passed, 1 failed (50)
```

**(c) Idempotencia**, con sus dos recuentos: `primera.written > 0`,
`segunda.written === 0`, `updated/deleted/extra === 0` y
`segunda.unchanged === primera.written + primera.unchanged`.

```
== M15-sin-diff   (no se lee el destino: se inserta todo siempre)
❯ … idempotencia: la SEGUNDA pasada escribe cero
ℹ AuthorizationBackendError: El backend de autorización 'database' no respondió (reconcile.insert)
❯ … --dry-run es el verificador: mismo recorrido, CERO escrituras (y no hay --fix)
ℹ AssertionError: expected 2 to equal +0
❯ … de punta a punta por el manager: authz:reconcile --to=database con el motor congelado
ℹ AssertionError: expected 2 to equal +0
Tests  43 passed, 7 failed (50)
```

Ese mutante deja escrito por qué la clave del diff es **exactamente el UNIQUE de
la tabla** (`holder_type, holder_uuid, role_uuid, scope_type, scope_uuid`) y por
qué `expires_at` **no** entra en ella: cambiar la caducidad es un UPDATE de la
misma fila, no una fila nueva (invariante 6). Sin diff, la segunda pasada choca
con el unique.

**(d) La caducidad es parte del estado, no de la clave.**

```
== M7-caducidad-fuera-del-diff   (todo lo que casa por clave se cuenta `unchanged`)
❯ … la caducidad viaja con su instante: distinta en el destino ⇒ `updated`, igual ⇒ `unchanged`
ℹ AssertionError: la caducidad que difiere se rehace: expected +0 to equal 1
Tests  49 passed, 1 failed (50)
```

**(e) `--dry-run` es el verificador, y NO hay `--fix`.**

```
== M8-dry-run-escribe
❯ … --dry-run es el verificador: mismo recorrido, CERO escrituras (y no hay --fix)
ℹ AssertionError: y no ha escrito ni una fila: expected [ …(2) ] to have a length of +0 but got 2
❯ … --prune con el ORIGEN vacío se niega (store ciego), y --allow-mass-delete es la salida
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_MASS_RECONCILE_REFUSED'
Tests  48 passed, 2 failed (50)
```

`reconcile` no acepta ninguna opción que se parezca a un `--fix`, el comando no
tiene esa bandera, y el docblock del método y el del comando lo dicen con esas
palabras (cruce 4 · S18).

**(f) Los hechos que sobran solo con `--prune`.**

```
== M9-borra-sin-prune
❯ … --prune borra las filas que el store ya no respalda; sin él solo se reportan
ℹ AssertionError: pero no se borra sin --prune: expected 1 to equal +0
Tests  56 passed, 1 failed (57)
```

**(g) El seguro del origen ciego**, simétrico al del 3a: `--prune` que borraría
hechos con el origen devolviendo **cero** ⇒ 500
`E_AUTHZ_MASS_RECONCILE_REFUSED` antes de tocar nada; `--dry-run` no lanza, lo
marca (`massDelete: true`); `--allow-mass-delete` es la decisión humana.

```
== M10-sin-seguro-origen-ciego
❯ … --prune con el ORIGEN vacío se niega (store ciego), y --allow-mass-delete es la salida
ℹ AssertionError: el --dry-run lo marca, no lanza: expected false to be true
Tests  49 passed, 1 failed (50)
```

**(h) La cota declarada (B5).**

```
== M12-cota-ignorada
❯ … la cota del volcado es un 500 con nombre, no un OOM (B5)
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_RECONCILE_TOO_LARGE'
Tests  49 passed, 1 failed (50)
```

**(i) El origen: la regla, y que sea perezosa.**

```
== M5-origen-adivinado   (con varios candidatos se coge el primero)
❯ 3b-3b · manager.reconcile: el ORIGEN / con MÁS de un origen posible NO se adivina: 500 pidiendo --from
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_CONFIG'
Tests  49 passed, 1 failed (50)

== M6-origen-no-perezoso   (el origen se resuelve al construir el `source`)
❯ 3b-3a · reconcile --to=openfga (servidor real) / de punta a punta por el manager: `authz:reconcile --to=openfga` con el motor congelado
ℹ UnsupportedOperationError: authz:reconcile --to=openfga necesita 'enumerateFacts' y el driver 'openfga' no lo implementa… Ningún driver registrado (database, openfga) sabe ser el ORIGEN de esta migración.
❯ 3b-3a · manager.reconcile / el destino se nombra por el REGISTRO, no por el driver activo
ℹ UnsupportedOperationError: …
❯ 3b-3a · manager.reconcile / durante la pasada las escrituras están congeladas y las lecturas no; el finally descongela
ℹ UnsupportedOperationError: …
❯ 3b-3a · manager.reconcile / si el driver revienta a mitad, el motor NO se queda congelado
ℹ AssertionError: expected [Function] to throw error including 'el destino se cayó a mitad de la migr…' but got 'authz:reconcile --to=destino necesita…'
❯ 3b-3a · manager.reconcile / la VENTANA del relay se reporta como deriva (y lo aparcado, aparte)
ℹ UnsupportedOperationError: …
❯ 3b-3b · manager.reconcile: el ORIGEN / el ORIGEN es PEREZOSO: `--to=openfga` no construye ningún driver de más
ℹ AssertionError: el destino no pidió hechos, así que no se resolvió ningún origen: expected 1 to equal +0
Tests  44 passed, 6 failed (50)

== M13-origen-vacio-en-silencio   (sin candidato se devuelve un enumerador vacío)
❯ authorization contract [database · 2.2] / sin enumerateFacts el driver NO puede ser el origen de una migración, y authz:reconcile lo DICE (500 E_AUTHZ_UNSUPPORTED nombrándolo) en vez de leer cero hechos y vaciar el destino con --prune
ℹ AssertionError: status de no debería haber llegado a leer hechos: expected undefined to equal 500
❯ authorization contract [database (sin listDenies) · 2.2] / (el mismo)
ℹ AssertionError: …
❯ 3b-3b · manager.reconcile: el ORIGEN / sin NINGÚN origen posible, la pasada lo DICE (500 E_AUTHZ_UNSUPPORTED) en vez de migrar cero
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_UNSUPPORTED'
Tests  333 passed, 3 failed (336)
```

M6 es el que justifica la pereza: resolver el origen con avidez rompe
**`--to=openfga` entero**, que no necesita ningún origen del puerto.

**(j) `enumerateFacts` y su cursor.**

```
== M14-sin-cursor   (la página no propaga el continuation_token)
❯ authorization contract [openfga · 2.2] / enumerateFacts: los hechos del driver salen paginados, con su caducidad SIN filtrar y con un cursor que avanza …
ℹ AssertionError: el deny es un hecho y sale: expected [] to have a length of 1 but got +0
❯ 3b-3b · reconcile --to=database (servidor real) / enumerateFacts: los hechos del ORIGEN salen paginados, con su caducidad y con el cursor avanzando
ℹ AssertionError: expected [] to have a length of 2 but got +0
Tests  334 passed, 2 failed (336)
```

**(k) El aviso del comando** dice del ORIGEN cuando el destino es `database`:

```
== M17-aviso-generico
❯ 3b-3a · authz:reconcile (las decisiones del comando) / 3b-3b: el aviso del origen ciego habla del ORIGEN cuando el destino es `database`
ℹ AssertionError: expected false to be true
Tests  50 passed, 1 failed (51)
```

### Qué entra en `skipped` en la vuelta

| Motivo | Qué es | ¿Se borra su rastro en el destino? |
|---|---|---|
| `expired` | tupla `assignee` con `valid_until` pasado: no concedía | solo `--prune` |
| `unknown-scope` | el árbol del consumidor ya no resuelve ese scope | solo `--prune` |
| `unknown-role` | `role_binding` de un rol que el catálogo ya no declara | solo `--prune` |
| `unknown-permission` | relación `denied_<P>` que el catálogo ya no declara (la reporta el ORIGEN) | solo `--prune` |
| `unknown-holder-type` | tipo FGA que `holderTypes` no declara (la reporta el ORIGEN) | solo `--prune` |
| `unparseable-binding` | id de binding con la gramática de 1.x/2.1 (slug en el id) — la reporta el ORIGEN | solo `--prune` |
| `unparseable-tuple` / `invalid-scope` | basura que no tiene la forma de un hecho | solo `--prune` |
| `folded-scope` | **dos** hechos del origen que colapsan en UNA fila del destino (ver §pérdidas) | no aplica: la fila se escribe una vez |
| `extra-fact` | fila del destino que el origen no respalda | solo `--prune` |

**Lo que NO produce `role-not-visible` en esta dirección, y por qué**: en
`facts`, el hecho de una asignación es el `assignee`; la arista
`scope#binding` significa «el rol es visible aquí» (3b-2g · R1) y ningún barrido
la confunde con la asignación. Al volver a `database`, la visibilidad se evalúa
**en cada pregunta** (invariante 18: en `database` se retira *sin escribir*), así
que migrar la fila conserva el hecho y no cambia ninguna respuesta. Descartar la
asignación aquí sería perder un hecho que el otro driver sí tiene.

---

## El bug que encontró el contrato: los hechos de la RAÍZ no se migraban

No estaba en el encargo: salió a la primera corrida de `runMigrationContract`,
porque su siembra fija **sí concede en `app`** y ningún caso del 3a lo hacía.

```
❯ migration contract [database ⇄ openfga (facts)] / 448 preguntas idénticas, database → openfga: …
ℹ InvalidIdentityError: Scope inválido: el scope 'app' es la raíz y no admite uuid (llegó '00000000-0000-0000-0000-000000000000'). Usa APP_SCOPE.
 ⁃ at scopeKey (src/identity.ts:183:3)
 ⁃ at handle (src/drivers/openfga_driver.ts:2664:21)
 ⁃ at OpenFgaAuthorizationDriver.readSourceFacts …
 ⁃ at OpenFgaAuthorizationDriver.reconcile …
```

**Causa**: `authz_assignments.scope_uuid` / `authz_denies.scope_uuid` son
`NOT NULL` y la raíz se guarda con el centinela `00000000-…`
(`APP_SCOPE_DB_UUID`, detalle de almacenamiento del driver `database`). El 3a
leía `row.scope_uuid ?? null`, que **nunca** es null, así que `scopeKey`
rechazaba `{app, uuid}` con un **422 a mitad de pasada**. Efecto real: un
`grant` o un `deny` en `app` hacía **reventar la migración entera**, sin migrar
nada de lo que venía después.

**Arreglo**: `fromDbScopeUuid` (que ya existía, privada en
`database_driver.ts`) se **exporta** y se usa en las dos ramas de
`readSourceFacts`. Caso propio en las dos direcciones
(«los hechos de la RAÍZ se migran en las dos direcciones»), y su mutante:

```
== M1-raiz   (se vuelve al `?? null`)
❯ migration contract […] / 448 preguntas idénticas, database → openfga: …
ℹ InvalidIdentityError: Scope inválido: el scope 'app' es la raíz y no admite uuid (llegó '00000000-0000-0000-0000-000000000000'). Usa APP_SCOPE.
❯ migration contract […] / 448 preguntas idénticas, database → openfga → database (--prune): …
ℹ InvalidIdentityError: …
❯ 3b-3b · el contrato de migración SABE fallar / una pérdida REAL que no se declara hace fallar el contrato
ℹ InvalidIdentityError: …
❯ 3b-3b · el contrato de migración SABE fallar / una pérdida DECLARADA que no ocurre también hace fallar el contrato
ℹ InvalidIdentityError: …
❯ 3b-3b · reconcile --to=database (servidor real) / los hechos de la RAÍZ se migran en las dos direcciones (el centinela de `app` no es un uuid)
ℹ InvalidIdentityError: …
Tests  52 passed, 5 failed (57)
```

---

## B3 · `runMigrationContract` — la garantía

`src/testing/migration_contract.ts`, publicado en
`@jantstack/adonis-authz/testing` junto al resto de la suite: un driver de
terceros tiene que poder correrlo, porque la promesa «migración idempotente y
bidireccional entre drivers» no la puede sostener un test privado del paquete.

**Forma**: el MOTOR (`runMigrationDirection(harness, direction)` ⇒
`MigrationVerdict`) está separado del registro de casos
(`runMigrationContract` / `registerMigrationContract`) **a propósito**: es lo
que permite al propio paquete demostrar que el contrato sabe fallar sin montar
un runner falso.

### La siembra fija

7 nodos (`app`, 2 organizations, 4 units; profundidad 4: `app → org1 → unit1 →
unit4`), 6 holders (4 `users` + 2 `admins`, y **uno de los admins comparte uuid
con un user** para que el invariante 4 esté en el set), 4 roles (dos a nivel
`app`, uno a `organization`, uno a `unit`), 4 permisos (uno de ellos,
`admin:all`, **no lo lleva ningún rol**: hay preguntas que son `false` en todas
partes), **14 grants** de los que **5 llevan caducidad** (4 vivas y **1 ya
pasada**), y **6 denies** (incluido uno en la RAÍZ, que es lo que destapó el bug
de arriba). Todo escrito con la API del driver, nunca a mano: lo que se migra
tiene que ser lo que el motor escribe.

### Las 448 preguntas

No es un número redondo por casualidad: es el producto de la siembra.

| Pregunta | Cuenta |
|---|---|
| `authorize` | 6 holders × 7 scopes × 4 permisos = **168** |
| `hasRole` | 6 × 7 × 4 roles = **168** |
| `listRoles` | 6 × 7 = **42** |
| `listScopes` | 6 × 4 permisos = **24** |
| `listSubjects` | 4 roles × 7 = **28** |
| `listRoleScopes` | 6 × 3 tipos de scope = **18** |
| | **448** |

Hay un caso que lo fija (y que corre sin servidor, en los 4 motores):
`3b-3b · el set fijo de preguntas / son 448, y son exactamente 168 + 168 + 42 +
24 + 28 + 18` — con la descomposición por tipo y la comprobación de que **no hay
ninguna repetida** (448 preguntas, no 448 llamadas a la misma).

### Las tres combinaciones

1. **`a→b`**: siembra en `database`, migra a `openfga`, compara.
2. **`b→a`**: siembra en `openfga`, migra a `database`, compara.
3. **`a→b→a` con `--prune`**: siembra en `a`, ida, y **vuelta con `--prune`**;
   se comparan las respuestas de `a` antes y después. Con `--prune` la vuelta
   sí puede quitarle algo a `a` — y lo que se lleva es exactamente la pérdida
   declarada (`expired`), que no cambia ninguna respuesta. Sin `--prune` el
   viaje redondo sería trivialmente limpio y no demostraría nada.

### `expectedLosses`: corta por las DOS caras

Ésta es la parte que hace del contrato una garantía y no un adorno:

1. **una respuesta que cambia y que ninguna pérdida declarada explica ⇒ FALLA**;
2. **todo lo que la pasada dejó fuera (cada motivo de `report.skipped`) y no
   está declarado ⇒ FALLA**. Sin esta mitad, un driver podría saltarse lo que
   quisiera mientras las 448 respuestas de *esa* siembra no cambiaran, que es
   justo la clase de bug que una siembra fija no puede ver. «Nunca se ignora
   ninguna» significa esto;
3. **una pérdida declarada que NUNCA ocurre ⇒ FALLA** también: una pérdida que
   no pasa es una línea falsa en el README, y el README es el contrato con el
   consumidor.

`changesAnswer` es **opcional y por defecto no reclama ninguna pregunta**:
declarar «esta pérdida puede cambiar cualquier respuesta» sería una declaración
sin contenido que taparía cualquier bug.

### El contrato SABE fallar (tres mutantes)

**(1) Una pérdida real sin declarar** — `expectedLosses: []`:

```
== M3-contrato-asimetrico   (se quita la regla «contado ⇒ declarado»)
❯ 3b-3b · el contrato de migración SABE fallar / una pérdida REAL que no se declara hace fallar el contrato
ℹ AssertionError: con expectedLosses vacío, `expired` no está declarada: expected [] not to be empty
Tests  6 passed, 1 failed (7)
```

(Es decir: con la regla puesta, `expectedLosses: []` **falla**; el mutante que
la quita deja pasar la pérdida silenciosa y por eso el caso se pone rojo.)

**(2) Una pérdida declarada que no ocurre** — se declara `unknown-holder-type`,
que esta siembra no produce: `verdict.declaredButAbsent === ['unknown-holder-type']`
y el `failures` lo nombra. Verde hoy.

**(3) Un hecho que se pierde EN SILENCIO** — el mutante más importante, porque
es la forma de una migración «casi correcta»: el ORIGEN se deja los denies por
el camino sin contarlos.

```
❯ migration contract [database ⇄ openfga (facts)] / 448 preguntas idénticas, openfga → database: …
+ Array [
+   "[b→a] la respuesta CAMBIÓ y no hay pérdida declarada que lo explique: authorize(users:…, docs:read, unit|…) — antes 'false', después 'true'",
+ ]
```

Y su recíproco, el mutante que hace desaparecer la pérdida en vez de la
respuesta (el origen filtra las caducadas por su cuenta):

```
== M2-origen-filtra-caducadas
❯ migration contract [database ⇄ openfga (facts)] / 448 preguntas idénticas, openfga → database: …
- Array []
+ Array [
+   "[b→a] la pérdida declarada 'expired' NO aparece contada en report.skipped (motivos vistos: ninguno). Una pérdida que nunca ocurre no se declara: se borra.",
+ ]
❯ 3b-3b · reconcile --to=database (servidor real) / lo que NO se migra sale contado y con su motivo
ℹ AssertionError: la caducada tiene que salir contada: expected +0 to be at least 1
Tests  55 passed, 2 failed (57)
```

Y el mutante que descompone la comparación entera:

```
== M4-contrato-no-compara   (nunca se compara: `if (after === was || true) continue`)
❯ 3b-3b · el contrato de migración SABE fallar / un hecho que se pierde EN SILENCIO cambia una respuesta y no hay pérdida que lo explique
ℹ AssertionError: expected [] not to be empty
Tests  6 passed, 1 failed (7)
```

---

## Las `expectedLosses` del par del paquete, con su razón MEDIDA

El panel había identificado cuatro. **Se verificaron una a una en vez de
copiarlas**, y el resultado es que la lista declarada del par
`database ⇄ openfga (facts)` es **UNA**.

### ✅ Declarada: `expired`

- **Qué**: una asignación cuyo `expires_at` / `valid_until` ya pasó. No concede
  (invariante 3), así que no se migra: escribirla sería llevar al destino una
  caducidad muerta.
- **Dónde se ve**: en las **dos** direcciones y en los **cuatro** motores. En la
  ida la cuenta `readSourceFacts` leyendo `authz_assignments`; en la vuelta la
  cuenta `database.reconcile` a partir de la condición `not_expired` de la
  tupla.
- **Qué respuesta cambia**: **ninguna**. Se pierde la FILA, no una respuesta —
  los `list*` devuelven hechos *vigentes* y `hasRole` filtra por caducidad—, y
  por eso `changesAnswer` no reclama ninguna pregunta. Eso también es una
  afirmación que el contrato comprueba: si cambiara alguna sin declararlo,
  fallaría.
- **Está contada** en `report.skipped['expired']` en las tres combinaciones.

### ❌ NO es una pérdida: precisión sub-segundo en MySQL

**Medida, no supuesta.** El esquema publicado ya la cerró: `expires_at` es
`DATETIME(3)` (el stub lo dice con esas palabras: «el `timestamp` de MySQL
redondea al segundo») y `sqlExpiryCodec` escribe y lee la cadena UTC
`YYYY-MM-DD HH:mm:ss.SSS` con `DATE_FORMAT`, sin depender de `timezone` ni del
`TZ` del proceso (2.5-B · K2). Del otro lado, la condición `not_expired` de FGA
lleva un ISO-8601 con milisegundos. Y un `Date` de JS no tiene más resolución
que ésa.

Caso que lo fija, en los cuatro motores (y por tanto **en MySQL de verdad**):
`la caducidad viaja al MILISEGUNDO en los dos sentidos (la «precisión
sub-segundo» que el panel declaró la cierra DATETIME(3))` — un `expiresAt` con
`.123` ms migra FGA → DB, se lee con el codec y coincide al milisegundo; y la
segunda pasada da `updated === 0`, que es la comprobación fuerte (si se hubiera
truncado, el instante diferiría y saldría como `updated` para siempre).

Verificado: `npm run test:mysql` → **848 passed**.

### ❌ NO es una pérdida de la MIGRACIÓN: la collation `*_ci` (S15)

También medida. Dos partes:

1. **`authz_*` no es case-insensitive.** El stub de migración colaciona
   explícitamente `holder_type`, `holder_uuid`, `scope_type`, `scope_uuid` como
   `utf8mb4_bin`. El `*_ci` afecta a la tabla del CONSUMIDOR (`demo_scopes`).
2. **Las dos direcciones escriben con la identidad CANÓNICA** (`chain[0]`,
   invariante 17), así que lo que hay en `authz_*` y lo que hay en el store son
   la misma ortografía: **la migración en sí no pierde nada ahí**.

Lo que S15 describe existe y sigue existiendo, pero es una divergencia de
**LECTURA**, no de migración: `database` canoniza la ortografía del llamante
contra el árbol y `openfga` en `facts` no (es la contrapartida de
`singleCheckAuthorize`). Eso ya es la capacidad **`canonicalScopeReads`**, con
su par de casos en la suite publicada y con la advertencia en el README. Ocurre
con o sin migrar.

**Lo que SÍ es una pérdida real y ahora se cuenta**: el store puede tener dos
scopes distintos (`scope:unit|aaa…` y `scope:unit|aaa-…`) que la tabla del
consumidor **no puede** tener a la vez (columna `uuid` de PostgreSQL, collation
`*_ci` de MySQL). Al volver, la cadena canónica los funde y dos hechos colapsan
en UNA fila. Antes de este lote eso habría sido un `Map.set` silencioso. Ahora:

- se cuenta como **`folded-scope`** con las dos ortografías nombradas;
- y la fila se queda con la caducidad que **MÁS dura** (`null` = para siempre),
  porque el origen concedía mientras cualquiera de las dos siguiera viva: la
  unión es lo que conserva la respuesta.

```
== M11-fold-silencioso
❯ 3b-3b · reconcile --to=database (servidor real) / dos hechos del ORIGEN que colapsan en UNA fila salen contados (`folded-scope`) y se quedan con la caducidad que más dura
ℹ AssertionError: el colapso se CUENTA, no se traga: expected undefined to equal 1
Tests  49 passed, 1 failed (50)
```

**Honestidad sobre ese caso**: el origen es un doble (una función `facts` que
devuelve dos hechos con el mismo scope canónico) para que corra en los CUATRO
motores. El disparador REAL —dos objetos del store con ortografías distintas del
mismo uuid— requiere escribir a mano en el store y solo se distingue en
PostgreSQL/MySQL; **no está cubierto por un caso contra el `:8101`**, y va en «lo
que no hice». Lo que sí está probado en los cuatro motores es la REGLA (contar y
quedarse con la caducidad más larga), que es lo que decide la respuesta.

### ❌ NO llega a `expectedLosses`: hechos sobre scopes fantasma

Existe, es real y **está contada** (`unknown-scope`) en las dos direcciones, con
caso propio en cada una (`lo que NO se migra sale contado y con su motivo`, en
los dos grupos). Pero **la siembra fija del contrato no la produce** —sus 7
nodos están vivos—, y declarar una pérdida que no ocurre hace fallar el contrato
por la cara (3). Así que se cubre con casos y no con una entrada de
`expectedLosses`. Si un consumidor migra con scopes fantasma en su base, su
harness la declarará y su contrato la exigirá contada.

---

## B4 · La capacidad y la entrada de contrato

El 3a dejó escrito (§«Lo que NO hice», punto 3) que la capacidad la decidiera
este lote «con el contrato de migración entero». Decisión:

- **`reconcile` NO es una capacidad.** Se queda con el patrón de método
  opcional del puerto (`E_AUTHZ_UNSUPPORTED`), como lo dejó el 3a. Motivo:
  después de este lote **los dos drivers del paquete lo implementan**, así que no
  hay cara `false` que un harness real pueda ocupar, y `src/testing/contract.ts`
  exige que una capacidad declarada tenga caso — una capacidad con una sola cara
  observable es una promesa sin juez.
- **`enumerateFacts` SÍ lo es**, y con las **dos caras ocupadas por drivers
  reales**: `openfga` la declara `true` (sus hechos son tuplas y solo él sabe
  volverlas a `(holder, rol, scope)`), `database` la declara `false` a propósito.

**Los dos casos del par** (`level: '2.2'`, en `src/testing/contract.ts`):

- `whenTrue`: se pasean las páginas con `limit: 1`, se comprueba que nunca
  llegan más de `limit`, que el cursor **no se repite**, que el deny sale como
  hecho, que **la caducada también sale y con su instante exacto**, que la
  identidad del rol es el uuid y que cada hecho viene nombrado (`detail`); y que
  con una página grande sale el mismo conjunto (el puerto promete «como mucho
  `limit`», así que un backend con su propio tope de página lo respeta y da
  cursor — es lo que hace `openfga`, cuyo `Read` no admite `pageSize` > 100).
- `whenFalse`: el driver no trae el método **y** `authz:reconcile` lo DICE con
  500 `E_AUTHZ_UNSUPPORTED` nombrándolo, contra un destino de laboratorio que sí
  sabe reconstruirse. Lo que se juzga es que la pasada muera nombrando al
  ORIGEN, no al destino, y que **no llegue a leer cero hechos**: ése es el
  fail-dangerous (leer cero + `--prune` = destino vacío), y es exactamente lo
  que M13 enseña en rojo.

Recuentos del juez actualizados en `tests/contract_harness.spec.ts`
(81→82, 76→77, 85→86) y capacidades declaradas en los harness de
`tests/contract.spec.ts`, `tests/openfga_facts.spec.ts` («las capacidades
declaradas del driver son las de la tabla del README») y la tabla del README.

---

## Verificación

```
npx tsc --noEmit -p tsconfig.json && npm run typecheck && npm run check:purity && npm run build   ✔
OPENFGA_TEST_URL=http://localhost:8101 npm test                    → 752 passed  (partía de 720)
OPENFGA_TEST_URL=http://localhost:8101 npm run test:sqlite-file    → 754 passed  (partía de 722)
TEST_PG_URL=… OPENFGA_TEST_URL=… npm run test:pg                   → 848 passed  (partía de 815)
OPENFGA_TEST_URL=http://localhost:8101 npm run test:mysql          → 848 passed  (partía de 815)
OPENFGA_TEST_URL=http://localhost:8103 npm test   (tope 3)         → 752 passed
```

Las cinco corridas son POSTERIORES a todos los cambios de código y de
documentación de este lote. `docker rm -f openfga-tiny` hecho.

**Stores en el `:8101`**: 50, y **ninguno de hoy** (47 del 28-08, 2 del 29-08,
1 del 26-08 — los de los scripts del auditor). Los harness de este lote crean su
store y lo borran en el teardown.

---

## Ficheros

| Fichero | Qué |
|---|---|
| `src/types.ts` | `ReconcileFact`/`ReconcileFactPage`/`ReconcileFactsEnumerator`; `ReconcileSource.facts?`; `AuthorizationDriver.enumerateFacts?`; capacidad `enumerateFacts`; `ReconcileOptions.maxTuples`; `DEFAULT_RECONCILE_MAX_TUPLES` |
| `src/reconcile.ts` (**nuevo**) | Piezas puras compartidas por las dos direcciones (`reconcileBatchSize`, `reconcileMaxTuples`, `RECONCILE_MAX_DETAILS`, fases) |
| `src/errors.ts` | `ReconcileTooLargeError` (500 `E_AUTHZ_RECONCILE_TOO_LARGE`) |
| `src/drivers/database_driver.ts` | `reconcile(source, options)`, `eachReconcileRow`, claves del diff, `longerExpiry`, `fromDbScopeUuid` **exportada**, capacidad `enumerateFacts: false` |
| `src/drivers/openfga_driver.ts` | `enumerateFacts(page)`, `readEveryTuple(maxTuples)`, el arreglo del centinela de la raíz, capacidad `enumerateFacts: true` |
| `src/manager.ts` | `reconcile({ to, from?, … })` y `#factsEnumerator` (regla del origen, perezosa) |
| `src/testing/migration_contract.ts` (**nuevo**) | `runMigrationContract` / `registerMigrationContract` / `runMigrationDirection`, siembra fija y las 448 preguntas |
| `src/testing/contract.ts` · `src/testing/main.ts` | el par `enumerateFacts` y los exports de `/testing` |
| `commands/authz_reconcile.ts` | `--from`, `--max-tuples`, aviso por dirección |
| `index.ts` | `ReconcileTooLargeError`, los tipos nuevos y `DEFAULT_RECONCILE_MAX_TUPLES` |
| `tests/reconcile.spec.ts` | +21 casos (13 de la vuelta, 7 del origen, 1 del comando) |
| `tests/migration_contract.spec.ts` (**nuevo**) | el contrato aplicado al par real + los 3 casos de «sabe fallar» + el set fijo |
| `tests/contract.spec.ts` · `tests/contract_harness.spec.ts` · `tests/openfga_facts.spec.ts` | capacidad declarada y recuentos del juez |
| `README.md` · `CHANGELOG.md` · `CLAUDE.md` · `stubs/config/authorization.stub` | documentación |

---

## Lo que NO hice, y por qué

1. **No hay migración por particiones ni cursor persistido entre ejecuciones**
   (B5). Es la decisión del lote: se **declara** con su cota y su error
   (`maxTuples` / `E_AUTHZ_RECONCILE_TOO_LARGE`) en vez de fingir que se cierra.
   El motivo estructural es que reconciliar exige la foto entera del destino, y
   partirla exige un criterio de partición que ninguna de las dos direcciones
   tiene hoy (¿por tenant? ¿por scope? el `Read` de FGA no filtra por subárbol).
   Está escrito en README, CHANGELOG y CLAUDE.md, y «reanudable» sigue siendo
   *idempotente y se repite*.
2. **`database` no implementa `enumerateFacts`**. Decisión, no olvido (§2 de
   «lo que se decidió»). Consecuencia real y declarada: un driver de TERCEROS
   que quiera ser destino de una migración **desde `database`** no puede
   consumir un puerto — tiene que leer `authz_assignments`/`authz_denies`, que
   es esquema publicado y documentado, exactamente como hace
   `openfga.reconcile`. Si el dueño prefiere la simetría total del puerto, es un
   cambio pequeño (≈40 líneas) pero deja la capacidad con las dos caras `true` y
   sin harness que ocupe el `false`.
3. **El disparador REAL de `folded-scope` no tiene caso contra el `:8101`.** La
   REGLA está probada en los cuatro motores con un origen doble; el escenario
   completo (dos objetos del store con ortografías distintas del mismo uuid,
   fundidas por la columna `uuid` de PG) requiere escribir tuplas a mano y solo
   se distingue en PG/MySQL. Queda anotado como el hueco de este lote.
4. **`unknown-scope` no está en `expectedLosses`** del par del paquete: la
   siembra fija no lo produce y declarar una pérdida que no ocurre hace fallar
   el contrato (cara 3). Tiene casos propios en las dos direcciones.
5. **No se añadió capacidad `reconcile`.** Motivo arriba (B4): no hay cara
   `false` que un harness real pueda ocupar después de este lote.
6. **No se tocó el orden ni el criterio de `--to=openfga`** más allá del bug del
   centinela de la raíz. Las decisiones 2 y 3 del informe del 3a (qué borra la
   pasada sola, `E_AUTHZ_MASS_RECONCILE_REFUSED`) se han replicado tal cual en
   la vuelta, no re-litigado.
7. **`runMigrationContract` no juzga la ventana del relay ni lo aparcado.** Son
   `drift`, no pérdidas: no dejan nada fuera de `skipped` y ya los reporta el
   comando (3a). Meterlos en `expectedLosses` mezclaría «lo que la migración
   pierde» con «lo que el consumidor todavía no ha relevado».
8. **`--max-tuples` no tiene caso end-to-end por el comando ace.** Como el resto
   de banderas del comando, se prueba por `manager.reconcile` y por la función
   pura `reconcileLines`; el comando no tiene más lógica que pasarlas.
