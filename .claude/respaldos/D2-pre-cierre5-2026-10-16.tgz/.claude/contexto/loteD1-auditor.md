# Lote D · sublote D1 (núcleo del deny): informe del AUDITOR · 2026-10-15

Árbol: `main` sobre `493c649` (= `v2.5.0-alpha.2`) con D1 sin commitear (26 ficheros). Repos en una copia
(`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/audD1/tree/`, con la guardia de stores de
`bin/test.ts` APAGADA en la copia para no barrer los stores del coordinador). Stores efímeros en `:8090` creados y borrados
por cada repro (`audD1-*`; comprobado al final: 0 restos). No toqué contenedores, `test:pg|mysql` ni los corredores de mutantes.

## Veredicto en una línea

**Seguro con reservas:** no encontré ningún camino de LECTURA que conceda a un denegado. Sí encontré uno de ESCRITURA: una
`purgeSubject` de `openfga` que se corta a medias concede algo que no concedía ni antes ni después (🟠 1, ejecutado). Eso
contradice la letra del README y del CHANGELOG. D1 no queda cerrado mientras el 🟠 siga abierto.

---

## Hallazgos (por severidad)

### 🟠 1 · `purgeSubject` en `openfga` cortada a medias: la membresía de grupo que TRANSPORTA un deny cae antes que el allow directo ⇒ el sujeto concede (S3 roto)

- **Escenario (EJECUTADO contra `:8090`).** Precondición: `U ∈ group:g` (`relate(U, member, g)`),
  `deny(g#member, viewer, docV)`, `relate(U, viewer, docV)` escrito DESPUÉS de 100 grants más de `U`. Antes de la purga:
  `check(U, viewer, docV) = false`. El atacante (o una caída del backend) hace que falle el 2.º `deleteTuples` de
  `purgeSubject(U)`, igual que el espía del caso D-26. Resultado: 503 marcado como parcial, y
  **`check(U, viewer, docV) = true`**. El 1.er lote llevaba `member@group:g` y no llevaba `viewer@docV`.
  Repro: `…/scratchpad/audD1/tree/tests/aud_d1_purge.spec.ts`. Salida:
  `ANTES false · purgeSubject 503 · lote 1 incluye member@group: true · lote 1 incluye victimDoc: false · DESPUÉS true`.
- **Causa** (`src/drivers/openfga_relations_driver.ts`, `#purgeByFilters` y `purgeSubject`): el orden global clasifica
  por PREFIJO (`denied_*` al final, todo lo demás primero). Pero `group:g#member@U` no es un deny y sí transporta denies.
  Además, `types = [FACTS_GROUP_TYPE, …]` hace que las membresías se lean y se borren PRIMERO. La gemela
  `purgeSubject(g#member)` falla igual: la arista anidada `group:h#member@group:g#member` cae antes que el allow directo
  de `g#member`, y los miembros de `g` pierden el deny de `h` mientras conservan el allow. El estado intermedio concede
  algo que no conceden ni el estado inicial ni el final. Esto NO es la fila declarada S10, que solo describe el estado final.
- **Efecto frente a lo esperado.** S3 del tester dice «cortada a medias ningún sujeto denegado concede». README y
  CHANGELOG lo publican así: «so a purge cut halfway leaves denies in excess, never in default». El efecto observado lo
  desmiente. El caso D-26 solo cubre `purgeObject` con deny DIRECTO, así que el hueco no tiene caso. `database` no se ve
  afectado: su purga es un único `DELETE`.
- **Steelman del defensor:** «la purga ya sale marcada como parcial (`indeterminate: true`) y el operador la repite».
  No me convence. Entre el 503 y la repetición, el sujeto que se está dando de baja tiene un acceso que nunca tuvo, y
  justo para eso existe S3 (invariante 6: «denies de MÁS, nunca de menos»).
- **Qué exige el cierre.** (a) Orden: allows sobre objetos que no son `group` → membresías `group:*#member` (son
  transportadoras de deny) → `denied_*`. (b) Residuo honesto: con más de un `Write` de membresías (más de 100), una que
  transporta un deny puede caer antes que otra que transporta un allow. Hay que declararlo como fila con caso, o escribir
  las membresías de un sujeto en un solo `Write`, con cota y 500 si se pasa. (c) Caso nombrado «purgeSubject cortada, deny
  por grupo» para holder y para userset, con su mutante (el orden de alpha.2 o el «solo prefijo» de hoy). (d) Corregir la
  frase del README y del CHANGELOG para que diga lo que se garantiza de verdad. Cuatro líneas de cierre: gemelos
  `purgeObject` ↔ `purgeSubject(holder)` ↔ `purgeSubject(userset)`; tabla de verdad {transporte directo, por grupo,
  anidado} × {corte tras lote k}.

### 🟡 2 · La puerta del opt-in en `deny` de los DRIVERS no tiene caso que la mate (solo la del manager)

- **Escenario (mutante EJECUTADO en `:memory:`).** Quito `assertRelationDenyable` y `assertDenyNoExpiry` de
  `DatabaseRelationsDriver.deny` y corro `relations_contract`, `relations_database`, `relations_harness`, `relations_bridge`
  y `relations_service`: **185 en verde**. En `relations`, `guard_surface` y `capabilities` cae solo G-M, por el `find`
  de un mutante que deja de casar. Eso es un rojo estructural, no de efecto, y se «arregla» reescribiendo el `find`.
  Todos los casos que esperan `E_AUTHZ_RELATION_NOT_DENYABLE` entran por el MANAGER: `relations_contract.ts:2247-2250`,
  `relations_database.spec.ts:1775` y `relations_openfga.spec.ts:1612`. `openfga` está igual por lectura: ningún caso llama
  a `driver.deny` sobre un tipo en `'read'`. La guardia de superficie no tiene columna «opt-in», y los 30 mutantes por
  pieza no están en el corredor de CI.
- **Efecto.** El informe §1.1 afirma que la puerta «la aplican el manager, los dos drivers y el doble». Por
  `manager.driver()`, que es la salida documentada de las barreras, una regresión de esa línea dejaría escribir un deny en
  FASE 1. Es justo lo que D10 impide: en `openfga`, con pods aún sin fijar, sería la ventana S11.
- **Steelman:** «es defensa en profundidad; el manager ya lo valida». Me convence a medias. En `{transaction}` el precedente
  L-5 exigió dientes en el driver precisamente porque `driver()` no es salida.
- **Cierre:** un caso por driver (y por el doble) que llame a `driver.deny` sobre `note`, `workspace` (`'read'`) y `group`
  ⇒ 422 con 0 llamadas al backend, y el mutante en el corredor (o una columna `denyable` en la guardia).

### 🟡 3 · `decideMany` de `openfga` sin `modelId` fijado: un memo rancio da `none` donde `check` da `false` por deny (decisión 5)

- **Escenario (LEÍDO, `openfga_relations_driver.ts`, `#modelDenied` y `decideMany`).** Un proceso cuya config no tiene
  tipos con deny no está obligado a fijar `modelId` (D14 no aplica). El proceso memoriza el ÚLTIMO modelo, que no tiene
  `denied_document#…`. Después alguien publica un modelo con deny y escribe un deny sobre `doc` (flota con dos configs:
  reactivación del opt-in). En ese proceso `check(U, viewer, doc)` da `false`, porque el servidor resta con el último
  modelo, pero `decideMany` no pregunta `denied_*` (`sources` vacías) y responde `none`. La cadena del llamante sigue
  subiendo y concede por el padre. Es fail-open en la primitiva de cadena.
- **Steelman:** «exige violar el runbook (fase 2 solo con toda la flota en la config nueva) y el memo se reinicia con el
  proceso». Me convence en buena parte, y por eso es 🟡 y no 🟠.
- **Cierre:** sin pin, no memorizar, o releer cuando `check` y el memo puedan discrepar. Lo mínimo es declararlo en el
  README junto a la decisión 5, con caso.

### 🟡 4 · `membersOf` (`database`) con deny: N consultas en serie sin cota ni deadline total (decisión 10)

- **LEÍDO** (`database_relations_driver.ts`, `membersOf`): basta UNA fila `denied_*` vigente en el objeto para que cada
  candidato pase por `check`, en serie, cada uno con su propio `now`. Un objeto con 10 000 miembros y un deny son 10 000
  CTE. Cada sentencia tiene su deadline, pero no hay deadline total ni `maxMembers`. Es una amplificación barata para quien
  puede escribir un deny: disponibilidad, no concesión.
- **Steelman:** «coste declarado en el código; la CTE única es más SQL por motor». Me convence que no sea 🟠, no que quede
  sin cota.
- **Cierre:** una cota (500 o 503 al pasarla, nunca una lista parcial) o la CTE con la relación, y la cifra en «Limits».

### ⚪ 5 · Letra ≠ efecto en la decisión 4

El informe dice que D-31 no cubre `removeDeny`/`listDenies`. El código sí guarda `removeDeny` para los tipos con opt-in
(`await this.#assertModelDeny([object.type])` en `removeDeny`) y no guarda `listDenies`. Sin opt-in no hay guarda.
**Medido** (`aud_d1_removedeny.spec.ts`): con el opt-in retirado y el modelo republicado SIN `denied_*`, `removeDeny`
responde 200 y BORRA de verdad (`listDenies` pasa de 1 a 0 y, con el modelo viejo, `check` vuelve a `true`). O sea, el
«`removeDeny` exitoso que no quita nada» no ocurre. Cierre: alinear la letra de la decisión 4 (y el docblock de
`removeDeny`) con el código.

### ⚪ 6 · El doble PUBLICADO cambió de semántica sin línea en el CHANGELOG (decisión 12)

`makeRelationsDriver` (en `/testing`) ahora hace `check(g#member, …)` subiendo por los grupos de `g`. Es coherente con
`database` y con FGA (y la terminación con ciclos está bien: punto fijo). Pero un tercero que fijaba la respuesta vieja del
doble verá cambiar su suite. El CHANGELOG solo dice «both doubles». Cierre: una línea en `[Unreleased]`.

### ⚪ 7 · D-31 comprueba que EXISTE `denied_<rel>`, no que `<rel>` reste ni la forma del cierre

Un modelo escrito a mano con `denied_viewer` declarado y `viewer` sin `but not` pasaría la guarda. El paquete no produce ese
estado. Basta con declararlo.

---

## Decisiones del implementador (§4 tiene 13, no 10)

| # | Decisión | Veredicto | Por qué |
|---|---|---|---|
| 1 | `deny: 'read' \| 'write'`; `true`/`false`/`null` ⇒ 422 | **Ratificar** | Nada publicado lo usa; el 422 al definir es ruidoso y nombra las dos fases. |
| 2 | `contractDenyRelationsConfig` aparte | **Ratificar** | Conserva D-29 y `EXPECTED_FUSED`. |
| 3 | `decideMany` sin capacidad ⇒ 500 | **Ratificar** | Sin deny no hay tri-estado que prometer; `allow/none` callado sería peor. |
| 4 | D-31 no cubre `removeDeny`/`listDenies` | **Condicionar** (⚪ 5) | El código sí cubre `removeDeny` en tipos con opt-in. El efecto es bueno (medido); hay que corregir la letra. |
| 5 | `openfga` pregunta el deny solo si el MODELO lo declara (memo) | **Condicionar** (🟡 3) | Sin pin el memo puede quedar rancio en el sentido `none` ⇐ `deny`. |
| 6 | `deny` = un `Write` sin `Read` | **Ratificar** | Re-deny idéntico ignorado (D-03); un deny condicional escrito a mano da 409/503 y el deny se queda: fail-closed. |
| 7 | `expiresAt` presente (también `null`/`undefined`) ⇒ 422 | **Ratificar** | — |
| 8 | Capacidad después de F-05; `*` antes de la gramática | **Ratificar** | Mismo orden que `membersOf`. |
| 9 | Reutiliza `E_AUTHZ_CHECK_MANY_BATCH` | **Ratificar** | El mensaje nombra `decideMany` (`check_many.ts`, parámetro `operation`); el README lo dice en «Limits». |
| 10 | `membersOf` con un `check` por candidato | **Condicionar** (🟡 4) | Necesita cota o deadline total. |
| 11 | Oráculo de T1 = tabla literal + fórmula a mano | **Ratificar** | Un mutante de `cutPathAllows` no se esconde detrás del oráculo. |
| 12 | Doble reescrito sobre el principal | **Ratificar con letra** (⚪ 6) | Falta la línea del CHANGELOG para terceros. |
| 13 | Purga: leer todos los filtros y borrar en orden global | **Rechazar como cierre de S3** (🟠 1) | Clasificar por prefijo no ve las membresías que transportan deny. |

---

## Lo que intenté y NO se rompió

- **Retículo en DIAMANTE** (`viewer ⊇ editor, commenter ⊇ owner`, un caso que T1 no cubre porque T1 es una cadena):
  256 estados × 4 preguntas × (`checkMany`, `decideMany`) en `database` `:memory:` frente a `openfga` `:8090`:
  **0 diferencias** (`aud_d1_diamond.spec.ts`). El cierre ascendente del generador (`denied_X = this ∨ denied_P`, con
  `X = base but not denied_X`) equivale a `cutPathAllows` también con varios caminos, porque el grant de `T` se anula en el
  propio `T`, antes de propagarse.
- **S12 / S15, re-ejecutados** con el mutante `fga.S12.decideMany.error-none`: los dos casos caen en rojo, y el mensaje
  muestra justo la forma del fail-open (`["none"]`). El mutante está bien matado.
- **`removeDeny` frente a un modelo sin `denied_*`**: borra de verdad (ver ⚪ 5).
- **Lecturas**: `check`, `checkMany`, `decideMany` y `listObjects` en los dos drivers y en el doble leen grants y denies
  en UNA consulta/`batchCheck`, con un solo `now`. Un `error` por ítem acaba en 503 por `alignBatchResults`; un resultado
  ausente, en 500. `listObjects` truncado es un subconjunto. `listSubjects` no resta, lo dice el README y es inocuo para la
  decisión (enumera hechos).
- **Identidad / catálogo**: ninguna relación de dominio puede empezar por `denied_` (`RESERVED_SLUG_PREFIXES`, en la
  config), así que `relate(…, 'denied_viewer', …)` es 422 por F-05 y el `#split` de `database` no confunde un allow con un
  deny. `*` ⇒ 422. Deny sobre `group` ⇒ 422 (y `group` no se puede declarar como tipo). El partitionKey va dentro del id del
  objeto (P-2, D-30).
- **D14 / D-31**: la vista `withClock` vuelve a pasar por el constructor (D14) y comparte el memo; `modelId: ''` cuenta como
  ausente; el cliente se construye con `authorizationModelId: options.modelId`.
- **D8**: una fila `denied_*` de una relación que la config no declara es inerte, porque nunca se lee y preguntar por esa
  relación es 422. La config persistida (`saveRelationsConfig`) guarda `deny` porque serializa la spec entera.
- **Purgas**: `purgeObject(doc)` cortada deja de más (D-26 correcto); `purgeObject(group:g)` cortada deja un subconjunto
  del estado final (S9, no peor). En `database` cada purga es un único `DELETE`.
- **Transversal**: `EXPECTED_FUSED`, `migration_stub.spec` y `freeze.spec` no están en el diff. El CHANGELOG solo AÑADE
  `[Unreleased]` encima de alpha.2. `openfga_facts`, `migration_stub`, `relations_events_docs` y `scope_depth` dan 111/111
  en `:memory:`. Los casos existentes que el lote puso en rojo (§0 del informe) tienen justificación cierta: la sonda de
  purga mide la misma propiedad con otra definición de «tras borrar».

## Preguntas abiertas que cambian el veredicto

1. ¿S3 significa «ningún estado intermedio concede lo que no concedían ni el inicial ni el final» (entonces el 🟠 1 bloquea
   D1) o solo «un deny DIRECTO sobrevive a su allow» (entonces la frase publicada es falsa y hay que reescribirla)?
2. Fuera de D1, pero bloqueante para publicar: hoy `reconcile` `database → openfga` NO lleva los denies (filas `denied_*`
   ⇒ `skipped.undeclared`, informe §6). alpha.3 no puede salir sin D2.
