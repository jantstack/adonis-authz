# L-5 · `openfga` rechaza `{ transaction }` CON DIENTES, en los dos puertos — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `f468b83` (= L-4b commiteado, árbol limpio al empezar; `git status` vacío). Árbol principal, SIN
> commits (los hace el dueño). Alcance: el lote L-5 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-5, §2
> «Capacidad», §6.1). Lo que gobierna: **una tupla de OpenFGA no puede entrar en una transacción SQL** (el store es
> otro servicio; no hay 2PC). `transactionalWrites` significa EXACTAMENTE «los dos o ninguno»; `openfga` no puede
> prometerlo y lo dice con `false` explícito; el consumidor lee la capacidad y ajusta («tiene que funcionar ya sea
> con un driver o con el otro, y que el cliente ajuste según lo quiera manejar»).

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l5-rojo-*.log`, `l5-verde-*.log`, `l5-mutante-*.log`, `suite-*.log`). Los mutantes se plantan con `perl` sobre una
copia de respaldo y se restauran en el MISMO comando.

(Informe INCREMENTAL: se completa pieza a pieza según avanza el lote.)

## Plan de piezas (escrito antes de tocar código)

Lo que L-2 dejó: la puerta 1 en los DOS managers (500 `E_AUTHZ_UNSUPPORTED` antes del driver) y las caras
`whenFalse` de los dos runners, que YA corren contra el `:8101` (el harness `openfga` de `contract.spec.ts` y el de
`relations_openfga.spec.ts` declaran `false` explícito y el runner registra la cara `whenFalse` contra el store real).
Lo que L-5 tiene que añadir es lo que el runner (genérico, para drivers de terceros) no puede: **el espía sobre el
cliente FGA REAL**, el rechazo por el **DRIVER mismo** (defensa en profundidad: `manager.driver()` con
`{ transaction }` no puede intentar un `Write`), el **arranque** con drivers reales y la **paridad que fija la
asimetría**.

1. **Roles contra el `:8101`** (`tests/contract.spec.ts`, sección `OPENFGA_TEST_URL`, grupo «L-5»): (a) por el
   MANAGER, `grant`/`revoke`/`deny`/`removeDeny` con `{ transaction }` ⇒ 500 nombrando `'openfga'` y la operación,
   espía sobre TODOS los métodos del cliente FGA (`write`/`writeTuples`/`deleteTuples`/`read`/`check`/`batchCheck`…) =
   0 llamadas, `onWrite` sin disparar; sin `transaction` la misma llamada entra (>0 llamadas, `authorize` true).
   (b) por el DRIVER en directo (`manager.driver()`), las cuatro ⇒ el mismo 500 con cero llamadas. (c) arranque:
   `requireTransactionalWrites: true` + `default: 'openfga'` (driver REAL) ⇒ 500 `E_AUTHZ_CONFIG` al resolver
   (`driver()`, `authorize`, `grant` sin transacción); `default: 'database'` + `openfga` solo REGISTRADO ⇒ resuelve
   y la factory de `openfga` no se invoca. Rojo esperado: (b) rojo literal (hoy el driver ignora `transaction` y
   ESCRIBE); (a) ya pasa ⇒ **mutante M1**: puerta 1 del manager de roles apagada ⇒ (a) rojo ANTES del driver que
   re-valida y verde DESPUÉS.
2. **Driver `openfga` de roles re-valida** (`src/drivers/openfga_driver.ts`): `revoke`/`deny`/`removeDeny` ganan
   `options?: WriteOptions` (el puerto ya lo declara desde L-2); `rejectTransaction(operation, options)` como
   PRIMERA línea de las cuatro (antes de `assertIdentity`, del catálogo y del store) ⇒ `UnsupportedOperationError`
   (misma clase y `code` que la puerta 1) diciendo que lo rechaza el DRIVER. `transactionalWrites: false` explícito
   con docblock: por qué (una tupla no entra en una trx SQL) y cuál es la alternativa que SÍ existe (la outbox de
   scopes para el ÁRBOL, que encola en tu trx; para HECHOS no hay outbox: descartada por el panel, fail-open medido).
3. **Relaciones contra el `:8101`** (`tests/relations_openfga.spec.ts`, grupo «L-5»): (a) por el `RelationsManager`
   las cuatro (`relate`/`unrelate`/`purgeObject`/`purgeSubject`) ⇒ 500 nombrando `'openfga'` (`driverName`) y la
   operación, cero llamadas al cliente, sin `onRelationWrite`; sin `transaction` entra. (b) por el DRIVER en directo,
   el mismo 500 con cero llamadas. (c) arranque por el PROVIDER (`buildRelationsManager`): `relations.default:
   'openfga'` (driver REAL) + `requireTransactionalWrites: true` ⇒ 500 `E_AUTHZ_CONFIG` al construir; `default:
   'database'` + `openfga` registrado ⇒ construye y la factory de `openfga` no se invoca. **Mutante M2**: puerta 1
   del `RelationsManager` apagada ⇒ (a) rojo antes del driver que re-valida, verde después.
4. **Driver `openfga` de relaciones re-valida** (`src/drivers/openfga_relations_driver.ts`): `purgeObject`/
   `purgeSubject` ganan `options?: RelationTransactionOptions` (el puerto ya lo declara); `#rejectTransaction` como
   PRIMERA línea de las cuatro (antes de F-05 y del `Read`); docblock de la capacidad como en 2.
5. **PARIDAD que fija la ASIMETRÍA a propósito** (`tests/relations_bridge.spec.ts`, la spec puente: mismo
   catálogo/árbol, los dos drivers de cada puerto): la MISMA llamada con `{ transaction }` —`grant(alice, 'r0',
   app)` en roles, `relate(u, 'viewer', doc, p)` en relaciones— es **200 en `database`** (escribe POR la trx, commit,
   censo 1, `authorize`/`check` true) y **500 en `openfga`** (cero llamadas al cliente, el store sin la tupla) — y el
   caso lo afirma en positivo con el docblock del porqué. Como `{ transaction }` exige pool ≥ 2 (decisión del
   dueño), la mitad `database` muestra el 200 en `sqlite-file`/PG/MySQL; en `:memory:` la MISMA llamada da lo que
   pool 1 da honestamente (503 por la barrera, cero sentencias por la trx: la cara de L-3/L-4) y la mitad `openfga`
   es idéntica en los cuatro modos. Ninguna rama es un skip: las dos mitades se afirman en todos los modos.
6. **El grep** (`tests/openfga_driver.spec.ts`, sin servidor): en `openfga_driver.ts`, `openfga_relations_driver.ts`,
   `openfga_facts.ts` y `openfga.ts` ninguna línea que diga «atómico/atomic» habla a la vez de la transacción del
   consumidor (`consumidor`, `llamante`, `{ transaction }`, `trx`, «transacción SQL»); y los dos drivers declaran
   `transactionalWrites: false` LITERAL (no por omisión) con la palabra `outbox` en el comentario que la acompaña.
7. Docs: CHANGELOG (sección «Lot L-5» antes de L-4b), docblocks. README/roadmap NO (L-6).

Conteos de `contract_harness.spec.ts`/`relations_harness.spec.ts`: no se mueven (los runners no cambian).

## Pieza 1 + 2 · Roles: el rechazo con dientes contra el `:8101` y el driver que re-valida ✅

**Casos** (`tests/contract.spec.ts`, grupo «L-5 · openfga (roles) rechaza { transaction } con dientes…», dentro de
`if (openFgaTestUrl)`, etiquetado `@l5` para poder correrlo suelto —los títulos llevan comas y el filtro `--tests`
de Japa las parte—; helper nuevo `tests/helpers/fga_spy.ts` = `spyFgaClient(driver)`: sustituye `driver.client` por
un Proxy que cuenta CADA método del cliente FGA real y delega en él):

1. **Por el MANAGER**: `grant`/`revoke`/`deny`/`removeDeny` con `{ transaction }` ⇒ 500 `E_AUTHZ_UNSUPPORTED`
   nombrando `'openfga'`, la operación y «transacción SQL»; `spy.calls` = `[]` (ni `write`, ni `read`, ni `check`,
   ni `batchCheck`); `onWrite` vacío. Sin `transaction` la MISMA llamada entra (`spy.total() > 0`, `authorize` true,
   un evento). Ya pasaba (puerta 1 de L-2) ⇒ mutante, abajo.
2. **Por el DRIVER en directo** (`manager.driver()`): las cuatro ⇒ el MISMO 500 con `spy.calls` = `[]`; `authorize`
   sigue `false` (la tupla NO se escribió «fuera de la transacción» en silencio); sin `transaction` entra.
3. **ARRANQUE**: `requireTransactionalWrites: true` + `default: 'openfga'` (driver REAL sobre el `:8101`) ⇒
   `driver()`, `authorize` y `grant` sin transacción son 500 `E_AUTHZ_CONFIG` nombrando `'openfga'` y
   `transactionalWrites`, cero llamadas al cliente; y `default: 'database'` (`true` por defecto) con `openfga` solo
   REGISTRADO ⇒ `driver()` resuelve, `grant`+`authorize` funcionan y **la factory de `openfga` no se invoca** (0).

**Rojo literal** (`l5-rojo-roles.log`; el driver ignoraba `transaction` y escribía la tupla):
```
ℹ AssertionError: ROJO: driver.grant con { transaction } NO lanzó sobre openfga (¿escribió una tupla fingiendo ir en la transacción?)
Tests  2 passed, 1 failed (3)
```
**Verde** (`l5-verde-roles.log`): `Tests 3 passed (3)`. `tsc` src y `npm run typecheck`: 0 errores.

**Código:**
- `src/errors.ts`: `UnsupportedOperationError.transactionalDriver(operation, driver, port)` — la MISMA clase, `code`
  y letra de la puerta 1 (`transactional(...)`) más la frase «Rechazado por el DRIVER … entrar por manager.driver()
  no es una salida … para el ÁRBOL la salida que existe es scopes.outbox; para hechos y relaciones no hay outbox».
- `src/drivers/openfga_driver.ts`: `private rejectTransaction(operation, options)` como PRIMERA línea de
  `grant`/`revoke`/`deny`/`removeDeny` (antes de `assertIdentity`, del catálogo y del store); `revoke`/`deny`/
  `removeDeny` ganan `options?: WriteOptions` (el puerto ya lo declaraba desde L-2; hasta hoy el driver los
  ignoraba). Docblock de `transactionalWrites: false` reescrito: por qué (una tupla no entra en una trx SQL, no hay
  2PC), las dos puertas, la alternativa que SÍ existe (outbox para el ÁRBOL) y la que NO (hechos: descartada por
  el panel, fail-open medido).

**Mutante M1** (`l5-mutante-m1-roles.log`: la puerta 1 del manager de roles devuelve sin lanzar) ⇒ **3 passed
(3)**: el caso «por el manager» sigue VERDE porque **el driver re-valida por sí mismo** (nombra `'openfga'` y la
operación igual; cero llamadas). **Mutante M1b** (`l5-mutante-m1b-roles.log`: manager Y driver apagados) ⇒ **2
failed**:
```
ℹ AssertionError: ROJO: manager.grant con { transaction } NO lanzó sobre openfga (¿escribió una tupla fingiendo ir en la transacción?)
ℹ AssertionError: ROJO: driver.grant con { transaction } NO lanzó sobre openfga (¿escribió una tupla fingiendo ir en la transacción?)
```
Restaurados desde copia; `grep -rc MUTANT src` = 0. **Decisión: el driver re-valida** (misma clase/código),
recomendación del encargo aceptada — es la defensa en profundidad de F-05 (L-0) aplicada a `{ transaction }`.

## Pieza 3 + 4 · Relaciones: el rechazo con dientes contra el `:8101` y el driver que re-valida ✅

**Casos** (`tests/relations_openfga.spec.ts`, grupo «L-5 · openfga (relations) rechaza { transaction } con
dientes…», `@l5`, store fusionado recién provisionado por caso):

1. **Por el `RelationsManager`** (`driverName: 'openfga'`): `relate`/`unrelate`/`purgeObject`/`purgeSubject` con
   `{ transaction }` ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrando `'openfga'`, la operación y «transacción SQL»;
   `spy.calls` = `[]`; `onRelationWrite` vacío. Sin `transaction` entra (`spy.total() > 0`, `check` true, un evento).
2. **Por el DRIVER en directo**: las cuatro ⇒ el MISMO 500, `spy.calls` = `[]`, `check` sigue `false` (el store no
   tiene la tupla); sin `transaction` entra.
3. **ARRANQUE por el PROVIDER** (`buildRelationsManager`): `relations.default: 'openfga'` (driver REAL) con
   `requireTransactionalWrites: true` en el RAÍZ y, en otra corrida, en `relations` ⇒ 500 `E_AUTHZ_CONFIG` al
   construir el `RelationsManager`, nombrando `'openfga'` y `transactionalWrites`, cero llamadas al cliente; y
   `default: 'database'` (`DatabaseRelationsDriver`, `true` por defecto) con `openfga` solo REGISTRADO ⇒ construye,
   `manager.driver().capabilities.transactionalWrites === true` y **la factory de `openfga` no se invoca** (0).

**Rojo literal** (`l5-rojo-relations.log`; el driver ignoraba `transaction`, `relate` leía y escribía la tupla):
```
ℹ AssertionError: ROJO: driver.relate con { transaction } NO lanzó sobre openfga (¿escribió una tupla fingiendo ir en la transacción?)
Tests  2 passed, 1 failed (3)
```
**Verde** (`l5-verde-relations.log`): `Tests 3 passed (3)`.

**Código** (`src/drivers/openfga_relations_driver.ts`): `#rejectTransaction(operation, options)` como PRIMERA línea
de `relate`/`unrelate`/`purgeObject`/`purgeSubject` (antes de F-05, del `Read` y del `Write`) ⇒
`UnsupportedOperationError.transactionalDriver('relations.<op>', 'openfga', 'relations')`; `unrelate` deja de
ignorar sus opciones (`_options` → `options`); `purgeObject`/`purgeSubject` ganan `options?:
RelationTransactionOptions` (el puerto ya lo declaraba desde L-2). Docblock de `transactionalWrites: false`
reescrito como en roles (por qué, las dos puertas, la outbox como alternativa SOLO para el árbol, «no hay outbox de
relaciones»). La vista `withClock` es una instancia real (no `Object.create`), así que el método privado funciona en
ella igual.

**Mutante M2** (`l5-mutante-m2-relations.log`: `#assertTransactional` del `RelationsManager` devuelve sin comprobar)
⇒ **3 passed (3)**: el caso «por el manager» sigue VERDE porque **el driver re-valida por sí mismo**. **Mutante M2b**
(`l5-mutante-m2b-relations.log`: manager Y driver apagados) ⇒ **2 failed**:
```
ℹ AssertionError: ROJO: manager.relate con { transaction } NO lanzó sobre openfga (¿escribió una tupla fingiendo ir en la transacción?)
ℹ AssertionError: ROJO: driver.relate con { transaction } NO lanzó sobre openfga (¿escribió una tupla fingiendo ir en la transacción?)
```
Restaurados desde copia; `grep -rc MUTANT src` = 0.

## Pieza 5 · La PARIDAD que fija la ASIMETRÍA a propósito ✅ (`tests/relations_bridge.spec.ts`, grupo «L-5 · PARIDAD …», `@l5`)

`sharedStore(apiUrl, config)` (el store fusionado con el catálogo `r0 ⇒ p0` sincronizado en `authz_*` y su
proyección) sale del bloque del caso-exploit a nivel de módulo para que la paridad use **el MISMO catálogo** para los
dos drivers de roles. Dos casos, uno por puerto, con el docblock del porqué (una tupla no entra en una transacción
SQL; no hay 2PC; «los dos o ninguno» es lo que la capacidad promete y `openfga` no puede prometerlo; **esa es la
respuesta correcta**, no una divergencia a arreglar; el otro final —escribir la tupla fuera de la transacción— es
justo lo que la cara `openfga` prohíbe):

- **ROLES**: `grant(alice, 'r0', app, { transaction })` a un `AuthorizationManager` sobre `database`
  (`transactionalWrites: true`) y a otro sobre `openfga` (`false`), **dentro de UNA transacción del consumidor**
  (`db.transaction`, `openfga` primero porque su puerta corta antes de cualquier SQL): `openfga` ⇒ 500
  `E_AUTHZ_UNSUPPORTED` nombrando `'openfga'` y `grant`, `spy.calls = []`, `fgaDriver.authorize(alice)` false (el
  store sin la tupla); `database` ⇒ **200**: `statements > 0` por la trx, censo `authz_assignments` = 1 tras el
  commit, `authorize` true. Control: sin `{ transaction }` los DOS conceden a `bob` — la asimetría es SOLO de la
  capacidad.
- **RELACIONES**: `relate(u, 'viewer', doc, p, { transaction })` a un `RelationsManager` sobre
  `DatabaseRelationsDriver` y a otro sobre `OpenFgaRelationsDriver` (misma `bridgeConfig()`): `openfga` ⇒ 500 con
  cero llamadas y `check` false; `database` ⇒ 200, censo `authz_relations` = 1, `check` true. Control sin
  transacción: la misma respuesta en los dos (la paridad de 4-4).
- **La rama de `:memory:`** (pool 1; `freezeTimeoutMs: 400`): la mitad `openfga` es IDÉNTICA; la mitad `database`
  da lo que pool 1 da honestamente —503 `E_AUTHZ_BACKEND_TIMEOUT` por la barrera en < 5 s, **0 sentencias por la
  trx**, censo 0— (la cara de L-3/L-4). Las dos mitades se afirman en los cuatro modos; ninguna rama es un skip.

Verde en los cuatro modos: `l5-paridad-{sqlite,sqlite-file,pg,mysql}.log` (2/2 cada uno; abajo las cifras).

## Pieza 6 · El grep ✅ (`tests/openfga_driver.spec.ts`, grupo «L-5 · openfga no promete «atómico» …», sin servidor)

1. En `openfga_driver.ts`, `openfga_relations_driver.ts`, `openfga_facts.ts` y `openfga.ts` ninguna línea que diga
   «atómico/atomic» habla a la vez de la transacción del consumidor (`consumidor`, `llamante`, `{ transaction }`,
   `trx`, «transacción SQL», `transactionalWrites: true`); y el grep tiene que ver ALGO (las líneas que hablan del
   `Write` atómico DENTRO del store, invariante 6, existen y pasan).
2. Los dos drivers declaran `transactionalWrites: false,` LITERAL en el fuente, con «transacción SQL», «2PC» y
   «outbox» en el comentario que la acompaña; y en runtime es propiedad PROPIA (`Object.hasOwn`) con valor `false`
   en los dos drivers (construidos sin servidor) y en la vista `withClock` del de relaciones.

**Rojo literal** (`l5-grep-unit.log`, antes de reescribir el comentario del driver de relaciones):
```
ℹ AssertionError: src/drivers/openfga_relations_driver.ts: la alternativa que SÍ existe (para el árbol): expected 'rectos (`group#member`) junto con los…' to include 'outbox'
Tests  40 passed, 1 failed (41)
```
**Verde** (`l5-verde-grep-unit.log`): `Tests 41 passed (41)`.

## Pieza 7 · Docs ✅

- **CHANGELOG** (`[Unreleased] — 2.4.0-alpha.2`, sección «Lot L-5» ANTES de L-4b): problema (la declaración sin
  dientes en el driver; el rechazo solo observado con dobles) → decisión (la razón del PAQUETE: una tupla no entra en
  una trx SQL, no hay 2PC; `false` explícito; el driver re-valida; medido contra el `:8101`; el arranque; la paridad
  que fija la asimetría «y esa es la respuesta correcta»; el grep) → **qué NO se hace** (sin outbox de hechos ni de
  relaciones; `openfga` no «acepta y escribe fuera»; README/roadmap son L-6; los runners no cambian).
- Docblocks: `transactionalWrites: false` en los dos drivers `openfga` (por qué + alternativa), `rejectTransaction`/
  `#rejectTransaction`, `UnsupportedOperationError.transactionalDriver`.
- **README y `roadmap-2.0.md` NO se tocaron** (L-6).

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, corridas a fichero, en SECUENCIA — el guard de stores de
`bin/test.ts` fotografía el servidor al arrancar y borra lo que no estaba, así que dos corridas solapadas se
borrarían los stores la una a la otra)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ (0 errores) · `npm run check:purity` ✔ ·
`npm run build` ✔ (`l5-build.log`, exit 0). El driver `openfga` sigue tras el subpath: `check:purity` verde, nada de
L-5 toca la ruta `database` (`errors.ts` gana un `static` sin imports nuevos).

| modo | base (L-4b) | ahora | delta | log |
|---|---|---|---|---|
| `npm test` (SQLite memoria) | 1053 | **1063 passed (1063)** | +10 | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1074 | **1084 passed (1084)** | +10 | `suite-sqlite-file.log` |
| `npm run test:pg` | 1169 | **1179 passed (1179)** | +10 | `suite-pg.log` |
| `npm run test:mysql` | 1169 | **1179 passed (1179)** | +10 | `suite-mysql.log` |

+10 en los cuatro modos: roles L-5 ×3 (`contract.spec`), relaciones L-5 ×3 (`relations_openfga.spec`), paridad ×2
(`relations_bridge.spec`), grep ×2 (`openfga_driver.spec`, sin servidor). **Aditivo**: ningún caso existente cambió
de resultado ni de número (los runners no se tocaron; `contract_harness`/`relations_harness` siguen en sus cifras).
Cero rojas transitorias en las cuatro corridas finales (las rojas del lote fueron las tres del rojo→verde —roles,
relaciones, grep— y los cuatro mutantes, dichos arriba). Stores del `:8101` al terminar: `{"stores":[]}`.
`grep -rc MUTANT src tests` = 0. `git status`: 8 ficheros modificados + 1 nuevo (`tests/helpers/fga_spy.ts`); el
informe vive en `.claude/contexto/`, fuera de git. Sin commits (los hace el dueño).

## Ficheros tocados

- `src/errors.ts` — `UnsupportedOperationError.transactionalDriver(operation, driver, port)`.
- `src/drivers/openfga_driver.ts` — `rejectTransaction` (primera línea de `grant`/`revoke`/`deny`/`removeDeny`),
  `options?: WriteOptions` en `revoke`/`deny`/`removeDeny`, docblock de la capacidad.
- `src/drivers/openfga_relations_driver.ts` — `#rejectTransaction` (primera línea de `relate`/`unrelate`/
  `purgeObject`/`purgeSubject`), `options` en `purge*` (y `unrelate` deja de ignorar las suyas), docblock de la
  capacidad.
- `tests/helpers/fga_spy.ts` (**nuevo**) — `spyFgaClient(driver)`.
- `tests/contract.spec.ts` — grupo L-5 de roles (+3); import de `AuthorizationManager` y del espía.
- `tests/relations_openfga.spec.ts` — grupo L-5 de relaciones (+3); imports de `DatabaseRelationsDriver`,
  `buildRelationsManager` y el espía.
- `tests/relations_bridge.spec.ts` — `sharedStore(apiUrl, config)` a nivel de módulo; grupo L-5 de paridad (+2).
- `tests/openfga_driver.spec.ts` — grupo L-5 del grep (+2).
- `CHANGELOG.md`.

## Lo que NO hice, y por qué

- **No toqué los runners publicados** (`contract.ts`/`relations_contract.ts`): su cara `whenFalse` ya corre contra el
  `:8101` por los harness `openfga` desde L-2, con espía sobre el DRIVER (lo que un runner genérico puede observar).
  El espía sobre el cliente FGA es específico del paquete y vive en los specs de `openfga`, no en el contrato de
  terceros. Los conteos no se mueven.
- **No generalicé el helper de espía de transacciones** (`spyTransaction`): la spec puente lleva su copia como L-3 y
  L-4 llevan las suyas (precedente); un helper compartido es una limpieza para otro lote, no de éste.
- **No hay outbox de hechos ni de relaciones** (descartada por el panel: fail-open medido). El docblock y el mensaje
  del driver lo dicen y señalan la que SÍ existe (la de scopes, para el árbol).
- **No toqué el driver `database`** (L-3/L-4 cerrados) ni README/roadmap (L-6). **No subí `version`**.
- **No cambié la clase ni el `code` del rechazo por el driver**: misma clase, mismo 500 `E_AUTHZ_UNSUPPORTED` y misma
  letra que la puerta 1, más la frase de «rechazado por el DRIVER». Distinguir por clase habría dado dos códigos para
  el mismo hecho.
- **La mitad `database` del caso de paridad en `:memory:` no muestra el 200**: es la decisión del dueño (`{trx}` exige
  pool ≥ 2) y lo que muestra es la cara honesta de pool 1 (503 por la barrera, 0 sentencias), afirmada, no saltada;
  el 200 se afirma en `sqlite-file`/PG/MySQL (los tres verdes).
- **`--tags=@l5`**: los grupos nuevos llevan la etiqueta (`group.tap`) para poder correr el lote suelto; el filtro
  `--tests`/`--groups` de Japa parte por comas y los títulos las llevan. No cambia nada en la suite completa.

Nada del encargo resultó imposible ni contradijo el código: la puerta 1 de L-2 ya hacía el 500 por el manager (por
eso los casos «por el manager» nacieron verdes y se juzgaron con el mutante), y lo que faltaba de verdad —el driver
que escribía ignorando `transaction` por `manager.driver()`— salió rojo literal en los dos puertos y quedó cerrado.
