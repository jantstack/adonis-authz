# Fase 2 · Lote 2A — informe de implementación (2026-08-28)

Rama `v2/fase-0` sobre `d0c8aaf` (**sin commits**: el commit lo hace el dueño). Node 22.23.2, OpenFGA
`:8101` (v1.19.0) y servidor efímero tope 3 (`openfga-tiny`, `:8103`, memoria; **eliminado al terminar**).
Sin `skip`/`only` (grep = 0). Optimización **sin cambiar respuestas**: los 36 casos core + 49 de 2.0 del juez
no se tocan (`contract_harness.spec` intacto) y pasan idénticos en ambos drivers; lo que cambia es la
factura por pregunta, fijada por espías y por el benchmark. `package.json` sigue en `2.0.0-alpha.1`
(la versión la decide el dueño al cerrar la fase); CHANGELOG con sección `## [Unreleased] — 2.1.0`
encima de la de 2.0.0; README con sección **Performance**; `CLAUDE.md` mapa y roadmap.

## Conteo de tests por configuración

| Momento | `npm test` (SQLite) | `OPENFGA_TEST_URL=:8101` | tope 3 (`:8103`) |
|---|---|---|---|
| Baseline (`d0c8aaf`) | 175 | 242 | — |
| Tests nuevos contra el código de HEAD (`git stash` de `src`/`index.ts`) | 83 ✅ / **18 ❌** de los 101 de los 5 specs afectados | — | — |
| **Cierre del lote (A1 + A2 + A3 + docs)** | **200 ✅** | **269 ✅** | **269 ✅** |

`npm run typecheck` y `npm run typecheck:build` verdes; `check:purity` (reglas 1–3) verde en cada `npm test`
(los dos módulos nuevos de `src/` no importan el SDK ni el driver openfga). Casos del juez: **36 core / 49 en
2.0**, sin cambios. Higiene: los stores `bench-*`/`spies-*` se borran al terminar (el bench los borra en
`finally`).

## Benchmark (`scripts/bench_authorize.mjs`)

`OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec scripts/bench_authorize.mjs`.
Cadena de 3 (unit → organization → app, árbol vía `resolveAncestors` con `memoryScopeTree`), 5 roles por
nivel, 20 permisos (4 por rol), alice con los 15 roles; N=200 tras 30 de warmup; round-trip HTTP incluido;
catálogo en SQLite en memoria como en la suite. TRUE = `p00` (solo lo concede un rol de la raíz: hay que
subir toda la cadena); FALSE = `p16` (nadie lo concede). El script imprime además la **factura** de cada
`authorize` (consultas SQL, de ellas cuántas leen el catálogo, y llamadas al cliente FGA).

| `authorize` | Antes (HEAD `d0c8aaf`) | Después (2A) | Factura antes → después |
|---|---|---|---|
| **openfga · TRUE** | p50 **4,33 ms** · p95 7,33 · media 4,34 | p50 **2,03 ms** · p95 3,83 · media 2,13 | 2 SQL (2 catálogo) + **2 batchCheck** → 0 SQL + **1 batchCheck** |
| openfga · FALSE | p50 2,36 ms · p95 3,48 | p50 0,01 ms · p95 0,01 | 2 SQL + 1 batchCheck → 0 SQL + **0** (ningún rol concede ⇒ no se pregunta) |
| database · TRUE | p50 0,37 ms · p95 0,98 | p50 0,27 ms · p95 0,40 | 3 SQL (1 catálogo) → 2 SQL (0 catálogo) |
| database · FALSE | p50 0,24 ms · p95 0,31 | p50 0,20 ms · p95 0,28 | idem |

Lectura honesta: el panel 2 §4 medía 6,35 → 3,76 ms con 18 checks (5 roles por nivel **sin** filtrar por los
que conceden). El driver real solo pregunta por los roles que conceden el permiso (4 checks en TRUE), así
que la base es más baja (4,33) y la ganancia proporcional es la misma: **una request en vez de dos ≈ −53 %
en p50**. Las dos consultas SQL de catálogo por pregunta desaparecen del régimen estable en ambos drivers.

## Pieza × rojo observado × estado

| # | Pieza | Caso(s) escrito(s) | Fallo real observado en rojo (tests nuevos contra `src` de HEAD) | Estado |
|---|---|---|---|---|
| **A1** | `src/catalog_cache.ts`: `CatalogCache` (`view()` perezosa: 3 consultas —permisos, roles, vínculos— con `guardSql` y el deadline del driver; cargas concurrentes comparten la promesa; una carga fallida no cachea), `CatalogView` (`permission`, `role`, `rolesGranting`, `roleSlugs`, `roleLevels`, `permissionSlugs`, `loadedAt`), `invalidateAuthzCatalog()` (contador de versión del proceso), `invalidate()` por instancia, `ttlMs` opcional (`> 0` o `TypeError`). `syncAuthzCatalog` sube la versión en `finally`. Ambos drivers: `findPermission`/`findRole(OrFail)` (+ `rolesGranting`/`catalogRoles`/`roleLevels` en openfga) desde el memo; opciones `catalog` (memo compartido) y `catalogTtlMs`; propiedad pública `driver.catalog`. Exportado por `index.ts`. | `catalog_cache.spec` (12): 100 authorize ⇒ 3 lecturas de catálogo y 200 de hechos (database); openfga con cliente falso ⇒ 3 SQL y 100 batchCheck; grant/deny/revoke se ven sin recargar; sync ⇒ `loaded` false y una recarga; **caso negativo** (insertar permiso+vínculo a mano ⇒ NO cambia hasta `invalidateAuthzCatalog()`); `driver.catalog.invalidate()` solo ese memo; TTL 40 ms caduca; memo compartido = una carga; 20 cargas concurrentes = 1; tabla ausente ⇒ 503 y nada cacheado, recarga al volver; toda consulta de carga con el `timeoutMs` del driver; `ttlMs` inválido. `spies.spec` (ambos drivers, servidor real): «100 authorize seguidos leen el catálogo una vez…» (régimen estable 0 lecturas; tras `catalog.invalidate()` exactamente 3) | `expected 100 to equal 3` (database: una lectura por pregunta); `expected 200 to equal 3` (openfga: dos por pregunta); `expected 9 to equal 3`; `Cannot read properties of undefined (reading 'loaded'/'invalidate')`; caso negativo `expected true to be false` (HEAD veía el cambio al instante: no había memo); TTL idem; `expected undefined to equal CatalogCache{}`; `expected 20 to equal 3`; 503 `expected undefined to equal 503` (HEAD fallaba en otra consulta); deadline `expected 1 to equal 3`; espía database `expected 300 to equal 200` | ✅ |
| **A2** | `authorize` openfga: `rolesGranting` primero; sin rol que conceda en la cadena ⇒ `false` sin request; **un solo `batchCheckAll`** con `[...denies, ...roles]` (correlación por id, troceo a 50 del SDK); orden de la regla: `error` ⇒ 503 (D1, dentro de `batchCheckAll`), deny `allowed` ⇒ false, rol `allowed` ⇒ true. `first()` sin uso eliminado del driver. | `openfga_driver.spec` grupo «un solo batchCheck por authorize (2A · A2)» (4): lote único con 2 `denied` + 2 `assignee` ⇒ true y 1 llamada; deny allowed gana con 1 llamada; nada allowed ⇒ false, 1 llamada; sin rol que conceda ⇒ 0 llamadas. Caso existente «todo check lleva context…» ajustado: `≥ 3` lotes → `≥ 2` (comentado). `spies.spec`: `factsPerAuthorize` = 1 en openfga (100 authorize ⇒ 100 llamadas FGA + 0 SQL), 2 en database. D1 (×3) intactos. | `expected [...] to have a length of 1 but got 2` (×2), `...length of +0 but got 1`; el existente `expected 2 to be at least 3` al implementar (único fallo de la suite antigua, esperado) | ✅ |
| **A3** | `src/memoize_ancestors.ts`: `memoizeAncestors(resolver)` (Map por clave `typeuuid`; memoiza la promesa —`null` incluido—; un rechazo borra la entrada). Puerto: `withAncestorsResolver?(resolver)` opcional en `AuthorizationDriver`; ambos drivers lo implementan como vista por prototipo (`Object.create(this)` + resolutor propio: mismo cliente/conexión, mismo memo de catálogo, mismos diagnósticos). Manager: `forRequest(): AuthorizationView` (tipo `Pick` del manager) = manager hijo con `#parent` (comparte el driver: una sola factory), `#readResolver` memoizado y `#reader()` para `authorize`/`hasRole`/`list*`; `grant`/`revoke`/`deny`/`removeDeny`/`scopes.*` siguen con `driver()` y el resolutor fresco del config. Sin `AsyncLocalStorage`; el middleware queda documentado en el README. | `memoize_ancestors.spec` (5): mismo scope 1 llamada, tipos distintos con el mismo uuid son scopes distintos; `null` memoizado; throw no memoizado y reintenta; dos memos independientes; concurrentes comparten. `spies.spec` (ambos drivers, servidor real): «forRequest(): las lecturas de una vista resuelven cada scope una vez; las escrituras, en fresco» (10 `authorize` + `hasRole` + `listRoles` ⇒ 1 llamada; `deny` ⇒ +1 fresco; **caso negativo**: la respuesta cambia a false con el memo intacto; `removeDeny`/`revoke` no consultan el árbol; fuera de la vista +1 por lectura; otra vista otro memo; `scopes.attached` fresco). `manager.spec` (2): driver de terceros sin `withAncestorsResolver` y manager sin resolutor ⇒ lee sin memo, una sola factory, `view.driver()` es el driver; la vista valida identidad (422) y notifica `onWrite`. | `TypeError: manager.forRequest is not a function` (×3) | ✅ |
| **Docs** | README: opciones `catalogTtlMs`/`catalog`, sección **Performance** (tabla medida, contrato del memo —qué invalida, escritura a mano ⇒ `invalidateAuthzCatalog()`, multi-proceso ⇒ reinicio o TTL, memo compartido—, batchCheck único, `forRequest()` con el middleware `ctx.authz`, `memoizeAncestors`, drivers de terceros), nota de `withAncestorsResolver?` en «Custom drivers», notas operativas de openfga ajustadas. CHANGELOG `[Unreleased] — 2.1.0` (A1, A2 con números, A3, ajuste de test). `CLAUDE.md`: mapa (`catalog_cache.ts`, `memoize_ancestors.ts`, `manager.forRequest`, `bench_authorize.mjs`, tests nuevos) y roadmap (2A ✅). | — | ✅ |

## Desviaciones respecto a la especificación (con el porqué)

1. **A1 · `purgeScope` (openfga) sigue leyendo el catálogo en SQL.** La spec lista `findPermission`/
   `findRoleOrFail`/`rolesGranting`/`catalogRoles`; la purga no está en la lista y debe demostrar cero contra
   el catálogo tal como ES (un rol añadido por fuera del sync tendría bindings que la purga no vería con un
   memo viejo). Es camino de escritura y raro; cuesta dos consultas por purga.
2. **A1 · en `database` el memo solo sustituye `findPermission`/`findRole`.** El join de `authz_assignments`
   con `authz_role_permissions` es una consulta de HECHOS (filtra asignaciones por rol) y se mantiene:
   por eso «quitar el vínculo rol→permiso deja la asignación sin nada que conceder» (`database_driver.spec`,
   borra el vínculo a mano) sigue verde sin invalidar. En openfga el mapa permiso→roles sí es del memo, y el
   caso gemelo del contrato («rol borrado del catálogo: la tupla sigue en el store…») borra filas a mano:
   **ahora llama a `invalidateAuthzCatalog()`** tras borrarlas —exactamente lo que el contrato del memo pide a
   quien escribe `authz_*` por fuera—; sus aserciones no cambian. Único test existente ajustado además del
   conteo `≥ 3 → ≥ 2` de A2.
3. **A1 · la invalidación por sync va en `finally`.** Un sync que falla al confirmar no sabe si confirmó;
   recargar de más es gratis. La spec decía «evento interno»: es un contador de versión de módulo (la
   opción más simple que pedía la regla 4), sin emisor ni suscriptores.
4. **A1 · `invalidate()` en dos niveles.** La spec habla de `catalog.invalidate()`; el consumidor tiene el
   manager, no el driver, así que la puerta pública es `invalidateAuthzCatalog()` (global del proceso,
   exportada de la raíz) y además `driver.catalog.invalidate()` (solo ese memo). `CatalogCache` se exporta
   para compartir un memo entre drivers (`catalog` en las opciones), que es la forma de «composición» pedida.
5. **A2 · sin rol que conceda ⇒ 0 llamadas.** HEAD gastaba la request de denies para responder `false` de
   todos modos. La respuesta no cambia (un deny no puede convertir un "nadie concede" en otra cosa) y D1
   sigue: si hay checks, cualquier `error` ⇒ 503. Es observable (el bench FALSE pasa a 0,01 ms) y está fijado.
6. **A3 · el espía «10 scopes bajo la misma org ⇒ ≤ 12 llamadas (no 30)» no es reproducible tal cual.**
   Con `resolveAncestorsFrom(tree)` una llamada devuelve la cadena entera, así que 10 scopes distintos son
   10 llamadas con o sin memo (`authorize` ya resolvía una vez por pregunta desde la Fase 1); el 30 saldría
   de un resolutor `parentOf` (B4, 2B). Lo que sí mide el memo hoy es la repetición: el caso fija 10
   lecturas del MISMO scope ⇒ 1 llamada, y que `listRoleScopes`/`listScopes` (una llamada por scope
   devuelto) se amortizan en la misma vista. `authorizeMany` es B6 y no entra en 2A.
7. **A3 · `AuthorizationView` es un `Pick` del manager, no otra clase.** La vista es un manager hijo
   (`#parent` para compartir el driver): cero duplicación de validación, `#write`, `#notify` y `scopes.*`. El
   tipo excluye `clearCachedDriver`; incluye `forRequest` (una vista puede abrir otra con memo nuevo).
8. **A3 · `removeDeny`/`revoke` no consultan el árbol** (borran en el scope exacto, como en la Fase 1); el
   espía lo afirma explícitamente en vez de contarlos como escrituras que resuelven en fresco.
9. **Benchmark · números distintos a los del panel.** El panel medía 18 checks (todos los roles); el driver
   solo pregunta por los que conceden. Se anotan los números reales del driver (4,33 → 2,03 ms p50) y no
   los del panel (6,35 → 3,76); la proporción es la misma. El script vive en `scripts/` como pide la spec y
   corre con `--import @poppinss/ts-exec` (importa `src/` y `tests/helpers/app.ts` para bootear Lucid).

## Hallazgos

- **La factory del driver openfga en `spies.spec` crea un store nuevo por `make()`**: el primer intento del
  espía A1 medía «desde cero» con un driver nuevo y falló solo contra `:8101` (`expected false to be true`:
  alice no existía en el store nuevo). El caso ahora enfría el memo con `catalog.invalidate()` sobre el mismo
  driver, que además ejercita la invalidación por instancia en ambos drivers.
- **El bench del panel contaba el join de hechos como consulta de catálogo** (regex por nombre de tabla). La
  regex de `catalogReads` (tests y bench) exige `from authz_(permissions|roles|role_permissions)`: el
  `inner join authz_role_permissions` de la consulta de asignaciones no es una lectura del catálogo.
- **`Object.create(this)` como vista del driver** funciona porque los drivers usan `private` de TS (propiedades
  normales) y no campos `#`: la vista hereda cliente, memo y diagnósticos y solo sobrescribe
  `resolveAncestors`. Un test existente ya sustituía `(driver as any).resolveAncestors` por asignación; sigue
  funcionando (propiedad propia del driver). Si algún día los drivers pasan a campos `#`, la vista necesita
  otro mecanismo (constructor con estado compartido).
- **Consistencia de la carga del memo**: las tres consultas no van en una transacción (una transacción no es
  builder y `guardSql` no le pone deadline, D4). Un sync que aterrice durante la carga deja una foto mixta
  para ESA pregunta, pero la versión se captura antes de leer y la siguiente pregunta recarga. Anotado en
  el código; no se observó en la suite.
- **En multi-proceso el memo no se entera del sync de otro worker** (contador en memoria). Documentado en
  README/CHANGELOG con las dos salidas (reinicio tras `authz:catalog:sync`, o `catalogTtlMs`). No se añadió
  pub/sub ni polling: no entra en 2A.
- **Sin store huérfano** tras las corridas contra `:8101` (bench ×2 con `finally`, suites ×3).

## Archivos

- **Nuevos**: `src/catalog_cache.ts`, `src/memoize_ancestors.ts`, `scripts/bench_authorize.mjs`,
  `tests/catalog_cache.spec.ts`, `tests/memoize_ancestors.spec.ts`, `.claude/contexto/fase-2-lote-a-informe.md`.
- **`src/`**: `types.ts` (`withAncestorsResolver?`), `manager.ts` (`AuthorizationView`, `forRequest`, `#parent`,
  `#reader`), `catalog.ts` (`syncInTransaction` + `invalidateAuthzCatalog` en `finally`),
  `drivers/database_driver.ts` (memo, `catalog`/`catalogTtlMs`, `withAncestorsResolver`),
  `drivers/openfga_driver.ts` (memo en las cinco lecturas del catálogo, batchCheck único, `withAncestorsResolver`,
  `first()` eliminado).
- **Raíz**: `index.ts` (exporta `CatalogCache`, `invalidateAuthzCatalog`, `memoizeAncestors`, tipos
  `AuthorizationView`/`CatalogView`/`CatalogRoleRef`/`CatalogCacheOptions`), `README.md`, `CHANGELOG.md`,
  `CLAUDE.md`.
- **`tests/`**: `spies.spec.ts` (+2 casos por driver, `factsPerAuthorize`, `catalogReads`), `manager.spec.ts`
  (+2), `openfga_driver.spec.ts` (+4, un conteo ajustado), `contract.spec.ts` (`invalidateAuthzCatalog()` en un caso).
