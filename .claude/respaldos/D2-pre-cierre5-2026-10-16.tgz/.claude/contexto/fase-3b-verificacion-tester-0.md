# Fase 3b · Lote 3b-0 — verificación del tester de contrato

> Worktree aislado en `2613916` (detached). Node 22.23.2 · OpenFGA `:8101` (v1.19.0) · PostgreSQL 18
> (`postgres18`) · MySQL 8.4 (`mysql84`) · tope 3 en `openfga-tiny-tester3b0` `:8143` (**creado y
> borrado**; `:8101` y el `openfga-tiny` de CI no se tocaron).
> Alcance: SOLO el delta `git diff 9675e64..2613916` (Z1, Z2, Z3, D7).
> Parche: `.claude/contexto/tests-tester-fase-3b0.patch` (153 líneas, **solo `tests/`**).

## Veredicto: **APTA CON CORRECCIONES**

El borrado está **bien hecho y bien vigilado**: todos los mutantes que reintroducen la superficie
retirada mueren, y ninguna de las 101 aserciones eliminadas escondía un comportamiento incorrecto.
El problema es el otro: **al quitar los casos, tres propiedades que los documentos siguen prometiendo
se quedaron sin ningún oráculo**, y una decisión de seguridad que el propio informe declara
deliberada («relajar la colisión era el fail-open») solo está medida **a mano**. Eso no lo acepto como
cobertura.

Ninguna es un fallo de comportamiento: el código hace lo que dice. Son huecos de observación, y los
tres se cierran con tests, sin tocar `src/`. Van en el parche, verificados rojo→verde en los cuatro
motores.

---

## 1. Suites (punto 1) — todas verdes y con los conteos esperados

Medido en el árbol limpio de `2613916`, sin `skip` ni `only` (grep = 0):

| Modo | Esperado | Medido | Con el parche |
|---|---|---|---|
| `npm test` (SQLite memoria) | 414 | **414 passed** | **417 passed** |
| `OPENFGA_TEST_URL=:8101 npm test` | 516 | **516 passed** | **519 passed** |
| `npm run test:sqlite-file` | 416 | **416 passed** | **419 passed** |
| `TEST_PG_URL=… OPENFGA_TEST_URL=:8101 npm run test:pg` | 684 | **684 passed** | **687 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` | 684 | **684 passed** | **687 passed** |
| Tope 3 (`:8143`, `LIST_*_MAX_RESULTS=3`, memoria) | 516 | **516 passed** | **519 passed** |
| `npm run typecheck` · `check:purity` | verde | **verde** | **verde** |

**Residuos**: 0 bases `authz_test_*` en PostgreSQL y en MySQL al terminar; 0 stores nuevos en
`:8101` (los 58 que hay son de los scripts del auditor del 26–29/08, anteriores a esta sesión);
contenedor `:8143` borrado.

⚪ **Anotado (a 3b-1, no del lote)**: durante la sesión se acumularon 8 bases `authz_test_*` en PG con
marca de 05:40–05:47 que **dos re-ejecuciones aisladas de `test:pg` (con y sin FGA) NO reproducen**
—ambas dejaron 0—. Parece una fuga no determinista del teardown en PG (K13 vigila el hijo de
`load_without_sdk`, no las scratch de los demás). Las borré; queda dicho porque «residuos 0» es un
criterio del lote y no puedo afirmar que sea estable.

---

## 2. Los casos borrados: ¿su tesis sigue teniendo sujeto? (punto 2)

Metodología: para cada caso, ¿qué afirmaba? De esas afirmaciones, ¿cuáles siguen siendo ciertas hoy?
Para cada una que siga siéndolo, **un mutante que la rompa**: si muere, tiene sujeto y juez; si
sobrevive, la propiedad se quedó sin defensor.

| Caso borrado | Tesis principal | Veredicto |
|---|---|---|
| Juez `'2.2'` **3D · M4** (`detached purga también los roles LOCALES`) | «la fila del rol no sobrevive» | **Sujeto muerto**: hoy es falsa por diseño. Sustituido por un caso que fija lo contrario. ✅ |
| Juez **3G · W4 (i)** | «el rango se mide en la cadena del OWNER de cada rol» | **Sujeto muerto**: no hay rango en `detached`. ✅ |
| Juez **3G · W4 (ii)** | `truncated` × policy de rango | **Sujeto muerto**: las dos piezas no existen. ✅ |
| Juez **3G · W4 (iv)** | «degradar nunca da más poder que enumerar» (en `detached`) | **Sujeto muerto**: `detached` no enumera. ✅ La misma regla en la de NIVEL sigue con caso propio (3F · S2 recortado + W4 iii). |
| Juez `whenFalse` puntos (3)(4) | `detached` ⇒ 500 sin `purgeRole` y su salida a mano | **Sujeto muerto y sustituido a mejor**: ahora se juzga que `detached` NO lo necesita y que `pruneOrphanRoles` sí lo dice con 500. ✅ |
| `manager.spec` **3E · P2/P3** | (a) policy de rango; (b) identidad **canónica** del alias; (c) lectura **de la BASE** | (a) sujeto muerto ✅ · (c) migrada a Z2 y con juez ✅ · **(b) DEBILITADA → hueco H1** (§3) |
| `manager.spec` **3F · S1** | (a) `reason`/rango saltado; (b) **«un scope que el árbol YA NO conoce se purga igual»**, hechos, asignaciones y denies | (a) sujeto muerto ✅ · denies: con juez (Z1) ✅ · **(b) SIN ORÁCULO → hueco H2** (§3), y sigue escrita en `CLAUDE.md` invariante 18 |
| `manager.spec` **3G · W1** | rango por rol en la cadena del owner | **Sujeto muerto** ✅ |
| `manager.spec` **3G · W2** | `truncated`/`reason` con `purgedRoles: 0`; y, de paso, que el `descendantsFrom` publicado responde `null` a un scope desconocido | Lo primero, sujeto muerto ✅ · lo segundo, ⚪ **M14 sobrevive** (§5) |
| `manager.spec` **3F · S2** (recortado) | mitad NIVEL viva; mitad `detached` borrada | Correcto: la mitad viva conserva sus aserciones ✅ |

**Propiedades que ningún test defiende hoy** (las tres, cerradas por el parche): H1, H2 y —no venía de
un caso borrado sino de una decisión del lote— H3.

---

## 3. Mutantes (punto 3) — 14 aplicados, uno a uno, sobre el árbol de `2613916`

Cada mutante = una edición mínima en `src/` + `npm test` completo. «Muere» = al menos un caso rojo.

| # | Mutante | Resultado | Quién lo mata |
|---|---|---|---|
| M1 | `detached` **no canoniza** el alias (`purged = child`) | 🔴 **SOBREVIVE** | — → **hueco H1** |
| M2 | `purgeScope` **no purga denies** | ✅ muere (3) | `manager.spec:2714` (Z1) + 2 del juez |
| M3 | `detached` **purga el nieto** (subárbol) | ✅ muere (1) | Z1 · ⚪ el juez publicado no lo ve (§5) |
| M4 | `pruneOrphanRoles` **sin `force` borra** | ✅ muere (3) | juez `contract.ts:2615` (×2) + Z2 |
| M5 | `pruneOrphanRoles` **no exige `resolveChain`** (⇒ sin 500 `E_AUTHZ_CONFIG`) | ✅ muere (1) | Z2 |
| M6 | `pruneOrphanRoles` **borra un rol cuyo owner SÍ resuelve** | ✅ muere (1) | Z2 |
| M7 | `readLocalRoles` **sin orden estable** (`orderBy uuid desc`) | ✅ muere (1) | Z2 |
| M8 | **colisión relajada para huérfanos** (el homónimo cuyo owner no resuelve deja de bloquear) | 🔴 **SOBREVIVE** | — → **hueco H3** |
| M9 | `detached` **vuelve a purgar** los roles del owner | ✅ muere (4) | Z1 + juez + 2 más |
| M10 | **vuelve la policy de RANGO** de 3E · P3 a `detached` | ✅ muere (1) | Z1 |
| M11 | el 500 `E_AUTHZ_UNSUPPORTED` de `pruneOrphanRoles` **solo con `--force`** | ✅ muere, **pero solo con `:8101`** | juez `contract.ts:2747` (§5) |
| M12 | `detached` **exige cadena** (`assertKnownScope`) | 🔴 **SOBREVIVE** | — → **hueco H2** |
| M13 | el **driver** deja de canonizar en `purgeScope` | 🔴 sobrevive (sqlite **y pg**) | ⚪ preexistente (§5) |
| M14 | `descendantsFrom` deja de responder `null` a un scope desconocido | 🔴 sobrevive | ⚪ oráculo perdido con W2 (§5) |

### H1 — la identidad CANÓNICA de `scopes.detached` ya no se observa

`detached` resuelve `chain[0]` y lo usa para tres cosas: `driver.purgeScope`, el evento
`scope_purged` y `driver.onScopeDetached`. **El driver canoniza por su cuenta**
(`database_driver.ts:993`, `canonicalOrSelf`), así que quitar la línea del manager no cambia qué
hechos se purgan: la aserción de Z1 «los hechos del scope, purgados por el alias» pasa igual.

Hasta `9675e64` esa línea tenía otro consumidor —la purga de roles leía por `scopeKey(purged)` y con
el alias no encontraba ninguno—, y por eso el mutante moría. Borrada la purga, **lo único que depende
de ella es lo que el manager saca hacia fuera**: el evento que ve el sink de auditoría y el
`onScopeDetached` del puerto, por donde un driver de terceros (y el modo `facts` de 3b) borra lo suyo
**por `scopeKey`**. Y eso lo prometen los invariantes 17 y 18 (`CLAUDE.md`: «purga hechos y solo
hechos —con la identidad CANÓNICA (`chain[0]`)—»).

No es «borrado porque su sujeto ya no existe»: es **debilitado**. La aserción del alias sigue en Z1,
pero ya no prueba lo que su comentario dice que prueba.

### H2 — «un scope que el árbol YA NO conoce se purga igual» (3F · S1) se quedó sin caso

`CLAUDE.md` invariante 18 lo sigue afirmando palabra por palabra. Lo fijaba `3F · S1`, borrado. Hoy
un `assertKnownScope` en lugar del `resolveChain` de `manager.ts:409` —que convertiría en 422
`E_AUTHZ_UNKNOWN_SCOPE` la limpieza que se hace **después** de borrar la fila, que es el orden que el
paquete admite— **no pone rojo nada**. Es justo la regresión que S1 vino a arreglar en 3F.

### H3 — la decisión de NO tocar la colisión no tiene juez

El informe (§1.2) mide a mano cinco casos y decide, a propósito, dejar `#assertNoRoleCollision` como
está: «hacerla más permisiva era el fail-open». La medición es correcta —la reproduje— pero **«lo
probamos a mano» no es cobertura**: el mutante que hace exactamente lo que el informe rechaza (saltar
el homónimo cuyo owner ya no resuelve) **pasa la suite entera en los cuatro motores**. El caso que
protege es el (c) del informe: un descendiente VIVO cuya ruta materializada sigue pasando por el
owner huérfano; ahí el rol **no está dormido** y dejar entrar el homónimo deja dos `jefe@unit`
visibles con toda ruta por slug muerta ahí abajo. De propina, tampoco había caso para las caras (a) y
(b) —el hermano y el ancestro **sí** entran—, que es la mitad del argumento de por qué el rol dormido
no bloquea nada que no bloqueara ya.

---

## 4. El cambio de comportamiento declarado (punto 4)

§3.3 del informe: *con `requireWithin: false`, un actor sin rango purga los hechos de un scope ajeno
**con** roles locales; antes 422 por la policy de rango.*

- **(a) ¿es cierto?** **Sí, y está fijado.** `manager.spec:2714` (Z1) lo hace con `requireActor: true`
  y un `forastero` de rank 0 sobre `unitA1`, que tiene un rol local de rank 40. **Mutante M10**
  (reintroducir la policy de rango) lo pone rojo: la cara abierta tiene juez.
- **(b) ¿sigue cerrado con `requireWithin: true`/`'non-root'`?** **Sí.** `#assertWithin` corre antes
  de resolver el driver, así que no depende de que el scope tenga roles locales; y el juez lo fija
  (`contract.ts:1902` `WITHIN_REQUIRED`, `:1930` `WITHIN_ROOT_FORBIDDEN`, `:1815` `NOT_WITHIN`).
- **(c) ¿hay un caso que lo fije en AMBOS sentidos?** **No lo había**: la cara cerrada solo estaba
  fijada sobre scopes **sin** roles locales, que es justo donde nunca hubo protección accidental que
  perder. Es el hueco H4 —🟡, sin comportamiento incorrecto— y como es la cabecera del lote lo cierro
  igual: un caso con las tres puertas de `within` sobre el mismo scope con rol local rank 40, y
  después la puerta abierta con el default. Así, revertir la decisión **en cualquiera de los dos
  sentidos** pone rojo.

---

## 5. Aserciones relajadas respecto a `9675e64` (punto 5)

101 líneas `-` con `assert`/`rejects` entre `tests/` y el juez. Clasificación completa:

**Borradas porque su sujeto ya no existe (≈ 90)** — todo lo que nombra `purgedRoles`, `truncated`,
`reason`, `ScopeDetachOutcome`, `roleByUuid(...)` tras un `detached`, o un 422
`E_AUTHZ_RANK_EXCEEDED` de `scopes.detached`. Correcto: no se puede afirmar sobre una superficie que
no existe.

**Migradas y con juez nuevo (3)** — «la purga lee la base, no la foto» (`tardio`), «el rol de la
organization que sigue en el árbol no se toca» (`deOrg`), «el evento del nieto lleva SU owner»: las
tres viven ahora en Z2 y **mueren** con M6/M7 y con un `readLocalRoles` desde el memo.

**Debilitadas o perdidas (4)** — H1, H2 (§3), H4 (§4) y:

- ⚪ `assert.isTrue(driver.authorize(alice,'docs:write',unitA1x))` del juez M4: el **juez publicado**
  ya no observa que `detached` **no toca los hechos del subárbol**. M3 solo muere en `manager.spec`.
  No es grave —la decisión de no bajar es del manager, no del driver, así que un driver de terceros
  no puede romperla— pero conviene saberlo. *A 3b-1.*
- ⚪ `assert.isNull(descendantsFrom(tree)(orgB, …))` (W2): el contrato `null` del helper **publicado**
  en `./testing` se quedó sin oráculo (**M14 sobrevive**). *A 3b-1.*

**Preexistentes que este lote no empeora, pero que la revisión destapa:**

- ⚪ **M13**: la canonización del propio driver en `purgeScope` no tiene oráculo en **ningún** motor
  (ni sqlite ni PG). Con el parche, la del manager sí lo tiene; la del driver protege la salida
  documentada `manager.driver().purgeScope(alias)` y sigue sin juez. *A 3b-1.*
- 🟡 **La cara `whenFalse` del par `purgeRole` solo corre con OpenFGA levantado**
  (`contract.spec.ts:719/746`: el único harness con `purgeRole: false` es openfga). El 500
  `E_AUTHZ_UNSUPPORTED` **nuevo** de `pruneOrphanRoles` es, por tanto, invisible en `npm test`,
  `test:sqlite-file`, `test:pg` y `test:mysql` sin `OPENFGA_TEST_URL`: M11 sobrevive en los cuatro y
  solo muere con `:8101`. En CI está cubierto; en local, un desarrollador sin FGA no lo ve. *A 3b-1.*
- 🟡 **Decisión, no defecto**: `pruneOrphanRoles()` en `--dry-run` es 500 con un driver sin
  `purgeRole` — ni siquiera **lista**. Está asertado a propósito (`contract.ts:2747`) y es
  fail-closed; solo dejo dicho que un «mírame qué hay» que no puede mirar es raro de explicar en el
  comando. *A 3b-1, si el dueño quiere.*

---

## 6. Conteos del juez (punto 6)

`tests/contract_harness.spec.ts` es **coherente y pasa**: `scoped` = 75, `withPurge` = `scoped + 5` =
80, `composición (3G · W4…)` = 1, `withoutDenies` = 70. Verificado además contra el fuente: el bloque
`whenTrue` tiene exactamente 5 `since('2.2')` (`purgeRole(uuid) revoca`, `scopes.detached purga los
HECHOS`, `defineScopedRole`, `composición W4 iii`, `effectivePermissions`).

Dos incoherencias **de prosa**, no de número:

1. ⚪ El comentario del propio `contract_harness.spec.ts` justifica el `+5` como «esos 3 casos MÁS el
   de `scopes.detached` **y el de `pruneOrphanRoles`**». No hay un caso propio de `pruneOrphanRoles`
   (se ejerce dentro del de `detached`): el quinto es `purgeRole(uuid) revoca…`. El número es
   correcto; la explicación despista a quien añada el siguiente caso.
2. ⚪ **`CLAUDE.md` quedó desactualizado** (fila `tests/` del mapa, línea 241): sigue diciendo «**con
   `purgeRole: true`, ocho más: 83**» y «desde 3G · W4 **los cuatro casos de COMPOSICIÓN**». Hoy son
   **cinco más: 80** y **un** caso de composición. El invariante 18 sí se reescribió; este contador
   no. *A 3b-1* (no lo toco: `CLAUDE.md` es del dueño).

---

## 7. El parche

`.claude/contexto/tests-tester-fase-3b0.patch` — **solo `tests/manager.spec.ts`**, +153 líneas, tres
casos nuevos en el grupo «manager — roles locales a un scope (3B · B3)». Cero cambios en `src/`.

| Caso (línea con el parche aplicado) | Cierra | Rojo contra |
|---|---|---|
| `3b-0 · Z1 (tester): la identidad CANÓNICA … sale del manager` (`:2865`) | **H1** y **H2** | **M1** (`Expected "01a0…-…" / Received "01a0…"`) y **M12** |
| `3b-0 · Z1 (tester): el cambio de política … tiene las DOS caras` (`:2934`) | **H4** | **M10** |
| `3b-0 · Z3 (tester): el rol DORMIDO no bloquea … pero SÍ el descendiente VIVO` (`:2964`) | **H3** | **M8** |

Cada uno se lee como frase, afirma **un** comportamiento y **se comprobó rojo con el mutante que le
corresponde y verde sin él** — no pasan por casualidad. Sin `sleep`, sin dependencia de orden entre
casos (todo se monta dentro del test; el árbol oculto es local). El primero además fija la mitad de
`3F · S1` que se había perdido (un scope fuera del árbol se purga igual, y nada resucita cuando el
árbol lo vuelve a conocer).

Verde con el parche en los seis modos: **417 / 519 / 419 / 687 / 687 / 519**, `typecheck` y
`check:purity` verdes, residuos 0.

---

## 8. Resumen para el juez

| Pregunta del lote | Respuesta |
|---|---|
| ¿El borrado quita algo que sigue importando? | **Sí, tres cosas**, todas de observación (H1, H2, H3) y una a medias (H4). Ninguna es comportamiento incorrecto. |
| ¿La superficie retirada está protegida contra su vuelta? | **Sí**: M9 (vuelve la purga de roles) y M10 (vuelve la policy de rango) mueren. |
| ¿`pruneOrphanRoles` tiene juez? | **Sí**: `force`, `resolveChain` obligatorio, owner vivo intacto, orden estable y lectura de la BASE — cuatro mutantes, cuatro muertos. El 500 sin `purgeRole`, solo con `:8101`. |
| ¿Los conteos cuadran? | En el test, **sí**. En `CLAUDE.md`, **no** (83/cuatro → 80/uno). |
| Veredicto | **APTA CON CORRECCIONES**: aplicar el parche de tests; lo ⚪ va a 3b-1. |
