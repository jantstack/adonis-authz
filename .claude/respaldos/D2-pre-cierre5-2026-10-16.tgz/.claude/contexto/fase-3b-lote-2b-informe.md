# Fase 3b · Lote 3b-2b — el árbol como hechos (informe del implementador)

> Árbol principal, rama `v2/fase-3b`, base `0b370a6` (3b-2a cerrado, 5 suites verdes).
> Sin commits (los hace el dueño).
> Encargo: `.claude/contexto/fase-3b-lote-2-plan.md`, sub-lote **3b-2b** y nada más.
> Diseño ya validado: `panel2-2026-08-28-juez.md`, cruces **3** (ciclos), **8** (`moved`) y **9** (S6).

## Cifras de partida (las que deja 3b-2a)

```
npm test              555
test:sqlite-file      557
test:pg               723
test:mysql            723
```

---

## Pieza 0 · La EVIDENCIA: el ciclo que FGA acepta (cruce 3), contra el `:8101`

No es código del paquete: es la razón por la que el anti-ciclos vive **en el paquete**. El caso
monta el ciclo **a mano**, saltándose toda validación, sobre el modelo (c2) publicado en un store
real, con el grant dentro del ciclo.

Montaje: `unit → org → app` legítimo, el `role_binding` colgado de la **unit** (el grant está
abajo del todo), y después la arista tramposa `org#parent@unit`.

**Medido (OpenFGA v1.19, `:8101`):**

| pregunta | antes del ciclo | después |
|---|---|---|
| `can_docs_read` en la **org** (ancestro de la unit) | `false` | **`true`** |
| `can_docs_read` en `scope:app` | `false` | `false` … |
| …y tras colgar además `app#parent@org` | — | **`true`** |

El servidor **no se cuelga** (respuesta en milisegundos; el caso lo afirma con una cota de 2 s),
no avisa de nada y no hay excepción que capturar: es fail-open mudo. Con el ciclo, la herencia se
vuelve bidireccional y un grant en un descendiente concede en su ancestro — exactamente lo que
prohíbe el invariante 1.

**Corrección honesta al montaje del panel.** El auditor (S2) reportó `true` en `scope:app`. Mi
primera versión del caso lo afirmaba sin más y salió **rojo**:

```
❯ facts · 3b-2b — el ciclo que FGA acepta (cruce 3) / un ciclo `parent` … (fail-open del servidor)
- true
+ false
ℹ AssertionError: y el grant de la unit acaba concediendo en scope:app: expected false to be true
```

La razón es del modelo, no del servidor: la herencia va **padre→hijo**, así que un ciclo `org↔unit`
no alcanza a `scope:app` mientras `app` no cuelgue de nadie. El `true` del auditor exige que la
RAÍZ esté dentro del ciclo. El caso quedó con las dos mitades, y así documenta de paso por qué
existe la validación (i) (`child ≠ app`): en cuanto la raíz cuelga de algo, un grant de una unit
concede en `scope:app` y con él en **todos los tenants del store**.

---

## Pieza 1 · `hierarchy: 'facts'` y la arista `scope#parent`

**Casos escritos** (`tests/openfga_facts.spec.ts`, grupo «hierarchy: facts escribe el árbol»):

1. `scopes.attached` escribe `scope:<hijo>#parent@scope:<padre>` en **UN** `write`, con `deletes`
   vacío y **0** `writeTuples`/`deleteTuples`.
2. **Por defecto (modo `resolver`) no se escribe nada**: `attached`/`moved`/`detached` no tocan el
   store. Es la garantía de que el lote es aditivo.
3. **Identidad canónica** (invariante 17): con un árbol que funde el alias sin guiones con su fila,
   la arista se escribe con los uuids **canónicos** de los dos extremos.
4. **Idempotencia** (invariante 6): re-anexar al mismo padre no llega al servidor.

**Rojo:**

```
❯ … / `scopes.attached` escribe la arista scope:<hijo>#parent@scope:<padre> en UN solo write
ℹ TypeError: driver.onScopeAttached is not a function
❯ … / la arista lleva la identidad CANÓNICA del árbol (invariante 17) …
ℹ TypeError: driver.onScopeAttached is not a function
❯ … / idempotencia (invariante 6): re-anexar al MISMO padre no escribe nada
ℹ TypeError: driver.onScopeAttached is not a function
```

(y, tras la primera implementación, el caso canónico volvió a salir rojo porque el árbol de
mentira no fundía el alias — se corrigió el CASO, no el código:
`scope:unit|01a0…6ebd → …` esperado contra `scope:unit|01a0…6ebd` sin guiones recibido)

**Verde:**

- `src/drivers/openfga_facts.ts`: `FACTS_SCOPE_TYPE`, `FACTS_PARENT_RELATION`, `factsScopeObject(key)`
  (con `assertFgaObjectId`) y `factsParentTuple(childKey, parentKey)`. Pieza pura, sin SDK.
- `src/drivers/openfga_driver.ts`: opción `hierarchy?: 'resolver' | 'facts'` (default `'resolver'`),
  campo privado, y `onScopeAttached`/`onScopeMoved` delegando en un `reparent` privado que canoniza
  los dos extremos, lee la arista actual y la sustituye.

**Decisiones donde el plan no lo decía:**

- **`hierarchy` en las opciones del DRIVER, no en el config del manager.** Es una propiedad del
  store (qué modelo tiene publicado), no del paquete: `database` no tiene modo. Sobrevive a
  `withClock`/`withChainResolver` porque las vistas son `Object.create(this)`.
- **En modo `resolver` los tres hooks existen y son no-ops**, en vez de no declararse. El puerto los
  tiene opcionales (`?.`), así que declararlos no cambia nada para el manager, y tenerlos siempre
  permite el caso 2 (el negativo que demuestra que el default no escribe). No hay `skip`.
- **La canonicalización la hace el DRIVER** (`canonicalOrSelf`, como `purgeScope`), no el manager.
  El manager pasa `child`/`parent` tal cual a `onScopeAttached`/`onScopeMoved` desde 2D y cambiar
  esa firma sería tocar el puerto en un lote que tenía que ser aditivo.

---

## Pieza 2 · Anti-ciclos EN EL PAQUETE, antes de escribir

Las tres validaciones del cruce 8 **ya existían en el manager** (`AuthorizationManager.#assertEdge`,
`src/manager.ts:596`) y están probadas en `tests/manager.spec.ts` con un driver falso. Lo que este
lote añade es (a) repetirlas **en el driver**, por defensa en profundidad, y (b) fijarlas contra el
camino que de verdad escribe aristas.

Por qué en el driver también: **`manager.driver()` es la salida documentada de todas las barreras**
del paquete (invariante 15, y así lo usan la plataforma y los tests). Sin la comprobación aquí, ese
camino escribe el ciclo directamente en el store — y la pieza 0 enseña que el servidor no lo para.

**Casos escritos** (grupo «anti-ciclos en el paquete (cruce 3)», sobre el driver):

1. (i) `app` como hijo ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` en `attached` y en `moved`, **0** aristas y
   **0** writes.
2. (ii) padre que el árbol no conoce ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE`, 0 writes.
3. (iii) colgar un scope de su propio descendiente, o de sí mismo ⇒ 422 `E_AUTHZ_SCOPE_CYCLE`,
   0 writes.
4. El anti-ciclos **canoniza**: el alias del uuid del hijo tampoco cierra el ciclo, y la arista
   legítima escrita con el alias **sí** pasa (no rechaza todo lo que no sea la forma exacta).

Y un quinto, de punta a punta por `manager.scopes.*` con el driver `facts` de verdad (grupo
«`manager.scopes.*` mantiene el árbol del store»): las tres formas ⇒ 422 y **el contador de writes
no se mueve** — el manager corta antes del driver.

**Rojo:**

```
❯ … / (i) la raíz `app` no puede colgar de nada ⇒ 422 E_AUTHZ_INVALID_IDENTITY sin escribir
ℹ AssertionError: attached: debería haber lanzado: expected null to not equal null
❯ … / (ii) un padre que el árbol no conoce ⇒ 422 E_AUTHZ_UNKNOWN_SCOPE sin escribir
ℹ AssertionError: attached: debería haber lanzado: expected null to not equal null
❯ … / (iii) colgar un scope de su propio DESCENDIENTE (o de sí mismo) ⇒ 422 E_AUTHZ_SCOPE_CYCLE …
ℹ AssertionError: moved: org bajo su unit: debería haber lanzado: expected null to not equal null
❯ … / el anti-ciclos canoniza: un ALIAS del uuid del hijo tampoco cierra el ciclo …
ℹ AssertionError: el alias del hijo desciende del padre: debería haber lanzado: expected null to not equal null
```

Rojo **por la razón correcta**: no es que lanzara el error equivocado — es que **no lanzaba nada**
y la arista del ciclo entraba en el store.

**Verde:** `OpenFgaAuthorizationDriver.assertEdge(child, parent, operation)`, que devuelve las dos
claves canónicas y hace, en orden: `assertScope` de ambos → `child.type === 'app'` ⇒
`InvalidIdentityError` → `knownScope(parent)` (422 `E_AUTHZ_UNKNOWN_SCOPE`) → `chain(child)` para la
clave canónica → `childKey ∈ chain(parent)` ⇒ `ScopeCycleError`. Es la misma secuencia que
`#assertEdge` del manager, escrita con los helpers del driver.

---

## Pieza 3 · `moved` = un `Read` y **UN** `Write` (cruce 8)

**Casos escritos** (grupo «`moved` es un Read y UN Write (cruce 8)»):

1. Mover una unit de `orgA` a `orgB`: exactamente **1** `read`
   (`{object:'scope:unit|<uuid>', relation:'parent'}`), exactamente **1** `write` con el `delete` del
   padre viejo y el `write` del nuevo **en la misma request**, **0** `writeTuples`/`deleteTuples`, y
   queda UNA arista por nodo.
2. `Read` con **0** padres (la arista nunca llegó al store: un store recién migrado, un relay con
   retraso) ⇒ el `Write` lleva solo `writes`.
3. `Read` con **más de un** padre ⇒ **lanza** 500 `E_AUTHZ_SCOPE_TREE_DRIFT` nombrando el objeto,
   **0** writes, y las dos aristas siguen ahí tal cual.

**Rojo:**

```
❯ … / mover un scope: 1 Read del padre actual + 1 write con deletes Y writes juntos …
ℹ AssertionError: expected [ Array(1) ] to deeply equal [ …(3) ]      ← aserción MÍA mal escrita (ver abajo)
❯ … / si el Read devuelve MÁS DE UN padre eso es deriva del store: lanza 500 E_AUTHZ_SCOPE_TREE_DRIFT …
ℹ AssertionError: dos padres: debería haber lanzado: expected null to not equal null
```

El primer rojo era un defecto del caso, no del código (esperaba en el store aristas de scopes que
el caso nunca había anexado); corregido el caso, las aserciones de «1 Read / 1 Write / 0
writeTuples» ya pasaban con la pieza 1 — el `Read`+`Write` único es la misma primitiva que usa
`attached`. Lo genuinamente nuevo de esta pieza es el **drift**, y ese sí estaba rojo por no
lanzar.

**Verde:** `assertOneParent(object, current)` en el driver + `ScopeTreeDriftError` (500,
`E_AUTHZ_SCOPE_TREE_DRIFT`) en `src/errors.ts`, exportado por `index.ts` y con fila en la tabla del
README.

**Decisiones donde el plan no lo decía:**

- **`client.write({writes, deletes})`, no `writeTuples`.** El plan y el cruce 8 dicen «exactamente 1
  `writeTuples`»; en el SDK `writeTuples` **no admite deletes** (lo aprendió 3b-2a · A5). El espía
  cuenta **1** `write` y **0** `writeTuples`/`deleteTuples`, que es lo que el cruce quiere decir.
- **Error propio para el drift, no `AuthorizationInternalError`.** Es una condición operativa
  concreta y accionable («alguien más escribe en tu store; reconstruye con `authz:reconcile`»), y la
  regla del proyecto es `status` + `code` por cada una.
- **El drift se comprueba en `moved`/`attached` pero NO en `detached`.** En `moved` habría que
  **elegir** cuál de los dos padres sobrevive, y eso es adivinar cuál de dos concesiones vivas es la
  buena. En `detached` el nodo se va entero: llevarse las dos aristas es lo correcto y no hay nada
  que elegir. Está escrito en el docblock.
- **Sin diferencia no se llama al servidor.** Además de la idempotencia del invariante 6, es
  necesario: con los `conflict` estrictos por defecto del SDK, reescribir una tupla existente sería
  un error.

---

## Pieza 4 · `detached`: los hechos primero demostrando cero, la arista al final (S6)

**Casos escritos** (grupo «`detached`: hechos primero, arista al final (S6)»):

1. `onScopeDetached` borra la arista en un `Write` de **solo deletes**.
2. Un scope sin arista en el store no escribe nada (re-detach = no-op seguro).
3. **El orden**: con un deny vivo que el borrado no se lleva, `purgeScope` no puede demostrar cero
   y lanza 500 `E_AUTHZ_PURGE_INCOMPLETE` — y **la arista sigue en el store**. Va por
   `manager.scopes.detached`, que es quien fija el orden.
4. Con la purga en verde, el mismo camino sí se lleva la arista.

**Rojo:**

```
❯ … / la arista del scope se borra al final, en un Write de solo deletes
ℹ TypeError: driver.onScopeDetached is not a function
❯ … / un scope sin arista en el store no escribe nada (re-detach es un no-op seguro)
ℹ TypeError: driver.onScopeDetached is not a function
❯ … / con la purga en verde, `scopes.detached` sí se lleva la arista (mismo camino, orden completo)
ℹ AssertionError: expected [ Array(1) ] to deeply equal []
```

**Honestidad sobre el caso 3.** Ese caso pasaba **también antes** de implementar `onScopeDetached`
(si nadie borra la arista, la arista se queda). Un verde que no puede ponerse rojo no fija nada, así
que lo comprobé **invirtiendo el orden en el manager** (`onScopeDetached` antes de `purgeScope`):

```
❯ … / si la purga de hechos NO puede demostrar cero, la arista SIGUE en el store …
- Expected  - 3
+ Received  + 1
-   "scope:organization|01a05336-4b74-75be-9f30-c73fe4294c3c → scope:app",
ℹ AssertionError: la arista se borra DESPUÉS de la purga: si la purga falla, el scope conserva su
  ancestro y los denies heredados siguen valiendo: expected [] to deeply equal [ Array(1) ]
```

El orden se restauró inmediatamente (`src/manager.ts:427` intacto). **El manager ya hacía lo
correcto desde 3b-0** (`purgeScope` y luego `onScopeDetached`); lo que faltaba era el caso que lo
sujeta, y ahora lo hay.

**Verde:** `OpenFgaAuthorizationDriver.onScopeDetached`, que canoniza, lee las aristas `#parent` del
scope y las borra todas en un `write({writes: [], deletes})`. Sin aristas, ni una request.

**Decisión donde el plan no lo decía:** `detached` **no** toca las aristas de los HIJOS
(`scope:<hijo>#parent@scope:<este>`). El contrato ya dice que el consumidor notifica un `detached`
por nodo (o un `moved` para recolgarlos), igual que `purgeScope` es del scope EXACTO (invariante 11
y 3b-0b · AA4). Enumerar el subárbol aquí es justo la superficie que 3b-0 · Z1 borró de esta
operación. Lo que quede colgando de un nodo que ya no existe lo ve `authz:reconcile` (3b-3), y está
anotado en el docblock.

---

## Pieza 5 · El árbol del driver contra el servidor REAL

Todo lo anterior se juzga contra un store en memoria. Dos casos más lo repiten contra el `:8101`
con el modelo (c2) publicado:

1. `attached`×3 → grant en `orgA` (rol, binding y vínculo del catálogo escritos a mano) → la **unit
   hereda** (`true`), la **otra org no** (`false`, nunca a hermanos), **`app` no** (`false`, nunca
   hacia arriba). Después `moved` de la unit a `orgB` ⇒ deja de heredar. Después `detached` ⇒ la
   arista se fue.
2. **Por qué `moved` necesita el `Read`**: `client.write` con un `delete` de una tupla inexistente
   **falla** en el servidor, y el `write` que lo acompañaba **tampoco aterriza** — que es lo que
   hace legal el `moved` del cruce 8 (mutación atómica).

Comprobé que el caso 1 no es decorativo invirtiendo `factsParentTuple` (user↔object):

```
❯ facts · 3b-2b — el árbol del driver contra el servidor real / attached/moved/detached mantienen el árbol …
ℹ AssertionError: la unit hereda de su org (invariante 1): expected false to be true
```

---

## Ficheros tocados

| Fichero | Qué |
|---|---|
| `src/drivers/openfga_facts.ts` | `FACTS_SCOPE_TYPE`, `FACTS_PARENT_RELATION`, `FactsTuple`, `factsScopeObject`, `factsParentTuple`. Sigue sin importar `@openfga/sdk`. |
| `src/drivers/openfga_driver.ts` | Opción `hierarchy`, campo privado, `onScopeAttached`/`onScopeMoved`/`onScopeDetached`, `reparent`, `assertEdge` (las tres validaciones) y `assertOneParent` (drift). |
| `src/errors.ts` | `ScopeTreeDriftError` (500, `E_AUTHZ_SCOPE_TREE_DRIFT`). |
| `index.ts`, `src/openfga.ts` | Exportan el error nuevo y el material del árbol. |
| `tests/openfga_facts.spec.ts` | +19 casos: ciclo real (1), `hierarchy: facts` (4), anti-ciclos (4), `moved` (3), `detached` (4), manager de punta a punta (1), servidor real (2). Helpers nuevos: `treeDriver`, `edgesOf`, `rejects`. |
| `CHANGELOG.md`, `README.md`, `CLAUDE.md` | Entrada del lote, `hierarchy` documentada con el fail-open **literal**, fila del error nuevo, mapa del código y roadmap. |

**No se ha tocado `src/manager.ts`** (la inversión del orden fue temporal y está revertida; `git
status` no lo lista).

## Verificación final

```
npx tsc --noEmit -p tsconfig.json                          → sin salida (OK)
npm run typecheck (tsconfig.test.json)                     → sin salida (OK)
npm run build (purity + typecheck + tsc + stubs)           → OK
check:purity                                               → ✔ (la ruta database sigue sin importar openfga)

OPENFGA_TEST_URL=… npm test                    574 passed   (partida 555, +19)
OPENFGA_TEST_URL=… npm run test:sqlite-file    576 passed   (partida 557, +19)
TEST_PG_URL=… OPENFGA_TEST_URL=… npm run test:pg      742 passed   (partida 723, +19)
OPENFGA_TEST_URL=… npm run test:mysql                 742 passed   (partida 723, +19)
```

Las cinco suites existentes siguen verdes **sin un solo cambio de respuesta**: el default
`hierarchy: 'resolver'` no escribe nada y los 19 casos nuevos son todos del material nuevo.

**Stores**: los cuatro que crea el spec (`facts-cycle-*`, `facts-tree-*`, `facts-del-*`, más los de
3b-2a) se borran en su teardown. `curl /stores` sigue listando los **50** que ya había antes del
lote (de los paneles del 28-08) y **ningún** `facts-*`.

## Lo que NO he hecho, y por qué

1. **Nada de 3b-2c / 2d / 2e**, por encargo: `authorize` sigue siendo el de hoy (cadena +
   `batchCheck`), no hay outbox ni `acceptScopeDriftRisk`, no hay capacidades nuevas
   (`singleCheckAuthorize`, `roleInheritanceNative`, `listObjectsInherited`), `purgeRole` sigue sin
   existir en el driver y **el modo `resolver` no se ha borrado**.
2. **Nadie escribe `scope:<key>#binding@role_binding:<...>`.** Este lote es el ÁRBOL
   (`scope#parent`) y solo eso. Sin `binding`, un store en modo `facts` tiene el árbol pero no las
   asignaciones colgadas de él: el `Check` de (c2) todavía no puede responder. Es 3b-2c.
3. **`openfga:provision` sigue publicando el modelo del modo `resolver`.** Consecuencia práctica,
   la misma que anotó 3b-2a y que sigue viva: hoy `hierarchy: 'facts'` solo funciona contra un store
   cuyo modelo declare el tipo `scope`, y el único sitio donde se escribe ese modelo es la suite. El
   gate de construcción que debería impedir esa combinación es 3b-2d/2e.
4. **No he tocado `src/testing/contract.ts` ni `contract_harness.spec.ts`.** El juez habla con el
   driver y no ve aristas; el anexo `hierarchyFacts` que el propio fichero deja anotado
   (`contract.ts:1444`) es de 3b-2e, cuando haya capacidad que declarar. El lote tenía que ser
   aditivo y no hay conteo de casos que mover.
5. **No he movido el anti-ciclos del manager al driver**: está en los dos. El del manager es el que
   corta antes de tocar el driver (y el que cubre a `database`); el del driver cubre
   `manager.driver()`. Duplicar una comprobación de seguridad en la frontera es la regla que ya
   siguen `assertIdentity`/`assertScope` en este paquete.
6. **No he medido el techo de PROFUNDIDAD del modelo (c2)** (los ~23 saltos del cruce 9). Sigue
   pendiente desde 3b-2a; necesita `maxDepth` en `capabilities`, que es 3b-2e. Con `hierarchy:
   'facts'` esa cota pasa a ser observable (la profundidad del árbol la fija el consumidor), así que
   conviene que 3b-2e no se la salte.
7. **No hay ningún `skip`**, y no hay ninguna capacidad declarada en `false` en este lote.
8. **No he hecho commits.**

## Aviso para el auditor / el tester

- **El árbol del store y el árbol del consumidor son dos copias.** Este lote las sincroniza
  *cuando el consumidor avisa*; si no avisa (o si su transacción hace `rollback` después de avisar),
  el store decide con un árbol que ya no existe. Es exactamente S5 / cruce 4, y su mitigación —el
  outbox y el gate de construcción— es **3b-2d**. Mientras tanto, `hierarchy: 'facts'` se puede
  construir sin ninguna red: es deliberado (el lote es aditivo) pero es una arista viva.
- El drift de **>1 padre** se detecta en `moved`/`attached` porque ahí se lee la arista. En
  `detached` no se comprueba (se borran todas, a propósito). En ningún otro camino se lee
  `scope#parent`, así que un árbol derivado puede estar concediendo por dos ramas hasta el siguiente
  `moved` de ese nodo o hasta `authz:reconcile`.
- Un `detached` deja **huérfanas las aristas de los hijos** (siguen apuntando a un nodo que ya no
  cuelga de nada). No conceden nada de más —el nodo desaparecido no tiene binding ni padre—, pero
  son deriva que `authz:reconcile` (3b-3) tiene que ver.
- `assertEdge` del driver hace **dos** `resolveChain` (padre y, si existe, hijo) por operación,
  igual que el del manager. Por `manager.scopes.*` son cuatro en total (dos del manager, dos del
  driver). Son escrituras del árbol, no camino caliente, pero está medido y dicho.
- La pieza 0 (`el ciclo que FGA acepta`) es un caso que afirma un **defecto del servidor**, no el
  contrato. Si un día OpenFGA lo arregla, ese caso se pondrá rojo: cámbielo entonces a la afirmación
  nueva, pero **no borre la validación del paquete** — la mitigación del cruce 3 es del paquete por
  decisión del panel, no por falta de alternativa.
