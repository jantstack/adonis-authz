# Panel «paquete óptimo» — tester de contrato (2026-10-16)

Solo lectura sobre `src/`/`tests/`. Escrito: este fichero y siete scripts en `.claude/reproducciones/`:

- `panel-optimo-tester-tiempos.ts`: coste de cada trozo de la fuerza bruta. Pura.
- `panel-optimo-tester-muestra.ts`: qué trozo y qué muestra mata a cada uno de los 16 mutantes de `relations.order.exhaustive`. Pura; trabaja sobre copias en un mkdtemp.
- `panel-optimo-tester-literales.ts`: convierte en casos literales los mutantes que hoy mueren «solo por cifras» (encoge `c4h.order.renewals-not-changing`). Pura.
- `panel-optimo-tester-l2.ts`: caso literal de `c41.order.without-ignored` sobre la función pura. Pura.
- `panel-optimo-tester-c4.ts`: mutante doble `c4.off` + `priority.deletes-first`. Pura.
- `panel-optimo-tester-c4lit.ts`: contraejemplo mínimo de `c4.off` con `walkPair`. Pura.
- `panel-optimo-tester-mbb.ts`: el make-before-break contra OpenFGA real. Usa un store efímero `pot-mbb-*` en `:8090`, que se borra al terminar; se comprobó que quedan cero `pot-*`.

Entorno: Node 22, `TEST_DB` sin definir (SQLite `:memory:`) y sin `OPENFGA_TEST_URL`. No corrí ningún gate, no hice ningún `docker restart` y no toqué el working tree.

```
source ~/.config/nvm/nvm.sh && nvm use 22
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-tiempos.ts
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-muestra.ts            # ~4 min
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-muestra.ts grandes '(original),order.c4.off,order.priority.deletes-first,order.c2.no-exclusion,order.withhold.off'
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-l2.ts
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-c4.ts
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-c4lit.ts
node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-literales.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-tester-mbb.ts
```

## Resumen

1. **El MBB es verificable con cambios, y lo medí contra el servidor.** Un `Write` `{write ranura B, delete ranura A}` entra (M2) y el deny no deja de cortar en ningún instante. Pero hay tres cosas que hay que convertir en casos antes de creerlo:
   - **«una sola ranura viva» NO la da el servidor** (M6: acepta las dos). Tiene que ser una regla de escritura comprobable por inducción (M9: «escribir X borra ¬X en el mismo `Write`»);
   - **todo borrado y toda lectura tienen que plegar las dos ranuras** (M7: borrar una no basta);
   - **el perdedor de una carrera recibe un 400 «cannot delete a tuple which does not exist»** (M4/M5), que hoy no se clasifica como choque y saldría como 503 (invariante 6).
2. **El juez publicado no ve la ventana.** La cara `atomicRenewal:true` (`relations_contract.ts:2070`) solo mira el estado FINAL. Un driver que renueve con delete + write la pasa en verde. Con `openfga` declarando `true`, eso pasa a ser un hueco real: hace falta un hook de corte en el harness.
3. **Lo que sobra si `openfga` pasa a `atomicRenewal: true` depende de una decisión de arquitectura.**
   - Si la capacidad sigue opcional para terceros, no sobra nada del helper.
   - Si un destino sin `atomicRenewal` con denies pasa a ser 500 (opción ii), sobran la rama «dos Write» de la fuerza bruta, `relationWithheldWrites`, 13 mutantes y los tres D4-*. Ahorro medido: **1,56 s por mutante** y **23 s** del spec exhaustivo.
4. **El tiempo del corredor: el 90 % de cada ejecución de la guardia es UN caso** (la fuerza bruta, 4,98 de 5,5 s). El corredor lo paga en los 181 mutantes, aunque solo 16 lo necesitan, porque corre el spec ENTERO para juzgar 1–3 títulos.
   - De ~6,5 a ~17,5 min = la vigencia (+3,5 s) × 181.
   - Filtrar por `expectRed` (medido: 0,63 s por mutante) + paralelizar ⇒ **≤ 1,5 min en CI, sin perder ni una muerte**.
5. **`relations_order_exhaustive.spec` es el 59 % de `npm test` en `:memory:`** (89 de 152 s) y CI lo corre 8 veces por push. Con `worker_threads` y un job único requerido ⇒ ≤ 30 s, una vez.
6. **Mutantes «solo por cifras».**
   - Dos de los tres del auditor NO están en el corredor; el tercero entra como `rec.plan.withhold-off`. De los 13 mutantes del cierre 4, 10 no los re-verifica nada.
   - Dejé dos casos literales medidos, para `without-ignored` (función pura) y `renewals-not-changing` (una combinación con vigencia).
   - **Encontré tres más en la guardia**: `c4.off`, que es de SEGURIDAD (literal U2 de una línea, encogido), y `priority.deletes-first` y `c2.no-exclusion`, que son equivalente y de precisión respectivamente: hay que declararlos.
   - Re-medido también el H2 del auditor: el `preexisting` del oráculo esconde D4-1 (23 485 / 33 612 / 41 795).

---

## 1 · Verificabilidad del make-before-break (MBB)

### 1.1 · Lo que medí contra OpenFGA real (`panel-optimo-tester-mbb.ts`, `:8090`, v1.19)

Modelo mínimo:
- `group#member = [user, user with not_expired] or member_alt`;
- `member_alt = [user, user with not_expired]`;
- `document#viewer = [user, group#member] but not denied_viewer`;
- `denied_viewer = [user, group#member]`.

Siembra: `U ∈ H` (ranura A, +1 h); el deny de `H#member` sobre `viewer X`; `U viewer X` directo.

| # | qué | resultado |
|---|---|---|
| M1 | antes de renovar: `U viewer X` | `false` (el deny llega por H) |
| M2 | renovar = UN `Write` `{writes: [member_alt U +2 h], deletes: [member U]}` | **OK**; queda `["member_alt@+2h"]`; `viewer X` = `false` en `now` y en +1,5 h (pasada la caducidad vieja); `member H` en +1,5 h = `true` |
| M3 | control (el M5 del panel de tenencia): delete + write de la MISMA clave | 400 `cannot_allow_duplicate_tuples_in_one_request` (reproducido) |
| M4 | CARRERA: dos renovadores parten del mismo estado (ranura B viva) y los dos mandan `{write A, delete B}` | `["OK", "400 write_failed_due_to_invalid_input «cannot delete a tuple which does not exist»"]`; queda UNA ranura |
| M5 | carrera CRUZADA (A→B y B→A desde lecturas distintas) | uno OK y el otro el MISMO 400; queda UNA ranura |
| M6 | dos ranuras vivas escritas a mano (bug, pasada vieja o carrera de tres pasos; ver P2) | el servidor lo ADMITE: `["member_alt@+5h", "member@+7h"]`; en +6,5 h `member` = `true` (manda la más larga) |
| M7 | borrar SOLO una de las dos | `member H` sigue `true`; el deny sigue llegando por la otra (`viewer X` = `false`) |
| M9 | regla «toda escritura de la ranura X borra la ¬X en el MISMO `Write`, con `onMissingDeletes: ignore`» | a) con ¬X presente queda UNA (`["member@+8h"]`); b) con ¬X ausente, OK (`["member_alt@+9h"]`); c) reescribir la ranura ocupada da 400 «cannot write a tuple which already exists» (el CAS lo da la unicidad de clave) |
| M8 | `check` medio con la unión (300 llamadas) | 2,0–2,5 ms (indicativo; el bench serio es del analista) |

Tres consecuencias para la verificación, todas MEDIDAS:

1. **El perdedor de una carrera recibe un 400 que hoy no se clasifica como choque.** Dice `write_failed_due_to_invalid_input` con «cannot delete a tuple which does not exist». El invariante 6 solo reconoce `Aborted` (409) y «cannot write a tuple which already exists» (400). Si no se toca la clasificación, una renovación que pierde la carrera sale como **503**, y debería salir como relectura + 409 `E_AUTHZ_WRITE_CONFLICT`.
2. **«Una sola ranura viva» NO la garantiza el servidor** (M6). Hay que garantizarla con una regla de ESCRITURA que se pueda comprobar por inducción (M9): todo `Write` que escribe la ranura X de la clave K borra la ¬X de K en el mismo `Write`. Con eso, tras cada `Write` hay ≤ 1 ranura viva por clave, sin depender de interleavings. Sin la regla existe la carrera de tres pasos (P1 lee «ausente»; P2 escribe A y renueva a B; P1 escribe A) y quedan dos ranuras. Además se pierde «gana el último escritor»: un acortamiento de P1 queda tapado por la B más larga de P2, lo que es fail-open.
3. **Plegar las dos ranuras es obligatorio en TODA lectura y en todo borrado** (M7). Un `unrelate`/`purgeObject`/`purgeSubject` que borre una sola ranura deja al sujeto como miembro (y concediendo, si el grupo da un allow): fail-open.

### 1.2 · Casos de contrato que añade (dado → cuando → entonces)

Los nombro P1…P9. «Doble» = `makeRelationsDriver` del contrato publicado; «fake» = cliente FGA en memoria de la guardia; «real» = `OPENFGA_TEST_URL`.

**P1 · Renovación atómica (relaciones: membresía, allow y deny con caducidad).**
- *Dado* una tupla viva con caducidad T1, *cuando* `relate` con T2 ≠ T1, *entonces* el backend recibe exactamente UN `client.write` con `{writes: [ranura libre @T2], deletes: [ranura ocupada]}`.
- Además, cortando el cliente antes y después de esa llamada (k = 0, 1), cada estado observable es el inicial o el final. Nunca uno sin la tupla.
- Inverso: con T2 = T1, CERO `write` (el atajo de hoy se conserva).
- Borde: la tupla vencida en el destino se reescribe sin comprobar portadora (⚪ C2-4 de hoy) y también en UN `Write`.
- **Cómo se observa:** el patrón de `openfga.purge.order` (cliente fake cortado tras cada `Write`), no el de `relations.reconcile.order`. Este último corta en la API del puerto (`relate`/`unrelate`, `guard_surface.spec.ts:1736-1752`), así que las dos llamadas internas de una renovación le son INVISIBLES. Por eso el N1 necesitó caso propio.

**P2 · Una sola ranura viva (propiedad INDUCTIVA, sin servidor).**
- *Dada* cualquier secuencia aleatoria con semilla fija de `relate` (con y sin caducidad), `unrelate`, `deny`, `removeDeny`, `purgeObject` y `purgeSubject` sobre 3 claves, *entonces*:
  - **cada** `Write` que el driver emite y escribe una ranura de K borra la otra ranura de K en el mismo `Write`;
  - y `Read({})` da ≤ 1 ranura por clave lógica tras cada operación.
- Va con espía del cliente (`tests/helpers/fga_spy.ts` ya existe) sobre el fake.
- Mutante que la mata: quitar el `delete ¬X` del camino «tupla nueva». M9 demuestra que sin él el servidor acepta dos ranuras.

**P3 · Carrera (servidor real, determinista, sin sleeps).**
- *Dado* un cliente envoltorio que bloquea el `Write` del renovador 1 hasta que el renovador 2 termina, *cuando* los dos renuevan la misma clave:
  - el final tiene UNA ranura con la caducidad del último `Write` aplicado;
  - el perdedor relee y re-aplica (gana el último escritor) o, si la contención no cede, da **409** `E_AUTHZ_WRITE_CONFLICT`, jamás 503 (M4/M5: el 400 «cannot delete…» tiene que entrar en `isDuplicateWrite`/su gemelo).
- Variante de tres pasos (P1 lee ausente → P2 escribe A y renueva a B → P1 escribe A): una ranura, y la caducidad es la de P1.
- **Solo es observable contra el servidor real.** El fake tendría que reimplementar la semántica de unicidad y del 400 para valer, y entonces se juzgaría a sí mismo.

**P4 · Plegado en lecturas y borrados.**
- *Dadas* las DOS ranuras vivas sembradas a mano (`client.write` directo, como M6), *entonces*:
  - `check`/`decideMany`/`listSubjects`/`membersOf`/`listObjects` dan lo mismo que con una sola (la más larga);
  - `enumerateRelations` emite UNA tupla lógica con la caducidad mayor;
  - `unrelate`, `purgeObject` y `purgeSubject` dejan CERO ranuras (`Read` exacto);
  - `reconcileRelations --dry-run` las cuenta como deriva propia (`dual-slot`), y la pasada real la deja en una. Mismos números en dry y real.
- **Riesgo concreto que este caso caza:** la poda y `#sweep` filtran por TIPO (`CLAUDE.md`, cierre 3 · 🟠 N9). Una relación `member_alt` que la config no declara llegaría a `planPartition` como `undeclared`, y entonces o es deriva perpetua o se borra con `--prune` la ranura VIVA. Hace falta el caso «renovar y luego `reconcile --dry-run` ⇒ limpio (`extra 0`, sin `undeclared`)».

**P5 · Paridad dry/real del reconcile.**
- Con `atomicRenewal: true` en `openfga`, el caso publicado «vigencia · C3-1» (`relations_reconcile_contract.ts:374`) tiene que dar `written 1, updated 1, []` en las dos direcciones contra el servidor, dry = real, y negar en `now` y tras la caducidad vieja (`withClock`). Ya lo hace la cara `database`.
- La L9 (`RESIDUE_FIXTURES`) deja de alcanzar `renewal-unsafe`/`deny-conditional`/`withheld-by-unsafe-deny` con los drivers del paquete. Solo la cara `false` del doble sigue juzgándolos.

**P6 · Gemelo de roles.**
- *Dado* `grant` con caducidad T1 en `openfga`/`facts`, *cuando* re-`grant` con T2, *entonces*:
  - UN `Write` `{writes: [estructura + assignee en la ranura libre], deletes: [ranura ocupada]}`;
  - `authorize` es `true` cortando el cliente en cada k;
  - `GrantOutcome.previousExpiresAt` = T1 (invariante 10);
  - `listRoles`/`hasRole`/`enumerateFacts`/`countRoleAssignments` pliegan las dos ranuras.
- Hoy `replaceAssignment` (`openfga_driver.ts:1214-1231`) hace delete y luego write. Eso deja una ventana fail-CLOSED y, si el write falla, PIERDE el grant (marcado parcial, ⚪ C2-5). Con MBB esa rama desaparece.
- Inverso: `purgeScope` y `purgeRole` demuestran cero también sobre la ranura alternativa. Si no, `E_AUTHZ_PURGE_INCOMPLETE` nunca se cumple o, peor, demuestra cero sobre una sola ranura.
- **Paridad entre drivers**: el mismo re-`grant` da la misma respuesta de `authorize` en todo prefijo en `database` y `openfga`.

**P7 · Modelo y cotas.**
- `openfga_facts`/`scope_depth.spec` re-medidos con la relación duplicada:
  - techo en BYTES (`factsModelBytes` contra el servidor, delta 0);
  - las cinco cifras de permisos publicadas (800/691/576/447/272);
  - y, si `assignee` pasa a ser una unión, **la profundidad fiable** (`FACTS_MAX_RESOLVE_DEPTH` = 22) con las 500 repeticiones de 3b-4 · C4. Cada unión añade un nodo al árbol de resolución, y el `--resolve-node-limit` es el que corta.
- La validación estructural D-31 (`openfga_relations_driver.ts:494-513`, igualdad tras `canonicalRewrite`) tiene que reconocer `member or member_alt`. Si no, el driver rechaza su propio modelo (500 al usarlo).

**P8 · Migración de stores existentes (operación larga, punto 8).**
Estados que hay que cubrir:
- *antes*: store pre-MBB, solo ranura A;
- *durante*: modelo nuevo publicado y flota mezclada;
- *después*: primera renovación a B;
- *abortada*: el modelo viejo fijado por `OPENFGA_MODEL_ID` y un pod nuevo que escribe `member_alt` ⇒ el servidor da 400. Tiene que salir como 500 de configuración ANTES de escribir, igual que D-31, nunca como un 503 a mitad;
- *repetida*: idempotente.

Cada estado es un paso del runbook de cutover o un caso.

**P9 · `atomicRenewal` (D15).** Sigue siendo opcional y con su par. Lo que cambia es QUIÉN aporta cada cara:
- `true`: `database` y `openfga`;
- `false`: solo el doble (ya lo fija `relations_harness.spec.ts:164-170`).

**Hueco del juez publicado que MBB hace grave:** la cara `whenTrue` (`relations_contract.ts:2070-2082`) solo mira el estado FINAL (la caducidad cambió y el deny sigue negando). Un driver que declare `true` y renueve con delete + write pasa ese caso en verde, y el estado final es idéntico. Hoy no importa porque el único `true` es `database` (transacción). Si `openfga` declara `true`, el juez no puede distinguir MBB de la ventana. Hace falta una de dos:
- **(a)** un hook de inyección en el harness publicado (`harness.interruptBackendAfter?(k)` o «cuántas escrituras de backend hizo la última operación»), con la cara `true` exigiéndolo como `BOTH_FACES_REQUIRED`;
- **(b)** declararlo en un `limits`, como `censusLimits`, y que la garantía la dé la guardia del paquete (P1 con el fake) solo para `openfga`.

Recomiendo (a). Es la misma lección del censo de 3b-4: «lo que el driver se auto-declara cierra las omisiones descuidadas, no las silenciosas».

### 1.3 · Verificabilidad por backend

| backend | ¿mismo test? | riesgo específico | notas |
|---|---|---|---|
| `database` (SQLite/PG/MySQL) | P1/P5/P6 sí, como CONTROL (ya es atómico) | ninguno nuevo; no tiene ranuras | la paridad de P6 se juzga contra él |
| `openfga` + fake en memoria (guardia) | P1, P2, P4 (lecturas y borrados), P6 | el fake no reproduce la unicidad ni el 400 de M4. P3 NO vale aquí | barato, sin servidor; va en cada mutante |
| `openfga` real (`OPENFGA_TEST_URL`) | P3, P4 (contra el servidor), P5, P7, P8 | carrera (M4/M5), cotas del modelo, D-31, migración | caro; job con servidor. P7 con repeticiones |
| doble publicado (`makeRelationsDriver`) | la cara `false` de P9 | que la cara `true` no observe la ventana (hueco de arriba) | |
| driver de terceros | P9 con hook (a) | sin hook, un `true` mentiroso pasa | README «Third-party drivers» |

### 1.4 · Encaje en la fuerza bruta y qué sobra si `atomicRenewal` es `true` en `openfga`

`bruteForceVigencia` ya tiene el eje correcto: `atomic: true | false` (`order_bruteforce.ts:368-580`).
- MBB no cambia el oráculo. Cambia qué driver real representa cada modo: con MBB los DOS drivers del paquete son `atomic: true`, y `false` pasa a ser «un driver de terceros que no renueva atómicamente».
- Lo que la fuerza bruta NO ve y MBB introduce (ranuras, plegado, carreras) no se modela en el universo. Va en P1–P4.

**Lo que sobra depende de una decisión que no es mía** (se la paso al arquitecto):

- **(i) La capacidad sigue opcional y el plan conserva la rama `!atomicRenewal` para terceros.** No sobra NADA del helper ni de la guardia: la rama `atomic: false` verifica código que sigue existiendo (`relationWithheldWrites`, `renewal-unsafe`, `deny-conditional`, `carrier-conflict`).
  - Sí cambia el peso: D4-1/D4-2/D4-3 siguen abiertos, pero solo para terceros.
  - Y el `preexisting` de la fuerza bruta (que esconde D4-1, auditor §D4-1) sigue necesitando arreglo.
- **(ii) `reconcileRelations` hacia un destino SIN `atomicRenewal` con denies declarados = 500 `E_AUTHZ_UNSUPPORTED` antes de leer** (fail-closed: «ese destino no puede llevar un deny»). Sobra todo esto:
  - en el helper: la rama `atomic: false` de `bruteForceVigencia`, `packageWithhold`/`WithholdFn` y los contadores `renewalUnsafe`, `denyConditional`, `withheld`, `refused` y `preexisting`;
  - en el spec exhaustivo: los 4 casos «dos Write» de `relations_order_exhaustive.spec.ts` y el literal «C3-1/C3-2 sin retener»;
  - en la guardia: la mitad `atomic: false` de la propiedad `relations.order.exhaustive`, las filas C3-1/C3-2 de `relations.reconcile.order` y el mutante `rec.plan.withhold-off` (con `order.withhold.off`, 2 de los 16);
  - fuera del corredor: los 13 mutantes a mano del cierre 4;
  - en el producto: `relationWithheldWrites` entero, `RenewalRacedError`, `RESIDUE_FIXTURES` `renewal-unsafe`/`deny-conditional`/`withheld-by-unsafe-deny`/`carrier-conflict` y los tres hallazgos D4-*.
  - Lo que NO sobra: el orden de renovaciones en el grafo (`renewals`/`shortening`). El horizonte encontró 19 686 pares inseguros también en ATÓMICO (informe del cierre 4 §2), así que la rama `atomic: true` y `order.renewals.horizon-flat` se quedan.

**Ahorro medido con (ii)** (`panel-optimo-tester-tiempos.ts`):
- la muestra «dos Write» de la guardia cuesta **1,56 s de los 4,8 s** que la fuerza bruta añade a cada mutante, es decir ×181 ≈ **4,7 min** del gate actual;
- en `relations_order_exhaustive.spec` los cuatro «dos Write» suman **23,2 s de 89 s**.

**Veredicto de esta sección: verificable con cambios.** Faltan:
- el hook (a) en el juez publicado;
- la clasificación del 400 «cannot delete…» como choque;
- la regla inductiva P2 como propiedad de la guardia, con mutante;
- y el caso P4 de `reconcile` limpio tras renovar.

Sin P2 y P4, «una sola ranura viva» solo sería una frase del README.

---

## 2 · Coste de la verificación: dónde se va el tiempo

### 2.1 · Mediciones (`:memory:`, Node 22, 16 núcleos)

**Guardia** (`tests/guard_surface.spec.ts`, 236 casos):
- **6,1 s de pared** por ejecución; 5,5 s de casos y ~0,55 s de arranque (boot + ts-exec, medido con un filtro que no casa nada).
- **El caso `GS · P · relations.order.exhaustive` son 4,98 s = el 90 %**. El siguiente caso más lento tarda 0,14 s.
- Desglose del caso (script de tiempos):

| trozo | ms |
|---|---|
| E1-reduced EXHAUSTIVO (131 072 pares) | 1 359 |
| vigencia E1-reduced, atómico, 50k | 1 910 |
| vigencia E1-reduced, dos Write, 50k | 1 558 |

- La muestra escala lineal: 5k = 188 ms, 10k = 348, 20k = 655, 50k ≈ 1 560.

**Corredor de mutantes** (`scripts/check_guard_mutants.mjs`):
- 181 mutantes, en SERIE;
- cada uno lanza un proceso nuevo con **el spec ENTERO** (`--files=tests/guard_surface.spec.ts`, línea 101), aunque solo juzga los títulos de `expectRed`;
- 181 × 6,1 s ≈ **18,4 min**, coherente con los ~17,5 medidos por el coordinador.

**Por qué pasó de ~6,5 a ~17,5 min.** No es que haya más mutantes de la propiedad (son 16 de 181). Es que **los 165 mutantes que NO tocan el orden pagan igualmente los 4,8 s de fuerza bruta**:
- antes del cierre 3 la propiedad solo tenía el exhaustivo de E1-reduced, ≈ 1,4 s;
- la vigencia (2 × 50k) añadió ~3,5 s **por mutante**, ≈ 10,5 min con 181;
- el resto lo explica el crecimiento del número de mutantes.

**CI**: el job `guard-mutants` corre la matriz `[sqlite, sqlite-file]` (`.github/workflows/ci.yml:268-281`), así que la fuerza bruta (pura, sin SQL) se paga **dos veces**.

**`npm test` por spec suelto** (61 specs en proceso aparte, suma 152 s, cada uno con su arranque de ~0,6–0,9 s):
- **`relations_order_exhaustive.spec.ts` = 89,3 s, el 59 % de la suite en `:memory:` sin OpenFGA**;
- le siguen `guard_surface` 5,6 s, `purity` 3,2 s, `relations_contract` 3,1 s y `command_flags_d2` 2,7 s.

Dentro del spec exhaustivo:

| caso | s |
|---|---|
| E1 EXHAUSTIVO (2 097 152 pares) | 25,0 |
| vigencia E1 300k atómico | 10,6 |
| vigencia E1-reduced 300k atómico | 9,5 |
| vigencia E1 300k dos Write | 8,8 |
| vigencia E1-reduced 300k dos Write | 8,4 |
| vigencia U2 30k atómico / dos Write | 4,8 / 3,9 |
| U2 30k (sin vigencia) | 3,9 |
| vigencia E3 30k atómico / dos Write | 3,1 / 2,1 |
| E1-reduced sin cuts | 2,5 |
| E3 30k (sin vigencia) | 2,1 |
| contraejemplos literales del cierre 4 | 2,1 |
| resto | ~2 |

No medido: la suite con `OPENFGA_TEST_URL`. Las reglas del panel solo permiten specs sueltos en `:memory:`.

### 2.2 · ¿Re-ejecutan los mutantes suites enteras?

**Sí: el spec entero, no la suite.** El criterio de muerte (`check_guard_mutants.mjs:167-176`) solo mira los títulos de `expectRed`. Los otros ~235 casos solo alimentan `collateral`, que es informativo y no decide nada. Hoy se corren 236 casos para juzgar 1–3.

### 2.3 · Propuestas, sin perder poder de detección

**G1 · Ejecutar por mutante SOLO sus `expectRed`.** Japa 5.3 filtra por título EXACTO con `--tests=<título>` repetible, sin partir por comas (`@japa/core` `#isTestTitleAllowed`, `includes(test.title)`).
- Medido: la guardia filtrada a un caso tarda **0,63 s de pared** (×3: 0,63/0,62/0,67).
- Proyección: 165 × ~0,65 s + 16 × ~5,6 s ≈ **3,3 min** en serie (×5,5).
- El poder de detección es idéntico por construcción: el criterio de muerte no cambia.
- Lo que se pierde: `collateral`. Se recupera con `--full` en un job nocturno.
- **Condición de aceptación (una vez):** correr los 181 en los dos modos y exigir el mismo estado por mutante. Así se demuestra que ningún caso de `expectRed` dependía del estado que dejaban casos anteriores del spec.

**G2 · Paralelizar el corredor.**
- Un directorio temporal por worker (la copia ya está aislada; `node_modules` va enlazado);
- `--jobs=N`, por defecto `os.availableParallelism() - 1`;
- memoria medida: 345 MB de RSS por ejecución de la guardia; con N = 4 son 1,4 GB.

Con G1:

| dónde | N | tiempo |
|---|---|---|
| esta máquina | 8 | **< 45 s** |
| `ubuntu-latest` | 4 | **≈ 1 min** |

Sin G1, N = 4 da ≈ 4,6 min.
- En `sqlite-file` cada proceso abre su propio fichero `mkdtemp`, así que no hay contención.
- El orden de salida se puede reordenar por id para que el log sea estable.

**G3 · No pagar la fuerza bruta dos veces en CI.** Los 15 mutantes de `tuple_order.ts` y los 4 de `reconcile.ts` no tocan SQL. Basta con correrlos en una sola pierna de la matriz (`--only-db-dependent` en la pierna `sqlite-file`).
- Hay 81 mutantes (`tuple_order` 15, `reconcile` 4, `relations_contract` 17, `openfga_*` 45) que, por el fichero que tocan, no deberían depender del motor. Pero `openfga_*` y el doble pasan por el manager, que lee el freeze por SQL.
- **Afirmar «independiente del motor» exige una prueba**, no una suposición: correrlos una vez en los dos motores y comparar. Sin esa prueba, G3 se limita a los 19 de `tuple_order` + `reconcile`, donde la independencia es estructural (el helper no importa la base).

**G4 · Acotar la fuerza bruta de la GUARDIA con datos.** El script de muestra mide qué trozo mata a cada mutante; resultado en §2.4.
- Si los 16 mueren por semántica con 10k de vigencia y el exhaustivo, la guardia puede bajar de 50k a 10k: 3,47 s → ~0,7 s por mutante, ×16.
- La cobertura grande se queda en el spec exhaustivo, que corre una vez.
- **Con G1 esto apenas importa** (solo afecta a 16 mutantes, ≈ 45 s en serie). Prioridad baja.

**G5 · El spec exhaustivo (89 s) en paralelo dentro del proceso.** Los resultados son SUMAS de contadores, así que se puede trocear la muestra en K particiones con semilla derivada (`seed + k`) y repartirlas en `worker_threads`.
- Con 8 workers, 89 s → ~12–15 s en esta máquina y ~25–30 s con 4 núcleos.
- **Coste**: las cifras FIJADAS cambian una vez (otra partición del espacio aleatorio). Hay que re-medirlas y reescribir README, CHANGELOG e informe, el mismo ritual que cuando se toca el orden.
- La semilla sigue fija y el resultado es determinista.

**G6 · Tiers declarados, no escondidos.** Lo que se separa va a un job requerido, no a un `skip` silencioso.
- `npm test` local: guardia (G1 + G2 no le afectan; 6 s) + exhaustivo con G5.
- CI:
  - los jobs que corren `npm test` SIN el spec exhaustivo, que es puro y no depende del motor. Hoy la suite corre **8 veces por push** (`ci.yml`: `test` ×2 en las líneas 29/33, `openfga` ×2 en 82/87, `engines` 2 motores × 2 en 155/158), así que el exhaustivo se paga 8 × ~89 s ≈ **12 min de runner** y la guardia 8 × 6 s;
  - un job `order-proof` único y requerido: el spec exhaustivo + `AUTHZ_ORDER_VIGENCIA_EXHAUSTIVE=1` (~10 min) **solo cuando cambian `src/relations/tuple_order.ts`, `reconcile.ts` o `tests/helpers/order_bruteforce.ts`** (filtro de rutas), y siempre en el job de RC.
- El exhaustivo largo es hoy una opción manual (`.skip` por variable). Con un job requerido por rutas, deja de depender de que alguien se acuerde.

**Objetivos concretos:**

| verificación | hoy | objetivo | con qué |
|---|---|---|---|
| guard-mutants, una pierna (`:memory:`) | ~17,5 min | **≤ 1,5 min** (CI, 4 núcleos); ≤ 45 s local | G1 + G2 |
| guard-mutants, matriz de CI completa | ~35 min de runner | **≤ 3 min** | G1 + G2 + G3 |
| `relations_order_exhaustive.spec` | 89 s, ×8 ejecuciones de `npm test` en CI (≈ 12 min de runner) | **≤ 30 s, ×1** (job `order-proof`) | G5 + G6 |
| exhaustivo de vigencia (33,5 M × 2) | manual, ~10 min | **requerido por rutas y en RC** | G6 |
| `npm test` `:memory:` sin OpenFGA | ~150 s (suma de specs) | **≤ 75 s** | G5 |

Ninguno de los cinco reduce casos, semillas ni universos. G4 es el único que recorta una muestra, solo en la guardia y solo si §2.4 lo justifica.

### 2.4 · Qué trozo mata a cada mutante de `relations.order.exhaustive` (`panel-optimo-tester-muestra.ts`)

Cada mutante se aplicó, con las `edits` del manifiesto, sobre una copia de `src/` + el helper, en proceso. Leyenda:
- **S**: muere por SEMÁNTICA (`malformed` o `unsafeWithoutResidue` > 0);
- **c**: muere SOLO por las cifras fijadas (comparadas en el exhaustivo y en 50k, que es lo que fija la guardia);
- **·**: vive en ese trozo.

Formato de las celdas de vigencia: atómico/dos Write.

| mutante | E1-red exh. | v 2k | v 5k | v 10k | v 20k | v 50k |
|---|---|---|---|---|---|---|
| (original) | ·/· | ·/· | ·/· | ·/· | ·/· | ·/· |
| order.phase.deny-writes-last · deny-deletes-first · allow-deletes-late · allow-writes-early | S | S/S | S/S | S/S | S/S | S/S |
| order.c1.off · c2.off · c3.off · selfcut.union · residue.hidden · pairs.holder-only | S | S/S | S/S | S/S | S/S | S/S |
| **order.c2.no-exclusion** | **solo c** | ·/· | ·/· | ·/· | ·/· | c/c |
| **order.c4.off** | **solo c** | ·/· | ·/· | ·/· | ·/· | c/c |
| **order.priority.deletes-first** | **solo c** | ·/· | ·/· | ·/· | ·/· | c/c |
| rec.plan.vigencia-ignored | · | S/S | S/S | S/S | S/S | S/S |
| order.withhold.off | · | ·/S | ·/S | ·/S | ·/S | ·/S |
| order.renewals.horizon-flat | · | S/S | S/S | S/S | S/S | S/S |

Lecturas:

1. **13 de los 16 mueren por semántica con una muestra de vigencia de 2 000** (o con el exhaustivo). La muestra de 50k de la guardia no es lo que los mata. Lo que la sostiene son **las CIFRAS**.
2. **Hay TRES mutantes más de la guardia que solo mueren por cifras, y no estaban declarados como tales**: `order.c2.no-exclusion`, `order.c4.off` y `order.priority.deletes-first`.
   - Dos son de precisión y se aceptan así:
     - `no-exclusion` añade precedencias espurias, lo que da más residuo y nunca concede;
     - `priority` reparte distinto.
   - **`order.c4.off` no es de precisión.** El manifiesto lo describe como «el sujeto que cambia de grupo denegado pierde el deny viejo antes de tener el nuevo», que es un hecho de SEGURIDAD. Que solo muera por cifras significa una de dos:
     - o la fuerza bruta lo absorbe como residuo declarado (el ciclo lo cubre y entonces C4 sería redundante);
     - o el universo no tiene la forma que lo ejerce.
   - Lo comprobé en los universos grandes (abajo). Hay que decidir si C4 es necesaria. Si lo es, necesita un caso literal `walkPair`.
3. **Consecuencia para G4:** bajar la muestra de la guardia NO pierde ninguna muerte SEMÁNTICA (2k ya basta para las 13), pero CAMBIA las cifras fijadas. Esas cifras son la única muerte de 3 mutantes, y de los 3 «a mano» del §3.1. Bajarla obliga a re-fijarlas: el poder de detección se conserva, porque las cifras a 10k también se mueven con los mismos mutantes, pero eso **hay que medirlo** antes de aceptarlo. La forma limpia es sustituir las muertes por cifras por casos LITERALES (§3.1). Después, la muestra de la guardia se puede bajar a 5–10k sin depender de cifras.

**En los universos GRANDES** (`panel-optimo-tester-muestra.ts grandes …`, en proceso; S(n) = n combinaciones sin residuo):

| mutante | E1 exh. | U2 30k | E3 30k | vig. E3 30k atóm. | vig. U2 30k atóm. |
|---|---|---|---|---|---|
| (original) | · | · | · | · | · |
| order.c2.no-exclusion | · | · | · | · | · |
| **order.c4.off** | · | **S(2)** | **S(2)** | **S(6)** | **S(2)** |
| order.priority.deletes-first | · | · | · | · | · |
| order.withhold.off | · | · | · | · | · (solo actúa en «dos Write»; ahí muere en la guardia) |

Y el mutante DOBLE (`panel-optimo-tester-c4.ts`, E1-reduced exhaustivo):

| mutante | sin residuo | ciclos | conceden |
|---|---|---|---|
| `c4.off` solo | 0 | 1 044 | 204 |
| `priority.deletes-first` solo | 0 | 1 140 | 204 |
| **los dos a la vez** | **128** (también 128 sin `cuts`) | 1 044 | 356 |

Lecturas:
- **`order.c4.off` es de SEGURIDAD y muere por semántica, pero solo en U2/E3**, es decir, en `relations_order_exhaustive.spec`, que el corredor de mutantes NO ejecuta. En el universo de la guardia lo enmascara el desempate «escrituras antes que borrados»: en E1-reduced el desempate basta y en U2 no.
- El contraejemplo mínimo, encogido con `walkPair` (`panel-optimo-tester-c4lit.ts`), es U2 con `--prune`:
  - inicial `[g@u2 g@h#member y@u2 x@g#member ¬y@g#member]`;
  - final `[h@u2 y@u2 x@g#member ¬y@h#member]`;
  - mutante: `+¬y@h#member -g@u2 …` **concede tras el paso 2** (U2 sale de g, que le negaba Y, antes de entrar en h, que también se lo niega);
  - original: `bad: null`.
  - Es un caso de `walkPair` de una línea. Entra en el spec exhaustivo y, si se quiere en el corredor, en la propiedad de la guardia como literal. Así deja de depender de cifras.
- **`order.priority.deletes-first` es semánticamente EQUIVALENTE** en los cinco universos (con C4 activa, el desempate no cambia la seguridad). Su muerte por cifras es legítima solo como «el reparto está fijado». Propongo declararlo así en el manifiesto (campo `kills: 'cifras'` con razón), igual que `c2.no-exclusion` (precisión: más residuo, nunca concede).

---

## 3 · Huecos de cobertura en la superficie pública (`src/testing/*`) y los tres mutantes «solo por cifras»

### 3.1 · Los tres mutantes del auditor (cierre 4, punto 5)

**Primero un hueco de proceso: ninguno de los tres está en `tests/fixtures/guard_mutants.json`.**
- `grep` da 0 para `c4h.order.renewals-not-changing` y `c41.order.without-ignored`.
- `c41.plan.withhold-off` aparece solo como `rec.plan.withhold-off`, que es otro id con el mismo efecto.
- Los 13 mutantes del cierre 4 se corrieron a mano en un scratchpad de otra sesión (`scratchpad/c4/mutants.py`, informe §«Mutantes»). Solo 3 entraron al corredor: `rec.plan.withhold-off`, `order.withhold.off` y `order.renewals.horizon-flat`.
- Los otros 10 (`c41.order.cascade-off`, `.deletes-off`, `.conflict-as-withheld`, `.shortening-as-extension`, `.without-ignored`, `c4h.plan.shortening-not-passed`, `c4h.order.renewals-not-changing`, `c42.plan.conditional-in-pass`, `c43.raced.same-code`, `c44.roles.purgeScope-no-partial`) **no los re-verifica nada**. Un refactor puede dejarlos vivos en silencio.
- Esto choca con el punto 6 del `CLAUDE.md` («una entrada sin mutante que la mate … es rojo»). Propuesta: entran al manifiesto con `properties` (las cuatro propiedades existentes los cubren) o con `cells`. Con G1 + G2 cuestan segundos.

**Los tres, uno a uno:**

**(1) `c41.plan.withhold-off`: ✅ ya muere por semántica.** Coincido con el auditor:
- `relations_reconcile_contract.ts:374-402` («vigencia · C3-1», `later.check(...) === false` con `withClock`);
- y la fila C3-1 de `relations.reconcile.order` en el horizonte;
- y `rec.plan.withhold-off` está en el corredor.

No hace falta más.

**(2) `c41.order.without-ignored`: 🟡 → caso LITERAL sobre la función PURA, medido** (`panel-optimo-tester-l2.ts`). El mutante sustituye `union.below(v.user, guard.without)` por `union.below(v.user)` (casa 2 veces: en `writeThreatens` y en `deleteThreatens`).

| entrada a `relationWithheldWrites` (con `cuts`) | original | mutante |
|---|---|---|
| L2: `U∈h` retenida (extensión), h transporta `¬viewer X`; candidato NUEVO `h#member viewer X` (solo llega a U por la propia portadora) | retenidas `[]` | **retenidas `[x@h#member]`** |
| L2 control: candidato `g#member viewer X` con `U∈g` (otro camino) | `[x@g#member]` | `[x@g#member]` |
| L2b `--prune`: borrar el propio deny de la portadora (`¬x@h#member`) | `[]` | **`[¬x@h#member]`** |

- Es un caso de tres líneas en `relations_order_exhaustive.spec` o en un spec unitario de `tuple_order`, sin servidor ni base.
- Es de PRECISIÓN (sobre-retener no concede): la aserción dice «se escribe», no «concede». Más el control, que fija que la retención sigue funcionando por el otro camino.
- **Pero si gana la opción (ii) de §1.4, este mutante y su caso desaparecen** con `relationWithheldWrites`.

**(3) `c4h.order.renewals-not-changing`: 🟡 → caso literal de UNA combinación con vigencia.**
- **Hueco de infraestructura:** `walkPair` (`order_bruteforce.ts:131`) no tiene vigencia, así que hoy no hay forma de fijar una combinación del universo con estados. Hace falta un `walkVigencia(name, order, states, { prune, atomic })` que reutilice el cuerpo del bucle de `bruteForceVigencia`. En el script lo hago con una opción `fixed` parcheada sobre una copia.
- El contraejemplo del auditor (E3, atómico, semilla 7, 17 tuplas), **re-ejecutado hoy:** mutante `unsafeWithoutResidue 2`, original 0.
- Encogido por tupla, con un orden de simplicidad estricto. Quedan **8 tuplas, `--prune`, destino atómico** (formato `tupla:destino/origen`):
  - `a@u1:absent/same`
  - `b@u1:live/absent`
  - `b@a#member:live/absent`
  - `c@b#member:live/shorter`
  - `x@b#member:live/same`
  - `y@c#member:live/same`
  - `¬y@b#member:absent/same`
  - `¬x@c#member:live/same`
- Mutante: orden `[+¬y@b#member +a@u1 ~c@b#member -b@u1 -b@a#member]` ⇒ **concede tras el paso 3** en el horizonte. Original: 0.
- Lectura: la renovación que ACORTA `b ⊂ c` no cuenta como arista que cambia. El auto-corte da por buena la arista vieja y deja salir la membresía en el orden equivocado.
- **El caso:** `walkVigencia('E3', packageOrder(ORDER_CUTS), estados, { prune: true, atomic: true })` ⇒ `bad === null`, cuatro líneas en el spec exhaustivo. Con él, el mutante muere por semántica en el spec. Para que muera también en el CORREDOR, el literal tiene que vivir en la propiedad de la guardia, que es barato: una combinación cuesta milisegundos.

**Y dos más que solo mueren por cifras, de los que nadie había avisado** (§2.4):
- `order.c4.off`, que es de seguridad: literal U2 de arriba;
- `order.priority.deletes-first`, equivalente: hay que declararlo.

### 3.2 · Otros huecos de la superficie pública

| # | hueco | estado | cómo se cierra |
|---|---|---|---|
| H1 | La cara `atomicRenewal:true` del juez de relaciones no observa el estado intermedio (`relations_contract.ts:2070-2082`) | ❌ no observable con el harness publicado | hook de corte (§1.2, (a)) |
| H2 | **El oráculo de la fuerza bruta cuenta como `preexisting` toda concesión final que el inicial ya diera en cuanto la partición tiene cualquier `renewal-unsafe`/`deny-conditional`** (`order_bruteforce.ts:557-560`). Por eso no ve D4-1: 23 485 / 33 612 / 41 795 de 400 000 combinaciones en E1/U2/E3, **re-medido hoy con el script del auditor** | 🟡 | `preexisting` solo si el final SIN retención también concede en t. La comprobación del auditor (escribir lo retenido arregla `now` ⇒ no es preexistente) se convierte en contador ROJO |
| H3 | El oráculo excluye los objetos `group:` (`order_bruteforce.ts:81`): es ciego a `member` (D4-2), a `listSubjects(group)` y a `membersOf` | 🟡 | añadir al universo E1 un objeto que sea grupo con `member` como relación juzgada, o una propiedad aparte «retener nunca deja una membresía que el origen no tiene» |
| H4 | 10 mutantes del cierre 4 fuera del corredor (§3.1) | 🟡 | manifiesto |
| H5 | El invariante 13 (`indeterminate`) no lo juzga ningún runner publicado (declarado, `roadmap-2.0.md`, Diferido 2.6+) | ❌ declarado | sin cambio. Con MBB desaparece la rama parcial de `relate`/`replaceAssignment` y queda la de las purgas |
| H6 | `relations.reconcile.order` corta en la API del puerto: cualquier operación del driver que haga más de un `Write` (renovación de hoy, purgas) es una caja negra para ella | 🟡 conocido | la propiedad hermana a nivel de cliente FGA, como `openfga.purge.order`, para `relate` (P1) |
| H7 | La garantía del freeze entre procesos solo es observable fuera de `:memory:` (`CLAUDE.md`, mutante `modulo`); el job local por defecto no la ve | ✅ cubierto en CI por los jobs de motor | sin cambio; G6 no debe sacar esos jobs |

### 3.3 · Invariantes en riesgo con MBB y qué test los cubre hoy

| invariante | riesgo con MBB | test hoy |
|---|---|---|
| 3 (expiración en la tupla de relación, ESTRICTA) | la caducidad efectiva es la MAYOR de dos ranuras; un acortamiento perdido en carrera es fail-open | ✅ caducidad exacta T−1/T/T+1 en el juez (par `injectableClock`); ❌ con dos ranuras: P3/P4 |
| 6 (idempotente; choque = 409, jamás 503) | el 400 «cannot delete a tuple which does not exist» (M4) | ❌ hoy no existe ese camino; P3 |
| 10 (tres estados de `expiresAt`, `previousExpiresAt`) | leer `previous` exige plegar ranuras | ✅ juez + cruce de caducidades de `runMigrationContract`; con MBB, P6 |
| 11 (purga con demostración de cero) | demostrar cero sobre UNA ranura | ✅ hoy (una ranura); ❌ P4/P6 |
| 13 (escritura parcial = `indeterminate`) | MBB elimina la rama parcial de renovación | ✅ `relations_openfga.spec` C2-3 / `openfga_driver.spec` C3-4. Pasarán a probar que NO hay parcial |
| `reconcile` read-only en dry / mismos números | `member_alt` como `undeclared` (poda por TIPO) | ❌ P4 |
| D15 | `atomicRenewal` sigue opcional con par | ✅ `relations_harness.spec.ts:164` |
| Cotas del modo `facts` (22 saltos, techo en bytes) | relación duplicada ⇒ más bytes y quizá más nodos de resolución | ✅ casos que fijan las cifras; con MBB tienen que re-medirse (P7) |

---

## Comparación

| opción | casos nuevos | invariantes en riesgo | coste de prueba | veredicto |
|---|---|---|---|---|
| **MBB con capacidad opcional (i)** | P1–P9 + hook (a) | 3, 6, 10, 11, `reconcile` limpio, cotas | **alto**: P3/P7/P8 con servidor real y repeticiones; la rama `atomic:false` sigue entera (D4-* abiertos para terceros, H2 sigue siendo obligatorio) | verificable con cambios |
| **MBB + destino sin `atomicRenewal` con denies = 500 (ii)** | P1–P9 + hook (a) + el caso del 500 (dry y real, cero lecturas) | los mismos | **medio**: lo mismo, menos la rama `atomic:false`, los contadores de retención, 13 mutantes y D4-1/2/3. Ahorro medido ≈ 1,56 s/mutante y 23 s de spec | **verificable con cambios; la más barata de mantener** |
| sin MBB (estado actual) | H2 + H3 + D4-1 (literal) | los de hoy | **alto y creciente**: la familia de retención es donde nacen los 🟠 de cierre en cierre, y el oráculo esconde uno (H2) | verificable con cambios (no APTA hasta H2) |
| G1 + G2 + G3 (corredor) | ninguno (misma muerte por mutante) + la comprobación de equivalencia de una vez | ninguno | bajo: un script | verificable |
| G5 + G6 (spec exhaustivo) | ninguno; las cifras se re-fijan una vez | ninguno | bajo-medio: helper con `worker_threads` + reescritura de cifras | verificable |
