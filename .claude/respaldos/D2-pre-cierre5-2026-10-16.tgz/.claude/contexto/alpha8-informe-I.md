# alpha.8 · informe del implementador I (incremental)

Base: `main` `13ba731` (= 2.4.0-alpha.7). Sin commits; `version` intacta. Corridas en el scratchpad
(`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/a8_*.log`).

## C2/C1 · el respaldo de `enumerateRelationsMany` perdía tuplas (🟠, primero) — HECHO

- **Rojo** (`a8_c_red.log`, sqlite): 3 rojos. C2 `tests/relations_reconcile.spec.ts` (grupo `alpha.8 · C2`): la medida
  del analista (dos particiones paginadas de 2 en 2: página 1 = a1,a5,b2,b3 · cursor b3; reanudar pierde `a9`) — hoy
  no lanza. C1 `tests/relations_database.spec.ts` (grupo `alpha.8 · C1`): `driver.enumerateRelationsMany is not a
  function`; y la reanudación por cursor a través del manager (respaldo) veía 2 páginas de 6 (pérdida).
- **Verde** (`a8_c_green.log`): 69/69 en los dos ficheros.
  - C2 `src/relations/manager.ts`: el respaldo (driver sin el método) NO emite cursores: si una partición devuelve
    cursor ⇒ 500 `E_AUTHZ_CONFIG` nombrando `enumerateRelationsMany` y la salida (implementarlo en el driver o
    paginar partición a partición con `enumerateRelations`); `after` en el respaldo ⇒ 500 con cero llamadas al driver.
    Sin cursor en ninguna partición sigue devolviendo la unión (control fijado).
  - C1 `src/drivers/database_relations_driver.ts`: `enumerateRelationsMany` nativo = el SELECT de `enumerateRelations`
    con `partition_key IN (ortografías de todas las particiones)`, `partition_key` en el select para devolver la
    partición PEDIDA, orden por `uuid`, `limit + 1`, cursor estable. `enumerateRelations` pasa por la misma consulta
    (`#enumerateRows`). `[]` ⇒ 500 con cero consultas. Sin capacidad nueva.
- **Casos**: UNA consulta (espía knex `countQueries`) para 3 particiones; paridad tupla a tupla y en orden con 3
  `enumerateRelations`; reanudación con `limit: 4` vía `RelationsManager` (nativo: 6 páginas, 21 vistas, 0 repetidas);
  `[]` ⇒ 500 y 0 consultas. Corren en los 4 motores (`relations_database.spec.ts`).
- **Mutantes**: C1 «quitar el nativo (vuelve al respaldo)» ⇒ 2 rojos (`a8_c_mut1.log`: consultas ≠ 1 y el 500 del
  respaldo al reanudar). C2 «el respaldo vuelve a emitir el cursor de la última partición» ⇒ 1 rojo (`a8_c_mut2.log`).

## X-1 · opción desconocida ⇒ 500 — HECHO

- **Rojo** (`a8_x1_red.log`): 2 rojos (`{ waitForLeaseMss: 5 }` y `{ appply: true }` no lanzaban). Ese rojo ES el mutante
  «sin validación».
- **Verde** (`a8_x1_green.log`, 102/102 `scope_outbox.spec`): `#assertKnownOptions(operation, options, known)` al inicio de
  `relayScopeChanges` (`RELAY_OPTIONS`) y `requeueScopeChanges` (`REQUEUE_OPTIONS`): claves desconocidas ⇒ 500 `E_AUTHZ_CONFIG`
  nombrándolas y la operación; `null`/lista/cadena ⇒ 500; una clave conocida con valor `undefined` vale (los comandos ace las
  pasan así). Cero filas/llamadas en el rechazo (fijado).

## A · la raíz `app` exenta (tres sitios, por REF) + variante B — HECHO

- **Rojo** (`a8_a_red.log` + `a8_a_red_contract.log`): A-1, A-2, A-3, A-8, A-6 (fallo bajo la raíz), A-9 (letra), VB «EL CASO»
  y O-07b ×3 harnesses. Negativos A-4/A-7 y el negativo del 🔴 1 verdes antes y después (fijan lo que NO cambia).
  Nota: en el negativo del 🔴 1 y en m7, la entrada que va DETRÁS de otra ya aplazada sale `depends-on:<esa>` (transitivo, origen
  aparcado), no `parked:` directo — es la mecánica de alpha.5 (d); los casos lo fijan así.
- **Verde** (`a8_a_green.log`, 165/165 = `scope_outbox` + contrato + harness):
  - `src/manager.ts`: `#isRootRef(scope)` (`type === 'app' && uuid == null`), `#changeScopes(change)` (hijo; + padre salvo raíz)
    y `#changeKeys` = `#changeScopes` → `scopeKey`; `#dependencyOf` y `requeueScopeChanges` pasan `#changeScopes` al puerto
    (`earlierPending`/`laterApplied`). Variante B SOLO en `#parkedKeys`: siembra `scopeKey(item.change.child)`.
  - Contrato: O-07b nuevo (dos `attached` bajo `app` no se contaminan; bajo el mismo padre no raíz sí); `EXPECTED_CASES` 15→16.
  - Letra: README (párrafo «The root `app` is not a scope key, and a parked entry only plugs the key of its own child
    (2.4.0-alpha.8)» con los tres 422 y los dos cambios de comportamiento observable); `CLAUDE.md` :742 corregida y regla de
    higiene (ii) ampliada (aditivo). A-9 lo fija.
- **Mutantes** (`a8_a_mut*.log`): m1 «la raíz vuelve a ser clave» ⇒ 7 rojos (A-2/A-3/A-6/A-8 + O-07b×3; A-1 queda verde porque
  la variante B ya subsume el tapón bajo la raíz, como midió el analista); m2 «solo la clave del hijo en TODAS partes (variante B
  en `#changeKeys`)» ⇒ 26 rojos (incl. el caso 1136 con respaldo, O-07 y `only` 1c-1); m3 «exención solo en S1» ⇒ 3 rojos
  (A-2/A-3/A-8: los del SQL de la sonda, el mutex bajo `only`); m4 «sin variante B» ⇒ 1 rojo (m7).

## B · `requeueScopeChanges(ids, { apply })` + `waitForLeaseMs` — HECHO

- **Rojo** (`a8_b_red.log`): 10 rojos (6 del grupo `apply`, 4 del grupo `waitForLeaseMs`): tras X-1, `apply`/`waitForLeaseMs`
  son «opción desconocida» (500); el comando no declaraba `--apply`/`--wait-lease-ms`; el README no decía nada. R-5
  (`apply`+`force` ⇒ 500) ya salía verde por X-1 (se confirma por la razón correcta con el mutante «apply+force permitido»).
- **Verde** (`a8_b_green.log`, 124/124 `scope_outbox.spec`, exit 0):
  - `src/manager.ts`: refactor de `relayScopeChanges` en `#relayInputs` (only/filter/dead/deadEntries/missingOf),
    `#acquireLease(outbox, waitForLeaseMs)` (un intento con 0; con tope, reintenta cada `RELAY_LEASE_POLL_MS` = 25 ms con el
    reloj inyectable `#wallMs`, `busy` al vencer), `#busyReport` y `#drainScopeChanges` (el cuerpo de la pasada, bajo lease ya
    tomado). `requeueScopeChanges(ids, { force?, apply?, waitForLeaseMs? })`: `apply`+`force` ⇒ 500; `waitForLeaseMs` sin
    `apply` ⇒ 500; con `apply`: barrera del freeze ANTES de nada → capacidades del puerto → lease PRIMERO (ocupado ⇒
    `relay.busy`, `requeued: []`, cero filas) → `#requeueHeld` (censo, sonda anti-reversión, `requeue`) → `#drainScopeChanges`
    con `only` = los ids reencolados y lo aparcado releído → `release` en `finally`. `RELAY_OPTIONS`/`REQUEUE_OPTIONS`
    ampliadas. `RELAY_LEASE_POLL_MS` exportado (index.ts).
  - `src/types.ts`: `ScopeRequeueReport.relay?: ScopeRelayReport` (solo con `apply`).
  - Comandos: `authz:scopes:requeue --apply` (explícito) y `--wait-lease-ms`; `requeueLines` con `relay`: `busy` ⇒ error +
    exit ≠ 0 (letra: otra pasada tiene el lease; `--wait-lease-ms` o sin `--apply`); por entrada aplicada/aplazada/fallida;
    limpio solo si TODO lo reencolado se aplicó; aviso si quedan pendientes (los dependientes no se arrastran).
    `authz:scopes:relay --wait-lease-ms`. El literal `force: this.force === true` se conserva (caso 2314).
  - README: párrafo «Closing the incident in one call…» (las cuatro condiciones, lease tomado ⇒ cero filas, `--apply` explícito)
    y «Waiting for the lease instead of giving up…» (default 0, sondeo, `busy` al vencer, pool ≥ 2, no dimensionar a un
    backlog); fila `RELAY_LEASE_POLL_MS` en Limits.
  - Casos: R-1/R-2 (P14 cerrado en una llamada; UNA adquisición con espía sobre `acquire`; el `only` del tenant sale `applied`
    después; el dependiente NO se arrastra), R-4 (anti-reversión con `apply`: 500, cero llamadas, cero filas, lease suelto),
    R-5, R-8 (freeze ⇒ 503, cero leases, cero filas; sin `apply` no pasa por la barrera), R-2b (lease tomado ⇒ busy, cero
    filas; soltado, entra), R-6/R-7 (causa rota ⇒ vuelve a `dead()` en la misma llamada; 503 ⇒ pendiente con max − 1), R-10
    (flags y `requeueLines`). W-1 (dos relays, la segunda espera y aplica lo que quedó; ≥ 3 adquisiciones), W-2 (default 0 ⇒
    UNA adquisición y busy), W-3 (vence en busy, intentos acotados, inválidos ⇒ 500), letra. **W-4 multiproceso** en
    `scope_outbox_multiprocess.spec.ts` (pg/mysql): el hijo (`relay_child.ts` + `AUTHZ_TEST_WAIT_LEASE_MS`) espera el lease
    del SERVIDOR que sostiene el padre y entra al soltarlo — verde en PG (`a8_w4_pg.log`, 3/3).
- **Mutantes** (`a8_b_mut*.log`): «default de `waitForLeaseMs` > 0» ⇒ 2 rojos, incluido el caso 2460 «dos pasadas a la vez ⇒
  busy» (como exigía el juez); «apply toma el lease dos veces (llama a `relayScopeChanges` por dentro)» ⇒ 3 rojos (R-1/R-2,
  R-2b, R-6); «apply sin barrera del freeze» ⇒ 1 rojo (R-8); «con el lease ocupado reencola y dice busy» ⇒ 1 rojo (R-2b).
- CHANGELOG `[Unreleased] — 2.4.0-alpha.8` escrito (estilo 1.1.0): Fixed (raíz, variante B, cursor del respaldo), Added
  (nativo, `apply`, `waitForLeaseMs`, X-1), «What is NOT done» (supersede con el 🔴 1 medido, `parkAfterMs` con el 🔴 2 medido:
  50 000 aparcadas ⇒ toda pasada 500 en 91 ms, `dead` ve 10 000, requeue de 200 = 490 ms; `blockOnParentKey`, `only`
  arrastrando, `--apply` por defecto, capacidad `…Native`).

## Verificación final (todo con `OPENFGA_TEST_URL=http://localhost:8101`)

- `tsc --noEmit` 0 · `npm run typecheck` 0 · `npm run check:purity` 0 · `npm run build` 0 (`a8_final_*.log`).
- `npm test` (sqlite :memory:) **1323/1323** (base 1292, +31) · `test:sqlite-file` **1349/1349** (base 1318, +31) ·
  `test:pg` **1445/1445** (base 1413, +32) · `test:mysql` **1447/1447** (base 1415, +32). Los +31 = C2 2 + C1 2 + X-1 2 +
  A 8 + variante B 3 + B 7 + W 4 + O-07b ×3 harnesses; el +1 de pg/mysql es W-4 multiproceso.
- Sin commits; `version` sigue `2.4.0-alpha.7`; sin `skip`; 17 ficheros, +1641/−81.

## Lo que NO hice (lote II / fuera de alcance)

- Edad de la cola (`createdAt`, `queue.{oldestPendingAt,pendingAgeMs}`, `--max-age`), `requireTransaction`, `origin` en
  `entries`, `deadCount`/`deadDetail`, trx cerrada ⇒ `E_AUTHZ_CONFIG`, letra del 422 y `maxDepth = N + 1`: implementador II.
- Supersede, `parkAfterMs`, `blockOnParentKey`, capacidad `enumerateRelationsManyNative`, `--apply` por defecto: decididos NO.
- El caso de la carrera real (dos altas concurrentes con el store caído) sigue sin observarse (riesgo 2 del juez, declarado).

## Contradicciones con el juez / decisiones que tomé sin reabrir nada

- Ninguna contradicción. Dos elecciones dentro del margen del juez: (1) C2 = «500 en cuanto una partición devuelve cursor» +
  «`after` en el respaldo ⇒ 500 con cero llamadas» (las dos caras del «falla ruidoso»; no se construyó cursor compuesto).
  (2) `waitForLeaseMs` también en `requeueScopeChanges` pero SOLO con `apply` (sin `apply` ⇒ 500: no hay lease que esperar),
  como injerto del juez «`--apply` acepta `--wait-lease-ms`».
- Observación para el auditor: A-1 (aparcada bajo la raíz) queda cubierto por la variante B aunque la raíz volviera a ser
  clave (mutante m1 la deja verde); la raíz la fijan A-2/A-3/A-6/A-8 y O-07b.
