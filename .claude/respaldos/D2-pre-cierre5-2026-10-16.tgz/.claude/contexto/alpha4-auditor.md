# alpha.4 — AUDITOR sobre el DIFF (veredicto)

Fecha: 2026-09-09 · Árbol: `main` @ `9a107ad` + lote alpha.4 **sin commitear** (11 modificados, 4 nuevos).
Contraste: mis condiciones de `.claude/contexto/panel-alpha4-auditor.md`.
Verificación propia: `npm test` **917/917 verde**, `npm run typecheck` limpio, `check:purity` verde, más cuatro
repros míos re-ejecutados contra el árbol nuevo (`audit4.ts`, `audit4b.ts`, `oldwrap.ts`, `weight.mjs` en el
scratchpad).

## Veredicto

**APTA.** Ningún 🔴 ni 🟠. Los tres hallazgos que condicionaban el lote (🔴 1, 🟠 2, 🟠 3) están cerrados y
**los he vuelto a medir yo, no me he fiado de la suite del implementador**. Quedan cuatro ⚪ (uno nuevo y
concreto: `--store-id` no valida el modelo), que no reabren.

---

## 1 · Mi 🔴 1 — ¿`capabilities()` toca `#driver` o cachea algo propio?

**Cerrado.** `src/manager.ts:426-429` es literalmente `const driver = await this.driver(); return normalizeAuthorizationCapabilities(driver.capabilities)`.
No hay segundo camino de resolución, no hay campo nuevo, no se escribe `#driver` (sigue habiendo exactamente
dos asignaciones: `:395` tras las puertas y `:756` en `clearCachedDriver`).

Medido por mí (`audit4.ts`), driver `hierarchyFacts: true` sin outbox ni firma:

```
1a capabilities() primero ⇒ E_AUTHZ_SCOPE_DRIFT_UNGUARDED
1a driver() después       ⇒ E_AUTHZ_SCOPE_DRIFT_UNGUARDED   (factory 2×: nada quedó cacheado)
1a authorize() después    ⇒ E_AUTHZ_SCOPE_DRIFT_UNGUARDED
```

La tercera línea es la que me importaba y no está en su suite: tras un `capabilities()` fallido **la ruta de
lectura también sigue cerrada**. Si hubiera envenenamiento, `authorize` respondería.

**Vista de `forRequest()`**: `capabilities` está en el `Pick` (`src/manager.ts:144`) y la vista **no** resuelve
nada propio — `driver()` delega en `#parent` (`:369`). Medido: la vista y el padre devuelven lo mismo con **una
sola** llamada a la factory. No hay ruta alternativa por la vista.

**¿Puede la copia MENTIR hacia `false` (mi 🟡 5)?** No en ninguna variante que pude construir:

```
2 caps=true · driver real=true (factory 1×)
2 tras clearCachedDriver(): caps=false · driver real=false  → coherentes
3 con config.clock (vista withClock por prototipo): caps=true · instancia=true
```

La razón estructural es correcta: `capabilities()` y `#assertTransactionalWrite` leen **la misma expresión**
(`await this.driver()`), así que la copia sale siempre de la instancia que escribe, incluida la vista de
`withClock` (hereda la propiedad del original por prototipo) y una re-resolución tras `clearCachedDriver()`.

## 2 · Mi 🟠 2 — opción B en `prepare()`

**Cerrado, y por el sitio correcto.** `prepare()` va antes que `run()` en el mismo `try` de
`BaseCommand.exec` de `@adonisjs/core` (`build/main-DvUje0hm.js:59-83`), que **no relanza**: guarda `error`,
pone `exitCode ?? 1` y lo pasa al `errorHandler`. Medido por mí:

| pregunta del coordinador | medido |
|---|---|
| ¿`prepare()` corre antes de que ace valide flags/args? | **No: la validación va primero.** `openfga:provision --flag-que-no-existe` ⇒ `E_UNKNOWN_FLAG` y la app **sigue en `initiated`** (no booteó). La validación está en `#execMain` (`@adonisjs/ace:2143-2165`), antes de instanciar el comando. |
| ¿Un `boot()` que lanza (un `config/*` que no importa) sale limpio o cuelga? | **Limpio**: provider con `boot()` que lanza ⇒ `exitCode=1`, `cmd.error` con el mensaje, sin proceso colgado, estado `initiated`. |
| ¿`app.terminate()` se llama al final con `startApp: false`? | **Sí, siempre**: el ignitor lo hace incondicionalmente para todo comando sin `staysAlive` (`@adonisjs/core/build/main-B2M1tZ4I.js:92-97`), y `terminate()` funciona desde `booted` (solo se salta desde `created`/`terminated`, `application-BCWLhWpE.js:2575`). Los `shutdown()` de los providers corren (lucid cierra el pool que ni llegó a abrirse). No quedan handles: el comando no abre conexiones. |
| ¿Un `booted` previo es de verdad no-op? | **Sí**: dos `exec` en el mismo proceso ⇒ estado `booted` tras el primero y tras el segundo, sin re-bootear (y `Application.boot()` es no-op silencioso fuera de `initiated`, que es justo por lo que la guarda de estado tiene que estar y está). |

Y la decisión queda demostrada donde tenía que estar: A-5 mide que con un provider cuyo `ready()` consulta la
base el comando **llega a `run()`** y solo corrieron `register`+`boot`. Es exactamente el escenario del
appliance que me hizo rechazar la opción A.

## 3 · Mi 🟠 3 — copia congelada en los dos managers y en la vista

**Cerrado.** `normalizeAuthorizationCapabilities` / `normalizeRelationsCapabilities` (`src/types.ts:365-375`,
`:1735-1743`) construyen un objeto nuevo, con todas las claves conocidas, `=== true` (la misma lectura que las
puertas) y `Object.freeze`. Verificado por mí: la copia es de valores booleanos puros (0 valores no booleanos,
así que el freeze superficial basta), no es alias del objeto del driver, y mutarla lanza. La vista devuelve la
misma copia por delegación. En relaciones es síncrono sobre `#driver`, que es **la misma instancia** que lee la
puerta 1 (`src/relations/manager.ts:145`) — incluida la vista de `withClock`, que el constructor sustituye
antes de guardarla.

Y el diente contra la deriva de claves es real, no circular: **D-1** compara `{...capabilities()}` con
`{...driver.capabilities}` de los dos drivers del paquete, así que una capacidad nueva que se añada al driver y
no a `AUTHORIZATION_DRIVER_CAPABILITY_KEYS` sale roja (el `ReadonlyArray<keyof …>` solo no lo forzaría: TS no
exige exhaustividad ahí).

## 4 · L-A — el loader

Verificado el mecanismo contra el framework, no contra el informe: `createAceKernel` hace
`kernel.addLoader(() => commandModule())` y usa **el namespace del módulo como loader**
(`@adonisjs/core/build/create_kernel-Bx7xtr5F.js:30-32`), así que el barrel de alpha.3 rompía `node ace`
entero. Con el árbol nuevo, registrando el módulo tal cual: `boot()` sin error y los **nueve** comandos.

- **¿`getCommand` puede devolver un comando ajeno?** No. El kernel guarda `{metaData, loader}` por comando y
  solo llama a `getCommand` **del loader que aportó esa metadata** (`@adonisjs/ace:2475-2482`); y
  `ListLoader.getCommand` filtra por `commandName` dentro de nuestras nueve clases (`:1764`). El único
  solapamiento posible es que el consumidor declare un comando con nuestro nombre, que es precedencia
  documentada del framework y no la introduce este lote.
- **`this` de las funciones exportadas**: `getMetaData`/`getCommand` cierran sobre el `loader` del módulo y no
  usan `this`; ace las invoca como propiedades del namespace (`loaderInstance.getMetaData()`), así que no hay
  `this` perdido. Correcto por construcción, no por suerte.
- **Peso y efectos de `@adonisjs/core/ace`**: 85 ms de importación, **0** listeners de proceso
  (`SIGINT`/`exit`/`unhandledRejection`) y ningún handle nuevo. No hay efectos colaterales, y el coste solo lo
  paga `node ace`. La regla de pureza no la toca (`check:purity` verde: la peer `@adonisjs/core` siempre estuvo
  permitida).

## 5 · L-F — validar antes de `createStore`

Correcto en `provisionOpenFgaStore` y medido por mí: catálogo que desborda ⇒ `E_AUTHZ_MODEL_TOO_LARGE` con
**cero requests**. Pero ver ⚪ N1: la rama `--store-id` **no** pasa por ahí.

---

## Hallazgos nuevos (ninguno reabre)

### ⚪ N1 · `--store-id` no valida el modelo: sigue saliendo un error crudo del SDK, con request incluida

- **Escenario**: precondición — store ya existente y catálogo que ha crecido por encima del techo (el caso
  típico de la rama `--store-id`, que es la de ACTUALIZAR el modelo). Acción —
  `node ace openfga:provision --store-id 01H…`. Resultado — el comando construye el modelo con
  `openFgaFactsModel` a secas (`commands/openfga_provision.ts:133-137`) y lo manda; el servidor lo rechaza.
- **Evidencia**: ✅ medido con el `fgaStub` del propio harness, 4000 permisos:
  `--store-id` ⇒ `FgaApiValidationError`, **1 request** (`POST /stores/…/authorization-models`);
  sin `--store-id` ⇒ `E_AUTHZ_MODEL_TOO_LARGE`, **0 requests**.
- **Por qué es ⚪ y no más**: no crea nada, no deja store huérfano (ese era mi ⚪ 7 y sí está cerrado) y el
  CHANGELOG acota la promesa a `provisionOpenFgaStore` — no hay sobreventa. Es asimetría de diagnóstico.
- **Steelman**: *"la rama `--store-id` no crea nada, el error del servidor ya lo dice"* → me convence a
  medias: el mensaje del SDK no nombra el techo ni la salida (`OPENFGA_MAX_AUTHORIZATION_MODEL_SIZE_IN_BYTES`),
  que es justo lo que el operador necesita en la actualización.
- **Corrección mínima**: `assertFactsModelPublishable(holderTypes, permissions, undefined, relations)` también
  en la rama `if (this.storeId)`, antes del `writeAuthorizationModel`.

### ⚪ N2 · La migración del workaround muere con un `TypeError` cuya letra no está documentada

- **Escenario**: un consumidor que usaba `new ListLoader(Object.values(m))` (según el README, *la única forma
  en que funcionaba antes de alpha.4*, o sea probablemente COGNITIV) actualiza ⇒ `node ace` entero muere con
  `TypeError: command.serialize is not a function`. ✅ medido.
- Es ruidoso y fail-closed (una CLI que no arranca), y la nota de migración existe en README y CHANGELOG; lo
  que falta es **la letra exacta del error nuevo** (solo está la del error viejo,
  `loaderInstance.getMetaData is not a function`), que es lo que la víctima va a pegar en un buscador.
- **Corrección mínima**: añadir `TypeError: command.serialize is not a function` a la nota de migración.

### ⚪ N3 · `capabilities()` responde en una vista de `forRequest()` ya CADUCADA

- ✅ medido: con `maxAgeMs` vencido, `authorize` ⇒ `E_AUTHZ_VIEW_EXPIRED` y `capabilities()` ⇒ responde.
- Sin impacto: no es dato de scope, no sale del memo de ancestros y delega en el driver del padre (no puede
  quedar obsoleta). Es la misma conducta que `driver()`, que también está en el `Pick` y tampoco pasa por
  `#assertReadable`. Lo dejo escrito para que sea decisión y no descuido.

### ⚪ N4 · El centinela `if (this.exitCode === 1) return` de `run()` es frágil

- Hoy es correcto y unívoco (ace deja `exitCode` en `undefined` hasta el final de `exec`, como bien anota el
  informe §4.7), pero acopla dos métodos por un valor público que cualquier código futuro puede poner.
- **Corrección mínima**: un campo privado (`#aborted = true` en `prepare()`), o `if (this.exitCode !== undefined) return`.

## Estado de mis hallazgos del panel

| # | Estado |
|---|---|
| 🔴 1 envenenar `#driver` | **Cerrado** (D-5a/b + mi tercera aserción sobre `authorize`) |
| 🟠 2 opción A | **Cerrado**: se eligió B, y A-5 mide que `ready()` no corre |
| 🟠 3 referencia mutable | **Cerrado**: copia congelada y normalizada en los dos managers |
| 🟡 4 lectura que lanza | **Aceptado y documentado** (README + docblock: llámalo en `booted`/`ready`) |
| 🟡 5 capacidad que miente | **Cerrado**: misma expresión que la puerta; medido con `clearCachedDriver` y `withClock` |
| ⚪ 6 `driver().capabilities = {…}` reemplazable en `database` | **Abierto** (sin cambios). Ya no toca a `capabilities()`, que devuelve copia; sigue exigiendo `driver()`. Corrección mínima si algún día molesta: pasar `capabilities` a getter como en `openfga` |
| ⚪ 7 store huérfano | **Cerrado** para la creación; ver ⚪ N1 para `--store-id` |
| ⚪ 8 `run()` sin casos | **Cerrado con creces**: `tests/helpers/ace.ts` + `tests/commands.spec.ts` (kernel real) |
| ⚪ 9 `boot()` no-op silencioso | **Cerrado**: guardas por estado + mensaje y exit 1 (A-7) |

## Lo que intenté contra el lote y NO se rompió

- Envenenar `#driver` con `capabilities()` por las dos puertas, y comprobar después `driver()` **y** `authorize`.
- Hacer divergir la copia de la instancia que escribe (`clearCachedDriver()`, `config.clock`/`withClock`, dos
  lecturas seguidas, vista de `forRequest`).
- Mutar la copia (lanza), mutar el objeto del driver a través de ella (es copia), y colar `{ transaction }`
  después (sigue 500 en las dos puertas y en los dos drivers).
- Bootear la app con un flag inválido (ace valida antes: no bootea), con un provider que revienta en `boot()`
  (exit 1 limpio), y dos veces en el mismo proceso (idempotente).
- Pedirle al loader un comando ajeno y registrar el módulo de las dos formas (correcta: nueve comandos;
  workaround viejo: TypeError ruidoso).
- Importar `@adonisjs/core/ace` a pelo buscando efectos de proceso: ninguno.

## Preguntas abiertas

Ninguna que cambie el veredicto. La única decisión que dejaría por escrito antes de publicar es la de ⚪ N1
(¿se valida también en `--store-id`, o se declara a propósito que esa rama es "modelo tal cual, lo juzga el
servidor"?).
