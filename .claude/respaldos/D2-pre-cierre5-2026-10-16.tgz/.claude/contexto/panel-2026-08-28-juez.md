# Panel 28-08-2026 · Juez — veredicto sobre las exigencias de COGNITIV

> Entradas: `panel-2026-08-28-arquitectura.md`, `panel-2026-08-28-seguridad.md`, `panel-2026-08-28-tester.md`, `exigencias-cognitiv-2026-08-27.md`, `CLAUDE.md`.
> Verificaciones propias del juez (lectura directa, no razonamiento): `src/drivers/openfga_driver.ts:84-100` (scopeKey/parseBindingId), `:609-694` (listSubjects/listBindings/listScopes), `src/drivers/database_driver.ts:50-56,130-156,188-224`, `src/middleware/app_access_middleware.ts:57`, `src/testing/contract.ts:177-192`, `tests/contract.spec.ts:182-229`.

## Veredicto

**Recomendación: aprobar Fase 0 (2 d) + Fase 1 (6 d) hoy, sin condiciones y sin esperar a ninguna respuesta del dueño.** Son 8 días que cierran los cuatro fail-open reproducidos (L0.7, L0.3, L0.6, N1) y ponen el juez en condiciones de ver lo que hoy no ve. Todo lo demás (`catalog/`, `relations/`, `http/`, hooks) queda **condicionado** y en fases posteriores.

**El porqué decisivo:** de las tres posturas, la única que se sostiene sobre hechos ejecutados es que el paquete **hoy tiene un fail-open publicado** (`listScopes` devuelve como concedidos scopes con deny explícito: 1000/10030 medido por el auditor, y reproducido por el tester con `MAX_RESULTS=3` en 6 segundos) y **publica un PEP indenegable** (`appAccess({role})` → `hasRole`, verificado en `app_access_middleware.ts:57`). Ninguna feature nueva del documento COGNITIV compite con eso en prioridad.

**Con estos injertos de otras posturas:**
1. **L0.4 sin flag y sin romper el juez** (injerto del juez, nace de cruzar analista+tester): `undefined` preserva solo una caducidad **vigente**; sobre una asignación **ya expirada** el re-grant revive, que es lo que el código ya documenta (`database_driver.ts:150-151`). Verificados los tres tests que el tester daba por rotos: `contract.ts:177` y `contract.spec.ts:221` usan caducidad **pasada** → siguen verdes; `contract.spec.ts:182` usa `+60_000` → la aserción `authorize=true` **sigue siendo cierta**, solo hay que renombrarlo/reescribirlo con `expiresAt: null`. **Cero aserciones rotas ⇒ L0.4 deja de ser 2.0.**
2. **`authorizedScopes` con `{kind:'all', excludedSubtrees: ScopeRef[]}`** (cierra el 🔴 E1 del auditor conservando el valor que el analista defiende — no materializar el árbol).
3. **`Read` paginado** del analista sustituye a `continuation_token` en L0.7 (el mecanismo que pedían el documento *y* el auditor no existe en el SDK).
4. **Prefijo de partición también en el id del userset** (auditor B1) como mecanismo, y `assertWrite` degradado a segunda línea (auditor G3): la contención vive en el driver, no en el hook.
5. **Bloque de identidad/errores en el juez** (auditor) dentro de la Fase 0, no de la 1: es lo que hace observables las correcciones de la Fase 1.
6. **`sqlDescendantsOf` opt-in** (analista) y **`purgeScope` en `roles/`** (auditor N5): los dos únicos rechazos de III.2 que hay que reabrir.

**Condición para proceder:** ninguna para Fases 0–1. Para la Fase 3 en adelante hacen falta dos respuestas del dueño (¿segundo consumidor? y ¿se acepta migrar los ids de tuplas FGA a uuid de rol?), listadas al final.

---

## Tabla de decisión por ítem (la que se usa para aprobar fases)

| Ítem | Decisión | Versión | Cambio concreto exigido | Fase |
|---|---|---|---|---|
| **A** módulos opt-in | 🟡 con cambios | 1.2 (subpaths) / consolidación 1.4 | No mover `src/drivers/*` ni `src/manager.ts`; no tocar el export raíz. Regla de grafo de módulos en `check_purity.mjs` **y que `check:purity` corra en `npm test`**. Consolidar *después* del segundo módulo. | 5 |
| **B** `relations/` | 🟡 **NO tal cual** (🔴 B1) | 1.4 | (1) `ObjectRef`/`UsersetRef` llevan la partición en el id (`unit:<partitionKey>\|<uuid>#member`) y se rechaza por comparación de string, sin `scopeOf`; (2) `membersOf` sale del puerto común a las opciones del driver `database`; (3) purgas exhaustivas que **lanzan** si no demuestran cero (B2); (4) filtro de prefijo con delimitador `\|` o parseo por componentes (B3); (5) enumeración por `Read` paginado. Los dos spikes ❓ del documento **ya están resueltos** (analista, ejecutados). | 4 |
| **C** `catalog/` | ✅ con cambios | 1.3 (mayor operativo) | Binding id = `role_binding:<scopeKey>\|<roleUuid>` (**no** 4 partes: `parseBindingId` descarta 4 partes en silencio, verificado en `:91-100`) + comando de reescritura de hechos; resolución interna **siempre por uuid**; `effectivePermissions` resta denies **por definición** y `defineScopedRole` exige que el actor no tenga deny de los permisos que compone (C2); renombrar `createTenantRole`/`tenantAssignablePermissions` → `defineScopedRole`/`delegablePermissions`; `owner_scope_key='global'` reservado ⇒ throw si un scope real serializa a `global`. | 3 |
| **C-bug latente** `listSubjects` cruza tenants | ❌ **no existe hoy** | — | El documento se equivoca; analista y tester lo midieron. No es L0. Se escribe hoy como **pin de regresión**. | 1 |
| **D-L0.1** `whereScopeIn([])` | ✅ | 1.2 | Lista vacía: lectura ⇒ resultado vacío sin ir a BD; escritura ⇒ lanza. | 1 |
| **D-L0.2** `holderTypes` inyectivo | ✅ | 1.2 | Verificación en el **constructor** del driver (no "en boot"). Comparación con el modelo del store → comando `authz:openfga:verify`, no bloqueante. | 1 |
| **D-L0.3** scope desconocido | ✅ con el hueco del auditor cerrado | 1.2 (corrección de seguridad) | `ScopeAncestorsResolver → Promise<ScopeRef[] \| null>`; `null` ⇒ `authorize` false, `grant/deny/hasRole` throw. **Y el default plano deja de aplicarse**: si el catálogo contiene roles con `scope_type ≠ 'app'` y no hay resolutor ⇒ lanza en la primera llamada. Escape documentado como inseguro: `flatScopeFallback: true`. | 1 |
| **D-L0.4** semántica de `expiresAt` | ✅ **sin flag** | 1.2 | `undefined` preserva caducidad **vigente**; asignación **expirada** ⇒ revive. Caso nuevo en `level:'1.2'`; reescribir el nombre de `contract.spec.ts:182`. **Ninguna aserción existente se rompe (verificado).** | 1 |
| **D-L0.5** identidad validada | ✅ | 1.2 | `assertIdentityComponent` **en el manager**, status **422**, longitudes contra las columnas publicadas. Cierra `user:undefined`, el 400→503 disfrazado y la divergencia PG/SQLite. | 1 |
| **D-L0.6** `hasRole` no decide acceso | ✅ **retirada, no deprecación** | 1.2 (corrección de seguridad) | `appAccess({ role })` **lanza** (sin escape). Receta de migración en el CHANGELOG. Sobrecarga `hasRole(s, {slug, scopeType}, scope)` (hoy filtra solo por `r.slug`, `database_driver.ts:215`). Caso de contrato que **fija** que un deny NO afecta a `hasRole`. | 1 |
| **D-L0.7** truncamiento | ✅ **con otra corrección** | 1.2 | `Read` paginado en las **tres** enumeraciones (`listBindings`, denies de `listScopes`, `listSubjects` vía `listUsers`). `continuation_token` en `ListObjects` **no existe** (SDK `apiModel.d.ts:783-839`). `RelationsResultTruncatedError` solo para `relations/`. CI con 2.º OpenFGA `MAX_RESULTS=3` (con `=1` fallan 3 tests por otra causa). Caso del **falso positivo**. | 0+1 |
| **D-L0.8** modelos read-only | 🟡 **se parte** | 1.2 / diferido | (a) ✅ `assertValidSlug` en los drivers en `grant/deny/revoke/removeDeny` y en la lectura de bindings — mitigación real del exploit (`removeDeny('docs~read')` levanta el deny de `docs:read`). (b) ❌ modelos "solo lectura" como mecanismo: `db.from(...)` sigue abierto. Documentación + caso openfga de "asignación fantasma". | 1 / 6 |
| **L0.9 (N1)** el sync nunca retira vínculos | ✅ **entra a L0** | 1.2 opt-in / 2.0 default | `syncAuthzCatalog(catalog, { prune: 'links' })` transaccional + `authz:catalog:diff` que falla en CI + `configure` lo cablea por defecto. | 1 |
| **L0.10 (N2/BORDE-app-uuid)** `{app, uuid}` | ✅ **entra a L0** | 1.2 | `{type:'app', uuid !== null}` ⇒ **422 en ambos drivers**. Hoy `openfga` lo colapsa a la raíz y `database` lo trata como scope distinto. | 1 |
| **L0.11 (N3)** caída del catálogo SQL | ✅ **entra a L0** | 1.2 | Envolver las consultas de catálogo de **ambos** drivers ⇒ `AuthorizationBackendError` (503). Hoy sale `SqliteError` sin status. | 1 |
| **L0.12 (N4)** `revoke` no-op silencioso | ➡️ se cierra con **C** | 1.3 | Desaparece al resolver siempre por uuid de rol. | 3 |
| **L0.13 (N6)** sin deadline | ✅ **entra a L0** | 1.2 | `timeout` configurable + caso "backend que no responde en N ms ⇒ 503". Hoy `authorize` se **cuelga**. | 1 |
| **L0.14 (N7)** `batchCheckAll` correlaciona por orden | ✅ **entra a L0**, **antes de E** | 1.2 | Correlacionar por `correlation_id`, no por posición. | 1 |
| **L0.15 (BORDE-centinela)** uuid nil en tipo ≠ app | ✅ (bajo) | 1.2 | Rechazar en el manager. | 1 |
| **L0.16** `parseBindingId` descarta en silencio | ✅ (bajo) | 1.2 | Un id no parseable se **registra y cuenta**, no `continue` mudo (`:686`). Prerrequisito de C. | 1 |
| **E** `within`/`isWithin` | ✅ | 1.2 aditivo / `requireWithin:true` en 2.0 | Default `false` + aviso en boot listando los tipos de scope sin contención. | 2 |
| **E** `authorizedScopes` | ✅ **redefinida** | 1.2 | `{kind:'none'}` \| `{kind:'some', scopes}` \| `{kind:'all', excludedSubtrees}`. **Nunca `all` con denies vivos.** Sin `descendantsOf` o con `maxScopes` superado ⇒ **lanza**. Excepción explícita al invariante 7 en `CLAUDE.md`. | 2 |
| **E** `descendantsOf` + `sqlDescendantsOf` | ✅ (reabre un rechazo de III.2) | 1.2 | Helper opt-in que **genera** la CTE; por dialecto o throw. Prohibido dentro de `authorize`/`listScopes`. | 2 |
| **E** `hierarchicalScopeResolver` | ✅ | 1.2 | Anti-ciclos, `maxDepth:64` que **lanza**. | 2 |
| **E** `memoizeAncestors` | 🟡 con cambios | 1.2 | Sin TTL de reloj: memo de una llamada, instanciado por request por el consumidor. **Solo camino de lectura**. | 2 |
| **E** `effectivePermissions` | ✅ | 1.2 | Composición sobre el puerto y **resta denies por definición**. Prerrequisito de C. | 2 |
| **E** `authorizeMany` | ✅ | 1.2 | Composición + `authorizeMany?()` opcional en el driver. **Después de L0.14.** | 2 |
| **E** `listDenies` | 🟡 diferido | 1.3 | Método nuevo del puerto. | 6 |
| **E** `purgeScope(scope)` en `roles/` | ✅ (injerto auditor N5) | 1.3 | Hoy borrar un tenant deja grants y denies vivos para siempre. | 3 |
| **F** `http/` | ➡️ **al consumidor hoy**; 🟡 al paquete si hay 2.º consumidor | 1.4 condicional | Si entra: `containerParam`, `load` inline, `gate` con contrato de error estricto, 404-contenedor y 404-recurso indistinguibles, `AuthorizationBackendError` nunca disfrazado, **prohibido aceptar `role`**. | 6 |
| **G** `actor` + `requireActor` | ✅ | 1.2 | Explícito en `GrantOptions`, nunca `AsyncLocalStorage`. | 2 |
| **G** `assertWrite` | ✅ con cambios | 1.3 | En el **manager**, puro, sin I/O, solo puede lanzar. Segunda línea, no mecanismo de contención. Obligatorio en `relations/`, opcional en `roles/`. | 6 |
| **G** `{trx}` + `onWriteInTrx` | 🟡 con cambios, **bloqueado por infra** | 1.3 | El tipo del puerto acepta `{trx}` en todos los drivers; el config declara `requireTransactionalWrites`; el **manager falla al construirse** si el driver no la soporta; `openfga` en runtime lanza error del paquete. **No se mergea sin harness de pool ≥ 2.** | 2.5 + 6 |
| **G1** outbox `pdp_version` | ➡️ consumidor | — | "INCR antes **y** después siempre"; clasificar por dirección semántica. | — |
| **H** `assignableAt` | ✅ | 1.3 | Control de **composición**, jamás barrera de evaluación. | 3 |
| **H** `authz:catalog:diff` | ✅ **con L0.9** | 1.2 | Solo vale acompañado del `prune`. | 1 |
| **I** rechazos III.2 | ✅ 7 de 9 tal cual | — | Se reabren dos: `sqlDescendantsOf` y `purgeScope`. Dos nominales resueltos arriba. | — |
| **Juez `level`/`capabilities`** | ✅ **camino crítico** | 1.2 | `level: 'core'\|'1.2'\|'1.3'` + `capabilities` + **toda capacidad `false` obliga a un caso negativo, nunca un `skip`** + **bloque de identidad/errores en el núcleo**. Sin esto, todo lo anterior es 2.0. | 0 |

---

## Tabla de puntuación (solo donde había posturas enfrentadas)

Criterios y pesos: Seguridad 30 · Compatibilidad de contrato 25 · Verificabilidad 20 · Coste/deuda 15 · Reversibilidad 10.

**Cruce 3 · L0.4 (`expiresAt`)**

| Opción | Seg | Contr | Verif | Coste | Rev | **Total** |
|---|---|---|---|---|---|---|
| A · 1.2 con flag `expiryMode`, flip en 2.0 (analista) | 6 | 8 | 7 | 5 | 8 | **6,8** |
| B · 2.0, romper y reescribir 3 casos (auditor/tester) | 9 | 3 | 9 | 4 | 3 | **6,0** |
| **C · Injerto del juez: `undefined` preserva solo lo vigente; expirado revive** | **9** | **9** | **9** | **9** | **8** | **8,9** |

**Cruce 2 · L0.6 (`appAccess({role})`)**

| Opción | Seg | Contr | Verif | Coste | Rev | **Total** |
|---|---|---|---|---|---|---|
| A · Documentar + deprecar en 1.2, retirar en 2.0 | 2 | 9 | 8 | 9 | 9 | **6,1** |
| **B · Retirar en 1.2 (lanza), receta de migración** | **10** | 5 | 8 | 7 | 6 | **7,7** |

El 🔴 no mitigado descalifica A.

**Cruce 1 · L0.7 (mecanismo)**

| Opción | Seg | Contr | Verif | Coste | Rev | **Total** |
|---|---|---|---|---|---|---|
| A · `continuation_token` en `ListObjects` (doc + auditor) | 0 | 0 | 0 | 0 | 0 | **0** (no existe en el SDK) |
| B · `streamedListObjects` + error por cantidad | 6 | 7 | 6 | 7 | 7 | **6,5** |
| **C · `Read` paginado en las 3 enumeraciones** (analista) | **9** | **8** | **9** | 6 | 8 | **8,2** |

**Cruce 4 · B1 (partición del userset)**

| Opción | Seg | Contr | Verif | Coste | Rev | **Total** |
|---|---|---|---|---|---|---|
| A · B tal cual, `assertObjectInPartition` cubre | 0 | 6 | 3 | 9 | 5 | **3,9** (🔴 sin mitigar) |
| B · `assertSubjectInPartition` del consumidor | 6 | 3 | 6 | 6 | 4 | **5,1** (reabre `scopeOf`) |
| **C · Partición en el id del userset, comparación de string** | **9** | **9** | **9** | 7 | 8 | **8,6** |

**Cruce 5 · E1 (`authorizedScopes` × deny)**

| Opción | Seg | Contr | Verif | Coste | Rev | **Total** |
|---|---|---|---|---|---|---|
| A · `all` tal cual (documento) | 0 | 4 | 6 | 10 | 8 | **4,1** (🔴) |
| B · Con ≥1 deny, degradar a `some` o lanzar (auditor) | 9 | 8 | 8 | 4 | 7 | **7,7** |
| **C · `{kind:'all', excludedSubtrees}`; sin `descendantsOf` ⇒ lanza** | **9** | **9** | **8** | **7** | 8 | **8,3** |

---

## Conflictos entre panelistas — resolución

1. **L0.7, mecanismo.** Gana el analista (verificó en SDK y servidor). Objetivo del auditor se cumple mejor con `Read`. CI: `MAX_RESULTS=3`. Aplica también a `listSubjects` y purgas de `relations/`.
2. **L0.6, alcance.** Gana el auditor. Retirada en 1.2.
3. **L0.4, versión.** Los tres se equivocan a medias; injerto del juez: 1.2, sin flag.
4. **B, aceptabilidad.** No entra tal cual; entra con cinco condiciones. `membersOf` es hueco de diseño de puerto.
5. **E1.** Primitiva entra redefinida. Nunca `all` con denies vivos.
6. **C, binding id.** Gana el analista (confirmado: `parseBindingId` parsea por conteo). "Bug latente de `listSubjects`" no existe hoy ⇒ fuera de L0.
7. **Capacidades/`level`.** Sí, Fase 0, con el bloque de identidad/errores del auditor dentro.
8. **`{trx}`.** Vía del analista reforzada; bloqueado por harness de pool ≥ 2.
9. **F `http/`.** Condicional: sin segundo consumidor ⇒ COGNITIV; con él ⇒ 1.4.
10. **Hallazgos nuevos.** Entran a L0: N1, N3, N6, N2/BORDE-app-uuid, N7, BORDE-centinela, `parseBindingId` mudo. No entran: deny-condition-sin-context (precondición de 1.3), G-trx (infra), `check_purity` (Fase 0).
11. **Estimación.** Ver Fases.
12. **8 preguntas.** Abajo.

---

## Fases, camino crítico y número

| Fase | Contenido | Días | Bloquea a |
|---|---|---|---|
| **0 · Desbloqueo** (sin condiciones) | `level` + `capabilities` + regla "capacidad false ⇒ caso negativo"; bloque de identidad/errores en el núcleo; 2.º OpenFGA `MAX_RESULTS=3`; harness de resolutor de ancestros; espías de backend; `check:purity` en el job `test` | **2,0** | todo |
| **1 · L0 = lote de seguridad (1.2)** | L0.1–L0.7 + L0.8(a) + L0.9–L0.16, con sus casos rojo→verde | **6,0** | README honesto, C, E |
| **2 · Primitivas de motor (1.2)** | `within`/`isWithin`, `effectivePermissions`, `authorizeMany`, `authorizedScopes` + `descendantsOf` + `sqlDescendantsOf`, `hierarchicalScopeResolver`, `memoizeAncestors`, `actor`/`requireActor` | **3,5** | C |
| **2.5 · Infra restante** | Reloj inyectable (0,5) + harness multi-motor con pool ≥ 2 (1,0) | **1,5** | G, caducidades de C y B |
| **3 · `catalog/` (1.3)** | `owner_scope_key`, resolución por owner, **binding id por uuid** + migración de hechos, `purgeRole`, `purgeScope`, `defineScopedRole`, `assignableAt`, exportar `assertValidSlug` (422) | **4,5** | — |
| **4 · `relations/` (1.4)** | Puerto + modelo + drivers + ~34 casos (18 núcleo / 12 anexo / 4 negativos) + tablas ficticias + `assertWrite` | **10,5** | — |
| **5 · Consolidación** | Módulos, `configure` interactivo, stubs/migraciones separadas, README + upgrade | **2,5** | — |
| **6 · Diferido / condicional** | `{trx}`+`onWriteInTrx` (2,0), `http/` (1,5 si hay 2.º consumidor), `listDenies`, deny con caducidad, `from`, modelos read-only | — | — |

- **Mínimo que cierra todo lo reproducido: Fases 0+1 = 8 d**, lo único incondicional.
- **Sin `relations/`**: **20 d**. **Con todo menos G y `http/`**: **30,5 d**. **Con G**: **32,5 d**. ⇒ **30–33 d**.
- **Camino crítico: Fase 0.** Sin `level`, cada caso nuevo del juez es un major.
- **Orden invertido respecto al documento**: reestructuración **después** del segundo módulo. Spikes FGA ya hechos.

---

## Las 8 preguntas de III.6 — respuesta recomendada al dueño

| # | Respuesta en una línea | ¿Contestada por evidencia? |
|---|---|---|
| 1 | **Asume que NO habrá segundo consumidor**: solo cambia `http/` (fuera, −1,5 d); L0, L1 y `catalog/` se hacen igual. | ❌ **Sigue siendo tuya** |
| 2 | **1.2 no es breaking de API, pero lleva dos correcciones de seguridad con impacto**: retirada de `appAccess({role})` y default estricto de resolutor (escape `flatScopeFallback`); L0.4 deja de ser breaking. | ✅ casi entera |
| 3 | **`string` validado por gramática y longitud**, stub nuevo `varchar(64)`, validación en el manager; **dejar de anunciar MySQL/SQLite** hasta tener contrato por motor. | ✅ |
| 4 | **Un solo juez, con capacidades declaradas y casos negativos obligatorios** — nunca bifurcado, nunca `skip`. | ✅ |
| 5 | **Sí, con `MAX_RESULTS=3`** (no 1), datastore `memory`, ~15 líneas de CI, 0,25 d. | ✅ medido |
| 6 | **Obligatorio en `relations/`**, **opcional en `roles/`**, siempre segunda línea. | ✅ |
| 7 | **Sí, cinco cosas**: README:36, :38, :114, :146, :164 + omisión del truncamiento. **No tocar el README antes de la Fase 1.** | ✅ |
| 8 | **No**: `grantableAt` en la evaluación rompe el invariante 1. Se cubre con `assignableAt` + `delegablePermissions`. | ✅ |

---

## Afirmaciones descartadas por falta de evidencia

- **Documento (§4)**: "`listSubjects` cruza tenants por slug" — **falso hoy** (medido). Fuera de L0.
- **Documento (§1, §7)**: "dos spikes FGA antes de `relations/`" — **ya resueltos** por ejecución.
- **Documento + auditor (L0.7)**: "`continuation_token` en `ListObjects`" — no existe.
- **Documento (L0.5)**: "`uuid` con `#` → userset accidental" — no ocurre hoy; sí con `relations/`.
- **Analista (A)**: "575 descargas ⇒ hay consumidores" — dato verificado, inferencia no.
- **Auditor (B2, C2, C3, E1–E3, F1–F3, G1)**: 🟡 diseño; riesgos a cerrar en la especificación, no defectos presentes.
- **Tester (§3)**: "~3 d de infra antes de `relations/`" — orden de magnitud, dentro de la Fase 4.

---

## Riesgos que quedan aunque se apruebe esto

1. `requireWithin: false` en 1.2 es seguridad opt-in (se cierra en 2.0).
2. `flatScopeFallback` existe; un consumidor puede reabrir L0.3.
3. `Read` no expande relaciones computadas — declararlo.
4. Deadline de 3 s de OpenFGA sin señal; sigue vivo en `relations/`.
5. `db.from('authz_assignments')` sigue abierto.
6. Cero cobertura de PostgreSQL y MySQL hasta la Fase 2.5.
7. C es major operativo (índice único + reescritura de ids FGA).
8. `relations/` duplica la superficie de test para un único consumidor.
9. Deny con caducidad (1.3) llega con bomba: `openfga_driver.ts:441-445` y `:670-674` consultan denies sin `context` ⇒ 400 → 503.

---

## Lo que preguntaría al humano antes de implementar

Ninguna bloquea las Fases 0–1:

1. **¿Habrá un segundo consumidor real del paquete en ~6 meses?** Decide `http/` y si `relations/` se diseña contra dos casos.
2. **¿Aceptas migrar los ids de las tuplas FGA a `role_binding:<scopeKey>|<roleUuid>`** (+0,5 d de comando)? Sin eso, `catalog/` no se recomienda.
3. **¿Aceptas que 1.2 retire `appAccess({ role })` sin escape?** Si no, D-L0.6 se queda en 🔴.

---

## Lo que se puede hacer HOY sin decidir nada

**Casos de test escribibles ya** (< 1 día):

1. **L0.2** — `holderTypes: {users:'user', admins:'user'}` funde holders (OpenFGA `:8101`).
2. **L0.5** — paridad de validación de identidad + "error semántico no es 503".
3. **L0.6** — deny no gobierna `hasRole`; `appAccess({role})` deja pasar.
4. **Invariante 8** — `rank` no se evalúa en `authorize` (único invariante sin cobertura).
5. **L0.9 / N1** — quitar `docs:write` del rol, re-sync, `authorize` sigue true.
6. **BORDE-app-uuid** — `{type:'app', uuid:'X'}`: openfga true / database false.
7. **Pin de regresión de C** — `listSubjects('org-admin', orgA)` no incluye orgB.

**Defectos corregibles sin depender de decisiones** (aditivos):

- `check:purity` en `npm test` y en el job `test`.
- Segundo OpenFGA de CI con `MAX_RESULTS=3`.
- L0.2 inyectividad de `holderTypes` en el constructor.
- L0.14 / N7 correlación de `batchCheckAll` por `correlation_id`.
- L0.16 `parseBindingId` que registra los ids no parseables.
- L0.11 / N3 catálogo caído ⇒ `AuthorizationBackendError`.
- L0.1 guarda de lista vacía en `whereScopeIn`.
- L0.8(a) `assertValidSlug` en los drivers en escrituras.
- Exportar `assertValidSlug` con status 422.

Ambas listas ≈ **1,5 días**; son estrictamente ganancia.
