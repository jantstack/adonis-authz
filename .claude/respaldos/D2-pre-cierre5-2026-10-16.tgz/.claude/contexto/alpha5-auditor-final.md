# `2.4.0-alpha.5` — AUDITOR, pasada FINAL sobre el lote de CIERRE

Base: árbol I + II + cierre (sin commitear). Contraste: los dos 🟠 de
`alpha5-auditor.md`. Medido con **PostgreSQL 18**, **MySQL 8.4** y el
**`:8101`**. Reproducciones: `.claude/reproducciones/relay-auditor-{1,2,5,6,7,8,9,10,10b,11}.ts`
(logs `$S/c_*.log`).

## Veredicto: **APTA**

Los dos 🟠 están **cerrados y medidos**, y el cierre no reabre nada de lo que
ya di por bueno (`only`/sonda, `requeue`, freeze, `GET_LOCK`, `maxDepth`,
contrato: re-ejecutados, idénticos). Los ataques nuevos al ORIGEN del bloqueo
—cadena mixta, dos claves, huérfano— **no rompieron**. Queda un 🟡 nuevo
(el `detached` bajo `only`), un 🟡 operativo sobre la cota y un ⚪ de tabla;
ninguno reabre.

---

## 1 · Los dos 🟠, cerrados

### 🟠 1 — el `detached` a un salto de una aparcada ⇒ **CERRADO**

`relay-auditor-7.ts`, pasada COMPLETA, las dos ramas:

```
[G] SIN un attached pendiente entre medias: detached ⇒ applied/   ¿purgó?: purge unit:52da
[G] CON un attached pendiente entre medias: detached ⇒ applied/   ¿purgó?: purge unit:ed08
```

(antes: `deferred/depends-on:4` en las dos pasadas y «¿purgó?: NO»). Y sigue
cerrado el 🟠 4 original: `relay-auditor-1.ts` ⇒ `[B] tras recuperarse el
store, aplicados: —` · «hijo aplicado=false, moved aplicado=false: el tapón
por clave lo retiene» (corregí de paso la heurística de esa repro, que
truncaba los uuid a 8 caracteres y con `uuidv7` colisionaba: era un falso «SÍ»
en el log, no en el comportamiento).

### 🟠 2 — censo acotado por `limit` ⇒ **CERRADO**

`relay-auditor-9.ts` (101 aparcadas, `{ only, limit: 1 }`):
`⇒ deferred/parked:101 · llamadas al driver: —` (antes: `applied` y la arista
colgada del padre viejo). Censo completo verificado end-to-end con filas
REALES en `relay-auditor-11.ts` (hasta 50 000).

---

## 2 · Ataques al ORIGEN del bloqueo — ninguno rompió

| Ataque | Resultado | Evidencia |
|---|---|---|
| (a) negativo puro: `attached` que FALLA ⇒ `detached` de esa clave | **se aplaza** (`depends-on:#1`), cero llamadas | 10b [J1] |
| (a) mixto: aparcado → aplazado-por-aparcado → `detached` que FALLA de verdad → segundo `detached` de la MISMA clave | el fallo **pisa** al aparcado: `deferred/depends-on:#3` | 10b [J2] |
| (b) dos claves del mismo cambio (`moved` ⇒ hijo + padre nuevo) | el origen viaja a las DOS con el tipo correcto: `detached` de la clave limpia y `detached` de la clave que heredó origen APARCADO ⇒ los dos `applied`; el ascenso a fallo es **por clave**, no por entrada | 10 [K], 10b [J2] |
| (c) `detached` por encima de un `attached` aplazado-por-aparcado | el `attached` **no** se aparca, **no** cuenta intento y **no** hay bucle: al arreglar la aparcada se **aplica** (`applied`, `attempts=0`) | 10 [L] |

Sobre (c), lo que queda dicho y no es un hallazgo nuevo del lote: ese
`attached` escribe la arista de un scope **ya purgado y borrado en SQL**
(medido: `purge child | detached child | … | attached child→unit`). No es
fail-open —los hechos del nodo se purgaron y no resucitan (invariante 11), y
`grant` sobre él es 422 `E_AUTHZ_UNKNOWN_SCOPE`—: es **deriva**, la que
`authz:reconcile` limpia, y existía igual en alpha.4 (una entrada cuyo HIJO
desapareció siempre se aplicó; la irreparable de 3b-2h es la que pierde el
PADRE, que sí falla con 422).

---

## 3 · Hallazgos nuevos (ninguno reabre)

### 🟡 A — bajo `only`, la exención del `detached` NO se aplica

- **Escenario**: aparcada `#1 moved(unit → o2)`; pendiente `#2 attached(child, unit)`;
  el consumidor releva su borrado con la receta inline:
  `relayScopeChanges({ only: [#4 detached(unit)] })`. Resultado: **`deferred/depends-on:#2`**,
  la purga no ocurre. En una pasada COMPLETA sí ocurre (🟠 1, arriba).
- **Causa**: la rama de la sonda marca su aplazamiento como origen FALLO
  (`manager.ts:1252-1259`, `defer(…, false)`) porque desde ahí no se sabe si la
  pendiente anterior está a su vez retenida por un aparcado. Conservador, y
  por eso no es 🟠: **no pierde la purga, la aplaza hasta la siguiente pasada
  completa**. El riesgo real es un despliegue que **solo** releva inline con
  `only` y nunca corre el supervisor: ahí la purga no llega nunca, que es la
  forma del 🟠 1 con otra precondición.
- **Evidencia**: ✅ medido antes y después del cierre, idéntico (repro 6 [B],
  cuarta línea: `only:[#4 detached(unit)] ⇒ deferred/depends-on:10`).
- **Steelman**: «el relay está pensado para un supervisor; el inline es para
  acortar la ventana, no para sustituirlo, y `remaining` es global». → Me
  convence como severidad, no como silencio: el README explica la exención del
  `detached` sin decir que necesita la pasada completa.
- **Mitigación mínima**: una frase en el párrafo del tapón («bajo `only` la
  exención no aplica: la purga espera a una pasada completa»), o que la sonda
  herede el origen consultando `parkedKeys` con las claves de la anterior.

### 🟡 B — la cota es un freno de plataforma que un tenant puede alcanzar, y el remedio escrito no baja el contador

- **Medido** (`relay-auditor-11.ts`, filas reales en PG):

  | aparcadas | pasada inline (`only`, 1 entrada) |
  |---|---|
  | 0 | 18 ms |
  | 1 000 | 16 ms |
  | 10 000 | 69 ms |
  | 49 000 | **199 ms** |
  | 50 000 | **500 `E_AUTHZ_CONFIG`**, 0 escrituras |

  El censo se rehace **en cada pasada**, así que hasta la cota es un impuesto
  de coste (×11 a 49 000) que paga **cada petición de cada tenant** y que se
  cobra **bajo el lease** (el relay es escritor único: también estrangula el
  caudal). En la cota, la pasada COMPLETA —la del cron— también es 500: **el
  relay de todos los tenants queda parado**, fail-closed, con la cola
  fail-open de siempre (los `moved`/`detached` que no aterrizan conservan el
  acceso viejo).
- **¿Lo puede provocar un tenant?** Sí, en teoría: un 503 ya no gasta intentos,
  así que necesita fallos de la NATURALEZA de la entrada (p. ej. `attached(X, P)`
  con `P` borrado antes del relevo ⇒ 422, que cuenta), y eso lo controla él.
  Son 50 000 escrituras de árbol y 5 pasadas por entrada.
- **Por qué 🟡 y no 🟠** (calibración honesta): es **fail-closed**, es
  **ruidoso desde la primera aparcada** (`dead` + exit ≠ 0 en cada pasada), y
  **se sale con un comando**: medido, reencolar UNA (49 999 < 50 000) devuelve
  el relay a la vida. La cota es además la mitigación que yo mismo pedí; sin
  ella el fallo era silencioso y fail-open.
- **Lo que sí falta es el remedio**: el mensaje dice «Mira `dead()`, **reencola
  o reconcilia**», y (i) `authz:reconcile` **no toca la outbox** (nada marca lo
  aparcado: el contador no baja), (ii) `requeue` no tiene `--all` a propósito y
  una entrada irreparable reencolada vuelve a aparcarse en UNA pasada (noria),
  y (iii) no hay comando de purga/expiración de la cola. El remedio real es
  SQL sobre la tabla del consumidor —legítimo, es suya— pero **no está escrito**.
- **Mitigación mínima**: decir en el mensaje y en el README que, pasada la
  cota, lo que corresponde es borrar/marcar las filas aparcadas de tu tabla
  (con `authz:reconcile --to=<driver>` DESPUÉS para recalcular el árbol).

### ⚪ C — `PARKED_CENSUS_MAX` no está en la tabla `### Limits`

Es una cota **exportada** cuyo rebase es un 500 que para el relay de todo el
despliegue, y la tabla dice de sí misma «every bound the package enforces… in
one place» con la suite atando las constantes. Está en el párrafo del tapón,
no en la tabla. Una fila.

---

## 4 · ¿El cierre reabre algo dado por bueno? — No (re-ejecutado)

| Pieza | Comprobación | Resultado |
|---|---|---|
| `only` + sonda (una y dos pendientes) | repro 6 [B]/[C] | idéntico a la pasada anterior (`parked:9`, `depends-on:10`, cero llamadas) |
| `requeue`, las dos puertas + `--force` + `maxAttempts − 1` | repro 6 [A]/[A2] | idéntico (500 `E_AUTHZ_REQUEUE_REFUSED`, `conflicts=1`, diff 3/3, `attempts=4`) |
| Freeze | repro 6 [D] | `requeue` entra sin barrera (declarado), relay inline **503 `E_AUTHZ_FROZEN`, 0 escrituras** |
| `maxDepth` (encolado, `driver()`, PARCIAL) | repro 6 [E] + repro 7 [H] | idéntico (422 antes de encolar; PARCIAL medido: hoja a 5 con techo 4) |
| Terceros sin recibo / que ignoran `{ ids }` | repro 6 [F] | 500 `E_AUTHZ_CONFIG` en las dos puertas |
| `GET_LOCK` en transición | repro 8 re-ejecutada contra MySQL 8.4 | se excluyen en los dos sentidos, sin fuga del lock nuevo |
| Reversión del `requeue` (control) | repro 5 | «sin reversión», converge en orgC |
| Deber del puerto (🟡 3 anterior) | `types.ts` docblock + README («`pending()` must return the whole unapplied queue, oldest first») + caso **O-08** del contrato (su mutante 12: 10 rojos) | cerrado en lo que se puede cerrar: `relay-auditor-2.ts` **sigue escalando** porque su doble esconde filas — ahora eso es una violación **escrita y juzgada** del puerto, no un hueco del paquete |

## 5 · Lo que sigue abierto y declarado (sin cambio, no reabre)

🟡 requeue después de un `reconcile` (la sonda solo ve la outbox) — cerrado por
letra, como se decidió. 🟡 un 503 eterno no converge y tapona su clave. ⚪
`maxDepth` PARCIAL. ⚪ `only` con ids ajenos aplica y enseña lo ajeno (en
orden). Ninguno es 🔴/🟠 y los cuatro están escritos.
