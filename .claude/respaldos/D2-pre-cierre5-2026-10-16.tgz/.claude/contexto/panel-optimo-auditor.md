# Panel «paquete óptimo»: auditor adversarial (2026-10-16)

Árbol: `main` sobre `75353fe`, con D2 y los cierres 1 a 4 sin commit.

**Qué se tocó**
- Solo lectura sobre el repo. Escritos: este informe y cinco scripts en `.claude/reproducciones/panel-optimo-auditor-*.ts`.
- OpenFGA v1.19.0 en `:8090`:
  - Stores efímeros `aud-opt-*`.
  - Comprobado al terminar: **0 residuales**.
  - Sin docker restart y sin gates.
- SQLite `:memory:` para los drivers del paquete.

```
source ~/.config/nvm/nvm.sh && nvm use 22
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-auditor-slots.ts         # S1–S14 (modelo mínimo a mano, HTTP crudo)
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-auditor-slots-depth.ts   # coste de la ranura en profundidad
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-auditor-nesting.ts        # R1: deny por anidación profunda (drivers del paquete)
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-auditor-nesting-allow.ts  # R1: allow por anidación profunda
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/panel-optimo-auditor-model-drift.ts    # R2: modelo fijado vs config en tipo sin deny
```

## Veredicto en una línea

**«Make-before-break» con dos ranuras: viable y mide bien, pero inseguro tal cual.**
- **Lo que mide bien:**
  - El swap atómico entra: `write(alt)` y `delete(main)` en un solo `Write` dan 200.
  - Es un compare-and-set de existencia: de 20 swaps concurrentes gana 1.
- **Lo que abre: una familia nueva, la de las N ranuras vivas.**
  - La invariante «≤ 1 ranura» **no se puede imponer en un `Write` de FGA**: la rompe un creador con una lectura rancia, y está medido.
  - Con dos ranuras vivas, cualquier lector o borrador de UNA clave es fail-open.
- **Lo que hay que hacer estructural:**
  - «Todo lector y todo borrador conoce las N ranuras».
  - La publicación en dos fases.
- **La premisa «desaparece la familia entera» es falsa en el orden:** las renovaciones que acortan siguen siendo pasos de una transición multi-tupla también en un destino atómico.

**Fuera de D2:**
- 🟠 El modelo fijado puede contradecir la config **sin error** en los tipos sin deny.
- 🟡 La anidación de grupos no tiene cota (el gemelo de `scopes.maxDepth` no existe).
- 🟡 Un 4xx determinista del servidor se vende como «el backend no respondió» (503).

---

## Parte 1: el diseño de dos ranuras (`rel` / `rel_alt`, `rel = this or rel_alt …`)

### Mediciones

Script `panel-optimo-auditor-slots.ts`, modelo mínimo:
- `group.member = this or member_alt`
- `document.viewer = (this or viewer_alt) but not denied_viewer`
- `denied_viewer = this or denied_viewer_alt`
- Condición `not_expired`.

| # | Qué | Resultado |
|---|---|---|
| S1 | `write member_alt(48 h)` + `delete member(1 h)` en un `Write` | **200**; queda solo `member_alt`; `check member` a +2 h = `true`. Sin ventana. |
| S2 | El mismo swap repetido con una lectura rancia | **400** «cannot delete a tuple which does not exist». Con un write libre y un delete ausente, el `Write` ENTERO se rechaza (`member` no se escribe). **Todo o nada.** |
| S3 | Borrar por clave sin condición una tupla CON condición | **200**, borrada. El CAS compara existencia y no caducidad (ABA posible; gana el último escritor, como hoy). |
| S4 | A crea `member(1 h)`; C renueva a `member_alt(48 h)`; B, que leyó «no hay», crea `member(1 h)` | **200 ⇒ las DOS ranuras vivas** (`member` 1 h y `member_alt` 48 h). |
| S5 | Con S4, un `unrelate` que borra solo la ranura que conoce | `check viewer` **true** ahora y a +2 h: **la revocación no revoca.** |
| S6 | Con S4, acortar escribiendo `member` | **400** (ocupada); `check viewer` a +2 h = **true**: el acortamiento no se puede expresar. |
| S7 | Membresía que transporta un deny, renovada a `member_alt`; Check con el modelo VIEJO (sin ranuras) | Modelo nuevo **false**. Modelo viejo **TRUE**. Check sin `authorization_model_id` (el último publicado es el viejo) **TRUE**. |
| S8 | Escribir `member_alt` contra el `modelId` viejo | **400** `validation_error` «relation 'group#member_alt' not found». |
| S9 | Deny a `group:h#member_alt` como userset | Con un modelo que no lo admite: **400** (barrera estructural del servidor). Con uno que sí: U∈H por `member`, el deny solo por `#member_alt` ⇒ `check` **TRUE** (deny parcial). |
| S10/S4 | `Read {user, object}` sin relación | Devuelve **las dos ranuras** en una llamada (sirve para releer). |
| S11 | 20 swaps concurrentes desde la misma lectura | **1 × 200 y 19 × 400** «cannot delete…»; final: una sola ranura. |
| S12 | Relación de dominio `viewer_alt` junto a `viewer` | El generador produce `viewer`, `denied_viewer`, `viewer_alt` y `denied_viewer_alt`: **colisión de nombres**. |
| S13 | Deny con caducidad en las dos ranuras (1 h y 48 h); `removeDeny` de la principal | A +2 h niega (la unión es más restrictiva: fail-closed). Tras borrar una ranura **sigue negando**. |
| S14 | Reparar dos ranuras de una membresía portadora | Borrar primero la LARGA: `check` a +2 h = **TRUE** (ventana). Borrar primero la CORTA (la dominada) y luego hacer el swap: false/false en todos los pasos. |
| depth | Anidación de grupos que resuelve | Hoy **25** (26 ⇒ 400 `authorization_model_resolution_too_complex`); con ranuras **24**. La ranura cuesta un nivel. |
| bytes | Modelo con 100 permisos y 3 tipos de relación × 3 relaciones (dos con deny) | 57 851 → **61 258 B** (+5,9 %), muy lejos del techo de 262 144. |

### Hallazgos

#### 🟠 MB-1 · «≤ 1 ranura» no es imponible en FGA: un creador rancio deja dos ranuras vivas, y un lector o borrador de una clave es fail-open

**Escenario**
- **Precondición:** `relate(U, member, G)` concurrente con una renovación de la misma tupla.
- **Acción:** el creador, con «no existe» leído antes de la renovación, escribe `member`. La ranura principal está libre porque la renovación la vació.
- **Resultado:**
  - Dos ranuras vivas (S4).
  - Un `unrelate` que borre la clave que conoce deja `viewer` concediendo (S5).
  - Un acortamiento choca y la caducidad larga sigue mandando (S6).

**Evidencia:** ✅ medido (S4–S6).
- FGA solo puede afirmar «no existe» escribiendo esa misma clave: no hay `Write` que afirme la ausencia de `member_alt` mientras escribe `member`.
- El precedente es `reparent` de roles (`openfga_driver.ts:1755-1830`): el mismo swap, y ahí también sobreviven dos aristas con dos escritores a padres distintos. Lo resuelve el ESCRITOR ÚNICO del relay y lo denuncia `assertOneParent`.
- En relaciones no hay escritor único.

**Steelman del defensor:** «Basta con borrar siempre las dos ranuras y leer con `Read {user, object}`».
- **¿Me convence?** Sí, y es exactamente la invariante que pido.
- Pero hoy hay al menos tres lecturas con filtro de relación (`openfga_relations_driver.ts:759` en `#carriedDeny`, `:1057` en `listDenies`, `:1168` en `listSubjects`) y dos borrados de una clave (`unrelate` `:823`, `removeDeny` `:880`). Cada uno es un sitio donde el defecto vuelve. Es el patrón de L1 antes del lote 0.

**Mitigación mínima:** un punto de paso único (`slotsOf`) para toda lectura y borrado, más una columna `slots` en la guardia de superficie con un mutante que quite la ranura alternativa.

#### 🟠 MB-2 · Flota mixta o modelo viejo: la membresía portadora renovada en `member_alt` es invisible y el deny deja de cortar

**Escenario**
- **Precondición:** el modelo con ranuras está publicado y un pod nuevo renueva a `member_alt`.
- **Acción:** se pregunta desde un pod viejo, o desde uno fijado al `modelId` anterior, o tras un `openfga:provision` de una versión anterior (el último modelo sin ranuras).
- **Resultado:** `check viewer` = **TRUE** donde el modelo nuevo niega (S7).

**Evidencia:**
- ✅ Medido (S7, S8).
- La guarda D-31 lo atraparía solo en un pod NUEVO fijado al modelo viejo, y solo en tipos con deny. Ver R2, que es el mismo defecto en los tipos sin deny.
- Un pod VIEJO no conoce la ranura.
- Es el mismo patrón que motivó D10 (dos fases del opt-in del deny).

**Steelman del defensor:** «Es lo mismo que el deny: dos fases y el rollback prohibido».
- **¿Me convence?** Sí, si se hace igual y con la misma guarda de `provision`.
- Hoy esa guarda barre los `denied_*` que un modelo nuevo dejaría huérfanos, pero no barre las ranuras. Es una entrada más de la misma clase, no un parche aparte.

**Mitigación mínima:**
- Fases `'read'` (todos leen las ranuras) y `'write'` (se escribe en `alt`).
- `provision` niega publicar un modelo sin ranuras si hay tuplas `*_alt` vivas.
- Rollback prohibido con ranuras vivas.

#### 🟡 MB-3 · Reparar dos ranuras es una operación multi-request, y en el orden equivocado concede (L10)

**Escenario:** dos ranuras de una membresía portadora (1 h y 48 h); se borra primero la de 48 h.

**Resultado:** a +2 h el sujeto concede (S14). Borrando primero la dominada no hay ventana (medido).

**Evidencia:** ✅ medido (S14). Es la propiedad universal de L10: el estado intermedio no puede conceder lo que no concedían ni el inicial ni el final.

**Steelman del defensor:** «Se borra siempre la dominada». **¿Me convence?** Sí, si pasa por `tuple_order.ts` y entra en la guardia de L10. Si se escribe a mano, es la 5.ª iteración del linaje.

**Mitigación mínima:** la reparación como operación de `tuple_order` (dominada primero; `null` = infinita), con su propiedad en el corredor.

#### 🟡 MB-4 · El CAS solo protege si no se ignora y si se clasifica como choque

**Escenario:** el driver de hoy usa `IGNORE_DUPLICATE_WRITES` e `IGNORE_MISSING_DELETES` en `relate`/`unrelate` (`openfga_relations_driver.ts:183-190`, `:694`, `:822`).
- Con `on_missing: ignore`, un swap rancio no falla y deja de ser CAS.
- Sin ignorar, el perdedor recibe 400 «cannot delete…» (S11), y `#guard` (`:455-466`) lo vende como **503 `E_AUTHZ_BACKEND_UNAVAILABLE`**.
- El invariante 6 dice: «una contención jamás es 503; se relee y se re-aplica; si no cede, 409».

**Evidencia:** ✅ en código. Ya existe la clasificación correcta en roles: `isTreeWriteRace` (`openfga_driver.ts:400-414`, «does not exist»).

**Steelman del defensor:** «Se reutiliza `isTreeWriteRace`». **¿Me convence?** Sí. Es trivial si se hace, y es el fallo típico si no.

**Mitigación mínima:** el swap sin ignorar; un 400 «does not exist»/«already exists» ⇒ releer `{user, object}` y re-aplicar; la contención ⇒ 409.

#### 🟡 MB-5 · Nombres: colisión con relaciones de dominio y ruptura del presupuesto de 50 caracteres

**Escenario:** un consumidor declara `viewer` y `viewer_alt` (legal hoy: ≤ 50 y sin prefijo reservado).
- El generador produce dos relaciones con el mismo nombre (S12).
- `denied_viewer_alt` es a la vez la ranura del deny de `viewer` y el deny de `viewer_alt`.

**Coste en el presupuesto:**
- Un sufijo `_alt` baja la cota publicada de 50 a 46. `RELATION_NAME_MAX = 50` está en `define_relations_config.ts:41` y se valida en `:493` desde 2.4. Eso es una ruptura para nombres de 47 a 50 caracteres.
- Con deny la cota baja de 43 a 39.

**Evidencia:** ✅ S12 y código.

**Steelman del defensor:** «Un prefijo reservado corto y una entrada en `RESERVED_SLUG_PREFIXES`». **¿Me convence?** Sí, y además entra en F-05 (L1) por diseño.
- Pero cualquier afijo resta caracteres. Para no romper, la ranura tiene que medir ≤ 50 por construcción: la cota se deriva igual que `DENIABLE_RELATION_NAME_MAX`, y pasa a ser rotura declarada o a aplicarse solo a tipos nuevos.

#### 🟡 MB-6 · Reconcile, listados y enumeración: sin un pliegue con máximo, el verificador certifica «limpio» con la ranura larga viva

**Escenario:** el destino tiene dos ranuras (`viewer` 1 h y `viewer_alt` 48 h); el origen tiene `viewer` 1 h.
- `planPartition` indexa por la clave lógica (`relationTupleKey`, `tuple_key.ts`).
- Si `#sweep` pliega `*_alt` sobre la misma clave y el `Map` se queda con la de 1 h, sale `unchanged` y la de 48 h sigue viva.
- Si no la pliega, `viewer_alt` es una relación no declarada ⇒ `undeclared`. Con un futuro `--prune-undeclared` se BORRARÍA la ranura viva, que en una membresía portadora es fail-open.
- `listSubjects`/`listDenies` leen con filtro de relación (`:1057`, `:1168`), así que omiten lo renovado (L8) o lo duplican, y rompen el cursor.

**Evidencia:** 🟡 depende de la implementación, pero el precedente existe: `folded-scope` en roles («la fila se queda con la caducidad que MÁS dura», CLAUDE.md, regla de higiene de reconcile).

**Mitigación mínima:** plegar con el máximo, un motivo propio (`folded-slot`) como deriva y la reparación de MB-3; la ranura nunca es `undeclared`.

#### ⚪ MB-7 · El userset por la ranura (`group#member_alt`) nunca puede entrar en el metadata

**Evidencia:** ✅ S9.
- Si el modelo lo admite, un deny escrito a `#member_alt` solo alcanza a los miembros de esa ranura y U concede.
- Si no lo admite, el servidor lo rechaza (400): es estructural gratis.

**Mitigación mínima:** mantener `holdersOrGroup` sin `group#member_alt`, con un caso que lo fije. B3 ya rechaza otros usersets en el driver.

#### ⚪ MB-8 · Store compartido con escritores ajenos

Un escritor que no es el paquete (COGNITIV con el SDK, `fga tuple write`, import/export) escribe `member` sin conocer `member_alt` ⇒ MB-1.
- No es nuevo como clase (README: el store es compartido), pero ahora un `unrelate` ajeno deja de revocar.
- **Mitigación mínima:** declararlo, y que el reconcile lo liste como `folded-slot`.

### «Desaparece la familia entera»: lo que sí y lo que no

- **Desaparece** (si la renovación es un swap y el destino declara `atomicRenewal: true`):
  - `E_AUTHZ_RENEWAL_UNSAFE` y `E_AUTHZ_RENEWAL_RACED`, más el TOCTOU de N1. Sin ventana, sobra `#carriedDeny`.
  - `renewal-unsafe`, `withheld-by-unsafe-deny` y `carrier-conflict` del reconcile, y con ellos D4-1/D4-2/D4-3. El cierre 4 midió que con un destino atómico `held`/`lost` quedan vacíos (`loteD2-auditor-cierre4.md` §2, openfga → database).
  - `deny-conditional` **solo si el deny también lleva ranura** (D3 se podría reabrir; S13: la unión de denies es fail-closed).
- **NO desaparece:**
  - El orden de L10 para transiciones multi-tupla con renovaciones que ACORTAN. El cierre 4 mató `c4h.order.renewals-not-changing` en un destino **ATÓMICO** (E3, 2 sin residuo frente a 0) y midió un 2,96 % de ciclos en un destino atómico (§4, §5).
  - El horizonte (`shortening`) sigue en `tuple_order`. Se reduce la vigencia de la fuerza bruta, no se elimina.

### La alternativa de indirección (un objeto por membresía): peor

- El creador rancio produce N objetos, no 2: es ilimitado.
- El id no es determinista, así que el reconcile no casa por clave sin otra generación, que es MB-1 de nuevo.
- `purgeSubject(user)` encuentra objetos de indirección, no membresías.
- Cada membresía añade un salto: el presupuesto de anidación (25 medido) se reparte entre más saltos (inferido de la medida de R1).

Las dos ranuras son acotadas y deterministas.

### Invariantes que harían falta, y cómo hacerlas estructurales

1. **I1 · Lectura N-ranura por un punto único:** `slotsOf(rel)` en toda lectura (`Read {user, object}` para una clave; `rel` ∪ `rel_alt` en `listSubjects`/`listDenies`/`#sweep`). Se hace estructural con una columna `slots` en la guardia de superficie y un mutante por entrada.
2. **I2 · Borrar = todas las ranuras en un `Write`** (`unrelate`, `removeDeny`, poda), con `IGNORE_MISSING`. Mismo mecanismo.
3. **I3 · Renovar = CAS** (`write(libre)` + `delete(actual)` sin ignorar). Un 400 de existencia ⇒ releer y re-aplicar; la contención ⇒ 409 (MB-4).
4. **I4 · Dos ranuras ⇒ reparación ordenada** (dominada primero, por `tuple_order`) más deriva `folded-slot` en el reconcile (MB-3, MB-6).
5. **I5 · Modelo:**
   - nombres reservados (MB-5);
   - metadata sin `#member_alt` (MB-7);
   - D-31 que compara las reglas de TODOS los tipos (cierra también R2).
6. **I6 · Despliegue:** fases `'read'`/`'write'`, guarda de `provision` contra un modelo sin ranuras con `*_alt` vivas, y rollback prohibido (MB-2).
7. **I7 (opcional) · Hacer «≤ 1» estructural con un marcador de existencia:**
   - Una tupla `rel_present` por clave lógica. Crear = `write(marker, main)`, que falla si el marcador existe. S2b y S6 miden que una escritura de una clave existente aborta el `Write` entero.
   - Coste: ×2 tuplas por relación. Sin I7, «≤ 1» es higiene y la seguridad la dan I1–I4.

---

## Parte 2: riesgo residual fuera de D2 (clases sin guardia estructural)

### 🟠 R2 · La guarda modelo↔config (D-31) solo cubre los tipos CON deny: en un tipo sin deny, el modelo fijado concede por una regla que la config ya retiró, sin error

**Escenario**
- **Precondición:** el tipo `note` sin deny se publica con `viewer includes editor`; los pods fijan ese `modelId`.
- **Acción:** se despliega una config que ESTRECHA `viewer` (sin `includes`) y no se republica ni se re-fija.
- **Resultado** (`panel-optimo-auditor-model-drift.ts`):

```
note SIN deny · config estrecha, modelo viejo: openfga check(U editor ⇒ viewer) TRUE · database FALSE
note deny:'read' · lo mismo:                   openfga 500 E_AUTHZ_CONFIG       · database FALSE
```

**Evidencia:**
- ✅ Medido.
- ✅ `openfga_relations_driver.ts:506-513`: `expected` solo existe si `spec.deny !== undefined`; para el resto solo se mira la forma de `difference`. Es una concesión persistente y silenciosa que `database` niega con la misma config.
- El docblock de D-31 (`:529-534`) dice que existe porque «un pod con la config nueva y el pin a un modelo viejo concedería». Es el mismo argumento para cualquier `includes`.

**Steelman del defensor:** «En `openfga` el modelo ES la regla; republicar es un paso documentado (provision → pin → deploy) y D-29 mantiene el literal byte a byte».
- **¿Me convence?** No. El paquete ya decidió que fiarse del paso manual no basta (D-31), y la guarda cuesta lo mismo: una lectura del modelo por proceso, ya memorizada.
- Es la regla 5.a de gemelos: la regla está aplicada a medias dentro del mismo driver.

**Mitigación mínima:** `#modelDenied` → `#modelMatches`: comparar `factsRelationRewrites` de TODOS los tipos declarados (y de `group`) con `canonicalRewrite`, y responder 500 al usarlo.

### 🟡 R1 · Anidación de grupos sin cota de escritura: desde 26 niveles, `check`/`checkMany`/`decideMany` de `openfga` son 503 permanentes, `database` responde y `listObjects` contradice a `check`

**Escenario**
- **Precondición:** un usuario con permiso de anidar grupos encadena 26 o más `group#member` (U ∈ G0 ⊂ … ⊂ G26).
- **Acción:** cualquier `check` cuyo camino atraviese la cadena.
- **Resultado** (`panel-optimo-auditor-nesting*.ts`):
  - Profundidad ≤ 25: paridad (deny por el grupo externo ⇒ `false`/`deny` en los dos drivers).
  - Profundidad 26, 30, 40 y 60, en `openfga`:
    - **503 `E_AUTHZ_BACKEND_UNAVAILABLE`** («no respondió»; causa `authorization_model_resolution_too_complex`) en `check`, `checkMany`, `decideMany` y `check(member)`.
    - `database` responde `true`/`false` correcto.
  - Con el allow solo por la cadena (sin deny), a profundidad 40, en `openfga`:
    - `listObjects` devuelve **`[X, Y]`, `truncated: false`** mientras `check(X)` es 503.
    - La propiedad planeada para C («`filtrar(P2) ⊆ check`») ya no se cumple.
  - Con un ciclo A⊂B⊂A y deny en B: los dos niegan (resiste).

**Evidencia:**
- ✅ Medido.
- ✅ El paquete ya reconoció ESTA clase en el árbol: README:1543, `scopes.maxDepth`: «past the ceiling the model answers 503 for the whole subtree (a DoS within reach of whoever can nest sub-scopes)».
- Para los grupos no hay ni gate ni fila en «Limits» (grep `nest` en el README: no hay cota de anidación de grupos).

**Steelman del defensor:** «Es fail-closed y ruidoso; nunca concede». **¿Me convence?** Para no subirlo a 🟠, sí. Pero:
- es un DoS con escrituras normales;
- es una paridad rota entre drivers;
- la letra dice que el backend «no respondió» cuando respondió (ver R3);
- el gemelo de árbol ya se cerró por el mismo motivo.

**Mitigación mínima:**
- `relations.maxGroupDepth`: 422 al `relate` de una arista de anidación que la supere, con cero I/O extra si se lee la cadena que `#carriedDeny` ya recorre.
- Un `drift.tooDeep` en el reconcile.
- Una fila en «Limits» con 25 medido (24 con ranuras).

### 🟡 R3 · Un 4xx determinista del servidor sale como 503 «el backend no respondió»

**Escenario:** `authorization_model_resolution_too_complex` (R1) o `validation_error` (S8, el modelo fijado sin la relación).

**Resultado:** `AuthorizationBackendError` (503) en los dos drivers. El invariante 5 dice «backend no responde ⇒ 503», pero aquí el backend respondió y la respuesta no cambiará con un reintento.

**Evidencia:**
- ✅ Medido en R1: la causa viaja y el código es 503.
- ✅ `openfga_relations_driver.ts:455-466` y `guardBackendErrors` (`openfga_driver.ts:466-478`): todo lo que no es timeout ni el límite de escritura es 503.
- ❓ No reproducido (un relevo con un 400 determinista exige un modelo fijado roto): la outbox trata el 503 como transitorio (alpha.5: «un 503 no consume intento»), así que un relevo que chocara con un 400 determinista no aparcaría nunca y taponaría su clave sin aparecer en `dead()`. Sería L4.

**Steelman del defensor:** «503 es el lado ruidoso; el `cause` lleva el código». **¿Me convence?** A medias.
- La política genérica del consumidor («503 ⇒ reintenta») y la del propio relay se apoyan en que 503 significa transitorio.
- Ya hay un precedente de reclasificar: «Escribir un deny contra un modelo sin `denied_X` … mapearlo a 500» (`panel-tenencia-2-analista.md` §M5).

**Mitigación mínima:**
- Una regla única de clasificación de los 4xx del servidor (`validation_error`/`resolution_too_complex` ⇒ 500 o un 422 propio, nunca 503) en el punto de paso que comparten los dos drivers.
- Un caso por código.

### ⚪ R4 · L10 se vigila por LISTA, no por inventario

`linajes.md` L10: la guardia son tres propiedades con nombre (`openfga.purge.order`, `relations.reconcile.order`, `openfga.roles.purgeScope.order`).
- Una operación multi-request NUEVA no nace roja, al contrario que L1, cuyo inventario sale por reflexión.
- El linaje ya lleva 4 iteraciones, y las ranuras añadirían una quinta (MB-3).

**Mitigación mínima:** inventario por reflexión de los métodos de driver que emiten más de un `client.write`, con fila obligatoria en el corredor de orden o exención firmada.

## Lo que intenté y NO se rompió

- El swap atómico de dos ranuras: sin ventana (S1). Es todo o nada (S2). Con 20 concurrentes, un ganador y estado final de una ranura (S11).
- El userset por la ranura con el modelo generado: el servidor lo rechaza (S9).
- El deny con caducidad en dos ranuras: siempre fail-closed (S13).
- Un ciclo de anidación con deny: niega en los dos drivers.
- La consistencia de las lecturas: `higher_consistency` por defecto en los dos drivers, con la caché de Check declarada (README:1158).
- El modelo sin fijar con deny: D14 exige `modelId` (`openfga_relations_driver.ts:390-399`), así que el memo de D-31 sobre «el último modelo» no aplica.
- La desviación de reloj: declarada (README:1120, 1478).
- El alias del uuid de holder/objeto: declarado (README:587).
- El coste de las ranuras: +5,9 % de bytes del modelo y −1 nivel de anidación. Es aceptable.

## Preguntas abiertas para el arquitecto

1. **¿«≤ 1 ranura» se hace estructural (marcador, I7, ×2 tuplas) o se acepta como higiene con I1–I4?** Sin una de las dos, MB-1 es 🟠 abierto.
2. **¿Cómo se paga MB-5?** ¿Las ranuras se aplican a todos los tipos (ruptura de la cota 50 → ≤ 46) o solo a los tipos con un opt-in nuevo (por ejemplo `renewal: 'atomic'`, con la cota derivada como la de 43)?
3. **R2:** ¿se extiende D-31 a todos los tipos en el mismo lote que las ranuras? Las ranuras cambian las reglas de TODOS los tipos y sin eso MB-2 queda sin guarda en los tipos sin deny.
