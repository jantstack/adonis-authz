# M6 · tupla condicional en la rama restada SIN `current_time` (2026-10-15)

Condición de entrada del lote D (juez ronda 2 §1 y §298; auditor R2-13 / ⚪ 18; tester fila M6 y S12).
**Medido contra OpenFGA `openfga/openfga:v1.19.0` (`:8090`, contenedor `openfga-dev`), SDK `@openfga/sdk` 0.9.6**, store
efímero creado y borrado por el script (`.claude/reproducciones/m6_condicion_sin_contexto.mjs`). Modelo: `document#viewer =
[user, user with not_expired, group#member] but not denied_viewer`, `denied_viewer` con los mismos tipos; `group#member` con
`user with not_expired`.

## Resultado

| Caso | CON `current_time` | SIN contexto: Check | SIN contexto: BatchCheck | SIN contexto: ListObjects |
|---|---|---|---|---|
| A · allow condicional vivo | `true` | **400** `validation_error` «missing context parameters '[current_time]'» | **error por ítem** | **400** |
| B · allow fijo + deny CONDICIONAL vivo (rama restada) | `false` | **400** (nombra la tupla `denied_viewer`) | error por ítem | 400 |
| C · allow fijo + deny por `group#member`, membresía condicional viva (deny TRANSPORTADO) | `false` | **400** (nombra `group:g#member@user:c`) | error por ítem | 400 |
| D · allow fijo + deny condicional CADUCADO | `true` | 400 | error por ítem | 400 |
| E · control: deny fijo | `false` | `false` | `false` | `[]` |
| F · allow condicional caducado | `false` | 400 | error por ítem | 400 |

## Conclusión

1. **OpenFGA 1.19 NUNCA omite una tupla condicional a la que le falta un parámetro, tampoco en la rama restada**: responde
   error (Check 400 `validation_error`, BatchCheck error por ítem, ListObjects 400). **No hay fail-open en el servidor.**
2. El riesgo que queda está en NUESTRO lado: cómo se traduce ese 400. Hoy el driver de relaciones clasifica por
   `backend_guard` (sin substring de mensaje desde el cierre-2 de alpha.3) y un error de `check`/ítem de `batchCheck` es 503,
   nunca `false` ni `true`. **Fila S12 del tester obligatoria en D**: espía que QUITA `context` en `check`, `checkMany`,
   `decideMany`, `listObjects` (y P2 en C) ⇒ 503 (o 500 si se decide «error de programación»), jamás T ni F; un mutante por
   camino (auditor R2-13). Con el deny, un 400 traducido a `false` en la RAMA del deny sería fail-OPEN en `decideMany`
   (`none` en vez de `deny` ⇒ la cadena de COGNITIV sigue subiendo): por eso el caso es por camino, no uno general.
3. **El deny transportado por un miembro de grupo con caducidad (caso C) se evalúa bien CON contexto**: el deny de D3 es una
   tupla SIN condición, pero puede alcanzar al usuario por una membresía condicional; con `current_time` el corte funciona,
   sin él es 400. No cambia el diseño de D; es un caso del juez (deny por grupo + membresía que caduca: vivo ⇒ `deny`,
   caducado ⇒ el allow vuelve), en los dos drivers.
4. Entrada del lote D: **M6 hecha**. Con D3, D5, D6, D8, D9, D10 firmadas y B integrado, D puede arrancar.
