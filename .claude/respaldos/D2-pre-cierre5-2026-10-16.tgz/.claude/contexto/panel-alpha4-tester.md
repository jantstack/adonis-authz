# Panel `2.4.0-alpha.4` — TESTER DE CONTRATO

Sobre `2.4.0-alpha.3` (`9a107ad`, árbol limpio) y el informe de COGNITIV del 2026-09-09.
Todo lo que sigue está **medido**, no razonado: los prototipos y su salida real están en
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/` (`probe_green.ts`,
`probe_stub.ts`, `probe_loader.mjs`, `evidencia-*.txt`). No se ha tocado `src/`, `commands/` ni `tests/`.

---

## 0. Veredicto sobre el diagnóstico de COGNITIV: CONFIRMADO, y se queda corto

### 0.1 El agujero que denuncian existe, literalmente

```
$ grep -rn "BaseCommand\|Kernel\|IgnitorFactory\|AceFactory\|kernel\.exec\|ListLoader" tests/
tests/purity.spec.ts:73:      'src/c.ts': `import '#start/kernel'\n`      ← una cadena dentro de un fixture
tests/purity.spec.ts:107:        `   ni require("#start/kernel") */`     ← ídem
(el resto de coincidencias de "exec" son RegExp.exec o execFile de scripts .mjs)
```

**Cero casos construyen un kernel de ace. Cero casos instancian un `BaseCommand`.** Lo que hay son
helpers PUROS extraídos de cada comando y juzgados con el config a mano:

| comando | helper exportado | quién lo juzga | ¿se ejecuta el comando? |
|---|---|---|---|
| `openfga:provision` | `permissionsOfCatalogs`, `relationsConfigOf` | `tests/relations_provision.spec.ts:27` | ❌ |
| `authz:catalog:sync` | `catalogSyncOptions` | `tests/openfga_facts.spec.ts:3890` | ❌ |
| `authz:reconcile` | `reconcileLines` | `tests/reconcile.spec.ts:1423` | ❌ |
| `authz:relations:reconcile` | `relationsReconcileLines`, `runRelationsReconcile` | `tests/relations_reconcile_cli.spec.ts:27` | ❌ |
| `authz:unfreeze` | `unfreezePlan` | `tests/freeze.spec.ts:300` | ❌ |
| `authz:catalog:prune-orphans` | `orphanLines` | `tests/manager.spec.ts:3957` | ❌ |
| `authz:catalog:diff` | — (ninguno) | **nadie** | ❌ |
| `authz:freeze` | — (ninguno) | **nadie** | ❌ |
| `authz:scopes:relay` | — (ninguno) | **nadie** | ❌ |

Tres módulos de `commands/` **no los importa ni un solo `.spec.ts`**: un error de sintaxis o de import
en ellos sale publicado. El propio comentario de `relations_reconcile_cli.spec.ts` lo dice sin
disimulo: *«Aquí se juzga sin montar un ace»*. Es una decisión consciente que se convirtió en el punto
ciego exacto donde cayó el defecto.

### 0.2 La causa raíz, medida en el framework (no inferida)

- `@adonisjs/application` — `Application.boot()` (`application-BCWLhWpE.js:2445`) hace
  `await this.#configManager.process(this.rcFile.directories.config)`. **El `Config` se crea en
  `boot()`, no en `init()`.** `get config()` (`:2086`) devuelve `this.#configManager.config`, que es
  `undefined` hasta entonces. Y `app.useConfig(values)` (`manager-CpbGmDZf.js:873`) **solo guarda los
  valores**; tampoco crea el `Config`. O sea: ni siquiera inyectando el config a mano se evita el
  `TypeError` sin `boot()`.
- `@adonisjs/core` — el ignitor de ace (`main-B2M1tZ4I.js:55-70`) hace `app.init()` y **solo** arranca
  la app dentro del hook `kernel.loading`:
  ```js
  kernel.loading(async (metaData) => {
    if (metaData.options.startApp && !app.isReady) { await app.boot(); await app.start(() => {}) }
  })
  ```
  Con `startApp: false` **la app no bootea nunca**. Este hook es el harness del caso 1.
- `commands/openfga_provision.ts:33` declara `startApp: false` y `:46` lee `this.app.config.get(...)`.
  **Es el ÚNICO de los nueve con `startApp: false`** (medido: los otros ocho declaran `true`), así que
  el defecto no se propaga a los demás por esta vía.

### 0.3 🔴 Y hay un defecto MAYOR en el mismo punto ciego: **ningún comando del paquete se puede cargar en un consumidor**

`configure.ts:47` registra `.addCommand('@jantstack/adonis-authz/commands')` ⇒ `build/commands/main.js`.
`createAceKernel` (`create_kernel-Bx7xtr5F.js`) lo registra así:
```js
app.rcFile.commands.forEach((m) => kernel.addLoader(() => typeof m === 'function' ? m() : app.import(m)))
```
y `Kernel.boot()` (`@adonisjs/ace/build/index.js:2452`) invoca `loaderInstance.getMetaData()` sobre el
**namespace del módulo**. Un *commands barrel* de Adonis tiene que exportar `getMetaData()`/`getCommand()`
y venir con un `commands.json` generado. `commands/main.ts` exporta **clases**:

```
$ node probe_loader.mjs      # contra los artefactos BUILD, no contra los .ts
FALLA @jantstack/adonis-authz (build/commands/main.js) → TypeError: loaderInstance.getMetaData is not a function
OK    @adonisjs/lucid/commands (referencia)            → db:seed, db:truncate, …, schema:generate
```
`find build -name commands.json` ⇒ **vacío**. `@adonisjs/lucid/build/commands/` ⇒ **tiene** `commands.json`
y un `main.js` que es un loader.

Consecuencia: en un consumidor que siga `node ace configure @jantstack/adonis-authz`, **`node ace` entero
revienta al arrancar** (el kernel bootea todos los loaders), no solo `openfga:provision`. Que COGNITIV
llegara a ver el `TypeError` de la línea 46 solo se explica porque su workaround
(`zz_tmp_openfga_provision.ts`) es un fichero en SU `commands/`, que carga el `FsLoader` — no el barrel.
**Esto lo caza gratis el caso 3a de abajo y no lo caza ningún otro caso propuesto.** Lo reporto al
analista y al auditor: mi veredicto es solo que hoy no es observable y con un caso lo es.

---

## 1. CASO 1 — el defecto, fijado SIN servidor · **PROTOTIPADO Y EJECUTADO**

### 1.1 El harness (nuevo helper): `tests/helpers/ace.ts`

Decisión medida, no de gusto: **`AppFactory`, jamás `IgnitorFactory`/`AceFactory`.**
`Ignitor.createApp()` llama a `setApp()` (`main-B2M1tZ4I.js:395`) y **reemplaza el servicio global
`@adonisjs/core/services/app`**, del que cuelgan `services/main.ts` y `@adonisjs/lucid/services/db`
(los dos hacen `await app.booted(...)` sobre el global al importarse). Una app fixture creada con el
ignitor dentro de la suite se lleva por delante la app de `bootApp()`. `AppFactory` **no** llama a
`setApp` — comprobado en el prototipo: `global app intacta: true` en las cuatro variantes.
Con esto el caso vive **en proceso**, sin hijo, sin restaurar nada y sin dependencia de orden.

```ts
// tests/helpers/ace.ts (propuesta)
import { AppFactory } from '@adonisjs/core/factories/app'
import { Kernel, ListLoader } from '@adonisjs/core/ace'

const REPO = new URL('../../', import.meta.url)

/**
 * Un kernel de ace con la MISMA regla de arranque del ignitor real
 * (src/ignitor/ace.ts): la app SOLO bootea si el comando declara startApp.
 * Copiar esa condición es el punto: si el harness booteara siempre, el caso
 * no probaría nada. NO usa IgnitorFactory: createApp() hace setApp() y se
 * lleva la app global de bootApp().
 */
export async function aceFor(Command: any, authorization: unknown) {
  const app: any = new AppFactory().create(REPO, (id) => import(id))
  app.useConfig({ authorization })
  await app.init()
  const kernel: any = new Kernel(app)
  kernel.loading(async (md: any) => {
    if (md.options.startApp && !app.isReady) { await app.boot(); await app.start(() => {}) }
  })
  kernel.addLoader(new ListLoader([Command]))
  kernel.ui.switchMode('raw')          // logs capturables
  kernel.errorHandler = { async render() {} }  // el kernel no imprime: aquí se AFIRMA
  return {
    app,
    async exec(argv: string[] = []) {
      const cmd = await kernel.exec(Command.commandName, argv)
      return { cmd, error: cmd?.error, exitCode: cmd?.exitCode,
               logs: kernel.ui.logger.getLogs().map((l: any) => l.message) }
    },
  }
}
```
Detalle que hay que documentar en el helper: **`kernel.exec` NO relanza**. `BaseCommand.exec` guarda
`this.error` y relanza; el `#exec` del kernel lo captura y se lo da al `errorHandler`. Por eso la
aserción va sobre `cmd.error`, nunca sobre `assert.rejects`. Un caso escrito con `assert.rejects`
pasaría en verde sin probar nada — ese es el primer sitio donde este lote se puede escribir mal.

### 1.2 Los casos (fichero nuevo `tests/commands_kernel.spec.ts`)

Fixture compartida — **`catalogs` es un espía**, que es lo que convierte «no explota» en «leyó ESTE config»:

```ts
function authzFixture(over = {}) {
  const spy = { called: 0 }
  return { spy, config: {
    holderTypes: { users: 'user' },
    catalogs: [async () => { spy.called++; return { permissions: [{ slug: 'posts.read' }, { slug: 'posts.write' }] } }],
    relations: { config: { objectTypes: [{ type: 'document', relations: [{ name: 'owner' }, { name: 'viewer', includes: ['owner'] }] }] } },
    openfga: { url: STUB_URL },
    ...over } }
}
```

**A-1 · `openfga:provision` por el kernel LEE el config y llega a la red (el defecto).**
`dado` un config de fixture con `holderTypes`, dos permisos en `catalogs` y `relations.config`, y
`openfga.url` apuntando a un **servidor HTTP local mudo que responde 400 y anota la request**;
`cuando` se ejecuta `openfga:provision` por el kernel de ace **sin flags**;
`entonces` (a) `cmd.error` **no** es un `TypeError`, (b) el espía de `catalogs` se llamó **1 vez**,
(c) el stub recibió **`POST /stores`**, (d) el error es el 400 del stub.
Las cuatro juntas dicen: el config se leyó, sus catálogos se resolvieron, su `openfga.url` se usó y el
comando llegó a provisionar. Es la aserción más fuerte que se puede hacer sin OpenFGA.

**A-2 · sin URL en ningún sitio, la letra del error.** `dado` el mismo config con `openfga: {}` y sin
`--url`; `entonces` `logs` contiene *exactamente* `Falta la URL del servidor: --url o \`openfga.url\` en
config/authorization.ts` y `exitCode === 1`, sin error. (Diente de letra, patrón `freeze.spec.ts` 3b-7.)

**A-3 · sin `catalogs`, la letra del error.** `dado` el config con `catalogs: undefined` y `openfga.url`
puesta; `entonces` `logs` contiene la frase de `resolvePermissions` («El modelo \`facts\` declara cuatro
relaciones por permiso…»), `exitCode === 1` y el stub **no** recibió ninguna request. Esto fija que la
negativa a provisionar sin catálogos ocurre **leyendo el config real**, no un `{}`.

**A-4 · `--url` gana al config.** `dado` `openfga.url` = un puerto muerto y `--url` = el stub;
`entonces` el stub recibe la request. (Precedencia de la línea 47, hoy sin caso.)

### 1.3 El rojo esperado, LITERAL (ejecutado hoy)

`node --import @poppinss/ts-exec probe_green.ts` — la app de la suite emulada (booteada, `setApp`,
`Database` en el contenedor), el comando **tal como está en `main`**:

```
──── ROJO  · mutante startApp:false · url en el CONFIG   (2 ms)
   startApp: false | isReady: false | config: undefined
   exitCode: 1
   error   : TypeError: Cannot read properties of undefined (reading 'get')
   error@  : at OpenFgaProvision.run (/home/jose/proyectos/Personal/adonis-authz/commands/openfga_provision.ts:46:36)
   logs    : []
   catalogs() llamado: 0
   global app intacta: true

──── VERDE · arreglado             · url en el CONFIG   (1951 ms)   ← contra puerto muerto
   startApp: true | isReady: true | config: Config
   exitCode: 1
   error   : FgaError: FGA Error: connect ECONNREFUSED 127.0.0.1:1
   error@  : at AxiosError.from (…/axios/dist/node/axios.cjs:1355:24)
   catalogs() llamado: 1

──── VERDE · arreglado             · sin url en ningún sitio   (1 ms)
   logs    : ["[ red(error) ] Falta la URL del servidor: --url o `openfga.url` en config/authorization.ts"]

──── VERDE · arreglado             · sin catalogs   (2 ms)
   logs    : ["[ red(error) ] El modelo `facts` declara cuatro relaciones por permiso: sin `catalogs` en
              config/authorization.ts no hay modelo que publicar. Declara tus catálogos y repite
              (el store que se creara sin ellos denegaría todo)."]
```

Y con el stub HTTP local en vez del puerto muerto (`probe_stub.ts`), **1951 ms → 133 ms**:
```
──── ROJO mutante  (2 ms)
   error   : TypeError: Cannot read properties of undefined (reading 'get')
   error@  : at OpenFgaProvision.run (commands/openfga_provision.ts:46:36)
   catalogs(): 0 | requests al stub: []
──── VERDE arreglado  (133 ms)
   error   : FgaApiValidationError: FGA API Validation Error: post  : Error stub: no hay servidor FGA de verdad aquí
   catalogs(): 1 | requests al stub: [{"method":"POST","url":"/stores"}]
```
**Por eso el caso A-1 usa el stub local y no el puerto muerto**: mismo poder de detección, 14× más
rápido y sin depender de cuántas veces reintente axios. El ECONNREFUSED del puerto muerto queda como
apunte, no como caso.

> **El rojo que hay que pegar en el CHANGELOG:**
> `TypeError: Cannot read properties of undefined (reading 'get')` **at `OpenFgaProvision.run (commands/openfga_provision.ts:46:36)`**, con `app.isReady: false`, `app.config: undefined`, `catalogs() llamado: 0` y `logs: []`.

### 1.4 Mutantes que este caso mata

| mutante | ¿muere? | cómo |
|---|---|---|
| `startApp: false` sin `boot()` (**el defecto**) | ✅ | `TypeError` en A-1..A-4 |
| «arreglo» que boota pero no re-lee el config | ✅ | `catalogs() === 0` en A-1 |
| quitar la guarda de la URL | ✅ | A-2: `logs` vacío |
| quitar la guarda de `catalogs` | ✅ | A-3: el stub recibe request |
| suavizar cualquiera de los dos mensajes | ✅ | A-2/A-3 fijan la letra |
| invertir la precedencia `--url`/config | ✅ | A-4 |
| **el harness boota siempre** (auto-gol) | ⚠️ | lo mata el caso 3b, que exige que el hook mire `startApp` |

### 1.5 Neutralidad respecto al arreglo — importante

El harness **no elige** entre la propuesta A (`startApp: true`) y la B (`if (getState() === 'initiated')
await this.app.boot()`): el hook obedece a `static options.startApp`, sea cual sea. Con A el harness
boota; con B boota el comando. Los dos ponen A-1..A-4 en verde. **El caso no es rehén de la
implementación** — condición para que sirva de criterio de aceptación del panel.

Aviso para el analista, medido: con la opción A (`startApp: true`) el comando deja de ser
«bootstrap antes de que haya base» de verdad. `await import('../src/openfga.js')` arrastra
`src/drivers/openfga_driver.ts`, que importa `@adonisjs/lucid/services/db` en el top level, y ese módulo
hace `app.container.make(Database)` **en cuanto la app está booteada**. En mi prototipo sin binding de
`Database` eso fue `RuntimeException: Cannot construct "[class Database]"` **antes** de leer los
catálogos. En un consumidor real el provider de Lucid lo tiene bindeado, así que no se ve; pero el
appliance sin `config/database.ts` sí lo vería. Es un caso más, barato, si se elige A:
**A-5 · `openfga:provision` funciona en una app SIN binding de `Database` en el contenedor** — hoy 🟡,
y con la opción B es ✅ por construcción.

---

## 2. CASO 2 — contra el `:8101`, gateado a `OPENFGA_TEST_URL`

**No ejecutable hoy**: `curl http://localhost:8101/stores` y `:8080` ⇒ sin respuesta (código 000). El
diseño va cerrado; la ejecución queda pendiente de levantar el servidor.

**B-1 · `openfga:provision` por el kernel crea el store y publica el modelo con las cuatro relaciones por permiso.**
- `dado` `OPENFGA_TEST_URL` vivo y el config de fixture (`holderTypes: { users: 'user' }`,
  `catalogs` ⇒ `['posts.read', 'posts.write']`, `relations.config` ⇒ `document{owner, viewer}`),
  con `openfga.url` = `OPENFGA_TEST_URL`;
- `cuando` se ejecuta `openfga:provision` por el kernel, **sin flags**;
- `entonces`:
  1. `exitCode === 0` y `cmd.error === undefined` (hoy NADA afirma que este comando salga 0);
  2. de `logs` se extraen `OPENFGA_STORE_ID=<id>` y `OPENFGA_MODEL_ID=<id>` con
     `/^OPENFGA_STORE_ID=(.+)$/m` — **el stdout ES el contrato del comando** (el operador copia esas
     líneas al `.env`), así que se afirma sobre él, no sobre un valor de retorno;
  3. `client.listStores()` contiene ese store id, y su `name` es el `appName` (o `openfga.storeName`);
  4. `client.readLatestAuthorizationModel()` de ese store devuelve un modelo cuyo id **es** el
     `OPENFGA_MODEL_ID` impreso, y cuyos `type_definitions` contienen `scope`, `role`, `role_binding`,
     `user` **y** `document`;
  5. para **cada** permiso `P ∈ {posts.read, posts.write}`, el tipo `scope` declara las **cuatro**
     relaciones `P`, `can_P`, `denied_P`, `permits_P` (`permits_P` en `role`) — se afirman las 4×2 = 8
     por nombre, no un `assert.isAbove(relations.length, 0)`;
  6. la relación `can_P` lleva `rooted` en su definición (invariante 9 · c2r): sin ese `and rooted` el
     modelo publicado sería fail-OPEN para un subárbol desgajado, y ese es el invariante que un
     `provision` mal publicado rompe en silencio.
- **Limpieza**: `stores.push(storeId)` + `group.teardown` con `new OpenFgaClient({apiUrl, storeId}).deleteStore()`,
  exactamente el patrón de `tests/relations_provision.spec.ts:52-56`. Y la red de `armOpenFgaStoreGuard`
  (`tests/helpers/openfga_stores.ts`) ya cubre una corrida interrumpida: **el store se crea desde el
  comando, así que la foto/baseline del guard lo ve igual** (borra lo que no estaba en la foto y se creó
  después). No hace falta tocar el guard.

**B-2 · `--store-id` escribe un modelo NUEVO en un store EXISTENTE, sin crear otro.**
`dado` el store de B-1; `cuando` se ejecuta con `--store-id=<ese>` y un catálogo con un permiso MÁS;
`entonces` `listStores()` no ha crecido, `readLatestAuthorizationModel()` devuelve un id **distinto** del
de B-1 y su `scope` declara las cuatro relaciones del permiso nuevo. Es el único camino de
`openfga_provision.ts:76-88` y hoy no lo pisa nadie.

**B-3 · inverso · un `--store-id` que no existe no crea nada.** `entonces` `exitCode !== 0` y
`listStores()` no cambia. (Que un id malo no acabe en un store fantasma.)

**Bordes que el plan no menciona y que aquí sí se ven**: catálogo con permisos **duplicados** entre dos
`catalogs` (⇒ `permissionsOfCatalogs` deduplica y el modelo no lleva la relación dos veces: FGA rechaza
el duplicado, así que sin dedup el comando explota); slug de permiso con `.` o `:` (`posts.read` ya lo
cubre, `posts:read` no — ¿es un nombre de relación válido en FGA?, hoy nadie lo pregunta);
`holderTypes` **vacío** (`{}`, que es el default de la línea 58: ¿un modelo sin ningún holder type se
publica y deniega todo, o se rechaza?); `catalogs` cuya función **lanza** (⇒ hoy el error sube crudo).

---

## 3. Los otros OCHO comandos — inventario y coste

**El defecto concreto no está en ellos**: los ocho declaran `startApp: true` (medido), así que el hook
del ignitor boota la app y `this.app.config` existe. Lo que sí comparten es el agujero de método.

### 3a · El caso genérico BARATO que hay que escribir sí o sí (y que caza el 🔴 de 0.3)

**C-1 · el barrel de comandos es un loader de ace válido y registra los NUEVE.**
`dado` `commands/main.js` (el que `configure.ts:47` mete en el `adonisrc` del consumidor);
`cuando` se registra **como lo registra `createAceKernel`** (`kernel.addLoader(() => import('../commands/main.js'))`)
y se hace `kernel.boot()`;
`entonces` `kernel.getCommands()` contiene los nueve `commandName` esperados (lista literal).
- **Rojo de hoy, medido**: `TypeError: loaderInstance.getMetaData is not a function`.
- **Coste: 1 caso, ~50 ms, cero infra.** Es el caso con mejor relación valor/coste de todo el lote:
  caza un defecto peor que el reportado, y a partir de ahí **un comando nuevo que no se exporte del
  barrel es rojo automático** (el fallo silencioso más probable de este paquete).

**C-2 · cada uno de los nueve declara su metadata mínima.** Sobre `kernel.getCommands()`: `commandName`
no vacío y único, `description` no vacía, `options.startApp` **declarado explícitamente** (`typeof ===
'boolean'`), `options.staysAlive` coherente. Coste: 1 caso, ~0 ms. Cierra de paso los tres módulos que
hoy **no importa ningún test**.

### 3b · El caso genérico de EJECUCIÓN: sí es barato, con una condición

Seis de los nueve tienen un **bail-out antes de tocar la base** (medido leyendo cada `run()`), lo que
permite ejecutarlos de verdad por el kernel sin base, sin manager y sin red:

| comando | `startApp` | argv/config que hace el bail | qué afirma |
|---|---|---|---|
| `openfga:provision` | `false` 🔴 | config sin `openfga.url` | «Falta la URL del servidor» |
| `authz:catalog:diff` | `true` | config sin `catalogs` | «No hay catálogos declarados» |
| `authz:catalog:sync` | `true` | config sin `catalogs` | «No hay catálogos declarados» |
| `authz:freeze` | `true` | sin `--reason` | «Falta --reason» |
| `authz:reconcile` | `true` | sin `--to` | «Falta --to» |
| `authz:relations:reconcile` | `true` | sin `--to` / sin `relations.drivers` | «Falta --to» / «No hay \`relations.drivers\`» |

**C-3 · cada comando con guarda llega a su guarda (parametrizado, 6 casos).**
`entonces` para cada uno: `cmd.error` **no** es `TypeError`, `exitCode === 1` y `logs[0]` contiene la
frase literal. Esto es exactamente «cada comando carga y su `run()` llega al config», medido de verdad,
y **generaliza el defecto reportado a los seis** (si mañana alguien pone `startApp: false` en
`authz:catalog:diff`, C-3 se pone rojo el mismo día).
**Coste: 6 casos, < 300 ms, cero infra nueva** (el helper de 1.1 y nada más).

Los tres restantes —`authz:unfreeze`, `authz:catalog:prune-orphans`, `authz:scopes:relay`— **no tienen
guarda**: van directos a `await import('../services/main.js')`, que resuelve `authz.manager` del
contenedor **GLOBAL** (`services/main.ts:12`, `app.booted` sobre `@adonisjs/core/services/app`), no del
de la app fixture. Dentro de la suite ese binding existe (`tests/helpers/app.ts` lo registra) y el
esquema está creado (`bin/test.ts`), así que ejecutarlos **funcionaría**, pero:
- es una integración de verdad contra la base de la suite (los tres son inocuos por defecto:
  `prune-orphans` es `--dry-run` por defecto, `relay` admite `--dry-run`, `unfreeze` sobre base sin
  congelar es `noop`), y
- el harness quedaría **bicéfalo**: config de la app fixture, manager de la app de la suite. Es
  honesto para afirmar «no revienta y llega a su lógica», pero **no** es un end-to-end y hay que
  escribirlo en el comentario del caso o alguien lo leerá como lo que no es.

**C-4 · los tres sin guarda arrancan y llegan al manager (3 casos).** `entonces` `cmd.error` no es
`TypeError` ni `RuntimeException` de contenedor, y `logs` contiene la primera línea de su reporte.
**Coste: 3 casos, ~1-2 s** (tocan la base de la suite), y **por motor** (sqlite/sqlite-file/pg/mysql).
Es el único trozo del lote que se paga cuatro veces. **Recomendación: escribir C-1..C-3 ahora y dejar
C-4 para cuando haya un motivo**; el 90 % del valor está en C-1 y C-3.

### 3c · El diente estático que impide la recaída (patrón `purity.spec.ts`)

**C-5 · un comando que lee `this.app.config` declara `startApp: true`.** Se leen los nueve `.ts` de
`commands/` y, si el fuente contiene `this.app.config`, `static options` tiene que traer
`startApp: true`. Rojo de hoy: `openfga:provision`. **Coste: 1 caso, ~5 ms.** No sustituye a A-1
(es un proxy sobre el fuente, no conducta) pero es la red que cubre a un comando FUTURO antes de que
nadie se acuerde de escribirle su C-3. Si se elige la opción B del arreglo (boot explícito dentro de
`run()`), la regla se enuncia «…declara `startApp: true` **o** llama a `app.boot()` en `run()`», y hay
que decidirlo con el analista antes de escribirla; con la opción A la regla es limpia.

### Coste total del punto 3
| bloque | casos | tiempo | infra nueva |
|---|---|---|---|
| C-1 barrel loader | 1 | ~50 ms | ninguna |
| C-2 metadata de los nueve | 1 | ~0 ms | ninguna |
| C-3 seis comandos con guarda | 6 | < 300 ms | `tests/helpers/ace.ts` |
| C-5 diente estático | 1 | ~5 ms | ninguna |
| **subtotal recomendado** | **9** | **< 400 ms** | **1 helper** |
| C-4 tres sin guarda (diferible) | 3 | 1-2 s **× 4 motores** | ninguna |

---

## 4. `authorization.capabilities()` / `relations.capabilities()`

### 4.1 La pregunta que hay que decidir ANTES de escribir el caso: ¿pasa por la puerta 2?

`manager.driver()` (`src/manager.ts:368-394`) hace, en este orden: resolver la factory → aplicar
`withClock` → **`#assertTransactionalWritesRequired`** (puerta 2, `:409`) → `#assertScopeDriftGuarded` →
cachear. Si `capabilities()` se implementa como `(await this.driver()).capabilities`, entonces
**hereda la puerta 2**: con `requireTransactionalWrites: true` y un driver que declara `false`,
`capabilities()` lanza 500 `E_AUTHZ_CONFIG` — o sea, **la API que existe para saber si el driver
soporta transacciones es inusable justo en el despliegue mal configurado que quiere diagnosticar**.
Ese es el hueco del diseño. Las dos salidas son legítimas y **cada una tiene su caso**; lo que no vale
es no decidirlo.

**Mi recomendación como verificador: `capabilities()` NO pasa por la puerta 2** (es una lectura de
metadata, la puerta 2 es un gate de arranque para escrituras), **pero sí aplica `withClock`** — porque
si no, podría reportar las capacidades de un objeto que no es el que decide. Implementación: resolver
igual que `driver()` (factory + `withClock`) **sin** los dos `assert`, y **sin** cachear en `#driver`
(cachear ahí saltándose los gates sería un bypass: la siguiente llamada a `driver()` devolvería el
driver cacheado sin haber pasado nunca por la puerta). Eso último es el riesgo real de esta API y
tiene su caso: **D-5**.

### 4.2 Los casos

**D-1 · `capabilities()` devuelve EXACTAMENTE lo que declara el driver activo.**
`dado` un manager con `database`; `entonces` `assert.deepEqual(await m.capabilities(), (await m.driver()).capabilities)`.
Ídem con `openfga`. Es la aserción de no-deriva: **una copia escrita a mano en el manager es
exactamente el bug que esta API puede introducir** (el precedente está en el invariante 18 ·
`countRoleAssignments`: contar en la tabla del driver `database` hacía que `openfga` reportara siempre
`false`, «fail-dangerous»).

**D-2 · es una copia CONGELADA y no un alias mutable.**
`entonces` (a) `Object.isFrozen(caps) === true`; (b) `caps !== (await m.driver()).capabilities`
—si es la misma referencia, no es una copia—; (c) tras `(caps as any).transactionalWrites = true`
en `'use strict'` (⇒ `TypeError`) o con `assert.throws`, una segunda llamada
`(await m.capabilities()).transactionalWrites` sigue siendo la original.
Ojo, medido: `database_driver.ts:499` ya hace `Object.freeze(...)` y `withClock` (`:547`) devuelve
`Object.create(this)`, así que la vista con reloj **comparte** el mismo objeto congelado. Si se decide
devolver la MISMA referencia (más barato y ya inmutable), entonces (b) se invierte y el caso lo dice
así — pero hay que elegir, porque `deepEqual` pasa en los dos mundos y no distingue nada.

**D-3 · un driver SIN `capabilities` ⇒ `{}`, jamás `undefined`.**
**Propuesta: `{}` congelado.** Motivo, y es del contrato ya escrito: `types.ts:241` dice que un driver
de 2.x sin `capabilities` «se trata como todo `false`», y el manager ya lo lee así
(`driver.capabilities?.transactionalWrites === true`). Devolver `undefined` obliga a **cada** llamante
de plataforma a escribir `caps?.x` y convierte el primer olvido en `undefined` (falsy) — que es «no
soporta», la respuesta correcta por accidente hoy y la incorrecta el día que una capacidad tenga
default `true`. Con `{}` el acceso `caps.transactionalWrites` es `undefined` igual, pero **la API
nunca devuelve nada que no sea un objeto** y `Object.keys(caps).length === 0` es la señal explícita de
«este driver no declara nada». `entonces`: `assert.deepEqual(await m.capabilities(), {})` y
`assert.isFrozen(...)` con un driver de prueba sin `capabilities` (`makeDriver` de
`src/testing/`). **Y su inverso:** con ese mismo driver, `requireTransactionalWrites: true` sigue
lanzando en `driver()` — `{}` no puede leerse como «declara false explícitamente y ya».

**D-4 · `relations.capabilities()`: el mismo trío.** D-1/D-2/D-3 contra `RelationsDriverCapabilities`
(`types.ts:1624`), con `database` (`membersOfNative: true`) y `openfga` (`membersOfNative: false`), que
son un par que ya distingue. Y el borde propio de relaciones: `RelationsManager` tiene su propio
`driver()`; hay que comprobar **cuál** de las dos vistas devuelve (`relations.capabilities()` no puede
devolver las del driver de ROLES).

**D-5 · 🔑 `capabilities()` no envenena el caché de `driver()`.**
`dado` un manager con `requireTransactionalWrites: true` y el driver `openfga` (que declara `false`);
`cuando` se llama **primero** a `capabilities()` y **después** a `driver()`;
`entonces` `driver()` sigue lanzando 500 `E_AUTHZ_CONFIG` con la letra de `:412-415`.
**Este es el caso que hay que escribir antes que ninguno**: es el único fallo de este lote con
consecuencia de SEGURIDAD (una lectura de metadata que deja el driver cacheado sin gate). Y su
gemelo con el orden invertido (`driver()` primero, luego `capabilities()`), porque el invariante
*«¿el resultado depende del orden de las llamadas?»* es justo lo que un caché tiene que responder «no».

**D-6 · en `forRequest()` la vista delega en el padre.** `driver()` hace `if (this.#parent) return
this.#parent.driver()` (`:369`). `capabilities()` tiene que hacer lo mismo, o una vista de request
podría resolver una segunda instancia del driver saltándose el caché y los gates.

**D-7 · el README lo bendice con su letra.** Diente de docs (patrón `trx_docs.spec.ts`): el README
nombra `capabilities()` **en la misma sección que `manager.driver()`**, como API de PLATAFORMA, y dice
que es de **solo lectura** y que **no** sustituye a la puerta 1 (una escritura con `{ transaction }`
sigue siendo 500 aunque el llamante haya preguntado antes). Sin esa frase, el consumidor la leerá como
un permiso.

**Coste**: 7 casos × 2 puertos (roles + relaciones) donde aplique ⇒ **~10 casos, en memoria, sin base
ni red, < 100 ms.** Barato. **Veredicto: verificable con cambios** — hay que decidir puerta 2 sí/no y
copia/referencia antes de escribir D-2 y D-5.

---

## 5. La frase del README sobre `sqlScopeEdges` multi-tabla — qué caso de letra

Medido: `sqlScopeEdges` (`src/sql_descendants.ts:245`) toma **una** `{ table, uuidColumn, parentColumn,
typeColumn | scopeType }`; `types.ts:962` y `README.md:927` dicen «lo implementa sobre una tabla con
columna padre». COGNITIV tiene el árbol en **tres** tablas y escribió su `enumerateScopeEdges` con un
`UNION ALL` (448 tuplas migradas, segunda pasada idempotente). O sea: la limitación es real, la frase
del README no miente, pero **calla el caso que el consumidor se va a encontrar**.

Una frase de docs sin caso es una promesa; el repo ya tiene el patrón para ponerle dientes
(`trx_docs.spec.ts`, `relations_events_docs.spec.ts`, `upgrade_recipe.spec.ts`). **Dos dientes:**

**E-1 · el diente de LETRA.** La sección del README de `authz:reconcile --to` contiene, con estas
palabras: (a) que `sqlScopeEdges` cubre **una sola tabla**; (b) que un árbol repartido en varias tablas
necesita un `enumerateEdges` **propio**, y que componer varias llamadas a `sqlScopeEdges` **no vale por
sí solo** —cada una pagina con su cursor y el contrato exige orden **total y estable** entre llamadas
(`types.ts:950-958`)—; (c) el **cómo**: concatenar las tablas en una sola consulta ordenada (`UNION ALL`
+ `ORDER BY` estable) o encadenar las tablas en un orden fijo codificando *qué tabla* dentro del cursor
opaco; (d) que una arista cuyo padre no está en **ninguna** de las tablas no se emite. Patrón:
`sectionOf(readme, '#### …')` + `assert.include`. **Rojo**: alguien suaviza o borra la frase.

**E-2 · 🦷 el diente EJECUTABLE, que es el que de verdad muerde.** Un `enumerateEdges` multi-tabla de
juguete escrito **como dice el README**, sobre tres tablas del harness SQL
(`tests/helpers/schema.ts` ya crea `demo_scopes`; hacen falta dos más, o tres vistas), pasado a
`authz:reconcile --to` (o directamente a la pieza que lo consume, como hace
`tests/reconcile.spec.ts:272`), y afirmar: (a) enumera **todas** las aristas de las tres tablas, sin
repetir ni saltarse ninguna, **con `limit` pequeño para forzar ≥ 3 páginas**; (b) reanudando desde
`after` a mitad, el conjunto final es idéntico (orden total y estable); (c) una arista cuyo padre está
en **otra** tabla se emite (es el punto entero de un árbol multi-tabla, y el sitio donde una
concatenación ingenua de tres `sqlScopeEdges` **falla**); (d) una arista con padre inexistente no se
emite. **Sin (c) la frase del README es una receta que nadie ha ejecutado.**
**Coste**: E-1 es 1 caso y ~0 ms; E-2 son 4 aserciones en 1-2 casos, necesitan **dos tablas nuevas en
el harness** y corren **por motor** (pg/mysql/sqlite: el `UNION ALL` con `ORDER BY` y `LIMIT` no se
escribe igual en los tres, que es precisamente por qué merece caso). Medio.
**Veredicto: E-1 verificable ya; E-2 verificable con cambios (fixtures nuevas).** Si solo cabe uno,
E-1 — pero entonces el README tiene que decir «receta no verificada por la suite», o es una promesa.

---

## 6. Resumen: coste total por modo

| bloque | casos | `npm test` (sqlite) | `sqlite-file`/`pg`/`mysql` | `OPENFGA_TEST_URL` | infra nueva |
|---|---|---|---|---|---|
| **A** · caso 1 sin servidor (A-1..A-4) | 4 | ~200 ms | igual (no toca base) | igual | `tests/helpers/ace.ts` + stub HTTP local |
| A-5 (solo si gana la opción A del arreglo) | 1 | ~50 ms | igual | igual | ninguna |
| **B** · caso 2 contra el `:8101` (B-1..B-3) | 3 | *skip* | *skip* | ~2-4 s | teardown de stores (patrón ya existente) |
| **C** · comandos: barrel + metadata + guardas + diente | 9 | < 400 ms | igual | igual | ninguna extra |
| C-4 (diferible) | 3 | ~1-2 s | **×4** | igual | ninguna |
| **D** · `capabilities()` (D-1..D-7, ×2 puertos) | ~10 | < 100 ms | igual | igual | ninguna |
| **E-1** · diente de letra del README | 1 | ~0 ms | igual | igual | ninguna |
| E-2 · diente ejecutable multi-tabla | 1-2 | ~200 ms | **×4** (SQL real) | igual | 2 tablas en `tests/helpers/schema.ts` |
| **TOTAL recomendado para alpha.4** | **~28** | **< 1 s** | **+ ~1 s ×4** | **+ ~4 s** | **1 helper + 1 stub + 2 tablas** |

### Veredictos

| punto | veredicto |
|---|---|
| 1 · defecto sin servidor | ✅ **verificable** — prototipado y **ejecutado hoy**, rojo literal capturado |
| 2 · contra el `:8101` | ✅ **verificable** — diseñado; **no ejecutado**: no hay servidor en `:8101`/`:8080` |
| 3 · los otros ocho | ✅ **verificable y barato** (9 casos, < 400 ms) — y destapa el 🔴 del barrel |
| 4 · `capabilities()` | 🟡 **verificable con cambios** — hay que decidir puerta 2 y copia/referencia antes de D-2/D-5 |
| 5 · README multi-tabla | 🟡 E-1 ✅ ya; E-2 **verificable con cambios** (fixtures nuevas) |

### Lo que pido al panel antes de que se escriba una línea de `tests/`
1. **Decidir el arreglo (A o B)** — el harness es neutral, pero C-5 y A-5 dependen de la elección.
2. **Decidir si `capabilities()` pasa por la puerta 2** y si devuelve copia o referencia (D-2, D-5).
3. **Confirmar que el 🔴 del barrel (0.3) entra en alpha.4**: es más grave que el defecto reportado
   —hoy `node ace` no arranca en un consumidor configurado por `configure.ts`— y su caso (C-1) cuesta
   un caso y 50 ms. No es mi decisión: la reporto al analista y al auditor.
