# Cierre 5 de D2 — brief del coordinador (2026-10-16)

Decisión del dueño §2026-10-16 (10): **opción A**. Contexto: `panel-optimo-juez.md`, `panel-optimo-auditor.md`, `panel-optimo-tester.md`, `panel-optimo-analista-global.md`, `loteD2-auditor-cierre4.md` (NO APTA: D4-1 🟠, D4-2/D4-3 🟡, D4-4/D4-5 ⚪). Árbol: D2 + cierres 1–4 SIN commit sobre `75353fe`. Antes de tocar nada, haz un respaldo tar de los ficheros modificados y nuevos en `.claude/respaldos/D2-pre-cierre5-<fecha>.tgz`.

## Orden de trabajo
### 1. Gate más barato PRIMERO (G1+G2+G3 del tester, sin tocar `src/`)
- `scripts/check_guard_mutants.mjs`: por mutante, correr SOLO los títulos de `expectRed` (Japa `--tests=<título>` exacto, medido 0,63 s/mutante) + `--jobs=N` (un directorio temporal por worker). Pasada completa disponible con una bandera (`--full`) para la nocturna.
- **Prueba de equivalencia, una vez**: los 181 mutantes en modo completo y filtrado dan el mismo veredicto; adjunta las dos salidas.
- G3: los mutantes de `tuple_order.ts`/`reconcile.ts` en una sola pierna de la matriz de CI. Objetivo: guard-mutants ≤ 3 min en local.

### 2. Opción A
- **`relate` en `openfga`**: se conserva el 409 `E_AUTHZ_RENEWAL_UNSAFE` con cero escrituras para una membresía portadora viva, `E_AUTHZ_RENEWAL_RACED`, la marca parcial y C2-4 (una portadora vencida no es 409). La **receta** del 409 se reescribe con honestidad: en `openfga` NO hay forma sin ventana; (1) patrón recomendado: membresías SIN caducidad en grupos con deny, que se terminan con `unrelate`; (2) aceptar la ventana explícitamente (`unrelate` + `relate`), dicho como tal; (3) causa: openfga/openfga#2151. Nunca presentar como segura una receta que reabre la ventana.
- **Reconcile**: fuera `relationWithheldWrites`, el residuo `withheld-by-unsafe-deny` y la negativa GLOBAL `carrier-conflict`. En su lugar: una partición con ≥ 1 `renewal-unsafe` o `deny-conditional` (deny que no se puede reescribir) recibe **CERO escrituras y cero borrados** (también sin `--prune`), se reporta como residuo de partición con sus causas y receta, y **el resto de particiones migra** (cierra D4-3). Se decide en el PLAN: `--dry-run` y la pasada real dan los mismos números. Exit ≠ 0 mientras exista. La línea dice qué partición, por qué, y que el destino de esa partición queda como estaba (con la deriva previa visible).
- Se conserva: `tuple_order.ts` (orden con renovaciones/vigencia/`shortening`, horizonte), `liveInDestination`, `expiredDelete`, streaming de `provision`, C2-5/C3-4 (marcas parciales de roles), `atomicRenewal` (capacidad D15: queda para cuando OpenFGA tenga upsert).
- **Fuerza bruta / oráculo**: (a) fuera la exclusión general `preexisting` (H2 del auditor): solo vale para particiones NEGADAS (cero escrituras ⇒ estado = inicial); para las demás, «ningún prefijo, ni el final, en ningún instante del horizonte, concede lo que ni el inicial ni el origen conceden», sin residuo silencioso; (b) el oráculo incluye objetos `group:` (D4-2); (c) el modo «dos Write» pasa a ser «negar la partición». Debe salir 0 sin residuo; si aparece algo, se declara.
- Casos literales del tester para los mutantes que solo morían por cifras: `order.c4.off` (contraejemplo U2 de una línea), `c4h.order.renewals-not-changing` (contraejemplo E3 de 8 tuplas; añade `walkVigencia` si hace falta), `c41.order.without-ignored` (precisión). Declara `order.priority.deletes-first` y `order.c2.no-exclusion` como equivalentes/precisión, con razón. Los mutantes del cierre 4 que sigan teniendo sentido tienen que estar en `guard_mutants.json`.
- D4-4 (letra de «orden SIN garantía» con renovaciones) y D4-5 (el contador de `purgeScope` de roles cuenta borrados hechos, no pedidos): son baratos, hazlos.

### 3. Del panel, dentro de este cierre
- **R2 🟠 (auditor del panel)**: la guarda D-31 compara modelo y config en TODOS los tipos de relación, no solo en los que tienen deny (`openfga_relations_driver.ts:~506-513`). Repro: `.claude/reproducciones/panel-optimo-auditor-model-drift.ts`. Caso + mutante.
- **Letra**: README con la sección del límite (cambiar la caducidad de una membresía portadora de deny en `openfga` = 409; patrón recomendado; TOCTOU de N1 declarado: un deny nuevo sobre un grupo durante la renovación de otra membresía de ese grupo tiene ventana; enlace a #2151; «cuando OpenFGA ofrezca upsert, `atomicRenewal` pasará a `true`»). Ninguna frase universal falsa. CHANGELOG bajo `[Unreleased]` (no tocar `[2.5.0-alpha.1]`).

## Reglas
- Implementador ÚNICO; sin commit, `npm version`, push ni sellado.
- Cada punto: caso que falla sin el arreglo + mutante medido. Cuatro líneas de cierre (gemelos, tabla de verdad, casos que se pusieron rojos, linaje L10).
- Ejecuta tú build, typecheck, las suites tocadas y el gate nuevo (nvm 22; `OPENFGA_TEST_URL=http://localhost:8090`; `TEST_PG_URL` con la contraseña de `postgres18`; `docker restart openfga-dev && sleep 8` antes de suites con OpenFGA).
- Informe: `.claude/contexto/loteD2-informe-cierre5.md` (por punto: qué, ficheros, casos, mutantes, cifras; líneas netas de src/tests eliminadas).
