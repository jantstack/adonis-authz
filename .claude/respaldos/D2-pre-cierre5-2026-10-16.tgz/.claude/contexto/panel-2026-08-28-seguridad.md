# Panel 28-08-2026 · Auditor de seguridad (modo rotura)

> Contra el código real de `@jantstack/adonis-authz` **1.1.0** (`252ea8c`).
> Suite base: **67/67 en verde** con `OPENFGA_TEST_URL=http://localhost:8101` — **con todos
> los hallazgos de abajo vivos**. Reproducciones ejecutadas en
> `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/repro_*.ts`
> (no se tocó ni un archivo del paquete).
> Códigos de ítem: A módulos · B `relations/` · C `catalog/` · D L0.1–L0.8 · E L1 · F L2 `http/` ·
> G L3 hooks · H L4 · I rechazos III.2 · J preguntas III.6.

## Veredicto en una línea

**Inseguro tal cual**: de los 8 defectos de D, 7 existen y 4 son fail-open o cruce de identidades
reproducibles hoy (uno de ellos con exploit ejecutable de principio a fin); además hay 7 defectos
presentes que el documento NO lista, y de los diseños nuevos B y E salen dos 🔴 estructurales que
ninguna de las correcciones L0 toca.

---

## 1. Verificación de D (L0.1 – L0.8)

| # | ¿Existe? | Severidad real | ¿La corrección cierra? |
|---|---|---|---|
| L0.1 `whereScopeIn([])` | ✅ sí, **no alcanzable hoy** | ⚪ latente | Sí, y es la correcta |
| L0.2 `holderTypes` no inyectivo | ✅ sí, **reproducido** | 🔴 | Sí, con un añadido (ver hueco) |
| L0.3 scope inexistente → `[app]` | ✅ sí, **reproducido (bypass de deny)** | 🔴 | Parcialmente |
| L0.4 re-grant borra `expiresAt` | ✅ sí, **reproducido** | Sí, pero **es breaking** (rompe 2 casos del juez) | 🟠 |
| L0.5 identidad divergente | ✅ sí, **peor de lo descrito** | 🟠 (🔴 según call-site) | Sí, si se clasifica 422 y vive en el manager |
| L0.6 `deny` no gobierna `hasRole` | ✅ sí, **reproducido** | 🔴 | **No** (deja el PEP publicado) |
| L0.7 truncamiento silencioso de denies | ✅ sí, **exploit ejecutable** | 🔴 | Sí para `listScopes`; deja `listUsers` y las purgas |
| L0.8 modelos escribibles | ✅ sí | 🟠 (sube de ⚪: habilita colisión de slugs) | Sí |

---

## 2. Hallazgos (ordenados por severidad)

### 🔴 D-L0.7 · `listScopes` devuelve como concedidos scopes con deny explícito (openfga)

- **Escenario**: sujeto `users:U` con ≥1000 tuplas `deny_binding` en el store (el tope de
  `ListObjects` **se consume con TODOS los denies del sujeto, de cualquier permiso y cualquier
  scope**: el filtro por permiso ocurre en JS, después de traer la lista) → el consumidor llama
  `listScopes(U, 'docs:read')` para pintar el índice departamental → recibe **30 organizaciones
  donde `authorize()` responde `false` por deny explícito**. Sin error, sin señal, sin log.
- **Evidencia**: ✅ ejecutado contra el OpenFGA de `:8101` (`repro_trunc7.ts`):

  ```
  denies devueltos / reales: "1000 / 10030"
  cuántas de las 30 orgs REALES aparecen en el ListObjects de denies: 0
  listScopes devuelve N scopes: 30
  scopes devueltos por listScopes con authorize=FALSE (fail-open): 30
  ```

  Código: `src/drivers/openfga_driver.ts:670-681` (denies) y `:632-640` (`listBindings`) —
  `client.listObjects()` sin `continuation_token`, sin `consistency`, sin comprobar
  `objects.length === max`.
- **Steelman**: *"`listScopes` no es un PDP; el README dice que se pregunte `authorize` sobre un
  scope concreto."* → **No me convence**: el contrato (invariante 7 + `types.ts:114-119`) promete
  literalmente "excluyendo los bloqueados por deny", el juez lo verifica
  (`contract.ts:232-247`) y el paquete lo publica como API. Un método que promete restar denies y
  no los resta es fail-open, se llame PDP o no. Además el mismo truncamiento afecta a `listRoles`
  y `listRoleScopes` (ahí en dirección cerrada, pero igual de silenciosa).
- **Mitigación mínima**: paginar con `continuation_token` **y** lanzar si el resultado alcanza el
  tope; mientras tanto, filtrar denies con `batchCheck` sobre los candidatos, no con `listObjects`.

### 🔴 D-L0.3 · Un resolutor de ancestros que no encuentra el scope tira el deny de la cadena

- **Escenario**: `resolveAncestors` del consumidor con el fallback natural
  `?? [APP_SCOPE]` (exactamente lo que hace el **default del propio paquete**,
  `database_driver.ts:52` y `openfga_driver.ts:362-363`) → `users:U` tiene `editor` a nivel `app`
  y un **deny de `docs:write` en `organization:B`** → se borra (o no se encuentra por timeout) la
  unit `unit:U1` de B → `authorize(U,'docs:write',{unit,U1})` pasa de `false` a **`true`**.
  Variante sin borrado: `authorize` sobre un **scope inventado por el atacante** también da `true`.
- **Evidencia**: ✅ `repro_db.ts`:

  ```
  authorize en unit REAL de orgB (deny visible): false
  authorize en la MISMA unit tras fallo del resolutor: true
  authorize en scope INVENTADO: true
  ```
- **Steelman**: *"el resolutor es del consumidor; si miente, es su culpa."* → **No me convence a
  medias**: el paquete **envía ese mismo fallback como default** y su tipo
  (`ScopeAncestorsResolver = (scope) => Promise<ScopeRef[]>`) no permite expresar "no existe".
  Un contrato que no tiene vocabulario para el caso peligroso lo está eligiendo por el consumidor.
- **Hueco de la corrección L0.3**: devolver `null` sigue siendo *opcional* — un resolutor que
  devuelve `[APP_SCOPE]` por defecto seguirá siendo legal y seguirá rompiendo. La corrección solo
  cierra si (a) el default del paquete para tipos ≠ `app` pasa a ser **lanzar** en vez de
  `[APP_SCOPE]`, y (b) el juez tiene un caso "resolutor que devuelve el fallback ⇒ `authorize`
  false, `grant` throw".
- **Mitigación mínima**: cambiar el default a "sin resolutor, cualquier scope ≠ `app` lanza en boot"
  y tipar el retorno como `ScopeRef[] | null`.

### 🔴 D-L0.6 · `deny` no gobierna `hasRole`, y el paquete publica un PEP indenegable

- **Escenario**: `users:U` con rol `editor` a nivel `app` y **deny de todos sus permisos** →
  `authorize` = `false` en todo → una ruta protegida con
  `middleware.appAccess({ role: 'superadmin' })` (`src/middleware/app_access_middleware.ts:57`)
  **sigue dejando pasar**. No existe forma de denegar a ese holder salvo revocar el rol.
- **Evidencia**: ✅ `repro_db.ts` (`authorize docs:read: false` / `hasRole editor: true`);
  `database_driver.ts:208-224` y `openfga_driver.ts:565-577` no consultan denies en ningún punto.
  El README lo contradice explícitamente en su línea 36 ("A deny anywhere in the scope chain blocks
  the permission").
- **Steelman**: *"`hasRole` es una pregunta de hecho, no de acceso: '¿tiene el rol?' se responde con
  la asignación."* → **Me convence como semántica y no me convence como producto**: si la respuesta
  es "es un hecho, no una decisión", entonces el paquete no puede envolver ese hecho en un
  middleware llamado `appAccess`. La corrección propuesta (documentar + deprecar) **no cierra
  nada**: mientras `appAccess({role})` siga exportado, hay un PEP indenegable publicado.
- **Mitigación mínima**: `appAccess({role})` lanza en boot (no "deprecado") o consulta denies del
  conjunto de permisos del rol; elegir una en 1.2, no en 2.0.

### 🔴 D-L0.2 · `holderTypes` no inyectivo funde dos holders en uno (invariante 4)

- **Escenario**: config `holderTypes: { users: 'user', integrations: 'user' }` (plausible: alguien
  quiere que las integraciones "sean usuarios" en FGA) → `grant(users:U, editor, app)` →
  `authorize(integrations:U, 'docs:read', app)` = **`true`**; `listSubjects` devuelve el morph
  **equivocado**; `revoke(integrations:U, …)` **borra la asignación de `users:U`**.
- **Evidencia**: ✅ `repro_fga.ts`:

  ```
  authorize users:U (concedido): true
  authorize integrations:U  <- invariante 4 violada: true
  listSubjects(editor, app): [{"type":"integrations", ...}]     ← miente el tipo
  authorize users:U tras revocar a integrations:U: false
  ```
  `openfga_driver.ts:103-114` (`fgaSubjectWith`) y `:612-614` (mapa inverso `fgaToMorph`, que
  colapsa). Nada valida el mapa: ni `defineConfig`, ni el provider, ni el constructor del driver.
- **Steelman**: *"es un error de configuración del consumidor."* → **No me convence**: el paquete
  publica el mapa como punto de extensión, genera el modelo FGA desde él
  (`openFgaAuthorizationModel` hace `new Set(Object.values(...))`, o sea **sabe** que hay colapso y
  lo ignora) y el error es silencioso y total. Una comprobación de inyectividad son tres líneas.
- **Hueco de la corrección**: verificar inyectividad en boot **no basta**. Nada compara el mapa con
  el que se usó para escribir el authorization model del store (`OpenFgaDriverOptions` solo lo
  documenta: "debe coincidir"). Añadir: leer el model del store en boot y comparar tipos.

### 🔴 B1 · `relations/`: un userset no lleva partición, así que "userset de otra partición → throw" no es implementable en el paquete

- **Escenario**: `UsersetRef = { object: {type,uuid}, relation }` (III.3.1). El consumidor
  (o un endpoint que acepte "compartir con este grupo") llama
  `relate({object:{type:'unit', uuid:U_de_orgB}, relation:'member'}, 'viewer', espacio_de_orgA,
  partition=orgA)` → el paquete conoce el tipo `unit` (declarado) y la partición del **objeto**
  (prefijada en su id), pero **no tiene ningún dato que le diga a qué partición pertenece `unit:U`**
  → la tupla se escribe → todos los miembros de una unit de la org B leen un espacio de la org A.
- **Evidencia**: 🟡 diseño. El documento promete el caso de contrato *"userset de otra partición →
  throw"* (III.3.2 y III.3.5) pero el único dato disponible es `{type,uuid}`: para resolver la
  partición hay que preguntarle al consumidor, y preguntarle al consumidor es exactamente el
  `scopeOf(tipo, uuid)` que III.2 **rechaza** por CRÍTICO. El diseño se contradice consigo mismo.
- **Steelman**: *"lo cierra `assertObjectInPartition`, el hook obligatorio."* → **No me convence**:
  ese hook valida el **objeto**, no el **sujeto-userset**. Son dos direcciones distintas; la fuga va
  por la que no tiene hook.
- **Mitigación mínima**: el id del userset se prefija con la partición igual que el del objeto
  (`unit:<partitionKey>|<uuid>#member`) y se rechaza cualquier userset cuyo prefijo no sea el de la
  partición de la operación. Si no, hace falta `assertSubjectInPartition` y entonces el rechazo de
  III.2 hay que reabrirlo.

### 🔴 E1 · `authorizedScopes → {kind:'all'}` es un bypass de deny en listados

- **Escenario**: `users:U` con `docs:read` a nivel `app` y **deny de `docs:read` en
  `organization:B`** → `authorizedScopes(U,'docs:read','organization')` devuelve `{kind:'all'}`
  (tiene el permiso en la raíz) → el consumidor ejecuta su CTE sin `WHERE` → **la org B aparece en
  el listado** aunque `authorize(U,'docs:read',orgB)` sea `false`.
- **Evidencia**: 🟡 diseño: la especificación de III.1/L1 define `all|some|none` y sus cotas
  (`maxScopes` lanza, sin `descendantsOf` lanza) pero **no dice una palabra sobre denies**.
  Que es una omisión real lo confirma el driver actual: `listScopes` sí resta denies
  (`database_driver.ts:343-360`), o sea que la primitiva "hermana" ya asume que hay que restarlos.
- **Steelman**: *"`all` significa 'no puedo acotarte por scope', y el filtrado fino lo hace
  `authorize` después."* → **No me convence**: si el consumidor tuviera que llamar `authorize` por
  fila, la primitiva no serviría para nada (nació para no hacer N llamadas).
- **Mitigación mínima**: `{kind:'all'}` **solo** es legítimo si el sujeto no tiene **ningún** deny
  de ese permiso; con al menos un deny, o se degrada a `{kind:'some'}` (que exige expandir los
  subárboles denegados con `descendantsOf`) o se lanza. Nunca `all` silencioso.

### 🟠 D-L0.5 · Identidad: `user:undefined` funde holders, y las dos implementaciones fallan al revés

- **Escenario**: un job/servicio construye `{type:'users', uuid: payload.userUuid}` con el campo
  ausente → driver `openfga`: `grant` **escribe `user:undefined`** y a partir de ahí **cualquier
  otro holder sin uuid hereda ese permiso**; driver `database`: la misma llamada **lanza 500**.
- **Evidencia**: ✅ `repro_undef.ts` y `repro_id.ts`:

  ```
  authorize del MISMO holder sin uuid: true
  authorize de OTRO holder sin uuid (colisión user:undefined): true
  listSubjects: [{"type":"users","uuid":"undefined"}]
  ```
  Tabla de divergencia medida (misma entrada, dos drivers):

  | entrada | `database` | `openfga` |
  |---|---|---|
  | `uuid: undefined` | `authorize`/`grant` → **500** | `authorize` false, **`grant` escribe `user:undefined`** |
  | `uuid: ''`, `'U1#assignee'`, `'a:b'` | **acepta y persiste** | `grant` → **503** (`AuthorizationBackendError`), `authorize` false |
  | `uuid: 'a b'` | **acepta y persiste** | `authorize` **503** |
  | `uuid: "x' OR '1'='1"` | **acepta y persiste**, `authorize` true | (503) |
  | `type` no declarado (`robots`) | `grant` **persiste una asignación muerta** | `grant`/`authorize` → **500** |
  | `deny` con holder no declarado | **acepta** | **500** |

  `fgaSubjectWith` (`openfga_driver.ts:103-114`) valida el *tipo* pero **no el uuid**;
  `assertScopeComponent` solo se aplica al scope. El driver `database` no valida nada
  (`database_driver.ts:96-128`).
- **Nota sobre el enunciado del documento**: "`uuid` con `#` → userset accidental en FGA" **no
  ocurre hoy** (los holder types se generan con `relations: {}`, así que FGA rechaza el write con
  400 → 503). Pero **pasará a ocurrir con `relations/` (B)**, donde los holder types sí tendrán
  relaciones declaradas: ahí `user:U#member` se convierte en un userset válido y el ataque es real.
  Conviene arreglarlo antes de B, no después.
- **Steelman**: *"nadie pasa un uuid undefined; el middleware ya lo comprueba."* → **No me
  convence**: el middleware lo comprueba (`app_access_middleware.ts:46-53`) precisamente porque
  alguien pensó que pasaría; los services y los jobs no tienen ese guard, y la clasificación de la
  entrada inválida como **503 "backend caído"** (openfga) manda a operaciones a buscar un incidente
  de infraestructura por un bug de programación.
- **Mitigación mínima**: `assertIdentityComponent` en el **manager** (una vez, no por driver),
  status **422**, con longitud máxima igual a la columna.

### 🟠 D-L0.4 · Re-grant sin opciones convierte un acceso temporal en permanente

- **Escenario**: `users:U` tiene `editor` con `expiresAt` a 60 s (acceso de emergencia) → cualquier
  código idempotente del tipo "asegúrate de que tiene el rol" llama `grant(U,'editor',scope)` **sin
  opciones** → `expires_at = NULL` → acceso permanente, sin evento distinguible en `onWrite`
  (`action:'granted'`, `expiresAt: null`).
- **Evidencia**: ✅ `repro_db.ts` (`expires_at tras grant temporal: 1787890198448` →
  `tras re-grant SIN opciones: null`). `database_driver.ts:137,152-155`; en `openfga`,
  `sameExpiry(stored, undefined)` → `false` → delete+write sin condition (`:498-521`).
- **Steelman**: *"está documentado: 'revivir una asignación expirada es un grant nuevo a todos los
  efectos' (comentario en `:150-151`)."* → **Me convence a medias**: es coherente para una
  asignación **ya expirada**, y peligroso para una **vigente**. La corrección L0.4 (`undefined` = no
  tocar) es la buena, pero hay que decir en voz alta que **rompe el juez actual**:
  `contract.ts:177-192` ("grant duplicado … y refresca expiresAt") y el caso openfga "quitar la
  expiración de una asignación que la tenía" **exigen hoy el comportamiento defectuoso**. → J.2.

### 🟠 D-L0.8 + N-slug · Los modelos exportados permiten insertar slugs que rompen el encoding de FGA y **levantan un deny**

- **Escenario**: alguien inserta un permiso `docs~read` fuera de `syncAuthzCatalog` (migración,
  seeder, o `AuthzPermission.create()` — el paquete lo exporta en `index.ts`) →
  `encodeSlug('docs:read') === 'docs~read'` → `removeDeny(U, 'docs~read', scope)` **borra el deny
  de `docs:read`**.
- **Evidencia**: ✅ `repro_fga.ts`:

  ```
  authorize docs:read con deny: false
  authorize docs:read tras removeDeny("docs~read"): true
  ```
  `encodeSlug`/`decodeSlug` (`openfga_driver.ts:49-54`) no son inyectivas; la única defensa es
  `assertValidSlug` en `catalog.ts:25-33`, que **los drivers no vuelven a aplicar** en
  `grant`/`deny`/`revoke`/`removeDeny`.
- **Steelman**: *"el catálogo se sincroniza con `syncAuthzCatalog`, que ya valida."* → **No me
  convence**: el paquete exporta los cinco modelos Lucid sin protección y publica un stub de
  migración; validar en un solo punto de entrada y confiar en que nadie use los otros es disciplina,
  no construcción — el mismo argumento que el paquete usa (bien) para envolver el cliente FGA
  entero en `guardBackendErrors` en vez de llamada por llamada.
- **Mitigación mínima**: `assertValidSlug` también en el driver, en `grant`/`deny` y en el camino de
  lectura de bindings; modelos exportados en solo lectura (L0.8).

### 🟠 N1 (→ H) · `syncAuthzCatalog` nunca retira un permiso de un rol: privilegio zombi tras editar el config

- **Escenario**: `editor` concede `docs:read` + `docs:write`; el equipo **quita `docs:write`** del
  rol en `config/app_acl.ts` y despliega → `authorize(U,'docs:write',app)` **sigue siendo `true`**,
  para siempre, en todos los entornos.
- **Evidencia**: ✅ `repro_db.ts` (`authorize docs:write TRAS el sync que lo quitó: true`);
  `catalog.ts:92-110` solo inserta. Tampoco actualiza `scope_type` (cambiarlo crea un rol NUEVO y
  deja el viejo con sus asignaciones vivas) y **silencia** los permisos de un rol que no estén en
  `catalog.permissions` (`:99` `if (!permUuid) continue`).
- **Steelman**: *"es aditivo por contrato, igual que el seeder original; la limpieza va por
  migración explícita."* → **No me convence para un paquete público**: "aditivo" es una decisión
  razonable para *crear*, pero aquí el efecto es que **la única fuente de verdad visible (el config)
  miente sobre los permisos efectivos**. El plan (H) responde con `authz:catalog:diff` que falla en
  CI: eso **detecta**, no corrige, y falla en CI *después* de que producción ya concede de más.
- **Mitigación mínima**: `syncAuthzCatalog(catalog, { prune: 'links' })` transaccional, y que el
  comando de diff sea el default en `configure`.

### 🟠 N2 · Un scope `{type:'app', uuid:X}` colapsa a la raíz global en `openfga` y no en `database`

- **Escenario**: un consumidor que use el tipo `app` con uuid (no hay nada que lo prohíba:
  `ScopeType = string`, y `APP_SCOPE_TYPE` es solo una constante) → `grant(U, rol, {app,'tenant-A'})`
  → `authorize(U, p, {app,'tenant-B'})` = **`true`**, y `authorize(U,p,APP_SCOPE)` = **`true`**:
  escalada de "tenant A" a **plataforma**. Con el driver `database`, las mismas llamadas dan `false`.
- **Evidencia**: ✅ `repro_fga.ts`:

  ```
  openfga:  {app,tenant-A}=true   {app,tenant-B}=true   APP_SCOPE=true
  database: {app,tenant-B}=false  APP_SCOPE=false
  ```
  `scopeKey()` (`openfga_driver.ts:84-89`) descarta el uuid en cuanto `type === 'app'`.
- **Steelman**: *"`app` es un nombre reservado; usarlo con uuid es un abuso."* → **Me convence como
  intención y no como implementación**: si es reservado, `grant`/`authorize` deben **lanzar** ante
  `{type:'app', uuid: !== null}`; descartar el uuid en silencio en un driver y respetarlo en el otro
  es la peor de las tres opciones. El juez no lo mira.

### 🟠 B2 · `purgeObject` / `purgeSubject` en `openfga` mienten en el conteo (mismo truncamiento)

- **Escenario**: se borra un `ia_space` con 1500 tuplas → `purgeObject` (que en FGA es
  `ListObjects`/`ListUsers` + `deleteTuples`) borra 1000, **devuelve 1000 y no lanza** → el
  `destroy()` del consumidor hace commit creyendo que purgó → quedan 500 tuplas huérfanas que
  siguen concediendo si el uuid se reutiliza o si el objeto se restaura.
- **Evidencia**: ✅ el mecanismo está reproducido arriba (D-L0.7: 1000/10030 sin señal);
  🟡 la aplicación a `purge*` es diseño. III.3.3 aplica `RelationsResultTruncatedError`
  **solo a `listObjects`**, no a las purgas ni a `listSubjects`.
- **Mitigación mínima**: las purgas iteran hasta agotar el token y **lanzan** si no pueden
  demostrar que quedaron a cero; nunca devuelven un número parcial.

### 🟠 B3 · Filtro por prefijo sin delimitador + `uuid: string` ⇒ cruce de particiones

- **Escenario**: partición A = `{organization, 'X'}` → prefijo `organization|X`; partición
  B = `{organization, 'XY'}` → objetos `ia_spaces:organization|XY|<uuid>`. Si el "filtro obligatorio
  al leer" (III.3.3) es `id.startsWith(partitionKey)` **sin el `|` final**, los objetos de B pasan
  el filtro de A. `ScopeRef.uuid` es `string` (J.3) y `assertScopeComponent` admite `[a-zA-Z0-9_.:-]`,
  así que `X` y `XY` son ambos legales.
- **Evidencia**: ✅ del regex y de `scopeKey` (`openfga_driver.ts:67-89`); 🟡 del filtro, que aún no
  existe.
- **Mitigación mínima**: comparar `id.startsWith(partitionKey + '|')` y, mejor, parsear en 3
  componentes y comparar por igualdad — nunca por prefijo.

### 🟠 C2 · `createTenantRole` permite **lavar un deny** vía un títere

- **Escenario**: el actor tiene `space.write` por rol pero un **deny** en su org → si
  `effectivePermissions(actor, scope)` (la que L1 define como prerrequisito de `catalog/`) **no
  resta denies**, el actor pasa el test `permissions ⊆ effectivePermissions(actor)`, crea un rol
  local con `space.write` y se lo asigna a una segunda identidad que controla (integración, usuario
  invitado) → ejecuta la acción denegada.
- **Evidencia**: 🟡 diseño. III.1/L1 define `effectivePermissions(subject, scope)` sin decir si
  resta denies; III.4/C define la policy en términos de esa función.
- **Steelman**: *"el deny es sobre el sujeto, no sobre el rol: el actor sigue denegado."* → **No me
  convence**: el objetivo de un deny es que la acción no ocurra bajo el control de ese actor, y la
  delegación es exactamente el camino que un deny debe cortar.
- **Mitigación mínima**: `effectivePermissions` resta denies por definición **y** `createTenantRole`
  exige que el actor no tenga deny de ninguno de los permisos que compone.

### 🟠 C3 + E3 · `memoizeAncestors` convierte una lectura obsoleta en un **grant cruzado persistido**

- **Escenario**: `unit:U1` se mueve de `organization:A` a `organization:B` durante la request →
  el memo (TTL 'request') sigue devolviendo `[org:A, app]` → la comprobación de contención de
  `catalog/` (`owner ∈ chain(scope) ∪ global`) y la de `within` (E) aprueban un **grant de un rol
  local de A sobre una unit que ya es de B** → la tupla queda escrita para siempre.
- **Evidencia**: 🟡 diseño (E define el memo; C define la contención sobre `chain`).
- **Steelman**: *"el TTL es de una request, la ventana es de milisegundos."* → **No me convence**:
  la ventana da igual cuando el efecto es una **escritura permanente**; una lectura obsoleta caduca
  sola, un grant no.
- **Mitigación mínima**: el memo se usa **solo** en el camino de lectura (`authorize`/`hasRole`);
  `grant`/`deny` y todo assert de contención resuelven ancestros en fresco.

### 🟠 E2 · `requireWithin = false` en 1.2 es seguridad opt-in

- **Escenario**: el equipo migra 20 de 30 call-sites a `grant(..., { within: orgScope })`; los 10
  restantes siguen concediendo un rol de tenant fuera de su cadena sin que nada lo note, y no hay
  forma de enumerar cuáles faltan.
- **Evidencia**: 🟡 diseño (III.1/L1: "`requireWithin` (false en 1.2, true en 2.0)").
- **Steelman**: *"no se puede romper a los consumidores en una minor."* → **Me convence la premisa
  y no la conclusión**: `requireWithin` puede ser **obligatorio de declarar** en el config
  (`requireWithin: true | false` sin default) — así el consumidor toma la decisión explícitamente en
  1.2 y el paquete puede listar en boot los tipos de scope sin contención.

### 🟠 G1 · El outbox `pdp_version` deja una ventana **fail-open** para `deny`

- **Escenario**: III.5 fija "`INCR` **antes** en revoke y **después** en grant". Un `deny` es una
  **restricción** que mecánicamente es un *write*: si se clasifica como "grant" (INCR después) y el
  proceso muere entre el write en FGA y el `INCR`, las cachés de claims siguen sirviendo
  **permitido** para un sujeto ya denegado, **sin límite de tiempo** (nadie va a re-incrementar).
- **Evidencia**: 🟡 diseño; el propio documento deja la salida entre paréntesis ("*o antes y después
  siempre*").
- **Mitigación mínima**: quitar el paréntesis: **antes y después siempre**, y clasificar por
  *dirección semántica* (restricción vs ampliación), no por verbo.

### 🟠 F1 · `gate(ctx)` sin contrato de error es un fail-open esperando

- **Escenario**: `gate` del consumidor lanza (BD lenta, membresía no cargada) o devuelve `undefined`
  → si el middleware hace `if (gate && !(await gate(ctx)))` o envuelve en `try/catch`, el resultado
  es "pasa".
- **Evidencia**: 🟡 diseño: III.1/L2 describe `gate(ctx)` como "opaco (membresía)" y no dice qué
  significa lanzar, devolver `undefined` o no declararlo.
- **Mitigación mínima**: `gate` devuelve `boolean` estricto; cualquier excepción se propaga (503/500),
  nunca se traduce; `undefined` es un error de programación, no un permiso.

### 🟡 N3 · La caída de la **base local** no produce `AuthorizationBackendError` en ningún driver

- **Escenario**: el catálogo vive en SQL para los dos drivers. Con la base caída,
  `authorize` lanza el error crudo del cliente SQL, **sin `status` y sin `code`** → el manejador de
  Adonis responde **500**, no 503, y el consumidor que quiera distinguir "backend caído" tiene que
  importar el error de Lucid — justo lo que `errors.ts` existe para evitar.
- **Evidencia**: ✅ `repro_dbdown3.ts`:

  ```
  openfga  authorize sin catálogo LANZÓ: SqliteError status=- esAuthorizationBackendError=false
  database authorize sin catálogo LANZÓ: SqliteError status=- esAuthorizationBackendError=false
  ```
  `database_driver.ts:77-79` y `openfga_driver.ts:396-398,415-427` consultan sin envolver.
  El README (línea 146) afirma lo contrario: *"The `database` driver has no equivalent failure"*.
- **Steelman**: *"si la base no está, la app entera está caída."* → **No me convence con el driver
  `openfga`**: ahí el diseño se vende como "los hechos viven fuera", pero el **catálogo** sigue
  siendo una dependencia dura de cada `authorize`, y su caída se presenta como bug de aplicación.
- No es fail-open (lanza), por eso 🟡. Pero rompe el invariante 5 tal y como está publicado.

### 🟡 N4 · `revoke` es un no-op silencioso si el rol ya no existe para ese `scope_type`

- **Escenario**: el catálogo cambia (el rol pasa de `organization` a `unit`, o se recrea) →
  `revoke(U,'org-editor',orgA)` **no borra nada, no lanza, devuelve void** → el operador cree que
  revocó; la asignación sigue concediendo.
- **Evidencia**: ✅ `repro_db.ts` (`asignaciones vivas tras revoke (sin error): 1`);
  `database_driver.ts:188-206`. Asimetría deliberada: `grant` lanza 422 ante el mismo desajuste.
- **Relevancia para C**: con roles locales, `revoke`/`listSubjects`/`hasRole` resuelven por
  **slug** y `grant` por otra vía; en cuanto `(slug, scope_type)` deje de ser único, "revoco lo que
  concedí" deja de estar garantizado. Resolver **siempre por uuid de rol** internamente.

### 🟡 C1 · Con roles locales, `hasRole(s, {slug, scopeType}, scope)` sigue sin discriminar dueño

- **Escenario**: L0.6 propone la forma `hasRole(s, {slug, scopeType}, scope)`. Con `catalog/`, la
  identidad externa del rol pasa a ser el **uuid** (III.4), pero el PEP sigue preguntando por slug →
  dos tenants con `admin` local + el `admin` global responden a la misma pregunta.
  Hoy `database_driver.ts:212-213` ni siquiera filtra `r.scope_type` en `hasRole`.
- **Evidencia**: ✅ del código actual; 🟡 de la interacción con C.
- **Mitigación mínima**: la forma nueva es `{ uuid }` o `{ slug, scopeType, owner }`; nunca solo slug.

### 🟡 B6 · Renovar por `delete+write`: si falla el segundo paso el sujeto queda **sin** acceso y la auditoría dice que se renovó

- **Escenario**: III.3.3 dice "si falla el segundo paso, `relate` **lanza**" — correcto (fail-closed),
  pero el hook `onRelationWrite` del manager actual se dispara **después** de la escritura y **se
  traga los fallos** (`manager.ts:114-120`). Si el mismo patrón se replica, el log dirá "renovado"
  sobre un acceso que se acaba de borrar.
- **Mitigación mínima**: emitir el evento con la acción real (`'expired'`/`'revoked_by_failure'`) o
  emitirlo solo tras el write con éxito.

### 🟡 F2/F3 · `resourceAccess`: el assert de tenant depende del mismo resolutor, y 404-vs-404 debe ser indistinguible de verdad

- `tenantScope ∈ chain(scope)` usa `resolveAncestors`: con el fallback de D-L0.3, la contención de
  tenant se evalúa contra una cadena inventada. El assert debe usar el resolutor **estricto**
  (el que lanza), no el de lectura.
- Si el resolutor o la base fallan durante el assert, el resultado **no puede ser 404**
  (fail-closed que oculta la caída y engaña al cliente): debe ser 503. El documento ya lo dice para
  `AuthorizationBackendError`; hay que extenderlo al **fallo del resolutor**.
- 404-tenant y 404-recurso deben compartir cuerpo **y** perfil de tiempo; si el 404-tenant se emite
  antes de cargar el recurso y el 404-recurso después, la diferencia de latencia es un oráculo de
  existencia entre tenants. ⚪ por sí solo, 🟡 combinado con enumeración de uuids.

### ⚪ D-L0.1 · `whereScopeIn([])` — real, pero **hoy inalcanzable**

- **Evidencia**: ✅ SQL generado (`repro_db.ts`):

  ```
  scopes=[]   : select * from `authz_assignments` where `holder_type` = 'users'   ← sin filtro de scope
  scopes=[app]: ... and ((`scope_type` = 'app' and `scope_uuid` = '000...'))
  ```
  Los cuatro call-sites pasan `[scope]` o `chain(scope)` (siempre ≥ 1 elemento), así que no es
  explotable en 1.1.0. La corrección (`whereRaw('1 = 0')`) es la correcta y **debe hacerse antes**
  de `descendantsOf`/`authorizedScopes`, que es lo que la volvería alcanzable. Nótese la asimetría
  que la hace peligrosa: en la consulta de denies un conjunto vacío **sobre-bloquea** (fail-closed),
  en la de asignaciones **concede en cualquier scope** (fail-open).

### ⚪ N5 · No existe purga de scope en `roles/`

Borrar una organization deja sus `authz_assignments`/`authz_denies` (sin FK: el scope es polimórfico)
y sus `role_binding`/`deny_binding` en FGA (sin FK ninguna) vivos indefinidamente. Combinado con
D-L0.3 (un scope inexistente resuelve a `[app]`) y con reutilización de uuid, un scope "borrado"
sigue teniendo titulares. El plan trae `purgeObject`/`purgeSubject` para **`relations/`** y
`purgeRole` para **`catalog/`**, pero nada para `roles/`. Es el hueco más obvio entre lo aceptado y
lo rechazado en I.

### ⚪ N6 · Ninguna llamada al backend tiene deadline

Durante las pruebas, `authorize` con el pool de la base cerrado **se quedó colgado indefinidamente**
(el script hubo de matarse a los 2 minutos) en vez de fallar. `AuthorizationBackendError` cubre los
*errores*, no los *cuelgues*: un backend lento convierte cada request autorizada en un socket
retenido. Un `timeout` configurable (y un caso de contrato "backend que no responde en N ms ⇒ 503")
cierra el tercer estado de verdad.

### ⚪ N7 · `batchCheckAll` correlaciona por **orden** y descarta `.request`

`openfga_driver.ts:379-392` comprueba la cardinalidad pero ignora el `correlation_id`/`request` de
cada resultado. Hoy es inocuo porque todos los consumidores usan `.some()`. En el momento en que
exista `authorizeMany(subject, permission, scopes[])` (E), un resultado mal atribuido es un
`true` en el scope equivocado. Arreglarlo **antes** de E, no después.

---

## 3. Lo que intenté y NO se rompió

- **Inyección SQL** por `subject.uuid`/`scope.uuid`/slug en el driver `database`: todo va
  parametrizado por knex; `"x' OR '1'='1"` se almacena y se compara como literal (se persiste, que es
  otro problema — D-L0.5 — pero no inyecta).
- **Confusión de claves de binding en FGA por el separador `|`**: `assertScopeComponent`
  (`openfga_driver.ts:67-77`) hace `scopeKey` inyectiva mientras ni el tipo ni el uuid contengan
  `|`/`~`. No conseguí que `{org,'anization|X'}` y `{'org|anization','X'}` colisionaran: lanza.
- **Fail-open del deny por error puntual en FGA**: `denyResults.some(r => r.allowed || r.error)`
  (`:447`) es correcto — un check de deny que falla deniega. Lo intenté con uuids inválidos
  (`a b`, `#`, `:`) y siempre salió `false` o 503, nunca `true`.
- **Cadena con scope duplicado** (resolutor que devuelve el propio scope): `batchCheck` responde
  1:1 y `authorize` funciona en ambos drivers. No hubo mismatch de cardinalidad ni 500.
- **`uuid` con distinta capitalización**: no cruza en ninguno de los dos drivers (`false` en ambos).
- **`hasRole`/`authorize` con rol o permiso inexistente**: `false` sin throw, como promete el
  invariante 5.
- **`guardBackendErrors`**: no logré que se escapara un `FgaError` del SDK por ninguna de las once
  rutas del driver (el Proxy envuelve el cliente entero, incluidos los métodos añadidos después).
  La fuga está en el **otro** backend: el catálogo SQL (N3).
- **Idempotencia de `deny`/`removeDeny`/`revoke`**: re-ejecutar no duplica ni lanza.
- **`APP_SCOPE_DB_UUID` como colisión**: un scope real con el uuid nil no colisiona con `app`
  porque el tipo discrimina.

---

## 4. Evaluación de I (los rechazos de III.2)

| Rechazo | ¿Correcto desde seguridad? |
|---|---|
| `resourceScopes` / `scopeOf(tipo,uuid)` en el motor | ✅ **Sí**, y por la razón correcta: un lookup ciego al tenant es cruce de tenants **y** oráculo de existencia. |
| Carga de recursos por el paquete | ✅ Sí: el paquete no debe saber qué es un "recurso". |
| "Membresía"/"tenant" como conceptos del paquete (entran como `gate()` y `within`) | ✅ Sí, con la reserva F1 (`gate` necesita contrato de error) y E2 (`within` opt-in no es contención). |
| `descendantsOf` implementado por el paquete sobre `parentOf` | ✅ Sí: sería N+1 no acotado y una cota que trunca es fail-open. |
| `permission.grantableAt` en la **evaluación** | ✅ Sí: añadir una segunda dimensión a `authorize` multiplica los caminos de fallo; como control de composición (H) está bien. |
| Middleware de `roles/` consultando `relations/` | ✅ Sí: es exactamente la fuga que el módulo A existe para impedir. |
| `from`/ABAC en v1 | ✅ Sí. |
| Deny con caducidad en 1.2 | ✅ Sí: un deny que caduca es un fail-open por reloj; mejor no tenerlo que tenerlo a medias. |
| `beforeWrite` unificado | ⚠️ **Rechazo nominal**: `assertWrite(event)` (aceptado en G) es un `beforeWrite` con otro nombre. No es un problema de seguridad, pero el documento cuenta como "rechazado" algo que entra por la puerta de al lado — y `assertWrite` **puro** no puede verificar contención (necesita datos), así que da menos garantía de la que aparenta (G3). |
| `onWrite` transaccional | ⚠️ Rechazado, y a la vez se acepta `onWriteInTrx` **solo para `database`** (G2). Eso crea una API que depende del driver, lo que contradice la regla del propio `CLAUDE.md` ("un cambio de driver es migración de hechos, no reescritura"). Es un coste legítimo, pero hay que declararlo como **decisión mayor**, no como detalle de hooks. |

**¿Faltó rechazar algo?** No. **¿Faltó aceptar algo necesario?** Sí: **`purgeScope(scope)` en
`roles/`** (N5). Hoy borrar un tenant no borra sus grants en ningún driver y en FGA no hay FK que lo
recoja nunca.

---

## 5. Postura sobre J (las 8 preguntas de III.6)

1. **¿Segundo consumidor?** Irrelevante para la seguridad. **L0 se hace igual** — y de L0, el orden
   por riesgo medido es **L0.7 → L0.3 → L0.6 → L0.2 → L0.5 → L0.4 → L0.8 → L0.1**, no el del
   documento.
2. **¿1.2 puede ser breaking?** Desde seguridad, **tiene que serlo** o hay que renumerar a 2.0:
   L0.4 **rompe dos casos del juez actual** (`contract.ts:177-192` y el caso openfga "quitar la
   expiración"), que hoy **exigen el comportamiento defectuoso**. Publicar la corrección sin
   reconocer la ruptura deja a los consumidores con dos semánticas de `grant` según la versión
   parcheada. Alternativa aceptable: `grant` gana `expiresAt?: Date | null | undefined` con
   `undefined` = no tocar **y** un flag de compat `legacyGrantClearsExpiry` que sale en 2.0.
3. **`ScopeRef.uuid`: ¿uuid o string?** → **String, pero validado por gramática y longitud**, no
   "uuid RFC". Razones medidas: (a) la injectividad de `scopeKey` (y del futuro prefijo de partición
   de B) depende de una gramática, no de que sea un uuid; (b) hoy **SQLite acepta `"x' OR '1'='1"`
   en una columna declarada `uuid`** (reproducido) mientras **Postgres lanzaría `22P02` en la propia
   lectura** → el mismo `authorize` responde `false` en un motor y **500 en otro**: eso sí es una
   respuesta a "¿puede `authorize` dar 500 en lectura?" — **hoy puede, y depende del motor**. Si se
   mantiene `string`, el stub debe declarar `varchar(64)` (no `uuid`) y el paquete validar en el
   manager; si se mantiene la columna `uuid`, hay que dejar de anunciar SQLite/MySQL como
   equivalentes. Lo que no se puede es seguir con las dos cosas a la vez.
4. **¿"Un solo juez para los dos drivers"?** **Sí, pero con capacidades declaradas — no bifurcado.**
   Un contrato bifurcado por driver deja que cada driver se autoexima justo de lo que importa. La
   forma: el driver declara `capabilities: { transactions, denyExpiry, exhaustiveLists }` y el juez
   verifica **las dos ramas**: con la capacidad, el comportamiento; sin ella, que la API
   correspondiente **lance** (nunca que devuelva un resultado degradado en silencio). Y el juez
   actual necesita **un bloque de identidad y clasificación de errores** que hoy no tiene: no hay un
   solo caso con `uuid` vacío/`undefined`, holder no declarado, `{app, uuid}`, ni base local caída —
   los seis hallazgos de esta auditoría que son puras divergencias entre drivers pasan por debajo
   de 67 tests verdes.
5. **¿CI con segundo OpenFGA (`--listObjectsMaxResults` pequeño)?** **Sí, bloqueante.** Es el único
   caso de esta auditoría que necesitó 10.000 tuplas para verse; con `--listObjectsMaxResults=5`
   cabe en un test de dos segundos. Sin él, L0.7 se "corrige" sin prueba de que quedó corregido.
6. **¿`assertWrite` obligatorio con recursos o roles locales?** **Sí, y fail-closed**: si el
   consumidor declara particiones/roles locales y no registra `assertWrite`, el paquete debe
   negarse a arrancar. Un hook de seguridad opcional es un hook que no está en producción.
   Con la reserva de G3: puro ⇒ no puede validar contención; la contención va en el driver.
7. **¿El README promete algo que el código no hace?** **Sí, tres cosas, todas verificadas**:
   línea 36 ("a deny anywhere in the chain blocks the permission") es **falsa para `hasRole`** y por
   tanto para `appAccess({role})`, que el propio paquete publica (D-L0.6);
   línea 38 ("two holders with the same uuid and different type never cross") es **falsa con un
   `holderTypes` no inyectivo**, que nada valida (D-L0.2);
   línea 146 ("the `database` driver has no equivalent failure") es **falsa**: con la base caída
   ninguno de los dos drivers produce `AuthorizationBackendError` (N3). Añadir: `listScopes` no
   cumple "sin los denegados" bajo truncamiento (D-L0.7).
8. **¿`grantableAt` reservando un permiso a un nivel?** Desde seguridad: **no en la evaluación**
   (el rechazo de III.2 es correcto); como control de **composición** en `catalog/` sí, con la nota
   del README de que **no es una barrera** — un rol que ya lo tiene sigue concediéndolo hacia abajo.

---

## 6. Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿`appAccess({ role })` se retira en 1.2 o sigue publicado hasta 2.0?** Si sigue publicado, el
   veredicto de D-L0.6 no baja de 🔴 por mucho que se documente: el paquete distribuye un punto de
   enforcement que un deny no puede parar.
2. **¿El default de `resolveAncestors` (`scope ≠ app ⇒ [APP_SCOPE]`) desaparece en 1.2?** Mientras
   exista, L0.3 sigue vivo aunque se añada `UnknownScopeError`, porque el camino peligroso sigue
   siendo el camino por defecto.
3. **B1: ¿cómo se determina la partición de un `UsersetRef` sin preguntarle al consumidor?** Si la
   respuesta es "prefijando también el id del userset", el diseño es implementable; si es "un hook
   del consumidor", hay que reabrir el rechazo de `scopeOf` en III.2. Sin respuesta, `relations/` no
   es auditable.
4. **E1: ¿qué devuelve `authorizedScopes` cuando hay al menos un deny?** De esto depende que la
   primitiva sea utilizable o sea un bypass de deny con nombre bonito.
5. **¿Se acepta que L0.4 rompe el juez actual (y con él la compatibilidad de `grant`)?** Es la
   pregunta que decide si 1.2 existe o si esto es 2.0.

---

## 7. Tabla de cierre

| Ítem | Hallazgo más grave | ¿El diseño tal cual es aceptable? |
|---|---|---|
| **A** módulos | Frontera `roles`/`relations` correcta por construcción; el riesgo no está en la separación sino en que ambos dependen del **mismo resolutor mentiroso** y del **mismo catálogo SQL sin clasificar errores** (N3) | ✅ **Sí**, con N3 corregido |
| **B** `relations/` | 🔴 **B1**: un `UsersetRef` no lleva partición ⇒ "userset de otra partición → throw" no es implementable sin reabrir el rechazo de `scopeOf`; + 🟠 B2 purgas truncadas, 🟠 B3 prefijo sin delimitador | ❌ **No** hasta responder B1 |
| **C** `catalog/` | 🟠 **C2** lavado de deny vía `createTenantRole` + títere; 🟠 C3 grant cruzado por memo obsoleto; 🟡 C1 PEP por slug con roles homónimos | ⚠️ **Con reservas**: exige `effectivePermissions` que reste denies y resolución por uuid |
| **D** L0.1–L0.8 | 🔴 **L0.7** reproducido de punta a punta (30 scopes denegados devueltos como concedidos); 7 de 8 defectos confirmados + 7 no listados | ⚠️ El lote es **correcto pero incompleto**: no cubre N1, N2, N3, N5, N6, N7 y **no cierra** L0.6 |
| **E** L1 primitivas | 🔴 **E1** `{kind:'all'}` ignora denies; 🟠 E2 `requireWithin=false`; 🟠 E3 memo en el camino de escritura | ❌ **No** sin definir la interacción `all` × deny |
| **F** L2 `http/` | 🟠 **F1** `gate()` sin contrato de error; 🟡 F2 el assert de tenant usa el resolutor laxo; 🟡 F3 oráculo por temporización | ⚠️ **Con reservas** (bien encaminado: `tenantParam` obligatorio y 404 son las decisiones correctas) |
| **G** L3 hooks | 🟠 **G1** outbox con `INCR` solo-después aplicado a `deny` = fail-open sin caducidad; 🟡 G2 API dependiente del driver | ⚠️ **Con reservas**: "antes y después siempre" deja de ser paréntesis |
| **H** L4 | 🟠 **N1**: el sync nunca retira vínculos ⇒ quitar un permiso del config no lo quita de producción; el diff en CI detecta tarde | ❌ **No**: hace falta `prune` transaccional, no solo un detector |
| **I** rechazos III.2 | Los 8 rechazos son correctos desde seguridad; dos son **nominales** (`beforeWrite`≈`assertWrite`, `onWrite` transaccional ≈ `onWriteInTrx` asimétrico) y **falta aceptar `purgeScope` en `roles/`** (N5) | ✅ **Sí**, añadiendo N5 |
| **J** preguntas | La que decide todo es la **2** (¿1.2 breaking?): L0.4 rompe el juez actual. La **3** se responde con datos: hoy `authorize` **ya puede dar 500** y depende del motor SQL. La **4**: un solo juez, con **capacidades declaradas** y un bloque de identidad que hoy no existe | ⚠️ Ver §5 |
