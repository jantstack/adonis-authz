# Fase 3b · Lotes 3b-0b + 3b-1 — verificación del tester de contrato

> Worktree aislado en `34e78ed` (detached). Node 22.23.2 · OpenFGA `:8101` (v1.19.0) · PostgreSQL 18
> (`postgres18`) · MySQL 8.4 (`mysql84`) · tope 3 en `openfga-tiny-tester3b1` `:8153` (**creado y
> borrado**; `:8101` y el `openfga-tiny` de CI no se tocaron).
> Alcance: `git diff 2613916..34e78ed` = 3b-0b (AA1–AA4, AB1–AB4, AC1–AC3) + 3b-1 (D1–D3, T-3b 1–9,
> M13, M14, ⚪3, ⚪4).
> Parche: `.claude/contexto/tests-tester-fase-3b1.patch` (122 líneas, **solo `tests/`, solo
> adiciones**).

## Veredicto: **APTA CON CORRECCIONES**

Los dos lotes están bien vigilados. **21 de los 24 mutantes que apliqué mueren**, incluidos los
cinco que el encargo pedía por pieza en 3b-0b y los ocho de 3b-1. Dos de los supervivientes son
mutantes **equivalentes** demostrados (§4). Los tres huecos reales que quedan son de *observación*,
no de comportamiento, y los cierro en el parche.

Las dos correcciones que **no** puedo cerrar con un test son de honestidad, y tocan el lote cuyo
título es «honestidad»: el CHANGELOG del 3b-1 abre con «**no behaviour change in `src/`**» y tres
bullets más abajo describe el cambio de comportamiento del diff, que puede volver rojo un
`authz:catalog:diff --fail-on-shadows` que ayer salía verde (§6.1). Y el CHANGELOG del 3b-0b
justifica `purged: CatalogRoleRef[]` con «whoever catches the error needs to know **which** roles
went» — y el error no los lleva (§6.2, medido).

Ninguna de las dos es un fallo de comportamiento. Por la regla de parada: **a 3b-2, no bloquea**.

---

## 1. Suites (punto 1) — las seis corridas verdes, con los conteos esperados

Árbol limpio de `34e78ed`, sin `skip` ni `only` (`grep` = 0 fuera de comentarios y de
`skipIfNoop`/`skipLibCheck`):

| Modo | Esperado | Medido | Con el parche |
|---|---|---|---|
| `npm test` (SQLite memoria, sin FGA) | 432 | **432 passed** | **434 passed** |
| `OPENFGA_TEST_URL=:8101 npm test` | 534 | **534 passed** | **536 passed** |
| `test:sqlite-file` + `:8101` | 536 | **536 passed** | **538 passed** |
| `test:pg` + `:8101` | 702 | **702 passed** | **704 passed** |
| `test:mysql` + `:8101` | 702 | **702 passed** | **704 passed** |
| Tope 3 (`:8153`, `LIST_*_MAX_RESULTS=3`, memoria) | 534 | **534 passed** | **536 passed** |
| `npm run typecheck` · `check:purity` | verde | **verde** | **verde** |

**Residuos: 0.** `select datname … like 'authz\_test%'` en PostgreSQL ⇒ vacío; `show databases like
'authz\_test%'` en MySQL ⇒ vacío; `/tmp` sin directorios del harness. Contenedor `:8153` borrado.
La única base huérfana de toda la sesión la dejó **a propósito** el mutante MU17 (guard de salida
desactivado) y la borré a mano — es precisamente lo que ese caso demuestra.

Confirmo además la fuga ⚪4 del 3b-0b como **cerrada**: seis corridas completas de motor y ninguna
base sobrante.

---

## 2. Mutantes (punto 2) — 24 aplicados, uno a uno

Cada mutante = una edición mínima + suite completa; «muere» = al menos un caso rojo. Salvo nota, el
modo es SQLite en memoria (el más barato) y el mutante muere **ahí**, sin necesidad de motor ni FGA.

### 3b-0b

| # | Mutante | Resultado | Quién lo mata |
|---|---|---|---|
| MU1 | `assignments` siempre 0 (⇒ `stillGranting` siempre `false`) | ✅ muere (4) | `catalog_cache.spec` (AA1/AB2), `manager.spec` AA1, y 2 más |
| MU1b | `assignments` cuenta también las **caducadas** (fuera el filtro de vigencia) | ✅ muere (1) | `catalog_cache.spec` AA1/AB2 |
| MU2a | la cota de purga masiva **nunca se dispara** (`massPurge = false`) | ✅ muere (5) | juez `contract.ts:2681` ×2 + AA2 + Z2 + Z3 |
| MU2b | la cota se dispara **con ratio bajo** (`massPurge = orphans.length > 0`) | ✅ muere (2) | AA2 («1 de 3 purga sin bandera») + AA3 |
| MU2c | `allowMassPurge` **no levanta** la cota | ✅ muere (5) | juez ×2 + AA2 + Z2 + Z3 |
| MU3 | **sin** re-resolución del owner antes de `purgeRole` (TOCTOU abierto) | ✅ muere (1) | AA3 |
| MU3b | la re-resolución usa el resolutor de la lectura en vez de uno «fresco» | 🟢 **equivalente** | §4 |
| MU4 | `maxLocalRoles` **trunca en silencio** (`limit(max)`, sin 500) | ✅ muere (1) | `catalog_cache.spec` AA1/AB2 |
| MU5 | `purged` incluye también los **saltados** | ✅ muere (1) | AA3 |
| MU5b | `purged` se apunta **antes** de que `purgeRole` confirme | 🔴 **SOBREVIVE** | → §6.2 (el parche lo cierra por el otro lado) |

### 3b-1

| # | Mutante | Resultado | Quién lo mata |
|---|---|---|---|
| MU6 | **D1**: el dueño del árbol SÍ puede ensombrecer un rank mayor (`#assertAboveShadowed` no lanza) | ✅ muere (4) | D1 + D2 + 3G · W3 + juez «composición 3G · W4 iii» |
| MU7 | **D2**: `#shadowedBelow` **rechaza** en la ventana (`chain === null` ⇒ sombra) | ✅ muere (2) | **D2** (el `define` debe seguir entrando) + 3b-0 · Z3 |
| MU8 | **D3**: `scopes.moved` **juzga** el catálogo antes de mover | ✅ muere (3) | D3 + 3E · R3 + 3F · U4 |
| MU9a | el diff toma `shadowedByGlobal` **solo del catálogo #1** | ✅ muere (1) | T-3b §6.1/§6.3 |
| MU9b | ídem con `shadowedByAncestor` | 🟢 **equivalente** | §4 |
| MU10 | `shadowedByAncestor` vuelve a **una línea por pareja** | ✅ muere (1) | T-3b §6.1/§6.3 |
| MU10b | nombra al ensombrecedor **menos** autorizado (orden invertido) | ✅ muere (1) | T-3b §6.1/§6.3 |
| MU11 | `lockCatalogForWrite` **sin** `FOR UPDATE` (**PG**) | ✅ muere (3) | **T2** (oráculo nuevo) + 3E · Q5 + juez |
| MU12 | **T4**: el hook `onWrite` lee el **memo** de `forRequest()` en vez de resolver en fresco | 🔴 **SOBREVIVE** | → §5.1 (**cerrado por el parche**) |
| MU13 | `sync.role.locals`: **una consulta por rol** del spec en vez de una en lote | ✅ muere (1) | T-3b 6 (oráculo nuevo) |
| MU14 | **M13**: el **driver** deja de canonizar en `purgeScope` | ✅ muere (1 en sqlite; **2 en PG**) | `database_driver.spec` M13 en los 4 modos + juez «árbol SQL» |
| MU15 | **M14**: `descendantsFrom` responde `[]` a un scope desconocido | ✅ muere (1) | `scope_tree.spec` M14 |
| MU16 | **⚪3**: el 500 `E_AUTHZ_UNSUPPORTED` de `pruneOrphanRoles` solo con `--force` | ✅ muere (1) **sin `:8101`** | el caso «driver sin `purgeRole`» |
| MU17 | **⚪4**: el guard `process.on('exit')` de `bootApp` desactivado (**PG**) | ✅ muere (1) | `harness_cleanup.spec` ⚪4 |
| MU18 | `drop_database.mjs` **sin** la comprobación del nombre `_<8 hex>` | 🔴 **SOBREVIVE** | → §5.2 (**cerrado por el parche**) |
| MU19 | `--fail-on-shadows` deja de contar como deriva | ✅ muere (1) | 3D · M2 d + 3F · S3 |
| MU20 | `role_purged` se notifica **antes** de purgar | ✅ muere (1) | caso nuevo del parche (§5.3) |

---

## 3. La pregunta específica (punto 3): ¿el único cambio de comportamiento del 3b-1 es el del diff?

**Sí, verificado por dos vías independientes.**

**(a) Estática, sobre el diff `6bdf946..34e78ed`.** El código publicado que cambia es
`src/catalog.ts`, `src/manager.ts` y `src/testing/contract.ts` (109 +, 15 −). Filtrando comentarios
y docblocks:

- `src/manager.ts`: **cero** líneas de código. Todo el delta son docblocks
  (`#assertLevelUnderOwner`, `scopes.moved`, `#shadowedBelow`, `#assertAboveShadowed`). Comprobado
  con `git diff … -- src/manager.ts | grep '^[+-]' | grep -v '^[+-]\s*\*'` ⇒ salida vacía.
- `src/testing/contract.ts`: 14 líneas, **todas aserciones** dentro del caso del alias (M13). Ni un
  caso nuevo, ni un cambio de la siembra.
- `src/catalog.ts`: el único código. Toca `classifyHomonyms`, `formatShadowedRoles` y
  `runCatalogDiff`. Alcanzabilidad comprobada: `classifyHomonyms` solo la llama `diffAuthzCatalog`
  (`catalog.ts:628`), y `diffAuthzCatalog`/`runCatalogDiff`/`formatShadowedRoles` solo se usan desde
  `index.ts` (exportación) y `commands/authz_catalog_diff.ts`. **Nada del camino de `authorize` ni
  de las escrituras pasa por ahí.**

**(b) Diferencial ejecutada.** Revertí **todo** el código publicado a `6bdf946`
(`git checkout 6bdf946 -- src/ commands/ index.ts`) y corrí la suite de `34e78ed`:

| Corrida | Resultado con `src/` de `6bdf946` |
|---|---|
| `npm test` | **431 passed, 1 failed (432)** |
| `test:pg` + `:8101` | **701 passed, 1 failed (702)** |

El **único** caso rojo, en los dos motores, es
`catálogo / 3b-1 · T-3b … runCatalogDiff acumula las sombras de TODOS los catálogos`. Los casos del
juez, los de `authorize`, `grant`/`revoke`/`deny`, la delegación, el memo y los espías de coste pasan
**idénticos** contra el `src/` de `6bdf946`. La afirmación del implementador se sostiene.

**Matiz que sí hay que anotar** (§6.1): «solo cambia el diff» no es lo mismo que «solo cambia lo que
se imprime». `runCatalogDiff` decide el `inSync` que el comando convierte en **exit code**, y con
`--fail-on-shadows` una sombra causada por el catálogo #2 antes no salía y hoy pone el gate en rojo.
Es un cambio de comportamiento de una herramienta de CI, y el CHANGELOG lo tapa con un titular.

---

## 4. Los dos supervivientes que NO son huecos (mutantes equivalentes)

**MU3b — `resolveChain(resolver, …)` en vez de `resolveChain(this.#freshResolver(), …)` en el
re-chequeo de AA3.** `#freshResolver()` es `return this.#config.scopes?.resolveChain ?? rootOnlyResolver`
(`manager.ts:483`): **no envuelve nada**, no memoiza. La constante `resolver` de la línea 1199 es
literalmente el mismo objeto. Lo que sí importa —y el mutante MU3 demuestra— es no reutilizar el
`Map resolved` de la primera pasada, y eso el código lo hace bien. La palabra «FRESCO» del docblock
describe la intención, no una diferencia observable: **no hay hueco**.

**MU9b — acumular `shadowedByAncestor` solo del catálogo #1.** `diff.shadowedByAncestor` sale
íntegro de `classifyHomonyms(sql, options.resolveChain)`, que lee `authz_roles` y el árbol y **no
mira el spec** (a diferencia de `shadowedByGlobal`, que tiene la rama spec-dependiente de
`catalog.ts:620`). Como `runCatalogDiff` no escribe entre iteraciones, el índice 0 y la unión de
todos dan siempre lo mismo. La mitad `shadowedByAncestor` del bucle de acumulación es código muerto
respecto a lo observable; el comentario del código ya lo dice («una fuente DEPENDIENTE del spec»),
así que es honesto. **No hay hueco**, pero tampoco hay nada que verificar ahí: si alguien lo
«simplifica» a índice 0, la suite no se enterará y no debería.

---

## 5. Huecos reales cerrados por el parche

### 5.1 T4 — el oráculo del coste de `onWrite` no distingue «fresco» de «memoizado» (🟡)

El caso `T-3b 7 (T4)` mide `vista.grant(...)` como **primera** operación de la vista: el memo está
vacío cuando llega la escritura, así que las dos resoluciones son forzosamente dos llamadas al árbol
**aunque el hook leyera el memo**. Medido con MU12 (`#resolvedRoles` usa `#readResolverOrFresh()`):
la suite entera sigue **verde**. La promesa publicada («un `resolveChain` **fresco** —no el memo de
`forRequest()`—», README desde 3F · T4, CHANGELOG del 3b-1) no tenía juez.

No es cosmético: el evento de auditoría tiene que describir el árbol de **ahora**, no la foto con la
que empezó la petición; un `moved` a mitad de request haría que el hook auditase el árbol viejo.

**Cerrado**: dos aserciones más en el mismo caso, con el memo **caliente** (`authorize` antes del
`grant`). Medido: real ⇒ 2 con hook y 1 sin hook; MU12 ⇒ 1 con hook. Con el parche, **MU12 muere**.

### 5.2 `drop_database.mjs` — la única barrera del guard destructivo no la mira nadie (⚪, harness)

El guard de salida de `bootApp` lanza `DROP DATABASE` por `spawnSync`, con credenciales de
administrador, disparado por **cualquier** proceso que salga sin `teardown()`. Lo único que lo separa
de destruir la base de desarrollo de alguien es `/_[0-9a-f]{8}$/.test(database)`. Quitar esa línea
(MU18) deja la suite en **verde en los cuatro modos**.

Es harness, no paquete (⚪ por eso), pero es un `DROP DATABASE` sin oráculo.

**Cerrado**: caso nuevo en `harness_cleanup.spec.ts` que corre el script con cuatro nombres ajenos
(`authz_test`, `produccion`, sufijo de 9 caracteres, sufijo en mayúsculas) y exige `exit 2` + el
mensaje; y, en PG/MySQL, un **control** con sufijo válido que sale 0 — sin él, el caso pasaría por un
simple fallo de conexión. No destruye nada: el rechazo es anterior a conectarse y el control usa un
nombre inexistente (el script es idempotente). Con el parche, **MU18 muere**.

### 5.3 La purga parcial no tenía caso: nadie miraba qué queda cuando `purgeRole` revienta a mitad (🟡)

Es la justificación entera de AB3 (`purged` como lista) y no había ningún caso con un `purgeRole`
que falle. Medido con una sonda (driver cuyo 2.º `purgeRole` lanza, 3 huérfanos):

```
PROBE-AB3 error: Error | code: (sin code) | status: (sin status)
PROBE-AB3 el error lleva la lista de purgados? NO
PROBE-AB3 propiedades propias del error: ["stack","message"]
PROBE-AB3 roles que SOBREVIVEN: [dos, tres]      <-- 1 de 3 borrado
PROBE-AB3 role_purged notificados: [uno]
```

**Cerrado**: caso nuevo en `manager.spec.ts` que fija lo que sí es cierto y sí es recuperable —lo
purgado antes del fallo está purgado, el que falló y el que no se intentó siguen vivos, el hilo de
`role_purged` nombra **exactamente** el que se fue, y la siguiente pasada recoge el resto (la
promesa «una pasada interrumpida la recoge la siguiente», que tampoco tenía caso)—. Deliberadamente
**no** afirmo que el error no lleve la lista: eso es el 🟡 de §6.2 y quiero que el caso siga verde si
lo arreglan. Mutante de validación: notificar `role_purged` **antes** de purgar (MU20) ⇒ **muere**.

---

## 6. Huecos que NO cierro con un test (van a 3b-2)

### 6.1 🟡 El CHANGELOG del 3b-1 dice «no behaviour change in `src/`» y sí lo hay

Titular: *«Honesty lot. No new feature and **no behaviour change in `src/`**»*. Tres bullets después,
*«Observability of the diff…»* describe un cambio de `src/catalog.ts`. Y no es solo lo que se
imprime: `runCatalogDiff` computa el `inSync` que `authz:catalog:diff` convierte en exit code, y

```ts
if (shadowed.length) { … if (options.failOnShadows) { inSync = false … } }
```

Antes, una sombra causada **solo por el catálogo #2** dejaba `shadowed` vacío ⇒ el bloque no entraba
⇒ `--fail-on-shadows` salía **0**. Hoy sale **1**. Es exactamente el arreglo que se buscaba, pero es
un **gate de CI que puede ponerse en rojo al actualizar** y el titular lo niega.

**Qué falta** (una frase, no un test): que el titular diga «un solo cambio de comportamiento, el del
diff, con efecto en el exit code de `--fail-on-shadows`». El informe del lote **sí** lo marca; el
artefacto publicado, no.

*Verificabilidad*: la composición ya está cubierta transitivamente (MU9a mata la acumulación, MU19
mata el gate), así que no añado caso. Si se quiere explícito, son dos líneas en el caso T-3b:
`runCatalogDiff([…], { failOnShadows: true })` con la sombra del catálogo #2 ⇒ `inSync === false`.

### 6.2 🟡 «Whoever catches the error needs to know which roles went» — y el error no los lleva

`CHANGELOG.md:146-150` y el docblock de `pruneOrphanRoles` («quien recoge el 503 necesita la lista,
no un contador») justifican el *breaking* `purged: CatalogRoleRef[]` con el camino de fallo. En ese
camino el valor de retorno **nunca se produce**: la excepción sale del bucle y el comando
`authz:catalog:prune-orphans` no imprime ni una línea de estado. Medido arriba: el error es el del
driver, tal cual, sin `purged`, sin `status` y sin `code`.

La recuperación existe (los eventos `role_purged`, que el parche fija), pero **no es lo que la frase
promete**. Es el mismo patrón que el auditor marcó en AA1: una frase publicada que el código no
sostiene, en el lote que la corrigió.

**Dos salidas, ambas de una línea de decisión**, y elegir es del dueño:
(a) adjuntar `purged`/`skipped` al error (`error.purged = purged` antes de propagar, o envolverlo en
un error del paquete con `status`/`code`, que además cumpliría la regla «errores con status+code»); o
(b) corregir la frase: la lista se recupera por `hooks.onCatalogWrite` y la pasada siguiente.

**Caso que lo fijaría** (si se elige (a)): *dado* 3 huérfanos y un `purgeRole` que falla en el 2.º,
*cuando* se llama con `force`, *entonces* el error tiene `status: 503`, `code` del paquete y
`purged` = exactamente el primero. Hoy ese caso es rojo; por eso no lo meto en el parche.

### 6.3 ⚪ La mitad `shadowedByAncestor` de la acumulación del diff es código no observable

Ver §4 (MU9b, equivalente). No es un defecto: es una simetría que el código añade por claridad. Queda
dicho para que nadie crea que la suite lo defiende.

### 6.4 ⚪ Heredado y confirmado: R7 sigue sin oráculo

El 3b-1 lo declara y no lo toca. Lo confirmo otra vez como mutante equivalente bajo el esquema
actual (el `CASCADE` es el garante): cerrarlo pide desactivar FKs o espiar el SQL, y es una decisión
de diseño de la suite, no deuda de estos lotes.

---

## 7. Aserciones relajadas respecto a `2613916` (punto 4): **ninguna**

Todas las líneas `-` de `tests/` y `src/testing/` en `git diff 2613916..34e78ed`, una por una:

| Línea eliminada | Qué la sustituye |
|---|---|
| `assert.equal(seco.purged, 0, …)` ×2 | `assert.deepEqual(seco.purged, [])` **+** `assert.deepEqual(seco.skipped, [])` — el tipo cambió (AB3) y se comprueba **más** |
| `assert.deepEqual({dryRun, purged: 3})` | el 500 `E_AUTHZ_MASS_PURGE_REFUSED` + «no borra nada» + «ni notifica» + la purga con bandera con los **slugs** + `skipped: []` (5 aserciones donde había 1) |
| `assert.deepEqual((await stale.pruneOrphanRoles({force:true})).purged, 0)` | `…, [])` (idem) |
| `assert.deepEqual((await diffAuthzCatalog(…)).shadowedByAncestor, [], 'disjuntos')` | la misma **+** `ambiguousRoles` vacío **+** `catalogInSync` (T-3b 4: la aserción que se había perdido, devuelta) |
| `roles: [{ slug: 'editor', scopeType: 'app', … }]` | el mismo rol **+** `org-editor@organization` (siembra que M13 necesita) |
| `import { execFileSync }` / `import { memoryScopeTree }` | los mismos **+** `spawnSync` / `descendantsFrom` |

Cero relajaciones. Cero `skip`/`only`.

### 7 bis. Conteos del juez (punto 4)

Coherentes y ejecutables: `contract_harness.spec` afirma `scoped = primitives.length + 9 = 75` y
`withPurge = scoped.length + 5 = 80`, más `composición (3G · W4… = 1`; `CLAUDE.md` dice **«con
`purgeRole: true`, cinco más: 80»** y «UN caso de COMPOSICIÓN». Los tres números cuadran y la suite
los verifica. Ninguno de los dos lotes añade casos al juez: 3b-0b y 3b-1 solo suman **aserciones**
dentro de casos que ya existían (Z1 y el del alias), y el diff de `contract_harness.spec` es todo
comentario. Verificado también por la corrida diferencial de §3(b): con `src/testing/contract.ts` de
`6bdf946` el harness sigue cuadrando.

---

## 8. Cobertura de las promesas nuevas de los dos lotes

| Promesa publicada | Estado |
|---|---|
| `stillGranting`/`assignments` cuentan asignaciones **vigentes** | ✅ `tests/catalog_cache.spec.ts` (AA1/AB2) + `manager.spec` AA1 · MU1/MU1b mueren |
| «dormido ≠ inerte»: concede, es membresía por los seis caminos y se asigna | ✅ `manager.spec` AA1 (los dos lados) |
| Cota de purga masiva: 100 % rechaza, bandera purga, ratio bajo purga sin bandera | ✅ `manager.spec` AA2 + juez · MU2a/b/c mueren |
| `pruneOrphanRoles` es **API de plataforma** (se salta `requireActor`/`requireWithin`) | ✅ AA2 (el config los lleva a `true`) |
| TOCTOU: re-resolución + `skipped: owner-came-back` | ✅ AA3 · MU3/MU5 mueren |
| `maxLocalRoles` ⇒ 500, nunca lista parcial | ✅ `catalog_cache.spec` · MU4 muere |
| `purged` es lista: **qué** se purgó | 🟡 el tipo sí; la entrega en el camino de fallo, no (§6.2). El parche fija la vía recuperable |
| AA4: los hechos del nieto sobreviven al `detached` y despiertan con el restore | ✅ `manager.spec` AA4 (comprobado en la base) |
| D1: el dueño del árbol se estrella por las **dos** puertas; la plataforma repara | ✅ D1 · MU6 muere |
| D2: la ventana **no se cierra** — el `define` entra, la sombra es permanente, el atacante gana yendo primero | ✅ D2 · MU7 muere |
| D3: `scopes.moved` crea sombras sin juzgar rango | ✅ D3 · MU8 muere |
| El diff acumula sombras de todos los catálogos | ✅ T-3b · MU9a muere (`shadowedByAncestor`: ⚪ equivalente, §4) |
| Una línea por ensombrecido, nombrando al **más autorizado** | ✅ T-3b · MU10/MU10b mueren |
| T2: quien espera en el cerrojo es 503 `catalog.lock` y no escribe | ✅ `catalog_cache.spec` (PG/MySQL) · MU11 muere |
| T4: `onWrite` cuesta un `resolveChain` **fresco** que el memo no absorbe | 🔴→✅ **hueco, cerrado por el parche** (§5.1) |
| Contador de `sync.role.locals` = 1 consulta en lote | ✅ `spies.spec` · MU13 muere |
| M13: `purgeScope` canoniza en el **driver**, en los cuatro modos | ✅ `database_driver.spec` + juez · MU14 muere |
| M14: `descendantsFrom` ⇒ `null` para desconocido, `[]` para hoja | ✅ `scope_tree.spec` · MU15 muere |
| ⚪3: el 500 `E_AUTHZ_UNSUPPORTED` se ve **sin** `:8101`, y antes de leer nada | ✅ · MU16 muere en sqlite |
| ⚪4: `process.exit()` sin `teardown()` no deja residuo, y avisa | ✅ `harness_cleanup.spec` · MU17 muere |
| `drop_database.mjs` «nunca borra una base sin sufijo» | 🔴→✅ **hueco, cerrado por el parche** (§5.2) |
| «No behaviour change in `src/`» (titular del 3b-1) | 🟡 falso para `--fail-on-shadows` (§6.1) |

---

## 9. El parche

`.claude/contexto/tests-tester-fase-3b1.patch` — 122 líneas, **solo adiciones**, solo `tests/`:

```
 tests/harness_cleanup.spec.ts | 42 +   (§5.2 · el guard de nombre de drop_database.mjs)
 tests/manager.spec.ts         | 58 +   (§5.3 · la purga parcial: qué queda, quién lo dice, quién lo recoge)
 tests/spies.spec.ts           | 22 +   (§5.1 · T4 con el memo CALIENTE)
```

Verificado rojo→verde: MU12, MU18 y MU20 **mueren** con el parche y **sobrevivían** sin él.
Suites con el parche: **434 / 536 / 538 / 704 / 704 / 536** (los seis modos, §1), `typecheck` y
`check:purity` verdes, residuos 0.

Aplicar con `git apply` desde la raíz del repo; si el contexto se ha movido,
`patch -p1 --fuzz=5` (los tres bloques son inserciones limpias).

---

## Cierre

**APTA CON CORRECCIONES.** Sin comportamiento incorrecto. Los tres huecos de observación van
cerrados en el parche; los dos 🟡 de honestidad (§6.1 titular del CHANGELOG, §6.2 la lista en el
camino de fallo) **no bloquean** por la regla de parada y van **a 3b-2** — el segundo con la
decisión pendiente (adjuntar la lista al error, o corregir la frase).
