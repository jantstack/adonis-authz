# Fase 3b · Lote 3b-0b — correcciones del auditor sobre el 3b-0 (+ piezas del tester)

> Rama `v2/fase-3b`, base `2613916`. Sin commits. Node 22.23.2, PostgreSQL 18 (`postgres18`),
> MySQL 8.4 (`mysql84`), OpenFGA `:8101` y el tope-3 en `:8103` (contenedor `openfga-tiny`, borrado).
> Spec: `.claude/contexto/fase-3b-correcciones-0b.md` (AA1–AA4, AB1–AB4) + tres piezas del tester
> (AC1–AC3) llegadas a mitad del lote.

## Veredicto en una línea

**Las cuatro 🟡 del auditor cerradas, las cuatro ⚪ obligatorias hechas y las tres piezas del tester
integradas.** La frase falsa («un rol dormido no concede, no es membresía y no se puede asignar») está
corregida en los cuatro sitios donde se publicaba, el barrido ya no finge que esos huérfanos no
existen (`stillGranting`), la purga en masa por resolutor ciego se rechaza, el TOCTOU se cierra
re-resolviendo el owner justo antes de cada borrado y la resurrección de los hechos del descendiente
está escrita y fijada con un caso.

**Suites (todas verdes, todas con `:8101` salvo la del tope):**

| corrida | resultado |
|---|---|
| `npm test` (SQLite memoria) | `Tests 422 passed (422)` |
| `OPENFGA_TEST_URL=:8101 npm test` | `Tests 524 passed (524)` |
| `test:sqlite-file` + `:8101` | `Tests 526 passed (526)` |
| `test:pg` + `:8101` | `Tests 692 passed (692)` |
| `test:mysql` + `:8101` | `Tests 692 passed (692)` |
| tope 3 (`:8103`, `OPENFGA_LIST_*_MAX_RESULTS=3`) | `Tests 524 passed (524)` |
| `npm run typecheck` | limpio |

Bases `authz_test_*`: 0 en PostgreSQL y 0 en MySQL al cerrar (las 4 que dejaron mis scripts `z*`
—que hacen `process.exit(0)` sin `teardown()`— borradas a mano). Contenedor `openfga-tiny`: borrado.
El `openfga-tiny-tester3b0` (:8143) y el worktree `agent-a19761198932fcd6c` del tester: **no tocados**.

---

## Las dos decisiones del spec, aplicadas

1. **`pruneOrphanRoles` sigue siendo público**, y el seguro es una **cota**, no ceremonia: se
   documenta como **API de plataforma junto a `driver()`** (README y `CLAUDE.md`) y se rechaza la
   pasada con la firma del resolutor ciego (AA2).
2. **La resurrección de hechos se cierra en 3b-3** (`authz:reconcile --prune`): aquí va la línea en
   CHANGELOG/README y el caso que la fija (AA4).

---

## AA1 🟡 — «dormido» no significa «inerte» (la premisa falsa que justificaba borrar)

**Qué era.** La frase publicada en `README.md:252`, `CLAUDE.md:121`, el docblock de
`manager.pruneOrphanRoles` y el del comando es **falsa y medible**: con un descendiente vivo cuya
ruta materializada sigue pasando por el owner, el rol concede por los seis caminos y **se puede
asignar**. Y era la justificación escrita de purgar sin actor y sin rango.

**Rojo de partida** — `z4_dormido.ts` (auditor, PG), antes:

```
--- el owner u1 ya NO resuelve; t1 SÍ, con u1 en su cadena ---
  authorize(holder, docs:read, t1)          = true
  hasRole(holder, {uuid}, t1)               = true
  hasRole(holder, 'lead'@team, t1)          = true
  effectivePermissions(holder, t1)          = ["docs:read"]
  listRoles(holder, t1)                     = ["lead"]
  listSubjects({uuid}, t1)                  = 1 sujeto(s)
    authorizedScopes(holder, docs:read, team) = {"kind":"some","scopes":[{"type":"team",…}]}
--- ¿se puede ASIGNAR el rol dormido? ---
    grant(otro, {uuid lead}, t1) = {"existed":false,"expiresAt":null}
    grant(otro, 'lead'@team, t1) = {"existed":true,…}
  authorize(otro, docs:read, t1) = true
--- la plataforma barre el huérfano ---
  purged=1
  authorize(holder, docs:read, t1) (el que tenía el rol local) = false
```

Es decir: el barrido borraba, sin decir nada, un rol que estaba concediendo a dos sujetos.

**Qué se hizo.**

- (a) **La frase, corregida en los cuatro sitios**: *dormido = **no visible desde ningún scope vivo
  cuya cadena NO pase por el owner***; un descendiente vivo que aún lo ve **sí** lo usa. Lo que sí
  vale siempre y se dice así: no concede en un scope cuya cadena ya no alcanza al owner, y un
  huérfano **sin asignaciones vigentes** no concede nada. (`README.md`, `CLAUDE.md` invariante 18,
  `src/manager.ts` y `commands/authz_catalog_prune_orphans.ts`; además el bullet del CHANGELOG del
  3b-0 lleva ahora su corrección explícita en el mismo sitio donde afirmaba lo contrario.)
- (b) **El barrido marca lo que todavía concede**: `readLocalRoles` devuelve el nº de **asignaciones
  vigentes** por rol (una consulta agregada más, con el codec de caducidad por dialecto y el reloj
  del config) y cada huérfano sale con `assignments` y `stillGranting`. El comando los lista
  **aparte, con `logger.warning`**, y remata con un aviso de que purgarlos revoca permisos que hoy
  funcionan. La marca es **conservadora a propósito** (cuenta hechos; no re-resuelve el scope de cada
  uno, que sería un `resolveChain` por asignación): `false` ⇒ no concede seguro; `true` ⇒ míralo.
- (c) **Caso que fija los dos lados**: `tests/manager.spec.ts` → *3b-0b · AA1*. Con el owner fuera
  del árbol y el nieto vivo afirma los seis caminos de lectura **y** las dos formas de `grant`; luego
  borra también al nieto y afirma que ahí sí no concede nada; y contrasta el huérfano con hechos
  (`assignments: 2, stillGranting: true`) contra el huérfano sin hechos (`0/false`).
  El contrato (`src/testing/contract.ts`, caso Z1 de `'2.2'`) suma la misma distinción con los dos
  roles que ya tenía.

**Verde** — `z4b_dormido.ts` (mi copia de `z4` con dos líneas de instrumentación; el original no
imprimía el dry-run):

```
--- la plataforma MIRA antes de barrer (--dry-run, el default) ---
  dry-run: [{"slug":"lead","assignments":2,"stillGranting":true}] massPurge=true
--- la plataforma barre el huérfano ---
    pruneOrphanRoles({force:true}) SIN la bandera -> 500 E_AUTHZ_MASS_PURGE_REFUSED: …
  purged=["lead"] skipped=[]
```

---

## AA2 🟡 — purga en masa por resolutor ciego

**Rojo de partida** — `z2_prune.ts` §C (config con `requireActor: true` y `requireWithin: true`):

```
=== §C el resolutor no ve el árbol (comando sin contexto de tenant / réplica atrasada) ===
  roles locales vivos antes: 2
  dry-run con el resolutor ciego: orphans=2 (jefe, lead2)
    pruneOrphanRoles({force:true}) con el resolutor ciego = {…}
  roles locales vivos DESPUÉS: 0   <-- ¿el catálogo local de TODOS los tenants?
```

**Qué se hizo.** Cota de seguridad en `pruneOrphanRoles`, evaluada **antes de borrar nada**: si
**todos** los owners distintos resultan huérfanos, **o** los huérfanos superan el **50 %** de los
roles locales ⇒ 500 `E_AUTHZ_MASS_PURGE_REFUSED` nombrando el ratio y exigiendo `allowMassPurge:
true` (`--allow-mass-purge` en el comando). El `--dry-run` **no lanza** —es justo el diagnóstico que
hay que poder leer— pero lo marca en `massPurge: true` y el comando lo avisa. Nueva clase de error
(`src/errors.ts`), exportada por `index.ts` y en la tabla del README. El método queda documentado
como **API de plataforma junto a `driver()`** en README y `CLAUDE.md`.

**Verde** — `z2_prune.ts` §C, mismo script:

```
  roles locales vivos antes: 2
  dry-run con el resolutor ciego: orphans=2 (jefe, lead2)
    pruneOrphanRoles({force:true}) con el resolutor ciego -> 500 E_AUTHZ_MASS_PURGE_REFUSED:
      pruneOrphanRoles: 2 de 2 roles locales (2 de 2 owners distintos) tienen el owner fuera del árbol. …
  roles locales vivos DESPUÉS: 2
```

**Casos**: *3b-0b · AA2* en `tests/manager.spec.ts` cubre los tres que pedía el spec — ratio bajo
(1 de 3 roles, 1 de 3 owners) purga **sin** bandera; ratio 100 % rechazado sin borrar ni notificar
(se comprueba que sobrevive también el catálogo local del **otro tenant**); con la bandera, purga. Y
la afirmación de que la cota es la única barrera aquí: el config del caso lleva `requireActor: true`
y `requireWithin: true` y el método sigue sin exigir ni actor ni `within` (es de plataforma). El
contrato añade el rechazo + `allowMassPurge` en su caso Z1.

**Nota honesta sobre el efecto de la cota**: un catálogo con **un solo** rol local cuyo owner
desaparece cae en «todos los owners distintos» y pide la bandera. Es exactamente lo que dice el
spec, y es el precio de que la firma del accidente sea la del caso pequeño; el mensaje nombra el
ratio para que se distinga de un vistazo. Dos casos preexistentes (el de `Z2` en `manager.spec` y el
`H3` del tester) pasan ahora por esa puerta: se les **añadió** la aserción del 500 y la bandera
explícita, no se relajó ninguna aserción.

---

## AA3 🟡 — TOCTOU en el barrido

**Rojo de partida** — `z2_prune.ts` §E (resolutor que devuelve `null` la 1.ª vez y la cadena después):

```
=== §E TOCTOU: el owner VUELVE entre la lectura y la purga ===
    pruneOrphanRoles({force:true}) = {…}
  filas de "lead3" (owner u2, VIVO en el momento de la purga): 0
```

**Qué se hizo.** El owner se **re-resuelve en FRESCO justo antes de su `purgeRole`**; si resuelve, el
rol se salta y se cuenta en `skipped: [{ role, reason: 'owner-came-back' }]`. El coste añadido es un
`resolveChain` por rol *purgado* (no por rol leído).

**Verde.** El `z2` original ya no llega a §E: la cota de AA2 lo para antes (2 de 3 roles huérfanos).
Para medir AA3 aislado hice `z2e_toctou.ts` = el mismo script con `allowMassPurge: true` **solo** en
§E:

```
=== §E TOCTOU: el owner VUELVE entre la lectura y la purga ===
    purged  = []
    skipped = [{"slug":"jefe","reason":"owner-came-back"},{"slug":"lead3","reason":"owner-came-back"}]
  filas de "lead3" (owner u2, VIVO en el momento de la purga): 1
```

**Caso**: *3b-0b · AA3* en `tests/manager.spec.ts` — resolutor que no ve al owner en la lectura y sí
en el momento de purgar; afirma `purged: []`, el `skipped` exacto, que la fila sobrevive, que **no**
se notificó ningún `role_purged` y que el rol sigue concediendo en su owner.

---

## AA4 🟡 — resurrección de los hechos del descendiente

**Medición de partida** — `z1_despertar.ts` (sin cambios en el código; es el comportamiento que había
que **documentar y fijar**):

```
=== el consumidor borra la RAMA (u1 y t1) y notifica detached(u1) ===
    scopes.detached(u1, {actor: orgAdmin}) = undefined
  filas de "caro": 1 · asignaciones vivas del rol: 1
=== RESTORE (mismo uuid) ===
  authorize(holder, docs:read, t1) DESPUÉS del restore = true   <-- resucita
```

**Qué se hizo.** Línea explícita en **CHANGELOG** y **README** (y en `CLAUDE.md`, invariante 18):
`scopes.detached` purga el **scope exacto**; los hechos de descendientes cuya ruta pasaba por él
sobreviven y **vuelven a conceder si el scope se restaura con el mismo uuid**; entre 3D y 3G el rol
se llevaba sus asignaciones consigo, así que **es un cambio de comportamiento** y el lote va marcado
*breaking*. La limpieza es notificar `detached` por nodo o, en 3b-3, `authz:reconcile --prune`.

**Caso**: *3b-0b · AA4* en `tests/manager.spec.ts` — el hecho vive en el nieto, `detached` del
ancestro no lo toca (se comprueba **en la base**, porque el scope ya no resuelve y ninguna lectura
del puerto lo enseña), no concede mientras la rama no está, vuelve a conceder tras el restore con el
mismo uuid, y purgado **nodo a nodo** ya no resucita.

---

## Obligatorias

| # | Qué se hizo |
|---|---|
| **AB1** | Fuera el consejo «vigila `truncated`» de `src/manager.ts` (el campo se borró en 3b-0): la frase dice ahora que lo único que hay que vigilar es la cota, y apunta a `--fail-on-shadows` como gate de CI. `grep truncated src/ commands/` ⇒ solo la línea que explica que ya no existe. |
| **AB2** | `readLocalRoles({ maxLocalRoles = 10 000 })`: se pide una fila de más y, si aparece, 500 `E_AUTHZ_TOO_MANY_LOCAL_ROLES` — **nunca** una lista parcial (truncar aquí es purgar a ciegas media base). Constante `DEFAULT_MAX_LOCAL_ROLES` exportada; clase de error nueva, exportada por `index.ts` y en la tabla del README. Caso en `tests/catalog_cache.spec.ts` (junto al de `assignments`), con la cota justa que pasa y la superada que lanza. |
| **AB3** | `purged: CatalogRoleRef[]` en vez de un contador (con `skipped` al lado), porque la pasada **no** es atómica y —con AA1— un fallo a mitad es revocación parcial de permisos vivos: quien recoge el error necesita saber **cuáles** se fueron. El comando imprime el estado por rol (`purgado` / `saltado (el owner volvió)` / `huérfano`). |
| **AB4** | CHANGELOG con la sección «Lot 3b-0b» completa (los cinco puntos + la corrección del bullet de 3b-0 que afirmaba lo contrario); `CLAUDE.md` invariante 18 con la definición corregida de «dormido» + los dos seguros + AA4, y las filas del mapa (`errors`, `manager`, `catalog_cache`, `commands`) y la línea de roadmap al día. |

## Piezas del tester (AC1–AC3)

| # | Qué se hizo |
|---|---|
| **AC1** | `tests-tester-fase-3b0.patch` aplicado (`patch -p1 --fuzz=5`: el `git apply` fallaba solo porque su contexto incluía el `purged, 0` que AB3 convirtió en `purged, []`). Entran los tres casos: **H1** la identidad canónica de `detached` observada donde el driver no la tapa (evento `scope_purged` + `onScopeDetached` del puerto), **H2** «un scope que el árbol ya no conoce se purga igual» vuelve a tener caso, **H3/H4** el caso (c) de la colisión con sus dos mitades (hermano y ancestro no bloquean). Única adaptación: el `pruneOrphanRoles({force:true})` final de H3 (1 de 1 owners) pasa ahora por la cota de AA2, así que el caso afirma **primero** el 500 `E_AUTHZ_MASS_PURGE_REFUSED` y **luego** purga con `allowMassPurge: true` — aserción añadida, ninguna quitada. |
| **AC2** | `CLAUDE.md` (fila `tests/`): «ocho más: 83» ⇒ **«cinco más: 80»**, y «los cuatro casos de COMPOSICIÓN» ⇒ **uno** (los otros tres se fueron con la superficie que juzgaban, 3b-0 · Z3). Comprobado contra las aserciones vivas del harness (`withPurge = scoped.length + 5`, `composición (3G · W4` ⇒ 1). |
| **AC3** | El comentario de `tests/contract_harness.spec.ts` decía que el `+5` incluía «el de `pruneOrphanRoles`»; no existe tal caso (el quinto es `purgeRole(uuid) revoca…`). Reescrito: el barrido no tiene caso propio del juez, se observa **dentro** del de `scopes.detached`, y la cara `false` cubre también su 500. |

## ⚪ anotados para 3b-1 (NO implementados aquí)

1. **M13** (preexistente): la canonización que hace el **driver** dentro de `purgeScope` no tiene
   oráculo en ningún motor. AC1/H1 cubre la del **manager** (evento + puerto), no la del driver.
2. **M14**: el contrato `null` del helper publicado `descendantsFrom` se quedó sin oráculo al
   borrarse W2.
3. La cara `whenFalse` del par `purgeRole` solo corre con OpenFGA, así que el 500
   `E_AUTHZ_UNSUPPORTED` de `pruneOrphanRoles` es **invisible** en los cuatro modos sin `:8101`.
4. Fuga no determinista del teardown en PostgreSQL (8 bases huérfanas que dos re-ejecuciones
   aisladas no reproducen). En este lote **no** la vi: las 4 bases que quedaron eran de mis scripts
   `z*`, que salen con `process.exit(0)` sin `teardown()`; las borré a mano y las suites de motor
   cerraron a 0.

## Superficie tocada

```
 CHANGELOG.md                            |  73 +++-      (sección Lot 3b-0b + corrección del bullet de 3b-0)
 CLAUDE.md                               |  49 +--       (invariante 18, mapa, roadmap, AC2)
 README.md                               |  11 +-        (dormido, dos seguros, AA4, dos códigos nuevos)
 commands/authz_catalog_prune_orphans.ts |  76 ++--      (--allow-mass-purge, listado aparte, skipped)
 index.ts                                |   2 +
 src/catalog_cache.ts                    |  55 ++-       (assignments vigentes + cota maxLocalRoles)
 src/errors.ts                           |  30 +         (MassPurgeRefusedError, TooManyLocalRolesError)
 src/manager.ts                          | 123 ++++--    (pruneOrphanRoles: AA1/AA2/AA3/AB3 + AB1)
 src/testing/contract.ts                 |  20 +-        (aserciones nuevas en el caso Z1; 0 casos nuevos)
 tests/catalog_cache.spec.ts             |  51 +
 tests/contract_harness.spec.ts          |   8 +-        (AC3)
 tests/manager.spec.ts                   | 380 ++++      (AA1–AA4 + los tres del tester)
```

Sin `skip`/`only`, sin commits, sin cambios en el conteo de casos del juez.
