# Panel `{trx}` — informe del AUDITOR (adversarial)

**Alcance**: opciones (A) outbox de hechos, (B) `{trx}` solo-SQL, (C) rechazar `{trx}` en `openfga`.
**Base**: worktree solo-lectura en `242d846` (`2.4.0-alpha.1`). Reproducciones REALES contra el
`:8101` (7 casos, todos ✅ verdes = todos los ataques entran), fichero de laboratorio
`tests/trxau_panel.spec.ts` **ya borrado**; stores `trxau-*` creados y **borrados** (`/stores` = 0).
Motor SQL del harness: SQLite `:memory:`.
**No escribo el veredicto**: eso es del juez. Mi trabajo es enseñar por dónde se rompe cada una.

---

## Veredicto en una línea

(A) **inseguro tal cual** (tres 🔴, uno de ellos escalada de puerto medida); (B) **inseguro como
PROMESA**, mecánicamente igual que hoy pero con la firma que invita al patrón que fuga; (C) **seguro,
y el único que no miente**, a costa de dejar el requisito 6 sin cumplir en `openfga` — que es
exactamente lo que hoy es verdad.

---

## Hallazgos (ordenados por severidad)

### 🔴 1 · (A) La RESURRECCIÓN: un `revoke` en línea sobre un hecho encolado es un no-op silencioso

- **Escenario**: despliegue `facts` con cola de hechos. `grant(alice, unit-editor, unit)` se ENCOLA
  dentro de la transacción del consumidor (T0, confirma) → un administrador revoca **sin** `{trx}`
  (T1, camino en línea): la tupla todavía no existe en el store, `revoke` es idempotente y **no-op
  seguro** (invariante 6), devuelve OK y `authorize` responde `false` → el relay pasa (T2) y aplica
  el grant encolado → **`authorize` vuelve a `true`, para siempre**.
- **Evidencia**: ✅ MEDIDO contra el `:8101` (caso `A2`). openfga: `true` tras el relevo;
  `database` con la misma secuencia: `false`. La divergencia es la señal.
- **Steelman**: «si TODAS las escrituras de hechos encolan (como el árbol hoy: `manager.ts:736`
  encola haya o no `transaction`), el orden por `id` lo salva». → **No me convence del todo**:
  (a) el enunciado de la opción dice «encolan dentro de la trx del consumidor», o sea camino mixto;
  (b) si encolan SIEMPRE, entonces cae el 🟠 4 (todo `deny`/`revoke` del sistema pasa a tener lag,
  donde hoy la ventana es CERO); (c) aun encolando siempre, el `id` se asigna en el INSERT y la
  visibilidad en el COMMIT: dos transacciones de duración distinta invierten el orden real de
  confirmación. Se elige entre 🔴 1 y 🟠 4; no hay puerta que no dé a un patio.
- **Mitigación mínima**: un `revoke`/`deny` en línea tiene que **cancelar en la misma transacción**
  las entradas pendientes de esa misma clave (holder+rol+scope), no solo escribir el store.

### 🔴 2 · (A) × relaciones — el camino de APLICACIÓN se salta F-05 y compone un `role_binding` REAL

- **Escenario**: `relations.relate(alice, 'assignee', { type: 'role_binding', id: <uuid del rol> },
  partition = org)` aplicado **por el relay** (o por `driver()`), sin pasar por `RelationsManager`.
  El driver `openfga` compone `role_binding:<scopeKey(org)>|<roleUuid>` — que es **carácter por
  carácter** el id que escribe `OpenFgaAuthorizationDriver.grant` (`openfga_driver.ts:960`) — y
  escribe `assignee`. Si otro holder ya tiene ese rol en ese scope, la ESTRUCTURA
  (`role_binding#role`, `scope#binding`) ya está, así que la tupla forjada **concede sola**.
- **Evidencia**: ✅ MEDIDO contra el `:8101` (caso `D1`): `authorize(alice,'docs:write',org)` pasa de
  `false` a `true` con una única llamada al puerto de RELACIONES. Y: `openfga_relations_driver.ts`
  `relate`/`unrelate` **no** comprueban `#config.hasType`/`isDeclared` (solo `assertRelationId`,
  R-16); `database_relations_driver.ts` tampoco. La frase publicada en `types.ts:1487` —«el driver la
  re-valida por defensa en profundidad»— **es falsa en los dos drivers**. En `database` es inocuo
  (tabla separada); en `openfga` el store es COMPARTIDO y por eso F-05 es lo único que hay.
- **Steelman**: «F-05 corta al ENCOLAR, que es donde está el manager; el relay solo propaga lo ya
  juzgado». → **No me convence**: es exactamente el argumento del relay de árbol («la policy ya se
  juzgó al encolar», `manager.ts:848`) y funciona mientras la cola sea de confianza — ver 🔴 3. Y
  basta un despliegue que deje de declarar un tipo entre el encolado y el relevo para que se aplique
  algo que hoy el manager rechazaría.
- **Mitigación mínima**: F-05 (tipo+relación declarados y tipos reservados) **dentro del driver
  `openfga` de relaciones**, no solo en el manager; y borrar la frase de `types.ts:1487` o hacerla
  verdad.

### 🔴 3 · (A) convierte la base del consumidor en ESCRITOR PRIVILEGIADO del PDP

- **Escenario**: hoy, en un despliegue `facts`, la aplicación **no tiene credenciales de FGA para
  hechos**: si le comprometen la base (SQLi, un job con permisos de más, un backup restaurado), no
  puede concederse un rol — los hechos viven en el store y solo el motor los escribe. Con (A), una
  fila `INSERT INTO authz_scope_outbox (op='granted', …)` es **un grant efectivo**: el relay la
  aplica saltándose `within` (invariante 15), `requireActor`, la policy del consumidor y —en
  relaciones— F-05.
- **Evidencia**: ✅ por código: `relayScopeChanges` es «operación de PLATAFORMA … se salta
  `requireActor` y `requireWithin` a propósito» (`manager.ts:847-850`) y aplica con `driver()`
  (`#applyScopeChange`, `manager.ts:1396`); la tabla no lleva firma, HMAC ni comprobación de
  procedencia (`stubs/scopes_outbox_migration.stub`, `scope_outbox.ts`).
- **Nota honesta**: hoy ya existe una versión menor de esto — una fila forjada de árbol puede colgar
  el scope del atacante bajo la organización de la víctima y heredar hacia abajo. Con hechos el
  radio pasa de «una arista» a «cualquier rol para cualquier holder en cualquier scope».
- **Steelman**: «quien escribe en tu base ya ha ganado». → **No me convence en ESTE producto**: la
  propiedad que se vendió con `facts` (y la que COGNITIV compra: PDP autónomo, appliance soberano)
  es precisamente que el PDP no depende de la integridad de la base de la aplicación. (A) la deroga
  y no lo dice en ninguna parte.
- **Mitigación mínima**: si (A) sale adelante, la cola de HECHOS necesita su propia tabla, con su
  propio usuario/grants SQL y —mínimo— un `actor` + `within` re-verificados en el relevo, o una
  firma sobre la fila.

### 🟠 4 · (A) `deny` y `revoke` encolados: fail-OPEN donde hoy la ventana es CERO

- **Escenario**: `deny(alice,'docs:write',org)` confirma en SQL a las 12:00:00; hasta el relevo
  `authorize` sigue respondiendo `true`. Igual con `revoke`. Es la primitiva de emergencia
  («quítale el acceso YA») convertida en asíncrona.
- **Evidencia**: ✅ MEDIDO (`A1`): grant encolado ⇒ `false` (fail-CLOSED, molesto);
  deny encolado ⇒ `true` (fail-OPEN); revoke encolado ⇒ `true` (fail-OPEN). Tras el relevo, los tres
  correctos.
- **Steelman**: «es el mismo lag que el árbol ya tiene declarado en el README, y la receta es drenar
  en la misma petición tras el commit». → **A medias**: el lag del árbol se aceptó sobre operaciones
  raras y de plataforma (mover un tenant); aquí se aplica a la operación más frecuente y más crítica
  del motor. Y «drenar en la misma petición» convierte el ahorro en nada: si de todas formas hay que
  relevar antes de responder, se ha pagado la cola para seguir siendo síncrono, y una caída entre el
  commit y el drenaje deja el deny sin aplicar igual.
- **Mitigación mínima**: la asimetría (ver «la opción que nadie puso»): lo que **quita** autoridad
  jamás encola.

### 🟠 5 · (A) La contaminación por clave de scope (3b-2h · 🔴 2) es INSUFICIENTE para hechos

- **Escenario**: `moved(dept → orgB)` falla en el relevo (503 de FGA, o acaba APARCADA) y detrás va
  algo que solo nombra a un **descendiente** (`unit`). `#changeKeys` (`manager.ts:1370`) devuelve
  `[child, parent]`, así que **no hay clave compartida** y el segundo cambio se aplica igual.
  Con hechos eso es: el `grant` sobre la `unit` entra, el `moved` no, y el `deny` que el tenant nuevo
  tiene puesto en `orgB` **no alcanza a la unit** porque en el store la unit sigue colgando de `orgA`.
- **Evidencia**: ✅ MEDIDO en dos mitades. `A3`, con el relay REAL y la outbox REAL:
  `report.failures.length === 1` (el `moved`), `report.deferred === []` (**nada se aplaza**) y el
  cambio sobre la `unit` se aplica en la MISMA pasada. `A4`, la consecuencia con hechos:
  `openfga → true` / `database → false` sobre la misma pregunta, con el deny de `orgB` puesto.
- **Razonamiento que rompe el invariante del 2h**: «dos cambios que pueden interactuar comparten
  siempre un scope» es cierto para el ÁRBOL (toda dependencia viaja por un nodo nombrado) y **falso
  para un HECHO**: el significado de un hecho en `S` depende de **toda la cadena** de `S` (denies
  heredados, `rooted`, visibilidad del rol local), no del nodo que nombra. Meter hechos en la misma
  cola con el mismo algoritmo de orden reintroduce el 🔴 2 del 2h por otra puerta.
- **Steelman**: «es el lag ya declarado tras un `moved`». → **No**: lo declarado es «el tenant
  ANTIGUO conserva acceso»; aquí lo que falla es que un **deny del tenant nuevo se reporta aplicado
  y es inerte**, y el operador ve la pasada del relay con un solo fallo (el `moved`) y todo lo demás
  en verde.
- **Mitigación mínima**: la clave de contaminación de un hecho tiene que ser su **cadena**, no su
  scope — y una cadena no se puede calcular en el relevo sin el resolutor del consumidor.

### 🟠 6 · (A) `grant` no es una escritura ciega: encolarlo obliga a mentir o a resolver dos veces

- **Escenario**: `grant` devuelve `GrantOutcome { existed, previousExpiresAt, expiresAt }`
  (invariante 10) y `expiresAt` OMITIDO significa «preserva la caducidad vigente; si expiró, revive
  sin caducidad». Eso es un **read-modify-write** contra el store (`openfga_driver.ts:998-1016`,
  `resolveGrantExpiry(current.validUntil, options.expiresAt, this.now())`). Al encolar no hay lectura
  posible: o se devuelve un `GrantOutcome` inventado (y el evento `extended` con
  `previousExpiresAt` es falso), o se resuelve en el relevo (y entonces lo devuelto en el commit no
  es lo que quedó escrito). Además el reloj que decide «¿había expirado?» pasa a ser el del relevo,
  no el de la petición.
- **Evidencia**: ✅ código (`manager.ts:2799-2830`, `openfga_driver.ts:939-1016`). 🟡 el impacto
  exacto depende de qué decida devolver el implementador.
- **Steelman**: «se guarda el `expiresAt` explícito y punto». → Entonces `expiresAt` deja de tener
  tres estados en `openfga` y eso es romper el invariante 10 sin discusión explícita.

### 🟠 7 · (A) no cumple el requisito 6 tal como está enunciado (la auditoría se va con el relay)

- **Escenario**: COGNITIV pide «la llave y `pdp_version` en la misma transacción». Con (A) lo que
  confirma con su transacción es **la intención**, no el hecho; y el evento de auditoría del paquete
  llega DESPUÉS, desde un proceso de plataforma sin su transacción — el propio código ya lo hace así
  a propósito para `detached` («no se audita `scope_purged` todavía, porque todavía no ha pasado
  nada», `manager.ts:824`). O sea: su fila dice `pdp_version = N`, su PDP cree que la llave existe, y
  el store todavía no la tiene. **La ventana que querían cerrar sigue abierta, con otro nombre.**
- **Evidencia**: ✅ código + 🟡 depende de lo que ellos llamen «atómico».
- **Y no hay forma de detectarla**: no existe API pública de marca de agua. `#relayWindow`
  (`manager.ts:1348`) es privada y solo aflora en el reporte de `reconcile`
  (`drift.pendingRelay`/`deadRelay`); `authz_catalog_version` **no se mueve con los hechos**
  (invariante 14 es del catálogo), así que el consumidor no puede fechar «mis hechos hasta N ya son
  visibles».

### 🟠 8 · `{trx}` × freeze — la barrera del cutover la decide el CLIENTE que pasa el llamante

- **Escenario**: otro proceso congela el motor (`authz:freeze`, ventana de operador, sin lease). Una
  escritura normal recibe 503 `E_AUTHZ_FROZEN`. **La misma escritura con `{transaction}` cuya foto no
  ve el freeze entra.** En producción esa «foto que no ve el freeze» es literalmente el snapshot de
  InnoDB: MySQL por defecto es REPEATABLE READ y una transacción abierta ANTES del freeze no lo verá
  en ninguna de sus sentencias.
- **Evidencia**: ✅ MEDIDO (`C1`, mecanismo): con freeze vivo, `grant` sin `transaction` ⇒ 503;
  `grant` con un `transaction` inyectado que devuelve la fila sin freeze ⇒ **entra**, y `authorize`
  responde `true`. ✅ código: `#assertNotFrozen(operation, options.transaction)` y
  `readFreezeRow({ client })` (`manager.ts:654-671`, `freeze.ts:80-90`). ❓ no pude medir la ventana
  REPEATABLE READ real: el harness corre SQLite `:memory:`; haría falta `TEST_DB=mysql`.
- **Lo peor**: **hoy ya pasa con `grant`**, sin que `{trx}` exista. `GrantOptions` no declara
  `transaction`, pero `#writeOptions` lo lee con un cast (`manager.ts:1435`) y TypeScript solo
  rechaza el literal fresco: `const opts = { actor, transaction: trx }; authz.grant(s,r,sc,opts)`
  compila. Es decir: **(C) «rechazar `{trx}`» no se consigue no declarándolo** — hace falta un
  rechazo ACTIVO (422) o el campo se sigue consumiendo por la puerta de atrás para decidir la
  barrera del freeze.
- **Steelman**: «está declarado: la promesa publicada es "otro proceso recibe 503", no "ninguna
  escritura entra" (`freeze.ts:84-88`, tester A4)». → **Me convence como estado del arte, no como
  destino**: hoy afecta a tres notificaciones de árbol; con `{trx}` en `grant`/`deny` afecta a todas
  las escrituras de hechos, y el freeze es lo que sostiene la certificación de `reconcile`. Con (B)
  además la tupla se escribe **en línea**, o sea dentro de la ventana congelada y por tanto dentro (o
  al lado) de la pasada que se certifica.

### 🟠 9 · `{trx}` de otra conexión: el encolado se va a la base equivocada, en silencio

- **Escenario**: `sqlScopeOutbox({ connection: 'authz' })` (tabla de autorización en otra base) y el
  consumidor pasa el `trx` de su conexión primaria. `on()` solo redirige a la conexión con nombre
  **cuando el cliente es el `database` por defecto**: con un `trx` devuelve el `trx` tal cual
  (`scope_outbox.ts:220-229`). El INSERT cae en la base del consumidor: si allí no existe la tabla,
  503 (ruidoso, aceptable); si existe —una migración copiada, un entorno clonado—, la fila se queda
  donde **ningún relay lee**. Con hechos: un `revoke` confirmado, aplaudido, que no se aplica nunca y
  que **ni siquiera aparece en `dead()`**.
- **Evidencia**: ✅ código. 🟡 la mitad «la tabla existe en las dos bases» es un escenario de
  despliegue, no lo he montado.
- **Mitigación mínima**: `enqueue` tiene que comprobar que el `trx` pertenece a la conexión de la
  cola y 500 si no (hoy solo se comprueba que tenga `.from`/`.table`, y `db` entero pasa esa prueba —
  pasar `db` como `transaction` escribe fuera de toda transacción sin decir nada).

### 🟠 10 · (B) reintroduce el cruce 4 · S5 para HECHOS, con la firma que lo invita

- **Escenario**: `db.transaction(async trx => { await authz.grant(alice, rol, unit, { transaction: trx });
  … throw })`. La tupla ya está en el store; el rollback no la deshace. **Escalada persistente e
  invisible desde la base del consumidor**, que es la definición exacta del cruce 4 · S5 que motivó
  la outbox.
- **Evidencia**: ✅ MEDIDO (`B1`): tras el rollback, `authorize ⇒ true`.
- **¿Es peor que hoy?** Mecánicamente **no**: hoy pasa exactamente igual si llamas a `grant` dentro
  de una transacción que luego revierte. La diferencia es la **promesa**: aceptar el parámetro y
  documentar que solo cubre la mitad SQL es lo que el paquete ya decidió que no vale — «una
  recomendación no es un mecanismo» es la frase con la que el driver `facts` se NIEGA a construirse
  sin outbox (500 `E_AUTHZ_SCOPE_DRIFT_UNGUARDED`). (B) es esa recomendación, con azúcar sintáctico.
- **Steelman**: «al menos es honesto y no añade lag ni cola». → Me convence a medias: es honesto en
  el CHANGELOG y deshonesto en la firma. Si (B) sale, el mínimo es que `grant(..., {transaction})` en
  un driver con `transactions: false` **emita el aviso por `logger.warn` en cada llamada** o exija
  `acceptNonAtomicRisk: true` en el config, con el mismo patrón del gate de deriva.

### 🟡 11 · `resolveChain` no recibe la transacción: `within` y «scope desconocido» se juzgan contra el árbol PRE-transacción

- **Escenario**: `ScopeChainResolver = (scope) => Promise<ScopeRef[] | null>` (`types.ts:843`): no
  hay parámetro para el cliente. Dentro de `db.transaction`, el consumidor crea la unit y concede en
  ella: el resolutor lee por `db`, **no ve la fila sin confirmar** y responde `null` ⇒ 422
  `E_AUTHZ_UNKNOWN_SCOPE` (invariante 9). Fail-CLOSED, pero es **el caso de uso exacto que pide
  COGNITIV** («crear el recurso y su regla en la misma transacción»). Y al revés: `within` se
  contrasta con el árbol de ANTES, así que la contención de tenant decide con datos que la propia
  transacción está cambiando.
- **Evidencia**: ✅ código (firma del puerto) + el propio paquete ya lo esquiva a mano en su suite
  (`activeClient`/`treeClient` en `tests/scope_outbox.spec.ts`, con la nota de que el consumidor
  «notifica ANTES de recolgar su fila»).
- **Aplica a las TRES opciones y también al `database` "trivial"**: la fila SQL será atómica, pero la
  DECISIÓN que la autoriza no lo es.

### 🟡 12 · `{trx}` en `database` no es trivial: mueve los cerrojos a la vida de la transacción del consumidor

- **Escenario**: `authz_relations` tiene un UNIQUE de siete columnas (`authz_rel_tuple_uq`,
  `stubs/migration.stub:206`) y `relate` es check-then-insert dentro de una transacción **interna y
  cortísima** (`database_relations_driver.ts`, con el comentario «`{trx}` NO se expone en el puerto
  (decisión (b), diferido)»). Con `{trx}` externa, dos transacciones del consumidor que relacionen la
  misma tupla se bloquean en el índice único durante toda la vida de la transacción ⇒ lock-wait
  timeout ⇒ `guardSql` lo clasifica como 503 `E_AUTHZ_BACKEND_TIMEOUT` en medio de la transacción del
  consumidor; y dos transacciones que escriban A→B y B→A **deadlockean**, cosa hoy imposible.
- **Y un detalle de invariante**: el 503 por deadline notifica `onWrite` con `indeterminate: true`
  (invariante 13), pero con `{trx}` la escritura NO es indeterminada — el rollback la determina.
  La auditoría publica la incertidumbre equivocada.
- **Evidencia**: ✅ código y esquema; ❓ no he medido el deadlock (haría falta PG/MySQL con pool ≥ 2).

### 🟡 13 · (A) × `reconcile` y × cutover: lo encolado-y-no-aplicado es invisible, y la certificación caduca por detrás

- **Escenario**: en un despliegue `facts` los hechos NO están en `authz_*` (`#factsOrigin` caso 1
  lo impone: el origen es `enumerateFacts` del propio store, `manager.ts:1199`). Un hecho encolado y
  no aplicado **no está en el store ni en `authz_*`**: `reconcile` no lo ve, la pasada sale limpia,
  se certifica bajo freeze durable… y el relay entra detrás y escribe. La foto certificada no
  describe el estado que hubo ni el que habrá.
- **Y en la dirección de salida** (`--to=database --from=openfga`, la migración de vuelta): lo
  encolado se **pierde** — el relay lo escribirá en un store que ya no sirve. Si lo encolado era un
  `revoke`/`deny`, la migración se lleva el grant y deja fuera su retirada: fail-OPEN.
- Sobre `--prune`: **no** borra lo encolado (no puede: no lo ve). El daño no es que lo borre, es que
  el relay lo resucite DESPUÉS de una pasada que ya dijo «cero deriva» — el mismo patrón que el 🔴 1.
- **Evidencia**: ✅ código (`manager.ts:1107-1243`, `reconcile.ts`); 🟡 la secuencia completa no la he
  montado (necesita dos drivers registrados y una pasada de migración).

### 🟡 14 · (A) El envenenamiento de la cola de hechos es CONTROLABLE por un admin de tenant

- **Escenario**: F-05 y la resolución del rol cortan al ENCOLAR (el manager es puro y va antes del
  driver), pero el driver **vuelve a resolver al aplicar** (`knownScope` + `resolveRoleQuery` +
  `assertRoleAssignableAt`, `openfga_driver.ts:950-954`). Un admin encola un `grant` de un rol local
  suyo y acto seguido lo borra (`deleteScopedRole`): la entrada ya no se puede aplicar, falla en cada
  pasada, **contamina su clave de scope** y aplaza todo lo que la toque —incluidos los `deny` de ese
  scope— hasta que `maxAttempts` (default 5) la aparca. Repetible a voluntad.
- **Evidencia**: 🟡 razonado sobre código medido (el mecanismo de contaminación y de aparcado está
  reproducido en `A3` y en la suite del 2h); no monté esta secuencia concreta.
- **Nota**: es fail-CLOSED en la entrada envenenada (bien) y fail-OPEN en lo aplazado (mal): lo que
  se aplaza son los denies.

### ⚪ 15 · (C) tal como está escrito en el roadmap no es implementable

- «el manager falla al construirse si el driver no soporta `transactions`» (`roadmap-2.0.md:103`): en
  el momento de construir no se sabe si alguien pasará `{trx}`, y el driver se resuelve **perezosa**
  y por nombre (`reconcile --to=`, `--from=`, `forRequest`). Si se toma literal, `openfga` deja de
  poder registrarse en cualquier config que quiera `{trx}` en `database`. La (C) sana es **422/500 en
  la llamada** que trae `transaction` contra un driver con `transactions: false` — y, por el 🟠 8, es
  la ÚNICA forma de que «rechazar» signifique algo, porque hoy el campo ya se consume.

### ⚪ 16 · No hay marca de agua pública

`#relayWindow` es privada; `pending`/`dead` solo salen por el comando y por el reporte de
`reconcile`. Cualquier opción con lag necesita que el consumidor pueda preguntar «¿mi escritura ya
es visible?» sin leer la tabla de la cola a mano.

---

## La composición, punto por punto (lo que se preguntó)

| Cruce | Resultado |
|---|---|
| `{trx}` × **freeze durable** | 🟠 8. No es que se encole durante el freeze y se aplique después (el `enqueue` pasa por `#writeOptions`, que corta, y el relay re-afirma la barrera por lote): es que **la barrera se lee por el cliente que pasa el llamante**, así que con `{trx}` la transacción decide si el motor está congelado. MEDIDO. |
| `{trx}` × **reconcile / `--prune`** | 🟡 13. `--prune` NO borra lo encolado (no lo ve). El daño es al revés: la pasada certifica «limpio» y el relay escribe después; y la migración de SALIDA pierde lo encolado. |
| `{trx}` × **partición de relaciones** | 🟡 12 + 🔴 2. El trigger de partición sigue defendiendo (corre en el INSERT, con o sin trx externa), pero el UNIQUE pasa a bloquear durante toda la transacción del consumidor, y el camino de aplicación de una cola de relaciones no tiene F-05. |
| `{trx}` × **`pdp_version` del consumidor** | 🟠 7. Sí hay ventana: con (A) su versión sube al commit y la tupla llega en el relevo; con (B) puede pasar al revés (tupla escrita, versión revertida). Y no existe marca de agua para cerrarla (⚪ 16). |
| `{trx}` × **rollback** | (A) correcto: la fila sin confirmar no la ve el relay, no encontré camino para que sí. (B) 🟠 10, MEDIDO: la tupla sobrevive. |
| `{trx}` × **dos relays** | El lease (`pg_try_advisory_xact_lock` / `GET_LOCK`) aguanta; en SQLite y dialectos desconocidos es de PROCESO y está escrito. Con hechos en la cola, «de proceso» deja de ser aceptable: dos réplicas re-aplicarían grants viejos sobre revokes nuevos. |

---

## Lo que intenté y NO se rompió

- **Rollback × outbox**: no encontré forma de que el relay vea una fila no confirmada, ni de que
  `markApplied` se adelante al commit. El mecanismo del `enqueue` en la trx es sólido.
- **`assertChange` al encolar**: el `ScopeRef` mal formado y el `op` desconocido mueren en el
  call-site (422), no en el relevo. El `actor` también se valida (`assertSubject`).
- **F-05 al ENCOLAR**: no conseguí colar un tipo/relación no declarado por `RelationsManager` — es
  puro y va antes del driver. El agujero está en el camino de APLICACIÓN (🔴 2), no en el de entrada.
- **El lease del escritor único**: con PG/MySQL no encontré cómo hacer que dos pasadas trabajen el
  mismo lote; la segunda sale `busy`.
- **Los tres centinelas del relay** (`done`, `parked`, `after`): no logré ni doble aplicación en una
  pasada, ni bucle infinito, ni que una outbox que ignora `after` cuelgue la pasada.
- **La re-afirmación del freeze por lote** (3b-8 · B3): no pude colar escrituras de árbol después de
  que otra pasada adquiriera el freeze a mitad.
- **`purgeScope` y el orden S6**: intenté dejar hechos vivos con la arista borrada; no lo conseguí
  por el camino soportado.
- **La contaminación por clave**: intenté que un `moved` fallido contaminara a un cambio sobre un
  DESCENDIENTE… y no contamina — eso es justamente el 🟠 5.
- **No pude verificar** ❓ la ventana REPEATABLE READ de MySQL (harness en SQLite `:memory:`), ❓ el
  deadlock del UNIQUE de `authz_relations` (pool 1), ❓ la secuencia completa de `reconcile` × cola
  (necesita dos drivers registrados y una migración de verdad).

---

## La opción que ninguno puso

No es mi trabajo diseñar, así que las dejo enunciadas y con el ataque que ya no funciona:

- **(D) La asimetría por DIRECCIÓN.** Solo lo que **añade** autoridad puede encolar
  (`grant`, `relate`); lo que la **quita** (`revoke`, `deny`, `unrelate`, `purge*`) va SIEMPRE en
  línea y síncrono. Mata el 🔴 1 (un revoke en línea puede además **cancelar la entrada pendiente**
  en la misma transacción, que es una operación SQL trivial) y el 🟠 4 (la ventana fail-open
  desaparece; queda solo fail-closed). No arregla el 🔴 3 ni el 🔴 2.
- **(E) El grant PROVISIONAL por condición.** El driver ya sabe escribir tuplas con
  `condition: not_expired { valid_until }`. Escribir la tupla EN LÍNEA con `valid_until = now + 30 s`
  antes del commit y reescribirla sin condición en un hook de post-commit: el rollback no deshace
  nada porque **la tupla se evapora sola**. Fail-CLOSED ante crash, sin cola, sin relay, sin nuevo
  escritor privilegiado. Límites conocidos: no vale para `deny` (hoy sin condición) ni para
  `revoke` (no existe el borrado provisional) — o sea, compone exactamente con (D).
- **(F) `authz_*` como log durable de hechos también en `facts`.** El hecho se escribe en la
  transacción del consumidor en las tablas del paquete (atómico de verdad, ya implementado) y el
  store pasa a ser una PROYECCIÓN reconstruible; `reconcile --from=database --prune` vuelve a ser
  una reparación legítima en vez de estar prohibida (`#factsOrigin` caso 1). Precio: se renuncia a
  «los hechos viven solo en el PDP», que es media fase 3b. Merece que el analista lo cuente.

---

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿(A) encola SIEMPRE o solo con `{trx}`?** Con «siempre» cae el 🔴 1 y sube el 🟠 4 a 🔴; con
   «solo con trx» es al revés. Son dos opciones distintas y el panel las está tratando como una.
2. **¿Qué devuelve un `grant` encolado?** Si es un `GrantOutcome` inventado, el invariante 10 se
   rompe; si `expiresAt` deja de tener tres estados en `openfga`, es una divergencia declarada nueva.
3. **¿El relay aplicaría los hechos por `driver()` (como hoy el árbol) o por el manager?** Si por
   `driver()`, el 🔴 2 y el 🔴 3 son inevitables por construcción.
4. **¿Una cola o dos?** Si la cola de hechos es otra tabla, no hay orden alguno entre árbol y hechos
   y el 🟠 5 deja de ser un caso raro para ser el caso normal.
5. **¿Qué significa «atómico» para COGNITIV: «se aplican los dos o ninguno», o «no se pierde»?** Si
   es lo segundo, (A) sirve con (D) encima. Si es lo primero, **ninguna de las tres lo cumple en
   `openfga`** y lo honesto es (C).
6. **Independiente del panel, y ya explotable hoy**: `#writeOptions` consume `options.transaction`
   en las nueve escrituras para decidir el freeze, aunque `GrantOptions` no lo declare
   (`manager.ts:1435`). ¿Se rechaza activamente, o (C) es una etiqueta sin mecanismo?
