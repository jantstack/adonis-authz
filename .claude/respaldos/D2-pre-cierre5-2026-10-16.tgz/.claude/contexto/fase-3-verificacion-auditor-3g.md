# Fase 3 · Lote 3G — Auditor de seguridad, pasada final (delta `ae3a7a8..6f87ee8`)

> Contra el código real en `v2/fase-0`, HEAD `6f87ee8`. **No se tocó ni un archivo del repo.**
> Scripts nuevos en `…/scratchpad/v10/` (`y1_owner_desconocido.ts`, `y2_w3.ts`,
> `y3_carrera_y_sonda.ts`); los ocho de `v9/` y los siete de `v8/` re-ejecutados **tal cual**.
> Motor: **PostgreSQL 18** + OpenFGA `:8101`.
> Suite completa `TEST_DB=pg` + `:8101`: **695 passed (695)** — coincide con el informe del lote.
> `repro5_resiste.ts`: **22 barreras, 22 `ok`, 0 `ROTO`**.
> Higiene: 13 bases `authz_test_*` que dejaron mis scripts, borradas; 0 en MySQL; no creé stores en
> OpenFGA (mis scripts corren sobre el driver `database`).

## Veredicto en una línea

**APTA** — y la respuesta a la pregunta prioritaria es **NO: el 3G no introdujo una cuarta regresión
de la clase de las tres anteriores**. Las tres tenían la misma firma observable (*algo que era 422 pasa
a ser una escritura destructiva que triunfa*) y **no encontré ninguna aquí**: los cuatro caminos que
ataqué en W1/W2/W3/Y1 responden 422 o fallan cerrado. Lo que sí introdujo el 3G es **una inversión de
autoridad** (el dueño del árbol pierde la vía de reparación cuando el squatter le supera en rango) y
**un control nuevo —W3— que no es un invariante**: se comprueba en escritura y se puede esquivar con
un `resolveChain` que devuelve `null` o moviendo el árbol después. Todo eso es 🟡/⚪ y va **a la
Fase 3b**; ninguno reabre la fase por la regla de parada.

---

## Misión 1 · N1–N7 y P1–P7 re-ejecutados: ¿revive alguno?

Salidas literales en `…/scratchpad/v10/*.out`.

| # | Hallazgo | 3F (`ae3a7a8`) | AHORA (`6f87ee8`) | Estado |
|---|---|---|---|---|
| **N1** 🟡 | mina de slug para tipos no-ancestro | cerrado | `n1_nivel`: el dueño del árbol (rank 50) define su `n-galaxia@galaxia` y el sync entra entero | ✅ sigue cerrado — **pero ver 🟡 D1**: si el squatter le supera en rango, ya no |
| **N2** 🟡 | `detached` sobre un scope borrado no purgaba nada | cerrado | `n6`: `{"purgedRoles":1,…,"reason":"owner-detached-unknown"}`, 0 filas / 0 asignaciones / 0 denies | ✅ |
| **N3** 🟡 | subárbol > cota ⇒ 503 sin purgar | cerrado | `n7`: `{"purgedRoles":3,"truncated":true}`, sin 503 | ✅ |
| **N4** ⚪ | README «the tenant only hurts itself» | cerrado | `n3_shadow` idéntico: `effectivePermissions(holderLocal) = ["docs:read"]`, 5/5 slugs globales muertos por slug | ✅ |
| **N5/N6/N7** ⚪ | doc, cerrojo, receta sin `purgeRole` | cerrados | `n2_p4`, `n4_race` (8 carreras PG: 1 fila, 1 ganador, 422 exacto ×8), `n5` | ✅ |
| **P1** 🟠 | `detached(ancestro desconocido)` destruía roles de descendientes VIVOS sin rango | **abierto** | `x1c`: el ataque es `422 RANK_EXCEEDED`, `filas de "caro": 1`, `authorize` sigue `true` | ✅ **cerrado** — y el control pasa de decir «rank 0» a «rank 20»: el rango se mide donde debe |
| **P2** 🟡 | `truncated: false` con la purga incompleta | abierto | `x4`: `{"purgedRoles":0,"truncated":true,"reason":"owner-detached-unknown"}` | ✅ cerrado |
| **P3′** 🟡 | ensombrecer por posición, sin rango | abierto | `x2`: `defineScopedRole(pobre rank 3, 'critico@unit') -> 422 RANK_EXCEEDED`; `hasRole = true`, `listSubjects = 2`. `x5` muere al plantar la sombra | ✅ cerrado **por la puerta directa** — ver 🟡 D2/D3 para las dos indirectas |
| **P4** 🟡 | la regla de nivel la apaga el actor / se apaga sola | abierto (por decisión) | `x3` §1–§4 **idénticos**: `descendientes de u1 = 4 (cota 3)` ⇒ el `define` pasa; con el resolutor caído, también | ⚪ sin cambio, documentado en X1 (`manager.ts:1387-1397`) |
| **P5** ⚪ | `catalogInSync` deja de contar sombras | abierto | `--fail-on-shadows` añadido (`catalog.ts:959-966`); `classifyHomonyms` ya no hace `continue` con un global en el grupo | ✅ cerrado como opt-in |
| **P6** ⚪ | `CLAUDE.md` se contradice en el invariante 18 | abierto | corregido | ✅ |
| **P7** ⚪ | el 422 filtraba slug y rank de otro tenant | abierto | `x6`: «El actor no tiene ningún rol vigente en la cadena de ese scope (rank 0)…», sin `'secreto-de-a' (rank 49)` | ✅ cerrado |

**Ninguno revive.**

### Los dos scripts que el implementador declara con defectos propios — verificado

- **`x2_autoridad`**: cierto y **el defecto es del script, no del paquete**. Su línea
  `deleteScopedRole(pobre, critico)` responde `422 E_AUTHZ_INVALID_IDENTITY: …llegó object` porque el
  script pasa el **objeto** del rol donde `assertCatalogUuid` espera el uuid en string
  (`manager.ts:1206`); es un guard que ya estaba en `ae3a7a8` y en 3E. Mi propio `y1` hace la misma
  llamada **bien** (con `caro.uuid`) y da lo que P3 promete: `422 RANK_EXCEEDED: El actor (rank 20 en
  el owner del rol) no puede tocar 'caro' (rank 40)`. El segundo fallo del script (`TypeError … reading
  'uuid'`) es consecuencia de que la sombra ya no se puede plantar: busca una segunda fila `critico`
  que W3 impide crear. **No hay regresión detrás de ninguno de los dos.**
- **`x3_degrada`**: cierto. §1–§4 dan **exactamente** lo de `ae3a7a8` (comprobado línea a línea contra
  `…/v9/x3_degrada.txt`, el rojo de 3F); §5 muere en su línea 91 con
  `422 PERMISSION_NOT_DELEGABLE: … el actor no lo tiene efectivo en unit:…`, que es el script pidiendo
  delegar `docs:read` con un actor sin rol en esa cadena. **Defecto del script**, y el informe del lote
  ya lo verificó con `git stash`; yo lo confirmo por la traza: el error sale de `#assertDelegable`
  (`manager.ts:1349`), no de nada que el 3G tocara.

---

## Misión 2 · Solo lo nuevo, buscando composición

### 🟡 D1 · W3 le quita al dueño del árbol la reparación de N1 cuando el squatter le supera en rango (la composición más cercana a una regresión)

- **Escenario**: `app → orgA → u1`. La plataforma le da a la unit un `unit-boss` **rank 60** (una
  capa que en 3F no cambiaba nada). El actor de la unit ocupa `mina@unit` con **rank 59**.
  → **acción**: `orgAdmin`, **rank 50 y DUEÑO del árbol**, intenta las tres vías de reparación que el
  paquete publica.
  → **resultado**: las tres son 422.
  ```
    orgAdmin define su mina@unit          -> 422 RANK_EXCEEDED (por debajo ya hay 'mina' con rank ≥ al tuyo: 50)
    orgAdmin deleteScopedRole(mina r59)   -> 422 RANK_EXCEEDED (rank 50 … no puede tocar 'mina' (rank 59))
    orgAdmin scopes.detached(u1)          -> 422 RANK_EXCEEDED (idem)
    la PLATAFORMA (rank 100) sí ensombrece = {…"rank":60}
  ```
- **Evidencia**: ✅ `…/scratchpad/v10/y2_w3.ts` §C. Código: `#assertAboveShadowed`
  (`manager.ts:1570-1580`) llamado desde `defineScopedRole` (`:1038`).
  **En 3F esto funcionaba**: la autoridad era solo posición, así que `orgAdmin` ensombrecía cualquier
  rank. Es exactamente la firma de las tres regresiones anteriores —dos piezas correctas (W3 «solo
  actúa quien supera en rango» + el arreglo de N1 «el ancestro recupera el nombre ensombreciéndolo»)
  que al componerse dejan un tercer estado— pero **el resultado no es un fail-open**, es un
  fail-closed de más: el daño es que un `(slug, nivel)` queda ocupado dentro del subárbol de la org y
  solo la plataforma lo recupera.
- **Steelman del defensor**: *«es la regla que la spec pidió y `#assertRank` garantiza
  `rank < min(actorRank, topGlobalRank)`, así que la plataforma —el único que tiene el rango global
  más alto— SIEMPRE puede; y X1 ya escribe que la mina residual la repara autoridad+rango, con
  `purgeRole` de la plataforma como último recurso»* → **me convence a medias**: el techo global es
  real y verificado (`la PLATAFORMA (rank 100) sí ensombrece`), así que no hay estado irrecuperable.
  Lo que no se sostiene es la frase de X1 «un ancestro con rango por encima define el suyo y lo
  ensombrece»: el ancestro **dueño del árbol** puede no tenerlo, y entonces el ticket sube a la
  plataforma. Requiere además un reparto de ranks no monótono con la profundidad (rank 60 en una unit
  bajo un admin de rank 50), que es configuración inusual.
- **A la Fase 3b**: una línea en README/X1 diciendo que la reparación por ensombrecimiento exige
  superar el rango **del squatter**, y que con ranks no monótonos el recurso es la plataforma.

### 🟡 D2 · W3 es fail-open cuando la cadena del owner de la víctima devuelve `null` en ese instante

- **Escenario**: `critico@unit` **rank 40** owner `u1`, vivo y concediendo. Atacante `pobre`, **rank
  10** en `orgA`.
  → **control**: `defineScopedRole(pobre, orgA, 'critico@unit' rank 5)` ⇒ `422 RANK_EXCEEDED` (W3
  funciona).
  → **acción**: la misma llamada mientras `resolveChain(u1)` devuelve `null` (ventana de soft-delete,
  réplica atrasada, scope en estado «pending» — el mismo tipo de estado que S1 admite como normal).
  → **resultado**: **se crea**. Restaurado el árbol, la sombra es real y permanente:
  ```
    ATAQUE: el mismo define con resolveChain(u1)=null = {…"owner":"organization|…","rank":5}
    filas 'critico': 2
    hasRole(holder,critico,u1)  -> 422 E_AUTHZ_AMBIGUOUS_ROLE
    grant(otro,critico,u1)      -> 422 E_AUTHZ_AMBIGUOUS_ROLE
    ¿repara el boss rank 60? deleteScopedRole -> 422 RANK_EXCEEDED (rank 0 en la cadena del owner de la sombra)
  ```
- **Evidencia**: ✅ `…/scratchpad/v10/y2_w3.ts` §A. Código: `#shadowedBelow` (`manager.ts:1541-1555`)
  hace `resolveChain(otherOwner)` y `if (chain && chain.some(...))` — **`null` ⇒ el rol no entra en la
  lista de ensombrecidos ⇒ `#assertAboveShadowed` no lo ve**. Es un `null` que termina en «permitido».
- **Steelman**: *«un owner que no resuelve no es visible en ninguna parte, así que en ese instante no
  se ensombrece a nadie; y `defineScopedRole` sí falla cerrado en lo que importa (la colisión hacia
  ARRIBA se juzga con la cadena del owner NUEVO, que sí resolvió)»* → **me convence en la lógica del
  instante, no en el resultado**, porque el estado que deja es permanente y la víctima no puede
  deshacerlo. **Lo que sí rebaja el hallazgo a 🟡**: el mismo atacante consigue la misma denegación
  **sin trampa ninguna**, simplemente **yendo primero** — medido en `y3` §A: en 6 de 12 carreras el
  rol rank 5 del ancestro entra y el `define` del descendiente (rank 40, actor rank 60) recibe
  `422 CATALOG_CONFLICT: es un ancestro`. W3 solo protege a los roles que **ya existen**; ocupar el
  nombre antes es gratis y siempre lo fue.
- **A la Fase 3b**: `#shadowedBelow` con `chain === null` debería contar como «no demostrable» y
  rechazar (o exigir rango igual), no como «no hay sombra».

### 🟡 D3 · La promesa de W3 no es un invariante: la sombra aparece moviendo el árbol, y ahí no se comprueba ningún rango

- **Escenario**: `lejano@unit` **rank 40** owner `u9`, que cuelga de `orgB`. `pobre` (**rank 10** en
  `orgA`) define `lejano@unit` **rank 5** en `orgA` — legal y sin sombra, porque `u9` no está bajo
  `orgA`.
  → **acción**: el consumidor mueve `u9` de `orgB` a `orgA` y lo notifica con `scopes.moved` (función
  normal de producto).
  → **resultado**: `grant(otro,'lejano',u9) -> 422 E_AUTHZ_AMBIGUOUS_ROLE`, y `bossB` (rank 50 en
  `orgB`, **0** en `orgA`) no puede repararlo: `deleteScopedRole -> 422 RANK_EXCEEDED`.
- **Evidencia**: ✅ `…/scratchpad/v10/y2_w3.ts` §B. `scopes.moved` (`manager.ts:366-373`) no vuelve a
  juzgar el catálogo, y no tiene por qué: el problema es que **la relación «ensombrece» es función del
  árbol** y W3 la comprueba solo en el instante de la escritura.
- **Steelman**: *«mover un scope entre organizaciones ya podía crear colisiones (un homónimo de
  ancestro aparece igual) y eso está desde 3B; W3 no empeora nada»* → **me convence a medias**: es
  cierto que no empeora, pero el 3G escribe en `CLAUDE.md`, README y CHANGELOG la regla *«sobre un rol
  solo actúa quien lo supera en rango»* como si fuera un invariante, y no lo es. Un agente que lea esa
  línea la va a dar por buena.
- **A la Fase 3b**: escribir la regla como **comprobación de escritura**, no como invariante, y
  mencionar `scopes.moved` como la vía por la que aparecen sombras sin juicio de rango.

### 🟡 D4 · Lo que W1 **no** cierra: un rol cuyo owner ya no resuelve SÍ concede si un descendiente vivo conserva su ruta

- **Escenario**: `app → orgA → u1 → t1`. Rol `caro@unit` **rank 40** owner `u1`, con holder.
  → **precondición**: el consumidor borra la fila de **u1** y notifica después (el orden que S1
  admite); `t1` sigue vivo con ruta materializada `team → unit → organization → app`.
  → **acción**: `scopes.detached(u1, { actor: forastero })` con un actor de **rank 0 en todas partes**.
  → **resultado**:
  ```
    authorize(holder, docs:read, t1) ANTES  = true      <-- el rol rank 40 SIGUE concediendo
    deleteScopedRole(forastero, caro)      -> 422 E_AUTHZ_UNKNOWN_SCOPE   (la otra puerta lo niega)
    ATAQUE: scopes.detached(u1, {actor})    = {"purgedRoles":1,"truncated":false,"reason":"owner-detached-unknown"}
    authorize(holder, docs:read, t1) DESPUÉS = false
  ```
- **Evidencia**: ✅ `…/scratchpad/v10/y1_owner_desconocido.ts`. Código: `#assertAboveOwnedRoles`
  (`manager.ts:534-546`) — `ownerChain === null ⇒ skipped = true; continue`.
  **La premisa publicada es falsa**: `manager.ts:475-479`, `types.ts:509-522` y el comentario del caso
  (b) en `tests/manager.spec.ts:3044` dicen «esos roles no son visibles en ninguna parte». Lo son,
  desde cualquier descendiente vivo cuya ruta materializada siga pasando por el owner — que es
  exactamente el árbol con el que se reprodujo P1.
- **Steelman**: *«el consumidor ya declaró que ese scope no existe; que un nieto siga apuntando a él
  es una inconsistencia SUYA, y purgar los roles huérfanos es literalmente para lo que existe S1. Sin
  esto, con `requireActor: true` esos roles, sus asignaciones y sus denies no tienen ninguna salida
  por el manager (N2)»* → **me convence lo bastante para NO llamarlo 🟠**, y por tres motivos
  medidos: (a) **no hay ganancia de privilegio**, solo destrucción; (b) en la config donde es
  alcanzable (`requireWithin: false`) el mismo llamante ya tiene un martillo mayor y documentado —
  `y3` §C y `x6`: `detached` de un scope de otro tenant le purga los **hechos** sin tocar rango; (c)
  con `requireWithin: true` la rama es inalcanzable (`422 UNKNOWN_SCOPE`, medido en
  `x1_detached_mentira` (e)). Lo que P1 tenía y esto no es que allí moría un rol de un scope **vivo y
  normal**.
- **A la Fase 3b**: cambiar la frase (es falsa) y, si se quiere cerrar, medir el rango en la cadena de
  cualquier descendiente vivo que todavía vea el rol.

### ⚪ D5 · `reason: 'owner-detached-unknown'` ya significa dos cosas y no distingue cuál

`reason = unknownScope || skipped` (`manager.ts:489`). Sale también cuando el scope notificado no
resuelve **pero la policy de rango se evaluó entera y pasó**. Quien audita ya no puede distinguir
«no se pudo evaluar el rango» de «el árbol no conocía el scope». `types.ts:509-522` lo documenta como
las dos cosas a la vez; el `ScopeDetachOutcome` no dice **qué roles** se saltaron. A la Fase 3b.

### ⚪ D6 · El coste de `scopes.detached` pasa de O(1) a O(owners distintos) en llamadas al árbol

`#assertAboveOwnedRoles` memoiza por clave de owner, pero hace **un `resolveChain` + un `rolesInChain`
por owner distinto con roles locales** (`manager.ts:535-539`); en 3F era exactamente uno.
`DEFAULT_MAX_DESCENDANTS = 10_000` (`manager.ts:138`), así que una purga de una org grande puede
disparar miles de idas y vueltas al árbol y al driver **antes** de escribir nada, en una operación que
un actor cualquiera puede invocar. Está reconocido en el docblock («Coste: … por OWNER distinto»); no
hay cota propia ni deadline. A la Fase 3b.

### ⚪ D7 · `types.ts`: dos docblocks seguidos sobre `ScopeDescendantsResolver`, y el viejo contradice al nuevo

El bloque nuevo de W2 se insertó **debajo** del que ya había (`types.ts:420-434` y `:435-451`). El
viejo dice «Más de `maxNodes` nodos ⇒ el consumidor lanza» y el nuevo «puede devolver la lista larga …
o lanzar». TypeScript se queda con el último, así que el efecto es cosmético — pero es justo el
docblock donde vive el contrato que W2 invoca como respuesta a la pregunta 2. A la Fase 3b.

---

## Lo que intenté y NO se rompió

- **W1 · fabricar el «no resuelve»**: (a) **alias del uuid** del scope notificado — con un scope que el
  árbol funde, `resolveChain` lo canoniza y el rango se mide en la cadena del owner
  (`x1_detached_mentira` (c): 422, `filas de "aliasrol": 1`); con un alias suelto, el scope queda
  desconocido pero **sus roles no aparecen**, porque `readRolesOwnedBy` casa por clave canónica
  (`{"purgedRoles":0}`). (b) **owner corrupto o no canónico**: imposible por construcción —
  `readRolesOwnedBy` filtra por `ownerKeys` canónicas, así que `#ownerOf` nunca ve una clave que no
  parsee. (c) **owner = el propio scope notificado**: es el caso de S1 y se comporta como debe.
- **W1 · el «todo o nada»**: es real, no «purga los que puede». `#assertAboveOwnedRoles` recorre
  **todos** los roles y lanza antes del bucle de purga (`manager.ts:487-489`); el caso mixto está
  fijado en `tests/manager.spec.ts:3035-3041` («ni el del owner desconocido, ni el del que sí
  resuelve») y en el juez, W4 (i). En `y1` y en `x1c`, tras el 422 **no se purgó nada**, ni los hechos.
- **W3 · rango medido donde debe**: `actorRank` sale de `#rolesAlong` sobre la cadena del **owner
  nuevo** y se compara con el rank del ensombrecido. Un actor de rango alto en un ancestro **ajeno**
  no alcanza: `#shadowedBelow` exige que la cadena de la víctima contenga al owner nuevo
  (`y2` §B, antes del move: `hasRole(...,lejano,u9) = false`, sin ambigüedad). Y `updateScopedRole`
  **no puede** convertir un rol inocuo en sombra: no cambia `slug`, `scopeType` ni `owner`
  (`manager.ts:1125-1130`), y encima ahora exige el rango del ensombrecido.
- **W3 · la carrera como bypass**: **no existe**. Si el memo no vio al homónimo, la re-comprobación
  dentro de la transacción encuentra `fresh` y **siempre** lanza `CATALOG_CONFLICT` («reintenta»,
  `manager.ts:1054-1072`); si lo vio, W3 corre. Medido: `y3` §A, **12 carreras ancestro(rank 10, rol
  rank 5) vs descendiente(rank 60, rol rank 40)** ⇒ 12/12 **exactamente un ganador**, nunca los dos.
- **Y1 · ¿un tercer final?** No lo encontré. (i) *Dos roles del mismo owner*: `y3` §B, 6/6 una sola
  fila y 422 exacto; `n4_race` B1–B3, 3/3 en dos procesos reales. (ii) *El descendiente conviviendo
  con el ancestro invertido*: cerrado por las dos puertas — si el memo del descendiente ve al ancestro
  es `CATALOG_CONFLICT: es un ancestro` antes de la transacción, y si no lo ve es el mismo 422 dentro
  (`n4_race` A2). Los dos finales que el juez acepta son los dos únicos alcanzables.
- **W1 + W3 compuestos**: no se cruzan. Con la sombra puesta, `scopes.detached(u1)` sigue midiendo el
  rango del rol ensombrecido en la cadena de **su** owner (`y2` §C: `orgAdmin` rank 50 ⇒ 422 contra el
  rank 59). Y al revés, purgar por `detached` para «hacer sitio» exige el mismo rango que
  `deleteScopedRole`, así que no ahorra nada.
- **W2 como sonda entre tenants**: hay oráculo, pero es el de siempre y es destructivo o inútil.
  `y3` §C: con roles locales y rank 0 ⇒ 422 sin escribir y **sin nombrar nada** (X5); sin roles
  locales ⇒ purga los **hechos** (la puerta que gobierna `within`, ya documentada); con el scope
  desconocido ⇒ `{"purgedRoles":0,"truncated":true,"reason":…}`, que solo revela «el árbol no conoce
  este scope». No encontré ninguna sonda **no destructiva** nueva.
- **`updateScopedRole` como puerta trasera de W3**: al contrario, se cierra de más — un descendiente
  que sube su propio rank **congela** el rol del ancestro (`y2` §D: `orgAdmin` no puede editar su
  propia sombra rank 20 porque debajo hay un rank 59, y si la borra ya no puede recrearla). Es
  molestia, no privilegio: sigue pudiendo borrarla. ⚪, a la Fase 3b.
- **Las 22 barreras de `repro5_resiste`**: 22/22 `ok`, 0 `ROTO`, incluidas las de rango, deny en
  ancestro, `assignableAt`, tenant hermano y raíz.
- **Regresión**: suite completa `TEST_DB=pg` + `:8101` ⇒ **695/695**.

---

## Preguntas abiertas para el arquitecto

Ninguna cambia el veredicto. Para el plan de 3b, en este orden:

1. **¿W3 es un invariante o una comprobación de escritura?** Hoy está escrito como lo primero y es lo
   segundo (D2, D3). Si se quiere lo primero hay que juzgar la sombra también en lectura, y eso es
   otra fase.
2. **¿La reparación de N1 es «autoridad + rango» o «la plataforma»?** Con ranks no monótonos el dueño
   del árbol se queda fuera (D1) y X1 promete lo contrario.
3. **¿Se acepta que un rol de un owner que no resuelve pueda seguir concediendo?** Es lo que mide D4 y
   lo que tres sitios del código afirman que no pasa.
