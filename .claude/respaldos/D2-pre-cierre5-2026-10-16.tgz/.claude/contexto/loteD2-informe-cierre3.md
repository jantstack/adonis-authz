# Sublote D2 · cierre 3 — informe del implementador (2026-10-16)

Brief: `loteD2-cierre3-coordinador.md` (C2-1…C2-5). Origen: `loteD2-auditor-cierre2.md` (NO APTA). Árbol: `main` sobre
`75353fe`, con D2 + cierres 1, 2 y 3 SIN commit. Sin `npm version`, sin push, sin sellado; CHANGELOG solo bajo
`[Unreleased]` (`git diff HEAD -- CHANGELOG.md`: 0 líneas borradas).

Raíz común (C2-1, C2-2, C2-4): una tupla vencida en `now` se trataba como viva. Ahora la regla tiene un punto de paso
ÚNICO en el plan: `liveInDestination(tuple, now)` (`src/relations/reconcile.ts`), y el mismo criterio en `relate` de los
drivers que renuevan en dos `Write`.

Reproducciones del auditor contra el árbol final (`:8090`): R1 409 sin hueco · R2 `renewal-unsafe` · **R3** `409
E_AUTHZ_RENEWAL_UNSAFE partial=true` (antes mudo) / con el 2.º `Write` caído `503 partial=true` + `carriedDeny` · **R4**
dry y real `written 2, updated 0, reasons []`, `destAfter false`, 2.ª pasada `written 0` (antes `true` para siempre) ·
**R5** prefijos `relate(member group) ⇒ false ; relate(viewer) ⇒ false` (antes el 1.º concedía) · **R6** sin error (antes
409) · **R7** `database` y `openfga`: `relate(U member h) ⇒ false ; relate(U member g) ⇒ false`, residuo `[]` (antes g
primero y concedía).

---

## 1 · 🟠 C2-1 — portadora VENCIDA en el destino

**Qué.** En `planPartition`, una tupla del destino vencida en `now` (el mismo `now` con el que el origen descarta las suyas)
es AUSENTE: no entra en `destByKey`. Consecuencias: su reescritura es `toWrite` (fase 3 si es membresía), nunca
`toUpdate` ni `renewal-unsafe`; no entra en `orderContext` (ni portadora, ni arista del auto-corte, ni «renovación» de la
fase 4). `#carriedDeny` de `openfga` y del doble: una arista de anidación vencida no transporta nada (parte C2-4).

**Ficheros.** `src/relations/reconcile.ts` (`liveInDestination`, `planPartition`), `src/testing/relations_reconcile_contract.ts`.

**Casos.** Contrato publicado `runRelationsReconcileContract` (cara `denies: true`), por dirección (A→B y B→A, o sea
los dos drivers como destino), en los harness «doble en memoria · deny» y «database ↔ openfga · deny» (servidor real):
- «vigencia · C2-1 …» = R4 + R5: el destino niega antes; espía que hace `check` tras CADA escritura: ningún prefijo
  concede; final niega X (como el origen) y concede Y (como el origen); `--dry-run` y real con los mismos números
  (`written 2, updated 0`, `details []`, `orderResidue []`); 2.ª pasada: plan vacío.
- «vigencia · C2-2 …» = R7 (con `toConfig`, abajo).
- Conteo del runner con `denies: true`: 16 → **20** (`relations_harness.spec.ts`, «vigencia ·» = 4).

**Mutante.** `c21.plan.vigencia-ignored` (`liveInDestination` ⇒ `true`): **MUERTO, 8 rojos** (2 casos × 2 direcciones × 2
harness). En la guardia: `rec.plan.vigencia-ignored` (abajo).

**Cuatro líneas de cierre (punto 5).**
- (a) *Gemelos*: `reconcileRelations` ↔ `runRelationsReconcile` ↔ comando: los tres pasan por `planPartition`. `relate`
  directo: C2-4. Roles (`authz:reconcile`): no aplica — sus hechos vencidos ya se cuentan aparte (`expired`/`extra-fact`)
  y no tiene clasificación de portadoras ni orden por grafo. Purgas de `openfga`: no aplica (borran todo, la vigencia no
  cambia el orden de una poda total).
- (b) *Tabla de verdad* (destino × origen × `atomicRenewal`): la sustituye la fuerza bruta con vigencia de C2-2 (7 estados
  por tupla × {`--prune`, sin} × {atómico, dos `Write`}, recorrida ENTERA en E1-reduced). Filas literales en el contrato:
  vencida/viva-portadora × `atomicRenewal` {false (doble, openfga), true (database)}.
- (c) *Casos existentes puestos rojos*: ninguno se debilitó. Cambió el conteo del runner (16 → 20) y el `find` del mutante
  `rec.apply.writes-then-prune` (el bucle ahora es `for (const step of steps)`; mismo efecto).
- (d) *Linaje*: L10 (PROMOVIDO). Cierre estructural: punto de paso único `liveInDestination`, propiedad universal (fuerza
  bruta con vigencia en `relations.order.exhaustive`) y mutante en la guardia de superficie.

## 2 · 🟡 C2-2 — la VIGENCIA en el universo de la fuerza bruta

**Qué.**
- `tests/helpers/order_bruteforce.ts` · `bruteForceVigencia(universo, orden, { atomic, sample? })`: cada tupla del universo
  en uno de **7 estados** (destino ausente/vencida/viva × origen ausente/viva-misma-caducidad/viva-otra). El plan se deriva
  con `liveInDestination` (la misma función que el plan real): vencida = ausente ⇒ escritura; viva con otra caducidad ⇒
  renovación; sobrante con `--prune` ⇒ borrado. El oráculo mira la vigencia REAL (vencida no conecta). Las renovaciones son
  OPERACIONES: destino atómico ⇒ una escritura; destino de dos `Write` ⇒ las portadoras (`denyCarrierGroups` del contexto)
  no se ejecutan (`renewal-unsafe`) y las demás son delete + write con el hueco comprobado como un prefijo más.
- **Hallazgo nuevo que midió la fuerza bruta** (y no el auditor): con la vigencia en el plan, una SOBRANTE vencida que se
  poda seguía entrando en el orden; un **deny vencido** podado contaba en el grafo unión como un deny que «ya niega» y
  quitaba una precedencia (47 pares sin residuo en la primera muestra: U ∈ h entraba antes de que h ⊂ g saliera).
  Arreglo: `applyPartition` poda las sobrantes vencidas (`plan.expiredDelete`) PRIMERO y FUERA del orden (no conectan
  nada). Con eso: 0.

**Cifras** (semilla 20261016; misma cifra en atómico y dos `Write` salvo `renewalUnsafe`):

| universo | modo | combinaciones (×2 modos) | sin residuo que concede | con ciclo | conceden | inherentes | renewal-unsafe (dos Write) |
|---|---|---|---|---|---|---|---|
| **E1-reduced (8)** | **EXHAUSTIVO** | 11 529 602 | **0** | 96 040 | 22 280 | 9 464 | 3 769 570 |
| E1-reduced | muestra | 600 000 | 0 | 5 057 | 1 113 | 460 | 195 475 |
| E1 (10) | muestra | 600 000 | 0 | 1 369 | 308 | 127 | 234 858 |
| U2 (21) | muestra | 60 000 | 0 | 296 | 16 | 2 | 40 078 |
| E3 (20) | muestra | 60 000 | 0 | 968 | 8 | 4 | 48 788 |
| guardia (E1-reduced) | muestra | 100 000 | 0 | 830 | 172 | 67 | 32 615 |

`malformed` = 0 en todas. El exhaustivo tarda ~106-111 s por tipo de destino: va GATEADO
(`AUTHZ_ORDER_VIGENCIA_EXHAUSTIVE=1`, caso con las cifras fijadas); la suite por defecto corre las muestras declaradas
(~40 s). «Inherentes» se mide sobre el diff de vigencia real (permutaciones de escrituras/borrados; el hueco de una
renovación no entra en esa DP): es una cota de lo inevitable, no la garantía. **Residuo nuevo: ninguno** — todo lo que
concede tiene ciclo declarado; no hace falta tocar `orderResidue`.

**Ficheros.** `tests/helpers/order_bruteforce.ts`, `tests/relations_order_exhaustive.spec.ts` (grupo nuevo: 8 muestras + 1
exhaustivo gateado), `src/relations/reconcile.ts` (`expiredDelete`, `applyPartition`), `tests/guard_surface.spec.ts`,
`tests/fixtures/guard_manifest.ts`, `tests/fixtures/guard_mutants.json`, README, CHANGELOG.

**Guardia.**
- `relations.order.exhaustive`: además del exhaustivo de presencia (131 072), muestra declarada de 50 000 combinaciones por
  modo con vigencia, en los dos tipos de destino, cifras fijadas. Título actualizado (13 `expectRed` + manifiesto).
- `relations.reconcile.order`: 4 filas nuevas sobre el doble — portadora vencida (C2-1), arista vencida con `toConfig`
  (R7), sobrante vencida (membresía) y sobrante vencida (deny condicional, inyectado en la enumeración: el doble no puede
  escribirlo y en FGA solo existe escrito a mano) con `--prune`. La fila admite `toConfig` (`cuts: true`) y `extra`.
- Mutantes nuevos: **`rec.plan.vigencia-ignored`** ⇒ MUERTO (2 rojos: las dos propiedades) y
  **`rec.apply.expired-deletes-in-order`** ⇒ MUERTO (1). Medido antes de la fila del deny: vivo — por eso está la fila.
- R5 y R7 como casos de contrato en los dos drivers: arriba (C2-1).

**README:843-845** («if the precedence graph has no cycle, no state … grants …»): queda cierta y ahora lo dice con su
precondición explícita: párrafo nuevo «Validity is part of the universe» con las cifras; el plan hace que valga para el
store tal como está (vencida = ausente; sobrantes vencidas fuera del orden).

## 3 · 🟡 C2-3 — TOCTOU de N1

**Qué** (`src/drivers/openfga_relations_driver.ts` · `relate`, `src/errors.ts`):
- Tras los dos `Write` de una renovación de membresía NO portadora, `#recheckCarried` (= `#carriedDeny`, sin lanzar).
  - Deny encontrado ⇒ `RenewalUnsafeError.raced(membership, deny)`: 409 `E_AUTHZ_RENEWAL_UNSAFE`, `renewalApplied: true`,
    `carriedDeny`, marcado `markPartialWrite` (el manager notifica `indeterminate: true`). Letra: «SE APLICÓ … el deny ya
    confirmado NO alcanzó al sujeto … receta».
  - La re-lectura falla ⇒ el 503 de la re-lectura, marcado parcial, con `carriedDenyUnknown` y la nota «SE APLICÓ, pero la
    re-comprobación falló».
- Si cae el 2.º `Write`: la re-comprobación corre igual y `annotateRacedDeny` añade al error (clase y `code` intactos)
  `carriedDeny` y la nota «la membresía quedó BORRADA … vuelve a escribirla (relate: UN Write)».
- README: ventana DECLARADA junto a «Every other renewal stays two `Write`s» (no se cierra: FGA no tiene primitiva para
  serializar `deny` contra la renovación). Tabla de errores actualizada.

**Caso** (`tests/relations_openfga.spec.ts`, «🟡 C2-3 …»): la barrera-espía existente (Proxy sobre `client.write`) mete
`admin.deny(g#member)` desde otro driver sobre el mismo store tras `#carriedDeny` y antes del delete, y comprueba que el deny
está confirmado. Dos variantes: (i) renovación completa ⇒ 409 parcial, `renewalApplied`, `carriedDeny` ~ `denied_viewer`, un
evento `indeterminate`, final niega; (ii) 2.º `Write` caído ⇒ 503 parcial con `carriedDeny`, «quedó BORRADA», final CONCEDE
(el caso persistente) y la receta (`relate`) lo repara.

**Mutantes.** `c23.fga.no-recheck` ⇒ MUERTO (1) · `c23.fga.no-annotate-on-failure` ⇒ MUERTO (1).

**Cuatro líneas.** (a) Gemelos: `database` renueva en una transacción (no aplica); el doble del juez es síncrono (sin
ventana: no aplica); roles: el `assignee` no transporta deny (gemelo de N1, no aplica) — su fallo parcial es C2-5. (b) Ejes:
{deny concurrente sí/no} × {2.º Write ok/cae} × {re-lectura ok/falla}: las cuatro filas con deny/sin deny × ok/cae tienen
rama propia en el código; las dos con deny, caso; «re-lectura falla» sin caso (requiere inyectar dos fallos ordenados; rama
pequeña y fail-loud). (c) Ningún caso existente rojo. (d) L10, mismo cierre de N1; la ventana queda declarada, no cerrada.

## 4 · ⚪ C2-4 — `relate` sobre una portadora YA vencida

**Qué.** `openfga`: `guarded = object.type === 'group' && isActiveExpiry(previous, now)`; una vencida se reescribe (delete +
write) sin comprobar portadora. `#carriedDeny` salta aristas de anidación vencidas. El doble del juez, igual
(`active(existing)`, `active(t)`).

**Caso.** En la cara `atomicRenewal:false` del juez publicado (`runRelationsDriverContract`; doble y `openfga` real):
membresía portadora vencida ⇒ `relate(…, { expiresAt: null })` entra y el deny vuelve a alcanzar al sujeto; membresía
cuyo único camino al deny es una arista vencida ⇒ se renueva. Sin cambio de título ni de conteo (dentro del caso existente).

**Mutantes.** `c24.fga.expired-still-guarded`, `c24.fga.expired-edge-carries`, `c24.double.expired-still-guarded`,
`c24.double.expired-edge-carries` ⇒ los cuatro MUERTOS (1 cada uno).

## 5 · ⚪ C2-5 — gemelo de roles: 2.º `Write` caído al renovar un grant

**Qué.** `src/drivers/openfga_driver.ts` · `replaceAssignment`: si `writeTuples` falla tras `deleteTuples` ⇒
`markPartialWrite`. `src/manager.ts` · `#write`: `indeterminate: true` para timeout O parcial (la misma rama que el
`RelationsManager`). Docblock del CHANGELOG/README.

**Casos** (`tests/openfga_driver.spec.ts`, grupo «⚪ C2-5»): driver con cliente falso — `deleteTuples` entra, `writeTuples`
cae ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE` con `isPartialWrite`; control: el 1.er grant (UN Write) que falla NO se marca.
Manager con driver falso — error marcado ⇒ un evento `granted` con `indeterminate: true`; sin marca ⇒ sin evento.

**Mutantes.** `c25.roles.driver-no-partial` ⇒ MUERTO (1) · `c25.roles.manager-no-partial-branch` ⇒ MUERTO (1).

---

## Mutantes (resumen)

A mano sobre copia (`scratchpad/c3/mutants.py`, resultados en `scratchpad/c3/mutants.json`): **10 / 10 muertos**.
En el corredor de la guardia: `rec.plan.vigencia-ignored`, `rec.apply.expired-deletes-in-order` (nuevos) y
`rec.apply.writes-then-prune` (`find` actualizado), muertos; corredor completo: ver Verificación.

## Ficheros tocados en el cierre 3

`src/relations/reconcile.ts`, `src/drivers/openfga_relations_driver.ts`, `src/drivers/openfga_driver.ts`, `src/manager.ts`,
`src/errors.ts`, `src/testing/relations_contract.ts`, `src/testing/relations_reconcile_contract.ts`,
`tests/helpers/order_bruteforce.ts`, `tests/relations_order_exhaustive.spec.ts`, `tests/relations_openfga.spec.ts`,
`tests/openfga_driver.spec.ts`, `tests/relations_harness.spec.ts`, `tests/guard_surface.spec.ts`,
`tests/fixtures/guard_manifest.ts`, `tests/fixtures/guard_mutants.json`, `README.md`, `CHANGELOG.md`.

## Verificación (yo, en primer plano y en secuencia; `docker restart openfga-dev && sleep 8` antes de cada suite con OpenFGA)

Node 22, `OPENFGA_TEST_URL=http://localhost:8090`, `TEST_PG_URL` con la contraseña de `postgres18`. Logs en
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/c3/`.

| paso | resultado |
|---|---|
| `npm run build` (purity + typecheck + tsc) | exit 0 |
| `npm test` (`:memory:` + OpenFGA) | **2037 passed, 3 skipped (2040)** (antes 2018/2) |
| `test:sqlite-file` | **2065 passed, 3 skipped (2068)** (antes 2046/2) |
| `test:pg` | **2162 passed, 2 skipped (2164)** (antes 2143/1) |
| `test:mysql` | **2164 passed, 2 skipped (2166)** (antes 2145/1) |
| reproducciones R1–R7 del auditor | todas en el sentido correcto (arriba) |
| exhaustivo con vigencia E1-reduced | 2 × 11 529 602, 0 sin residuo, 0 malformados |
| mutantes a mano C2-1…C2-5 | **10 / 10 muertos** |
| `check:guard-mutants` | **178 muertos / 178**, 0 vivos (760 s; antes 176) |
| `check:flag-mutants` | **37 / 37 muertos**, 0 vivos, 1 pendiente (`--prune-undeclared`), VERDE |
| `cutover-runbook` sqlite-file | VERDE (2 verdes, 0 rojos) |
| `cutover-runbook` pg | VERDE (2 verdes, 0 rojos) |

El skip nuevo es el exhaustivo gateado. Tras la última suite solo cambió un docblock de `src/manager.ts#write`
(typecheck y purity en verde después). Nada queda corriendo en segundo plano.

## No hecho (con razón)

- **Cerrar la ventana de C2-3**: no hay primitiva en FGA para serializar `deny` contra la renovación; queda declarada y
  ruidosa.
- **Caso de la rama «la re-lectura de C2-3 también falla»**: necesita inyectar dos fallos ordenados; la rama es pequeña,
  marca parcial y deja `carriedDenyUnknown`. Candidato para el auditor.
- **El orden con reloj del servidor FGA** (pregunta abierta 1 del auditor): el plan usa el `now` del paquete; un desfase
  con `current_time` del servidor solo mueve la frontera milisegundos en las dos direcciones. Sin cambio.
- `CLAUDE.md` (mapa: `liveInDestination`, `expiredDelete`, `RenewalUnsafeError.raced`, rama parcial del manager de
  roles), `linajes.md` y `RETOMAR.md`: le tocan al coordinador.
