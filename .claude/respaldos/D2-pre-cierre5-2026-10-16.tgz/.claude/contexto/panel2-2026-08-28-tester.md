# Panel 2 · 28-08-2026 — Tester de contrato

> Entradas: `CLAUDE.md`, `propuesta-jerarquia-hechos-2026-08-28.md`, `panel-2026-08-28-juez.md`.
> Informe previo: `panel-2026-08-28-tester.md` (su §9 se reutiliza, no se repite).
> **Todo lo marcado 📏 está EJECUTADO contra el OpenFGA de `:8101` hoy.** Scripts en
> `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
> (`facts_model.mjs`, `facts_model_c.mjs`, `demo_facts.mjs` … `demo_facts5.mjs`).

**Línea base medida hoy:** `OPENFGA_TEST_URL=http://localhost:8101 npm test` → **67 passed (67)**, 7 s.

---

## 0. Las cinco mediciones que cambian el plan

Antes de responder P2/P3, cinco hechos ejecutados. Los cinco son de verificabilidad y
los cinco tienen consecuencia directa sobre el diseño del juez.

### 0.1 📏 El modelo `role` global (opción (b) de la propuesta, y el que hay hoy en el store `authz-panel2-sec`) **rompe el caso 9 del juez**

`demo_facts3.mjs`, store `01M14B376JS0KE7W5K6MSE47N2`:

```
9-facts  authorize(alice,docs:write,orgA) = true  (esperado true)
9-facts  authorize(alice,docs:write,orgB) = true  (esperado FALSE — invariante 1)
9-facts  authorize(alice,docs:write,app)  = false (esperado false)
```

Con el rol como objeto global (`role:<uuid>`) y el catálogo materializado como
`role → P_role → scope`, la tupla de grant es `user:alice#assignee@role:<uuid>`: **no
contiene el scope**. `grant(alice,'org-editor',orgA)` y `grant(alice,'org-editor',orgB)`
son la MISMA tupla. Un grant en una organización autoriza en todas las que usen ese rol
del catálogo — fail-open que viola el invariante 1 y el caso `scope aislado`
(`contract.ts:134`).

**Consecuencia:** el modo facts **obliga** a la opción (c) de la propuesta — binding por
scope, `role_binding:<scopeKey>|<roleUuid>`, igual que hoy. La (b) queda descartada por
ejecución, no por razonamiento.

### 0.2 📏 Con binding por scope, el modo facts pasa 20/20 casos semánticos

`demo_facts4.mjs`, store `01M14B4QPAG443ZRWJ1HPBW4VC`, modelo `facts_model_c.mjs`:

```
type role_binding · define assignee: [user, user with not_expired]
type scope
  define parent: [scope]
  define P_binding: [role_binding]
  define P: assignee from P_binding or P from parent
  define denied_P: [user] or denied_P from parent
  define can_P: P but not denied_P
```

```
PASS C9a  authorize(alice,docs:write,orgA)          PASS C12e deny quirúrgico: docs:read intacto
PASS C9b  aislamiento orgA/orgB                     PASS C12f removeDeny restaura
PASS C9c  nunca hacia arriba (app)                  PASS C13a holder polimórfico admin
PASS C10  herencia orgA→unit (1 solo Check)         PASS C13b user:alice sigue sin orgB
PASS C3   permiso fuera del rol                     PASS C14a moved: alice PIERDE unit
PASS C11a app→orgB                                  PASS C14b moved: admin GANA unit
PASS C11b app→unit                                  PASS C14c moved: bob (app) mantiene
PASS C12a deny en orgA bloquea orgA                 PASS C15a expirada no concede (heredado)
PASS C12b deny hereda a unit                        PASS C15b futura sí concede
PASS C12c deny no toca orgB                         PASS C12d deny no toca app
TODOS OK (20)
```

Herencia de dos niveles, deny-wins heredado, caducidad por condición, aislamiento entre
hermanos y `moved` **funcionan con un solo `Check`**. La respuesta a P1 en la parte que
me toca (¿es observable?) es **sí**.

### 0.3 📏 Un ciclo en FGA no lanza: **concede de más, en 3 ms, en silencio**

`demo_facts2.mjs`, store `01M14B1AZWZSPHPG4934Z54HMF`:

```
8a sin ciclo · check en X (ancestro) = false   (correcto: nunca hacia arriba)
8b CON ciclo · check en X (ancestro) = true    (FAIL-OPEN: el grant sube al ancestro)
  ciclo X<->Y, Check en X -> allowed=true (3 ms)
  ciclo X<->Y, Check en Y -> allowed=true (3 ms)
  self-loop Z->Z, Check en Z -> allowed=false (2 ms)
```

FGA **no detecta ciclos**: no lanza, no se cuelga, responde. Un ciclo introducido por
drift (o por un `attached` sin validar) convierte la herencia en bidireccional y **sube
grants a los ancestros**. Es el peor fallo posible contra el invariante 1 y es
completamente mudo.

⇒ "ciclo ⇒ lanza" tiene que ser **del paquete** (validación en `scopes.attached/moved`
con `resolveAncestors` antes de escribir), y el caso de contrato tiene que fijar **las dos
mitades**: (a) el paquete lanza; (b) si el ciclo se cuela por drift, `verify` lo lista —
porque el motor no va a avisar.

### 0.4 📏 `ListObjects` sobre `can_P` **sí** enumera descendientes heredados

```
9  listObjects can_docs_write: [ 'scope:app', 'scope:organization|a', 'scope:unit|u' ]
9b listObjects tras deny en A:  [ 'scope:app' ]
```

Con un grant solo en `app`, FGA devuelve `app`, `organization|a` y `unit|u`. El
invariante 7 de `CLAUDE.md` dice literalmente lo contrario: *"los `list*` no enumeran
herencia"*. En modo facts, implementar `listScopes` con `ListObjects` sería la vía
natural y **rompería el invariante 7 sin que ningún test actual lo notara** (los 19 casos
usan `includeMembers`/`notInclude`, no igualdad estricta: `contract.ts:245-246`).

⇒ Caso negativo obligatorio, y **cambiar `includeMembers` por igualdad de conjunto** en
`listScopes`/`listRoles`/`listRoleScopes`. Nota lateral: `9b` demuestra que el deny sí
poda el `ListObjects`, así que la tentación va a ser fuerte.

### 0.5 📏 Un permiso del catálogo local que no está en el modelo FGA da **400 → 503**

`demo_facts5.mjs`:

```
can_docs_read -> allowed= false
can_no_existe -> FgaApiValidationError 400 : invalid relation: relation 'scope#can_no_existe' not found
can_docs_write-> FgaApiValidationError 400 : invalid relation: relation 'scope#can_docs_write' not found
scope fantasma -> false
sin context   -> false
```

Dos consecuencias:

1. **Invariante 5** (`permiso desconocido ⇒ false, nunca throw`) solo se sostiene porque
   el driver consulta el catálogo local primero (`openfga_driver.ts:433`). En facts eso
   deja de ser una optimización y pasa a ser **carga estructural**. Caso obligatorio.
2. Peor: `docs:write` **está** en el catálogo local pero el modelo se publicó cuando solo
   existía `docs:read`. El short-circuit local **no lo atrapa** ⇒ cada `authorize` sobre
   ese permiso es un 503. Es el problema 5 de la propuesta, y es **observable**: caso
   nuevo "catálogo y modelo desincronizados".

---

## 1. P2 · ¿Un solo juez para tres modos?

**Sí, sin bifurcar, con una condición estructural: el árbol deja de ser una inyección del
harness y pasa a ser una abstracción del CONTRATO.** Hoy el juez no menciona el árbol en
ninguna línea; por eso los 8 casos que dependen de él pasan por accidente (con el
resolutor plano por defecto) y **pasarían en falso en modo facts**.

### 1.1 El mecanismo: `ContractScopeTree`, no `hierarchy: 'facts'|'resolver'`

La suite **no debe saber** en qué modo está. Si la suite pregunta `if (harness.hierarchy
=== 'facts')`, ya está bifurcada. Lo que se parametriza es **quién materializa el árbol**:

```ts
export interface ContractScopeTree {
  attach(child: ScopeRef, parent: ScopeRef): Promise<void>
  move(child: ScopeRef, newParent: ScopeRef): Promise<void>
  detach(child: ScopeRef): Promise<void>
  edges(): AsyncIterable<{ child: ScopeRef; parent: ScopeRef }>
}

export interface DriverContractHarness {
  name: string
  level: 'core' | '1.2' | '1.3' | '2.0'
  capabilities: DriverCapabilities
  seedCatalog(catalog: CatalogSpec): Promise<void>
  makeDriver(tree: ContractScopeTree): Promise<AuthorizationDriver>  // ⭐ recibe el árbol
  makeTree(): Promise<ContractScopeTree>                             // ⭐ nuevo
  cleanup(): Promise<void>
}
```

- Harness **database / openfga-resolver**: `makeTree()` devuelve un `memoryTree` (un `Map`
  hijo→padre respaldado por la tabla ficticia `demo_scopes`); `makeDriver` le inyecta al
  driver un `resolveAncestors` que camina ese mismo `Map`. `attach/move/detach` solo tocan
  el `Map`. Es el harness de resolutor de ancestros de la §9 #3, generalizado.
- Harness **openfga-facts**: `makeTree()` devuelve un `factsTree` que **(a)** actualiza el
  mismo `Map` (porque `resolveAncestors` sigue haciendo falta en escrituras, `hasRole` y
  `verify` — ver 1.4) y **(b)** llama a `manager.scopes.attached/moved/detached`, que
  escriben las tuplas `parent` y los bindings de catálogo.

La suite escribe siempre `await tree.attach(orgA, APP_SCOPE)`. **Cero condicionales.**
Y con eso el caso 10 (`herencia hacia abajo`) deja de pasar por el default del resolutor
y pasa a probar lo que dice su nombre en los tres modos.

**Efecto lateral de higiene**: hoy `contract.ts` habla con `driver.*` directamente
(`contract.ts:62`); `scopes.*` es API del manager. Con `ContractScopeTree` el juez **no
necesita el manager**: el harness decide si detrás hay un manager, un `Map` o tuplas.
Esto mantiene el juez publicable para drivers de terceros (`./testing`) sin arrastrar el
manager al paquete de test.

### 1.2 Los 19 casos actuales, uno a uno

| # | `contract.ts` | Caso | ¿Corre sin cambios en facts? | Qué necesita |
|---|---|---|---|---|
| 1 | :69 | grant concede permisos | ✅ | catálogo materializado en `app` por `seedCatalog` |
| 2 | :76 | sin asignación → false | ✅ | — |
| 3 | :80 | fuera del rol / desconocido → false | ⚠️ **solo por el short-circuit local** | 📏 0.5: `can_no:existe` da 400→503. **Caso negativo obligatorio** |
| 4 | :90 | revoke retira | ✅ | — |
| 5 | :97 | grant de rol inexistente lanza | ✅ | catálogo local, no toca FGA |
| 6 | :103 | deny gana / removeDeny restaura | ✅ | — |
| 7 | :116 | deny de permiso desconocido lanza | ✅ | catálogo local |
| 8 | :120 | expirada / futura | ✅ | 📏 C15a/C15b |
| 9 | :134 | **scope aislado orgA/orgB/app** | ❌ **pasa en falso** | `tree.attach` de orgA y orgB. Sin ellos FGA responde false por no existir el nodo: el test verde **por la razón equivocada** |
| 10 | :147 | **herencia app → org** | ❌ **FALLA** | `tree.attach(org, APP)`. Sin la arista, `can_P` en la org es false |
| 11 | :155 | deny cercano bloquea heredado | ❌ **FALLA** | `tree.attach` ×2 |
| 12 | :167 | holder polimórfico | ✅ | 📏 C13a/C13b |
| 13 | :177 | grant idempotente + `listSubjects` | ✅ | `Read` sobre `role_binding:app\|<uuid>#assignee` |
| 14 | :194 | **`hasRole` respeta herencia** | ❌ **FALLA** y **no es un solo Check** | ver 1.4 — es el hallazgo estructural |
| 15 | :213 | `listSubjects` vigentes | ⚠️ | el grant en `otherScope` exige que ese scope exista con catálogo materializado |
| 16 | :232 | `listScopes` sin denegados | ❌ **riesgo de fail-open** | `tree.attach` ×2 + 📏 0.4: prohibido `ListObjects`; assert por igualdad de conjunto |
| 17 | :249 | no-ops seguros | ✅ | — |
| 18 | :256 | `listRoles` directos | ❌ | `tree.attach(orgA)` |
| 19 | :276 | `listRoleScopes` | ❌ | `tree.attach` ×2 |

**Cuenta: 11 corren sin cambios · 8 exigen el árbol · de esos, 3 pasan hoy en falso
(9, 15, 16) y 5 fallarían directamente en facts (10, 11, 14, 18, 19).**

La lectura importante no es "8 hay que tocar". Es esta: **el invariante 1 —el que el
README vende como la característica principal— hoy solo está probado en su caso trivial**
(ya lo dije en §9 #3 del informe anterior). El modo facts no lo rompe: lo **destapa**. Los
mismos 8 casos, reescritos sobre `ContractScopeTree`, valen más para `database` que para
facts.

### 1.3 Cambio de firma obligatorio en el harness (hoy imposible en facts)

`contract.spec.ts:258-272` provisiona el store **dentro de `cleanup`**, y
`provisionOpenFgaStore` genera el modelo **solo desde `holderTypes`**. En facts el modelo
depende del **catálogo** (una relación `P`, `denied_P`, `can_P`, `P_binding` por permiso).
El orden actual `cleanup → seedCatalog → makeDriver` es incompatible.

Orden nuevo, obligatorio: **`cleanup → seedCatalog → makeTree → makeDriver`**, y
`provisionOpenFgaStore(apiUrl, name, holderTypes, catalog)`.

Lo bueno: **el aislamiento por store ya existe** (store nuevo por test,
`contract.spec.ts:261`). No hay que inventar "un segundo store FGA por test": ya está, y
resuelve gratis el problema de los modelos regenerados. Coste real de esta pieza: bajo.

### 1.4 🔴 Hallazgo estructural: `hasRole` **no** puede ser un solo `Check` en facts

`hasRole(alice, 'editor', unit)` pregunta *"¿tiene el ROL editor en la cadena de unit?"*,
no *"¿tiene un permiso?"*. En el modelo por bindings el rol vive en el id del objeto
(`role_binding:<scopeKey>|<uuid>`), no en una relación ⇒ para responder hay que saber
**qué scopeKeys** hay en la cadena ⇒ **hay que llamar a `resolveAncestors`**.

Las alternativas se caen solas:
- Una relación `has_role_<uuid>` por rol en el modelo ⇒ el modelo cambia cada vez que se
  crea un rol ⇒ incompatible con roles por tenant (`catalog/`, Fase 3).
- `scope#inherited_binding: [role_binding] or inherited_binding from parent` + `Check(user,
  assignee, role_binding:?)` ⇒ dos Checks y **sigues sin saber el scopeKey** del binding.

⇒ **El requisito 1 del dueño ("un solo `Check`, sin SQL en el camino caliente") se cumple
para `authorize`, NO para `hasRole`, `listRoles`, `listRoleScopes`, `listSubjects` ni
`listScopes`.** Eso no invalida la propuesta —`authorize` es el camino caliente real— pero
**tiene que estar declarado como capacidad y probado con un caso negativo**, o el README
mentirá otra vez (III.6.7 del informe anterior).

Capacidad: `singleCheckAuthorize: true` / `roleInheritanceNative: false`.
Caso obligatorio, con el espía de la §9 #7 extendido a `resolveAncestors`:

> **dado** un harness facts con espía sobre `resolveAncestors` y sobre el cliente FGA
> **cuando** se llama `authorize(alice,'docs:write',unit)`
> **entonces** `resolveAncestors` se llamó **0 veces** y hubo exactamente **1** `check` y **0** `batchCheck`
>
> **y cuando** se llama `hasRole(alice,'editor',unit)`
> **entonces** `resolveAncestors` se llamó **≥1 vez** — *el contrato declara la asimetría en vez de esconderla*

### 1.5 Casos NUEVOS que el modo facts exige

#### Al NÚCLEO (los tres modos, sin condicional) — 9 casos

| # | dado → cuando → entonces |
|---|---|
| N1 | **dado** `attach(orgA,app)`, `attach(unit,orgA)`, grant `editor@app` → **cuando** `authorize(_,'docs:write',unit)` → **entonces** `true` (herencia de **2 niveles**, no uno). *Hoy no existe: el resolutor por defecto solo produce cadenas de longitud 2.* 📏 C10 |
| N2 | **dado** el árbol anterior y `deny(alice,'docs:write',orgA)` → **cuando** se pregunta en `unit`, `orgB` y `app` → **entonces** `false, true, true` (deny hereda hacia abajo y **solo** hacia abajo). 📏 C12b/c/d |
| N3 | **dado** grant `org-editor@orgA` → **cuando** `authorize` en `orgB` → **entonces** `false`. *Existe (:143) pero hay que **rehacerlo sobre `tree`**: es el que caza 📏 0.1* |
| N4 | **`moved` cambia la respuesta del subárbol.** **dado** grant `org-editor@orgA`, `unit` bajo `orgA`, `authorize(unit)=true` → **cuando** `tree.move(unit, orgB)` → **entonces** `authorize(unit)=false`, `authorize(orgA)=true` **sin ninguna otra escritura**. 📏 C14a |
| N5 | **`moved`, cara positiva.** **dado** grant `org-editor@orgB` y `authorize(unit)=false` → **cuando** `move(unit,orgB)` → **entonces** `true`. *Sin N5, N4 se satisface borrándolo todo.* 📏 C14b |
| N6 | **`moved` no toca lo heredado de la raíz.** **dado** grant `editor@app` → **cuando** `move(unit,·)` → **entonces** `authorize(unit)` sigue `true`. 📏 C14c |
| N7 | **`detached` purga.** **dado** grant y deny en `unit` → **cuando** `tree.detach(unit)` → **entonces** `listRoles(alice,unit) = []`, `listScopes(alice,'docs:write')` no contiene `unit`, y un `attach(unit, orgB)` posterior **no resucita** el grant. *La última mitad es la que importa: sin ella, "purga" puede ser "desconecta".* |
| N8 | **`detached` es quirúrgico.** **dado** hermanos `unit1`, `unit2` bajo `orgA` con grants → **cuando** `detach(unit1)` → **entonces** los hechos de `unit2` y de `orgA` intactos. |
| N9 | **ciclo ⇒ lanza (paquete, no backend).** **dado** `attach(orgA,app)`, `attach(unit,orgA)` → **cuando** `attach(orgA, unit)` o `move(orgA, unit)` → **entonces** lanza una `Exception` del paquete con status **422** y **no queda escrita ninguna arista** (`tree.edges()` idéntico antes y después). 📏 0.3 justifica el 422 en vez de confiar en FGA |

N4–N9 son **casos del núcleo, no del anexo**: `database` los cumple trivialmente (mueve el
`Map`, `detach` llama a `purgeScope`) y eso es exactamente lo que hay que fijar — que
cambiar de driver no cambie la respuesta.

#### Al ANEXO facts (`capabilities.hierarchyFacts === true`) — 6 casos

| # | dado → cuando → entonces |
|---|---|
| A1 | **`attached` con padre inexistente.** **dado** un padre que `resolveAncestors` no conoce → **cuando** `scopes.attached(child, ghost)` → **entonces** lanza 422 **y no escribe la tupla**. 📏 7a demuestra que **FGA la acepta encantado** ⇒ la barrera es del paquete o no existe |
| A2 | **`authorize` es un solo Check y no toca `resolveAncestors`** (espías). Ver 1.4 |
| A3 | **`hasRole` SÍ usa `resolveAncestors`** (caso negativo de `roleInheritanceNative: false`). Ver 1.4 |
| A4 | **`listScopes` no enumera herencia.** **dado** grant solo en `app` y 3 orgs con arista → **cuando** `listScopes(alice,'docs:write')` → **entonces** `deepEqual([app])`, **no** las 3 orgs. 📏 0.4: `ListObjects` devuelve las 3 ⇒ el caso falla si alguien "optimiza" |
| A5 | **catálogo y modelo desincronizados.** **dado** un permiso añadido a `authz_permissions` **sin** republicar el modelo → **cuando** `authorize(_, ese permiso, _)` → **entonces** error **del paquete** identificable (no un `false` silencioso, no un 503 genérico de red). 📏 0.5: hoy sale 503 indistinguible de "FGA caído" |
| A6 | **`attached` a medias.** **dado** que `attached` escribe `1 + K` tuplas (arista + `K` bindings de catálogo) y el write del bloque de bindings falla → **cuando** se hace `grant` en ese scope → **entonces** o bien la arista tampoco quedó, o bien `verify` lo lista. *📏 medido: `1 arista + 2 tuplas de catálogo` por organization con un solo rol de 2 permisos ⇒ **O(roles×permisos) por scope creado**; es el coste operativo escondido de la propuesta* |

#### Al ANEXO `database` (`hierarchyFacts === false`) — 2 casos, **obligatorios**

Regla del juez (Fase 0): capacidad `false` ⇒ caso negativo, nunca `skip`.

| # | dado → cuando → entonces |
|---|---|
| B1 | **`scopes.*` es no-op observable salvo `detached`.** **dado** driver `database`, grant `org-editor@orgA` y `unit` bajo `orgA` en las tablas del consumidor → **cuando** se llama `scopes.attached(unit, orgB)` **sin** actualizar `demo_scopes` → **entonces** `authorize(unit)` **no cambia**: el árbol de `database` es el de las tablas, no el de las llamadas. *Es lo que hace honesta la recomendación "llama a `scopes.*` siempre".* |
| B2 | **`detached` NO es no-op ni en `database`.** **dado** grant + deny en `unit` → **cuando** `scopes.detached(unit)` → **entonces** `purgeScope` se ejecutó: `listRoles(alice,unit)=[]` y ninguna fila `authz_assignments`/`authz_denies` sobre ese scope. *Cierra N5 del auditor: hoy borrar un tenant deja grants vivos para siempre.* |

---

## 2. P3 · Contrato de migración

### 2.1 Diseño

```ts
export interface MigrationContractHarness {
  name: string                                  // 'database → openfga-facts'
  from: DriverContractHarness
  to: DriverContractHarness
  migrate(ctx: { tree: ContractScopeTree }): Promise<MigrationReport>
  /** Hechos que el destino NO puede representar. Vacío ⇒ round-trip exacto. */
  expectedLosses?: Array<'expiredAssignments' | 'subSecondExpiry' | 'usersets'>
}

export interface MigrationReport {
  assignments: number; denies: number; edges: number
  skipped: Array<{ reason: string; count: number; sample: unknown }>   // ⭐ nunca silencioso
  startedAt: Date; finishedAt: Date
}

export function runMigrationContract(h: MigrationContractHarness): void
```

**Siembra fija** (una constante exportada, `MIGRATION_FIXTURE`, idéntica en las tres
combinaciones — si cada combinación siembra lo suyo, el contrato no compara nada):

- **Árbol**: `app → orgA → unitA1`, `app → orgA → unitA2`, `app → orgB`, `app → orgC → unitC1 → deepC`
  (4 niveles: fuerza cadenas largas), 7 nodos.
- **Holders**: 6 = `users`×3, `admins`×2, `integrations`×1, **uno de ellos con el mismo uuid
  en dos types** (invariante 4).
- **Roles**: `editor@app`, `viewer@app`, `org-editor@organization`, `unit-viewer@unit`, con
  `rank` distinto (invariante 8: debe sobrevivir sin afectar).
- **Grants**: 14 — al menos uno por nivel del árbol, dos del mismo holder en scopes
  hermanos, uno duplicado (idempotencia), uno sobre un **scope fantasma** (existe en el
  origen, no en `enumerateEdges`).
- **Caducidades**: 5 — `null`; futura redonda; futura con **milisegundos ≠ 0**; pasada;
  exactamente `now + 1 ms` (borde).
- **Denies**: 6 — en `app`, en `orgA`, en `deepC`, uno sobre un permiso que ningún rol del
  holder concede (deny huérfano: debe sobrevivir), uno duplicado, uno del holder polimórfico.

**Set fijo de preguntas** (`MIGRATION_QUESTIONS`), evaluado en origen **y** destino y
comparado por igualdad estricta:

```
∀ (holder, permiso, scope) ∈ 6 × 4 × 7   →  authorize()            = 168
∀ (holder, rol, scope)     ∈ 6 × 4 × 7   →  hasRole()              = 168
∀ (rol, scope)             ∈ 4 × 7       →  listSubjects()  (set)  =  28
∀ (holder, scope)          ∈ 6 × 7       →  listRoles()     (set)  =  42
∀ (holder, permiso)        ∈ 6 × 4       →  listScopes()    (set)  =  24
∀ (holder, scopeType)      ∈ 6 × 3       →  listRoleScopes()(set)  =  18
                                                            total  = 448
```

Un solo `assert.deepEqual(answersBefore, answersAfter)` sobre un objeto de 448 claves
ordenadas. **Igualdad de conjunto, no `includeMembers`** — es la única forma de cazar 📏 0.4.

Coste medido: `authorize` en facts ≈ 3 ms ⇒ 448 preguntas ×2 lados ≈ **3 s por
combinación**, 9 s las tres. Aceptable en CI.

### 2.2 Las tres combinaciones

| Combinación | `migrate` | Pérdidas declaradas |
|---|---|---|
| **db → facts** | `openfga:provision --hierarchy=facts` + `openfga:import` (hechos + catálogo materializado + aristas de `enumerateEdges`) | `expiredAssignments` (el importer ya las salta: `openfga_driver.ts:298-301`) |
| **facts → db** | `authz:export --from=openfga --to=database` (`Read` paginado → `authz_assignments`/`authz_denies`) | ver 2.3 |
| **resolver ↔ facts** | solo aristas + bindings de catálogo (los hechos ya están en el mismo formato `role_binding`) | ninguna — **debe ser round-trip exacto**, y es el mejor test de los tres porque cualquier diferencia es un bug puro |

### 2.3 Qué NO sobrevive a facts→db, y cómo el contrato lo hace **fallar**

Cinco pérdidas. La regla es la misma para las cinco: **una pérdida no declarada es un
fallo del test; una pérdida declarada en `expectedLosses` debe aparecer contada en
`report.skipped`.** Ignorar en silencio no es una opción.

1. **El árbol, si hay drift.** En `database` el árbol se lee de las tablas del consumidor;
   en facts vive en tuplas. Si divergieron, `facts→db` adopta el árbol de la BD **sin
   avisar** y 448 respuestas cambian. **Detección**: `runMigrationContract` ejecuta
   `authz:scopes:verify` como **paso 0** y falla si el exit ≠ 0. Caso dedicado:
   > **dado** el fixture migrado a facts **y** una tupla `parent` escrita a mano que mueve
   > `unitA1` bajo `orgB` → **cuando** `migrate()` → **entonces** **lanza**
   > `E_AUTHZ_SCOPE_DRIFT` con las aristas divergentes. *Nunca migra "lo que pueda".*

2. **Hechos sobre scopes fantasma.** 📏 7a: FGA acepta tuplas sobre scopes inexistentes.
   Al pasar a `database` la fila entra (no hay FK a las tablas del consumidor) pero
   `resolveAncestors(ghost)` devuelve `null` ⇒ con L0.3 `authorize` es `false`: **la
   respuesta cambia true→false**. Por eso el fixture **incluye un grant fantasma**:
   > **entonces** `migrate()` **lanza** listando los N hechos sobre scopes desconocidos, o
   > los cuenta en `report.skipped[{reason:'unknownScope'}]` **y** el conjunto de 448
   > respuestas lo refleja idéntico en ambos lados (porque el origen ya respondía false).
   > Lo que el contrato **prohíbe** es que el reporte diga `skipped: []`.

3. **Precisión de la caducidad.** `valid_until` viaja como ISO con milisegundos;
   `expires_at` es una columna. **MySQL `DATETIME` sin precisión trunca a segundos** ⇒ el
   fixture lleva a propósito una caducidad con ms ≠ 0 y otra en `now + 1 ms`. Caso:
   > **dado** un grant con `expiresAt` a `+3600000.457 ms` → **cuando** facts→db→facts →
   > **entonces** el `valid_until` recuperado es **el mismo instante**; si el motor no puede,
   > `expectedLosses` debe incluir `subSecondExpiry` **y** el harness de MySQL debe
   > declararlo. Un `deepEqual` de 448 respuestas no lo caza (ambas siguen vigentes): hace
   > falta la aserción directa sobre el valor, con el **reloj inyectable** (§9 #1).

4. **Usersets y wildcards.** Hoy el modelo generado no los admite
   (`directly_related_user_types` solo lista tipos concretos) ⇒ imposibles de escribir ⇒
   nada que perder. Caso **preventivo**, barato, que fija la frontera antes de `relations/`:
   > **cuando** se intenta `writeTuples([{user:'role_binding:app|X#assignee', …}])` o
   > `user:*` → **entonces** FGA lo **rechaza**. Si algún día pasa, este test se pone rojo y
   > avisa de que facts→db acaba de volverse con pérdida.

5. **Asignaciones ya expiradas.** `db→facts` las salta deliberadamente
   (`skippedExpired`). ⇒ **db→facts→db NO es round-trip**: las filas expiradas desaparecen.
   Las 448 respuestas **no cambian** (expirada = false en ambos lados), así que el
   `deepEqual` **no lo detecta** — y ese es justo el punto:
   > **entonces** `report.skipped` contiene `{reason:'expiredAssignment', count: 1}` **y** el
   > conteo de filas en `authz_assignments` tras el round-trip es `14 - 1`. Sin esta
   > aserción de conteo, el contrato bendice una pérdida silenciosa.

### 2.4 La ventana de migración (grant durante el import)

Tal como está planteada, **no es observable**: `migrate()` es una operación larga sin
puntos de enganche. Hay dos formas de hacerla verificable; recomiendo la segunda.

**(a) Medir la pérdida (documenta el agujero, no lo cierra).** Espía sobre
`client.writeTuples` que, en el chunk 2 de N, hace un `grant(dave,…)` contra el driver
**origen**. Entonces:
> `authorize(dave,…)` en el destino es `false`, y `report` lo delata: `finishedAt` es
> posterior al grant y un `authz:migration:diff --since=<startedAt>` lista exactamente 1
> hecho no migrado.

Requiere que `MigrationReport` lleve `startedAt` y que exista el `diff`. Es honesto pero
deja el sistema en estado incorrecto: **el consumidor se entera después**.

**(b) Cerrar la ventana y probar el cierre.** El manager gana
`freeze()` / `unfreeze()`; `migrate()` lo hace por su cuenta. Caso:
> **dado** un manager congelado por `migrate()` → **cuando** cualquier escritura
> (`grant`/`revoke`/`deny`/`removeDeny`/`scopes.*`) → **entonces** lanza
> `E_AUTHZ_MIGRATION_IN_PROGRESS` (**503**, reintentable) — y las **lecturas siguen
> respondiendo** (`authorize` no se congela: congelar lecturas es un apagón).
>
> **y cuando** `migrate()` termina → **entonces** la misma escritura pasa.
>
> **y** caso inverso: **dado** un `migrate()` que **lanza** a mitad → **entonces** el
> manager queda **descongelado** (`finally`), no bloqueado para siempre. *Este es el caso
> que se olvida y deja la app muerta tras un fallo.*

(b) es 100 % testeable en proceso, sin infra nueva, sin `sleep`, y convierte "exige
ventana" de nota en el README a **comportamiento del paquete**. Recomiendo (b) + el
`diff` de (a) como red.

**Lo que NO se puede probar:** dual-write / migración en caliente sin ventana. No está
propuesto y no debería estarlo: sin transacción común entre Postgres y FGA, no hay caso
de contrato que lo demuestre — solo se puede medir la tasa de divergencia, que no es un
test.

---

## 3. `authz:scopes:verify`

### 3.1 📏 Restricción medida del API que condiciona el diseño

`Read` **no admite filtrar solo por relación**:

```
read {"relation":"parent"}                  -> 400 "the 'tuple_key' field was provided but the
read {"object":"scope:","relation":"parent"} -> 400  object type field is required and both the
read {"type":"scope","relation":"parent"}    -> 400  object id and user cannot be empty"
read {"object":"scope:unit|u","relation":"parent"} -> OK, 1 tupla
read({})                                     -> OK, TODAS las tuplas del store (paginado)
```

(`ReadRequestTupleKey` solo tiene `user`/`relation`/`object`; `apiModel.d.ts:1174`. El
`{type:'scope'}` que parece funcionar es un campo **ignorado** ⇒ equivale a `read({})`.)

⇒ **`verify` tiene dos estrategias y ninguna las cubre todas:**

| Estrategia | Coste | Detecta faltante / distinto | Detecta **sobrante** |
|---|---|---|---|
| `Read` por hijo, uno por cada arista de `enumerateEdges` | 1 llamada / nodo | ✅ | ❌ (solo mira los hijos que el consumidor ya conoce) |
| `read({})` completo, paginado | todas las tuplas del store | ✅ | ✅ |

La arista **sobrante** —la del subárbol que el consumidor borró de su BD sin pasar por
`scopes.detached`— es precisamente el drift más peligroso (deja vivo un padre que ya no
existe). **Solo se ve con el barrido completo.** ⇒ `verify` debe tener dos modos:
`--quick` (por hijo, para un hook post-deploy) y `--full` (barrido, para cron), y **el
contrato debe fijar que `--quick` NO detecta sobrantes** con un caso negativo explícito;
si no, alguien lo pondrá en CI y creerá que está cubierto.

### 3.2 Casos (8)

| # | dado → cuando → entonces |
|---|---|
| V1 | **dado** árbol de 7 nodos sembrado con `scopes.attached` → **cuando** `verify --full` → **entonces** exit **0** y salida `7 aristas verificadas, 0 diferencias` |
| V2 | **arista sobrante.** **dado** V1 **y** una tupla `parent` escrita a mano para `unit|zzz` (que `enumerateEdges` no emite) → **cuando** `verify --full` → **entonces** exit **≠ 0**, salida contiene `unit\|zzz` marcada `sobrante`. **Y** `verify --quick` sale **0** (caso negativo del alcance de `--quick`) |
| V3 | **arista faltante.** **dado** V1 **y** borrada a mano la tupla `parent` de `unitA1` → **cuando** `verify` (ambos modos) → **entonces** exit ≠ 0, `unitA1 falta`. **Y** el caso que le da sentido: `authorize(alice,'docs:write',unitA1)` con grant en `orgA` es **false** — el drift se ve en la respuesta, no solo en el diff |
| V4 | **padre distinto.** **dado** V1 **y** `UPDATE demo_scopes SET parent = orgB WHERE uuid = unitA1` (sin `scopes.moved`) → **cuando** `verify` → **entonces** exit ≠ 0 con `esperado orgB, encontrado orgA`. **Y** `authorize` sigue respondiendo con el árbol **viejo** (el de FGA) |
| V5 | **ciclo en FGA.** **dado** las tuplas `orgA#parent@unitA1` **y** `unitA1#parent@orgA` → **cuando** `verify` → **entonces** exit ≠ 0 con el ciclo listado. **Caso hermano obligatorio**: 📏 0.3 — `authorize(dave,'docs:write',orgA)` con grant solo en `unitA1` es **`true`** ⇒ el test documenta que el ciclo es **fail-open** y que FGA jamás lo va a señalar |
| V6 | **binding de catálogo faltante.** **dado** V1 **y** borrada la tupla `orgA#docs_write_binding@role_binding:organization\|a\|<uuid>` → **cuando** `verify --full` → **entonces** exit ≠ 0. *`verify` que solo mira aristas deja pasar 📏 A6: `attached` escribe `1+K` tuplas y puede quedarse a medias* |
| V7 | **`enumerateEdges` que lanza a mitad.** **dado** un `enumerateEdges` que emite 3 aristas y lanza → **cuando** `verify` → **entonces** exit ≠ 0 con el error, **jamás** exit 0 con "0 diferencias". *El fallo modo-silencio clásico de las herramientas de reconciliación* |
| V8 | **idempotencia.** **cuando** `verify` se ejecuta dos veces sobre el mismo estado → **entonces** exit y salida idénticos, y **no escribe nada** (espía sobre `writeTuples`: 0 llamadas). *`verify` no es `repair`* |

### 3.3 Cómo se ejecuta en CI sin consumidor real

Con la **tabla ficticia** del harness, que es la generalización de la §9 #6:

```sql
CREATE TABLE demo_scopes (
  uuid varchar(36) PRIMARY KEY,
  type varchar(64) NOT NULL,
  parent_uuid varchar(36) NULL REFERENCES demo_scopes(uuid)
)
```

- `enumerateEdges()` = `SELECT uuid, type, parent_uuid FROM demo_scopes` (async iterable,
  paginado de 100 en 100 para que el paginado también se pruebe).
- `resolveAncestors(scope)` = subida iterativa por `parent_uuid` con `maxDepth` (el
  `hierarchicalScopeResolver` de la Fase 2 sirve tal cual).
- El `memoryTree` del §1.1 **es** esta tabla ⇒ un solo mecanismo alimenta al juez, al
  contrato de migración y a `verify`.
- **Inyección de drift**: dos primitivas del harness, `writeRawEdge(child,parent)` /
  `deleteRawEdge(child)` (tuplas directas, saltándose `scopes.*`) y `UPDATE demo_scopes`
  directo. Con esas dos se producen V2–V6 sin tocar el paquete.
- El comando recibe `scopes.enumerateEdges` del **config**, así que el spec de test
  construye un `AuthorizationConfig` que apunta a `demo_scopes`. **No hace falta app
  anfitriona** — igual que hoy (`tests/helpers/app.ts`).

Coste: la tabla y sus dos resolutores, ~80 líneas. Los 8 casos, ~150. **0,4 d**, y la
mitad ya estaba presupuestada en §9 #6.

---

## 4. Infraestructura: qué se añade a la §9

`ContractScopeTree` **absorbe** la §9 #3 (harness de resolutor) y la §9 #6 (tablas
ficticias) en vez de sumarse a ellas. El **segundo store FGA por test ya existe**
(`contract.spec.ts:258-272`) — no es infra nueva, es un cambio de firma. El **reloj
inyectable** (§9 #1) **sí llega** a `context.current_time`: 📏 la caducidad se evalúa con
el timestamp que manda el **cliente**, no el del servidor FGA (`checkContext()`,
`openfga_driver.ts:116`), así que inyectar el reloj cubre facts sin nada más. Y 📏 un
check **sin** `current_time` responde `false` (no error) ⇒ hay una tercera vía de
fail-closed que también hay que fijar con un caso.

| # | Pieza nueva o modificada | Por qué bloquea | Coste |
|---|---|---|---|
| **10** | **`ContractScopeTree`** + `memoryTree` + `factsTree`; los 8 casos del §1.2 reescritos sobre él | Sin él la suite se bifurca o pasa en falso (📏 0.1 pasa desapercibido). **Es el camino crítico de la Fase 0 de facts** | **0,75 d** (sustituye los 0,5 d de §9 #3) |
| **11** | **Tabla ficticia `demo_scopes`** + `enumerateEdges`/`resolveAncestors` derivados + `writeRawEdge`/`deleteRawEdge` | Alimenta el juez, la migración y `verify` con un solo mecanismo. Es §9 #6 adelantado y generalizado | **0,4 d** |
| **12** | **Firma del harness**: `cleanup → seedCatalog → makeTree → makeDriver`; `provisionOpenFgaStore(..., catalog)` | El modelo facts depende del catálogo; el orden actual es **incompatible** (§1.3) | **0,25 d** |
| **13** | **Espía de `resolveAncestors` y `enumerateEdges`** (contador), extendiendo el espía de cliente de §9 #7 | Único modo de observar `singleCheckAuthorize` y la asimetría de `hasRole` (§1.4). Sin él, el README vuelve a prometer de más | **0,15 d** |
| **14** | **`runMigrationContract`** + `MIGRATION_FIXTURE` + `MIGRATION_QUESTIONS` (448) + `MigrationReport.skipped` | Es la "garantía ejecutable" de la propuesta. Sin `skipped` contado, las pérdidas son invisibles (§2.3 punto 5) | **0,75 d** |
| **15** | **`manager.freeze()`** + su caso (incluido el `finally` que descongela tras fallo) | Única forma de **cerrar** la ventana de migración en vez de documentarla (§2.4) | **0,3 d** |
| **16** | **Harness de `verify`** con inyección de drift, modos `--quick`/`--full` | 📏 3.1: sin barrido completo no hay detección de sobrantes; hay que fijar el alcance de cada modo | **0,4 d** |
| **17** | **Igualdad de conjunto en `list*`** (sustituir `includeMembers`/`notInclude` por `deepEqual` ordenado en `:228`, `:245`, `:266`, `:271`, `:288`) | 📏 0.4: con `includeMembers`, un `listScopes` que enumere herencia **pasa el test**. Barato y con efecto inmediato en los tres modos | **0,15 d** |

**Subtotal nuevo: 3,15 d.** Restando lo que ya estaba en §9 (#3 0,5 + #6 0,75 = 1,25 d) y
lo que se descubre gratis (store por test), el **incremento real sobre la §9 es ≈ 1,9 d**;
la infra total antes de tocar código de facts pasa de **4,5 d → 6,4 d**.

**Orden obligatorio (nada de facts se implementa antes):** 12 → 11 → 10 → 17 → 13 → 16 →
14 → 15. Los cuatro primeros (**1,55 d**) son ganancia pura para `database` y
`openfga-resolver` **aunque facts nunca se implemente**: destapan el invariante 1 y
cierran el fail-open latente de `listScopes`.

---

## 5. Verificabilidad por backend

### 5.1 Grupos de casos × backend

Leyenda: ✅ mismo test, mismo resultado · 🟡 mismo test, riesgo específico · ❌ no aplica /
caso negativo obligatorio · 🔵 test **distinto** (no reutilizable).

| Grupo de casos | SQLite | PG | MySQL | FGA-resolver | FGA-facts | Riesgo específico |
|---|---|---|---|---|---|---|
| Núcleo 1–8, 12, 17 (10 casos sin árbol) | ✅ | ✅ | ✅ | ✅ | 🟡 | facts: caso 3 depende del short-circuit local (📏 0.5) |
| Núcleo con árbol 9–11, 15, 16, 18, 19 | ✅ | ✅ | ✅ | ✅ | ✅ | requiere `ContractScopeTree` en los 5 |
| `hasRole` con herencia (14) | ✅ | ✅ | ✅ | ✅ | 🟡 | facts: no es un Check; usa `resolveAncestors` (§1.4) |
| N1–N3 herencia profunda / aislamiento | ✅ | ✅ | ✅ | ✅ | ✅ | 📏 C9/C10 |
| N4–N6 `moved` | ✅ | ✅ | ✅ | ✅ | ✅ | resolver/db: cambia el `Map`. facts: 2 escrituras **sin transacción** ⇒ ventana en la que el nodo no tiene padre |
| N7–N8 `detached` / purga | ✅ | ✅ | ✅ | ✅ | 🟡 | facts: purga en chunks sin transacción (problema 3 de la propuesta); MySQL: `DELETE` masivo sin `RETURNING` ⇒ el "demuestra cero" del auditor necesita un `SELECT` extra |
| N9 ciclo ⇒ lanza | ✅ | ✅ | ✅ | ✅ | ✅ | mismo test: la validación es del paquete. 📏 0.3: FGA **no** ayuda |
| A1–A6 anexo facts | ❌ | ❌ | ❌ | ❌ | ✅ | `hierarchyFacts:false` ⇒ B1/B2 obligatorios en los otros 4 |
| Caducidad exacta (reloj inyectable) | ✅ | ✅ | 🔵 | ✅ | ✅ | **MySQL `DATETIME` trunca a segundos** ⇒ test propio o `expectedLosses:['subSecondExpiry']` |
| Migración db→facts | 🟡 | 🟡 | 🟡 | — | 🟡 | mismo `MIGRATION_FIXTURE`; el motor SQL solo cambia el origen |
| Migración facts→db | 🟡 | 🟡 | 🔵 | — | 🟡 | MySQL: la precisión de `expires_at` cambia el resultado del round-trip |
| Migración resolver↔facts | — | — | — | ✅ | ✅ | round-trip **exacto**, sin `expectedLosses` |
| `verify` V1–V8 | ✅ | ✅ | ✅ | ❌ | ✅ | resolver: `verify` no aplica (no hay aristas en FGA) ⇒ caso negativo: **el comando lanza** "el driver no está en modo facts", no sale 0 |
| Truncamiento (L0.7) | ❌ | ❌ | ❌ | ✅ | 🟡 | facts: `ListObjects` sigue truncando a 1000/3 s **y ahora enumera descendientes** (📏 0.4) ⇒ superficie mayor |
| Concurrencia / `{trx}` | 🔵 | 🔵 | 🔵 | ❌ | ❌ | bloqueado por pool ≥ 2 (§9 #2). En facts, `transactions:false` es **estructural**, no una limitación del cliente |

**Cobertura hoy: solo SQLite y FGA-resolver.** PG y MySQL siguen a cero (riesgo 6 del
juez). El modo facts **no** empeora eso, pero la fila de caducidad exacta es la primera
que produce un test 🔵 genuinamente distinto por motor.

### 5.2 Capacidades que declara el harness de facts, con su caso negativo

Regla del juez (Fase 0): **cada capacidad `false` obliga a un caso negativo, nunca un
`skip`.** Y añado la simétrica, que es la que faltaba: **cada capacidad `true` obliga a un
caso que la ejerza** — si no, es una etiqueta.

| Capacidad | facts | resolver | database | Caso obligatorio |
|---|---|---|---|---|
| `hierarchyFacts` | `true` | `false` | `false` | `true` → A1 (padre inexistente lanza). `false` → **B1** (`attached` es no-op observable) |
| `purgeScope` | `true` | `true` | `true` | **N7/N8** en el núcleo. Un driver con `false` no es driver 2.0 |
| `singleCheckAuthorize` | `true` | `false` | `false` | `true` → **A2** (espía: 1 `check`, 0 `batchCheck`, 0 `resolveAncestors`). `false` → el espía cuenta **>1** llamada al backend por `authorize` |
| `roleInheritanceNative` | `false` | `false` | `true` | `false` → **A3** (`hasRole` llama a `resolveAncestors`). Es el caso que impide vender "sin SQL en el camino caliente" a secas |
| `listObjectsInherited` | **`false` forzado** | `false` | `false` | **A4**: `listScopes` tras grant solo en `app` ⇒ `deepEqual([app])`. 📏 0.4 demuestra que FGA daría las 3 orgs ⇒ el caso es rojo→verde de verdad |
| `catalogInModel` | `true` | `false` | `false` | `true` → **A5** (permiso local sin relación en el modelo ⇒ error del paquete identificable, no 503 genérico). 📏 0.5 |
| `transactions` | `false` | `false` | `true` | `false` → `grant(..., {trx})` **lanza** un error del paquete (§9 #2, pool ≥ 2) |
| `truncationSignal` | `true` | `true` | `false` | `true` → con `MAX_RESULTS=3`, `listScopes` **lanza/señala** en vez de devolver una lista corta (§9 #4) |
| `strongConsistency` | `true` | `true` | `n/a` | 📏 `HIGHER_CONSISTENCY` soportado en `:8101`. `true` → tras un `grant`, `authorize` inmediato es `true` **sin reintentos**. Sin esta capacidad, todos los casos de facts son *flaky* por diseño |
| `injectableClock` | `true` | `true` | `true` | 📏 el `current_time` lo pone el cliente ⇒ reloj inyectable **cubre facts**. Caso extra: check **sin** `current_time` ⇒ `false` (📏), nunca `true` |

---

## 6. Ejecución: lo que se demostró con checks reales

| Demostración | Store | Resultado |
|---|---|---|
| Modelo facts variante `role` global, caso `scope aislado` | `01M14B376JS0KE7W5K6MSE47N2` | **FALLA**: `orgB = true` cuando debe ser `false` (§0.1) |
| Modelo facts variante `role_binding` por scope, 20 casos | `01M14B4QPAG443ZRWJ1HPBW4VC` | **20/20 PASS**, incluidos herencia de 2 niveles, deny heredado, aislamiento, polimorfismo y **`moved` en sus tres caras** (§0.2) |
| Ciclo, self-loop, `ListObjects` heredado, purga de subárbol, consistencia fuerte | `01M14B1AZWZSPHPG4934Z54HMF` | ciclo = **fail-open mudo**; `ListObjects` enumera descendientes; `HIGHER_CONSISTENCY` OK (§0.3, §0.4) |
| Relación inexistente, scope fantasma, check sin `context`, filtros de `Read` | `01M14B03G7RCS20EFCEEMS85TH`, `demo_facts5` | 400→503 en permiso fuera del modelo; `Read` no filtra por relación (§0.5, §3.1) |
| Suite del paquete, sin tocar nada | — | **67/67**, 7 s |

Los dos que el encargo pedía explícitamente, con sus asertos:

```
C10  herencia orgA→unit (1 solo Check)          PASS   true
C14a moved: alice (grant en orgA) PIERDE unit   PASS   true → false
C14b moved: admin (grant en orgB) GANA unit     PASS   false → true
C14c moved: bob (grant en app) mantiene         PASS   true → true
```

No hice falta esperar al analista: dejó el store `authz-panel2-sec` con un modelo facts,
pero es el de `role` global — el que 📏 0.1 tumba. Construí el mío.

---

## 7. Tabla de cierre

| Ítem | Casos nuevos | Invariantes en riesgo | Coste de prueba | Veredicto |
|---|---|---|---|---|
| **`ContractScopeTree` (juez único, 3 modos)** | 8 casos existentes reescritos + 0 nuevos | **1** (hoy solo probado en su caso trivial) | **medio** (0,75 d) — es el camino crítico | **verificable con cambios**; sin él, bifurcación garantizada |
| **Núcleo N1–N9** (herencia profunda, `moved`, `detached`, ciclo) | **9** | **1**, 2, 7 | bajo tras `ContractScopeTree` (0,4 d) | **verificable** — 📏 8 de los 9 ya ejecutados |
| **Anexo facts A1–A6** | **6** | 1, **5**, 7 | medio (0,5 d) — necesita espías + modelo desde catálogo | **verificable**; A5 es rojo hoy (📏 503) |
| **Anexo `database` B1–B2** | **2** | 6 | bajo (0,15 d) | **verificable** — cierra N5 del auditor |
| **`hasRole` en facts** | 1 (declaratorio) | — | bajo | **verificable, pero la feature no cumple lo prometido**: no es un solo Check (§1.4). Declararlo o retirar la promesa |
| **`listScopes` en facts** | 1 + 5 asserts reforzados | **7** 🔴 | bajo (0,15 d) | **verificable con cambios**: hoy `includeMembers` deja pasar el fail-open (📏 0.4) |
| **`runMigrationContract` db↔facts** | 3 combos × 448 preguntas + **5 casos de pérdida** | 3, **4**, 6 | **alto** (0,75 d + fixture) | **verificable con cambios**: exige `report.skipped` contado y `verify` como paso 0 |
| **Ventana de migración** | 3 (congelado, descongelado, `finally` tras fallo) | 5 | bajo (0,3 d) **si** entra `manager.freeze()` | **no verificable tal cual** → verificable con `freeze()` |
| **`authz:scopes:verify` V1–V8** | **8** | **1**, 2 | medio (0,4 d) | **verificable con cambios**: `--quick` no ve sobrantes (📏 3.1) y hay que decirlo con un caso |
| **Ciclo** | 2 (paquete lanza + fail-open documentado) | **1** 🔴 | bajo | **verificable** — y es el hallazgo con más consecuencia: 📏 FGA concede de más en 3 ms sin avisar |
| **Colisión de slugs `docs:write`/`docs_write`** | 1 | 4, catálogo | muy bajo | **verificable**: 📏 `enc()` produce la misma relación ⇒ `syncAuthzCatalog` debe rechazarlo |
| **Coste operativo de `attached`** | 1 (conteo de tuplas) | — | muy bajo | **verificable**: 📏 `1 + O(roles×permisos)` tuplas por scope creado. Ponerlo en un test de conteo evita que crezca sin que nadie mire |
| **PG / MySQL** | los mismos, ×2 motores | 3 | **alto** (§9 #2, 1,0 d) | **no verificable tal cual** — sigue a cero, y MySQL es el único que produce un test 🔵 propio (precisión de caducidad) |

---

## 8. Las tres cosas que diría en la reunión

1. **El modo facts no rompe el juez: lo destapa.** 8 de los 19 casos dependen del árbol y
   hoy ninguno lo prueba —pasan con el resolutor plano por defecto—. `ContractScopeTree`
   (0,75 d) es ganancia inmediata para `database` **aunque facts se cancele**.

2. **Dos fail-open medidos hoy que ningún test actual vería.** El ciclo (📏 0.3: concede
   hacia el ancestro, en silencio, y FGA jamás lo señala) y `listScopes` vía `ListObjects`
   (📏 0.4: enumera descendientes heredados, y `includeMembers` lo bendice). El segundo se
   cierra con 0,15 d cambiando cinco asertos.

3. **La promesa "un solo `Check`, sin SQL en el camino caliente" vale para `authorize` y
   para nada más.** `hasRole` y los cinco `list*` siguen necesitando `resolveAncestors`
   (§1.4, con demostración de por qué no hay alternativa en el modelo). Es defendible —
   `authorize` es el 95 % del tráfico— pero tiene que entrar en el contrato como capacidad
   con caso negativo, no en el README como titular.
