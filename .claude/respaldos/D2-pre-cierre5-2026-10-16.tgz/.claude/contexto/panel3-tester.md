# Panel 3 — TESTER · ¿cuál de las cuatro opciones se puede PROBAR?

> **Estado: CERRADO.** Escrito de forma incremental durante la sesión.
> Fecha: 2026-08-31. Worktree aislado (solo lectura del repo principal), clavado en `2507f45`:
> `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-tester`.
> Motores: OpenFGA real `:8101`, `postgres18`, `mysql84`, SQLite (`:memory:` y fichero).
> **No soy el juez.** Esto es solo el veredicto de VERIFICABILIDAD.
>
> **En una línea:** las cuatro son falsificables **menos D**, cuya garantía he puesto
> en rojo con una medida (la 2ª pasada se declara **limpia** sobre la pérdida que
> ocurre en su propia ventana). Y el argumento de «A no se puede probar»
> **no se sostiene**: el caso multiproceso existe, cuesta **1 s** y mata un mutante
> que el caso barato deja vivo — pero **no corre en `npm test`** (SQLite en memoria),
> donde ese mismo mutante queda **verde**.

---

## 0. Método y qué he corrido de verdad

Todo lo que sigue está **medido**, no razonado. Ficheros que he escrito y ejecutado en el worktree:

| fichero (en el worktree) | qué mide | motores en los que lo he corrido |
|---|---|---|
| `tests/panel3_d.spec.ts` (7 casos) | la opción **D** como detector | PG 18 + OpenFGA `:8101` real |
| `tests/panel3_a.spec.ts` (4 casos) | la opción **A** (`freeze()` durable), prototipada | sqlite `:memory:`, sqlite-file, PG 18, MySQL 8.4 |
| `tests/helpers/panel3_freeze_child.ts` | el proceso HIJO del caso multiproceso | idem |
| `src/manager.ts` (parcheado) | prototipo mínimo de freeze durable + 3 mutantes | idem |

Higiene: **0 stores** en `:8101` al terminar (comprobado), **0 bases `tester3_*`** en PG y MySQL
(comprobado). Nombres propios `tester3_authz_<8hex>`, borrados por el teardown del harness.

---

## 1. Lo que ya existe (leído antes de opinar)

- **El freeze tiene 6 casos hoy**, todos de INSTANCIA: `tests/reconcile.spec.ts:147` (escrituras 503
  reintentable), `:171` (lecturas siguen), `:185` (`forRequest` hereda), `:205` (el `finally`
  descongela), `:903` y `:1451`. Ninguno afirma nada entre procesos, y hacen bien: hoy no lo hay.
- **`CLAUDE.md` ya lo describe BIEN**: línea 498, *«el estado vive en el manager RAÍZ, así que
  alcanza a las vistas de `forRequest()`»*. Ese es el alcance real. **La frase falsa vive solo en el
  README (~608)**. Consecuencia para el panel: **B no toca ningún invariante**; es alinear el README
  con lo que `CLAUDE.md` ya dice. **A sí cambia ese invariante** (el estado dejaría de vivir en el
  manager raíz).
- **La idempotencia que D quiere reutilizar YA tiene caso**: `tests/reconcile.spec.ts:431` y `:1172`,
  *«idempotencia: la SEGUNDA pasada escribe cero»*, en las dos direcciones. D **no añade ningún
  observable nuevo**: reutiliza una aserción que existe y le cuelga una conclusión.
- **Hay precedente de test multiproceso REAL**: `tests/expiry_timezone.spec.ts` +
  `tests/helpers/expiry_child.ts` — `execFileSync` de un hijo que hace `bootApp({ reuse })` sobre la
  MISMA base, gateado a `pg`/`mysql`. Esto es decisivo para A y lo he reusado.
- **Hay precedente de test sobre la LETRA del README**: `tests/scope_outbox.spec.ts:1800-1858`,
  con `assert.include` y —lo importante— `assert.notInclude('the shorter your relay cycle…')`.
  Es exactamente la forma que hace falsificable a B.
- **`reconcileLines(report)`** (`commands/authz_reconcile.ts`, casos en `reconcile.spec.ts:967-982`)
  es una función pura sobre el reporte: cualquier línea o `exit 1` nuevo se prueba ahí por 3 líneas.

---

## 2. Respuesta 4 primero (es la que decide): **D no distingue nada, y está medido**

D dice: *«segunda pasada que escribe cero ⇒ nadie escribió durante la primera»*. La he montado y
medida sobre el escenario EXACTO del hallazgo 3 (PG + FGA real). Los 7 casos pasan; lo que afirman es
lo que sigue.

### D1 · un REVOKE en la ventana ⇒ la 2ª pasada escribe CERO y el destino sigue concediendo

Siembra: `ana` con `org-admin` en `org`, motor vivo en `openfga` (`hierarchy: 'facts'`), migración de
vuelta `--to=database --from=openfga`. La ventana se fuerza con un `Proxy` sobre `enumerateFacts`: el
`revoke` del worker entra **después** de leer la página.

```
pasada 1: written=1  skipped={}                 ← la pérdida es silenciosa (confirma el hallazgo 3)
pasada 2: written=0  deleted=0  skipped={"extra-fact":1}
sql.authorize(ana,'docs:read',org) → TRUE       ← el destino concede lo REVOCADO
```

**«escribe cero» y la pasada NO fue limpia.** La inferencia de D es falsa. El único rastro está en
`skipped['extra-fact']`, que **no es lo que D mira**.

### D2 vs D3 · el número no significa lo que D dice, tampoco cuando NO es cero

- **D2** (`grant` DENTRO de la ventana, se perdió y se repara): `pasada2.written = 1`.
- **D3** (ventana **limpia**; el `grant` llega **después** de terminar la pasada; **no se perdió
  nada**): `pasada2.written = 1`.

**Mismo número, dos mundos opuestos.** Un reporte que diga «la segunda pasada escribió 1» no
distingue una pérdida de tráfico normal. Bajo carga real, D grita siempre.

### D5 · la REGRESIÓN: el detector se declara limpio sobre su propia pérdida

La 2ª pasada tiene **su propia ventana**. Con la 1ª pasada limpia y el `revoke` dentro de la ventana
de la **segunda**:

```
pasada 2: written=0  deleted=0  skipped={}      ← veredicto de D: «LIMPIA»
facts.authorize(ana) → false                    ← el origen ya no concede
sql.authorize(ana)   → true                     ← el destino sí
```

**El detector emite su certificado de limpieza sobre la pérdida que acaba de causar.** Para
demostrar que la segunda pasada fue limpia haría falta una tercera, y así sin fin. Esto no es un
hueco de cobertura: es que **la propiedad no existe**.

### D4 · lo mismo en la otra dirección (`--to=openfga`)

```
pasada 2: written=0  deleted=0  skipped={"extra-fact":3}   (3 tuplas por asignación en el modelo facts)
facts.authorize(ana) → TRUE                                 ← el store concede lo revocado
```

### D6 · el suelo de ruido, para ser justo

Dos pasadas seguidas sin que nadie escriba: `skipped={}` en las dos. `extra-fact` **no** es ruidoso
en un par sano. O sea: la variante enriquecida de D —«`written == 0` **y** `extra == 0`»— **sí**
detectaría D1 y D4. Pero **no** detecta D5 (la ventana de la propia pasada, `extra=0`) y **sigue** sin
distinguir D2 de D3. Es una mejora del reporte, no una garantía.

### D7 · el steelman: la 2ª pasada con `--prune`

```
pasada 2 --prune: written=0  deleted=2  skipped={}
```

Detecta el revoke de la ventana… **y borra también la fila que el origen no respalda** (la que el
operador escribió a propósito durante el corte). Un `deleted` que mezcla las dos causas sin
distinguirlas. Y en el escenario mínimo del auditor (el revoke deja el origen con **cero** hechos) la
pasada **ni siquiera reporta**: revienta con 500 `E_AUTHZ_MASS_RECONCILE_REFUSED` (medido en la
primera corrida de D7, antes de engordar la siembra).

### Veredicto sobre D

> **D es la única de las cuatro que NO es falsificable como GARANTÍA**, y no porque falte
> infraestructura: porque la proposición «escribe cero ⇒ nadie escribió» es **falsa** y lo he puesto
> en rojo. Lo que sí es falsificable es D **como línea de reporte**: «la 2ª pasada escribió N» se
> prueba con `reconcileLines` en 3 líneas y muere con un mutante que devuelva 0 siempre. Pero
> entonces D no *detecta* nada: informa de un número que no significa ni «hubo pérdida» ni «no la
> hubo».
>
> Si D entra, tiene que entrar con esta frase y no con otra: *«la segunda pasada te dice si el
> destino coincide con el origen AHORA; no te dice si la primera pasada fue limpia, y no puede.»*
> Eso sí tiene caso (es la idempotencia de `reconcile.spec.ts:431`, que ya está escrita).

---

## 3. Respuesta 3 (el problema duro): **sí se puede probar A entre procesos. Medido.**

He prototipado el freeze durable en el worktree: tabla `authz_freeze` (`id=1`, `reason` nullable),
`freezeDurable()`/`unfreezeDurable()` que escriben la fila, y una barrera `#assertNotFrozenDurable`
—un `SELECT` por clave primaria— delante de `#writeOptions`. **Coste de implementación medido**:
`#writeOptions` pasa a `async` ⇒ **7 `await` nuevos** en las llamadas (`manager.ts:489, 519, 557,
2401, 2448, 2457, 2466`) más `#requireActor` para la delegación. La suite entera con ese refactor:
**587 passed, 1 failed** (el único rojo es mi propio A1 con la bandera apagada). El refactor **no
rompe nada**.

### Los cuatro casos, y lo que cuestan

| caso | qué afirma | motores | tiempo |
|---|---|---|---|
| **A1** dos MANAGERS, un proceso | el freeze de A rechaza el `grant` de B con 503 `E_AUTHZ_FROZEN`, y `b.frozen` sigue en `false` (lo ve por la FILA, no por memoria) | los 4 | **54 ms** |
| **A3** la asimetría | congelado, la LECTURA de B sigue respondiendo | los 4 | **37 ms** |
| **A2** dos PROCESOS de verdad | `execFileSync` de un hijo con `bootApp({ reuse })`: control sin freeze ⇒ `ACEPTADO`; con freeze del padre ⇒ `RECHAZADO / E_AUTHZ_FROZEN / 503` | **pg, mysql, sqlite-file** | **1 s** (dos spawns) |
| **A4** la ventana que queda | el freeze aterriza entre el check y la escritura ⇒ el `grant` **entra igual** | los 4 | **39 ms** |

### Los mutantes: por qué A2 NO es redundante

| mutante | `npm test` (sqlite `:memory:`) | `test:pg` / `test:mysql` / `test:sqlite-file` | quién lo mata |
|---|---|---|---|
| `no-escribe` — `freezeDurable` no escribe la fila | 💀 (A1) | 💀 (A1 + A2) | A1 |
| `no-lee` — el camino de escritura no consulta la fila | 💀 (A1) | 💀 (A1 + A2) | A1 |
| **`modulo`** — el «durable» es en realidad una **global del módulo** | ✅ **SOBREVIVE · 3 passed, VERDE** | 💀 **solo A2** | **A2 y nadie más** |

Ése es el resultado que importa, y es contraintuitivo en las dos direcciones:

1. **El caso multiproceso se puede escribir, es fiable y cuesta 1 s.** El patrón ya está en el repo
   (`expiry_timezone.spec.ts`), el helper son ~50 líneas y no hay `sleep` ni carrera: el padre
   congela, el hijo arranca después. Cero fragilidad de tiempos. **El argumento «A no se puede
   probar bien» es falso y no debe usarse contra A.**
2. **Pero A2 no existe en `npm test`.** El motor por defecto es SQLite `:memory:`: un segundo
   proceso **no puede abrir** esa base. Y ahí el mutante `modulo` —un freeze que se vende como
   compartido y es de proceso, o sea **exactamente el defecto que A viene a arreglar**— pasa
   **verde**. La garantía de A solo es observable en 3 de los 4 motores, y el que la gente corre por
   defecto no es uno de ellos. Eso hay que escribirlo en CI o la regresión volverá sin ruido.

### Lo que A **no** puede prometer, y también está medido (A4)

El freeze durable es un `SELECT` seguido de una escritura: entre los dos hay una ventana. En A4 el
`freeze()` del proceso migrador aterriza **después** de que el escritor pasara su barrera:

```
b.manager.grant(...) → la escritura ATERRIZA con el motor ya congelado (a.manager.frozen === true)
```

Cerrar eso de verdad pide **atomicidad** entre la barrera y la escritura (un cerrojo sobre la fila
sostenido durante la escritura), y **eso es imposible cuando el destino es OpenFGA**: la barrera está
en SQL y la escritura en otro servicio. **Conclusión de verificabilidad: A hace falsificable
«otro proceso recibe 503», y deja NO falsificable «ninguna escritura entra en la ventana».** Si A
entra, la frase del README tiene que ser la primera, nunca la segunda.

### Coste de mantenimiento que A introduce en la suite (medido, no imaginado)

Un `freeze` que se escapa de un caso **envenena todos los siguientes**. Me pasó: A3 congela y no
descongela, y A4 murió por eso —no por el mutante—. La limpieza tiene que ser **explícita en el
teardown** de cada grupo que toque el freeze, y hoy `cleanAuthzTables()` no toca `authz_freeze` (es
una fila de estado, no de datos: se comporta como `authz_catalog_version`). Sin esa disciplina, A
convierte cualquier caso rojo en una cascada ilegible.

---

## 4. Respuesta 1 · Los casos, opción por opción

### Opción A · `freeze()` durable

**Casos de contrato que añade**
- *Dado* un `freeze('authz:reconcile --to=database')` en el proceso P1, *cuando* el proceso P2 hace
  `grant`, *entonces* 503 `E_AUTHZ_FROZEN` **reintentable**, y `P2.frozen === false` (lo ve por la fila).
- *Dado* lo mismo, *cuando* P2 hace `authorize`, *entonces* responde con normalidad (la asimetría).
- *Dado* un `unfreeze()` en P1, *cuando* P2 vuelve a escribir, *entonces* entra.
- *Dado* un proceso que **muere a mitad de la migración**, *cuando* arranca el siguiente worker,
  *entonces* … **❌ no hay respuesta definida y es el hueco más grave de A**: la fila sobrevive al
  proceso y la aplicación queda **sin poder escribir hasta que alguien la borre a mano**. Hoy el
  `finally` de `withFrozenWrites` cubre la excepción; no cubre un `SIGKILL`. **Esto necesita
  decisión de producto antes que test** (¿TTL? ¿`owner_pid`+`heartbeat`? ¿`authz:unfreeze`?), y cada
  respuesta trae su propio caso (y el TTL, un reloj inyectable — nada de `sleep`).
- *Dado* el `freeze` puesto, *cuando* corre `relayScopeChanges` en otro proceso, *entonces* 503
  (hoy el invariante lo cubre `#assertNotFrozen`, con A hay que reprobarlo por la fila).

**Invariantes en riesgo** · `CLAUDE.md:498` «el estado vive en el manager RAÍZ» → **lo desmiente A**:
hay que reescribirlo. · «las lecturas nunca se congelan» → `reconcile.spec.ts:171` lo cubre en
proceso; hace falta el gemelo entre procesos (A3, escrito). · «una escritura durante la migración no
se valida a medias» (`#assertNotFrozen` va **antes** de validar identidad) → con un `SELECT` de por
medio, el orden hay que reprobarlo.

**Verificabilidad por backend**

| backend | ¿mismo test? | riesgo específico | notas |
|---|---|---|---|
| sqlite `:memory:` (**`npm test`**) | **no**: A2 imposible | el mutante `modulo` queda **verde** | medido |
| sqlite-file | sí | ninguno | A2 pasa; 1 s |
| PostgreSQL 18 | sí | la fila puede ser también un cerrojo (`FOR UPDATE`) ⇒ más garantía, más casos | A2 pasa; 1 s |
| MySQL 8.4 | sí | idem | A2 pasa |
| OpenFGA (destino) | **no aplica**: la barrera vive en SQL | **la atomicidad barrera↔escritura es imposible**: A4 no se puede cerrar | el argumento duro contra la frase fuerte |

**Huecos que el plan no menciona** · el freeze huérfano tras un `SIGKILL` (arriba). · el coste de un
`SELECT` por escritura: hay `catalogRevalidate: { everyMs }` como precedente, y **cualquier caché de
la fila reabre exactamente la ventana** (habría que probar el borde `everyMs`). · el **orden**: dos
`freeze` de dos migraciones a la vez (¿el segundo pisa el motivo del primero? ¿el `unfreeze` del
primero descongela para el segundo? — hoy `freeze` es idempotente y `unfreeze` incondicional: entre
procesos eso es un bug esperando). · el borde `reason` vacío / `null` / la fila **ausente** (¿fail-open
o 500? con la tabla sin crear, ¿el motor deja de escribir o deja de arrancar?).

**Coste de prueba: MEDIO.** 4 casos + 1 helper de ~50 líneas + 1 tabla + limpieza explícita; ~1,1 s
por corrida. Lo que lo sube de bajo a medio: hay que **gatear por motor** y **decirlo en CI**, porque
en el motor por defecto la garantía no es observable.

**Veredicto: verificable con cambios** (gate por motor + decisión sobre el freeze huérfano), y **con
una promesa que hay que recortar**: «otro proceso recibe 503», nunca «ninguna escritura entra».

---

### Opción B · Quitar la promesa

**Casos de contrato que añade**
- *Dado* el README publicado, *cuando* se busca la frase `which is the one thing the report promises
  cannot happen`, *entonces* **no está** (`assert.notInclude`), y sí están las palabras honestas
  (`freeze() is per process`, `stop your writers`). Forma exacta: `tests/scope_outbox.spec.ts:1800`.
- *Dado* `authz:reconcile` sin la bandera, *cuando* corre, *entonces* **para** con un error que
  nombra a los escritores vivos (y `reconcileLines` lo refleja en el `exit`).
- *Dado* `--allow-live-writers` (o como se llame), *cuando* corre, *entonces* procede y **el reporte
  lo dice** —la bandera tiene que salir en el reporte, no solo en el `argv`: es lo que queda escrito
  en el log de la operación—.
- *Dado* el mismo comando en `--dry-run`, *entonces* **no** exige la bandera (un verificador que
  pide permiso para leer es un verificador que no se corre).
- *Dado* el escenario del hallazgo 3 (revoke en la ventana), *entonces* el resultado **es el que el
  README describe**: se pierde y no se cuenta. **Esto es lo mejor de B: convierte el hallazgo del
  auditor en un caso que fija el comportamiento documentado en vez de taparlo.**

**Invariantes en riesgo** · ninguno. `CLAUDE.md:498` ya dice la verdad; B alinea el README con él.
Los 6 casos de freeze existentes siguen valiendo palabra por palabra.

**Verificabilidad por backend**

| backend | ¿mismo test? | riesgo específico | notas |
|---|---|---|---|
| los 4 SQL | **sí, el mismo** | ninguno | el caso del README es `readFile` + `assert`: no toca base |
| OpenFGA | sí | ninguno | el caso del hallazgo 3 necesita FGA real, y ya lo tengo escrito (D1) |

**Huecos** · el **inverso** hay que escribirlo: con la bandera, la migración **sí** procede (si no,
un mutante que la rechace siempre pasa desapercibido). · el **borde**: bandera + `--dry-run`, y
bandera repetida. · el **orden**: la bandera no puede cambiar lo que la pasada escribe, solo si
arranca — eso es un caso (`written` idéntico con y sin bandera).

**Coste de prueba: BAJO.** 4-5 casos, todos en un proceso, todos en los 4 motores, cero infra nueva.

**Veredicto: verificable.** Es la única opción cuya garantía completa se puede poner en rojo con un
mutante hoy, sin infraestructura nueva y en los cuatro motores.

---

### Opción C · Las dos

**Casos**: la unión (A ∪ B), sin colisión: la frase del README pasa a ser *«el freeze alcanza a los
demás procesos si `durableFreeze` está en el config; si no, es de proceso»* — y **esa condicional
necesita sus dos casos**, uno por rama, más el caso de que el config **por defecto** sea el que el
README dice que es (un `defineConfig` sin la opción ⇒ freeze de proceso ⇒ el comando exige la
bandera). Ese tercer caso es el que impide que la promesa quede escrita para una configuración que
casi nadie tiene.

**Invariantes en riesgo**: los de A, más uno nuevo: **el comportamiento por defecto**. Con dos
modos, la mitad de los 6 casos de freeze existentes tienen que correr **en los dos** o dejar dicho
por qué no.

**Coste de prueba: ALTO.** No es A + B: es (A + B) × 2 modos en los casos de barrera, y con el gate
por motor de A encima. Es la opción que más multiplica la matriz.

**Veredicto: verificable con cambios**, y es la que más suite arrastra. Si el juez la elige, el
caso que no puede faltar es **«sin la opción en el config, el comando exige la bandera»**: sin él,
C es B con una frase que no aplica al despliegue por defecto.

---

### Opción D · B + detección a posteriori

**Casos que añade** · uno solo, y es honesto: *dado* un reporte de segunda pasada con `written = N`,
*cuando* `reconcileLines` lo formatea, *entonces* sale la línea con N y el `exit` correspondiente.
Muere con el mutante «siempre 0». **Todo lo demás que D promete no tiene caso posible**, y lo he
medido: D1 (cero ≠ limpia), D3 (N ≠ pérdida), D5 (la ventana de la propia pasada), D7 (`--prune`
detecta y destruye a la vez, o revienta con 500).

**Invariantes en riesgo** · **la idempotencia se resignifica**. Hoy `reconcile.spec.ts:431` dice «la
segunda pasada escribe cero» como propiedad del **destino**; D la reutiliza como afirmación sobre el
**pasado**, que es otra cosa. Un lector del README leerá el caso verde como prueba de la conclusión
de D, y no lo es. **Eso es lo que descalifica a D en este proyecto**: una garantía que se afirma sola
apoyándose en un test verde que prueba otra cosa.

**Verificabilidad por backend**

| backend | ¿mismo test? | riesgo específico | notas |
|---|---|---|---|
| los 4 SQL + OpenFGA | sí para la LÍNEA del reporte | — | trivial |
| cualquiera | **no existe** el test de la GARANTÍA | D5: la 2ª pasada tiene su propia ventana | medido |

**Coste de prueba: BAJO** (para lo poco que se puede probar) — y ése es justo el problema.

**Veredicto: NO verificable tal cual.** Verificable si se reescribe como *«el reporte de la 2ª
pasada dice cuántos hechos faltaban AHORA; no dice si la 1ª fue limpia»*. Con esa frase, D es una
mejora de reporte perfectamente sana y barata. Con la frase del plan, es la misma clase de promesa
que el hallazgo 3 acaba de desmentir, un piso más arriba.

---

## 5. Respuesta 5 · El coste en la suite PUBLICADA (`src/testing/`)

Esto lo dice la firma del harness, no una opinión. `MigrationContractHarness`
(`src/testing/migration_contract.ts:117`) le pide al driver de terceros: `seedCatalog`, `setup(tree)
⇒ { reconcile(options), drivers }`, `cleanup`, `expectedLosses`. **No hay manager, no hay segundo
escritor, no hay segundo proceso, y no hay forma de exigir un motor.** Y `runMigrationContract`
juzga **DRIVERS**; el `freeze` es del **MANAGER**.

| opción | ¿toca `contract.ts` / `runMigrationContract`? | qué haría falta | coste para un driver de terceros |
|---|---|---|---|
| **A** | **sí, y mal**: hoy no cabe | un gancho nuevo en `MigrationContractHarness` («escribe DESDE FUERA mientras la pasada corre»). Obligatorio ⇒ **rompe** a los drivers que ya lo implementan; opcional ⇒ salteable ⇒ **no es garantía**. Y no se puede exigir pg/mysql desde un contrato agnóstico de motor. | **alto**: o rompe la interfaz o la promesa queda fuera del contrato publicado |
| **B** | **no** | nada: la letra del README es un `readFile` en la suite privada; la bandera vive en `commands/` y se prueba con `reconcileLines` | **cero** |
| **C** | como A | como A, más las dos ramas del config | **alto** |
| **D** | **no**, y no debe: la 2ª pasada ya está en la combinación `a→b→a` | si se metiera la conclusión («fue limpia») en el contrato, el contrato **afirmaría en nombre del driver algo que no observa**. Sería la peor regresión posible en la pieza que más se publica. | **cero si se queda fuera; inaceptable si entra** |

**Aviso que va aquí y no en otro sitio:** si A entra, la promesa del README aplica a **cualquier**
driver (es del manager), pero la garantía solo estará verificada para los drivers del paquete y en 3
de 4 motores. Un tercero leerá «el freeze alcanza a todos tus procesos» y correrá un contrato que no
lo comprueba **nunca**. Esa asimetría —promesa global, verificación local— es la misma forma del
hallazgo 3, y hay que decidirla a sabiendas.

---

## 6. Comparación final

| opción | casos nuevos | invariantes en riesgo | motores donde la garantía es observable | coste en la suite publicada | coste de prueba | **veredicto de verificabilidad** |
|---|---|---|---|---|---|---|
| **A** durable | 5 (uno sin respuesta: el freeze huérfano) | `CLAUDE.md:498`; orden de la barrera; lecturas | **3 de 4** — *no* en `npm test` | **alto** (gancho nuevo o promesa sin contrato) | medio (~1,1 s/corrida) | **verificable con cambios**, con la promesa recortada a «otro proceso recibe 503» |
| **B** quitar la promesa | 5, todos baratos | **ninguno** | **4 de 4** | **cero** | bajo | **verificable** ✅ |
| **C** las dos | A ∪ B + el caso del default | los de A + el comportamiento por defecto | 3 de 4 | alto | alto | **verificable con cambios** |
| **D** detección a posteriori | 1 (la línea del reporte); **la garantía, ninguno** | resignifica la idempotencia ya probada | **ninguno** | cero / inaceptable | bajo | **NO verificable tal cual** ❌ |

**Lo único que aporto al juez, dicho corto:**

1. **D está desmentida con medida**, no con argumento: D5 es el detector declarándose limpio sobre su
   propia pérdida. En un proyecto que descalifica lo no falsificable, D no debería sobrevivir con la
   frase del plan.
2. **A es más barata de probar de lo que parece** (1 s, patrón que ya está en el repo) y **más cara
   de mantener de lo que parece**: no corre en el motor por defecto, arrastra el freeze huérfano, y
   su promesa fuerte (la ventana cerrada) sigue sin ser falsificable con destino OpenFGA.
3. **B es la única con cobertura completa hoy**, y su mejor caso no es documental: es convertir el
   escenario del hallazgo 3 en un test que **fija** el comportamiento en vez de taparlo.

---

## 7. Dónde está lo que he corrido

Todo en el worktree (mutado a propósito; el repo principal **no se ha tocado** salvo este informe):

- `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-tester/tests/panel3_d.spec.ts`
- `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-tester/tests/panel3_a.spec.ts`
- `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-tester/tests/helpers/panel3_freeze_child.ts`
- `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-tester/src/manager.ts` (prototipo + mutantes, tras `const PANEL3_GLOBAL` y en `freezeDurable`/`#assertNotFrozenDurable`)
- Copia del `manager.ts` original: `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/manager.orig.ts`

Cómo reproducir:

```bash
cd .../wt-panel-tester
# D — la opción D como detector (necesita FGA real)
TEST_DB=pg TEST_PG_URL='postgres://postgres:<pass>@127.0.0.1:5432/tester3_authz' \
  OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec bin/test.ts --files=panel3_d

# A — el freeze durable, y sus tres mutantes
PANEL3_DURABLE_FREEZE=1 TEST_DB=pg TEST_PG_URL='…' node --import @poppinss/ts-exec bin/test.ts --files=panel3_a
PANEL3_MUTANT=modulo PANEL3_DURABLE_FREEZE=1 node --import @poppinss/ts-exec bin/test.ts --files=panel3_a          # VERDE (sqlite :memory:)
PANEL3_MUTANT=modulo PANEL3_DURABLE_FREEZE=1 TEST_DB=pg TEST_PG_URL='…' node … --files=panel3_a                    # ROJO solo en A2
```
