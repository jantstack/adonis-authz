# Cierre 3 de D2 — brief del coordinador (2026-10-16)

Origen: `loteD2-auditor-cierre2.md` (NO APTA). Reproducciones: `.claude/reproducciones/loteD2-auditor-cierre2-fga.ts` (R1–R7) y `loteD2-auditor-cierre2-orden.ts` (O1–O4). Árbol sin commit sobre `75353fe`; verificado por el coordinador antes de este cierre: 2018/2046/2143/2145, guardia 176/176, banderas 37/37, runbook ×2.

Raíz común de C2-1/C2-2/C2-4: **una tupla vencida en `now` se trata como viva** (plan del reconcile, contexto del orden, `#carriedDeny`, renovación en `relate`).

## Puntos
1. **🟠 C2-1** (`reconcile.ts:~1192-1205`): en el plan, una tupla del destino vencida en `now` cuenta como AUSENTE: su reescritura es escritura normal (nunca `toUpdate`/`renewal-unsafe`), y no entra al contexto del orden. Mismo criterio en `#carriedDeny` (un deny que llega por una membresía vencida no transporta nada). Caso: R4 convertido en test de contrato en los dos drivers (destino niega antes, tras una pasada niega o concede según el ORIGEN, y converge en la 2.ª pasada con plan vacío). Mutante que reintroduce la vigencia ignorada ⇒ rojo.
2. **🟡 C2-2**: añadir la VIGENCIA al universo de la fuerza bruta (`tests/helpers/order_bruteforce.ts`): cada tupla de destino puede estar viva, vencida o ausente, y las renovaciones son operaciones del plan. La propiedad `relations.order.exhaustive` debe seguir en 0 sin residuo declarado con ese universo (exhaustivo si cabe; si no, muestreo declarado con cifras). R5 y R7 como casos de contrato (database y openfga). Si queda algún residuo nuevo, se DECLARA (README + `orderResidue`), nunca silencioso. Revisar que la frase de README:843-845 quede cierta.
3. **🟡 C2-3** TOCTOU de N1: tras la renovación en dos `Write`, re-comprobar si apareció un deny transportado; si apareció (o si falla el 2.º `Write`) el error/la marca parcial NOMBRA el deny afectado y la receta. Declarar la ventana residual en README junto a «Every other renewal stays two `Write`s». Caso con la barrera-espía existente.
4. **⚪ C2-4**: renovar en `relate` una membresía portadora YA vencida no da 409 (sale de 1). Caso.
5. **⚪ C2-5** gemelo roles: fallo del 2.º `Write` al renovar un grant ⇒ marca parcial + evento coherente con relaciones (no 503 «no escrito»). Caso con fallo inyectado.

## Reglas
- Implementador ÚNICO; sin commit, `npm version`, push ni sellado. CHANGELOG solo bajo `[Unreleased]`; no tocar `[2.5.0-alpha.1]`.
- Cada punto con caso que falla sin el arreglo y mutante medido.
- Ejecuta tú build, typecheck y las suites tocadas (entorno: nvm 22; `OPENFGA_TEST_URL=http://localhost:8090`; `TEST_PG_URL` con la contraseña de `postgres18`; `docker restart openfga-dev && sleep 8` antes de suites con OpenFGA).
- Informe: `.claude/contexto/loteD2-informe-cierre3.md` (por punto: qué, ficheros, casos, mutantes, cifras).
