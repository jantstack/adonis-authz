# alpha.8 · informe del implementador II (incremental)

Base: `main` `13ba731` (= 2.4.0-alpha.7) + el lote I sin commitear (1323 / 1349 / 1445 / 1447). Sin commits; `version`
intacta; nada del lote I descartado. Corridas en el scratchpad
(`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/a8ii_*.log`).

## ⚠️ Contradicción con la spec (`maxDepth = N + 1`) — PARADA y decisión tomada

La spec dice: «`maxDepth` cuenta SALTOS hasta `app` ⇒ un árbol de N niveles necesita `maxDepth = N + 1`, con caso
EJECUTABLE (árbol de 3 niveles, `maxDepth: 3` ⇒ 422 en el tercero; `maxDepth: 4` ⇒ entra)». **Medido contra el código
antes de escribir nada** (`a8ii_probe.ts`): con `app → org → unit` y `sub` colgando de `unit` (3 saltos),
`scopes.maxDepth: 2` ⇒ 422, `maxDepth: 3` ⇒ ENTRA, `maxDepth: 4` ⇒ entra. La condición es `chain.length > maxDepth` con
la cadena del PADRE (que incluye `app`, longitud 3): `3 > 3` es falso. Lo mismo con `hierarchicalScopeResolver({ maxDepth })`
(`maxDepth: 2` ⇒ 500 TOO_DEEP, `3` ⇒ cadena de 4). O sea: **N niveles ⇒ `maxDepth = N`**, no N + 1; la letra del panel
(tester N-1/N-2, copiada a la spec) es falsa. No cambié la semántica (el juez la prohibió: breaking). Escribí el README y
el caso ejecutable con la regla MEDIDA (`maxDepth: 2` ⇒ 422 en el tercero, `maxDepth: 3` ⇒ entra) y lo dejo anotado en
el CHANGELOG «for the record». Si el dueño prefiere la frase del panel, es un cambio de semántica (hops → niveles) que
no cabe en una alpha aditiva.

## Edad de la cola — HECHO

- **Rojo** (`a8ii_e_red.log`, 8 rojos; `a8ii_e_red_harness.log`, 16 ≠ 17): el B2 de COGNITIV con reloj inyectado
  (10 pasadas con 503, `attempts` 0, `dead` 0, sin `queue`), edad bajo `only`, bordes, terceros, busy/dryRun, el
  puerto sin `createdAt`, el comando sin `--max-age`, la letra.
- **Verde** (`a8ii_e_green.log`, 212/212): `PendingScopeTreeChange.createdAt?`; `rowToPending` lo devuelve (`stampOf`:
  `Date` en PG/MySQL, número de ms en SQLite —medido—, ilegible ⇒ ausente); `ScopeRelayQueue` + `ScopeRelayReport.queue`
  + `deadCount`; manager: `#queueStatus` (el `pending(1)` del final, SIN filtro) y `#queueOf` (`Math.max(0, #wallMs() −
  createdAt)`; sin `createdAt` ⇒ `{ null, null }`), `#busyReport` pasa a instancia (necesita el reloj), `dryRun` reusa
  `batch[0]` sin filtro y consulta la cabeza global con `only`; `#relayInputs` devuelve `census`/`deadCount` y
  `#parkedKeys(census)` deja de leer (cero consultas nuevas: el censo completo solo se releía si `dead` no cabía en un
  lote, y ahora lo hace `#relayInputs` una vez). Comando: `--max-age` + `queueAgeLines(queue, maxAgeMs)` PURA (sin edad
  ⇒ nada; con edad ⇒ info; con umbral y por encima ⇒ error + exit 1; umbral inválido ⇒ lanza). Contrato: par
  `createdAt` (`true`: Date, no decreciente, la cabeza del reporte es ese sello también bajo `only`; `false`: campo
  AUSENTE y `{ null, null }` en verde), `makeScopeOutbox({ now? })` lo sella solo si lo declara; `EXPECTED_CASES` 16→17,
  claves 7→8; el harness SQL declara `true`, el doble mínimo `false`.
- **Mutantes** (`a8ii_e_mut*.log`): sin `Math.max` ⇒ 1 rojo (skew); «terceros degradan a ahora/0» ⇒ 2 rojos (caso +
  cara `false` del contrato); «la edad bajo `only` mira lo pedido» ⇒ 1 rojo; «exit ≠ 0 sin umbral» ⇒ 1 rojo.
- `parkAfterMs` NO existe.

## `requireTransaction` — HECHO

- **Rojo** (`a8ii_t_red.log`, 4 rojos): P13 (`enqueue(change, {})` escribe hoy), por el manager, valor inválido, letra.
- **Verde** (`a8ii_t_green.log`, 191/191): opción `requireTransaction?: boolean` en `SqlScopeOutboxOptions` (default
  `false`; no booleano —`'true'`, `1`, `null`— ⇒ 500 al construir); en `clientOf`, sin trx y con la opción ⇒ 500
  `E_AUTHZ_CONFIG` ANTES del INSERT con el mensaje que nombra la fuga («la fila confirmaría sola, y si tu transacción
  hace rollback después el cambio se queda en la cola y el relay lo aplica al store — tu base diría un padre y el PDP
  otro»). El manager NO construye la outbox (`config.scopes.outbox` es la instancia) ⇒ la opción vive solo en
  `sqlScopeOutbox` (la spec lo condicionaba a «si el manager la construye»). README + CHANGELOG anuncian **default `true`
  en 2.5** y que `ctx()` del contrato pasará la trx. El contrato publicado sigue verde (17/17 con `ctx()` sin trx).
  Nota: el caso «con `{ transaction }` por el manager encola» se salta en `:memory:` (pool 1: la barrera del freeze
  lee por OTRA conexión; el mismo gate que L-3); corre en sqlite-file/pg/mysql.
- **Mutantes** (`a8ii_t_mut*.log`): «comprobar DESPUÉS del INSERT» ⇒ 2 rojos (cero filas afirmado); «opción ignorada»
  ⇒ 3 rojos.

## Menores — HECHO

- **Rojo** (`a8ii_m_red.log`, 10 rojos + 2 errores de tipos por `deadDetail`): O-1..O-4 sin `origin`; `dead[]` con
  `error` bajo `only`; trx cerrada ⇒ 503 (outbox, roles `grant.find`, relaciones `relate.select`); el 422 nombra
  `openfga`; README sin la regla de `maxDepth`.
- **Verde** (`a8ii_m_green.log`, 288/288):
  - `origin`: `blocked: Map<key, { id, origin }>` tri-estado, `BLOCK_RANK` (`failed > pending > parked`), `defer(…,
    origin)`, `#blockOriginOf` devuelve el origen (`failed` si un hit es fallo; `pending` si un hit es pendiente; `parked`
    por hit/censo solo para `attached`/`moved`; sin anterior ⇒ `pending`; cota de saltos ⇒ `failed`); la decisión
    aplicar/aplazar NO cambia (solo `'parked'` exime al `detached`); `entries[].origin` solo en `deferred`.
  - `deadCount` siempre (del censo) + bajo `only` `dead[]` sin `error` salvo `deadDetail: 'full'` (`RELAY_OPTIONS`
    lo conoce; otro valor ⇒ 500); `deadEntries` (lo pedido) conserva `reason`. El `relay` interno de `requeue { apply }`
    hereda el default (sin `error`).
  - Trx cerrada: 4.ª comprobación en `assertCallerTransaction` (`isCompleted === true` ⇒ 500 nombrando la operación y
    «confirmada o revertida», cero sentencias); casos en los TRES llamadores (outbox C-1; roles: grupo nuevo en
    `database_transaction.spec.ts` SIN gate de motor —una trx cerrada no retiene conexión— con las 4 escrituras,
    confirmada y revertida, espía = 0; relaciones: ídem en `relations_database.spec.ts` con las 4).
  - 422: `ScopeDepthLimitError(message, details)`; el `message` sin `openfga`/`facts`/`FACTS_MAX_RESOLVE_DEPTH`/
    `OPENFGA_RESOLVE_NODE_LIMIT` (caso L-1 con `notInclude` ×4) y con profundidad + `scopes.maxDepth=N` + «No se ha
    escrito ni encolado nada» (L-2); `details = { depth, maxDepth, why, server }`.
  - `maxDepth`: caso N-2 ejecutable con la regla MEDIDA (ver arriba) + letra del README.
  - `dead[].supersededBy`: **NO** (un `laterApplied` por aparcada y por pasada, bajo el lease: ~2,5 ms cada uno según
    la medida del auditor ⇒ +250 ms por pasada con 100 aparcadas). Escrito en el CHANGELOG.
- **Mutantes** (`a8ii_m_mut_*.log`): «origin del prefijo de `reason`» ⇒ 2 rojos (el `pending` de O-3 y la raíz de
  O-4… bajo only); «`pending` colapsa en `failed`» ⇒ 1 rojo (O-3 🔑); «`deadCount = dead.length`» ⇒ 1 rojo; «nunca quita
  `error`» ⇒ 1 rojo; «sin la 4.ª comprobación» ⇒ 3 rojos (outbox, roles, relaciones); «el mensaje nombra openfga» ⇒
  1 rojo; «`>=` en el gate» ⇒ 2 rojos (N-2 y 4-4).

## Docs

- CHANGELOG `[Unreleased] — 2.4.0-alpha.8`: cabecera ampliada (lotes I y II; `EXPECTED_CASES` 15 → 17), entradas de
  edad/`--max-age`, `requireTransaction` (default 2.5), `origin`, `deadCount`/`deadDetail`, trx cerrada, 422 + `maxDepth
  = N` (con la nota de la contradicción), y «What is NOT done»: `supersededBy` (no es barato, con la medida),
  `scopes.requireOutboxTransaction` del manager (no la construye), sin aviso `warnOnOptInSecurity`.
- README: párrafos «How old is the queue?», «Enqueueing outside your transaction», «What the report says about the
  parked set», la regla de la trx cerrada en «The rule», filas de errores (`E_AUTHZ_CONFIG`, `E_AUTHZ_SCOPE_DEPTH_LIMIT`),
  `maxDepth = N` con el caso, snippet del contrato con `createdAt` y el conteo (17: nueve deberes + ocho pares), bash con
  `--max-age`.
- `CLAUDE.md` (aditivo): cabecera con `alpha8-informe-II.md`, (vii) conteos corregidos (9 + 8, 17), (ix) nuevo, filas de
  `scope_outbox.ts` y `transaction_guard.ts`.
- `roadmap-2.0.md` 2.5: reconcile acotado por subárbol/tenant (requisito traducido del supersede), default
  `requireTransaction: true` + `ctx()` con trx (prerrequisito) + gate del manager a valorar, `createdAt` tachado (hecho).

## Verificación final (todo con `OPENFGA_TEST_URL=http://localhost:8101`, en primer plano y en secuencia)

- `tsc --noEmit` 0 · `npm run typecheck` 0 · `npm run check:purity` 0 · `npm run build` 0 (`a8ii_final_{tsc,typecheck,purity,build}.log`).
- `npm test` (sqlite `:memory:`) **1349/1349** (base 1323, +26) · `test:sqlite-file` **1375/1375** (base 1349, +26) ·
  `test:pg` **1471/1471** (base 1445, +26) · `test:mysql` **1473/1473** (base 1447, +26).
  Los +26 = E 8 + T 4 + M 7 (3 `origin` + 4 `deadCount`/`deadDetail`/trx cerrada/letra) + roles 1 + relaciones 1 +
  profundidad 2 + par `createdAt` ×3 harnesses del contrato. Aditivo: ningún caso existente cambió de resultado.
- Sin commits; `version` sigue `2.4.0-alpha.7`; sin `skip`; `clock.spec` verde (ningún `Date.now()` nuevo en `src/`).

## Lo que NO hice

- `dead[].supersededBy` (no es barato: un `laterApplied` por aparcada y pasada).
- Gate en el MANAGER (`scopes.requireOutboxTransaction`, injerto del juez): el manager no construye la outbox; la spec lo
  condicionaba. Registrado en el roadmap 2.5 junto al default.
- Aviso `warnOnOptInSecurity` con `requireTransaction` apagado (injerto del juez, no en la spec; la outbox no tiene logger).
- El default `true` de `requireTransaction` y el `ctx()` con trx del contrato: 2.5 (anunciado).
- No reabrí ninguna decisión (supersede, `parkAfterMs`, `--apply` por defecto, capacidad `…Native`).

## Contradicciones con la spec

1. **`maxDepth = N + 1`** (arriba): falsa contra el código; escrito con la regla medida (`= N`) y el caso ejecutable con
   los números reales (`maxDepth: 2` ⇒ 422 en el tercero; `maxDepth: 3` ⇒ entra). Requiere confirmación del dueño.
2. Menor, resuelta a favor de la spec: el juez (cuestión 5) decía «`createdAt` como campo opcional, par de capacidad en
   2.5» y «cola vacía ⇒ campo AUSENTE»; la spec pide el par ahora y `null`. Hecho como la spec (par + `null`), anotado en
   el roadmap.
3. Menor, resuelta a favor de la spec: el juez (7.2) proponía `deadDetail: 'ids'` opt-in con `dead: []`; la spec (y el
   coordinador) piden `dead[]` sin `lastError` por DEFECTO y `deadDetail: 'full'` opt-in. Hecho como la spec.
