# Decisión: llaves de colección, OpenFGA y el paquete `@jantstack/adonis-authz`

> 27-08-2026 · Consolidado de **cuatro** informes independientes (arquitectura y seguridad, dos rondas cada uno) hechos contra el código real:
> `auditoria-e1-v3-arquitectura-openfga.md`, `auditoria-e1-v3-seguridad-openfga.md` (marco original) y
> `auditoria-e1-v3b-arquitectura-modulos.md`, `auditoria-e1-v3b-seguridad-modulos.md` (marco revisado).
>
> **Marco definitivo (dueño del paquete):** el paquete es de JATN, es público, **no lo usa ningún proyecto funcional todavía**, y se quiere que incluya **todo de fábrica** (RBAC + llaves/ReBAC + roles por tenant) sin perder su filosofía: *usable en cualquier proyecto, maleable*.

> NOTA DEL DUEÑO DEL PAQUETE (28-08-2026): este documento lo produjo el proyecto consumidor (COGNITIV, un chasis AdonisJS con organizations/units/ia_spaces). Las exigencias hay que analizarlas primero: ¿son factibles? ¿son compatibles con la filosofía del paquete de NO acoplarse a ningún sistema? No se implementa nada hasta responder eso.

---

## 0. Respuesta corta (los dos auditores coinciden)

1. **Sí: el paquete puede incluirlo todo de fábrica sin perder la filosofía**, siempre que sea como **tres módulos opt-in independientes** — `roles/` (RBAC actual), `relations/` (ReBAC genérico) y `catalog/` (roles globales o locales a un scope) — cada uno con su puerto, sus dos drivers (`database`/`openfga`), su suite de contrato y su config. Lo que condenaría al paquete no es incluir ReBAC: es **mezclar los dos modelos en un solo `authorize()`**.
2. **La frontera entre `roles/` y `relations/` es por construcción**, no por disciplina: `roles.authorize()` sigue siendo `false` aunque exista una tupla `viewer`; `relations/` **nunca** llama a `roles.authorize()` ni a `resolveAncestors` (la partición no tiene árbol); ningún manager recibe al otro por constructor. Test bloqueante en la suite del paquete.
3. **`ia_space_access` puede y debe ser la tabla del paquete** (una verdad, sin proyección paralela), aceptando una pérdida real: la **FK compuesta** no existe en una tabla polimórfica. Se compensa con **cuatro piezas juntas** (ninguna basta sola): partición obligatoria con FK real a `organizations`, hook `assertObjectInPartition` **obligatorio** (sin hook, el paquete se niega a escribir), **trigger** de partición por tipo de objeto generado por un helper del paquete, y el reader de la app cruzando con `ia_spaces(uuid, organization_uuid)` + `lifecycle` + `deleted_at`.
4. **T2 no espera al paquete.** Nace con SQL propio detrás de **seams de lote** y una **suite de contrato exportable**; el swap al módulo `relations/` cuesta **1–1,5 d** si esos seams se respetan (4–5 d si no).
5. **Estimación real del paquete: 14–16 días** (no 8–10): puerto + driver `database` (3 d) + driver `openfga` (2,5 d) + contrato (~28 casos × 2) + `catalog/` (2,5 d) + **reestructurar en módulos, `configure` interactivo, stubs y migraciones separadas (1,5 d)** + docs/guía de upgrade (1 d) + spikes (0,5 d).
6. **Orden**: T2 (ya) → 2 spikes de FGA (90 min) → `catalog/` (roles por tenant: más barato, requisito de cliente identificable, y sirve para ensayar la modularización sobre la pieza pequeña) → `relations/` → swap.

---

## 1. Hechos del paquete que gobiernan la decisión (verificados en `node_modules/@jantstack/adonis-authz@1.1.0`)

| Hecho | Dónde | Consecuencia |
|---|---|---|
| El modelo FGA lo **genera el paquete** entero desde `holderTypes`; holders con `relations: {}` → almacén de tuplas con TTL | `openfga_driver.js:85-122` | Sin costura de modelo no se pueden escribir tuplas de otros tipos en el mismo store |
| `role_binding` ya tiene `assignee` → el userset `role_binding:organization\|X\|admin#assignee` es expresable con una línea | `openfga_driver.js:98-100` | El userset "rol de org" no exige tipos nuevos |
| `SubjectRef = {type, uuid}`; `holder_uuid` es `uuid`; scope polimórfico sin FK; `chain()` con herencia incondicional | `types.d.ts:35-38`; `stubs/migration.stub:66-82`; `database_driver.js:39-41` | `roles/` es incompatible con usersets, partición y "sin herencia": `relations/` necesita **tabla, driver y contrato propios** |
| `database_driver` escribe con `db.table(...).insert` y no acepta `trx` | `database_driver.js:112-121` | El mixin `auditable` (hooks de modelo Lucid) **nunca dispararía** sobre una tabla del paquete; y `pdp_version` en la misma trx exige `{trx}` externo en el puerto nuevo |
| `onWrite` sin actor, post-escritura, se traga fallos | `manager.js:234-241`; `types.d.ts:118-127` | Auditoría y `pdp_version` no pueden depender del hook tal como está |
| `ListObjects` sin paginación ni señal de corte (1000 / 3 s); el driver no pasa `consistency` | `openfga_driver.js:489-497`; openfga #2828 abierto | Solo es detectable el truncamiento **por cantidad**, no por deadline |
| `openfga:provision` crea store nuevo cada vez; `api`/`worker` sin `depends_on: openfga` | `openfga_provision.js:401-405`; `docker-compose.prod.yml:152-174` | T0b sigue siendo prerrequisito de cualquier driver `openfga` en producción |
| ❓ Conditions sobre tuplas de userset (`unit#member with not_expired`) · ❓ `streamed-list-objects` sin límite de 1000 | API lo representa (`apiModel.d.ts:1243-1268`, `:843-849`); doc no lo ejemplifica | **Dos spikes (90 min) antes de escribir `relations/`**: de ellos depende la paridad de caducidad entre drivers y si `listObjects` puede ser un PDP honesto |

---

## 2. La arquitectura: un paquete, tres módulos

```
@jantstack/adonis-authz
├─ roles/       RBAC por scope con herencia (lo actual, intacto; instalable solo)
├─ relations/   ReBAC genérico: relate / unrelate / check / listObjects (lote) / listSubjects / purgeObject / purgeSubject
└─ catalog/     roles y permisos, globales o locales a un scope (dueño natural: roles/; relations/ NO lo necesita)
```

| Acoplamiento | Veredicto |
|---|---|
| `relations/` acepta `role_binding:<scope>\|<rolUuid>#assignee` como userset | ✅ por **dato** (cadena declarada por el consumidor), no por código |
| `relations/` reutiliza `scopeKey()` / `assertScopeComponent()` de `roles/` | ✅ utilería de serialización, no semántica |
| `relations/` llama a `roles.authorize()` o `resolveAncestors` | ❌ **prohibido**: la partición no es un nodo de árbol; es la puerta de la fuga D6 |
| `catalog/` obligatorio para `relations/` | ❌ `relations/` tiene relaciones declaradas en su modelo, no roles |
| `roles/` depende de `relations/` | ❌ nunca |

**Prueba de genericidad (barata):** diseñar `relations/` contra **dos** casos a la vez — las llaves de COGNITIV y "compartir un documento con un usuario o grupo, estilo Drive" (`document` + `viewer/editor/owner` + `group#member`). Si el puerto sirve a ambos sin un `if`, es genérico.

---

## 3. Módulo `relations/` — diseño acordado

### 3.1 Puerto
```ts
type ObjectRef  = { type: string; uuid: string }
type UsersetRef = { object: ObjectRef; relation: string }        // unit:U#member
type RelationSubject = SubjectRef | UsersetRef                    // reutiliza SubjectRef de roles/

interface RelationsDriver {
  relate(s: RelationSubject, relation, o: ObjectRef, partition: ScopeRef, opt?: { validUntil?, externalRef?, trx? })
  unrelate(s, relation, o, partition, opt?: { trx? })
  check(s: SubjectRef, relation, o, partition): Promise<boolean>
  listObjects(subjects: RelationSubject[], relation, objectType, partition): Promise<ObjectRef[]>   // POR LOTE
  listSubjects(relation, o, partition): Promise<RelationSubject[]>
  purgeObject(o, partition, opt?: { trx? }): Promise<number>
  purgeSubject(s, partition, opt?: { trx? }): Promise<number>     // baja de usuario / unit / expulsión
}
hooks.onRelationWrite({ action, subject, relation, object, partition, actor, externalRef, meta })
```
- **`partition: ScopeRef`** (no `string`): reutiliza tipo, `scopeKey` y escape; **obligatoria y no-nullable** en todas las operaciones; sin partición "global" (un consumidor no multi-tenant usa una constante); **FK declarable** a la tabla del consumidor (`partitionRef`), obligatoria en COGNITIV.
- **`{trx}` externa** en el driver `database` (no abre la suya si la recibe); el driver `openfga` la rechaza explícitamente (documentado).
- **Sin tabla de atributos en el paquete.** `attributes` rompería la pureza del driver `openfga` (escribiría en dos backends sin transacción). En su lugar: `externalRef` opcional en la tupla + tabla **del consumidor** (`ia_space_access_meta`: `granted_by`, `reason`, `constraints`, `external_did`) escrita en la misma trx. El hook recibe actor y `meta` para auditar; **nunca** es la fuente de `pdp_version`.

### 3.2 Modelo declarado por el consumidor (JSON/TS, no DSL)
```ts
defineRelationsConfig({
  partitionType: 'organization',
  objects: {
    ia_spaces: { relations: {
      manager:     { subjects: ['users','integrations','unit#member','role_binding#assignee'] },
      contributor: { subjects: [...], includes: ['manager'] },
      viewer:      { subjects: [...], includes: ['contributor'] },
    } },
  },
  usersets: {
    'unit#member':           { usersetsOf: async (subject, partition) => [...],   // sujeto → usersets (check/listObjects)
                               membersOf:  (userset, qb) => qb.whereIn(...) },    // userset → sujetos, como SUBQUERY (listSubjects)
    'role_binding#assignee': { usersetsOf, membersOf },
  },
  hooks: { onRelationWrite },
})
```
- **`includes`** = jerarquía **entre relaciones del mismo objeto** (`viewer ⊂ contributor ⊂ manager`). **`from` (herencia entre objetos) NO existe en v1**: así "sin herencia entre objetos" es una imposibilidad verificable, no una promesa. Límite aceptado: carpetas anidadas no se modelan; añadir `from` después es aditivo.
- **Expansión de usersets: UN nivel, en el paquete no hay recursión.** La recursión (units anidadas) vive en el `usersetsOf` del consumidor, donde ya está el anti-ciclos (`scope_resolver.ts:33-57`). Límites: `maxNodes` (default 1000) → al superarlo **lanza** (`RelationExpansionTooDeep`), nunca `false` ni parcial. Cualquier `catch` en la ruta de decisión es un defecto.
- **Dos direcciones** (`usersetsOf` / `membersOf`), y `membersOf` devuelve fragmento de query, no array (5.000 miembros en un `IN` revienta).
- Usersets no declarados → throw; **userset de otra partición → throw** (cierra E3-por-accidente sin hook).

### 3.3 Driver `openfga`
- Fusiona el modelo declarado con los bindings RBAC en un solo authorization model (`openFgaAuthorizationModel(holderTypeMap, extensions)`); **lanza ante colisión** de nombre de tipo.
- Object id **con la partición**: `ia_spaces:<partitionKey>|<uuid>` (escape con `assertScopeComponent`) y **filtro obligatorio al leer**: descarta con log de error todo resultado sin el prefijo.
- `listObjects` con `consistency: HIGHER_CONSISTENCY`; si `objects.length === listObjectsMaxResults` → `RelationsResultTruncatedError`. Escribir en el README **"detección parcial de truncamiento (por cantidad, no por deadline)"**; probar `streamed-list-objects` (spike).
- Caducidad por condición `not_expired` (❓ sobre usersets: spike). Renovar = `delete+write`: si falla el segundo paso, `relate` **lanza** (nunca revocación silenciosa). Purga de caducadas: `relations:prune --partition` emite `onRelationWrite({action:'expired'})`.
- Reutiliza `guardBackendErrors` (503, nunca `false`/`[]`).

### 3.4 Esquema (driver `database`)
```sql
authz_relations
  uuid PK
  partition_type varchar(20) NOT NULL · partition_uuid uuid NOT NULL   -- FK declarable al consumidor
  object_type varchar(50) NOT NULL · object_uuid uuid NOT NULL
  relation varchar(50) NOT NULL
  subject_key varchar(200) NOT NULL      -- users:<uuid> | unit:<uuid>#member | role_binding:<k>#assignee  (identidad de la fila)
  subject_type · subject_uuid · subject_relation                        -- desglose para consultar/auditar
  valid_until timestamptz NULL · external_ref varchar(100) NULL · created_at · updated_at
  UNIQUE (partition_type, partition_uuid, object_type, object_uuid, relation, subject_key)
  INDEX  (partition_type, partition_uuid, subject_key)                  -- listObjects por lote
  INDEX  (partition_type, partition_uuid, object_type, object_uuid)     -- listSubjects / purgeObject
  INDEX  (valid_until) WHERE valid_until IS NOT NULL
```
+ helper `relationPartitionTrigger(objectType, table, uuidCol, partitionCol)` que genera un `BEFORE INSERT OR UPDATE` en la migración del consumidor (cierra el `INSERT` manual; el borrado del padre lo cubre `purgeObject` en el `destroy()` del consumidor, misma trx).

### 3.5 Suite de contrato (~28 casos × 2 drivers) — bloqueantes marcados
Directas (6) · jerarquía de relaciones (3) · usersets (6: miembro añadido **después** del grant lee; retirado deja de leer; un nivel; no declarado → throw; otra partición → throw) · **partición (5)**: P1 no responde en P2 en `check/listObjects/listSubjects`; sin partición → throw; **objeto fuera de la partición → throw vía hook; sin hook → throw** · lotes y límites (4): lista vacía sin ir al backend; unión sin duplicados; truncado por cantidad → throw; backend caído → 503 · purga (2) · caducidad (3: pasada no cuenta; renovar no duplica; fallo en 2.º paso → lanza) · expansor que lanza ⇒ `check` lanza (no true/false/[]) · `{trx}` con rollback ⇒ nada persistido · ids con `|~#:` → throw · **frontera (2)**: tupla `viewer` no hace `roles.authorize('space.read')` verdadero; rol de org con `space.*` no concede `check(viewer)` · hook recibe actor y meta.

---

## 4. Módulo `catalog/` — roles por tenant (1.3.0)

Principio: **"un rol puede ser global o local a un `ScopeRef`"**; `role` sigue siendo `string`; `SubjectRef` intacto. **Permisos siempre globales** (el consumidor los define; el tenant los combina, nunca los inventa).

| Pieza | Cambio |
|---|---|
| `authz_roles` | `+ owner_scope_key varchar(80) NOT NULL DEFAULT 'global'`; `unique(slug, scope_type, owner_scope_key)`; index. Identidad externa del rol = **uuid** siempre |
| `catalog.js` | upsert por `(slug, scopeType, ownerScopeKey)`; **solo toca globales**; **falla** ante colisión con un rol local; deja de pisar `rank` de locales; **exportar `assertValidSlug`** |
| `database_driver` `findRoleOrFail`/`revoke`/`listRoles`/`listScopes`/**`listSubjects`** (bug latente: hoy cruza tenants por slug) | resolver por `owner ∈ chain(scope) ∪ global`; prohibir colisión local/global |
| `database_driver.grant` | assert de contención: rol local de `organization:X` solo en X o descendientes; en `app` → throw |
| `openfga_driver.rolesGranting` | `(permissionUuid, chain)` filtrando por owner (si no, un check por cada slug homónimo de cada tenant) |
| Binding id FGA | `<scope>\|<uuid>\|<rolUuid>\|<owner>` (4 partes; 3 partes = global, compatible) |
| Puerto | `purgeRole(role, scope)` (revocar todo + borrar en la misma trx; FGA: `ListUsers` + `deleteTuples`) con hook `onRoleDeleted`; `createTenantRole(actor, ownerScope, spec)` con policy: `permissions ⊆ effectivePermissions(actor)` **y** `⊆ tenantAssignablePermissions` (lista blanca: nunca `space.*`, `org.settings.*`, `app`); `0 < rank < min(actorRank, systemTopRank)`; globales inmutables; `onCatalogWrite` para auditoría |
| Contrato (+8×2) | local de A en B → throw · en A concede en A y sus units · en `app` → throw · `listRoles`/`listSubjects` no cruzan tenants · `purgeRole` y recrear slug no revive nada · slug con `\|~` → throw · colisión → throw · crear con permiso ajeno → throw · rank ≥ actor → throw · editar global → throw |
| Impacto en COGNITIV | `role_assignment_policy.ts:25-40` (`roleOrFail`, `maxCatalogRank` ignora locales); `role_clearance` valida contra `authz_roles` por owner; `rol_visible` no exponer nombres de roles de tenant al engine |

---

## 5. `ia_space_access` como tabla del paquete — la decisión honesta

| Aspecto | Veredicto |
|---|---|
| Una sola verdad | ✅ **`ia_space_access` pasa a ser `authz_relations` (+ `ia_space_access_meta` del consumidor)**. Nunca dos tablas en paralelo con proyección: sería un segundo reconciliador de la misma verdad |
| FK compuesta | ❌ pérdida **real** (FK imposible sobre tabla polimórfica). Sustituto = partición con FK + hook obligatorio + trigger de partición + reader con join `(uuid, organization_uuid)` + `purgeObject` transaccional. Es una **degradación consciente** de garantía de motor a garantía de motor-parcial + código; queda decidida aquí, no como nota al pie |
| `subject_key` | ✅ mejora: del paquete, con la forma del `user` de una tupla FGA |
| `pdp_version` transaccional | ✅ con `database` (`{trx}`); con `openfga` → **outbox**: `INCR` **antes** en revoke y **después** en grant (o antes y después siempre) |
| D8 "Redis caído → recalcular desde BD" | con driver `openfga`, **no hay BD desde la que recalcular**: `relations/` es tier-0 → reescribir D8 y `docs/authorization.md` |
| Auditoría | el mixin `auditable` **no funciona** sobre una tabla escrita por query builder → `granted_by`/`reason`/`self_granted` se escriben en `ia_space_access_meta` **en la misma trx** desde `SpaceKeysService` (actor explícito, jobs incluidos) y el hook `onRelationWrite` los audita |
| `lifecycle='active'` | se queda en la app: el reader filtra por `ia_spaces.lifecycle` después de `listObjects` |
| Partición | **siempre del middleware (`:org` resuelto)**, nunca del cuerpo ni del objeto |
| Swap | migración `INSERT … SELECT` (misma forma) con conteo por partición + `pdp_version + 1` + interruptor por org `ia_keys_store = table\|relations` (monótono, auditado, con pre-flight, como `ia_pdp_mode`) |

---

## 6. Lo que T2 fija YA (bloqueante) para que el swap cueste 1,5 d y no toque un test

1. **Seams con la firma del futuro puerto**: `SpaceKeyStore.grant(subject|userset, role, spaceUuid, orgUuid, { expiresAt, grantedBy, reason, trx })` / `revoke` / `renew` / `purgeSpace(spaceUuid, orgUuid, trx)` / `purgeSubject(subject, orgUuid, trx)`; `SpaceKeyReader.spacesReadableBy(subjects[], orgUuid)` (**lote**). La partición es **argumento obligatorio**, no se deduce del espacio. Ningún `IaSpaceAccess.create()` fuera del store (incluido el `space-manager` del creador).
2. **Suite de contrato exportable** `runSpaceKeyStoreContract(harness)` (patrón `contract.js`), no un `.spec` con la impl cableada.
3. **`subject_key` con la forma canónica del paquete**: `users:<uuid>` · `integrations:<uuid>` · `organization:<uuid>#member` · `unit:<uuid>#member` · `role_binding:organization|<orgUuid>|<roleUuid>#assignee`. **Roles por uuid desde el día 1** (`subject_role_uuid`); `role_clearance` por uuid o solo slugs de `organization_acl`.
4. **`unique(organization_uuid, space_uuid, role, subject_key)`** (con la partición dentro) **y** la FK compuesta mientras exista la tabla propia.
5. **Reader con join defensivo** `× ia_spaces ON (uuid, organization_uuid)` + `lifecycle='active'` + `deleted_at IS NULL` + vigencia. Test bloqueante: fila `(org=A, space=B)` insertada a mano **con la FK desactivada en el test** → el reader no la devuelve (así el test sobrevive al swap).
6. **`pdp_version + 1` en la misma trx** en el **store**, nunca en un hook.
7. **`AccessResolver` con tres aserciones**: solo `space-<hex>`/`sin-acceso`; nunca `purpose !== 'user'` ni `spaces_all` por camino de usuario (`context_signer.ts:68` deja que las claims sobrescriban `purpose`); membresía vigente antes de leer llaves; `spaces_all` solo cuando alcanza **todas** las activas.
8. **Auditoría por el store**, no por el mixin: ningún test depende de `created/deleted` del mixin para llaves.
9. **`purgeSpace` en `IaSpacesService.destroy` y en `PurgeOrgFromEngineJob`**; `removeMember`/`units.destroy` borran llaves **antes** del `revoke` del motor.
10. **`fgaSubjectKey()` en una sola función**; `RedisClaimsCache` con HMAC + versión + recalcular en caída; retirar el `Map` de `identity_context_builder.ts`; interruptor `ia_keys_store` previsto en el esquema; **cero cambios al paquete durante T2**.

---

## 7. Estimación y orden de ejecución

| # | Qué | Días | Bloquea |
|---|---|---|---|
| 1 | **T2** con SQL propio + seams de §6 | 3,5 | nada — **adelante ya** |
| 2 | Spikes FGA: conditions sobre usersets · `streamed-list-objects` | 0,5 | el diseño de `relations/` |
| 3 | Reestructurar el paquete en módulos (`configure` interactivo, stubs y migraciones separadas, provider, compat) | 1,5 | — |
| 4 | **`catalog/`** roles locales (+8 tests × 2) | 2,5 | — |
| 5 | `relations/` puerto + validación del modelo | 1,5 | — |
| 6 | driver `database` (expansión bidireccional, partición, caducidad, `{trx}`) | 3 | — |
| 7 | driver `openfga` (fusión de modelos, prefijo+filtro, lotes, truncamiento, streaming) | 2,5 | — |
| 8 | suite de contrato `relations/` (~28 × 2) | 2 | — |
| 9 | README/docs de 3 módulos + guía de upgrade | 1 | — |
| 10 | Swap de T2 al módulo + migración de datos + trigger + `ia_keys_store` | 1–1,5 | — |
| | **Total paquete** | **14–16** | |

T0b (OpenFGA operativo) sigue siendo prerrequisito de cualquier driver `openfga` en producción.

---

## 8. Lo que NO se hace
- Mezclar `roles/` y `relations/` en un `authorize()`, o que `relations/` use `resolveAncestors`/`roles.authorize()`.
- `partition: string` (es `ScopeRef`), ni partición "global"/nullable.
- Tabla de `attributes` en el paquete; `from` (herencia entre objetos) en v1; recursión de usersets en el paquete.
- Prometer "detección de truncamiento" a secas (solo por cantidad).
- Mantener `ia_space_access` y `authz_relations` en paralelo (proyección).
- Roles por tenant sin `assertValidSlug`, `purgeRole`, owner en catálogo y techo de permisos; permisos por tenant.
- `AUTHZ_DRIVER=openfga` (para cualquier módulo) sin T0b.
- Posponer T2 por el paquete.

## 9. Preguntas para el usuario
1. **Producto**: roles de empresa = combinar nuestros permisos (sí) / inventar permisos (no) — confirmar.
2. **Dónde está el código fuente** de `@jantstack/adonis-authz` (aquí solo está `build/` en `node_modules`) para clonarlo en `~/proyectos/…` y empezar por los spikes + `catalog/`.
3. OK a la secuencia: **T2 ahora con seams** → spikes → `catalog/` → `relations/` → swap.

---

# Parte III · Permisos por recurso / departamento: veredicto del panel (27-08, noche)

> Panel: analista técnico (`panel-paquete-arquitectura.md`), auditor de seguridad en modo rotura (`panel-paquete-seguridad.md`), tester de contrato (`panel-paquete-tester.md`) y juez (`panel-paquete-juez.md`). **Código fuente del paquete localizado**: `/home/jose/proyectos/Personal/adonis-authz` (v1.1.0, `252ea8c`; suite 40/40 SQLite · 67/67 con OpenFGA).

## III.0 Veredicto del juez
El paquete **sí** puede expresar "X solo en su departamento/recurso" sin vocabulario de dominio, pero **no con las 7 piezas propuestas**: 3 estaban mal encuadradas y las 2 de más valor no estaban en la lista. Entra un lote de **8 correcciones de defecto presente**, **6 primitivas nuevas** y un **cuarto módulo `http/`** para el middleware. Se rechazan `resourceScopes` en el motor (CRÍTICO no mitigado: `scopeOf(tipo, uuid)` sin tenant = cruce de tenants + oráculo de existencia), `beforeWrite` unificado y `onWrite` transaccional.

## III.1 Lo que entra

**L0 · Correcciones de defecto presente (se hacen pase lo que pase, 2 d + 1 d de casos)**
| # | Nombre definitivo | Hallazgo que cierra |
|---|---|---|
| 1 | `whereScopeIn([]) ⇒ whereRaw('1 = 0')` | conjunto vacío = sin cláusula (fail-open latente; alcanzable con `descendantsOf`) |
| 2 | `holderTypes` inyectivo, verificado en boot | mapa inverso colapsado → `listSubjects` miente, revocación en bucle deja asignaciones vivas |
| 3 | `UnknownScopeError`: `ScopeAncestorsResolver` puede devolver `null` ⇒ `authorize` **false**, `grant/deny/hasRole` **throw**; sin resolutor, declarar tipos ≠ `app` ⇒ throw en boot | scope inexistente/borrado resolvía a `[app]`: un grant de plataforma gobernaba recursos borrados (latente: `superadmin` no lleva `org.*`) |
| 4 | `expiresAt`: `undefined` = no tocar · `null` = quitar; acción `extended` con `previousExpiresAt` | re-grant sin opciones borraba una caducidad vigente |
| 5 | `assertIdentityComponent` (gramática + longitud) en **ambos** drivers + validación de longitudes en `defineConfig` | `database` no validaba nada; `openfga` sí → divergencia; `uuid` con `#` → userset accidental |
| 6 | `hasRole` **no es decisión de acceso** (documentado + caso de contrato); `appAccess({ role })` deprecado; forma `hasRole(s, {slug, scopeType}, scope)` | **`deny` no gobierna `hasRole`** en ningún driver; el paquete publica un PEP indenegable; el chasis usa `orgAccess({ role: 'owner' })` |
| 7 | Paginación con `continuation_token` + `RelationsResultTruncatedError` en los dos `listObjects` del driver `openfga` | **truncamiento silencioso de denies en `listScopes`** = scope denegado devuelto como concedido (fail-open; ninguno de los 67 tests lo ve) |
| 8 | Modelos exportados de solo lectura (condicionado a la pregunta "¿1.2 puede ser breaking?") | escritura por `AuthzAssignment.create()` salta hooks, catálogo y contención |

**L1 · Primitivas nuevas (3,25 d)** — todas en `roles/`
- `GrantOptions.within?: ScopeRef` + `isWithin(a,b)`: assert `within ∈ chain(scope)`; `requireWithin` (false en 1.2, true en 2.0). **No se llama "tenant"**: contención en la cadena, vale para org/unit y project/task.
- `authorizedScopes(subject, permission, scopeType) → {kind:'all'} | {kind:'some', scopes} | {kind:'none'}`; `maxScopes` **lanza**; sin `descendantsOf` declarado, **lanza** (nunca lista incompleta).
- `descendantsOf(scope, {maxNodes})`: **puerto que implementa el consumidor** (CTE recursiva); prohibido dentro de `authorize` y `listScopes`.
- `hierarchicalScopeResolver({ parentOf, maxDepth: 64 })`: helper opcional, anti-ciclos, cota que **lanza** (truncar la cadena pierde el deny de la raíz = fail-open).
- `memoizeAncestors(resolver, { ttl: 'request' })` (memo de ancestros, nunca de decisiones) · `listDenies(subject, scope?)` · `effectivePermissions(subject, scope)` (prerrequisito de `catalog/`) · `authorizeMany(subject, permission, scopes[])`.

**L2 · Módulo nuevo `http/` (1,5 d)** — `resourceAccess({ resource, param, tenantParam, permission, readPermission })`: `resources[key].load(ctx, id) → {scope} | null` (callback del consumidor; el paquete nunca carga por modelo), `gate(ctx)` opaco (membresía), `tenantParam` **obligatorio** con assert `tenantScope ∈ chain(scope)` **antes** de autorizar (fallo ⇒ **404, nunca 403**), `readPermission` declarado sin default, orden 401 → 403 ability → 404 tenant → 404 recurso → authorize exportado como default sobrescribible, `AuthorizationBackendError` **nunca** disfrazado de 404, sin segundo `authorize` si la acción ya concedió.

**L3 · Hooks (2 d, aplazable)** — `AuthzWriteEvent.actor` + `requireActor` · `assertWrite(event)` (puro, ambos drivers, fail-closed) · `onWriteInTrx(event, trx)` **solo `database`** (registrarlo con `openfga` falla en boot) · `{trx}` en `GrantOptions` rechazada explícitamente por `openfga`. `onWrite` y `manager.spec.ts:72,89` **intactos**.

**L4 · `catalog/`** — `assignableAt` como control de **composición** (no barrera de evaluación; aviso en README) + `authz:catalog:diff` que falla en CI (el sync es aditivo y nunca borra vínculos).

## III.2 Se rechaza
`resourceScopes`/`scopeOf(tipo, uuid)` en el motor · carga de recursos por el paquete · "membresía"/"tenant" como conceptos del paquete (entran como `gate()` y `within`) · `beforeWrite` unificado / `onWrite` transaccional · `descendantsOf` implementado por el paquete sobre `parentOf` · `permission.grantableAt` en la **evaluación** (rompería "un grant en un scope autoriza en sus descendientes"; debate de producto) · middleware de `roles/` consultando `relations/` · `from`/ABAC · deny con caducidad en 1.2 (→ 1.3, migración + condition en `deny_binding`).

## III.3 Va al consumidor
`gate()` · `load()` · `descendantsOf` (CTE) · compare-and-swap en el `UPDATE` (TOCTOU de dueño) · policy de `deny` (rango; "quien deniega puede desdenegar") · `pdp_version` y outbox · filtrado por `lifecycle`/`deleted_at` tras `authorizedScopes` · formato de errores HTTP.

## III.4 Coste corregido y orden
| Bloque | Días |
|---|---|
| Base (tres módulos, decisión §7) | 14–16 |
| L0 defectos | 2,0 |
| L1 primitivas | 3,25 |
| L2 `http/` | 1,5 |
| L3 hooks | 2,0 |
| Suite real (tester: harness `fakeCtx`, tablas ficticias, reloj inyectable, 2.º OpenFGA con `--listObjectsMaxResults` pequeño; 37 casos + ~6 de L0) | 5,0 |
| **Total con todo / sin L3** | **27–29 / 25–27** |
| Mínimo que entrega "X en su departamento" (L0 + `within` + `authorizedScopes`/`descendantsOf` + L2 + suite) | +7,5 sobre la base |

Orden: **T2 ya** (nada la bloquea) → **L0 en paralelo** (defectos, no esperan a nada) → spikes FGA + reestructurar en módulos → **L1 antes de `catalog/`** (`effectivePermissions` es prerrequisito) → `catalog/` → **L2** → `relations/` → swap → **L3** cuando se decida.

## III.5 Lo que COGNITIV hace YA en T2 (lista única del juez)
1. Un solo embudo `authorize()` con `ScopeRef` calculado; nunca `orgScope()` inline.
2. `scopeOfSpace(space) → ScopeRef` en una sola función (hoy siempre `organization`).
3. **Fallo cerrado en el chasis hoy**: `scope_resolver.ts:30` y `:59` devuelven `[APP_SCOPE]` para space/unit inexistentes → centinela que haga `authorize` false (0,1 d).
4. Rama `default` con throw en `resolveScopeAncestors` para tipos desconocidos (hoy caen en la rama `unit` y cuelgan de `app`).
5. `spaceAccess` con la firma del futuro middleware (`resource, param, tenantParam, permission, readPermission`), `loadSpace()` separado, **membresía factorizada a `gate()`**.
6. El recurso se resuelve con `where organization_uuid = :org` **antes** de autorizar; ajeno ⇒ 404, nunca 403.
7. `UPDATE` con compare-and-swap sobre la columna de scope autorizada; 0 filas ⇒ 409.
8. CTE de descendientes detrás de `authorizedScopes(...) → all|some|none`, no `whereIn` incrustado en `baseQuery()`.
9. No usar `listScopes` en producto/caminos calientes ni `withAuthzScopes` para índices departamentales.
10. Toda llamada a `grant` precomprueba el contenedor (`findUnitOrFail`); revisar `organization_invitations_service.ts:147`, `organizations_service.ts:127`.
11. Policy en el servicio (`assertCanManageSpaceKey`, rangos, listas blancas, **`assertCanManageDeny`** antes de exponer `deny` por HTTP).
12. **Migrar los PEP por rol a permiso** (`organizations.ts:39` `role:'owner'` y el otro): mientras existan, un `deny` no los frena.
13. Orden real de middlewares: `validateUuidParam` va antes de `auth` (`ia.ts:135`) → 400 en vez de 401; `try/catch` en `JSON.parse(token.abilities)` (`ability_middleware.ts:36-39`).
14. Lo ya decidido en §6 (roles por uuid, `subject_key` canónica, unique con partición + FK compuesta, reader con join, `pdp_version` en el store, `purgeSpace`, `fgaSubjectKey()`, suite exportable, `ia_keys_store`).
15. `pdp_version + 1` en `assignRole/removeRole` de unit (bloqueante).
16. No añadir `spaces` a `unitRolesStructure` hasta que exista PEP en `unit`.
17. Cero cambios al paquete durante T2.

## III.6 Preguntas para el dueño del paquete (por impacto)
1. ¿Habrá un **segundo consumidor real** en los próximos meses? Decide L1+L2 (con uno solo, `authorizedScopes` y el middleware se escriben en COGNITIV en ~2 d). **L0 se hace igual.**
2. ¿**1.2 puede ser breaking**? De ello dependen L0.3, L0.4, L0.8 y L0.6; si no, se agrupan en 2.0.
3. ¿`ScopeRef.uuid` es uuid (validar) o string (ampliar columnas)? Decide si `authorize` puede dar 500 en lectura y si se sigue anunciando MySQL/SQLite.
4. ¿Se sostiene "un solo juez para los dos drivers"? `{trx}`, caducidad de denies y truncamiento no pueden correr en ambos: contrato bifurcado por driver o dejar de prometer paridad.
5. ¿CI con segundo OpenFGA (`--listObjectsMaxResults` pequeño)? Sin él, el test del truncamiento de denies no se escribirá.
6. ¿`assertWrite` obligatorio cuando el consumidor declara recursos o roles locales?
7. ¿El README publicado promete algo que el código no hace (herencia, `listScopes`, "el deny gana")?
8. Producto: ¿un permiso puede reservarse a un nivel (`grantableAt`) aunque rompa la herencia hacia abajo?
