# Lote B (plan 2.5) — re-ataque 2 del auditor sobre el cierre 2 (repaso final, 2026-10-15)

Árbol: `main` sobre `beb1d0a` + lote B + cierre 1 + cierre 2, en el working tree. Para aislar lo que cambió el cierre 2 comparé
contra la copia del cierre 1 (`scratchpad/audB2/repo`). Copia de trabajo: `scratchpad/audB3/repo` (`node_modules` enlazado). Repro
propio: `scratchpad/audB3/repo/tests/audb3_repro.spec.ts`.

Qué corrí y qué no:
- Solo SQLite `:memory:`.
- Ni pg, ni mysql, ni gates, ni `docker`, ni OpenFGA.
- Los mutantes los apliqué sobre la copia y la restauré; `diff -rq src` quedó limpio.
- No modifiqué el repo salvo este fichero.

## Veredicto en una línea

**NO apta para sellar tal cual, por un solo punto.** N1–N8 están cerrados de verdad: lo comprobé ejecutando o leyendo cada uno, sin
debilitamientos ni regresiones del cierre 2. Pero aparece **1 🟠 nuevo, N9**. No es una regresión: existe desde L-0 y el lote A.
Sin embargo, la decisión §6.1 del cierre 2 («un 422 en la poda solo puede ser el driver contradiciendo al plan») y el README
§Upgrading 6 («one rule for every destination row the API does not admit») lo afirman imposible, y con los drivers del paquete
pasa. Se cierra con un arreglo pequeño en el plan o con un límite declarado y firmado. Además hay 3 ⚪ de letra.

## Tabla N1–N8 → estado

| # | Estado | Evidencia (✅ ejecutada / 📖 leída) |
|---|---|---|
| 🟠 N1 `Infinity` | **Cerrado** | 📖 `openfga_relations_driver.ts:289` `Number.isInteger(d) && d > 0`; `Infinity`/`NaN`/0/negativo/`'3000'`/`1.5` ⇒ 500 con la letra (caso `relations_openfga.spec.ts:1601` y `:1632`, ✅ verdes). Grep `no deadline\|sin deadline\|Infinity` en README, CHANGELOG, src, tests y commands: solo quedan frases que niegan o retiran, más los `notInclude` del caso y usos ajenos (`sql_descendants`, hooks). README :687-695, la fila Limits :1293 y §Upgrading 7 :1543-1560 dicen «lower of … (when not 0) and `--request-timeout`», citan v1.19.0 y la medición (30 ms ⇒ 0 de 40 000), y que los dos a 0 no se soportan. El caso `:1626` está reescrito. Umbral 0,9: sigue siendo correcto, ver la tabla de abajo. Restos ⚪ en N10. |
| 🟡 N2 forma → F-05 | **Cerrado** | 📖 `reconcile.ts:517-518` `assertSupportedUserset` antes que `assertRelationDeclared`. ✅ Mutante «invertir el orden» ⇒ **1 rojo / 42** (`relations_reconcile` + `_cli`), en el caso `:373`. Ese caso cubre tres `toConfig` (sin `folder` ni `reader`, con `folder`, sin config), ×dry/real, y afirma `usersetUnsupported 2`, `undeclared 0`, `modelDrift []` y que no aparece «decláralos». |
| 🟡 N3 unificación | **Cerrado** (las garantías del lote A se sostienen; la premisa del 422 no, ver N9) | ✅ **Tabla de verdad EJECUTADA** (`audb3_repro` B) por `reconcileRelations` + `relationsReconcileLines`: {`invalid-identity`, `userset-unsupported`, podable, 2 podables + 1 inválida, limpio} × prune {ausente, `false`, `true`} × {dry, real}, 30 filas. Coinciden con la tabla del informe: el residuo nunca recibe `unrelate` (`unrel=0`); `pruned: false` con prune (dry y real) y ausente sin prune; `error` con el prefijo `^sobra (<motivo>) destino:`; `clean=false` en los cuatro modos; el consejo solo aparece sin prune, en pasada real y por `extra − residuo` («2 tupla(s)» en la fila mixta). 📖 `report.prune` lo pone siempre la pasada (`prune = false` por defecto). Casos (c) del lote A: la justificación es cierta. F-R1 del runbook es de **roles** (`authz:reconcile`, bucket `unknown-scope`), no de relaciones: el runbook y su script no se tocan y no afirman `pruned: true` de relaciones. La garantía «una tupla fuera de gramática se lista con lado, motivo y porqué» sigue en pie, ahora con `error` en vez de `warning`. Lo único que se pierde es que un driver sin gramática ya no la borra, que es la regla decidida. |
| 🟡 N4 runner B3 | **Cerrado** para el harness con las capacidades; el límite no está escrito (⚪ N11) | ✅ Mutante «`relate` guarda y DESPUÉS lanza» sobre el doble ⇒ `relations_contract.spec` **57/58, 1 rojo** («ROJO (N4) … listSubjects la enumera»). El harness mínimo (`usersetSubjects: false`, `enumerateRelations: false`) sigue verde con el mutante. El informe dice que el límite «se declara en el runner (comentario)», pero 📖 `grep -n "mínimo\|N4"` en `src/testing/relations_contract.ts`, README y CHANGELOG no lo encuentra. |
| ⚪ N5 lecturas puntuales | **Cerrado** | 📖 Las seis llamadas `client.read(` de los dos drivers pasan por `tuplesOrThrow` (×4 en roles) o por `Array.isArray` (`#readTuple :540`, `#readAll :1006`). El grep del caso es `tuples\s*(\?\?|\?\.\[)` sobre los dos drivers. Casos `openfga_driver.spec:1474` y `relations_openfga.spec:1669` verdes ✅. |
| ⚪ N6 no-objeto | **Cerrado** | 📖 `relations_config_store.ts:96-102`. Una `spec` NULL no es posible: la columna es `notNullable` en el stub. Caso `relations_persisted_config.spec:116` verde ✅. |
| ⚪ N7 `holderTypes` | **Cerrado** | 📖 `define_relations_config.ts:399-404`; `null` también da 422. Caso `relations.spec:283` verde ✅. El límite de roles está escrito en el informe §1. |
| ⚪ N8 desglose R-17 | **Cerrado** | 📖 `describeSkipped` (`reconcile.ts:457-470`). Caso `:423` verde ✅. |
| CLAUDE.md punto 7 | **Cerrado** | 📖 :979-982. `grep "exitCode = [^1]" commands` = 0, así que todas las ramas fallidas salen con 1, como dice el punto. Los casos nombran el prefijo: `^sobra \(invalid-identity\) destino: `, `^sobra \(userset-unsupported\) destino: .*`, `^sin migrar \(…\) origen:`. |

Transversal (✅ diff contra la copia del cierre 1):
- **Ficheros de test cambiados:** solo los 7 del informe, más `src/testing/relations_contract.ts`.
- **Asserts quitados:** son exactamente los de los casos (c) declarados: el ⚪ R2 de `_cli`, `:568`/`:599` de `relations_reconcile`, el 🟡 8 de `relations_openfga`, el `include Infinity` de `scope_depth` y el grep de 3 → 4 de `openfga_driver`. Todos están reescritos con aserciones iguales o más fuertes.
- Sin `skip` nuevos.
- `freeze.spec`, `EXPECTED_FUSED` y `migration_stub` fuera del diff del cierre 2.
- **Specs en `:memory:`:** las 8 tocadas, 188/188 verdes ✅. `relations_contract.spec` 58/58 sin mutante ✅.
- **README §Upgrading to 2.5.0:** puntos 4–11 = B1–B8, cada uno con *Adapt*.
- **CHANGELOG:** una entrada por B1–B9 en `[Unreleased]`. El 🟡 8 del cierre 1 está corregido en su sitio, no duplicado. Pero la sección del cierre 2 está mal colocada: ver ⚪ N12.

### Tabla N1: servidor × lo declarado × `timeoutMs` del cliente (default 5 000 ms)

El cliente mide desde antes del `fetch`, así que una llamada cortada por el servidor en S dura al menos S, y S ≥ 0,9·S: el umbral
nunca deja pasar como completa una lista cortada en el S declarado. Su único precio es el falso positivo ya declarado.

| `--listObjects-deadline` / `--request-timeout` | Corte real S | `listObjectsDeadlineMs` D | `timeoutMs` T | Llamada larga ⇒ | ¿Lista muda? |
|---|---|---|---|---|---|
| 3 s / 3 s (defaults) | 3 s | 3 000 (default) | 5 000 | 200 a ~3 s ≥ 2 700 ⇒ `truncated` | no |
| 0 / 3 s | 3 s | 3 000 | 5 000 | igual | no (con `Infinity` era sí: el 🟠 N1) |
| 0 / 30 ms (medición) | 30 ms | 30 | 5 000 | ≥ 27 ms ⇒ `truncated` (caso) | no |
| 10 s / 10 s | 10 s | 10 000 | 5 000 | el cliente corta a 5 s ⇒ 503 | no (ruidoso; la señal es inalcanzable, sin daño) |
| 3 s / 3 s | 3 s | 2 000 | 1 500 | 503 del cliente a 1,5 s | no |
| 3 s / 3 s | 3 s | **10 000** (sobredeclarado) | 5 000 | 200 a ~3 s < 9 000 | **sí**: error del operador que la guarda no ve. Mismo caso con `Number.MAX_SAFE_INTEGER` (⚪ N10) |
| 0 / 0 | ❓ gateway 5 s | — | — | no medido | límite declarado |
| ambos > 5 s, vía HTTP | ❓ `--http-upstream-timeout` 5 s | — | — | lo más probable es un 5xx del gateway (⇒ 503, ruidoso) | ❓ no medido; la letra «lower of the two» no nombra este tercer corte (⚪ N10) |

Ningún `timeoutMs` < D produce una lista muda: el cliente aborta con 503 antes de recibir el 200. La única lista muda posible es
D > S, que es una declaración errónea.

## Hallazgos nuevos (por severidad)

### 🟠 N9 · Una relación RETIRADA de la config deja filas en el destino, y `--prune` aborta a mitad de pasada tras escribir: el 🟠 1 original con otro disfraz, preexistente
- **Escenario:**
  1. **Precondición:** destino `database`, el driver de relaciones del paquete, con una config de la que se retiró una relación
     (`document#publisher`) mientras quedan filas suyas en `authz_relations`. Es evolución normal de la config, no SQL a mano. El
     destino tiene además una tupla que sobra (X) y el origen una nueva (W).
  2. **Acción:** `authz:relations:reconcile --prune`.
  3. `#enumerateRows` filtra por tipos declarados, **no por relación** (`database_relations_driver.ts:930-937`), así que la fila
     `publisher` llega al plan.
  4. El plan solo juzga gramática y forma del userset en el lado destino (`reconcile.ts:625-648`), así que la mete en `toDelete`.
  5. La poda llama a `to.unrelate`, que corre F-05 en su primera línea (`database_relations_driver.ts:554`) ⇒ **422
     `E_AUTHZ_RELATION_UNKNOWN`**.
  6. El catch del 422 se borró en el cierre 2 (`reconcile.ts:436-442`), así que se propaga. El comando no lo captura
     (`authz_relations_reconcile.ts:491`, `throw error`) y sale un **stack crudo**.
- **Resultado ✅ medido** (`audb3_repro` A, `:memory:`):
  - `--dry-run --prune`, con y sin `toConfig`: `escritas 1, borradas 2, sobran 0`, `details []`, sin ninguna línea sobre la fila.
  - La pasada real lanza `422 E_AUTHZ_RELATION_UNKNOWN La relación 'publisher' no está declarada…` **después** de escribir W y
    borrar X. El destino queda a medias: W está, X no, `publisher` sigue.
  - La pasada siguiente: el mismo throw. `--prune` queda inutilizable para esa partición para siempre.
- **Lo que esto contradice:**
  - dry ≠ real.
  - «Never a throw mid-pass for data the report can count».
  - README §Upgrading 6: «One rule for every destination row the API does not admit … never asked of the driver». Esta fila es
    exactamente una que la API no admite: `unrelate` la rechaza.
  - Decisión §6.1 del cierre 2 y CHANGELOG :268: «everything in `toDelete` passed the grammar, so a 422 there is the driver
    contradicting the plan». Es falso: pasó la gramática, pero no F-05.
- **Alcance:**
  - ✅ en `database`.
  - ❓ en `openfga`: `#sweep` también filtra solo por tipo (`:847-854`) y `unrelate` hace F-05 (`:564`). Que el `Read` devuelva
    tuplas de una relación que el modelo vigente ya no declara no lo medí.
  - Un driver de terceros que lance 422 en `unrelate` por cualquier otra razón produce lo mismo.
  - **No es regresión del cierre 2:** en el cierre 1 el catch solo absorbía tuplas `invalid` (📖 `audB2/repo/src/relations/reconcile.ts:433`), así que esta ya se propagaba.
  - No concede nada ni es fail-open. Es la misma forma y la misma severidad que el 🟠 1 del auditor 1: pasada parcial tras
    escribir, que no converge.
- **Steelman del defensor:** «es el residuo declarado de tipos no declarados; el operador no debe retirar una relación con filas
  vivas». ¿Me convence? **No.**
  - Lo declarado es que esas tuplas «no las barre nadie», no que tumben la pasada.
  - El README promete «one rule for every row the API does not admit».
  - La enumeración por tipo deja pasar exactamente las de relación retirada.
- **Mitigación mínima:** dos opciones.
  - Que el plan clasifique en el lado destino las tuplas cuya relación no declara la config del destino, como residuo
    `undeclared` con `pruned: false`, sin entrar en `toDelete` y con la regla y la línea de N3. Exige `toConfig`, o que la
    enumeración del driver filtre también por relación.
  - O, si no entra en este cierre, retirar la frase de §6.1 y del CHANGELOG, declarar el límite en README «Limits» y anotarlo como
    pendiente firmado.
  - Caso: `audb3_repro` A invertido.

### ⚪ N10 · Restos de letra de N1
- 📖 `Number.isInteger(Number.MAX_SAFE_INTEGER)` es `true`: la guarda admite un «sin deadline» con otro nombre. El informe dice
  «no hay forma de escribir "sin deadline"» (§2 (d)), y es exagerado. Fuera de un D enorme el riesgo es el mismo que cualquier D
  sobredeclarado (tabla), así que basta con rebajar la frase o rechazar `D > timeoutMs / RATIO`, que nunca es útil.
- 📖 README :682 y §Upgrading 7 (primera frase), y CHANGELOG B4 :57, dicen todavía «default … = OpenFGA's
  `--listObjects-deadline`; set it to the server's». El párrafo siguiente lo corrige, pero la entrada B4 del CHANGELOG no. Además
  B4 sigue citando `monotonic` como opción inyectable, que ⚪ 9 ya retiró.
- 📖 «lower of `--listObjects-deadline` (when not 0) and `--request-timeout`» no dice qué pasa con `--request-timeout=0` y deadline
  ≠ 0 (un lector literal calcula min = 0 ⇒ 500). Tampoco nombra el corte del gateway (5 s) cuando los dos superan 5 s.

### ⚪ N11 · El límite de N4 no está escrito donde el informe dice
- Un tercero con `usersetSubjects: false` y `enumerateRelations: false` que guarde la fila inerte y lance el 422 pasa el runner:
  el harness mínimo sigue verde con el mutante (✅).
- El informe §1/§6.5 dice que eso «se declara en el runner (comentario)», pero no está en `relations_contract.ts`, ni en README
  «Third-party drivers» / §Upgrading 2, ni en el CHANGELOG N4. Este último dice sin matiz «the runner goes red».
- **Exige:** una frase en README «Third-party drivers», junto a la del deadline, y otra en el comentario del caso.

### ⚪ N12 · La sección del cierre 2 está bajo la release YA PUBLICADA
- 📖 `CHANGELOG.md:205` `## [2.5.0-alpha.1] — 2026-10-15` va seguido de su párrafo de intro, y en `:209` empieza
  `### Closure 2 of lot B`. Es decir, el cierre 2 aparece documentado como parte de alpha.1, publicada, y no de `[Unreleased]`
  (alpha.2), que es lo que pedía el brief.
- **Exige:** moverla encima de `:205`, tras «Closure 1 of lot B».

## Decisiones §6 del cierre 2

| # | Decisión | Veredicto | Por qué |
|---|---|---|---|
| 1 | N3 estructural: `invalid-identity` nunca en `toDelete`; desaparece el catch y un 422 en la poda se propaga | **Condicionar** | La regla por fila es correcta y está bien ejecutada (tabla). Lo falso es la premisa «todo lo de `toDelete` pasó la gramática ⇒ un 422 es una contradicción»: F-05 de `unrelate` sí la rechaza (N9). O el plan clasifica también esa fila, o se retira la frase y se declara el límite. |
| 2 | `report.prune` opcional; el consejo cuenta `extra − residuo` | **Ratificar** | Ejecutado en 30 filas. Ausente = no pasado es compatible con reportes de terceros. |
| 3 | N2 solo en el plan; la API mantiene F-05 → forma | **Ratificar** | En la API los dos son 422 con cero llamadas. El orden solo decide bucket y remedio, que es cosa del plan. |
| 4 | N1 sin caso contra servidor real; medición citada; guardia por fuente | **Ratificar** | La medición es reproducible y está citada con método. Ver la frase exagerada de N10. |
| 5 | N4: límite del harness mínimo | **Condicionar** | El límite es real e inevitable por el puerto, pero hay que escribirlo donde dice el informe (N11). |
| 6 | N5: `{}` ⇒ `unknown` en `readAssignment`, con la vía degradada de objetivo explícito | **Ratificar** | Conserva el contrato de `grant`. Sin objetivo explícito ⇒ 503 sin escribir (caso). |
| 7 | CHANGELOG del cierre 1 corregido en su sitio | **Ratificar, con N12** | La corrección está bien, pero la sección nueva cayó bajo `[2.5.0-alpha.1]`, y B4 conserva dos frases rancias (N10). |

## Lo que intenté y NO se rompió
- **Las ocho specs tocadas** en `:memory:`: 188/188.
- **Mutantes N2 y N4:** muertos (1/42 y 1/58).
- **Tabla N3:** 30 filas ejecutadas y coherentes con el informe y con el punto 7.
- **Consejo «repite con --prune»:**
  - Nunca sale con `prune: true`.
  - Nunca sale con solo residuo.
  - Con residuo del origen, no descuenta del destino.
- **Lecturas FGA:** las seis pasan por la regla exhaustivo-o-503.
- **N6:** la columna `spec` NOT NULL descarta la variante «fila sin spec».
- **`holderTypes: null`:** da 422.
- **Códigos de salida:** ningún `exitCode` distinto de 1 en `commands/`.
- **Runbook y `command_flags`:** no dependen de `pruned: true` de relaciones ni del consejo.

## Preguntas abiertas que cambian el veredicto
1. N9: ¿se arregla en este cierre (clasificar en el plan la fila de relación no declarada del destino, con la regla de N3), o se
   declara como límite firmado y se retira la frase de §6.1 y del CHANGELOG? Cualquiera de las dos deja el lote apto. Dejarlo
   como está, no.
