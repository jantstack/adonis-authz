# `2.4.0-alpha.9` · lote B — el reconcile de hechos respeta el store COMPARTIDO

Rama `main`, HEAD `d18af8e` (alpha.8 publicada). El árbol llevaba SIN commitear el **lote A** (banderas de ace);
este lote es ADITIVO sobre él: no se ha descartado, reabierto ni tocado nada de A. **Sin commits; `version` sigue
en `2.4.0-alpha.8`.**

Base de partida (lote A, verificada): **1364 / 1390 / 1486 / 1488**.

## 0 · El defecto, y lo que ya estaba decidido

`familyOfTuple` (`src/drivers/openfga_driver.ts`) tenía `return 'facts'` de CATCH-ALL, así que en un store
COMPARTIDO (con `openfga` los hechos y `relations/` viven en el mismo store) toda tupla de relación caía en
`phases.facts.extra` y `--prune` la borraba —60 de 60 medidas por COGNITIV, `group` incluido—, con la pasada
destructiva reportando `clean = true` y exit 0. No se re-investigó: la evidencia está en
`panel-shared-store-{auditor,analista}.md` y la decisión en `decisiones-dueno-2026-08-28.md` §2026-09-11 (2).

Las cinco condiciones se han cumplido tal cual (lista blanca explícita y congelada que NO es
`RESERVED_FACTS_TYPES`; la clasificación de borrado no lee nada en runtime; `foreign` como campo propio fuera de
`skipped` y de `details` con `phases` intacto; `relations/` sin tocar; residuo declarado en README + roadmap 2.5).

## 1 · Por pieza: rojo observado → verde → mutante

### S1 · `familyOfTuple` sin catch-all + `OWN_FACTS_OBJECT_TYPES`

`src/drivers/openfga_driver.ts`:

- **`OWN_FACTS_OBJECT_TYPES`** (exportada): `Object.freeze(new Set([FACTS_SCOPE_TYPE, FACTS_ROLE_TYPE,
  FACTS_BINDING_TYPE, LEGACY_DENY_BINDING_TYPE]))` — los CUATRO tipos, compuestos con las constantes que ya
  existían en el módulo (`LEGACY_DENY_BINDING_TYPE` es la de `enumerateFacts`, 3b-8 · A2: el mismo driver no puede
  tratar esa tupla como propia por un lado y ajena por otro). Docblock con el porqué, con el «NO es
  `RESERVED_FACTS_TYPES`, que incluye `group`» y con la regla escrita: *un tipo nuevo del modelo `facts` entra aquí
  en el MISMO commit* (y en `RESERVED_FACTS_TYPES`).
- **`objectTypeOf(object)`** con `indexOf(':')`, no `split`: el id de una tupla de relaciones lo compone el
  consumidor y lleva `|`, y esto decide un `delete`.
- **`familyOfTuple` devuelve `ReconcileFamily | 'foreign'`** y mira el TIPO lo PRIMERO, antes que la relación: una
  tupla ajena que se llamara `rooted` no puede caer en una familia DERIVADA, que son las que se borran **sin**
  `--prune` (endurecimiento propio; `rooted` está en `RESERVED_SLUGS`, así que no es alcanzable declarando una
  relación, pero sí desde un modelo anterior de otro dueño).
- En el bucle de `reconcile`, `family === 'foreign'` sale con `continue` **antes** de `storeBindings`, de
  `parents`, de `phases[...]`, de `note()` y de `deletes.push`.

### S3 · el reporte

- `ReconcileReport.foreign?: { tuples, types: Record<string, number>, relations?, unknown? }` (`src/types.ts`),
  de nivel superior, **fuera de `skipped` y de `details`**; `phases` NO crece (un caso lo fija).
- `reconcileLines` (`commands/authz_reconcile.ts`, pura) imprime, con `foreign.tuples > 0`: la línea de store
  COMPARTIDO con el desglose por tipo (`document (40), group (10)…`), y con `--prune` «`--prune` ha respetado N
  tupla(s) ajenas». Nivel `log`, nunca `error`: **no deriva, no toca `clean`, no cambia el exit**.

### S4 · partir el reporte (hecho, no aplazado)

- `ReconcileSource.relationTypes?: readonly string[]`, que pone el MANAGER desde
  `config.relations.config.objectTypes`; el driver le suma `group` (lo emite siempre el generador) y parte
  `foreign` en `relations` / `unknown`. Sin esa lista, **todo es `unknown`** y no se inventa el desglose.
- Es **solo para el reporte**: la decisión de borrar ya está tomada en S1 y no lo mira (el mutante (c) lo fija).
- El `warning` de «no las reclama nadie» solo sale cuando hay tipos declarados: sin ellos «desconocida» no
  significa nada.

### S2 · los casos

Seis casos nuevos en `tests/reconcile.spec.ts` (ninguno gateado por motor; los tres primeros necesitan
`OPENFGA_TEST_URL`, que las cuatro corridas llevan):

| caso | qué fija | ROJO literal (código de alpha.8) | verde |
|---|---|---|---|
| **B-1** `--prune` no borra ni una ajena | store compartido montado por la VÍA REAL (`OpenFgaRelationsDriver.relate`: 5 `document`, 2 `space`, 1 `group`) sobre el store ya migrado: `foreign.tuples = 8` por tipo, `phases.facts.extra = 0`, nada en `skipped`, `phases` con sus CUATRO claves, `clean = true`, `--prune` deja el store **idéntico tupla a tupla** y el `check` del userset del grupo sigue concediendo | `expected undefined to equal 8` (y con el defecto vivo: `deleted = 8`) | ✅ |
| **B-2** **la prueba decisiva** | store con modelo ANTERIOR (`deny_binding` de 2.2 + `legacy_thing` de otro dueño) + `role_binding:organization\|<uuid>\|org-editor` (id de 1.x) + las ajenas: `--prune` borra **2 de 2** propias obsoletas y **ninguna** ajena (`document` 5, `space` 2, `group` 1, `legacy_thing` 1 intactas) | `las DOS propias obsoletas, y solo ésas: expected 11 to equal 2` | ✅ |
| **B-3** el desglose | sin `relationTypes` ⇒ `unknown = 9` y `relations` ausente; con ellos ⇒ `relations = 8` / `unknown = 1` + `warning`; la única deriva que queda es el `extra-fact` de la tupla PROPIA de 2.2, no las 9 ajenas; y con la lista o sin ella `--prune` borra lo mismo | `expected undefined to equal 9` | ✅ |
| **B-4** (manager, sin servidor) | `source.relationTypes` sale de `relations.config.objectTypes`; sin esa config, `undefined` | `expected undefined to deeply equal [ 'document', 'space' ]` | ✅ |
| **B-5** (puro, `reconcileLines`) | lo ajeno se imprime por tipo, NO tumba `clean`, `--prune` lo AFIRMA, el `warning` de `unknown` solo con desglose, y sin ajenas no hay ni una línea | `expected false to be true` | ✅ |
| **B-6** (estático, sin servidor) | la lista blanca es exactamente los cuatro, **no** lleva `group`, `RESERVED_FACTS_TYPES` sí, y lo propio ⊆ lo reservado | (mata al mutante (b)) | ✅ |

### Mutantes (los tres de S2, obligatorios)

1. **(a) devolver el catch-all `return 'facts'`** ⇒ **3 rojos** (B-1, B-2, B-3). El de B-2 es el defecto medido:
   `expected 11 to equal 2` (borró las 9 ajenas además de las 2 propias). Restaurado.
2. **(b) `OWN_FACTS_OBJECT_TYPES = RESERVED_FACTS_TYPES`** ⇒ **4 rojos**: B-6 (`expected [ 'deny_binding',
   'group', …(3) ] to deeply equal [ 'deny_binding', 'role', …(2) ]`), B-1 (`expected 7 to equal 8`: el `group`
   deja de contarse como ajeno), B-2 (`expected 3 to equal 2`: **borra la tupla de `group`**) y B-3. Restaurado.
3. **(c) decidir «ajena» leyendo `relations.config`** (clasificar por `source.relationTypes` en vez de por la lista
   congelada) ⇒ **3 rojos** con el config AUSENTE, que es el caso de COGNITIV: B-1 `expected 1 to equal 8` y B-2
   `expected 10 to equal 2` (2 propias + 8 ajenas borradas). Restaurado.

## 2 · S5 · Docs

- **CHANGELOG** (`[Unreleased] — 2.4.0-alpha.9`, continuando el del lote A), estilo 1.1.0 y **empezando por el
  impacto**: `--prune` borraba las 60 de 60 y reportaba `clean = true` con exit 0; párrafo propio de «si lo
  corriste, reconstruye tus relaciones con `authz:relations:reconcile`»; la decisión con sus tres partes (la lista
  no es `RESERVED_FACTS_TYPES`, la clasificación no lee nada, `foreign` es campo propio); y el «qué NO se hace y
  por qué» (no se filtra el `Read` —400 medido—, no se toca `relations/` —sin defecto simétrico, medido—, no hay
  `--prune-foreign`, `phases` no crece) más el residuo declarado.
- **`CLAUDE.md`**: corregida la frase publicada del bloque «Todo en un driver o todo en otro» — «la basura de un
  modelo anterior, que se lee y se borra aunque ya no se pueda escribir» ahora dice **de los CUATRO tipos que esta
  pasada gobierna**, y que lo de cualquier otro tipo es AJENO y no se toca ni con `--prune`, con la lista, el
  «no lee nada en runtime», `report.foreign`, la asimetría con `relations/` y el residuo declarado.
- **Docblock de `readEveryTuple`**: leer el store entero no significa que sea suyo; la basura que se borra es la de
  ESTE subsistema; el filtro por tipo es un 400 del servidor; lo ajeno ocupa cota de `maxTuples`.
- **README**, sección del reconcile: párrafo nuevo del store COMPARTIDO (qué gobierna, qué es `foreign`, qué
  imprime el comando, el desglose `relations`/`unknown`, la asimetría medida con `relations/`) y el **residuo
  declarado** con su salida de hoy.
- **`roadmap-2.0.md` · 2.5**: `authz:relations:reconcile --prune-undeclared`, con lo descartado a propósito.

## 3 · Verificación

| comprobación | resultado |
|---|---|
| `npx tsc --noEmit -p tsconfig.json` | ✅ 0 |
| `npm run typecheck` (`tsconfig.test.json`) | ✅ 0 |
| `npm run check:purity` | ✅ verde |
| `npm run build` | ✅ 0 |

Las cuatro corridas, en PRIMER PLANO y en SECUENCIA, todas con `OPENFGA_TEST_URL=http://localhost:8101`
(`:8101` arriba, `/stores` ⇒ 200):

| suite | base (lote A) | ahora | delta |
|---|---|---|---|
| `npm test` (sqlite `:memory:`) | 1364 | **1370** | +6 |
| `npm run test:sqlite-file` | 1390 | **1396** | +6 |
| `npm run test:pg` (`TEST_PG_URL` de `postgres18`) | 1486 | **1492** | +6 |
| `npm run test:mysql` | 1488 | **1494** | +6 |

Las cuatro **PASSED**, 0 fallos, **sin un solo `skip`**. El delta es exactamente los 6 casos nuevos en los cuatro
motores (ninguno gateado por motor; los tres que necesitan el `:8101` corren en las cuatro porque las cuatro
llevan `OPENFGA_TEST_URL`).

Corridas a fichero en el scratchpad de la sesión (`runs-B/`): `rojo-1.txt`, `verde-1.txt`, `mutante-a.txt`,
`mutante-b.txt`, `mutante-c.txt`, `build.txt`, `sqlite.txt`, `sqlitefile.txt`, `pg.txt`, `mysql.txt`.
Los stores del `:8101` quedan limpios: cada caso borra los suyos en el `teardown` del grupo y el guard de
`bin/test.ts` barre lo que sobre («la suite dejó N store(s) sin borrar; barridos»).

## 4 · Lo que NO hice

- **No filtré el `Read` por tipo** (descartado con medida: sin `user`, el filtro por tipo de objeto es un 400 del
  servidor en v1.19.0, y el volcado entero es requisito del algoritmo).
- **No toqué `relations/`** —ni el driver, ni `src/relations/reconcile.ts`—: el defecto simétrico no existe
  (medido por el analista) y ése es el patrón que se copió.
- **No añadí una quinta clave a `phases`** ni cambié ningún tipo publicado de forma incompatible: `foreign` y
  `relationTypes` son opcionales, así que `--to=database` y cualquier driver de terceros siguen compilando y
  `reconcileLines` los trata como cero.
- **No añadí `--prune-foreign` ni `--prune-unknown`**, ni ninguna bandera nueva.
- **No hice commits** ni subí `version` (sigue `2.4.0-alpha.8`); no publiqué nada.
- **No toqué nada del lote A** (banderas, `tests/command_flags.spec.ts`, `tests/scope_outbox.spec.ts`): lo único
  que comparte fichero es el CHANGELOG, donde la sección de A se conserva entera y solo se le añadió media frase
  («…fue a su propio panel, y es el lote de abajo») para encadenar con la de B.
- **No escribí un caso del COMANDO `authz:reconcile` end-to-end contra un store compartido**: la decisión vive en
  `reconcileLines` (pura, B-5) y en el driver (B-1..B-3, contra el `:8101`), y el comando ya imprime todas las
  líneas que la función devuelve. Un caso por el kernel de ace con un store compartido sería más fiel y no lo hice.
- **No reabrí ninguna decisión del dueño** ni cambié el reparto de deberes entre los dos subsistemas.

## 5 · Tensiones con la spec (ninguna me obligó a PARAR)

1. **Dónde vive la lista blanca.** La condición 1 del AUDITOR pedía `RESERVED_FACTS_TYPES` **menos** `group`,
   «importada de `src/identity.ts`, no tres literales nuevos»; la DECISIÓN del dueño (y la spec) piden lo
   contrario: «una constante PROPIA del módulo», porque `RESERVED_FACTS_TYPES` incluye `group` y confundirlas es
   el bug. Manda la decisión: la constante vive en `openfga_driver.ts`. Para no perder lo que el auditor
   protegía —que las dos listas no se separen— **no hay literales nuevos** (se compone con
   `FACTS_SCOPE_TYPE`/`FACTS_ROLE_TYPE`/`FACTS_BINDING_TYPE`/`LEGACY_DENY_BINDING_TYPE`, las constantes que ya
   usaba el módulo) y **B-6 afirma que lo propio ⊆ `RESERVED_FACTS_TYPES`**, así que declarar un tipo nuevo del
   modelo `facts` solo en una de las dos listas pone la suite en rojo.
2. **El analista proponía la constante en `openfga_facts.ts`** (junto a los `FACTS_*_TYPE`). Está en
   `openfga_driver.ts` porque es donde viven `familyOfTuple` (la spec lo nombra por fichero y línea) y
   `LEGACY_DENY_BINDING_TYPE`, que es la mitad obsoleta de la lista. Es una diferencia de ubicación, no de forma.
3. **`familyOfTuple` mira el TIPO antes que la relación**, que es una pizca más de lo que pedía la letra («lo que
   no está en la lista ⇒ `foreign`»). El motivo: la primera rama era `tuple.relation === FACTS_ROOTED_RELATION`
   sin mirar el objeto, y las familias DERIVADAS se borran **sin** `--prune`; una tupla ajena de un modelo de otro
   dueño con esa relación habría entrado por ahí. No es alcanzable declarando relaciones (`rooted` está en
   `RESERVED_SLUGS`), pero era gratis cerrarlo.
4. **`clean` en un store compartido con basura PROPIA de 2.2 sigue siendo `false`** (B-3, y por eso el caso lo
   afirma): lo ajeno sale de `skipped`, pero un `deny_binding` de 2.2 es nuestro, es `extra-fact` y es deriva
   hasta que pase un `--prune`. Es lo correcto y no contradice la spec; lo escribo porque la frase «`clean` vuelve
   a poder ser `true`» vale para el store compartido LIMPIO (B-1), no para uno que además arrastra legado propio.

## 6 · Estado al cerrar

`git status --short` (todo SIN commitear, lote A + lote B juntos, `version` intacta):

```
 M CHANGELOG.md            (lote A + sección nueva de B)
 M CLAUDE.md               (lote A: fila commands/ · lote B: la frase del reconcile)
 M README.md               (lote B)
 M commands/authz_catalog_diff.ts, authz_catalog_prune_orphans.ts, authz_freeze.ts,
   authz_relations_reconcile.ts, authz_scopes_relay.ts, authz_scopes_requeue.ts   (lote A)
 M commands/authz_reconcile.ts        (lote A: banderas · lote B: reconcileLines)
 M src/drivers/openfga_driver.ts      (lote B)
 M src/manager.ts                     (lote B)
 M src/types.ts                       (lote B)
 M tests/scope_outbox.spec.ts         (lote A)
 M tests/reconcile.spec.ts            (lote B)
?? tests/command_flags.spec.ts        (lote A)
```

Stores del `:8101` al terminar: **6**, ninguno de este lote (`relay-auditor-…`, `migration-…`,
`fused-depth-…`, `a6-sweep-…`, `auditor-legacy` — de sesiones anteriores; no los toco porque no son míos).
Los `compartido-…` de estos casos se borran en el `teardown` del grupo.
