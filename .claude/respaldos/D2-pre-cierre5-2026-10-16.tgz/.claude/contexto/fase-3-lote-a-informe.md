# Fase 3 · Lote 3A — informe incremental

Base: `7a28cdf` (Fase 2.5 cerrada; baseline **443** con OpenFGA en `:8101`). Spec: `fase-3-plan.md` §Lote 3A.
Rojo→verde por pieza; sin skip/only; sin commits; sin cambio de respuestas del juez (los casos existentes pasan idénticos; `contract_harness` sin tocar).

## Tabla pieza × rojo × estado × conteos

| Pieza | Rojo anotado (contra `7a28cdf`) | Estado | Conteos |
|---|---|---|---|
| **A1.1** `parseBindingId` desde la derecha (`<scopeKey>\|<uuid>`, scopeKey de 1 o 2 partes); uuid del catálogo = UUID canónico en minúsculas; desaparecen `encodeSlug`/`decodeSlug` | `parseBindingId('app\|<uuid>')` devolvía `{ slug }`; `'app\|editor'` parseaba (hoy `null`); el spec fallaba al cargar por `ids` (test de correlación con literal, corregido a literal puro) | ✅ verde | unitario nuevo (12 aserciones: 1 y 2 partes, 4 partes, sin `\|`, scope inválido, `app` con uuid, uuid vacío/MAYÚSCULAS/sin guiones, ids 1.x con y sin `~`) |
| **A1.2** driver openfga por uuid: `checksFor`/`authorize`/`authorizeMany`/`grant`/`revoke`/`hasRole`/`deny`/`removeDeny`/`listSubjects`/`listBindings`/`deniedScopeKeys`/`listRoles`/`rolesInChain`/`listRoleScopes`/`listScopes`/`listDenies`/`purgeScope`; filtro D5 por `roleByUuid` + nivel | test «ningún id contiene `~`»: los ids llevaban `docs~read`/`org-editor`; L0.16 contaba 2 no parseables (hoy 3: el id 1.x también); D5 con uuid «fantasma» devolvía `[]` en vez de `['editor']` | ✅ verde | 2 tests nuevos (`grep -c '~'` = 0 sobre los ids emitidos por 8 operaciones + guardia de fuente sin `encodeSlug`/`decodeSlug`/`'~'`); 23 tests existentes del spec adaptados a ids por uuid (`seedCatalog`/`ids.role`/`ids.permission`) |
| **A1.3** importador + reconcile: ids por uuid; ids 1.x ⇒ `extra` | contrato (`:8101`): «rol borrado del catálogo» leía `role_binding:app\|editor` (0 tuplas); S7 dry-run daba `written: 1` en vez de `updated: 1`; test nuevo daba `extra: 0` (el importador antiguo consideraba suyos los ids 1.x) | ✅ verde | 1 test nuevo en `contract.spec` (`dry-run` ⇒ `extra: 2`; driver: `authorize`/`hasRole` false, `listRoles`/`listSubjects`/`listDenies` vacíos, `unparseableBindings` = 2; `--prune` ⇒ `deleted: 2` y el hecho reimportado concede) |
| **A2** `database` por uuid: `findRoleOrFail` ⇒ `CatalogRole`; `hasRole` por `(scope, role_uuid)` del memo por nivel; `listRoles`/`rolesInChain` por `role_uuid` → memo; `listSubjects` resuelve el rol antes de consultar | sin rojo propio: por spec «sin cambio de respuestas: contrato idéntico» | ✅ verde (contrato idéntico en 4 motores) | 0 tests nuevos; lecturas de hechos por operación sin cambio (`spies.spec` verde) |
| **A3** `CatalogView.roleByUuid`, `rolesFor(scopeType, ownerKeys)`, `role()` ⇒ `CatalogRole` (`owner: 'global'`), `GLOBAL_OWNER_KEY`; sync estable por `(slug, scopeType)`; `uuid` del spec validado (`assertCatalogUuid`, 422) | `GLOBAL_OWNER_KEY` no exportado (fallo de carga); `roleByUuid` no existía; el sync aceptaba `uuid: 'EDITOR'`/`''`/`42` | ✅ verde | 4 tests nuevos en `catalog_cache.spec` |

**Totales**: 443 → **450** con OpenFGA en `:8101` (SQLite). Ver §Ejecuciones para PG/MySQL/tope 3.

## Desviaciones (con porqué)

1. **Gramática del uuid en el id: UUID canónico, no `[a-z0-9._-]{1,36}`.** El spec solo dice «último componente = uuid». Con la gramática de identidad del consumidor, `app|editor` (id 1.x) parsearía como `{ uuid: 'editor' }` y la promesa «2.x no lee tuplas 1.x» dependería del catálogo, no de la forma. `authz_roles.uuid`/`authz_permissions.uuid` son `table.uuid(...)` (UUID real; PG lo exige), así que exigir 8-4-4-4-12 hex en minúsculas es exacto y hace la distinción estructural.
2. **`syncAuthzCatalog` valida el `uuid` opcional del spec (422 `E_AUTHZ_INVALID_IDENTITY`).** No está en A1–A3, pero A1 lo hace necesario: un uuid en mayúsculas del spec (PG lo normaliza, MySQL/SQLite lo guardan tal cual) produciría un binding id que el propio driver no leería de vuelta. Test con rojo propio en `catalog_cache.spec`.
3. **`CatalogRole.owner` y `GLOBAL_OWNER_KEY` ya en 3A** aunque la columna `owner_scope_key` llega en 3B · B1: `rolesFor(scopeType, ownerKeys)` está en el spec de A3 y sin `owner` no tiene forma; se fija `'global'` para todo rol y se documenta que B1 lo cargará de la columna.
4. **`hasRole` en `database` pasa a leer el memo del catálogo** (antes hacía join por slug sin memo): +1 revalidación de versión por pregunta (no es lectura de hechos; `spies.spec` y el juez no la cuentan). Es el precio de resolver por uuid; A2 lo pide.
5. **Nota final del plan sobre el puerto `resolveChain`**: el fichero `fase-3-plan.md` no contiene tal nota (grep `resolveChain` = 0). No se ha inventado nada: el puerto no se toca.
6. **Sin comando de migración** (decisión del dueño §2): documentado en CHANGELOG/README/driver; la vía es `openfga:import --reconcile --prune`.
7. **`CatalogView.roleSlugs`/`roleLevels` retirados**: tras A1/A2 no tenían ningún uso en `src` ni `tests` (la membresía se filtra por `roleByUuid` + nivel); mantenerlos sería API por slug dentro del motor, justo lo que 3A elimina. Documentado en CHANGELOG.

## Archivos

- `src/drivers/openfga_driver.ts` — A1 (ids, `parseBindingId`, importador, `declaredRole`, `rolesGranting` por uuid).
- `src/drivers/database_driver.ts` — A2.
- `src/catalog_cache.ts` — A3 (`CatalogRole`, `GLOBAL_OWNER_KEY`, `roleByUuid`, `rolesFor`).
- `src/identity.ts` — `assertCatalogUuid`/`isCatalogUuid`; comentarios (el slug ya no viaja en ids FGA; reglas del modelo `facts` intactas).
- `src/catalog.ts` — validación del `uuid` del spec.
- `src/testing/contract.ts` — solo comentario L0.8a (aserciones idénticas).
- `tests/openfga_driver.spec.ts`, `tests/catalog_cache.spec.ts`, `tests/contract.spec.ts` — tests.
- `CHANGELOG.md` (`## [Unreleased] — 2.2.0` · Lot 3A), `README.md` (§ openfga: binding ids), `CLAUDE.md` (mapa + estado 3A).
- Este informe.

## Ejecuciones (cierre, 2026-08-29; `npm run typecheck` limpio; `check:purity` dentro de `npm test`)

| Ejecución | Resultado |
|---|---|
| `npm test` (SQLite) | **357 passed** |
| `OPENFGA_TEST_URL=http://localhost:8101 npm test` | **450 passed** (baseline 443 + 7) |
| `OPENFGA_TEST_URL=:8101 npm run test:pg` (PG 18, `authz_test_c3066f9c`) | **595 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` (MySQL 8.4, `authz_test_4a7ebeae`) | **595 passed** |
| `OPENFGA_TEST_URL=http://localhost:8103 npm test` (`openfga-tiny`, MAX_RESULTS=3) | **450 passed**; contenedor retirado |

Nota: la retirada de `roleSlugs`/`roleLevels` (desviación 7) aterrizó mientras corría PG; MySQL y el tope 3 (y el typecheck) corrieron ya sobre el árbol final. Sin skip/only; sin commits; `contract_harness` sin tocar (ningún caso nuevo del juez).
