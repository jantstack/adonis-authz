# Fase 5 · `http/` — el middleware `resourceAccess` — informe

**Estado:** cerrada. Aditiva (+15 casos por motor). Sin modelo ni driver nuevos: el
middleware COMPONE el `authorize` que ya existe sobre el `{ scope }` que el consumidor
devuelve al cargar el recurso.

## Ficheros

- `src/middleware/resource_access_middleware.ts` — el middleware (nuevo).
- `tests/resource_access_middleware.spec.ts` — el harness `fakeCtx` + 15 casos (nuevo).
- `configure.ts` — registra el named middleware `resourceAccess` junto a `appAccess`.
- `package.json` — subpath `./resource_access_middleware` (gemelo de `./app_access_middleware`).

Patrón de partida: `src/middleware/app_access_middleware.ts` (forma, wiring, prohibición de `role`).

## El ROJO de arranque

Antes de escribir el middleware, el spec entero estaba rojo por el import ausente:

```
Cannot import "../src/middleware/resource_access_middleware.js" ... ERR_MODULE_NOT_FOUND
```

Tras implementarlo: **15 passed (15)**.

## El orden como propiedad de seguridad — rama a rama, con su rojo

Orden implementado: **500 config/role → 401 → 403 gate → 404 contenedor → 404 recurso
(mismo cuerpo) → authorize (false ⇒ 404, mismo cuerpo)**. El 503 nunca se disfraza.

| Rama | Caso | Cómo se prueba el ORDEN / la inversión |
|---|---|---|
| **500 `{ role }`** | `resourceAccess({ role }) es 500 ...` | lanza `E_AUTHZ_ROLE_IS_NOT_ACCESS` con receta `{ permission`, antes de mirar el usuario, aun con `permission` presente |
| **500 config** | `sin permission ...`, `sin param o sin load ...`, (+`resource`) | cada opción obligatoria ausente ⇒ 500 `E_AUTHZ_CONFIG`, sin respuesta HTTP |
| **401** | `sin autenticar responde 401 y no carga el recurso` | `load.calls === 0` y `nextCalls === 0`: el 401 corta ANTES de tocar el recurso |
| **500 holder** | `un holder sin @MorphMap o sin uuid es 500, no un 404` | un subject inválido nunca degrada a 404 |
| **403 gate** | `el gate del consumidor niega ⇒ 403 ...` | `load.calls === 0` y `authorized === 0`: el gate va ANTES de cargar y de autorizar |
| **404 contenedor** | `contenedor ausente ⇒ 404 y NO se carga el recurso` | `load.calls === 0`: el contenedor se comprueba ANTES del recurso (el orden observable) |
| **404 recurso = contenedor** | `recurso ausente (load ⇒ null) es 404 con el MISMO cuerpo ...` | `deepEqual(body_recurso, body_contenedor)`: indistinguibles |
| **authorize false ⇒ 404 (no 403)** | `authorize false es 404 (no 403) ... mismo cuerpo` | **inversión probada:** cambiar el `notFound()` final por `forbidden()` pone el caso rojo con `AssertionError: expected 403 to equal 404`; y el cuerpo es idéntico al del recurso ausente |
| **deny ⇒ 404** | `un deny explícito sobre el recurso concedido es 404 (no 403)` | el deny gana (invariante 2) y sale como 404, no 403 |

Además del 404/403, la inversión **contenedor↔recurso** es observable por `load.calls`: si se
comprobara el recurso antes del contenedor, `load` se llamaría con el contenedor ausente y el
caso «contenedor ausente … NO se carga el recurso» se pondría rojo.

## El espía de «un solo `authorize`»

`camino feliz: next UNA vez, el recurso propagado al controlador, un solo authorize` envuelve
`authorization.authorize` con un contador (`authorized`) y afirma `authorized === 1`,
`nextCalls === 1`, `load.calls === 1`. El middleware llama a `authorize` UNA vez y no
re-autoriza. La propagación al controlador se comprueba con
`deepEqual(ctx.document, { id: 'r1', scope: APP_SCOPE })` — el recurso cargado (con su scope)
llega bajo `ctx[options.resource]`, sin recargarlo.

## El 503 NUNCA disfrazado

Dos casos, porque hay dos fuentes de caída en el camino:

- `backend caído en authorize ⇒ 503 propagado, jamás un 404`: se monkeypatch-ea `authorize`
  para lanzar `AuthorizationBackendError`; el middleware lo propaga tal cual (503,
  `E_AUTHZ_BACKEND_UNAVAILABLE`) y **no** hay ninguna respuesta HTTP (`responses` vacío).
- `un load que LANZA (no pudo comprobar) propaga, no se convierte en 404`: distingue
  «no existe» (`load ⇒ null ⇒ 404`) de «no pude comprobar» (`load` lanza ⇒ 503). El
  middleware NO envuelve `gate`/`load`/`authorize` en try/catch a propósito.

## Decisiones tomadas donde la spec era ambigua (la más segura, la que menos filtra)

1. **`readPermission` vs `permission`.** Los métodos SEGUROS (GET/HEAD) usan `readPermission`
   **si se declara**; en cualquier otro caso (POST/PUT/PATCH/DELETE, o un GET sin
   `readPermission`) se exige `permission`. Una lectura **nunca es gratis**: sin
   `readPermission` cae en `permission`. Casos: `un GET usa readPermission; un POST usa
   permission` (espía qué permiso recibió `authorize`: `['docs:read','docs:write']`) y `sin
   readPermission, un GET cae en permission`.
2. **`gate` es opcional.** Si se declara y devuelve `false` ⇒ 403; si se omite, no hay
   pre-check adicional (la seguridad la da igualmente `authorize`). No inventé una interfaz de
   policy: `gate(ctx) => boolean` a secas, con acceso al `ctx` entero.
3. **`containerParam` sin segundo hook de carga.** La spec lista solo `load` y `gate` como
   hooks del consumidor. El paso «404 contenedor» comprueba la PRESENCIA del param de ruta del
   contenedor (`ctx.params[containerParam]`); un contenedor ausente ⇒ 404 con el MISMO cuerpo
   que un recurso ausente. La PERTENENCIA real del recurso al contenedor la comprueba `load`
   (que ve `ctx.params`): devolver `null` allí es el mismo 404, así que «no existe» y «no está
   en este contenedor» quedan indistinguibles. No se añadió un `loadContainer` — una interfaz
   simple basta.
4. **Propagación al controlador.** El recurso cargado se estampa en `ctx[options.resource]`
   (p. ej. `resource: 'document'` ⇒ `ctx.document`), de modo que dos `resourceAccess` anidados
   no se pisan y el controlador no recarga.

## Qué se probó con doble y qué tocó el `:8101`

- **Todo el orden HTTP** (401/403/404/500, mismo cuerpo, propagación, `next`) se prueba con el
  doble `fakeCtx` — registra el orden de respuestas, un `next` con contador y lo propagado —,
  sin backend.
- **`gate`/`load`** son dobles inyectados en las opciones (funciones del test).
- **`authorize`** se ejerce contra el manager REAL sobre el driver `database` en memoria (mismo
  patrón que `middleware.spec.ts`): catálogo sembrado con `syncAuthzCatalog`, `grant`/`deny`
  reales, para el camino feliz, el deny y el espía de permiso.
- El **`:8101` no interviene**: el middleware es composición sobre `authorize`, no un driver, así
  que no añade casos al contrato. La suite completa se corrió igualmente con
  `OPENFGA_TEST_URL=http://localhost:8101` (servidor vivo, `/healthz` 200) en los cuatro motores.

## Cifras (aditivo, +15 por motor)

| Suite | Base | Ahora |
|---|---|---|
| SQLite `:memory:` (+openfga) | 979 | **994** |
| SQLite fichero (+openfga) | 984 | **999** |
| PostgreSQL 18 (+openfga) | 1078 | **1093** |
| MySQL 8.4 (+openfga) | 1078 | **1093** |

`tsc --noEmit -p tsconfig.json`, `npm run typecheck`, `npm run check:purity`
(«el paquete no depende de ningún consumidor…») y `npm run build` pasan.

## Lo que NO hice

- **No refactoricé `appAccess`** para compartir la extracción holder→subject: dupliqué los ~15
  líneas (con comentario que lo señala como gemelo) para dejar la Fase 4 y `appAccess` byte-a-byte
  intactos. Es la opción conservadora; si el dueño prefiere un helper compartido, es un cambio
  aparte.
- **No añadí un hook `loadContainer`** ni una interfaz de policy para `gate` (decisiones 2 y 3):
  la spec pide la superficie mínima.
- **No toqué `contract.ts` ni la suite de contrato**: `resourceAccess` no es un driver.
- **No añadí casos al `contract_harness` counting** ni a los stubs de config (el middleware se
  registra por `configure.ts`, no por un stub de config; `configure.spec` sigue verde porque
  solo renderiza los stubs de config, que no cambian).
- **No hice commit** (lo hace el dueño).

## Nota para el revisor sobre el harness

El helper `loaderAt()` usa `Object.defineProperty(load, 'calls', { get })` y NO
`Object.assign` — `Object.assign` INVOCA el getter en la fuente y lo copia como valor estático,
lo que dejaba `load.calls` congelado en 0 y ocultaba si `load` se llamó (fue el rojo que se cazó
durante el desarrollo). El contador de `next` en `fakeCtx` es un getter sobre el objeto devuelto
y se lee directamente (`h.nextCalls`), nunca por spread (que lo aplanaría igual).
