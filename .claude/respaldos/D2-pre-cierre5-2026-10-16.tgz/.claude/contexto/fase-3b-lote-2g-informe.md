# Fase 3b · lote 2g — R1: la paridad de NIVEL

Encargo: `decisiones-dueno-2026-08-28.md` §«Decisión del 2026-08-30 (2)», apartado **R1 · (c2) no
conoce el NIVEL del rol ⇒ SE ARREGLA**. **R2 no se toca** (se declara en otro lote) y R3 se cerró
en el 2f. Rama `v2/fase-3b`, sobre `bd28e1b`, árbol principal, sin commits.

---

## 1. El caso, y la salida ROJA literal

El caso de aceptación es el del juez, y ya existía: **`paridad entre drivers (3D · N1)`**. Partida
medida antes de tocar nada (`AUTHZ_CONTRACT_FACTS=1`, servidor real en `:8101`):

```
❯ authorization contract [openfga facts · 2.2] / paridad entre drivers (3D · N1): una asignación
  cuyo rol está declarado para OTRO nivel no cuenta en ninguno de los dos — ni concede, ni es
  membresía, ni se enumera — y vuelve a contar en cuanto el nivel del rol coincide otra vez
ℹ AssertionError: el rol ya no existe en ese nivel: expected true to be false

 [41m❯ 2575 ┃  assert.isFalse(await driver.authorize(alice, 'docs:write', unitA1), 'el rol ya no existe en ese nivel')
```

Falla **por la razón correcta**: la línea que revienta es la PRIMERA después de `retypeRole(lead,
'organization')`, es decir `authorize` sigue concediendo en un scope `unit` un rol que el catálogo
ya solo declara para `organization`. Las aserciones de membresía y enumeración que vienen detrás
(`hasRole`, `listRoles`, `listSubjects`, `listScopes`, `listRoleScopes`, el `grant` 422) **no
fallaban**: esas ya filtran por catálogo en los dos drivers. Lo único divergente era `authorize`,
que en `facts` es un `Check` contra un modelo que no lleva el `scope_type` del rol.

Además se añadieron **tres casos de driver contra el servidor real** (`tests/openfga_facts.spec.ts`,
grupo `facts · 3b-2g · R1 — el barrido por NIVEL`), y se comprobó que están rojos por la razón
correcta con un **mutante** (la llamada al barrido comentada dentro de `projectCatalogRole`):

```
❯ facts · 3b-2g · R1 / PARIDAD: cambiar el NIVEL de un rol local retira lo concedido en los DOS drivers…
ℹ AssertionError: facts: tampoco (si concede, es el fail-open R1 del lote 2e): expected true to be false
❯ facts · 3b-2g · R1 / PARIDAD con un rol GLOBAL: no hace falta cadena para decidir el nivel…
ℹ AssertionError: facts: el rol ya no se declara para unit: expected true to be false
❯ facts · 3b-2g · R1 / y el barrido del owner no lo resucita: tras un `moved` dentro del owner…
ℹ AssertionError: precondición: el barrido por NIVEL quitó la arista: expected true to be false
Tests  3 failed (3)
```

Restaurada la llamada: `Tests  3 passed (3)`. Los tres son doble driver (`database` + `facts`) sobre
el MISMO catálogo y el MISMO árbol: lo que se compara es la respuesta de `authorize`, que es el
criterio de aceptación firmado (la igualdad, no el detalle).

---

## 2. El código que lo puso verde

Mismo mecanismo aprobado el 30-08 para el owner: **barrer aristas `scope#binding`**. Se EXTENDIÓ el
del 2e, no se escribió uno paralelo.

**a) Una sola regla, en un solo sitio.** El barrido del 2e decidía con `chainKeys.includes(role.owner)`
—solo el owner—. Ahora los dos barridos clasifican la arista con **`declaredRoleAt`**, que es la
función que `database` evalúa en cada pregunta (nivel declarado **y** owner en la cadena):

```ts
private classifyBindingEdge(catalog, binding, chainKeys, writes, deletes): void {
  const edge = factsScopeBindingTuple(scopeKey(binding.scope), binding.uuid)
  if (declaredRoleAt(catalog, binding.uuid, binding.scope.type, chainKeys)) writes.push(edge)
  else deletes.push(edge)
}
```

Consecuencia que vale por sí sola, y que tiene caso (`el barrido del owner no lo resucita`): con la
regla partida, un `moved` DENTRO del owner reescribía la arista que el nivel acababa de prohibir.
Con la regla única no puede.

**b) El disparador del lado del catálogo: `projectCatalogRole`.** El nivel de un rol no cambia por
la API de delegación (3E · P1, a propósito): la única vía es una escritura de catálogo. Se barre
desde `projectCatalogRole`, que ya es el hook de «una escritura de catálogo cambió este rol» —el
manager lo llama tras `defineScopedRole`/`updateScopedRole` (3b-2e · E4)—, y que a partir de ahora
rehace **las dos proyecciones del rol**: lo que concede (`permits_<P>`) y **dónde es visible**
(`scope#binding`, `sweepRoleVisibility`).

```ts
async projectCatalogRole(roleUuid: string): Promise<void> {
  if (this.hierarchy !== 'facts') return
  assertCatalogUuid('rol', roleUuid)
  await this.sweepRoleVisibility(roleUuid)   // ← 3b-2g · R1
  …
}
```

`sweepRoleVisibility` lee los bindings de ESE rol (`role_binding:…#role@role:<uuid>`, filtrando por
`user`, que es lo que el servidor real exige), resuelve la cadena del STORE de cada scope distinto
—**solo si el rol es local**: la visibilidad de un global no depende del árbol— y aplica el estado
que debe quedar con `Ignore` en las dos direcciones (invariante 6). Un rol que el catálogo ya no
declara no se barre: sus hechos son de `purgeRole` y de `authz:reconcile`.

**c) El escritor «a mano» del juez rehace la proyección, como los otros dos.** `retypeRole` del
harness (`src/testing/contract.ts`) pasa a llamar a `driver.projectCatalogRole?.()`, exactamente la
regla que el lote 2e ya fijó para `localRole`, `linkByHand` y `withoutLink`: *quien escribe `authz_*`
por fuera del sync rehace la proyección derivada del driver, igual que ya tenía que invalidar el
memo*. En `database` `projectCatalogRole` no existe y es un no-op —la regla se evalúa en cada
pregunta—, así que la paridad que mide el caso sigue siendo paridad de RESPUESTA, no de mecanismo.
Esto se dice aquí porque es la parte honesta del arreglo: **en `facts` la visibilidad está
materializada**, y una escritura de catálogo que no avise deja la arista donde estaba, igual que
antes de este lote dejaba las tuplas `permits_<P>`.

**d) La consecuencia conceptual, documentada y no escondida.** La arista `scope#binding` pasa a
significar **«el rol es visible aquí»**, no «esta asignación existe». El hecho de la asignación es
el `assignee`, que ningún barrido toca — por eso `hasRole`/`listRoles`/`listSubjects` siguen
enumerando por `assignee` + catálogo y no cambian ni una respuesta. Escrito en:

- `CLAUDE.md`, invariante 18 (párrafo nuevo tras el barrido del owner);
- `README.md`, §*Roles global or local to a scope* (con esas palabras: *"the role is visible here",
  not "this assignment exists"*);
- `CHANGELOG.md`, entrada nueva **Lot 3b-2g**;
- y en el TSDoc de `factsScopeBindingTuple` (`src/drivers/openfga_facts.ts`), que es donde se
  construye la arista.

Ficheros tocados: `src/drivers/openfga_driver.ts`, `src/drivers/openfga_facts.ts`,
`src/testing/contract.ts`, `tests/openfga_facts.spec.ts`, `CLAUDE.md`, `README.md`, `CHANGELOG.md`.

---

## 3. Los rojos del juez, antes y después (con nombre)

`AUTHZ_CONTRACT_FACTS=1 OPENFGA_TEST_URL=http://localhost:8101 …`

| Harness | Antes | Después |
|---|---|---|
| SQLite (`npm test`) | 748 passed, **3 failed** (751) | 752 passed, **2 failed** (754) |
| PostgreSQL (`test:pg`, árbol SQL) | 921 passed, **4 failed** (925) | 925 passed, **3 failed** (928) |

**Uno menos en cada uno, y es el de R1.** Los que quedan, por nombre:

- **SQLite (2)**
  1. `authorizeMany: … un scope que lanza ⇒ lanza entero` — *R2 (b)*: con `singleCheckAuthorize` la
     decisión no pasa por el árbol, así que la caída del resolutor no se observa desde `authorize`.
  2. `scopes.detached purga los HECHOS del scope y SOLO los hechos … los roles locales … DORMIDOS` —
     *R2 (a)*: `el nieto pierde su cadena y con ella todo: expected true to be false`.
- **PostgreSQL (3)**: las dos anteriores, más
  3. `un alias del uuid del scope … jamás evade un deny` — *R2 (c)*: `sin guiones: lo concedido sigue
     concedido: expected false to be true` (fail-**closed**, pero rompe la igualdad).

Los tres son **R2 y siguen rojos, que es lo correcto** por la decisión firmada. **No he tocado R2**.

**Aviso de arrastre (lo que el encargo pedía que dijera si aparecía):** R1 se cerró **sin** meter
`resolveChain` en ningún camino, así que no arrastra R2 ni lo repara por la puerta de atrás. Lo que
sí hay es una **dependencia declarada**: `sweepRoleVisibility` resuelve la cadena con `storeChain`
—el árbol del STORE, igual que el barrido del 2e—, de modo que hereda la propiedad (a) de R2 (el
árbol del store decide) y el fail-open temporal del lag del relay. Es la misma herencia que el 2e ya
aceptó y documentó, no una nueva.

---

## 4. Coste en requests (medido contra el servidor real de `:8101`)

Contando las llamadas del cliente FGA envolviendo `read`/`write`/`check` de un driver real:

| Operación | read | write |
|---|---|---|
| `scopes.moved`, catálogo **sin roles locales** | 1 | 1 |
| `scopes.moved`, con 1 rol local (subárbol de 1 nodo) | 6 | 2 |
| `projectCatalogRole` de un rol **sin bindings** (todo `defineScopedRole`) | 2 | 1 |
| `projectCatalogRole` de un rol **global** con 1 binding | 2 | 1 |
| `projectCatalogRole` de un rol **local** con 1 binding (cadena de 3) | 5 | 1 |

Lecturas:

- **La propiedad del 2e se conserva exactamente**: `moved` sin roles locales sigue costando el
  `Read` + `Write` del cruce 8 — **cero requests de barrido** —, y las cuentas de requests del 2b
  siguen exactas. El barrido del owner no cambió ni una llamada: solo cambió el predicado en
  memoria (`chainKeys.includes(owner)` → `declaredRoleAt`).
- Lo que cuesta el lote es **sobre `projectCatalogRole`**, que es camino de escritura de catálogo,
  nunca el camino caliente: **+1 `Read`** (los bindings del rol) siempre, y **solo si el rol es
  local y tiene bindings**, la cadena del store de cada scope distinto (3 lecturas en el ejemplo:
  unit → org → app → ∅) más **1 `Write`** por lote de 100. Un rol sin bindings —el caso de todo
  `defineScopedRole`— no escribe nada por este barrido. Un rol global no paga cadena.
- `authorize`, `hasRole` y los `list*` no pagan **nada**: siguen igual.

Nota de superficie de error: `sweepRoleVisibility` puede propagar lo que ya propagaba el barrido del
2e cuando el árbol del store está corrupto (`E_AUTHZ_SCOPE_TREE_DRIFT` 500 con dos padres, ciclo,
o profundidad), ahora también desde `defineScopedRole`/`updateScopedRole` de un rol local **con
bindings**. Es fail-closed y ruidoso, con `status` + `code`, como el resto.

---

## 5. Verificación

Las cuatro cifras (todo verde, sin `skip`, servidor real en `:8101`):

| Suite | Partida | Ahora |
|---|---|---|
| `npm test` (SQLite en memoria) | 664 | **667 passed (667)** |
| `npm run test:sqlite-file` | 666 | **669 passed (669)** |
| `npm run test:pg` | 838 | **841 passed (841)** |
| `npm run test:mysql` | 838 | **841 passed (841)** |

El **+3** en las cuatro son exactamente los tres casos nuevos del grupo `facts · 3b-2g · R1` (no
hay casos borrados ni renombrados).

```
npx tsc --noEmit -p tsconfig.json      → sin salida (OK)
npm run typecheck                      → OK
npm run check:purity                   → ✔ purity: el paquete no depende de ningún proyecto consumidor…
npm run build                          → OK (check:purity + typecheck + tsc + copy:stubs)
```

Guardia de fuente actualizada (`facts · A6`): `FACTS_ROLE_TYPE}:` pasa de 4 a **5** sitios —
`projectCatalog`, `projectCatalogRole`, los **dos** barridos de la arista y `purgeRole` —, y ninguno
pregunta qué permisos tiene un rol, que es lo que A6 protege. El comentario del caso lo enumera.

**Stores del `:8101`**: cero huérfanos de este lote. Los grupos nuevos borran su store en el
`teardown` (patrón del 2e) y se comprobó por API: no queda ningún `facts-level-*`, `facts-sweep-*`
ni el `cost-*` temporal que se usó para medir requests (el fichero de medición se borró; no está en
el árbol). Los 58 stores que hay en el servidor son de sesiones anteriores (`audit-*`, `tester-*`,
`atk-*`… del 26 y el 28 de agosto), ajenos a este lote.
