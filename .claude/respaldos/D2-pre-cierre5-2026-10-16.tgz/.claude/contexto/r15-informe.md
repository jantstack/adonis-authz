# R-15 · caducidad de la tupla de relación — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `242d846` (= `2.4.0-alpha.1` publicado). Árbol principal, SIN commits (los hace el
> dueño). Alcance: el encargo del dueño tras la verificación de COGNITIV (7/9 ✅; su requisito #5 era
> la caducidad en la tupla de relación, diferida a 2.6 sobre una suposición falsa para el cliente).
> Todo es ADITIVO sobre lo publicado; la superficie nueva se declara y se juzga en el contrato.
> Plan de referencia: `fase-4-juez.md` §4 (c) («renovar = delete+insert» observable) y §7-4-6 (R-15),
> informes `fase-4-lote-3-informe.md` (driver `database`) y `fase-4-lote-4-informe.md` (driver `openfga`).

## Qué se implementó (por pieza, rojo→verde, con la salida roja literal)

Corridas a fichero en `scratchpad/r15/*.log`. Un caso que ya pasaba se anclo con un MUTANTE (visto rojo) y
el código se restauró (`diff` limpio contra la copia de seguridad, comprobado con `grep`).

### P1 · `expires_at` en `authz_relations` (stub + espejo)

Caso: `tests/migration_stub.spec.ts` · «R-15: authz_relations lleva expires_at DATETIME(3) nullable en el
stub Y en el espejo». Rojo antes de tocar el esquema:
```
❯ la migración publicada y el esquema de la suite coinciden / R-15: authz_relations lleva expires_at …
ℹ AssertionError: el stub declara authz_relations.expires_at: expected [ 'uuid', 'partition_key', …(8) ] to include 'expires_at'
Tests  6 passed, 1 failed (7)
```
Verde con `table.datetime('expires_at', { precision: 3 }).nullable()` en `stubs/migration.stub` y en
`tests/helpers/schema.ts` (`createAuthzRelationsTable`) — el MISMO tipo que `authz_assignments.expires_at`
(2.5 · J3: `DATETIME(3)` en MySQL, `timestamptz(3)` en PG) y el mismo codec `sqlExpiryCodec`. K11 (stub
ejecutado en una base de trabajo = espejo, columna a columna) sigue verde en los tres motores; el caso nuevo
además afirma el tipo que dice el motor (`datetime(3)` / `timestamp with time zone` precisión 3).

**Receta `ALTER TABLE` (aditiva, para quien ya migró la alpha.1)** — en el CHANGELOG y en el README:
```ts
this.schema.alterTable('authz_relations', (table) => {
  table.datetime('expires_at', { precision: 3 }).nullable()
})
```
```sql
ALTER TABLE authz_relations ADD COLUMN expires_at timestamptz(3) NULL;   -- PostgreSQL
ALTER TABLE authz_relations ADD COLUMN expires_at datetime(3) NULL;      -- MySQL
ALTER TABLE authz_relations ADD COLUMN expires_at datetime NULL;         -- SQLite
```
El store de `openfga` no necesita migración de tuplas: se republica el modelo fusionado (las tuplas
existentes no llevan condición y siguen concediendo sin caducidad).

### P2 · el puerto `RelationsDriver` + el manager (invariante 10, caducidad estricta, reloj)

`src/types.ts`: `RelationWriteOptions.expiresAt?: Date | null` (tres estados), `RelationRef.expiresAt`
(viaja en `assertWrite`/`onRelationWrite` solo en `relate`), `RelationTuple.expiresAt` (lo que enumera
`enumerateRelations`, sin filtrar), capacidad `injectableClock` y `withClock?(now)` opcional.
`src/relations/manager.ts`: `assertExpiresAt` ANTES del driver (422 `E_AUTHZ_INVALID_IDENTITY`), `expiresAt`
en la referencia de auditoría, y opción `clock` que se aplica con `withClock` (500 `E_AUTHZ_CONFIG` si el
driver no lo trae, como el manager de roles). `providers/authz_provider.ts` pasa `config.clock` — el MISMO
reloj que roles. No hay caso nuevo propio del manager: lo juzga el runner (P3, «expiresAt inválido ⇒ 422 sin
tocar el driver», con el espía de escrituras a 0).

### P3 · el contrato (`runRelationsDriverContract`) y el doble en memoria

Casos nuevos en `src/testing/relations_contract.ts`:
- **Núcleo (sin reloj)** · «R-15 · relate con expiresAt pasado NO concede (check/listObjects/listSubjects);
  futuro sí; expiresAt inválido ⇒ 422 sin tocar el driver».
- **Par `injectableClock`** (como en roles, 2.5 · J1): `whenTrue` · tres estados con el reloj inyectado +
  caducidad EXACTA T−1 ms / T / T+1 ms (`T` con milisegundos) en `check`, `listObjects`, `listSubjects`, a
  través de un userset (la MEMBRESÍA caduca) y `membersOf` si `membersOfNative`; renovación (`Date`
  posterior), revivir (omitido sobre caducada ⇒ sin caducidad, vigente en 2099), preservar (omitido sobre
  vigente NO la hace permanente) y quitar (`null`). `whenFalse` · los tres estados en tiempo real (1,5 s) y
  el driver NO trae `withClock` (declara lo observable).
- El doble (`makeRelationsDriver`) lleva `expiresAt` por tupla, filtra lo caducado en lecturas, NO en
  `enumerateRelations`, y trae `withClock` solo con la capacidad (vista sobre las MISMAS tuplas).

Rojo literal contra el driver `database` real (SQLite), antes de tocarlo:
```
❯ relations contract [database (sqlite)] / R-15 · relate con expiresAt pasado NO concede …
ℹ AssertionError: caducada ⇒ check false: expected true to be false
❯ relations contract [database (sqlite)] / injectableClock:true · expiresAt en tres estados con el reloj inyectado …
ℹ AssertionError: injectableClock: true exige withClock en el puerto: expected undefined to be a function
Tests  29 passed, 2 failed (31)
```
Y el mismo rojo contra `openfga` (`:8101`) antes de tocarlo: `Tests  21 passed, 2 failed (23)` con las
dos mismas aserciones.

### P4a · driver `database` (`src/drivers/database_relations_driver.ts`)

- `relate(…, { expiresAt })`: dentro de la transacción interna lee la fila exacta (con
  `codec.select('expires_at')`), resuelve los tres estados con `resolveGrantExpiry(previous, requested, now)`,
  misma caducidad ⇒ no-op (`sameInstant`), distinta ⇒ **DELETE + INSERT** (nunca UPDATE), inserta con
  `codec.toDb(expiresAt)`. `created_at` pasa a sellarse con `systemClock()` (K5: sello, no decisión — con el
  reloj inyectado en 2099 un `TIMESTAMP` de MySQL reventaría).
- Lecturas con caducidad ESTRICTA y UN `now` por operación (K9): `#activeSql` =
  `(r.expires_at IS NULL OR r.expires_at > ?)` con `codec.bind(now)`; aplicado en la CTE `principal`
  (solo membresías vigentes suben por la recursión), en el `SELECT` final de `check`/`listObjects`, en
  `listSubjects` (query builder, `#whereActive`) y en los cuatro tramos de `membersOf`.
- `enumerateRelations` selecciona `expires_at` por el codec y emite `expiresAt` **sin filtrar**.
- `withClock(now)`: instancia nueva con la misma conexión/config/deadline (el driver no tiene estado; los
  campos `#privados` no sobreviven a `Object.create(this)`, de ahí la instancia).
- Capacidad `injectableClock: true`.

Verde en **SQLite, PG 18 y MySQL 8.4** (`relations_database.spec.ts`: 32/32 en cada motor), incluidos
T−1/T/T+1 al milisegundo en MySQL (`DATETIME(3)` + codec UTC).

### P4b · driver `openfga` (`src/drivers/openfga_relations_driver.ts`) + modelo fusionado

- Modelo (`src/drivers/openfga_facts.ts`, `factsRelationTypeDefinitions`): cada sujeto admitido de una
  relación —los holders Y el userset `group#member`— va ADEMÁS `with not_expired`
  (`FACTS_EXPIRY_CONDITION`, la misma condición que `role_binding#assignee`). El literal `EXPECTED_FUSED` de
  `tests/openfga_facts.spec.ts` se actualizó (rojo por literal distinto → verde); la ADITIVIDAD del modelo
  `facts`-solo sigue byte a byte; la profundidad `can_<P>` (22, 500 reps) sigue verde sobre el fusionado.
- `relate`: **un `Read` por clave exacta** (`#readTuple`) + los tres estados: ausente ⇒ un `Write` (con
  `condition: { name: 'not_expired', context: { valid_until } }` si caduca); presente con la misma
  caducidad ⇒ no-op; presente con otra ⇒ `delete` + `write` en DOS llamadas (FGA no admite reescribir la
  condición de una tupla existente; un `Ignore` se quedaría la caducidad vieja en silencio). Entre las dos
  llamadas hay un instante fail-closed (la misma ventana que el `grant` de roles).
- `check` y `listObjects` llevan `context: { current_time }` del reloj del driver; `listSubjects` filtra en
  cliente `valid_until <= now` (estricta); `#readAll` conserva `validUntil`; `purge*` borra TODO (caducadas
  incluidas); `enumerateRelations` emite `expiresAt` sin filtrar.
- `withClock(now)`: instancia nueva a la que se le presta el MISMO `client` (el espía de «1 Check» sigue
  viendo `client.check`). Capacidad `injectableClock: true`.

Verde contra el `:8101`: `relations_openfga.spec.ts` + `openfga_facts.spec.ts` = 142/142.

### P5 · «renovar = delete+insert» (decisión (c) del juez, observable)

`tests/relations_database.spec.ts` · grupo «R-15 · renovar la caducidad es delete+insert
(INSERT/DELETE-ONLY)». Lo observable es el **`uuid` (PK) de la fila**: renovar con otra caducidad deja UNA
fila con OTRO uuid y la caducidad nueva; la misma caducidad u omitida deja el MISMO uuid (no reescribe);
`null` también es delete+insert. Verde en los tres motores. **Mutante** (UPDATE de `expires_at` en vez de
delete+insert), salida roja literal:
```
❯ database relations — R-15 · renovar la caducidad es delete+insert (INSERT/DELETE-ONLY) / renovar cambia el uuid de la fila …
ℹ AssertionError: renovar es delete+insert: la fila es NUEVA (no un UPDATE): expected '01a05ea7-…' to not equal '01a05ea7-…'
Tests  31 passed, 1 failed (32)
```
Restaurado.

### P6 · `enumerateRelations`/`reconcile` llevan la caducidad (la lección de la 3b)

`src/relations/reconcile.ts`: opción `now` (default `systemClock`); una tupla del origen caducada al
instante de la pasada se cuenta en **`skipped.expired`** y no respalda nada (con `--prune` lo que sobra en
el destino se borra); una vigente se escribe con `{ expiresAt }` EXPLÍCITO (`Date` fija, `null` quita — un
`relate` sin opciones PRESERVARÍA la del destino); misma clave con OTRA caducidad ⇒ se reescribe y se cuenta
en **`updated`**. `commands/authz_relations_reconcile.ts`: `actualizadas` y `caducadas omitidas` en el resumen;
`updated` es deriva en `--dry-run`, `skipped.expired` se dice y NO lo es (como `expired` en roles, 3b-8 · B2).
Contrato publicado (`src/testing/relations_reconcile_contract.ts`): un caso NUEVO por dirección · «R-15 · la
caducidad VIAJA: la vigente llega con su instante (y una distinta en el destino se reescribe, updated); la
caducada LLEGA enumerada y se cuenta en skipped.expired, no se escribe» — afirma que el origen la ENUMERA
(con su `expiresAt`), `skipped.expired === 1`, `updated === 1` (el destino la tenía sin caducidad),
`written === 6`, la caducada no está en el destino ni concede, la vigente llegó `sameInstant` al
milisegundo, el censo, y la idempotencia de la segunda pasada. Verde doble↔doble y **database↔openfga**
contra el `:8101` en las dos direcciones.

Dos mutantes, rojos y restaurados:
```
(a) reconcile escribe `to.relate(...)` SIN expiresAt
❯ relations reconcile [doble en memoria] / A→B · R-15 · la caducidad VIAJA …
ℹ AssertionError: la caducidad viajó al milisegundo (destino undefined, origen 2027-09-01T20:33:37.276Z): expected false to be true
Tests  16 passed, 2 failed (18)
(b) el driver `database` FILTRA la caducada en enumerateRelations
❯ relations reconcile [database ↔ openfga] / A→B · R-15 · la caducidad VIAJA …
ℹ AssertionError: la tupla CADUCADA tiene que llegar enumerada del origen: expected undefined to not equal undefined
Tests  28 passed, 1 failed (29)
```

### P7 · paridad `database` ↔ `openfga` con caducidad (misma pregunta ⇒ misma respuesta)

`tests/relations_bridge.spec.ts` · «R-15 · caducidad con el MISMO reloj: T−1 ms / T / T+1 ms, renovación y
membresía caducada — la misma respuesta en los dos»: los dos drivers con el MISMO reloj inyectado, se
comparan `check`, `listObjects`, `listSubjects` y el check a través de un userset cuya membresía caduca, en
T−1/T/T+1, tras revivir (2099) y la enumeración (`expiresAt` igual en los dos). Verde. **Mutante** (`database`
ignora la caducidad, `#activeSql` ⇒ `1 = 1`), rojo literal:
```
❯ relaciones · 4-4 — paridad database ↔ openfga … / R-15 · caducidad con el MISMO reloj …
ℹ AssertionError: T: database y openfga divergen: expected { check: true, …(3) } to deeply equal { check: false, listObjects: [], …(2) }
Tests  9 passed, 1 failed (10)
```
Restaurado.

### P8 · el conteo del juez (`tests/relations_harness.spec.ts`)

- Runner de relaciones: **19** casos por harness (era 17: +R-15 núcleo, +la cara `injectableClock`), 7
  capacidades cubiertas, FULL y MÍNIMO con el mismo total y caras distintas; caso nuevo que fija que
  `injectableClock` es un par y que el núcleo lleva R-15 en las dos caras.
- Contrato de reconcile: **11** (era 9: 5 × 2 direcciones + 1).
- Conteo literal del juez: `BREAKDOWN` suma **41 = JUEZ_TARGET** (soloDriver 2→3 con «renovar», anexo 1→2
  con R-15), `DEFERRED = {}` (nada diferido), y `BEYOND_JUEZ = 3` declarado aparte (las dos caras del reloj y
  la caducidad a través de reconcile, que el juez no contó porque R-15 era condicional).

## Cuánto se movió el techo de bytes del modelo fusionado (medido con `factsModelBytes`, generador viejo vs nuevo)

Fixture: 3 holders (`user`/`admin`/`integration`), permisos realistas `recursoN:leer` (557 B cada uno),
tipos `document` de 3 relaciones (`owner ⊆ editor ⊆ viewer`).

| pieza | antes | ahora | delta |
|---|---|---|---|
| `group` (1 relación) | 86 B | 191 B | +105 B (0,15 → 0,34 permisos) |
| `document` (3 relaciones) | 270 B | 579 B | +309 B (0,49 → 1,04 permisos) |
| por relación declarada | 90 B | 193 B | +103 B = `(holders + 1) × (tipo + 'not_expired' + marco)` |
| tipos `document` que caben junto a 447 permisos realistas | 52 | 24 | −28 |
| permisos realistas que caben con 1 `document` | 472 | 471 | −1 |

El gate (`assertFactsModelPublishable`) sigue midiendo el fusionado con delta 0 respecto al servidor (el
caso A3 de calibración sigue verde); los casos del gate de 4-1 son auto-calibrados y no fijan cifras. La
cifra publicada en el README/CHANGELOG (0,46 por tipo, ≈0,1 `group`, «~20 tipos») se reescribió con estas.

## Las 4 cifras (todas verdes, corridas a fichero, `OPENFGA_TEST_URL=:8101`)

| modo | base (alpha.1) | ahora | delta |
|---|---|---|---|
| `npm test` (SQLite) | 994 | **1010** | +16 |
| `test:sqlite-file` | 999 | **1015** | +16 |
| `test:pg` | 1093 | **1109** | +16 |
| `test:mysql` | 1093 | **1109** | +16 |

+16 = migration_stub (1) + dobles (2 × 2) + database (2 contrato + 1 renovar) + openfga (2) + puente (1) +
reconcile (2 doble↔doble + 2 database↔openfga) + harness (1). `tsc` (ambos tsconfig), `typecheck`,
`check:purity` y `build` limpios. El `:8101` quedó sin stores residuales (el guard barre; los specs borran
los suyos).

## Ficheros

Tocados (27): `src/types.ts`, `src/relations/manager.ts`, `src/relations/reconcile.ts`,
`src/drivers/database_relations_driver.ts`, `src/drivers/openfga_relations_driver.ts`,
`src/drivers/openfga_facts.ts`, `src/testing/relations_contract.ts`,
`src/testing/relations_reconcile_contract.ts`, `providers/authz_provider.ts`,
`commands/authz_relations_reconcile.ts`, `stubs/migration.stub`, `tests/helpers/schema.ts`, los specs
`migration_stub`, `openfga_facts` (literal fusionado), `relations`, `relations_bridge`, `relations_contract`,
`relations_database`, `relations_design_cases`, `relations_harness`, `relations_openfga`,
`relations_reconcile`, `relations_reconcile_cli`, `relations_service` (capacidad nueva en los literales),
`README.md`, `CHANGELOG.md` (entrada `[Unreleased] — 2.4.0-alpha.2` + receta), `CLAUDE.md` (invariante 3).
Ningún fichero nuevo.

## Lo que NO hice, y por qué

- **No subí `version` en `package.json`** (sigue `2.4.0-alpha.1`): el release lo hace el dueño; la entrada
  del CHANGELOG va como `[Unreleased] — 2.4.0-alpha.2`.
- **No hay manejo de carrera entre dos `relate` concurrentes con caducidades distintas** en `openfga`: el
  `Write` de una tupla ausente va con `onDuplicateWrites: Ignore` (dos `relate` idénticos a la vez son
  idempotentes) y la renovación es delete+write sin releer; si otro escritor se cuela, gana el último
  `Write` o el nuestro se ignora como duplicado. Es la misma postura que antes de R-15 (el 4-4 tampoco lo
  cubría); el 409/relectura del `grant` de roles NO se porta. Declarado en el CHANGELOG.
- **`{trx}` en `relate`/`unrelate`** sigue diferido (paridad con `roles/`, decisión (b)); `includes` con
  `from`, también.
- **No toqué el stub de config** (`stubs/config/authorization.stub`): los drivers de relaciones no necesitan
  opción nueva; el reloj llega por `config.clock` a través del provider.
- **El caso `whenFalse` del reloj duerme 1,7 s** (solo corre en el doble MÍNIMO de `relations_contract.spec`):
  es el mismo coste que la cara `false` de roles.
- **No medí la latencia** del `Read` extra que `relate` paga ahora en `openfga` (antes: 1 `Write`; ahora:
  1 `Read` + 1–2 `Write`). Es el precio de «omitido preserva / caducada revive» (invariante 10), el mismo que
  paga `grant`; no está en el encargo y no cambia `check` (sigue siendo UN `Check`, espía verde).

Nada del encargo resultó imposible ni contradijo el código. La única decisión de diseño que tomé sin
precedente exacto: `withClock` en los drivers de relaciones devuelve una **instancia nueva** (no una vista
`Object.create(this)` como en roles) porque estos drivers usan campos `#privados` que no sobreviven a la
vista por prototipo; en `openfga` la instancia comparte el `client` para que el espía de «1 Check» siga
valiendo.
