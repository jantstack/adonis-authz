# Fase 6b — Reorg de `src/` a carpetas de módulo (informe)

Refactor **sin cambio de comportamiento**: solo se mueven ficheros y se arreglan imports.
La superficie pública queda idéntica y la suite entera verde en los 5 modos con el mismo nº de casos.

## Qué se movió y a qué carpeta

| De | A | Motivo |
|---|---|---|
| `src/drivers/backend_guard.ts` | `src/shared/backend_guard.ts` | Utilidad SQL COMPARTIDA (la usan catálogo, ambos drivers, trait, manager, freeze, outbox, sql_descendants). El docstring de la regla 2 de `check_purity` ya nombraba `src/shared/` como su hogar. **Desbloquea `src/catalog/`** (un módulo no puede importar `src/drivers/*`). |
| `src/drivers/sql_expiry.ts` | `src/shared/sql_expiry.ts` | Ídem: codec de `expires_at` compartido por drivers, trait, catálogo, outbox. |
| `src/catalog.ts` | `src/catalog/catalog.ts` | Módulo `catalog/` de la spec. |
| `src/catalog_cache.ts` | `src/catalog/catalog_cache.ts` | Ídem. |
| `src/middleware/app_access_middleware.ts` | `src/http/app_access_middleware.ts` | Módulo `http/` de la spec. `src/middleware/` se elimina. |
| `src/middleware/resource_access_middleware.ts` | `src/http/resource_access_middleware.ts` | Ídem. |

`backend_guard.ts` y `sql_expiry.ts` no cambiaron sus PROPIOS imports (mismo nivel de profundidad
raíz→`shared`); los middleware tampoco (`src/middleware/`→`src/http/` es mismo nivel).

### Qué se dejó en la raíz de `src/` y por qué

- **Transversales puros** (como autorizaba la consigna): `types.ts`, `manager.ts`, `identity.ts`,
  `errors.ts`, `clock.ts`, `expiry.ts`, `define_config.ts`, `freeze.ts`, `reconcile.ts`, y los
  resolutores/outbox de scopes (`hierarchical_resolver.ts`, `memoize_ancestors.ts`,
  `sql_descendants.ts`, `scope_outbox.ts`, `relation_partition_trigger.ts`). `manager.ts` es la
  fachada (no puede vivir en un módulo: la regla 2 lo prohíbe como destino) y `types.ts` es el puerto.
- **`relations_config_store.ts` se dejó en la raíz A PROPÓSITO** (no se metió en `src/relations/`):
  puentea relaciones con la infraestructura de versión del catálogo (`catalog_cache`). Meterlo en
  `src/relations/` habría creado una arista relations→catalog entre módulos y más churn en
  commands/tests sin ganancia de claridad. Es cross-cutting; queda en raíz.
- `src/relations/` YA era un módulo (Fase 4) y no se tocó su contenido.
- `src/drivers/` (incl. `openfga_driver.ts`, `openfga_facts.ts`, `openfga.ts` en `src/`) se queda:
  son los drivers concretos, no módulos opt-in.

## Superficie pública — diff

**Criterio duro cumplido: no se removió, renombró ni cambió ningún símbolo exportado.**

Los subpaths (`.`, `./openfga`, `./testing`, `./types`, `./services/*`, `./commands*`, los dos
middleware, `./authz_provider`) conservan **el mismo nombre**. En `package.json` solo cambió la RUTA
INTERNA de los dos middleware (`./build/src/middleware/…` → `./build/src/http/…`), que la consigna
declara explícitamente permitida (el nombre del subpath es API; la ruta interna no). **Claves de
subpath: idénticas** (`diff` de claves vacío).

Diff de la superficie de símbolos (`baseline-surface.txt` vs regenerado):

```
108a109,112
> ### build/services/main.d.ts
> { authorization as default }
> ### build/services/relations.d.ts
> { relations as default }
```

Este residuo **NO es un cambio de API**: es un hueco de captura del baseline. El
`baseline-surface.txt` no contiene NINGUNA línea de `services/` (0 coincidencias) — cuando se capturó,
`build/services/main.d.ts` y `build/services/relations.d.ts` no estaban en `build/`. El reorg NO tocó
`services/` (git lo confirma: `services/` y `providers/` sin cambios), así que sus exports
(`authorization`, `relations`) son idénticos a antes. El diff es **estrictamente aditivo** (`108a…`):
ni una línea eliminada o cambiada ⇒ todo símbolo del baseline sigue presente y byte a byte igual en
`index.d.ts`, `openfga.d.ts`, `testing/main.d.ts` y `types.d.ts`.

Prueba complementaria (git diff de `index.ts`): los únicos cambios son rutas en cláusulas `from`, cero
símbolos:

```
-} from './src/catalog.js'                          +} from './src/catalog/catalog.js'
-… from './src/catalog.js'                           +… from './src/catalog/catalog.js'
-} from './src/catalog_cache.js'                     +} from './src/catalog/catalog_cache.js'
-} from './src/catalog_cache.js'                     +} from './src/catalog/catalog_cache.js'
```

## Migraciones por módulo — NO se separan (decisión)

No se separan las migraciones por módulo. Motivo: `stubs/migration.stub` crea las seis tablas
`authz_*` (roles, permissions, role_permissions, assignments, denies, catalog_version) que son
cross-cutting del dominio roles/catálogo, y `migration_stub.spec` EJECUTA el stub y lo compara con el
espejo columna a columna / FK a FK. Trocearlo obligaría a `configure` a publicar varios stubs en orden
y arriesgaría ese test sin ningún beneficio funcional (el stub publicado tiene que seguir creando
EXACTAMENTE las mismas tablas). La única migración ya separada —la outbox opt-in
(`stubs/scopes_outbox_migration.stub`)— se queda como estaba. Como avisaba la consigna, la parte de
ficheros ya es el grueso del valor.

## `check_purity.mjs` — cómo quedó el grafo

- **Sin cambio de lógica; mide lo mismo (más).** `KNOWN_MODULES` ya listaba `['catalog','relations','http']`
  y `MODULE_FORBIDDEN_TARGETS` sigue siendo `src/manager` + `src/drivers/*` (no se movieron). Ahora que
  `src/catalog/` y `src/http/` EXISTEN (antes no), la regla 2 los vigila de verdad (además de
  `src/relations/`, que ya existía). La regla 3 (openfga) apunta a `src/openfga`,
  `src/drivers/openfga_driver`, `src/drivers/openfga_relations_driver` y `commands/openfga_*`: todos
  intactos.
- Se pusieron al día **solo los comentarios** (decían «hoy la lista de módulos está vacía», ya falso):
  el docstring de la regla 2 y el bloque de `KNOWN_MODULES`. Cero cambio de comportamiento del script.
- `check:purity` verde con la nueva estructura (catalog/ ya no importa drivers: tira de `src/shared/`).

## Cifras (los 5 modos) — el conteo NO baja

| Modo | Comando | Casos | Baseline |
|---|---|---|---|
| sqlite memoria + openfga | `OPENFGA_TEST_URL=…:8101 npm test` | **994** ✓ | 994 |
| sqlite fichero + openfga | `… npm run test:sqlite-file` | **999** ✓ | 999 |
| PostgreSQL 18 + openfga | `TEST_PG_URL=… npm run test:pg` | **1093** ✓ | 1093 |
| MySQL 8.4 + openfga | `… npm run test:mysql` | **1093** ✓ | 1093 |
| tope 3 (openfga tiny :8103) | `OPENFGA_TEST_URL=…:8103 npm test` | **994** ✓ | 994 |

Todos PASSED, exit 0. `npx tsc --noEmit` (test config), `npm run typecheck`, `npm run check:purity`
y `npm run build` verdes.

## Lo que NO se movió (resumen)

- `services/`, `providers/`, `configure.ts`, `stubs/`, `commands/` (solo se ajustaron imports de
  commands que apuntaban a `catalog.js`).
- El núcleo transversal de `src/` (ver arriba).
- `relations_config_store.ts` (cross-cutting; queda en raíz, justificado arriba).
- `src/drivers/*`, `src/models/*`, `src/traits/*`, `src/testing/*`, `src/relations/*` (contenido).
- Ninguna línea de LÓGICA: solo movimientos de fichero y reescritura de especificadores de import.
</content>
