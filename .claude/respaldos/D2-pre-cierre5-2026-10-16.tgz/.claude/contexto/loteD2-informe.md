# Lote D · sublote D2 (migración y operación del deny) — informe del implementador · 2026-10-15

**Árbol `main` sobre `75353fe`** (D1 cerrado, sin publicar). Fui el único agente que mutó el árbol. **Sin commit, sin
`version` y sin push.**
- Brief: `loteD-coordinador.md`, sección «D2» y «Addendum para D2».
- Entorno: Node 22.23.2, OpenFGA `:8090` (`openfga-dev`, reiniciado antes de CADA suite), `postgres18` y `mysql84`. No se
  usó `:8103`, y no queda ningún contenedor `openfga-tiny`.
- Logs: `scratchpad/d2/`. Contiene `red-reconcile.log`, `red-guard-denyPhase.log`, `piece_mut.log`, `mutants.json`,
  `logs/<mutante>.log` y `final/*.log`.
- Sin tocar: `EXPECTED_FUSED`, `migration_stub.spec` y `freeze.spec` (`git diff --quiet` en los dos specs; 0 líneas
  `EXPECTED_FUSED` en el diff).
- CHANGELOG: `git diff -U0` da un solo hunk (`@@ -180,0 +181,71 @@`). Solo crece `[Unreleased]`, debajo del bloque de D1.
  `[2.5.0-alpha.2]` y `[2.5.0-alpha.1]` están intactos.
- Ningún `skip` ni `pending` nuevo. Los dos `pending` del runbook pasaron a ser pasos reales, y el `pending` de
  `--allow-drop-deny` en el flag-mutants ya se juzga.

---

## 0 · Rojos observados por pieza

Método: primero escribí el caso, después lo corrí contra el código SIN la pieza. En la pieza 1 hubo rojo literal antes
de escribir código. En las demás, el rojo es el del caso contra un mutante de «retirada» (la pieza quitada), corrido en
una copia del árbol (`scratchpad/d2/mutrun.py`).

| Pieza | Rojo observado |
|---|---|
| **Reconcile con `kind` + puerta** | `tests/relations_reconcile_deny.spec.ts` escrito ANTES del código ⇒ **11/13 rojos** (`red-reconcile.log`): `enumerateRelations marca kind…: expected ['undefined:denied_viewer', …]`; `S6: expected undefined to equal 500` (sin puerta, el reconcile ESCRIBÍA el allow); `R2-5 · workspace: undefined` ×2; `unmarked`/`undeclared`/`no-deny-phase`: sin negativa; `--prune: expected 1 to equal 2` (el deny sobrante no se borraba); `dry-run: written 2 vs 1`; `massDelete: denies undefined`; `S4 k=1: parcial ⇔ ya escribió`; `reporte parcial: expected false to be true`. |
| **`denyPhase` en la guardia (punto 11)** | Con el método ya en `src/` y SIN fila, **5 rojos** con su nombre (`red-guard-denyPhase.log`): G-0 ×3 («DatabaseRelationsDriver / OpenFgaRelationsDriver / makeRelationsDriver tiene operaciones SIN fila … denyPhase»), 🟡 E («database.denyPhase: operación SIN CLASIFICAR» ×3) y G-R («sin forma de invocarse … database.denyPhase, openfga.denyPhase»). Con la fila puesta: G-M rojo («celdas con sonda SIN mutante … database.denyPhase.f05, …») y ⚪11 rojo hasta escribir los 3 mutantes. |
| **Guardia L9** | Mutante `l9.registry-missing` (quitar la entrada de `E_AUTHZ_DENY_EXPIRY_UNSUPPORTED`) ⇒ rojo: «422 del puerto de relaciones SIN clasificar en RELATION_REJECTIONS: RelationDenyExpiryError (E_AUTHZ_DENY_EXPIRY_UNSUPPORTED)». `l9.reasons-not-derived` ⇒ 2 rojos (lo derivado, y «la poda NO absorbe un 422 de fuera de la familia»). |
| **`openfga:provision --allow-drop-deny`** | `p2.provision-no-guard` (el código de D1) ⇒ 4 rojos («SIN --allow-drop-deny … exit 1»: salía 0 y publicaba el modelo mutilado). `p2.provision-no-sweep` ⇒ 2 rojos («deny VIVO»). Mutante inerte de la bandera ⇒ muerto (2 rojos). |
| **Runbook pasos 20/21** | `rb.enum-no-kind.db` (el `enumerate` de `database` de D1, sin `kind`) ⇒ el caso del runbook rojo en `sqlite-file` (paso 20: la migración no lleva el deny). |
| **Gemelo de roles de N3** | `n3.roles-503` (sin la clasificación) ⇒ rojo: «gemelo N3: E_AUTHZ_BACKEND_UNAVAILABLE …» (el 503 «transitorio» de antes). |
| **Orden de `purgeScope` (roles)** | Mutante `roles.purgeScope.denies-first` en el corredor ⇒ rojo: «tras 2 de 6 Write: CONCEDE». |
| **Orden del reconcile (propiedad)** | `rec.order.allows-before-denies` y `rec.order.prune-denies-first` en el corredor ⇒ 1 rojo cada uno. |
| **Letra del CLI** | `cli.refused-clean` sobrevivió a la primera tanda: el dry-run del caso S6 ya era «sucio» por sus escrituras. Escribí el caso puro «una negativa de deny SOLA … es DERIVA» y el mutante murió. |

**Casos existentes que el lote puso rojos** (justificados, punto 5 c):
1. **R-1 de `command_flags_r.spec`.** La rama `--store-id` de `provision` lee ahora PRIMERO el modelo actual del store
   (la guarda), así que la primera request es `GET /stores/<id>/authorization-models`. Con el stub 400 el comando se
   niega con su línea («provision NEGADO: no se pudo leer…»). Lo que el caso juzga sigue siendo lo mismo: va a ESE store
   y no crea otro.
2. **⚪11 de `guard_surface.spec`** («el doble entra en la columna partition»). `denyPhase` no recibe partición (es
   config) y queda fuera de ese recorrido. La `NA_MATRIX` admite su `na: signature` solo para esa operación.
3. **`relations_harness.spec`.** Sin cambio en la cuenta base (11). Añadí la cuenta con la cara del deny (16).

---

## 1 · Piezas (ficheros, casos, mutantes)

### 1.1 Reconcile con `kind` y las cuatro fases (prioridad 1)
- **`RelationTuple.kind?: 'allow' | 'deny'`** (`src/types.ts`; opcional, ausente = allow).
- **Punto de paso único `storedRelationKind`** (`src/relations/define_relations_config.ts`): `denied_viewer` pasa a
  `{ relation: 'viewer', kind: 'deny' }`. Es inequívoco porque el prefijo está en `RESERVED_SLUG_PREFIXES`. Lo usan
  `#enumerateRows` (database), `#sweep` (openfga) y el doble.
- **`src/relations/reconcile.ts`, reescrito el plan y la escritura:**
  - `planPartition` separa allows y denies (`denyWrite`, `denyUpdate`, `denyPresent`, `denyDelete`).
  - Un deny no se descarta jamás como `skipped`. Lo que lo impide es una negativa (`denyRefusals`): `unmarked`,
    `undeclared` con `toConfig`, e `invalid` por identidad o sujeto. Solo la caducidad lo descarta.
  - `applyPartition` hace las cuatro fases **por partición**: denies → allows → poda de allows (`unrelate`) → poda de
    denies (`removeDeny`). `deleteOrClassify` sustituye a `unrelateOrClassify`.
  - Un deny del destino con caducidad distinta se rehace permanente con `to.deny` (D3/R2-8).
- **Reporte:**
  - `report.denies` (subconjunto de los totales).
  - `report.denyRefused` (solo en `--dry-run`).
  - `report.partitions` (estado y contadores por partición).
  - En el error, `error.report` con `partial: true` y `markPartialWrite` si se escribió algo.
- **Comando** (`commands/authz_relations_reconcile.ts`):
  - Línea `denies: escritos …`.
  - Líneas `deny NO migrable (<motivo>) …`, que son deriva.
  - Catch de `E_AUTHZ_DENY_MIGRATION_REFUSED` (exit 1, sin stack).
  - Catch del error con `report.partial` y las líneas `pasada PARCIAL: …` (`partialReportLines`, pura).
- **Casos:**
  - `tests/relations_reconcile_deny.spec.ts` (14). Contiene T3 sobre dobles, S4 (corte tras k = 0…4 escrituras), S5
    (poda cortada), el reporte parcial y la letra con dientes del README.
  - `tests/relations_reconcile_cli.spec.ts` (+1, el caso puro de la negativa sola).
  - El runner publicado `runRelationsReconcileContract` gana la cara `denies: true`: por dirección «el deny viaja como
    DENY … CENSO por listDenies» y «--prune … removeDeny DESPUÉS de los allows», más S6 global. Corre en
    doble ↔ doble y en `database ↔ openfga` contra `:8090`, en las dos direcciones.
  - `tests/relations_reconcile.spec.ts` gana el caso del modelo fijado sin `denied_*` (motivo `model`, cero tuplas en
    el store).
- **Propiedad de la guardia `relations.reconcile.order`** (`tests/fixtures/guard_manifest.ts` + caso puro en
  `guard_surface.spec`): reconcile cortado tras CADA escritura en 4 filas (mismo hecho, corte de camino, deny por grupo,
  poda). Mutantes en el corredor: `rec.order.allows-before-denies` y `rec.order.prune-denies-first`.

### 1.2 Puerta por driver DESTINO (S6, R2-5)
- **Método nuevo del puerto `denyPhase?(object, relation)`.** Hace F-05 estricto y devuelve `'read' | 'write' | null`
  según la config DEL DRIVER. En `openfga` corre además `#assertModelDeny` (D-31). Está en database, openfga, el doble y
  la vista `withClock`.
- **`denyGate`** en `reconcileRelations`: corre DESPUÉS de planificar todas las particiones y ANTES de la primera
  escritura.
  - Para escribir hace falta `'write'`; para un deny que ya está, opt-in en cualquier fase.
  - Motivos: `no-capability`, `no-deny-phase`, `phase`, `undeclared`, `model`, `unmarked`, `invalid`.
  - Pasada real: 500 `DenyMigrationRefusedError` / `E_AUTHZ_DENY_MIGRATION_REFUSED` (nuevo, exportado por la raíz, con
    `refusals`). `--dry-run`: `denyRefused`.
- **Guardia:**
  - Filas `configRead(database|openfga|double, 'denyPhase')`.
  - `PORT_READS` + `denyPhase`; dos reglas de `NA_MATRIX` (`partition` y `truncation` `na: signature` solo para
    `denyPhase`); `INVOKE`; `F05_VARIANTS` (type, relation, undefined).
  - 3 mutantes: `database|openfga|double.denyPhase.f05`.

### 1.3 Guardia del linaje L9
- **`RELATION_REJECTIONS`** (`src/relations/reconcile.ts`): una entrada por cada clase 422 del puerto.
  - `classified` (4): TYPE_UNKNOWN y RELATION_UNKNOWN ⇒ `undeclared`, USERSET ⇒ `userset-unsupported`,
    INVALID_IDENTITY ⇒ `invalid-identity`.
  - `refused` (1): NOT_DENYABLE ⇒ `phase`.
  - `unreachable` (6), con su porqué: DENY_EXPIRY, CHECK_MANY_BATCH, RELATION_CONFIG, CONFIG_UNKNOWN_KEY, INVALID_SLUG y
    ACTOR_REQUIRED.
- **`RELATION_422_REASONS` se DERIVA del registro.** `relateOrSkip` y `deleteOrClassify` clasifican por `code` con él.
- **`tests/relations_reconcile_l9.spec.ts`** (9 casos):
  1. Reflexión: clases con `status === 422` de `src/errors.ts` ∩ nombradas en `src/relations/*` (salvo el registro),
     `relations_reconcile`, los dos drivers, el doble e `identity.ts`. Tiene que coincidir con el registro: falta ⇒ rojo
     con nombre; sobra ⇒ rancio.
  2. `RELATION_422_REASONS` = lo derivado.
  3. Cada `classified`/`refused` tiene un caso en `FIXTURES` (cerrado en los dos sentidos).
  4. Un caso por entrada: provoca el 422 en el driver y afirma que el plan lo clasifica sin pedirle la tupla, con los
     mismos números en dry y real.
  5. Un 422 de fuera de la familia en `unrelate` se propaga.

### 1.4 `openfga:provision` con `--allow-drop-deny` y barrido (prioridad 2)
- `commands/openfga_provision.ts`. Solo en la rama `--store-id`: `guardDroppedDenies` lee el modelo actual. Con la función
  pura `droppedDenyRelations(current, next)` (solo tipos de relación; los `denied_<P>` de `scope` no cuentan):
  - Sin la bandera: exit 1 «provision NEGADO: el modelo nuevo QUITA …» con cero escrituras.
  - Con la bandera: barrido `Read` paginado (`PROVISION_DROP_DENY_SWEEP_MAX` = 1 000 000, fila en «Limits», atada en
    `scope_depth.spec`). Cero denies vivos ⇒ publica y lo dice; si quedan ⇒ exit 1 que los cuenta.
  - Modelo actual ilegible ⇒ exit 1, sin publicar a ciegas.
- **`tests/command_flags_d2.spec.ts`** (6 casos de provision, por el kernel y SIN servidor). Usa un OpenFGA de mentira en
  memoria que sirve `GET/POST authorization-models` y `POST read`, así que entra en el flag-mutants.
- `scripts/flag_mutants.manifest.json`: la entrada `pending` de `--allow-drop-deny` se retira. Mutante juzgado: **muerto**.

### 1.5 Runbook: los dos pasos `pending` convertidos en pasos reales (prioridad 3) + D-27
- `tests/helpers/cutover_child.ts`:
  - `phase.deny` (`'read'`/`'write'`/ausente) decide la config de relaciones del despliegue.
  - Órdenes nuevas: `relDeny`, `relRemoveDeny`, `relListDenies`, `podCheck` (un pod con otra config y otro `modelId`
    sobre el mismo store) y `countRelationDenies` (la constante del README).
- `tests/cutover_runbook.spec.ts`:
  - **Paso 20:**
    - `provision --store-id` desde la config `'read'` ⇒ `modelId` nuevo.
    - FASE 1: `deny` ⇒ 422 en los dos drivers; 0 denies.
    - FASE 2 (segundo despliegue `'write'`): el deny entra; `authz:relations:reconcile` lo lleva (`denies: escritos 1`);
      `check` es F en los dos drivers; `listDenies` lo ve; el verificador sale «Sin deriva».
    - **S11:** un pod sin redesplegar con el modelo viejo **concede** (fila declarada); con el `modelId` nuevo, F; config
      nueva con pin viejo ⇒ 500.
  - **Paso 21:**
    - La consulta del README cuenta 1.
    - Un proceso con la config sin opt-in: `provision` sale 1, también con `--allow-drop-deny` («1 deny(s)»); el store
      queda intacto y el deny sigue negando.
    - `removeDeny` + `--prune` ⇒ `denies: … borrados 1`, cuenta 0, y `--allow-drop-deny` publica («0 denies vivos»).
- **D-27 (T3 por el kernel)**, `tests/command_flags_d2.spec.ts` (5 casos, con la bandera de verdad):
  - deny vivo: exit 0 y la línea `denies:`.
  - S6 real y `--dry-run`: exit 1 con los prefijos `deny NO migrable:` / `deny NO migrable (no-capability)`, y cero
    escrituras.
  - `--prune` ⇒ `removeDeny`.
  - `--dry-run` con efecto: 0 escrituras con la bandera, 1 sin ella.
  - Pasada cortada: exit 1 y `pasada PARCIAL: partición app · REVENTÓ aquí … denies escritos 1`.

### 1.6 S11 / S17 (prioridad 4)
- **S11:** fila declarada con caso en el runbook (20d) y en README §Upgrading. El caso «S11 · FILA DECLARADA» de D1 se
  queda como estaba.
- **S17/D12:**
  - Fila declarada en README §Upgrading.
  - La consulta `RELATION_DENIES_COUNT_SQL` (`substr`, portable a los tres motores; `LIKE 'denied\_%'` no lo es en
    SQLite). Está en `define_relations_config.ts` y la ejecuta `upgrade_recipe.spec` en los 4 modos, contra el bloque
    del README byte a byte.
  - Paso 21 del runbook.

### 1.7 Gemelo de roles de N3 y orden de `purgeScope` (prioridad 5)
- **`isServerWriteLimit` movida a `src/shared/backend_guard.ts`** (punto de paso de los dos puertos).
  - En roles, `guardBackendErrors` (que envuelve TODA llamada del cliente) convierte el 400 `exceeded_entity_limit` en un
    500 `E_AUTHZ_CONFIG` con letra (`serverWriteLimitError`).
  - Caso: `tests/openfga_write_limit.spec.ts`. Usa un HTTP falso con el 400 en la forma medida; `purgeScope` llega a la
    red y el error es el real del SDK.
- **Propiedad `openfga.roles.purgeScope.order`** (manifiesto + caso en `guard_surface.spec`): `purgeScope` real sobre un
  cliente en memoria, cortada tras cada `deleteTuples`. 6 `Write`; víctima asignada y denegada; oráculo de (c2r) reducido
  al scope. **Medido: con los denies AL FINAL ningún estado intermedio concede.** El orden de 3b-2f · R3 ya era correcto,
  así que lo que hace falta es el caso que lo fije y no un cierre. Mutante `roles.purgeScope.denies-first` en el corredor:
  muerto.

### 1.8 Letra (prioridad 6)
- **README:**
  - Párrafo «Denies migrate as denies» en «Migrating tuples between drivers».
  - Fila `E_AUTHZ_DENY_MIGRATION_REFUSED` en la tabla de códigos.
  - Fila `PROVISION_DROP_DENY_SWEEP_MAX` en «Limits».
  - Sección nueva **«Upgrading to 2.5.0-alpha.3»**: «provision → pin `modelId` → deploy» en tres pasos, la guarda de
    `provision`, la fila declarada D12/S17 con la consulta y el procedimiento, y «un 2.5 nunca clasifica un deny como
    `undeclared`».
- **Letra con dientes:** caso en `relations_reconcile_deny.spec`. Los prefijos del README son los que imprime el código.
- **CHANGELOG `[Unreleased]`:** bloque «Plan 2.5 · lot D · D2» (problema → decisión → qué NO).

---

## 2 · Cuatro líneas de cierre por pieza grave

**(P1) Reconcile con `kind` + cuatro fases (S4/S5; R2-3).**
- **(a) Gemelos.**
  - `reconcile` (roles) ↔ `relations:reconcile`. Roles ya escribía los denies sin `kind`, como `denied_<P>` de `scope`, y
    `authz:reconcile` trata lo de relaciones como ajeno. Para la parte de denies no aplica.
  - Comando ↔ `runRelationsReconcile` ↔ primitivo: un solo plan. El comando y la vía pública delegan en él.
  - `database` ↔ `openfga` ↔ doble: un solo `storedRelationKind`.
  - Runner publicado: cara `denies: true`.
- **(b) Tabla de verdad:** §3.1. Corte: S4 con k = 0…4 sobre dobles, más la propiedad de la guardia con 4 filas.
- **(c) Casos existentes puestos en rojo:** ninguno de efecto. El bucle de escritura se reescribió y los 113 casos de
  reconcile y CLI siguieron verdes.
- **(d) Linaje:** L10 (purga/escritura multi-request), 4.ª iteración ⇒ estructural. Hay propiedad universal escrita, punto
  de paso único (`applyPartition`) y ENTRADA en `GUARD_PROPERTIES` con dos mutantes. No toqué `linajes.md` (le toca al
  coordinador).

**(P2) Puerta del destino (S6, R2-5).**
- **(a) Gemelos.**
  - Comando ↔ API: la misma puerta.
  - `--dry-run` ↔ real: mismos motivos (`denyRefused` ↔ `error.refusals`).
  - `openfga` ↔ `database` ↔ doble: `denyPhase` en los tres; en `openfga` además D-31.
  - Roles: no aplica. `authz:reconcile` no escribe denies de relaciones (son ajenos).
- **(b) Tabla de verdad:** §3.1, filas 2–7, ejecutadas: doble sin capacidad, doble sin `denyPhase`, fase `'read'`, sin
  opt-in, par no declarado, `openfga` pineado a un modelo sin `denied_*` (servidor real) y `unmarked`.
- **(c) Casos existentes puestos en rojo:** ninguno.
- **(d) Linaje:** es justo la R2-5 que abrió L9. La puerta no absorbe: lanza o lista.

**(P3) Guardia L9 (decisión §2026-10-15 (7)).**
- **(a) Gemelos:** capa 1 (plan) ↔ capa 2 (`relateOrSkip`/`deleteOrClassify`), las dos derivadas del mismo registro.
  Roles: no aplica. Roles no tiene un plan que clasifique 422 de un puerto de relaciones; su reconcile ya separa lo
  ajeno por lista blanca.
- **(b) Tabla de verdad:** el registro mismo (11 clases × {classified, refused, unreachable}), y 5 casos ejecutables.
- **(c) Casos existentes puestos en rojo:** ninguno. `relateOrSkip` pasa de `instanceof` a `code` y los casos de N9/B3
  siguieron verdes.
- **(d) Linaje:** L9, 3.ª aparición ⇒ estructural (propiedad, registro único y guardia por reflexión). La fila en
  `linajes.md` le toca al coordinador.

**(P4) Guarda de `provision` (R2-4 c, H3).**
- **(a) Gemelos:**
  - Comando ↔ función pura (`droppedDenyRelations`), con caso puro.
  - D-31 (el pod lo detecta al usar) ↔ provision (lo detecta al publicar): complementarias, con las dos en el runbook.
  - `database`: no aplica (D8 honra siempre; no hay modelo).
- **(b) Tabla de verdad:** §3.2, por el kernel y en el runbook.
- **(c) Casos existentes puestos en rojo:** R-1 (justificado en §0).
- **(d) Linaje:** L5 (entrada del operador sin efecto): la bandera nueva nace con su caso de EFECTO y su mutante inerte
  muerto.

**(P5) Gemelo de roles de N3.**
- **(a) Gemelos:** relaciones (cierre 2 de D1) ↔ roles, con la misma función compartida.
- **(b) Tabla de verdad:** {error del SDK, envuelto en `cause`, otro 400, null} en la pura; `purgeScope` contra el 400
  real.
- **(c) Casos existentes puestos en rojo:** ninguno.
- **(d) Linaje:** no pertenece a ninguno.

**(P6) Orden de `purgeScope` como propiedad (L10 en roles).**
- **(a) Gemelos:** `openfga.purge.order` (relaciones, D1) ↔ `openfga.roles.purgeScope.order`.
- **(b) Tabla de verdad:** corte tras k = 0…5 `Write`; el estado inicial no concede (deny), el final tampoco (vacío), y
  ningún intermedio concede.
- **(c) Casos existentes puestos en rojo:** ninguno.
- **(d) Linaje:** L10, ahora con dos propiedades en la guardia.

---

## 3 · Tablas de verdad

### 3.1 Reconcile con denies: origen con deny vivo × destino × {dry, real} × {prune}
Todas las filas son casos. «0 W» = cero escrituras en el destino.

| destino | real | `--dry-run` | con `--prune` |
|---|---|---|---|
| capacidad + `'write'` (y en openfga modelo con `denied_*`) | escribe deny ANTES que allow, `denies.written`, exit 0 | mismos números, deriva (exit 1) | deny sobrante ⇒ `removeDeny` DESPUÉS de los allows; `denies.deleted` |
| sin `relationDenies` | 500 `no-capability`, **0 W** (ni el allow) | `denyRefused`, exit 1 «deny NO migrable (no-capability)» | igual: la puerta va antes de toda poda |
| `relationDenies` sin `denyPhase` | 500 `no-deny-phase`, 0 W | marca, exit 1 | igual |
| tipo en `'read'` / sin opt-in EN EL DESTINO | 500 `phase`, 0 W | marca, exit 1 | igual |
| par tipo/relación no declarado en el destino | 500 `undeclared`, 0 W | marca, exit 1 | igual |
| openfga con `'write'` y pin a un modelo SIN `denied_*` | 500 `model` (D-31), **0 tuplas en el store** (medido, `:8090`) | marca, exit 1 | igual |
| origen que no marca `kind` (`denied_viewer` como allow) | 500 `unmarked`, 0 W | marca, exit 1 | igual |
| deny caducado (a mano) en el origen | `skipped.expired`, no se escribe, exit 0 | ídem | — |
| deny ya presente; destino con opt-in en cualquier fase | `denies.unchanged`, exit 0 | limpio | — |
| deny del destino con caducidad, origen permanente | `to.deny` lo rehace permanente (`denies.updated`) | contado | — |
| corte tras k escrituras (k = 0…n) | denies de MÁS, nunca un allow sin su deny; parcial ⇔ k > 0; `error.report` | — | poda cortada: allows antes que denies, ningún estado concede |

### 3.2 `openfga:provision --store-id`

| ¿el modelo nuevo quita `denied_*` de un tipo de relación? | `--allow-drop-deny` | denies vivos de esas relaciones | modelo actual legible | resultado |
|---|---|---|---|---|
| no | — | — | sí | publica, exit 0, sin barrido |
| sí | no | — | sí | exit 1 «provision NEGADO: el modelo nuevo QUITA …», 0 W |
| sí | sí | 0 | sí | barre, publica, exit 0 «0 denies vivos» |
| sí | sí | ≥ 1 | sí | exit 1 «… no apaga denies VIVOS: … N deny(s)», 0 W |
| — | — | — | no | exit 1 «provision NEGADO: no se pudo leer…», 0 W |
| barrido > 1 000 000 tuplas | sí | ? | sí | exit 1 (no se demuestra el cero) — sin caso (declarado) |

### 3.3 Runbook (pg y sqlite-file, OpenFGA real): 22 pasos, 0 pendientes

| paso | estado | lo que se afirma |
|---|---|---|
| 20a | antes | `provision --store-id` desde `'read'` ⇒ `modelId` nuevo ≠ viejo |
| 20b | fase 1 | `deny` ⇒ 422 en database y openfga; 0 denies; `check` sin cambios |
| 20c | fase 2 | deny vivo; migración `denies: escritos 1`; `check` F en los dos; censo `listDenies`; verificador limpio |
| 20d | S11 (declarada) | pod sin desplegar + pin viejo ⇒ **T**; + pin nuevo ⇒ F; config nueva + pin viejo ⇒ 500 |
| 21 | rollback con deny vivo | cuenta 1; `provision` sin opt-in ⇒ exit 1; con `--allow-drop-deny` ⇒ exit 1 (1 deny); el store sin cambios; el deny sigue negando |
| 21 | procedimiento | `removeDeny` + `--prune` ⇒ `denies … borrados 1`, cuenta 0, ni un `denied_*` en el store, `--allow-drop-deny` publica |

---

## 4 · Decisiones a ratificar (con la alternativa descartada)

1. **Un método nuevo del puerto, `denyPhase(object, relation)`, para que el DESTINO responda por su opt-in.**
   - Descartadas: la spec persistida (`toConfig`; el juez la prohíbe, nadie la escribe en producción); sondear con
     `to.deny` (escribe); exponer la config del driver como campo (la guardia la vería como namespace, y acopla); una
     capacidad por tipo (las capacidades son booleanas por doctrina).
   - Precio: un driver de terceros con `relationDenies` necesita `denyPhase` para ser destino de denies. `relationDenies`
     nace en esta alpha, así que hoy no rompe a nadie. Y el runner del DRIVER (`runRelationsDriverContract`) no lo juzga;
     solo el de reconcile (§6).
2. **Para escribir un deny hace falta `'write'`; para conservar uno que ya está basta con opt-in en cualquier fase.**
   Descartado: exigir siempre `'write'`, que haría fallar una pasada de verificación en fase 1. Consecuencia: un destino
   que retiró el opt-in con denies presentes niega la pasada siguiente (ruidoso).
3. **Un deny cuyo par no declara el destino ⇒ negativa (`undeclared`), no `skipped`**, aunque en el origen sea inerte (por
   ejemplo, una relación retirada). Descartado `skipped.undeclared`: con configs desalineadas, el corte de camino del
   destino no vería ese deny y concedería lo que el origen niega. Receta: borrarlo a mano o declarar la relación.
4. **`unmarked`:** una tupla `denied_*` sin `kind` es negativa. Descartado migrarla como allow (`relate(denied_*)` ⇒ 422)
   o contarla `undeclared`.
5. **Los contadores totales incluyen los denies; `report.denies` es el subconjunto.** Descartado separarlos, porque cambiaba
   el significado de `written` para quien ya lo lee.
6. **Fases POR PARTICIÓN, no globales.** El deny y el allow del mismo objeto siempre comparten partición, y así el reporte
   parcial dice qué partición quedó a medias.
7. **El reporte parcial no cambia la clase ni el `code` del error** (un 503 sigue siendo 503). Lleva `error.report`, y
   `markPartialWrite` solo si se escribió algo.
8. **La guarda de `provision` actúa solo en `--store-id` y solo sobre tipos de relación**; los `denied_<P>` de `scope`
   quedan fuera.
   - Compara nombres de relación, no formas (la forma la juzga D-31 en el pod).
   - Un modelo actual ilegible es exit 1. Descartado publicar a ciegas.
9. **El gemelo de N3 en `guardBackendErrors`** (todas las llamadas del cliente de roles), no por operación. Roles no marca
   la escritura parcial: el invariante 13 de roles no lo juzga ningún runner (ya estaba declarado).
10. **`RELATION_REJECTIONS` vive en `reconcile.ts`** (módulo privado, no sale por la raíz). El escaneo incluye
    `identity.ts`, y por eso `InvalidSlug` y `ActorRequired` aparecen como `unreachable` con su porqué.
11. **La consulta de denies usa `substr(relation, 1, 7) = 'denied_'`** (portable). `LIKE` sin `ESCAPE` no escapa `_` en
    SQLite.
12. **Los pasos 20/21 del runbook corren con `default: 'database'`** (tras la VUELTA): el opt-in no depende de la
    dirección del cutover.
13. **`DenyMigrationRefusedError`** (sin «Relation» en el nombre), exportado por la raíz. `droppedDenyRelations` entra en
    `NON_SURFACE_FUNCTIONS`.
14. **`relateOrSkip` clasifica por `code` del registro** en vez de por `instanceof`: una clase de terceros con el mismo
    código se trata igual.

---

## 5 · Cifras (EN SECUENCIA, `:8090` reiniciado antes de cada suite; `scratchpad/d2/final/`)

| Modo / gate | Resultado | Δ sobre la partida |
|---|---|---|
| `npm run build` | rc 0 (purity + typecheck + tsc) | — |
| `npm test` (`:memory:` + `:8090`) | **1974** passed, 2 skipped (95 s) | +79 |
| `test:sqlite-file` | **2002** passed, 2 skipped (108 s) | +79 |
| `test:pg` | **2099** passed, 1 skipped (159 s) | +79 |
| `test:mysql` | **2101** passed, 1 skipped (161 s) | +79 |
| `check:guard-mutants` | **166 / 166** muertos | 160 → 166 |
| `check:flag-mutants` | **37 / 37** muertos, 1 pending (`--prune-undeclared`, lote C) | 36 → 37 |
| `cutover-runbook` sqlite-file / pg | verde ×2: **22 pasos, 0 pendientes** (16,2 s / 18,0 s) | 2 pending → 0 |

- Los skipped son los de siempre.
- **Mutantes de pieza** fuera del corredor (`scratchpad/d2/mutants.json` + `piece_mut.log`): **16/16 muertos**. Tras el
  primer intento quedó vivo `cli.refused-clean`; lo mató el caso puro añadido.

---

## 6 · No hecho (con razón)

- **`CLAUDE.md` y `linajes.md` sin tocar.** La fila L9 de la tabla, la promoción de L10 (ahora con 3 propiedades en la
  guardia) y el mapa del código (`denyPhase`, `RELATION_REJECTIONS`, `report.denies/partitions`) los dejo al
  coordinador, como en D1.
- **`denyPhase` no está en `runRelationsDriverContract`** (el runner del driver). Solo lo ejerce el runner de reconcile
  con `denies: true`. Un caso «`denyPhase` responde la fase de la config» por cara cambiaría las cuentas H9 y lo dejo
  propuesto.
- **El memo D-31 del destino `openfga` es por proceso.** Un pod sin pin, con el memo rancio, podría pasar la puerta. Es el
  límite ya declarado de D-31; con deny, D14 exige el pin.
- **S17 con un hijo que corre el tarball real de `2.4.0-alpha.10`** (E5/E7 del tester): no hecho. El brief pide fila
  declarada + paso del runbook + conteo, y los tres están.
- **⚪ del roadmap: contar en el reporte las tuplas de particiones NO pedidas** que ve el barrido. No hecho; no estaba en
  el brief.
- **R2-11 (techo de bytes + opt-in), la medición de `membersOf` con deny y los ejes T1-b:** no los toqué. Son pendientes
  de D1 y no estaban en D2.
- **La fila «barrido > 1 000 000» de §3.2 no tiene caso** (necesitaría un millón de tuplas). La declaro.
- La función `pending()` del runbook queda sin usos (ya no hay pasos pendientes). La dejo para lotes futuros; no hay
  ningún `pending` nuevo.
- **Auditoría de sistema (punto 9):** le corresponde al coordinador antes de publicar `alpha.3`.

---

## Estado del árbol

```
 M CHANGELOG.md
 M README.md
 M commands/authz_relations_reconcile.ts
 M commands/openfga_provision.ts
 M index.ts
 M scripts/flag_mutants.manifest.json
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_driver.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/relations/define_relations_config.ts
 M src/relations/reconcile.ts
 M src/shared/backend_guard.ts
 M src/testing/relations_contract.ts
 M src/testing/relations_reconcile_contract.ts
 M src/types.ts
 M tests/command_flags_r.spec.ts
 M tests/cutover_runbook.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/guard_surface.spec.ts
 M tests/helpers/cutover_child.ts
 M tests/relations_harness.spec.ts
 M tests/relations_reconcile.spec.ts
 M tests/relations_reconcile_cli.spec.ts
 M tests/scope_depth.spec.ts
 M tests/upgrade_recipe.spec.ts
?? tests/command_flags_d2.spec.ts
?? tests/openfga_write_limit.spec.ts
?? tests/relations_reconcile_deny.spec.ts
?? tests/relations_reconcile_l9.spec.ts

 CHANGELOG.md                                |  71 +++
 README.md                                   |  74 +++-
 commands/authz_relations_reconcile.ts       |  59 +++
 commands/openfga_provision.ts               | 122 +++++-
 index.ts                                    |   1 +
 scripts/flag_mutants.manifest.json          |   6 -
 src/drivers/database_relations_driver.ts    |  16 +-
 src/drivers/openfga_driver.ts               |  25 +-
 src/drivers/openfga_relations_driver.ts     |  35 +-
 src/errors.ts                               |  17 +
 src/relations/define_relations_config.ts    |  22 +
 src/relations/reconcile.ts                  | 653 +++++++++++++++++++++-------
 src/shared/backend_guard.ts                 |  15 +
 src/testing/relations_contract.ts           |  10 +-
 src/testing/relations_reconcile_contract.ts |  99 +++++
 src/types.ts                                |  21 +
 tests/command_flags_r.spec.ts               |  10 +-
 tests/cutover_runbook.spec.ts               |  78 +++-
 tests/fixtures/guard_manifest.ts            |  43 +-
 tests/fixtures/guard_mutants.json           |  79 ++++
 tests/guard_surface.spec.ts                 | 151 ++++++-
 tests/helpers/cutover_child.ts              |  43 +-
 tests/relations_harness.spec.ts             |  16 +
 tests/relations_reconcile.spec.ts           |  69 ++-
 tests/relations_reconcile_cli.spec.ts       |  16 +
 tests/scope_depth.spec.ts                   |   3 +
 tests/upgrade_recipe.spec.ts                |  34 ++
 27 files changed, 1594 insertions(+), 194 deletions(-)
```

Hay 4 ficheros nuevos sin seguimiento (1 044 líneas): `command_flags_d2.spec.ts` (310), `openfga_write_limit.spec.ts`
(81), `relations_reconcile_deny.spec.ts` (379) y `relations_reconcile_l9.spec.ts` (274). El diff es contra `75353fe`.
