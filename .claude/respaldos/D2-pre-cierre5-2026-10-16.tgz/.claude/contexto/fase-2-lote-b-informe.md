# Fase 2 · Lote 2B — informe de implementación (2026-08-28)

Rama `v2/fase-0` sobre `b126e20` (2A commiteado; **sin commits nuevos**: el commit lo hace el dueño).
Node 22.23.2, OpenFGA `:8101` (v1.19.0) y servidor efímero tope 3 (`openfga-tiny`, `:8103`, memoria;
**eliminado al terminar**, `docker ps -a` no lo lista). Sin `skip`/`only` (grep = 0). Todo **aditivo** sobre
el puerto 2.0: el driver gana solo dos métodos **opcionales** (`listDenies?`, `authorizeMany?`); las siete
primitivas viven en el manager como composición. Juez con nivel **`'2.1'`** (`ContractLevel`, `LEVEL_RANK`);
los dos harness del paquete pasan a `level: '2.1'`. Errores nuevos, todos con `status` + `code`. CHANGELOG
`[Unreleased] — 2.1.0`, sección "Lot 2B", una entrada por pieza. `package.json` sigue en `2.0.0-alpha.1`.

Sesión interrumpida por un fallo de conexión tras anotar el rojo de B1; reanudada sobre el árbol parcial
(`git diff` coherente, typecheck con el único error esperado de B1) sin rehacer nada.

## Conteo de tests por configuración

| Momento | `npm test` (SQLite) | `OPENFGA_TEST_URL=:8101` | tope 3 (`:8103`) |
|---|---|---|---|
| Baseline (`b126e20`, 2A) | 200 | 269 | 269 |
| B7 actor | 203 | 272 | — |
| B1 within | 205 | 276 | — |
| B4 + B2 (resolutor jerárquico, CTE) | 218 | 289 | — |
| B5 listDenies + effectivePermissions | 221 | 294 | — |
| B6 authorizeMany | 227 | 302 | — |
| B3 authorizedScopes | 231 | 309 | — |
| **Cierre (docs, stub)** | **231 ✅** | **309 ✅** | **309 ✅** |

`npm run typecheck` y `npm run typecheck:build` verdes; `check:purity` (reglas 1–3) verde en cada `npm test`
(`sql_descendants.ts` importa solo `@adonisjs/lucid/services/db`, errores, identidad y `backend_guard`; el
juez importa el manager, que no es un módulo opt-in vigilado por la regla 2). Casos del juez: **36 core /
49 en 2.0 / 57 en 2.1** (`contract_harness.spec` afirma `core ⊂ 2.0 ⊂ 2.1`). Los 13 casos nuevos del juez
pasan idénticos contra `database`, `openfga :8101` y `openfga` tope 3.

## Pieza × rojo observado × estado

| # | Pieza | Caso(s) escrito(s) | Fallo real observado en rojo | Estado |
|---|---|---|---|---|
| **B7** | `WriteOptions { actor? }` → `ScopedWriteOptions { within? }` → `GrantOptions { expiresAt? }`; `DenyOptions`; `revoke`/`removeDeny`/`scopes.attached/moved/detached` con `options?: WriteOptions`; `AuthzWriteEvent.actor?`; `#writeOptions` valida `actor` (`assertSubject`) y aplica `requireActor` ⇒ 422 `E_AUTHZ_ACTOR_REQUIRED` antes del driver y del hook; aviso `console.warn` **una vez por config** (`WeakSet`; `forRequest()` no lo repite) si `requireWithin`/`requireActor` no están en `true`, silenciable con `warnOnOptInSecurity: false`, y nombra solo los que faltan. | `manager.spec` grupo «manager — lote 2B (2.1)»: evento con `actor` en las 5 escrituras y sin él cuando no se pasa; `requireActor` ⇒ 422 en 7 escrituras con 0 llamadas al driver y 0 eventos; actor inválido/mayúsculas ⇒ 422 identidad; lecturas no exigen actor; aviso una vez / silenciado / parcial. | TS: `'actor' does not exist in type 'GrantOptions'`, `Expected 3 arguments, but got 4`, `'warnOnOptInSecurity' does not exist`, `'actor' does not exist on type 'AuthzWriteEvent'`. Ejecución: `expected [['granted', undefined]…] to deeply equal …`, `grant: debería haber rechazado: expected undefined to equal 422`, `expected [] to have a length of 1 but got +0`. Tras implementar, un fallo propio: el texto del aviso nombraba ambos flags aunque solo faltara uno (`expected … to not include 'requireWithin'`) ⇒ el mensaje se construye solo con los que faltan. | ✅ 203 / 272 |
| **B1** | `isWithin(inner, outer)` (= `outer ∈ chain(inner)`, inclusive; desconocido ⇒ `false`; resolutor **fresco** siempre); `#assertWithin` en `grant`/`deny`: scope desconocido ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE` (antes que la contención), `within ∉ chain` ⇒ 422 `E_AUTHZ_NOT_WITHIN`, `requireWithin` sin `within` ⇒ 422 `E_AUTHZ_WITHIN_REQUIRED`; todo antes del driver. `AuthorizationView` incluye `isWithin`. Juez: `ContractLevel` `'2.1'`, `LEVEL_RANK`, helper `managerOver(overrides)` que construye un `AuthorizationManager` sobre el driver del harness con `resolveAncestorsFrom(tree)` + `descendantsFrom(tree)`; `descendantsFrom` (nuevo en `scope_tree.ts`, desde `edges()`, exportado por `./testing`). | Juez `since('2.1')` ×2: «within: grant/deny dentro de la cadena escriben; fuera ⇒ 422 sin escribir; app y el propio scope contienen» (hermano, descendiente y raíz-bajo-org rechazados; `within` desconocido ⇒ 422; scope desconocido ⇒ UNKNOWN_SCOPE; 8 aserciones de `isWithin`); «requireWithin: true ⇒ … sin escribir; con el default siguen escribiendo» (`revoke`/`removeDeny` no lo exigen). | TS: `Property 'isWithin' does not exist on type 'AuthorizationManager'` (×8). Ejecución: 2 fallos — `assert.fail('debería haber rechazado')` en el grant sin `within` con `requireWithin: true` (**el grant fuera de la cadena pasaba**: E2 tal cual) y `authz.isWithin is not a function`. | ✅ 205 / 276 |
| **B4** | `src/hierarchical_resolver.ts`: `hierarchicalScopeResolver({ parentOf, maxDepth = 64 })` → `ScopeAncestorsResolver`. `parentOf → undefined` ⇒ `null` (también a mitad de cadena); `null` o `app` ⇒ termina en `APP_SCOPE`; visitados ⇒ 422 `E_AUTHZ_SCOPE_CYCLE`; `chain.length + 1 > maxDepth` ⇒ 500 `E_AUTHZ_SCOPE_TOO_DEEP` (nuevo) sin cadena corta; un throw de `parentOf` se propaga tal cual; `maxDepth` no entero ⇒ `TypeError` al construir. | `tests/hierarchical_resolver.spec.ts` (5): cadena de 3 ordenada y la raíz no se pregunta; `undefined` ⇒ `null`, hijo huérfano ⇒ `null`, padre `app` explícito; ciclo A→B→A y auto-padre ⇒ 422; 64 entera / 65 lanza / `maxDepth: 10` lanza / `maxDepth: 65` resuelve / `maxDepth: 0` TypeError; `parentOf` que lanza propaga el mismo objeto y a través de `DatabaseAuthorizationDriver` es 503 `E_AUTHZ_RESOLVER_FAILED`, y sano hereda de app. | `Cannot find module '../src/hierarchical_resolver.js'` (TS2307 y en ejecución). | ✅ (con B2) 218 / 289 |
| **B2** | `ScopeDescendantsResolver` en `types.ts`; `config.scopes.descendantsOf?`, `maxScopes?`, `maxDescendants?`. `src/sql_descendants.ts`: `sqlDescendantsOf({ table, uuidColumn, parentColumn, typeColumn \| scopeType, maxNodes?, connection?, timeoutMs? }, database = db)`: identificadores por regex (500 `E_AUTHZ_CONFIG` si no; nada más se interpola), exactamente uno de `typeColumn`/`scopeType`; dialecto por `connection.dialect.name` (`postgres`, `sqlite3`, `better-sqlite3`; otro ⇒ 500 `E_AUTHZ_UNSUPPORTED_DIALECT` en la primera llamada); existencia (`SELECT 1 … LIMIT 1`, `null` si no); UNA CTE `WITH RECURSIVE` con `LIMIT maxNodes + 1` y profundidad `< maxNodes + 1`; `> maxNodes` ⇒ 422 `E_AUTHZ_TOO_MANY_SCOPES`; uuid repetido ⇒ 422 `E_AUTHZ_SCOPE_CYCLE`; `rawQuery` vía `guardSql` (503 + deadline). Tabla ficticia `demo_scopes(uuid, type, parent_uuid)` en `tests/helpers/schema.ts` (`createDemoScopesTable`, la crea `bin/test.ts`). | `tests/sql_descendants.spec.ts` (8): subárbol entero (tipos y profundidad), `app` ⇒ todo, hoja ⇒ `[]`; desconocido/tipo que no casa ⇒ `null`; `maxNodes` 2 lanza, 3 entero (frontera), cota propia del helper, la consulta lleva `LIMIT`; ciclo X↔Y termina y lanza; `scopeType` fijo y config excluyente; identificadores inyectados rechazados; MySQL (`mysql`, `mysql2`) ⇒ 500 dialecto; tabla ausente ⇒ 503; toda consulta con `timeout` 1234. | `Cannot find module '../src/sql_descendants.js'`. Tras implementar, **un rojo real**: «un ciclo en la tabla … lanza» ⇒ `debería haber rechazado`: con `depth < maxNodes` un ciclo de dos nodos producía exactamente `maxNodes − 1` filas duplicadas (X, Y, X…) **en silencio**. Corregido: profundidad `< maxNodes + 1` (un ciclo alcanzable ⇒ ≥ `maxNodes + 1` filas ⇒ lanza) + cinturón de uuid repetido. | ✅ 218 / 289 |
| **B5** | Puerto: `DenyRef { permission, scope }`, `listDenies?(subject, scope?) → DenyRef[]`. `CatalogView.rolePermissions(slug, scopeType)` y `permissionSlug(uuid)`. `database.listDenies` (SQL + memo; scope exacto o todos; desconocidos fuera, D8). `openfga.listDenies` (`readAllTuples` de `deny_binding`, catálogo, scope, D8). Manager: `listDenies` (passthrough), `effectivePermissions` (cadena con el resolutor de lectura; `listRoles` por nivel × `rolePermissions` − `listDenies` por nivel; desconocido ⇒ `[]`), `#optional(driver, method, primitive)` ⇒ 500 `E_AUTHZ_UNSUPPORTED` (nuevo, nombra el método y el driver), `#catalogFor(driver)` (memo del driver si es `CatalogCache`, si no uno propio). | Juez ×2: «listDenies: directos vigentes del scope exacto o todos; fuera del catálogo no cuenta» (exacto sin herencia, `app`, otro sujeto, desconocido, sin scope con 4 pares, tras `removeDeny`); «effectivePermissions: unión de la cadena menos lo denegado; el orden no importa» (rol expirado no aporta, coherencia permiso a permiso con `authorize`, orden inverso, `removeDeny` restaura, desconocido ⇒ `[]`). `manager.spec`: driver sin `listDenies` ⇒ 500 `E_AUTHZ_UNSUPPORTED` con el nombre, sin llamar nada; `listRoles` sigue. | TS: `Property 'listDenies' does not exist on type 'AuthorizationDriver'` (×9), `'effectivePermissions' does not exist on 'AuthorizationManager'` (×9). Tras implementar, **rojo real**: `expected [] to deeply equal ['billing:read']` en `app` — `rolePermissions` devolvía vacío porque la clave de `roleByKey` lleva un separador **U+001F invisible** (`slug\x1Fscope_type`) que mi copia había perdido (y que explicaba un rechazo previo del sandbox por «control characters»). Corregido con `roleKey()` explícito (`\u001f` como escape). | ✅ 221 / 294 |
| **B6** | Puerto: `authorizeMany?(subject, permission, scopes) → boolean[]`. Manager: `authorizeMany` (identidad de todos antes de nada; vacío ⇒ `[]`; fuera de una vista abre una propia para memoizar; delega al driver o `Promise.all` de `authorize`). `openfga`: `checksFor()` extraído de `authorize` (mismo comportamiento 2A) y `authorizeMany` con UN `batchCheckAll` para todas las cadenas, atribución por posición dentro del lote correlacionado (L0.14), `error` ⇒ 503 entero (D1), desconocido/sin rol ⇒ `false` sin checks. | Juez: «authorizeMany: idéntico a N authorize por posición (duplicados, desconocidos, denegados); vacío ⇒ [] sin backend ni árbol; un scope que lanza ⇒ lanza entero» (Proxy sobre el driver + espía del árbol: 0 llamadas con `[]`; 503 entero; identidad inválida en cualquier posición ⇒ 422 sin tocar nada). `manager.spec`: composición sin `authorizeMany` (orden, `[]` con 0 llamadas, rechazo entero) y delegación con él. `openfga_driver.spec` grupo «authorizeMany en un solo batchCheck (2B · B6)» (3): 5 posiciones ⇒ 1 llamada con 14 checks y respuesta **desordenada** correlacionada; sin rol/`[]`/permiso desconocido ⇒ 0 llamadas; `error` en el 4.º check ⇒ 503. `spies.spec` (ambos drivers, servidor real): 20 posiciones/10 scopes ⇒ `openfga` 1 batchCheck, `database` 38 consultas; 10 llamadas al árbol (una por scope distinto); vacío ⇒ 0 y 0. | TS: `Property 'authorizeMany' does not exist on type 'AuthorizationManager'` (×13) y `…'OpenFgaAuthorizationDriver'` (×5). Ejecución: `authorizeMany is not a function` (juez, manager ×2, driver ×2), `expected undefined to equal 503`. Tras implementar, un ajuste de **factura** (no de semántica): `expected 38 to equal 40` en `database` — un scope denegado cuesta 1 consulta (el deny corta antes de las asignaciones); el espía declara `2n − denegados`. | ✅ 227 / 302 |
| **B3** | `AuthorizedScopes = none \| some{scopes} \| all{excludedSubtrees}`; `NoDescendantsResolverError` (500 `E_AUTHZ_NO_DESCENDANTS_RESOLVER`). Manager `authorizedScopes(subject, permission, scopeType, { maxScopes? })`: sin `descendantsOf` ⇒ 500 **antes de mirar nada**; cotas enteras ≥ 1 (si no, 500 `E_AUTHZ_CONFIG`); vista propia por llamada; `listScopes` ⇒ vacío ⇒ `none`; denies del permiso vía `listDenies(subject)`; raíz entre los directos ⇒ `all{excludedSubtrees: denies}` (nunca `all` a secas; > `maxScopes` ⇒ lanza); si no, candidatos = directos ∪ `descendantsOf` de cada uno, excluidos = denies ∈ candidatos ∪ sus subárboles, filtro por tipo; > `maxScopes` ⇒ 422 `E_AUTHZ_TOO_MANY_SCOPES`; vacío ⇒ `none`. `#descendants` clasifica como `resolveChain`: throw ⇒ 503 `E_AUTHZ_RESOLVER_FAILED`, no-array/scope mal formado ⇒ 503, `null` ⇒ nada debajo, > `maxNodes` ⇒ 422. `DEFAULT_MAX_SCOPES = 1000`, `DEFAULT_MAX_DESCENDANTS = 10000`. | Juez ×3 (los 7 del tester + invariante 7 + arquitectura): «all SOLO con excludedSubtrees; deny en app ⇒ none; sin grants ⇒ none» (`all{[]}`, `all{[orgB, unitA1]}` y `authorize(orgB)` false, otro permiso `all{[orgA]}`, deny en raíz ⇒ `none` y al quitarlo vuelve `all`, permiso desconocido ⇒ `none`); «some = directos del tipo ∪ descendientes … menos subárboles denegados; listScopes sigue sin enumerar» (unit bajo unit, grant directo de unit en org sin grant, deny excluye subárbol y un grant directo dentro de él, coherencia scope a scope con `authorize`, `removeDeny` restaura, tipo sin nodos ⇒ `none`); «maxScopes superado ⇒ 422 (nunca parcial), frontera exacta responde; sin descendantsOf ⇒ 500 aunque no haya grants; descendantsOf jamás se llama desde authorize/list*» (opción de llamada y config; espía: 0 llamadas en `authorize`, `authorizeMany`, `hasRole`, 4 `list*`, `effectivePermissions`, `listDenies`, `isWithin`, `grant{within}`, `deny`; > 0 en `authorizedScopes`). `manager.spec`: `descendantsOf` que ignora `maxNodes` ⇒ 422; el `maxNodes` recibido es `maxDescendants`; lanza ⇒ 503; `'no-es-un-array'`/`{app,'X'}`/`Unit` ⇒ 503; `null` ⇒ solo los directos; `maxScopes: 0` ⇒ 500 config; driver sin `listDenies` ⇒ 500 UNSUPPORTED. | TS: `Property 'authorizedScopes' does not exist on type 'AuthorizationManager'` (×28). Ejecución: `authorizedScopes is not a function` (×4). | ✅ 231 / 309 |
| **Docs** | CHANGELOG «Lot 2B» (7 entradas + higiene); README: sección **Primitives (2.1)** con ejemplos (`within`/`isWithin`, `actor`, `authorizeMany`, `effectivePermissions`, `authorizedScopes`) y **Scopes: ancestors and descendants** (`hierarchicalScopeResolver`, `sqlDescendantsOf`, cotas), `listDenies` en Queries, 9 filas nuevas en la tabla de errores, `level: '2.1'` y los métodos opcionales en «Custom drivers»; CLAUDE.md: invariante 7 con la excepción, mapa (manager, config, dos módulos nuevos, errores, juez, tests), roadmap 2B ✅; `stubs/config/authorization.stub`: comentario con `descendantsOf`/`requireWithin`/`requireActor` (los stubs siguen compilando: `configure.spec`). | — | ✅ |

## Desviaciones respecto a la especificación (con el porqué)

1. **B5 · `listDenies` devuelve `DenyRef[]` (`{ permission, scope }`) y admite `scope` opcional**, en vez
   de `(subject, scope) → string[]`. B3 necesita los **scopes** con deny de un permiso y B5 los
   **permisos** denegados en un scope: un solo método opcional del puerto sirve a ambas primitivas
   (regla 4: solo `listDenies?` y `authorizeMany?` entran al driver). Un `string[]` habría obligado a un
   segundo método opcional (`listDenyScopes`) o a enumerar denies con N llamadas.
2. **B2 · `descendantsOf` en el manager no toma el `maxNodes` de `maxScopes`** sino de una cota propia
   `scopes.maxDescendants` (default 10 000). Con la misma cota, una org con 100 units y `maxScopes: 5`
   sobre `organization` lanzaría aunque la respuesta tenga 1 elemento: `maxScopes` acota la **respuesta**,
   `maxDescendants` el **paseo del árbol**. Ambas lanzan `E_AUTHZ_TOO_MANY_SCOPES`.
3. **B2 · `sqlDescendantsOf` exige `typeColumn` o `scopeType`** (exactamente uno). La spec listaba
   `typeColumn?` sin decir de dónde sale el tipo cuando falta; un tipo fijo por tabla es la alternativa
   honesta (una tabla de un solo nivel). Y acepta un `database` inyectable como segundo parámetro: es la
   única forma de observar el rechazo de MySQL sin el harness multi-motor de 2.5.
4. **B3 · `all` también aplica `maxScopes` a `excludedSubtrees`** (no estaba en la spec): «nunca parcial»
   vale también para la lista de exclusiones; un consumidor con más denies que `maxScopes` sube la cota a
   sabiendas. Y `excludedSubtrees` **no se minimiza** (un deny anidado en otro subárbol excluido se lista
   también): restar de más es inocuo y calcular la contención costaría una cadena por deny.
5. **B3 · sin `descendantsOf` lanza 500 (`AuthorizationConfigError`-like), no 422.** Es el despliegue el que
   está incompleto (como `scopes.*` sin `resolveAncestors`, que ya es 500 `E_AUTHZ_CONFIG`), y debe saltar
   en el primer request de desarrollo. `E_AUTHZ_UNSUPPORTED` (driver sin método opcional) y
   `E_AUTHZ_UNSUPPORTED_DIALECT` son 500 por la misma razón. `E_AUTHZ_TOO_MANY_SCOPES` es 422 (la
   pregunta, tal como está, no se puede responder entera; se acota o se sube la cota). `E_AUTHZ_SCOPE_TOO_DEEP`
   (B4) es 500 y no 503: no es transitorio, no invita a reintentar.
6. **B4 · `maxDepth` cuenta la cadena devuelta (`app` incluida)**: 64 nodos ⇒ 63 ancestros + `app` = 64
   ⇒ entera; 65 ⇒ lanza. Es la lectura más simple de «profundidad 65 ⇒ lanza» y la que fija el test.
7. **B1 · el aviso de seguridad opt-in es una vez por *config* (WeakSet), no por proceso ni por
   instancia.** `forRequest()` construye managers hijos con la misma config y no debe repetirlo por request;
   dos configs distintas (dos managers de verdad) avisan cada una. El aviso nombra solo los flags que faltan.
8. **Juez · los casos 2.1 pasan por un `AuthorizationManager` sobre el driver del harness.** Las primitivas
   son composición, así que el juez no puede llamarlas en el driver; `managerOver()` las construye con el
   árbol del juez (`resolveAncestorsFrom` + `descendantsFrom`, este último derivado de `edges()`, lo único
   que `ContractScopeTree` exige: un harness con árbol propio no tiene que implementar nada nuevo). Un
   driver de terceros sin `listDenies` falla los casos de `effectivePermissions`/`authorizedScopes` con 500
   `E_AUTHZ_UNSUPPORTED` nombrando el método (verificado con un driver falso en `manager.spec`; en el juez no
   se puede quitar el método al driver del harness sin fingir).
9. **B7 · `actor` y `within` viajan también al driver en `grant`** (las opciones se pasan enteras): el
   driver los ignora. La firma del puerto no cambia; `deny` del driver sigue sin opciones.

## Hallazgos

- **Separadores U+001F literales en el código** (`catalog_cache.ts` clave de rol, `memoize_ancestors.ts`
  clave del memo). Invisibles en cualquier salida; una copia perdió el carácter y `rolePermissions`
  devolvió vacío (rojo real de B5). Ahora son escapes explícitos `\u001f` (`roleKey()`), como ya hacía
  `scope_tree.ts`; `grep -P "[\x00-\x1f]"` sobre `src`/`tests`/`index.ts` = 0. Sin cambio de comportamiento.
- **La CTE recursiva con cota de profundidad `< maxNodes` dejaba pasar un ciclo de 2 nodos en silencio**
  (`maxNodes − 1` filas duplicadas). El test del ciclo lo destapó en rojo; la cota `< maxNodes + 1` garantiza
  que cualquier ciclo alcanzable produzca más de `maxNodes` filas y lance. Segunda barrera: uuid repetido.
- **En `database`, `authorizeMany` de 20 posiciones cuesta 38 consultas, no 40**: un scope denegado corta
  en la primera consulta. Está declarado en el espía (`2n − denegados`), no tapado.
- **`authorizeMany` en `openfga` con respuesta desordenada** (el cliente falso invierte el `result`): la
  atribución por posición dentro del lote correlacionado es correcta (L0.14 en la práctica).
- **El artefacto `--files` de Japa**: filtrar `manager` arrastra `database_driver.spec` por un `import`
  dinámico de un test del catálogo y falla con «Cannot import japa test file directly». No aparece en la
  suite completa; no se tocó.
- **`descendantsFrom(tree)` recorre `edges()` entero por llamada**: O(aristas) por scope. Es el harness,
  no el paquete; el caso de arquitectura lo cuenta (0 llamadas fuera de `authorizedScopes`).
- Sin store huérfano tras las corridas contra `:8101` y `:8103`; `openfga-tiny` eliminado.

## Archivos

- **Nuevos**: `src/hierarchical_resolver.ts`, `src/sql_descendants.ts`, `tests/hierarchical_resolver.spec.ts`,
  `tests/sql_descendants.spec.ts`, `.claude/contexto/fase-2-lote-b-informe.md`.
- **`src/`**: `types.ts` (`WriteOptions`, `ScopedWriteOptions`, `GrantOptions extends`, `DenyOptions`,
  `AuthzWriteEvent.actor?`, `ScopeDescendantsResolver`, `AuthorizedScopes`, `DenyRef`, `listDenies?`,
  `authorizeMany?`), `errors.ts` (+9 clases), `define_config.ts` (`scopes.descendantsOf/maxScopes/maxDescendants`,
  `requireActor`, `requireWithin`, `warnOnOptInSecurity`), `manager.ts` (B1/B3/B5/B6/B7, `#optional`,
  `#catalogFor`, `#descendants`, `DEFAULT_MAX_*`, `AuthorizationView` ampliada), `catalog_cache.ts`
  (`rolePermissions`, `permissionSlug`, `roleKey`), `memoize_ancestors.ts` (escape explícito),
  `drivers/database_driver.ts` (`listDenies`), `drivers/openfga_driver.ts` (`checksFor`, `authorizeMany`,
  `listDenies`), `testing/contract.ts` (nivel `'2.1'`, `managerOver`, 13 casos), `testing/scope_tree.ts`
  (`descendantsFrom`), `testing/main.ts`.
- **Raíz**: `index.ts` (exporta los dos módulos, los errores y tipos nuevos, `DEFAULT_MAX_*`), `bin/test.ts`
  (`createDemoScopesTable`), `README.md`, `CHANGELOG.md`, `CLAUDE.md`, `stubs/config/authorization.stub`
  (comentario).
- **`tests/`**: `contract.spec.ts` (`level: '2.1'` ×2), `contract_harness.spec.ts` (36/49/57, `2.0 ⊂ 2.1`),
  `manager.spec.ts` (grupo «lote 2B» +7; `warnOnOptInSecurity: false` en los managers existentes),
  `openfga_driver.spec.ts` (+3), `spies.spec.ts` (+1 por driver, `factsPerAuthorizeMany`), `helpers/schema.ts`
  (`createDemoScopesTable`), `helpers/app.ts` (silencia el aviso).
