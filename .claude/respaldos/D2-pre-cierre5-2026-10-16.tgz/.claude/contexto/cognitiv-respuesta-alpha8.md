# Respuesta al paquete — alpha.8 recibida y verificada (11-09-2026)

Asunto: Re: alpha.8 — los tres bloqueantes cerrados por nuestra parte; respuesta a vuestra pregunta; `maxDepth` cuadra

Instalada `2.4.0-alpha.8` sobre `api-cognitiv` (suite completa verde, 832 casos, driver `database`). Contrastado
contra el build publicado, no contra el changelog:

1. **Raíz exenta.** Confirmado en `#changeKeys`, `earlierPending` y `laterApplied` (por referencia). Con esto L4
   (cutover) deja de estar condicionado. La variante B del tapón (solo la clave del hijo) es la que queríamos: un
   `moved(unit → orgA)` aparcado ya no congela la org destino.
2. **`requeue --apply`.** Entra en nuestro runbook tal cual: `authz:scopes:requeue --id=<n> --apply` cierra el
   incidente en una llamada; `--force` queda prohibido sobre `attached`/`moved` (solo `reconcile`). Las cuatro
   condiciones (lease único, barrera del freeze, excluyente con `force`, `only` = los ids reencolados) son las que
   necesitábamos; `busy` con cero filas es lo correcto.
3. **Edad de la cola.** Nuestro cron de relevo (60 s) alarma por `queue.pendingAgeMs` y el comando por
   `--max-age`; aparcar por tiempo no lo pedimos más: vuestra medida (censo de 50.000 aparcadas negando todas las
   pasadas) es concluyente.

**Vuestra pregunta — ¿devolvemos o logueamos el reporte del relay en la petición del tenant?** No. La costura
nunca devuelve el reporte. Hoy el 503 `authz.tree_not_relayed` lleva solo `pending` (cuántas claves NUESTRAS
quedaron sin aplicar) y `cause` (el `error` de NUESTRA entrada, recortado); con `only` (L2) la decisión se toma
solo con `entries` + `busy` + nuestro `applied_at`, y el `cause` sale sin ids. `queue.*`, `deadCount`, `dead[]`,
`remaining` y `failures` los lee únicamente el job de plataforma y van al log y a las alarmas, nunca por HTTP.
`deadDetail: 'full'` solo desde el comando/job.

**`maxDepth`: cuadra, es la misma cuenta.** Nuestro "N + 1" tenía N = niveles de unit bajo la organización
(raíz de units = 1, tope 18); vuestro N cuenta saltos desde `app`. La unit número 18 está a 19 saltos de `app`
(17 units + organización + app), así que declaramos `scopes.maxDepth: 19` (= `UNIT_TREE_MAX_DEPTH + 1`), que es
`chain.length > maxDepth` con la cadena del padre de 19 elementos. Lo fijamos con un caso en L2.

**Lo que adoptamos de alpha.8 desde el primer día de L2:** `sqlScopeOutbox({ requireTransaction: true })` (la
guardia estática nuestra ya exige `{ transaction }` en los seis llamantes; la vuestra es la red de verdad);
`entries[].origin` para distinguir `parked` sin leer prosa; `waitForLeaseMs` acotado (≤ 250 ms) en el relevo en
línea en vez de nuestro bucle de reintentos ante `busy`; `--max-age` en el cron.

**Para 2.5 (lo que anunciáis):** contamos con el `authz:reconcile` acotado por tenant/subárbol con `--dry-run`
(es lo que sustituye al supersede que pedimos) y con `requireTransaction: true` por defecto. Nada más pendiente por
nuestra parte sobre la outbox.

Nota al margen, por si os sirve como patrón: al subir a alpha.8 nos saltó un caso intermitente **nuestro**
(no vuestro): fechábamos intenciones con `Date` de JS (milisegundos) y los sellos con `clock_timestamp()`
(microsegundos); en el mismo milisegundo un sello anterior quedaba "posterior". Corregido atando el literal exacto
de la base en las comparaciones.
