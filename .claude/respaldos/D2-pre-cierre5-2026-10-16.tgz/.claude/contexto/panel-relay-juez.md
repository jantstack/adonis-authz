# Panel relay/outbox — JUEZ (2026-09-09)

Entrada: `cognitiv-informe-2026-09-09b.md` + `panel-relay-{analista,auditor,tester}.md`, sobre
`2.4.0-alpha.4` (`5547fa4`). No propongo opciones nuevas: puntúo las que hay, resuelvo las
contradicciones con la evidencia MEDIDA de cada informe y decido.

Lecturas propias de verificación (rápidas, para arbitrar tres puntos disputados):
`README.md:1020-1028` (el 22 está en PROSA, no en tabla), `src/scope_outbox.ts:89, 306-350`
(`localLeases` y el `name.slice(0, 64)` de MySQL), `tests/scope_outbox.spec.ts:1130-1177`
(qué fija exactamente el caso 1136 — **decide la cuestión 2**).

---

## Veredicto (30 segundos)

| # | Cuestión | Decisión | Puntuación de la ganadora |
|---|---|---|---|
| 1 | Recibo y filtro | **`only` = subconjunto de ids EN EL PUERTO + sonda de dependencia contra la cola ENTERA ⇒ `deferred`** (D). Sin filtro por tenant. | **92,5/100** |
| 2 | Aparcado / `requeue` | **503 no consume intento (por naturaleza del error) + lo aparcado vuelve a ORDENAR solo para `attached`/`moved` + `requeue` con sonda anti-reversión, `attempts = maxAttempts − 1`** | **83,5/100** |
| 3 | Lease | **No se toca.** Sigue siendo por PASADA. | **96/100** |
| 4 | `enumerateRelations` | **Declarar el límite en alpha.5; barrido único para K particiones en 2.5.** Prefijo: prohibido. | **92/100** (declarar) |
| 5 | Profundidad 22 | **Tabla de límites atada a la constante (alpha.5) + gate opt-in por CONFIG (`scopes.maxDepth`), declarado PARCIAL.** Canal `driver.limits`: 2.5, con el dueño. | **86,5/100** |
| 6 | Lo no pedido | Orden: **(1) aparcado [vivo hoy] → (2) `only` → (3) `runScopeOutboxContract` → (4) lease multiproceso + `GET_LOCK` 64 → (5) reporte por tenant**. | — |
| 7 | Versionado | **alpha.5** = R0, R2a, R1, R2b, R5, R6, R4. **2.5** = R3 y el canal `driver.limits`. | — |

**Condición para proceder (bloqueante, y es el hallazgo central de este panel):**
**R2a es PRERREQUISITO de R1.** La sonda de dependencia de `only` mira la cola de PENDIENTES; una
entrada APARCADA sale de `pending()` (`scope_outbox.ts:264`), así que sin R2a el `only` aplicaría
fuera de orden por la puerta del aparcado — el mismo 🔴 1 del auditor entrando por el 🟠 4. Si solo
cabe un lote en alpha.5, es R2a, no R1.

**Descalificado de entrada:** el `only` que filtra `pending()` sin sonda (🔴 1 del auditor, MEDIDO
contra el `:8101`: `authorize(A@orgA, docs:read, child) = true` con el reporte en verde), el
`requeue` sin sonda (🔴 2, MEDIDO: reversión del árbol con un solo padre), el `Read` por prefijo
(🔴 3, MEDIDO: 200 con cero tuplas) y —añadido por mí— **el statu quo de la cuestión 2**: el 🟠 4
del auditor produce *el árbol del store con el padre VIEJO de forma permanente*, que es
literalmente la «escalada persistente e invisible desde la base del consumidor» que el outbox
existe para evitar (`CLAUDE.md:509-512`). Lo trato como 🔴 del juez, no como 🟠: **está vivo hoy en
COGNITIV, sin ninguno de los cuatro cambios.**

---

## Criterios y pesos (declarados antes de puntuar)

Para las cuestiones 2-5, los del panel por defecto:
**Seguridad 30 · Compatibilidad con el contrato 25 · Verificabilidad 20 · Coste y deuda 15 ·
Reversibilidad 10.**

Para la cuestión 1 uso los que fija el encargo, con estos pesos:
**Seguridad (orden por clave / escritor único) 30 · Resuelve el problema REAL de COGNITIV 25 ·
No breaking para terceros 20 · Verificabilidad 15 · Coste medido 10.**

Regla aplicada: una afirmación sin archivo:línea, sin escenario reproducido o sin número vale
cero; un 🟡/❓ de un panelista es incertidumbre, no hecho; un 🔴 no mitigado descalifica.

---

## Cuestión 1 — Recibo del encolado y filtro del relay

### Opciones puntuadas

- **A** `only` = subconjunto que filtra `pending()`, tal cual lo pide COGNITIV (forma del analista
  §1(b) *sin* la sonda de §1(c)).
- **B** `only` filtra solo el REPORTE (mitigación mínima del auditor, 🔴 1).
- **C** PREFIJO por id: «aplica hasta mi id inclusive» (primitiva alternativa del auditor).
- **D** `only` = subconjunto **en el puerto** + **sonda de dependencia contra la cola entera**
  (pendientes *y* aparcadas) ⇒ `deferred` con causa. Síntesis: filtro del analista + condición
  (b)/(c) del auditor satisfecha por otra vía + caso 1b-3 del tester.

| Criterio (peso) | A | B | C | D | Nota |
|---|---|---|---|---|---|
| Seguridad (30) | **1** | 9 | 9 | **9** | A: escalada cruzada MEDIDA (`relay-auditor-2.ts`). D: la sonda (0,69 ms) aplaza el caso exacto del 🔴 1 |
| Resuelve el problema real (25) | 10 | **1** | 5 | **10** | B deja los 4 507 ms y la entrada propia sin aplicar (tester §1.2, medido). C no acorta: el prefijo hasta mi id = la cola entera |
| No breaking (20) | 9 | 10 | 10 | **9** | D: covarianza de `enqueue` + parámetro opcional de `pending` + guardia 500 si un tercero no lo honra |
| Verificabilidad (15) | 7 | 5 | 8 | **9** | 1b-3 (espía sobre `pending`) distingue D de B; 1c-1..1c-4 fijan la sonda y sus inversos |
| Coste medido (10) | 9 | 10 | 7 | **9** | D: sin columna nueva, sin migración; `pending` con `whereIn(id)` = 0,20 ms; sonda 0,69 ms |
| **Total** | **desc.** | **67** | **78,5** | **92,5** | |

### Resolución de la contradicción central del panel

El encargo pregunta si existe una opción que dé las dos cosas. **Sí, y es D**, por un argumento que
ninguno de los tres hace explícito:

> **La sonda de un nivel es equivalente al cierre transitivo.** Si una cadena de dependencias
> pendientes llega hasta mi entrada, su ÚLTIMO eslabón comparte clave de scope conmigo por
> definición de contaminación por clave (`CLAUDE.md:522`: «dos cambios que pueden interactuar
> comparten siempre un scope»). Luego preguntar «¿hay alguna entrada anterior no aplicada que toque
> alguna de MIS claves?» detecta toda cadena, sin leer las 500 filas ajenas.

Esto convierte la disyuntiva «leer `pending()` entero (4 507 ms) o romper el orden» en falsa: se
lee **una sonda de existencia** sobre la cola entera (0,69 ms medidos, índice `(applied_at, id)`) y
se aplica **solo lo mío** (0,20 ms de `whereIn`). El `blocked` no se «calcula sobre lo que la pasada
ve» (`manager.ts:1053`) sino sobre la cola, que es exactamente lo que el auditor exige en su
condición 1(b), obtenido sin pagar su coste.

Verificación contra los dos escenarios que el auditor MIDIÓ:
- `#1 moved(unit→orgB)` pendiente, `only:[2] attached(child, unit)` ⇒ comparten la clave `unit` ⇒
  **`deferred`**, cero llamadas al driver. El 🔴 1 queda cerrado, no mitigado a medias.
- `detached(#20)`/`attached(#21)` ajenos, `only:[21]` ⇒ comparten la clave del hijo ⇒ **`deferred`**.
  El DoS dirigido queda cerrado.

**Residual honesto:** `only:[20]` (la PRIMERA de un par ajeno) sí se aplica, porque en orden es
legal — es el mismo estado intermedio que produce cualquier pasada completa entre entrada y
entrada. El efecto es fail-CLOSED (invariantes 1 y 9: el subárbol desraizado no concede) y dura
hasta el siguiente relay. Lo acoto con la regla de plataforma, no con código.

### Decisión final (cuestión 1)

1. **Recibo.** `enqueue(...): Promise<void | { id }>` (covariante ⇒ un tercero que devuelva `void`
   compila y funciona) y `scopes.attached/moved/detached` ⇒ `Promise<ScopeEnqueueReceipt>` con
   `{ queued: Array<string|number> }` — **plural**, porque `scopes.detached` encola una fila por
   ORTOGRAFÍA (`manager.ts:~930`, invariante 17). Sin outbox, `{ queued: [] }` y el docblock dice
   «vacío = ya aplicado». Un tercero sin recibo deja `queued: []` y entonces `only` es **500
   nombrando el puerto**, jamás relevar la cola entera en silencio (1d-3 del tester).
2. **`only` llega al PUERTO**: `pending(limit, after, filter?: { ids })`. Si un tercero lo ignora y
   devuelve un id ∉ `only` ⇒ 500 `E_AUTHZ_CONFIG`, mismo patrón que el `markApplied` no honrado
   (`manager.ts:1084`). Filtro en memoria: **prohibido** (es la implementación que deja los 50 casos
   verdes sin resolver nada — tester §1.4).
3. **Sonda de dependencia obligatoria**, sobre pendientes **y aparcadas** anteriores que compartan
   clave ⇒ `deferred` con causa que nombra la clave y el id bloqueante. Nunca 422 (la pregunta no
   está mal formada) y nunca arrastre de dependencias (transitivo ⇒ la cola entera).
4. **`only: []` ⇒ 500 `E_AUTHZ_CONFIG`** (tester 1c-4 gana al «no-op» del analista: un array vacío
   por un `filter` del consumidor no puede acabar ni en drenaje ni en un reporte vacío en verde).
5. **`remaining` y `dead` se CALCULAN sin filtro** (analista (e): filtrarlos dio `remaining: false`
   con 500 pendientes — trampa medida) **y se REPORTAN como contador** cuando hay `only`
   (injerto del auditor 🟡 7: así el reporte deja de enumerar el movimiento de árbol de otros
   tenants aunque el consumidor lo devuelva por HTTP).
6. **`only` viene del RECIBO del propio proceso, jamás del cuerpo de la petición** (invariante 15
   por analogía con `within`). Esto responde por sí solo la pregunta abierta nº 1 del auditor: el
   relay inline **no** es «exponer el relay por HTTP» — el servidor llama a la API de plataforma con
   los ids que su propio código acaba de recibir. Un endpoint que acepte `only` del cuerpo es policy
   en una API sin policy, y va escrito en el docblock.
7. **Filtro por tenant/`organization`: CONFIRMADO descartado.** Los tres coinciden y el argumento
   decisivo es el del auditor 🟠 5, que es de CÓDIGO y no de opinión: `scopes.detached` soporta que
   la fila ya no exista (`manager.ts:926`), así que esa entrada no pertenece a ninguna organización
   — excluirla siempre es fail-open permanente (sus hechos no se purgan nunca, invariante 11) e
   incluirla siempre es «cualquiera relaya el `detached` de cualquiera». Y para `moved`, la cadena
   de HOY atribuye la entrada al DESTINO: el tenant relaya lo que trae cosas hacia él y deja sin
   aplicar lo que las saca — el sesgo que conserva accesos. La variante honesta del analista
   (`only: { scopes }` = claves exactas, sin descendientes) se aplaza a un segundo caso real.

**Injertos de las perdedoras:** de B, el reporte filtrado + `dead` como contador (🟡 7). De C, la
frase del README: si lo que quieres es «la cola aterrizada hasta aquí», la primitiva es el prefijo y
no el subconjunto — se documenta como receta operativa, no se implementa hasta que haya caso.

---

## Cuestión 2 — Aparcado, intentos y `requeue`

### Opciones puntuadas

- **A** statu quo + nota en el README (lo que COGNITIV pide literalmente: «no piden cambiar el default»).
- **B** flag del call-site (`relayScopeChanges({ countAttempts: false })`, plan B del analista).
- **C** por NATURALEZA del error: un 503 del backend no consume intento **+** las claves de `dead()`
  siembran `blocked` **solo para `attached`/`moved`** **+** `requeue` con sonda anti-reversión.
- **D** = C pero con `blocked` sembrado por `dead()` para **todas** las operaciones (🟠 4(b) del
  auditor, literal).

| Criterio (peso) | A | B | C | D | Nota |
|---|---|---|---|---|---|
| Seguridad (30) | **2** | 4 | **9** | 5 | A: desorden aplicado PERMANENTE, medido por los dos (auditor 🟠 4, tester §2.3). D: rompe la purga, ver abajo |
| Compat. contrato (25) | 6 | 7 | **8** | 4 | C cambia una semántica FIJADA (`spec.ts:1136`) y hay que desdoblarla; D la invierte entera |
| Verificabilidad (20) | 8 | 7 | **9** | 8 | C: 2-2b, 2-9a/2-9b, más el inverso «sin clave compartida avanza» |
| Coste y deuda (15) | 10 | 9 | **7** | 7 | C: tercer parámetro opcional en `markFailed` + sonda 0,33 ms; sin migración |
| Reversibilidad (10) | 10 | 8 | **8** | 8 | C es config/semántica, no datos |
| **Total** | **desc.** | 65 | **83,5** | 59,5 | |

### El contraejemplo que decide entre C y D (lectura propia de `spec.ts:1130-1177`)

El auditor pide sembrar `blocked` con las claves de `dead()`. **Leí el caso 1136 y su composición
refuta la versión literal**: la entrada aparcada es `attached(hijo, padre)` y la que avanza es
**`detached(padre)`** — una PURGA. Sembrar `blocked` con la clave del padre para todas las
operaciones dejaría esa purga sin aplicar para siempre: los hechos de un scope borrado siguen
concediendo. Eso es exactamente el fail-open que el invariante 11 cierra, y es peor que el desorden
que se quería evitar.

**Resolución:** el tapón por clave se aplica a lo que CONCEDE o recuelga (`attached`, `moved`) y
nunca a lo que RETIRA (`detached`). Es la misma doctrina del orden S6 y de la purga a medias: dejar
denies de MÁS, nunca de menos (`CLAUDE.md:90-93`). Con esa regla:

- 🟠 4 del auditor (`#2 attached(child, unitV)` tras aparcarse `#1 moved`) ⇒ **`deferred`**. Cerrado.
- §2.3 del tester (id1 `attached(H,P)` con id0 aparcado) ⇒ **`deferred`**. Cerrado.
- Caso 1136 (`detached(padre)` avanza) ⇒ **se conserva**. La convergencia no se pierde.

### Decisión final (cuestión 2)

1. **Un 503 del backend NO consume intento**, decidido por la **naturaleza del error**, no por flag
   del call-site (los dos panelistas coinciden y el argumento es correcto: la causa es la caída, que
   es común a todas las entradas, no una propiedad de la entrada). Forma: `markFailed(id, error,
   options?: { transient?: boolean })`; un tercero que ignore el tercer parámetro cuenta el intento
   = comportamiento de hoy (degrada hacia lo seguro). `last_error` se escribe SIEMPRE: nada se
   vuelve silencioso. El plan B (`countAttempts` en el call-site) queda descartado y escrito.
2. **Sí, se revierte parcialmente la decisión fijada en `scope_outbox.spec.ts:1136`**, y el caso se
   desdobla en dos: (a) lo aparcado **sigue reportándose en cada pasada** y **sigue sin volver a
   `pending()`** (converge); (b) lo aparcado **vuelve a contaminar su clave** para `attached`/`moved`
   y **no** para `detached`. Va al CHANGELOG con el porqué en el estilo de la casa (problema →
   decisión → qué NO se hace: no volvemos al tapón por COLA del 🔴 2 de 3b-2h; el tapón es por
   CLAVE, que es la diferencia que el propio auditor señala).
3. **`requeue`: sonda anti-reversión OBLIGATORIA, sin excepción por HTTP.** Se niega si existe una
   entrada APLICADA posterior que comparta clave de scope, nombrándola y remitiendo a
   `authz:reconcile --to=<driver>` (que es el remedio correcto: recalcula con el árbol de HOY).
   Coste 0,33 ms. **Dónde vive la sonda: en el MANAGER, no en `sqlScopeOutbox`** — necesita
   `#changeKeys` y, si vive en la implementación, un outbox de terceros no la tiene. `outbox.requeue?`
   queda mecánico (opcional en el puerto) y la política es del manager. Esto no lo dice ninguno de
   los tres y es lo que hace la garantía universal.
4. **`--force`: existe SOLO en el comando ace** (`authz:scopes:requeue --id=… --force`), imprime la
   entrada culpable y la reversión que causaría antes de pedir confirmación; **nunca** en una ruta
   alcanzable por HTTP, como `driver()` y `prune-orphans`. Sujeto a la pregunta 2 al dueño.
5. **`attempts` tras `requeue`: `maxAttempts − 1`, ni 0 ni conservado.** Aquí los dos panelistas se
   contradicen y los dos tienen media razón: el tester quiere conservarlo (para que una entrada
   irreparable reencolada no regale 5 pasadas de contaminación — caso 2-2b, medible) pero eso exige
   `requeued_at`/`requeues`, es decir **columna nueva y migración**, que el analista prohíbe con
   razón (el stub ya está desplegado en los consumidores) — y además `attempts` conservado a secas
   **no reencola nada**: `pending()` seguiría excluyéndola. `maxAttempts − 1` da la propiedad
   observable que el tester exige (vuelve a `dead` en UNA pasada si la causa sigue rota, entra a la
   primera si el operador la arregló) con **cero columnas nuevas**. El comando lo dice en su salida.
6. **Nota del README junto a la receta inline**, con los números medidos: 5 peticiones aparcan una
   entrada; en la petición N hay N−1 aplazadas por contaminación; y la frase que falta y es la
   importante: **«la pasada inline devuelve un reporte, NO lanza»** — un `failures`/`deferred` no
   aborta la petición si nadie lo mira (tester §2.1, analista).

**Injertos:** del auditor, el tapón por clave (acotado como arriba) y «nunca por HTTP». Del tester,
el caso 2-2b como juez de `attempts`, el 2-6 (una entrada YA APLICADA no revive jamás: reencolar un
`detached` aplicado vuelve a purgar) y el 2-3/2-4 (todo o nada, cero filas tocadas en silencio).

---

## Cuestión 3 — Lease

| Criterio (peso) | No tocar | Por lote | TTL/fence | Nota |
|---|---|---|---|---|
| Seguridad (30) | **10** | 3 | **1** | Por lote: 10 relays concurrentes pasan de 1 intento consumido a 10 (auditor, medido `busy=9`) |
| Compat. contrato (25) | **10** | 2 | 2 | `types.ts:1185` publica «cerrojo SOSTENIDO, no un TTL»: cambiarlo es **breaking del puerto** (tester §5.3) |
| Verificabilidad (20) | 8 | 5 | 4 | El 8 es con R6; hoy la garantía no está observada entre procesos |
| Coste y deuda (15) | **10** | 5 | 4 | |
| Reversibilidad (10) | **10** | 4 | 3 | |
| **Total** | **96** | 35,5 | **desc.** | |

**Decisión: no se toca.** Los tres coinciden y el argumento del analista es el que cierra: con lease
por lote, R1 suelta el lease tras contaminar `C`, R2 arranca con `blocked` vacío y `reparent`
**sustituye** la arista ⇒ el árbol queda con el padre viejo y una sola arista, sin nada que lo
delate (`openfga_driver.ts:1591-1700`). El lease por lote no es una versión barata del mismo
invariante: es otro invariante, más débil. Y el TTL/fence no existe aquí porque la escritura de
destino es una tupla de FGA, que no admite condición sobre un token de PostgreSQL.

**También descarto la tercera vía del tester (§5.4, `only` sin lease)**: la marca él mismo como
«probablemente» y no la corrió; sin lease, dos pasadas con `only` solapado re-aplican la misma
entrada y `reparent` revierte — es el 🟠 4 de 3b-2h por otra puerta. Con `only`, el lease dura 19 ms:
no hay problema que resolver. Sí adopto su caso **5-9** (censo de conexiones con pool N y K
peticiones), para que la respuesta a COGNITIV tenga número propio y no sea una extrapolación.

**Respuesta a COGNITIV, en una frase (con el número):**
> *El lease seguirá siendo por PASADA; lo que hay que acortar es la pasada, no el lease: con `only`
> la conexión extra se sostiene **19 ms** en vez de los **4 507 ms** que hoy cuesta una pasada con
> 500 entradas ajenas por delante (una pasada de una entrada es p50 13,3 ms / p95 17,0 ms, y
> `acquire()+release()` 0,56 ms), así que no bajen el pool por el lease — bájenlo, si acaso, después
> de medir con `only` puesto.*

---

## Cuestión 4 — `enumerateRelations`

| Criterio (peso) | Declarar límite | Barrido único K particiones | Prefijo | Índice en FGA | Índice en SQL |
|---|---|---|---|---|---|
| Seguridad (30) | 8 | 8 | **1** | 5 | **2** |
| Compat. contrato (25) | 10 | 9 | 3 | 7 | 3 |
| Verificabilidad (20) | 9 | 8 | 6 | 6 | 5 |
| Coste y deuda (15) | 10 | 6 | 8 | 4 | 3 |
| Reversibilidad (10) | 10 | 8 | 5 | 5 | 3 |
| **Total** | **92** | **79,5** | **desc.** | 55,5 | 40,5 |

**Prefijo: prohibido y escrito en el README.** Medido por los dos independientemente (analista: «200
con 0 tuplas»; auditor 🔴 3: `object prefijo → []`, `object solo tipo → validation_error`). El modo
de fallo es silencioso **en el ORIGEN de una migración**: `authz:reconcile` copiaría cero tuplas y
lo llamaría éxito, y una purga por partición «demostraría cero» sin haber borrado nada.

**Decisión:**
- **alpha.5**: se declara el límite, con los números medidos: *O(tuplas del despliegue) por partición
  y por llamada; 100 tuplas/página (tope DURO del servidor: `pageSize: 1000` ⇒ 400); 15 000 tuplas ⇒
  151 páginas ≈ 0,46-0,55 s, sea cual sea el tamaño de la partición; con K particiones, K × ese
  barrido*. Y la nota operativa del auditor 🟡 8: **que la operación no se dispare desde una petición
  de tenant** (cola/cron) — es README, no mecanismo, y se dice que es README.
- **2.5**: barrido único para K particiones (o honrar el cursor de verdad, que hoy se ignora). Es
  **método/opción NUEVA**, el actual se queda intacto ⇒ podría ser aditivo, pero lo mando a 2.5 por
  coste de verificación (siembra de ~500 tuplas contra el `:8090` para 3-1/3-2) y porque no está en
  el camino crítico de COGNITIV. Mejora medida: 3 particiones 1,4 s → 0,46 s; 50 particiones ~23 s →
  0,5 s.
- **Índice propio en FGA**: solo se documenta la condición de rentabilidad
  (`objetos_de_la_partición < tuplas_del_store / 100`) y el riesgo (deriva del índice = falsear el
  ORIGEN de una migración). No se implementa. **Índice en SQL: no se hace** (segunda fuente de verdad
  sin 2PC en el origen de un reconcile).
- **Cualquier alternativa debe fallar RUIDOSA si no puede enumerar exhaustivamente** (auditor,
  condición 4): nunca devolver menos sin decirlo.

**Injertos del tester (siguen valiendo aunque muera el prefijo):** el caso **3-3** (partición
`APP_SCOPE` = clave `app`, sin `|`, contra `appliance|<uuid>`: `document:app` es prefijo literal de
`document:appliance|…`) y el **3-6** (invariante 4 + las DOS ortografías del uuid,
`#partitionSpellings`) se escriben igual contra el barrido único, porque cualquier agrupación por
clave de partición tiene que comparar la clave ENTERA. Y el **3-1'** (doble de cliente con páginas
sintéticas) para que el caso de coste corra en `npm test` sin `OPENFGA_TEST_URL`: si el único caso
de coste vive tras un gate, la regresión entra en `main` sin que nadie la vea.

---

## Cuestión 5 — Profundidad 22

**Corrección al informe de COGNITIV, verificada por mí:** `FACTS_MAX_RESOLVE_DEPTH` **sí está en el
README** (`README.md:1020-1028`, § *The scope-chain depth ceiling (facts)*), en PROSA y dentro de
las notas de operación de OpenFGA. Lo que no existe es una **tabla de límites**, y el número no está
donde lee quien DISEÑA su árbol (§ «The scope tree»). Su observación es correcta en el fondo y no en
la letra; se les responde así, con la referencia.

| Criterio (peso) | Letra sola | Letra + gate por CONFIG | Letra + gate declarado por el DRIVER |
|---|---|---|---|
| Seguridad (30) | 6 | **9** | 9 |
| Compat. contrato (25) | **10** | 9 | 6 |
| Verificabilidad (20) | **9** | 8 | 5 |
| Coste y deuda (15) | **10** | 8 | 4 |
| Reversibilidad (10) | **10** | 9 | 6 |
| **Total** | 86 | **86,5** | 64 |

Empate técnico entre las dos primeras, y lo desempata que el gate ataja **también** el 🟡 9 del
auditor (medido: un `attached` cuesta 8,3 ms a profundidad 1 y 48,3 ms a 34 — ×5,8 de amplificación
que el vecino elige y que paga la cola compartida del relay). La tercera pierde por lo que mide el
tester: `capabilities()` normaliza con `=== true` y `capabilities.spec.ts:186` (D-3) afirma que
todas las claves conocidas son booleanas — un `maxScopeChainDepth: 22` saldría `false` de la lectura
publicada, y arrastra `AUTHORIZATION_DRIVER_CAPABILITY_KEYS`, el normalizador, D-3 y su gemelo de
relaciones.

**Decisión:**
1. **Tabla «Limits» en el README, alpha.5**, con el caso **4-2** del tester: el test importa
   `FACTS_MAX_RESOLVE_DEPTH` y afirma que ESE número está en la tabla (`assert.include(readme, …)`).
   Sin él, la tabla envejece a la primera medición nueva; con él, la letra es contrato. Entran
   también `FGA_MAX_BATCH_CHECK = 50`, `READ_PAGE_SIZE = 100`, `maxAttempts = 5`,
   `DEFAULT_RELAY_LIMIT`, `maxScopes = 1000`, `maxDescendants = 10 000`, `maxLocalRoles = 10 000`,
   los bytes del modelo y el O(store) de `enumerateRelations`. Más una línea en § «The scope tree»
   con enlace, que es donde falta.
2. **Gate opt-in por CONFIG (`scopes.maxDepth`), alpha.5.** 422 `E_AUTHZ_SCOPE_DEPTH_LIMIT` (código
   nuevo: `E_AUTHZ_SCOPE_TOO_DEEP` ya está tomado con 500 y otra semántica, `errors.ts:481`), en
   `attached`/`moved`, **antes de escribir o encolar** (caso 4-3: cero llamadas al driver **y cero
   filas en la outbox`). Coste de I/O **cero**: `#assertEdge` ya tiene la cadena completa del padre
   en la mano (`manager.ts:1741`), los saltos son `chain.length`. Por ser opt-in y del config, el
   caso 4-5 del tester (**el gate no aplica a `database`**) es trivial de satisfacer: si no lo pones,
   no existe.
3. **Se declara PARCIAL, en el README, con esas palabras**: no ve la altura del subárbol que se
   mueve (`moved` de un subárbol de altura h deja las hojas a `chain.length + h`) y calcularla exige
   `descendantsOf`, que está prohibido en el camino de escritura. Vender el gate como garantía sería
   una promesa falsa (analista, y lo suscribo).
4. **El aviso al 80 %** del auditor va en `authz:reconcile --dry-run`, no en el camino de escritura
   (donde sería ruido por petición): reconcile ya es read-only y ya camina el árbol, así que reporta
   como deriva las cadenas > techo. Es el caso 4-6 del tester.
5. **Canal `driver.limits?.maxScopeChainDepth`: 2.5 y decisión del dueño** (pregunta 3).

---

## Cuestión 6 — Lo que salió sin pedirlo, y su prioridad

Orden por «¿está vivo hoy?» → «¿es fail-dangerous?» → «¿bloquea a otro lote?» → coste.

| Prioridad | Hallazgo | De quién | Por qué ahí | Lote |
|---|---|---|---|---|
| **1** | El aparcado por conteo de pasadas y el desorden que produce | auditor 🟠 4 (+ tester §2.3) | **Vivo hoy en COGNITIV con relay inline, sin ningún cambio**; el resultado medido es el árbol del store con el padre viejo, permanente; y es **prerrequisito** de `only` | R2a |
| **2** | `only` en el puerto + sonda | los tres | Lo que COGNITIV pidió; ×237 medido; disuelve la cuestión 3 | R1 |
| **3** | `runScopeOutboxContract` en `/testing` | tester (su nº 1) | El puerto tiene **7 deberes** no triviales y el manager solo caza 2 en caliente; los lotes R1/R2 le añaden 3 más. Ampliar un puerto que nadie juzga es deuda con interés | R5 |
| **4** | Escritor único NO observado entre procesos + `GET_LOCK` a 64 chars | tester 🔴 | La garantía que sostiene toda la mitigación está sujeta por un caso que el mutante `localLeases` deja **verde en los cuatro motores** (verificado: `scope_outbox.ts:89`) | R6 |
| **5** | El reporte global enumera actividad de otros tenants | auditor 🟡 7 | Sale gratis dentro de R1 (reporte filtrado + `dead` como contador) | dentro de R1 |
| **6** | Coste por entrada ∝ profundidad del vecino | auditor 🟡 9 | Se ataja con el gate (R4) y con `only`; se declara | R0/R4 |

**Sobre el punto 3 (coste):** el tester estima 14-18 casos y lo pone primero; el analista no lo
menciona. Los concilio así: **los casos que juzgan lo NUEVO (recibo, `only` honrado, `dead` fuera de
`pending`, `requeue`, `acquire` sostenido) se escriben directamente dentro de
`runScopeOutboxContract` en vez de en `scope_outbox.spec.ts`**, y el lote R5 solo añade los deberes
ya existentes que faltan. Así el coste incremental es pequeño y no se escribe dos veces.

**Sobre el punto 4, un detalle que solo se ve leyendo el código** (`scope_outbox.ts:306, 329, 338`):
el nombre del lease es `authz_scope_outbox:<conexión>:<tabla>` y MySQL lo recorta con
`name.slice(0, 64)`. Dos despliegues que coincidan en los primeros 64 caracteres **comparten lease**
y se excluyen mutuamente para siempre — y el modo de fallo es `busy: true`, que **no lanza**: el
relay de uno de los dos no corre nunca y su ventana de deriva no se cierra jamás, en silencio. El fix
es un hash del nombre completo, pero **cambiar el nombre del lock tiene su propio riesgo de
despliegue**: durante un rolling deploy, un proceso con el nombre viejo y otro con el nuevo **no se
excluyen** ⇒ doble escritor ⇒ la reversión del árbol de 3b-2h. Así que el fix lleva obligatoriamente
una de estas dos cosas, y hay que elegir: (a) nota «no mezcles versiones del relay en el mismo
despliegue» en el CHANGELOG, o (b) una versión de transición que tome **los dos** locks (+0,56 ms).
Recomiendo (b): el paquete no puede pedirle a un consumidor que coordine su rolling.

---

## Cuestión 7 — Versionado y lotes

### `2.4.0-alpha.5`

| Orden | Lote | Qué entra | Dificultad | Breaking |
|---|---|---|---|---|
| 1 | **R2a** | 503 no consume intento (`markFailed(..., { transient })`); `dead()` siembra `blocked` por clave para `attached`/`moved` y **no** para `detached`; el caso 1136 desdoblado | media | no (semántica, al CHANGELOG) |
| 2 | **R1** | Recibo `{ queued: ids[] }`; `pending(limit, after, { ids })`; guardia 500 del `only` no honrado; sonda de dependencia ⇒ `deferred`; `only: []` ⇒ 500; `remaining`/`dead` globales pero reportados como contador | media | no (covarianza + parámetro opcional) |
| 3 | **R2b** | `requeue` con sonda anti-reversión **en el manager**; `attempts = maxAttempts − 1`; comando `authz:scopes:requeue --id` por el kernel de ace real; `--force` solo en el comando | media | no |
| 4 | **R5** | `runScopeOutboxContract` en `/testing` (los 7 deberes + los 3 nuevos) | media | no |
| 5 | **R6** | `relay_multiprocess.spec.ts` (5-2 pg/mysql, 5-4 sqlite-file con su «verde malo», 5-5 declarado en la cabecera); fix del `GET_LOCK` con transición de dos locks | media | no |
| 6 | **R4** | Tabla «Limits» + caso 4-2 atado a la constante; gate opt-in `scopes.maxDepth` ⇒ 422; deriva «cadena > techo» en `authz:reconcile --dry-run` | fácil | no |
| 0 | **R0** | Docs: los tres límites declarados, la nota de `maxAttempts` con los números, «la pasada inline devuelve reporte, no lanza», el prefijo prohibido con su porqué | trivial | no |

R0 se escribe con cada lote, no como lote suelto (cada frase tiene su caso de letra).

### `2.5`

- **R3**: `enumerateRelations` en un barrido para K particiones / cursor honrado, con 3-1, 3-1', 3-2,
  3-3, 3-6.
- **Canal `driver.limits`** para el techo de profundidad, si el dueño lo quiere (pregunta 3).
- **`Clock` inyectable en `relayScopeChanges`**: hoy el riesgo 🟠 del lag es **prosa sin caso**
  (tester §4) y `sqlScopeOutbox` ya acepta `now`; el manager no.

### Qué NO se hace (y queda escrito)

Lease por lote · lease con TTL/fence · `only` sin lease · filtro por tenant/`organization` · `only`
que arrastra sus dependencias · `Read` por prefijo, `pageSize > 100`, `Read` por tipo sin user ·
índice de particiones en SQL · columna nueva o migración de `authz_scope_outbox` · subir
`maxAttempts` como única respuesta · exponer `relayScopeChanges`/`requeue` por HTTP o aceptar `only`
del cuerpo · vender el gate de profundidad como garantía · `verify --fix`.

---

## Conflictos entre panelistas y cómo los resuelvo

1. **Analista («`only` filtra `pending()`, 19 ms») vs auditor (🔴 1: eso es escalada cruzada, medida)
   vs tester (1b-3: filtrar el reporte no acorta nada).** → **Los tres tienen razón sobre algo
   distinto y la síntesis existe**: filtro en el puerto (tester) + orden garantizado sin leer la cola
   (analista, con su sonda de 0,69 ms) = la condición (b) del auditor satisfecha por equivalencia
   transitiva. Carga de la prueba: el caso **1c-1** (el `only` que depende de una entrada no incluida
   ⇒ `deferred` y CERO llamadas al driver) reproduce el escenario exacto de `relay-auditor-2.ts`; si
   sale verde, el 🔴 1 está cerrado. Es el caso que hay que escribir primero del lote R1.
2. **Auditor (🟠 4(b): `dead()` siembra `blocked`) vs tester (eso está FIJADO como querido en
   `spec.ts:1136`).** → Resuelto por lectura propia del caso: 1136 fija que una **purga** avance, no
   que un `attached` avance. Se siembra `blocked` **solo para `attached`/`moved`**. Nadie pierde.
3. **Analista (`only: []` = no hacer nada) vs tester (`only: []` ⇒ 500).** → Gana el tester: el no-op
   devuelve un reporte vacío **en verde**, indistinguible de «todo aplicado». Coste del 500: cero.
4. **Tester (`attempts` conservado + `requeued_at`) vs analista (`attempts = 0`, sin migración).** →
   Ninguno: conservado a secas no reencola (sigue fuera de `pending()`) y `requeued_at` es columna
   nueva sobre un stub ya desplegado. **`maxAttempts − 1`** da la propiedad de 2-2b sin migración.
5. **Auditor (🟠 6: el lease por lote es incompatible con el cambio 1) vs tester (§5.3: el orden por
   clave no se rompe solo por soltar el lease, porque cada lote relee `pending()`).** → Es una
   contradicción **aparente y ya resuelta por ellos mismos**: el tester lo dice para un `pending()`
   sin filtrar y añade el entrelazado L-2, que sí rompe cuando hay una aparcada de por medio; el
   auditor habla de `pending()` filtrado. Ambos concluyen «no lo hagas». No hace falta arbitrar más:
   el lease no se toca por el contrato publicado (`types.ts:1185`), que es razón suficiente y previa.
6. **Auditor («`requeue` nunca por HTTP; `--force` con diff») vs analista («`--force` para el
   operador que sabe»).** → Compatibles: `--force` solo en el comando ace, con el diff impreso.
   Sujeto a la pregunta 2.
7. **COGNITIV («el 22 no está en el README») vs analista y tester («sí está, en prosa, ~línea
   1020»).** → Verificado por mí: `README.md:1020-1028`. Se les corrige con la referencia y se hace
   igualmente la tabla, que es lo que de verdad falta.

---

## Afirmaciones descartadas por falta de evidencia

- **Analista: «+1 conexión aguanta ~75 escrituras de árbol por segundo».** Es Little sobre 13,3 ms
  medidos, no una medida bajo carga. Vale como orden de magnitud, **no** como cifra para dimensionar
  el pool de COGNITIV. Sustituto: el caso **5-9** del tester (censo de `pg_stat_activity`), que da el
  número de verdad. No cambia ninguna decisión.
- **Auditor, 🟠 5, variante «`resolveChain` desfasado por réplica de lectura o caché»:** él mismo la
  marca 🟡 «razonamiento, no medida». No la cuento. El filtro por tenant se descarta igual por la
  parte **sí medida en código** (`manager.ts:924-936`, el `detached` de una fila borrada).
- **Auditor, bonus del 🔴 1 («ids autoincrementales, adivinables ⇒ un atacante elige qué entrada
  ajena se aplica»):** el hecho (ids autoincrementales) está verificado; la explotabilidad depende de
  que `only` llegue del cuerpo de la petición, que es su propia pregunta abierta nº 1 y que yo cierro
  por contrato (`only` viene del recibo, la API es de plataforma). Queda como **condición de diseño**,
  no como hallazgo vivo.
- **Tester, §5.4: «`only` sin lease… probablemente es la respuesta barata».** Marcado como
  probable y sin caso corrido. Descartado con razón técnica (re-aplicación concurrente + `reparent`
  que sustituye la arista), no por falta de fe.
- **COGNITIV: «`maxAttempts: 5` está dimensionado para job».** Cierto pero incompleto, y la parte que
  falta la miden los dos: con relay inline son **5 peticiones de CUALQUIERA**, no 5 ciclos de
  tiempo. Se les responde con el matiz.
- **Nadie lo afirma, pero conviene fijarlo:** que la sonda de dependencia de un nivel equivale al
  cierre transitivo es un argumento MÍO, no una medida. Su carga de la prueba es el caso **1c-2**
  (dos eslabones incluidos ⇒ se aplican en orden) y el segundo eslabón del aplazamiento que el
  auditor ya reprodujo (`spec.ts:1006`). Si ese caso sale rojo, la cuestión 1 vuelve a la opción C
  (prefijo).

---

## Riesgos que quedan aunque se implemente todo esto

1. **Un `dead` irreparable congela `attached`/`moved` de su clave hasta que un humano actúe.** Es el
   precio del tapón por clave. Acotado (no es la cola, que era el 🔴 2 de 3b-2h) y **ruidoso**
   (`deferred` + `dead` + exit ≠ 0), pero real: la ventana fail-open del `moved` de ese scope pasa de
   «segundos» a «hasta que alguien mire». Va literal en el README, junto a la salida
   (`authz:reconcile --to=…`).
2. **`only:<id ajeno legal-en-orden>` sigue siendo aplicable.** Fail-closed y transitorio, pero la
   defensa es de contrato (API de plataforma, `only` del recibo), no de código: el paquete no puede
   saber de quién es un id.
3. **El gate de profundidad no ve la altura del subárbol movido.** Declarado, no cerrado.
4. **El lag del relay sigue sin caso**: el riesgo 🟠 más publicitado del README es prosa hasta que
   haya `Clock` inyectable (2.5).
5. **`sqlite-file` no excluye entre procesos** y eso es correcto pero hay que fijarlo con el caso
   cuyo verde es el comportamiento malo (5-4), o se venderá como garantía.
6. **`enumerateRelations` sigue siendo O(store)** hasta 2.5, y a 1M de tuplas son ~35 s por
   operación (auditor, extrapolación desde 4/55/214 ms medidos — extrapolación, no medida).

---

## Lo que preguntaría al dueño antes de implementar (solo lo que cambia el veredicto)

1. **¿Se acepta desdoblar la decisión fijada en `tests/scope_outbox.spec.ts:1136?** Es decir: lo
   aparcado **sigue** sin volver a `pending()` y **sigue** reportándose, pero **vuelve a contaminar
   su clave** para `attached`/`moved` (no para `detached`). Es un cambio de semántica sobre un
   comportamiento que un panel anterior fijó a propósito, y es el prerrequisito de todo lo demás. Si
   la respuesta es no, la cuestión 1 baja a la opción C (prefijo) y COGNITIV se queda sin los 19 ms.
2. **¿`authz:scopes:requeue --force` existe?** Mi decisión es que sí, solo en el comando ace, con el
   diff de la reversión impreso y confirmación — nunca alcanzable por HTTP. Si prefiere que negarse
   sea absoluto, el único remedio de una entrada aparcada con posteriores aplicados pasa a ser
   `authz:reconcile --to=<driver>`, y hay que decirlo en la salida del comando.
3. **¿El techo de profundidad lo declara el driver (canal nuevo `driver.limits`, fuera de
   `capabilities`, que es booleana por doctrina) o el config del consumidor (`scopes.maxDepth`)?**
   He decidido config para alpha.5 para no bloquear el lote; si quiere el canal del driver, R4 se
   parte y la mitad que lo declara se va a 2.5 con `AUTHORIZATION_DRIVER_CAPABILITY_KEYS`, el
   normalizador, D-3 y su gemelo de relaciones en el diff.
