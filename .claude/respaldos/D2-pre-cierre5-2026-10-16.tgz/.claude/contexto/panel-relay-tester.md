# Panel 2.5 — relay/outbox · veredicto del TESTER

Fecha 2026-09-09 · árbol `main` `5547fa4` · `2.4.0-alpha.4`.
Alcance: las cuatro observaciones de COGNITIV (`cognitiv-informe-2026-09-09b.md`) + la pregunta del lease.
Yo no decido arquitectura ni seguridad: decido **si se puede observar**, con qué caso y a qué precio.
No he tocado `src/`, `commands/` ni `tests/`; los prototipos están en el scratchpad de la sesión.

## 0. Veredictos

| # | Cambio | Casos nuevos | Modos | Invariantes en riesgo | Coste | Veredicto |
|---|--------|--------------|-------|-----------------------|-------|-----------|
| 1 | Resultado por entrada + `only` | **11** | 4 motores × (con/sin FGA) | 6 (idempotencia del relevo), 9/(c2r) orden del árbol, contrato publicado del puerto | medio | **verificable con cambios** (el `only` mal colocado no arregla nada y hay caso que lo distingue) |
| 2 | `requeue(ids)` + comando + nota README | **9** | 4 motores; comando con kernel ace real | 11 (purga/orden S6), la garantía de ORDEN por clave | bajo-medio | **verificable con cambios** (hay que decidir `attempts` y el orden tras el requeue) |
| 3 | `enumerateRelations` acotado | **6** (2 coste + 4 corrección) | doble de cliente + `:8090` real | 4 (holders polimórficos ⇒ particiones que no se cruzan) | medio | **verificable** |
| 4 | Profundidad 22 en README (+ gate) | **2** letra + **4** gate | letra: todos; gate: `openfga`+`facts` | `AUTHORIZATION_DRIVER_CAPABILITY_KEYS` (D-3: todo booleano) | bajo (letra) / alto (gate) | letra **verificable**; gate **verificable con cambios** |
| 5 | Lease por lote | **5** (3 multiproceso + 2 tasa de intentos) | pg, mysql, sqlite-file (`:memory:` NO) | el CONTRATO publicado del lease en `types.ts` | alto (proceso hijo nuevo) | **verificable**, y hoy la garantía **no está observada de verdad** |

Dos hallazgos que van por delante de todo:

- 🔴 **El rojo de 1(b) está reproducido y medido** (§1.2). Con 500 entradas ajenas y `limit: 50`, la entrada propia
  no aparece en **ninguna** lista del reporte: `applied` no la trae, `failures: []`, `failed: null`,
  `deferred: 0`, `dead: 0`, `remaining: true`. COGNITIV tiene razón literal.
- 🔴 **Ya hoy, sin ningún cambio, el aparcado ROMPE el orden por clave** (§2.3, medido): una entrada aparcada sale
  de `pending()`, deja de contaminar, y sus dependientes se aplican **sin ella**. Está fijado como comportamiento
  deseado en `tests/scope_outbox.spec.ts:1136`. `requeue` reabre exactamente eso: reencolar la cabecera **después**
  de que sus dependientes se aplicaron produce un orden invertido. Es la decisión más cara del lote 2 y no está en
  la petición de COGNITIV.

## 0.1 Lo que corrí de verdad (no lo esperado)

```
npm test --files=tests/scope_outbox.spec.ts
  sqlite  (:memory:)          50 passed   180 ms
  sqlite-file                 50 passed
  pg      (postgres 18)       50 passed
  mysql   (mysql 8.4)         50 passed
  sqlite-file + OPENFGA_TEST_URL=http://127.0.0.1:8090   59 passed
```

(pg/mysql exigen `TEST_PG_URL`/`TEST_MYSQL_URL`: las credenciales por defecto del `bin/test.ts` no son las de
los contenedores de esta máquina. No es un fallo del paquete, pero conviene que el README de CI lo diga.)

---

## 1. Inventario: qué fija HOY `tests/scope_outbox.spec.ts`

50 casos en 12 grupos (59 con `OPENFGA_TEST_URL`). El harness es doble: **dobles en memoria** (`spyDriver`,
`recordingOutbox` + `queueFrom`, `memoryScopeTree`, `managerWith`, líneas 203-260) para las garantías del
algoritmo del relay, y **`sqlScopeOutbox()` sobre la base de la suite** (`cleanScopeOutbox`, `sqlScopeTree`)
para lo que depende del motor.

| Garantía del relay | Casos que la fijan hoy | Harness | Cobertura |
|---|---|---|---|
| **Escritor único (lease)** | `1283` dos pasadas a la vez ⇒ la 2ª `busy` y el cambio se aplica UNA vez; `1311` el lease se suelta si la pasada lanza; `1335` outbox sin `acquire` funciona igual | `sqlScopeOutbox()` real + `Promise.all` **en el MISMO proceso** | 🟡 in-process solamente — ver §5 |
| **Aplazamiento transitivo** | `897` el fallo aplaza lo que le toca y el resto avanza; `953` 1er eslabón; `1006` 2º eslabón (**lo APLAZADO contamina**, rama `collision`, no la del `catch`); `1050` caso negativo: sin clave compartida no contamina | dobles en memoria | ✅ completa, con inverso |
| **Aparcado (`dead`)** | `1103` agota `maxAttempts` ⇒ sale de `pending()` y entra en `dead()` con su causa; `1123` `maxAttempts` entero ≥ 1 ⇒ 500; `1136` se reporta en cada pasada y **lo que dependía de ella avanza** | `sqlScopeOutbox()` real | ✅ … y `1136` fija justo lo que §2.3 señala como riesgo |
| **Orden por clave / de encolado** | `443` los pendientes salen en orden de encolado con la identidad intacta; `680` aplica en orden attached→moved→detached, hechos primero y arista al final (S6); `1087` `pending(limit, after)` continúa tras un id | mixto | 🟡 el orden se fija **dentro de una pasada**; entre pasadas solo por `id` asc |
| **Reanudable** | `747` una falla ⇒ se marca y las siguientes siguen pendientes; `836` `limit` corta y lo que queda sigue | dobles | ✅ |
| **Anti-bucle** | `818` outbox que no marca lo aplicado ⇒ 500 `E_AUTHZ_CONFIG`; el `progress` break de `after` ignorado | dobles | ✅ |
| **Encolar ≠ escribir** | `262/279/324/350/370/393` (`attached`/`moved`/`detached` encolan, identidad canónica inv. 17, actor y `{transaction}` viajan, validaciones primero ⇒ cero encolado) | dobles + `memoryScopeTree` | ✅ |
| **El encolado va en la trx del consumidor** | `495` rollback ⇒ cero intención; `518` commit ⇒ queda; `543`/`589` trx de otra conexión o `db` entero ⇒ 500 `E_AUTHZ_CONFIG` y nada escrito | `sqlScopeOutbox()` real | ✅ los 4 motores |
| **Gate de construcción** | `78/91/96/103` (driver) + `139/163/171/185` (manager) | dobles | ✅ |
| **Letra del README** | `1906` los dos signos del lag; `1940` el ciclo NO acota la ventana | `readFile` + `include`/`notInclude` | ✅ patrón establecido |
| **dryRun / sin cola / comando** | `788`, `809`, `861`, `870` | dobles + lectura de `commands/main.ts` | 🟡 `861/870` leen el fichero, **no ejecutan** el comando: desde alpha.4 existe `tests/helpers/ace.ts` (kernel real) y este comando aún no pasa por él |

**Lo que NADIE fija hoy y es la raíz de las cuatro observaciones**: no hay **contrato publicado del puerto
`ScopeOutbox`**. `src/testing/main.ts` exporta `runAuthorizationDriverContract`, `runMigrationContract`,
`runRelationsDriverContract` y `runRelationsReconcileContract` — ninguno juzga una outbox. Todo lo de arriba
juzga `sqlScopeOutbox` o un doble ad-hoc de la propia suite; una implementación de terceros no tiene juez.

---

## 2. Por cambio

### Cambio 1 — Resultado por entrada + `only`

#### 1.1 (a) `enqueue` devuelve id estable y el reporte habla de ESA entrada

Ojo con un detalle que la petición de COGNITIV no menciona y que decide si el cambio sirve para nada:
**`manager.scopes.attached/moved/detached` devuelven `Promise<void>`** (`src/manager.ts:836`, y sus dos
hermanas). Que `enqueue` devuelva un id no basta: el id tiene que salir por ahí, o el consumidor no lo ve.

| id | Caso (dado → cuando → entonces) | Fichero | Harness | Aserción | Rojo hoy | Mutante que mata |
|----|---|---|---|---|---|---|
| **1a-1** | dado outbox con recibo → cuando `scopes.attached(U, A)` → entonces devuelve un id **no vacío** y `sqlScopeOutbox` tiene esa fila con ese `id` | `scope_outbox.spec.ts` | `sqlScopeOutbox()` real, 4 motores | `assert.isDefined(receipt.id)`; `select … where id = receipt.id` trae `op='attached'` | ✅ `undefined` | devolver el `rowCount` en vez del PK |
| **1a-2** | dado ese id → cuando `relayScopeChanges({ only: [id] })` y el driver acepta → entonces `applied` trae **esa** entrada, `deferred/failures/dead` vacíos, `remaining` refleja el resto | ídem | ídem | `applied.map(a=>a.id)` deepEqual `[id]` | ✅ no existe `only` | `only` que se ignora ⇒ `applied` trae las 50 viejas |
| **1a-3** | mismo id, driver que lanza → entonces `failures[0].id === id` **y** `failed === failures[0]` **y** `attempts` subió en la fila | ídem | ídem | tres aserciones | ✅ | `markFailed` sin `increment` |
| **1a-4** | mismo id, la entrada agotó `maxAttempts` → entonces sale en `dead` con **su** id y su `lastError`, y `applied` vacío | ídem | `maxAttempts: 2` | `dead.map(d=>d.id)` | ✅ | `dead()` que ignora el `only` |
| **1a-5** | id **estable**: dos pasadas seguidas sobre la misma entrada fallida ⇒ el MISMO id en las dos | ídem | ídem | igualdad estricta | 🟡 | id derivado del índice del lote |

**Nota de identidad (borde, y el que se olvida siempre)**: el id de `sqlScopeOutbox` es un `bigint`
autoincremental; en MySQL y PG llega como `number` o `string` según driver. El caso 1a-1 tiene que afirmar
que **el id que devuelve `enqueue` y el que devuelve `pending()` son intercambiables como clave de `only`**
(`String(a) === String(b)` no basta: `only` va a comparar). Sin este caso, `only` con un id numérico contra
una fila que vuelve como string es un no-op silencioso — el peor de los fallos posibles aquí.

#### 1.2 (b) EL ROJO: backlog ajeno + `limit` pequeño

**Reproducido**, prototipo `scratchpad/rojo_1b.ts` (500 `attached` de otro tenant + el mío al final, `limit: 50`):

```json
{ "miId": 500, "applied": 50, "failures": [], "failed": null,
  "deferred": 0, "dead": 0, "remaining": true, "busy": false,
  "miaAplicada": false, "miaEnAlgunaLista": false, "driverVioLaMia": false }
```

El reporte es *correcto* y a la vez *inútil*: nada distingue «tu cambio se aplicó» de «tu cambio ni se miró».
El workaround que cita COGNITIV (comparar `applied[].change`) exige comparar `ScopeRef`s a mano y **no funciona
con dos cambios iguales encolados dos veces**.

| id | Caso | Aserción | Rojo |
|----|---|---|---|
| **1b-1** | dado 500 entradas ajenas y la propia al final, `limit: 50`, **sin** `only` → el reporte **dice por entrada** que la propia sigue pendiente | el reporte trae la propia en una lista **nombrada** (`remaining`/`notAttempted`/como se llame) con su id | ✅ (arriba) |
| **1b-2** | mismo escenario **con** `only: [mío]` → la propia se **aplica**, y `applied` es exactamente `[mío]` | `applied.map(a=>a.id)` deepEqual `[mío]`; el driver vio **1** llamada | ✅ |
| **1b-3** 🔑 | **el caso que distingue las dos implementaciones de `only`**: espía sobre `outbox.pending` contando filas devueltas → con `only`, el relay **no** puede haber leído las 500 ajenas | `spy.rowsRead <= K` (K pequeño y declarado) | — |

**1b-3 es el caso decisivo del cambio 1.** Si `only` se implementa como filtro **del reporte** (leer `pending(limit)`
y filtrar en memoria), con backlog de 500 y `limit: 50` la entrada propia **sigue sin aplicarse** y COGNITIV está
igual que hoy, con un reporte más bonito. `only` tiene que llegar al **puerto** — `pending(limit, after, { ids })`
o un `byIds(ids)` nuevo — o no arregla nada. Sin 1b-3, el lote se puede cerrar en verde sin haber resuelto el problema.

#### 1.3 (c) `only` y el aplazamiento transitivo — el fail-open que introduce

Éste es el riesgo real del cambio 1, y no está en la petición.

Hoy el aplazamiento vive en un `Set` **en memoria de la pasada** (`blocked`, `manager.ts:1050`), que se llena
**solo con lo que la pasada VE**. Con `only`, las entradas anteriores no se leen ⇒ `blocked` queda vacío ⇒
una entrada `only` que depende de otra no incluida **se aplica fuera de orden**. Aplicar `moved(H, orgB)`
sin el `attached(H, P)` que le precede escribe en el store un árbol que nunca existió; con (c2r) eso no es
fail-closed, es *otro* árbol.

| id | Caso | Aserción | Mutante |
|----|---|---|---|
| **1c-1** | dado id3 `attached(H,P)` pendiente y id7 `moved(H,orgB)` → cuando `relay({ only: [id7] })` → entonces id7 sale en **`deferred`** con causa que **nombra la clave y el id bloqueante**, y el driver recibe **CERO** llamadas | `deferred[0].id===id7`; `include(error, keyOf(H))`; `deepEqual(calls, [])` | `only` que aplica sin mirar predecesores |
| **1c-2** | mismo escenario con `only: [id3, id7]` → los dos se aplican **en orden** (`id3` antes que `id7`) | `calls` deepEqual `[attached H→P, moved H→orgB]` | orden por posición del array `only` en vez de por id |
| **1c-3** | inverso (el que debe seguir permitido): id7 `moved(H,orgB)` y un id3 pendiente **sin clave compartida** → `only:[id7]` **aplica** | `applied` = `[id7]` | un `only` demasiado conservador que aplaza todo |
| **1c-4** | borde: `only: []` ⇒ 500 `E_AUTHZ_CONFIG` (no «drena todo»), `only` con un id inexistente ⇒ error nombrando el id, jamás un reporte vacío en verde | `rejects` con `code` | `only` inexistente ⇒ `applied: []` silencioso |

`1c-4` no es tiquismiquis: `only: []` interpretado como «sin filtro» convierte un bug del consumidor
(array vacío por un `filter`) en un drenaje completo bajo el lease de una petición HTTP.

#### 1.4 (d) Compatibilidad de terceros y el contrato del puerto

**No hay contrato publicado de `ScopeOutbox`.** Verificado: `src/testing/main.ts` no exporta nada de outbox.

| id | Caso | Aserción |
|----|---|---|
| **1d-1** | dado un outbox de terceros con `enqueue: async () => {}` (sin recibo) y **sin** el método de filtro → cuando `scopes.attached` → entonces **sigue funcionando** y el recibo es `undefined` (nunca un id inventado) | `isUndefined(receipt)`; la cola tiene la entrada |
| **1d-2** | ese mismo outbox → `relayScopeChanges()` **sin** `only` se comporta exactamente como hoy (los 50 casos actuales siguen verdes) | la suite entera |
| **1d-3** | ese mismo outbox → `relayScopeChanges({ only: [...] })` ⇒ **500 declarado** nombrando el método que falta, **cero** llamadas al driver — jamás un filtrado en memoria silencioso que aplique lo más viejo | `rejects({status:500})`; `deepEqual(calls, [])` |

**Recomendación firme: sí, hay que publicar `runScopeOutboxContract` en `/testing`.** Justificación de tester,
no de gusto: el puerto tiene ya **siete** deberes no triviales que hoy solo cumple la implementación del paquete
—`enqueue` dentro de la trx del llamante; orden por antigüedad; `after` como continuación; `markApplied`
idempotente; `markFailed` que cuenta el intento y no pierde la fila; `dead()` que NO devuelve lo aparcado por
`pending()`; `acquire()` **sostenido**, sin TTL— y el manager solo caza dos de ellos en caliente (el bucle
infinito, `manager.ts:1085`, y el `progress` break). Los otros cinco los rompe un tercero en silencio.
Coste estimado: **14-18 casos** parametrizados por harness (`makeOutbox()` + `cleanup()`), reutilizando el
esqueleto de `relations_contract.ts`. Es el lote con mejor relación defecto-cazado/coste de todo el panel.

**Invariantes en riesgo (cambio 1)**: invariante 6 (una escritura es una escritura — `only` que aplica un
`detached` sin su predecesor); invariante 9/(c2r) (el árbol del store deja de ser un árbol que existió);
el contrato de `ScopeOutbox.pending` publicado en `types.ts:1152` («los pendientes MÁS ANTIGUOS primero»)
si `only` los reordena. **Coste: medio** — 11 casos, sin infra nueva salvo el espía de `pending`.

---

### Cambio 2 — `requeue(ids)` + comando + nota del README

#### 2.1 La medida que pide el encargo: ¿cuántas peticiones aparcan una entrada?

Prototipo `scratchpad/medida_2.ts`, `maxAttempts: 5`, relay inline al final de cada petición, store caído todo
el rato, tráfico normal (cada petición encola su propio `attached`):

| petición | `attempts` de la 1ª | `failures` | `deferred` | `dead` | ¿aparcada? |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 0 | — | no |
| 2 | 2 | 1 | 1 | — | no |
| 3 | 3 | 1 | 2 | — | no |
| 4 | 4 | 1 | 3 | — | no |
| 5 | **5** | 1 | 4 | — | no (`dead()` se lee al **principio** de la pasada) |
| 6 | 5 | 1 | 4 | `[0]` | **sí** |

**Respuesta: 5 peticiones.** Y sale peor de lo que COGNITIV describe: en la petición N hay **N-1** entradas
aplazadas por contaminación, así que una caída del store de 5 peticiones —segundos— aparca la cabecera y
contamina **toda** la cola detrás. Además `relayScopeChanges` **no lanza**: las 6 peticiones devuelven 200 con
el árbol sin propagar. El consumidor no se entera por la vía del error, solo por el reporte que hoy no sabe leer
(cambio 1). Los dos lotes son el mismo problema.

#### 2.2 Casos de `requeue`

| id | Caso | Fichero | Harness | Aserción | Rojo | Mutante |
|----|---|---|---|---|---|---|
| **2-1** | dado una entrada aparcada (`attempts >= maxAttempts`) → cuando `outbox.requeue([id])` → entonces vuelve a salir por `pending()` y **desaparece de `dead()`** | `scope_outbox.spec.ts` | `sqlScopeOutbox({maxAttempts:2})`, 4 motores | `pending(10)` la trae; `dead(10)` no | ✅ | `requeue` que solo borra `last_error` |
| **2-2** | `attempts` tras el requeue (**decisión abajo**) | ídem | ídem | valor exacto | ✅ | — |
| **2-3** | id **inexistente** ⇒ error claro nombrando el id; **cero** filas tocadas | ídem | espía de UPDATE / `count(*)` antes-después | `rejects` + censo | ✅ | `where id in (…)` que afecta 0 filas y calla |
| **2-4** | id **no aparcado** (pendiente vivo, o ya aplicado) ⇒ error claro **por id**, y los demás del lote **no** se aplican a medias | ídem | lote mixto `[aparcado, aplicado]` | todo o nada, y lo dice | ✅ | requeue parcial silencioso |
| **2-5** | idempotencia: `requeue([id])` dos veces ⇒ la segunda es no-op segura o error, **nunca** `attempts` negativos ni una fila aplicada revivida | ídem | ídem | — | ✅ | `decrement('attempts', N)` |
| **2-6** | **una entrada YA APLICADA no revive jamás** (`applied_at` no nulo) — es el borde peligroso: reencolar un `detached` aplicado vuelve a purgar | ídem | ídem | `rejects`; el driver no recibe `purgeScope` | ✅ | `requeue` que solo mira `attempts` |
| **2-7** | comando `authz:scopes:requeue --id=…` por el **kernel de ace real** (`tests/helpers/ace.ts`): sale 0 y lo dice; sin `--id` ⇒ error, no «requeue todo» | `commands.spec.ts` | `AceHarness` | `cmd.error`/`exitCode`/`logs` | ✅ | comando sin `--id` que reencola la cola entera |
| **2-8** | letra del README: la nota de `maxAttempts` **junto a** la receta del relay inline, con el número medido | `scope_outbox.spec.ts` grupo de letra | `readFile` | `include` de la frase y de «5» | ✅ | — |
| **2-9** | **orden tras el requeue** — ver 2.3 | ídem | dobles | — | ✅ | — |

**`attempts` a 0 o conservado — propuesta del tester: conservarlo y añadir `requeued_at`/`requeues`.**
Motivo observable: con `attempts` a 0, un operador que reencola una entrada **irreparable** (el padre se borró
y no va a volver) le regala otras 5 pasadas de contaminación a toda la cola detrás (§2.1: cada pasada aplaza
N-1). Con `attempts` conservado la entrada vuelve, se intenta **una** vez y se vuelve a aparcar, que es
exactamente el comportamiento que el operador quiere si arregló la causa (entra) y el que quiere si no la
arregló (no hace daño). El caso que separa las dos opciones: **2-2b** — dado una entrada aparcada cuya causa
**sigue** rota, `requeue` + 1 pasada ⇒ con `attempts` conservado vuelve a `dead` en **una** pasada y `deferred`
tiene 0 entradas de más; con `attempts: 0` tarda 5 pasadas y contamina en las cinco. Es medible y es la razón.
Si el dueño prefiere 0, que sea explícito y que el comando lo diga en su salida.

#### 2.3 🔴 El agujero de ORDEN que `requeue` reabre (medido)

Prototipo `scratchpad/medida_2.ts`, bloque B. Cola: id0 `attached(padre, org)` (irreparable), id1 `attached(hijo, padre)`.

- Pasadas 1-5: id0 falla, id1 se aplaza. Correcto.
- **Pasada 6**: id0 se aparca ⇒ sale de `pending()` ⇒ deja de contaminar ⇒ **id1 se aplica solo**.
  El driver ve `attached hijo → padre` **sin** que `padre` esté colgado. (Fijado hoy en `scope_outbox.spec.ts:1136`
  como comportamiento querido, y con (c2r) es fail-CLOSED: el hijo no alcanza la raíz y no concede nada.)
- **Tras `requeue(id0)`** y arreglada la causa, el driver ve:
  `[attached hijo→padre, attached padre→org]` — **orden invertido**.

Para `attached` converge (las dos aristas acaban escritas). Para una cola con un `moved` o un `detached`
intercalado **no converge**: el `detached` de un nodo que aún no existe en el store, o un `moved` aplicado
antes de su `attached`, dejan el store en un estado que ninguna pasada posterior arregla — y eso es
invariante 11 (la purga con demostración de cero) juzgada sobre un nodo que el store no tiene.

| id | Caso | Aserción |
|----|---|---|
| **2-9a** | dado id0 `attached(P,org)` aparcado, id1 `moved(H,P)` **ya aplicado** → cuando `requeue([id0])` + pasada → entonces el relay **avisa** de que reencola una entrada **anterior** a hechos ya aplicados que comparten clave (o lo rechaza), jamás lo aplica en silencio | `logs`/reporte nombra la clave y el id posterior aplicado |
| **2-9b** | inverso: reencolar una aparcada cuyos posteriores **no** comparten clave ⇒ se aplica sin ruido | `applied` = `[id0]`, sin avisos |

Sin 2-9a, `requeue` es una herramienta de operador que reescribe el árbol del store en un orden que nunca
existió. Es el punto que le llevaría al arquitecto.

**Invariantes en riesgo (cambio 2)**: 11 (purga y su orden S6), y la garantía de orden por clave del relay
—que hoy la suite fija solo *dentro* de una pasada—. **Coste: bajo-medio**; el único harness nuevo es el
kernel de ace, que ya existe desde alpha.4.

---

### Cambio 3 — `enumerateRelations` O(store) → acotado a la partición

Estado actual verificado: `src/drivers/openfga_relations_driver.ts:610-621` hace `#readAll('enumerateRelations', {})`
—`Read` sin filtro— y descarta en JS lo que no es de la partición. `#readAll` pagina con `READ_PAGE_SIZE = 100`
(línea 85), así que el coste observable es **`ceil(tuplas_del_store / 100)` llamadas `read`**, sea cual sea el
tamaño de la partición pedida.

#### 3.1 Casos de COSTE

`tests/helpers/fga_spy.ts` sirve tal cual: cuenta cada método del cliente por nombre, así que
`spy.calls.filter(c => c === 'read').length` **es** el número de páginas pedidas al servidor.

| id | Caso | Fichero | Harness | Aserción | Rojo hoy |
|----|---|---|---|---|---|
| **3-1** | dado 20 tuplas en la partición A y 480 en B (mismo store) → cuando `enumerateRelations(A)` → entonces el nº de `read` **no depende de B**: `<= 2` | `relations_openfga.spec.ts` (gate `OPENFGA_TEST_URL`) | store real `:8090` + `spyFgaClient` | `readCalls <= 2` y `tuples.length === 20` | ✅ hoy son **5** |
| **3-2** | control del propio caso: con B **vacío** el nº de `read` es el mismo que en 3-1 | ídem | ídem | igualdad | — |
| **3-1'** | **la versión barata**, sin servidor: doble de cliente FGA que devuelve páginas sintéticas de 100 y cuenta las peticiones | `relations_openfga.spec.ts` sin gate | doble + `spyFgaClient` sobre el doble | idem | ✅ |

3-1' existe para que el caso corra en `npm test` a secas: si el único caso de coste está detrás de
`OPENFGA_TEST_URL`, una regresión de rendimiento entra en `main` sin que nadie lo vea. Y 3-2 no es adorno:
sin el control, `readCalls <= 2` pasa también con una implementación que se limita a **truncar**.

#### 3.2 Casos de CORRECCIÓN que la mejora por prefijo NO puede romper

El id es `<objectType>:<scopeKey(partición)>|<objectUuid>` (`#objectId`, línea 302) y el parseo canónico corta
por el **último** `|` (`#parseObjectId`, línea 347). Un filtro por prefijo **no** tiene esa propiedad. Tres
adversarios concretos:

| id | Caso (dado → cuando → entonces) | Por qué duele |
|----|---|---|
| **3-3** 🔑 | dado partición `APP_SCOPE` (clave `app`, **sin** `|`) y partición `{type:'appliance', uuid}` (clave `appliance|<uuid>`) con tuplas en las dos → cuando `enumerateRelations(APP_SCOPE)` → entonces **solo** las de `app` | `document:app` es prefijo literal de `document:appliance|…`. La raíz es la partición sin separador: es el único caso donde el prefijo no está cerrado por `|` |
| **3-4** | dado dos tipos de scope donde uno es prefijo del otro (`org` / `organization`) con el **mismo** uuid → `enumerateRelations({type:'org', uuid})` no trae las de `organization` | `document:org` prefijo de `document:organization|…` |
| **3-5** | dado dos tipos de **objeto** donde uno es prefijo del otro (`doc` / `document`) en la misma partición → cada `Read` por tipo trae solo el suyo | si la mejora es «un `Read` por tipo declarado», el tipo se compara entero, no por prefijo |
| **3-6** | invariante 4 sobre esto: mismo uuid, **distinto tipo** de partición ⇒ jamás se cruzan — y las **dos ortografías** del uuid (32 hex y 8-4-4-4-12, `#partitionSpellings`) siguen llegando las dos | la mejora por prefijo es justo donde se pierde una de las dos ortografías |

**3-3 es el caso que mata a la implementación ingenua**, y es el que escribiría primero: es realista
(`app` es una partición legítima) y el fallo es *contaminación entre tenants en una enumeración que alimenta
`authz:reconcile`* — es decir, una migración que se lleva tuplas ajenas.

**Invariantes en riesgo**: 4 (holders polimórficos / particiones que no se cruzan) y el contrato de
`enumerateRelations` como ORIGEN exhaustivo de `authz:reconcile` (`types.ts`, y la caducada que tiene que
llegar para contarse en `skipped.expired`, invariante 3). **Coste: medio** — 3-1/3-2 necesitan sembrar ~500
tuplas contra `:8090` (unos segundos con `writeTuples` en lotes); 3-3..3-6 son baratos.

---

### Cambio 4 — Profundidad 22

#### 4.1 Estado real (mejor de lo que dice el informe)

La cota **sí está medida contra el servidor**, y bien: `tests/openfga_facts.spec.ts:3398-3535` fija que a 22
saltos resuelve **siempre** (500 repeticiones por lado), que a 23 deja de resolver de forma fiable y que a 24
falla — con su caso negativo de 503 (nunca `false`, invariante 5) y una aserción que **detecta si el servidor
cambia de `--resolve-node-limit`**. Es de lo mejor de la suite.

Lo que falta es solo la **letra**: el README lo explica en prosa (§ *The scope-chain depth ceiling (facts)*,
~línea 1020) pero **no existe ninguna tabla de límites declarados** en el README (`## Performance`, `## Driver
options` y `## Errors` no la tienen). Así que el cambio 4 no es «añadir una fila», es «crear la tabla».

| id | Caso | Fichero | Aserción | Mutante |
|----|---|---|---|---|
| **4-1** | el README trae una tabla de límites declarados que incluye **22** con su nombre (`FACTS_MAX_RESOLVE_DEPTH`), su alcance (`openfga` + `facts`, **no** `database`) y su síntoma (503, nunca `false`) | grupo de letra en `scope_outbox.spec.ts` o `scope_edges_docs.spec.ts` | `include` de las cuatro piezas | bajar el número en el código y dejar el README |
| **4-2** 🔑 | **la tabla y el código no se pueden separar**: el caso importa `FACTS_MAX_RESOLVE_DEPTH` y afirma que **ese número** está en la tabla | `assert.include(readme, \`| ${FACTS_MAX_RESOLVE_DEPTH} |\`)` | cambiar la constante sin tocar el README ⇒ rojo |

4-2 es la diferencia entre documentación y contrato: sin él, la tabla envejece a la primera medición nueva.
Y la tabla debería traer también los otros límites que hoy solo viven en prosa o en CLAUDE.md:
`FGA_MAX_BATCH_CHECK = 50`, `READ_PAGE_SIZE = 100`, `maxAttempts = 5`, `DEFAULT_RELAY_LIMIT`,
`maxLocalRoles = 10 000`, `MAX_SCOPE_BOUND`. Un límite no documentado es una sorpresa en producción; los seis
en la misma tabla cuestan lo mismo que uno.

#### 4.2 El gate (si se añade) — y por qué es caro

| id | Caso | Aserción | Riesgo |
|----|---|---|---|
| **4-3** | dado un árbol de 23 saltos → cuando `scopes.attached` del nodo 23 → entonces 422/aviso **ANTES** de escribir o encolar: cero llamadas al driver **y cero filas en la outbox** | `deepEqual(calls, [])` + `count(*)` de la cola | — |
| **4-4** | borde exacto: **22 entra** | `applied` | un `>=` por un `>` |
| **4-5** 🔑 | **el gate NO aplica con el driver `database`**: el mismo árbol de 23 es legal ahí | `attached` pasa | un gate en el manager que rompe a los consumidores de `database` |
| **4-6** | `authz:reconcile` avisa de las cadenas que exceden **sin abortar la migración** (o abortando, si es la decisión — pero fijado) | `drift`/salida del comando | — |

**Invariante en riesgo, concreto**: si el gate se apoya en `capabilities()`, hay que meter un número donde hoy
todo es booleano. `capabilities()` normaliza con `=== true` y `tests/capabilities.spec.ts:186` (**D-3**) afirma
que *ninguna clave es `undefined`* y que todas las claves conocidas son `false` — un `maxScopeChainDepth: 22`
saldría **`false`** de la lectura publicada. El cambio 4 con gate arrastra, por tanto: `AuthorizationDriverCapabilities`,
`AUTHORIZATION_DRIVER_CAPABILITY_KEYS`, el normalizador, D-3 y su gemelo de relaciones. **Coste alto**, y es
una decisión de arquitectura, no mía. **Letra sola: coste bajo, 2 casos, verificable ya.**

---

### Cambio 5 — Lease por lote

#### 5.1 Cómo se observa HOY el escritor único (y por qué no basta)

Un solo caso: `scope_outbox.spec.ts:1283`, `Promise.all` de dos `relayScopeChanges()` **en el mismo proceso**,
con un `onScopeAttached` que duerme 60 ms y la segunda pasada arrancando 10 ms después. Afirma `busy: true`
en la segunda y que el driver vio el cambio **una** vez.

El agujero no hace falta mutarlo para verlo: **en `npm test` (sqlite `:memory:`, el modo por defecto y el de CI)
ese caso pasa por la rama `localLeases`** — un `Set` de módulo (`scope_outbox.ts:89`), no un cerrojo de servidor.
Y en pg/mysql, aunque sí toma `pg_try_advisory_xact_lock`/`GET_LOCK`, **las dos pasadas comparten proceso**, así
que el `Set` de módulo también las excluiría. Conclusión: el mutante «sustituir el advisory lock por
`localLeases` en todos los dialectos» deja **verde** el caso 1283 en los cuatro motores. Es literalmente el
mutante `modulo` que `freeze_multiprocess.spec.ts` documenta y mata para el freeze, y aquí no está muerto.

🟡 **La garantía «el relay es escritor ÚNICO» (3b-2h · 🟠 4) no está observada donde importa: entre procesos.**
Y es la garantía que sostiene toda la mitigación, porque el escenario que la motiva —dos réplicas, un
`CronJob` con `concurrencyPolicy: Allow`— es multiproceso por definición.

#### 5.2 El caso multiproceso (patrón `freeze_multiprocess.spec.ts`)

Nuevo `tests/helpers/relay_child.ts` + `tests/relay_multiprocess.spec.ts`. Determinista, **sin `sleep`**: el
padre toma el lease a mano y *después* lanza al hijo (misma receta que el freeze: congelar antes de `execFileSync`).

| id | Caso | Gate por motor | Aserción | Mutante que mata |
|----|---|---|---|---|
| **5-1** | control: sin lease tomado, el hijo releva y aplica | pg, mysql, sqlite-file | `applied.length === 1` | — |
| **5-2** 🔑 | dado el padre con `outbox.acquire()` **sostenido** → cuando el hijo `relayScopeChanges()` → entonces `busy: true`, `applied: []` y **cero** escrituras en el store | **pg, mysql** | reporte del hijo + censo del store | `localLeases` en vez del advisory lock |
| **5-3** | soltado el lease, el hijo entra y aplica | pg, mysql | `applied.length === 1` | `release()` que no revierte la trx (PG) / no llama `release_lock` (MySQL) |
| **5-4** ⚠️ | **el caso que fija la advertencia del README**: en `sqlite-file` el hijo **SÍ** aplica pese al lease del padre — el cerrojo es de PROCESO y por eso SQLite no vale para dos réplicas del relay | **sqlite-file** | `applied.length === 1` **y** el README lo dice con esas palabras | borrar la advertencia del README |
| **5-5** | `:memory:` no puede observar nada de esto y va **declarado** en la cabecera del fichero, como en `freeze_multiprocess.spec.ts` | — | — | — |

5-4 es un caso cuyo «verde» es el comportamiento *malo*: fija una limitación conocida para que no se venda
como garantía. Es exactamente el patrón que ya usa el repo con el lag del relay.

#### 5.3 El lease POR LOTE: lo que rompe y el entrelazado adversario

**Primero, el hecho incómodo: el lease por lote contradice un contrato PUBLICADO.** `src/types.ts:1185`,
docblock de `acquire`, dice literalmente: *«CONTRATO: el lease se toma UNA vez al inicio de la pasada y se
sostiene hasta el `finally`; el relay NO lo re-verifica ni lo renueva dentro del bucle […] la implementación
DEBE ser un cerrojo SOSTENIDO mientras dura la pasada, no un TTL que pueda vencer a mitad: los que trae el
paquete lo cumplen»*. Cambiarlo a por-lote es **breaking del puerto** para cualquier tercero que haya
implementado `acquire` leyendo ese párrafo, y hay que tratarlo como tal (caso de letra + CHANGELOG), no como
una optimización interna.

**Segundo, la buena noticia medida**: el orden por clave **no** se rompe por el simple hecho de soltar el lease
entre lotes, porque cada lote **relee `pending()`** y la contaminación se reconstruye desde la cabecera de la
cola en cada pasada. Lo que sí se rompe es otra cosa, y es observable:

**Entrelazado adversario L-1 (la tasa de intentos).** Con lease por lote y **R** pasadas alternando lotes, la
misma entrada fallida recibe **R** `markFailed` por unidad de tiempo en vez de 1 ⇒ **`maxAttempts` se agota R
veces más rápido** ⇒ se aparca antes ⇒ y una vez aparcada, §2.3 (medido): **sus dependientes se aplican fuera
de orden**. El lease por lote no rompe el orden *directamente*: acelera el camino que ya lo rompe hoy.

| id | Caso | Harness | Aserción | Rojo esperado |
|----|---|---|---|---|
| **5-6** 🔑 | dado id0 irreparable e id1 dependiente, `maxAttempts: 5`, **dos** pasadas alternando lotes (lease por lote) → entonces id0 se aparca en **≤3** pasadas de cada una en vez de 5, e id1 se aplica sin su padre antes | dobles + outbox con lease por lote | contar pasadas hasta `dead` y el orden de `calls` | con lease por pasada: 5 y 5 |
| **5-7** | el mismo entrelazado **sin** lease por lote (control) | ídem | 5 pasadas | — |

**Entrelazado adversario L-2 (el que hay que descartar explícitamente).** `after` sobrevive al lote dentro de
una pasada (`manager.ts`, `let after`), mientras que `blocked`/`parked` son estado de la pasada. Con lease por
lote, entre el lote k y el k+1 de P1 entra P2 con `after: undefined` y `blocked` vacío. Caso:

- Cola: id1 `attached(P, orgA)`, id2 `attached(H, P)`, id3 `moved(H, orgB)`; `batchSize: 1`.
- P1 lote1: id1 **falla** (store lento) → `blocked = {P, orgA}`, `after = id1`, **suelta el lease**.
- P2 entra: lote1 → `pending(1)` → id1 (sigue pendiente) → vuelve a fallar → contamina. Se salva.
- **Pero** si id1 se aparcó (por L-1), P2 lee id2 con `blocked` vacío y lo aplica; luego P1 reanuda con
  `after = id1` y aplica id3. Resultado: `attached H→P` y `moved H→orgB` escritos **sin** `attached P→orgA`.

| id | Caso | Aserción |
|----|---|---|
| **5-8** | el entrelazado L-2 completo, con la aparcada de por medio → el store **no** contiene `H` bajo `orgB` sin `P` bajo `orgA`, o el reporte lo **dice** | censo del store (`:8090`) + reporte de las dos pasadas |

5-8 es el caso que decide si el lease por lote es aceptable. Si sale rojo, la respuesta a COGNITIV es: el lease
por lote exige que `after` **no** cruce la frontera del lote (reset por lote) o que `blocked` se materialice en
la cola, y las dos cosas son cambios del puerto, no del bucle.

#### 5.4 Y la pregunta operativa que COGNITIV hace de verdad

Su problema no es el orden: es que **cada petición de escritura de árbol sostiene una conexión extra** mientras
dura la pasada (`acquire()` abre una transacción que no escribe nada, `scope_outbox.ts:314`). Eso es medible sin
tocar el diseño:

| id | Caso | Aserción |
|----|---|---|
| **5-9** | dado pool N, K peticiones concurrentes con relay inline → entonces las conexiones en uso durante la pasada son K (lease) + K (trabajo), y con pool < 2K hay espera | censo de `db.manager` / `pg_stat_activity`, patrón de `pool_concurrency.spec.ts` |

Con ese número, la respuesta al consumidor deja de ser una opinión. Y hay una tercera opción que ningún caso
del panel contempla y que a ellos les vale igual: **`relayScopeChanges({ only })` sin lease** — si la pasada
solo toca *mi* entrada, la exclusión que hace falta es por entrada, no por cola. El caso que lo fija sería
5-10: dos pasadas concurrentes con `only` **disjuntos** ⇒ las dos aplican, ninguna dice `busy`; con `only`
**solapado** ⇒ una de las dos ve la entrada ya aplicada y no la re-aplica. Eso conecta el cambio 5 con el
cambio 1 y probablemente es la respuesta barata.

---

## 3. Verificabilidad por backend

| backend / modo | 1 (`only`) | 2 (`requeue`) | 3 (`enumerate`) | 4 (letra / gate) | 5 (lease) |
|---|---|---|---|---|---|
| `sqlite` `:memory:` (default, CI) | ✅ mismo test | ✅ | ✅ (doble 3-1') | ✅ / n/a | ❌ **no observable** (proceso único; el lease es un `Set` de módulo) |
| `sqlite-file` | ✅ | ✅ | ✅ | ✅ / n/a | ⚠️ observable **al revés** (5-4: el doble escritor ocurre, y está bien que ocurra) |
| `pg` | ✅ | ✅ ojo con `bigint` como string | ✅ | ✅ / n/a | ✅ advisory lock **de servidor**: es el motor del caso 5-2 |
| `mysql` | ✅ | ✅ | ✅ | ✅ / n/a | ✅ `GET_LOCK` de sesión; ojo: el nombre se recorta a 64 chars (`scope_outbox.ts:329`) — **falta un caso** de dos tablas cuyos nombres colisionen tras el recorte |
| driver `database` | ✅ | ✅ | n/a | 4-5 (**el gate no debe aplicar**) | ✅ |
| driver `openfga` + `facts` (`:8090`/`:8101`) | ✅ y es donde duele | ✅ | ✅ único sitio real | ✅ | ✅ |
| outbox de **terceros** | 1d-1..3 | ❌ `requeue` es opcional ⇒ hace falta capacidad + caso | n/a | n/a | ❌ sin contrato publicado nadie juzga su `acquire` |

**Riesgo específico que solo aparece en un motor**, para que no se pierda: el recorte a 64 caracteres del
nombre del `GET_LOCK` en MySQL (`name.slice(0, 64)`). Dos despliegues con tablas de outbox distintas cuyos
nombres coincidan en los primeros 64 caracteres del string
`authz_scope_outbox:<conexión>:<tabla>` **comparten lease** y se bloquean mutuamente para siempre. Es un caso
de 5 líneas y hoy no existe.

---

## 4. Lo NO verificable con la infraestructura actual

| Qué | Por qué | Qué haría falta |
|---|---|---|
| El escritor único **entre procesos** en `npm test` a secas | `:memory:` es del proceso; el lease cae a `localLeases` | Ya cubierto por el gate por motor de 5-2/5-4 — pero hay que **declararlo en la cabecera del fichero**, como hace `freeze_multiprocess.spec.ts`, o CI verde miente |
| El lag del relay como **ventana temporal** (cuántos ms concede de más un `moved` sin relevar) | No hay reloj inyectable en el camino del relay; medirlo con `sleep` sería flaky | Un `Clock` inyectable en `relayScopeChanges` (hoy `sqlScopeOutbox` ya acepta `now`, el manager no). Sin eso, el riesgo 🟠 del README es **prosa sin caso** |
| Que un outbox de terceros cumpla los 7 deberes del puerto | No hay `runScopeOutboxContract` | Publicarlo en `/testing` (§1.4). Es mi recomendación nº 1 del panel |
| La **cota real** de `--resolve-node-limit` del servidor del cliente | Se mide contra el `:8090`/`:8101` de aquí; el suyo puede tener otra | Ya está bien resuelto: `openfga_facts.spec.ts:3507` **detecta** que el servidor cambió de cota. Documentar esa señal en el README junto a la tabla de límites (4-1) |
| Coste de `enumerateRelations` en un store de producción (millones de tuplas) | Sembrar eso en CI no es viable | 3-1/3-2 miden la **forma** del coste (independiente del backlog), no la magnitud. Es lo correcto y hay que decirlo así en el caso |
| Que `requeue` de un operador no pise una pasada del relay en curso | `requeue` escribiría la cola **sin** el lease | Caso 2-10 (no listado arriba, lo añado aquí): `requeue` durante una pasada con el lease tomado ⇒ o toma el lease, o el reporte de la pasada en curso no cuenta esa entrada como suya. Hoy no hay forma de expresarlo |

---

## 5. Orden de ataque que propongo

1. **`runScopeOutboxContract` en `/testing`** (14-18 casos). Sin él, los cuatro cambios amplían un puerto que
   nadie juzga. Mejor relación defecto/coste del panel.
2. **1b-3 + 1c-1** (2 casos). Son los que impiden cerrar el cambio 1 en verde sin haberlo resuelto.
3. **5-2 y 5-4** (multiproceso, pg/mysql/sqlite-file). Cierran el punto ciego que hoy deja verde el mutante
   `modulo` en el lease.
4. **2-9a** (el orden que `requeue` reabre) y la decisión sobre `attempts`, con 2-2b como juez.
5. **3-3** (partición `app` vs `appliance`), antes de escribir una sola línea de la mejora por prefijo.
6. **4-1/4-2** (letra + la tabla atada a la constante). Coste bajo, valor inmediato para COGNITIV.

**Lo que NO acepto como cobertura de ninguno de los cinco**: «lo probamos a mano contra el `:8101`», y
«los 50 casos actuales siguen verdes» — los 50 siguen verdes con `only` implementado como filtro de reporte,
que es justamente la implementación que no arregla nada.
