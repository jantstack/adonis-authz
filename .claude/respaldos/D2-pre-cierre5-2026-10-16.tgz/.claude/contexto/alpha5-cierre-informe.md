# `2.4.0-alpha.5` — lote de CIERRE (auditor: `alpha5-auditor.md`, NO APTA por 🟠 1 y 🟠 2) · INCREMENTAL

**Base:** el árbol de los lotes I + II (sin commitear), **1271 / 1297 / 1392 / 1394** con el `:8101`. Sin commits, sin
subir `version`, nada reabierto fuera de lo pedido. `$S` = `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`.

## 1 · ROJO = las repros del auditor, tal cual

`$S/a5C_red_repro7.log`: «[G] CON un attached pendiente entre medias: detached ⇒ deferred/depends-on:4 … ¿purgó?: NO».
`$S/a5C_red_repro9.log`: «[I] 101 aparcadas · relay({ only, limit: 1 }) ⇒ applied/ … cuelga del padre VIEJO».
Casos nuevos en `tests/scope_outbox.spec.ts` (grupos «alpha.5 · CIERRE», 7 casos) + O-08 en el contrato: `$S/a5C_red.log`
= 5 rojos / 90 verdes (los dos controles ya en verde).

## 2 · Qué cambia

| Fichero | Qué |
|---|---|
| `src/manager.ts` | **🟠 1**: `blocked` pasa de `Map<key, id>` a `Map<key, { id, parked }>` con `block(key, id, parked)` (un fallo real pisa a un bloqueo por aparcado, nunca al revés); `defer(…, byParked)` propaga el ORIGEN; la colisión ignora, para `detached`, los bloqueos de origen aparcado. **🟠 2**: `PARKED_CENSUS_MAX = 50_000` (exportada); `#parkedKeys(outbox, dead, batchSize)` reutiliza `dead` solo si `dead.length < batchSize` (= no hay más) y si no lee `dead(PARKED_CENSUS_MAX)`; al alcanzar la cota ⇒ 500 `E_AUTHZ_CONFIG` antes de aplicar nada. **⚪ 6**: `laterApplied(…, DEFAULT_RELAY_BATCH + 1)` ⇒ `truncated: true` cuando hay más de 100. |
| `src/types.ts` | `ScopeRequeueConflict.truncated?`; docblock de `pending`: **«no puede ESCONDER una entrada sin aplicar»** como deber del puerto (🟡 3). |
| `commands/authz_scopes_requeue.ts` | Línea «… y más: solo se listan las primeras N … el diff está CORTADO». |
| `src/testing/scope_outbox_contract.ts` · `tests/scope_outbox_harness.spec.ts` | **O-08** (dos «tenants», seis entradas, `pending(100)` y paginando con `after` salen todas en orden); `EXPECTED_CASES = 15`. |
| `README.md` | Párrafo del tapón: transitividad de la exención del `detached` (origen del bloqueo) + censo completo/`PARKED_CENSUS_MAX`; párrafo del requeue: diff cortado + «`laterApplied` only sees the outbox … do not requeue after reconciling … reconcile again»; deber de `pending()` («must return the whole unapplied queue, oldest first»). |
| `CHANGELOG.md` · `CLAUDE.md` | Bloque «Closing lot»; higiene (viii); mapa del contrato (8 deberes, 15). |

Sin cambios en el puerto (no hacía falta `deadKeys?`: `dead(limit)` con cota propia basta y no toca a terceros).

## 3 · Verde y mutantes

| | |
|---|---|
| **VERDE** | `scope_outbox.spec` 95/95 (`$S/a5C_green.log`); repros 7 y 9 ahora «detached ⇒ applied … purge» y «deferred/parked:101 … llamadas: —» (`$S/a5C_green_repro{7,9}.log`); contrato 45/45 = 15 × 3 (`$S/a5C_contract_green.log`); harness 4/4. |
| **MUTANTE 10** — todo bloqueo es de origen aparcado (`block(key, id, true)` en el fallo; `$S/a5C_mut10_allparked.log`) | 5 rojos en el grupo 🟠 1, el CASO NEGATIVO incluido (el `detached` tras un `attached` FALLADO se aplicaba). |
| **MUTANTE 11** — censo = lo que leyó el reporte (`$S/a5C_mut11_census.log`) | 2 rojos: **la repro I** («expected [['applied', undefined]] to deeply equal [['deferred', 'parked:675']]») y la cota. |
| **MUTANTE 12** — el doble esconde las filas de un «tenant» en `pending()` (`$S/a5C_mut12_hiding.log`) | 10 rojos en los dos dobles, O-08 entre ellos (y todo lo que se apoya en el orden: el contrato SÍ caza un puerto que filtra por su cuenta). |

Casos 🟠 1: EL CASO con nieto (`#2` `parked:#1`, `#2b` `depends-on:#2`, `#3 detached(unit)` y `#4 detached(child)` APLICADOS
y purgados, ningún `attached` fuera de orden; segunda pasada solo aplaza lo que concede); control sin hijo; NEGATIVO
(`detached` tras `attached` FALLADO ⇒ `depends-on`, y al arreglar el fallo entran en orden). Casos 🟠 2: repro I (101
aparcadas, `{ only, limit: 1 }` ⇒ `parked:<#101>`, cero llamadas; `{ limit: 50 }` sin `only` igual; `dead` del reporte sigue
en 100); cota (`dead()` que siempre llena ⇒ 500 nombrando `PARKED_CENSUS_MAX`, cero llamadas). 🟡: 101 aplicadas ⇒
`truncated` + «y más», 100 exactas ⇒ sin marca; letra README/docblock.

## 4 · Verificación final (4 modos, `:8101`, primer plano y en secuencia)

`tsc --noEmit` ✔ · `typecheck` ✔ · `check:purity` ✔ · `build` ✔ (`$S/a5C_build.log`).

| modo | base (lote II) | **ahora** | Δ | exit | s | log |
|---|---|---|---|---|---|---|
| sqlite `:memory:` | 1271 | **1281** | +10 | 0 | 87 | `$S/a5C_final_sqlite.log` |
| sqlite-file | 1297 | **1307** | +10 | 0 | 91 | `$S/a5C_final_sqlitefile.log` |
| pg | 1392 | **1402** | +10 | 0 | 131 | `$S/a5C_final_pg.log` |
| mysql | 1394 | **1404** | +10 | 0 | 139 | `$S/a5C_final_mysql.log` |

Δ = 7 casos del cierre en `scope_outbox.spec` + O-08 × 3 harnesses. Aditivo; sin `skip`; sin mutantes residuales.

## 5 · No tocado (a propósito)

Puerto `ScopeOutbox` intacto (sin `deadKeys?`); 🟡 5 (503 eterno no converge) y ⚪ 7 (`maxDepth` parcial) ya declarados;
la barrera del freeze en `requeueScopeChanges` sigue sin ponerse (🟡 4 se cierra por letra, como pidió el coordinador);
⚪ 8 (`only` con ids ajenos) sin cambio.
