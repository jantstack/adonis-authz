# Fase 2 · Lote 2E — cierre final (auditor 2D + tester 2D; code-review pendiente de reenviar)

> Veredictos sobre `4346bcc`: auditor APTA CON CORRECCIONES (🔴 y 🟠 anteriores cerrados con dos procesos reales; 2 🟠 nuevos, 1 🟡), tester APTA CON CORRECCIONES (parche de tests). Mismas reglas: rojo→verde, tres configuraciones, sin skip, sin commits, informe incremental en ruta absoluta.

## Bloqueantes

| # | Hallazgo | Decisión |
|---|---|---|
| **H1** 🟠 | (Auditor 1) `scopes.moved(child, newParent, { within })` y `attached` solo contrastan `within` con la cadena del **nuevo padre**; la cadena actual del hijo no se mira ⇒ admin de A se lleva `unitB1` a `orgA` (`a5_move_steal.mjs`: `authorize` pasa de false a true). | `moved`: `within ∈ chain(newParent)` **y** `within ∈ chain(child)` (cadena actual, resolutor fresco). `attached`: `within ∈ chain(parent)` y, si el hijo ya existe en el árbol (resolutor ≠ null), también `within ∈ chain(child)`. Invariante 15 de `CLAUDE.md` reescrito ("contra origen y destino"). Caso del juez: `moved` de una unit ajena con `within: orgA` ⇒ 422 `E_AUTHZ_NOT_WITHIN`, sin llamar al driver. |
| **H2** 🟠 | (Auditor 2) `bumpAuthzCatalogVersion()` llamado sin `client: trx` desde una transacción commitea **antes** que la escritura ⇒ otro proceso recarga datos viejos con la versión nueva y **nunca revalida** (verificado con dos procesos). Olvidar el bump = fail-open permanente. | (a) `bumpAuthzCatalogVersion(trx)` **exige** el cliente transaccional (parámetro obligatorio; sin él ⇒ 500 `E_AUTHZ_CONFIG` con mensaje); (b) helper `withAuthzCatalogWrite(async (trx) => { … })` que abre la transacción, ejecuta la escritura del consumidor y hace el bump **al final, dentro**; (c) `syncAuthzCatalog` usa el mismo camino; (d) README/jsdoc: "escribe `authz_*` solo vía `withAuthzCatalogWrite`; el bump siempre es lo último de la transacción". Caso: bump fuera de trx ⇒ 500; dos memos con `withAuthzCatalogWrite` ⇒ el otro revalida y ve la escritura (test existente de dos managers extendido). |
| **H3** 🟡 | (Auditor 3) `{ everyMs }` y `maxAgeMs` usan `Date.now()`: reloj hacia atrás alarga la ventana / resucita una vista caducada. | Reloj monótono (`performance.now()`/`process.hrtime.bigint()`) en `catalog_cache.ts` y `manager.ts` (vistas). Tests con reloj falso inyectable (`now` en opciones internas) que retrocede ⇒ sigue caducando. |
| **H4** | (Tester parche) `tests-tester-fase-2d.patch`: identidad inválida ⇒ 0 consultas totales (no solo de hechos); `expandExcludedSubtrees` con descendientes mal formados ⇒ 503. | `git apply` al principio. |

## Obligatorias (rápidas)

| # | Qué |
|---|---|
| I1 | (Auditor ⚪7) Invariante 14 dice "sin fila de versión ⇒ 503" y el código devuelve 0: hacer que la fila ausente ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE` con mensaje "migración 2.0 no aplicada" (fail-closed) + test. |
| I2 | (Auditor ⚪10) `expandExcludedSubtrees` respeta `maxAgeMs` de la vista como el resto de lecturas + test. |
| I3 | (Auditor ⚪11) `catalog` compartido entre drivers con `catalogRevalidate` distinto ⇒ 500 `E_AUTHZ_CONFIG` al construir (no ignorar en silencio). |
| I4 | (Auditor ⚪6) Documentar en README §within que `within` debe venir de la **sesión** (tenant autenticado), nunca del cuerpo de la petición: `within = scope` satisface siempre por definición. |
| I5 | (Tester ⚪) Caso del **juez** (no solo `manager.spec`) con un harness cuyo driver no implementa `listDenies` ⇒ los casos 2.1 que lo necesitan fallan con 500 `E_AUTHZ_UNSUPPORTED` (registrar como par de capacidad `listDenies: false`, nunca skip). `warnOnOptInSecurity: false` en los harness del paquete para que la suite no ensucie stdout. |
| I6 | (Auditor 🟡4) `authorizedScopes`: documentar el coste O(descendientes × resolveAncestors) y la cota `maxDescendants`; no cambiar el algoritmo en esta fase (nota en README §Performance). |
| I7 | CHANGELOG 2.1 "Lot 2E"; CLAUDE.md invariantes 14/15 corregidos; `contract_harness` conteos. |

## Entrega
`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-2-lote-e-informe.md` incremental. Sin commits.
