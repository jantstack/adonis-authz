# Respuesta a COGNITIV (T2) — enviada/para enviar el 2026-09-02, tras publicar la alpha.3

> Asunto: Re: 2.4.0-alpha.2 verificada en consumo real — 2.4.0-alpha.3 publicada: vuestros 2 defectos y 5 más

Gracias por el informe: los criterios de aceptación que proponéis son casos de contrato bien
formados y entraron tal cual. `2.4.0-alpha.3` está publicada con dist-tag `alpha`
(`npm i @jantstack/adonis-authz@alpha`). Punto por punto, verificado contra el código y contra
los backends reales:

**1 · Hooks del `RelationsManager` no cableados por el provider — corregido, con un matiz.**
`requireActor` SÍ estaba cableado (el provider pasa el del raíz del config); lo que faltaba era
`assertWrite` y `onRelationWrite`, en el provider y en el bloque `relations` de `defineConfig`.
Ahora `relations.assertWrite`, `relations.onRelationWrite` y `relations.requireActor` (este
último anula el del raíz solo para relaciones). Vuestro criterio es un caso de la suite: un
`relate` por el singleton `authz.relations` dispara `onRelationWrite` con su `actor`, y
`requireActor: true` rechaza sin actor por esa misma vía.

**2 · `RelationWriteEvent` sin `transactional` — corregido.** Paridad con el evento de roles:
`transactional: true` cuando la escritura va en vuestra transacción, para que el sink difiera el
registro a `trx.after('commit')`. Vuestro criterio («rollback ⇒ ni tupla ni evento contabilizado
como definitivo») es un caso medido en PostgreSQL, MySQL y SQLite-fichero.

**Lo que salió al barrer la forma entera del defecto** («¿qué tiene el evento de roles que el de
relaciones no?»), y que os afecta más que el #2:

- **El invariante 13 no se cumplía en relaciones.** En roles, una escritura que vence el
  deadline del backend se notifica con `indeterminate: true` ANTES de propagar el 503, para que
  la auditoría registre «puede haber ocurrido». En relaciones no se notificaba nada: una llave
  que pudo entrar y de la que no quedaba rastro. Corregido, medido por motor; y también cuando
  una purga en OpenFGA muere a medias habiendo borrado algo.
- **`purgeObject`/`purgeSubject` no emitían evento.** Un borrado masivo de llaves era invisible
  para el sink. Ahora un evento por purga, con `actor`, y `requireActor` las alcanza (más
  estricto; solo os afecta si ya lo exigíais).
- **Un sink de auditoría que lanzaba tumbaba un `relate` ya escrito** (el hook se llamaba sin
  protección; en roles está protegido). Ahora el hook no puede deshacer ni abortar la escritura.
  A cambio, el sink se espera: está en el camino crítico y, con `{ transaction }`, dentro de
  vuestra transacción — lo lento va a `after('commit')` o a una cola.
- **`assertWrite` era un fail-open por dos caminos**: declarado `async`, la promesa se descartaba
  y la escritura entraba; y devolviendo un veredicto (`false`) en vez de lanzar, también entraba.
  Es exactamente la suposición que vuestro panel hizo al revés, y una línea de docs no bastaba:
  ahora ambos casos son 500 `E_AUTHZ_CONFIG` antes de escribir. `assertWrite` es síncrono y puro
  a propósito, lanza o no lanza; la policy con actor o base de datos va en vuestro servicio (lo
  dice el README, con un caso que fija la frase).
- **La lista blanca de tipos (F-05) no cubría las purgas ni las lecturas.** Nuestro auditor
  reprodujo contra OpenFGA real que `purgeObject` sobre un tipo NO declarado en
  `defineRelationsConfig` podía borrar un `role_binding` del store compartido de roles (un
  usuario perdía su rol), con evento de auditoría limpio; y `listSubjects` enumeraba holders de
  un rol sin catálogo. Pre-existente en la alpha.2. Ahora las ocho operaciones del puerto
  (`relate`, `unrelate`, `purgeObject`, `purgeSubject`, `check`, `listSubjects`, `listObjects`,
  `membersOf`) rechazan con 422 cualquier tipo o relación no declarados, en el manager y en los
  dos drivers. Si vuestro almacén de llaves comparte store con roles en OpenFGA, esto os
  concierne; con `database` no es alcanzable.
- El `actor` de relaciones no se validaba (roles sí): ahora 422 si está mal formado, y un actor
  vacío o `null` no satisface `requireActor`.

**Breaking para vosotros, en resumen** (todo en el CHANGELOG): `requireActor` alcanza a las
purgas; `actor: null` es 422; las lecturas lanzan 422 con tipo o relación no declarados en vez
de responder vacío; `purgeObject`/`purgeSubject` reciben `RelationPurgeOptions` (con `actor`).

**3 · Arista de membresía configurable — aceptado para 2.7**, como proponéis. Vuestro
workaround (`group` como tipo) es el uso previsto hoy.

Verificado en SQLite, SQLite-fichero, PostgreSQL 18 y MySQL 8.4 contra OpenFGA, con auditoría
adversarial en dos rondas sobre el diff (la segunda cazó una regresión del primer cierre antes
de publicar). Lo que verificasteis a favor (censo en los tres motores, caducidad dentro de la
CTE, F-05 en las dos capas, aislamiento por partición) está citado en el CHANGELOG.
