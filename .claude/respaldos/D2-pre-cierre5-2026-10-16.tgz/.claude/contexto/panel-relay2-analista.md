# Panel relay-2 · ANALISTA — el 3er informe de COGNITIV (10-09-2026)

Viabilidad, forma mínima, coste **medido** y plan por lotes de los 3 bloqueantes + 7 menores del
informe `cognitiv-informe-2026-09-10.md`, contra `2.4.0-alpha.7` (commit `13ba731`).

## Cómo está medido (para que se pueda repetir)

Dos copias del árbol en el scratchpad: **`lab0` = alpha.7 intacta** y **`lab` = alpha.7 + los parches
de este informe**. Los guiones usan el mismo harness que `.claude/reproducciones/relay-auditor-*.ts`
(`bootApp` + `sqlScopeOutbox` + driver espía + `memoryScopeTree`).

| Guion | Qué mide | Motor |
| --- | --- | --- |
| `m1-baseline.ts` | la raíz como clave: aparcado de A ⇒ alta de B | sqlite |
| `m2-orden.ts` | 5 pares de cambios: qué orden pierde la exención | sqlite |
| `m3-edad.ts` | coste de la sonda de edad, duración de pasada, trx cerrada, enqueue sin trx | **PostgreSQL 18** |
| `m4-requeue.ts` | `requeue` con y sin `{ apply: true }` | sqlite |
| `m5-ceguera.ts` | 10 pasadas con el store caído + coste de `acquire()` ocupado | **PostgreSQL 18** |
| `m6-many.ts` | el camino de respaldo de `enumerateRelationsMany` | dobles |
| `m7-tapon.ts` | qué bloquea cada clave de una aparcada | sqlite |
| `m8-inline.ts` | la receta INLINE bajo la raíz **sin nada aparcado** | **PostgreSQL 18** |

Los dos árboles y los guiones viven en
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/{lab0,lab}/` (efímero:
si hace falta conservarlos, los parches de `lab/src/manager.ts` son 22 líneas añadidas y 8 quitadas,
y están descritos literalmente más abajo). PG: `TEST_DB=pg TEST_PG_URL=postgres://postgres:…@127.0.0.1:5432/authz_test`.

**Suite completa**: `lab0` 1026/1026 · `lab` (con los tres parches) **1026/1026** (sqlite). Ni un caso
publicado fija el comportamiento que se cambia — lo que significa dos cosas: no es breaking para la
suite, y **hay que escribir los casos que lo fijen** (van en el plan).

---

## 1. La raíz `app` como clave de bloqueo — ✅ **confirmado, y es peor de lo que reportan**

### Lo verificado en código

- ✅ `#changeKeys` (`src/manager.ts:1959`) devuelve `[child]` para `detached` y **`[child, parent]`**
  para `attached`/`moved`; `scopeKey(APP_SCOPE) === 'app'` (`src/identity.ts:227`).
- ✅ Esas claves alimentan **cuatro** caminos: el censo de aparcadas (`#parkedKeys`), el bloqueo por
  fallo (`block`), el origen transitivo (`#blockOriginOf`) y —por una lista de scopes construida
  aparte, no por `#changeKeys`— la sonda de `only` (`#dependencyOf` → `earlierPending`) y la sonda
  anti-reversión de `requeue` (`laterApplied`). **Son 3 sitios que hay que tocar, no 1.**
- ✅ La raíz **nunca es hijo**: `assertEdge` lanza 422 si `child.type === 'app'` (manager y driver
  `openfga`), y la raíz no se purga (invariante 11). Es decir, `app` solo aparece como PADRE.

### Tres síntomas medidos (el tercero no está en su informe)

| # | Escenario | alpha.7 |
| --- | --- | --- |
| I | Aparcada `attached(orgA, app)` ⇒ `attached(orgB, app)` (`only` y pasada completa) | `deferred · parked:1`, **5/5 pasadas con `applied = []`** |
| II | **Sin NADA aparcado**: dos altas de tenant concurrentes bajo la raíz, receta inline | tenant B ⇒ `deferred · depends-on:1` (PG, 15,3 ms) |
| III | `requeue` de la aparcada `attached(orgA, app)` habiendo aplicado `attached(orgB, app)` | **500 `E_AUTHZ_REQUEUE_REFUSED`** (conflicto FALSO: la única clave común es `app`) |

**II es el hallazgo grave**: no hace falta ningún incidente. Con la receta documentada («releva lo
tuyo tras el commit»), **el alta de un tenant no aterriza mientras el alta de otro siga pendiente**, y
en (c2r) eso es fail-CLOSED: la organización recién creada no concede NADA hasta que pase el cron. La
raíz no es «un amplificador de incidentes», es un **serializador global del registro**.

**III** significa además que hoy la salida documentada del incidente (`authz:scopes:requeue`) exige
`--force` —imprimiendo un diff de una reversión que no existe— en cuanto otro tenant se dio de alta.

### ¿Qué orden conserva incluir al PADRE? La respuesta, por pares

Medido en `m2-orden.ts` (pristine vs parcheado; ✅ = igual en los dos):

| Par | alpha.7 | Con la raíz exenta | ¿Se pierde orden? |
| --- | --- | --- | --- |
| `attached(A, app)` falla + `attached(B, app)` | `deferred` | **`applied`** | **No**: son dos aristas distintas bajo un padre que ni se mueve ni se purga |
| `moved(org→app)` falla + `attached(unit, app)` | `deferred` | **`applied`** | **No**: ídem |
| `attached(org, app)` falla + `attached(unit, org)` | `deferred` | `deferred` ✅ | Se conserva por la clave del HIJO (`organization\|X`) |
| `detached(org)` + `attached(unit, org)` | `applied, applied` | ✅ | Se conserva por la clave `organization\|X` (padre del `attached`) |
| `detached(orgA)` + `attached(orgB, app)` | `applied, applied` | ✅ | **Ya hoy no comparten `app`**: `#changeKeys(detached)` es solo `[child]` |

Dos matices que corrigen el enunciado de la consulta:

1. **`detached(org)` seguido de `attached(org', app)` NO comparten `app` hoy** — un `detached` no
   aporta la clave de su padre (no la tiene). No hay nada que arreglar ahí.
2. El par que SÍ importa —`detached(P)` y luego `attached(Y, P)`— se conserva porque el `attached`
   aporta `P` **como clave propia** al comparar. La regla es asimétrica y hay que mantenerla así:
   **al MARCAR (contaminar) sobra la raíz; al COMPARAR se siguen usando las dos claves.**

### Formas mínimas, comparadas

| Opción | Qué arregla | Veredicto |
| --- | --- | --- |
| **(A) Exentar la raíz como clave de contaminación** (la del hijo sigue), en `#changeKeys` + la lista de scopes de `earlierPending` + la de `laterApplied` | I, II y III | ✅ **Recomendada** |
| (B) `blockOnParentKey: false` / opción de config | igual que (A) pero opt-in | ❌ Convierte una cuestión de corrección en una decisión de despliegue y duplica la semántica a probar. La raíz como clave **no conserva ningún orden**: no hay dos comportamientos legítimos que ofrecer |
| (C) Exentar la raíz solo para el TAPÓN de aparcados | Solo I | ❌ Medido: deja II (que no necesita ningún aparcado) y III |

**Forma mínima de (A)**, tal como está parcheada y medida en `lab`: `#changeKeys` devuelve
`[scopeKey(child)]` cuando `parent.type === APP_SCOPE_TYPE`, y un `#changeScopes(change)` gemelo
alimenta `earlierPending`/`laterApplied` (hoy construyen la lista a mano en dos sitios).
**Coste medido: +14 / −6 líneas en `src/manager.ts`, cero consultas nuevas, suite 1026/1026.**
Latencia del `only` sin cambio: con 500 pendientes ajenas bajo la raíz, 4,8 ms (alpha.7, `deferred`)
frente a 5,3 ms (parcheado, `applied`) en PG.

**¿Breaking?** No en el puerto, ni en tipos, ni en la suite. Sí en **comportamiento observable**: un
`attached`/`moved` bajo la raíz que hoy sale `deferred` pasará a aplicarse. Es exactamente el bug.
Documentación a rehacer: `README.md` 139/141/145/149, `CLAUDE.md` (bloque de higiene, punto (ii) y la
frase de la tabla de `scope_outbox_contract.ts`: *«la raíz `app` también es clave: dos `attached` bajo
`app` se contaminan entre sí»*, que dejará de ser verdad).

### La variante fail-open que describen: ¿hueco o decisión?

Su variante — una aparcada `moved(unit → orgA)` contamina `organization|A` y todo `moved` posterior
de esa org queda `deferred` — es **decisión** (tapón por clave, alpha.5 · R2a), pero **el radio es más
ancho de lo que la decisión necesitaba**. Medido (`m7-tapon.ts`, aparcada `moved(unit→A)`):

| Pendiente posterior | alpha.7 | ¿Justificado? |
| --- | --- | --- |
| `attached(doc, unit)` | `deferred parked:` | **Sí**: la posición de `unit` en el store es incorrecta; colgar de ella es colgar del padre VIEJO (es el caso 1136) |
| `moved(unit → orgC)` | `deferred parked:` | Discutible → ver «supersede» |
| `attached(otra unit, orgA)` | `deferred parked:` | **No**: `orgA` no está tocado por el fallo; las dos entradas escriben aristas distintas y conmutan |
| `detached(unit)` | `applied` ✅ | Sí (invariante 11) |

**Variante B (opcional, decisión del dueño):** sembrar el censo de aparcadas **solo con la clave del
HIJO** (`#parkedKeys`, 1 línea). Principio: *una entrada aparcada dice que la POSICIÓN DE SU HIJO en
el store es incorrecta; no dice nada de su padre nuevo*. Medido: el `attached(otra unit, orgA)` pasa a
`applied` y los otros tres casos **no cambian**; suite 1026/1026. Subsume la exención de la raíz para
el tapón (la raíz nunca es hijo), pero **no** para la sonda de `only` ni para `laterApplied`, así que
(A) sigue haciendo falta. Coste: 1 línea. Riesgo: cambia una decisión escrita de alpha.5 que **ningún
caso fija** — por eso va como decisión aparte, con sus casos.

### «Supersede»: ¿el último `moved` gana?

- ✅ Medido: con `moved(unit→A)` aparcada, un `moved(unit→C)` posterior queda `deferred` **para
  siempre** y el store conserva el padre VIEJO. Real.
- ❌ **`laterApplied` no lo sabe**: solo ve entradas **APLICADAS** posteriores, y la que superaría a la
  aparcada está `deferred` (nunca llega a aplicarse). Hace falta una sonda NUEVA sobre pendientes por
  HIJO.
- La regla sería sólida (`attached`/`moved`/`detached` posteriores del MISMO hijo redefinen por
  completo la arista de ese hijo ⇒ la aparcada es basura), pero el coste no es de alpha.8:
  1. sonda nueva en el puerto (`laterForChild(id, child)`) ⇒ capacidad nueva + caso del juez;
  2. **estado terminal nuevo** en la cola: o una columna (`superseded_by` ⇒ migración en la tabla del
     consumidor, que es SUYA) o marcar `applied_at` mintiendo en el registro de propagación;
  3. la aparcada superada hoy es la única traza de un incidente; borrarla sola cambia el runbook.

**Veredicto: fuera de alpha.8.** Lo que resuelve el 90 % del dolor a coste ~0 es (A) + variante B; el
resto es el runbook ya publicado (SQL del operador + `authz:reconcile --to=<driver>`). Si se quiere
algo en 2.5, lo barato y honesto es **diagnóstico read-only**: marcar en el reporte `dead[]` cuál
tiene un cambio posterior del mismo hijo (`supersededBy: <id>`), sin tocar la cola.

---

## 2. `requeue` que aplique en la misma pasada — ✅ **viable, trivial, sin conflicto con la sonda**

- ✅ Reproducido (tester P14): tras `requeueScopeChanges([id])`, el `only` del tenant sale
  `#2 deferred(depends-on:1)`; el incidente **no se cierra con un comando**.
- ✅ Causa: la reencolada vuelve con su id ORIGINAL (menor) y comparte clave ⇒ la sonda
  `earlierPending` la ve delante. Es correcto: lo que falta es aplicarla.

**Forma mínima (implementada y medida):** `requeueScopeChanges(ids, { apply: true })` =
`outbox.requeue(ids)` y, **en la misma llamada**, `relayScopeChanges({ only: [...ids] })`, cuyo
reporte se devuelve en `ScopeRequeueReport.relay`.

| Medición (`m4-requeue.ts`, sqlite) | Resultado |
| --- | --- |
| `{ apply: true }` | **2,0 ms**; la aparcada aplica en la misma llamada y el `only` siguiente del tenant sale `applied` |
| ¿Conflicto con la sonda anti-reversión? | **No**: la sonda corre ANTES y no cambia — con una APLICADA posterior de la misma clave sigue siendo `E_AUTHZ_REQUEUE_REFUSED` con **cero** llamadas al driver |
| Coste en código | +4 líneas + 1 campo de tipo |

Detalles que hay que escribir:
- El `relay` toma el **lease**; si otra pasada lo tiene, `report.relay.busy === true` y la entrada
  queda `pending` (correcto y no silencioso: hay que mirarlo).
- Exige además la capacidad `filter` del puerto (`pending(…, { ids })`), aparte de
  `dead`+`requeue`+`laterApplied`: si falta ⇒ 500 nombrándola (o `apply` no se ofrece).
- **No es atómico**: `requeue` confirma y luego el relay puede salir 503 (freeze, store caído). La
  entrada queda pendiente — que es el estado correcto — y el comando lo dice.
- ❌ **Rechazo la alternativa «que `only` incluya automáticamente las reencoladas»**: `only` es «los
  ids de MI recibo»; ampliarlo por debajo con entradas de otro incidente rompe la propiedad que hace
  la receta inline defendible (nunca se aplica lo ajeno dentro de la petición de un tenant).

**¿Breaking?** No: opción nueva y campo nuevo del reporte. El comando `authz:scopes:requeue` gana
`--apply` (aditivo; **valorar hacerlo el default del comando** —ahí no hay ambigüedad de lease— y
dejar `apply: false` como default de la API).

---

## 3. Edad de la cola y aparcado por tiempo — ✅ **la mitad es GRATIS; el aparcado por tiempo, NO**

### La ceguera, confirmada

Medido con el store caído (PG, 10 pasadas, `m5-ceguera.ts`): `pendientes = 10`, `attempts = 0`,
`dead = 0`, `remaining = true`, `failures = 1` por pasada (`transient: true`). Su auditor B2 tiene
razón: **las dos alarmas del contrato (`dead` y el exit ≠ 0 por aparcados) son ciegas** justo ahí. Lo
único que hoy avisa es `failures[0].transient` de cada pasada.

### `oldestPendingAt` / `pendingAgeMs`: coste CERO

- ✅ `created_at` **existe** en `stubs/scopes_outbox_migration.stub` (`table.timestamp('created_at').notNullable()`).
- ✅ `sqlScopeOutbox.pending()` hace `select *`: la columna **ya viaja**; lo único que falta es que
  `rowToPending` la mapee a `createdAt` (campo OPCIONAL de `PendingScopeTreeChange`).
- ✅ La pasada **ya ejecuta `outbox.pending(1)`** al final (para `remaining`) y en la rama `busy`, sin
  filtro: esa fila **es** la cabeza global de la cola (`orderBy id asc`), y su `created_at` es la
  edad. **0 consultas nuevas** en las dos ramas; solo `dryRun` necesitaría una (medida: 1,6 ms con
  2 000 pendientes en PG).
- Comparativa medida (PG, 2 000 pendientes): `MIN(created_at)` 1,63 ms vs `ORDER BY id LIMIT 1`
  1,59 ms. La segunda es la que ya se hace y va por el índice `(applied_at, id)`; `MIN` degrada con la
  cola. **Reusar `pending(1)`, no añadir `MIN`.**
- Reloj: `Date.now()` del sistema, no el `clock` inyectable — `created_at` es auditoría, no una
  decisión (README, «audit stamps are not decisions»). Si el puerto no trae `createdAt` ⇒
  `oldestPendingAt: null`, jamás `0`.

### `parkAfterMs`: ❌ **no**

Aparcar por tiempo mete en el **tapón por clave** —diseñado para lo IRREPARABLE— todo lo que solo está
esperando a que vuelva el store. Consecuencias, con la mecánica de hoy: al volver el backend, nada se
aplica solo (lo aparcado no vuelve a `pending()` jamás), la cola entera queda a la espera de un humano
y el `attached` de cada tenant sigue fail-CLOSED. Convierte **una caída transitoria en un incidente
manual permanente**, que es justo lo contrario de la decisión (i) de alpha.5 («un 503 no consume
intento»).

**Forma mínima correcta: alarma por EDAD sin aparcar.** `report.oldestPendingAt` / `pendingAgeMs`
(gratis) + `node ace authz:scopes:relay --max-age=<ms>` que sale ≠ 0 si se supera. El cron ya existe
en su runbook y ahí es donde vive la alarma.

**¿Breaking?** No: campo opcional en `PendingScopeTreeChange`, dos campos nuevos en
`ScopeRelayReport`, un flag nuevo. Un `ScopeOutbox` de terceros que no traiga `createdAt` degrada a
`null` (nunca a una alarma en verde: `null` ≠ «cola joven»; el comando lo dice).

---

## 4–10. Los menores

| # | Punto | Viabilidad / forma mínima | Breaking | Coste |
| --- | --- | --- | --- | --- |
| 4 | `origin` en `entries` | ✅ Real: `depends-on:` **no distingue** «anterior pendiente» de «fallo real», y el caso heredado (`byParked` transitivo de alpha.6) hoy **solo está en la prosa española** de `deferred[].error`. Forma mínima: `blocked: Map<key, { id, parked }>` → `{ id, origin: 'parked'\|'pending'\|'failed' }` con precedencia `failed > pending > parked` (el «fallo pisa a aparcado» de hoy), `#blockOriginOf` devuelve el origen en vez de un booleano, y `ScopeRelayEntry.origin` opcional. **Ojo**: la exención de `detached` (invariante 11) sigue mirando SOLO `origin === 'parked'` | No (campo aditivo) | ~40 líneas, 0 consultas |
| 5 | `dead` bajo `only` | ⚠️ Su premisa es medio falsa: `report.dead` es `RelayedScopeChange` = `{id, change, attempts, error}` — **no lleva actor** (el actor solo viaja en `PendingScopeTreeChange`). Lo que fuga es `change` (uuids de scopes de otros tenants) y `error`. Quitar solo `lastError` **no cierra la fuga**. Y hay un punto ciego aparte: `dead` está acotado a `batchSize` (100), así que `dead.length` miente cuando hay más. Forma mínima: **(a)** `report.deadCount` SIEMPRE (gratis: `#parkedKeys` ya lee el censo COMPLETO cuando `dead.length >= batchSize`), **(b)** opción `deadDetail: 'full' \| 'ids'` (default `full`) que bajo `only` deja `dead` con id+attempts y sin `change`/`error`. La alarma («la cola no converge») la sostiene `deadCount`, no `dead.length` | No si es opt-in y `deadCount` es aditivo | ~15 líneas |
| 6 | `enqueue` sin `{ transaction }` ⇒ 500 | ✅ Medido: hoy se acepta y escribe fuera de la unidad de trabajo. Pero **sí rompe a quien encola a propósito fuera de trx** (seeders, back-office, los tests del propio paquete). Forma mínima: **opt-in** `scopes.requireOutboxTransaction: true` en el config del MANAGER (no en `sqlScopeOutbox`: así vale para cualquier puerto), comprobado en los 3 sitios de `enqueue` justo tras `const outbox = this.#outbox()`. Con `warnOnOptInSecurity` avisando si no está. Default `true` ⇒ 2.5, anunciado | Aditivo ahora; breaking si el default cambia (dejarlo para 2.5) | ~10 líneas |
| 7 | Trx cerrada ⇒ `E_AUTHZ_CONFIG` | ✅ Confirmado end-to-end: hoy sale **503 `E_AUTHZ_BACKEND_UNAVAILABLE` «no respondió (enqueue)»** porque `assertCallerTransaction` pasa (`isTransaction === true` en una trx confirmada) y knex revienta dentro de `guardSql`, que traduce todo lo desconocido a 503. ✅ La señal existe: Lucid publica `isCompleted` (getter booleano, `transaction_client/index.js:54`) y **medido `isCompleted === true`**. Forma mínima: 4.ª comprobación en `assertCallerTransaction` (`trx.isCompleted === true` ⇒ 500 nombrando la operación). Vale gratis para `database` roles (L-3) y relaciones (L-4) | Cambia 503→500 en ese caso (es lo pedido); ningún caso lo fija | **4 líneas** |
| 8 | `enumerateRelationsManyNative` | ⚠️ **La capacidad no es el arreglo**. Medido (`m6-many.ts`): el camino de respaldo de `RelationsManager.enumerateRelationsMany` (`src/relations/manager.ts:583-591`) no es «K barridos correctos»: acumula tuplas de todas las particiones y devuelve **el cursor de la última que tenía más**; reanudar con él aplica `uuid > after` a TODAS ⇒ **pierde tuplas en silencio** (medido: 6 tuplas en el store, 5 vistas, `a9` perdida). En el ORIGEN de una migración eso es «esa tupla no existía». (`relations/reconcile.ts::enumerateAllMany` NO usa este camino: pagina por partición, así que `authz:reconcile` está a salvo.) Forma mínima, en dos piezas: **(a)** implementar `enumerateRelationsMany` en `database_relations_driver` — es el mismo SELECT con `whereIn('partition_key', todas las ortografías)`, orden por `uuid`, cursor SANO, y un mapa clave→`ScopeRef` para devolver la partición pedida en cada tupla (~35 líneas) — y **(b)** que el respaldo del manager deje de mentir: o cursor compuesto `(índice de partición, after)`, o 500 en cuanto una partición devuelve cursor. La capacidad `enumerateRelationsManyNative` sobra si se hace (a): con los dos drivers publicados nativos, el respaldo solo lo pisa un driver de terceros | (a) aditivo; (b) cambia un comportamiento **roto** | ~35 + ~15 líneas |
| 9 | `waitForLeaseMs` | ✅ Viable sin tocar el puerto: bucle de reintento sobre `acquire()` con sondeo. Medido en PG: **0,29 ms por sondeo ocupado** (y no retiene conexión entre sondeos). Dimensionado real: una pasada completa de 2 000 entradas con driver espía **1 357 ms (0,68 ms/entrada de puro overhead)** — con escrituras reales a FGA son decenas de segundos, así que el número del panel anterior (13 ms/pasada) **no es la cota**: esperar un backlog completo no es realista. Forma mínima: `waitForLeaseMs` opt-in, sondeo cada 50 ms, y `busy: true` al vencer (nunca un cuelgue). Riesgo a escribir: con **pool 1** el que espera puede estar reteniendo la única conexión que necesita el que tiene el lease ⇒ `waitForLeaseMs` exige **pool ≥ 2**, como `{ transaction }` | No (opción nueva) | ~12 líneas |
| 10 | El 422 y `maxDepth` | ✅ Confirmada la fuga: el mensaje de `ScopeDepthLimitError` (`src/manager.ts:2256-2259`) nombra `FACTS_MAX_RESOLVE_DEPTH (22)`, «el modelo facts de openfga» y `OPENFGA_RESOLVE_NODE_LIMIT`. Es un 422 que llega al tenant. Forma mínima: dejar en el mensaje solo la pregunta del llamante (scope, saltos, techo, «no se ha escrito ni encolado nada») y mover el porqué al docblock/README/config. `maxDepth = N + 1`: **docs**, ❌ no cambiar la semántica a NIVELES (breaking, y la unidad correcta es la que gasta el presupuesto de profundidad de FGA: saltos hasta `app`) | No (texto y docs; ningún caso fija esta letra — `trx_docs.spec.ts` cubre otras) | ~6 líneas + docs |

---

## Plan por lotes

### Lote A — el cutover de COGNITIV (bloqueantes 1–3) · **fácil**

| Paso | Dificultad | Qué queda demostrable |
| --- | --- | --- |
| A1 · la raíz deja de ser clave de contaminación (`#changeKeys` + `#changeScopes` en las dos sondas) | **fácil** (+14/−6 líneas, ya medido) | El alta de un tenant bajo `app` aterriza en su propia petición con la cola de otros pendiente (M8) y con una aparcada ajena (M1); `requeue` deja de negarse en falso (M1-V) |
| A2 · casos que lo FIJAN: dos `attached` bajo la raíz no se contaminan (aparcado, fallo y `only`), y el mutante «la raíz vuelve a ser clave» muere; los 3 pares de orden que NO cambian | **medio** (es el trabajo de verdad del lote) | La suite protege el arreglo y el orden que sí importa |
| A3 · `requeueScopeChanges(ids, { apply })` + `--apply` en el comando | **trivial** | El incidente se cierra con UN comando (M4-B) |
| A4 · `createdAt` en el puerto + `oldestPendingAt`/`pendingAgeMs` reusando `pending(1)` + `--max-age` | **fácil** | Con el store caído, la pasada dice la edad de la cola (M5) sin una consulta de más |
| A5 · docs: README 139/141/145/149, `CLAUDE.md` (higiene (ii) y la frase de la tabla del juez), CHANGELOG | **fácil** | Nada publicado sigue diciendo que la raíz es clave |

**Camino crítico: A1 → A2.** Todo lo demás es paralelizable. A2 es lo que decide si el lote es serio.

### Lote B — los menores baratos · **trivial/fácil**

B1 `isCompleted` en `assertCallerTransaction` (**trivial**, 4 líneas) · B2 el mensaje del 422 sin
nombrar el servidor + docs de `maxDepth = N + 1` (**trivial**) · B3 `deadCount` siempre +
`deadDetail: 'ids'` (**fácil**) · B4 `origin` en `entries` (**fácil**, cuidado con la exención del
`detached`) · B5 `waitForLeaseMs` (**fácil**, con la nota de pool ≥ 2) · B6
`scopes.requireOutboxTransaction` opt-in (**fácil**).

### Lote C — relaciones · **medio**

C1 `enumerateRelationsMany` nativo en `database_relations_driver` (**fácil-medio**, ~35 líneas) ·
C2 el respaldo del manager deja de perder tuplas (**medio**: cursor compuesto o 500) · C3 caso que
mata al mutante «respaldo con cursor de la última partición» (**medio**). La capacidad
`enumerateRelationsManyNative` **no se añade** si entra C1 (y si se añadiera, sería después: es un
par de capacidad más en `runRelationsContract`).

### Lote D — decisión del dueño, con sus casos · **medio**

D1 variante B del tapón: el censo de aparcadas siembra **solo la clave del hijo** (1 línea + 4 casos).
Arregla la variante fail-open que reportan; **cambia una decisión escrita de alpha.5 que ningún caso
fija**. No entra en alpha.8 sin un «sí» explícito.

### Qué NO hacer

1. ❌ **`parkAfterMs`** (aparcar por edad): convierte una caída transitoria en un incidente manual
   permanente y contradice la decisión (i) de alpha.5.
2. ❌ **`blockOnParentKey` como opción de config**: la raíz como clave no conserva ningún orden; no
   hay dos comportamientos legítimos que ofrecer.
3. ❌ **«supersede» de aparcadas** en alpha.8: necesita sonda nueva en el puerto + estado terminal
   nuevo (columna o mentira en `applied_at`). A 2.5, y antes solo como diagnóstico read-only.
4. ❌ **`only` que arrastra automáticamente las reencoladas**: rompe «`only` = mi recibo».
5. ❌ **`dead: []` bajo `only`**: un reporte en verde sobre una cola que no converge (la decisión de
   alpha.5 sigue siendo correcta; por eso `deadCount` es el precio de admitir la redacción).
6. ❌ **Cambiar `maxDepth` a NIVELES**: breaking y la unidad correcta es la que gasta el presupuesto
   de FGA.
7. ❌ **Tocar `EXPECTED_CASES` del juez del puerto en alpha.8**: `createdAt` entra como campo
   opcional que degrada a `null`; convertirlo en deber (con su par de capacidad) es 2.5.

### Qué entra en una `alpha.8` ADITIVA

**Lote A + Lote B + Lote C**. Todo es campo nuevo, opción nueva o corrección de un comportamiento
roto; **cero cambios de firma del puerto** (`createdAt` es opcional y covariante, como lo fueron
`{ id }`, `{ ids }` y `{ transient }` en alpha.5). Los dos cambios de comportamiento observable son
exactamente los que se piden (la raíz deja de bloquear; la trx cerrada pasa de 503 a 500) y el
tercero es la reparación de una pérdida silenciosa de tuplas.

**Fuera de alpha.8:** el Lote D (decisión), el supersede, la capacidad
`enumerateRelationsManyNative`, y cualquier deber nuevo del juez del puerto.

---

## Lo que hay que decidir antes de implementar (preguntas al dueño)

1. **¿Entra la variante B** (el censo de aparcadas siembra solo la clave del hijo)? Arregla la
   variante fail-open que COGNITIV reporta, cuesta 1 línea y **cambia una decisión escrita de
   alpha.5**. Sin ella, un aparcado sigue congelando los `attached` de todo lo que cuelgue de su
   padre nuevo.
2. **¿`--apply` es el default del comando `authz:scopes:requeue`?** (en la API sigue siendo opt-in).
3. **¿`deadDetail: 'ids'` se ofrece**, sabiendo que la fuga real es `change` y no solo `last_error`, y
   que la alarma pasa a ser `deadCount`?
4. **`scopes.requireOutboxTransaction`: ¿opt-in en 2.4 y default en 2.5, o directamente 500 ya?**
   Medido: hoy hay usos legítimos sin transacción (los propios tests del paquete).

---

## Recomendación en una frase

**La raíz `app` como clave de contaminación no conserva ningún orden y rompe la receta inline incluso
sin incidentes (medido en PG, sin nada aparcado): exentarla en los tres sitios cuesta 14 líneas y deja
la suite en 1026/1026 — ese es el arreglo, y `requeue --apply` + la edad de la cola (coste cero,
reusando el `pending(1)` que la pasada ya hace) completan una `alpha.8` estrictamente aditiva.**

**Siguiente paso concreto:** decidir la pregunta 1 (variante B) — es lo único del lote A que cambia
una decisión ya tomada; con eso resuelto, A1 y A2 se escriben del tirón (el parche de A1 ya está
medido en el scratchpad, `lab/src/manager.ts`).
