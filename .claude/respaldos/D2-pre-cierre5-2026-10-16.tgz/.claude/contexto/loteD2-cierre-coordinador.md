# Sublote D2 — cierre 1: decisiones del coordinador sobre `loteD2-auditor.md` (2026-10-15)

Auditor: 2 🟠, 4 🟡, 6 ⚪. Resisten: la puerta del destino con cero escrituras, denies entre particiones, gemelo N3, R-1/⚪11,
`EXPECTED_FUSED`/`migration_stub`/`freeze.spec`, CHANGELOG solo en `[Unreleased]`, S11/S17 con efecto. Todo lo de abajo entra.

## 🟠 1 · Reconcile cortado: el allow directo llega antes que la membresía que transporta el deny ⇒ el destino concede
**Es la 4.ª aparición del patrón «estado intermedio de una operación multi-request concede»** (candidato L10, `linajes.md`:
3b-2f R3, 3b-6 P1, D1 🟠 1 purga, D2 🟠 1 reconcile). No se parchea: **punto de paso ÚNICO para el orden de escritura y de
borrado de relaciones, compartido por la purga de `openfga` (D1) y por el reconcile**:
- **Escritura** (reconcile): denies (todos, directos y sobre `g#member`) → membresías `group:*#member` → allows sobre objetos que
  no son `group`. Con todos los denies ya escritos, una membresía nueva no puede conceder nada que un deny del origen corte.
- **Borrado** (poda del reconcile y purga): allows que no son `group` → membresías → denies (el de D1).
- Una función (`relationWriteOrder`/`relationDeleteOrder` o el nombre que encaje) usada por los DOS caminos; la propiedad de la
  guardia (`relations.reconcile.order` y `openfga.purge.order`) pasa a juzgar esa función con la tabla {deny directo, por grupo,
  anidado} × {orden de enumeración del origen: membresía primero, allow primero} × {corte tras k}, y el mutante «orden de
  enumeración del origen» (el de hoy) muere. Cuatro líneas de cierre.
- Letra: README/CHANGELOG dicen exactamente lo que el orden garantiza, con el residuo si lo hay.

## 🟠 2 · El rollback no detiene las escrituras de deny de la flota
El procedimiento de rollback (README + paso 21 del runbook) gana un paso PREVIO obligatorio: **pasar la flota a la fase `'read'`**
(D10: `deny` ⇒ 422, las lecturas siguen honrando) y desplegarla **antes** de contar, barrer o publicar; el conteo (consulta del
README) se repite al final y debe dar 0. Paso 21 del runbook con EFECTO: con la flota en `'read'` un `deny` concurrente es 422 y no
escribe; con la flota aún en `'write'` el runbook lo detecta (la cuenta final ≠ 0 ⇒ exit 1 con letra) en vez de publicar.
`provision --allow-drop-deny` vuelve a contar justo antes de `writeAuthorizationModel` (TOCTOU: cuenta ≠ 0 ⇒ exit 1, cero modelo).

## 🟡 / ⚪
| # | Decisión |
|---|---|
| 🟡 3 | La guarda de `provision` compara contra el ESTADO DEL STORE (hay tuplas `denied_<rel>` vivas para una relación que el modelo nuevo no declara ⇒ negado), no contra el último modelo publicado. Caso: un modelo alpha.10 publicado entre medias no desactiva la guarda. Rechaza la parte «contra el último modelo» de la decisión 8. |
| 🟡 4 | Re-deny en `openfga` sobre un deny CONDICIONAL preexistente (solo puede venir de fuera del paquete: D3) da 409 ⇒ hoy 503 que se repite. ⇒ **500 `E_AUTHZ_CONFIG`** con letra (M5: FGA no puede reemplazar la misma clave en un `Write`; receta explícita `removeDeny` + `deny` con su ventana declarada); el reconcile lo lista como residuo con motivo propio, nunca 503 repetido. Corregir «lo rehace permanente» (solo `database`). |
| 🟡 5 | Paso 20 del runbook también con deny POR GRUPO y con una membresía con caducidad que transporta el deny (M6). |
| 🟡 6 | La receta de `undeclared` tiene que funcionar por la API: «re-declara el tipo con `deny: 'write'` temporalmente, `removeDeny`, retíralo» (o la vía que funcione), EJECUTADA en un caso. Nunca una receta que da 422. |
| ⚪ 7 | La reflexión de L9 cubre también las clases 422 que nombra solo `src/shared/` (o enumera `errors.ts` entero por `status === 422`). |
| ⚪ 8 | Un deny del destino sin `kind` (tercero) ⇒ 500 en el plan con letra, nunca planificado como allow. |
| ⚪ 9 | La cara de `denyPhase` en el runner del DRIVER (la propuesta del auditor), con su par; README «Third-party drivers». |
| ⚪ 10 | «pasada PARCIAL» solo si se escribió ≥ 1 tupla; con 0, la línea del error sin «PARCIAL». |
| ⚪ 11 | Destino `database` sin opt-in `'write'`: se mantiene la negativa (escribir un deny exige la fase `'write'` en todo destino), pero la letra explica por qué aunque D8 honre una fila existente. |
| ⚪ 12 | CHANGELOG: los contadores totales que ahora incluyen denies son un CAMBIO de significado, no «additive»; frase para quien los parsea (COGNITIV clasifica residuo con ellos). |
Decisiones §4 del implementador: ratifico 2, 5, 6, 7, 9–14; 1, 3, 4, 12 con las condiciones del auditor; 8 sin la parte «último modelo».

Reglas: rojo → verde → mutante; cuatro líneas para 🟠 1 y 🟠 2; CHANGELOG `[Unreleased]` («Closure 1 of sublot D2»; bloques
publicados intactos); verificación 4 modos + 3 gates; suites en PRIMER PLANO y nada en segundo plano al terminar. Informe
`loteD2-informe-cierre.md`. Sin commit, sin `version`, sin push.
