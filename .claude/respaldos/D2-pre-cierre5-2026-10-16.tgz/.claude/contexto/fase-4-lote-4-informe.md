# Fase 4 · Lote 4-4 — driver `openfga` de relaciones + el 🔴 PROBADO VERDE + truncado

> Base: `main` @ `d39838f` (4-3 mergeado). Árbol principal, SIN commits (los hace el dueño).
> Plan: `fase-4-juez.md` §4-4 + `fase-4-plan.md` §4 + `fase-4-auditor.md` (F-05, ⚪5) + informes 4-1/4-2/4-3.
> Alcance: el driver `openfga` del puerto `RelationsDriver` (store COMPARTIDO con `facts`), el caso-exploit
> del auditor VERDE contra el `:8101`, la paridad `database`↔`openfga`, el truncado medido en el tope 3
> (`:8103`), el espía de «1 Check», y la robustez del test de profundidad del 4-1.

## Qué se implementó (todo aditivo)

- **`src/drivers/openfga_relations_driver.ts`** — `OpenFgaRelationsDriver implements RelationsDriver` sobre el
  MISMO store y `modelId` que el driver `facts` de roles (store COMPARTIDO, decisión del dueño/juez §2):
  - `relate`/`unrelate` = `client.write`/delete de UNA tupla (`<type>:<scopeKey(partition)>|<uuid>#<rel>@<sujeto>`),
    idempotentes (`onDuplicateWrites: Ignore` en write, `onMissingDeletes: Ignore` en delete — las tuplas de
    relación no llevan condición, así que un duplicado es idéntico por construcción).
  - `check` = **UN solo `client.check`** (el modelo FUSIONADO resuelve includes + usersets anidados del lado del
    servidor). Espía en la spec.
  - `listObjects` = `client.listObjects` (derivación server-side) + FILTRO por partición + **señal de TRUNCADO**:
    `ListObjects` corta al tope del servidor sin `continuation_token` ni bandera, así que se compara el número de
    resultados con el tope configurado (`listObjectsMaxResults`) — `>= tope` ⇒ `truncated: true` (nunca una lista
    parcial muda, lección S16/L0.7).
  - `listSubjects` = `client.read` por `(object, relation)` — hechos DIRECTOS (invariante 7); `usersetSubjects: true`
    ⇒ los usersets (`group#member`) vuelven junto con los holders.
  - `membersOf` ⇒ **500 `E_AUTHZ_UNSUPPORTED`** (`membersOfNative: false`, `whenFalse`): la transitiva sería
    `ListUsers`, que trunca sin señal fiable; se dice con 500, jamás un userset a medias (el par de `purgeRole` de 3b).
  - `purgeObject`/`purgeSubject` = `Read` exhaustivo (paginado) + delete + **RE-LEE para demostrar cero** o lanza
    500 `E_AUTHZ_PURGE_INCOMPLETE` (invariante 11); barren las DOS ortografías del uuid de partición (🟡2, paridad
    con `database`). `purgeSubject` recorre cada tipo declarado (`group` + los del consumidor) con
    `Read({ user, object: '<type>:' })` porque un `Read` solo por `user` es un 400 del servidor (medido).
  - **⚪5 · parseo CANÓNICO del id** (`#parseObjectId`): el id lleva DOS `|` con partición no-raíz
    (`document:unit|<partUuid>|<objUuid>`), así que se parsea DESDE LA DERECHA (`lastIndexOf('|')`, el mismo
    cuidado que `parseBindingId`): partición = todo menos el ÚLTIMO segmento; el objeto es el último y no lleva `|`.
  - Capacidades: `singleCheckRelations`, `listObjectsInherited:false`, `usersetSubjects`, `membersOfNative:false`,
    `enumerateRelations:false` (es 4-5), `listObjectsTruncation:true`. La abstracción NO filtra: todo va por
    `#guard`, que clasifica cualquier error del SDK a 503/timeout (ningún `FgaError` escapa).
- **`src/openfga.ts`** — exporta `OpenFgaRelationsDriver` + su `OpenFgaRelationsDriverOptions` (subpath
  `@jantstack/adonis-authz/openfga`, como el driver de roles).
- **`scripts/check_purity.mjs`** — el nuevo driver se añade a `OPENFGA_ALLOWED_FILES` (puede tocar el SDK) y a
  `OPENFGA_TARGETS` (un módulo que lo importe delata la ruta openfga). `check:purity` sigue verde.

Ficheros nuevos: `src/drivers/openfga_relations_driver.ts`, `tests/relations_openfga.spec.ts`,
`tests/relations_bridge.spec.ts`. Tocados: `src/openfga.ts`, `scripts/check_purity.mjs`,
`tests/openfga_facts.spec.ts` (robustez del test de profundidad 4-1).

## EL CASO-EXPLOIT DEL AUDITOR — rojo (escalada) → verde (422 + check false), MEDIDO contra el `:8101`

Spec PUENTE (`tests/relations_bridge.spec.ts`): construye a la vez el `OpenFgaAuthorizationDriver` (roles) y el
`OpenFgaRelationsDriver` sobre el **MISMO store** con el modelo FUSIONADO (facts con `p0` + `document`), catálogo
sincronizado con su proyección (marcador `scope:app#rooted` incluido).

**🔴 REPRODUCIDO primero (la escalada, sin F-05):** grant legítimo de `alice` (rol `r0`⊃`p0`) a nivel `app`;
llamar al driver EN DIRECTO (la salida `manager.driver()`, saltándose F-05) con `object.type='role_binding'`
compone `role_binding:app|<roleUuid>` —byte a byte el binding real— y escribe un `assignee` plano:
```
CONTROL: alice concede (true), evil aún NO (false)
relations.relate(evil, 'assignee', {type:'role_binding', id:<roleUuid>}, app)  // driver directo
⇒ roles.authorize(evil, 'p0', app) = TRUE   ← la escalada del auditor, contra el :8101
```
El test `🔴 ROJO reproducido …` afirma esa `true`: la escritura de relations CRUZA a `roles.authorize`.

**🟢 CERRADO (F-05 en el manager):** el MISMO ataque por `RelationsManager.relate` ⇒ 422 antes de tocar el
driver, y el store queda intacto. **Salida ROJA literal** al mutar F-05 (comentar `#assertDeclared` en
`RelationsManager.relate`) y correr el test VERDE:
```
❯ relaciones · 4-4 — el caso-exploit del auditor … / 🟢 VERDE: el manager corta con F-05 (422) …
ℹ AssertionError: expected undefined to equal 422
  156 ┃  assert.equal(caught.status, 422)
 Tests  6 passed, 1 failed (7)
```
(Sin F-05, `manager.relate` NO lanza: la tupla `assignee` se escribiría y evil escalaría.) **Verde** con F-05:
422 `E_AUTHZ_RELATION_TYPE_UNKNOWN`, `authorize(evil, p0, app)` **sigue `false`** y `authorize(alice, p0, app)`
**sigue `true`** (el binding legítimo intacto), MEDIDO contra el `:8101` en el store compartido. Manager
restaurado (`diff` limpio). **Es la condición dura del veredicto, VERDE.**

## Paridad `database` ↔ `openfga` (spec puente, misma pregunta ⇒ misma respuesta)

`tests/relations_bridge.spec.ts` corre los dos drivers de relaciones sobre el mismo catálogo/árbol/tuplas y
compara con `assert.deepEqual`: check con includes (`editor⊆viewer`, y el inverso NO), check con userset
anidado (grupos), aislamiento de partición (false en B), `listObjects` (mismo conjunto de ids), `unrelate`
(false en los dos). **Salida ROJA literal** al mutar `#expandDown` del driver `database` para ignorar includes:
```
❯ relaciones · 4-4 — paridad database ↔ openfga … / check con includes (editor ⊆ viewer): la misma respuesta
ℹ AssertionError: expected false to deeply equal true
```
(database respondía `false`, openfga `true` ⇒ divergencia). Restaurado.

## El truncado MEDIDO contra el tope 3 (`:8103`) — `listObjectsTruncation` whenTrue, no ❓

La spec `tests/relations_openfga.spec.ts` **detecta el tope de `ListObjects` del servidor al arrancar**
(top-level await: relate 8 a un user fresco en un store efímero, cuenta lo que devuelve `ListObjects`). Con
tope BAJO (`:8103` = 3) el harness declara `listObjectsTruncation: true` y la cara `whenTrue` del contrato se
MIDE; con tope alto (`:8101` = 1000) declara `false` y se mide la cara `whenFalse` (exhaustiva, sin señal
falsa). Las dos son medidas reales contra el servidor, **ninguna un skip**. Además, un caso dedicado propio
(«listObjects señala truncado cuando el servidor corta») confirma en `:8103` que el corte es del SERVIDOR y no
del driver: un `Read` crudo (sin tope) demuestra que las 6 tuplas existen mientras `listObjects` devuelve 3 con
`truncated: true`. **Salida ROJA literal** al mutar el driver para no señalar nunca (`truncated = false`),
corriendo en `:8103`:
```
❯ relations contract [openfga (tope ListObjects 3)] / listObjectsTruncation:true · listObjects trunca al tope y SEÑALA truncated
ℹ AssertionError: expected undefined to be true   (assert.isTrue(page.truncated))
❯ openfga relaciones — listObjectsTruncation MEDIDO … / listObjects señala truncado … (tope real 3)
ℹ AssertionError: expected undefined to be true
```
Restaurado. (El tester marcó la cara `whenTrue` de `truncationSignal` —capacidad de ROLES— como VACÍA; NO se
reusa: esta es la capacidad PROPIA `listObjectsTruncation` de relaciones, con su whenTrue medido de verdad.)

## El espía de «1 Check» y ⚪5, con su rojo

- **1 Check** (`tests/relations_openfga.spec.ts`): un `check` con includes + userset anidado dispara
  EXACTAMENTE un `client.check`. Mutante (un segundo `client.check` en `check`):
  `ℹ AssertionError: la derivación … la resuelve el modelo en UN Check: expected 2 to equal 1`. Restaurado.
- **⚪5** (parseo canónico, partición no-raíz): `listObjects`/`listSubjects` devuelven el uuid del objeto (último
  segmento), no la partición; y no cruzan a `app`. Mutante (parsear desde la IZQUIERDA, `indexOf('|')`):
  `ℹ AssertionError: expected [] to deeply equal [ Array(1) ]` (el filtro de partición falla, lista vacía).
  Restaurado.

## Robustez del test de profundidad del 4-1 (nota del lote 4-1, familia E5 de 3b-8)

`tests/openfga_facts.spec.ts` · el bloque OVER-DEPTH del test `facts · 4-1 — profundidad can_<P> … (500 reps)`
se endureció con la MISMA tolerancia que el grupo E5 del 3b-8: pasada la cota, la evidencia es SOLO el veredicto
de profundidad del servidor (`authorization_model_resolution_too_complex`); la CONTENCIÓN (`deadline_exceeded`)
se reintenta acotada (`despiteContention`) y, si persiste, se DISTINGUE de «la cota subió». Antes el `continue`
sobre la contención dejaba `failures === 0` bajo saturación y el `isAbove(0, 0)` daba un **falso rojo por
carga**. Ahora, con `failures === 0`, se separan tres desenlaces: `contended > 0` ⇒ el `:8101` estuvo saturado
(no es que la cota subiera; reinícialo), `resolvedOver === ROUNDS` sin contención ⇒ la cota SUBIÓ (rojo real),
y `failures > 0` ⇒ la cota confirmada. **Sin skip, 22 intacto** (los 22 saltos siguen exigiendo las 10 rondas
enteras). El test siguió verde en todas las corridas (no flaqueó); la robustez es para la saturación futura.

## Las 4 cifras + tope 3 (todas verdes, corridas a fichero)

| modo | antes (4-3) | ahora | delta |
|---|---|---|---|
| `npm test` (`:8101`) | 883 | **910** | +27 |
| `test:sqlite-file` (`:8101`) | 888 | **915** | +27 |
| `test:pg` (`:8101`) | 982 | **1009** | +27 |
| `test:mysql` (`:8101`) | 982 | **1009** | +27 |
| **`npm test` (`:8103`, tope 3)** | — | **910** | (todas verdes; la cara whenTrue del truncado midió aquí) |

+27 = `relations_openfga.spec.ts` (20: 17 del contrato del puerto sobre el driver REAL + 1 espía «1 Check» +
1 ⚪5 + 1 truncado MEDIDO) + `relations_bridge.spec.ts` (7: 2 del caso-exploit rojo/verde + 5 de paridad).
`tsc` (ambos tsconfig), `typecheck`, `check:purity` y `build` limpios. `:8101` y `:8103` a **0 stores** al
cerrar (el guard barrió; `openfga-tiny` eliminado).

## Notas de diseño / decisiones

- **`listObjectsMaxResults`** es el mecanismo honesto del truncado: `ListObjects` no da bandera ni cursor, así
  que el driver se configura con el tope del servidor y señala `truncated` cuando recibe `>= tope`. Ponerlo por
  debajo del tope real daría un truncado FALSO; por encima, perdería el corte. La spec lo detecta del servidor.
- **Filtro por partición y truncado**: `ListObjects` enumera el tipo en TODAS las particiones (la partición vive
  en el id), así que el tope se consume entre todas y el filtro por partición se aplica DESPUÉS — otra razón para
  señalar el truncado y no callar (va al README en 4-6).
- **`client` es soft-private** (como el driver de roles) para que el espía de «1 Check» pueda envolver
  `client.check`; los demás campos son `#privados`.
- **Aislamiento en `openfga`**: el harness del contrato provisiona un store fresco por caso (precedente del
  harness `facts` de roles). El guard de `bin/test.ts` barre los stores al cerrar (≈18 por corrida del contrato).

## Lo que NO se hizo, y por qué

- **`enumerateRelations` real (origen de `authz:reconcile` de relaciones)**: capacidad `false` (whenFalse ⇒ 500).
  Es 4-5, con el reconcile de relaciones.
- **F-01/F-02 anclados con mutante de conflación; la carrera `defineRelationsConfig`↔`syncAuthzCatalog`; el
  gate del modelo fusionado en el camino del SYNC; la config de relaciones persistida bajo el gate de versión
  (🟡3)**: son 4-5. Este lote cierra el 🔴 (F-05 + el exploit VERDE); la frontera con dientes y la carrera son
  el siguiente lote.
- **La rama `E_AUTHZ_PURGE_INCOMPLETE` de `purge*`**: implementada (re-lee y demuestra cero), pero solo se
  ejercita el camino feliz (R-07/R-08 del contrato demuestran el cero). El 500 es defensa; forzarlo pediría un
  doble del cliente que devuelva residuo — se puede añadir en 4-6 si el juez lo pide, no cambia el mecanismo.
- **Paginación con cursor de `listObjects`**: `ListObjects` no tiene `continuation_token`; su respuesta al
  desbordar el tope es la SEÑAL de truncado, no un cursor. `listSubjects`/`purge*` sí paginan `Read` hasta agotar.
- **Wiring del `RelationsManager` en el manager/config principal** (`defineRelationsConfig` persistida): fuera de
  este lote; el exploit y la paridad construyen el manager de relaciones a mano sobre los drivers reales.

Nada del plan resultó imposible ni contradictorio con el código: el caso-exploit se reprodujo (escalada con el
driver directo) y se cerró (422 + check false con F-05), MEDIDO contra el `:8101` en el store compartido.
