# `2.4.0-alpha.3` — informe del implementador (INCREMENTAL)

**Base:** HEAD `7e21c46` = `2.4.0-alpha.2`, árbol limpio al arrancar (2026-09-02). Especificación:
`alpha3-tester-casos.md`. Decisiones de forma del coordinador: D-1..D-5 (ver §2). Sin commits, sin subir
`version`.

Este fichero se escribe caso a caso: cada bloque registra el ROJO observado (fichero:línea o aserción),
el mutante con el que se volvió a ver rojo tras la implementación, y lo que quedó.

---

## 0 · Cómo se corre un caso suelto

`node --import @poppinss/ts-exec bin/test.ts --files=<fichero>` (Japa `--files`). Toda corrida a fichero
en `/tmp/claude-1000/.../scratchpad/` o `/tmp/*.log`.

---

## 1 · Casos, en el orden del tester (A→F)

Formato: **caso** → fichero · ROJO observado (aserción/línea) · MUTANTE que lo devuelve a rojo (log en
`$S/<nombre>.log`, `$S` = scratchpad de la sesión).

### Bloque A — el cableado (`tests/relations_service.spec.ts`, grupo `alpha.3 · A`; `tests/configure.spec.ts`)

| caso | ROJO observado (antes de tocar código) | mutante (tras el verde) |
|---|---|---|
| **A1** | `relations_service.spec.ts:200` «el provider no cablea relations.onRelationWrite (cero eventos por el singleton): expected [] to have a length of 1» | quitar `onRelationWrite: relations.onRelationWrite` del provider ⇒ el mismo rojo (`A12_mut.log`) |
| **A2** | `:234` «relations.assertWrite no llega al manager: el owner ENTRÓ por el singleton» | quitar `assertWrite: relations.assertWrite` ⇒ rojo (`A12_mut.log`) |
| **A3** | `:183` «(ii) relations.requireActor: true no lanzó» (y (iii) no compilaba: la clave no existía) | `config.requireActor ?? relations.requireActor` ⇒ (ii) rojo (`A3_mut1.log`); `relations.requireActor \|\| config.requireActor` ⇒ (iii) rojo con `ActorRequiredError` (`A3_mut2.log`) |
| **A4** | verde de nacimiento (no-regresión: el cableado es `?.`, sin default ruidoso) | — |
| **A5** | forma: verde en cuanto el stub la tuvo; `tsc --noEmit`: rojo `TS2678: Type '"purgeObject"' is not comparable to type '"relate" \| "unrelate"'` (el tipo del evento) — el diente de TIPOS | declarar el hook también en `hooks` ⇒ la aserción «un solo home» rojo (no ejecutado: es la aserción `notInclude(hooksBlock, 'onRelationWrite')` + `lengthOf(match, 1)`) |
| **A6** | `:315` «assertWrite no está cableado (el 0 de arriba era por el motivo equivocado): expected +0 to equal 1» | el mismo mutante que A2 lo pone rojo (`A12_mut.log`, tercera aserción) |

Verde: 11/11 (`A_green.log`), `configure.spec.ts` 4/4 con el stub compilando (`A5_green.log`).

### Bloque B — `transactional` (`tests/relations.spec.ts` L-2; `tests/relations_database.spec.ts` L-4; runner; `tests/trx_docs.spec.ts`)

| caso | ROJO observado | mutante |
|---|---|---|
| **B1** | «el evento de relaciones no lleva transactional: true con { transaction }: expected [['relate', undefined],…]» (`B1_red.log`) | `!== undefined` sin el `null` ⇒ borde rojo en `unrelate` con `{ transaction: null }` (`B1_mut1.log`); emitir `transactional: false` sin trx ⇒ `notProperty` rojo (`B1_mut2.log`) |
| **B2** (`sqlite-file`) | `relations_database.spec.ts:803` «el evento no lleva transactional: true y el sink no puede diferir» — y la siguiente aserción sería «un rollback dejó un registro de auditoría firme» (`B2B3_red.log`) | la marca solo en `relate` ⇒ la mitad de `unrelate` rojo (no ejecutado como mutante aparte: la aserción `:emitidos[2].transactional` lo cubre) |
| **B3** cara `true` (`sqlite-file`/pg/mysql) | `relations_contract.ts` «el evento de una escritura inscrita en tu transacción no lleva transactional: true (las ocho)» — rojo con 0/8 antes de B, 4/8 tras B (faltaban las purgas, E), 8/8 tras E | — (es el runner) |
| **B3** cara `false` (dobles, `:memory:`) | verde de nacimiento (no-regresión: «cero eventos» con una escritura rechazada) | — |
| **B4** | sin cambios (se conserva `relations_openfga.spec.ts:446` tal cual) | — |
| **B5/F1** | el caso no existía; la frase estaba publicada desde L-6 (verde al nacer: es letra) | quitar la frase del README ⇒ rojo (`isString(sentence)`) |

### Bloque C — invariante 13 (`tests/relations.spec.ts`; `relations_database.spec.ts` L-4; `relations_openfga.spec.ts` FUERA de la guarda)

| caso | ROJO observado | mutante |
|---|---|---|
| **C1** | «una escritura de relación que vence el deadline no notifica indeterminate: true: expected [] …» (`C1_red.log`) | notificar sin la marca ⇒ rojo (`C1_mut_b.log`); notificar DESPUÉS (`setImmediate`) ⇒ rojo por la secuencia/eventos (`C1_mut_c.log`); notificar en cualquier `catch` ⇒ C2 (i) rojo (no ejecutado aparte: C2 (i) lo cubre con `ECONNREFUSED`) |
| **C2** | verde de nacimiento, escrito DESPUÉS de C1 (no-regresión; (iv) el freeze se mide ahora en los 4 modos y sin trx) | — |
| **C3** (pg/mysql) | `relations_database.spec.ts` «el deadline dentro de tu transacción tiene que publicar indeterminate: true Y transactional: true: expected [['relate', true, false]] to deeply equal [… , ['relate', true, true]]» (`C3_red.log`, PG); en MySQL verde tras `#write` con la trx VIVA (`C3_mysql.log`); `sqlite-file` la cara honesta (`SQLITE_BUSY`, sin indeterminado) | mantener `indeterminate` y perder `transactional` ⇒ rojo (lo cubre la tupla `[op, transactional, indeterminate]`) |
| **C4** (4 modos, sin `:8101`) | «el deadline de openfga (relations) no publica indeterminate: true: expected []» (`C4_red.log`); 503 en < 1 s ya era verde (el deadline existía) | `maxRetry: 1` ⇒ pasa del presupuesto de 1 s (no ejecutado: cambiaría el driver, que este lote no toca) |

### Bloque D — paridad del despacho (`tests/relations.spec.ts`)

| caso | ROJO observado | mutante |
|---|---|---|
| **D1** | `:666` «el error del hook tumbó un relate ya escrito» (`CD_red.log`) | sin `try/catch` ⇒ rojo (`D1_mut_a.log`); tragar sin registrar ⇒ rojo por `isNotEmpty(logged)` (`D1_mut_b.log`) |
| **D2** | `:697` «nadie registró nada (el hook no se esperó: el rechazo se perdió como unhandled rejection)» | sin `await` ⇒ rojo (`D2_mut.log`) |
| **D3** | `:749` «(que rechaza/relate): la escritura ENTRÓ con un assertWrite async (la promesa se descartó: fail-open)» — **H2 medido** | quitar la detección del thenable ⇒ rojo (`D3_mut.log`) |
| **D4** | `:828` «(uuid con #/relate): el actor mal formado ENTRÓ»; borde `:849` «actor: {} satisface requireActor» — **H3 medido** | validar solo en `relate` ⇒ rojo en `unrelate` (`D4_mut_a.log`); exigir con `!actor?.uuid` ANTES de validar ⇒ el borde rojo con `E_AUTHZ_ACTOR_REQUIRED` en vez de identidad (`D4_mut_c.log`). Nota: «truthiness antes de validar» tal como lo enuncia el tester (`D4_mut_b.log`) resultó EQUIVALENTE con `{}` (validar después también da 422 de identidad); el mutante real del orden es el de `D4_mut_c` |

### Bloque E — las purgas (`tests/relations.spec.ts`; runner R-17; `relations_database.spec.ts`)

| caso | ROJO observado | mutante |
|---|---|---|
| **E1** | `:908` «la purga no notifica (o notifica una vez por tupla borrada): expected [] to have a length of 1» (`E_red.log`) | `operation: 'unrelate'` ⇒ rojo (`E1_mut_a.log`); notificar dos veces ⇒ `lengthOf(events, 1)` rojo (`E6_mut.log`, también R-17) |
| **E2** | `:943` «la purga vacía no notifica» | condicionar al «borró algo» ⇒ rojo (`E2_mut.log`) |
| **E3** | tras D4 el 422 ya salía; rojo por «con actor, entran» (eventos vacíos) — **breaking D-3** | exigir el actor DESPUÉS del driver ⇒ «cero llamadas» rojo (`E3_mut.log`) |
| **E4** (`sqlite-file`/pg/mysql) | `relations_database.spec.ts:912` «la purga no notifica» (`E46_red.log`) | — (la marca la cubre B1's mutante) |
| **E5** | «una purga que vence el deadline … no notifica indeterminate: true» | los de C1 |
| **E6** | `:266` «la purga no notifica exactamente UNO (¿uno por ortografía?)» | dos eventos ⇒ rojo (`E6_mut.log`) |
| **E7** | R-17 rojo en los dos dobles «la purga no notifica exactamente UN evento por llamada: … length of 4 but got 3» (`E7_red.log`); `relations_harness.spec.ts` con `EXPECTED_CASES = 21` y `BEYOND_JUEZ.purgeEvents` | — |
| **E8** | adaptado a D-2 (opcionales, no unión): el stub hace `switch (event.operation)` con las cuatro ramas y COMPILA; el «tsc caza la pérdida de estrechamiento» del tester NO aplica con opcionales (ver §6) | — |
| **E9** | verde de nacimiento salvo la parte de eventos (rojo con E1) | — |

Verde: unidad 35/35, dobles 42/42 (21×2), `database` 52/52 en sqlite-file/PG/MySQL, `openfga` contra el `:8101` 31/31 (R-17 + C4 + L-5 intactos).

---

## 2 · Decisiones D-1..D-5 tal como quedaron

| # | Decisión del coordinador | Cómo quedó en el código |
|---|---|---|
| **D-1** | UN evento por purga, `operation: 'purgeObject' \| 'purgeSubject'`, objetivo + partición, sin conteo, uno aunque el driver barra dos ortografías | `RelationsManager.purgeObject/purgeSubject` construyen `{ operation, object\|subject, partition, actor?, transactional? }` y lo pasan por `#write` + `#notify` una vez; la partición viaja TAL COMO la pasó el llamante (E6 lo fija); las purgas NO pasan por `assertWrite` (E9). `RelationWriteEvent` documenta el «sin conteo» y la receta (`enumerateRelations`/`listSubjects` antes). |
| **D-2** | La forma espeja `AuthzWriteEvent`: campos opcionales, no unión discriminada | `RelationWriteEvent` deja de `extends RelationRef` (cuya `operation` sigue siendo `'relate' \| 'unrelate'`, tipo publicado de R-13) y declara `operation` con las cuatro, `subject?`, `relation?`, `object?`, `partition`, `expiresAt?`, `actor?`, `transactional?: true`, `indeterminate?: true`. Consecuencia de tipos (declarada en el CHANGELOG): un sink que hacía `event.object.id` sin estrechar recibe error bajo `strict` (`object` es opcional); la receta es `switch (event.operation)` o `event.object?.id`. El stub trae el `switch`. **E8 del tester queda adaptado**: con opcionales el compilador NO obliga a decidir qué hacer con una purga (ese era el argumento de la unión) — es el precio que la decisión asume; ver §6. |
| **D-3** | `actor` y `requireActor` alcanzan a las purgas (breaking, fail-closed) | `RelationPurgeOptions extends RelationTransactionOptions { actor? }` (exportado en `index.ts`), `#assertActor(options, op)` en las cuatro; el `ActorRequiredError` nombra `relations.<op>`. CHANGELOG: **BREAKING**. |
| **D-4** | Hooks en `relations.*` de `defineConfig`, un solo home; el stub los muestra | `AuthorizationConfig.relations.{assertWrite, onRelationWrite, requireActor}` con docblocks; el provider los pasa; el stub declara `onRelationWrite: onAuthzRelationWrite` + `assertWrite`/`requireActor` comentados DENTRO de `relations`; `configure.spec.ts` A5 fija que `hooks` no los tiene y que `onRelationWrite:` aparece una sola vez. |
| **D-5** | `relations.requireActor ?? config.requireActor`, tres sentidos con caso | `authz_provider.ts`: `requireActor: relations.requireActor ?? config.requireActor`; A3 (i)/(ii)/(iii); dos mutantes (`??` al revés, `\|\|`) muertos. |

Ninguna resultó imposible ni contradice un invariante.

---

## 3 · H1–H4

| H | Cierre | Caso |
|---|---|---|
| **H1 🔴** hook que lanza tumba la escritura | `#notify` = `try { await hook } catch { #logHookFailure }` (réplica de `manager.ts:3276-3293`); el log nombra la operación: «authz: el hook onRelationWrite falló tras '<op>' (la escritura sí se aplicó)». El hook se ESPERA. | D1, D2 (+ mutantes `D1_mut_a/b`, `D2_mut`) |
| **H2 🔴** `assertWrite` async = bypass | `#assertWrite`: si devuelve un thenable ⇒ `AuthorizationConfigError.asyncAssertWrite('relations.<op>')` (500 `E_AUTHZ_CONFIG`) ANTES del driver; la promesa descartada recibe un `.then(undefined, noop)` para no salir como unhandled rejection (el caso lo mide con `process.on('unhandledRejection')`). Cierra rechace o resuelva. | D3 (+ `D3_mut`), F4 byte a byte |
| **H3 🟠** actor sin validar | `#assertActor`: `assertSubject` si viene (422 `E_AUTHZ_INVALID_IDENTITY`), después `requireActor`; `actor: {}` es 422 de identidad, no «requerido». En las cuatro. | D4 (+ `D4_mut_a`, `D4_mut_c`) |
| **H4 🟠** README:176 falso y sin caso | Ahora es verdad (B1/B2/B3/E4) y `trx_docs.spec.ts` (grupo L-6) sujeta la frase con los dos puertos, la marca y `trx.after('commit')`. | B5/F1 |

---

## 4 · Lo que NO se hizo y por qué

- **`void \| Promise<void>` en `RelationsManagerOptions.onRelationWrite`** (D2 del tester lo pedía como «ampliación, no breaking»): NO es ampliación — `(e) => events.push(e)` (el propio runner en `relations_contract.ts:674`) deja de compilar, porque un retorno libre solo es asignable a `void` a secas. La opción PUBLICADA conserva `void` (que ya admite `async`) y el docblock dice que la promesa se espera; la clave NUEVA `relations.onRelationWrite` sí va tipada `void \| Promise<void>` (coherente con `hooks.onWrite`). El comportamiento (D2) lo fija el caso.
- **Conteo en la purga, `assertWrite` en las purgas, `indeterminate` en el runner, eventos en `authz:relations:reconcile`, `group#member`**: fuera por las razones del tester (§5 de su documento), sin cambios.
- **Mutante C4 (`maxRetry: 1`)**: no ejecutado — toca el driver `openfga`, que este lote no modifica; el caso mide `< 1 s` y lo cazaría.
- **El caso «hooks.onRelationWrite también declarado» de A5**: la aserción está escrita (`notInclude(hooksBlock, 'onRelationWrite')` + una sola aparición); no se ejecutó el mutante sobre el stub.
- **`retryable`/otros campos del `ActorRequiredError`**: no se tocan; solo el mensaje nombra ahora `relations.<op>` (el caso E3 lo comprueba con `include(caught.message, op)`).
- **No se cambió ningún driver** (`database_relations_driver.ts`, `openfga_relations_driver.ts`): todo el lote vive en el manager, el provider, los tipos, el runner y las docs.

---

## 5 · Cifras de cierre

Estáticas: `npx tsc --noEmit -p tsconfig.json` ✅ · `npm run typecheck` ✅ · `npm run check:purity` ✅ ·
`npm run build` ✅ (`verify_static.log`, `static=0`).

| modo (todos con `OPENFGA_TEST_URL=http://localhost:8101`) | base alpha.2 | alpha.3 | Δ | log |
|---|---|---|---|---|
| `npm test` (sqlite `:memory:`) | 1074 | **1107** | +33 | `/tmp/s.log` |
| `npm run test:sqlite-file` | 1095 | **1131** | +36 | `/tmp/sf.log` |
| `npm run test:pg` | 1190 | **1226** | +36 | `/tmp/pg.log` |
| `npm run test:mysql` | 1190 | **1226** | +36 | `/tmp/my.log` |

Cero ✖ en los cuatro. Desglose de los +33 de `:memory:`: A1–A4/A6 (5) + A5 (1) + B1 (1) + B5 (1) + C1 (1)
+ C2 (1) + C4 (1) + D1/D2 (2) + D3 (1) + D4 (2) + E1/E2/E3/E5/E9 (5) + E6 (1) + R-17 × 4 harness (4) + F (7)
= 33. Los +3 de los otros modos: B2, C3, E4 (grupo L-4, pool ≥ 2). Sin `skip`. Aditivo: ningún caso
existente cambió de resultado; los tres títulos del runner que cambiaron (`transactionalWrites:true/false`)
solo AMPLÍAN su aserción y el harness de conteo los reconoce.

Sin `OPENFGA_TEST_URL` no se midió aparte (la base del encargo es la de servidor; la sqlite sin él daba
825 y no es una regresión).

Árbol: 17 ficheros modificados + `tests/relations_events_docs.spec.ts` nuevo; **sin commit, sin subir
`version`** (sigue `2.4.0-alpha.2`).

---

## 6 · Contradicciones entre el tester y el código (y con las decisiones)

1. **D2 · «ampliar el tipo a `void | Promise<void>` (ampliación, no breaking)»** — es breaking de tipos para
   cualquier sink que devuelva algo (`(e) => arr.push(e)`), incluido el runner publicado. Ver §4; resuelto
   conservando `void` en la opción publicada y `void | Promise<void>` en la clave nueva del config.
2. **E8 · «con opcionales el stub sigue compilando pero pierde el estrechamiento — por eso el stub tiene
   que acceder a `event.relation` en una rama donde la unión lo garantiza»** — el tester escribió E8 para
   la unión discriminada (su D-2); el coordinador decidió opcionales (paridad con `AuthzWriteEvent`). Con
   opcionales NO existe el diente «tsc caza la pérdida de estrechamiento» (no hay nada que perder). El
   stub compila con `switch (event.operation)` y comentarios por rama; el diente de tipos real de A5 es
   que `'purgeObject'` sea comparable a `event.operation` (rojo observado: `TS2678`). Lo que los opcionales
   NO expresan y la unión sí: «el compilador obliga a decidir qué hacer con una purga». Se reporta, no se
   implementa (regla D-2).
3. **D4 · mutante «comprobar `requireActor` con truthiness antes de validar ⇒ `actor: {}` pasa»** — tal
   como está enunciado resultó EQUIVALENTE: si después de la comprobación de presencia se valida, `{}`
   sigue dando 422 de identidad. El mutante que sí distingue el ORDEN es exigir con `!actor?.uuid` antes
   de validar (`{}` ⇒ `E_AUTHZ_ACTOR_REQUIRED`): ése es el que mata el caso del borde (`D4_mut_c.log`).
4. **B5/F1 y F6 «ROJO hoy: el caso no existe»** — son casos de letra: nacen verdes porque la frase ya
   estaba publicada; su rojo es quitar/suavizar la frase. No hay contradicción, se anota para el auditor.
5. **C3 en `sqlite-file`**: el tester lo describe como «SQLITE_BUSY ⇒ 503 sin evento indeterminado» —
   correcto; pero el evento del PRIMER `relate` (T1, con `transactional: true`) SÍ existe, así que la
   forma medida es `[['relate', true, false]]`, no «cero eventos» (mismo detalle que en roles).
6. **Numeración**: `relations/manager.ts:210/230` y `:266/:273` del tester coinciden con el HEAD leído;
   `authz_provider.ts:47-56` también. `README.md:176` y `:566` también (la segunda va partida en dos
   líneas, 565-566: el caso F6 usa `\s+`).
