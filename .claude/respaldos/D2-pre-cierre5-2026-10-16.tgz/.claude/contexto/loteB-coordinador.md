# Lote B (plan 2.5) — brief del coordinador (2026-10-15) ⇒ `2.5.0-alpha.2`

**Base:** `main` en `beb1d0a` (= `v2.5.0-alpha.1`, publicada). Único agente muta el árbol; **sin commit, sin tocar `version`,
sin `git push`** (los hace el coordinador). Rama en la salida: `main`.

**Qué es el lote B:** las rupturas que tienen que entrar ANTES de la primera estable 2.x y antes del deny (lote D). Lo decidió
el juez de la ronda 2 (`panel-tenencia-2-juez.md` §1, tabla B1–B9 y fila «B» de la tabla de lotes, línea 321) y lo firmó el dueño
el 2026-10-14 (`decisiones-dueno-2026-08-28.md` §2026-10-14 (2): plan completo, D7 «entran B6 y B7», D11 «claves desconocidas ⇒ 422»).
**No hay panel nuevo**: el panel ya corrió; lo que hay que hacer es implementar B1–B9 con sus condiciones, y después auditor sobre el diff.

## Entorno (medido, no el de la memoria vieja)
`source ~/.config/nvm/nvm.sh && nvm use 22`; **OpenFGA real = `OPENFGA_TEST_URL=http://localhost:8090`** (contenedor `openfga-dev`;
`:8101` NO responde); `TEST_PG_URL="postgres://postgres:$(docker exec postgres18 printenv POSTGRES_PASSWORD)@127.0.0.1:5432/authz_test"`;
`docker restart openfga-dev && sleep 8` antes de cada suite; suites `npm test`, `npm run test:sqlite-file`, `test:pg`, `test:mysql`;
gates `npm run check:guard-mutants`, `npm run check:flag-mutants`, `TEST_DB=sqlite-file npm run cutover-runbook`, `TEST_DB=pg npm run cutover-runbook`.
Cifras de partida (alpha.1): 1673 / 1701 / 1798 / 1800 (2/2/1/1 skipped); 104/104; 36/36; runbook verde ×2.

## Las nueve piezas (del juez; severidad hoy; qué exige)

| # | Pieza | Dónde hoy | Exigencia del juez / coordinador |
|---|---|---|---|
| B1 | Ciclos de `includes` ⇒ 422 en `defineRelationsConfig`, **nombrando el ciclo** | `src/relations/define_relations_config.ts:265-285` (hoy acepta `editor ⊇ viewer ⊇ editor`; M3 medido: OpenFGA rechaza CUALQUIER ciclo al publicar; `database` lo sirve ⇒ paridad rota) | Caso por ciclo directo (`a ⊇ a`), de 2 y de 3; mensaje con la cadena `type#a → type#b → type#a`; mutante. Paridad: el mismo 422 vale para los dos drivers porque es config. Cuatro líneas de cierre (punto 5 de CLAUDE.md). |
| B2 | Claves desconocidas en la spec de relaciones (en el tipo Y en la relación) ⇒ 422; `frozenTypes` deja de descartar en silencio | `define_relations_config.ts:299-304` (`frozenTypes` copia solo `name`/`includes`; tester H3 midió que `deny: true`/`denny: 1` se TIRAN) | **Propiedad universal (L5, 5.ª iteración): ninguna clave de una spec de config se descarta.** Caso por spec: `objectTypes[i]` y `relations[j]`, y también la raíz de la spec si tiene claves. Revisar si `defineConfig` (roles) tiene el mismo agujero: gemelo (a) obligatorio — caso o «no aplica porque…» con evidencia. Código de error propio (`E_AUTHZ_RELATIONS_CONFIG_UNKNOWN_KEY` o el que ya use la familia), lista blanca explícita por nivel. |
| B3 | Userset de un tipo que no sea `group#member` ⇒ 422 en las ESCRITURAS de los dos drivers (y en el manager, L-0) | `database` lo guarda inerte; `openfga` responde 400 ⇒ hoy 503 mal clasificado (auditor [N 9] ronda 1) | Mismo función/clase/código/mensaje en manager + 2 drivers ANTES de tocar backend (patrón F-05 `assertRelationDeclared`). Cero `Write`/`INSERT` (espía). Entrada en la guardia de superficie si es una guarda transversal nueva: fila con mutante por capa; si se integra en F-05, que las variantes F-05 existentes la cubran con un mutante nuevo. Decidir y escribir cuál. Lecturas (`check`, `listSubjects` con userset raro): decidir con tabla de verdad; mínimo: no 503 mal clasificado. |
| B4 | `listObjects` de `openfga`: `truncated` por deadline (opción `listObjectsDeadlineMs`, umbral 0,9×) **y** corrección de la letra de `README.md:635` («never a mute partial list» es FALSO hoy: M4 midió 200 con lista parcial sin señal) | `src/drivers/openfga_relations_driver.ts` (`listObjects` ~`:551`, `#listObjectsMax`, `withDeadline`) | **M8 activado (L8, 5.ª iteración, primera [N]):** propiedad universal «toda enumeración que se puede cortar devuelve `truncated` o lanza»; punto de paso ÚNICO = el envoltorio de lista del driver; **entrada en la guardia de superficie: fila «enumeración» con su mutante** (manifiesto `tests/fixtures/guard_manifest.ts`, mutantes `tests/fixtures/guard_mutants.json`). Caso con **reloj inyectado** (no `sleep`): si la llamada dura ≥ 0,9 × deadline del servidor configurado, `truncated: true`; par de capacidad si aplica (D15: `?:`, normalizada a `false`, con su par). Letra del README fijada por caso (`trx_docs`/`scope_depth` ya hacen eso). Decidir y escribir qué pasa con `listSubjects` (`Read` pagina: ¿se puede cortar?) y con `enumerateRelations`. |
| B5 | `toConfig` del reconcile: un fallo de lectura es un ERROR; `null` («no hay config persistida») sigue valiendo | `commands/authz_relations_reconcile.ts:530` (`.catch(() => undefined)`) | Tabla de verdad: {config leída, `null`, lanza} × {dry-run, real}. Fallo ⇒ exit ≠ 0 con letra y cero escrituras (en real). Línea distinta por rama (punto 7). Caso por el kernel de ace. L5. |
| B6 | `sqlScopeOutbox({ requireTransaction })` por defecto **`true`**; prerrequisito: el `ctx()` de `runScopeOutboxContract` pasa la trx | `src/scope_outbox.ts:310` (default `false`); `src/testing/scope_outbox_contract.ts` | «B6 con el par en el juez de la outbox»: el contrato publicado tiene que ejercer las dos caras (con trx ⇒ ok; sin trx ⇒ 500 con letra que nombra `requireTransaction`). Si el harness de tests encola sin trx en algún sitio, el rojo lo dice: ese rojo es la medida, documentarlo (c). README + CHANGELOG + §Upgrading. Mutante: poner el default en `false` ⇒ un caso rojo. |
| B7 | `runRelationsReconcile` a un subpath propio `./relations/reconcile` | `commands/authz_relations_reconcile.ts:66`; hoy se importa de `@jantstack/adonis-authz/commands/authz_relations_reconcile` (`index.ts:196`) | Nuevo entry en `package.json` `exports` (`./relations/reconcile` ⇒ fichero fino que reexporta SOLO `runRelationsReconcile` y sus tipos). ¿Se mantiene el viejo? Decisión: **NO se mantiene** (es la ruptura que entra antes de la estable), pero `./commands/*` sigue sirviendo la clase del comando: hay que comprobar que importar la función desde `./commands/authz_relations_reconcile` deja de ser posible o, si no se puede impedir sin romper el loader de ace, dejarlo escrito como límite con caso. `tests/purity`/inventario de exports (lote 0) y la guardia de imports por ruta resuelta (alpha.10 repaso) deben seguir verdes o cambiar con razón. |
| B8 | El verificador de roles (`modelPermissions`) lee el modelo `options.modelId` cuando está FIJADO, no el último | `src/drivers/openfga_driver.ts:2738-2739` (`readLatestAuthorizationModel`) | Caso: dos modelos publicados, pod fijado al viejo ⇒ el verificador lee el viejo. Falla cerrado en las dos direcciones (auditor R2-10). Mutante. |
| B9 | Letra: quitar `republishFusedModel` de `README.md:637-640`; cabecera «(2.5)» de `README.md:377` (`resourceAccess` existe desde 2.4.0-alpha.x: poner la versión real); `CLAUDE.md` punto 10 «2.4.0» ⇒ «2.5.0» (ya dice que aplica a 2.5.0: dejar una sola frase) | README, CLAUDE.md | Grep final: cero `republishFusedModel` en README/CLAUDE/src. |

## Reglas que aplican (CLAUDE.md «Cómo se decide un cambio»)
- Rojo observado ANTES de cada pieza (tabla §0 del informe, como en `loteA-informe.md`), verde, mutante por pieza.
- Punto 5: cuatro líneas de cierre (gemelos / tabla de verdad / casos existentes puestos rojos / linaje) **para B1, B2, B3 y B4** como mínimo.
- Punto 6: guardia de superficie — B3 y B4 tocan la guardia; una entrada sin mutante es rojo. No hay exenciones nuevas (serían firma del dueño).
- Punto 7: toda salida nueva dice qué rama corrió (B5).
- Punto 11 (D15): capacidades nuevas `?:` normalizadas a `false` con su par.
- CHANGELOG: sección `## [Unreleased]` (el coordinador la sella como `2.5.0-alpha.2`), una entrada por ruptura en estilo «problema → decisión → qué NO se hace y por qué»; README §«Upgrading to 2.5.0» ampliada con B1–B8 (qué se rompe y cómo se adapta).
- `tests/freeze.spec.ts`, `EXPECTED_FUSED`, `migration_stub.spec` **sin tocar** salvo razón escrita.
- Verificación final en los 4 modos + 3 gates, con cifras y skipped; el coordinador la repite y gana su medición.

## Entregable
`.claude/contexto/loteB-informe.md` con: §0 rojos observados por pieza; §1 piezas entregadas (ficheros, casos, mutantes); §2 cuatro líneas de
cierre de B1–B4 (y de cualquier otra que lo necesite); §3 tablas de verdad (B3 lecturas, B5, B6); §4 decisiones tomadas por el
implementador que el coordinador debe ratificar (lista corta, con alternativas descartadas); §5 cifras de los 4 modos + 3 gates;
§6 lo que NO se hizo y por qué. Terminar con `git status --short` y `git diff --stat`.
