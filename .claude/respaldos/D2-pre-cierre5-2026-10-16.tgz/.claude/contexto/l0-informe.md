# L-0 · F-05 con dientes en los DOS drivers de relaciones — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `723815b` (= R-15 commiteado). Árbol principal, SIN commits (los hace el dueño).
> Alcance: el lote L-0 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-0), que cierra el 🔴 2
> del auditor (`panel-trx-auditor.md`): F-05 vivía SOLO en el `RelationsManager`, los dos drivers no
> re-validaban tipo/relación aunque el docblock de `types.ts` lo publicaba, y `reconcileRelations`
> escribe por el DRIVER. Independiente de `{trx}`. Aditivo sobre lo publicado.

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l0-rojo.log`, `l0-verde.log`, `l0-mutante-openfga.log`, `l0-mutante-openfga-bridge.log`,
`l0-mutante-database.log`, `suite-*.log`, `suites-resumen.log`). Los mutantes se plantaron con `sed`
sobre la línea de la guarda y se restauraron en el MISMO comando (`grep -c MUTANT` = 0 al final,
`git status` limpio de restos).

## La decisión de diseño: UNA función, tres llamadores

`assertRelationDeclared(config, object, relation)` — exportada desde
`src/relations/define_relations_config.ts` (módulo puro: errores + gramática + puerto; regla 2 de
pureza intacta) — es el cuerpo que tenía `RelationsManager#assertDeclared`, sacado a función. La llaman:

1. el manager, primero (`#assertDeclared` delega en ella; corta antes del driver, como hasta hoy);
2. `OpenFgaRelationsDriver.relate`/`unrelate`, como PRIMERA línea (antes del `Read` de la tupla y del `Write`);
3. `DatabaseRelationsDriver.relate`/`unrelate`, como PRIMERA línea (antes de pedir la conexión).

Así la «doble validación» que avisaba el juez no puede desincronizarse: misma clase
(`RelationTypeUnknownError` / `RelationUnknownError`), mismo `code`
(`E_AUTHZ_RELATION_TYPE_UNKNOWN` / `E_AUTHZ_RELATION_UNKNOWN`), mismo mensaje, por cualquier puerta. El
manager sigue cortando antes; el driver es la red para quien entra por `manager.driver()` o por
`reconcileRelations`.

## Qué se implementó (por pieza, rojo→verde, con la salida roja literal)

### P1 · El caso-exploit del auditor POR EL DRIVER, contra el `:8101` y en el MISMO store

`tests/relations_bridge.spec.ts`, grupo «4-4 — el caso-exploit del auditor, en el store COMPARTIDO».
El caso «🔴 ROJO reproducido» de la Fase 4 —que AFIRMABA la escalada por el driver (`assert.isTrue(authorize(evil))`)—
se convierte en el caso L-0: `relations.relate(evil, 'assignee', {type:'role_binding', id:<roleUuid>}, APP_SCOPE)`
EN DIRECTO al driver ⇒ 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN` (`instanceOf RelationTypeUnknownError`),
**cero `Write` y cero `Read`** (espía sobre `client.write`/`client.read`), `roles.authorize(evil)` sigue
`false`, el binding de alice intacto; y `unrelate(alice, 'assignee', role_binding)` también 422 con cero
`Write` y alice sigue concediendo (sería un revoke por la puerta de relaciones).

Rojo contra `723815b` (sin la guarda), `l0-rojo.log`:
```
❯ relaciones · 4-4 — el caso-exploit del auditor, en el store COMPARTIDO / L-0 · relate(evil, assignee, role_binding, S) EN DIRECTO al driver ⇒ 422 con cero Write, y authorize(evil) sigue false
ℹ AssertionError: esperaba 422 y llegó ROJO: el driver aceptó role_binding/assignee (F-05 no vive en el driver): expected undefined to equal 422
```
(el caso se reordenó después para que la línea roja sea la ESCALADA y no el «no lanzó»; ver el mutante en P5.)

Verde con la guarda en `openfga_relations_driver.ts` (`l0-verde.log`, 108/108 de las cinco specs tocadas).

### P2 · Paridad: el MISMO 422 en los dos drivers, para el tipo y para la relación, en `relate` y `unrelate`

`tests/relations_bridge.spec.ts`, grupo «paridad database ↔ openfga», caso «L-0 · F-05 en el DRIVER: el MISMO
422 (clase y code) en los dos…». Cuatro intentos —`role_binding#assignee`, `scope#parent`,
`document#assignee` (relación no declarada de un tipo declarado), `group#viewer` (relación no declarada del
built-in)— × `relate`/`unrelate`: `database` da `422:<code>` y `openfga` da EXACTAMENTE lo mismo; control:
`group#member` entra en los dos.

Rojo literal (`l0-rojo.log`):
```
ℹ AssertionError: database · relate · tipo no declarado (role_binding): expected 'ACEPTADO' to equal '422:E_AUTHZ_RELATION_TYPE_UNKNOWN'
```
Y el detalle que el auditor llamaba «503 mal clasificado»: en `openfga`, `document#assignee` salía como **503**
del servidor (relación desconocida en el modelo), no como 422 (`l0-rojo.log`):
```
ℹ AssertionError: relate · document#assignee: expected 503 to equal 422
```

### P3 · Driver `database`: 422 ANTES de pedir la conexión (espía = la `database` inyectada)

`tests/relations_database.spec.ts`, grupo «L-0 · F-05 en el driver: 422 ANTES de tocar la conexión (espía)».
El constructor admite `database: { connection(name) }` inyectable: el espía CUENTA cada `connection()`.
Tres casos: tipos no declarados (`role_binding`, `scope`, `folder`) × relate/unrelate ⇒ 422
`E_AUTHZ_RELATION_TYPE_UNKNOWN`, `connections() === 0`, cero filas; relaciones no declaradas
(`document#assignee`, `group#viewer`) ⇒ 422 `E_AUTHZ_RELATION_UNKNOWN`, cero accesos; control: lo declarado y
`group#member` escriben (2 filas, `connections() > 0`).

Rojo literal:
```
ℹ AssertionError: relate · role_binding: relate aceptó el tipo no declarado 'role_binding': expected undefined to equal 422
ℹ AssertionError: relate · document#assignee: expected undefined to equal 422
```

### P4 · Driver `openfga`: 422 ANTES del `Read`/`Write` (espía sobre el cliente)

`tests/relations_openfga.spec.ts`, grupo «L-0 · F-05 en el driver: 422 ANTES de tocar el store (espía)». Dos
casos (tipos: `role_binding`/`scope`/`role`/`folder`; relaciones: `document#assignee`, `document#can_p0`,
`group#viewer`) × relate/unrelate ⇒ 422 con `calls = {read: 0, write: 0}`; control: `document#viewer`
escribe y `check` lo ve. Rojo literal como en P3 (`expected undefined to equal 422` para el tipo,
`expected 503 to equal 422` para la relación).

### P5 · El MUTANTE: quitar la guarda del driver ⇒ el caso-exploit ROJO en los dos drivers

Mutación: `sed` comenta las DOS líneas `assertRelationDeclared(this.#config, object, relation)` del driver
(relate y unrelate); corrida; `sed` inverso; `grep -c MUTANT` = 0.

**openfga** (`l0-mutante-openfga-bridge.log`, solo la spec puente): 9 passed, **2 failed**. La línea roja es
la ESCALADA literal, medida contra el `:8101`:
```
❯ relaciones · 4-4 — el caso-exploit del auditor, en el store COMPARTIDO / L-0 · relate(evil, assignee, role_binding, S) EN DIRECTO al driver ⇒ 422 con cero Write, y authorize(evil) sigue false
ℹ AssertionError: ROJO: una escritura de relations EN DIRECTO al driver concedió en roles.authorize (la escalada del auditor): expected true to be false
❯ relaciones · 4-4 — paridad database ↔ openfga … / L-0 · F-05 en el DRIVER: el MISMO 422 …
ℹ AssertionError: paridad · relate · tipo no declarado (role_binding): database y openfga divergen: expected 'ACEPTADO' to equal '422:E_AUTHZ_RELATION_TYPE_UNKNOWN'
```
(La primera corrida del mutante, `l0-mutante-openfga.log`, con bridge + openfga: 32 passed, **4 failed** —los
dos de arriba más los dos del espía de P4.)

**database** (`l0-mutante-database.log`, bridge + database + reconcile): 74 passed, **4 failed**:
```
ℹ AssertionError: database · relate · tipo no declarado (role_binding): expected 'ACEPTADO' to equal '422:E_AUTHZ_RELATION_TYPE_UNKNOWN'
ℹ AssertionError: relate · role_binding: relate aceptó el tipo no declarado 'role_binding': expected undefined to equal 422
ℹ AssertionError: relate · document#assignee: expected undefined to equal 422
ℹ AssertionError: solo la declarada (document#viewer) cuenta como escrita: expected 3 to equal 1
```
La última es el reconcile de P6 SIN `toConfig`: con la guarda del driver quitada, el embudo desaparece y las
tres tuplas se escriben. Es la prueba de que en esa puerta los dientes son los del DRIVER.

### P6 · `reconcileRelations` embuda por la misma validación (`skipped.undeclared`)

`src/relations/reconcile.ts`:
- `skipped: { expired, undeclared }`. Con `toConfig`, en el MISMO bucle que descarta la caducada: una tupla
  viva cuyo tipo no cabe (`toConfig.hasType`, que incluye el built-in `group`) o cuya relación no está
  declarada (`toConfig.isDeclared`) se descarta ANTES del driver y se cuenta; el tipo va además a
  `modelDrift`. `--dry-run` y la pasada real dan los MISMOS números. `usableSource` (seguro R-17) pasa a
  ser `sourceTuples.length` (lo descartado ya no está).
- Sin `toConfig` (o con una que no coincida con la del driver del destino): `relateOrSkip` llama a
  `to.relate` y, si el driver lanza EXACTAMENTE `RelationTypeUnknownError`/`RelationUnknownError`, cuenta en
  `skipped.undeclared` y descuenta de `written`/`updated`; cualquier otro error se propaga tal cual. Nunca
  un throw a mitad de pasada por una tupla que el reporte puede contar, nunca un silencio.
- Una tupla no declarada ya PRESENTE en el destino deja de estar «respaldada» por el origen: es `extra`, y
  `--prune` la barre (hasta hoy se quedaba como `unchanged`).
- `commands/authz_relations_reconcile.ts` · `relationsReconcileLines`: `skipped.undeclared > 0` es línea de
  **error** y `clean = false` (exit ≠ 0) —a diferencia de `expired`, es una relación VIVA que no llegó—; el
  resumen la nombra.

Casos (`tests/relations_reconcile.spec.ts`, grupo «L-0 · F-05 embuda el reconcile»): origen = doble en memoria
con config que declara `folder` y `document#publisher`; destino = `DatabaseRelationsDriver` REAL con la config
del contrato (ninguno de los dos), envuelto para CONTAR qué `relate` le pide el reconcile.
- SIN `toConfig`: `written 1`, `skipped.undeclared 2`, `modelDrift []`, el driver recibió las 3 y rechazó 2;
  censo en `authz_relations`: solo `document#viewer`.
- CON `toConfig`: dry-run `written 1` / `undeclared 2` / `modelDrift ['folder']` / cero `relate`; pasada real
  los MISMOS números y el driver solo vio `document#viewer`; segunda pasada `written 0`, `unchanged 1`,
  `undeclared 2` (no desaparecen sin rastro).
- La MISMA tupla `folder` en origen y destino (doble): `extra 1` en dry-run, `deleted 1` con `--prune`.

Rojo literal (`l0-rojo.log`): `expected 3 to equal 1` (las tres se escribían) y `expected 2 to equal 1`.
`tests/relations_reconcile_cli.spec.ts`: caso «skipped.undeclared SIEMPRE es deriva» (rojo: `expected true to be false`).

### P7 · El docblock de `types.ts` pasa a ser verdad (no se borra: se cumple)

`RelationsDriver` (types.ts ~1520): la frase «el driver la re-valida por defensa en profundidad» se conserva y
se precisa: qué operaciones (`relate`/`unrelate` de los dos), qué 422 (mismos `code` que el manager, la misma
función), antes de qué (cero `Write`, cero INSERT), para quién es la red (`manager.driver()`, `reconcile`) y
qué pasaba antes (la escalada medida). Docblocks de `RelationTypeUnknownError`/`RelationUnknownError`
actualizados; el comentario de `#assertObject` en `database` («el type ya pasó F-05 en el manager») corregido.
README: el párrafo de F-05 ya no dice que `manager.driver()` la salta (dice qué SÍ salta: actor, `assertWrite`,
`onRelationWrite`), y el de `enumerateRelations`/reconcile documenta `skipped.undeclared`. CHANGELOG: sección
«Lot L-0» dentro de `[Unreleased] — 2.4.0-alpha.2`, estilo 1.1.0 (problema → decisión → qué NO se hace).

## Las 4 cifras (todas verdes, corridas a fichero, `OPENFGA_TEST_URL=:8101`)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ · `npm run build` ✔.

| modo | base | ahora | log |
|---|---|---|---|
| `npm test` (SQLite memoria) | 1010 | **1020 passed (1020)** | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1015 | **1025 passed (1025)** | `suite-sqlite-file.log` |
| `npm run test:pg` | 1109 | **1119 passed (1119)** | `suite-pg-2.log` |
| `npm run test:mysql` | 1109 | **1119 passed (1119)** | `suite-mysql.log` |

+10 en cada modo: bridge +1 (paridad; el caso 1 se reescribe, no suma), `database` +3, `openfga` +2,
reconcile +3, CLI +1. Aditivo: ningún caso existente cambió de resultado.

**Una roja transitoria, ajena a L-0.** La primera pasada de PG (`suite-pg.log`) dio 1118/1119: falló
`openfga_facts.spec.ts` «4-1 — la cota es 22 y NO 23 también en el FUSIONADO (500 reps)» con «a 23 saltos las
10/10 rondas resolvieron limpias y SIN contención… expected +0 to be above +0» — la medición autocalibrada de
profundidad contra el `:8101`, que depende de la contención del servidor (venía de encadenar tres suites
seguidas sobre él). L-0 no toca el generador del modelo ni la profundidad. Repetida la suite PG entera:
1119/1119. Stores del `:8101`: barridos por el guard de la suite en cada corrida.

## Ficheros tocados

- `src/relations/define_relations_config.ts` — `assertRelationDeclared` (nueva, exportada).
- `src/relations/manager.ts` — `#assertDeclared` delega; imports.
- `src/drivers/openfga_relations_driver.ts` — guarda en `relate`/`unrelate` (primera línea).
- `src/drivers/database_relations_driver.ts` — ídem; comentario de `#assertObject`.
- `src/relations/reconcile.ts` — `skipped.undeclared`, filtro con `toConfig`, `relateOrSkip`, `declaredIn` por `hasType`.
- `commands/authz_relations_reconcile.ts` — línea de error + `clean` + resumen.
- `src/types.ts`, `src/errors.ts` — docblocks.
- `README.md`, `CHANGELOG.md`.
- Tests: `tests/relations_bridge.spec.ts` (caso 1 reescrito + paridad), `tests/relations_database.spec.ts` (+3),
  `tests/relations_openfga.spec.ts` (+2), `tests/relations_reconcile.spec.ts` (+3), `tests/relations_reconcile_cli.spec.ts` (+1, y el literal `skipped` del caso existente).

## Lo que NO hice, y por qué

- **El contrato publicado (`runRelationsDriverContract`) NO planta el caso por el driver.** Hoy planta el
  exploit por el MANAGER (`state.manager.relate(evil, 'assignee', role_binding)` con `writes() === 0`). Añadir
  la cara por el driver obligaría al doble en memoria a validar F-05 y cambiaría el contrato para drivers de
  terceros (más casos, `relations_harness.spec.ts` a literal): es un cambio de contrato que decide el dueño, no
  este lote. Los dientes del paquete están en las specs de driver y en la spec puente (con mutante).
- **`check`/`listObjects`/`listSubjects`/`purgeObject`/`purgeSubject` NO aplican F-05 en el driver.** Son
  lecturas (o purgas de algo que, si no está declarado, no existe); fuera de los criterios del juez. Queda dicho
  en el CHANGELOG: un `check(evil, 'can_<P>', {type:'scope', …})` por `manager.driver()` leería una decisión de
  roles por el puerto de relaciones, pero no puede escribir ninguna. Si el dueño quiere cerrarlo, es la misma
  función en cuatro sitios más.
- **`--dry-run` sin `toConfig` no anticipa el rechazo del driver** (lo reporta como `written`; la pasada real
  lo cuenta en `undeclared`). El comando pasa siempre la config persistida cuando puede leerla; el caso sin
  config es el de un llamante programático, y está escrito en el docblock de `toConfig`.
- **No toqué `CLAUDE.md`** (el mapa no describe F-05 al detalle; el CHANGELOG y el README sí).
- **Nada de `{trx}`**: L-0 es independiente y va antes, como pidió el juez.
