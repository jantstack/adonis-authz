# Panel «tenencia» · ronda 2 — analista técnico («la 2.5 de una vez, con el deny bien hecho»)

Fecha: 2026-10-14 · base analizada: `2.4.0-alpha.10` (working tree; `package.json:3`; último commit `6d443e4`).
Leído: `panel-tenencia-2-coordinador.md`, mi informe de ronda 1, juez/auditor/tester de ronda 1, `cognitiv-informe-7-tenencia.md`,
`CLAUDE.md` («Cómo se decide un cambio» 1–10), `linajes.md`, `roadmap-2.0.md` (§2.5 y Diferido), README §Relations, §Limits y
§Upgrading, `decisiones-dueno-2026-08-28.md` (§2026-09-13 (5) y §2026-10-14). Código: `src/relations/{manager,reconcile,
define_relations_config}.ts`, `src/drivers/{database_relations_driver,openfga_relations_driver,openfga_facts}.ts`,
`src/types.ts` (puerto de relaciones), `src/relations_config_store.ts`, `commands/authz_relations_reconcile.ts`,
`stubs/migration.stub`, `.github/workflows/ci.yml`, `scripts/`.

Leyenda (sin emojis): **[V]** verificado en código · **[M]** medido ahora contra OpenFGA v1.19.0 · **[D]** diseño/estimación ·
**[?]** incógnita.

**Las cinco mediciones están HECHAS** (§5). Usé el OpenFGA `openfga-dev` de `127.0.0.1:8090` (v1.19.0; el `:8101` no responde)
con un store temporal `analista-tenencia2-tmp` (borrado, HTTP 204), y para la del deadline un contenedor efímero
`openfga/openfga:v1.19.0` en `127.0.0.1:8104` con `OPENFGA_LIST_OBJECTS_DEADLINE=3ms` (borrado con `docker rm -f`). Comprobé
después que no quedaba ningún store `*tmp*` en el `:8090`. Los scripts están en el scratchpad de la sesión, no en el repo.
Tres de los cinco resultados cambian el plan del coordinador.

---

## 0 · Veredicto en una tabla

| Pregunta | Coordinador | Analista (ronda 2) | Por qué |
|---|---|---|---|
| ¿Una sola línea, siguiente estable 2.5.0? | Sí | **Sí, y es una ventaja**: 2.5.0 será la **primera estable de 2.x** (`latest` sigue en `1.1.0`; [V] `npm view … dist-tags` = `{ latest: '1.1.0', alpha: '2.4.0-alpha.10' }`). Todo lo que rompa (tipos, claves de capacidad obligatorias, defaults) **tiene que entrar antes de 2.5.0**; después de esa versión, solo con una major | `CLAUDE.md` punto 4: después de 2.5.0, una ruptura del contrato de terceros es 3.0 |
| Orden 0 → A → mediciones → D → C → RC | Sí | **0 → A → B → D → C → RC, con R en paralelo**. Hay un **lote B nuevo** de endurecimiento: son rupturas que tienen que ir antes del deny y antes de la estable. **R** es la infraestructura del criterio de estable, que **no existe**. Las mediciones salen del camino crítico: ya están hechas | §1 y §5 |
| ¿C antes que D? | Pregunta | **D antes que C**. El orden propio de COGNITIV deja P2 al final y lo cross-org es su fase 2. Hacer C sin deny y retocarla cuesta 8–12 h, frente a 3–4 h si C se hace después | §2 |
| Caducidad del deny (D3) | «según medición» | **Medido: en `openfga` es imposible renovar sin ventana** (400 `cannot_allow_duplicate_tuples_in_one_request`; 409 con `on_duplicate: ignore`). Recomiendo **deny sin caducidad en v1**, como el de roles. Si COGNITIV la necesita (C2): caducidad solo al crear, y cambiarla sobre un deny vivo es 409 | §5 M5 |
| Ciclos de `includes` | condición de D | **OpenFGA rechaza CUALQUIER ciclo de `includes`, con deny o sin él** ([M]). Hoy `database` los acepta y `openfga:provision` falla al publicar: es un **defecto de paridad que ya existe**. Pasa al lote B | §5 M3 |
| `ListObjects` parcial por deadline | «medir» | **[M] Sí: devuelve 200 con una lista parcial, sin señal**. El README afirma lo contrario (`README.md:634-635`, «never a mute partial list»). Es un defecto de letra ≠ efecto **de hoy** (L8). Pasa al lote B. Con el deny dentro del modelo la lista parcial es un subconjunto (fail-closed), así que el diseño del deny no cambia | §5 M4 |
| Roadmap 2.5 ya planificado | — | **Entran** `requireTransaction` por defecto en la outbox y `runRelationsReconcile` a un subpath (rupturas: o antes de la estable o en 3.0), en B. También `--prune-undeclared` (el deny lo vuelve necesario), en C. **Se difieren a 2.6 como opt-in aditivo**: el sello durable del activo, la identidad de backend, el reconcile por subárbol, `limits.maxScopeChainDepth` y el invariante 13 en los runners | §1.3 |

**Recomendación en una frase:** una línea `2.5.0-alpha.1…4 → rc.1 → 2.5.0` en este orden: guardia L1 → aditivo (P5, clave, `checkMany`)
→ **endurecimiento con las rupturas pendientes** → **deny** (sin caducidad en v1, opt-in por tipo, publicación en dos fases) →
P2 con el deny ya presente. La infraestructura del criterio de estable va en paralelo en un worktree, porque hoy no existe.

---

## 1 · Plan definitivo por lotes

### 1.1 Tabla

| Lote | Contenido | Versión | Horas [D] | Depende de | Resultado demostrable |
|---|---|---|---|---|---|
| **0** | Guardia de superficie L1 por reflexión sobre `RelationsManager.prototype` y los dos drivers (columnas L2 `{transaction}` y L3 freeze en las escrituras), un mutante por entrada, y exenciones firmadas (D6). Sustituye la lista a mano de `tests/relations_database.spec.ts:554-599` | `2.5.0-alpha.1` | 6–10 | — | Un método nuevo sin su fila es rojo. Desde aquí, `checkMany`/`deny`/`removeDeny`/`listDenies`/`decideMany`/`listObjectsForSubject` **no pueden** entrar sin F-05, la puerta trx y el freeze |
| **A** | P5 (`createTestClock` en `/testing`, caso P5-1 que se pone rojo si se borra `authz_provider.ts:59`, README «Testing expiry»). `relationTupleKey` con `kind` desde el primer día (pura, exportada desde la raíz y usada por `reconcile.ts` en lugar de `tupleKey` en `:54`; se unifica `scopeKeyOf` `:50` con `scopeKey` `identity.ts:225`). `checkMany` booleano (tope 50, `[]` ⇒ 422, 503 por ítem ⇒ 503 total, un solo `now`) | `2.5.0-alpha.1` | 10–18 | 0 | COGNITIV arranca su fase 0 con la cadena de ancestros en una llamada. Modelo FGA intacto (literal `EXPECTED_FUSED` verde) |
| **B** *(nuevo)* | Endurecimiento: rupturas que van antes del deny y antes de la estable. (1) Ciclos de `includes` ⇒ 422 en `defineRelationsConfig` (paridad: FGA ya los rechaza, [M]). (2) Userset de un tipo que no sea `group#member` ⇒ 422 en las escrituras de los dos drivers ([N 9]: hoy `database` lo guarda inerte y `openfga` da 400 ⇒ 503 mal clasificado). (3) D4: la partición con uuid de 32 hex sin guiones ⇒ 422 en las 8 operaciones, con una consulta de detección en la receta. (4) `listObjects` de `openfga`: señal `truncated` por deadline (opción `listObjectsDeadlineMs`, ver M4) y corrección de la frase del README. (5) `sqlScopeOutbox({ requireTransaction })` pasa a `true` por defecto, con su prerrequisito (`runScopeOutboxContract` pasa la trx en `ctx()`). (6) `runRelationsReconcile` sale de `commands/` a `./relations/reconcile`. (7) README: quitar la mención a `republishFusedModel` (`README.md:637-640`; se retiró en 4-8 según `src/relations_config_store.ts:14-22`) | `2.5.0-alpha.2` | 14–24 | 0 (no necesita A; mismo árbol ⇒ en serie) | Las condiciones previas del deny (ciclos, alias de partición, userset inerte) cerradas en los dos drivers. Las rupturas del roadmap 2.5 dentro de la línea |
| **D** | Deny completo (§4): corte de camino (D5), opt-in por tipo, ≤ 43, sin `*`, `group` ⇒ 422, sin caducidad en v1 (D3), `decideMany`, reconcile con `kind` y censo, purgas ordenadas en `openfga`, guarda de arranque modelo↔config, guarda de `openfga:provision` contra la mutilación, eventos, capacidades, mapeo del 400 «relation … not found» a 500, reporte parcial por partición del reconcile (roadmap 2.5, 2–3 h: el bucle de escritura se reescribe igualmente) | `2.5.0-alpha.3` | 40–60, +50 % de cierres ⇒ hasta ~90 | 0, A (clave con `kind`, base de `checkMany`), B, D3/D5/D6 firmadas | T1 (corte) y P1-M (64 estados) en BRIDGE; tabla de signos del auditor en verde; T3 por el kernel; `factsModelBytes` en Limits |
| **C** | P2 `listObjectsForSubject` (solo holders, directas + `includes`, **filtrada por deny desde el primer día** con el `decide` de D, cursor `(partition_key, object_uuid)`, índice nuevo, par de capacidad, nota de seguridad) + `authz:relations:reconcile --prune-undeclared` (incluye los denies de un tipo al que se le quitó `deny: true`) | `2.5.0-alpha.4` | 18–30 | D, A | «Compartido conmigo» exhaustivo y paginado en los dos drivers, coherente con `check` (propiedad `filtrar(P2) ⊆ check` en BRIDGE) |
| **R** *(paralelo, worktree)* | Criterio de estable, que hoy **no existe** ([V]: `scripts/` = `bench_authorize`, `check_purity`, `openfga_prune_stores`; ningún `check_flag_mutants.mjs`; `ci.yml` sin job `cutover-runbook`). Mutantes de banderas, job del runbook (pg + sqlite-fichero + OpenFGA real; **con los pasos de relaciones y deny**, que se añaden después de D), resto de M7 (L2–L5) | sin release; es puerta de la RC | 19–29 (orden de metodología) + 4–6 por los pasos de deny | arranca ya; los pasos de deny, después de D | `CLAUDE.md` punto 9 en verde |
| **RC** | Auditoría M4 sin diff, con perspectiva nueva; ensayo de COGNITIV sobre el tarball exacto **con plazo cerrado** (propongo 7 días naturales); cualquier grave reabre | `2.5.0-rc.1` (tag `next`) → `2.5.0` (`latest`) | 6–12 + el plazo | todo | `CLAUDE.md` punto 10 (con «2.4.0» sustituido por «2.5.0») |

**Total de trabajo [D]: 113–183 h**, más los cierres de los auditores (el historial de alpha.3/alpha.10 da +50 % en lotes de
riesgo), más el plazo del ensayo. Estimación para ordenar, no para comprometer.

### 1.2 Camino crítico y paralelismo

```
0 ──► A ──► B ──► D ──► C ──► RC(rc.1: M4 + ensayo COGNITIV) ──► 2.5.0
                         ▲
R (worktree propio) ─────┴── los pasos de deny del runbook se añaden cuando D esté en main
```

- **Camino crítico: D.** Es el lote más largo y el que más cierres va a tener, y C depende de él (§2). Todo lo que adelante el inicio
  de D sin coste añadido acorta la línea. Por eso las mediciones ya están hechas y B es corto.
- **0, A, B y D tocan los mismos ficheros** (manager, drivers, `reconcile.ts`), así que van **en serie** (memoria:
  «revisiones no concurrentes»). **R no los toca** (`scripts/`, `.github/`, `tests/command_flags*`): va en un worktree aislado y se
  integra antes de la RC.
- **Decisiones del dueño que bloquean**: D3, D5 y D6 antes de D. D4 antes de B. La nueva **D7** (lo que se difiere del roadmap 2.5)
  antes de cerrar el alcance de B.

### 1.3 Lo ya planificado para 2.5 en el roadmap: entra o se difiere

| Ítem (`roadmap-2.0.md`) | ¿Rompe? | Decisión | Por qué |
|---|---|---|---|
| `sqlScopeOutbox({ requireTransaction })` por defecto `true` | **Sí** (un `enqueue` sin trx pasa a 500) | **Entra (B)** | Después de 2.5.0 sería una major. Prerrequisito escrito: `ctx()` del contrato con `transactions.begin()` |
| `runRelationsReconcile` a un subpath propio | **Sí** (cambia la ruta de import) | **Entra (B)** | Ídem. 2–3 h |
| `--prune-undeclared` en relaciones | No (bandera nueva) | **Entra (C)** | D crea un caso nuevo de «tupla no declarada»: los `denied_X` de un tipo al que se le quita `deny: true`. Hoy nadie los barre y resucitan si se reactiva (el signo es seguro, pero bloquean el reconcile: ver §4.7) |
| Reporte parcial por partición del reconcile de relaciones | No (campo aditivo) | **Entra (D)** | D reescribe ese bucle (`reconcile.ts:298-325`); hacerlo a la vez cuesta 2–3 h |
| Sello durable del driver activo + identidad de backend | Solo si se hace obligatorio | **Se difiere a 2.6, opt-in** | Necesita su propio panel, toca la migración publicada y el arranque, y no tiene relación con la tenencia. Los límites ya están declarados (README ×2, CHANGELOG). Como opt-in no rompe a nadie después de 2.5.0 |
| Reconcile por subárbol, `limits.maxScopeChainDepth` | No | **Se difieren a 2.6** | Aditivos |
| Invariante 13 en los runners publicados (Diferido 2.6+) | Sí, si es una cara obligatoria | **Se difiere a 2.6, como capacidad opcional** | Ya estaba en 2.6+. Regla para después de 2.5.0: toda capacidad nueva es **opcional** en la interfaz |

**Regla nueva que propongo escribir en `CLAUDE.md`:** hasta 2.5.0, una clave nueva de `*DriverCapabilities` puede ser
obligatoria. Desde 2.5.0, toda clave nueva es `?:`, se normaliza a `false` y entra con su par. Si no, cada capacidad nueva rompe la
compilación de los drivers de terceros, y eso es una major.

---

## 2 · ¿C antes o después de D?

**Steelman de C primero (lo que pregunta el coordinador).** P2 cuesta la mitad que D y tiene menos riesgo, y COGNITIV tendría
«compartido conmigo» unas dos semanas antes. Sin deny, «directas vivas + `includes`» sale **exacto** del `Read` crudo ([M] en la
ronda 1), sin un solo `Check`.

**Por qué D primero:**

1. **COGNITIV no lo pidió así.** Su orden explícito es `P1 → P4 → P5 → P3 → P2` (informe §8) y la compartición cross-org es su
   «fase 2» (§1). Dentro de su organización, «compartido conmigo» ya sale de `listObjects` en su partición. P2 no está en su F0.
2. **Retocar C cuando llegue D no es gratis** [D]:
   - `openfga`: hay que verificar los candidatos de cada página con `batchCheck`, porque el `Read` del usuario no ve los denies que
     le llegan por un grupo. Las páginas pasan a traer menos de `limit` y aparecen casos nuevos: P2-5 (deny directo, deny por
     grupo y deny en una relación superior). Son 4–6 h.
   - `database`: el filtro por deny con la CTE `principal` por partición. Son 3–4 h.
   - Contrato: se re-ejecuta y hay un **cambio de semántica entre alphas** que anunciar en el CHANGELOG.
   - Total: **8–12 h**. Haciendo C después de D, el filtro es la llamada al `decide` que D ya construye: **3–4 h**. El sobreprecio
     son 5–8 h y una semántica que cambia a mitad de la línea.
3. **C se diseña mejor sabiendo cómo es D.** El cursor por clave natural sobrevive a páginas cortas solo si se diseña para ellas
   desde el principio.

**Lo que haría cambiar este orden:** que COGNITIV conteste (C4b) que P2 está en el camino crítico de su F0. En ese caso C va antes
que D, con una costura `#verify(candidates)` que en alpha.3 sea la identidad y que D rellene. El coste es el de arriba.

---

## 3 · Camino de upgrade desde `2.4.0-alpha.10`

### 3.1 Por artefacto

| Artefacto | Qué cambia | ¿Obligatorio? | Receta |
|---|---|---|---|
| **SQL `database` · deny** | **Nada de DDL.** El deny es una fila de `authz_relations` con `relation = 'denied_<rel>'` ([V] la columna es `varchar(50)` en `stubs/migration.stub:205`; con `denied_` + 43 caben 50; el UNIQUE `authz_rel_tuple_uq` en `:213-216` sirve tal cual) | — | — |
| **SQL `database` · índice de P2** | `authz_rel_subject_any_idx`. **Propongo ensanchar el del juez** a `(subject_type, subject_uuid, object_type, partition_key, object_uuid)`: así la paginación por `(partition_key, object_uuid)` es un recorrido ordenado del índice, sin `ORDER BY` en memoria. Tamaño de clave en MySQL: (50+64+50+64+64) × 4 = 1.168 B < 3.072 | **No para la corrección** (sin el índice la consulta es correcta y O(tabla)); sí para el rendimiento | PG: `CREATE INDEX CONCURRENTLY …` **fuera de transacción** (migración Lucid con `disableTransactions = true`). MySQL 8: `ALTER TABLE … ADD INDEX …, ALGORITHM=INPLACE, LOCK=NONE`. SQLite: `CREATE INDEX`. Las tres se ejecutan en `upgrade_recipe.spec`, como manda la costumbre |
| **SQL · D4 (lote B)** | Nada de DDL. Detección: `SELECT count(*) FROM authz_relations WHERE partition_key` acabe en `\|` + 32 hex (o `subject_partition`). Por motor: PG `~ '\|[0-9a-f]{32}$'`, MySQL `REGEXP`, SQLite con `GLOB` | Solo si la cuenta es > 0 | Re-clave a la forma con guiones, deduplicando contra el UNIQUE (el patrón de L-4b). En `openfga`: `authz:relations:reconcile` desde `database`, o borrar y escribir. **Lo decide la respuesta C3** |
| **Modelo FGA** | **Sin ningún `deny: true`, el modelo fusionado es byte a byte el de hoy**: no hay que republicar. Con `deny: true` en un tipo, el tipo crece +598 B ([M]) y **hay que republicar** con `openfga:provision --store-id` | Solo al activar el deny | Publicación en **dos fases** (§3.2) |
| **Tipos publicados** | `RelationRef.operation` (`types.ts:1910`) y `RelationWriteEvent.operation` (`:1944`) se ensanchan con `deny` y `removeDeny`. `RelationsDriverCapabilities` (`:2043`) gana `relationDenies` y `listObjectsForSubject` como **obligatorias** (antes de la estable). `RelationTuple.kind?: 'deny'` (`:2140`, opcional). Métodos opcionales nuevos en `RelationsDriver` (`:2193`) | Compila o no compila | Un `switch` exhaustivo deja de compilar: es el aviso que se busca. Un driver de terceros añade las dos claves y su `harness.capabilities` declara las dos caras |
| **Comportamiento (B)** | Ciclos ⇒ 422 al arrancar. Userset no `group#member` ⇒ 422. Partición sin guiones ⇒ 422. `enqueue` sin trx ⇒ 500 (salvo `requireTransaction: false` explícito). `listObjects` de openfga puede marcar `truncated` por deadline. Nueva ruta de import de `runRelationsReconcile` | Sí | CHANGELOG problema → decisión → qué NO |
| **`authz:relations:reconcile`** | Clave con `kind`. Escribe primero los denies y poda los denies al final. Destino sin `relationDenies` con un origen que tiene denies ⇒ 500 antes de escribir | — | **Nunca se ejecuta desde un proceso < 2.5.0-alpha.3 una vez que hay denies en el store**: un proceso viejo los cuenta como `undeclared` y su `--prune` los borra con `unrelate`, que es un 422 de F-05 a mitad de la poda (§3.3) |

### 3.2 Consumidores que NO activan el deny (opt-in por tipo)

Lo que ven, verificado contra el diseño de §4:
- **Lecturas de `database`**: la SQL de `check`/`listObjects`/`membersOf` es **idéntica** para un tipo sin `deny: true` (la rama con
  deny solo se compone si el tipo es denegable). Esto se fija con un caso de espía sobre el texto SQL.
- **Modelo FGA**: byte a byte igual (literal `EXPECTED_FUSED`).
- **`assertWrite`**: nunca recibe `operation: 'deny'`, porque `deny` sobre un tipo no denegable es 422 **antes** de `assertWrite`.
- **Reconcile**: las claves de allow no cambian de valor (el discriminador solo aparece en las de deny).
- **Lo único que notan**: los tipos (compilación) y las rupturas de B, que no tienen que ver con el deny.

**Activar el deny en un tipo es una operación con dos fases** [M]: un pod con el `modelId` viejo fijado responde
`viewer = allowed: true` sobre un objeto denegado. Un pod con código < 2.5.0-alpha.3 en `database` filtra
`relation IN (down*(R))` y nunca ve `denied_*`. Las dos cosas son fail-open durante el despliegue. Por eso:
1. Toda la flota en ≥ `2.5.0-alpha.3` con `deny` apagado.
2. `deny: true` en `relations.config` + `saveRelationsConfig` + `openfga:provision --store-id` + toda la flota en el `modelId` nuevo.
3. Solo entonces se escriben denies.

Dos guardas lo hacen ruidoso en vez de silencioso (§4.6): la de arranque del driver `openfga` (config dice deny y el modelo no
tiene `denied_X` ⇒ 500) y la de `openfga:provision` (un modelo nuevo que quita `denied_*` que el actual tiene ⇒ 500, salvo
`--allow-drop-deny`). **Quitar** `deny: true` exige antes barrer los denies del tipo (`--prune-undeclared`, lote C).

### 3.3 Lo que se rompe al meter D y C en la línea del cutover de roles

| Superficie compartida | Riesgo | Mitigación |
|---|---|---|
| **Modelo FGA fusionado** (roles + relaciones) | El **único** escritor de modelos es `openfga:provision` ([V] `grep writeAuthorizationModel` ⇒ `commands/openfga_provision.ts:141` y `openfga_driver.ts:328`), y lee `relations.config` **del proceso**. Un `provision` lanzado desde un proceso sin `deny: true` (o con un paquete viejo), por ejemplo para publicar un permiso nuevo, **republica el modelo sin `denied_*`**: todos los denies quedan inertes, fail-open silencioso | Guarda de `provision` contra la mutilación (§4.6). Paso del runbook: `provision` solo desde la versión y la config actuales |
| **Reconcile de roles** | [V] `familyOfTuple` trata como ajeno lo que no esté en `OWN_FACTS_OBJECT_TYPES` (auditor ronda 1: `openfga_driver.ts:3536-3541`), y los denies de roles exigen el objeto `scope:` (`:1397-1403`). `document:…#denied_viewer` no lo toca `authz:reconcile`, ni con `--prune` | Ninguna. Se fija con un caso: «`authz:reconcile --prune` no borra un deny de relación» |
| **Reconcile de relaciones** (versión vieja) | alpha.10 sin `kind`: `denied_viewer` no está declarado ⇒ `skipped.undeclared`, y con `--prune` la tupla del destino va a `unrelate` ⇒ 422 de F-05 en el driver ⇒ excepción a mitad de la poda ([V] `reconcile.ts:312-316` + `assertRelationDeclared` en el driver) | Runbook: ninguna pasada desde < alpha.3 una vez que hay denies |
| **Freeze** | `deny`/`removeDeny` son escrituras: si les falta la barrera, el cutover certifica un estado que cambia por debajo (L3) | La guardia de lote 0, con la columna L3 |
| **Runbook M1** | Si no contiene relaciones con denies, la RC se certifica sin probar el camino nuevo | Los pasos de deny en R después de D: `database → openfga` con denies, censo con `listDenies`, y vuelta |

### 3.4 `latest`, dist-tags y deprecate

- **[V] Rangos**, con el `semver` de npm: `^2.4.0-alpha.10` **no** acepta `2.5.0-alpha.1` ni `2.5.0-rc.1`, y **sí acepta `2.5.0`
  estable**. `~2.4.0-alpha.10` no acepta `2.5.0`. Consecuencia: un consumidor con `^` recibe la estable sola y, con ella, las
  rupturas de B. Hay que decírselo a COGNITIV (C6).
- **Publicación**: `2.5.0-alpha.N` con `--tag alpha` (pasa por delante de `2.4.0-alpha.10`), `2.5.0-rc.N` con `--tag next` y
  `2.5.0` con `--tag latest` **escrito explícitamente**. Un `npm publish` de una prerelease sin `--tag` mueve `latest`: es el error
  que hay que evitar. `latest` sale así de la `1.1.0` deprecada.
- **No habrá `2.4.0` estable**: se dice en el CHANGELOG y en el README («the 2.4 alpha line ends at alpha.10 and continues as
  2.5.0-alpha.1»).
- **Deprecate, solo después de 2.5.0**:
  - `2.4.0-alpha.9`, `2.4.0-alpha.10` y todas las `2.5.0-alpha.*`/`rc.*`, **versión a versión** (no por rango: el 2026-09-14 el
    rango dio E422 y además `includePrerelease` deja fuera prereleases).
  - Mensaje: «superseded by 2.5.0 — see README › Upgrading from 2.4.0-alpha.10».
  - Antes de la estable **no** se deprecia ninguna alpha limpia: COGNITIV fija la versión.

---

## 4 · Diseño concreto del lote D, fichero por fichero

Semántica fijada (juez ronda 1 + decisiones pendientes):
- **Corte de camino** (D5): un deny en `Y` anula todo grant `T` con `Y ∈ up*(T)`, con todo lo que deriva ([M] en ronda 1, y
  reconfirmado ahora: `denied_manager` = true y `manager` = false sobre un objeto con deny en `viewer`).
- **Opt-in por tipo**; ≤ 43 caracteres.
- **Sin comodín `*`**; deny sobre `group` ⇒ 422.
- **`listSubjects` no resta**; `listObjects`, `membersOf` y P2 sí.

### 4.1 Config — `src/relations/define_relations_config.ts`
- `RelationObjectTypeSpec` (`:46-52`) gana `deny?: boolean`. Con `deny: true`, cada relación del tipo debe medir ≤
  `DENIABLE_RELATION_NAME_MAX = 50 − 'denied_'.length` (derivada, como `MAX_SLUG_LENGTH` en `identity.ts:340`); si no, 422.
- **Lo que hoy falta y hace falta**: `frozenTypes` (`:276-282`) reconstruye cada tipo con `{ type, relations }` y **tira toda otra
  propiedad**, así que `deny` se perdería en silencio (L5). Hay que copiarla, con un caso.
- `RelationsConfig` (`:82-90`) gana:
  - `isDenyable(type)`;
  - los cierres precalculados `down*(type, R)` y `up*(type, R)`. Son **el punto de paso único** del grafo de `includes`, que hoy
    reimplementa `#expandDown` (`database_relations_driver.ts:432-447`) y que el generador FGA recorre por su cuenta. Con el deny
    hacen falta las dos direcciones en tres sitios; si se calculan tres veces, divergen.
- `saveRelationsConfig` persiste `JSON.stringify(spec)` ([V] `relations_config_store.ts:57`), así que el `deny` viaja sin cambios.

### 4.2 Tipos publicados — `src/types.ts`
| Línea | Cambio |
|---|---|
| `:1910` `RelationRef.operation` | `'relate' \| 'unrelate' \| 'deny' \| 'removeDeny'` |
| `:1944` `RelationWriteEvent.operation` | + `'deny' \| 'removeDeny'` (las purgas siguen igual) |
| `:2043-2099` `RelationsDriverCapabilities` | + `relationDenies: boolean` (C añadirá `listObjectsForSubject`). Las dos, obligatorias antes de la estable |
| `:2102-2111` `RELATIONS_DRIVER_CAPABILITY_KEYS` | Las dos claves **en el mismo commit**: si no, `capabilities()` da `undefined` y el caso D-3 lo caza |
| `:2140` `RelationTuple` | + `kind?: 'deny'`: opcional, así un tercero compila. La garantía viene del censo del runner |
| `:2193+` `RelationsDriver` | + `deny?`, `removeDeny?`, `listDenies?(relation, object, partition, page?)`, `decideMany?(subject, relation, objects, partition): Promise<('allow'\|'deny'\|'none')[]>`. Opcionales en el puerto; **obligatorios si `relationDenies: true`** (lo juzga la cara `whenTrue` del par) |
| nuevo | `RelationDenyOptions = RelationTransactionOptions & { actor? }`: **sin `expiresAt` en v1** (D3 b). Si se pasa, es 422 nombrando la razón medida |

### 4.3 Manager — `src/relations/manager.ts`
- **`deny`/`removeDeny`** siguen el mismo embudo que `relate` (`:378-401`), en este orden:
  1. `#assertTransactional`
  2. `#assertNotFrozen`
  3. `#assertDeclared` (F-05 estricta, sobre el nombre **público**)
  4. **`#assertDenyable`**, nuevo: tipo sin `deny: true` o `group` ⇒ 422 `E_AUTHZ_RELATION_NOT_DENYABLE`
  5. `#assertObjectId`
  6. `#assertActor`
  7. `assertScope`
  8. `#assertSubject`, con la restricción de usersets de B
  9. `assertWrite({ operation: 'deny', … })`
  10. `#copyEvent`
  11. `#write` (invariante 13)
  12. `#notify`

  La capacidad `relationDenies: false` da 500 `E_AUTHZ_UNSUPPORTED` **después** de F-05, como `membersOf` (`:529-553`).
- **`listDenies`**: F-05 estricta + denegable + capacidad. Devuelve hechos directos (no resta).
- **`decideMany`**: la misma validación que `checkMany` del lote A (tope 50, `[]` ⇒ 422, F-05 por ítem, un `now`, error por ítem ⇒
  503 total). Sin `relationDenies`, cada posición es `'allow'` o `'none'` (exacto: no hay deny posible).
- `check`/`listObjects`/`listSubjects`/`membersOf`/purgas: **sin cambios en el manager**. El deny lo resuelve el driver.
- `#assertSubject` (`:623-633`): la regla de B (userset solo de `group#member`) ya está aplicada aquí.

### 4.4 Driver `database` — `src/drivers/database_relations_driver.ts`
| Método | Línea | Cambio |
|---|---|---|
| `relate` / `unrelate` | `:451-537` / `:539-583` | Se extraen `#upsertTuple(storedRelation, …)` y `#deleteTuple(storedRelation, …)`. `deny`/`removeDeny` los llaman con `denied_<rel>` **después** de F-05 sobre el nombre público. La renovación es atómica (transacción interna, `:536`); con D3 (b) no hay renovación de caducidad |
| `check` | `:585-607` | Solo para tipos denegables: `SELECT DISTINCT r.relation` con `IN (down*(R) ∪ { denied_Y : Y ∈ up*(down*(R)) })` sobre la misma CTE `principal`. En JS: `allow ⇔ ∃T ∈ filas∩down*(R) tal que up*(T) ∩ denegadas = ∅`. **Una sola consulta**. Para tipos no denegables, la SQL de hoy literal |
| `listObjects` | `:610-642` | Ídem, devolviendo `(object_uuid, relation)` y aplicando la regla por objeto |
| `membersOf` | `:680-743` | La pieza cara: la CTE `grp` arrastra la relación por la que se llegó (`grp(g_uuid, rel)`) y la consulta final devuelve `(holder, relation)` para grants **y** para `denied_*`, en las cuatro ramas. En JS, la regla por holder. Un holder denegado a través de un grupo denegado también resta |
| `listSubjects` | `:644-678` | Sin cambio (relación exacta; un nombre público nunca empieza por `denied_`). `listDenies` es `listSubjects` sobre la relación almacenada |
| `decideMany` | nuevo | La SQL de `check` con `object_uuid IN (…)`, devolviendo `(object_uuid, relation)`. `deny` = alguna `denied_*` alcanza; `allow` = la regla; `none` = el resto. Base: el `checkMany` de A |
| purgas | `:746-815` | Sin cambio: un `DELETE` atómico que arrastra los `denied_*` |
| `#enumerateRows` | `:862-902` | Traduce `denied_X` ⇒ `{ relation: X, kind: 'deny' }` **siempre**, también si el tipo ya no es denegable: tiene que llegar para que el reconcile lo vea |
| `capabilities` | `:192` | `relationDenies: true` |

**Decisión que propongo (alternativa nombrada):** las lecturas de `database` honran `denied_*` **solo en tipos denegables**, por
paridad con `openfga`, donde el modelo decide. La alternativa (honrarlos siempre) cierra el hueco del despliegue en `database`, pero
rompe la paridad al quitar `deny: true` (`database` seguiría denegando y `openfga` no). Prefiero la paridad más las dos fases de §3.2.

### 4.5 Driver `openfga` — `src/drivers/openfga_relations_driver.ts` + `src/drivers/openfga_facts.ts`
| Pieza | Línea | Cambio |
|---|---|---|
| Generador | `openfga_facts.ts:1011-1018` | Para un tipo denegable, por cada `X`: `X = difference{ base: <la de hoy>, subtract: computed(denied_X) }` y `denied_X = union{ this, computed(denied_P) por cada P que incluye X }` (o `this`), con los **mismos** `directly_related_user_types` (holders + `group#member`, con y sin `not_expired`). Para tipos no denegables, el literal de hoy |
| `assertRelationsConfigPublishable` | `:871-958` | Sin colisiones nuevas posibles: `denied_X` choca con `facts` si y solo si `X` choca con un permiso, y eso ya se rechaza. Basta un caso que lo fije |
| `relate`/`unrelate` | `:405-436` / `:451-470` | `deny`/`removeDeny` con `#rejectTransaction` como primera línea (L-5) y la relación almacenada `denied_X`. Sin caducidad en v1 ⇒ un solo `Write`, sin ventana. Con D3 (c): re-deny que cambia la caducidad de un deny **vivo** ⇒ 409, **antes** del primer `Write` |
| Clasificación de fallos | `#guard` `:275` | **Nuevo [M]**: escribir un deny contra un modelo sin `denied_X` es un 400 `validation_error … relation 'tenancy_node#denied_viewer' not found`. Hoy saldría como 503 (backend), y es un 500 `E_AUTHZ_CONFIG`: «el modelo publicado no declara deny para `<tipo>`; republica» |
| Guarda de arranque | nuevo, perezosa y memoizada | En la primera lectura o escritura de un tipo denegable: `ReadAuthorizationModel(modelId ?? latest)`. Si falta algún `denied_X` ⇒ 500 `E_AUTHZ_CONFIG`. Es una request por proceso. Cierra el fail-open de un modelo mutilado o de un pin viejo **en los pods con la config nueva**. Los pods con código viejo no se pueden cubrir: van al runbook |
| `check`/`listObjects` | `:488-541` | **Sin cambios**: la exclusión se evalúa en el servidor (y por eso un `ListObjects` parcial es un subconjunto, M4) |
| `listSubjects` | `:549-571` | Sin cambios. `listDenies` = el mismo `Read` sobre `denied_X` |
| `decideMany` | nuevo | `batchCheck` con 2 ítems por objeto (`R` y `denied_R`), reutilizando `batchCheckAll` + `correlateBatchResults` de roles (portados en A para `checkMany`); se alinea por `correlationId` |
| `#sweep` | `:658-685` | Traduce `denied_X` ⇒ `kind: 'deny'` |
| Purgas | `:701-745`, `#purgeByFilter` `:773-800` | **Orden global**: hoy cada filtro (ortografía × tipo) borra en el orden del `Read`, así que un deny puede caer antes que su allow ([N 7]). Se reestructura en: leer **todas** las claves de todos los filtros, borrar todos los allows y después todos los denies; la demostración de cero se mantiene. Si la purga muere a medias, quedan denies de **más**, nunca de menos (el orden S6 de roles). `markPartialWrite` sin cambios |
| `capabilities` | `:179-200` | `relationDenies: true` |

### 4.6 Las dos guardas contra la mutilación del modelo
- **`openfga:provision`** (`commands/openfga_provision.ts:141`): antes de `writeAuthorizationModel` lee el último modelo del store.
  Si el modelo nuevo **quita** un `denied_*` que el actual tiene ⇒ exit 1 con letra, salvo `--allow-drop-deny`. La bandera entra en
  `check_flag_mutants.mjs` (lote R).
- **`authz:relations:reconcile --dry-run`**: «tipo denegable cuyo modelo publicado no declara `denied_*`» y «`denied_*` de un tipo
  no denegable» son deriva (exit ≠ 0), con su línea (`CLAUDE.md` punto 7).

### 4.7 Reconcile — `src/relations/reconcile.ts` + `commands/authz_relations_reconcile.ts`
- Clave: `tupleKey` (`:54`) se sustituye por `relationTupleKey` (A), con `kind`.
- `planPartition` (`:375-429`):
  - F-05 sobre el nombre público.
  - `kind: 'deny'` con `toConfig` que no declara el tipo como denegable ⇒ **500** con cero escrituras. Nunca `skipped`: perder un deny
    no es una pérdida que se pueda declarar.
- `reconcileRelations` (`:236-325`):
  - Antes de escribir: origen con denies y destino con `capabilities.relationDenies !== true` ⇒ 500.
  - Escritura en cuatro fases:
    1. denies nuevos y actualizados (`to.deny`);
    2. allows (`relateOrSkip`, `:440`);
    3. con `prune`, allows sobrantes (`unrelate`);
    4. con `prune`, denies sobrantes (`to.removeDeny`), los últimos.
  - Si muere a medias, el destino tiene denies de más.
- `massDelete` (`:426`): «utilizable» sigue siendo una tupla viva del origen que cabe en el destino, denies incluidos.
- Reporte:
  - `report.denies = { written, deleted, extra }` (aditivo);
  - el reporte parcial por partición del roadmap 2.5.
- `relationsReconcileLines` (`commands/authz_relations_reconcile.ts:195-306`): una línea propia para los denies, y exit ≠ 0 si un
  deny no llega.
- **`toConfig` se lee con `.catch(() => undefined)`** ([V] `:469`): si falla la lectura, el reconcile sigue sin config del destino
  y en silencio. Con denies eso quita la puerta del 500 en el plan (quedaría solo la del driver). **Propongo que un fallo de
  lectura sea un error (L5)**; «no hay config persistida» (`null`) es otra cosa y sigue valiendo.

### 4.8 Contrato y guardias — `src/testing/`
- `relations_contract.ts`, par `relationDenies` (mecánica de `:529-540`):
  - `whenTrue`: T1 de corte y P1-M (64 estados) en BRIDGE, P1-1..32.
  - `whenFalse`: `deny` ⇒ 500 con cero llamadas.
  - Se actualizan el desglose de `EXPECTED_CASES` y `CAPABILITY_KEYS`.
- `relations_reconcile_contract.ts`:
  - el censo (`:114-125`) busca también cada deny sembrado con `listDenies`;
  - fila nueva: «un driver que declara `relationDenies: true` y no marca `kind` no pasa».
- Guardia del lote 0: `deny`/`removeDeny`/`listDenies`/`decideMany` aparecen por reflexión. Solo hay que poner sus filas y sus
  mutantes.
- **Tabla de signos** del auditor (2.º `Write` caído, purga cortada, reloj ±, alias, pod con el modelo viejo, `provision` mutilante):
  en cada fila el deny sigue bloqueando o el fallo es ruidoso.
- `linajes.md`:
  - **L9 (candidato) «el deny invierte el signo del fallo»**, con la tabla de signos como guarda.
  - L1 pasa a «punto de paso único: la guardia del lote 0».

### 4.9 Errores, eventos y docs
- `errors.ts`: `RelationNotDenyableError` (422 `E_AUTHZ_RELATION_NOT_DENYABLE`), `.modelLacksDeny()` (500 `E_AUTHZ_CONFIG`).
- Eventos: `operation: 'deny' | 'removeDeny'`, la misma copia y la misma regla de `indeterminate`. Se reescriben F3/F10 de
  `relations_events_docs.spec`.
- README:
  - §Relations · deny: semántica de corte con la tabla medida, «no resuelve una herencia externa» (el caso Nóminas).
  - Limits: +598 B por tipo de 3 relaciones (≈ +199 B por relación con 2 holder types) y la cota de 43.
  - Upgrading: §3 entero.
  - Identidad: el alias de partición queda cerrado por D4; **los alias de objeto y de sujeto no** (§6.2).
- CHANGELOG en el estilo 1.1.0.

---

## 5 · Las cinco mediciones: método, resultado y qué cambia

Entorno [M]: OpenFGA **v1.19.0** (`openfga-dev`, `127.0.0.1:8090`). El modelo fusionado real sale de
`build/src/drivers/openfga_facts.js` (`openFgaFactsModel` con 60 permisos y 2 holder types) y la variante con deny se construye a
mano con la forma de §4.5. Las latencias se tomaron por HTTP desde Node en el mismo host, sin el SDK. Para medir contra el `:8101`
canónico, cuando vuelva, hay que repetirlas con `FGA=http://127.0.0.1:8101 node measure.mjs`.

| # | Cómo | Resultado | ¿Cambia el diseño? |
|---|---|---|---|
| **M1 · bytes** | `factsModelBytes` (calibrado con delta 0 contra el servidor) del fusionado base frente al fusionado con `deny` en 1 y en 2 tipos de 3 relaciones; publicar los dos | Base 34.714 B; +1 tipo 35.312 (**+598**); +2 tipos 35.904 (+1.190). Un tipo de 3 relaciones pasa de 526 B a ~1.124 (**×2,14**: la estimación ×2 de la ronda 1 era buena). Los dos se publican (201) | **No.** Un tipo denegable cuesta ≈ 1 permiso realista (~586 B/permiso, según la cifra de 447 de `CLAUDE.md`). Va a la tabla Limits. Lo cambiaría un delta > 5 % del techo por tipo |
| **M2 · latencia `but not`** | 300 `manager` + 30 `denied_viewer`; 200 `Check(viewer)` y 30 `ListObjects(viewer)`, con el modelo base y con el de deny, sobre el mismo store | `Check` p50 **3,02 → 3,82 ms** (+0,8 ms), p95 5,21 → 5,76. `ListObjects` (300 objetos) p50 3,85 → 4,16 ms, p95 5,12 → 6,16, y devuelve 270 = 300 − 30 (correcto) | **No.** Lo cambiaría ×2 o más en `Check`, o que `ListObjects` se acercara al deadline con volúmenes de COGNITIV (decenas a miles por organización) |
| **M3 · ciclos de `includes`** | Publicar `a = this or b; b = this or a`, sin deny y con deny | **Los dos se rechazan: 400 `invalid_authorization_model` «an authorization model cannot contain a cycle»** | **Sí, y es de hoy.** `defineRelationsConfig` acepta el ciclo ([V] solo rechaza la autoinclusión, `define_relations_config.ts:265-288`), `database` lo resuelve (`#expandDown` usa un `Set`) y `openfga:provision` falla. Es un defecto de paridad. **Va a B** (422 en la config). D ya no tiene que definir qué hace un deny en un ciclo |
| **M4 · `ListObjects` parcial por deadline** | Contenedor efímero v1.19 con `OPENFGA_LIST_OBJECTS_DEADLINE=3ms` y tope 100.000; 4.000 nodos con `manager` a través de 5 grupos (+200 denies); 8 llamadas por modelo | **200 con listas parciales y variables, sin señal**: base 700–3.600 de 4.000; deny 600–3.300 de 3.800. Ninguna cabecera lo indica (solo `openfga-store-id` y `openfga-authorization-model-id`) | **Sí, y es de hoy (L8).** `README.md:634-635` promete «never a mute partial list», y la heurística `raw.length >= tope` (`:528`) no lo detecta. Lote B: opción `listObjectsDeadlineMs` (por defecto 3.000, el del servidor) y `truncated: true` si el tiempo transcurrido ≥ 0,9 × deadline (solo da falsos positivos, nunca negativos), o declararlo. **Para el deny confirma el diseño**: con la exclusión en el servidor la lista parcial es un subconjunto (fail-closed). Restar en el cliente filtraría ([A 12]) |
| **M5 · delete+write de la misma clave en un `Write`** | Sembrar `denied_viewer` con `valid_until` 2099 y renovar a 2100: (a) `deletes`+`writes` en un `Write`; (b) `writes` con `on_duplicate: ignore`; (c) las dos con `ignore` | (a) **400 `cannot_allow_duplicate_tuples_in_one_request`**; (b) **409 `Aborted` «already exists with a different condition»**; (c) 400. La tupla se queda en 2099 | **Sí: D3 queda forzada.** En `openfga`, cambiar la caducidad de un deny vivo exige dos `Write` con una ventana fail-open entre ellos, y si el segundo falla el deny **desaparece** hasta que alguien reintente (fail-open persistente, no solo indeterminado). P1-R2 «nunca hay ventana» es insatisfacible. Recomendación: (b) **deny sin caducidad en v1** (paridad con el deny de roles, que tampoco caduca; el roadmap ya difería «deny con caducidad» a 2.6+). Si C2 dice que hace falta: (c) caducidad solo al crear y 409 al cambiarla sobre un deny vivo (renovar uno **caducado** no abre ventana, porque antes tampoco bloqueaba) |

**Hallazgos laterales [M]**, que entran en D:
- Un pod con el `modelId` viejo fijado responde `allowed: true` sobre un objeto denegado. De ahí las dos fases y la guarda de
  arranque.
- Escribir un deny contra un modelo sin `denied_X` da 400 `validation_error`. Hay que mapearlo a 500, no a 503.
- `denied_manager` = true sobre un objeto con deny en `viewer` (el cierre ascendente). Es la base de `decideMany`.

---

## 6 · Ataque a la propuesta del coordinador

### 6.1 Lo que suscribo
Una línea con 2.5.0 como siguiente estable; lote 0 primero; la clave con `kind` desde el primer día; el deny en su propia relación,
opt-in, ≤ 43, sin `*`, `group` ⇒ 422; el reconcile con `kind` y su orden de escritura y poda; la purga ordenada; D4 como condición.

### 6.2 Lo que corrijo o añado
1. **Las mediciones no son un paso**: están hechas y tres de cinco mueven trabajo a un lote B que el plan no tenía (ciclos, deadline
   y D3 forzada).
2. **«Expiración omitida en re-deny ⇒ permanente»** solo tiene sentido si el deny caduca. Con D3 (b) desaparece. Con D3 (c), un
   re-deny que la omite sobre un deny vivo con caducidad es un cambio ⇒ 409.
3. **D4 cierra uno de tres ejes de alias.** El objeto (`document:p|<id>`) y el holder (`users:<uuid>`) también admiten las dos
   ortografías de un uuid: un allow a `users:abc…` (32 hex) y un deny a `users:abc-…` son sujetos distintos. Roles tiene el mismo
   límite con los holders (el invariante 17 solo cubre scopes). Propuesta: **declararlo** («los ids de objeto y de sujeto se
   comparan byte a byte; usa una sola ortografía»), con un caso que lo fije en las dos direcciones, y cerrar solo la partición, que
   es la que corresponde al scope. Rechazar uuids sin guiones en objetos y sujetos rompería ids legítimos que no son uuid.
4. **El criterio de estable no es «RC y listo»**: hoy faltan el script de mutantes y el job del runbook ([V]). Son 19–29 h que no
   aparecían en el plan. Van en paralelo (R).
5. **La mutilación del modelo** (un `provision` sin `deny` quita todos los denies en silencio) no estaba en ninguna lista. Es el
   fallo de mayor alcance del deny en `openfga`: guarda en `provision` (§4.6).
6. **El reconcile lee `toConfig` tragando el error** (`authz_relations_reconcile.ts:469`): es una entrada inerte de L5 que el deny
   vuelve peligrosa.
7. **Las rupturas del roadmap 2.5** (`requireTransaction`, subpath): o entran ahora o esperan a 3.0. El plan las omitía.
8. **Regla de capacidades después de la estable** (§1.3): ninguna clave obligatoria nueva.

### 6.3 Riesgos que quedan aunque se haga todo
- El hueco del despliegue para pods con código viejo **no lo cubre ninguna guarda**: solo el runbook.
- Con deny, el sesgo de reloj deja de ser seguro en cualquier dirección ([A 13]). Con D3 (b) desaparece del deny, porque no
  caduca.
- `membersOf` con deny en `database` es la consulta más compleja del paquete: hay riesgo de rendimiento con grupos profundos. Hay que
  medirlo en el lote (PG/MySQL con 1.000 miembros en 3 niveles).
- La heurística del deadline en `listObjects` da falsos positivos cerca del umbral (es aceptable: es la dirección ruidosa).

---

## 7 · Qué preguntar a COGNITIV ahora que el deny entra

C1–C5 del juez siguen en pie, con cambios. Añado C6–C12.

| # | Pregunta | Qué decide |
|---|---|---|
| **C1′** | El deny entra en 2.5, pero **no arregla Nóminas**: no exime al owner y no cubre al invitado cross-org. ¿Confirmáis `inherits=false` en vuestro evaluador para ese caso? ¿Para qué casos reales usaríais el deny («el grupo sí, esta persona no»)? Nos sirven para nombrar los casos | Realismo de P1-1..32 |
| **C2** | ¿Necesitáis deny **temporal**? Hemos **medido** que en OpenFGA no se puede cambiar la caducidad de un deny vivo sin una ventana en la que deja de bloquear. Por defecto, v1 va sin caducidad, como el deny de roles | D3 (b) o (c) |
| **C3** | ¿Escribís siempre la partición con el uuid canónico? Ejecutad la consulta de detección (§3.1) y mandadnos el número | D4 y la receta |
| **C4** | ¿Os basta P2 con «directas + `includes`»? **C4b**: ¿P2 está en el camino crítico de vuestra F0 o en vuestra fase 2? | Orden C/D (§2) |
| **C5** | ¿Cómo retiráis las tuplas de relación de una organización borrada? No hay purga por partición | ¿Lote para 2.6? |
| **C6** | ¿Fijáis la versión exacta o con `^`? Con `^2.4.0-alpha.10` os llega la `2.5.0` estable sola, con las rupturas de B | Nota de release |
| **C7** | ¿Fijáis `modelId` en el driver `openfga` de relaciones? ¿Quién ejecuta `openfga:provision` y desde qué proceso? | Publicación en dos fases, guardas |
| **C8** | ¿Qué tipos llevarían `deny: true`? ¿Alguna relación de más de 43 caracteres? | Cota y opt-in |
| **C9** | ¿Vuestros `assertWrite`/`onRelationWrite` hacen `switch` exhaustivo sobre `operation`? | Aviso de compilación |
| **C10** | ¿Usáis usersets de tipos que no sean `group#member` o `includes` cíclicos? (B los convierte en 422) | Rupturas de B |
| **C11** | ¿Llamáis a `listObjects` de `openfga` sobre particiones grandes? Desde B puede marcar `truncated` por deadline | Opción `listObjectsDeadlineMs` |
| **C12** | ¿Qué fechas os vienen bien para el ensayo sobre la RC, con plazo cerrado (propuesta: 7 días)? | Calendario de 2.5.0 |
| **C13** | ¿Os vale la semántica de corte: «un deny en `editor` anula entero un grant de `manager`; solo sobrevive un `viewer` directo»? | D5 |

---

## 8 · Decisiones del dueño (las del juez, actualizadas)

- **D1**: superada. Una línea 2.5.
- **D2**: superada. El deny entra.
- **D3**: forzada por M5. Recomiendo **(b) sin caducidad en v1**; (c) si C2 la exige.
- **D4**: canonizar o 422 la partición sin guiones. Recomiendo **422**, porque no hay cadena con la que canonizar en relaciones.
  Firmar también la declaración de los otros dos ejes de alias (§6.2.3).
- **D5**: corte de camino. Medido; recomiendo aceptarlo.
- **D6**: exenciones de la guardia L1.
- **D7 (nueva)**: qué entra del roadmap 2.5 (§1.3). Recomiendo: entran las dos rupturas (B) y `--prune-undeclared` (C); el sello y la
  identidad de backend se difieren como opt-in a 2.6.
- **D8 (nueva)**: en `database`, ¿las lecturas honran `denied_*` solo en tipos denegables (paridad, recomendado) o siempre?

---

**Recomendación en una frase:** aprobar la línea `0 → A → B → D → C → rc` con R en paralelo, y firmar ya D3 = deny sin caducidad
en v1. La medición demuestra que en OpenFGA no se puede renovar un deny sin ventana, y es la decisión que más simplifica D.

**Siguiente paso concreto:** que el dueño firme D3–D8 y que salga la consulta a COGNITIV (C1′–C13). Mientras tanto, arrancar el
lote 0 en `main` y el lote R en un worktree aislado.
