# Diagnóstico del coordinador (2026-09-13) — por qué siguen apareciendo rojos, para que el panel lo ATAQUE

Pregunta del dueño: «siento que hay un hueco en la metodología, que estamos en círculos; ¿hay un patrón que se repita o
un punto fuerte que reforzar? La idea es que el patrón se repita menos o deje de repetirse».

## Tesis
La metodología no falla donde se aplica; tiene un PERÍMETRO y los defectos se han mudado fuera de él. Al principio los
rojos los encontrábamos nosotros en el núcleo; ahora los encuentra el cliente (COGNITIV) en la FRONTERA con el uso real.

| Versión | Defecto grave | Capa | Quién lo vio |
|---|---|---|---|
| alpha.3 | F-05 no cubría purgas/lecturas (borraba `role_binding` reales) | núcleo del puerto | nuestro auditor |
| alpha.4 | loader de comandos inválido (`node ace` entero reventaba) | integración con Adonis | nuestro panel, tras aviso COGNITIV |
| alpha.5 | el aparcado rompía el orden (padre viejo permanente) | operación: relay inline | nuestro auditor, tras aviso COGNITIV |
| alpha.8 | la raíz `app` como mutex de plataforma | operación: registro de tenants | COGNITIV |
| alpha.9 | 18 banderas de ace inertes (`--dry-run` escribía) | integración con ace | COGNITIV |
| alpha.9 | `--prune` borraba las relaciones de un store compartido | composición entre subsistemas | COGNITIV |
| alpha.10 | `--to=<activo> --from=<otro>` resucita revocaciones | operación DESPUÉS del cutover | COGNITIV |

## Patrones (hipótesis)
P1 **Probamos la función, no la puerta por la que se usa.** «Función pura + comando fino» facilita testear pero dio
   ilusión de cobertura: `reconcileLines` probada y el comando no; helpers de provision con config a mano; `cmd.dryRun =
   true` a mano. El fallo vivía en la capa fina.
P2 **El auditor ataca lo que le enseñamos (el diff).** Las banderas llevaban rotas desde 3b-3a/3b-7; ningún diff las tocó
   en ~15 rondas. Auditamos cambios, no el sistema.
P3 **«Un sitio más allá» se barre por intuición, no por enumeración.** Cierre de alpha.9: se cubrió `uuid sin type` y
   `type sin uuid` y se escapó `type=app con uuid` (4 combinaciones de 2 banderas).
P4 **Probamos el ANTES de las operaciones largas y nunca el DESPUÉS.** Los tres de alpha.10 son del después del cutover.
P5 **Tests que codifican el defecto.** Seis aserciones nuestras leían `f.name ?? f.flagName` y pasaban en verde PORQUE el
   bug estaba puesto; a COGNITIV le pasó igual con dos casos suyos.

## Medidas propuestas (hipótesis)
M1 **Runbook ejecutable del cutover dentro del paquete**: ida y vuelta, por el kernel de ace, banderas reales, contra
   OpenFGA, afirmando EFECTO en cada paso, incluido el después (repetir migración, ventana caducada, mantenimiento).
M2 **La unidad de test de un comando es su invocación** + guardia: cada bandera declarada aparece en ≥ 1 caso por kernel.
M3 **Tabla de verdad en los cierres**: combinaciones de entradas/estados enumeradas; cada fila con caso o «imposible».
M4 **Auditoría de SISTEMA sin diff antes de salir de alpha**: README como operador, cada comando con cada bandera,
   divergencias docs↔comportamiento.
M5 **Estados en el panel de diseño** para operaciones largas: antes / durante / después / abortada / repetida.
M6 **Retirar el arreglo al cerrar un bug** y ver qué casos existentes de la zona siguen verdes: esos no protegen nada.
Criterio de `2.4.0` estable derivado: M1 pasa + M4 da APTA (en vez de «una ronda de COGNITIV sin rojos»).

## Lo que el panel tiene que responder
¿El diagnóstico es correcto y completo? ¿Qué medidas cazarían de verdad los defectos REALES (contrafactual, no opinión)?
¿Cuáles son teatro? ¿Qué cuestan? ¿Qué patrón no cubre ninguna? ¿En qué orden se adoptan?
