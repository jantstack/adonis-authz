# `2.4.0-alpha.10`: re-ataque del auditor al CIERRE-2 (sin commitear)

## Veredicto en una línea

**Seguro con reservas.** No hay 🔴, 🟠 ni 🟡. El cierre-2 no introduce regresiones en C2, C3 ni C4. Queda un ⚪ nuevo con repro (C5: la guardia por fuente no ve una ruta sin normalizar) y dos ⚪ de letra o CHANGELOG sin repro.

Repro: `.claude/reproducciones/alpha10-cierre2-reataque.spec.ts`. Runner `alpha10-cierre2-run.ts`, SQLite `:memory:`, no toca `tests/`:
`env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec .claude/reproducciones/alpha10-cierre2-run.ts`

**Resultado: 19/19 verdes.**
- 1 caso «DEFECTO» (⚪ C5): defecto presente.
- 18 casos «CONTROL»: resisten.

Comprobé que el spec sabe fallar. En una copia temporal (ya borrada) invertí tres aserciones (C3 operador ⇒ `acquired`, C4 ⇒ `released`, C2 `notEvaluated`) y salieron 11 rojos de 19.

PG y MySQL no se ejecutaron (restricción de BD compartida). Lo que digo de esos motores es razonamiento sobre el SQL generado ❓, y el implementador declara verde en los 4 modos.

---

## Hallazgos (ordenados por severidad)

### ⚪ C5′ · La guardia por FUENTE es una regex sobre el especificador literal: una ruta no normalizada al mismo módulo, o un `import()` con backticks, pasa en verde

- **Escenario**
  - Precondición: un contribuidor añade en `src/foo.ts` `import { reconcileRelations } from './relations/./reconcile.js'` y un wrapper sin guard, exportado por un subpath.
  - Acción: `npm test`.
  - Resultado: la guardia por fuente no lo ve, porque el patrón exige `…relations/reconcile.js` contiguo. La guardia por identidad tampoco lo ve si es un wrapper. Hay dos variantes más que tampoco casan:
    - ``import(`./relations/reconcile.js`)``, con backticks.
    - `import d, * as ns from '…'`, cláusula no contemplada.
  - La letra declarada («cualquier importador nuevo») es más fuerte que lo que la regex cubre.
- **Evidencia**
  - ✅ Repro: Node resuelve `src/relations/./reconcile.js` al MISMO módulo (`strictEqual` de `reconcileRelations`), y el patrón leído de `tests/command_flags.spec.ts:1054-1056` no lo casa. Control: la forma normal sí la ve.
  - ✅ Por lectura, con la misma regex: un fichero en `src/relations/<subdir>/` que importe `'../reconcile.js'` tampoco casa. La rama «relations» solo admite `./reconcile.js` o `…relations/reconcile.js`.
- **Steelman del defensor**: «Es un detector de regresión contra el error honesto, no contra un contribuidor que se esconde; y nadie escribe `./relations/./`».
  - Me convence para ⚪. No es explotable por un consumidor: el mapa `exports` resiste, como ya se vio en el cierre-1.
- **Mitigación mínima**: resolver cada especificador con `path.resolve(dirname(file), spec)` y comparar contra la ruta absoluta del módulo, en vez de regex sobre el texto. O rebajar la letra a «un import con la ruta canónica».

### ⚪ C3′ · Letra y CHANGELOG: dos cambios observables del cierre-2 que no están en la lista «by name»

1. **423 → 503 en la doble carrera.** Antes, la doble carrera entre UPDATE y relectura devolvía `held`, un 423 `E_AUTHZ_FREEZE_HELD` no reintentable. Ahora devuelve un 503 `AuthorizationBackendError` reintentable.
   - El párrafo ⚪ lo cuenta, pero la lista «Minor breaking changes of this release, by name» solo nombra `OPERATOR:…`. Un llamante que ramifica por `code` ve un código distinto en la misma situación.
2. **`freezeKindOf` reclasifica holders sin `:`.** `'operator'`, `'reconcile'` y `'platform'` pasan de su kind a `unknown`, y `FreezeStatus.kind` es público vía `freezeStatus()`/`lastFreezeStatus()`.
   - ✅ Repro CONTROL: `'operator'` caducado ⇒ `acquired`, `kind=unknown`. En el cierre-1 JS decía `operator` y el SQL (`LIKE 'operator:%'`) ya la tomaba, así que la decisión de toma no cambia, solo `kind`.
   - Consecuencia: `authz:unfreeze` sin `--fence` pasa de `lift` a `refuse` sobre esa fila VIVA. Solo afecta a filas escritas a mano: `freeze()` escribe siempre `<kind>:<pid>:<hex>`.
- **Steelman del defensor**: «Las dos solo se alcanzan con filas manuales o con una carrera de sub-milisegundo».
  - Me convence: ⚪. Aun así, «by name» es la promesa de ese párrafo.
- **Mitigación mínima**: añadir las dos a la lista «by name».

### ⚪ C3″ · `operatorHolderSql()` cae en la rama SQLite (`substr`) para cualquier dialecto que no sea MySQL ni PG

- Escenario: un consumidor en un dialecto de Lucid fuera de los tres declarados (p. ej. `mssql`, sin `substr`). Cada `freeze()` da un 503 del motor. Con `LIKE` funcionaba.
- Evidencia: 🟡 por lectura (`src/freeze.ts`, `operatorHolderSql`). ❓ No ejecutado.
- **Steelman del defensor**: «El paquete solo declara PG, MySQL y SQLite; `sqlDescendantsOf` ya da 500 con otro dialecto».
  - Me convence: ⚪. Lo coherente sería un 500 `E_AUTHZ_UNSUPPORTED_DIALECT` explícito, como `sqlDescendantsOf`, y no un 503 que invita a reintentar.

---

## Lo que intenté y NO se rompió

### C3: regla única y rama 503

**Holders legítimos.** No cambia su clasificación ni su rama; ✅ lo cubre el CONTROL, 6 holders × {caducado, vivo con lease, vivo sin caducidad}:

| Holder | Caducado | Vivo (con lease o sin caducidad) |
|---|---|---|
| `operator:<pid>:<hex>` y `operator:` | `expired-operator` | `held` |
| `reconcile:<pid>:<hex>` | `acquired` | `held` |
| `platform:<pid>:<hex>` | `acquired` | `held` |
| NULL | `acquired` | `held` |

Ninguno de esos casos da la 503.

**¿Hay algún holder que alcance la 503 de forma determinista?** Para eso haría falta que el UPDATE excluya la fila, que JS la vea no viva y que no sea de operador. Por lectura, eso exige que `isOperatorHolder` y `operatorHolderSql` discrepen, o que discrepen la nulidad o el número. Ninguna discrepancia es posible:
- `reason` usa `whereNull` ⇔ `=== null`, y `''` es no-nulo en los dos lados.
- `until` usa `<= nowMs` con el MISMO `nowMs` en el UPDATE, en `freezeIsLive` y en el reintento.
- El prefijo es ASCII: 9 caracteres SQL (`substr`/`SUBSTRING`) ⇔ 9 unidades UTF-16 cuando la igualdad es verdadera. Un carácter astral en cabeza falla en los dos lados.
- `NULL` va por `whereNull` antes de `NOT(...)`.
- En SQLite, `substr()` no hereda collation (BINARY) y el stub no declara collation en la columna.
- En MySQL, `CAST … AS BINARY` a los dos lados quita `_ai_ci` y el PAD SPACE.
- En PG, `COLLATE "C"`.

**¿Aparece la 503 en un caso normal?** No en secuencia ni con dos managers compitiendo: 50 rondas de `freeze()` concurrentes dieron solo 423 (✅ CONTROL; en `:memory:` el pool 1 serializa, así que es un control débil). En multiproceso exige que la fila pase dos veces a no viva entre UPDATE y SELECT, es decir, dos ventanas completas de otro dueño dentro de ese hueco. Ningún código del paquete toma y suelta el freeze en bucle cerrado.

### C4: el token `'?'`

- No levanta una ventana VIVA con holder real (`operator:`/`reconcile:`/`platform:`), ni `'? '`, `'??'`, `''` o `'NULL'` con el fence actual (✅ CONTROL, 7 casos).
  - La comprobación JS (`===`) va antes que el UPDATE.
  - El `= '?'` de MySQL `_ci`/PAD SPACE solo podría casar `'? '` si la fila cambiase entre la lectura y el UPDATE conservando el fence. El fence sube en cada toma, así que eso solo pasa escribiendo a mano.
- La fila viva con holder NULL (o `'?'` literal) sí se levanta con `'?'` + fence. Eso es lo diseñado para filas legadas: no es una ventana de un dueño del paquete, y NULL ya lo casaba el cierre-1.
- La letra «la fila NO cambió» de `authz:unfreeze`: el UPDATE falla con la fila idéntica en (holder publicado, fence, motivo) solo si hay un defecto real. `NULL`→`'?'` con el mismo fence seguiría casando el token.

### C2: `notEvaluated` y el gemelo de aparcados

- `--only` sin `--limit`, en los dos modos: `missing=[999999]`, `notEvaluated=[]` y la misma letra «no existe». No aparece la línea «NO lo evaluó» (✅ CONTROL).
- `--only=a,b --limit=1`, en los dos modos: exit 1, `#b está PENDIENTE` y sin «no existe» (✅ CONTROL).
- Por lectura de `#drainScopeChanges` y `#relayInputs`:
  - `unseenOf` corre dentro del lease, después del drenaje.
  - Solo hace una lectura extra si hay ids sin ver, con `#assertOnlyHonoured`.
  - Los `deferred`/`failed`/`applied` van a `entries` y por tanto a `seen`.
  - Un id fuera del lote por `break outer` o por el `while` sale como `notEvaluated`.
  - Lo aparcado más allá de `batchSize` sale del censo y el comando lo nombra con exit 1.
  - `busy` ⇒ `[]`.
  - `requeue --apply` usa `DEFAULT_RELAY_LIMIT`.
- Un id mal formado ya viajaba al puerto en la lectura principal, así que la lectura nueva no añade ningún error nuevo.
- Residuo sin valor práctico: con una outbox de terceros que ignora `after`, la salida por `!progress` rotularía «alcanzó --limit». La caza antes el 500 de `done`/`assertOnlyHonoured` en la mayoría de formas.

### C7: `RunRelationsReconcileOptions` y exports

- `Omit<RelationsReconcileOptions,'from'|'to'> & {toKey, fromKey, allowStaleSource?}` no expone `activeKey`, y el runtime da 500 igual si llega.
- Ningún subpath (`./types`, `./testing`, `./openfga`, `services`, `providers`) re-exporta `RelationsReconcileOptions`.
- El `d.ts` del subpath importa por ruta relativa interna, que el mapa `exports` no restringe.
- El CHANGELOG declara `notEvaluated` (obligatorio, con nota de migración para `deepEqual` y reportes a mano), la salida del tipo de la raíz y `OPERATOR:…`.

## Preguntas abiertas para el arquitecto

Ninguna cambia el veredicto.
