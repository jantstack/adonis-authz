# Lote D · sublote D1 · CIERRE 2 — informe del implementador · 2026-10-15

**Árbol `main` sobre `493c649`**, con D1 + cierre 1 + cierre 2 sin commitear. Son 28 ficheros: los 27 de antes más
`scripts/check_guard_mutants.mjs`, que solo cambia el docblock. Fui el único agente que mutó el árbol. **Sin commit, sin `version` y sin push.**
- Brief: `loteD1-cierre2-coordinador.md`. Hallazgos: `loteD1-auditor-cierre.md`.
- Entorno: Node 22, OpenFGA `:8090` (`openfga-dev`, reiniciado antes de cada suite), `postgres18` y `mysql84`.
- Logs: `scratchpad/c2/` (`logs/*.log` = un log por mutante de pieza; `final/*.log` = la verificación).
- Sin tocar: `EXPECTED_FUSED`, `migration_stub.spec` y `freeze.spec`.
- CHANGELOG: `git diff -U0 CHANGELOG.md` da un solo hunk, `@@ -2,0 +3,178 @@`. Solo crece `[Unreleased]`, con el bloque
  «Closure 2 of sublot D1». Los bloques `[2.5.0-alpha.2]` y `[2.5.0-alpha.1]` están intactos byte a byte.

---

## 1 · 🟡 N1 — la fila simétrica: allow TRANSPORTADO por grupo + deny DIRECTO

- **Código**: ningún cambio. El orden de `purgeWrites` (allows → membresías → denies) ya era el correcto. Lo que faltaba
  era el diente.
- **Casos** (`tests/relations_openfga.spec.ts`, en el grupo «lote D · cierre 1 de D1 · 🟠 1 …», con el helper `row()`
  extendido con dos transportes):
  - `:1903` «purgeSubject cortada, allow por grupo × deny DIRECTO (holder) …». Tuplas: `group:gA#member@U`,
    `doc:V#viewer@group:gA#member`, `doc:V#denied_viewer@U` y 100 allows de relleno.
  - `:1908` «… (userset g#member) …». Tuplas: `group:h#member@group:g#member`, `doc:V#viewer@group:h#member`,
    `doc:V#denied_viewer@group:g#member` y 100 allows de `g#member`. La víctima es W ∈ g.
  - Cada fila tiene dos variantes: {cabe ⇒ 1 `Write`; no cabe ⇒ 3 `Write` `[100][membresía][deny]`} × corte tras cada k.
    En todos los cortes la víctima da F.
- **Mutante** `fga.purge.denies-before-memberships` (`[allows][denies][membresías]`), contra el servidor: **muerto, 2 rojos**:
  `ROJO (🟠 1 · S3 · allow por grupo × deny directo × no cabe · corte tras el lote 2 de 3): el estado intermedio CONCEDE … lotes aplicados: [100 allows] [document:…#denied_viewer@user:…]`
  y el mismo rojo en la gemela userset (`logs/fga.purge.denies-before-memberships.log`). Es lo que midió el auditor.
- **Rojo observado**: solo con el mutante, porque el código ya era correcto. Sin el mutante los 7 casos del grupo están verdes.
- **Letra**: el README («Deny on relations») cita el caso holder y dice que la misma tabla corre sin servidor en la guardia.

### Tabla de verdad, filas nuevas (medidas en `:8090`; inicial F y final F)

| transporte | ¿cabe? | `Write` | corte tras k | víctima | mutante denies-antes |
|---|---|---|---|---|---|
| allow por grupo × deny directo (holder U) | cabe (3) | 1 | k = 0 | F | — |
| ídem | no cabe (102) | 3: [100 allows] [gA] [deny] | k = 0, 1, 2 | F, F, F | **T en k = 2** |
| allow por grupo × deny directo (userset g#member, víctima W ∈ g) | cabe (3) | 1 | k = 0 | F | — |
| ídem | no cabe (102) | 3: [100 allows] [h∋g] [deny] | k = 0, 1, 2 | F, F, F | **T en k = 2** |

Con estas filas, la tabla completa del 🟠 1 cubre las dos mitades de la propiedad: membresías DESPUÉS de los allows (filas
del cierre 1) y membresías ANTES de los denies (estas filas).

## 2 · ⚪ N2 — los mutantes de orden de la purga, en el corredor publicado (estructural, M8)

- **Guardia de superficie con PROPIEDADES**:
  - `tests/fixtures/guard_manifest.ts:518` añade `GUARD_PROPERTIES` (interfaz `GuardProperty`: id, título canónico, punto
    de paso y lista CERRADA de mutantes).
  - `GuardMutant` acepta `properties?` en vez de `cells?`.
  - La primera propiedad es `openfga.purge.order`, con punto de paso `purgeWrites`. `purgeWrites` se exporta del módulo
    del driver; no sale por `/openfga`.
- **Caso puro** (`tests/guard_surface.spec.ts:1675`, grupo «GS · P · propiedades de un punto de paso …»), sin servidor:
  - Usa un evaluador mínimo del modelo: allow directo o por `group#member` anidado, menos el deny directo o por grupo.
  - Filas: las de la tabla del servidor. Son {directo, por grupo, anidado, allow-por-grupo×deny-directo holder,
    ídem userset} × {cabe, no cabe}, más «allow Y deny por grupo × 99 allows».
  - Cada fila se juzga en el orden del `Read` del driver (`group` primero) y en el inverso.
  - Exige dos cosas: (a) ningún prefijo de `Write` concede; (b) si la purga cabe, es UN `Write`.
- **G-M** (`guard_surface.spec`):
  - Un mutante nombra celdas O propiedades, nunca las dos ni ninguna. `expectRed` = el título de cada una.
  - Caso nuevo `:1525`: la lista de mutantes de cada propiedad es CERRADA en los dos sentidos. Sacar del corredor uno de los
    cinco da rojo, y también un sexto sin declarar.
- **`tests/fixtures/guard_mutants.json`**: +5 entradas (`properties: ["openfga.purge.order"]`):
  - `fga.purge.prefix-only`
  - `fga.purge.memberships-first`
  - `fga.purge.contiguous`
  - `fga.purge.no-single-write`
  - `fga.purge.denies-before-memberships`
- **El corredor**: `scripts/check_guard_mutants.mjs` funciona sin cambios. Solo cambió el docblock.
- **Medido**:
  - `--only` con los cinco ⇒ 5/5 muertos en 5 s, en `:memory:` y sin OpenFGA (sirve para el job `guard-mutants` de CI).
  - Corredor completo: **160/160**.
- **Rojo de cada mutante** (`logs/gs-*.log`):
  - `prefix-only` ⇒ «por grupo × no cabe · orden del Read · tras 1 de 2 Write: CONCEDE (lotes [100, 2] …)».
  - `memberships-first` ⇒ «por grupo × no cabe · tras 1 de 3 … lotes [1, 100, 1]».
  - `contiguous` ⇒ «allow Y deny por grupo × 99 allows · tras 1 de 2 … [100, 1]».
  - `no-single-write` ⇒ «directo × cabe: cabe en un Write (2 tuplas) y salió en 2».
  - `denies-before-memberships` ⇒ «allow por grupo × deny directo (holder) × no cabe · tras 2 de 3 … [100, 1, 1]».
- **Linaje**: la propiedad cita L10 (propuesto), con 3 iteraciones: 3b-2f · R3, 3b-6 · P1 y D1 · 🟠 1. No toqué `linajes.md`;
  es del coordinador.

## 3 · ⚪ N3 — `--max-tuples-per-write` < 100 ⇒ 500 con letra, parcial si ya borró

- **Medición previa** (`scratchpad/c2/measure400.mjs`, `:8090`): `deleteTuples` de 101 ⇒ `FgaApiValidationError`, con
  `statusCode` 400, `apiErrorCode` `exceeded_entity_limit` y `apiErrorMessage` «The number of write operations exceeds the
  allowed limit of 100».
- **Código** (`src/drivers/openfga_relations_driver.ts`):
  - `#purgeByFilters` captura el error de cada `Write` de la purga.
  - `isServerWriteLimit` (`:1416`) lo reconoce, mirando el error y su `cause` directa: `#guard` lo envuelve en un 503.
  - Si lo es ⇒ `purgeWriteLimitError`: 500 `AuthorizationConfigError` (`E_AUTHZ_CONFIG`). La letra dice:
    - el tamaño del `Write` y el mensaje del servidor;
    - «RELATIONS_PURGE_WRITE_MAX = 100» y «--max-tuples-per-write ≥ 100 … (OPENFGA_MAX_TUPLES_PER_WRITE …)»;
    - «No es transitorio»;
    - «Ya se habían borrado N tuplas … A MEDIAS (escritura parcial).» o «No se borró nada.».
  - La marca de escritura parcial la pone el `#partialIfDeleted` que ya existía. El manager notifica `indeterminate: true`.
  - Docblock de `RELATIONS_PURGE_WRITE_MAX` corregido: la frase falsa «503 sin haber borrado nada» desaparece.
- **Casos** (`tests/relations_openfga.spec.ts:2493` y `:2515`, FUERA de la guarda del servidor: corren en los 4 modos):
  - Cliente falso con 3 allows + 60 membresías + 40 denies. El error es el `FgaApiValidationError` REAL del SDK, construido
    con la forma medida.
  - Caso `:2493`: 400 en el 2.º `Write` ⇒ `writes = [3, 60]`, 500 con toda la letra, parcial, y un evento con
    `indeterminate: true` (vía `RelationsManager`).
  - Caso `:2515`: 400 en el 1.º ⇒ 500 «No se borró nada.», sin marca.
- **Rojo observado = mutante** `fga.purge.write-limit-as-503` (quitar la clasificación): 2 rojos,
  `ROJO (⚪ N3): el 400 del tope del servidor salió como 503 E_AUTHZ_BACKEND_UNAVAILABLE (parece transitorio y la purga no termina nunca)`.
- **Letra**:
  - «Limits»: la fila `RELATIONS_PURGE_WRITE_MAX` gana «**Requires `--max-tuples-per-write` ≥ 100 on the server** …».
    `scope_depth.spec` la ata a la constante.
  - La fila `E_AUTHZ_CONFIG` de la tabla de códigos y el CHANGELOG.
  - Sin opción nueva.

## 4 · ⚪ N4 — D-31 por igualdad ESTRUCTURAL con lo que genera el paquete

- **Medición previa** (`:8090`): `ReadAuthorizationModel` devuelve las mismas reglas con otras dos diferencias: otro orden de
  claves y `object: ""` en cada `computedUserset`. Por eso hace falta una forma canónica.
- **Código**:
  - `src/drivers/openfga_facts.ts:1043`, `factsRelationRewrites(objectType)`: las reglas `relations` de un tipo, ahora la
    fuente ÚNICA del generador. `factsRelationTypeDefinitions` la usa. El metadata sale en el mismo orden; `EXPECTED_FUSED`
    sigue verde.
  - `:1077`, `canonicalRewrite`: ordena claves, quita `object: ''` y ordena los hijos de `union`/`intersection`.
  - En el driver (`:500`), `#modelDenied`, para un tipo CON opt-in: `<rel>` y `denied_<rel>` tienen que ser iguales a las
    generadas (`sameRewrite`, `:1405`).
  - Para un tipo SIN opt-in (D8, lo que necesita `decideMany`) se queda la forma de ⚪ 7.
  - El mensaje del 500 dice «—o la declara pero <rel> o denied_<rel> no son las reglas que genera el paquete (but not y el cierre del corte de camino)—».
- **Casos**:
  - `relations_openfga.spec:1491`: modelo a mano con `denied_editor = { this: {} }`. Primero se demuestra que el servidor
    CONCEDE `editor` a un owner con deny en `viewer` (cliente crudo: `allowed: true`). Después, `driver.check` ⇒ 500
    `E_AUTHZ_CONFIG` nombrando `document#denied_editor`, con solo la llamada `readAuthorizationModel`.
  - `:1520`: modelo EQUIVALENTE (hijos de la unión invertidos) ⇒ entra, y el deny corta (F; quitado el deny, T).
- **Rojo observado = mutantes**:
  - `fga.D31.shape-only` (volver a ⚪ 7) ⇒ 1 rojo:
    `ROJO (⚪ N4): un modelo con denied_editor sin el cierre respondió true donde database niega`.
  - `fga.D31.textual` (comparar sin canonicalizar) ⇒ 35 rojos: el caso de equivalencia y todo el contrato deny de openfga,
    porque el servidor devuelve `object: ""`.

## 5 · Decisión 1 — la letra

Docblock de `MembersOfDenyLimitError` (`src/errors.ts`) y fila `E_AUTHZ_MEMBERS_DENY_LIMIT` del README: **500 y no 422**,
porque no es una pregunta inválida del llamante sino una cota del despliegue (precedente `E_AUTHZ_TOO_MANY_LOCAL_ROLES`).
El docblock dice además por qué no es 503 ni se parece a `E_AUTHZ_TOO_MANY_SCOPES`. CHANGELOG, línea «Letter».

## 6 · Cuatro líneas de cierre (🟡 N1, por §5 aplicado a su fila)

- **(a) Gemelos.**
  - Holder ↔ userset: con caso los dos.
  - `purgeObject`: pasa por el mismo `purgeWrites`, así que la propiedad pura lo cubre.
  - Roles (`purgeScope` en `facts`): no aplica, porque ninguna tupla de roles transporta deny por membresía. Su orden propio
    no es todavía una propiedad de la guardia (no hecho).
  - `database`: un `DELETE`, no aplica.
- **(b) Tabla de verdad**: §1. Completa la del cierre 1, contra el servidor, y se repite pura en la guardia.
- **(c) Casos existentes puestos en rojo**: ninguno de efecto. G-M cambió de forma (`cells` opcional) y sigue con los mismos asertos para celdas.
- **(d) Linaje**: 3.ª iteración, así que es estructural: propiedad universal escrita, punto de paso único (`purgeWrites`) y
  ENTRADA en la guardia de superficie (§2).

## 7 · Cifras (secuencia, `:8090` reiniciado antes de cada suite; `scratchpad/c2/final/`)

| Modo / gate | Resultado | Δ sobre la partida |
|---|---|---|
| `npm run build` | rc 0 | — |
| `npm test` | **1895** passed, 2 skipped | +8 |
| `test:sqlite-file` | **1923** passed, 2 skipped | +8 |
| `test:pg` | **2020** passed, 1 skipped | +8 |
| `test:mysql` | **2022** passed, 1 skipped | +8 |
| `check:guard-mutants` | **160 / 160** muertos | 155 → 160 |
| `check:flag-mutants` | **36 / 36**, 2 pending | = |
| `cutover-runbook` sqlite-file / pg | verde ×2 | = |

- **+8** = N1 2 + N3 2 + N4 2 + caso puro de la propiedad 1 + G-M de propiedades 1.
- **Incidencia**: la primera corrida de `npm test` dio 1 rojo (1894/1).
  - Causa: en el README partí una cita de caso en dos líneas, y la regex del docs-test (`relations_events_docs.spec`) no la
    casaba.
  - Arreglo: la cita va en una línea, y `npm test` se re-corrió en primer plano tras el arreglo: 1895/0 (`test2.log`).
  - Lo que esa corrida en segundo plano NO prueba: `sqlite-file`, pg y mysql (y los gates) ya corrían con el README
    arreglado, y verdes.
- **Mutantes de pieza fuera del corredor** (con servidor): 4/4 muertos.
  - `fga.purge.denies-before-memberships` contra el servidor.
  - `fga.purge.write-limit-as-503`.
  - `fga.D31.shape-only`.
  - `fga.D31.textual`.
- **Los cuatro mutantes de orden del cierre 1, contra el servidor**: no los re-corrí. Ahora viven en el corredor (muertos
  por el caso puro).

## 8 · No hecho

- **Gemelo de roles de N3** sin tocar: `projectCatalog` y `applyReconcileWrites` asumen el mismo 100, y con un servidor de
  tope menor siguen dando 503. Escrito en el CHANGELOG.
- **El orden de `purgeScope` de roles** (3b-2f · R3) no es todavía una propiedad de `GUARD_PROPERTIES`, aunque sea del
  mismo linaje L10.
- **Sin tocar**: `linajes.md` (L10 es del coordinador) y `CLAUDE.md` (la cifra «112 mutantes» de «Comandos» ya era rancia
  antes de este cierre).
- **D-31 no compara el `metadata`** (`directly_related_user_types`): no decide qué concede, y un tipo de sujeto que falte
  rompe ruidosamente al escribir.
- **⚪ N5** (higiene: `assertDenyNoExpiry` sin caso por driver, regla `notDeny` por nombre, hash de alpha.2) no estaba en el
  brief y no se tocó.

## Estado del árbol

```
 M CHANGELOG.md
 M README.md
 M index.ts
 M scripts/check_guard_mutants.mjs
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_facts.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/openfga.ts
 M src/relations/check_many.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/testing/main.ts
 M src/testing/relations_contract.ts
 M src/types.ts
 M tests/capabilities.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/guard_surface.spec.ts
 M tests/openfga_facts.spec.ts
 M tests/relations.spec.ts
 M tests/relations_bridge.spec.ts
 M tests/relations_contract.spec.ts
 M tests/relations_database.spec.ts
 M tests/relations_events_docs.spec.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/scope_depth.spec.ts

 CHANGELOG.md                             | 178 +++++++
 README.md                                | 101 +++-
 index.ts                                 |  14 +-
 scripts/check_guard_mutants.mjs          |   3 +-
 src/drivers/database_relations_driver.ts | 296 +++++++++--
 src/drivers/openfga_facts.ts             |  88 +++-
 src/drivers/openfga_relations_driver.ts  | 431 +++++++++++++--
 src/errors.ts                            |  43 ++
 src/openfga.ts                           |   2 +-
 src/relations/check_many.ts              |  10 +-
 src/relations/define_relations_config.ts | 235 ++++++++-
 src/relations/manager.ts                 | 142 ++++-
 src/testing/main.ts                      |   2 +
 src/testing/relations_contract.ts        | 738 ++++++++++++++++++++++++--
 src/types.ts                             |  61 ++-
 tests/capabilities.spec.ts               |   5 +
 tests/fixtures/guard_manifest.ts         | 132 ++++-
 tests/fixtures/guard_mutants.json        | 866 +++++++++++++++++++++++++++++--
 tests/guard_surface.spec.ts              | 337 +++++++++++-
 tests/openfga_facts.spec.ts              |  64 +++
 tests/relations.spec.ts                  |  85 ++-
 tests/relations_bridge.spec.ts           | 118 +++++
 tests/relations_contract.spec.ts         |   2 +
 tests/relations_database.spec.ts         | 150 ++++++
 tests/relations_events_docs.spec.ts      |  54 +-
 tests/relations_harness.spec.ts          |  39 +-
 tests/relations_openfga.spec.ts          | 690 +++++++++++++++++++++++-
 tests/scope_depth.spec.ts                |  12 +-
 28 files changed, 4634 insertions(+), 264 deletions(-)
```

(diff contra `493c649`: D1 + cierre 1 + cierre 2.)
