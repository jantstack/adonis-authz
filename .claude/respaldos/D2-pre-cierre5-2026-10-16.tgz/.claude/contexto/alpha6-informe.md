# `2.4.0-alpha.6` — barrido ÚNICO de `enumerateRelations` + exención de la purga bajo `only` · INCREMENTAL

**Base:** `main` `85e90c3` (= alpha.5 publicada), **1281 / 1307 / 1402 / 1404** con el `:8101`. Sin commits, sin subir
`version`. `$S` = `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`.

## 0 · Diseño elegido (y por qué)

**Pieza 1.** Método OPCIONAL del puerto `enumerateRelationsMany?(partitions[], page?)` — mismo tipo de retorno que
`enumerateRelations` (`RelationTuplePage`, cada tupla con SU `partition`), sin capability booleana (precedente:
`earlierPending?`/`dead?`/`acquire?` del `ScopeOutbox`; añadir una clave a `RelationsDriverCapabilities` arrastraría el
par whenTrue/whenFalse del runner y el conteo de `capabilities.spec`). En `openfga` los dos métodos son `#sweep`: UN
`#readAll(op, {})` repartido por `scopeKey` ENTERA (`Map` clave → referencia pedida) — exactamente lo que midió el
analista («un solo `Read({})` que reparte por `partitionKey`», §3.2). `enumerateRelations(partition)` =
`#sweep([partition])`: semántica intacta (exhaustiva, la caducada llega, sin cursor). **Descartada** la «caché por
pasada» dentro del driver: una enumeración cacheada tras un `relate` sería un ORIGEN desfasado y no hay forma de saber
desde `enumerateRelations(p)` que dos llamadas son «la misma pasada» sin un objeto de sesión. El consumidor de K
particiones es `reconcileRelations`: gana `partitions?: ScopeRef[]` (exactamente uno de `partition`/`partitions`),
enumera origen y destino UNA vez (`enumerateAllMany`, con caída a K llamadas si el driver no trae el método), decide los
K diffs (`planPartition`) y evalúa R-17 en TODAS antes de escribir en ninguna; reporte = suma. **Las purgas no aplican**:
`purgeObject`/`purgeSubject` no barren el store (Read por objeto EXACTO / por `user`+tipo), no hay nada que unificar.

**Pieza 2.** `#blockOriginOf(outbox, earlier, blocked, parkedKeys, batchSize, memo)`: simula hacia atrás, sobre las
entradas NO pedidas, la misma regla que `block`/`defer` aplican a las procesadas — clave en `blocked` con origen FALLO ⇒
fallo; `attached`/`moved` con clave en `parkedKeys` o en `blocked` con origen aparcado ⇒ aparcado; si no, SU anterior
(`#dependencyOf`, reutilizado) recursivamente; sin anterior ⇒ «se aplicaría» ⇒ NO aparcado. Ids estrictamente
decrecientes (termina), memo por pasada que se OLVIDA al primer bloqueo real (`block(..., false)`), cota
`RELAY_ORIGIN_MAX_HOPS = 100` (exportada, en «Limits», atada por `scope_depth.spec`); pasada la cota ⇒ fallo (aplaza,
hacia lo seguro). En la rama de la sonda: `detached` + origen aparcado ⇒ cae a `#applyScopeChange`; lo demás `defer(...,
byParked)` con el origen heredado (antes siempre `false`).

## 0b · Qué cambia

| Fichero | Qué |
|---|---|
| `src/drivers/openfga_relations_driver.ts` | `enumerateRelationsMany(partitions)` + `#sweep` (UN `#readAll(op, {})` repartido por `scopeKey` entera); `enumerateRelations` = `#sweep([p])`; `#readAll`: respuesta sin `tuples` ⇒ 503; `[]` ⇒ 500 con cero lecturas; docblocks con el prefijo PROHIBIDO y el coste por PASADA. |
| `src/types.ts` | `RelationsDriver.enumerateRelationsMany?` (opcional, sin capability; docblock: exhaustivo o ruidoso). |
| `src/relations/manager.ts` | Fachada `enumerateRelationsMany` (delegación o caída a K llamadas; `[]` ⇒ 500). |
| `src/relations/reconcile.ts` | `partitions?: ScopeRef[]` (exactamente uno de `partition`/`partitions`, dedupe por clave); `enumerateAllMany` (una pasada con el método si existe y K > 1; guardas de cursor iguales); `planPartition` (diff puro por partición); R-17 evaluado en TODAS antes de escribir (mensaje nombra la partición y «no se ha escrito nada»); reporte = suma. |
| `src/manager.ts` | `RELAY_ORIGIN_MAX_HOPS = 100` (exportada); `origins` (memo, se limpia en `block(..., false)`); la rama de la sonda hereda el origen (`#blockOriginOf`) y deja pasar el `detached`; mensaje del aplazo distingue «espera a una entrada APARCADA» de «corre el relay completo». |
| `index.ts` | exporta `RELAY_ORIGIN_MAX_HOPS`. |
| `tests/helpers/fga_spy.ts` | `invocations` (método + args) además de `calls`. |
| `tests/relations_openfga.spec.ts` | Grupo con el `:8101` (4 casos: EL CASO con filtro/paridad/`app` vs `appliance`, reconcile 3-en-1 = suma y mismo destino + idempotente, prefijos 3-4/3-6 + una sola pedida, mutante página vacía + token repetido + sin `tuples` + `[]`) y grupo 3-1' sin servidor (2 casos: coste con doble de cliente; caída a K llamadas y los tres 500 de `partition(s)`). |
| `tests/scope_outbox.spec.ts` | Grupo alpha.6: EL CASO (un salto y dos, `attached` pedido detrás sigue aplazado, no pedidas intactas, pasada completa coherente), NEGATIVO 1, NEGATIVO 2, letra README. |
| `tests/scope_depth.spec.ts` | `RELAY_ORIGIN_MAX_HOPS` en la tabla; «one sweep for K partitions»; el prefijo; la sección de coste. |
| `README.md` | Párrafo «Under `only` the purge exemption holds too» (sustituye a «does not apply yet»); filas «Limits» (`Read` page size: página vacía + token ≠ fin, 503 en vez del «500 E_AUTHZ_INTERNAL» que no era verdad; coste por BARRIDO con cifras antes/después; `RELAY_ORIGIN_MAX_HOPS`); sección `#### The source sweep, measured` con la tabla; mención de `partitions` en el párrafo de migración. |
| `CHANGELOG.md` | `[Unreleased] — 2.4.0-alpha.6` (Added/Fixed, estilo 1.1.0; el lock viejo se retira en la siguiente). |
| `CLAUDE.md` | cabecera (informe), párrafo de cotas, higiene (iii) (herencia del origen), fila del driver de relaciones (alpha.6). |
| `.claude/contexto/roadmap-2.0.md` | los dos ítems de 2.5 tachados como HECHOS en alpha.6. |

## 1 · ROJO

| | log | resultado |
|---|---|---|
| Pieza 1 · `relations_openfga.spec.ts` (4 casos con el `:8101` + 2 sin servidor, 3-1') | `$S/a6_p1_red.log` | **6 rojos** / 39 verdes (`enumerateRelationsMany` no existe; `partitions` ignorado) |
| Pieza 2 · `scope_outbox.spec.ts` (EL CASO + 2 negativos + letra) | `$S/a6_p2_red.log` | **2 rojos** / 97 verdes: EL CASO (`#3 detached(unit)` ⇒ `deferred/depends-on:#2`, `#4 detached(grandchild)` ⇒ `deferred/depends-on:#2`, ninguna purga) y la letra; los negativos verdes (fijan el comportamiento conservador de hoy; existen para el mutante) |

## 2 · Línea base y paridad (script `$S/a6_sweep.ts`, store persistido `$S/a6_store.json`)

5 000 tuplas (`app`, `appliance|…` —prefijo literal de `app`—, `unit|…` × 1 000 + 2 000 ajenas), OpenFGA v1.19.0 `:8101`:

| | `read` | ms (3 corridas) | log |
|---|---|---|---|
| ANTES: 3 × `enumerateRelations` | 150 | 502 · 530 · 558 | `$S/a6_sweep_baseline.log` |
| DESPUÉS: 1 × `enumerateRelationsMany([3])` | **50** | **194 · 209 · 170** | `$S/a6_sweep_many.log` |

Paridad **byte a byte** (JSON canónico ordenado por `object.id`, `expiresAt` normalizado) de las tres particiones contra
`$S/a6_baseline_{0,1,2}.json` guardados ANTES del cambio: **SÍ en las tres, en las tres corridas**.

## 3 · VERDE

- Pieza 1: `$S/a6_p1_green.log` ⇒ **45/45**. Dos ajustes de expectativa, no de código: el SDK exige ULID en `storeId`
  aun sin servidor (3-1'); nada más.
- Pieza 2: `$S/a6_p2_green.log` ⇒ **99/99**. Dos ajustes de expectativa, no de código, ambos semántica fijada en alpha.5:
  la sonda nombra la pendiente MÁS ANTIGUA que comparte clave (`depends-on:#2`, no `#2b`), y bajo `only` las aparcadas no
  pedidas van en `dead` (global), no en `entries`. EL CASO: `#3 detached(unit)` y `#4 detached(grandchild)` **applied** con
  `purgeScope` de los dos; `#5 attached(cousin, child)` pedido ⇒ `deferred/depends-on:#2` (origen aparcado); las tres no
  pedidas siguen `pending` con `attempts = 0`; la pasada completa posterior aplaza exactamente esas tres.
- Letra: `scope_depth.spec` **7/7** (`RELAY_ORIGIN_MAX_HOPS` atado a la tabla, «one sweep for K partitions», el prefijo,
  la sección de la tabla de coste); `typecheck` ✔ (`$S/a6_typecheck2.log`).

## 4 · Mutantes (cada uno: mutar → suite → restaurar desde copia; `cmp` final = árbol pre-mutante)

| Mutante | Qué | log | rojos |
|---|---|---|---|
| **A · filtrar por PREFIJO** | `#sweep`: `#readAll(op, {})` → un `#readAll(op, { object: \`document:${clave}|\` })` por partición | `$S/a6_mutA_prefix.log` | **6** / 45: EL CASO (filtro `{}` y paridad), reconcile 3-en-1, prefijos 3-4/3-6, el caso de página vacía, el 3-1' sin servidor **y el caso del contrato publicado** («enumera las tuplas de la partición»: 200 con cero tuplas) |
| **B · una página vacía = fin** | `#readAll`: `continuationToken = tuples.length === 0 ? undefined : token` | `$S/a6_mutB_emptypage.log` | **1** / 45: el caso «página con CERO tuplas y token no termina el barrido» |
| **C · toda anterior = aparcado** | rama de la sonda: `byParked = true` | `$S/a6_mutC_allparked.log` | **2** / 99: NEGATIVO 1 (anterior pendiente de verdad ⇒ purgaba) y NEGATIVO 2 (anterior bloqueada por FALLO ⇒ purgaba); EL CASO sigue verde, como debe |

## 5 · Verificación final (4 modos, `:8101`, primer plano y en secuencia)

`tsc --noEmit` ✔ (`$S/a6_tsc2.log`) · `typecheck` ✔ (`$S/a6_typecheck2.log`) · `check:purity` ✔ (`$S/a6_purity.log`) · `build` ✔
(`$S/a6_build.log`).

| modo | base (alpha.5) | **ahora** | Δ | exit | s | log |
|---|---|---|---|---|---|---|
| sqlite `:memory:` | 1281 | **1291** | +10 | 0 | 101 | `$S/a6_final_sqlite.log` |
| sqlite-file | 1307 | **1317** | +10 | 0 | 97 | `$S/a6_final_sqlitefile.log` |
| pg | 1402 | **1412** | +10 | 0 | 137 | `$S/a6_final_pg.log` |
| mysql | 1404 | **1414** | +10 | 0 | 176 | `$S/a6_final_mysql.log` |

Δ = 6 casos en `relations_openfga.spec` (4 con el `:8101` + 2 sin servidor) + 4 en `scope_outbox.spec`. Aditivo; sin `skip`;
sin mutantes residuales (`cmp` tras cada uno).

## 6 · Lo que NO hice / contradicciones con el diseño

- **«Un `Read` que responde 200 con cero tuplas donde el censo previo decía que había ⇒ 500»**: en la ENUMERACIÓN no
  existe un «censo previo» en runtime (la primera lectura ES el censo), así que esa cláusula no se puede implementar
  como guarda del driver sin inventar un segundo barrido. Donde sí hay censo previo —la purga (`#purgeByFilter`: lee,
  borra, re-lee y exige cero)— la demostración de cero ya existía (invariante 11). Lo que SÍ hay: (a) prohibición del
  prefijo verificada por el FILTRO de cada `read` (espía con `invocations`), que es la única forma en que un 200-vacío
  puede aparecer; (b) página vacía con token ≠ fin; (c) token repetido / >10 000 páginas / respuesta sin `tuples` ⇒ 503;
  (d) `[]` ⇒ 500 con cero lecturas; (e) en los casos, la paridad contra el censo por partición. Reportado, no inventado.
- **README decía «500 `E_AUTHZ_INTERNAL`»** para el token repetido; el código lanza desde siempre `AuthorizationBackendError`
  (503 `E_AUTHZ_BACKEND_UNAVAILABLE`). No cambié el código (sería breaking sin motivo); corregí la letra y lo anoto en el
  CHANGELOG.
- **`purgeObject`/`purgeSubject` «por partición si aplica»**: no aplica (no barren el store). Escrito en CLAUDE.md.
- El comando `authz:relations:reconcile` sigue siendo de UNA partición (`--partition-type/uuid`); `partitions` es API de
  código para la plataforma que itera tenants (el docblock del comando ya decía «migrar TODAS es iterar por el
  consumidor»). Un flag repetible es una decisión de interfaz que no estaba en el encargo.
- El lock viejo de MySQL NO se retira (por diseño; dicho en el CHANGELOG).
