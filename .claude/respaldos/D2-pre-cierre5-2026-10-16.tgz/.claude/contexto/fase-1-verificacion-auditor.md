# Fase 1 · Verificación del auditor de seguridad — prueba de cierre (2026-08-28)

> Contra `188d625` (`v2/fase-0`), árbol limpio, **sin tocar un solo archivo del paquete**.
> Reproducciones nuevas en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/v2/`:
> `v2_db.ts`, `v2_fga.ts`, `v2_trunc.ts`, `v2_tope3.ts`, `v2_attacks.ts`, `v2_attacks2.ts`,
> `v2_phantom.ts`, `v2_import.ts`, `v2_diverge.ts`, `v2_prune.ts`, `v2_rolequery.ts`, `v2_dbdown.ts`
> (son los `repro_*.ts` de los paneles 1 y 2 adaptados a la API 2.0: `grant → GrantOutcome`,
> resolutor `→ null`, `appAccess` sin `role`).
> Servidores: OpenFGA `:8101` (v1.19.0, postgres) y uno efímero con **tope 3**
> (`openfga-tope3-audit`, `:8109`, `OPENFGA_LIST_OBJECTS_MAX_RESULTS=3` +
> `OPENFGA_LIST_USERS_MAX_RESULTS=3`), **eliminado al terminar**.
> Suite del paquete verificada por mi cuenta antes de atacar: **200/200 contra `:8101`** y
> **200/200 contra el tope 3** (`npm test` con `OPENFGA_TEST_URL`).

## Veredicto en una línea

**APTA CON CORRECCIONES**: los 16 defectos que la Fase 1 dice cerrar están cerrados —cada exploit
que yo escribí falla ahora con el 422/503/`false` previsto, incluido el único fail-open medido con
datos realistas (L0.7, 10.030 denies)— y **no encontré ningún 🔴 nuevo ni ningún camino de
autorización que un atacante pueda abrir**; lo que queda es un 🟠 de disponibilidad/auditoría
(una escritura que aterriza *después* de que el paquete devolvió 503, sin evento `onWrite`) y una
lista de 🟡 en los que **la documentación promete más de lo que el código demuestra**.

---

## Misión 1 · Prueba de cierre

Cada fila: el exploit del panel, lo que hacía en 1.1.0 y lo que hace ejecutado tal cual (adaptado a
la API 2.0) contra `188d625`.

| Defecto | Reproducción | Resultado 1.1.0 | Resultado ahora | Estado |
|---|---|---|---|---|
| **L0.1** `whereScopeIn([])` | `v2_db.ts` | SQL **sin filtro de scope** (concede en cualquiera) | lectura ⇒ `null` **sin consultar**; escritura ⇒ 500 `E_AUTHZ_INTERNAL` | ✅ cerrado |
| **L0.2** `holderTypes` no inyectivo | `v2_fga.ts` | `authorize(integrations:U)`=**true**, `listSubjects` mentía, `revoke` cruzado | constructor **y** generador de modelo ⇒ 500 `E_AUTHZ_CONFIG` (también mapa vacío) | ✅ cerrado (hueco declarado → H6) |
| **L0.3** scope borrado con deny | `v2_db.ts` | `false → **true**` al borrar la unit del árbol; scope inventado **true** | `false` en ambos; `grant`/`deny` ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE`; `revoke`/`removeDeny` no-op; sin resolutor ⇒ 422 `E_AUTHZ_NO_SCOPE_RESOLVER` (y `app` sigue funcionando) | ✅ cerrado (residual → H8) |
| **L0.4** re-grant sin opciones | `v2_db.ts` | `expires_at 1787890198448 → **null**` (temporal ⇒ permanente) | `{existed:true, previousExpiresAt:…, expiresAt:…}` y `expires_at` **intacto**; `null` la quita | ✅ cerrado (matiz → H10) |
| **L0.5** `user:undefined` e inyección | `v2_db.ts`, `v2_fga.ts` | openfga escribía `user:undefined`; database **persistía** `''`, `x#y`, `a b`, `"x' OR '1'='1"` | **422 `E_AUTHZ_INVALID_IDENTITY` en 11/11 entradas y en los dos drivers**, `authorize` incluido; `filas escritas: 0`; `listSubjects: []` | ✅ cerrado (⚪ holder type no declarado → H15) |
| **L0.6** `appAccess` y `hasRole` | `v2_db.ts` | `appAccess({role})` dejaba pasar con todos los permisos denegados; `hasRole` solo por slug | `appAccess({role})` y `appAccess({role,permission})` ⇒ 500 `E_AUTHZ_ROLE_IS_NOT_ACCESS`; `hasRole('owner', org)`=true por herencia de app pero `hasRole({slug:'owner',scopeType:'organization'}, org)`=**false** | ✅ cerrado |
| **L0.7** truncamiento de denies | `v2_trunc.ts` (**10.030 denies reales**) + `v2_tope3.ts` | `listScopes` devolvía **30 scopes con `authorize=false`** (fail-open) | `listObjects` crudo **sigue** devolviendo 1000/10030 (el tope es real) pero el driver ya no lo usa: `listScopes` = **0 scopes**, `listBindings` **30/30**, `diagnostics.unparseableBindings: 0`, 771 ms | ✅ cerrado |
| **L0.7** (tope 3) | `v2_tope3.ts` | — | `listScopes` 4/5 sin la denegada, `listRoleScopes` 5, `listSubjects` **11** mientras `listUsers` crudo del mismo objeto devuelve **3** | ✅ cerrado |
| **L0.8** `docs~read` | `v2_fga.ts` | `removeDeny('docs~read')` **levantaba** el deny de `docs:read` | 422 `E_AUTHZ_INVALID_SLUG` en `deny` y `removeDeny`; el deny sigue en pie (`authorize`=false antes y después) | ✅ cerrado |
| **N1** sync sin prune | `v2_db.ts`, `v2_prune.ts` | `docs:write` seguía concediendo tras quitarlo del config | `false`; y el prune es **transaccional de verdad en SQLite** (verificado con un 422 a mitad y con la tabla de vínculos caída: los vínculos quedan como estaban) | ✅ cerrado |
| **N2** `{app, uuid}` | `v2_fga.ts` | openfga: `{app,tenant-A}`, `{app,tenant-B}` y `APP_SCOPE` todos **true**; database false | 422 `E_AUTHZ_INVALID_IDENTITY` en `grant` y en `authorize`, en **ambos** drivers | ✅ cerrado |
| **N3** base local caída | `v2_dbdown.ts` | `SqliteError` **sin status ni code** en los dos drivers | 503 `E_AUTHZ_BACKEND_UNAVAILABLE` (`instanceof AuthorizationBackendError`) en `authorize` y `listScopes`, en ambos | ✅ cerrado |
| **N4** `revoke` no-op silencioso | `v2_db.ts`, `v2_diverge.ts` | 1 asignación viva tras `revoke`, sin error | **igual** (`authorize` sigue true, `listRoles` la muestra) — y ahora además **diverge**: openfga sí borra | ❌ abierto (no estaba en la Fase 1) → H9 |
| **N5** purga de scope | `v2_attacks2.ts` | no existía | `purgeScope` obligatorio + `scopes.detached`; raíz 422; database transaccional | ⚠️ parcial (openfga no puede demostrar cero → H2) |
| **N6** cuelgue sin deadline | `v2_phantom.ts` | `authorize` **colgado indefinidamente** | 503 `E_AUTHZ_BACKEND_TIMEOUT` **en 254 ms** con `timeoutMs: 200` contra un servidor que responde a 1,2 s | ✅ cerrado (con H1) |
| **N7** `batchCheckAll` por orden | lectura de `openfga_driver.ts:197-228` + su unitario | correlación posicional, `.request` descartado | `correlateBatchResults` por `correlationId`, 500 `E_AUTHZ_INTERNAL` ante duplicado/ausente/ajeno | ✅ cerrado |
| **S2** ciclos de `parent` | `v2_attacks.ts` A3 | FGA evalúa el ciclo y responde `true` en la raíz | 422 `E_AUTHZ_SCOPE_CYCLE` **sin una sola llamada al driver** (`llamadas: []`) | ✅ cerrado (límite → H12) |
| **S3** `moved` en dos requests | — | patrón peligroso en el driver | el manager valida; ningún driver implementa aún `onScopeMoved` (es 3b) | ⚠️ diferido, sin superficie hoy |
| **S4** familias `can_/denied_/permits_` | `v2_fga.ts` | `can_docs_write` colapsaba la relación y **anulaba el deny** | 422 `E_AUTHZ_INVALID_SLUG` para `can_*`, `denied_*`, `permits_*`, `parent`, `assignee`, mayúsculas, `a:b:c`, 43 chars, y colisión `docs:write`/`docs_write` **en el mismo spec** | ✅ cerrado (parcial entre catálogos → H5) |
| **S7** import con `Ignore` | `v2_import.ts` | la caducidad se evaporaba y el import reportaba éxito | 409 `E_AUTHZ_STORE_NOT_EMPTY` sin `--reconcile`; con él, `updated: 1` y la tupla pasa a llevar `valid_until`; 1 ms de diferencia ⇒ `updated` | ✅ cerrado (no converge → H3) |
| **S11** `HIGHER_CONSISTENCY` | `v2_fga.ts` (espía sobre el cliente) | ausente en todas las llamadas | `llamadas sin consistency: []` en `read` y `batchCheck`; `operaciones usadas: read, writeTuples, batchCheck`; **cero** `listObjects`/`listUsers` | ✅ cerrado |
| **S13/S14** longitudes y reservados | `v2_fga.ts` | sin límite; un permiso `parent` invalidaba el modelo entero | 42 chars como frontera (42 acepta, 43 rechaza), reservados 422 | ✅ cerrado |
| **S17** `context` en los denies | `v2_fga.ts` (espía) | los checks de deny iban **sin** `context` | `batchChecks sin context.current_time: 0` (grant, deny, hasRole, listScopes, listRoles, listSubjects) | ✅ cerrado |

**Resumen: 20 ✅ cerrados, 2 ⚠️ parciales/diferidos (N5 y S3, ambos declarados en el CHANGELOG),
1 ❌ abierto que nunca estuvo en el alcance (N4).**

---

## Misión 2 · Romper lo nuevo — hallazgos

### 🟠 H1 · Escritura fantasma: la escritura aterriza *después* del 503 por deadline, y `onWrite` no la ve

- **Escenario**: precondición — OpenFGA (o un proxy/ingress delante) responde más lento que
  `timeoutMs` pero **acaba respondiendo** (1,2 s con `timeoutMs: 250`; un pico de latencia normal).
  Acción — el consumidor llama `authorization.grant(subject,'editor',APP_SCOPE,{expiresAt:null})`.
  Resultado — el paquete lanza `AuthorizationBackendTimeoutError` (503) a los 754 ms, **el manager
  no emite ningún evento `onWrite`** … y 3 segundos después la tupla **está escrita** y
  `authorize` responde **`true`**. Idéntico con `deny`.
- **Evidencia**: ✅ `v2_phantom.ts` (proxy HTTP local que reenvía a `:8101` con retardo):

  ```
  grant LANZO en 754 ms: "AuthorizationBackendTimeoutError/503/E_AUTHZ_BACKEND_TIMEOUT"
  eventos onWrite emitidos: []
  tupla inmediatamente despues del 503: 0
  tupla 3 s despues del 503 (escritura fantasma): 1
  authorize tras el grant que "fallo": true
  deny 3 s despues del 503 (fantasma): 1
  ```
  Causa: `withDeadline` (`backend_guard.ts:87-94`) hace `Promise.race` y **libera al llamante sin
  abortar la petición**; el SDK sigue (y además reintenta: `maxRetry: 3`). Lo dice el propio informe
  del lote A (desviación 2), pero solo como coste interno.
- **Steelman del defensor**: *"un deadline es un deadline; el SDK no permite abortar por llamada y
  la alternativa (esperar la suma de reintentos) es peor."* → **Me convence lo del deadline y no me
  convence el silencio**: el problema no es que la escritura llegue tarde, es que (a) el llamante
  cree que **no** ocurrió, (b) **la auditoría no la registra** —`onWrite` es el sitio que el chasis
  usa para auditar y emitir SSE— y (c) el README promete lo contrario en su lista de propiedades
  operativas del driver (*"none of them can grant access that wasn't granted, all fail towards
  denied"*). Un privilegio vivo del que no hay rastro en el log es peor que un 503.
- **Severidad**: 🟠 y no 🔴 porque el atacante no lo dispara ni elige el resultado; pero la
  condición (backend lento) es rutinaria y el efecto es un privilegio sin auditoría.
- **Mitigación mínima (una línea)**: pasar un `AbortController`/`signal` por llamada en las
  **escrituras** (axios lo soporta vía `baseOptions`/`options`), o —si no— documentar y emitir un
  evento `onWrite` con `action` de resultado indeterminado antes de propagar el 503.

### 🟡 H2 · `purgeScope` (openfga) dice "cero" sin poder demostrarlo, y el hecho resucita

- **Escenario**: precondición — un rol se retira del catálogo (`authz_roles`) después de haberse
  concedido; es la operación que el propio README manda hacer a mano ("roles and permissions are
  never deleted [por el sync] … they carry assignments"). Acción — `scopes.detached(unit)` ⇒
  `purgeScope`. Resultado — **la purga devuelve éxito**, el `role_binding` sigue en el store, y en
  cuanto el rol vuelve al catálogo (re-deploy) `authorize` responde **`true`** sobre un scope que
  el operador dio por purgado.
- **Evidencia**: ✅ `v2_attacks2.ts` A5:

  ```
  authorize antes de purgar: true
  purgeScope(unit) con el rol ya borrado: "EXITO (dice cero)"
  tuplas de rol que quedan tras la purga exitosa: 1
  authorize tras resucitar el rol en el catalogo: true
  ```
  `openfga_driver.ts:1057-1066` construye los objetos a purgar **desde el catálogo SQL**
  (`authz_roles` de ese `scope_type` + todos los permisos); lo que no está en el catálogo no se lee
  ni se cuenta como residuo.
- **Steelman del defensor**: *"está declarado en el CHANGELOG ('bindings of a role removed from the
  catalog are unreachable by the openfga purge … become `authz:reconcile`'s job in 3b') y en el
  README (§ operational notes)."* → **Me convence como decisión de alcance y no como contrato**:
  `src/types.ts:160-167` dice literalmente *"Debe demostrar que quedó a cero o lanzar (500
  `E_AUTHZ_PURGE_INCOMPLETE`): un borrado parcial silencioso deja hechos huérfanos e indenegables"*,
  y el caso del juez se llama *"detach purga los hechos del scope: **nada resucita** al volver a
  colgarlo"*. El puerto y el juez afirman una garantía que el driver no tiene; el README la
  desmiente 150 líneas más abajo. Un invariante que se cumple "salvo que…" hay que escribirlo así.
- **Mitigación mínima**: la purga puede demostrar cero de verdad sin índice por objeto con la misma
  primitiva que ya usa: `readAllTuples({ object: 'role_binding:' })` paginado y filtrado en cliente
  por el prefijo `<scopeKey>|` (es lo que hace `listBindings`); si se prefiere no pagar ese coste,
  reescribir el comentario del puerto y el título del caso para acotar la promesa al catálogo.

### 🟡 H3 · `--reconcile` no converge: lo que el store tiene de más sobrevive, y el reporte parece "en sync"

- **Escenario**: precondición — store poblado (migración `database → openfga`, restore, o un import
  anterior). Acción — `openfga:import --reconcile`. Resultado — las tuplas que **no** están en SQL
  (un grant revocado en SQL, o un holder que nunca estuvo) **siguen concediendo**, y el reporte sale
  `{written:0, updated:0, unchanged:0, skippedExpired:0}` — indistinguible de "no había nada que
  hacer".
- **Evidencia**: ✅ `v2_import.ts`:

  ```
  authorize del ZOMBIE (nunca estuvo en SQL) tras reconcile: true
  reconcile tras revocar en SQL: {"written":0,"updated":0,"unchanged":0,...}
  authorize de alice tras revocar en SQL + reconcile: true
  ```
- **Steelman del defensor**: *"el CHANGELOG dice explícitamente 'No deletion of tuples that SQL no
  longer has (that is `authz:reconcile`, phase 3b)'."* → **Me convence a medias**: la decisión está
  declarada, pero el nombre de la bandera es `--reconcile`, el README lo vende como *"compare tuple
  by tuple"* y *"a run that dies half-way is fixed by running it again with `--reconcile`"*, y el
  reporte de ceros no distingue "convergido" de "no miré lo que sobra". `CLAUDE.md` (regla del
  catálogo/drivers) promete además que la migración *"reporta written/**deleted**/updated/skipped"*.
- **Mitigación mínima**: añadir al reporte un `foreignTuples` (contadas, no borradas) o renombrar la
  bandera a `--reconcile-writes`; una línea en el README diciendo "no borra lo que sobra".

### 🟡 H4 · `RoleQuery` en objeto donde el contrato pide `string` ⇒ 503 (database) o `TypeError` crudo (openfga)

- **Escenario**: precondición — un call-site JS (o una entrada sin tipar: un body, un job) pasa
  `{slug:'editor', scopeType:'app'}` a `listSubjects`/`grant`/`revoke`, cuya firma es `role: string`.
  `assertIdentity({ role })` lo valida como `RoleQuery` y **lo deja pasar**. Resultado — database:
  503 `E_AUTHZ_BACKEND_UNAVAILABLE`; openfga: `TypeError` sin `status` ni `code`.
- **Evidencia**: ✅ `v2_rolequery.ts`:

  ```
  database: listSubjects({slug,scopeType}) LANZO: "AuthorizationBackendError/503/E_AUTHZ_BACKEND_UNAVAILABLE"
  openfga:  listSubjects({slug,scopeType}) LANZO: "TypeError/status=-/code=-"
  openfga:  revoke({slug,scopeType}) LANZO: "TypeError/status=-/code=-"
  ```
  `manager.ts:144-147,164-199` usa el mismo `assertIdentity({ role })` para los cinco métodos, pero
  solo `hasRole` acepta la forma objeto (`types.ts:99`).
- **Steelman del defensor**: *"TypeScript ya lo impide; es un error de programación."* → **No me
  convence**: es exactamente el argumento que la Fase 1 rechazó al cerrar L0.5 (el `uuid: undefined`
  también "lo impedía TypeScript"), y el resultado es lo que el lote A prometió erradicar: **un bug
  de programación disfrazado de caída de infraestructura** (503 manda a operaciones a buscar un
  incidente que no existe) o un error sin clasificar cruzando la abstracción.
- **Mitigación mínima**: en el manager, los métodos con `role: string` validan con
  `assertValidSlug('rol', role)` en vez de `assertIdentity({ role })`.

### 🟡 H5 · La colisión de slugs solo se comprueba **dentro** de un spec; entre catálogos pasa, y el prune de un catálogo borra los vínculos del otro si comparten el rol

- **Escenario A (colisión)**: catálogo de plataforma con `docs:write`, catálogo de tenant con
  `docs_write`. Cada `syncAuthzCatalog` valida su propio spec ⇒ los dos slugs conviven en la base.
  Hoy es inocuo (el driver openfga codifica `:`→`~`), pero es **exactamente** la colisión de S4 que
  el modo `facts` (3b) proyectará a la misma relación `docs_write`.
- **Escenario B (prune cruzado)**: dos catálogos declaran el mismo `admin`@`app` con permisos
  distintos. Sincronizarlos en orden deja **solo** los del último: el sync del catálogo B **borró
  los vínculos del rol del catálogo A** en su transacción.
- **Evidencia**: ✅ `v2_fga.ts`:

  ```
  colisión docs:write / docs_write REPARTIDA en dos catálogos: "ACEPTADA (ambos en la base)"
  permisos en base: ["docs:write","docs_write"]
  vínculos de `admin`@app tras sincronizar los dos catálogos: ["tenant:read"]
  ```
  `catalog.ts:24-38` valida `assertNoSlugCollisions` sobre `catalog.permissions` del spec, no contra
  lo que ya hay en `authz_permissions`; `catalog.ts:141-152` poda por `role_uuid`, y la identidad
  del rol es `(slug, scope_type)` — compartirla es compartir el rol.
- **Steelman del defensor**: *"el README ya dice que el spec manda **para los roles del spec** y que
  el orden de `config.catalogs` importa."* → **Me convence para B a medias** (el efecto es
  fail-closed y `authz:catalog:diff` lo delata) **y no para A**: el README afirma sin matices que la
  validación incluye *"collisions after encoding (`docs:write` vs `docs_write`)"*, y la frase
  siguiente promete que dos catálogos coexisten. Las dos cosas no son ciertas a la vez.
- **Mitigación mínima**: `assertNoSlugCollisions` sobre spec ∪ `authz_permissions` de la base dentro
  de la misma transacción, y un aviso (o 422) si un rol del spec ya existe con vínculos de otro
  catálogo.

### 🟡 H6 · `holderTypes` inyectivo no está atado al store: renombrar un morph hereda los hechos del anterior

- **Escenario**: store escrito con `{ users: 'user' }`. El consumidor renombra el morph name
  (`users` → `people`) o reutiliza el store con otro mapa igual de inyectivo. Acción — `authorize`
  con `{type:'people', uuid:U}`. Resultado — **`true`**: hereda todos los grants de `users:U`.
- **Evidencia**: ✅ `v2_fga.ts`: `MISMO store, morph renombrado people→user: authorize(people:U): true`.
- **Steelman del defensor**: *"L0.2 pedía inyectividad y eso está hecho; `OpenFgaDriverOptions`
  documenta que el mapa debe ser el mismo con el que se escribió el modelo."* → **Me convence como
  alcance** (yo mismo lo marqué como "hueco" en el panel 1 y el plan no lo recogió) **y no como
  garantía del invariante 4**: la inyectividad protege de fundir dos morphs *hoy*; no protege de
  fundir el morph de hoy con el de ayer. Es config, no ataque: por eso 🟡.
- **Mitigación mínima**: escribir el mapa como metadata del store (o derivar el nombre del tipo FGA
  del morph, `users` → `users`) y compararlo en el boot del driver.

### 🟡 H7 · `readAllTuples` no acota las páginas: un `continuation_token` que no avanza es un bucle infinito

- **Escenario**: precondición — el servidor (o un proxy/caché delante) devuelve siempre el mismo
  `continuation_token`. Acción — cualquier `list*` del driver openfga. Resultado — el bucle
  `do…while` de `openfga_driver.ts:1112-1128` **no termina nunca**: el deadline es *por llamada*, no
  por operación, así que ni `timeoutMs` ni el guard lo cortan.
- **Evidencia**: ✅ `v2_attacks.ts` A4 — tuve que cortar el fake a las 300 páginas para que el
  proceso terminara (`siguio hasta que corte el fake … (301 lecturas)`); sin ese corte el script se
  comió los 2 minutos de timeout del runner y no ejecutó nada más.
- **Steelman del defensor**: *"OpenFGA devuelve token vacío al acabar; eso no pasa."* → **No me
  convence del todo**: es la misma clase de suposición ("el backend se porta bien") que N6 cerró con
  un deadline, y aquí el fallo no es un 503 sino un proceso que no vuelve.
- **Mitigación mínima**: cota de páginas (o de tuplas) en `readAllTuples` y 503/500 al superarla;
  cortar también si el token se repite.

### 🟡 H8 · L0.3 residual: un resolutor que responde `[APP_SCOPE]` a lo que no conoce reabre el bypass entero

- **Escenario**: el consumidor escribe `resolveAncestors` con el fallback natural
  `?? [APP_SCOPE]` (lo que hacía el default del paquete en 1.1.0). Acción — `authorize` sobre un
  scope inventado o ya borrado, con el holder denegado en su organización real. Resultado — **`true`**.
- **Evidencia**: ✅ `v2_attacks.ts` A2:
  `authorize en unit INVENTADA con resolutor que cae a [app]: true` / `(comparar) authorize en la org donde hay deny: false`.
- **Steelman del defensor**: *"el paquete ya no trae ese default, el tipo permite decir `null`, el
  README lo prohíbe en negrita ('Never answer `[APP_SCOPE]` for what you do not know') y hay un caso
  del juez que lo fija."* → **Me convence**. Lo anoto porque es el único camino que reabre L0.3 y
  porque conviene que quede escrito que **es responsabilidad del consumidor**, no un defecto abierto.
- **Mitigación mínima**: nada en el paquete; en el chasis, que el resolutor publicado devuelva `null`
  y un test de integración lo fije.

### 🟡 H9 · N4 sigue abierto y ahora es una **divergencia entre drivers**

- **Escenario**: el `scope_type` de un rol cambia en el catálogo después de concederlo. Acción —
  `revoke(holder, rol, scope)`. Resultado — `database`: **no borra nada, no lanza**, `authorize`
  sigue `true` y `listRoles` sigue mostrándolo; `openfga`: **sí borra** (el binding es por
  `scopeKey|slug`, no por uuid de rol).
- **Evidencia**: ✅ `v2_diverge.ts`:

  ```
  database: revoke tras cambiar scope_type: "sin error"   → authorize DESPUES del revoke: true  · listRoles: ["org-editor"]
  openfga:  revoke tras cambiar scope_type: "sin error"   → authorize DESPUES del revoke: false · listRoles: []
  ```
- **Steelman del defensor**: *"N4 nunca entró en la Fase 1."* → **Correcto**, por eso no cuenta
  contra el cierre; pero el README afirma *"for everything the suite covers, both drivers answer the
  same"* y el juez no cubre esto, así que la afirmación se sostiene por omisión.
- **Mitigación mínima**: `revoke` resuelve el rol **por uuid** (o borra por `slug` sin filtrar
  `scope_type`), y un caso del juez con el catálogo cambiado bajo los pies.

### 🟡 H10 · Un acceso temporal recién expirado se vuelve **permanente** con un re-grant idempotente

- **Escenario**: acceso de emergencia con `expiresAt` a 60 s. Expira. El cron "asegúrate de que
  tiene el rol" llama `grant` sin opciones. Resultado — la asignación revive **sin caducidad**.
- **Evidencia**: ✅ `v2_attacks2.ts` A6:
  `outcome del re-grant sin opciones: {"existed":true,"previousExpiresAt":"…","expiresAt":null}` y
  `authorize tras el re-grant: true`. Con `expiresAt` **exactamente ahora** ocurre lo mismo
  (`isActiveExpiry` usa `>`).
- **Steelman del defensor**: *"es la semántica decidida y documentada en tres sitios (tabla del
  README, `GrantOptions`, `expiry.ts`), y el manager la audita como `extended` con
  `previousExpiresAt`."* → **Me convence**: es explícito y auditable. Lo dejo en 🟡 porque el efecto
  (temporal ⇒ permanente) es el mismo que L0.4 cerró, solo que un segundo más tarde, y quien lea
  "L0.4 cerrado" puede no darse cuenta.
- **Mitigación mínima**: nada de código; una línea en el README diciendo que "revive" significa
  **permanente**, o un `revive: 'never' | 'permanent'` en `GrantOptions` para Fase 2.

### ⚪ H11 · Un ancestro inválido devuelto por el resolutor sale como **422 de identidad** en una lectura

`authorize` con un resolutor que devuelve `{app,'X'}` o `{organization,'a|b'}` lanza
`InvalidIdentityError` (422) — la pregunta era válida; lo inválido era la respuesta del árbol, que
es una dependencia (503 `E_AUTHZ_RESOLVER_FAILED`). Fail-closed, pero mal clasificado y sin pistas
para el operador. ✅ `v2_attacks.ts` A2. Mitigación: validar la cadena en `resolveChain` y envolver
el fallo como `ScopeResolverError`.

### ⚪ H12 · El anti-ciclo es tan bueno como el resolutor, y un error del consumidor con `code: E_AUTHZ_*` pasa sin reclasificar

`#assertEdge` pregunta la cadena al resolutor del consumidor: un resolutor que omite al hijo deja
pasar el ciclo (✅ `attached(org, unit) con resolutor que oculta el ciclo: ACEPTADO`). Es inherente
(el paquete no tiene otra fuente de verdad) pero conviene no leer `CLAUDE.md` ("anti-ciclos … son
del paquete, nunca del backend") como si fuera una garantía independiente. Además `isAuthzError`
(`backend_guard.ts:25-27`) confía en el prefijo del `code`: un error del resolutor que lo lleve
puesto se propaga tal cual (✅ `Error/status=422/code=E_AUTHZ_INVALID_IDENTITY`).

### ⚪ H13 · `purgeScope` (database) sale **sin deadline**

✅ `v2_attacks2.ts` A7: los dos `DELETE` dentro de `db.transaction` salen con `timeout: false`,
mientras las consultas normales llevan `timeout: 250`. El README afirma *"every SQL query is built
with a knex timeout"*. `guardSql` solo fija el deadline si lo que recibe es un builder
(`backend_guard.ts:59-70`), y una transacción no lo es.

### ⚪ H14 · `type` con mayúsculas es identidad válida (S15 sigue abierto)

`{type:'Users'}` y `{type:'users'}`, `{type:'Unit'}` y `{type:'unit'}` pasan `assertIdentity`
(✅ `v2_attacks.ts` A1). En openfga son holders/scopes distintos; en `database` sobre MySQL con
collation `*_ci` serían **el mismo**. Con SQLite/PG no se nota. S15 no estaba en la Fase 1; queda
como deuda declarada del harness multi-motor (2.1).

### ⚪ H15 · Holder type no declarado: 500 sin `code` (openfga) vs asignación muerta persistida (database)

✅ `v2_fga.ts`: openfga lanza `Exception/status=500` **sin `code`**; database acepta y escribe la
fila (`filas con holder robots: 1`). Declarado en el informe del lote A (desviación 7) como fuera de
alcance. También ⚪: con el rol borrado del catálogo, `listRoles`/`listRoleScopes` de openfga siguen
devolviéndolo y los de database no (✅ `v2_diverge.ts`) — `authorize` deniega en ambos.

### ⚪ H16 · Higiene menor

- `readAllTuples` descarta en silencio las tuplas sin `user`/`relation`/`object`
  (`openfga_driver.ts:1120`) sin sumarlas a `diagnostics.unparseableBindings`, que es justo la regla
  que L0.16 impuso en los demás caminos.
- `syncAuthzCatalog` con la base caída sigue lanzando `SqliteError` sin `status` ni `code`
  (✅ `v2_prune.ts`); declarado como herramienta en el lote A, pero es lo que corre en el arranque
  de un despliegue.
- `IDENTITY_LIMITS.slug = 100` no lo usa nadie (el límite real es `MAX_SLUG_LENGTH = 42`).

---

## Misión 3 · `CLAUDE.md` / README / CHANGELOG: afirmaciones que el código no cumple

| Documento | Afirmación | Realidad medida |
|---|---|---|
| README § scope tree | *"`detached` runs `purgeScope` — every assignment and deny of that exact scope is deleted and the driver proves zero or throws"* y *"**Nothing resurrects** when the same uuid is attached again"* | Falso en openfga si el rol/permiso ya no está en el catálogo: purga con éxito, la tupla sobrevive, `authorize` vuelve a `true` (H2). El propio README lo desmiente en § *Operational notes* |
| `src/types.ts:160-167` (el puerto) | *"Debe demostrar que quedó a cero o lanzar"* | Misma cosa: la prueba de cero se limita a los objetos que el catálogo conoce |
| README § driver options | *"**every SQL query** is built with a knex timeout"* | Falso para `purgeScope` (transacción: `timeout: false`) y para `syncAuthzCatalog` (H13) |
| README § catalog | *"The whole catalog is validated … including **collisions after encoding** (`docs:write` vs `docs_write`)"* + *"two catalogs coexist"* | Solo dentro de un spec; repartida entre dos catálogos pasa (H5) |
| README § catalog | *"roles outside the spec are untouched, so two catalogs coexist"* | Cierto salvo si comparten `(slug, scopeType)`: el sync del segundo poda los vínculos del primero (H5) |
| README § driver options / § operational notes | el timeout se describe solo como *"an elapsed deadline is 503"*, y las propiedades operativas se cierran con *"none of them can grant access that wasn't granted"* | La escritura puede aterrizar después del 503 y conceder, sin evento `onWrite` (H1) |
| README § import | *"`--reconcile`: compare tuple by tuple"*, *"a run that dies half-way is fixed by running it again with `--reconcile`"* | No borra lo que sobra; un reporte de ceros no distingue convergencia de "no miré" (H3). El CHANGELOG sí lo declara |
| `CLAUDE.md` (regla "todo en un driver o todo en otro") | *"la migración entre drivers es `authz:reconcile`: idempotente, **bidireccional**, reanudable … (reporta written/**deleted**/updated/skipped)"* | La herramienta que existe hoy (`openfga:import --reconcile`) no es bidireccional ni reporta `deleted`; conviene marcar la frase como **3b** para que nadie la lea sobre el `--reconcile` actual |
| `CLAUDE.md` (mapa, `src/identity.ts`) | *"longitudes contra columnas (holder_type 50, scope_type 20, **slug 100**, uuid 36)"* | El límite aplicado es **42** (`MAX_SLUG_LENGTH`); `IDENTITY_LIMITS.slug` está muerto |
| README § install | *"The suite compiles both published configs against the package on every run, so they **cannot drift**"* | `defineConfig<T extends AuthorizationConfig>` absorbe claves de más (el propio informe del lote C lo anota como límite): detecta tipos incorrectos, no deriva por adición |
| `package.json` | `"version": "1.1.0"` | README y CHANGELOG hablan de 2.0.0; es el release del dueño, lo apunto para que no se publique con la versión vieja |

Todo lo demás que verifiqué del README (los ocho invariantes, la tabla de errores, `hasRole` por
nivel, `appAccess`, los tres estados de `expiresAt`, el `consistency`, la nota de "verificado en
SQLite") **coincide con el código y con lo que medí**.

---

## Lo que intenté y NO se rompió

1. **Esquivar `assertIdentity`**: `\n` final y en medio, TAB, NUL, NBSP, RTL override (U+202E),
   homoglifo cirílico, uuid de 37, `scope_type` de 21, `subject` como array, `type` con `toString`,
   `uuid` numérico, `role` objeto sin `scopeType`, permiso `:b` / `a:` / `-a` / vacío, y una `parts`
   con `subject` **heredado del prototipo**: 422 en todos. La lista blanca ASCII anclada
   (`/^[A-Za-z0-9_.-]+$/`) no tiene el agujero del `$` de Python: `'abc\n'` **no** casa en JS.
2. **Inyección SQL** por uuid, tipo o slug: imposible ya en la puerta (422 antes de tocar la base) y
   parametrizada después.
3. **Fail-open del deny por error puntual en FGA**: `denyResults.some(r => r.allowed || r.error)`
   sigue siendo correcto; un batchCheck que falla en la parte de denies **lanza**, no concede.
4. **Página parcial silenciosa**: con la 2.ª página caída, `listRoleScopes` **propaga 503**; no
   devuelve la lista incompleta (`v2_attacks.ts` A4).
5. **`context` y `consistency`**: 0 checks sin `current_time`, 0 llamadas sin `HIGHER_CONSISTENCY`,
   0 `listObjects`/`listUsers` en todo el camino del driver.
6. **Transaccionalidad del prune en SQLite**: real en los dos modos de fallo (422 semántico a mitad y
   tabla desaparecida): los vínculos quedan exactamente como estaban.
7. **`manager.scopes.*`**: ciclo, raíz como hijo, padre fantasma e identidad rota ⇒ 422 **con cero
   llamadas al driver**; resolutor que lanza ⇒ 503; `detached` con `purgeScope` que falla ⇒ **ni
   hook ni evento `scope_purged`**; `scopes.*` sin `config.scopes` ⇒ 500 `E_AUTHZ_CONFIG`.
8. **`whereScopeIn` en lectura con conjunto vacío** ⇒ `null` sin consulta (no "todas las filas").
9. **Enumeraciones bajo tope 3**: `listSubjects` devuelve 11 donde `listUsers` crudo devuelve 3;
   `listScopes` resta el deny; la suite entera (200 casos) pasa contra ese servidor.
10. **Reloj y caducidad**: en SQLite `expires_at` viaja como entero de ms y `previousExpiresAt`
    vuelve idéntico — no conseguí extender una caducidad **vigente** con un re-grant (el vector de
    zona horaria que buscaba no existe en este motor; **❓ no verificable aquí para PG/MySQL**, que
    es justo lo que el README declara sin verificar).
11. **`correlateBatchResults`**: por lectura de código, duplicado, ausente y ajeno terminan en 500
    `E_AUTHZ_INTERNAL`; no logré fabricar un `true` en el scope equivocado.

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **H1**: ¿se acepta que una escritura pueda aterrizar tras un 503 sin evento `onWrite`, o la Fase 2
   se compromete a abortar la petición? Si se acepta, tiene que estar en el README **y** el chasis
   necesita saber que su auditoría no es completa.
2. **H2**: ¿se corrige la purga (leer por prefijo y demostrar cero de verdad) o se corrige la
   promesa (`types.ts` + título del caso del juez)? Hoy el puerto afirma lo contrario del código, y
   eso es lo único que un driver de terceros va a leer.
3. **H4**: ¿`assertIdentity({role})` debe distinguir "rol como pregunta" (`hasRole`) de "rol como
   slug" (el resto)? Es la diferencia entre un 422 y un 503 en producción.
4. **H5**: con `config.catalogs` publicado, ¿la colisión de slugs y la identidad `(slug, scopeType)`
   compartida entre catálogos se validan contra la base, o se documenta que dos catálogos no pueden
   nombrar el mismo rol?

---

**Servidor tope 3 (`openfga-tope3-audit`, `:8109`) eliminado. Ningún archivo del paquete tocado.**
