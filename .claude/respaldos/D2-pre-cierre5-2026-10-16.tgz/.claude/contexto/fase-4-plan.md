# Fase 4 · `relations/` — ReBAC genérico · PLAN MEDIDO

> Base: `main` @ `76c5846` (Fase 3b mergeada, 2.3.0-alpha). Decisión del dueño del 2026-08-31 (4):
> se construye ENTERA, con los dos drivers al mismo nivel de exigencia, sin condicionarla a COGNITIV.
> Este documento NO implementa: entrega el veredicto medido del desconocido y el plan por lotes con
> criterios de aceptación, listo para que lo ataquen auditor + tester y lo sintetice el juez.
> Todo lo marcado ✅ está **medido contra el `:8101`, pg18 y mysql84** (métodos y números en el cuerpo).

---

## VEREDICTO (una línea)

**`relations/` CABE en el modelo `facts`, en el MISMO store y sin bajar los 22 saltos** — el bloque de
relaciones es de coste FIJO (≈271 bytes por tipo de objeto, ≈86 el tipo `group`), no crece con las tuplas,
y compite con los permisos por el mismo techo de 262.144 B; a 447 permisos realistas (97,6 % del techo)
quedan **6.247 B ≈ 23 tipos de objeto** de margen, y cada tipo cuesta ≈ **0,5 permisos**.

**Pero eso convierte «cuántos permisos» y «cuántos tipos de objeto» en UN presupuesto compartido, y eso es
una decisión del dueño, no mía** (§0.4): comparto el store por defecto (simplicidad + promesa de «un Check»),
y dejo el store separado como escape medido para el consumidor que necesite muchos tipos cerca del techo de
permisos.

---

## 0 · El desconocido, MEDIDO (esto decide la fase)

Método: scripts efímeros con `node --import @poppinss/ts-exec` reutilizando `openFgaFactsModel` y
`factsModelBytes` de `src/drivers/openfga_facts.ts` (delta 0 contra el servidor, ya validado en 3b-4·C3);
catálogo realista = 3 holder types + 447 slugs `recursoN:accion` (la fila «≈450 realistas» del docstring de
`FACTS_MODEL_MAX_BYTES`). Modelo de relaciones fusionado = `group#member` (userset) + N tipos `documentK`
con `owner ⊆ editor ⊆ viewer` (includes) y `[holders, group#member]` en cada relación (usersetsOf de un nivel).
Todos los stores creados se borraron; `:8101` quedó a 0 stores.

### 0.1 · TAMAÑO — presupuesto COMPARTIDO, coste fijo del bloque de relaciones

| modelo | bytes | % techo | ¿publica el `:8101`? |
|---|---|---|---|
| facts-only, 447 permisos realistas | 255.897 | 97,6 % | (referencia) |
| + `group` + 1 tipo objeto | 256.254 (+357) | 97,8 % | — |
| + `group` + 5 tipos objeto | 257.338 (+1.441) | 98,2 % | ✅ **201 ACEPTADO** |
| + `group` + 10 tipos objeto | 258.693 (+2.796) | 98,7 % | — |
| + `group` + 20 tipos objeto | 261.413 (+5.516) | 99,7 % | — |

- Coste de `group` (con anidamiento `member from member`): **+86 B**.
- Coste marginal por tipo de objeto (`owner`/`editor`/`viewer` + includes + userset): **+271 B**.
- Bytes por permiso realista: **≈589 B**. ⇒ `group` ≈ **0,1 permisos**; cada tipo de objeto ≈ **0,46 permisos**.
- Margen a 447 permisos: `262.144 − 255.897 = 6.247 B` ≈ **23 tipos de objeto**, o ≈ **10 permisos**.
- **Las tuplas no cuentan** para el tamaño del modelo: un millón de documentos compartidos = 0 bytes de modelo.
  Lo que gasta techo es el nº de TIPOS y de RELACIONES declaradas, no el volumen de datos.

**Conclusión de tamaño:** cabe holgado si el catálogo no está pegado al techo; si lo está, cada tipo de
objeto se paga con ~2 permisos. El gate `assertFactsModelPublishable` **tiene que medir el modelo fusionado**
(hoy solo mide el de `facts`) — si no, un `defineRelationsConfig` empuja por encima del techo y el store queda
sin poder regenerarse: la avería silenciosa que 3b-2a persiguió, movida a esta fase.

### 0.2 · PROFUNDIDAD — el bloque de relaciones NO baja los 22 saltos

Método 2e·E5 (grant en la raíz, `Check` a profundidad creciente, 25 repeticiones/punto), sobre el modelo
**fusionado**:

| | 20 | 21 | 22 | 23 | 24 |
|---|---|---|---|---|---|
| `can_<P>` (facts) en el modelo FUSIONADO | 25/25 | 25/25 | **25/25** | 22/25 | 0/25 |

**Idéntico a `facts`-solo** (22 sólido / 23 probabilístico / 24 nunca). Los `includes` y los `usersetsOf`
viven en tipos `document`/`group` DISJUNTOS del tipo `scope`: un `Check` de `can_<P>` nunca los recorre, así
que **no pueden bajar los 22**. Control: `can_<P>` a 22 saltos con las tuplas de relaciones ya escritas en el
store = 25/25.

Y en el otro sentido — la profundidad PROPIA de un check de relaciones:

| viewer vía N grupos anidados (+2 saltos includes) | 1 | 5 | 10 | 15 | 20 | 22 | 23 | 24 |
|---|---|---|---|---|---|---|---|---|
| resuelve (25 reps) | 25/25 | 25/25 | 25/25 | 25/25 | 25/25 | 25/25 | 25/25 | **25/25** |

Un check de relaciones resuelve MÁS profundo que `can_<P>` (>24 grupos anidados sin fallar en el rango
medido) porque su cadena es un TTU lineal (`member from member`), no una resta sobre unión de dos TTU. **La
profundidad NO es la restricción de `relations/` v1** (includes + un nivel de userset son 2-4 saltos fijos).

### 0.3 · UN CHECK / UN STORE — la promesa central sobrevive

El modelo fusionado se publicó (`201`, model id asignado) y en el MISMO store un `Check` de `document0#viewer`
para `user:alice` vía `group#member` respondió `{"allowed":true}` mientras el árbol `facts` seguía en el
mismo store. Cada pregunta sigue siendo **un** `Check`: `authorize` → `can_<P>`; `relations.check` →
`<relation>`. No se «fusionan» en tiempo de query; comparten store y modelo, no camino de resolución.

### 0.4 · La decisión que queda para el DUEÑO (no la tomo yo)

Compartir store por defecto es lo recomendado (un modelo, un `modelId`, un `reconcile`, «un Check» intacto).
El precio, medido: **el config de relaciones y el catálogo comparten UN ciclo de vida de modelo** — todo
`syncAuthzCatalog` Y todo `defineRelationsConfig` republican el modelo entero y re-pinean `modelId`, y el gate
de bytes es conjunto. El escape (store/modelo separado para `relations/`) solo se justifica si un consumidor
necesita **> ~20 tipos de objeto Y está cerca del techo de permisos** a la vez. **Pregunta al dueño:**
¿store compartido por defecto con el escape documentado, o `relations/` en store propio desde el día 1?
Recomendación: **compartido** (los números dicen que la colisión es un caso extremo, y separar duplica la
coordinación de backup, freeze y reconcile que 3b ya pagó una vez).

---

## 1 · El modelo de relaciones fusionado (c2r + relations) — LITERAL

Se AÑADE al modelo `facts` de hoy (no lo toca). Las líneas nuevas son solo los tipos `group` y los tipos de
objeto que declare el consumidor. DSL (probado byte a byte y publicado en `:8101`):

```
# ── tipos de FACTS (c2r), sin cambios: user/admin/integration, role, role_binding, scope ──
# ── AÑADIDO por relations/ ──
type group
  define member: [user, admin, integration, group#member]        # usersetsOf: 1 userset (grupos anidan)

type <objectType>                                                # p.ej. document, folder, space, key…
  define owner:  [user, admin, integration, group#member]
  define editor: [user, admin, integration, group#member] or owner    # includes (sin `from` en v1)
  define viewer: [user, admin, integration, group#member] or editor    # includes
```

JSON (la forma que `openFgaFactsModel` debe emitir como `type_definitions` extra; medida):
`group.member = { this }` con `directly_related_user_types: [user, admin, integration, group#member]`;
cada relación de objeto = `{ union: { child: [ {this}, {computedUserset:{relation:<incluida>}} ] } }` para las
que tienen `includes`, `{ this }` para la base, y `directly_related_user_types` con los holders + `group#member`.

**Partición**: NO va en el modelo. Va en el id del objeto y del userset
(`document:<partitionKey>|<uuid>`, `group:<partitionKey>|<uuid>#member`), y el cruce de particiones se corta
por **comparación de string en el driver** (sin `scopeOf`, boceto), reforzado en `database` por el trigger de
§3. `APP_SCOPE` (partición `app`) es válido para mono-tenant.

**Lo que v1 NO expresa** (diferido, boceto): `includes` con `from` (herencia cross-objeto tipo `viewer from
parent` de una carpeta) — eso metería un TTU entre tipos de objeto y habría que RE-MEDIR profundidad, porque
ya no serían 2-4 saltos fijos. Queda como 2.6+.

**Alternativa evaluada y descartada — store/modelo separado para `relations/`:** cabe (0 conflicto de techo),
pero cuesta un segundo `modelId`, un segundo store a coordinar en freeze/backup/reconcile, y **rompe «un
Check»** solo si alguna pregunta necesitara cruzar roles↔relations (no la necesita: son preguntas distintas).
No compensa salvo el caso extremo de §0.4. **Se deja como decisión del dueño, con los números.**

---

## 2 · El puerto `RelationsDriver` (ajustado a los dos drivers de hoy)

Interfaz nueva, **separada** de `AuthorizationDriver` (higiene: «todo en un driver o todo en otro» aplica —
un `RelationsDriver` es completo por sí mismo). `partition: ScopeRef` es obligatoria en TODA operación.

```ts
interface RelationsDriver {
  readonly capabilities?: RelationsDriverCapabilities
  relate(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef, opts?): Promise<void>
  unrelate(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef, opts?): Promise<void>
  check(subject: RelSubject, relation: string, object: RelObject, partition: ScopeRef): Promise<boolean>
  listObjects(subject: RelSubject, relation: string, objectType: string, partition: ScopeRef, page): Promise<{objects; cursor?}>
  listSubjects(relation: string, object: RelObject, partition: ScopeRef, page): Promise<{subjects; cursor?}>
  purgeObject(object: RelObject, partition: ScopeRef): Promise<void>   // demuestra cero o lanza
  purgeSubject(subject: RelSubject, partition: ScopeRef): Promise<void> // demuestra cero o lanza
}
```

Ajustes obligados por la realidad de hoy (verificados en `src/types.ts`):
- `RelSubject` puede ser un HOLDER (`{type,uuid}`, como `SubjectRef`) o un **userset** (`{object, relation}`,
  p.ej. `group:eng#member`) — el puerto lo tipa explícito; un userset de OTRA partición ⇒ 422 por string.
- `listObjects`/`listSubjects` van **paginados con cursor opaco que AVANZA y no filtra herencia**
  (misma regla que `list*` de roles, invariante 7 e higiene de reconcile): devuelven hechos DIRECTOS +
  lo que el modelo deriva por includes/userset, nunca «todo el subárbol». `listObjects` es el que en
  `openfga` obliga a `ListObjects` (trunca al tope del servidor): capacidad + señal de truncado, NO un
  silencio (lección S16/L0.7).
- `purgeObject`/`purgeSubject` **demuestran cero o lanzan 500** (`E_AUTHZ_PURGE_INCOMPLETE`), como
  `purgeScope`/`purgeRole` (invariante 11).
- Capacidades declaradas con caso (patrón 3b-2e·E2): `singleCheckRelations`, `listObjectsInherited:false`,
  `usersetSubjects`, `membersOfNative` (solo `database`), `enumerateRelations` (origen de reconcile).
- `assertWrite` puro en el manager es **obligatorio aquí** (boceto), opcional en `roles/`; `actor` en
  `onRelationWrite` (auditoría del consumidor sin `AsyncLocalStorage`, como `AuthzWriteEvent.actor`).
- **`❓ Pendiente de verificar`**: si `relate`/`unrelate` aceptan `{trx}` externa — el boceto lo pide para
  `database` pero `{trx}` sigue DIFERIDO (2.6+) en el puerto de `roles/`. Decisión: o `relations/` estrena
  `{trx}` (adelanta la Fase diferida) o se aplaza aquí también. **Pregunta al dueño** (§7 lo toca).

---

## 3 · Driver `database` — `authz_relations` + trigger de partición POR DIALECTO

`authz_relations` (columnas para lo que se busca/filtra, JSON para nada — todo se consulta):
`partition_key`, `object_type`, `object_id`, `relation`, `subject_type`, `subject_id`, `subject_relation`
(vacío = holder; no vacío = userset), `subject_partition`, `created_at`. Índices por
`(partition_key, object_type, object_id, relation)` y por `(partition_key, subject_*)`. Unicidad de la tupla.
`{trx}` externa igual que el resto de escrituras del driver.

**El check** = una CTE recursiva por dialecto (mismo patrón que `sqlDescendantsOf`, `src/sql_descendants.ts`):
resolver `member from member` (grupos anidados) e `includes` es un `WITH RECURSIVE` con el carácter de cita
por dialecto (`"` PG/SQLite, `` ` `` MySQL) o **throw `E_AUTHZ_UNSUPPORTED_DIALECT`** en la primera llamada.

**El trigger de partición — MEDIDO en los tres motores (crea el trigger, inserta legal, inserta cross-partición):**

| motor | forma del trigger (medida) | cross-partición | objeto directo |
|---|---|---|---|
| SQLite | `CREATE TRIGGER … BEFORE INSERT … FOR EACH ROW WHEN … BEGIN SELECT RAISE(ABORT,'…'); END` | ✅ RECHAZADO | ✅ aceptado |
| PostgreSQL | **`CREATE FUNCTION … RETURNS trigger … LANGUAGE plpgsql` (RAISE EXCEPTION) + `CREATE TRIGGER … EXECUTE FUNCTION`** | ✅ RECHAZADO | ✅ aceptado |
| MySQL | `CREATE TRIGGER … BEFORE INSERT … FOR EACH ROW BEGIN IF … THEN SIGNAL SQLSTATE '45000' …; END IF; END` | ✅ RECHAZADO | ✅ aceptado |

**Los tres defienden la partición, pero con DDL totalmente distinta** (confirma el aviso del encargo):
SQLite usa `RAISE(ABORT)` y no tiene funciones ni `SIGNAL`; PG **exige una función plpgsql SEPARADA** + el
`CREATE TRIGGER` que la invoca (dos sentencias); MySQL usa `SIGNAL SQLSTATE`. Gotchas medidos que van al plan:
1. El cuerpo compuesto (`BEGIN…END`) lleva `;` internos ⇒ **no puede pasar por un runner que trocea por `;`**;
   cada trigger es UNA sentencia raw por dialecto (`knex.raw` lo aceptó tal cual, sin `DELIMITER`).
2. Se probó `BEFORE INSERT`; una tupla de relación puede **UPDATE-arse** (renovar caducidad si se añade) ⇒
   el trigger necesita `BEFORE UPDATE` también, o `authz_relations` es insert/delete-only (recomendado:
   insert/delete-only, como los hechos de `roles/`, y así un solo trigger).
3. Cuarto dialecto ⇒ `relationPartitionTrigger` **throw** (nunca una tabla sin defensa), exactamente como
   `sqlDescendantsOf`. La app-level string-comparison del boceto es la defensa primaria; el trigger es
   defensa en profundidad — **ambas**, porque la primaria protege al driver `openfga` (que no tiene trigger)
   y el trigger protege a un escritor «a mano» de `authz_relations`.
4. La suite corre esto en PG/MySQL/SQLite (donde 2.5 sacó 8 defectos de motor): el caso de aceptación es
   «insert cross-partición ⇒ error del motor clasificado, no un `false` ni un insert silencioso».

---

## 4 · La API declarativa `defineRelationsConfig` — como casos del contrato

Cada feature se expresa PRIMERO como caso del contrato que el juez observa en AMBOS drivers (paridad). Lo que
no se pueda expresar como caso se marca aquí.

| # | Caso del contrato (observable en `database` Y `openfga`) | Núcleo |
|---|---|---|
| R-01 | `relate(u, viewer, doc, P)` ⇒ `check(u, viewer, doc, P) = true`; sin relate ⇒ `false` (denegación por defecto) | ✅ |
| R-02 | **`includes` sin `from`**: `relate(u, editor, doc, P)` ⇒ `check(u, viewer, doc, P) = true` (editor⊆viewer); el inverso NO | ✅ |
| R-03 | **`usersetsOf`**: `relate(group:g#member, viewer, doc, P)` + `member(u, g)` ⇒ `check(u, viewer, doc, P)=true` | ✅ |
| R-04 | Grupos anidados un nivel: `member(u,g1)` + `member(g1#member, g2)` ⇒ `check` vía `g2#member` = true | ✅ |
| R-05 | **Partición aísla**: userset/objeto de partición B en un `check` de partición A ⇒ 422 (string), nunca cruza | ✅ |
| R-06 | `unrelate` retira; re-`relate` idempotente (no duplica); re-`unrelate` no-op seguro (invariante 6) | ✅ |
| R-07 | `purgeObject(doc, P)` borra sus tuplas y demuestra cero, o 500; nada resucita | ✅ |
| R-08 | `purgeSubject(u, P)` idem para el sujeto | ✅ |
| R-09 | `listObjects`/`listSubjects` = hechos directos + derivados, paginados, cursor avanza, sin herencia abierta | ✅ |
| R-10 | `listObjects` en `openfga` que trunca al tope del servidor ⇒ señal de truncado, no lista parcial muda | ✅ |
| R-11 | Backend caído ⇒ 503 `AuthorizationBackendError`, jamás `false` (invariante 5) | ✅ |
| R-12 | Identidad/relación/objeto mal formados ⇒ 422 con `code` (gramática de identidad, cotas FGA 50/256) | ✅ |
| R-13 | `assertWrite` puro rechaza la escritura ⇒ nada toca el driver; `actor` viaja en `onRelationWrite` | anexo |
| R-14 | **`membersOf` solo `database`**: capacidad `membersOfNative`; en `openfga` la ruta que la pide ⇒ declarado, con caso | anexo |
| R-15 | Caducidad de una tupla de relación (si se soporta): expirada ⇒ `check=false` sin scheduler (SQL / condition FGA) | anexo |

**Lo que NO se puede expresar como un caso del contrato** (se marca, como pide el encargo):
- El **coste de bytes del modelo fusionado** (§0.1) no es un caso de comportamiento: es un gate
  (`assertFactsModelPublishable` sobre el modelo fusionado) con su caso de «rebasa ⇒ 500» + «al 80 % ⇒ avisa».
- La **profundidad** (§0.2) es un caso pero PROBABILÍSTICO en el borde: se clava con repeticiones (500
  resoluciones/lado, patrón 3b-4·C4), no con una tirada — un caso apoyado en 23 sería flaky en el artefacto.
- `membersOf` (R-14) es una asimetría DECLARADA entre drivers, no una paridad: se expresa como capacidad +
  caso negativo del lado que no la tiene, no como igualdad.

---

## 5 · La frontera roles↔relations — verificada, con un MATIZ

El boceto dice «regla de grafo en `check_purity` (ya preparada)». **Verificado en `scripts/check_purity.mjs`:**
la regla 2 (grafo de módulos) SÍ existe y `relations` YA está en `KNOWN_MODULES`, así que `src/relations/`
nace vigilado — pero esa regla solo impide que `src/relations/` importe `src/manager` o `src/drivers/*`
(aislamiento de BUNDLE). **NO** es la que impide «una tupla viewer hace `roles.authorize` true»: esa frontera
SEMÁNTICA la garantiza la CONSTRUCCIÓN (tablas/tipos de objeto separados: `authz_relations` ≠
`authz_assignments`; tipo `document`/`group` ≠ tipo `scope`/`role_binding`) + casos del contrato. **El boceto
sobrevende la regla de pureza**; hay que añadir la frontera como casos, no darla por hecha:

| # | Caso frontera (ambos drivers) |
|---|---|
| F-01 | `relate(u, viewer, doc, P)` ⇒ `roles.authorize(u, cualquier permiso, scope)` sigue `false` (una tupla de relación no concede en `roles/`) |
| F-02 | `roles.grant(u, rol)` + `authorize=true` ⇒ `relations.check(u, viewer, doc, P)` sigue `false` (un rol no crea relaciones) |
| F-03 | Higiene: `src/relations/` no importa `manager`/`drivers/*` (check_purity regla 2, fixture que lo detecta) |
| F-04 | Un permiso del catálogo y una relación de `relations/` con el MISMO nombre NO colisionan (espacios separados; en `openfga` viven en tipos de objeto distintos, no en las 4 familias de `factsRelationMap`) |

F-04 es real: `factsRelationMap` reserva el espacio plano `<P>/can_/denied_/permits_` en los tipos
`role`/`scope`; las relaciones de `relations/` viven en tipos `document`/`group`, así que no chocan — pero
hay que FIJARLO con un caso, porque el modelo es uno solo y un futuro refactor podría acercarlos.

---

## 6 · Plan por lotes (formato 3b-lote-2), con criterios de aceptación

Estimación: **6 lotes** (~10,5 d), camino crítico marcado. Cada lote cierra rojo→verde + typecheck +
`npm test` + `:8101` + tope 3 + tester (worktree, mutantes) + auditor (árbol principal, **nunca en paralelo**)
+ `/code-review`.

### 4-1 · El modelo fusionado y el generador (CAMINO CRÍTICO — desbloquea todo)
Pieza pura, sin `check` todavía. `openFgaFactsModel` emite además los `type_definitions` de `group` + los
tipos de `defineRelationsConfig`; `assertFactsModelPublishable` mide el modelo **fusionado**.
- **AC:** modelo fusionado = literal de §1 para `group`+1 tipo; **se publica en `:8101`** (201);
  gate de bytes con el bloque de relaciones incluido (rebasa ⇒ 500 nombrando bytes; 80 % ⇒ avisa);
  colisión de nombres entre relación de objeto y familia de permiso ⇒ detectada (F-04); depth `can_<P>`
  intacta (22, medida sobre el fusionado con 500 reps). **0 tuplas, `authorize` de `roles/` sin tocar.**

### 4-2 · El puerto `RelationsDriver` + `defineRelationsConfig` + manager
Interfaz, tipos (`RelSubject` holder|userset), `assertWrite`, `actor`/`onRelationWrite`, capacidades con caso.
- **AC:** un driver falso satisface el puerto; `defineRelationsConfig` valida (includes sin `from`,
  `usersetsOf` un nivel, `membersOf` solo en opciones de `database`); casos R-13, capacidades declaradas.

### 4-3 · Driver `database` (`authz_relations` + CTE + trigger por dialecto)
Migración/stub de `authz_relations`, `relate/unrelate/check/list*/purge*`, CTE recursiva por dialecto,
`relationPartitionTrigger` (SQLite/PG/MySQL o throw), `{trx}` externa (❓ §2, según decisión del dueño).
- **AC:** R-01…R-12 verdes en **SQLite + PG + MySQL**; trigger cross-partición ⇒ error de motor clasificado
  (medido: los tres rechazan); dialecto ajeno ⇒ throw; `purge*` demuestra cero o 500.

### 4-4 · Driver `openfga` (fusión con `facts`)
`relate/unrelate` = `Write`/delete de tuplas del store (mismo store, mismo `modelId`); `check` = 1 `Check`;
`list*` = `Read`/`ListObjects` paginado con señal de truncado; `purge*` = exhaustiva que lanza si no demuestra
cero; partición por string en el id (userset de otra partición ⇒ throw).
- **AC:** R-01…R-12 verdes contra `:8101`; **paridad con `database`** (la misma pregunta ⇒ la misma
  respuesta en los dos); R-10 (truncado) con el servidor de tope 3; `check` = 1 `Check` (espía).

### 4-5 · Frontera roles↔relations + `reconcile` de relaciones
Casos F-01…F-04; `enumerateRelations` (origen) + destino en `reconcile` para las tuplas de relación;
`reconcile --dry-run` vigila la proyección del modelo fusionado.
- **AC:** F-01…F-04 verdes en ambos drivers; `authz:reconcile --to=…` migra relaciones idempotente y
  bidireccional, nunca silenciosa; `--dry-run` reporta deriva del modelo fusionado.

### 4-6 · Casos anexo, negativos, README/CHANGELOG y cierre
R-14 (`membersOf`), R-15 (caducidad si aplica), tablas ficticias del consumidor para los dos casos de diseño
(§7), README honesto del presupuesto compartido (§0.1/§0.4) y de la partición; CHANGELOG 2.4.
- **AC:** ~34 casos (18 núcleo / 12 anexo / 4 negativos) del boceto cubiertos; juez `'2.4'`; suite entera
  verde en los 5 modos; auditor + tester + `/code-review` cerrados.

**Decisiones pendientes antes de arrancar** (no las tomo yo): (a) store compartido vs separado (§0.4);
(b) `{trx}` en `relations/` ahora o diferido (§2); (c) `authz_relations` insert/delete-only vs con UPDATE (§3.2).

---

## 7 · COGNITIV como insumo de diseño (NO como puerta)

La pregunta abierta —¿su «llave a un espacio» es acceso a un SCOPE o ReBAC de OBJETOS?— **no decide si se
construye** (decisión del dueño del 31 (4)); es insumo. El plan sirve para los DOS casos que nombra el roadmap,
y por eso se diseña para ambos sin esperar respuesta:

- **«Llave COGNITIV» como acceso a un espacio = un SCOPE**: eso ya lo resuelve `roles/` (un grant en el scope
  del espacio, heredado hacia abajo). `relations/` NO es necesario para este caso — y el plan lo dice para no
  construir de más. Si COGNITIV es esto, `relations/` se justifica por el segundo caso, no por el primero.
- **«Compartir documento estilo Drive» = ReBAC de OBJETOS**: `document` + `viewer/editor/owner` (includes) +
  `group#member` (usersetsOf) + partición por tenant — exactamente el modelo medido en §0/§1. Este es el caso
  que da sentido a `relations/`, y el que se construye.

Diseñado para los dos: si la «llave» resulta ser una relación sobre un objeto `space`/`key` (no un scope),
encaja como un tipo de objeto más (+271 B, medido); si es un scope, no toca `relations/`. **La respuesta de
COGNITIV afina las tablas ficticias del consumidor del lote 4-6, no cambia el plan.**

---

## Apéndice · Qué está medido vs qué queda por verificar

- ✅ Medido contra `:8101`: tamaño del modelo fusionado, publicación (201), profundidad `can_<P>` (22) y de
  relaciones (>24 grupos), single-store single-Check.
- ✅ Medido en pg18/mysql84/SQLite: viabilidad y DIVERGENCIA de la DDL del trigger de partición, rechazo
  cross-partición, aceptación de objeto directo.
- ✅ Verificado en código: `check_purity` regla 2 con `relations` en `KNOWN_MODULES` (frontera de bundle, no
  semántica); el puerto actual (`src/types.ts`) sin `relate/unrelate`; el patrón de dialecto de
  `sql_descendants.ts`; `factsModelBytes`/`assertFactsModelPublishable` miden hoy solo el modelo de `facts`.
- ❓ Por verificar en su lote: si `relations/` estrena `{trx}` (hoy diferido 2.6+); UPDATE sobre
  `authz_relations` (medí solo INSERT); el coste real de `ListObjects` truncado en `openfga` (R-10) con el
  tope 3; el número exacto de casos del juez `'2.4'` (el boceto estima 34).
