# Fase 3b · Lote 8 — las correcciones del `/code-review` de fin de fase

Rama `v2/fase-3b`, sobre HEAD `49f3010` (árbol del dueño; sin commits, como siempre).
Hallazgos de `.claude/contexto/fase-3b-code-review-hallazgos.md`: **los 10 confirmados quedan
CERRADOS, y el intermitente E5 aislado de la contención** — cada uno con su caso rojo→verde en la
suite (los rojos se capturaron con el código de HEAD restaurado, o con un mutante equivalente
declarado; salida literal abajo).

Método de captura de los rojos: con los casos nuevos YA escritos, se restauró el código de HEAD
(`git show HEAD:<fichero>` sobre los 7 ficheros tocados, más el mutante A1 —el helper extraído con
el comportamiento viejo— para que el spec importara), se corrió cada spec, y se volvió a poner el
fix. Verde antes y después en cada spec afectado.

---

## Grupo A · Fail-open

### A1 · `authz:catalog:sync` no pasaba `catalogProjection()` — el camino de recuperación documentado no existía

**Caso** (`tests/openfga_facts.spec.ts`, grupo «facts · 3b-8 — code-review de fin de fase», contra
el `:8101`): el MISMO camino del comando (`catalogSyncOptions(driverActivo)` + `syncCatalogs`)
sincroniza un catálogo v1, un grant concede `docs:write`; el catálogo v2 quita `docs:write` del rol
y re-sincroniza por el CLI ⇒ tiene que dejar de conceder. Más la decisión PURA (patrón
`reconcileLines`): con un driver que declara `catalogProjection` las opciones la llevan; con
`database`, no; `--keep-links` ⇒ `prune: 'none'`.

**Rojo ANTES** (helper extraído con el comportamiento de HEAD, sin proyección):

```
❯ facts · 3b-8 — … / A1: el camino del CLI (`catalogSyncOptions` + `syncCatalogs`) proyecta el catálogo…
ℹ AssertionError: el sync del CLI tiene que llevar la proyección del driver activo (3b-8 · A1):
  expected undefined to not equal undefined
```

**Fix**: `catalogProjection?(): CatalogProjection` entra en el PUERTO (`src/types.ts`, opcional,
como `projectCatalogRole` — el comando solo ve `AuthorizationDriver`); el comando
(`commands/authz_catalog_sync.ts`) resuelve el manager (`services/main.js`, como
`authz_reconcile`), y `catalogSyncOptions(driver, keepLinks)` —exportada y pura— añade
`projection: driver.catalogProjection()` cuando el driver la declara. `database` no la declara y el
sync va sin ella, como siempre.

### A2 · `enumerateFacts` tiraba en silencio los denies del modo `resolver` de 2.2

**Caso** (`tests/reconcile.spec.ts`, grupo «3b-3b · reconcile --to=database (servidor real)»): un
store con el modelo VIEJO (tipos `role_binding`/`deny_binding`) y sus dos tuplas —la asignación de
ana y el deny de bea (`deny_binding:<orgKey>|<permissionUuid>#denied`)—, el modelo (c2r) publicado
encima, y `reconcile --to=database`: el deny tiene que LLEGAR a `authz_denies`
(`listDenies(bea, org) = [{docs:write}]`, el camino del censo del contrato de migración), la
asignación también, `written = 2`. Y un deny viejo de un permiso que el catálogo ya no declara sale
contado (`skipped['unknown-permission']`), jamás mudo.

**Rojo ANTES**:

```
❯ 3b-3b · reconcile --to=database (servidor real) / 3b-8 · A2: un deny del formato 2.2 …
ℹ AssertionError: el deny explícito de 2.2 tiene que MIGRAR: perderlo con el verificador en verde
  es el fail-open del hallazgo A2: expected [] to deeply equal [ { permission: 'docs:write', …(1) } ]
```

**Fix** (`src/drivers/openfga_driver.ts`, `enumerateFacts`): la rama
`relation === 'denied' && object.startsWith('deny_binding:')` **emite un deny** — `parseBindingId`
desde la derecha (el mismo parser), el uuid del permiso traducido a slug por
`catalog.permissionSlug`; lo que no parsea/traduce/mapea sale en `skipped`
(`unparseable-binding`/`unknown-permission`/`unknown-holder-type`). Elegí MIGRARLOS (no solo
contarlos): un deny de más es fail-closed, `reconcile` es el sustituto documentado del importador
borrado, y el propio `--prune` se lleva después la tupla vieja (familia `facts`). Constantes
`LEGACY_DENY_BINDING_TYPE`/`LEGACY_DENIED_RELATION` con su porqué.

### A3 · el `moved` REINTENTADO se saltaba el barrido del invariante 18

**Caso** (`tests/openfga_facts.spec.ts`, dentro del grupo E1 del barrido, con su harness de
PARIDAD `pair()`): rol local `lead` de orgA, grant en la unit; el «primer intento» escribe la
arista en el store a pelo y muere antes del barrido (lo que deja un relay que muere entre `Write` y
barrido); el REINTENTO (`onScopeMoved`) cae en el atajo idempotente ⇒ tiene que barrer igual:
`fga.authorize === sql.authorize === false` fuera del owner, y la vuelta (también por el camino del
reintento) restaura.

**Rojo ANTES**:

```
❯ facts · 3b-2e · E1 — … / un `moved` cuyo primer intento escribió la arista y murió ANTES del barrido…
ℹ AssertionError: facts: el reintento del `moved` tiene que barrer igual — si concede, el rol de la
  org A vive en el subárbol de la B (3b-8 · A3): expected true to be false
```

**Fix** (`reparent`): el atajo idempotente (`current == wanted`) llama a
`sweepLocalRoleBindings(childKey)` antes de volver. Coste: cero requests sin roles locales (el
propio corte del barrido).

### A5 · el anti-ciclos miraba la cadena del CONSUMIDOR, no la del STORE

**Caso** (grupo 3b-8, contra el `:8101`): árbol del consumidor de HOY `app→org→unit`; árbol del
STORE desincronizado por una outbox en desorden (`org#parent@unit`, de un `moved` viejo). El relevo
de `unit → org` es legal para el consumidor y cierra `unit→org→unit` en el store — FGA lo acepta y
la herencia se vuelve bidireccional (cruce 3, fail-open mudo; `storeChain` del barrido solo lanzaba
DESPUÉS de escribir, y con cero roles locales ni eso). Tiene que ser 422 `E_AUTHZ_SCOPE_CYCLE`
**sin escribir**: la unit se queda con su padre de antes.

**Rojo ANTES**:

```
❯ … / A5: una arista legal para el consumidor que cerraría un ciclo EN EL STORE es 422 E_AUTHZ_SCOPE_CYCLE…
ℹ AssertionError: la arista que cierra un ciclo en el STORE (3b-8 · A5): debería haber lanzado:
  expected null to not equal null
```

**Fix** (`reparent`, pensado JUNTO con A3 — es la zona de composición que ha mordido al proyecto):
antes del `Write` (y solo si hay algo que escribir: el atajo idempotente de A3 no lo paga) se sube
por `storeChain(parentKey)`; si la cadena del padre EN EL STORE contiene al hijo ⇒ 422 con la
receta (`authz:reconcile`). El orden de las dos piezas: atajo idempotente (con barrido, A3) →
anti-ciclo del store (A5) → `Write` → barrido. Coste declarado: O(profundidad) lecturas por cambio
de árbol, fuera del camino caliente; el caso «`moved` es un Read y UN Write» pasa a afirmar «el
Read del padre actual + la cadena del padre nuevo + UNA mutación» (aserción actualizada, no
borrada), y el docblock y `CLAUDE.md` lo dicen.

### A4 · `revoke`/`removeDeny` por un alias sin cadena eran un no-op silencioso

**Caso** (grupo 3b-8, PARIDAD con `database` — el patrón `canonicalOrSelf` + una sola ortografía
era el mismo en los dos drivers, así que se cerró en los dos): grant + deny en org (uuid canónico
con guiones) por ambos drivers; la fila del árbol se borra (el orden soportado de 3F · S1);
`revoke`/`removeDeny` llegan con el ALIAS sin guiones; el scope se restaura con el mismo uuid (AA4:
los hechos despiertan) ⇒ lo revocado sigue revocado y el deny quitado sigue quitado, en los DOS.

**Rojo ANTES** (rojo en los dos drivers; el primero en fallar):

```
❯ … / A4: revocar (y quitar un deny) por el ALIAS sin guiones de un scope ya borrado…
ℹ AssertionError: database: el revoke por alias tiene que haber borrado la fila canónica (si
  concede, fue un no-op silencioso): expected true to be false
```

**Fix**: `canonicalScopeTargets(resolver, scope, op)` en `backend_guard.ts` —con cadena, `[chain[0]]`
(exactamente uno, como siempre); sin cadena, **el fan-out `scopeSpellings` de `identity.ts`
reutilizado**, no otro—; `openfga.revoke` borra los `assignee` de todas las ortografías en un
`deleteTuples`, `openfga.removeDeny` un `denyTuple` por ortografía, y `database` pasa la lista a
`whereScopeIn(..., targets, 'write')`. Nota: el hallazgo nombraba solo `openfga`, pero el espejo en
`database` tenía el mismo agujero (fila escrita canónica + `WHERE scope_uuid = alias` = 0 filas) y
la nota de divergencia publicada dice «la ESCRITURA sí canoniza en los dos drivers»: cerrarlo solo
en uno la dejaba falsa. `purgeScope` no lo necesita: el fan-out de `detached` vive en el manager.

## Grupo B · Pérdida de datos / disponibilidad

### B1 · el seguro de borrado masivo miraba el conteo CRUDO — y su espejo

**Casos** (uno por dirección, `tests/reconcile.spec.ts`, servidor real): tras una migración normal,
el árbol deja de resolver los scopes de TODOS los hechos del origen (`tree.detach(org)` — la firma
de un resolutor ciego o de la base equivocada): el origen sigue devolviendo filas (conteo crudo
> 0) y las N se descartan (`unknown-scope`). `--prune` tiene que ser 500
`E_AUTHZ_MASS_RECONCILE_REFUSED` sin borrar nada; `--dry-run` lo marca (`massDelete: true`) y dice
el porqué (`skipped`).

**Rojo ANTES** (las dos direcciones):

```
❯ 3b-3a · reconcile --to=openfga (servidor real) / 3b-8 · B1: --prune con un origen cuyos hechos se DESCARTAN todos…
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_MASS_RECONCILE_REFUSED'
❯ 3b-3b · reconcile --to=database (servidor real) / 3b-8 · B1: --prune con un STORE cuyos hechos se descartan todos…
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_MASS_RECONCILE_REFUSED'
```

**Fix**, en las dos (el primo del 🔴 del lote 5, un escalón abajo): el seguro cuenta hechos
**UTILIZABLES**. En `database.reconcile`, `usableFacts` se incrementa solo cuando la fila pasa
todas las puertas (caducidad, scope, rol/permiso) y llega a `wanted*`; en `openfga.reconcile`,
`wantAssignment`/`wantDeny` devuelven ahora `boolean` («¿aportó algo?») y
`readSourceFacts`/`readOriginFacts` devuelven `{ rows, usable }`; el seguro mira `usable === 0` y
el mensaje dice cuántos se leyeron y descartaron («mira 'skipped'»). README (tabla de errores y
párrafo del guard) actualizado: ya no dice «solo cubre el origen VACÍO».

### B2 · `clean` era inalcanzable con datos reales por las caducadas — decisión justificada

**Caso** (puro, `reconcileLines`): `skipped: { expired: 3 }` ⇒ `clean: true` Y la línea «3 sin
migrar por 'expired'» sigue saliendo; `{ expired: 1, 'unknown-role': 1 }` ⇒ `false`;
`{ 'extra-fact': 1 }` ⇒ `false`.

**Rojo ANTES**:

```
❯ 3b-3a · authz:reconcile (las decisiones del comando) / 3b-8 · B2: `expired` se REPORTA pero no tumba…
ℹ AssertionError: la pérdida DECLARADA no puede dejar el verificador en rojo para siempre (3b-8 · B2):
  expected false to be true
```

**La elección, justificada** (las dos lecturas eran «eximir `expired` de `clean`» o «que algo barra
las caducadas»; elegí la PRIMERA, en `reconcileLines`):

1. `expired` es la ÚNICA pérdida DECLARADA de la migración (README, contrato de migración — que
   además EXIGE que ocurra y se cuente): una pérdida declarada no puede ser deriva permanente, o el
   gate de CI que el CHANGELOG promete verde no existe.
2. Una asignación caducada no concede en NINGÚN driver (invariante 3): no hay divergencia que
   vigilar ahí, y ninguna escritura del DESTINO puede «arreglar» una fila caducada del ORIGEN — el
   verificador estaría en rojo por algo que la pasada no puede tocar por contrato.
3. Barrer las filas caducadas era la otra lectura y la descarté: sería una escritura NUEVA sobre el
   origen (que `reconcile` no toca jamás), rozaría el invariante 3 («expiración observable sin
   scheduler» es una decisión de diseño, no un descuido) y cambiaría la semántica del revive del
   invariante 10. **Para el operador**: nada que operar en el origen; las caducadas que SOBRAN en
   el DESTINO siguen siendo deriva (`extra-fact`) y su barrido ya existe y es explícito: `--prune`.
   Esto va escrito en el README (párrafo del verificador) y en el docblock de `reconcileLines`.

Si el dueño prefiere la otra lectura (un barrido explícito de caducadas), el punto de decisión es
`reconcileLines` + este párrafo: el resto del lote no depende de ello.

### B3 · el freeze se miraba UNA vez y la pasada seguía 10.000 escrituras

**Casos** (`tests/freeze.spec.ts`, grupo nuevo «3b-8 · B3», dos managers sobre el mismo backend):
(1) relay con `batchSize: 1` y dos cambios encolados; la PRIMERA aplicación dispara el freeze de
otro worker ⇒ el siguiente lote corta con 503 `E_AUTHZ_FROZEN` reintentable, lo aplicado queda
marcado (reanudable), lo demás pendiente, y tras `unfreeze` la siguiente pasada drena. (2)
`pruneOrphanRoles({force})` con dos huérfanos; la primera purga dispara el freeze ⇒ la segunda NO
se ejecuta y el 503 viaja como `cause` de `E_AUTHZ_PRUNE_INTERRUPTED` con `purged` (la lista de lo
ya borrado).

**Rojo ANTES**:

```
❯ 3b-8 · B3 — … / relay: un freeze adquirido a MITAD del drenaje corta la pasada en el siguiente lote…
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'
❯ 3b-8 · B3 — … / prune-orphans --force: un freeze adquirido a MITAD corta ANTES de la siguiente purga…
ℹ AssertionError: la segunda purga tras el freeze tenía que cortarse (3b-8 · B3): expected null to not equal null
```

**Fix** (`src/manager.ts`): `#assertNotFrozen` re-afirmado **por lote** al tope del bucle `outer`
del relay (una lectura de la fila `id=2` por lote; el 0,14 ms/escritura ya medido y aceptado), y
**por rol** dentro del `try` de la purga de `pruneOrphanRoles` (ahí envuelto en
`PruneInterruptedError` para que viaje la lista). Un freeze a mitad corta con el 503 reintentable
de siempre; lo aplicado está marcado en la outbox y la pasada es reanudable.

## Grupo C · Arranque / operabilidad

### C1 · el stub firmaba la mitigación donde el manager NO la lee

**Caso** (`tests/configure.spec.ts`): el objeto `scopes: { … }` del stub (SIN llaves anidadas: la
firma dentro de la factory del driver no cuenta — mi primera regex se tragaba el bloque `drivers` y
el caso pasaba en falso; endurecida a `/scopes:\s*\{[^{}]*\}/` antes de capturar el rojo) tiene que
llevar `acceptScopeDriftRisk: true` o `outbox:`. Y el MECANISMO demostrado con dos managers: la
forma del stub pasa el gate; sin la firma, `driver()` es 500 `E_AUTHZ_SCOPE_DRIFT_UNGUARDED`.

**Rojo ANTES**:

```
❯ configure — stubs publicados / 3b-8 · C1: la sección `scopes` del stub lleva una mitigación del gate del MANAGER…
ℹ AssertionError: el gate del manager lee config.scopes, no las opciones del driver: la firma tiene
  que estar AQUÍ (3b-8 · C1): expected 'scopes: { resolveChain: resolveScopeC…' to match /acceptScopeDriftRisk:\s*true|outbox:/
```

**Fix** (`stubs/config/authorization.stub`): `scopes` lleva `acceptScopeDriftRisk: true` con el
comentario espejo del de la factory (por qué el manager lo lee AQUÍ, la receta del outbox con la
MISMA instancia en los dos sitios, y que con `AUTHZ_DRIVER=database` no aplica). La regex del caso
viejo del seam se hizo tolerante a las dos formas (`[,}]`).

### C2 · `purgeScope` contaba como residuo lo que no sabía borrar

**Caso** (grupo 3b-8, contra el `:8101`): grant + deny en org, más una arista
`scope#binding@role_binding:<key>|<uuid fantasma>` de un rol que `authz_roles` no declara (la fila
borrada/cambiada de nivel entre el commit y el barrido no atómico). `purgeScope(org)` tiene que
demostrar cero de verdad (sin denies y sin aristas de binding — tampoco las de roles retirados;
la arista `parent` queda, que es de `detached` por S6) y ser idempotente.

**Rojo ANTES** (y era PARA SIEMPRE — se reintentaba y volvía a fallar):

```
❯ … / C2: una arista `scope#binding` de un rol que el catálogo ya no declara no bloquea la purga…
ℹ PurgeIncompleteError: purgeScope organization|01a05a68-…: quedan tuplas tras el borrado —
  scope:organization|01a05a68-… (1). No confirmes el borrado del scope; reintenta la purga.
```

**Fix** (`purgeScope`, paso nuevo entre hechos y denies): se borran del objeto `scope:<key>` las
aristas `#binding` cuyo `role_binding` NO es de un rol del catálogo de ese nivel (`known`). Borrar
esa arista nunca concede (es visibilidad, y su rol ya no existe en el nivel — de hecho la QUITA a
un rol que cambió de nivel y seguiría concediendo por ella: fail-closed); la arista de un rol DEL
catálogo que un grant concurrente reescribió sigue protegida y sigue saliendo como residuo, que es
la señal de reintento correcta. El orden «denies los últimos» no cambia.

## E5 · el borde de profundidad 22 bajo contención — qué medí y cómo quedó

**Qué medí** (sonda `probe_e5.ts` del scratchpad, contra el `:8101` real, modelo (c2r) del
generador del paquete, cadena de N saltos + 50 hojas, `batchCheck` de 50):

- **En frío**: profundidad 22 ⇒ 200/200 resuelven; 23 ⇒ 1 fallo en 300, y el fallo es UN error con
  nombre: `{"input_error":"authorization_model_resolution_too_complex","message":"resolution depth
  exceeded"}`; 24 ⇒ 100/100 ese mismo error. **El veredicto de profundidad es determinista y
  distinguible.**
- **Bajo carga** (bucles de `batchCheck` en paralelo): con saturación total (24 bucles) TODO falla
  a CUALQUIER profundidad con OTRO error — `{"internal_error":"deadline_exceeded","message":
  "context deadline exceeded"}` — e incluso los `write` del montaje mueren
  (`Request Deadline Exceeded`, medido: el grupo E5 entero en rojo por el setup, no por la cota).
  Con carga media (6-8 bucles) no falla nada. La banda intermitente es finísima: es exactamente lo
  que hacía al caso esporádico.

**El diagnóstico**: el caso contaba CUALQUIER 503 como evidencia contra la cota
(`unresolved += 1`), así que un `deadline_exceeded` de contención de un vecino del `:8101`
compartido lo ponía en rojo con el mensaje FALSO «la cota publicada está por encima de la real».

**Cómo quedó** (sin `skip`, sin tocar el 22): la evidencia sobre la cota es SOLO el veredicto del
servidor (`depthVerdict`: `authorization_model_resolution_too_complex` / «resolution depth
exceeded», mirado por la cadena de `cause` — cubre el batch y el Check único por `apiErrorCode`);
la contención se reintenta ACOTADA (`despiteContention`: 4 intentos con espera creciente, y el
veredicto de profundidad NO se reintenta jamás); si la saturación persiste, el caso **falla
igual**, nombrando la saturación en vez de la cota. Las dos direcciones del caso conservan sus
dientes: con la constante a 23, el lado (a) recibe el veredicto determinista y sigue rojo; con la
constante a 21, el lado (b) sigue rojo (solo el veredicto cuenta, y a 22 no aparece nunca — 500/500
medidas). La distinción quedó FIJADA con un caso determinista dentro del grupo, con las dos formas
LITERALES medidas contra el servidor; su rojo, por mutante (`depthVerdict ⇒ true`, el caso viejo):

```
❯ facts · 3b-2e · E5 — … / 3b-8 · E5: el veredicto de PROFUNDIDAD se distingue de la CONTENCIÓN…
ℹ AssertionError: la contención del servidor compartido NO es evidencia sobre la cota (3b-8 · E5):
  contarla dejaba el caso intermitente: expected true to be false
```

**Estabilidad verificada**: el grupo E5 en verde 3 corridas de 3 en frío, y en verde con carga
media real encima (880 lotes de 50 checks concurrentes durante la corrida). Bajo saturación TOTAL
del servidor compartido el grupo sigue pudiendo fallar por el SETUP (los `write` vencen su
deadline) — eso no lo puede absorber ningún caso y ahora el fallo nombra la saturación, no la cota.

---

## Cambios de código (resumen por fichero)

| Fichero | Qué |
|---|---|
| `src/types.ts` | `catalogProjection?()` en el puerto (A1) |
| `commands/authz_catalog_sync.ts` | `catalogSyncOptions` pura + el comando la usa con el driver activo (A1) |
| `src/drivers/openfga_driver.ts` | A2 (legacy denies en `enumerateFacts`), A3+A5 (`reparent`), A4 (`revoke`/`removeDeny` con `canonicalTargets`), B1 espejo (`usable` en `readSourceFacts`/`readOriginFacts`/`wantAssignment`/`wantDeny` + seguro), C2 (`purgeScope`) |
| `src/drivers/database_driver.ts` | A4 espejo, B1 (`usableFacts` + seguro) |
| `src/drivers/backend_guard.ts` | `canonicalScopeTargets` (A4, reusa `scopeSpellings`) |
| `src/manager.ts` | B3 (barrera por lote en el relay, por rol en prune-orphans) |
| `commands/authz_reconcile.ts` | B2 (`expired` fuera de `clean`, docblock) |
| `stubs/config/authorization.stub` | C1 (firma en `scopes`) |
| `tests/openfga_facts.spec.ts` | grupo 3b-8 (A1/A4/A5/C2), A3 en el grupo E1, E5 (`depthVerdict`/`despiteContention` + caso de la distinción), caso del coste de `moved` actualizado (2 reads) |
| `tests/reconcile.spec.ts` | A2, B1×2, B2 |
| `tests/freeze.spec.ts` | grupo B3 (relay + prune) |
| `tests/configure.spec.ts` | C1 (+ seam tolerante) |
| `CLAUDE.md`, `README.md`, `CHANGELOG.md` | coherencia: coste de `moved`, seguro por hechos utilizables, `expired` no es deriva, fan-out de `revoke`/`removeDeny`, denies legacy, lote 3b-8 en el CHANGELOG |

## Verificación

(las cifras se rellenan abajo, todas las corridas a fichero en el scratchpad de la sesión)


### Estado EXPLÍCITO de los 10 hallazgos + E5

| # | Estado | Caso (rojo→verde) |
|---|--------|-------------------|
| A1 | **VERDE** | `openfga_facts.spec` grupo 3b-8 |
| A2 | **VERDE** | `reconcile.spec` grupo `--to=database (servidor real)` |
| A3 | **VERDE** | `openfga_facts.spec` grupo E1 (barrido) |
| A4 | **VERDE** (los DOS drivers) | `openfga_facts.spec` grupo 3b-8 (paridad database/facts) |
| A5 | **VERDE** | `openfga_facts.spec` grupo 3b-8 |
| B1 | **VERDE** (las DOS direcciones) | `reconcile.spec` grupos `--to=openfga` y `--to=database` (servidor real) |
| B2 | **VERDE** | `reconcile.spec` grupo `las decisiones del comando` (puro) |
| B3 | **VERDE** (relay + prune-orphans) | `freeze.spec` grupo 3b-8 · B3 |
| C1 | **VERDE** | `configure.spec` |
| C2 | **VERDE** | `openfga_facts.spec` grupo 3b-8 (servidor real) |
| E5 | **AISLADO** (sin skip, 22 intacto) | `openfga_facts.spec` grupo E5 (caso determinista de la distinción + reintento acotado de contención) |

**Los 10 confirmados quedan VERDES y E5 aislado.** Ninguno quedó a medias, ninguno con `skip`.

### A4 — barrido del patrón COMPLETO, no de uno en uno

Auditados **los 8 sitios de `onMissingDeletes: Ignore`** del `openfga_driver.ts` (más los `.delete()`
equivalentes de `database_driver.ts`), no solo `revoke`/`removeDeny`. El bug de A4 (una ortografía
del LLAMANTE que va a un delete + `Ignore` = no-op silencioso cuando llega un alias) solo es posible
donde el scope del delete viene del llamante SIN reconciliarse con una lectura del store. Resultado:

- `revoke` (1163) y `removeDeny` (1212) — **el bug; CERRADOS** con `canonicalScopeTargets`.
- `grant`→`replaceAssignment` (1114) — **a salvo**: el scope pasa por `knownScope` (422 si no
  existe), así que la key es canónica; el delete borra exactamente la key que va a reescribir.
- `applyBindingSweep` (1890), `purgeScope` (1973), `purgeRole` (2226), `applyReconcileWrites`
  (3290) — **a salvo**: cada uno borra tuplas que acaba de LEER del store (ya canónicas), no una
  ortografía del llamante.
- `database.purgeScope` (canonicalOrSelf, una sola ortografía) — **a salvo**: el fan-out del caso
  sin cadena vive AGUAS ARRIBA, en `manager.scopes.detached` (`scopeSpellings`, 3b-2h · 🟠 3), que
  llama a `purgeScope`/`onScopeDetached` una vez por ortografía. Meterlo también en `purgeScope`
  sería duplicar la barrera.

Conclusión: el patrón queda barrido entero. Las dos puertas que faltaban eran `revoke`/`removeDeny`
(y su espejo en `database`); el resto no comparte el defecto por razones distintas y verificadas.

### Cifras de la verificación (todas a fichero en el scratchpad de la sesión)

- `npx tsc --noEmit -p tsconfig.json` · `npm run typecheck` · `npm run check:purity` · `npm run build` → **OK**.
- **sqlite + openfga** (`npm test`): **796 passed** (parte de 783; +13 casos nuevos). Log `suite-sqlite.log`.
- **sqlite-file + openfga** (`test:sqlite-file`): **801 passed** (parte de 788). Log `suite-sqlite-file.log`.
- **pg + openfga** (`test:pg`): **895 passed** (parte de 882; +13). Log `suite-pg.log`.
- **mysql + openfga** (`test:mysql`): **895 passed** (parte de 882; +13). Log `suite-mysql.log`.

### Lo que NO se cerró

Nada de los 10 + E5 quedó abierto. Único punto declarado para el dueño: **B2** tiene dos lecturas
posibles (eximir `expired` de `clean` — lo IMPLEMENTADO — vs. barrer las filas caducadas del
origen). Elegí la primera y la justifiqué arriba; si el dueño prefiere la otra, el único punto de
cambio es `reconcileLines` y el resto del lote no depende de ello.

### Tope 3 (intermitencia)

Tres corridas del suite completo sqlite + `:8101`, a fichero desde la primera pasada
(`tope3-1.log`/`tope3-2.log`/`tope3-3.log`): **796 / 796 / 796, exit 0 las tres** — sin
intermitencia. El E5, que era el que arrastraba el flaky, entra en las tres y pasa en las tres.

### Stores del `:8101`

La sonda de E5 y los grupos contra el servidor crean stores efímeros; los de la sonda se borran al
final de cada corrida (`teardown`) y el harness de la suite arma su propio barrido
(`armOpenFgaStoreGuard`/`sweep`). Se verificó y se limpiaron a mano los stores que dejó la sonda
manual: **0 stores restantes** en el `:8101` tras la medición de E5.
