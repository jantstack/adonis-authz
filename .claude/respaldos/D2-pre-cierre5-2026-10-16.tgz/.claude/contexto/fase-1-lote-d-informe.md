# Fase 1 · Lote 1D — informe de implementación (2026-08-28)

Rama `v2/fase-0` sobre `188d625` (**sin commits**: el commit lo hace el dueño). Node 22.23.2, OpenFGA
`:8101` (v1.19.0) y servidor efímero tope 3 (`openfga-tiny`, `:8103`, `OPENFGA_LIST_OBJECTS_MAX_RESULTS=3`
+ `OPENFGA_LIST_USERS_MAX_RESULTS=3`, memoria; **eliminado al terminar**). Sin `skip`/`only` (grep = 0).
Parche del tester aplicado con `git apply` limpio como primer paso. Orden: E1 (parche) → D1…D16 → E1–E5.
`package.json` ⇒ `2.0.0-alpha.1`. CHANGELOG: sección `### Closing corrections — phase 1, lot D` bajo
`[Unreleased] — 2.0.0` (una entrada por pieza, problema → decisión → qué NO se hace, más la receta de
migración de slugs de 1.1.0). README y `CLAUDE.md` actualizados (E5).

## Conteo de tests por configuración

| Momento | `npm test` (SQLite) | `OPENFGA_TEST_URL=:8101` | tope 3 (`:8103`) |
|---|---|---|---|
| Baseline (`188d625`) | 142 | 200 | — |
| E1 · parche del tester (H2, H3, H4, T1, T2) | 146 | — | — |
| D1–D3 | 154 | — | — |
| D4–D5 | 156 | 215 | — |
| D6–D7 | 161 | 221 | — |
| D8–D9 | 166 | 227 | — |
| D10–D13 | 171 | 235 | — |
| D14–D16 + E1–E4 | 174 | 241 | — |
| **Cierre del lote (E5 docs, build)** | **174 ✅** | **241 ✅** | **241 ✅** |

`npm run typecheck`, `npm run typecheck:build`, `check:purity` (reglas 1–3) y `npm run build` verdes al
cierre; `build/src/openfga.js` existe y `build/index.js` carga en un proceso con `@openfga/sdk`
bloqueado (49 exports, sin `OpenFgaAuthorizationDriver`). Casos del juez: `contract_harness.spec.ts`
pasa de 32 core / 44 en 2.0 a **36 core / 49 en 2.0** (+4 core: D7, D10, D11, E3; +1 2.0: D8).
Higiene: `:8101` tiene 48 stores, **ninguno** con prefijo de esta suite (`contract-`, `regrant-`,
`import-`, `orphan-`, `spies-`); son de otros agentes, como ya anotó el tester.

## Pieza × rojo observado × estado

| # | Pieza | Caso(s) escrito(s) | Fallo real observado en rojo | Estado |
|---|---|---|---|---|
| **E1** (parche) | `tests-tester-fase-1.patch` aplicado tal cual (5 casos) | H2, H3, H4 (`database_driver`/`manager`), T1 (openfga con servidor), T2 | `git apply --check` limpio; 146 verde de entrada. H4 y T1 se reescribieron después (ver E1 y D5) | ✅ |
| **D1** | Cualquier `r.error` en un `batchCheck` ⇒ 503 en `batchCheckAll` (única puerta de las tres fases: denies, roles, `hasRole`), con el error del servidor como `cause` | `openfga_driver.spec` «un error por check en batchCheck es 503, nunca false» (3: rol, deny, hasRole; cliente falso con `{ error: { input_error } }`) | Los tres: «debería haber lanzado» — `authorize` y `hasRole` devolvían **false** | ✅ |
| **D2** | `retryParams: { maxRetry: 0 }` por defecto en el cliente (opción `retryParams` del driver); manager `#write()` notifica `onWrite({ …evento, indeterminate: true })` ante `AuthorizationBackendTimeoutError` antes de propagar (grant/revoke/deny/removeDeny y `scopes.detached`); `AuthzWriteEvent.indeterminate?` | `openfga_driver.spec` «retryParams.maxRetry es 0 por defecto» + «opt-in explícito» (espía sobre `client.configuration`); `manager.spec` «una escritura que vence el deadline notifica onWrite con indeterminate: true ANTES de propagar el 503» (grant y deny ⇒ evento; un 503 no-timeout en revoke ⇒ sin evento) | `expected [] to deeply equal [['granted', true], …]`; `expected 3 to equal +0` (maxRetry del SDK); tipos: `indeterminate`/`retryParams` no existían | ✅ |
| **D3** | `CatalogConflictError` (422 `E_AUTHZ_CATALOG_CONFLICT`); `resolveDisjointCatalogs` en `syncCatalogs`/`runCatalogDiff` (rol `(slug,scopeType)` y permiso en un solo catálogo, antes de tocar la BD); colisión tras codificar contra `authz_permissions` dentro de la transacción del sync y en el diff | `manager.spec` «un rol o un permiso declarado en dos catálogos es 422 … sin escribir» (sync y diff; permiso repetido; disjuntos siguen coexistiendo), «la colisión tras codificar se comprueba también contra los permisos ya en la base» | `sync: debería haber rechazado: expected undefined to equal 422`; colisión spec↔BD aceptada (`status undefined`). El test existente de diff pasaba `[before, after]` (mismo rol dos veces): ahora es conflicto legítimo, ajustado a `[after]` | ✅ |
| **D4** | Cada `DELETE` de la transacción de `purgeScope` pasa por `guardSql` (deadline + clasificación); el guard exterior clasifica BEGIN/COMMIT | L0.13 extendido con `purgeScope` y aserción de que aparece el DELETE de `authz_denies` | `expected [5000, …] to deeply equal [5000, …]`: los dos DELETE salían con `timeout: false`. Al fijarlos, `BEGIN;`/`COMMIT;` de knex seguían en `false` (no son builders): el caso los excluye explícitamente y afirma que son exactamente 2 | ✅ (desviación 2) |
| **D5** | `catalogRoles(scopeType)` / `roleLevels(slug)`; `hasRole` solo pregunta por niveles que el catálogo declara para el slug; `listRoles`/`listRoleScopes`/`listSubjects` filtran por catálogo; promesa de `purgeScope` acotada en `types.ts`/README; T1 del tester reescrito (binding de rol retirado ⇒ `hasRole` false, `listRoles`/`listRoleScopes`/`listSubjects` sin él, tupla comprobada viva con cliente crudo) | `openfga_driver.spec` «un binding de un rol que no está en el catálogo no es membresía…» (y ningún check al backend por `fantasma`), «listSubjects de un rol que no existe para ese nivel es [] sin leer el store» | `expected ['editor', 'fantasma'] to deeply equal ['editor']`; `listSubjects` devolvía al holder. Con `:8101`, T1 reescrito: 215 verde | ✅ |
| **D6** | `isDuplicateWrite(error)` (exportada): solo el duplicado es carrera; `catch (error)` conserva la causa; `writeAssignment` idem; `withPreserveRecipe` añade `{ expiresAt: null }` al 503 de `grant` sin `expiresAt` (lectura caída o relectura vacía tras la carrera) | `openfga_driver.spec` grupo D6 (4): 400 `validation_error` ⇒ 503 con `cause.statusCode 400`, sin reintento (`['read','writeTuples']`); duplicado + relectura vacía + omitido ⇒ 503 con receta y `['read','writeTuples','read']`; duplicado + `null` ⇒ camino largo; lectura caída sin `expiresAt` ⇒ receta | `expected AssertionError: debería haber lanzado … to be an instance of AuthorizationBackendError` (el 400 se tragaba y se reintentaba); mensaje sin receta ×2. **Contra `:8101`** el primer intento (solo 409) rompió «una escritura concurrente no hace que se pierda esta expiración»: el servidor devuelve **400** — ver desviación 1 | ✅ |
| **D7** | `assertExpiresAt` (exportada) en `assertIdentity` (`expiresAt ∈ { undefined, null, Date válida }`); manager y ambos drivers lo pasan en `grant` | Contrato core «expiresAt que no es Date válida, null ni omitido ⇒ 422 … sin escribir» (`'2026-12-31'`, `new Date('x')`, `123`, `{}`; los tres estados legales siguen valiendo); `manager.spec` +2 entradas en «rechaza sin llamar al driver» | Ambos drivers: «debería haber rechazado»; manager: `expiresAt string: expected undefined to equal 422` | ✅ |
| **D8** | `listRoles`: cadena `null` ⇒ `[]`; `listRoleScopes`: `knownOnly`/filtro por resolutor (una llamada por scope; coste documentado) en ambos drivers | Contrato 2.0 «listRoles y listRoleScopes tampoco responden por un scope que el árbol no conoce» — el árbol olvida la org **sin purgar** (parche de `tree.ancestorsOf`) y la recuerda después | `expected ['org-editor'] to deeply equal []`. Dos unitarios L0.7 sin resolutor pasaron a 422 `E_AUTHZ_NO_SCOPE_RESOLVER` (ahora `listRoleScopes` consulta el árbol): `fakeReadStore` recibe un resolutor | ✅ |
| **D9** | `src/openfga.ts` (entrada del subpath), `exports["./openfga"]`, `HolderTypeMap` a `types.ts`, `index.ts` sin `openfga_driver`, `define_config` sin importar el driver, stub `await import('@jantstack/adonis-authz/openfga')` dentro de la factory, comandos desde `../src/openfga.js`, regla 3 de `check_purity` (lista blanca: `src/openfga`, el driver, `commands/openfga_*`), `tests/helpers/load_without_sdk.ts` + `block_openfga_hook.mjs` (`module.register`), `configure.spec` mapea el subpath | `purity.spec` «regla 3: … importando el driver o el SDK hacen fallar el script» (fixture con 6 infractores, 3 permitidos), «el paquete real cumple la regla 3», «index.ts carga con el SDK bloqueado» y su **control** «src/openfga.ts NO carga con el SDK bloqueado»; `configure.spec` +2 aserciones | `expected +0 to equal 1` (regla 3 inexistente); `index.ts` incluye `openfga_driver`; carga de `index.ts`: `Cannot find package '@openfga/sdk' (bloqueado por el test)` desde `index.ts:73`; control: fallaba por otra razón (no existía el archivo). `npm run build` y `configure.spec` (stubs compilan) verdes | ✅ (desviación 3) |
| **D10** | `revoke` ⇒ `findRoleOrFail`; `removeDeny` ⇒ `UnknownPermissionError`, ambos drivers; doc del puerto | Contrato core «revoke/removeDeny con rol o permiso fuera del catálogo ⇒ 422, como grant/deny» (`no-existe`, `org-editor`@app, `no:existe`; los hechos intactos). Caso 17 («inexistentes son no-ops seguros») intacto | «debería haber rechazado» en ambos drivers | ✅ |
| **D11** | `IdentityParts.roleSlug` ⇒ `assertValidSlug('rol')`; manager y drivers lo usan en `grant`/`revoke`/`listSubjects` (`hasRole` sigue con `role`) | Contrato core «un RoleQuery objeto donde el contrato pide un slug ⇒ 422 E_AUTHZ_INVALID_SLUG»; `manager.spec` +3 entradas | (observado junto a D12/D13: el proceso murió por OOM antes de reportar; verde tras implementar los tres) | ✅ |
| **D12** | `MAX_READ_PAGES = 10_000` (exportada); token repetido o tope ⇒ 500 `E_AUTHZ_INTERNAL`; tuplas malformadas ⇒ `diagnostics.unparseableBindings` + `warn`; misma cota en `readPages` del importador | `openfga_driver.spec` «un continuation_token que no avanza ⇒ 500 … en menos de 1 s» (< 10 lecturas), «una tupla sin user/relation/object se cuenta en diagnostics y se registra» | **`FATAL ERROR: … JavaScript heap out of memory`**: el bucle real sin cota (literal H7 del auditor) | ✅ |
| **D13** | `resolveChain` valida la respuesta del resolutor: no-array o `ScopeRef` inválido ⇒ `ScopeResolverError` 503 con la causa | `spies.spec` «un ancestro inválido devuelto por el resolutor es 503 E_AUTHZ_RESOLVER_FAILED, no un 422» (4 respuestas malas, en ambos drivers) | (misma tanda que D11/D12) | ✅ |
| **D14** | Importador: con `reconcile`, `Read({})` completo paginado y acotado; tuplas `role_binding`/`deny_binding` sin correspondencia en SQL ⇒ `extra`; `prune` ⇒ `deleted` (dry-run: las que se borrarían); `prune` sin `reconcile` ⇒ 500 `E_AUTHZ_CONFIG`; reporte `{ written, updated, unchanged, extra, deleted, skippedExpired, dryRun }`; `openfga:import --prune` con aviso cuando hay `extra` sin prune | `contract.spec` (servidor) «reconcile converge: las tuplas que SQL no tiene se cuentan como extra y --prune las borra (D14)» (zombie nunca en SQL + revoke y removeDeny en SQL ⇒ `extra: 3`; sin prune la tupla ajena sigue; dry-run `deleted: 3` sin borrar; prune ⇒ `deleted: 3`, `authorize`/`hasRole` false, alice intacta; segunda pasada `extra: 0`), «prune no tiene sentido sin reconcile: 500» | Tipos: `prune` no existe en `ImportFactsOptions` (×3); los `deepEqual` de los reportes existentes sin `extra`/`deleted`. Verde contra `:8101` (116 en `contract.spec`) | ✅ |
| **D15** | `guardSql('catalog', …)` en cada consulta del sync (dentro de la transacción, `.first()` ⇒ `limit(1)`) y del diff, `timeoutMs` (default 5000); holder no declarado ⇒ `AuthorizationConfigError` (500 `E_AUTHZ_CONFIG`) | `manager.spec` «el catálogo con la base caída es 503 …» (sync y diff con `withTableMissing`); `openfga_driver.spec` «authorize y grant con un morph fuera del mapa ⇒ 500 E_AUTHZ_CONFIG sin tocar el store» (4 operaciones, 0 llamadas al cliente) | `sync: … no such table: authz_permissions: expected undefined to equal 503` (SqliteError crudo); `authorize: expected undefined to equal 'E_AUTHZ_CONFIG'` | ✅ |
| **D16** | El caso L0.7 del juez escribe **150** denies de ruido (75 orgs × 2 permisos) antes del relevante; timeout 60 s; título intacto | Mutante «no seguir el token» (`continuationToken = undefined` en `readAllTuples`) contra `:8101`, solo ese caso | **`orgB está denegada y se listó como concedida: expected [ …(2) ] to not include 'organization:01a049ea…'`** en openfga (database pasa, como debe). Driver restaurado (0 `MUTANTE`) | ✅ |
| **E1** | Manager normaliza `void` ⇒ `{ existed: false, expiresAt: options?.expiresAt ?? null }`; H4 del tester reescrito para afirmar el outcome normalizado (dos llamadas) | `manager.spec` «un driver de terceros cuyo grant no devuelve GrantOutcome sigue notificando granted» | `expected undefined to deeply equal { existed: false, …(1) }` | ✅ |
| **E2** | `IDENTITY_LIMITS.slug` eliminado (comentario: el límite es `MAX_SLUG_LENGTH` = 42); `CLAUDE.md` mapa de `identity.ts` con longitudes y **42** | Sin test (campo muerto); typecheck verde tras quitarlo | — | ✅ |
| **E3** | Contrato core «uuid centinela en un scope que el árbol SÍ conoce ⇒ 422 E_AUTHZ_INVALID_IDENTITY, y la raíz sigue limpia» (el harness cuelga el centinela de `app`); `middleware.spec` «sin permiso ni rol» fija `500`/`E_AUTHZ_CONFIG` y 0 respuestas | — | Sin rojo: `assertScope` rechaza el centinela antes de consultar el árbol. El caso **fija** lo que H1 del tester pedía (discrimina del `UNKNOWN_SCOPE` de B1); el del middleware ya cumplía y ahora lo afirma | ✅ (fija) |
| **E4** | `TYPE_FORMAT` (minúsculas) para tipo de holder y de scope (el uuid sigue tal cual); `assertScopeType(role.scopeType)` en `assertCatalogGrammar` | Contrato core (caso de identidad) +`Users`/`USERS`/`Organization` ⇒ 422; `manager.spec` catálogo +5 `scopeType` malos (vacío, `org\|x`, `Organization`, 21 chars, no string) ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` | «debería haber rechazado» (tipo en mayúsculas aceptado en ambos drivers); `scopeType vacío: expected undefined to equal 422` | ✅ |
| **E5** | README (subpath, `indeterminate`/`retryParams`, "un rol pertenece a un catálogo", `E_AUTHZ_CATALOG_CONFLICT`, `revoke`/`removeDeny` 422, `RoleQuery`/`expiresAt`/tipos en minúsculas, `purgeScope` acotado al catálogo, resolutor validado, deadline honesto con BEGIN/COMMIT, `Read` acotado, `--reconcile --prune`, `E_AUTHZ_CONFIG` ampliado, `3b`); `types.ts` (`purgeScope`, invariante 7, `revoke`/`removeDeny`); CHANGELOG (sección lote D + receta de migración de slugs 1.1.0: `org:admin`, `can_*`, reservados, 43+, colisiones, y qué hacer con un store openfga); `CLAUDE.md` (invariantes 9–13, peer opcional = subpath + regla 3, `authz:reconcile` marcado **3b** con lo que existe hoy, mapa con `src/openfga.ts`, `identity.ts` 42, `errors.ts` con `CatalogConflictError`, `commands` `--prune`, `scripts` reglas 1–3, `tests` 36/49 + helpers, roadmap); `package.json` `2.0.0-alpha.1` | — | — | ✅ |

## Desviaciones respecto a la especificación (con el porqué)

1. **D6 · el "duplicado" de FGA no es un 409.** La spec dice «solo tratar como carrera un 409/duplicate del
   SDK». Medido contra OpenFGA v1.19 con la carrera real del contrato («una escritura concurrente no hace
   que se pierda esta expiración»): el servidor responde **HTTP 400** con
   `apiErrorCode: 'write_failed_due_to_invalid_input'` y `apiErrorMessage: "cannot write a tuple which
   already exists"`. (El 409 que citaba el informe del lote B era el de escribir la misma clave con OTRA
   condición.) `isDuplicateWrite` acepta el 409 **o** ese par código+mensaje; un 400 `validation_error`
   sigue sin ser carrera (test explícito). El fake de los unitarios reproduce la forma real.
2. **D4 · `BEGIN;`/`COMMIT;` de knex no llevan timeout.** Los emite la transacción, no son builders y no
   admiten `.timeout()`. Los dos `DELETE` sí lo llevan (era el hallazgo H13). El caso L0.13 excluye
   explícitamente el control de transacción y afirma que son exactamente 2 sentencias; README lo dice
   («every SQL query the driver builds… only knex's own BEGIN/COMMIT carry none»). Alternativa
   descartada: `withDeadline` sobre la transacción entera liberaría al llamante con la purga en vuelo (el
   problema de D2).
3. **D9 · la regla 3 es una lista blanca, no la lista de cuatro archivos.** Superconjunto de lo pedido:
   todo bajo `ROOTS` salvo `src/openfga.ts`, `src/drivers/openfga_driver.ts` y `commands/openfga_*` tiene
   prohibido importar `@openfga/sdk` o el driver (también `import type`, porque se mira el especificador).
   Cubre `define_config` (que importaba el tipo del driver: `HolderTypeMap` pasa a `types.ts`), providers y
   services. El test de carga bloqueada corre sobre `index.ts` (fuente, en proceso hijo con la app mínima
   booteada, porque Lucid `services/db` exige app) y no sobre `build/`: el build no está garantizado en
   `npm test`. `build/index.js` se verificó a mano con el mismo hook (carga, 49 exports, sin el driver).
4. **D5 · T1 del tester cambia de semántica.** Su parche afirmaba `hasRole` **true** sobre la tupla
   huérfana («membresía, se lee del store»). La spec fija lo contrario (filtro por catálogo en ambos
   drivers): el caso ahora afirma `hasRole` false, `listRoles`/`listRoleScopes`/`listSubjects` vacíos y,
   con un cliente crudo, que la tupla **sigue** en el store (la promesa de `purgeScope` queda acotada).
5. **D3 · un test existente se ajusta.** «diffAuthzCatalog… runCatalogDiff falla si hay diferencias»
   pasaba `[before, after]` (el mismo `editor@app` dos veces) para provocar el fallo; eso ahora es
   `E_AUTHZ_CATALOG_CONFLICT`. Pasa `[after]`, que es lo que quería probar.
6. **D15 · más de lo pedido.** Además de clasificar (503), cada consulta del catálogo lleva deadline
   (`timeoutMs`, default 5000) y `.first()` se sustituye por `limit(1)` para poder fijarlo. Coste: cero;
   beneficio: el README puede decir sin matices que el catálogo tampoco cuelga.
7. **D2 · `indeterminate` también en `scope_purged`.** La spec habla de «una escritura»; la purga lo es y
   pasa por el mismo `#write`. Se emite `scope_purged` con `indeterminate: true` si vence el deadline, y
   el `scope_purged` normal solo tras `onScopeDetached`.
8. **D8 · dos unitarios necesitan resolutor.** `listRoleScopes` consulta el árbol; `fakeReadStore` de L0.7
   inyecta `async () => [APP_SCOPE]`. No cambia lo que esos casos prueban (paginación y caducidad).
9. **D14 · `deleted` en dry-run.** Cuenta las que se borrarían con `prune` (igual que `written`/`updated`
   son «se escribirían»); sin `prune`, 0. `extra` solo se calcula con `reconcile` (en un store vacío no
   hay nada que sobre).
10. **E4 · el uuid no se fuerza a minúsculas.** La spec dice «`type` y slugs»; el uuid es identidad del
    consumidor y su collation es asunto suyo. Queda anotado.

## Hallazgos

- **El rojo de D12 fue un OOM del proceso de test** (`Ineffective mark-compacts near heap limit`): el
  bucle sin cota acumulaba tuplas hasta reventar el heap. Es la reproducción más literal posible de H7.
- **Un unitario dependía del orden de archivos.** «un id no parseable se registra y se cuenta (L0.16)»
  llamaba a `listRoles` sin sembrar `editor@app`: pasaba porque otro spec dejaba el catálogo puesto.
  Con D5 (filtro por catálogo) cayó al correr el archivo aislado. Ahora siembra el suyo.
- **`Exception` de Adonis ya no se usa en el driver openfga**: el único `throw new Exception` (holder no
  declarado) pasa a `AuthorizationConfigError`. Todos los errores del paquete llevan `code`.
- **`--import <hook>` no registra hooks**: hay que llamar a `module.register()`. El helper lo hace; mi
  comprobación manual sobre `build/src/openfga.js` con `--import` a secas dio un falso «carga», anotado
  para que nadie repita el error. El caso de control del test (`src/openfga.ts` DEBE fallar) es lo que
  demuestra que el bloqueo actúa.
- **Coste nuevo de las lecturas de membresía en openfga**: una consulta SQL por llamada (`authz_roles`
  del nivel) y, en `listRoleScopes`, una llamada al resolutor por scope devuelto (D8, igual que
  `listScopes`). `spies.spec` no lo fija (mide `authorize`); el memo por request (Fase 2) lo amortiza.
- **La receta de migración de slugs** (CR3) exige `authz:catalog:sync` con el paquete VIEJO antes de
  subir, porque el nuevo rechaza el slug ilegal antes de poder renombrarlo; y en openfga el slug va
  dentro del id del binding, así que hay que reimportar con `--reconcile --prune`.
- **Sin store huérfano** tras ~15 corridas contra `:8101` (incluidas las que fallaron a mitad).

## Archivos

- **Nuevos**: `src/openfga.ts`, `tests/helpers/load_without_sdk.ts`, `tests/helpers/block_openfga_hook.mjs`,
  `.claude/contexto/fase-1-lote-d-informe.md`.
- **`src/`**: `types.ts` (`HolderTypeMap`, `indeterminate`, docs de `purgeScope`/`revoke`/`removeDeny`),
  `errors.ts` (`CatalogConflictError`), `identity.ts` (`TYPE_FORMAT`, `assertExpiresAt`, `roleSlug`, sin
  `IDENTITY_LIMITS.slug`), `manager.ts` (`#write`, normalización de `void`, `roleSlug`/`expiresAt`),
  `catalog.ts` (`guardSql`, `timeoutMs`, colisión contra BD, `assertScopeType`, `resolveDisjointCatalogs`),
  `define_config.ts` (tipo desde `types.ts`), `drivers/backend_guard.ts` (validación de la respuesta del
  resolutor), `drivers/database_driver.ts` (D4, D8, D10, D11), `drivers/openfga_driver.ts` (D1, D2, D5, D6,
  D8, D10–D15), `testing/contract.ts` (+5 casos, D16, E3/E4).
- **Raíz**: `index.ts`, `package.json` (`exports["./openfga"]`, versión), `scripts/check_purity.mjs`
  (regla 3), `stubs/config/authorization.stub`, `commands/openfga_import.ts` (`--prune`),
  `commands/openfga_provision.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`.
- **`tests/`**: `contract.spec.ts` (T1 reescrito, D14 ×2, reportes con `extra`/`deleted`, import del
  subpath), `contract_harness.spec.ts` (36/49), `database_driver.spec.ts` (parche + D4),
  `manager.spec.ts` (parche + D2, D3 ×2, D7, D11, D15, E1), `middleware.spec.ts` (E3),
  `openfga_driver.spec.ts` (D1 ×3, D2 ×2, D5 ×2, D6 ×4, D12 ×2, D15, seed en L0.16, resolutor en
  `fakeReadStore`), `purity.spec.ts` (D9 ×4), `spies.spec.ts` (D13), `configure.spec.ts` (subpath).
