# Sublote D2 — repaso adversarial del CIERRE 4 (auditor, 2026-10-16)

Árbol: `main` sobre `75353fe` con D2 + cierres 1–4 SIN commit. Solo lectura sobre el repo. Escrito: este fichero y
`.claude/reproducciones/loteD2-auditor-cierre4.ts` (D4-1…D4-3; SQLite `:memory:` + stores efímeros `aud-d2c4-*` en
`:8090`, borrados al terminar). Búsquedas de mutantes fuera del repo (scratchpad: copia de `tuple_order.ts` con la mutación,
importada por un script; el repo no se tocó). Sin docker restart, sin gates, sin `test:pg|mysql`.

```
source ~/.config/nvm/nvm.sh && nvm use 22
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre3.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre2-fga.ts
node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre2-orden.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre4.ts
```

## Veredicto en una línea

**NO APTA.** C3-1…C3-4 están cerrados en efecto: re-ejecuté las tres reproducciones anteriores y la fuerza bruta del
paquete, con 2,4 M combinaciones por modo y 0 sin residuo en el código real.

Pero la retención en CASCADA tiene un hueco medido contra OpenFGA (🟠 D4-1):
- Una membresía nueva que transporta OTRO deny se retiene, y el destino sigue concediendo EN `now` lo que ese deny corta y el origen niega.
- La línea dice justo lo contrario («escribir esto haría que el destino concediera»).
- El README afirma «Withholding only restricts… except a grant… through a path the lost deny alone was cutting», y aquí el camino lo cortaba otro deny.
- El docblock de `WithholdPlan.conflicts` dice que este caso es un CONFLICTO; el código no lo implementa para candidatos.
- La fuerza bruta no lo ve: lo cuenta como `preexisting` siempre que la partición tenga cualquier `renewal-unsafe`/`deny-conditional`. Son 23 485 / 33 612 / 41 795 de 400 000 combinaciones (E1/U2/E3, dos Write) que la retención deja concediendo en `now`.

Además, el mutante `c4h.order.renewals-not-changing` sí tiene un asesino semántico: E3, atómico, muestra 200k, semilla 7 ⇒ 2 sin residuo frente a 0 del original.

---

## 1. C3-1…C3-4: re-ejecución

`loteD2-auditor-cierre3.ts` contra `:8090`:

| repro | cierre 3 | ahora |
|---|---|---|
| C3-1 openfga | `written 1`, `destAfterOldExpiry TRUE` | dry = real: `written 0, updated 0, [renewal-unsafe, withheld-by-unsafe-deny]`; `destJustAfter false`, **`destAfterOldExpiry false`**; la 2.ª pasada (ya vencida la vieja) da `written 2` y sigue negando |
| C3-1 database (control) | `updated 1`, false | `written 1, updated 1, []`, false |
| C3-2 | dry ≠ real; el destino concedía | dry = real: `written 0, [deny-conditional, withheld-by-unsafe-deny]`; el destino niega |
| C3-3 (las dos ramas `carriedDenyUnknown`) | 503 parcial | igual: 503 parcial, nunca un éxito |
| C3-4 (frontera T−1 / T) | 409 / reescrita | igual |

`loteD2-auditor-cierre2-fga.ts`:
- R1 da 409 `RENEWAL_UNSAFE` sin hueco.
- R3 da ahora **409 `E_AUTHZ_RENEWAL_RACED` partial=true**, con final `false`.
- R4 da `written 2`, niega, y la 2.ª pasada da 0.
- R5 y R7 (database/openfga) niegan en cada prefijo.

`loteD2-auditor-cierre2-orden.ts`: O3 da `bad: null`; O4 da 4 194 304 pares con `unsafeNoResidue 0`.

**Cerrados en efecto.**

Fuerza bruta del código REAL, fuera de las muestras fijadas:
- E3, U2 y E1, cada uno con 3 semillas × 400 000 por modo: `unsafeWithoutResidue 0` y `malformed 0` en todas.
- En dos Write, la pasada se NIEGA en un 21–25 % de las combinaciones de U2/E3 y en un 10 % de E1. Ver §3.

## 2. Retención en cascada y horizonte (punto 2)

Probé:
- varias relaciones (viewer/editor/owner, con `cuts` desde `toConfig`);
- dos niveles de anidamiento (E3);
- `--prune` y sin `--prune`;
- la dirección openfga → database.

**Resiste:**
- **openfga → database.** El destino tiene `atomicRenewal`, así que `held`/`lost` quedan vacíos y no hay retención. Un deny condicional del origen openfga se escribe permanente en database (D3), que es más restrictivo.
- **Una retención de candidatos sola** (allows, membresías y extensiones de allows que alcanzan al sujeto protegido por otro camino): restringe.
- **`--prune` sobre allows:** nunca se retiene un borrado de allow.
- **El punto fijo de la cascada sobre candidatos:** cubre los allows NUEVOS que el deny de la membresía retenida habría cortado.

Lo que **no** cubre la cascada es lo que el destino YA tiene. Eso es D4-1 (abajo).

D4-2: un borrado retenido deja una MEMBRESÍA sobrante viva, que es en sí misma una concesión de `member`.

## 3. `carrier-conflict` (punto 3)

**¿Cero escrituras? Sí** (D4-3, medido):
- Tuplas del store: 6 antes y 6 después de la real con `--prune`.
- Respuesta: 500 `E_AUTHZ_DENY_MIGRATION_REFUSED`.
- `denyGate` lanza antes del primer `applyPartition` (`reconcile.ts:603-606`); el borrado de vencidas también va después.
- Dry-run lo marca en `denyRefused`.
- Sin `--prune` no hay conflicto posible: `conflicts` solo nace de `deletes`.

**¿DoS? Sí, acotado: 🟡 D4-3.**
- Un tenant con escritura NORMAL en el origen, entre dos pasadas, puede forzarlo. Le basta con: extender una membresía portadora que la pasada anterior copió más corta, y quitar en el origen una membresía que sigue en el destino, cuyo grupo concede algo y transporta un deny sobre lo mismo.
- La negativa es GLOBAL: la partición de OTRO tenant (`V viewer W`) queda sin migrar tras `--prune`. Sin `--prune` sí entra.

## 4. Orden con renovaciones y `shortening` (punto 4)

**Sin regresión medida** en la propiedad de prefijos:
- 0 sin residuo en 2,4 M combinaciones por modo, fuera de las muestras fijadas.
- La proporción de ciclos sube en destino atómico: 2,96 % de combinaciones en E1-reduced exhaustivo frente al 0,83 % del cierre 3, aunque los universos no son comparables (6 → 8 estados). Está declarado.

⚪ La letra del aviso `orden SIN garantía` (`commands/authz_relations_reconcile.ts:207-214`) describe el ciclo como «el mismo sujeto entra o sale a la vez». Desde el cierre 4 un ciclo puede contener una RENOVACIÓN, que en `now` ni entra ni sale. Tampoco dice «en un instante posterior». Es higiene.

## 5. Los tres mutantes «solo por cifras» (punto 5)

- **`c4h.order.renewals-not-changing`: SÍ hay propiedad semántica, y es la misma propiedad de la fuerza bruta, en E3.**
  - Muestra 200k, semilla 7, destino ATÓMICO: mutante `unsafeWithoutResidue 2`, original 0 (`loteD2-auditor-cierre4-mutantes.ts`, M1).
  - Ejemplo: renovaciones que ACORTAN `b ⊂ a` y `c ⊂ b`, deny en `a`/`c`.
  - E1-reduced exhaustivo (atómico) no lo ve (0), porque solo tiene un nivel.
  - El mutante cambia el orden en 706/3 618/1 852 de 200 000 transiciones aleatorias de E1/E3/U2: no es equivalente.
  - Que muera hoy solo por cifras se debe a que la muestra E3 de 30k es demasiado pequeña.
  - Cómo matarlo semánticamente: fijar ese ejemplo como caso literal (`walkPair`), o subir la muestra/semilla de E3 en el modo gateado.
- **`c41.order.without-ignored`** (más conservador): la propiedad que lo mata es de PRECISIÓN, no de seguridad. Un allow nuevo que llega al sujeto protegido SOLO a través de la portadora retenida tiene que escribirse: cuando la portadora vence, el sujeto pierde a la vez el allow y el deny. Ejemplo: `H#member editor X` con deny `H#member viewer X` y `U∈H` retenida por extensión. Un caso literal así lo mata sin cifras. Sin él, sobre-retener solo cuesta disponibilidad (más deriva, exit ≠ 0) y nunca concede: está bien declarado.
- **`c41.plan.withhold-off`**: ya muere por una aserción semántica, no por cifras. El caso de contrato «vigencia · C3-1» comprueba `later.check(...) === false` con `withClock` (`relations_reconcile_contract.ts:402`), y la fila C3-1 de `relations.reconcile.order` comprueba el horizonte (`guard_surface.spec.ts:1925`). Con el mutante, el allow se escribe y concede tras la caducidad vieja. No hace falta más.

## 6. RACED frente a UNSAFE y la marca parcial de `purgeScope` (punto 6)

- `E_AUTHZ_RENEWAL_UNSAFE` significa ahora siempre cero escrituras.
- `E_AUTHZ_RENEWAL_RACED`:
  - lleva su clase, se exporta en `index.ts:102`, va marcado parcial y tiene la letra «NO apliques la receta de UNSAFE»;
  - aparece en el README (sección y tabla) y en el CHANGELOG;
  - R3 lo da;
  - no queda ningún `.raced` en `src`.
- Un consumidor con la política genérica «409 ⇒ reintenta» no reabre la ventana: el reintento de `relate` con la misma caducidad no renueva. **Resiste.**
- `purgeScope` de roles: `markPartialWrite` si `progress.deleted > 0`, incluido el `PURGE_INCOMPLETE` posterior. Es una función local (sobrevive al Proxy del runbook). **Resiste.**
- ⚪ `progress.deleted += batch.length` cuenta como borradas claves pedidas con `onMissingDeletes: Ignore`. La fase 1 borra la estructura «a ciegas», así que un fallo posterior en una purga que no había borrado NADA sale como `indeterminate: true`. Es el lado conservador: sobre-notifica, nunca sub-notifica.

---

## Hallazgos (por severidad)

### 🟠 D4-1 · La retención en cascada de una membresía que transporta OTRO deny deja al destino concediendo EN `now` lo que el origen niega; la línea dice lo contrario y la fuerza bruta lo absorbe como `preexisting`

**Escenario**
- **Precondición** (origen `database`, destino `openfga`, la dirección del cutover):
  - En los dos lados:
    - `deny(H#member, viewer, X)`;
    - `deny(K#member, viewer, Y)`;
    - `relate(K#member, viewer, X)`;
    - `relate(U, viewer, Y)`.
  - Origen: `U ∈ H` durante 1 día y **`U ∈ K`**. Es normal que un admin añada a U a un grupo «suspendido» después de la pasada anterior.
  - Destino: `U ∈ H` durante 1 h, sin `U ∈ K`.
- **Acción:** `reconcileRelations`, dry y real.
- **Resultado (D4-1, `:8090`):**
  ```
  origen  U viewer Y (now)        false
  destino U viewer Y antes        true
  dry/real written 0 · denyRefused [] · [renewal-unsafe U∈H, withheld-by-unsafe-deny U∈K]
  destino U viewer Y tras la pasada (now)   TRUE      (+2 h: TRUE)
  ```
- La pasada del cierre 3 escribía `U∈K` y arreglaba Y en `now`.
- Ahora la retiene, porque K concede X y el deny de H sobre X «no viaja». Con ella se pierde el deny de K sobre Y, que nadie compensa: la cascada solo retiene CANDIDATOS, y `U viewer Y` ya está en el destino.
- La línea de `U∈K` dice «escribir esto haría que el destino concediera lo que el origen niega desde <fecha>». No dice que NO escribirla deja la concesión de Y AHORA.

**Evidencia**
- ✅ Medido en D4-1.
- ✅ `tuple_order.ts`, bucle de candidatos de `relationWithheldWrites`: solo hace `out.withheld.set(...)` y la cascada, nunca `conflicts`. Pero el docblock de `WithholdPlan.conflicts` dice: «una membresía que concede lo protegido Y transporta un deny (no escribirla quita su deny) … la pasada se NIEGA entera».
- ✅ README §«Not renewing is not neutral» dice: «Withholding only restricts … except a grant the destination already gave … through a path the lost deny alone was cutting». Es falso aquí: lo cortaba el deny de K, no el perdido.
- ✅ `order_bruteforce.ts`: `declared = held.length + lost.length > 0`. Cualquier `renewal-unsafe` de la partición convierte en `preexisting` toda concesión final que el inicial ya diera.
- ✅ Medido en `loteD2-auditor-cierre4-mutantes.ts` (M2), dos Write, 400 000 combinaciones: concesiones en `now` que escribir lo retenido habría evitado = **23 485 (E1) · 33 612 (U2) · 41 795 (E3)**.
  - Ejemplo E1: `h@u1:expired/same`, `¬x@h#member:absent/same`, `g@u1:live/other`, `x@u1:live/shorter`, retenidas `[h@u1]`. La membresía nueva que trae el deny de X se retiene y U1 sigue viendo X en `now`.

**Steelman del defensor:** «No es una concesión NUEVA: el destino ya concedía antes de la pasada; sale con exit ≠ 0 y una línea con receta; el runbook verifica antes del switch, y tras resolver la causa la siguiente pasada lo arregla».
- **¿Me convence?** A medias. Es exactamente la defensa que no bastó para C3-1:
  - La letra (línea, README y docblock) le dice al operador que retener deja el destino MÁS restrictivo, y aquí lo deja MENOS restrictivo YA, por un camino que ninguna línea nombra.
  - El oráculo, que es la prueba publicada de «0 sin residuo», lo esconde en `preexisting`.
  - Si se juzga por «no empeora el inicial» estaría en el borde con 🟡. Lo marco 🟠 por coherencia con C3-1 y porque la propia doctrina del cierre («igual o más restrictivo en TODO instante futuro») queda falsada en `now`.

**Mitigación mínima:**
- Que una membresía CANDIDATA que transporta un deny que corta algo que los sujetos de debajo reciben en el final real sea `carrier-conflict` (lo que ya promete el docblock). O, si se prefiere residuo, una línea propia que diga qué concede YA.
- En la fuerza bruta, `preexisting` solo cuando el final SIN retención también concedería en `t`, o con un vínculo causal con la causa declarada.

### 🟡 D4-2 · `--prune`: el borrado RETENIDO de una membresía que solo transporta denies deja al sujeto como MIEMBRO del grupo (`member`) que el origen ya no tiene

**Escenario**
- **Precondición:** deny de H y de K sobre `viewer X` en los dos lados; `U viewer X`; `U∈H` extendida en el origen; `U∈K` solo en el destino.
- **Acción:** reconcile con `--prune`.
- **Resultado (D4-2):** `deleted 0`, la línea es `withheld … no se BORRA U∈K`, y `check(U, member, K)` da: origen **false**, destino **TRUE**.

**Evidencia**
- ✅ Medido.
- ✅ `deleteThreatens`/`grants` solo miran los allows que el grupo transporta (`reach(allowIndex)`), no la propia tupla de membresía.
- ✅ El oráculo de la fuerza bruta excluye los objetos `group:` (`order_bruteforce.ts:81`), así que es ciego a la relación `member`.
- «Withholding only restricts» es falso para `member`, `listSubjects(group)` y `membersOf`.

**Steelman del defensor:** «Está declarado tupla a tupla ("no se BORRA <membresía>"), es deriva, y sin `--prune` las sobrantes siempre se quedaron».
- **¿Me convence?** Para la severidad, sí: 🟡.
- Para la letra universal, no: hay que acotarla («restringe ALLOWS sobre objetos que no son grupo; una membresía retenida sigue siendo membresía»).

**Mitigación mínima:** acotar la frase del README y del docblock, o tratar como `conflicts` el borrado retenido de una membresía si la config declara que `group#member` se consulta.

### 🟡 D4-3 · `carrier-conflict` se puede forzar desde el ORIGEN con escrituras normales y bloquea con `--prune` la migración de TODAS las particiones

**Escenario**
- **Precondición:** un tenant con escritura en el origen. Entre la pasada N (que copió `U∈H` con caducidad corta y `U∈K`) y la N+1:
  - extiende `U∈H` (H transporta deny `viewer X`);
  - quita `U∈K`, donde K transporta deny `viewer X` y concede `viewer Z`.
- **Acción:** la pasada N+1 con `--prune`, sobre las particiones `[P, P2]`.
- **Resultado (D4-3):**
  - 500 `E_AUTHZ_DENY_MIGRATION_REFUSED` (`carrier-conflict`), tuplas 6 → 6.
  - La partición P2 de OTRO tenant **queda sin migrar** (`V viewer W` false).
  - Sin `--prune` la pasada entra (`written 1, extra 1`) y P2 migra.

**Evidencia**
- ✅ Medido.
- ✅ `reconcile.ts:603-606`: una negativa en una partición ⇒ cero escrituras en todas.

**Steelman del defensor:**
- «Bajo la ventana del operador (`authz:freeze`) el tenant no puede rearmarlo.»
- «La receta (unrelate + relate en el destino) lo resuelve.»
- «Un `renewal-unsafe` cualquiera ya pone exit ≠ 0 en el verificador.»
- «"Cero escrituras globales" es la regla de la puerta del deny desde D2.»

**¿Me convence?** Sí para no subirlo: es disponibilidad, acotada por el freeze y con receta. Pero es la primera negativa global de la puerta que un tenant dispara con su API normal (las demás dependen de la config o de escrituras a mano). Hay que declararlo en el README.

**Mitigación mínima:** declararlo; opcionalmente que `carrier-conflict` niegue solo su partición y lo reporte.

### ⚪ D4-4 · Letra del aviso `orden SIN garantía` sin las renovaciones

- `commands/authz_relations_reconcile.ts:207-214` dice «entra o sale a la vez». Un ciclo puede contener ahora una renovación, y el corte que concede puede darse en un instante posterior.
- **Mitigación:** ajustar la letra.

### ⚪ D4-5 · `purgeScope` de roles: el contador cuenta borrados pedidos con `Ignore`, no los efectivos

- **Escenario:** la fase 1 borra a ciegas la estructura de roles sin bindings; si el lote siguiente falla, el resultado es `indeterminate: true` aunque no se haya borrado nada.
- **Evidencia:** ✅ `openfga_driver.ts`, `deleteKeys` (`progress.deleted += batch.length`).
- **Steelman del defensor:** «sobre-notificar es el lado seguro». Me convence: ⚪.

## Lo que intenté y NO se rompió

- C3-1…C3-4 y R1–R7, O3/O4: todos en el sentido correcto (§1).
- Código real con 3 semillas × 400k por modo en E1/U2/E3: 0 sin residuo, 0 malformados.
- `carrier-conflict`: realmente cero escrituras, también en las otras particiones y en el borrado de vencidas. Dry-run lo marca.
- openfga → database: sin retención (`atomicRenewal`); un deny condicional del origen se escribe permanente (más restrictivo).
- Multi-relación con `cuts`: un deny `viewer` corta `owner`/`editor`; un deny `editor` no corta `viewer`. Correcto según D5.
- `RENEWAL_RACED` frente a `RENEWAL_UNSAFE`: códigos, clases, export y letra; reintentar ante cualquier 409 no reabre la ventana.
- La marca parcial de `purgeScope`, incluido el `PURGE_INCOMPLETE` posterior y el Proxy del runbook.
- `c41.plan.withhold-off` muere por una aserción semántica, no por cifras.
- Stores: cero `aud*` residuales en `:8090`.

## Preguntas abiertas para el arquitecto

1. 🟠 D4-1: una membresía CANDIDATA que transporta un deny que corta algo que el destino ya concede, ¿es `carrier-conflict` (lo que promete el docblock, a costa de más negativas: D4-3) o un residuo propio con una letra que diga «concede YA»? Sin una de las dos, y sin acotar `preexisting` en la fuerza bruta, no hay APTA.
2. 🟡 D4-3: la negativa `carrier-conflict`, ¿global (regla actual de la puerta) o por partición?

