# Panel «tenencia» (7.º informe de COGNITIV) — auditor de seguridad

> Fecha: 2026-10-14. Rol: atacante. Leí el código de alpha.10, no solo la postura. Fuentes: `cognitiv-informe-7-tenencia.md`,
> `panel-tenencia-coordinador.md`, `linajes.md`, `CLAUDE.md`, README §Relations (511–730) y §capabilities (858+),
> `src/relations/manager.ts`, `src/relations/reconcile.ts`, `src/drivers/{database,openfga}_relations_driver.ts`,
> `src/relation_partition_trigger.ts`, `src/drivers/openfga_driver.ts` (deny de roles), `src/drivers/openfga_facts.ts`,
> `src/expiry.ts`, `src/identity.ts`, `stubs/migration.stub`. No ejecuté nada contra `:8101`. Las marcas de evidencia son
> ✅ (lo vi en el código), 🟡 (depende de cómo se implemente) y ❓ (no lo pude verificar).

## Veredicto en una línea

**Tal como está, es inseguro.** P1 (deny) es la pieza peligrosa. Cada mecanismo que hoy falla **cerrado** con un allow
falla **abierto** con un deny, y además P1+P4, tal como están propuestos, no cubren el caso de uso que motiva el informe
(«Finanzas/Nóminas»). P2–P5 son seguros con reservas si se fijan los casos de abajo.

---

## Hallazgo transversal: el deny invierte el signo de cada fallo (candidato a linaje nuevo, «L9»)

Todo el paquete se diseñó con una propiedad tácita: **«si algo sale mal en la tupla, el resultado es denegar»**. Con
allows es verdad, porque perder, retrasar o malinterpretar una tupla quita acceso. Con una tupla NEGATIVA, el mismo
fallo **da** acceso. Encontré siete instancias de golpe (🔴2, 🟠4, 🟠6, 🟠7, 🟠8, 🟡12 y 🟡13). Ninguna es un defecto
del código actual: son caminos que hoy son seguros y que P1 vuelve inseguros **sin tocarlos**. Por eso no las recomiendo
como siete parches. La guarda M7 que propongo está al final: una tabla de signos que inyecta cada fallo y exige que, del
lado del deny, el resultado siga siendo denegar.

---

## Hallazgos (ordenados por severidad)

### 🔴 1 · P1+P4 no implementan «el deny gana» a lo largo de la cadena del consumidor: el caso Nóminas no queda bloqueado
- **Escenario:** el departamento tiene `viewer` en `Finanzas`. Se pone `deny(org#member, viewer, Nóminas)`. El evaluador
  del consumidor llama a `checkMany(U, viewer, [informe.pdf, Nóminas, 2026, Finanzas])` y obtiene `[false, false, false,
  true]`. Aplica «alguno concede» y el resultado es **true**. El deny no hace nada, porque en `Nóminas` no había ningún
  allow que restar: el allow está en `Finanzas`, el deny en `Nóminas`, y `check` solo resta dentro del MISMO objeto.
- **Evidencia:** ✅ `check` devuelve un booleano efectivo por objeto (`database_relations_driver.ts:585-607`,
  `openfga_relations_driver.ts:488-499`). Un `false` no distingue «aquí no hay allow» de «aquí hay un deny». El informe,
  en §7, dice literalmente «una `checkMany` sobre la cadena y la regla deny gana». Con booleanos esa regla no se puede
  implementar.
- **Steelman del defensor:** «La herencia es del consumidor: que llame también a `listDenies` en cada nodo». **¿Me
  convence?** No. Eso son 2N llamadas que P4 quería evitar, P4 no lo ofrece, y el consumidor ya escribió en su informe el
  plan que falla. Además lo hará fail-open en silencio: su suite pasará, porque el caso «deny en el mismo objeto» sí
  funciona.
- **Caso que lo fija (los dos drivers):** «un deny en Nóminas bloquea el allow heredado de Finanzas, evaluado con la
  primitiva PUBLICADA de cadena». Si ninguna primitiva publicada puede pasar ese caso, P1 no resuelve el caso de uso y hay
  que decirlo en el README.

### 🔴 2 · En openfga, renovar un deny con caducidad es delete+write en dos llamadas: hay una ventana fail-open y un deny que puede desaparecer sin evento
- **Escenario:** existe `deny(U, viewer, D, { expiresAt: 31-dic })` y U tiene un allow. El operador lo prorroga.
  `relate` borra la tupla (llamada 1) y la reescribe (llamada 2). Entre las dos, `check` devuelve `true`. Si la llamada 2
  devuelve un 503 que no es timeout, el deny ya no existe y el manager no emite evento, porque solo notifica
  `indeterminate` en timeouts o en purgas parciales. El invariante 13 lo clasifica como «no ocurrió». El resultado es un
  fail-open **persistente** con una auditoría que dice que no pasó nada.
- **Evidencia:** ✅ `openfga_relations_driver.ts:425-435` (dos `client.write`) y `src/relations/manager.ts:197-206`
  (`#write`). 🟡 Depende de que el deny reutilice el camino de `relate`, que es lo natural: la postura dice «caducidad
  estricta, misma semántica». Con allows esa ventana es fail-closed y por eso hoy se acepta.
  `database` no tiene el problema: el delete+insert va en UNA transacción interna (`database_relations_driver.ts:536`).
- **Steelman del defensor:** «Es la misma ventana que el `grant` de roles». **¿Me convence?** No. El deny de roles no
  caduca (`denied_<P>: [<holders>]`, `openfga_facts.ts:37`), así que nunca se renueva. No hay precedente.
- **Mitigación mínima:** en openfga la renovación de un deny nunca pasa por un estado sin deny. Si no puede garantizarlo,
  marca la escritura como parcial o indeterminada y no la deja salir como «no ocurrió».
- **Caso:** un espía que hace fallar el segundo `Write` ⇒ el deny sigue vigente, o el evento sale `indeterminate`. Nunca
  `check = true` con «no ocurrió».

### 🔴 3 · El reconcile de relaciones migra los denies como allows si `kind` es opcional
- **Escenario:** P1 añade `kind: 'deny'` a `RelationTuple` como campo opcional, igual que `expiresAt`, y los drivers lo
  emiten. `reconcileRelations` no se toca. `relateOrSkip` llama a `to.relate(...)` para TODA tupla. Resultado:
  `deny(U, viewer, Nóminas)` llega al destino como «U es viewer de Nóminas», con `written++` y exit 0. Además,
  `tupleKey` no incluye `kind`: un allow y un deny con la misma clave colapsan en el `Map` y se pierde uno de los dos. Si
  se pierde el deny, es fail-open.
- **Evidencia:** ✅ `src/relations/reconcile.ts:54` (`tupleKey` sin `kind`), `:440-446` (`relateOrSkip` → `to.relate`),
  `:314` (`--prune` → `to.unrelate` sin `kind`) y `src/types.ts:2140-2152` (`RelationTuple` no tiene `kind`). 🟡 Depende
  de la implementación, pero con un campo opcional TypeScript no obliga a nadie a tratarlo.
- **Steelman del defensor:** «El informe ya pide el caso "reconcile migra los denies como denies"». **¿Me convence?**
  A medias. El caso lo fija para los dos drivers del paquete. Un driver de terceros que soporte deny y no emita `kind`
  pasa el contrato publicado, salvo que el runner siembre un deny y lo cense.
- **Mitigación mínima:** `kind` OBLIGATORIO en `RelationTuple`, de modo que no compile quien no lo trate. Además, `kind`
  en `tupleKey` y un censo de denies en `runRelationsDriverContract` y en el contrato de migración de relaciones.

### 🟠 4 · Si la relación efectiva lleva un nombre NUEVO (el patrón `can_<P>` de roles), los usersets y los pods viejos se saltan el deny
- **Escenario A (rolling deploy):** el modelo gana `viewer_eff = viewer but not denied_viewer` y `check` pasa a consultar
  `viewer_eff`. Los pods de alpha.10 siguen preguntando por `viewer` (la relación cruda) y no ven ningún deny durante todo
  el despliegue. Lo mismo vale para cualquier código del consumidor que llame a FGA directamente.
- **Escenario B (deny sobre una membresía):** si se admite `deny(U, member, group:G)`, las tuplas de documentos guardan
  el userset `group:<key>|G#member`. FGA resuelve la relación nombrada en el userset (`member`, la cruda), no
  `member_eff`. U sigue entrando por el grupo en todos los documentos. En `database`, en cambio, la CTE `principal` sí
  podría honrarlo, así que los drivers tampoco darían la misma respuesta.
- **Evidencia:** ✅ los usersets y los `includes` apuntan a la relación por nombre: `computed(name)` en
  `openfga_facts.ts:1013-1015` y `directly_related_user_types` con `group#member` en `:987-996`. 🟡 Depende de la
  codificación que se elija.
- **Steelman del defensor:** «Es el patrón probado de roles». **¿Me convence?** No. En roles nadie escribe usersets que
  apunten a `<P>`; en relaciones es lo normal. Y el patrón de roles no ejercita ni la condición ni el userset en la rama
  que se resta (⚪ 18).
- **Caso:** «un pod con el modelo/cliente anterior no concede lo que un deny bloquea», y «un deny sobre `group#member`
  bloquea en los documentos compartidos con el grupo, en paridad». La salida obvia es que la relación pública sea la
  efectiva, directamente asignable con `but not`. El diseño no es asunto mío; el caso sí.

### 🟠 5 · El deny literal rompe la implicación de `includes`, y «nadie ve X» deja de poder expresarse con un solo deny
- **Escenario:** con `viewer ⊇ editor ⊇ manager` y deny literal en `viewer`: `check(U, viewer, D) = false`, pero
  `check(U, editor, D) = true` y `check(U, manager, D) = true`. **No es que el manager siga viendo: es que sigue
  editando.** Un consumidor que protege «abrir» con `viewer` y «guardar» con `editor` deja que un usuario denegado
  sobrescriba el documento, y en casi cualquier UI editar implica leer. Al revés, un `deny(manager)` deja intactos el
  `editor`/`viewer` que se derivan de ese mismo grant denegado. Para bloquear del todo hacen falta N denies, uno por
  relación del retículo, y una relación que se añada después al config deja incompletos los conjuntos ya escritos (la
  relación siguiente).
- **Evidencia:** ✅ hoy `editor ⇒ viewer` está garantizado por construcción (`#expandDown`,
  `database_relations_driver.ts:420-436`, y la unión `computed` en FGA). El literal es el primer mecanismo que lo
  rompe.
- **Respuesta a la pregunta del coordinador:** que un deny en `viewer` deje al manager viendo **no ocurre**, porque el
  deny se resta del `viewer` calculado. Lo que ocurre es que el manager sigue con `editor` y `manager`. Si eso es un
  bypass o la semántica correcta es decisión del dueño, pero **rompe una implicación que hoy es invariante** y el
  consumidor pidió la contraria (§2.5).
- **Steelman del defensor:** «Paridad con el deny de roles, que es por permiso». **¿Me convence?** No. Entre permisos no
  hay implicación; entre relaciones con `includes`, sí.
- **Caso:** una matriz de paridad 3×3×3 (deny ∈ {viewer, editor, manager} × grant × relación preguntada) con la misma
  respuesta en los dos drivers. Esa matriz caza también el mutante que copia en `database` el predicado del allow
  (`relation IN expandDown(R)`), que invertiría la dirección.

### 🟠 6 · Los tres estados de `expiresAt` están invertidos para un deny: re-denegar sin fecha conserva la caducidad
- **Escenario:** existe un bloqueo temporal hasta el 31-dic. Ocurre un incidente y el admin llama a
  `deny(U, viewer, D)` sin `expiresAt`, con intención de bloquear para siempre. El invariante 10 dice «omitido preserva
  la vigente», así que el deny sigue caducando el 31-dic y el acceso vuelve solo, sin aviso.
- **Evidencia:** ✅ `src/expiry.ts:16-23` (`resolveGrantExpiry`). Con allows, preservar la caducidad es la opción
  conservadora; con denies es la arriesgada.
- **Steelman del defensor:** «Es la misma API que `relate`; el consumidor pasa `null`». **¿Me convence?** No. La forma
  natural de decir «bloquéalo» es no pasar fecha.
- **Caso:** «re-deny con `expiresAt` omitido sobre un deny temporal vigente ⇒ X». La X la decide el dueño, pero tiene
  que quedar escrita. Una opción es que en deny omitido valga «sin caducidad» o, al menos, que el resultado devuelva
  `previousExpiresAt`.

### 🟠 7 · La purga de openfga no tiene orden: puede morir dejando allows sin sus denies
- **Escenario:** `purgeObject(Nóminas)` lee todas las tuplas del objeto (allows y denies mezclados, en el orden que
  devuelva `Read`) y las borra en lotes de 100. Si muere tras borrar el lote que contenía los denies, quedan allows
  vivos sin su deny. El evento sale `indeterminate`, pero el store concede hasta que alguien reintente.
- **Evidencia:** ✅ `openfga_relations_driver.ts:773-800` (`#purgeByFilter`, en el orden de `Read`) y `:727-760`
  (`purgeSubject`: tipos × ortografías). Roles resolvió exactamente esto: `purgeScope` borra con un orden fijo y los
  denies al final, para que una purga a medias deje denies de MÁS (invariante 6). Relaciones no tiene orden porque hasta
  ahora todo eran allows. 🟡 Se activa en cuanto el deny vive en el mismo objeto, que es lo que propone todo el mundo.
- **Steelman del defensor:** «Se marca indeterminado y el consumidor reintenta». **¿Me convence?** No. Roles ya decidió
  que una purga a medias tiene que fallar del lado del deny, no del lado del reintento.
- **Caso:** un espía que falla tras el primer `deleteTuples` de una purga con allows y denies ⇒ no queda ningún allow
  sin su deny.

### 🟠 8 · Un alias del uuid de la partición evade el deny (reabre K1 en relaciones)
- **Escenario:** el share se creó por una ruta que escribe la partición sin guiones (`org|aaaa…32hex`) y el deny por la
  ruta de admin con guiones (`org|aaaa-…`). Un `check` con la ortografía sin guiones ve el allow y no el deny ⇒ `true`.
  En openfga son dos objetos distintos; en `database`, dos `partition_key` distintas. El atacante elige la ortografía:
  por ejemplo, la URL llega sin guiones y la comprobación de tenant del consumidor la acepta porque PG castea a `uuid`.
- **Evidencia:** ✅ el manager de relaciones «no canoniza particiones» (`src/relations/manager.ts:469-472`).
  `check`/`listObjects` comparan `partition_key` exacta (`database_relations_driver.ts:585-607`;
  `openfga_relations_driver.ts:488-499` compone el id con `scopeKey(partition)`). Solo las purgas barren las dos
  ortografías. Con allows el alias es fail-closed; con deny, fail-open. Para roles, «un alias del uuid jamás evade un
  deny» es un caso del contrato (invariante 17).
- **Steelman del defensor:** «Requiere escrituras inconsistentes del consumidor». **¿Me convence?** Solo para bajar a
  🟠. Es justo la clase de error que K1 decidió defender en el paquete.
- **Caso:** «un alias de la partición jamás evade un deny de relación», en los dos drivers. Arreglarlo es canonizar o
  rechazar con 422 la forma sin guiones en las ocho operaciones más las nuevas.

### 🟠 9 · `database` acepta como sujeto un userset de un tipo del consumidor y lo trata como inerte: un deny así no bloquea a nadie, en silencio
- **Escenario:** `deny({ object: { type: 'folder', id: 'f' }, relation: 'viewer' }, 'viewer', doc, p)`. El manager lo
  acepta, porque `#assertSubject` solo pide que el par esté declarado. En `database` se escribe, pero la CTE `principal`
  solo expande `group#member`, así que ningún sujeto «es» `folder:f#viewer` y el deny no bloquea a nadie. En `openfga` el
  modelo solo admite holders y `group#member`, así que es un 400 ⇒ 503 (ruidoso).
- **Evidencia:** ✅ `src/relations/manager.ts:623-631`, `database_relations_driver.ts:923-945` (la CTE filtra
  `object_type = 'group'` y `relation = 'member'`) y `openfga_facts.ts:987-996`. Hoy con allows es fail-closed y por eso
  nadie lo vio. Ningún test lo cubre (lo busqué y no hay caso).
- **Linaje:** L5, entrada inerte silenciosa, ahora por la API.
- **Steelman del defensor:** «Nadie escribiría eso». **¿Me convence?** No. La firma lo admite y el informe pide deny
  «a usersets».
- **Caso:** un userset de un tipo que no sea `group#member` ⇒ 422 en las operaciones de escritura de los dos drivers (y
  así también hay paridad).

### 🟠 10 · P2 sin partición: `Read` devuelve tuplas crudas y amplía el radio de un IDOR a todos los tenants
- **(a) Letra ≠ efecto.** `Read({ user, object: 'document:' })` devuelve tuplas ESCRITAS: incluye las caducadas, las que
  tienen deny directo y, sobre todo, las bloqueadas por un deny vía grupo, que un `Read` por usuario no puede ver. El
  usuario con `viewer` directo en Nóminas y denegado por `org#member` aparece en «Compartido conmigo», mientras `check`
  responde `false`. Si la UI pinta el título o la miniatura desde ese listado, se filtra información.
  ✅ `listSubjects` ya muestra que el filtro de caducidad es manual (`openfga_relations_driver.ts:566`); para denies vía
  grupo no hay filtro posible sin hacer `Check` por objeto.
- **(b) Radio.** Hoy `listObjects` exige partición y el consumidor pasa la de la sesión, así que un IDOR («`?userId=`»)
  se queda dentro de su tenant. P2 quita esa cota: un solo IDOR enumera lo que tiene cualquier usuario en todas las
  organizaciones. El paquete se protege de esto en las escrituras (`within` viene de la sesión) y en P2 no ofrece nada.
- **(c) Usersets.** Si P2 admite un userset como sujeto sin partición (pregunta 3 del informe), `group:finance#member`
  es ambiguo: los ids de grupo son cadenas del consumidor (`RELATION_ID_FORMAT`, no uuids), y una CTE `principal` sin
  `partition_key` casaría el `finance` de otro tenant. Eso sería 🔴 si se admite. La postura dice «sin usersets»: tiene
  que ser un 422 con caso, no una omisión.
- **Steelman del defensor:** «El sujeto lo pone el consumidor desde la sesión». **¿Me convence?** Para (b), en parte;
  para (a) y (c), no.
- **Casos:** «listObjectsForSubject solo devuelve objetos con `check` = true, incluido el deny vía grupo»; «un userset
  como sujeto ⇒ 422».

### 🟠 11 · L1 (F-05) en las cinco operaciones nuevas: la quinta iteración del linaje se cierra estructuralmente o no se cierra
- **Escenario:** `listObjectsForSubject(U, 'assignee', 'role_binding')` sin F-05 ⇒ `Read({ user: 'user:U', object:
  'role_binding:' })` ⇒ enumera todos los roles de U en todos los scopes por el puerto de relaciones. Es la fuga de
  alpha.3 (🟠 2, `listSubjects('assignee')`), ahora además sin partición. `checkMany` tiene que validar el par
  (tipo, relación) de CADA objeto, no solo el del primero. Un deny, `removeDeny` o `listDenies` sobre `role_binding`
  compone el id real `role_binding:<scopeKey>|<R>`. Hoy eso no escala (no existe `denied_assignee` ⇒ 400 ⇒ 503), pero
  entra en el store compartido.
- **Evidencia:** ✅ el historial de L1 en `linajes.md`: cada operación nueva se quedó fuera de F-05.
- **Steelman del defensor:** «Se copia `#assertDeclared` en cada método». **¿Me convence?** No. Es exactamente lo que
  `linajes.md` dice que no se hace a la tercera iteración (M8).
- **Guarda M7:** recorrer los métodos del prototipo de `RelationsManager` y de los dos drivers, y por cada uno un
  mutante que quite F-05 y deje la suite en rojo. Un método nuevo sin entrada en la tabla ⇒ rojo.

### 🟡 12 · Restar los denies en cliente con `ListObjects` deja pasar objetos denegados cuando el servidor corta sin avisar
- **Escenario:** si `listObjects` lista `viewer` y resta los denies obtenidos con OTRO `ListObjects` sobre la relación
  de deny, esa segunda lista se corta al tope o al deadline. El driver solo detecta el corte por el número de resultados
  (`raw.length >= max`, `openfga_relations_driver.ts:528`). Un corte por deadline con menos resultados que el tope pasa
  por completo, y el objeto denegado aparece.
- **Evidencia:** ✅ la detección es solo por conteo. ❓ El corte por deadline con resultados parciales lo afirman
  discusiones de la comunidad, no la documentación oficial (fuentes al final). **Resiste** si la exclusión la evalúa el
  servidor (`but not` en el modelo): el tope recorta allows, nunca hace aparecer un denegado.
- **Caso:** el que pide el informe contra el `:8103` con tope 3, más «los denies jamás se enumeran con `ListObjects`».

### 🟡 13 · P5 (reloj): con denies ninguna dirección del sesgo es segura, y el reloj inyectado gobierna también la barrera del freeze
- **Escenario:** un reloj adelantado ya era fail-closed (los allows caducan antes). Con denies que caducan, también es
  fail-open (los denies caducan antes). Además, `#assertNotFrozen` decide la vigencia del lease con ESE reloj
  (`src/relations/manager.ts:373`). Un helper «de testing» que mute el singleton del provider en vez de devolver una vista
  hace que el proceso vea vencidos los leases de las pasadas (15 s) y escriba durante un reconcile (L3). En
  `reconcileRelations`, `now` decide qué es `skipped.expired`: con `--prune` y el reloj adelantado se borran denies vivos.
- **Evidencia:** ✅ la barrera usa `options.clock`. ✅ `tests/clock.spec.ts` solo prohíbe `new Date()` y `Date.now()`:
  un método nuevo que llame a `systemClock()` en vez de a `this.#now()` pasa la guarda y mezcla dos relojes en una misma
  decisión.
- **Caso:** el helper devuelve una instancia nueva (como `withClock`) y nunca muta el singleton. Y un `now` por operación
  en `checkMany`/P2, con un caso que mezcle relojes.

### 🟡 14 · P4 `checkMany`: los cuatro sitios por donde puede esconderse un fallo
- Alinear por `correlationId` y no por posición: el SDK trocea y paraleliza. Roles ya lo hace
  (`openfga_driver.ts:244-280`, `802-825`): **se reutiliza, no se reimplementa**. Usar el id del objeto como
  `correlationId` rompe con duplicados (400 ⇒ 503) o, peor, deduplica.
- Un `error` por ítem ⇒ 503 total. Hoy un error leído como `false` es fail-closed; en cuanto P4 devuelva información de
  deny (ver 🔴 1), un error leído como «no denegado» es fail-open.
- `objects: []`: hay que decidir 422 o `[]` con un caso. Un `every([])` en el consumidor es verdad vacía.
- F-05 por objeto (🟠 11) y un solo `current_time` para todo el lote.

### 🟡 15 · P3: aunque no se almacene `meta`, la clave tiene que ser una y canónica
- `relationKey` sin `kind` hace que el allow y el deny de la misma tupla compartan meta. Con la ortografía del llamante,
  la meta queda huérfana tras una purga que barre las dos ortografías; si el consumidor inserta con «on conflict do
  nothing», un share nuevo hereda el «grantedBy» antiguo y la auditoría queda falseada.
- Hoy ya hay dos codificaciones de clave: `scopeKeyOf` en `src/relations/reconcile.ts:50` duplica `scopeKey` de
  `identity.ts:225`. Una tercera para `relationKey` es deriva garantizada.
- Si se acaba almacenando `meta` (la versión del informe): `listSubjects` devolvería `grantedBy`/`reason` a un invitado
  de otra organización (fuga de PII); el diff del reconcile no compara meta, así que «unchanged» con meta distinta (L8);
  «≤ 2 KB» medido con `JSON.stringify().length` son unidades UTF-16, no bytes; y en openfga, tupla + fila SQL son dos
  escrituras (L2). La postura del coordinador (no almacenar) **evita todo eso**.

### 🟡 16 · El informe espera un efecto que hoy no existe: «purgeScope de la partición dueña lo retira»
- `scopes.detached` purga hechos de ROLES, no relaciones. Las particiones de relaciones no están atadas al árbol
  (✅ README §Relations; `assertScope` es solo gramática). Las tuplas de una organización borrada siguen
  respondiendo `check` y P2 las haría visibles sin conocer la partición. Es letra ≠ efecto en el caso de prueba que pide
  el propio consumidor.

### ⚪ 17 · `denied_<rel>` no cabe con relaciones de 44 a 50 caracteres
- `RELATION_NAME_MAX = 50` (`define_relations_config.ts:23`) frente al tope de 50 de FGA más el prefijo `denied_`. Roles
  lo resolvió con `MAX_SLUG_LENGTH`. Un config válido en alpha.10 dejaría de publicar en 2.5 (breaking no anunciado).

### ⚪ 18 · «Patrón probado» está sobrevalorado
- El deny de roles es `denied_<P>: [<holders>] or denied_<P> from parent` (`openfga_facts.ts:37`): sin condición
  `not_expired` y sin userset. Las dos cosas que P1 necesita en la rama que se resta no las ejercita nadie hoy. ❓ No
  verifiqué cómo evalúa OpenFGA un `but not` cuya rama restada tiene una tupla condicional sin contexto. Si la omite,
  sería fail-open. El driver siempre manda `current_time`, pero cualquier camino nuevo (P2/P4) que lo olvide fallaría
  abierto en vez de cerrado.

---

## Linaje de cada pieza y la guarda M7 que evitaría el punto a punto

| Pieza | Linajes que toca | Guarda de superficie (M7) |
|---|---|---|
| P1 deny / removeDeny / listDenies | **L1** (5.ª+ iteración ⇒ estructural), **L2** (3 escrituras nuevas: puerta 1 en el manager + `#rejectTransaction` en el driver + `#writer` en `database`), **L3** (barrera del freeze en las escrituras nuevas), **L6/L8** (reconcile con `kind`), inv. 13 (renovación parcial), **L9 candidato** | (1) Tabla de operaciones × {F-05, puerta trx, freeze, `#write`/`#notify`} recorrida por reflexión sobre el prototipo, con un mutante por celda. (2) **Tabla de signos**: por cada fallo inyectado (2.º `Write` caído, purga cortada, reloj ±, alias de partición, pod con modelo viejo, contexto sin `current_time`, re-deny omitido), el deny sigue bloqueando. (3) Paridad 3×3×3 de `includes`. |
| P2 listObjectsForSubject | **L1**, **L8** (listado ≠ check), aislamiento de tenant | La misma tabla de L1; caso «todo objeto listado tiene `check` = true» (con deny vía grupo); 422 para userset; nunca `[]` sin capacidad. |
| P3 relationKey | (si se almacena) **L2** | Una sola función de clave, la misma que `tupleKey` del reconcile, con caso de identidad. |
| P4 checkMany | inv. 5 (503 por ítem), alineación L0.14 | Reutilizar `batchCheckAll`; mutante «por posición» ⇒ rojo; F-05 por objeto. |
| P5 reloj | **L3** (el lease se juzga con el reloj inyectado), K9 (un `now` por operación) | Ampliar `clock.spec`: cero `systemClock()` en métodos de decisión de `drivers/*relations*`, solo `this.#now`; el helper devuelve una vista. |

## Lo que intenté y NO se rompió
- **Un deny de relación leído como deny de rol:** no ocurre. `enumerateFacts`/`#listDeniesOf` de roles exigen el objeto
  `scope:` (`openfga_driver.ts:1397-1403`, `3252`) y `familyOfTuple` trata todo lo que no esté en
  `OWN_FACTS_OBJECT_TYPES` como ajeno (`:3536-3541`). `document:…#denied_viewer` no contamina roles.
- **Colisión de nombres:** `denied_` está reservado como prefijo de las relaciones del consumidor (`identity.ts:314`),
  así que el consumidor no puede declarar una relación que choque con la generada.
- **Deny con userset cruzado entre particiones:** imposible por el trigger (`relation_partition_trigger.ts`) y por la
  composición del id en openfga (`#subjectUser`).
- **Deny sobre `role_binding` sin F-05:** no escala. `denied_*` no existe en ese tipo ⇒ 400 ⇒ 503. Aun así, F-05 es
  obligatorio (🟠 11).
- **Renovación en `database`:** atómica (transacción interna, `database_relations_driver.ts:536`). No hay ventana.
- **Tope de `ListObjects` con exclusión evaluada en el servidor:** un objeto denegado no aparece; el tope solo recorta
  allows (fail-closed).
- **P2 en openfga:** `Read({ user, object: '<tipo>:' })` existe, es exhaustivo (sin tope) y ya lo usa `purgeSubject`.
- **`config.clock` llega al `RelationsManager`** (`providers/authz_provider.ts:59`): P5 es, en efecto, documentación.
  Su único riesgo es el helper (🟡 13).
- **P3 sin almacenamiento (postura del coordinador):** cierra toda la superficie de inyección, fuga y atomicidad de
  `meta`.

## Preguntas abiertas para el arquitecto (las que cambian el veredicto)
1. ¿La primitiva de cadena devuelve booleanos o un tri-estado (allow / deny / nada)? Con booleanos, 🔴 1 no tiene
   solución en el consumidor.
2. En FGA, ¿la relación pública (`viewer`) pasa a ser la efectiva, directamente asignable con `but not`, o se añade
   `viewer_eff`? Lo segundo deja abierto 🟠 4.
3. `includes`: ¿deny literal o deny que se propaga hacia las relaciones más fuertes? Lo decide el dueño, con la matriz
   3×3×3 como caso.
4. ¿Se admite deny sobre `group#member`? ¿Y usersets de tipos del consumidor (hoy inertes en `database` y 503 en
   `openfga`)?
5. ¿Se canonizan las particiones en relaciones? Si no, 🟠 8 queda declarado y no cerrado.
6. En `database`, ¿el deny va en la misma tabla con columna `kind`? El UNIQUE `authz_rel_tuple_uq`
   (`stubs/migration.stub:213-216`) no lleva `kind`: o choca con el allow, o el «¿ya existe?» de `relate` encuentra el
   allow y trata el deny como un no-op con éxito, que es fail-open silencioso. ¿O va como relación `denied_<rel>`?

Fuentes del ❓ de 🟡 12 (comunidad, no documentación oficial):
- [OpenFGA discussion #95](https://github.com/orgs/openfga/discussions/95)
- [OpenFGA discussion #105](https://github.com/orgs/openfga/discussions/105)
