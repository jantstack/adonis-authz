# Panel «tenencia» (7.º informe de COGNITIV) — analista técnico

Fecha: 2026-10-14 · versión analizada: `2.4.0-alpha.10` (working tree, solo lectura).
Leído: `cognitiv-informe-7-tenencia.md`, `panel-tenencia-coordinador.md`, `CLAUDE.md`, README §Relations (511-730) y
§Reading capabilities (858), `linajes.md`, `src/relations/{manager,reconcile,define_relations_config}.ts`,
`src/drivers/{database_relations_driver,openfga_relations_driver,openfga_facts}.ts`, `openfga_driver.ts` (deny de roles,
`batchCheckAll`), `stubs/migration.stub`, `providers/authz_provider.ts`, `src/testing/relations_contract.ts` (índice de casos).

**Medido, no supuesto.** El `:8101` no respondía; había un OpenFGA **v1.19.0** en `127.0.0.1:8090` (`openfga-dev`). Creé un
store temporal (`analista-tenencia-tmp`), publiqué el modelo de §1.4, escribí 6 lotes de tuplas, corrí `Check`,
`ListObjects`, `Read` y `BatchCheck`, y **borré el store** (HTTP 204). Los resultados citados como «medido» salen de ahí.

Leyenda: ✅ verificado en código o medido · 🟡 diseño/estimación · ❓ incógnita · ❌ no existe.

---

## 0 · Veredicto en una tabla

| # | COGNITIV | Coordinador | Analista | Por qué cambia |
|---|---|---|---|---|
| P1 | Deny, sube por `includes` | SÍ, **literal**, bump FGA | **SÍ condicionado**, **cierre ascendente** (no literal), **opt-in por tipo**, sin DDL en `database`, y **NO antes** de la guardia de superficie de L1/L2/L3 | El literal rompe la implicación `manager ⇒ viewer`; el precedente de roles no aplica (los permisos no tienen `includes`). El caso que lo motiva (Nóminas) se resuelve mejor con **ruptura de herencia en el consumidor** (§1.7) |
| P2 | `listObjectsForSubject` | SÍ, directas | **SÍ**, directas **+ includes resueltos**, solo holders, verificadas contra `check` si P1 existe; índice nuevo en `database` | `Read` FGA devuelve tuplas CRUDAS (sin includes, sin deny, sin caducidad): medido |
| P3 | `meta` por tupla | NO; exportar clave | **De acuerdo**; la clave es una función PURA exportada que también usa `reconcile` (un punto de paso) | Dual-write no atómico en `openfga`; el consumidor lo tendría igual |
| P4 | `checkMany` | SÍ, tope 50 | **SÍ**, pero **booleano NO basta en cuanto exista P1**: el evaluador de herencia necesita tri-estado `allow/deny/none` (`decideMany`) | Con booleanos un deny en un ancestro es indistinguible de «no hay grant» y el evaluador hereda del abuelo |
| P5 | Reloj documentado | SÍ, doc | **SÍ**, doc + `createTestClock()` en `/testing` + aviso: el reloj mueve también la lectura del lease del freeze | `manager.ts:373` usa el mismo `clock` para la barrera |

**Recomendación en una frase:** entregar ya P5 + P3-clave + P4-booleano (alpha.11, aditivo y sin tocar el modelo), después
P2, y P1 solo tras (a) la guardia de superficie que cierre L1/L2/L3 para operaciones nuevas y (b) la respuesta de COGNITIV
a «¿os basta romper la herencia en vuestro evaluador?».

---

## 1 · P1 · Deny en relaciones

### 1.1 Viabilidad verificada

- ✅ El patrón de exclusión ya existe en roles: `can_<P> = (<P> but not denied_<P>) and rooted`
  (`openfga_facts.ts:394-404`, comentario en `openfga_driver.ts:143,881`).
- ✅ Hoy una relación de objeto se genera como `{ union: [this, computed(include)…] }` (`openfga_facts.ts:1013`), con
  sujetos `[holders, group#member]` × `{sin condición, with not_expired}` (`openfga_facts.ts:990-998`).
- ✅ **Medido en v1.19**: un `difference` cuya `base` es `union{this, computed(editor)}` **se publica y evalúa** (la doc
  oficial solo muestra `[user] but not blocked`; la unión como base no estaba documentada — ahora está medida).
- ✅ El prefijo `denied_` ya está reservado para nombres de relación del consumidor (`identity.ts:314`,
  `define_relations_config.ts` lo rechaza; `openfga_facts.ts` §`assertRelationsConfigPublishable` también) ⇒ un
  `denied_<rel>` generado **no puede colisionar** con una relación declarada.
- ✅ Roles lee sus denies filtrando por objeto `scope:` (`openfga_driver.ts:1398-1403` y `:3252`) y su reconcile trata
  como AJENO todo tipo fuera de `OWN_FACTS_OBJECT_TYPES` (`:3501,3536`) ⇒ un `tenancy_node:…#denied_viewer` **no se lee
  como deny de roles** ni lo barre `authz:reconcile`. Los dos motores siguen sin responderse (invariante del README).
- ⚠️ Cota de nombre: relación ≤ 50 (`define_relations_config.ts:24`, `FGA_MAX_RELATION_NAME = 50` en
  `openfga_facts.ts:117`) y la columna `authz_relations.relation` es `varchar(50)` (`migration.stub:205`).
  `denied_` + 50 = 57 ⇒ **una relación denegable tiene que medir ≤ 43** (mismo truco que `MAX_SLUG_LENGTH` = 42 de roles,
  `identity.ts:340`). Solo para tipos con deny activado ⇒ no rompe a nadie.
- ❌ No existe purga por partición en relaciones (`grep purgePartition` = 0; las purgas son por objeto o por sujeto,
  `manager.ts:487,505`). El caso de COGNITIV *«purgeScope de la partición dueña lo retira»* (§3.3) presupone algo que no
  existe: `scopes.detached`/`purgeScope` es del motor de roles y no toca `authz_relations`.

### 1.2 La decisión que importa: deny literal o deny que sube por `includes`

Notación: `viewer includes editor` significa `viewer = this ∪ editor`, o sea **editor ⇒ viewer** (así lo compila
`openfga_facts.ts:1013`, y así lo lee `#expandDown` en `database_relations_driver.ts:432`). Sea `up*(T)` = las relaciones
que T implica (T incluida) y `down*(R)` = las que implican R.

**Steelman del literal (postura del coordinador).** Es la forma del deny de roles (uno por permiso), el modelo FGA es más
corto (`denied_<rel>` sin uniones), y permite expresar «degradar»: denegar `manager` sin tocar lo que `manager` aportaba a
`viewer`. Además es lo que COGNITIV ofrece como alternativa.

**Por qué lo rechazo:**

1. **Rompe la implicación que `includes` promete.** Con literal, `deny(alice, viewer, doc)` + `relate(alice, manager,
   doc)` da `check(manager)=true` y `check(viewer)=false`. Hoy la suite fija R-02 *«includes: relate(editor) ⇒
   check(viewer) true»* (`relations_contract.ts:555`): el literal convierte esa propiedad en «salvo si hay un deny», y todo
   consumidor que pinte «Editar» porque `check(editor)` es `true` asume que puede ver. Es incoherencia observable, no un
   matiz.
2. **El precedente de roles no decide nada.** En roles cada permiso es independiente (no hay `includes` entre permisos:
   `can_<P>` solo resta `denied_<P>`), así que «literal» y «cierre» coinciden. El argumento «como roles» es silencioso
   sobre la pregunta.
3. **«Degradar» no es un deny, es una escritura**: `unrelate(manager)` + `relate(editor)`. Con el cierre ascendente
   tampoco se pierde expresividad útil (ver la regla).

**Regla propuesta (cierre ascendente, «no puede ver ⇒ no puede nada»):**

> `check(s, R, o)` es `true` **si y solo si** existe una tupla de grant viva de relación `T ∈ down*(R)` que alcanza a `s`
> (directa o por `group#member`) **y no existe** un deny vivo que alcance a `s` sobre cualquier `Y ∈ up*(T)`.

Consecuencias (todas **medidas** en v1.19 con el modelo de §1.4):

| Escenario | `manager` | `editor` | `viewer` |
|---|---|---|---|
| alice: grant `manager`, deny `viewer` | false | false | false ✅ («deny en viewer bloquea al manager») |
| bob: grant `manager` + grant `viewer` directo, deny `manager` | false | false | **true** ✅ (el deny de manager solo anula grants que implican manager) |
| carol: miembro de `g`; `g#member` grant `viewer`; deny directo a carol | — | — | false ✅ |
| dave: grant directo `viewer`; deny a `g#member`; dave ∈ g | — | — | false ✅ |
| erin: grant `viewer`; deny caducado (2020) | — | — | true ✅ · deny futuro (2099) ⇒ false ✅ |

Y `Check(user, denied_<R>, o)` responde «¿hay un deny que me afecta para R?» (medido: `alice denied_manager` = true por
el deny en `viewer`; `dave denied_manager` = true por el deny al grupo) ⇒ **el tri-estado de P4 es consultable** (§4).

### 1.3 Cómo lo resuelve el CTE de `database` (sin una línea de DDL)

**Codificación: el deny es una fila de `authz_relations` con `relation = 'denied_<rel>'`.** Misma tabla, mismo UNIQUE
`authz_rel_tuple_uq` (`migration.stub:213-216`), mismo trigger de partición, mismo codec de `expires_at`.

Por qué esta codificación y no una columna `kind`/`effect` o una tabla `authz_relation_denies` (la de roles):

- **Fail-closed por construcción.** Todas las lecturas actuales filtran `relation IN (#expandDown(R))`
  (`database_relations_driver.ts:597-606, 622-636`) o `relation = ?` (`listSubjects`, `:660-668`); `denied_*` nunca está en
  esos conjuntos porque el consumidor no puede declarar ese prefijo. Una columna `kind` obligaría a añadir
  `AND kind='allow'` en **cada** consulta existente, y la que se olvide lee un deny **como grant**: escalada. Es
  exactamente el modo de fallo del linaje L1 («la operación siguiente»).
- **Las purgas lo borran gratis**: `purgeObject` borra por objeto sin filtrar relación (`:746-768`) y `purgeSubject` por
  sujeto (`:771-795`). La promesa 2.3.6 de COGNITIV sale sin código.
- **`unrelate(viewer)` no toca el deny** (filtra `relation = 'viewer'`, `:539-570`) y `removeDeny` no toca el grant.
- **Paridad textual con FGA**: la tupla se llama igual en los dos drivers (`denied_viewer`), y la traducción a
  `{ kind: 'deny', relation: 'viewer' }` vive en UN sitio por driver (enumerate).

`check` (sigue siendo **una** consulta, `singleCheckRelations` intacto): la CTE `principal` de hoy (`:923-950`) + un
SELECT `DISTINCT r.relation` sobre el objeto con `relation IN (down*(R) ∪ { denied_Y : Y ∈ ⋃ up*(T), T ∈ down*(R) })` y
vigencia; en JS: `allowed = ∃ T ∈ filas ∩ down*(R) tal que up*(T) ∩ denegadas = ∅`. Los conjuntos `up*`/`down*` son
estáticos por config (se precalculan en el constructor, como `#expandDown` pero en los dos sentidos).
`listObjects`: misma consulta devolviendo pares `(object_uuid, relation)` y la misma regla por objeto. Exhaustiva como hoy.
`membersOf`: la CTE de `:680-743` tiene que devolver `(holder, relation)` en las cuatro ramas y calcular también los
holders alcanzados por usersets **denegados**; la regla se aplica por holder. Es la pieza más cara de `database`.

### 1.4 Modelo FGA generado (opt-in por tipo)

Para un tipo con `deny: true` (por cada relación `X` con `includes: [I…]`):

```
define X:         ([holders…, group#member, …with not_expired] or I1 or I2…) but not denied_X
define denied_X:  [holders…, group#member, …with not_expired] or denied_P1 or denied_P2…
                  # P = cada relación que INCLUYE a X (el grafo de includes, invertido)
```

Ejemplo `viewer ⊇ editor ⊇ manager`: `denied_editor = this or denied_viewer`, `denied_manager = this or denied_editor`.
Coste estructural: una relación más por relación declarada y una arista `computed` por arista de `includes`; cero tuplas.
Se queda **anidado dentro de la propia relación** (no un `can_viewer` paralelo como sugiere COGNITIV §2.6), y eso tiene
tres ventajas medidas/verificadas:

- `check`/`listObjects`/`listSubjects` siguen preguntando por `viewer`: **cero cambios en el call-site** ni en los ids.
- **Las tuplas existentes siguen valiendo**: el `this` sigue en la base del `difference`; no hay migración de tuplas, solo
  republicar el modelo (`openfga:provision` / pin del `modelId`).
- Con la relación anidada, la regla de §1.2 sale sola (lo demostré arriba: un camino `R → … → T` queda cortado en el nodo
  `X` si hay deny en algún `Y ⊇ X`, y eso equivale a `Y ∈ up*(T)`).

Sin `deny: true` el modelo del tipo es **byte a byte el de hoy** ⇒ nadie que no lo active paga bump ni bytes.

**Lo que hay que medir antes de publicar (❓):** (a) bytes del modelo fusionado con `factsModelBytes` — estimo 🟡 que un
tipo de 3 relaciones pasa de ≈1,0 a ≈2,0 «permisos equivalentes» (la metadata de `denied_X` repite la de `X`); (b) latencia
de `Check`/`ListObjects` con exclusión (la doc de OpenFGA avisa que `but not` es más caro); (c) si `includes` puede ser
cíclico: `defineRelationsConfig` rechaza la auto-inclusión pero **no** veo comprobación de ciclos `A⊇B⊇A`
(`define_relations_config.ts`, bloque de `includes`); con `denied_*` invertido el ciclo también se invierte — hay que
fijar qué hace el servidor y, si hace falta, rechazar ciclos en la config.

### 1.5 Contrato y efectos laterales

```ts
deny(subject, relation, object, partition, options?: RelationWriteOptions): Promise<void>
removeDeny(subject, relation, object, partition, options?: RelationWriteOptions): Promise<void>
listDenies(relation, object, partition, page?): Promise<RelationSubjectsPage>   // hechos DIRECTOS, misma forma que listSubjects
```
- `listDenies` con la **misma firma que `listSubjects`** (relación incluida). La de COGNITIV (`listDenies(object, …)`)
  devuelve sujetos sin relación: no sirve en un tipo con tres relaciones denegables.
- Manager: el mismo embudo que `relate` (`manager.ts:378-401`): puerta 1 `{transaction}` → freeze → F-05 estricta →
  **`assertRelationDenyable`** (tipo con `deny: true`, si no 422 nuevo `E_AUTHZ_RELATION_NOT_DENYABLE`) → id → actor →
  scope → sujeto → `expiresAt` → `assertWrite` → `#write` (invariante 13) → `#notify`.
- Evento: el campo publicado es **`operation`**, no `action` (`types.ts:1944`): `operation: 'deny' | 'removeDeny'`. Y
  `RelationRef.operation` (`types.ts:1910`, lo que recibe `assertWrite`) se ensancha a `'relate'|'unrelate'|'deny'|
  'removeDeny'` — **cambio de tipo publicado**: un `switch` exhaustivo del consumidor deja de compilar. Anunciarlo.
- `database`: `{transaction}` por `#writer` como `relate` (L2). `openfga`: `#rejectTransaction` primera línea (L2/L-5).
- Idempotencia y tres estados de `expiresAt`: el mismo `resolveGrantExpiry` (renovar = delete+insert / delete+write).
- `listSubjects` **no** resta denies: devuelve hechos directos (invariante 7) — **paridad con roles**, cuyo `listSubjects`
  tampoco resta denies, mientras que `listScopes` sí (`contract.ts:1792`). Traducción: lo que enumera **hechos**
  (`listSubjects`, `listDenies`, `enumerateRelations`) no resta; lo que enumera **acceso efectivo** (`listObjects`,
  `membersOf`, P2) sí. Esto contradice COGNITIV §2.3.4 a propósito y se fija con caso con nombre.
- `enumerateRelations`/`enumerateRelationsMany`: `RelationTuple` gana `kind?: 'deny'` (opcional ⇒ un driver de terceros
  que no lo emita sigue compilando). La traducción `denied_X ↔ {kind:'deny', relation:X}` en `#enumerateRows`
  (`database_relations_driver.ts:862`) y `#sweep` (`openfga_relations_driver.ts:658`).
- **`reconcile` (lo más delicado):** hoy `tupleKey` (`reconcile.ts:54`) y `relateOrSkip` (`:440`) no conocen `kind`. Sin
  cambios, un deny migraría como `to.relate(s, 'denied_viewer', …)` ⇒ 422 F-05 ⇒ **`skipped.undeclared`**, y con
  `--prune` el destino **perdería sus denies**: una ESCALADA fabricada con el verificador «contando». Requisitos:
  (1) `kind` en la clave; (2) despachar a `to.deny`; (3) **denies primero, grants después** al escribir, y **grants primero,
  denies los últimos** al podar (la regla de `purgeScope` de roles: a medias, denies de MÁS); (4) destino sin capacidad de
  deny y origen con denies ⇒ **500 antes de escribir**, nunca `skipped` (perder un deny no es una pérdida declarable);
  (5) `massDelete` (`reconcile.ts:426`) cuenta solo grants utilizables; (6) el censo de
  `relations_reconcile_contract.ts` busca los denies uno a uno con `listDenies`.
- Capacidad nueva `relationDenies` (par `whenTrue`/`whenFalse`); `RELATIONS_DRIVER_CAPABILITY_KEYS` (`types.ts:2102`) en
  el mismo commit (si no, `capabilities()` devuelve `undefined`, que el caso D-3 caza).

### 1.6 Coste y riesgo

🟡 **30–50 h** + rondas de auditor (el historial de alpha.3/alpha.10 sugiere +50 % en cierres). Riesgo **alto**: son 3
escrituras/lecturas nuevas que tienen que pasar por F-05, freeze y `{transaction}` — los tres linajes abiertos (L1, L2, L3) —
más el camino de `reconcile`. Casos estimados: 14–16 + el par de capacidad.

### 1.7 Alternativa más simple — y el agujero del ejemplo de COGNITIV

El caso motivador es *«todo el departamento ve Finanzas, pero nadie ve Finanzas/Nóminas salvo el owner»*. Tres problemas:

1. **«Salvo el owner» no se puede expresar con «deny gana»**: el owner es miembro de `organizations:<uuid>#member`; un deny a
   ese grupo le bloquea también a él (fila *dave* de §1.2). O el evaluador del consumidor exime al owner antes de preguntar,
   o la semántica no es «deny gana».
2. **Un deny a `org#member` no cubre a los invitados de otra organización** (nunca son miembros, informe §1). Invitado con
   `viewer` en `Finanzas` (cross-org) + deny a `org#member` en `Nóminas` ⇒ en `Nóminas` el motor dice «nada» para él ⇒ el
   evaluador de COGNITIV **hereda de `Finanzas` y le deja ver Nóminas**. Fuga. Solo la cierra un comodín `*` en deny, que
   a su vez bloquea al owner (punto 1).
3. **Lo que el ejemplo pide es romper la herencia**, y la herencia vive en el consumidor (informe §1: «la resuelve un
   evaluador puro del consumidor con `ancestor_uuids`»). Un flag `inherits = false` en `tenancy_nodes` hace que Nóminas
   solo conceda lo que tenga directamente (el owner): cubre owner, departamento e invitados, **sin cambiar el paquete**.
   Es el modelo de «carpeta de acceso limitado» de Drive/SharePoint.

Deny en el motor sigue siendo genérico y útil para «este grupo sí, esta persona del grupo no» sobre un mismo objeto.
Pero **no es camino crítico de la F0 de la tenencia** si COGNITIV rompe la herencia en su evaluador.

### 1.8 ¿Amarra el paquete a COGNITIV?

No, si se mantiene: opt-in por tipo, semántica definida por el grafo de `includes` (no por «carpeta»), sin comodín, y sin
nada de herencia objeto→objeto. Lo que **sí** amarraría: el comodín «solo para deny» (una asimetría hecha a medida) y
cualquier noción de «owner» en el motor.

---

## 2 · P2 · `listObjectsForSubject` sin partición

### 2.1 Viabilidad verificada

- ✅ La partición va en el id (`openfga_relations_driver.ts` `#objectId`, `#parseObjectId:347`), y `purgeSubject` ya usa
  `Read({ user, object: '<type>:' })` (`:727-755`).
- ✅ **Documentado y medido**: el `Read` de OpenFGA admite **user + relation + object type** (patrón 2 de la doc
  «Relationship Queries») y **user + object type** (patrón 4). Medido: `Read({user:'user:frank', relation:'viewer',
  object:'node:'})` devuelve `node:p1|x` **y** `node:p3|z` — tuplas de varias particiones en una llamada. Sin user
  (`relation + node:`) es **400** `validation_error` (medido).
- ⚠️ **Pero `Read` devuelve tuplas CRUDAS** (medido): con `relation: 'viewer'` no devuelve el `editor` de `node:p2|y`
  (los `includes` no se expanden), **sí** devuelve `node:p3|z` aunque frank tiene un deny vivo ahí, y no evalúa la
  condición de caducidad (trae `condition`, como ya asume `#readAll`, `:815-860`). La postura del coordinador («`Read`
  por sujeto + tipo ⇒ P2 directo factible») es correcta en lo que trae y **omite lo que hay que hacer después**.
- ✅ Dato lateral medido: **`ListObjects` ya es multi-partición en el servidor** — `ListObjects(frank, viewer, node)` devolvió
  `p1|x` y `p2|y` (con `includes`, deny y caducidad resueltos); el driver filtra la partición DESPUÉS
  (`openfga_relations_driver.ts:512-541`). Es una vía alternativa que descarto en §2.4.
- ✅ `database`: hoy el índice es `(partition_key, subject_type, subject_uuid)` (`migration.stub:218`) — con
  `partition_key` en cabeza, una consulta sin partición **no lo usa**: recorre la tabla. Hace falta un índice nuevo.

### 2.2 Diseño

```ts
listObjectsForSubject(subject: SubjectRef, relation: string, objectType: string,
                      page?: RelationPage, options?: { partitions?: ScopeRef[] })
  : Promise<{ objects: Array<{ object: RelObject; partition: ScopeRef }>; cursor?: string }>
```
- **Sujeto: solo holders.** Un userset vive en una partición (trigger en `database`, id en `openfga`); «en cualquier
  partición» no tiene sentido para él ⇒ 422.
- **Semántica:** objetos donde el holder tiene una tupla **directa** viva de alguna `T ∈ down*(R)` (los `includes` SÍ se
  resuelven: si no, «compartido conmigo como editor» no saldría al pedir `viewer`, y `listObjects` sí lo resuelve — sería
  letra ≠ efecto, L8) y, si P1 existe, **verificada por `check`**. Lo que llega solo por grupos **no** sale, y el nombre o
  el README lo dicen.
- **Por qué basta para COGNITIV**: los invitados cross-org son siempre `users:<uuid>` directos (informe §1); lo de su
  propia organización lo da `listObjects(…, partición propia)`, que sí resuelve grupos. «Compartido conmigo» =
  `listObjects(propia) ∪ listObjectsForSubject(…, partitions ≠ propia)`.
- `database`: `SELECT DISTINCT partition_key, object_uuid … WHERE subject_type=? AND subject_uuid=? AND
  COALESCE(subject_relation,'')='' AND object_type=? AND relation IN (down*(R)) AND vigente ORDER BY partition_key,
  object_uuid LIMIT n+1`, **cursor por `(partition_key, object_uuid)`, no por `uuid`**: renovar una caducidad cambia el
  `uuid` (delete+insert, `:500-512`) y un cursor por `uuid` devolvería el mismo objeto dos veces. Índice nuevo
  `authz_rel_subject_any_idx (subject_type, subject_uuid, object_type)` ⇒ stub + receta de upgrade **ejecutada** en los tres
  motores (es la costumbre: `upgrade_recipe.spec`). Sin el índice es correcto pero O(tabla).
- `openfga`: `#readAll({ user, object: '<type>:' })` **sin** filtro de relación (una sola lectura cubre todas las `T` y,
  con P1, también los `denied_*` directos), filtro en cliente por `down*(R)`, caducidad con el reloj del driver (como
  `listSubjects`, `:563-570`), parseo de partición desde la derecha, orden por `(partitionKey, objectUuid)` y paginación
  **en memoria** con cursor opaco. Leer todo cada página es O(tuplas directas del usuario en ese tipo): pequeño para un
  usuario, y es lo único que da «exhaustivo y sin duplicados» (un objeto con `viewer` y `editor` cae en páginas distintas
  del `Read`, que ordena por ULID de escritura — se ve en el `continuation_token` medido).
- **Deny (si P1):** el `Read` del usuario no ve los denies que le llegan por un grupo ⇒ verificar los candidatos de la
  página con `batchCheck` (FGA) o con la consulta de §1.3 (SQL), agrupando por partición. Una página puede traer menos de
  `limit`; el fin es «sin cursor». Un `error` por ítem ⇒ 503 entero.
- `options.partitions`: filtro con efecto medible o 422 (L5: ninguna entrada inerte). `[]` ⇒ 500 (precedente
  `enumerateRelationsMany`, `manager.ts:590-593`).
- Capacidad `listObjectsForSubject` (par); sin ella, 500 `E_AUTHZ_UNSUPPORTED` nombrándola (precedente `membersOf`,
  `manager.ts:529-553`), nunca `[]`.
- **Seguridad (escrito en README):** el resultado enseña claves de partición de OTROS tenants (las que compartieron con
  él). El `subject` sale de la SESIÓN, nunca del cuerpo: si no, es un oráculo de enumeración cross-tenant. Misma doctrina que
  `within`.
- `enumerateRelations`/reconcile/purgas/eventos: no cambian (es una lectura). F-05: el `objectType` pasa por
  `assertObjectTypeDeclared` + relación estricta, en manager **y** driver (L1).

### 2.3 Coste y riesgo
🟡 **14–22 h** (dos drivers, cursor, índice + receta en tres motores, par de capacidad, 6–8 casos, Limits del README).
Riesgo **medio**: paginación (duplicados/huecos), ortografías de partición (dos ortografías del mismo uuid son dos claves,
igual que en `enumerateRelationsMany`), fuga por mal uso del `subject`.

### 2.4 Alternativas descartadas
- **`ListObjects` sin filtro de partición (FGA):** resuelve grupos, deny y caducidad en el servidor, pero **no pagina**,
  trunca al tope (1000) y —según discusiones de la comunidad, 🟡 no verificado en la doc oficial— también devuelve
  resultados parciales al vencer su deadline (3 s por defecto) **sin señal**; la heurística `raw.length >= tope`
  (`:528`) no lo detecta. Y en `database` exigiría una CTE de grupos multi-partición para la paridad. Descartada.
- **Índice local en el consumidor:** lo que COGNITIV quiere evitar con razón (deriva con caducidades y purgas).

### 2.5 ¿Amarra?
No: «qué me han compartido en cualquier tenant» es genérico de cualquier multi-tenant con compartición cross-tenant.

---

## 3 · P3 · Metadatos por tupla

### 3.1 Viabilidad
- ✅ `database`: trivial (una columna JSON). ✅ `openfga`: el store no tiene metadatos por tupla ⇒ tabla SQL auxiliar ⇒
  dos escrituras no atómicas; el driver **rechaza `{transaction}`** (`transactionalWrites: false`,
  `openfga_relations_driver.ts:185-202`), así que tampoco puede inscribir la fila auxiliar en la trx del consumidor.
- ✅ `relate` devuelve `void` en el puerto; cambiarlo a «devuelve id» es cambio de firma del puerto (drivers de terceros).
  Y no hay id estable que devolver: `database` cambia el `uuid` al renovar (`:500-512`), FGA no tiene id.

### 3.2 Decisión: de acuerdo con el coordinador, con dos matices
**Steelman de guardarlo:** en `database` sería atómico y gratis. **Por qué no:** COGNITIV corre los dos drivers en CI; un
`capabilities.relationMeta` que es `true` en uno y `false` en otro le obliga a mantener SU tabla igualmente ⇒ dos caminos
de código para lo mismo. Y meter el dual-write dentro del paquete no lo vuelve atómico, solo lo esconde (L2).

Lo que sí:
- **`relationTupleKey(subject, relation, object, partition, kind?)` pura, exportada desde la raíz** (sin SDK), y que
  **`reconcile.ts` use la misma** en vez de su `tupleKey` privado (`reconcile.ts:54`): un solo punto de paso para «qué es la
  misma tupla». Inyectiva porque ningún id admite `| # : @` (gramática `RELATION_ID_FORMAT`,
  `database_relations_driver.ts:84`). Incluye `kind` desde el primer día (si P1 llega, un grant y un deny del mismo sujeto
  son tuplas distintas).
- **Límite a escribir:** la clave es función de los argumentos **tal como llegan**; el manager no canoniza particiones
  (`manager.ts`, docblock de las purgas) y dos ortografías del uuid dan dos claves. El consumidor usa una ortografía.
- La tabla del consumidor se mantiene con `onRelationWrite` (las purgas notifican objeto/sujeto sin conteo,
  `manager.ts:487-523`) y filtrando por `listSubjects` para no enseñar meta de tuplas caducadas.

### 3.3 Coste / riesgo / amarre
🟡 **2–4 h**, riesgo bajo. No amarra (es una función de identidad).

---

## 4 · P4 · `checkMany`

### 4.1 Viabilidad
- ✅ Roles ya tiene `batchCheckAll` + `correlateBatchResults` (`openfga_driver.ts:244-283, 802-829`): alinea por
  `correlationId`, un `error` por ítem ⇒ 503. El driver de **relaciones** no lo tiene: hay que exportar/reutilizar esas
  dos piezas (mismo subpath, sin problema de pureza).
- ✅ SDK 0.9.6 `batchCheck` trocea a 50 (`ClientMaxBatchSize`) y paraleliza; `FGA_MAX_BATCH_CHECK = 50`
  (`openfga_facts.ts:208`). **Medido**: el servidor acepta dos ítems idénticos con distinto `correlation_id`.
- ✅ Precedente de duplicados: `factsAuthorizeMany` deduplica por clave y responde por posición
  (`openfga_driver.ts:944-966`).
- `database`: una consulta con la CTE `principal` + `object_uuid IN (…)` devolviendo `(object_uuid, relation)`.

### 4.2 Diseño
```ts
checkMany(subject, relation, objects: RelObject[], partition): Promise<boolean[]>
```
Una partición por llamada; `[]` ⇒ `[]` con cero llamadas; > 50 ⇒ 422 (cota en la tabla Limits atada a la constante);
duplicados permitidos, deduplicados dentro, respuesta por posición; F-05 + `assertObjectId` por objeto ANTES del driver;
un solo `now` para todo el lote (precedente K9); cualquier fallo ⇒ 503 entero. Método opcional del puerto: si el driver
no lo trae, el manager **compone** con N `check` (precedente `authorizeMany`, «delega o compone»), así que no hace falta
capacidad.

**El ataque (vale para COGNITIV y para el coordinador):** en cuanto exista P1, **un booleano no le sirve al evaluador de
herencia**. Para `Finanzas/Nóminas/informe.pdf` con grant en `Finanzas` y deny en `Nóminas`, `checkMany` da
`[false, false, true]`: el `false` de Nóminas es igual que «no hay nada», el evaluador sube y concede por `Finanzas`. La
regla «deny gana» de COGNITIV §7 necesita **ver** el deny. Por eso, junto a P1 y no antes:

```ts
decideMany(subject, relation, objects, partition): Promise<Array<'allow' | 'deny' | 'none'>>
```
FGA: dos ítems por objeto (`R` y `denied_R`) en el mismo `batchCheck` (20 nodos ⇒ 40 ítems ⇒ una request); `denied_R` ya
incluye el cierre ascendente (medido, §1.2). SQL: la misma consulta de `check` por objeto. `deny` = `denied_R`; `allow` =
`check` sin deny; `none` = el resto. Sin P1, `decideMany` no existe y `checkMany` booleano es exacto.

### 4.3 Coste / riesgo / amarre
🟡 `checkMany`: **6–10 h** (SQL nuevo, port del alineado, 6 casos: equivalencia con N `check` incluidos `includes`/
userset/caducidad, 503 por ítem, 422 > 50, orden, duplicados, `[]`). `decideMany`: +4–6 h dentro de P1. Riesgo bajo.
No amarra: es el `authorizeMany` del puerto de relaciones.

---

## 5 · P5 · Reloj

- ✅ El provider pasa `config.clock` al `RelationsManager` (`authz_provider.ts:59`) y el manager lo aplica con `withClock`
  (`manager.ts`, constructor). Es documentación… **y un matiz**: el mismo `clock` decide la barrera del freeze
  (`manager.ts:373`, `nowMs` de `assertNotFrozenRow`). Un reloj de test adelantado a 2099 hace que un lease vivo se lea
  como caducado. Hay que escribirlo.
- Diseño: `createTestClock(start)` en `/testing` ⇒ `{ now: () => Date, set(d), advance(ms) }` (una función estable que lee
  un valor mutable: no hay que reconstruir el manager), y la receta en README «Testing expiry from your app»:
  `clock: app.inTest ? testClock.now : undefined` en `config/authorization.ts`. Un caso: T−1 ms concede, T no, a través del
  provider real. Lo de «propagar a P2/P4» sale solo: todo lee `this.#now()` del driver.
- 🟡 **2–4 h**, riesgo bajo, no amarra.

---

## 6 · Las 5 preguntas de §9 de COGNITIV

1. **¿Deny literal o sube por `includes`?** **Sube** (cierre ascendente, regla de §1.2): un deny en `Y` anula todo grant
   `T` que implique `Y`. Fijado con dos casos con nombre: *«un deny en viewer bloquea al manager»* y *«un deny en manager no
   quita el viewer directo»*. Razón: es la única semántica que conserva `check(manager) ⇒ check(viewer)`; medida en v1.19
   con el modelo anidado; y en SQL es un cálculo estático sobre el grafo de `includes`.
2. **¿Comodín `*` solo para deny?** **No en v1.** Con «deny gana», `*` es «objeto cerrado para todos, owner incluido»: no
   es lo que pide el ejemplo. Pero ojo: sin `*`, un deny a `org#member` no cubre a invitados cross-org (§1.7.2). Si eso
   importa, la respuesta correcta es romper la herencia en el evaluador, no el comodín.
3. **¿Usersets en `listObjectsForSubject`?** **Solo tuplas directas del holder, con `includes` resueltos.** Los usersets son
   de una partición; la vía «por grupos en cualquier tenant» exige recorrer membresías multi-partición (FGA: un `Read` por
   grupo). Para COGNITIV basta (§2.2).
4. **¿`meta` en `openfga` o `capabilities.relationMeta=false` + id estable?** Ninguna de las dos: **sin `meta` en el
   paquete** y **sin cambiar el retorno de `relate`**; `relationTupleKey()` pura y determinista, que es mejor que un id
   (no cambia al renovar y no depende del driver).
5. **Tope y duplicados en P4.** Tope **50 objetos ⇒ 422**; duplicados **permitidos**, se deduplican dentro, respuesta por
   posición; `[]` ⇒ `[]` sin llamadas; un error en un ítem ⇒ 503 para todos.

## 7 · Las preguntas del coordinador

**¿Deny de relaciones y deny de roles comparten algo?** Nada de código, tabla ni familia evaluable. Comparten: el prefijo
reservado `denied_` (que es justo lo que hace segura la codificación, `identity.ts:314`), los helpers puros
(`resolveGrantExpiry`, `sameInstant`) y la forma del evento. Verificado que no se cruzan en FGA (roles filtra por `scope:`,
`openfga_driver.ts:1398,3252`; reconcile de roles trata lo demás como ajeno, `:3536`). Semánticas distintas: el de roles
baja por el árbol (`denied_<P> from parent`), el de relaciones sube por `includes` y no conoce árbol.

**Linajes por pieza y punto de paso único:**

| Pieza | Linaje | Riesgo concreto | Punto de paso único propuesto |
|---|---|---|---|
| `deny`/`removeDeny`/`listDenies`, `checkMany`/`decideMany`, `listObjectsForSubject` | **L1** (F-05, 4+ iteraciones, punto único «pendiente») | Cinco operaciones nuevas = «la operación siguiente» | **Antes de P1**: guardia de superficie que recorra por reflexión los métodos de `RelationsManager` y de cada driver y exija un caso «tipo `role_binding` ⇒ 422 con cero llamadas» por método; un método sin fila ⇒ rojo (M7) |
| `deny`/`removeDeny` | **L2** (`{transaction}`) | Escritura nueva que no pasa por `#writer`/`#rejectTransaction` | La misma guardia, con la columna «`{transaction}` en driver `false` ⇒ 500 sin llamadas» |
| `deny`/`removeDeny` | **L3** (freeze) | Escritura nueva sin `#assertNotFrozen` | La misma guardia, columna «congelado ⇒ 503» |
| `reconcile` con `kind` | candidato nuevo «**un deny que no llega es una escalada**» (ya visto en roles 3b-8 · A2 y 3b-6) | Deny contado como `undeclared` y podado | `relationTupleKey` (con `kind`) + 500 si el destino no sabe deny |
| P2 «directas» | **L8** (letra ≠ efecto) | Que «compartido conmigo» prometa lo que no da (grupos) | El nombre/README + caso que fija que un grant por grupo NO sale |
| `options.partitions` (P2) | **L5** | Filtro ignorado en silencio | Rechazo explícito de entradas inválidas + caso de efecto |

## 8 · Contra la postura del coordinador, punto por punto

| Afirmación | Veredicto |
|---|---|
| «Roles ya hace deny con `but not`: patrón probado para P1» | ✅ el operador, sí. ❌ la forma: roles resta en una relación PARALELA (`can_<P>`); relaciones necesita restar **dentro** de la relación para que `includes` siga siendo coherente. Esa forma no estaba probada; ahora está medida (v1.19). |
| «Deny literal, como roles por permiso» | ❌ (§1.2). El precedente no aplica: los permisos no tienen `includes`. |
| «Sin comodín» | ✅, pero el porqué es otro: el comodín no arregla «salvo el owner» y el caso se resuelve sin deny (§1.7). |
| «Bump de modelo FGA» | 🟡 solo para quien active `deny` en un tipo; sin opt-in el modelo es idéntico. Las tuplas no migran. |
| «`Read` por sujeto+tipo ⇒ P2 factible» | ✅ en lo que trae (medido) · ⚠️ trae tuplas crudas: sin `includes`, con denegadas, sin caducidad aplicada. El trabajo está en el filtro posterior. |
| «P5 es documentación» | ✅ + el matiz del freeze (`manager.ts:373`). |
| «`batchCheck` ya existe: P4 pequeño» | ✅ en FGA (hay que portarlo al driver de relaciones); ❌ «suficiente»: con P1 hace falta tri-estado. |
| «P3: dual-write no atómico (L2)» | ✅ de acuerdo. Añado: que `reconcile` use la misma función de clave. |
| «Versión 2.5 (minor: `list*` omiten denegados)» | ⚠️ El cambio observable solo aparece si escribes un deny (opt-in). Lo que de verdad cambia para todos es TIPOS: `RelationRef.operation` (`types.ts:1910`) y `RelationTuple.kind`. |
| «Orden P5 → P4 → P1 → P2 → P3» | ❌ P3-clave cuesta 2–4 h y va en el primer lote; P1 no puede ir antes de la guardia de L1/L2/L3 ni de la respuesta de COGNITIV sobre la ruptura de herencia. |
| (no lo dice) | El caso de COGNITIV *«purgeScope de la partición dueña lo retira»* presupone una purga por partición que **no existe** (❌). Hay que decir que no o diseñarla aparte. |

## 9 · Plan por lotes

| Lote | Contenido | Resultado demostrable | Versión | Horas 🟡 |
|---|---|---|---|---|
| **A** | P5 (`createTestClock` + README + caso por el provider) · P3-clave (`relationTupleKey` + `reconcile` la usa) · P4 `checkMany` booleano (dos drivers + 6 casos) | COGNITIV puede escribir su evaluador de cadena con una llamada y probar caducidades al borde | `2.4.0-alpha.11` (aditivo; modelo FGA intacto) | 10–18 |
| **B** | Guardia de superficie de relaciones: F-05 / `{transaction}` / freeze por reflexión sobre los métodos del puerto, con mutantes | Ningún método nuevo puede entrar sin sus tres barreras (cierra L1 estructuralmente en relaciones) | `alpha.11` o `alpha.12` | 6–10 |
| **C** | P2 directo (+ índice, receta ejecutada, par de capacidad, nota de seguridad) | «Compartido conmigo» exhaustivo y paginado en los dos drivers | `2.4.0-alpha.12` | 14–22 |
| **D** | P1 opt-in (cierre ascendente) + `decideMany` + P2 filtrado por deny + reconcile con `kind` | Deny en relaciones con la misma suite en los dos drivers | `2.5.0-alpha.1` (cambio de tipos publicados + modelo FGA para quien lo active) | 34–56 |

**Camino crítico de COGNITIV:** lote A (P4) + **su decisión sobre la ruptura de herencia**. Si la ruptura de herencia les
basta, D deja de estar en su camino crítico y se puede esperar a un segundo consumidor (regla de tres).

**Pendiente de verificar antes de comprometer D:** bytes reales del modelo con `deny` (`factsModelBytes`), latencia de
`Check`/`ListObjects` con exclusión contra el `:8101`, comportamiento del servidor con `includes` cíclicos, y si
`ListObjects` corta en silencio al vencer su deadline (afecta ya hoy a `listObjects`, con o sin deny).

---

**Siguiente paso concreto:** preguntar a COGNITIV (una línea): *«Vuestro caso Nóminas, ¿lo cubre un `inherits=false` en
`tenancy_nodes` dentro de vuestro evaluador? Si sí, P1 no está en vuestro camino crítico; si no, ¿qué caso necesita
deny que no sea ruptura de herencia, y cómo excluís al owner?»* — y abrir el lote A en paralelo.

Fuentes externas: [OpenFGA · Relationship Queries (Read)](https://openfga.dev/docs/interacting/relationship-queries) ·
[OpenFGA · Configuration Language (exclusion)](https://openfga.dev/docs/configuration-language) ·
[OpenFGA · Perform a List Objects call](https://openfga.dev/docs/getting-started/perform-list-objects) ·
[Discusión comunidad ListObjects deadline/parcial (🟡)](https://github.com/orgs/openfga/discussions/95)
