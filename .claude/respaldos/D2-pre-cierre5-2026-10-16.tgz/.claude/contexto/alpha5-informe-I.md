# `2.4.0-alpha.5` — informe del implementador I (R2a + R1) · INCREMENTAL

**Base:** HEAD `5547fa4` = `2.4.0-alpha.4`, árbol limpio al arrancar (2026-09-09). Especificación:
`panel-relay-juez.md` (cuestiones 1 y 2) + `decisiones-dueno-2026-08-28.md` §2026-09-09 (2) + los tres informes
del panel (`panel-relay-{analista,auditor,tester}.md`) + reproducciones del auditor (`relay-auditor-{1,2}.ts`) y
prototipos del tester (`rojo_1b.ts`, `medida_2.ts`). Sin commits, sin subir `version`. Base con `:8101` dada por
el coordinador: **1178 / 1202 / 1297 / 1297** (sqlite / sqlite-file / pg / mysql).

`$S` = `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`. Todo caso suelto:
`node --import @poppinss/ts-exec bin/test.ts --files=tests/scope_outbox.spec.ts`.

Orden seguido, el del juez: **R2a primero** (prerrequisito de R1: la sonda de `only` mira `pending()`, y una
aparcada sale de `pending()`), **R1 después**.

---

## 0 · Lo que cambia (superficie)

| Fichero | Qué |
|---|---|
| `src/types.ts` | `ScopeOutbox.enqueue` ⇒ `Promise<void \| { id }>` (covariante); `pending(limit, after?, filter?: { ids })`; `markFailed(id, error, options?: { transient })`; `earlierPending?(id, scopes)` (opcional). Tipos nuevos exportados: `ScopeEnqueueReceipt`, `ScopeOutboxPendingFilter`, `ScopeOutboxFailure`, `ScopeRelayFailure` (con `transient`), `ScopeRelayEntry`/`ScopeRelayEntryStatus`. `ScopeRelayReport` gana `entries` y `missing`; `failures[]`/`failed` llevan `transient`. Docblocks. |
| `src/scope_outbox.ts` | `enqueue` devuelve `{ id }` (`returning('id')`; medido por motor: `[id]` sqlite/mysql, `[{ id }]` pg); `pending` filtra por `whereIn('id', ids)` en SQL (`ids: []` ⇒ 500); `markFailed` con `transient` escribe `last_error` y NO incrementa; `earlierPending` = una consulta de existencia (`id < ?`, sin aplicar, `attempts < max`, hijo O padre ∈ scopes, la raíz como `app` con uuid nulo). |
| `src/manager.ts` | `scopes.attached/moved/detached` ⇒ `Promise<ScopeEnqueueReceipt>` (`#receiptOf`: plural, vacío sin outbox o sin id). `relayScopeChanges({ only })`: `#onlyOf` (`[]` ⇒ 500), filtro al puerto + `#assertOnlyHonoured` (500 si vuelve un id ∉ only), `#dependencyOf` (sonda `earlierPending` o paginado de `pending()` con tope `RELAY_WINDOW_MAX_PAGES` ⇒ 500 antes que adivinar) ⇒ `deferred` `depends-on:<id>`; `#parkedKeys` siembra desde `dead()` (censo hasta `limit` si el reporte de `dead` va lleno) y aplaza SOLO `attached`/`moved` (`parked:<id>`); `#isTransientRelayFailure` (`AuthorizationBackendError` o `status === 503`) ⇒ `markFailed(..., { transient })`; `blocked` pasa de `Set<key>` a `Map<key, id>` para que todo aplazado nombre a su bloqueante; `entries` y `missing`. Docblock del método ampliado. |
| `index.ts` | Exporta los tipos del puerto y del relay (`ScopeOutbox`, `ScopeOutboxContext`, `ScopeOutboxLease`, `ScopeTreeChange`, `PendingScopeTreeChange`, `RelayedScopeChange`, `ScopeRelayReport` + los seis nuevos). **Hueco preexistente**: ninguno salía por la entrada principal y no hay subpath de tipos en `package.json`; el README decía «or your own implementation of `ScopeOutbox`» sobre un tipo que el consumidor no podía importar. Aditivo. |
| `commands/authz_scopes_relay.ts` | `--only=12,13` (o repetido; `parseOnly` estática); `--only` vacío ⇒ error + exit 1; salida POR ENTRADA desde `report.entries` (aplazado por aparcado dicho como tal), `missing` avisado, fallo transitorio dicho como «no consume intento». |
| `tests/scope_outbox.spec.ts` | 50 → **82 casos** con `OPENFGA_TEST_URL` (72 sin): el 1136 desdoblado en (a)/(b) + (c)/(d); grupo R2a (4 + driver real contra puerto muerto); grupo recibo (4); grupo `only` (11, con 1b-3 medido y el puerto SQL); grupo `:8101` (el 🔴 1 con tiempos); letra (README + comando). Doble `memoryQueue` (puerto alpha.5 en memoria, con `probe`/`honourFilter` conmutables para los casos de terceros). |
| `src/testing/contract.ts` · `tests/manager.spec.ts` | Una aserción cada uno (Z1, «`detached` no devuelve nada que declarar a medias»: `isUndefined` ⇒ `deepEqual({ queued: [] })`), con el comentario de por qué el recibo vacío no es el contador que Z1 prohibía. Salieron en rojo en la primera cadena de 4 modos (4 fallos por modo = los 4 niveles del contrato), no en el spec del outbox. |
| `README.md` | Sección del outbox: recibo y `only` («deferred, never out of order», con el porqué medido), lo que NO hace (tenant, cuerpo, arrastre), «A 503 does not consume an attempt», el desdoble del aparcado, «Do not return the relay report over HTTP», «the inline pass returns a report, it does not throw», `remaining`/`dead` globales; lista del puerto; `--only` en el bloque bash; fila `E_AUTHZ_CONFIG`. |
| `CHANGELOG.md` | `[Unreleased] — 2.4.0-alpha.5` (estilo 1.1.0/alpha.4: problema reportado → el problema vivo debajo → decisiones → qué NO se hace). |
| `CLAUDE.md` | Cabecera (lote I en el árbol) + regla de higiene de la outbox: tres incisos (503, tapón por clave, recibo/`only`), aditivo. |

Sin migración, sin columna nueva, sin tocar el lease, sin `requeue` (II), sin filtro por tenant.

Corrección durante la autorrevisión del diff (antes de la verificación final): el filtro que va al puerto lleva los
ids **tal cual los dio el llamante** (`options.only`), no el `Set<string>` que el manager usa para comparar — en
sqlite funcionaba por coerción; en pg un `bigint`/`integer` contra texto también, pero no es lo que el docblock
del puerto promete. La cadena de 4 modos se paró y se relanzó sobre el código final.

---

## 1 · R2a · Aparcado (PRIMERO)

### R2a-1 · Un 503 del backend NO consume intento

| | |
|---|---|
| **ROJO** (`$S/a5_r2a_red.log`, antes de tocar `src/`) | 7 rojos / 50 verdes intactos. Los casos nuevos mueren en el recibo (`Cannot destructure property 'queued'`) y en `failures[0].transient` (`expected undefined to be true`). |
| **VERDE** (`$S/a5_r2a_green.log`) | 57/57. |
| **MUTANTE** — `markFailed` siempre incrementa (`$S/a5_r2a_mut1_transient.log`) | 2 rojos: «un 503 no consume intento: cero en las cinco peticiones: **expected [ 1, 2, 3, 4, 5 ] to deeply equal [ 0, 0, 0, 0, 0 ]**» — la cifra literal de la repro del auditor — y el caso del puerto. El caso de terceros (outbox que ignora el tercer parámetro) sigue verde en el mutante: es el comportamiento que se degrada a propósito. |

Clasificación: `AuthorizationBackendError` (el timeout es subclase) o cualquier `status === 503` ⇒ transitorio;
422/500/`E_AUTHZ_SCOPE_TREE_DRIFT`/padre inexistente/`Error` sin status ⇒ cuenta. **Nota sobre la repro del
auditor tal cual**: `relay-auditor-1.ts` simula la caída con `throw new Error('el store no responde')` (sin status);
con la regla decidida eso CUENTA (naturaleza desconocida ⇒ lo de hoy). Por eso el caso de la suite usa lo que lanza
el driver de verdad (`AuthorizationBackendError`) y hay un segundo caso **con el driver `openfga` real contra
`127.0.0.1:9`** (sin espía): 503, `transient: true`, `attempts = 0`, `last_error` escrito.

### R2a-2 · Lo aparcado tapona por clave lo que concede o recuelga; deja pasar lo que retira (desdoble del 1136)

| | |
|---|---|
| **ROJO** | Antes de la siembra, (b) se aplica con el padre viejo — es lo que mide el mutante 2 abajo (el rojo puro está enmascarado en `a5_r2a_red.log` por la falta de recibo). |
| **VERDE** | (a) purga avanza, aparcada reportada en todas las pasadas, `entries` = `[applied detached, dead attached]`; (b) `attached` ⇒ `deferred` con `parked:<id>` nombrando la clave, cero llamadas, `remaining: true`, y sigue aplazado en la pasada siguiente; (c) negativo: sin clave compartida no tapona; (d) transitivo: el nieto se aplaza por el hijo aplazado por aparcado. |
| **MUTANTE 2** — no sembrar `blocked` con `dead()` (`$S/a5_r2a_mut2_noseed.log`) | 2 rojos: **(b) «el `attached` NO se aplica: se colgaría del padre viejo: expected [ { id: 21, … } ] to deeply equal []»** (el 🔴 del juez, literal) y (d). |
| **MUTANTE 3** — sembrar para TODAS las operaciones (`$S/a5_r2a_mut3_allops.log`) | 1 rojo: **(a) «la PURGA del padre no queda bloqueada por la aparcada que lo nombra (invariante 11)»**. |

El censo de claves aparcadas: el `dead` ya leído (hasta `batchSize`) y, si viene lleno y `limit > batchSize`, una
relectura de `dead(limit)`; acotado por `limit` y dicho en el docblock.

---

## 2 · R1 · Recibo y `only` (DESPUÉS)

### R1-1 · Recibo

Verde (`$S/a5_r1_green.log`, 72/72): `attached`/`moved` ⇒ `{ queued: [id] }` y `String(id)` = `String(pending()[0].id)`
(intercambiables como clave de `only`: pg puede devolver bigint como string, por eso el manager compara siempre
por `String`); `detached` sin cadena con alias sin guiones ⇒ 2 ids en el orden de encolado; sin outbox ⇒
`{ queued: [] }` y 3 llamadas al driver; terceros con `enqueue` `void` ⇒ `{ queued: [] }`, la cola tiene la entrada,
y `only: queued` ⇒ 500 «sin recibo no hay only», cero llamadas; sin `only` todo como antes.

### R1-2 · `only` con sonda contra la cola ENTERA

| | |
|---|---|
| **ROJO** | El estado del 🔴 1 = el prototipo del analista (filtro en el puerto, `blocked` sobre lo que la pasada ve). Es el **mutante 4**: quitar la sonda ⇒ 1c-1 «**no se aplica fuera de orden: expected [ { id: 1, … } ] to deeply equal []**» (el `attached` aplicado antes que su `moved`) y el caso de terceros sin `earlierPending` (`$S/a5_r1_mut4_noprobe.log`). |
| **VERDE** | 1c-1 (`deferred`, `depends-on:<moved>`, nombra clave y bloqueante, cero llamadas, `remaining` global, `missing: []`); 1c-2 (los dos en orden de id, no del array); 1c-3 (inverso); 1c-4 (`only: []` ⇒ 500; id inexistente ⇒ `missing`, `entries: []`; id ya aplicado ⇒ `missing`, sin lanzar); 1d-3 (outbox que ignora `ids` ⇒ 500 nombrando `pending(limit, after, { ids })`, cero llamadas); terceros sin `earlierPending` (paginado ⇒ mismo veredicto); `only` sobre aparcada ⇒ `dead` en `entries` (y `parked:<id>` para su dependiente, con `only`); `dryRun` + `only`; `entries` sin `only` (failed/deferred/applied/dead en orden de proceso, aparcadas al final); 1b-3; el puerto SQL (`whereIn` + `after`, `earlierPending` por hijo/padre/raíz, ignora aplicadas y aparcadas, un fallo transitorio sigue bloqueando, `ids: []` ⇒ 500). |
| **MUTANTE 5** — filtro EN MEMORIA (`$S/a5_r1_mut5_memfilter.log`) | 2 rojos: **1b-3 «con only la pasada no lee la cola ajena (leyó 452 filas): expected 452 to be at most 3»** (el caso decisivo del tester) y 1d-3. |
| **MUTANTE 6** — `only: []` = sin filtro (`$S/a5_r1_mut6_emptyonly.log`) | 2 rojos: 1c-4 y el caso de terceros sin recibo («debería haber lanzado»). |

### R1-3 · El 🔴 1 contra el `:8101` y el tiempo medido

`$S/a5_fga_run2.log` (82/82 con `OPENFGA_TEST_URL`). Escenario exacto de `relay-auditor-2.ts` con la API de verdad
(`only`), y 500 entradas del tenant C por delante:

- `only: [attached]` ⇒ `deferred` `depends-on:<moved>`, `authorize(A@orgA, docs:read, child) = false` (en alpha.4 con
  el envoltorio: `true`, reporte en verde) y B `false` (fail-closed hasta que aterrice el moved).
- `only: [moved, attached]` ⇒ `['moved', 'attached']`, B `true`, A `false`, `remaining: true`.
- Drenar las 500 ajenas ⇒ 500 aplicadas, `remaining: false`.

**Tiempos (sqlite `:memory:` + `:8101`, un run):** pasada `only` aplazada (0 llamadas a FGA) **0,8 ms** · `only
[moved, attached]` **23,3 ms** · drenar las 500 ajenas **3 948 ms**. Aserción fija `bothMs < drainMs / 10`. Mismo
orden que la medida del analista (19 ms frente a 4 507 ms).

**1b-3 con `sqlScopeOutbox` real** (500 ajenas + `limit 50`, espía sobre `pending`, sqlite): pasada ciega 50 de 501
**3,1 ms**, pasada `only` **1,5-1,7 ms**, **2 filas leídas** (la mía + la sonda `pending(1)` de `remaining`). En
pg/mysql las cifras van en el §4 cuando termine la verificación.

### R1-4 · Comando

`--only` como `@flags.array` (coma o repetido), `parseOnly` estática (numérico ⇒ `Number`), vacío ⇒ error + exit 1
antes de llamar al manager; salida por `entries` («aplazado por APARCADO (parked:<id>)» / «aplazado
(depends-on:<id>): corre el relay completo»), `missing` avisado, fallo transitorio dicho. El comando sigue sin
ejecutarse por el kernel de ace en la suite (va a `services/main.js` global: excluido a propósito desde alpha.4,
2.6); la letra se fija leyendo el fichero (patrón de los casos 861/870).

---

## 3 · Letra

Casos de letra en `scope_outbox.spec.ts` (patrón `trx_docs.spec.ts`/3b-2d): README con las frases exactas
(`{ queued: [id] }`, `relayScopeChanges({ only: queued })`, «deferred, never out of order», «never from the request
body», «There is no filter by tenant or organization», «A 503 does not consume an attempt», «A parked entry blocks,
by scope key, what grants or re-parents» / «lets through what retires», «Do not return the relay report over
HTTP», «the inline pass returns a report, it does not throw», «`remaining` and `dead` are always global») y el
comando (`--only` entre los flags; `report.entries`, `report.missing`, `parked:` en la fuente).

---

## 4 · Verificación final (4 modos, `:8101`)

| modo | base (coordinador) | **ahora** | Δ | exit | duración | 1b-3: ciega 50/501 → `only` 1/501 (filas leídas) | 🔴 1 vs `:8101`: `only` aplazada · `only [moved, attached]` · drenar 500 ajenas |
|---|---|---|---|---|---|---|---|
| sqlite `:memory:` (`/tmp/s.log`) | 1178 | **1204 / 1204** | +26 | 0 | 88 s | 2,0 ms → 0,9 ms (2) | 0,6 ms · 22,7 ms · 3 682 ms |
| sqlite-file (`/tmp/sf.log`) | 1202 | **1228 / 1228** | +26 | 0 | 84 s | 3,8 ms → 0,9 ms (2) | 0,8 ms · 18,1 ms · 3 586 ms |
| pg (`/tmp/pg.log`) | 1297 | **1323 / 1323** | +26 | 0 | 119 s | 13,6 ms → 2,1 ms (2) | 1,8 ms · 20,6 ms · 4 098 ms |
| mysql (`/tmp/my.log`) | 1297 | **1323 / 1323** | +26 | 0 | 128 s | 63,4 ms → 4,2 ms (2) | 2,9 ms · 31,1 ms · 4 673 ms |

**El tiempo pedido** («pasada con `only`, objetivo del orden de 20 ms frente a 4,5 s»): con el driver `openfga`
real contra el `:8101` y 500 entradas ajenas por delante, relevar lo propio (`only: [moved, attached]`, 2 entradas,
8 llamadas a FGA) cuesta **18-31 ms** según el motor SQL de la outbox; drenar la cola entera **3,6-4,7 s**. La
pasada `only` que se aplaza por dependencia (0 llamadas a FGA) cuesta **0,6-2,9 ms**. La aserción fija
`only < drenar / 10`. Las 2 filas leídas con `only` son la propia + `pending(1)` de `remaining` (global).

`npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ (corre dentro de cada
`npm test`) · `npm run build` ✔ (`$S/a5_build.log`, posterior a la última edición de `src/`).

**Cómo se corrió (incidencia de máquina, no del paquete).** La cadena de 4 modos en segundo plano fue MATADA dos
veces por el harness («system is running low on memory»: la RAM la ocupan Chrome/VS Code/Postman del usuario, ~19 GB
RSS sobre 15 GB) — la primera vez durante mysql, la segunda al arrancar sqlite. Una tercera se mató sola por un
`pkill -f` que casaba con su propia línea de órdenes. Al final cada modo corrió en PRIMER plano, uno detrás de
otro (comparten el `:8101` y su guardia de stores), con `exit` y duración anotados al pie de cada log. Los
`:8101`/pg/mysql no hicieron falta reiniciarlos; la base `authz_test_1996d385` que dejó la corrida matada (sin teardown) se borró a mano al final, y los stores de FGA huérfanos los barrió la guardia de la suite en la corrida siguiente. Antes de eso, la primera cadena (sobre la suite sin las dos
aserciones Z1 adaptadas) dio sqlite 1200/1204, sqlite-file 1224/1228 y pg 1319/1323, con los 4 fallos por modo
siendo la misma aserción `isUndefined(await scopes.detached(...))` en los 4 niveles del contrato.

---

## 5 · Lo que NO hice (a propósito)

- Filtro por tenant/`organization` (decidido: no). `requeue`/`authz:scopes:requeue` (II). Tocar el lease. Esquema de
  `authz_scope_outbox` (sin migración). `runScopeOutboxContract` (R5, II). R0 docs de límites / profundidad (II).
- No edité las reproducciones del auditor ni los prototipos del tester.
- `dead` como CONTADOR con `only` (injerto 🟡 7 del juez, decisión 1.5): ver §6.

## 6 · Contradicciones / desviaciones respecto al juez (para el coordinador)

1. **`dead` con `only`: lista global (encargo) frente a «contador» (juez, cuestión 1 · decisión 5 / injerto de B).**
   El encargo dice literalmente «`remaining` y `dead` NUNCA se filtran (siempre globales)» y remite el 🟡 7 al aviso
   del README; el juez decía «se CALCULAN sin filtro y se REPORTAN como contador cuando hay `only`». Cambiar el tipo
   de `dead` según haya `only` (`RelayedScopeChange[] | number`) rompería a quien lo lee; he seguido el ENCARGO (lista
   global siempre + aviso «Do not return the relay report over HTTP» en README y docblock). Si el dueño quiere el
   contador, es un campo nuevo (`deadCount`) y no lo he añadido. **No he decidido: lo dejo escrito.**
2. **Id desconocido en `only`**: el tester (1c-4) quería «error nombrando el id»; el juez solo adoptó `only: []` ⇒ 500.
   Un id ya aplicado por otra pasada (receta inline con cron detrás) no puede ser un 500, y el relay no distingue
   «aplicado» de «inexistente» con el puerto actual. Salida: `report.missing` (nunca un reporte vacío en verde, nunca
   un 500 en la receta). Lo señalo por si el coordinador prefiere otra cosa.
3. **Errores sin `status` de un driver de terceros** cuentan intento (naturaleza desconocida ⇒ lo de hoy). La repro
   `relay-auditor-1.ts` tal cual (bare `Error`) sigue aparcando por eso; el driver real no.
4. **Precio declarado del tapón por clave** (riesgo 1 del juez): una aparcada `attached(X, org)` congela TODO
   `attached`/`moved` que nombre `org` (p. ej. crear otra unit bajo la misma org) hasta que un humano actúe. Es lo
   decidido; lo comprobé al escribir el caso de `entries` (tuve que poner la aparcada bajo otra org). Va en README.
