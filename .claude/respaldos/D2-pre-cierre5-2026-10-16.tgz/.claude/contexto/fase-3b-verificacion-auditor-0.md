# Fase 3b · Lote 3b-0 — verificación del auditor de seguridad

> Rama `v2/fase-3b`, HEAD `2613916`, base `9675e64`. Árbol limpio, sin tocar.
> Motores: PostgreSQL 18 (`postgres18`), OpenFGA `:8101`, Node 22.23.2.
> Scripts en el scratchpad `v12/` (copias de `v6`…`v10` + `z1`…`z4` nuevos + `old/` = `git archive 9675e64`).
> Bases `authz_test_*` creadas por mis scripts: **borradas** (0 en PG, 0 en MySQL). Store FGA de `n2_p4`: borrado por el propio script (204).

## Veredicto en una línea

**APTA CON CORRECCIONES** — ningún 🔴 ni 🟠, así que por la regla de parada **no bloquea**; el borrado
**no abrió ningún bypass** y cierra dos ataques que estaban abiertos, pero deja tres frases publicadas
que son **falsas y medibles** y que son justo la justificación de una operación destructiva nueva.

---

## 1. Dictamen sobre el cambio declarado (`scopes.detached` con `requireWithin: false`)

**Es la eliminación de una inconsistencia, no una pérdida real de defensa.** Medido, no razonado:

`v12/z3_detached.ts` §A, un forastero con rank 0 en el tenant A (es admin de B), config **por defecto**
(`requireWithin: false`), holder con `docs:read` heredado de `orgA` y **deny** en `a1` y en `a2`:

```
  a1 = unit CON rol local (rank 40) · a2 = unit SIN roles locales
  detached(a2, actor forastero)  = undefined   → authorize(holder, docs:read, a2) pasa de false a TRUE
  detached(a1, actor forastero)  = undefined   → authorize(holder, docs:read, a1) pasa de false a TRUE
  filas de "caro" (el rol rank 40): 1          ← el ROL sobrevive; en 3G se destruía
```

Es decir: **el efecto de seguridad que importa —borrar un `deny` y voltear una decisión de `authorize`—
ya se conseguía en 3G eligiendo `a2` en vez de `a1`**. La policy de rango protegía un subconjunto
arbitrario (“los scopes que resultan tener roles locales”) de una operación cuya barrera diseñada es
`within` (invariante 15), y el atacante solo tenía que cambiar de scope. No era una barrera: era ruido
que además costó tres regresiones.

Y a cambio el lote **cierra** dos cosas que sí estaban abiertas (verificado, §4): el forastero de rank 0
ya no **destruye** el rol de rank 40 de un descendiente vivo (`y1`), y el canal lateral de W2 devuelve
**cero bits** (`x6`, `y3` §C).

**Con `requireWithin: true` / `'non-root'` sigue cerrado en todos los caminos** (`z3` §B, los dos modos):

| camino | `true` | `'non-root'` |
|---|---|---|
| sin `within` | 422 `E_AUTHZ_WITHIN_REQUIRED` | 422 `E_AUTHZ_WITHIN_REQUIRED` |
| `within: app` | pasa (por diseño) | 422 `E_AUTHZ_WITHIN_ROOT_FORBIDDEN` |
| `within: orgB` (el suyo) contra un scope de A | 422 `E_AUTHZ_NOT_WITHIN` | 422 `E_AUTHZ_NOT_WITHIN` |
| scope desconocido del árbol | 422 `E_AUTHZ_UNKNOWN_SCOPE` | 422 `E_AUTHZ_UNKNOWN_SCOPE` |
| alias del uuid (sin guiones) + `within` ajeno | 422 `E_AUTHZ_NOT_WITHIN` | idem |

Las dos puertas que pasan (`within: orgA` ajeno declarado a mano, `within: a1`) son la salvedad de
siempre del invariante 15 —`within` sale de la **sesión**, jamás del cuerpo— y están documentadas.
No es de este lote.

**Lo que este lote NO cambia y sigue siendo el agujero de verdad** (preexistente, ya reportado en `x6`/`y3` §C):
con el default `requireWithin: false` —opt-in con un aviso por consola— `scopes.detached` es un
**removedor de denies** para cualquier llamante que lo alcance. Eso ya era así y sigue igual.

---

## 2. Hallazgos (ordenados por severidad)

### [🟡] `pruneOrphanRoles` decide qué BORRAR sobre una premisa que el propio lote declara falsa

- **Escenario**: el consumidor borra la fila de `u1` pero `t1` (team vivo) conserva su ruta materializada
  por `u1` — el caso (c), que con rutas materializadas o borrado en dos pasos es lo normal → el rol
  “dormido” **concede, es membresía, se enumera y SE PUEDE ASIGNAR** → la plataforma corre
  `authz:catalog:prune-orphans --force` (o cualquier código llama a `pruneOrphanRoles({force:true})`) →
  el rol y **todas sus asignaciones** se borran sin actor y sin rango, con un `role_purged` sin actor.
- **Evidencia**: ✅ `v12/z4_dormido.ts` sobre PG:
  ```
  --- el owner u1 ya NO resuelve; t1 SÍ, con u1 en su cadena ---
    authorize(holder, docs:read, t1)   = true
    hasRole({uuid}, t1) = true · hasRole('lead'@team, t1) = true
    effectivePermissions(holder, t1)   = ["docs:read"]
    listRoles(holder, t1) = ["lead"] · listSubjects({uuid}, t1) = 1 sujeto
    authorizedScopes(holder, docs:read, team) = {"kind":"some","scopes":[t1]}
    grant(otro, {uuid lead}, t1) = OK · grant(otro, 'lead'@team, t1) = OK → authorize(otro,…,t1) = true
  ```
  Y el barrido lo borra igual: `purged=1`, `authorize(holder, docs:read, t1)` → `false`.
  La afirmación contraria está publicada en tres sitios: `README.md:252` (“a dormant role grants nothing,
  is nobody's membership and cannot be granted”), `CLAUDE.md:121` (“sin conceder, sin ser membresía y sin
  poder asignarse”) y el docblock de `src/manager.ts:1096-1101` + `commands/authz_catalog_prune_orphans.ts:7-11`,
  que es **la justificación escrita de purgar sin rango y sin actor**. `CLAUDE.md:131` y `CHANGELOG.md:57`
  dicen lo contrario cuatro líneas más abajo, en el mismo párrafo.
- **Efecto lateral medido**: al liberar el `(slug, nivel)`, un `grant` por slug en `t1` que antes era 422
  `E_AUTHZ_AMBIGUOUS_ROLE` pasa a enlazar el rol **GLOBAL** homónimo, con más permisos:
  `effectivePermissions(otro, t1) = ["docs:read","docs:write"]`.
- **Steelman del defensor**: «es fail-closed (quita permisos, no los da), es una operación de plataforma
  con `--dry-run` por defecto, y D4 está declarado irrelevante en `CLAUDE.md`». → **Me convence a medias**:
  el impacto es destructivo, no una escalada, y por eso es 🟡 y no 🟠. Pero “ya no decide nada con esa
  premisa” es **falso desde este lote**: `pruneOrphanRoles` es un consumidor nuevo de la premisa, y es el
  que borra. Publicar la frase falsa en el README es peor que tenerla en un docblock interno.
- **Mitigación mínima**: corregir las tres frases (“dormido = no visible **desde ningún scope vivo cuya
  cadena no pase por el owner**”) y que el `--dry-run` marque los huérfanos que todavía conceden.

### [🟡] Resurrección de un hecho después de la limpieza documentada (regresión medida contra `9675e64`)

- **Escenario**: rol local `caro@team` owner `u1`, con el hecho en el **nieto** `t1`. El consumidor borra
  la rama y notifica `scopes.detached(u1)` → hoy sobreviven el rol **y la asignación de `t1`** → si `u1`
  vuelve al árbol con el mismo uuid (undelete / restore de papelera, o recrear la unit), `authorize`
  vuelve a `true` **sin ninguna escritura**.
- **Evidencia**: ✅ el mismo script en los dos commits (`v12/z1_despertar.ts` / `v12/z1_old.ts`):
  ```
  2613916:  detached(u1) = undefined   → filas "caro": 1 · asignaciones: 1 → tras el restore: authorize = TRUE
  9675e64:  detached(u1) = {"purgedRoles":1,…} → filas "caro": 0 · asignaciones: 0 → tras el restore: authorize = false
  ```
- **Steelman del defensor**: «invariante 11 siempre fue “el scope EXACTO”; el consumidor debe notificar
  por nodo, y el invariante 18 dice literalmente que volver la unit **restaura** lo concedido: es la
  semántica del árbol de hoy». → **Me convence como contrato**, no como comunicación: el CHANGELOG marca
  el lote *breaking* y no menciona esta consecuencia, y la salida que ofrece (`prune-orphans`) **no** limpia
  esos hechos si el owner vuelve a resolver. Entre 3D y 3G el rol se llevaba las asignaciones consigo.
- **Mitigación mínima**: una línea en CHANGELOG/README, y que `authz:reconcile` (3b) barra los hechos
  de scopes que ya no resuelven.

### [🟡] `pruneOrphanRoles` es público y se salta `requireActor` y `requireWithin`

- **Escenario**: es un método público del **mismo** `AuthorizationManager` que exporta
  `services/main.ts`; no toma actor, no mide rango, no pasa por `#writeOptions`. Un controlador que lo
  llame (nombre inocuo, sin parámetro de actor que avise) borra catálogo local **de todos los tenants**
  sin auditoría (`role_purged` sin actor). Peor: si el `resolveChain` del consumidor está filtrado por el
  tenant de la petición —patrón normal en multi-tenant— o corre sin contexto (comando, réplica atrasada),
  devuelve `null` para **todo** y una pasada con `force` se lleva el catálogo entero.
- **Evidencia**: ✅ `v12/z2_prune.ts` §B y §C, con `requireActor: true` y `requireWithin: true` en config:
  ```
  §B pruneOrphanRoles({force:true}) SIN actor y SIN within = {…}   ← no lanza; purga
  §C roles locales vivos antes: 2 → dry-run con el resolutor ciego: orphans=2 → force → vivos DESPUÉS: 0
  ```
- **Steelman del defensor**: «`manager.driver()` ya es la salida documentada de todas las barreras, y
  el `--dry-run` por defecto es real: nadie borra sin leer la lista». → **Me convence a medias**: el
  `--dry-run` (verificado: solo `--force` escribe, y `this.force === true` estricto) protege el camino del
  comando, que es el 90 % del uso; no protege el camino programático, y `driver()` al menos **se llama
  `driver()`**. El fail-closed que sí está bien puesto: sin `scopes.resolveChain` ⇒ 500 `E_AUTHZ_CONFIG`
  antes de leer nada, y sin `purgeRole` ⇒ 500 `E_AUTHZ_UNSUPPORTED` antes de leer nada.
- **Mitigación mínima**: abortar si **todos** los owners resultan huérfanos (o si el ratio supera un
  umbral), que es exactamente la firma de un resolutor ciego.

### [🟡] TOCTOU en el barrido: el owner vuelve entre la lectura y la purga

- **Escenario**: `pruneOrphanRoles` resuelve todos los owners en un bucle y purga en **otro** bucle
  posterior, sin re-comprobar. Un `scopes.attached` / restore concurrente (o una réplica que se pone al
  día) durante la pasada ⇒ se borra un rol cuyo owner **resuelve** en el instante del `purgeRole`.
- **Evidencia**: ✅ `v12/z2_prune.ts` §E (resolutor que devuelve `null` la 1ª vez y la cadena después):
  `filas de "lead3" (owner u2, VIVO en el momento de la purga): 0`.
- **Steelman del defensor**: «la ventana es de milisegundos y es una carrera que el tenant pierde igual».
  → **No me convence del todo**: la ventana es *toda la pasada* (lectura de N roles + N `resolveChain`),
  no un instante, y el resultado es irreversible.
- **Mitigación mínima**: re-resolver el owner justo antes de cada `purgeRole`.

### [⚪] Higiene

- `src/manager.ts:1334` sigue aconsejando «vigila `truncated`», campo borrado en este lote (mismo tipo de
  deuda que D7, que sí se arregló).
- `readLocalRoles()` no tiene cota: lee **todos** los roles locales en una consulta. En un comando da
  igual; expuesto por HTTP (hallazgo anterior) es amplificación.
- Purga parcial: si un `purgeRole` falla a mitad, los anteriores ya están borrados y no hay vuelta atrás
  (asumido en el docblock; con el hallazgo del caso (c) significa revocación parcial de permisos vivos).

---

## 3. Respuestas directas a las cuatro preguntas

**(1) ¿pérdida de defensa?** No. Ver §1: es la eliminación de una protección accidental y dependiente
de los datos, y a cambio se cierran `y1` y `x6`. Con `requireWithin: true`/`'non-root'`, cerrado en los
cinco caminos y también con alias del uuid.

**(2) ¿el rol dormido concede / es membresía / ensombrece / se despierta?**
- **Concede y es membresía en el caso (c)**, por todos los caminos: `authorize`, `hasRole` (por uuid y por
  slug), `listRoles`, `listSubjects`, `effectivePermissions`, `authorizedScopes` (coherente con `authorize`,
  invariante 16 intacto) y **se puede asignar** con `grant` por uuid y por slug. La frase publicada es falsa.
- **No ensombrece** por `#shadowedBelow` (el owner que no resuelve nunca entra en `shadowed`) — eso es D2,
  abierto y de 3b-1, sin cambios.
- **Se despierta**: sí, y con las asignaciones que en 3G se habrían ido con el rol (hallazgo 2, medido en
  los dos commits).
- **Caso (c) en la colisión**: ✅ **sigue dando 422** `E_AUTHZ_CATALOG_CONFLICT` («es un ancestro») al definir
  el homónimo desde `t1`; desde un hermano no bloquea; `deleteScopedRole`/`updateScopedRole` sobre el
  huérfano siguen siendo 422 `E_AUTHZ_UNKNOWN_SCOPE`. Coincide con la tabla del informe del implementador.

**(3) `prune-orphans`**: el comando es de plataforma pero **el método del manager es público** y se salta
`requireActor`/`requireWithin` (hallazgo 3). Puede borrar un rol cuyo owner sí resuelve por dos vías: el
caso (c) (hallazgo 1) y el TOCTOU (hallazgo 4). `--dry-run` por defecto **es real** (`force: this.force === true`,
estricto; solo `--force` escribe). Sin `scopes.resolveChain` ⇒ 500 `E_AUTHZ_CONFIG` **antes de leer nada** ✅;
sin `purgeRole` en el driver ⇒ 500 `E_AUTHZ_UNSUPPORTED` antes de leer nada ✅. El resolutor que **lanza**
⇒ 503 `E_AUTHZ_RESOLVER_FAILED` sin borrar nada ✅ (fail-closed correcto); el que **devuelve `null`** es el
peligroso, y no se distingue del huérfano legítimo.

**(4) Re-ejecución de mis scripts** (todos sobre PG + `:8101`): **confirmo las tres afirmaciones del
implementador**.
- `v8/n2_p4`: `openfga: scopes.detached(U1) = undefined` y `¿siguen los HECHOS? authorize = false`. El
  callejón sin salida desaparece. ✅
- `v9/x6_canal` y `v10/y3` §C: `detached` sobre scope de A con roles locales, sin roles locales y
  **inexistente** → los tres `undefined`. **Cero bits.** ✅
- `v10/y1`: tras borrar la fila de `u1`, `ATAQUE: scopes.detached(u1, actor forastero rank 0) = undefined`
  y **`filas de "caro": 1`** (en 3G: `purgedRoles: 1`). El rol de rank 40 sobrevive. ✅
- `v10/y3` §A/§B: dos finales legales, un solo ganador, `filas: 1` en 2/2. ✅
- `v8/n5`, `n6`, `n7`: el rol huérfano sobrevive, los hechos y los denies se purgan (`asignaciones: 0`,
  `denies vivos: 0`); con config estricto, `detached` y `deleteScopedRole` sobre el scope ya borrado son
  422 `E_AUTHZ_UNKNOWN_SCOPE`. ✅
- `v6/repro5_resiste`: **22 barreras, 22 `ok`, 0 `ROTO`**. ✅

**(5) Regresión**: `TEST_DB=pg OPENFGA_TEST_URL=:8101 npm test` → **`Tests 684 passed (684)`**, 54 s,
`check:purity` verde. ✅ Coincide con lo esperado.

---

## 4. Lo que intenté y NO se rompió

- Escalada por el rol dormido: no hay ningún camino en el que un rol cuyo owner no está en la cadena del
  scope preguntado conceda. La regla única de visibilidad (`isRoleVisibleWith`) no se tocó y aguanta.
- Cruce entre tenants por `prune-orphans`: purga por uuid de rol, el owner sale de `owner_scope_key`;
  no hay forma de que el barrido toque el rol de otro owner que sí resuelve (salvo los dos casos del
  hallazgo 1 y 4, que son del propio owner).
- Fuga de información: `detached` ya no devuelve nada y ningún 422 nombra catálogo ajeno (X5 sigue en pie).
- Ambigüedad: con el global y el local visibles, `grant` por slug es 422 `E_AUTHZ_AMBIGUOUS_ROLE`
  (fail-closed), nunca “el más cercano gana”.
- Fail-open por el resolutor: el que lanza da 503 en `pruneOrphanRoles` y en `detached`; la cadena vacía y
  la no-array siguen siendo 503; nada se traduce a `false` ni a “permitido”.
- `--force` no es accidental: `flags.boolean` + comparación estricta `=== true`; sin la bandera no escribe.
- Ninguna de las 22 barreras de delegación (`repro5`) cede, ni la carrera del catálogo (`y3` §A/§B).

## 5. Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. ¿Se acepta que `pruneOrphanRoles` sea público en el manager del tenant, o se mueve detrás de una
   fachada de plataforma (como `driver()`) antes de publicar 2.0? Si se acepta, el hallazgo 3 es ⚪.
2. ¿`authz:reconcile` (3b) va a barrer también los **hechos** de scopes que ya no resuelven? Si sí, el
   hallazgo 2 se cierra ahí y basta con la línea en el CHANGELOG.
