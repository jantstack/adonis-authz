# Cierre 4 de D2 — brief del coordinador (2026-10-16)

Origen: `loteD2-auditor-cierre3.md` (NO APTA). Reproducción: `.claude/reproducciones/loteD2-auditor-cierre3.ts`. Árbol sin commit sobre `75353fe` con D2 + cierres 1–3, verificado por el coordinador: 2037/2065/2162/2164, guardia 178/178, banderas 37/37, runbook ×2.

## Principio rector (decisión del coordinador, coherente con §2026-10-15 (9) RECHAZAR)
Cuando el reconcile NO puede escribir un deny o una membresía que transporta un deny (residuo `renewal-unsafe` o `deny-conditional`), el destino debe quedar **igual o más restrictivo que el origen en TODO instante futuro**, no solo en `now`. Por tanto: **no se escriben los allows que ese deny cortaría** (quedan como residuo `withheld-by-unsafe-deny` con su receta), y la línea del residuo dice la fecha desde la que el destino divergiría si se aplicara a mano. Nada se escribe a medias para "luego converger".

## Puntos
1. **🟠 C3-1** extensión `renewal-unsafe` (destino openfga, membresía viva que vence antes que en el origen): aplicar el principio — retener los allows cortados por el deny que la membresía transporta. Caso de contrato = la reproducción del auditor (destino niega en `now` y SIGUE negando tras la caducidad vieja; con reloj inyectado, sin sleeps reales si el contrato lo permite). Control con destino `database` sin cambios. Mutante.
2. **🟡 Horizonte temporal en la fuerza bruta** (`tests/helpers/order_bruteforce.ts`): evaluar la propiedad no solo en `now` sino en cada instante de caducidad posterior (del destino tras la pasada) — «ningún prefijo ni ningún estado final, en ningún instante t ≥ now, concede lo que el origen niega en t, salvo residuo declarado». Añadir al universo los denies que fallan al escribirse (C3-2). Debe salir 0 sin residuo; si aparece un residuo nuevo, se declara.
3. **🟡 C3-2** deny condicional vencido / no rehacible en el destino openfga: decidirlo EN EL PLAN (dry y real con los mismos números y motivos), y aplicar el principio (no escribir los allows que ese deny corta). Caso dry==real.
4. **⚪ C3-3** separar códigos: `E_AUTHZ_RENEWAL_UNSAFE` = cero escrituras, aplica la receta; otro código (p. ej. `E_AUTHZ_RENEWAL_RACED`) = renovación aplicada y apareció un deny, receta distinta que NO reabre la ventana. Exportado, en README y CHANGELOG.
5. **⚪ C3-4** `purgeScope` de roles en openfga por lotes: corte a medias ⇒ `markPartialWrite` + `indeterminate`, gemelo de relaciones. Caso con fallo inyectado.

## Reglas
- Implementador ÚNICO; sin commit, `npm version`, push ni sellado; CHANGELOG solo bajo `[Unreleased]` (no tocar `[2.5.0-alpha.1]`).
- Cada punto: caso que falla sin el arreglo + mutante medido. Actualiza la guardia y la letra del README (sin frases universales falsas).
- Vigila el coste: la pasada de guard-mutants ya tarda ~13 min; la muestra de fuerza bruta por defecto no debe crecer más (usa un modo exhaustivo opt-in con env si hace falta).
- Ejecuta tú build, typecheck y suites tocadas (nvm 22; `OPENFGA_TEST_URL=http://localhost:8090`; `TEST_PG_URL` con contraseña de `postgres18`; `docker restart openfga-dev && sleep 8` antes de suites con OpenFGA).
- Informe: `.claude/contexto/loteD2-informe-cierre4.md`.
