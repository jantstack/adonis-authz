# Lote D · sublote D1 · CIERRE 1 — informe del implementador · 2026-10-15

**Árbol `main` sobre `493c649`** con D1 + cierre 1 sin commitear (27 ficheros: los 26 de D1 + `src/openfga.ts`). Único
agente que muta el árbol; **sin commit, sin `version`, sin push**. Brief: `loteD1-cierre-coordinador.md`; hallazgos:
`loteD1-auditor.md`. Entorno: Node 22 (`nvm use 22`), OpenFGA `:8090` (`openfga-dev`, reiniciado antes de cada suite),
`postgres18`, `mysql84`. Logs: `scratchpad/c1/` (`red-o1.log`, `green-o1.log`, `piece_mut.log`, `mutants.json`,
`final/*.log`). `EXPECTED_FUSED`, `migration_stub.spec`, `freeze.spec` y los bloques `[2.5.0-alpha.2]`/`[2.5.0-alpha.1]`
del CHANGELOG **sin tocar** (`git diff -U0 CHANGELOG.md` = un solo hunk, `@@ -2,0 +3,131 @@`).

---

## 0 · Medición previa (🟠 1 a): máximo de tuplas por `Write` del servidor

`scratchpad/c1/measure_max.mjs` contra `:8090` (OpenFGA v1.19.0, sin `OPENFGA_MAX_TUPLES_PER_WRITE` ⇒ default):

| `Write` | Resultado |
|---|---|
| 100 writes | OK |
| 101 writes | 400 «The number of write operations exceeds the allowed limit of 100» |
| 100 deletes | OK |
| 101 deletes | 400, el mismo mensaje — **y no se aplicó nada** (la tupla `x-0` seguía) |
| 50 writes + 51 deletes | 400 (el tope cuenta writes + deletes juntos) |

⇒ `RELATIONS_PURGE_WRITE_MAX = 100` (`src/drivers/openfga_relations_driver.ts:108`, exportada en `/openfga`), con la
medición en su docblock y en «Limits».

---

## 1 · 🟠 1 — `purgeSubject` de `openfga` cortada a medias con el deny TRANSPORTADO

- **Código**: `src/drivers/openfga_relations_driver.ts:1252` (`#purgeByFilters`, docblock con la propiedad y el residuo) y
  `:1385` (`purgeWrites`, pura: un `Write` si `≤ 100`; si no, allows no-`group` → membresías `group:*#member` ordenadas
  por objeto/sujeto en sus PROPIOS `Write` → `denied_*`). `purgeObject`/`purgeSubject` (holder y userset) pasan por ahí.
- **Casos** (`tests/relations_openfga.spec.ts:1682`, grupo «lote D · cierre 1 de D1 · 🟠 1 …»):
  - `:1799` «purgeSubject cortada, deny DIRECTO (holder)»;
  - `:1804` **«purgeSubject cortada, deny por grupo (holder)»** (el repro del auditor);
  - `:1809` **«purgeSubject cortada, deny anidado (userset g#member)»** (la gemela con `group:h#member@group:g#member`);
  - `:1820` «allow Y deny por grupo: las membresías del sujeto (≤ 100) van en UN Write propio»;
  - `:1857` **«FILA DECLARADA · purgeSubject con más de 100 membresías de grupo …»** (residuo (b)).
  Cada fila: escenario sin corte (cuenta los `Write`, afirma 1 si cabe), y para cada k un escenario NUEVO cortado por un
  espía tras k `deleteTuples` (el k+1 lanza `ECONNRESET`): 503, marca parcial ⇔ k > 0, víctima F.
- **Rojo observado** (código de D1, `scratchpad/c1/red-o1.log`): 4 de 5 rojos —
  `ROJO (🟠 1 · S3 · por grupo × no cabe · corte tras el lote 1 de 2): el estado intermedio CONCEDE … lotes aplicados:
  [group:unit|…#member@user:…]` y `ROJO (🟠 1 · S3 · anidado × no cabe · corte tras el lote 1 de 2) … [group:…#member@group:…#member]`
  (el fail-open del auditor, reproducido en los dos gemelos); «allow Y deny por grupo»: `[100, 1]` en vez de `[99, 2]`;
  «directo»: 2 `Write` en vez de 3 (estructural). Verde tras el arreglo (`green-o1.log`, 5/5).
- **Mutantes** (por pieza, `scratchpad/c1/mutants.json` + `mutrun.py`; fuera del corredor publicado, como los 30 de D1):
  `fga.purge.prefix-only` (el orden «solo prefijo» de D1) ⇒ 4 rojos; `fga.purge.memberships-first` ⇒ 3 rojos (grupo,
  anidado, allow+deny); `fga.purge.contiguous` (troceado contiguo allows+membresías) ⇒ 4 rojos, entre ellos «allow Y
  deny por grupo»; `fga.purge.no-single-write` ⇒ 3 rojos (las filas «cabe»). **4/4 muertos.**
- **Letra** (e): README («Deny on relations»: «**On `openfga` a purge that fits in one `Write` is one `Write`** … **a purge
  cut halfway grants nothing that neither the state before nor the state after granted** … **Declared row:** with more
  than 100 group memberships of the subject, a membership that carries a deny can fall in an earlier `Write` than one that
  carries an allow …», citando los tres casos) y fila de «Limits» `RELATIONS_PURGE_WRITE_MAX`; la frase vieja «never in
  default» sale del README (el docs-test la prohíbe: `notInclude`) y del párrafo D-26 del CHANGELOG `[Unreleased]`.

### Tabla de verdad (observada en `:8090`; todas las celdas son casos)

Inicial = F y final = F en todas las filas. «D1» = el código antes del cierre (orden «solo prefijo», tipos `[group, …]`).

| transporte | ¿cabe en un `Write`? | `Write` (hoy) | corte tras el lote k | víctima tras el corte (hoy) | D1 |
|---|---|---|---|---|---|
| directo (holder U) | cabe (2 tuplas) | 1 | k = 0 (nada aplicado) | F, sin marca parcial | F |
| directo | no cabe (100 + 2) | 3: [100 allows] [1 allow] [deny] | k = 0, 1, 2 | F, F, F | F (2 `Write`) |
| por grupo (holder U) | cabe | 1 | k = 0 | F | F |
| por grupo | no cabe (100 + 2) | 3: [100 allows] [allow V] [membresía g] | k = 0, 1, 2 | F, F, F | **T en k = 1** (membresía en el lote 1) |
| anidado (userset g#member; víctima W ∈ g) | cabe | 1 | k = 0 | F | F |
| anidado | no cabe (100 + 2) | 3: [100 allows] [allow V] [arista h∋g] | k = 0, 1, 2 | F, F, F | **T en k = 1** |
| allow por g_allow + deny por g_deny (99 allows) | no cabe (101) | 2: [99 allows] [g_deny, g_allow] | k = 0, 1 | F, F | — (mutante contiguo: [99 + g_deny] [g_allow] ⇒ **T en k = 1**) |
| **> 100 membresías** (101; g_deny primera, g_allow última) | no cabe | 2: [100 membresías] [1] | k = 1 | **T — FILA DECLARADA** (repetida la purga: F) | — |

### Cuatro líneas de cierre (🟠 1)

- **(a) Gemelos.** `purgeObject` ↔ `purgeSubject(holder)` ↔ `purgeSubject(userset)`: un solo punto (`#purgeByFilters` →
  `purgeWrites`). Holder y userset con caso nombrado; `purgeObject(doc)` sigue con D-26 (sin membresías: allows → denies,
  verde sin cambio). `purgeObject(group:g)`: **no aplica** caso nuevo — todo lo que lee son membresías DE g, y cada
  miembro queda dentro de g (estado inicial) o fuera (final); ningún estado intermedio concede lo que no concedan uno u
  otro (S9 sigue siendo su fila declarada). `database`: no aplica (un `DELETE`). Roles (`purgeScope` en `facts`): no
  aplica — el deny de roles es `scope#denied_<P>@holder` DIRECTO, ninguna tupla de roles transporta un deny.
- **(b) Tabla de verdad**: arriba (transporte × cabe/no cabe × corte tras k), ejecutada contra el servidor; la guardia de
  producto es `RELATIONS_PURGE_WRITE_MAX`.
- **(c) Casos existentes que el arreglo puso rojos**: ninguno de efecto (D-26 y la sonda `openfga.purge*.write` de la
  guardia, verdes). El docs-test de la sección del deny gana frases y prohíbe la vieja.
- **(d) Linaje**: no es iteración de ninguna fila de `linajes.md`. Propongo **candidato** «purga multi-request: el estado
  intermedio concede» (D-26 → 🟠 1, 2 iteraciones en relaciones; S6 de roles como antecedente). El arreglo ya es
  estructural: un punto de paso (`purgeWrites`), atomicidad donde cabe y la propiedad universal escrita.

---

## 2 · 🟡 2 — columna `denyable` en la guardia de superficie

- **Manifiesto** (`tests/fixtures/guard_manifest.ts`): `GuardColumn` + `'denyable'` (`:49`, `GUARD_COLUMNS` `:464`), razón
  cerrada `notDeny` (`:128`), `NaRule.exceptOperations` y la regla `notDeny` (`:168`: `na` en todo salvo `deny`), filas
  `platform`/`view` con `denyable: signature`; `denyable: probe` en `deny` de manager, `database`, `openfga` y doble.
- **Sondas** (`tests/guard_surface.spec.ts`): manager `:549`, database `:654`, openfga `:936`, doble `:1004`. Tres
  entradas (variantes `noOptIn` = `note`, `readPhase` = `workspace`, `groupDeny` = `group`, todas pasan F-05) ⇒ 422
  `E_AUTHZ_RELATION_NOT_DENYABLE`; manager: CERO llamadas al driver y cero eventos (por las tres vías de construcción);
  database: cero accesos a la conexión y cero sentencias (base y vista `withClock`); openfga: cero llamadas al cliente —ni
  `readAuthorizationModel`— (base y vista); doble: el deny no queda escrito (`listDenies` vacío).
- **Mutantes en el corredor** (`tests/fixtures/guard_mutants.json`, +4): `manager.deny.denyable`,
  `database.deny.denyable`, `openfga.deny.denyable`, `double.deny.denyable` — cada uno quita la línea
  `assertRelationDenyable(…)` de SU capa. **Rojo observado**: el corredor `--only` ⇒ 4/4 muertos, 1 rojo cada uno (el caso
  `GS · <capa>.deny · denyable`; las otras capas re-aplican la puerta, así que solo la sonda de la capa lo ve). Corredor
  completo: **155/155**.
- **Casos existentes puestos rojos (justificados)**: 4 repros literales de la guardia (`🟠2 · relateMany/checkMany …` y
  `🟡 E` clasificación) construían filas con 7 columnas ⇒ `TypeError` al leer `cells.denyable`; ganan la columna
  (`SIG` / `{ na: 'notDeny' }`), mismas aserciones.

## 3 · 🟡 3 — `decideMany` de `openfga` exige `modelId` fijado

- **Código**: `src/drivers/openfga_relations_driver.ts:899` (`#assertPinnedForDecideMany`, 500 `E_AUTHZ_CONFIG` que nombra
  D14 y la receta «provision → fijar modelId → desplegar»), llamada en `:847`, tras las 422 y antes de cualquier llamada.
- **Caso**: `tests/relations_openfga.spec.ts:1622` «🟡 3 · decideMany de openfga exige modelId FIJADO también sin tipos con
  deny …» (pod sin pin con memo del modelo sin deny; otro pod republica con deny y escribe uno; `check` = false; `decideMany`
  ⇒ 500 con CERO llamadas; con pin ⇒ `['deny']`).
- **Rojo observado** (sin la guarda): `ROJO (🟡 3): decideMany sin pin respondió ["none"] donde check dice false` — el
  fail-open del auditor, medido. **Mutante** `fga.decideMany.no-pin` ⇒ 1 rojo, muerto.
- **Letra**: README junto a D14/D-31 («**`decideMany` on `openfga` requires a pinned `modelId` always**»), CHANGELOG.

## 4 · 🟡 4 — `membersOf` de `database` con deny: cota y deadline total

- **Código**: `src/drivers/database_relations_driver.ts:87` (`RELATIONS_MEMBERS_DENY_CHECK_MAX = 1_000`, exportada por la
  raíz), `:994` (cota ⇒ 500 `MembersOfDenyLimitError` / `E_AUTHZ_MEMBERS_DENY_LIMIT`, `src/errors.ts:1009`, ANTES del
  primer `check`), `:1010` (`withDeadline` sobre el bucle con `timeoutMs` ⇒ 503 `E_AUTHZ_BACKEND_TIMEOUT`; una bandera
  para el bucle tras vencer). Sin filas deny: cero consultas de más (D-15b intacto).
- **Casos**: `tests/relations_database.spec.ts:1849` (1 001 candidatos ⇒ 500, 0 `check`; 1 000 ⇒ 1 000 `check` y la resta)
  y `:1877` (3 candidatos × 60 ms con `timeoutMs: 100` ⇒ 503, el bucle se para —< 3 `check`—; sin deny, ningún `check`).
  En los 4 modos.
- **Rojo observado**: `ROJO (🟡 4): 1001 candidatos con deny respondió una lista de 1000` y `ROJO (🟡 4): sin deadline total
  respondió {"subjects":[…3…]}`. **Mutantes** `db.membersOf.no-cap` y `db.membersOf.no-deadline` ⇒ muertos.
- **Letra**: fila de «Limits» atada a la constante (`scope_depth.spec`), fila en la tabla de códigos, README del deny.
- **CTE con la resta**: **no medida** (ver §8). Se eligió la cota + deadline del brief.

## 5 · ⚪ 5 — letra de la decisión 4

El docblock de `removeDeny` (`openfga_relations_driver.ts`) decía que la guarda D-31 no hace falta ahí; el código SÍ la
corre para tipos con opt-in. Docblock corregido (con opt-in vivo: guarda; con opt-in retirado: sin guarda y el delete
borra de verdad — el efecto medido por el auditor). Línea «Letter» en el CHANGELOG. El informe de D1 no se reescribe
(es histórico): esta sección es la corrección.

## 6 · ⚪ 6 — el doble publicado

Línea «Third-party drivers: the published double changed its answer» en `[Unreleased]` (cierre 1): `check(g#member, …)`
sube por los grupos de `g#member`, como `database` y FGA.

## 7 · ⚪ 7 — D-31 comprueba la FORMA

- **Código**: `openfga_relations_driver.ts:486` — `type#denied_<rel>` cuenta como declarada solo si `<rel>` es
  `difference` con `subtract.computedUserset.relation === denied_<rel>`; el mensaje del 500 dice «—o la declara y <rel>
  no la resta (but not)—».
- **Caso**: `tests/relations_openfga.spec.ts:1465` «⚪ 7 · D-31 juzga la FORMA …» (modelo a mano con `denied_viewer` y
  `viewer` sin `but not` ⇒ 500, solo `readAuthorizationModel`).
- **Rojo observado**: `ROJO (⚪ 7): un modelo con denied_viewer que no resta respondió false`. **Mutante**
  `fga.D31.exists-only` ⇒ muerto.

---

## 8 · Cifras (secuencia, `:8090` reiniciado antes de cada suite; `scratchpad/c1/final/`)

| Modo / gate | Resultado | Δ sobre la partida de D1 |
|---|---|---|
| `npm run build` | rc 0 | — |
| `npm test` (`:memory:` + `:8090`) | **1887** passed, 2 skipped | +13 |
| `test:sqlite-file` | **1915** passed, 2 skipped | +13 |
| `test:pg` | **2012** passed, 1 skipped | +13 |
| `test:mysql` | **2014** passed, 1 skipped | +13 |
| `check:guard-mutants` | **155 / 155** muertos (base 226 casos) | 151 → 155 |
| `check:flag-mutants` | **36 / 36**, 2 pending (los de D2) | = |
| `cutover-runbook` sqlite-file / pg | verde ×2 | = |

+13 = 5 (🟠 1) + 1 (🟡 3) + 1 (⚪ 7) + 2 (🟡 4) + 4 celdas `denyable`. Skipped, los de siempre. Mutantes por pieza del
cierre: **8/8 muertos** (`piece_mut.log`).

## 9 · Decisiones nuevas (a ratificar)

1. **Error nuevo `MembersOfDenyLimitError` / `E_AUTHZ_MEMBERS_DENY_LIMIT` (500)**, exportado por la raíz, en vez de
   reutilizar `E_AUTHZ_UNSUPPORTED` (cuyo mensaje dice «el driver no implementa…») o `E_AUTHZ_CONFIG` (no es config).
   Precedente: `E_AUTHZ_TOO_MANY_LOCAL_ROLES`.
2. **El deadline total de `membersOf` es el `timeoutMs` del driver** (el mismo número que el de cada sentencia), sin
   opción nueva. Con 5 s por defecto y ~1–2 ms por `check`, 1 000 candidatos caben.
3. **Las membresías se ordenan por objeto/sujeto** dentro de su clase (el reparto en el residuo no depende del `Read`;
   hace el caso de la fila declarada determinista).
4. **`RELATIONS_PURGE_WRITE_MAX` fijo en 100**, sin opción: un servidor con tope más alto no gana nada (conservador); uno
   con tope MÁS BAJO responde 400 al primer `Write` de más — **no medido** qué sale (el docblock dice 503 sin borrar).
5. **`decideMany` sin pin es 500 también en tipos sin deny** (lo pide el brief) — rompe a quien usara `decideMany` en
   `openfga` sin pin; ningún caso existente lo hacía.

## 10 · No hecho

- La CTE con la resta para `membersOf` (analista §4.4): no medida en los 3 motores; queda la cota (lo que pedía el brief
  como mínimo).
- Los mutantes de 🟠 1/🟡 3/🟡 4/⚪ 7 no están en un corredor publicado (son por pieza, como los 30 de D1); solo los 4 de
  `denyable` entran en `check:guard-mutants`.
- Sin caso para `purgeObject(group:g)` cortado (razonado en (a)); sin caso para un servidor con `--max-tuples-per-write` < 100.
- `linajes.md` y `CLAUDE.md` sin tocar (el candidato de §1 (d) es para el coordinador). El docblock de `decideMany` no
  menciona el pin (lo hace `#assertPinnedForDecideMany`).
- `decideMany` del doble y `membersOf` del doble sin cota (el brief la pide en `database`).

## Estado del árbol

```
 M CHANGELOG.md
 M README.md
 M index.ts
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_facts.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/openfga.ts
 M src/relations/check_many.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/testing/main.ts
 M src/testing/relations_contract.ts
 M src/types.ts
 M tests/capabilities.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/guard_surface.spec.ts
 M tests/openfga_facts.spec.ts
 M tests/relations.spec.ts
 M tests/relations_bridge.spec.ts
 M tests/relations_contract.spec.ts
 M tests/relations_database.spec.ts
 M tests/relations_events_docs.spec.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/scope_depth.spec.ts

 CHANGELOG.md                             | 131 +++++
 README.md                                |  96 +++-
 index.ts                                 |  14 +-
 src/drivers/database_relations_driver.ts | 296 ++++++++++--
 src/drivers/openfga_facts.ts             |  38 +-
 src/drivers/openfga_relations_driver.ts  | 356 +++++++++++++-
 src/errors.ts                            |  40 ++
 src/openfga.ts                           |   2 +-
 src/relations/check_many.ts              |  10 +-
 src/relations/define_relations_config.ts | 235 ++++++++-
 src/relations/manager.ts                 | 142 +++++-
 src/testing/main.ts                      |   2 +
 src/testing/relations_contract.ts        | 738 ++++++++++++++++++++++++++--
 src/types.ts                             |  61 ++-
 tests/capabilities.spec.ts               |   5 +
 tests/fixtures/guard_manifest.ts         |  86 +++-
 tests/fixtures/guard_mutants.json        | 801 +++++++++++++++++++++++++++++--
 tests/guard_surface.spec.ts              | 139 +++++-
 tests/openfga_facts.spec.ts              |  64 +++
 tests/relations.spec.ts                  |  85 +++-
 tests/relations_bridge.spec.ts           | 118 +++++
 tests/relations_contract.spec.ts         |   2 +
 tests/relations_database.spec.ts         | 150 ++++++
 tests/relations_events_docs.spec.ts      |  54 ++-
 tests/relations_harness.spec.ts          |  39 +-
 tests/relations_openfga.spec.ts          | 494 ++++++++++++++++++-
 tests/scope_depth.spec.ts                |  10 +-
 27 files changed, 3969 insertions(+), 239 deletions(-)
```
(diff contra `493c649`: incluye D1 + este cierre.)
