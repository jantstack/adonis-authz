# `2.4.0-alpha.4` — informe del implementador (INCREMENTAL)

**Base:** HEAD `9a107ad` = `2.4.0-alpha.3`, árbol limpio al arrancar (2026-09-09). Especificación:
`panel-alpha4-sintesis.md` + los tres informes del panel + restricción del coordinador sobre L-A (sin
`default`; nota de migración del envoltorio `ListLoader(Object.values(m))`). Sin commits, sin subir `version`.
Base medida antes de tocar nada (sqlite + `:8101`): **1141/1141** (`$S/base_sqlite.log`).

`$S` = `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`. Todo caso suelto:
`node --import @poppinss/ts-exec bin/test.ts --files=<fichero>`.

---

## 1 · Por pieza: rojo observado → verde → mutante

### L-A · Loader de comandos (`commands/main.ts`) — 🔴 del panel

| | |
|---|---|
| **ROJO** (`$S/LA_LB_red.log`, antes de tocar código) | C-1: `TypeError: loaderInstance.getMetaData is not a function` (el kernel, con el barrel registrado como lo registra `createAceKernel`); C-2: «el barrel exporta getMetaData(): expected undefined to be a callable function»; C-5: `loader.getMetaData is not a function` |
| **VERDE** | `commands/main.ts` = `ListLoader` de `@adonisjs/core/ace` (re-export del de `@adonisjs/ace`; se importa por `core` porque es la peer que ya usan los nueve comandos y `@adonisjs/ace` no es dependencia directa del paquete) sobre las nueve clases; `getMetaData()`/`getCommand()` nombrados; las nueve re-exportaciones con nombre se mantienen; **sin `default`** (restricción del coordinador). C-1, C-2, C-5, C-6 (forma: 9 clases + 2 funciones, sin `default`, y el envoltorio `new ListLoader(Object.values(m))` revienta con `TypeError`), C-7 (letra de la nota de migración del README). El `build/` también: `probe_loader.mjs` del tester contra `build/commands/main.js` ⇒ `OK … authz:catalog:diff, …, openfga:provision` (los nueve + `list`). |
| **MUTANTE** | el propio estado de partida (barrel sin `getMetaData`) es el mutante: 3 rojos. Un segundo mutante implícito lo fija C-5: quitar una clase del `ListLoader` ⇒ «no está en el loader de commands/main.ts». |

`configure.ts:47` no cambia. `check:purity` admite el import de `@adonisjs/core/ace` (las tres reglas solo miran aliases `#…`, el grafo `src/<modulo>/` y `@openfga/sdk`).

### L-B · `openfga:provision` opción B

| | |
|---|---|
| **ROJO** (`$S/LA_LB_red.log`) | A-1..A-6, C-3 (provision) y B-1/B-2: `TypeError: Cannot read properties of undefined (reading 'get') at OpenFgaProvision.run (commands/openfga_provision.ts:46:36)`, `catalogs() === 0`, stub sin requests. Literal, como el tester. |
| **VERDE** (`$S/LA_LB_green.log`, 24/24) | `prepare()`: `created`→`init()`, `initiated`→`boot()`, `booted`/`ready` no-op; si tras eso `!this.app.config` ⇒ `logger.error('config/* no está cargado: …')` + `exitCode = 1` (y `run()` sale sin leer nada). Docblocks de `static options`, `prepare()`, `:69` y `:153` reescritos con la letra pedida («bootstrap sin base: arranca hasta `boot()` para cargar `config/*`, que tiene que poder importarse; no ejecuta `start`/`ready` ni preloads»). Casos: A-0 (`startApp === false`), A-1 (stub recibe `POST /stores`, `catalogs()` = 1, error = 400 del stub, app `booted` y no `ready`), A-2/A-3 (letra de los dos bail-outs, cero requests), A-4 (`--url` gana), **A-5** (provider del consumidor con `ready()` que lanza: `['register','boot']` y NO `start`/`ready`, y aun así `POST /stores`), A-6 (app ya `ready`: idempotente), A-7 (⚪ 9: `boot()` que no carga config ⇒ letra + exit 1, nunca TypeError). |
| **MUTANTE 1** — quitar el `boot()` (`$S/LB_mut_noboot.log`) | 7 rojos: A-1 «catálogos … expected +0 to equal 1», A-2/A-3/C-3 la guarda ⚪ 9 salta con su letra en vez de la del bail-out, A-4, A-5 `[]` en vez de `['register','boot']`, L-F por comando. |
| **MUTANTE 2** — `startApp: true` (opción A) (`$S/LB_mut_startapp.log`) | 4 rojos: A-0 y C-2 (`startApp`), A-1 «expected 'ready' to equal 'booted'», **A-5: `Error: ready(): SELECT 1 falla, la base todavía no existe`** — el caso que fija B frente a A. |

**Caso 2 contra `:8101`** (B-1/B-2, dentro de `LA_LB_green.log`): exit 0 (`exitCode` queda `undefined`
hasta que ace lo pone a 0 al terminar `exec`; se afirma `?? 0`), `OPENFGA_STORE_ID`/`OPENFGA_MODEL_ID`
extraídos del stdout, `getStore().name` = `openfga.storeName`, `readLatestAuthorizationModel().id` = el
impreso, tipos `scope`/`role`/`role_binding`/`user`/`document`, las 4×2 relaciones por nombre (`Object.hasOwn`:
el `.` de `posts.read` no es ruta anidada para `assert.property`) y `"rooted"` dentro de `can_<P>`; B-2
`--store-id` ⇒ mismo store, modelo nuevo, `listStores()` no crece. Limpieza con el patrón de
`relations_provision.spec.ts` (`deleteStore` en `teardown`) + la red de `helpers/openfga_stores.ts`.

**Caso 1 en Node 24** (`$S/LB_node24.log`, `nvm use 24` ⇒ `v24.19.0`, vuelto a `v22.23.2` después):

```
[suite] motor SQL: sqlite (:memory:)
Tests  24 passed (24)
```

Sin avisos (`ExperimentalWarning`/`DeprecationWarning`: 0). Mismo resultado que en 22.

### L-C · Los otros comandos por el kernel

- **C-3** (7 casos, en `LA_LB_green.log`): `authz:catalog:diff`, `authz:catalog:sync` («No hay catálogos
  declarados»), `authz:freeze` («Falta --reason»), `authz:reconcile` («Falta --to»),
  `authz:relations:reconcile` sin `--to` y sin `relations.drivers`, y `openfga:provision` sin URL: `cmd.error`
  undefined, exit 1, la frase literal en `logs`, `app.config` definido. Los cinco `startApp: true` arrancan la app
  fixture entera por el hook del harness (sin providers ni preloads: `start()` es inocuo ahí).
- **C-5** diente estático: los nueve ficheros de `commands/` (salvo `main.ts`) tienen su `default` en el loader
  y `getCommand` devuelve ESA clase.
- **FUERA** (dicho en la spec, CHANGELOG, CLAUDE.md y roadmap): `authz:unfreeze`, `authz:catalog:prune-orphans`,
  `authz:scopes:relay` no tienen guarda pre-base y resuelven `authz.manager` del contenedor GLOBAL de la suite ⇒
  harness bicéfalo; 2.6.

### L-D · `capabilities()`

| | |
|---|---|
| **ROJO** (`$S/LD_red.log`, 9/9) | `manager.capabilities is not a function` (×8) y «falta la sección «### Reading capabilities at runtime»» |
| **VERDE** (`$S/LD_green.log`, 9/9) | `AuthorizationManager.capabilities()` async = `normalizeAuthorizationCapabilities((await this.driver()).capabilities)`; `RelationsManager.capabilities()` sync ídem con `normalizeRelationsCapabilities`; los dos normalizadores + las listas de claves literales (`AUTHORIZATION_DRIVER_CAPABILITY_KEYS`, `RELATIONS_DRIVER_CAPABILITY_KEYS`) en `src/types.ts` (copia `Object.freeze`, `=== true` — la MISMA lectura que la puerta 1); `'capabilities'` añadido al `Pick` de `AuthorizationView` (D-6: la vista delega por `driver()`; decisión a propósito, [ABIERTO] 3 del analista); `AuthorizationDriverCapabilities` exportado de `index.ts`. README: sección `### Reading capabilities at runtime (2.4.0-alpha.4)` al final de «Driver options», con el ejemplo del consumidor y «`driver()` is still platform API». |
| **Casos** | **D-5a PRIMERO**: driver `hierarchyFacts: true` sin outbox/firma ⇒ `capabilities()` 500 `E_AUTHZ_SCOPE_DRIFT_UNGUARDED`, `driver()` después SIGUE lanzando, `authorize` también, factory llamada 3 veces (nada cacheado). **D-5b**: `requireTransactionalWrites: true` + openfga ⇒ `E_AUTHZ_CONFIG` con la MISMA letra desde `capabilities()` y `driver()`, en los dos órdenes. D-1 paridad con `driver().capabilities` en `database` y `openfga` (una factory). D-2 copia congelada de un driver de terceros mutable: mutar lanza `TypeError`, el original no cambia, `grant({ transaction })` sigue siendo 500 `E_AUTHZ_UNSUPPORTED`. D-3 sin `capabilities` ⇒ las nueve claves `false`, ninguna `undefined`; parciales ⇒ `undefined`→`false` y `'yes'`→`false`. D-6 vista. D-4 relaciones: paridad `database` (`membersOfNative: true`)/`openfga` (`false`), claves de RELACIONES (no `hierarchyFacts`), `{}` como driver ⇒ todo `false`, mutar la copia no apaga la puerta 1 de `relate`. D-7 letra del README. |
| **MUTANTE** (`$S/LD_mut_bypass.log`) | «una lectura que no lanza»: `this.#driver ??= await factory()` sin puertas ⇒ **D-5a y D-5b rojos** («ROJO: capabilities() no lanzó»); 7/9. Restaurado (`grep -c MUTANTE src/manager.ts` = 0). |

### L-E · README `sqlScopeEdges` multi-tabla

- Párrafo nuevo en «Migrating and verifying: `authz:reconcile`» tras «It needs `scopes.enumerateEdges`»: una
  tabla; la concatenación NO vale (LEFT JOIN contra sí misma, salto EN SILENCIO, tipo del padre mal); `--prune`
  borra ⇒ **subárbol entero deniega** (invariante 9); receta (`enumerateEdges` propio, UNION ALL, cursor por uuid
  del hijo, `parent IS NULL` = `app`, solo si el padre existe en alguna tabla, `--dry-run` antes); «*Recipe not
  verified by the suite*»; `composeScopeEdges`/`parentTable` diferidos a 2.6. Docblocks de `ScopeEdgesEnumerator`
  (`src/types.ts`) y `SqlScopeEdgesOptions` (`src/sql_descendants.ts`) con el mismo aviso.
- **E-1** (`tests/scope_edges_docs.spec.ts`, patrón `trx_docs.spec.ts`): rojo si se suaviza (verde de
  nacimiento: es letra; el mutante es borrar la frase).

### L-F · ⚪ provisión: validar antes de crear el store

| | |
|---|---|
| **ROJO** (`$S/LA_LB_red.log`) | «expected undefined to equal 'E_AUTHZ_MODEL_TOO_LARGE'» con `FgaApiValidationError` del stub y `POST /stores` recibido: el store se creaba ANTES de validar. |
| **VERDE** | `provisionOpenFgaStore`: `assertFactsModelPublishable(holders, permissions, undefined, relations)` + `openFgaFactsModel` ANTES de `createStore`. Casos (dobles: el stub): 1500 slugs ⇒ `E_AUTHZ_MODEL_TOO_LARGE` 500 y **cero requests**; `['x','can_x']` ⇒ error con `code` del paquete y cero requests; por el comando ⇒ `run.error.code === 'E_AUTHZ_MODEL_TOO_LARGE'`; control: un catálogo sano sí llega a `POST /stores`. |
| **MUTANTE** | el orden de partida (crear primero) es el mutante: 3 rojos. |

---

## 2 · Cifras (con `OPENFGA_TEST_URL=http://localhost:8101`)

| modo | base | ahora | delta |
|---|---|---|---|
| `npm test` (sqlite) | 1141 | **1177** | +36 |
| `test:sqlite-file` | 1165 | **1201** | +36 |
| `test:pg` | 1260 | **1296** | +36 |
| `test:mysql` | 1260 | **1296** | +36 |

Los +36: `commands.spec.ts` 26 (C-1/C-2/C-5/C-6/C-7 = 5, A-0..A-7 = 8, L-F = 4, C-3 = 7, y con `:8101` B-1/B-2 = 2),
`capabilities.spec.ts` 9, `scope_edges_docs.spec.ts` 1. Sin `:8101` serían +34 (B-1/B-2 quedan fuera del grupo gateado).

`npx tsc --noEmit -p tsconfig.json` ✅ · `npm run typecheck` ✅ · `npm run check:purity` ✅ · `npm run build` ✅
(`$S/typecheck.log`, `$S/purity.log`, `$S/build.log`). Logs de las cuatro corridas: `/tmp/s.log`, `/tmp/sf.log`, `/tmp/pg.log`, `/tmp/my.log` (0 `✖` en todas).

---

## 3 · Lo que NO hice y por qué

- `startApp: true` en `openfga:provision` (mutante 2: A-5 muere en `ready()` del consumidor); homogeneizar los
  otros ocho; leer config a mano desde disco; assembler/`commands.json`; `default` en el barrel (ace no lo
  desenvuelve: C-6 lo fija y el CHANGELOG lo dice para que nadie lo «arregle»).
- Tocar `driver()`, su docblock o el README `:285`; refactorizar las puertas para leer de los normalizadores (se
  perdería el matiz «nada (sin capabilities)» del mensaje); un `capabilities()` best-effort; exponer más que el
  tipo del puerto.
- `parentTable`/`composeScopeEdges` y el diente ejecutable E-2 (roadmap 2.6).
- Caso de ejecución de `unfreeze`/`prune-orphans`/`scopes:relay` (harness bicéfalo; roadmap 2.6).
- Caso A-5 «sin binding de `Database` en el contenedor» del tester: solo aplicaba si ganaba A; con B no hay
  `start()` y `services/db` no se resuelve por este comando (A-5 real cubre el provider).
- Bordes del tester §2 (permisos duplicados entre catálogos, `holderTypes` vacío, `catalogs` que lanza): fuera
  del lote; `permissionsOfCatalogs` ya deduplica y tiene su caso.

## 4 · Contradicciones y matices respecto a los informes del panel

1. **Tester §1.2 / analista 1.7, caso «app en `created`»**: por el kernel NO es alcanzable — `kernel.create()`
   sobre una app sin `init()` revienta antes (`TypeError … reading 'make'`: no hay contenedor). La guarda
   `created`→`init()` queda en `prepare()` como pedía el analista, pero el caso que la observa (A-7) simula ⚪ 9
   con un `boot()` que no carga config, no con `created`.
2. **Tester C-5** enunciaba «un comando que lee `this.app.config` declara `startApp: true`»; con la opción B
   esa regla sería falsa para `openfga:provision`. Se implementó C-5 como el diente que la síntesis pide
   («cada fichero de `commands/` está en el loader»); la decisión de `startApp` la fija C-2 (`false` solo en
   `openfga:provision`) y la conducta A-1/A-5.
3. **Tester D-3** proponía `{}` para un driver sin `capabilities`; la síntesis (y el analista) piden todas las
   claves en `false`. Se hizo lo segundo (D-3 lo fija: nueve claves, ninguna `undefined`).
4. **Tester §4.1** recomendaba que `capabilities()` NO pasara la puerta 2; la síntesis y el auditor (🔴 1)
   dicen lo contrario. Se hizo lo segundo (D-5b) — y el mutante «sin puertas» pone D-5a/b en rojo.
5. **Tester `kernel.getCommands()` = nueve**: el kernel trae de serie su `list`; C-1 lo filtra.
6. **Coordinador**: `ListLoader` «de `@adonisjs/ace`» — se importa de `@adonisjs/core/ace` (re-export), que es
   la peer declarada; `@adonisjs/ace` no es dependencia directa del paquete.
7. **Espera de `exitCode` en B-1**: ace deja `exitCode` en `undefined` hasta el final de `exec` y lo pone a 0
   solo ahí; en el harness se lee tras `kernel.exec`, así que la aserción es `run.exitCode ?? 0 === 0` y
   `run.error === undefined`.

## 5 · Ficheros tocados

`commands/main.ts`, `commands/openfga_provision.ts`, `src/manager.ts`, `src/relations/manager.ts`, `src/types.ts`,
`src/drivers/openfga_driver.ts`, `src/sql_descendants.ts`, `index.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`,
`.claude/contexto/roadmap-2.0.md`; nuevos: `tests/helpers/ace.ts`, `tests/commands.spec.ts`,
`tests/capabilities.spec.ts`, `tests/scope_edges_docs.spec.ts`. `version` NO tocada; sin commits.
