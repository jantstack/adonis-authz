# Fase 3b · lote 2j — `stillGranting` pasa al puerto

**Rama** `v2/fase-3b` · **HEAD al empezar** `24cc154` (árbol limpio) · **sin commits** (los hace el dueño).
**Encargo**: `.claude/contexto/decisiones-dueno-2026-08-28.md` §«Decisión del 2026-08-31 (3)».
**Origen del hallazgo**: `fase-3b-lote-2i-informe.md` §7 (destapado, no causado, por 2i; existe desde 3b-0b).

---

## 0 · Resumen

`pruneOrphanRoles().stillGranting` se calculaba contando `authz_assignments` —la tabla del driver
`database`—, así que con `openfga` en modo `facts`, donde los hechos viven en el store, era
**siempre `false`**. Su contrato publicado es «falso ⇒ este rol seguro que no concede» y se lee
**justo antes de un borrado destructivo**: el barrido declaraba basura inerte un rol que estaba
concediendo.

Ahora los hechos se los cuenta **el driver**: `AuthorizationDriver.countRoleAssignments(roleUuids)`,
opcional en el puerto, con su **capacidad** (`countRoleAssignments`), su **par de casos en la suite
publicada** (`src/testing/contract.ts`) y su **CHANGELOG como breaking del puerto**. Un driver que no
lo traiga deja `assignments` y `stillGranting` en **`undefined`, jamás en `false`**, y el comando
lista esos roles **aparte**, como a los que sí conceden.

**Criterio de aceptación cumplido**: contra el `:8101` real, con el driver `openfga` en `facts`, el
caso del juez `scopes.detached …` marca el rol huérfano que todavía concede. El juez contra `facts`
pasa de **2 rojos en SQLite y 3 en PG** a **1 y 2**.

---

## 1 · Diseño (y por qué así)

| Decisión | Alternativa descartada |
|---|---|
| El método devuelve un **conteo por posición** (`countRoleAssignments(uuids): Promise<number[]>`), no un booleano | Un `roleStillGrants(uuid): boolean` dejaba `assignments` saliendo de SQL: en `facts` el reporte diría `assignments: 0, stillGranting: true` y el comando imprimiría «asignaciones VIGENTES: 0». Con el conteo, **los dos campos** son verdaderos o los dos son `undefined`. |
| **Lote**, no uno por rol | El barrido tiene hasta `maxLocalRoles` (10 000) roles locales. En `database` es UNA consulta agrupada; uno-por-rol eran N. Precedente en el puerto: `authorizeMany` (respuesta por posición). |
| Se le pregunta **solo por los huérfanos**, no por todo el catálogo local | Antes `readLocalRoles` contaba para TODOS los roles locales; ahora la pasada cuenta menos. |
| `readLocalRoles` **deja de contar** | Dejar ahí un conteo que miente es invitar a que vuelva a usarse. Su caso (`tests/catalog_cache.spec.ts`) conserva la cobertura moviendo la parte de «la caducada no cuenta» al método del driver, donde ahora vive el código. |
| Un uuid que el motor no conoce ⇒ `0`; mal formado ⇒ 422 | Es un conteo de HECHOS, no una consulta al catálogo (`purgeRole` sí es 422 para el desconocido: ahí el rol es el objeto de la operación). |
| `openfga` lo trae **solo en `facts`**; en `resolver` el constructor lo retira | Igual que `purgeRole` (3b-2e · E4): sin la arista `role_binding#role` de (c2) los bindings de un rol no se enumeran. No traerlo es la forma documentada de decir «no lo sé». |

**Lo que NO cambia**: el campo sigue siendo **conservador** (cuenta hechos, no re-resuelve el scope
de cada uno). Cero ⇒ no concede seguro; N ⇒ míralo antes de `--force`.

---

## 2 · Pieza 1 — el manager le pregunta al driver, y sin método es `undefined`

### 🔴 El caso (nuevo), rojo por la razón correcta

`tests/manager.spec.ts` · *3b-2j: un driver SIN countRoleAssignments deja stillGranting (y
assignments) en `undefined`, JAMÁS en `false`*. Un driver de terceros de 2.2 (vista por prototipo con
`purgeRole` y **sin** el método nuevo), un rol local huérfano que todavía concede desde un nieto vivo.

```
❯ manager — roles locales a un scope (3B · B3) / 3b-2j: un driver SIN countRoleAssignments deja
  stillGranting (y assignments) en `undefined`, JAMÁS en `false` — «no lo sé» no puede degradar a
  «no concede» justo antes de un borrado destructivo

  Comparing two different types of values. Expected undefined but received boolean.

ℹ AssertionError: sin el método del puerto no se sabe: undefined: expected true to equal undefined

 ⁃ at Object.executor (tests/manager.spec.ts:3210:12)
 ❯ 3210 ┃      assert.isUndefined(huerfano.stillGranting, 'sin el método del puerto no se sabe: undefined')

Tests  1 failed (1)
```

Rojo **por la razón correcta**: el barrido calculaba el campo por su cuenta (aquí `true`, contando
`authz_assignments`) en vez de preguntárselo al driver — y por tanto se lo inventaba también cuando
el driver no puede responder.

### 🟢 El código

- `src/types.ts`: `countRoleAssignments?(roleUuids: string[]): Promise<number[]>` en
  `AuthorizationDriver` + `countRoleAssignments: boolean` en `AuthorizationDriverCapabilities`.
- `src/manager.ts` · `pruneOrphanRoles`: los huérfanos nacen con `assignments: undefined,
  stillGranting: undefined`; si el driver trae el método se le pregunta **una vez** con los uuids de
  los huérfanos (ninguna llamada si no hay). Respuesta que no cuadra (longitud distinta, no entero,
  negativo) ⇒ 500 `E_AUTHZ_INTERNAL`: es por posición y se lee antes de borrar, no se adivina.
- `src/catalog_cache.ts` · `readLocalRoles`: deja de contar `authz_assignments` (y de aceptar `now`).
- `src/drivers/database_driver.ts`: `countRoleAssignments` con UNA consulta agrupada y la caducidad
  ESTRICTA del driver (`whereActive`, reloj J1); capacidad `true`.

### 🔴 Mutante que confirma el caso del driver `database`

`countRoleAssignments` sin el filtro de caducidad (`whereActive` fuera):

```
❯ CatalogView por uuid (3A · A3) / 3b-0b · AA1/AB2 + 3b-2j: … los HECHOS los cuenta el DRIVER
  (countRoleAssignments: la asignación caducada no cuenta)
- Expected  - 1
+ Received  + 1
```
Restaurado.

---

## 3 · Pieza 2 — el driver `openfga` en `facts` (el criterio de aceptación)

### 🔴 El rojo, reproducido con mutante (el barrido vuelve a decidirlo él, degradando a `false`)

Mutante en `src/manager.ts`: `orphans.push({… assignments: 0, stillGranting: false })` y no se
pregunta al driver — es exactamente el comportamiento de antes del lote. Con
`AUTHZ_CONTRACT_FACTS=1` y el `:8101`:

```
❯ authorization contract [openfga facts · 2.2] / scopes.detached purga los HECHOS del scope y SOLO
  los hechos (invariante 11): los roles locales de ese owner —y los del subárbol— sobreviven
  DORMIDOS …; la salida es pruneOrphanRoles, que es de plataforma
ℹ AssertionError: el del nieto conserva su hecho; el del scope purgado, no: expected [] to deeply
  equal [ Array(1) ]

❯ authorization contract [openfga · 2.2] / sin countRoleAssignments: el puerto NO lo trae y
  pruneOrphanRoles deja stillGranting (y assignments) en `undefined` —JAMÁS en `false`— …
ℹ AssertionError: sin el método del puerto: no se sabe: expected false to equal undefined

❯ authorization contract [database · 2.2] / scopes.detached purga los HECHOS …
ℹ AssertionError: el del nieto conserva su hecho; el del scope purgado, no: expected [] to deeply equal [ Array(1) ]

Tests  782 passed, 8 failed (790)
```

El primero es **la literal exacta** que el lote 2i dejó anotada (`expected [] to deeply equal
[ Array(1) ]`). El mutante mata 8 casos en total (los tres de arriba, sus gemelos en los otros
harnesses y los dos casos nuevos del manager). Restaurado.

### 🟢 El código

`src/drivers/openfga_driver.ts` · `countRoleAssignments`: por cada rol, los `role_binding` que
apuntan a él (`user: role:<uuid>`, `relation: role`, `includeExpired` — la arista estructural no
caduca) y, por binding, sus `assignee` **sin** `includeExpired` (la caducidad va en la *condition*, y
es la misma con la que responde `authorize`). Un `user` que no se entiende como holder **se cuenta
igual** (a diferencia de `listSubjects`): aquí contar de más marca el rol para que un humano lo mire,
y contar de menos es decir «no concede» sobre algo que sí. Capacidad `countRoleAssignments: facts`;
en modo `resolver` el constructor retira el método, como ya hacía con `purgeRole`.

### 🔴 Mutante sobre el driver de `facts` (el conteo cuenta caducados)

```
❯ authorization contract [openfga facts · 2.2] / countRoleAssignments(uuids) cuenta los hechos
  VIGENTES de cada rol en TODOS los scopes y responde POR POSICIÓN: …
ℹ AssertionError: …y tampoco cuenta: expected [ 4, +0 ] to deeply equal [ 3, +0 ]
```
Restaurado.

---

## 4 · Pieza 3 — la capacidad y su par en la suite publicada

`src/testing/contract.ts`, `caseFor('countRoleAssignments', …)` (nivel `'2.2'`), que es lo que un
driver de terceros corre para saber qué se le exige:

- **`whenTrue`** — *«countRoleAssignments(uuids) cuenta los hechos VIGENTES … POR POSICIÓN»*: el
  método existe en el puerto; rol recién definido ⇒ 0; hechos en dos scopes y de dos holders ⇒ 3;
  el caducado no concede **y tampoco cuenta**; `[]` ⇒ `[]`; el orden es el de la pregunta; uuid
  desconocido ⇒ 0; uuid mal formado ⇒ 422 `E_AUTHZ_INVALID_IDENTITY`; cada `revoke` baja el contador
  hasta cero. Corre en `database` (×2 en memoria, ×3 con árbol SQL) y en `openfga facts`.
- **`whenFalse`** — *«sin countRoleAssignments: el puerto NO lo trae y pruneOrphanRoles deja
  stillGranting (y assignments) en `undefined` —JAMÁS en `false`—»*: `driver.countRoleAssignments`
  es `undefined`; sobre un huérfano que **sí** concede (nieto vivo con el owner en su cadena), el
  barrido devuelve `undefined` en los dos campos y **no** `false`, y el `--dry-run` no purga (el
  `purgeRole` de la vista falla el caso si llega a llamarse). Corre en los harnesses `openfga`
  (modo `resolver`), que es justo el driver donde el `false` era peligroso.

`tests/contract_harness.spec.ts` (la regla de capacidades, ejecutable) sube sus literales: 78 → **79**
casos en `'2.2'` con `NONE`, 73 → **74** sin `listDenies`, 82 → **83** con reloj; y añade que
`countRoleAssignments: true` por debajo de `'2.2'` se **rechaza** al registrar (promesa sin juez).

Capacidad declarada en los harnesses: `database` y `openfga facts` ⇒ `true`; `openfga` en
`resolver` (los dos harnesses) ⇒ `false`. `tests/openfga_facts.spec.ts` fija el objeto de
capacidades de los tres drivers y el recuento de sitios que leen el tipo `role` (guardia A6: 5 → **6**,
el sexto es este método).

---

## 5 · Pieza 4 — el comando lista el `undefined` APARTE

`commands/authz_catalog_prune_orphans.ts`: el reparto —lo único que el comando decide— sale a una
función pura exportada, `orphanLines(orphans, purged, skipped)`, con **tres** cubos:

| `stillGranting` | Salida |
|---|---|
| `false` | línea normal (`logger.log`) — el único cubo del que se puede decir «no concede» |
| `true` | `warning` · `TODAVÍA CONCEDE` + aviso final (3b-0b · AA1) |
| `undefined` | `warning` · `NO SE SABE SI CONCEDE` + **aviso final propio**, que nombra `countRoleAssignments` y avisa de que `--force` los borra igual |

El caso: `tests/manager.spec.ts` · grupo *3b-2j · authz:catalog:prune-orphans lista aparte lo que
concede Y lo que no se puede demostrar*. **Mutante** (el reparto de antes, `!x.stillGranting` para el
cubo inerte):

```
❯ 3b-2j · authz:catalog:prune-orphans lista aparte lo que concede Y lo que no se puede demostrar /
  `false` es la única línea normal: `true` sale con TODAVÍA CONCEDE, `undefined` con NO SE SABE …
- Expected  - 0
+ Received  + 4
  Array [
    Object { "head": "purgado", "level": "log" },
+   Object { "head": "huérfano", "level": "log" },      ← el `undefined` listado como si no concediera
    Object { "head": "huérfano · TODAVÍA CONCEDE", "level": "warning" },
```
Restaurado.

---

## 6 · Documentación

- **`CHANGELOG.md`** — entrada nueva *Lot 3b-2j — `stillGranting` becomes a question for the driver
  (**breaking change to the port**)*: el problema medido, el método nuevo, qué le pasa a un driver de
  2.2 (dos campos `undefined`, tres cubos en el comando, capacidad juzgada por la suite publicada) y
  que `readLocalRoles` ya no cuenta hechos.
- **`README.md`** — fila `countRoleAssignments` en la tabla de capacidades de los tres drivers, línea
  en el stub del harness, párrafo nuevo del puerto (contrato completo del método) y el párrafo de
  `prune-orphans` reescrito: los hechos los cuenta el driver, y sin el método los dos campos son
  `undefined` y esos huérfanos se listan aparte.
- **`CLAUDE.md`** — invariante 18: el párrafo de `pruneOrphanRoles`.
- **Docblocks**: `manager.pruneOrphanRoles` (incluido el coste), `readLocalRoles` (por qué YA NO
  cuenta), los dos drivers, el comando y el `factsHarness` de `tests/contract.spec.ts`, cuyo listado
  de rojos pendientes pasa de tres a **dos**, con el tercero marcado como cerrado por este lote.

---

## 7 · Verificación

Todo contra los servicios reales (`:8101`, PG 18, MySQL 8.4). `npx tsc --noEmit -p tsconfig.json`,
`npm run typecheck`, `npm run check:purity` y `npm run build`: **OK**.

| Modo | Antes | Ahora |
|---|---|---|
| `npm test` (SQLite memoria) | 698 | **703 passed** |
| `npm run test:sqlite-file` | 700 | **705 passed** |
| `npm run test:pg` (PG 18) | 872 | **879 passed** |
| `npm run test:mysql` (MySQL 8.4) | 872 | **879 passed** |

Los `+5` de SQLite son: el caso negativo del manager, el del reparto del comando, la cara `whenTrue`
del par en los dos harnesses `database` y la cara `whenFalse` en el harness `openfga`. En PG/MySQL
son `+7`: los dos harnesses de árbol SQL suman su cara.

**Tope 3** (`openfga-tiny` en `:8103`, salida a fichero desde la primera pasada,
`/tmp/.../scratchpad/tope3.log`): **703 passed**, ninguna incidencia. El rojo intermitente sin
identificar del lote 2h **no reapareció**. Contenedor borrado.

### El juez contra `facts` (`AUTHZ_CONTRACT_FACTS=1`)

| | Antes (3b-2i) | Ahora |
|---|---|---|
| SQLite | 2 rojos | **1 rojo** — `790 passed, 1 failed (791)` |
| PostgreSQL | 3 rojos | **2 rojos** — `965 passed, 2 failed (967)` |

Los que quedan, nombrados:

1. **R2 (b)** — `authorizeMany: idéntico a N authorize por posición …; un scope que lanza ⇒ lanza
   entero` (`AssertionError: debería haber rechazado`). Con `singleCheckAuthorize: true` la decisión
   no pasa por el árbol. SQLite y PG. **Pendiente, correcto.**
2. **R2 (c)** — `un alias del uuid del scope (mayúsculas, guiones quitados) jamás evade un deny …`.
   Solo con árbol SQL (PG/MySQL). **Pendiente, correcto.**

El tercero —`pruneOrphanRoles().stillGranting`— es el que este lote cierra: **verde**.

---

## 8 · Higiene

- **Stores en el `:8101`: 50 al empezar y 50 al acabar.** Ninguno con prefijo mío.
- **`openfga-tiny` borrado** tras la tanda de tope 3.
- **Bases**: cero `authz_test%` residuales en PG 18 y en MySQL 8.4.
- **Diff**: 15 ficheros, +568 / −91. `CHANGELOG.md`, `CLAUDE.md`, `README.md`,
  `commands/authz_catalog_prune_orphans.ts`, `src/catalog_cache.ts`, `src/drivers/database_driver.ts`,
  `src/drivers/openfga_driver.ts`, `src/manager.ts`, `src/testing/contract.ts`, `src/types.ts`,
  `tests/catalog_cache.spec.ts`, `tests/contract.spec.ts`, `tests/contract_harness.spec.ts`,
  `tests/manager.spec.ts`, `tests/openfga_facts.spec.ts`. **Sin commits.**
- Ni un `skip`. Todos los errores nuevos con `status` + `code` (`E_AUTHZ_INVALID_IDENTITY` 422,
  `E_AUTHZ_INTERNAL` 500).

---

## 9 · Lo que NO hice, y por qué

1. **No cambié `authz:reconcile` ni el `--prune` de 3b-3** para que use el conteo nuevo. No está en
   el encargo y `reconcile` compara hechos contra el catálogo, no cuenta por rol; mezclarlo aquí
   sería diseñar el lote siguiente.
2. **No hice `countRoleAssignments` obligatorio en el puerto.** La decisión del dueño dice
   *opcional*, y hacerlo obligatorio rompería al COMPILAR a todo driver de terceros escrito para
   2.0/2.2 (el mismo argumento que 3E · Q4 para `purgeRole`).
3. **No añadí un `countRoleAssignments` de mentira al `openfga` en modo `resolver`.** Podría contar
   leyendo el store entero, pero es justo lo que 3b-2e · E4 rechazó para `purgeRole`: un método que
   solo puede responder caro y mal es peor que no traerlo, y con `purgeRole: false` ese driver ni
   siquiera llega a `pruneOrphanRoles` (500 antes de leer nada).
4. **No hice que `stillGranting` re-resuelva el scope de cada hecho.** Seguiría siendo un
   `resolveChain` por asignación y el campo es —y se documenta como— conservador. Cambiarlo es otra
   decisión, no ésta.
5. **No toqué los dos rojos pendientes del juez** (R2-b y R2-c): el encargo los declara pendientes y
   correctos.
6. **No arreglé la mezcla de versiones del README** («since 2.2» / «since 2.3» conviviendo con un
   CHANGELOG cuyo *Unreleased* dice 2.2.0). Escribí «2.3» por coherencia con las 16 referencias que
   la Fase 3b ya había dejado, pero **el número de versión de este ciclo es una decisión del dueño**
   y merece una pasada aparte.
