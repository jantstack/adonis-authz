# Fase 3b · Lote 7 — el `freeze()` durable (decisión B + E-analista)

> **Estado: CERRADO.** Las cuatro suites en verde sobre el árbol final.
> Fecha: 2026-08-31 · Árbol principal, rama `v2/fase-3b`, base `3cf300f`.
> Encargo: decisión del dueño del 2026-08-31 (3b) — B entera + E-analista,
> con el cutover en alcance (F1–F7). Sin commits (los hace el dueño).

## Decisiones de diseño (tomadas antes de escribir código)

1. **Dónde vive el freeze**: la fila `id = 2` de `authz_catalog_version`, con
   cuatro columnas nuevas (`freeze_reason` varchar(255) null, `freeze_holder`
   varchar(120) null, `freeze_until_ms` bigint null, `freeze_fence` bigint
   not null default 0), inofensivas para la fila `id=1`. Colocación medida
   por el analista (renovación 10-12 ms contra el `FOR UPDATE` del catálogo,
   no 805-816); consulta de barrera PROPIA y sin memo (juez C2): el número
   defendido es +0,14 ms p50 por escritura (PG) / +0,11 (MySQL), 0 en
   `authorize`.
2. **Cómo aparece la fila `id=2`**: sembrada en el stub de migración
   publicado (y en el espejo de tests, y en la receta 1.x→2.x del README,
   que `upgrade_recipe.spec` ejecuta). **Sin upsert perezoso**: un write en
   el camino de lectura de la barrera, fuera de `withAuthzCatalogWrite`,
   sería una carrera gratis. En runtime, una base sin la fila (o sin las
   columnas) ⇒ **503 «migración 2.0 no aplicada» en TODA escritura** — el
   mismo patrón que la fila `id=1` (invariante 14); leerla como «no
   congelado» sería exactamente la promesa incumplida que este lote quita.
   Breaking declarado en el CHANGELOG con la receta (`ALTER TABLE … ADD
   COLUMN ×4; INSERT id=2`).
3. **Token de dueño** (`FreezeToken = { fence, holder }`, `holder` =
   `<kind>:<pid>:<8hex>` con `kind ∈ {operator, reconcile, platform}`):
   `freeze()` pasa a ser async y devolverlo; `unfreeze(token)` es
   condicional en SQL (fence+holder) — uno ajeno o rezagado no toca nada.
   `frozen` (getter) pasa a significar «¿SOSTIENE este manager un freeze?»;
   la pregunta de flota es `freezeStatus()` (la fila).
4. **Lease renovado**: default 15 000 ms (`DEFAULT_FREEZE_LEASE_MS`),
   renovación condicional cada `leaseMs/3` con `setInterval(...).unref()`
   (`WHERE fence=? AND holder=? AND until_ms > now`); 0 filas ⇒ `lapsed=true`
   y el renovador PARA (nunca «recupera» un freeze que dejó de ser suyo).
   `leaseMs: null` = sin caducidad. El reloj es el de PARED del config
   (`config.clock ?? systemClock`) — el mismo que decide caducidades — y por
   eso todos los casos de lease van con reloj inyectado y sin `sleep`.
5. **El anidado y el choque (F4)**: si el manager raíz YA sostiene un freeze,
   una ventana interior (`withFrozenWrites` o `reconcile`) corre DENTRO y su
   cierre es un no-op (A1.1/A1.3 fijados con caso y con mutante). Un freeze
   vivo de OTRO dueño ⇒ **423 `E_AUTHZ_FREEZE_HELD`** (error nuevo,
   exportado por `index.ts`) — salvo el de OPERADOR, que `reconcile`
   reconoce como contexto propio (F6).
6. **`#assertNotFrozen` async**: la barrera lee la fila en cada escritura
   (fast-path sin SQL solo si ESTE proceso sostiene el token). Consecuencia
   mecánica: `#writeOptions` y `#requireActor` pasan a async (los ~10
   call-sites que el tester contó), y en `pruneOrphanRoles` la barrera va
   DESPUÉS del check de `purgeRole` — «no sé purgar» es permanente y se dice
   sin consultar NADA (promesa medida del 3b-1, su caso cuenta 0 consultas).

## Las piezas, con su rojo

### F2+F3+F4 · El freeze durable, el token y el lease (`src/freeze.ts` + manager)

Caso primero (`tests/freeze.spec.ts`, «el freeze de un manager congela a
OTRO manager del mismo backend»), rojo literal contra el código del lote 6:

```
❯ 3b-7 · freeze durable — la fila, el token y el lease / el freeze de un manager congela a OTRO manager del mismo backend (la fila, no la memoria)
ℹ AssertionError: freeze() devuelve el token del dueño: expected undefined to be an object
❯ … / unfreeze AJENO no levanta la barrera de otro (el token manda)
ℹ TypeError: Cannot read properties of undefined (reading 'fence')
Tests  5 failed (5)
```

Verde con `src/freeze.ts` (primitivas SQL puras: `readFreezeRow`,
`freezeIsLive`, `acquireFreeze` condicional+atómico, `renewFreeze`,
`releaseFreeze` — la policy vive en el manager) + el rework del manager.
Casos del grupo: durable entre managers (asimetría de lectura incluida),
unfreeze ajeno no-op + segundo freeze 423, lease vencido ⇒ la flota escribe
sola (reloj inyectado, sin sleep — el equivalente determinista del SIGKILL
del analista), `leaseMs: null` no caduca, y la barrera sobre las 7
escrituras + delegación ENTRE managers.

**Mutante del fence** (pieza implementada antes que su caso): `releaseFreeze`
sin el `WHERE fence/holder` (release incondicional) ⇒
`unfreeze AJENO no levanta la barrera de otro` ROJO (`Tests 4 passed,
1 failed`). Restaurado.

### F4 · El dueño en `reconcile` (A1.3, dos pasadas, contexto de operador)

Grupo nuevo «3b-7 · reconcile y el freeze durable» en `reconcile.spec.ts`:

- `report.frozen = { durable, lapsed:false, leaseMs:15000, fence }` en la
  pasada que escribe; `--dry-run` sin `frozen` (no congela — el caso del 3b-6
  sigue en pie).
- **A1.3**: `reconcile` dentro de una ventana congelada corre DENTRO y NO la
  levanta al terminar. Mutante (release incondicional de la ventana interior)
  ⇒ ROJO en ese caso exacto (`Tests 35 passed, 2 failed`). Restaurado.
- **Dos `reconcile` simultáneos ⇒ 423** con el mensaje nombrando la pasada
  viva (espera acotada, sin bucles infinitos: un fallo cuenta su motivo).
- **F6**: `reconcile` con freeze de OPERADOR vivo corre como contexto propio
  (fence del operador en el reporte, `leaseMs: null`, la ventana SIGUE en pie
  tras la pasada — el intervalo pasada→cutover es del operador). Mutante
  (ignorar `operatorAsContext`) ⇒ ROJO en los dos casos del cutover
  (`FreezeHeldError … operator:…`). Restaurado.
- **Fence**: el operador levanta su ventana a mitad ⇒ `lapsed=true`.

### F3 · `lapsed` publicado y el exit ≠ 0 (juez C4)

Rojo literal (el manager ya decía `lapsed=true`; faltaba la función pura):

```
❯ 3b-7 · reconcile y el freeze durable / el lease que caduca A MITAD de la pasada sale publicado: lapsed=true y el comando no certifica (juez C4)
ℹ AssertionError: lapsed=true ⇒ la pasada NO se certifica (exit ≠ 0): expected true to be false
```

Verde con `reconcileLines`: línea de error con el nombre del lease y
`clean &&= frozen?.lapsed !== true`. El caso simula la pausa del `m11` del
analista con reloj inyectado (la pasada «tarda» más que el lease) — sin
sleep.

### F6 · Los comandos del cutover

`commands/authz_freeze.ts` (`--reason` obligatorio, `--lease-ms` opt-in) y
`commands/authz_unfreeze.ts` (+ `--fence`), registrados en `commands/main.ts`.
La única decisión del unfreeze es la función PURA `unfreezePlan(status,
fence)` (patrón `reconcileLines`), con sus 3 casos; mutante (levantar
cualquier freeze sin `--fence`) ⇒ ROJO en «el de una PASADA viva no»
(`Tests 7 passed, 1 failed`). Restaurado.

**La decisión del lease de operador, justificada** (el encargo pedía elegir y
declarar la no elegida): **la ventana del operador NO caduca por defecto**.
Motivo: la duración de un cutover no se conoce de antemano — duración de la
ventana y tolerancia a la parada son magnitudes INDEPENDIENTES, el mismo
argumento del analista que tumbó el TTL fijo (§2.2) — y una ventana que
caduca a mitad del cutover devuelve EN SILENCIO el fail-open (escrituras al
driver que deja de ser fuente de verdad) que este mecanismo existe para
cerrar; con la respuesta firmada del dueño («la parada no me pesa si
garantiza el trabajo») la asimetría manda. El contra, declarado en README y
en el propio comando: olvidarse de `authz:unfreeze` deja la flota sin
escribir hasta que alguien lo ejecute — incidente RUIDOSO (cada 503 nombra el
motivo y el comando que lo levanta), no pérdida invisible. **La opción no
elegida queda disponible y declarada**: `--lease-ms` hace la ventana
auto-caducable SIN renovación (el comando termina: no hay proceso que
renueve), con SU contra impreso por el propio comando — un cutover más lento
que el lease devuelve a los escritores sin aviso, a mitad.

### F7 · La prueba multiproceso y el mutante `modulo`

`tests/freeze_multiprocess.spec.ts` + `tests/helpers/freeze_child.ts`
(patrón EXACTO de `expiry_timezone.spec.ts`: `execFileSync` de un hijo con
`bootApp({ reuse })`, el padre congela ANTES de lanzarlo — determinista, sin
sleep). Gateado a `pg`/`mysql`/`sqlite-file` con la limitación declarada EN
el propio spec: en `:memory:` la base es del proceso y un hijo no puede
abrirla. Dos casos, ~1 s en sqlite-file: control (sin freeze, el hijo
escribe) y congelado (503 `E_AUTHZ_FROZEN` en el hijo, `driverSawGrant:
false`, `frozenGetter: false` —lo ve por la fila—, `readOk: true` —la
asimetría entre procesos—, y tras `unfreeze` vuelve a entrar).

**El mutante `modulo`, plantado y muerto** (los cuatro verbos de
`src/freeze.ts` sobre una global de módulo en vez de la fila):

- `npm test` (SQLite `:memory:`) con el mutante: **`Tests 604 passed (604)`,
  VERDE** — incluidos los 9 de `freeze.spec.ts` (dos managers del mismo
  proceso comparten el módulo). La predicción del tester, reproducida en el
  árbol real.
- `TEST_DB=sqlite-file … --files=freeze_multiprocess` con el mutante:
  ```
  ℹ AssertionError: el freeze ALCANZA al otro proceso: eso es «durable»: expected 'accepted' to equal 'E_AUTHZ_FROZEN/503'
  Tests  1 passed, 1 failed (2)
  ```
- Restaurado; ambos verdes después.

Consecuencia escrita en `CLAUDE.md` y en el spec: los jobs de motor de CI no
son opcionales para esta garantía.

### F1+F5 · B entera: README, alcance honesto, CLAUDE.md

- Fuera del README (con caso de LETRA en `freeze.spec.ts`, patrón
  `scope_outbox.spec.ts:1800`, rojo antes de reescribir):
  «which is the one thing the report promises cannot happen» y «a
  maintenance window of seconds» (al tope declarado son ≈136 s: 0,136
  ms/hecho × 1 000 000, analista §2.1 — orden de magnitud, no cifra
  publicable, y así va escrito).
- Dentro: el freeze durable con su mecánica (fila, token, lease, fence,
  coste medido), la promesa recortada del tester A4 — **«another process
  gets a retryable 503», never «no write enters the window»** —, el alcance
  EXACTO (auditor 🟠 5): **no congela `syncAuthzCatalog`, `manager.driver()`
  ni el árbol SQL del consumidor**, solo alcanza a procesos que comparten
  `authz_*`, y la garantía es del MANAGER — «the published contract suite
  never checks it» para drivers de terceros (riesgo 4 del juez, declarado en
  vez de heredado en silencio).
- Sección nueva «The cutover window: `authz:freeze` / `authz:unfreeze`» con
  el intervalo nombrado y las dos variantes de lease con sus contras.
- Receta 1.x→2.x actualizada (las 4 columnas + INSERT id=2, PG y MySQL) — la
  ejecuta `upgrade_recipe.spec` contra el stub.
- Tabla de errores: `E_AUTHZ_FROZEN` reescrito + fila nueva
  `E_AUTHZ_FREEZE_HELD` (423).
- `CLAUDE.md`: la frase del invariante («el estado vive en el manager RAÍZ»)
  sustituida por la mecánica durable completa; entradas de mapa para
  `src/freeze.ts`, los comandos y los dos specs nuevos; roadmap con 3b-7.
- `CHANGELOG.md`: entrada 3b-7 estilo problema→decisión→receta→lo que NO se
  hace, breaking de esquema y de API declarados.

### La migración de esquema (pregunta explícita del encargo)

Decisión: **stub + espejo + receta del README** (ver Decisiones 2). No hay
consumidores publicados de 2.0 (sigue en `2.0.0-alpha.1`), así que el cambio
va dentro del mismo major; para una base ya migrada con el stub anterior, la
receta del CHANGELOG (ALTER + INSERT). El comportamiento ante la fila
ausente es fail-closed ruidoso con caso implícito en cada suite (la fila la
siembra el harness; `migration_stub.spec` fija la siembra y las columnas del
stub ejecutándolo en una base de trabajo).

### Hallazgo propio durante la verificación: la barrera interbloqueaba un pool de 1

La primera corrida completa con FGA dejó en rojo los tres casos del rollback
del consumidor (`scope_outbox.spec.ts`, «contra el servidor real»), por
`Test timeout`:

```
❯ 3b-2d · el rollback del consumidor… / SIN outbox: el rollback deja una escalada PERSISTENTE…
ℹ Error: Test timeout
```

Causa: `manager.scopes.moved(...)` dentro de la transacción del consumidor.
La barrera nueva lee la fila por el `db` global, es decir, pide OTRA conexión
del pool mientras el consumidor sostiene la suya — y con el pool 1/1 de
SQLite `:memory:` eso no es una lectura, es un interbloqueo (hasta el
timeout del pool). Arreglo: **la barrera lee por la transacción del llamante
cuando la escritura llega con una** (`ScopeTreeWriteOptions.transaction`,
la misma que la outbox ya usa para encolar), con el precio DECLARADO en el
docblock de `freeze.ts`: en un motor cuyo aislamiento por defecto congela la
foto (InnoDB REPEATABLE READ), un freeze puesto después de abrir esa
transacción puede no verse desde dentro — la misma ventana que una escritura
que ya pasó su barrera (tester A4), y por eso la promesa publicada es «otro
proceso recibe 503» y no «ninguna escritura entra». El caso SIN outbox del
spec pasa ahora su transacción (con comentario), que es la forma documentada.

## El comportamiento medido en SQLite (encargo explícito)

Medido en este árbol (script efímero, borrado):

| medida | sqlite-file | sqlite `:memory:` |
|---|---|---|
| barrera `SELECT id=2` (lo que paga cada escritura) | p50 **0,040-0,071 ms** · p95 0,075-0,108 (n=1000) | p50 **0,039 ms** · p95 0,070 |
| renovación `UPDATE` del lease | p50 **0,039-0,042 ms** · p95 0,072-0,088 (n=200) | p50 0,040 · p95 0,091 |

Declaraciones (no suposiciones):

1. **El freeze es durable también en SQLite**: la fila vive en el fichero y
   el caso multiproceso pasa en `sqlite-file` (1 s). En `:memory:` la base
   es del proceso: el freeze alcanza a todos los managers del proceso (la
   fila existe) pero «flota» no hay — es la MISMA degradación declarada que
   el lease de la outbox.
2. **SQLite serializa escritores**: una transacción de escritura abierta
   retiene la renovación del lease hasta que termina (medido en proceso: la
   sonda de renovación quedó sin resolver mientras el escritor sostenía la
   transacción; entre procesos better-sqlite3 espera síncronamente con
   `busy_timeout` 5 s). Consecuencia honesta, escrita: un escritor SQL largo
   puede retrasar la renovación; si el retraso supera el lease, el fence lo
   caza (`lapsed=true`) y la pasada no se certifica — el mecanismo falla
   DICIÉNDOLO, no concediendo.
3. La sonda de la barrera en SQLite es ~3× más barata que el +0,14 ms p50 de
   PG (es un fichero local): el coste publicado (el de PG) es el peor caso
   de los tres motores SQL.

## Cifras finales (tope 3 de corridas: se usaron 2 completas)

Contra el `:8101`, salida a fichero desde la primera pasada
(`…/scratchpad/suite-*.log` la primera, `…/scratchpad/final-*.log` la
definitiva):

| suite | antes (encargo) | ahora | estado |
|---|---|---|---|
| `npm test` (+FGA) | parte de 767 | **783 passed (783)** | ✅ exit 0 |
| `npm run test:sqlite-file` (+FGA) | parte de 770 | **788 passed (788)** | ✅ exit 0 |
| `npm run test:pg` (+FGA) | parte de 864 | **882 passed (882)** | ✅ exit 0 |
| `npm run test:mysql` (+FGA) | parte de 864 | **882 passed (882)** | ✅ exit 0 |

Más: `npx tsc --noEmit` ✅ · `npm run typecheck` ✅ · `npm run check:purity` ✅
(`src/freeze.ts` importa `@adonisjs/lucid/services/db` como ya hacía
`catalog_cache.ts`; ningún alias de consumidor) · `npm run build` ✅ ·
**0 stores** residuales en el `:8101` al terminar.

La PRIMERA pasada completa (la de fichero `suite-memory.log`) dejó dos cosas,
las dos con su historia:

1. Los 3 timeouts del rollback (hallazgo propio de arriba, arreglado y verde
   en la corrida final).
2. UN rojo en `facts · 3b-2e · E5` («a 22 saltos 3 de 10 lotes NO
   resolvieron») — **el intermitente que la caza en segundo plano persigue**,
   disparado por la contención de esa misma caza sobre el `:8101` (mi lote no
   toca la resolución de profundidad). En la corrida final no se reprodujo.
   Se lo dejo nombrado al dueño para el expediente de la caza.

El caso multiproceso cuesta **~1 s** en sqlite-file (2 spawns), como predijo
el tester.

## Lo que NO hice, y por qué

- **El testigo `readChanges({ startTime })`** para la dirección cuyo origen
  es el store: sigue sin implementar, como ya declara el README del 3b-6. El
  juez lo injertó como AVISO condicionado a medir retención/granularidad del
  changelog, y eso no está medido — publicarlo sin medir sería la clase de
  promesa que este panel corta.
- **Cerrar la ventana barrera↔escritura** (tester A4): imposible por
  construcción (una fila SQL y un backend externo no tienen atomicidad
  conjunta); se escribe, no se «mitiga». La promesa publicada es la
  recortada.
- **Entrada en la suite de contrato publicada**: el freeze es del MANAGER y
  `MigrationContractHarness` juzga drivers (sin manager, sin segundo
  escritor, sin segundo proceso); meter un gancho obligatorio rompería a los
  drivers existentes y uno opcional no es garantía (tester §5). Se declara
  en el README con esas palabras en vez de fingir cobertura.
- **Renovación observada con timer real en un caso**: el renovador va por
  `setInterval` real (`unref()`); los casos de lease usan reloj inyectado y
  las primitivas condicionales (`renewFreeze` con fence ajeno ⇒ false) — un
  caso con sleep de segundos para ver el timer disparar sería exactamente el
  tipo de test que el proyecto rechaza. El camino del timer queda cubierto
  por la corrida real de `reconcile` (que renueva durante la pasada) en las
  suites con FGA.
- **Medir el cruce renovación×`FOR UPDATE` en PG/MySQL otra vez**: lo midió
  el analista (10-12 ms en fila propia) y la implementación usa exactamente
  esa colocación; repetir la medida no cambiaba ninguna decisión.
