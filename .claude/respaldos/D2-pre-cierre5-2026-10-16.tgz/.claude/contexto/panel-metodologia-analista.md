# Panel de metodología — ANALISTA (2026-09-13)

Encargo: medir `metodologia-diagnostico-coordinador.md` contra el historial real, no opinar sobre él.
Solo lectura. Fuentes: `git log` completo (`242d846^..7fbc638`, cuerpos de commit), `git log -S` sobre el código
publicado, tags `v2.4.0-alpha.1..9` y `v1.x`, los seis informes de COGNITIV, los informes/auditores de cada lote
(`alpha3-*` … `alpha10-informe.md`, `l0..l6`), los paneles (`panel-trx-*`, `panel-alpha4-*`, `panel-relay*-*`,
`panel-shared-store-*`), `decisiones-dueno-2026-08-28.md` y `09-METODOLOGIA-DE-DESARROLLO.md`.

Convención de marcas: **[V]** verificado en código/git · **[I]** leído en un informe y no re-medido · **[A]** asumido/estimado.
Severidad en la escala de los auditores: CRÍTICO (= rojo) · ALTO (= naranja). Los MEDIOS/BAJOS solo aparecen en el anexo
cuando hacen falta para un patrón.

Hueco de evidencia: el commit de alpha.9 cita `alpha9-auditor.md`, **y ese fichero no existe en `.claude/contexto/`** [V].
Lo que sé de ese auditor sale del cuerpo del commit y de `tests/command_flags.spec.ts` («cierre alpha.9, 🟡 B del auditor»).

---

## 0 · Resultado en cinco líneas

1. **Hay 34 defectos graves corregidos (o mitigados) entre alpha.1 y alpha.10, no 7.** La tabla del coordinador omite 27.
2. **La tesis «se han mudado a la frontera» es cierta en QUIÉN los encuentra y falsa en CUÁNDO nacieron.** De los 12
   que encontró COGNITIV, 9 son anteriores a `2.4.0-alpha.1` (Fase 3b, Fase 4, e incluso `v1.0.0`). No se mudaron:
   **estaban ahí desde el principio en capas que nadie ejecutaba**, y COGNITIV es el primero que las recorre.
3. **P2 es falso tal como está escrito.** El diff de alpha.8 AÑADIÓ tres banderas inertes (`--max-age` y
   `--wait-lease-ms` ×2, commit `b5868d8`) y el auditor lo dio APTA. Además, los auditores sí leyeron código fuera del
   diff y cazaron así seis defectos viejos. Lo que falla no es «leer solo el diff», sino **no ejecutar el sistema por
   su puerta real ni recorrer las secuencias del operador**.
4. **El patrón que no aparece en el diagnóstico, y que explica los «círculos», son los LINAJES.** La misma guarda se
   cierra punto de llamada a punto de llamada, y cada cierre deja abierta la siguiente variante. Hay seis linajes con 2 a 5
   iteraciones cada uno: F-05, la puerta `{transaction}`, la barrera del freeze, el tapón del relay, la entrada inerte
   silenciosa y el origen rancio del reconcile. Ninguna de las medidas M1–M6 ataca esa forma.
5. **Contrafactual (S = 1, P = 0,5): M4 9,0 · M3 7,0 · M1 6,0 · M5 5,5 · M2 3,0 · M6 0.** Una medida nueva de
   *guardia estructural de superficie* (M7, abajo) saca 11,0. **11 de los 34 no los caza ninguna M1–M6.**
   **El criterio «M4 da APTA» es malo, y hay datos:** las últimas cinco veces que un auditor dio APTA (alpha.3 final, alpha.4, alpha.6,
   alpha.8 y alpha.9), el informe siguiente trajo un defecto grave.

---

## 1 · Inventario de defectos graves (alpha.1 → alpha.10)

Fechas de publicación (fecha del tag [V]): alpha.1 09-01 15:50 · alpha.2 09-02 11:26 · alpha.3 09-02 16:16 ·
alpha.4 09-09 16:56 · alpha.5 09-10 13:45 · alpha.6 09-10 15:58 · alpha.8 09-11 08:46 · alpha.9 09-13 11:12
(`CLAUDE.md` dice 09-11; `RETOMAR.md` y el tag dicen 09-13; uso el tag) · `v1.0.0` 07-29. alpha.10 no está publicada.

Capas: **N** núcleo del contrato · **P** puerto/driver · **M** manager · **C** comando/CLI · **I** integración con
Adonis/ace/Lucid/knex/motor · **X** composición entre subsistemas · **O** operación temporal/runbook · **D** documentación.
Detector: **PnP** panel previo (de otra feature, leyendo código existente) · **Impl** implementador midiendo ·
**Tst** tester · **Coord** barrido de forma del coordinador · **AudD** auditor sobre el diff · **AudR** re-ataque del
auditor · **COG** COGNITIV · **PnP←COG** panel lanzado por un aviso de COGNITIV.

| # | Defecto | Sev | Introducido (commit) [V] | Detectado en | Detector | Capa | Publicado |
|---|---|---|---|---|---|---|---|
| 1 | F-05 solo en el manager; los drivers no revalidan (`driver.relate` compone un `role_binding` real y concede) | CRÍT | Fase 4-2 `b8cf492` | pre-alpha.2 | PnP (panel `{trx}`, 🔴 2) | P + X | ~20 h (a.1→a.2) |
| 2 | La barrera del freeze se lee por la trx del llamante (un snapshot se la salta) | ALTO | 3b-7 `49f3010` | pre-alpha.2 | PnP (🟠 8) | M + O | ~20 h |
| 3 | El deadline de knex no cubre la espera del pool: 60 007 ms para uno de 300 ms (barrera colgada) | ALTO | 3b-7 | L-1 | Impl (medido; contradice al juez) | I | ~20 h |
| 4 | La outbox ignora `connection`, y `db` entero pasa como trx (encola fuera de la unidad de trabajo sin avisar) | ALTO | 3b-2d `2ef4f6b` | pre-alpha.2 | PnP (🟠 9) | P + I | ~20 h |
| 5 | Relaciones sin barrera de freeze; `authz:relations:reconcile` no congela | ALTO | Fase 4 (posterior a 3b-7) | pre-alpha.2 | PnP (juez, J1) | X + O | ~20 h |
| 6 | El UNIQUE de `authz_relations` no defiende holders (NULL ≠ NULL): filas dobles | ALTO | Fase 4-3 `d39838f` | L-4 | Impl (caso de motor) | P (esquema) | ~20 h |
| 7 | Los drivers `openfga` ignoraban `{transaction}` si se entraba por `driver()` (atomicidad fingida) | ALTO | L-2 `c2937db` (puerta solo en el manager) | L-5 | Impl (rojo literal) | P | 0 |
| 8 | El provider no cablea `assertWrite`/`onRelationWrite` de relaciones | ALTO | Fase 4-8 `7b5d4db` | alpha.3 | COG (T2) | I | ~24 h |
| 9 | `RelationWriteEvent` sin `transactional`, y el README de L-6 lo prometía | ALTO | Fase 4-2 / L-6 `d209895` | alpha.3 | COG + Tst (H4) | D + M | ~24 h (letra falsa ~5 h) |
| 10 | El invariante 13 no se cumple en relaciones (sin `indeterminate`) | ALTO | Fase 4-2 | alpha.3 | Coord (barrido de paridad) | M | ~24 h |
| 11 | Las purgas de relaciones no emiten evento | ALTO | Fase 4-2 | alpha.3 | Coord | M | ~24 h |
| 12 | Un sink que lanza tumba un `relate` ya escrito (H1; `onRelationWrite?.(` sin `await`) | CRÍT | Fase 4-2 `b8cf492` | alpha.3 | Tst | M | ~24 h |
| 13 | Un `assertWrite` async es un bypass silencioso (H2) | CRÍT | Fase 4-2 | alpha.3 | Tst | M | ~24 h |
| 14 | El `actor` de relaciones no se valida (H3) | ALTO | Fase 4 | alpha.3 | Tst | M | ~24 h |
| 15 | F-05 no cubre las purgas: `purgeObject(role_binding)` borra asignaciones reales (con evento limpio) | CRÍT | Fase 4-2; **L-0 lo declaró «fuera de la AC»** (`cef972d`) | alpha.3 | AudD (leyendo fuera del diff) | X + M/P | ~24 h |
| 16 | F-05 no cubre las lecturas: `listSubjects` enumera los asignados de un rol | ALTO | Fase 4-2 / L-0 | alpha.3 | AudD | X | ~24 h |
| 17 | Un `assertWrite` que devuelve un booleano es fail-open (el cierre de H2 solo tapó el thenable) | ALTO | Fase 4-2; cierre a medias en el diff de alpha.3 | alpha.3 | AudD | M | ~24 h |
| 18 | REGRESIÓN DEL CIERRE: `relation?` opcional apaga F-05 en `relate`/`unrelate` | ALTO | cierre de alpha.3 (sin commit) | alpha.3 | AudR | M/N | 0 |
| 19 | `commands/main.ts` no es un loader de ace: `node ace` revienta entero | CRÍT | **`v1.0.0` `6eaf5ef`** | alpha.4 | PnP←COG (tester) | I | **42 días (desde v1.0.0; sigue en `latest` 1.1.0)**; 8 días en 2.4 |
| 20 | `openfga:provision` (`startApp: false`) lee `app.config` antes del `boot()`: TypeError siempre | ALTO | **`v1.0.0` `6eaf5ef`** (v1.1.0:37 [V]) | alpha.4 | COG | I + C | 42 días / 8 días |
| 21 | Los 503 de otros tenants consumen intentos; lo aparcado sale de `pending()` y deja de ordenar ⇒ padre VIEJO permanente | CRÍT (juez) | 3b-2h `0359b56` | alpha.5 | PnP←COG (auditor 🟠 4, el juez lo sube) | M + O | ~9 días |
| 22 | `GET_LOCK` recortado a 64 caracteres: dos despliegues comparten lease y quedan `busy` en silencio | ALTO | 3b-2h `0359b56` (`name.slice(0, 64)` [V]) | alpha.5 | PnP (juez, leyendo código) | P + I | ~9 días |
| 23 | REGRESIÓN de alpha.5: a un salto de una aparcada, la purga se aplaza para siempre | ALTO | lote alpha.5 (sin commit) | alpha.5 | AudD | M | 0 |
| 24 | REGRESIÓN de alpha.5: el censo de aparcadas queda acotado por `limit` (tapón ciego) | ALTO | lote alpha.5 (sin commit) | alpha.5 | AudD | M | 0 |
| 25 | La raíz `app` como clave de bloqueo = mutex de plataforma | CRÍT (bloqueante) | clave raíz en 3b-2h + tapón y sonda de alpha.5 `106c1b0` | alpha.8 | COG (3.er informe) | M + O | ~19 h (a.5→a.8) |
| 26 | El respaldo de `enumerateRelationsMany` pierde tuplas al reanudar con el cursor | ALTO | alpha.6 `a554ed6` [V] | alpha.8 | PnP (analista relay2) | M/P (respaldo) | ~17 h |
| 27 | La cola no tiene edad: una caída larga del store no dispara ninguna alarma | ALTO (bloqueante) | decisión de alpha.5 («503 no consume»), **ya declarada** como 🟡 5 del auditor | alpha.8 | COG | O | ~19 h |
| 28 | `requeue` no cierra el incidente en una pasada (`depends-on` de sí mismo) | ALTO (bloqueante) | diseño de alpha.5 | alpha.8 | COG | O + M | ~19 h |
| 29 | `enqueue` sin `{transaction}` = fuga S5 silenciosa en el uso correcto | ALTO | 3b-2d | alpha.8 (**mitigado opt-in**; default `true` en 2.5) | PnP (auditor relay2 🟠 7) + COG | P + I | ≥ 12 días, sigue por defecto |
| 30 | 18 banderas inertes en 7 comandos (`--dry-run` ESCRIBÍA; las relaciones migraban 0 con éxito) | CRÍT | 3G `6f87ee8`, 3b-0b, 3b-2d, 3b-3a/3b, 3b-7, Fase 4-6, **alpha.8 `b5868d8`** (3 nuevas) [V] | alpha.9 | COG (4.º y 5.º) | C + I | ~12 días en npm; alcanzable por la vía documentada solo desde alpha.4 (~4 días); las de alpha.8, ~2 días |
| 31 | `authz:reconcile --prune` borra TODAS las relaciones de un store compartido, con `clean=true` y exit 0 (y, sin `--prune`, `clean=false` para siempre) | CRÍT | catch-all de `familyOfTuple` en 3b-3a `047dc9d`; dañino desde el store fusionado de Fase 4 | alpha.9 | COG (5.º) | X | ~12 días |
| 32 | `--to=<activo> --from=<otro>` resucita las revocaciones posteriores al cutover | CRÍT | 3b-5 `e4a5102` (el cierre del 🔴 2 de 3b dejó abierta la vía `--from`) | alpha.10 | COG (6.º) | M + O | ≥ 12 días, sigue publicado |
| 33 | `authz:unfreeze` responde éxito con la ventana CADUCADA | ALTO | 3b-7 `49f3010` (`if (!freezeIsLive` → `null` → noop) | alpha.10 | COG | C + O | ≥ 12 días (por API); por el comando, desde alpha.9 |
| 34 | La pasada de mantenimiento dice «no escribe ni borra un solo hecho» y con `--prune` borra | ALTO | 3b-5 `e4a5102` [V] | alpha.10 | COG | D + C | ≥ 12 días |

Anexo (MEDIO, no entran en los totales; hacen falta para §3): la media pareja `--partition-*` (defecto presente desde Fase 4-6,
cazado por el auditor de alpha.9 como 🟡 B) · **`--partition-type=app --partition-uuid`**, la fila de la tabla de verdad que el cierre de alpha.9
no enumeró (COG, 🟡) · `leaseMs: null` en la ventana adoptada (COG, 🟡) · **hueco ABIERTO en alpha.10**: con `database`
activo, `--to=database` sin `--from` elige solo `openfga` como origen, que es la misma dirección rancia que el nº 32
(`alpha10-informe.md:53-56`).

Cazados en DISEÑO sin llegar nunca a código (no cuentan como defecto, pero miden el panel previo): `capabilities()` que
envenena la caché (alpha.4), `only` sin sonda, `requeue` sin sonda y `Read` por prefijo (relay), supersede y
`parkAfterMs` (relay2), `deny_binding` tratado como ajeno y la clasificación leída en runtime (shared-store). **Ocho.**

### 1.1 · ¿Se mudaron a la frontera? Lo que dicen los números

| Periodo | Defectos | Internos (PnP/Impl/Tst/Coord/AudD/AudR) | COGNITIV (directo o ←COG) |
|---|---|---|---|
| tramo alpha.2 (1–7) | 7 | 7 | 0 |
| alpha.3 (8–18) | 11 | 9,5 | 1,5 |
| alpha.4 (19–20) | 2 | 0 | 2 |
| alpha.5 (21–24) | 4 | 3 | 1 (nº 21, lanzado por COG) |
| alpha.8 (25–29) | 5 | 1,5 | 3,5 |
| alpha.9 (30–31) | 2 | 0 | 2 |
| alpha.10 (32–34) | 3 | 0 | 3 |

**Confirmado:** el detector se desplaza de dentro a fuera.
**Refutado:** la edad. Encontrados por COGNITIV: nº 8, 19, 20, 25, 27, 28, 30, 31, 32, 33 y 34, más el 21 por aviso suyo. Nacidos antes de
alpha.1: 8, 19, 20, 21, 30 (en su mayoría), 31, 32, 33 y 34. **Los únicos «nuevos de frontera» son 25, 27 y 28 (las tres,
consecuencias operativas de decisiones de alpha.5) y las tres banderas de alpha.8.** La frontera no es un sitio al que se
hayan mudado los defectos: es el sitio que la metodología nunca recorrió.

**Por capa.** Los nº 1–18 son M/P/X del núcleo; los nº 19–34 son I/C/O/X en 13 de 16 casos.
**Por quién, dentro:** los auditores encontraron defectos VIEJOS leyendo código ajeno al diff (nº 1, 2, 4, 5, 15, 16, 22,
26), así que «auditamos cambios, no el sistema» es inexacto. **Ninguno** de los defectos de C/I/O lo encontró alguien
interno sin un aviso previo de COGNITIV.

---

## 2 · Contrafactual: defectos × medidas

Pregunta: aplicada ANTES de publicar la versión que introdujo el defecto, ¿lo habría detectado? **S** sí · **P** probable ·
**N** no. Aplico M4 como si se corriera en esa publicación, aunque el diagnóstico lo pone solo antes de la estable.
**M7** es la medida nueva que propongo en §3 (se incluye para comparar). La columna «por qué» justifica cada S/P. El N por
defecto se explica por la capa: no es comando (M2), ni cierre (M3), ni operación larga (M5), ni un paso del runbook (M1).

**Sesgo retrospectivo que declaro:** M1 enumera «repetir migración, ventana caducada, mantenimiento», que son
literalmente los tres hallazgos de alpha.10. Un runbook escrito ANTES no los traería necesariamente. Por eso a M1 le doy
P, y no S, en los nº 32–34.

| # | M1 | M2 | M3 | M4 | M5 | M6 | M7 | Por qué (solo S/P) |
|---|---|---|---|---|---|---|---|---|
| 1 | N | N | P | P | N | N | S | M3: F-05 NACIÓ como cierre de un 🔴 (4-2) y una tabla capas×guarda da la fila «driver». M4: el docblock «defensa en profundidad» era falso. M7: enumerar las entradas que llegan al store |
| 2 | N | N | N | N | P | N | N | M5: el estado «durante la ventana, con una trx abierta antes del freeze» |
| 3 | N | N | N | N | N | N | N | Semántica de knex bajo pool 1; lo cazó la medición |
| 4 | N | N | N | N | N | N | N | Despliegue con dos conexiones; ningún recorrido lo toca |
| 5 | P | N | N | P | P | N | S | M1: solo si el paso del freeze afirma también las escrituras de RELACIONES. M4: lo que el freeze «no congela» se lista sin relaciones. M7: barrera × cada escritura de los dos managers |
| 6 | N | N | N | N | N | N | N | NULL ≠ NULL bajo concurrencia; lo cazó un caso de motor |
| 7 | N | N | N | N | N | N | S | M7: puerta × capa (manager y driver) |
| 8 | N | N | N | P | N | N | P | M4: el operador busca los hooks de relaciones en `defineConfig`. M7: paridad de config roles↔relaciones |
| 9 | N | N | N | S | N | N | P | M4: README ↔ comportamiento, el objetivo explícito. M7: paridad del evento |
| 10 | N | N | N | P | N | N | P | M4: el invariante 13 publicado como general. M7: paridad del evento por escritura |
| 11 | N | N | N | N | N | N | P | M7: «toda escritura emite», enumerado |
| 12 | N | N | N | N | N | N | P | M7: paridad del despacho del hook |
| 13 | N | N | N | N | N | N | P | Ídem |
| 14 | N | N | N | N | N | N | P | M7: validación del actor × escritura |
| 15 | N | N | P | P | N | N | S | M3: L-0 escribió «fuera de la AC»; la tabla exige caso o «imposible». M4: la sección de `purgeObject`. M7: F-05 × las 8 operaciones |
| 16 | N | N | P | N | N | N | S | Ídem, lecturas |
| 17 | N | N | S | N | N | N | N | M3: el cierre de H2 tiene un eje discreto, el tipo de retorno (undefined/promesa/función/booleano) |
| 18 | N | N | S | N | N | N | P | M3: relación presente/ausente × operación. M7: caso por operación |
| 19 | S | S | N | S | N | N | P | Cualquier comando ejecutado por el loader real. M7 ≈ el C-5 «cada fichero está en el loader» |
| 20 | S | S | N | S | N | N | N | `provision` es el primer paso del cutover |
| 21 | N | N | P | N | P | N | N | M3: 3b-2h cerró el tapón; tabla pendiente/fallida/aparcada × dependiente. M5: backend caído durante el relay |
| 22 | N | N | N | N | N | N | N | Longitud de nombre en MySQL; no es combinatorio ni un paso del runbook |
| 23 | N | N | P | N | P | N | N | M3: origen del bloqueo × operación × saltos. M5: pasada repetida con aparcadas |
| 24 | N | N | P | N | N | N | N | M3: `limit` ≤ / > `batchSize` × censo |
| 25 | N | N | P | N | N | N | N | M3: clave del padre ∈ {raíz, no raíz}. El precio del tapón ESTABA declarado (adenda 09-10 (5)), pero no su peor instancia |
| 26 | N | N | N | N | P | N | P | M5: estado «reanudada». M7: paridad nativo↔respaldo |
| 27 | N | N | N | N | N | N | N | Ya estaba DETECTADO (🟡 5 de alpha.5) y se declaró: ninguna medida de detección lo cambia |
| 28 | N | N | N | N | P | N | N | M5: el «después» del incidente |
| 29 | N | N | N | N | N | N | N | Conocido desde 3b-2d (S5); decisión de default |
| 30 | S | S | N | S | N | N | S | Bandera real por el kernel afirmando efecto |
| 31 | S | N | N | P | N | N | N | M1: una ida y vuelta completa del paquete lleva relaciones en el store. M4: README de store compartido |
| 32 | P | N | S | P | S | N | N | M3: el cierre de 3b-5, `to` × `from` × antes/después del cutover. M5: «después». M1: repetir la migración documentada tras servir |
| 33 | P | N | N | P | S | N | N | M5: ventana caducada = «abortada». M1: solo si usa `--lease-ms` y lo deja vencer |
| 34 | P | N | P | S | P | N | N | M4: letra ↔ efecto. M3: mantenimiento × `--prune` |

**Totales (S = 1, P = 0,5):**

| Medida | S | P | Puntos | Contribución única (S/P que ninguna otra M1–M6 da) |
|---|---|---|---|---|
| M1 runbook | 4 | 4 | **6,0** | nº 31 (S) |
| M2 invocación | 3 | 0 | **3,0** | ninguna (19, 20 y 30 también los dan M1 y M4) |
| M3 tabla de verdad | 3 | 8 | **7,0** | nº 1, 15, 16, 17, 18, 21, 23, 24, 25 |
| M4 auditoría sin diff | 5 | 8 | **9,0** | nº 8, 9, 10 (letra y paridad) |
| M5 estados | 2 | 7 | **5,5** | nº 2, 26, 28 |
| M6 retirar el arreglo | 0 | 0 | **0** | — |
| **M7 guardia de superficie** (nueva) | 6 | 10 | **11,0** | nº 7, 11, 12, 13, 14 (ninguna M1–M6 los toca) |

**Sin cobertura de ninguna M1–M6: nº 3, 4, 6, 7, 11, 12, 13, 14, 22, 27, 29 (11 de 34).** Con M7 quedan 6 (3, 4, 6, 22, 27, 29):
cuatro de semántica de infraestructura en condiciones de despliegue, que ya caza «mide contra lo real» (tres de esos cuatro los
encontró dentro un implementador o un panel), y dos decisiones ya declaradas.

**Por qué M6 = 0.** Ya se practica: todos los lotes desde L-0 registran «Mutantes: … rojos y restaurados», y el hallazgo
colateral «esto sigue verde» ya aparece (L-5: «con la puerta del MANAGER apagada, los casos por el manager siguen
VERDES»). Los casos que codificaban el defecto (P5) no se habrían descubierto retirando un arreglo: **no protegían
ningún arreglo, eran la especificación del defecto**. Las seis aserciones `f.name ?? f.flagName` (`2ef4f6b`, `106c1b0`,
`b5868d8`) se pusieron ROJAS con el arreglo, no verdes. Hay dos casos más de P5 que el diagnóstico no cita y M6 tampoco
habría encontrado:
- `tests/reconcile.spec.ts:994`: el caso «🔴 2» de 3b-5 migra con `from: 'database'` en un despliegue cuyo default ya es
  `openfga`. Es decir, fija como legítima la dirección del nº 32.
- `tests/freeze.spec.ts:306`: «sin freeze vivo: no-op en verde». Ahí «caducada» y «nunca hubo» se funden, que es el nº 33.

**Sobre M4:** saca la puntuación más alta de las seis, pero no se sostiene como gate.
(a) Sus S en los nº 19, 20 y 30 los dan también M1/M2, que son automáticas, y su aportación única se reduce a divergencias de letra.
(b) Es un juicio, y el juicio del auditor sobre el sistema tiene historial: tras cada APTA final (alpha.3, alpha.4, alpha.6,
alpha.8 y alpha.9) la ronda siguiente trajo defectos graves: tras alpha.3 los nº 19 y 20; tras alpha.4 el 21; tras
alpha.6 el 25 y el 26; tras alpha.8 el 30 y el 31; tras alpha.9 del 32 al 34. Salvo el 25 y el 26, todos llevaban publicados
desde ANTES de esa APTA, y en alpha.8 el propio diff auditado contenía tres banderas inertes.

---

## 3 · Patrones que el diagnóstico NO vio

### 3.1 · LINAJES: la guarda se cierra punto de llamada a punto de llamada, no por superficie (esto son los «círculos»)

| Linaje | Iteraciones [V] | Qué quedaba fuera cada vez |
|---|---|---|
| **F-05** | 4-2 `b8cf492` (manager) → L-0 `cef972d` (drivers, SOLO `relate`/`unrelate`: «check/list*/purge* … fuera de la AC») → alpha.3 (purgas y lecturas, nº 15/16) → cierre-1 (regresión `relation?`, nº 18) → cierre-2 (`membersOf`, 🟡 3) | la operación siguiente |
| **Puerta `{transaction}`** | L-2 `c2937db` (manager) → L-5 `6a05884` (drivers, nº 7): «Otra vez "el mismo bug, una puerta más allá"» (cita del commit) | la capa siguiente |
| **Barrera del freeze** | 3b-7 (escrituras de roles) → L-1 (lectura por la conexión del motor, nº 2) → J1 (relaciones, nº 5) | el subsistema siguiente |
| **Tapón del relay** | 3b-2h (tapón permanente) → alpha.5 R2a (aparcado, nº 21) → cierre de alpha.5 (un salto y `limit`, nº 23/24) → alpha.6 (exención bajo `only`) → alpha.8 (raíz, nº 25) | el estado o la clave siguiente |
| **Entrada inerte silenciosa** | alpha.8 X-1 (opción desconocida de la API ⇒ 500; **no se barrió la CLI en el mismo lote**) → alpha.9 (18 banderas, nº 30) → cierre de alpha.9 (media pareja) → alpha.10 (`app` + uuid) | la combinación siguiente |
| **Origen rancio del reconcile** | 3b-5 (pasada por defecto) → alpha.10 (`--from`, nº 32) → **abierto**: `--to=database` sin `--from` (`alpha10-informe.md:53`) | la bandera siguiente |

Seis linajes explican 17 de los 34 (nº 1, 2, 5, 7, 15, 16, 18, 21, 23, 24, 25, 30, 32 y, por paridad, 10–14 como réplica
parcial de las garantías de roles en relaciones). La metodología escrita dice «barrer la FORMA entera» (`09-METODOLOGIA`
§composición), pero el barrido es un `grep` y cada iteración decidió a mano su alcance. **M3 caza la variante de ENTRADA
dentro de un cierre; no caza la variante de SUPERFICIE** (otra operación, otra capa, otro puerto), porque los ejes de la
tabla también se eligen por intuición. El cierre de alpha.9 hizo 2 de las 4 filas.

**Medida propia, M7 · guardia estructural de superficie.** Para cada guarda transversal (F-05, barrera del freeze, puerta
`transaction`, `requireActor`/validación del actor, evento con los invariantes 13 y 14, rechazo de entrada desconocida,
origen del reconcile), un test que ENUMERA por reflexión las entradas y falla si alguna no tiene caso registrado o
exención escrita con motivo. Las entradas son: métodos de los prototipos de `AuthorizationManager`, `RelationsManager` y
los drivers, flags booteados de los comandos, y opciones de `reconcile`/`relay`/`requeue`. **El repo ya tiene tres
guardias de esta forma y funcionan:** `BOTH_FACES_REQUIRED`/`uncoveredCapabilities` (cada capacidad declarada tiene sus dos
caras), C-5 «cada fichero de `commands/` está en el loader» y A-G-2 (cada bandera es `dashCase`). M7 generaliza el patrón que ya
demostró funcionar a las guardas de seguridad.

**Medida propia, M8 · regla de tres en los linajes.** El tercer defecto de un mismo linaje no se parchea: se para, se
registra el linaje con su propiedad en forma universal («toda escritura que alcanza el store…») y el arreglo tiene que ser
un único punto de paso con su guardia M7. Contrafactual: con M8, la tercera iteración de F-05 (alpha.3) habría sido
estructural en vez de un `relation?` opcional (nº 18 P). La tercera del relay (cierre de alpha.5) habría obligado a
repensar las claves, raíz incluida (nº 25 P). **Coste: casi cero.** Es una regla de decisión más un registro de una
tabla. Encaja con el «simple primero, complejidad cuando el patrón se repite» de la casa.

### 3.2 · Lo DECLARADO cuya peor instancia nadie evaluó

- **nº 27**: «un 503 eterno no converge» se declaró en alpha.5 (🟡 5) y COGNITIV lo convirtió en bloqueante.
- **nº 25**: el precio del tapón se escribió («una aparcada congela todo bajo `org`», adenda 09-10 (5)), pero no su peor
  instancia, que es la clave `app`: la plataforma entera.
- **nº 29**: la fuga S5 se aceptó como opt-in.
- **R-15**: se difirió «sobre una SUPOSICIÓN del coordinador» (corrección del 09-01).

La regla de parada («los menores se anotan») es sana, pero **clasifica por explotabilidad y no por impacto en la
operación del cliente**. Medida barata: todo límite o precio declarado lleva su peor instancia medida (¿y si la clave es
la raíz? ¿y si la caída dura una hora?) y se pregunta a COGNITIV antes de publicarlo. Contrafactual: nº 25 S, nº 27 S,
nº 28 P, nº 29 P.

### 3.3 · Semántica del framework ANFITRIÓN asumida, no medida

«Mide contra lo real» se aplicó a los BACKENDS de datos (OpenFGA, PG, MySQL), y ahí funcionó: los nº 3 y 6 los cazó la
medición, y el `Read` por prefijo se cazó en diseño. **No se aplicó al anfitrión**, que es Adonis:
- nº 19: el loader llama `getMetaData` sobre el namespace.
- nº 20: `app.config` no existe antes de `boot()`.
- nº 30: `name` no es `flagName`.
- nº 8: el provider.

Hasta alpha.4 no existía ni un kernel de ace en los tests (`0d8e295`: «NINGÚN caso ejecutaba un comando por el kernel»).
Los nº 19 y 20 llevan en `latest` (1.1.0) desde el 07-29 [V: `v1.1.0:commands/main.ts`, `v1.1.0:commands/openfga_provision.ts:24,37`].
Esto no es un patrón de proceso nuevo: es P1 aplicado al framework. Pero conviene nombrarlo, porque la regla escrita
(«mide contra lo real») tenía un perímetro implícito, «real = backend de datos», y ese perímetro es el hueco.

### 3.4 · Cómo se cierran: las regresiones de cierre, medidas

Defectos NACIDOS dentro de un cierre: **nº 17** (cierre a medias de H2), **18**, **23**, **24**, **25** (consecuencia de R2a),
**32** (cierre de 3b-5), más la variante `app` + uuid (🟡) y el hueco abierto de alpha.10. Son **6 graves de 34 (18 %)**.
El re-ataque del auditor cazó 3 de 3 (nº 18, 23, 24) de los que viven DENTRO del diff y son lógicos. Se escaparon los 3 cuyo
disparo es operativo (nº 25 con tráfico real, 32 después del cutover) o de superficie (17). Así que el re-ataque ya
funciona para lo que puede ver, y no hace falta más ceremonia ahí. Lo que falta es que el cierre re-enuncie la propiedad
de forma universal (M8) y enumere la superficie (M7). Si M1 existe, el re-ataque puede además re-ejecutar el runbook.

---

## 4 · Coste de cada medida

Datos de partida [I]: suite de unos 90 s en sqlite y unos 130 s en pg/mysql, con la RAM justa. Un caso por el kernel en
proceso cuesta milisegundos: 9 casos en menos de 400 ms (`panel-alpha4-tester.md:531`); `provision` contra un puerto
muerto, 1,95 s por timeout. `--prune` sobre ~500 tuplas en el `:8101` tarda 27–43 ms (decisiones 09-11 (2)), y un barrido de
5 000 tuplas de relaciones, ~190 ms (alpha.6). El lote A de alpha.9 (18 banderas, 13 casos y la guardia) se hizo en
~1,5 h de implementador (informe de COGNITIV a las 21:10, `alpha9-informe-A` a las 21:37 y commit a las 22:30).

| Medida | Construcción | Segundos por corrida | Mantenimiento | Riesgo de ceremonia | Nota |
|---|---|---|---|---|---|
| **M1** runbook ejecutable | **4–8 h [A]**: el harness existe (`tests/helpers/ace.ts`, `factsDeployment` en `reconcile.spec`, red de stores del `:8101`); falta el guion ida → servir → mantenimiento → repetir → ventana caducada → vuelta, con relaciones en el store | **+3–6 s por modo con `OPENFGA_TEST_URL` [A]** (~40 invocaciones de kernel más dos reconciles reales); +12–24 s entre los 4 modos, **menos del 5 %** de la suite | medio: se toca cuando cambia un comando o el README del cutover | **bajo**: es un test y corre solo | Es la única que cubre la clase de los nº 31–34. Riesgo: que se escriba con dobles en vez del `:8101` (A-5 de alpha.9 ya lo hizo así, `alpha9-informe-A.md` §6) |
| **M2** invocación + guardia | **ya hecha en un ~80 %** (`tests/command_flags.spec.ts`, 13 casos más A-G-1..3). Resto, **1–2 h**: una guardia estática «cada bandera booteada aparece en al menos un `exec([...])`»; hoy `--prune`, `--to`, `--from`, `--only`, `--id`, `--force`, `--apply` y `--keep-links` no tienen caso de efecto por el kernel [V: grep de los grupos A-1..A-10] | < 1 s | bajo | bajo | Valor futuro: cada bandera nueva (2.5 trae `--prune-undeclared` y el reconcile por tenant) |
| **M3** tabla de verdad en los cierres | 15–45 min por cierre [A] | casos con dobles, ms | bajo | **medio-alto**: los ejes se eligen por intuición (alpha.9 hizo 2 de 4) y una tabla con «N/A» pasa revisión | Útil solo con M8 (propiedad universal) y M7 (el eje de superficie lo da la reflexión, no la memoria) |
| **M4** auditoría sin diff | 3–6 h de agente por gate más la verificación del coordinador [A], recurrente | 0 (manual) | alto | **alto**: sin criterio de pasa/falla; historial de APTA seguido de un grave (5 de 5) | Lo automatizable de M4 ya lo dan M1 (recorrido de operador) y los tests de letra (`trx_docs.spec`, `relations_events_docs.spec`) |
| **M5** estados en el panel | 20–40 min por panel de operación larga [A] | 0 | bajo | **medio**: se rellena de forma mecánica | Aplica a lo que viene en 2.5 (reconcile por tenant, `--prune-undeclared`) |
| **M6** retirar el arreglo | 10–60 s por cierre (re-correr los ficheros de la zona) | 0 en la suite | bajo | medio | **Redundante** con los mutantes obligatorios que ya se hacen; 0 en el contrafactual |
| **M7** guardia de superficie (nueva) | **6–10 h [A]** para las 6–7 guardas (reflexión sobre prototipos más un registro de casos y exenciones) | < 2 s (reflexión y dobles) | medio: la lista de exenciones | **bajo-medio**: la exención con motivo puede acabar siendo un sello; mitigación: una exención nueva la firma el dueño | Mayor puntuación. El patrón está probado en el repo |
| **M8** regla de tres | ~0 (una tabla de linajes en `.claude/contexto/` y una línea en «Cómo se decide un cambio») | 0 | bajo | bajo (es un disparador, no una revisión) | Sin M7 se queda en intención |
| **Peor instancia de lo declarado** (§3.2) | 10–20 min por límite declarado más una pregunta a COGNITIV | 0 | bajo | medio | Contrafactual: nº 25 S, nº 27 S |

---

## 5 · Recomendación

### Adoptar, en este orden (defectos evitados / coste)

1. **Cerrar M2** (1–2 h): la guardia de cobertura «cada bandera booteada tiene un `exec` de efecto». Es barata, automática,
   y deja cerrado el linaje de entrada inerte para la CLI.
2. **M7 más M8 juntas** (6–10 h, un lote). Es la mayor puntuación (11,0) y la única que ataca los linajes, que es lo que el
   dueño llama «círculos». Primero, las guardas de los dos linajes que siguen vivos: el **origen del reconcile** (con el hueco
   `--to=database` sin `--from` como primera fila roja) y la **entrada inerte** (opciones de API y combinaciones de banderas).
   Después F-05, freeze, `transaction` y actor sobre los dos managers.
3. **M1 runbook ejecutable** (4–8 h), contra el `:8101` y **con relaciones en el store**. Es la única que cubre la clase
   composición/después (nº 31–34) y la que convierte «el cutover funciona» en un test en vez de en un ensayo de COGNITIV.
4. **M3 solo dentro de M8**: la tabla de verdad se exige al cerrar, con la propiedad enunciada en forma universal y el eje
   de superficie sacado de M7. Suelta, es ceremonia.
5. **Peor instancia de lo declarado** (§3.2) y **M5**, como dos preguntas fijas en la plantilla de los paneles de operación
   larga, no como secciones nuevas.

### Descartar

- **M6** como medida propia: ya existe (mutantes obligatorios) y en este historial no habría detectado nada.
- **M4 como gate**: por el historial de APTA y por coste. Lo que aporta de verdad (letra ↔ comportamiento) se consigue
  automatizado con los tests de letra que el repo ya usa, ampliados a las frases operativas del README del cutover (la del nº 34
  se habría fijado así).

### El criterio de salida a `2.4.0` estable

«M1 pasa + M4 da APTA» es **medio bueno**. M1 es objetivo y cubre la clase que hoy encuentra COGNITIV. M4 es un juicio con
un historial de falsos negativos de 5 de 5. Propongo un criterio en el que cada condición sea verificable sin opinión:

1. **M1 verde en los 4 modos contra el `:8101`**: ida, servir con escrituras, mantenimiento con y sin `--prune`, repetir la
   migración (debe negarse), ventana caducada (debe delatarse) y vuelta.
2. **M7 verde con cero entradas sin caso** y la lista de exenciones firmada por el dueño.
3. **Linajes quietos:** ningún defecto grave nuevo de un linaje ya registrado en el ciclo de la RC (esto convierte en
   número la «señal de convergencia» de la propia metodología).
4. **Un ensayo de cutover de COGNITIV sobre el tarball exacto de la RC**, sin defectos graves y con plazo cerrado. Es la
   señal externa que ha encontrado 12 de los 34 (35 %; 13 si se cuentan a medias los nº 9 y 29, compartidos): quitarla del criterio sería quitar al detector que
   más acierta en la capa donde están ahora.

### Lo que el dueño tiene que decidir antes (preguntas que cambian el plan)

- ¿**`npm deprecate`** de `1.1.0` (`latest`), además de las alphas 4–8? Lleva los nº 19 y 20 desde el 07-29 [V].
- ¿El hueco abierto de alpha.10 (`--to=database` sin `--from`) entra en alpha.10 o sirve como primera fila roja de M7?
- ¿El ensayo de COGNITIV sobre la RC es condición de la estable, o solo informativo?

---

**Recomendación en una frase:** el hueco no es de perímetro sino de forma. Los defectos vuelven porque cada cierre tapa
un punto de llamada y no la superficie. Hay que adoptar M7 + M8 (guardia estructural por guarda y regla de tres en los
linajes) y M1 (runbook ejecutable con relaciones contra el `:8101`), cerrar el resto de M2 y descartar M6 y M4 como gate.

**Siguiente paso concreto:** el juez decide sobre esta tabla. Si M7 gana, el primer caso rojo es el hueco `--to=database`
sin `--from` de `alpha10-informe.md:53-56`, que es la cuarta iteración del linaje del origen rancio.
