# Fase 2.5 · Verificación del `tester-contrato`

> Worktree aislado. Nació en `main` (`252ea8c`) ⇒ `git checkout e2cf8cd` hecho antes de nada.
> Node 22.23.2 (`~/.config/nvm`), `npm ci` limpio (280 paquetes, 0 vulnerabilidades).
> Motores: OpenFGA `:8101` (compartido), `postgres18` (127.0.0.1:5432), `mysql84` (127.0.0.1:3306),
> tope 3 en `openfga-tiny-tester` `:8113` (puerto libre para no chocar con el auditor; **borrado al terminar**).
> Todo lo que sigue está **ejecutado**, no leído. Los errores son literales del runner.

**Veredicto: APTA CON CORRECCIONES.** El lote hace lo que dice y los mutantes lo confirman
en los cuatro modos. Hay un hueco de ruta principal que **cerré con parche** (nada vigilaba las
bases huérfanas: la suite daba 335/335 en verde dejando bases en el servidor de otro) y cuatro
huecos menores que dejo documentados, no bloqueantes.

---

## 1. Suites en los cuatro modos × tres configuraciones de FGA

Árbol tal y como está en `e2cf8cd` (sin mi parche). **12/12 verdes**, conteos exactamente los
esperados (335 / 425). Tiempo = el que reporta Japa (`real` de `time` entre paréntesis).

| Modo | sin OpenFGA | con `:8101` | tope 3 (`:8113`) |
|---|---|---|---|
| `npm test` (SQLite `:memory:`, pool 1/1) | **335** · 5 s (6,6 s) | **425** · 14 s (15,2 s) | **425** · 12 s (12,5 s) |
| `npm run test:sqlite-file` (fichero, pool 2..5, WAL) | **335** · 5 s (5,9 s) | **425** · 15 s (16,1 s) | **425** · 12 s (12,9 s) |
| `npm run test:pg` (PostgreSQL 18) | **335** · 11 s (11,6 s) | **425** · 23 s (24,2 s) | **425** · 20 s (20,9 s) |
| `npm run test:mysql` (MySQL 8.4) | **335** · 13 s (13,8 s) | **425** · 25 s (25,9 s) | **425** · 23 s (23,6 s) |

Sin `skip`, sin `only`, sin tests pendientes. `npm run build` (purity + typecheck + tsc + stubs) verde.

**¿Cabe la matriz de CI en < 3 min por motor?** Sí, con mucho margen: el peor motor (MySQL) suma
**≈ 40 s** de tests entre las dos entradas del job (`test:mysql` sin FGA + con FGA). A eso el job
`engines` añade `npm ci` (con caché), el healthcheck de los servicios y el `docker run` de OpenFGA:
del orden de 60–90 s más. Presupuesto total estimado **≈ 2 min**. No es un riesgo.

### Bases residuales (antes / después)

Medición controlada por modo (snapshot inmediatamente antes y después de una ejecución limpia):

| Motor | Antes de empezar | Nuevas tras una ejecución limpia | Al cerrar la sesión |
|---|---|---|---|
| PostgreSQL 18 | 0 `authz_test_*` (23 bases ajenas) | **0** (`diff` vacío) | **0** · total 23 bases, las ajenas intactas |
| MySQL 8.4 | 0 `authz_test_*` (8 bases ajenas) | **0** (`diff` vacío) | **0** · las ajenas intactas |
| `/tmp/authz-sqlite-*` | 0 | **0** | **0** |

Dos notas de honestidad, porque el auditor trabaja en paralelo sobre los mismos motores:

1. Durante la ventana de mis primeras 12 ejecuciones aparecieron 1 base en PG, 1 en MySQL y 1
   directorio en `/tmp` que **no eran míos** — desaparecieron solos (eran ejecuciones vivas del
   auditor). Por eso la cifra que vale es la del `diff` controlado antes/después, no el recuento bruto.
2. Al cerrar queda en MySQL un esquema `zz_probe` que **no he creado yo** (no lo toco).
   Mis propios residuos (6 bases PG generadas *a propósito* por el mutante J2) los borré uno a uno
   con `dropdb --force`; PG ha vuelto exactamente a sus 23 bases de partida.

---

## 2. Mutantes — pieza × mutante × motor × resultado

Los mutantes van en `src/` o en el espejo del esquema (`tests/helpers/schema.ts`), nunca en las
aserciones. Todos restaurados con `git checkout --` (árbol limpio verificado).

### J1 · reloj inyectable

| # | Mutante | Dónde | sqlite | sqlite-file | pg | mysql | openfga (`:8101`) | Error literal |
|---|---|---|---|---|---|---|---|---|
| J1a | `whereActive` vuelve al reloj de pared (`systemClock()`, para **no** disparar el grep y aislar el contrato) | `database_driver.ts:236` | **8 ✖** | — | — | — | — | `T: el que expira ahora ya no cuenta: expected {…} to deeply equal { authorize: false, …(5) }` · `vence a los 600 ms, no al segundo: expected true to be false` · `expected true to be false` ×2 |
| J1a' | Lo mismo con `new Date()` literal | ídem | **9 ✖** | — | — | — | — | Los 8 anteriores **+** `lecturas del reloj fuera de src/clock.ts` (grep de `tests/clock.spec.ts`) |
| J1b | `checkContext` vuelve al reloj de pared | `openfga_driver.ts:819` | — | — | — | — | **4 ✖** | Los mismos 4 casos, sobre el harness `openfga` |
| J1c | Quito `withClock` del driver `database` (renombrado) | `database_driver.ts:200` | **10 ✖** | — | — | — | — | `AuthorizationConfigError: config.clock está declarado pero el driver 'database' no implementa withClock(now): el reloj no llegaría a ninguna decisión` (= el 500 esperado) · `injectableClock: true exige withClock en el puerto: expected undefined to be a function` · `TypeError: driver.withClock is not a function` ×4 |

**Lectura.** J1 está bien observado y con doble red: el **contrato** (los 4 casos del juez, ×2
harnesses `database`) y el **grep** (`tests/clock.spec.ts`), que son detectores independientes. Los
4 casos que mueren son distintos entre sí y cubren las tres caras que pedía el plan: los tres
estados con reloj (core), la caducidad exacta T−1/T/T+1 (2.1), los milisegundos, y `config.clock`
del manager. J1c da exactamente el 500 `E_AUTHZ_CONFIG` prometido, **y además** el juez tiene un
guardián propio (`injectableClock: true` exige `withClock`): declarar la capacidad sin traerla no
cuela. ✅

### J3 · defectos por motor

Mutantes sobre el **espejo** (`tests/helpers/schema.ts`) para aislar el comportamiento del motor
de las aserciones de texto sobre el stub.

| # | Mutante | sqlite | sqlite-file | pg | mysql | Error literal (motor que lo mata) |
|---|---|---|---|---|---|---|
| J3a | `datetime('expires_at', {precision:3})` → `timestamp` | ✔ 335 | — | ✔ 335 | **10 ✖** | `expected 1893456002000 to equal 1893456001500` · `lo que se lee es lo que se escribió, al milisegundo: expected 1893456001000 to equal 1893456000600` · `T: el que expira ahora ya no cuenta` · `expected false to be true` (config.clock) · **`ronda 0: caducidad final: expected 1787983552000 to be one of [1787979952470, 1787983552470]`** (¡el caso de concurrencia J4 también lo caza!) |
| J3b | Quito `collate('utf8mb4_bin')` (todas las columnas) | ✔ 335 | — | ✔ 335 | **2 ✖** | `el de mayúsculas no está denegado: expected false to be true` |
| J3c | `string(…,64)` → `uuid` en `holder_uuid`/`scope_uuid` | ✔ 335 | — | **2 ✖** | **2 ✖** | PG: `AuthorizationBackendError: … 'database' no respondió (grant.find)` · MySQL: `el de mayúsculas no está denegado` (`uuid()` es `char(36)` sin `_bin`) |
| J3d | Quito el hint `SET_VAR(cte_max_recursion_depth)` | ✔ 335 | — | ✔ 335 | **1 ✖** | `…'sqlDescendantsOf' no respondió (descendantsOf) · causa: … Recursive query aborted after 1001 iterations…: **expected 503 to equal 422**` |
| J3e | MySQL sin quoting por dialecto (backtick → `"`) | ✔ 335 | — | ✔ 335 | **7 ✖** | `SELECT 1 AS "ok" FROM "demo_scopes" … You have an error in your SQL syntax …: expected 503 to equal 422` |

**Lectura.** Los cinco mutantes mueren **exactamente en el motor que se predijo** y en ninguno más
(salvo J3c, que además mata MySQL por un efecto secundario legítimo del tipo). La discriminación
por motor es real: sin PG y sin MySQL, cinco defectos de esta fase serían invisibles. ✅

Dos matices menores (no bloqueantes, §4 G7):
- El caso "milisegundos **y** 2040" es **un solo test con dos afirmaciones**. Con J3a la aserción de
  ms falla primero y la de 2040 nunca se evalúa: detecta bien, diagnostica peor. Un test, una
  afirmación.
- J3b/J3c matan **el mismo** caso (`el de mayúsculas no está denegado`) por causas distintas
  (collation vs. tipo). Si mañana se cambia el tipo, el mensaje seguirá hablando de mayúsculas.

### J4 · concurrencia

| # | Mutante | sqlite | sqlite-file | pg | mysql | Error literal |
|---|---|---|---|---|---|---|
| J4 | Quito la rama de carrera de `grant` (`const raced = null`) | **2 ✖** | **2 ✖** | **2 ✖** | **2 ✖** | `ronda 0: El backend de autorización 'database' no respondió (grant.insert): **expected 503 to equal 409**` |

**Lectura.** El caso discrimina y el error es literalmente el predicho. **Pero** —y esto matiza el
informe del implementador, que lo atribuía a `sqlite-file` con pool ≥ 2— el mutante muere **igual
en `:memory:` con pool 1/1**: la carrera que observa J4(a) es de *check-then-insert* a nivel de
JavaScript (`Promise.allSettled`), no de conexión. Ver hueco G4. ✅ con reserva.

### J2 · el hijo de `purity.spec` hereda `TEST_DB`

| # | Mutante | Motor | Resultado de la suite | Residuo real |
|---|---|---|---|---|
| J2 | El hijo cierra el pool (`db.manager.closeAll()`) en vez de `app.teardown()` | pg | **335/335 EN VERDE** | **2 bases `authz_test_*` huérfanas** en el servidor |

**Este es el hallazgo.** La corrección de J2 existe y funciona, pero **ningún test la vigilaba**:
con el mutante puesto, `npm run test:pg` daba un verde impecable mientras escribía —y dejaba—
bases en el servidor de PostgreSQL de otra persona. El propio informe de fase lo reconoce como
un hallazgo encontrado *a mano* (16 bases huérfanas), y a mano se quedó. Es exactamente el tipo de
promesa que CLAUDE.md hace por escrito ("cada ejecución crea `authz_test_<8 hex>` y la borra al
terminar; nunca se toca una base existente") sin un test detrás. **Cerrado con parche** (§5). ❌ → ✅

---

## 3. El juez

| Comprobación | Resultado |
|---|---|
| `contract_harness`: 36 core / 49 en 2.0 / 65 en 2.1 | ✅ fijado y verde (`assert.lengthOf(core, 36)`, `(full, 49)`, `(primitives, 65)`) |
| 68 con `injectableClock: true` | ✅ `assert.lengthOf(fullWith, 68)` y `fullWith.length === fullWithout.length + 3` |
| 59 sin `listDenies` | ✅ `assert.lengthOf(without, withIt.length - needIt.length + 1)` con `needIt` = 7 |
| Niveles **anidados y ejecutando** | ✅ `for (const t of core) assert.include(full, t)` y `full ⊂ primitives`; y `contract.spec.ts` corre los tres harnesses a `level: '2.1'` de verdad (no con la API falsa) |
| Pares de capacidad no son un `skip` | ✅ declarar `truncationSignal: true` o `listDenies: true` fuera de 2.1 **lanza al registrar** (probado) |
| `grep setTimeout/sleep` en el juez | ⚠️ **el caso de 1,5 s SIGUE EXISTIENDO** — ver abajo |

### El caso de 1,5 s: lo que realmente pasó

`grep -n "setTimeout\|1_500" src/testing/contract.ts` da tres aciertos:

```
501:  const soon = new Date(clock.now().getTime() + 1_500)          ← cara true, reloj inyectado, NO duerme
673:  const soon = new Date(Date.now() + 1_500)                     ← cara false
699:  await new Promise((r) => setTimeout(r, Math.max(0, soon.getTime() - Date.now()) + 300))   ← cara false
```

La afirmación correcta no es "ya no existe" sino: **el paquete ya no lo ejecuta**. El caso vive en
la cara `whenFalse` del par `injectableClock`, y los tres harnesses de `contract.spec.ts` declaran
`injectableClock: true`. Comprobado poniendo `injectableClock: false` a mano:

```
AssertionError: el harness declara injectableClock: false y el driver trae withClock:
  declara lo observable: expected [Function withClock] not to be a function
Tests  327 passed, 2 failed (329)
```

Es decir: como ambos drivers del paquete **sí** traen `withClock`, la cara `false` es
**estructuralmente inalcanzable aquí** — solo corre su primera línea (el guardián), nunca el
cuerpo con la espera. Eso está bien diseñado (el guardián impide declarar `false` mintiendo) y
cumple el objetivo del plan para *este* repo, pero deja el cuerpo del caso como **código publicado
y nunca ejecutado** para el driver de terceros que lo herede. Ver hueco G2.

---

## 4. Huecos

### Aserciones relajadas respecto a `4d1d3b6`

**Ninguna.** Revisé todas las líneas `-` con `assert.` del diff completo: las 15 que desaparecen son
las del caso de tres estados, **reindentadas** dentro de `whenFalse` (mismas aserciones, mismos
`closeTo(…, 1_000)`). La única otra baja es `assert.lengthOf(primitives, 61)` → `65`, que es una
actualización de conteo. Y la cara nueva (`whenTrue`) es **estrictamente más fuerte**: cambia
`closeTo(…, 1_000)` por `assert.equal(...getTime(), soon.getTime())` (igualdad exacta) y añade la
frontera T−1 ms / T. Aserciones nuevas laxas: solo `assert.oneOf(state.previousExpiresAt…, [e1, e2])`
en J4(a), que es inherente a una carrera (cualquiera de los dos puede ganar) y aun así el mutante
J4 la mata. ✅

### Promesas nuevas del README sin test

| # | Promesa | Estado | Qué haría falta |
|---|---|---|---|
| **G1** | CLAUDE.md §Comandos: "cada ejecución crea `authz_test_<8 hex>` y la borra al terminar; nunca se toca una base existente" | ❌ → **✅ con mi parche** | Hecho: `tests/harness_cleanup.spec.ts` |
| **G2** | §Compatibility: "`injectableClock` … `false` ⇒ it can only observe the three states in real time, with a 1.5 s wait" | ❌ **no observable**: la cara `false` no corre en este repo (guardián `notTypeOf withClock`) | Un harness de prueba con un driver *envoltorio* al que se le quite `withClock` (como ya se hace con `listDenies` en «database (sin listDenies)»). Es la simetría que falta: `listDenies:false` sí tiene su harness real; `injectableClock:false` no |
| **G3** | §Compatibility: "CI runs all of it: SQLite, PostgreSQL and MySQL" y "`npm run test:sqlite-file` … real connection-level concurrency" | 🟡 **`sqlite-file` no está en ningún job de CI** (`test` = memoria, `openfga` = memoria, `engines` = `[pg, mysql]`) | Añadir `sqlite-file` a la matriz de `engines` (coste ≈ 18 s, sin servicios) o al job `test` |
| **G4** | El valor añadido de `sqlite-file` (pool 2..5 = "concurrencia real de conexión") | 🟡 **no observable**: ningún test fija que el pool sea > 1, y el mutante J4 muere igual en `:memory:` con pool 1/1 | Un caso que solo pueda pasar con dos conexiones (p. ej. un `SELECT` mientras otra conexión mantiene una escritura abierta), o al menos `assert.isAtLeast(db.connection().pool.max, 2)` en el modo `sqlite-file` |
| **G5** | §Operational notes: la receta de subida desde 1.x (`ALTER COLUMN holder_uuid TYPE varchar(64)` / `MODIFY expires_at datetime(3)`) | ❌ **sin test**: nadie ejecuta ese SQL. Es la única promesa del README que un consumidor copiará y pegará en producción | Un caso que cree el esquema *viejo* (uuid + timestamp), aplique el SQL documentado y corra un puñado de aserciones de identidad y caducidad encima. Coste medio; alto valor |
| **G6** | §Operational notes: "the server's time zone setting only matters in that the same process writes and reads them" | ❌ **sin test** (lo verifiqué a mano: `TZ=America/Caracas` con motores en UTC ⇒ **335/335 en pg y en mysql**). La promesa es cierta hoy, pero nada la fija | Un caso de motor que fije el instante con el reloj inyectado y compruebe el ida-y-vuelta con el proceso en TZ ≠ UTC. Barato: es una variable de entorno |
| **G7** | "la caducidad guarda milisegundos **y** fechas más allá de 2038" | 🟡 dos afirmaciones en un test; la de ms enmascara la de 2040 | Partirlo en dos casos |
| — | `E_AUTHZ_UNSUPPORTED_DIALECT` fuera de PG/MySQL/SQLite | ✅ `tests/sql_descendants.spec.ts` (`mssql`/`oracledb`/desconocido, con espía de 0 consultas) | — |
| — | `now` / `withClock` / `clock` en §Driver options | ✅ `manager.spec` («config.clock», 4 casos) + los 4 del juez + `clock.spec` | — |
| — | "Nothing else in `src/` reads the wall clock (a grep test pins it)" | ✅ `tests/clock.spec.ts`, probado con J1a' | — |

### Inversos, bordes y orden que no aparecen

- **Inverso de J3c**: se fija que un id **no**-UUID funciona; no se fija que un id que **excede** la
  gramática (37 chars, o `varchar(64)` desbordado) siga siendo 422 y no un truncado silencioso de
  MySQL. En MySQL no estricto un `varchar(64)` con 65 chars trunca — la gramática lo corta antes
  (≤ 36), así que hoy no es alcanzable, pero nada lo fija por el lado del esquema.
- **Borde de J3a**: hay caso en `T` exacto y `T ± 1 ms`; no hay caso en el **borde de 2038**
  (`2038-01-19T03:14:07Z`), que es el instante que rompía `TIMESTAMP`. El caso salta a 2040.
- **Orden en J4(b)** (`purgeScope` vs `grant`): se acepta cualquiera de los dos órdenes con
  `assert.include([0,1], roles.length)`. Es correcto, pero significa que un driver que *siempre*
  pierda el grant pasaría. No hay mutante determinista para (b) ni para (c) — el propio informe lo
  admite (§4.4) y lo comparto: es honesto, no un defecto.

---

## 5. Parche (`tests-tester-fase-2.5.patch`)

Cierra **G1**, que es ruta principal: la suite escribiendo fuera de su caja sin que nada lo note.

**Caso de contrato.** *Dado* el harness en cualquier motor; *cuando* se lanza el proceso hijo de la
prueba de carga (el de `purity.spec`, que hereda `TEST_DB` y provisiona su propia base) — tanto en
el camino feliz (`index.ts` carga) como en el de control (`src/openfga.ts` revienta con el SDK
bloqueado); *entonces* lo que ese hijo provisionó **ya no existe** cuando termina.

Dos archivos:

- `tests/helpers/load_without_sdk.ts` (+6): el hijo imprime `db:<lo que provisionó>` nada más
  bootear. **Por qué así y no contando bases**: el auditor corre en paralelo sobre los mismos
  motores creando y borrando las suyas; un recuento antes/después sería *flaky*. Comprobar un
  nombre concreto es determinista y no le pisa nada a nadie.
- `tests/harness_cleanup.spec.ts` (nuevo, 127 líneas): dos casos (camino feliz y camino que falla).
  Consulta `pg_database` / `information_schema.schemata` **desde la conexión de la suite** (son
  catálogos compartidos: no hace falta abrir una conexión administrativa) y maneja el
  `[rows, fields]` de mysql2 que se descubrió en J3. En `sqlite-file` comprueba que el directorio
  de `mkdtemp` desapareció; en `sqlite` (`:memory:`) no hay nada que fugar y el caso lo dice en vez
  de fingir.

**Prueba de que el test prueba algo** (con el mutante J2 puesto):

```
pg          → AssertionError: el hijo dejó la base 'authz_test_27eea3e1' en el servidor pg:
                la suite escribe fuera de su caja: expected true to be false
              AssertionError: el hijo que falla dejó la base 'authz_test_bc4a218d' …
              Tests  335 passed, 2 failed (337)

sqlite-file → AssertionError: el hijo dejó el directorio temporal /tmp/authz-sqlite-IDXMKt
              AssertionError: quedó /tmp/authz-sqlite-ShiGYE
              Tests  335 passed, 2 failed (337)
```

Sin el mutante, verde en todo: **337** (sqlite, sqlite-file, pg, mysql) y **427** con `:8101` y con
el tope 3. `npm run typecheck` y `npm run build` verdes. No toca `src/`, no toca el juez, no cambia
los conteos de `contract_harness`.

Limitación declarada: en `TEST_DB=sqlite` el caso no puede fallar (no hay nada que fugar); el test
lo afirma explícitamente (`assert.equal(provisioned, ':memory:')`) en vez de pasar por casualidad.
La discriminación real está en `sqlite-file`, `pg` y `mysql`.

Nota de la sesión: los `dropdb --force` de mis 6 bases-mutante se me bloquearon primero en su forma
compuesta (clasificador de permisos) y salieron una a una. PG está de vuelta en sus 23 bases.

---

## 6. Veredicto

**APTA CON CORRECCIONES.**

Lo que la fase 2.5 dice que hace, lo hace, y ahora está demostrado con mutantes en los cuatro
modos y los cinco defectos de motor:

- **J1** ✅ doble detector (contrato + grep), 500 correcto cuando falta `withClock`.
- **J2** ✅ el harness funciona y no fuga — pero **no estaba vigilado**; cerrado con parche.
- **J3** ✅ los cinco mutantes mueren en el motor predicho y en ninguno más. Es la pieza mejor hecha.
- **J4** ✅ discrimina en los cuatro modos; la atribución a `sqlite-file` del informe es optimista (G4).
- **J5** 🟡 YAML correcto y dentro del presupuesto de tiempo; falta `sqlite-file` en la matriz (G3).
- **J6** 🟡 tres promesas nuevas del README sin test (G2, G5, G6).

Nada de esto rompe un invariante de CLAUDE.md ni cambia semántica. Las correcciones que pido antes
de dar la fase por cerrada, por orden:

1. **Aplicar el parche** (o equivalente): G1 es el único hueco que deja a la suite escribiendo en
   el servidor de otro sin que nadie se entere.
2. **G5** — la receta de subida desde 1.x del README es SQL que un consumidor va a copiar en
   producción y que nadie ha ejecutado nunca. O se prueba, o se marca como no verificada.
3. **G3** — meter `sqlite-file` en CI: hoy el modo existe, se documenta y no se ejecuta en ninguna
   parte automáticamente.

Y dos que dejaría para 2.6 sin bloquear: **G2** (harness real para la cara `injectableClock: false`,
por simetría con «database (sin listDenies)») y **G4/G6** (fijar el pool ≥ 2 y el ida-y-vuelta con
TZ ≠ UTC).

Fuera de mi competencia y los dejo apuntados para quien toque: el `collate('utf8mb4_bin')` y el
`varchar(64)` son decisiones de esquema con consecuencias de seguridad (colisión de identidades)
que corresponden al **auditor**; el hint `SET_VAR` construido desde una cota entera lo miré solo
por el lado de la observabilidad (el 422 vuelve), no por el de la inyección.
