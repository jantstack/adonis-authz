# Lote B (plan 2.5) — cierre 2: informe del implementador (2026-10-15) ⇒ `2.5.0-alpha.2`

**Árbol `main` sobre `beb1d0a` + lote B + cierre 1 + cierre 2 (working tree, sin commit).** Único agente que muta el árbol;
**sin commit, sin tocar `version`, sin `git push`**. Entorno medido: Node 22 (`nvm use 22`), `postgres18`, `mysql84`, OpenFGA
**`:8090`** (v1.19.0; `docker restart openfga-dev && sleep 8` antes de CADA suite). Brief: `loteB-cierre2-coordinador.md`
(1 🟠, 3 🟡, 4 ⚪, decisión 4 para CLAUDE.md punto 7). Re-ataque: `loteB-auditor-cierre.md` (repros `audb2_*.spec.ts` como
punto de partida). Método por hallazgo: **rojo observado** (los casos nuevos corridos sobre el árbol del cierre 1 ANTES de
tocar `src/`: 15 rojos, §0) → verde → **mutante** (aplicado y revertido sobre una copia aparte, `scratchpad/cierre2/repo`,
script `mutants.py`; 13 mutantes, todos muertos, §4). Sin contenedores nuevos: la medición de N1 es la del auditor
(v1.19.0, 40 000 tuplas, `--request-timeout=30ms` ⇒ `200 objects 0 of 40000`), citada con su método en README/CHANGELOG/docblocks.

## 0 · Rojos observados ANTES (casos nuevos sobre el árbol del cierre 1; `scratchpad/cierre2/red.log`: 163 passed, 15 failed)

| Spec | Rojo observado |
|---|---|
| `relations_openfga` | **3**: N1 «Infinity entró — la receta que produce el 200 mudo sigue aceptada» (`expected null to not equal null`); N1 lista de inválidos «deadline Infinity: expected undefined to equal 'E_AUTHZ_CONFIG'»; N5 «relate: el 200 sin tuples se tomó por «no existe»». |
| `scope_depth` | **1**: N1 «la receta que produce la lista parcial muda ya no se publica: expected README not to include 'listObjectsDeadlineMs: Infinity'». |
| `relations_reconcile` | **4**: N2 «la forma del userset domina sobre F-05 del par: `{"undeclared":2,"usersetUnsupported":0}` expected 0 to equal 2»; N8 «el residuo no se nombra» (la letra decía «todas de tipos que el destino no declara»); N3 fake «el reporte lleva prune: expected undefined to equal true» (y `deleted 1`, `unrelated ['ABC']`); N3 `database` dry-run «pruned of false, but got true». |
| `relations_reconcile_cli` | **3**: N3 «con --prune pasado el consejo contradice: expected [warning] to have length 0»; N3 «destino sin prune, real: un residuo que nadie borra es deriva: expected true to be false» (era `clean`); N3 fila userset «el consejo contradice la línea del residuo» («no pasaste --prune» junto a «--prune NO lo borra»). |
| `openfga_driver` | **2**: N5 grep «un default sobre `tuples` vende un 200 sin cuerpo como ausencia» (`tuples?.[0]` en `readAssignment`, `tuples ?? []` en `#readTuple`); N5 «el 200 sin tuples se tomó por «no existe» y grant escribió». |
| `relations_persisted_config` | **1**: N6 «readRelationsConfigSpec con null: se leyó como null («ninguna persistida», la vigilancia se apaga)». |
| `relations` | **1**: N7 «holderTypes "user" entró: expected undefined to equal 422». |
| `relations_contract` (N4) | El árbol del cierre 1 es verde por construcción (el doble valida antes de `push`); el rojo de N4 es el del MUTANTE del auditor «guarda la fila y después lanza» sobre el doble: **58/58 verdes** con el runner del cierre 1 (medido por el auditor) → **1 rojo / 58** con el runner del cierre 2 (§4). |

## 1 · Qué se hizo, por hallazgo (fichero:línea, caso, mutante, rojo)

### 🟠 N1 · `Infinity` RETIRADO; `listObjectsDeadlineMs` = el corte EFECTIVO del servidor
- **Código**: `src/drivers/openfga_relations_driver.ts:285-297` — guarda `Number.isInteger(deadline) && deadline > 0`
  (`Infinity`/`NaN`/≤ 0/no entero ⇒ 500 `E_AUTHZ_CONFIG`) con la letra «el corte EFECTIVO de ListObjects de tu servidor, que es
  --listObjects-deadline si no es 0 y, si es 0, --request-timeout (3 s por defecto; medido en OpenFGA v1.19.0 …). El servidor
  siempre corta en alguno de los dos; declara el menor. No hay «sin deadline» (Infinity ya no se admite)». Docblocks de
  `DEFAULT_LIST_OBJECTS_DEADLINE_MS` (`:106-121`) y de la opción (`:170-188`) reescritos con la medición, la fuente
  (`list_objects.go` solo pone su `WithTimeout` con deadline ≠ 0; si no hereda el ctx del interceptor de `--request-timeout`) y el
  límite declarado (los dos a 0 no se soportan: gateway HTTP `--http-upstream-timeout` 5 s sin medir, el paquete no promete «sin
  deadline» sobre lo no medido).
- **Letra**: README párrafo de relaciones (`:687-695`: «whichever is lower … both at 0 is not supported … measured on OpenFGA
  v1.19.0»), fila Limits (`:1293`, «effective cut … the lower of …»), §Upgrading 7 (`:1543-1560`, la medición del auditor con
  números, por qué la del cierre 1 no distinguía «sin deadline» de «deadline = request timeout», y «withdrawn»); CHANGELOG: el
  párrafo 🟡 8 del cierre 1 corregido («that reading was wrong and the advice is withdrawn in closure 2») + entrada N1 en
  «Closure 2 of lot B»; CLAUDE.md fila de `src/relations/`.
- **Caso**: `tests/relations_openfga.spec.ts:1632` (🟠 N1: `Infinity` ⇒ 500 con la letra «siempre corta en alguno de los dos»,
  `--request-timeout`, `--listObjects-deadline`, «declara el menor», sin la receta retirada; el significado nuevo: servidor con
  deadline 0 y `--request-timeout=30ms` se declara con `30` y una llamada de 27 ms señala, 26 no, el tope sigue; y POR FUENTE: ni
  `deadline === Infinity` ni «Infinity si el servidor corre» en el driver) + `Infinity` y `1.5` en la lista de inválidos de
  `:1601`; `tests/scope_depth.spec.ts:103-112` (README: `listObjectsDeadlineMs: Infinity` AUSENTE, sin «has no deadline
  (measured» ni «(no deadline, measured)», con `--request-timeout`, «whichever is lower», «both at 0 is not supported», «measured
  on OpenFGA v1.19.0»). El caso `:1626` del cierre 1 («con Infinity una hora de llamada no es un corte») **reescrito**: era el
  supuesto falso.
- **Mutante** `N1.acepta-Infinity` (vuelve la rama `|| deadline === Infinity`) ⇒ **2 rojos / 9**. **Rojo observado**: §0 (3 + 1).

### 🟡 N2 · `classifySubject`: la FORMA del userset ANTES que F-05, con o sin `toConfig` (decisión 3 del cierre 1 rechazada)
- **Código**: `src/relations/reconcile.ts:504-523` — `assertSupportedUserset(subject)` primero y, con `toConfig`,
  `assertRelationDeclared(toConfig, subject.object, subject.relation)` después (solo un `group#member` que F-05 rechace es
  `undeclared`). Docblock con el porqué y el mutante. `assertSupportedUserset` (`define_relations_config.ts:323`) documenta el
  orden en el plan y que en la API (`assertUsersetSubject`, la pregunta del llamante) el orden sigue F-05 → forma.
- **Caso**: `tests/relations_reconcile.spec.ts:373` (origen `database` real con `document#viewer@folder:F#viewer` y
  `document#viewer@document:E#reader` sembrados por SQL; tres `toConfig`: sin `folder` ni `reader`, con `folder`, ninguno ⇒
  `skipped.usersetUnsupported 2`, `undeclared 0`, `modelDrift []`, 2 `details` con receta, dry = real, dos líneas
  «(userset-unsupported) origen», sin «decláralos en el destino»; corre en los 4 modos).
- **Mutante** `N2.f05-primero` (invertir el orden) ⇒ **1 rojo / 31**. **Rojo**: §0.
- **Decisión nueva (para ratificar)**: solo cambia el PLAN. En la API un userset de tipo no declarado sigue siendo
  `E_AUTHZ_RELATION_TYPE_UNKNOWN` antes que `USERSET_UNSUPPORTED`: los dos son 422 con cero llamadas y nada se escribe; la
  guardia de superficie sondea esa cara y cambiarla ahí no cierra nada.

### 🟡 N3 · UNIFICACIÓN: `invalid-identity` del destino = `userset-unsupported`; «repite con --prune» solo por lo que `--prune` borra y solo si no se pasó
- **Código** (plan, `src/relations/reconcile.ts`): `:163-169` `RelationsReconcileReport.prune?: boolean` (opcional; `:348` lo
  pone la pasada); `:625-641` la tupla del destino fuera de la gramática va a `destInvalid` y **NUNCA a `toDelete`**
  (`:696-698`: `!destResidue.has && !destInvalid.has && !sourceByKey.has`); `:700` `destResidue = usersets + invalid` suma a
  `extra` con o sin `prune` (`:446`); `:423` `pruned: false` desde el plan para `invalid-identity` (también en `--dry-run`); el
  bucle de poda (`:436-442`) ya NO tiene el catch del 422 de una tupla inválida (todo lo que hay en `toDelete` pasó la gramática:
  un 422 ahí es el driver contradiciendo al plan y se propaga, R2-5); `refused` desaparece. Docblocks de `extra`, `details`,
  `pruned` y `PartitionPlan` reescritos.
- **Código** (letra, `commands/authz_relations_reconcile.ts:93-144`): UNA rama para los dos motivos del destino — `error` con el
  prefijo ESTABLE «`sobra (<motivo>) destino:`», «--prune NO lo/la borra» (`pruned: false`) o «tampoco lo/la borraría» (sin
  prune), receta (`DELETE … authz_relations …` para B3; «corrígela o bórrala a mano (SQL/SDK)» + «ningún driver del paquete la
  admite en unrelate, R-16» para `invalid-identity`), `destResidue` cuenta los dos y tumba `clean`; `:176-191` el consejo «no
  pasaste --prune: repite con --prune» solo si `prunable = extra − destResidue > 0 && !dryRun && report.prune !== true`, y cuenta
  SOLO lo podable. La rama `pruned === true` queda como «BORRADA por --prune» para un reporte de terceros (el paquete ya no lo
  emite); desaparecen «se pedirá … BORRE» y «NO se pudo borrar».
- **Casos**: `tests/relations_reconcile_cli.spec.ts:112` (tabla del consejo: {prune ausente/false/true} × {extra podable / solo
  residuo de cada motivo / 2 extra + 1 residuo ⇒ «1 tupla(s)»} / residuo del origen no descuenta), `:146` (tabla
  `invalid-identity` destino × prune × dry-run: SIEMPRE error con prefijo estable, no limpia, «NO la borra»/«tampoco la
  borraría», «R-16», «a mano (SQL/SDK)», jamás «repite con --prune», jamás «se pedirá/BORRADA/NO se pudo borrar»; origen sin
  cambios), fila userset `:198+` con `notMatch(/no pasaste --prune|repite con --prune/)`; `tests/relations_reconcile.spec.ts:668`
  (fake sin gramática como destino, 4 modos: `extra 1`, `deleted 0`, `unrelated = []`, `pruned: false` bajo prune, ausente sin
  prune, `report.prune`, línea `error` con prefijo, sin consejo) y `:704` (destino `database` real con `object_uuid` en
  mayúsculas: dry `pruned: false` + `extra 1`, real con Proxy espía ⇒ `unrelates = []`, la fila sigue, la buena intacta).
- **Mutantes**: `N3.invalid-en-toDelete` ⇒ 2/31; `N3.pruned-true` ⇒ 2/31; `N3.consejo-sin-mirar-prune` (`extra > 0` a secas) ⇒
  4/42; `N3.invalid-no-es-residuo` (solo cuenta B3) ⇒ 3/42; `N3.invalid-warning` (warning + limpia) ⇒ 2/11. **Rojo**: §0 (5).
- **Casos existentes cuyo exit o letra cambió por la unificación (línea (c))**: §2.

### 🟡 N4 · el runner B3 observa por `listSubjects` (y `enumerateRelations`) que NO quedó fila
- **Código**: `src/testing/relations_contract.ts:1179-1191` — tras los intentos por el manager y por el driver en directo,
  `listSubjects('viewer', doc, S)` no contiene `document:<other>#viewer` y, con la capacidad, `enumerateRelations(S)` tampoco. El
  comentario «por el driver directo el runner no ve su backend» (decisión 8 del cierre 1) **borrado**: lo ve por el puerto.
  Recuento de casos sin cambio (el caso se amplía). README §Upgrading 2 y CHANGELOG («A third-party driver that stored the inert
  row passed the whole contract until now») pasan a ser verdad.
- **Mutante** `N4.guarda-y-luego-lanza` (en el doble publicado `assertSubjectDeclared` detrás de `tuples.push`) ⇒ **1 rojo / 58**
  (el harness «doble en memoria (full)»). **Límite declarado**: el harness «doble (mínimo)» declara `usersetSubjects: false` y
  `enumerateRelations: false`, así que ahí la fila inerte no es observable por ningún camino del puerto (y por eso ese harness
  sigue verde con el mutante); un driver de terceros con esas dos capacidades a `false` queda fuera de esta observación.

### ⚪ N5 · `Array.isArray` en las dos lecturas PUNTUALES
- `src/drivers/openfga_driver.ts:1221-1224` `readAssignment` ⇒ `this.tuplesOrThrow(response, 'readAssignment')[0]` dentro del
  `try` (un `{}` es `unknown` con el 503 como causa: `grant` con `expiresAt` omitido lanza ese 503 y NO escribe; con objetivo
  explícito sigue la vía degradada documentada); `src/drivers/openfga_relations_driver.ts:535-548` `#readTuple` ⇒ 503
  `E_AUTHZ_BACKEND_UNAVAILABLE` sin `tuples`. **Casos**: `tests/openfga_driver.spec.ts:1458` (grep ampliado
  `tuples\s*(\?\?|\?\.\[)` sobre los DOS drivers + `tuplesOrThrow` × 4) y `:1474` (grant ⇒ 503, cero `write`);
  `tests/relations_openfga.spec.ts:1669` (relate ⇒ 503, cero `write`; control: `unrelate` no lee — delete ciego con
  `IGNORE_MISSING_DELETES`). **Mutantes**: `N5.readAssignment-absent` ⇒ 2/46; `N5.readTuple-default` ⇒ 2/55. **Rojo**: §0.

### ⚪ N6 · fila persistida que es JSON válido pero no objeto ⇒ 422 «NO valida»
- `src/relations_config_store.ts:78-103`: solo la fila AUSENTE es `null`; JSON corrupto ⇒ 422 (🟡 7); `null`/`0`/`false`/`""`/`[]`
  ⇒ 422 `RelationConfigError` «no es un objeto … Re-guárdala con saveRelationsConfig(<spec>)». El comando ya tiene la rama (🟡 7,
  `error instanceof RelationConfigError`). **Caso**: `tests/relations_persisted_config.spec.ts:116` (las cinco × las dos lecturas
  ⇒ 422, nunca `null`; fila ausente ⇒ `null`). **Mutante** `N6.no-objeto-es-null` ⇒ 1/9. **Rojo**: §0.

### ⚪ N7 · `Array.isArray(holderTypes)` ⇒ 422
- `src/relations/define_relations_config.ts:399-404`. **Caso**: `tests/relations.spec.ts:283` (cadena/objeto/número ⇒ 422
  «'holderTypes' tiene que ser un array»; la cadena + `objectType` homónimo ya no se cuela; control con array ⇒ el 422 de ⚪4).
  **Mutante** `N7.holderTypes-sin-array` ⇒ 1/63. **Rojo**: §0. **Límite declarado (roles)**: `holderTypes: 'users'` y
  `drivers: 1` en el config de roles entran en `assertAuthorizationConfigShape` (solo juzga claves y bloques) y fallan después, al
  resolver el driver o en el driver openfga; ninguno concede nada. No se amplía la guarda de roles en este cierre.

### ⚪ N8 · desglose de R-17 por su nombre
- `src/relations/reconcile.ts:457-470` `describeSkipped(plan.skipped)`: «N de tipo o relación que el destino no declara
  (skipped.undeclared)», «N con sujeto userset no admitido (B3, skipped.usersetUnsupported)», «N con identidad fuera de la
  gramática (skipped.invalid)», «N caducada(s)» — cada uno solo si > 0; «todas de tipos que el destino no declara» desaparece.
  **Caso**: `tests/relations_reconcile.spec.ts:423` (origen solo residuo B3 + caducada, con y sin `toConfig` ⇒ 500 nombrando
  «1 con sujeto userset no admitido (B3 …)» y «1 caducada(s)», nunca «todas de tipos…»; control: origen solo con tipo no declarado
  ⇒ «1 de tipo o relación que el destino no declara (skipped.undeclared)»). **Mutante** `N8.sin-desglose` ⇒ 1/31. **Rojo**: §0.
  La frase «no ha aportado NI UNA utilizable» (que `command_flags_r.spec:407` fija) no cambia.

### Decisión 4 · CLAUDE.md punto 7
- `CLAUDE.md:979-982`: «**Exit propio = ≠ 0 y distinto del de éxito; la RAMA se identifica por un prefijo ESTABLE de la línea,
  que el caso nombra** … no se inventan códigos de salida por rama». Los casos de N3 nombran el prefijo («`sobra (<motivo>)
  destino:`», «`sin migrar (<motivo>) origen:`»).

### Letra transversal
- `CHANGELOG.md:209-290` «### Closure 2 of lot B» (N1–N8 + decisión 4, estilo problema → decisión → qué NO se hace); el 🟡 8 del
  cierre 1 (`:184-190`) corregido en vez de dejar la frase falsa en el mismo `[Unreleased]`.
- README: párrafo de relaciones, Limits, §Upgrading 6 (N2 + unificación N3 + «the report carries `prune`») y 7 (N1), párrafo
  «Migrating tuples between drivers» (`:710-713`: lo que `--prune` no toca).
- `CLAUDE.md`: punto 7 y fila de `src/relations/` (N1, N2, N3).
- `tests/freeze.spec.ts`, `EXPECTED_FUSED`, `migration_stub.spec`: **sin tocar**.

## 2 · Cuatro líneas de cierre (punto 5)

**🟠 N1**
- (a) *Gemelos*: `listObjects` de relaciones ↔ roles: el driver de roles NO usa `ListObjects` (sus enumeraciones son `Read`,
  exhaustivo-o-503 por `tuplesOrThrow`, cierre 1): **no aplica**. Driver ↔ vista `withClock`: hereda la guarda del constructor
  (misma instancia de opciones; el caso de B4 ya juzga la vista). Driver ↔ README ↔ CHANGELOG ↔ CLAUDE.md: las cuatro letras
  dicen lo mismo y `scope_depth.spec` fija la del README. Timeout del CLIENTE (`timeoutMs`, 5 s) ↔ corte del servidor: el 200
  mudo llega porque el cliente espera más que el servidor; no se toca (sería una tercera cota que tampoco señala).
- (b) *Tabla de verdad* (dominios: `--listObjects-deadline` ∈ {≠ 0, 0} × `--request-timeout` ∈ {≠ 0, 0}; fuente: medición del
  auditor + `list_objects.go`/`run.go`/`timeout.go`):

  | deadline | request-timeout | quién corta `ListObjects` | qué declarar | estado |
  |---|---|---|---|---|
  | ≠ 0 | ≠ 0 | el menor de los dos (el deadline pone su propio ctx; el interceptor envuelve por fuera) | el menor | soportado |
  | ≠ 0 | 0 | `--listObjects-deadline` | el deadline | soportado (default de siempre) |
  | 0 | ≠ 0 | `--request-timeout` con 200 mudo (**medido**: 30 ms ⇒ 0 de 40 000) | el request-timeout | soportado; `Infinity` aquí era el 🟠 |
  | 0 | 0 | ❓ el gateway HTTP (`--http-upstream-timeout` 5 s), no aislable (rompe los `Write`) | nada: **no soportado** | límite declarado |

  Y el driver: `listObjectsDeadlineMs` ∈ {entero > 0 ⇒ construye; `Infinity`/`NaN`/0/negativo/no entero ⇒ 500} (caso).
- (c) *Casos existentes puestos rojos*: `relations_openfga.spec.ts:1626` del cierre 1 (afirmaba el supuesto falso: reescrito como
  N1) y la línea `assert.include(readme, 'listObjectsDeadlineMs: Infinity')` de `scope_depth.spec.ts:105` (invertida a
  `notInclude` + las cinco frases nuevas). Ningún otro.
- (d) *Linaje*: **L8 (letra ≠ efecto), bajo M8** («toda enumeración que se puede cortar devuelve `truncated` o lanza»): el cierre 1
  había añadido una receta que producía justo la lista muda que M8 prohíbe; el cierre 2 la retira estructuralmente (la guarda
  solo admite enteros > 0: no hay forma de escribir «sin deadline») y el README deja de prometer lo no medido. No es la 3.ª
  iteración de un linaje NUEVO: es la misma propiedad universal de B4, corregida en la receta. Punto de paso único sin cambio
  (`#listObjectsPage`, mutantes de la guardia 112/112).

**🟡 N3**
- (a) *Gemelos*: `invalid-identity` ↔ `userset-unsupported` (los dos motivos por la MISMA rama del plan —`destResidue`— y de la
  letra —prefijo «sobra (<motivo>) destino:»—; tabla ejecutada para ambos); dry-run ↔ real (mismos números y misma línea: caso 4
  modos); plan ↔ comando (`report.prune` viaja; `runRelationsReconcile` no toca el reporte); origen ↔ destino (el origen no cambia:
  `skipped.invalid` / `skipped.usersetUnsupported`, deriva); `authz:reconcile` de roles: **no aplica** — sus «extra» son
  `extra-fact` con `--prune` real que SÍ borra (lo ajeno no se lista como podable: `foreign`), y su consejo del relay es otra
  cortesía; doble `fake` sin gramática ↔ `database` real (los dos casos: ni uno recibe el `unrelate`).
- (b) *Tabla de verdad* ({motivo} × {prune} × {dry-run, real}; todas ejecutadas: `relations_reconcile_cli.spec` :146/:198
  (letra), `relations_reconcile.spec` :668 (fake, 4 modos)/:704 (`database`, dry+real con prune)/:373 (origen, 🟠 1 del cierre
  1 sin prune); exit = el del comando, `clean=false` ⇒ 1):

  | motivo (destino) | prune | modo | bucket | `details.pruned` | línea (nivel `error`, prefijo estable) | consejo «repite con --prune» | exit |
  |---|---|---|---|---|---|---|---|
  | `invalid-identity` | sin | dry-run | `extra` | ausente | «sobra (invalid-identity) destino: … --prune tampoco la borraría (ningún driver del paquete … R-16 …) … a mano (SQL/SDK)» | no | 1 |
  | `invalid-identity` | sin | real | `extra` | ausente | ídem | no (hasta el cierre 2: warning + exit 0 + consejo) | 1 |
  | `invalid-identity` | con | dry-run | `extra` (NO `deleted`) | `false` | «… --prune NO la borra …» | no | 1 |
  | `invalid-identity` | con | real | `extra`; cero `unrelate` por ella | `false` | ídem | no | 1 |
  | `userset-unsupported` | sin | dry-run | `extra` | ausente | «sobra (userset-unsupported) destino: … tampoco lo borraría … DELETE …» | no | 1 |
  | `userset-unsupported` | sin | real | `extra` | ausente | ídem | no (hasta el cierre 2 salía el consejo) | 1 |
  | `userset-unsupported` | con | dry-run | `extra` | `false` | «… --prune NO lo borra … DELETE …» | no | 1 |
  | `userset-unsupported` | con | real | `extra`; cero `unrelate` | `false` | ídem | no (hasta el cierre 2 salía JUNTO a «NO lo borra») | 1 |
  | (sin residuo) `extra` podable | sin | real | `extra` | — | — | **sí**, «N tupla(s) … (no pasaste --prune)» con N = `extra − residuo` | 0 |
  | (sin residuo) `extra` podable | con | real | `deleted` | — | — | no (`report.prune === true`) | 0 |

  Origen (sin cambio): `invalid-identity` ⇒ `skipped.invalid` + «sin migrar (invalid-identity) origen: … a mano», exit 1;
  `userset-unsupported` ⇒ `skipped.usersetUnsupported` + receta, exit 1; ninguno descuenta del consejo del destino (caso).
- (c) *Casos existentes cuyo exit o letra cambió por la unificación* (todos `invalid-identity`, lote A ⚪ R2; listados y
  justificados):
  1. `relations_reconcile_cli.spec.ts:111` «⚪ R2 · details (invalid-identity) …» — reescrito como N3 `:146`. Cambian: destino
     sin prune de `warning` + `clean=true` (exit 0) a `error` + `clean=false` (exit 1) — **justificación**: `--prune` no la quita
     (los dos drivers del paquete la rechazan por R-16), así que «repite con --prune» era un consejo falso y exit 0 escondía una
     fila que solo se borra a mano; dry-run con prune de `pruned: true` + «se pedirá … BORRE … NO la borrará» a `pruned: false` +
     «NO la borra» (la letra vieja ya admitía que no la borraría: ahora lo dice el bucket); «BORRADA por --prune» (`pruned: true`
     real) y «NO se pudo borrar» (`pruned: false` tras pedirla) dejan de ser filas del paquete (la pasada no la pide).
  2. `relations_reconcile.spec.ts:568` «el repro del auditor, invertido: fake([good, garbage]) … --prune la borra (deleted 1)» —
     reescrito como N3 `:668`. Cambia: con prune de `deleted 1` + `unrelated ['ABC']` + `pruned: true` a `extra 1` + `unrelated []`
     + `pruned: false` — **justificación**: un destino SIN gramática (el fake) era el único que la borraba; la regla del
     coordinador es por la FILA (ningún driver del paquete la admite), no por el driver, así que la pasada no se la pide a nadie.
  3. `relations_reconcile.spec.ts:599` «destino REAL (database) … --prune se la pide al driver, que la rechaza» — título y dos
     aserciones (`:704`): dry-run de `pruned: true` a `pruned: false` (+ `extra 1`, `deleted 0`); real igual que antes
     (`pruned: false`, `extra 1`, la fila sigue) pero ahora con la prueba de que `unrelate` NO se llamó. **Justificación**: en
     dry-run la letra vieja vendía «se pedirá borrar» una fila que la pasada real nunca iba a borrar: dry ≠ real.
  4. `relations_reconcile_cli.spec.ts:99` «extra sin --prune AVISA pero no tumba»: sin cambio (sin `details`, sin `prune` ⇒ el
     consejo sigue). Ningún caso por el kernel (`command_flags`) ni el runbook afirmaba el consejo o `pruned: true`.
- (d) *Linaje*: **L8** («una operación destructiva lista lo que destruye», letra ≠ efecto) — la 11.ª iteración, y la regla
  «una regla, no dos» del coordinador aplicada ESTRUCTURALMENTE: una sola rama en el plan (`destResidue`, nunca `toDelete`) y una
  sola en la letra para todo residuo del destino que la API no admite; el reporte lleva `prune` para que la letra no adivine. No
  se abre linaje nuevo. Punto de paso único: `planPartition` (destino) + `relationsReconcileLines` (letra); mutantes 5/5 muertos.

## 3 · Tabla B5 y el resto: sin cambio (🟡 7 del cierre 1). N6 entra por la rama «NO valida» ya existente (misma letra, `exit 1`).

## 4 · Mutantes (copia `scratchpad/cierre2/repo`, `mutants.py`; aplicados uno a uno y revertidos; `diff -rq src` limpio al final)

| id | qué quita | rojos |
|---|---|---|
| N1.acepta-Infinity | vuelve `\|\| deadline === Infinity` | 2 / 9 |
| N2.f05-primero | F-05 antes que la forma en `classifySubject` | 1 / 31 |
| N3.invalid-en-toDelete | `invalid-identity` del destino vuelve a `toDelete` | 2 / 31 |
| N3.pruned-true | `pruned: true` para `invalid-identity` con prune | 2 / 31 |
| N3.consejo-sin-mirar-prune | el consejo con `extra > 0` a secas | 4 / 42 |
| N3.invalid-no-es-residuo | solo B3 tumba `clean` | 3 / 42 |
| N3.invalid-warning | `invalid-identity` destino como warning limpio | 2 / 11 |
| N4.guarda-y-luego-lanza | el doble guarda la fila inerte y DESPUÉS lanza el 422 (el mutante del auditor) | 1 / 58 (era 0 / 58) |
| N5.readAssignment-absent | `tuples?.[0]` ⇒ absent | 2 / 46 |
| N5.readTuple-default | `tuples ?? []` en `#readTuple` | 2 / 55 |
| N6.no-objeto-es-null | el no-objeto vuelve a `null` | 1 / 9 |
| N7.holderTypes-sin-array | sin la guarda | 1 / 63 |
| N8.sin-desglose | «todas de tipos que el destino no declara» de vuelta | 1 / 31 |

## 5 · Cifras (4 modos + 3 gates; en SECUENCIA, primer plano, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite; logs en `scratchpad/cierre2/`)

| Qué | Resultado |
|---|---|
| `npm run typecheck` / `npm run build` | ✔ exit 0 (purity + typecheck + tsc + stubs) |
| `npm test` (`:memory:` + OpenFGA) | **1725 passed, 2 skipped (1727)**, 1 m (partida 1718: **+7**) |
| `npm run test:sqlite-file` | **1753 passed, 2 skipped (1755)**, 2 m (partida 1746: +7) |
| `npm run test:pg` | **1850 passed, 1 skipped (1851)**, 2 m (partida 1843: +7) |
| `npm run test:mysql` | **1852 passed, 1 skipped (1853)**, 2 m (partida 1845: +7) |
| `check:guard-mutants` (`:memory:`) | **112 / 112 muertos**, 0 vivos, 0 sin casar, 95 s |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes, 50 s |
| `TEST_DB=sqlite-file cutover-runbook` | **VERDE**: 20 pasos + 2 pendientes |
| `TEST_DB=pg cutover-runbook` | **VERDE**: 20 pasos + 2 pendientes |
| Bases huérfanas PG / MySQL · stores en `:8090` | 0 / 0 · 5 (los mismos de antes; ninguno creado por estas corridas) |

Desglose del **+7** (`:memory:`): `relations_reconcile` +2 (N2, N8; N3 reescribe 2 casos existentes); `relations_reconcile_cli`
+1 (N3 consejo; N3 letra reescribe el ⚪ R2); `relations_openfga` +1 (N5; N1 reescribe el 🟡 8); `openfga_driver` +1 (N5 grant;
el grep se amplía); `relations_persisted_config` +1 (N6); `relations` +1 (N7). N4 amplía el caso B3 del runner (×4 harnesses, sin
sumar). `guard_surface` 171 casos / 112 mutantes sin cambio (ningún `find` de `guard_mutants.json` toca lo editado).

## 6 · Decisiones nuevas tomadas por el implementador (para ratificar)

1. **N3, estructural**: `invalid-identity` del destino **nunca entra en `toDelete`** (ni siquiera para un driver de terceros
   que la aceptara): la regla es por la fila, como pide «una regla, no dos»; desaparece el catch del 422 en el bucle de poda
   (un 422 ahí ahora se propaga: el plan clasifica, el driver no absorbe). `pruned` conserva el tipo `boolean` y el comando
   imprime «BORRADA» para un `true` que solo un harness de terceros podría construir.
2. **N3, `report.prune`** (opcional, ausente = no pasado) en vez de deducirlo de la letra: el consejo cuenta `extra − residuo`.
3. **N2 solo en el plan**: la API (`assertUsersetSubject`) mantiene F-05 → forma (ambos 422, cero llamadas); el bucket y el
   remedio se deciden en `classifySubject`.
4. **N1 sin caso contra un servidor real con deadline 0 dentro de la suite**: la medición es la del auditor (citada con método,
   cifras y versión en README/CHANGELOG/docblocks); el caso del driver corre con el reloj monótono inyectado y hay guardia por
   fuente. Los dos a 0: límite declarado, no promesa.
5. **N4, límite**: el harness «doble (mínimo)» (`usersetSubjects: false`, `enumerateRelations: false`) no puede observar la fila
   inerte por el puerto; se declara en el runner (comentario) y aquí.
6. **N5 en `readAssignment`**: `{}` es `unknown` (503 como causa), no un throw directo — conserva el contrato existente de
   `grant` («con objetivo explícito se puede escribir a ciegas; sin él, 503 con la receta de preservación»).
7. **CHANGELOG del cierre 1 corregido** (párrafo 🟡 8) además de la entrada nueva: una frase falsa no se deja en el mismo
   `[Unreleased]` que la que la retira.

## 7 · Lo NO hecho y por qué

- Re-medir N1 con contenedores propios: el brief lo deja como «solo si hace falta para medir»; la medición del auditor es
  reproducible (método y cifras en su informe) y no cambia la decisión del coordinador. No se levantó ningún contenedor.
- Guarda `Array.isArray` para `holderTypes`/`drivers` en el config de ROLES (N7): línea de límite (fallan al resolver).
- Caso por el kernel para N6: la rama del comando es la de 🟡 7 (`RelationConfigError`), ya cubierta por la tabla B5; N6 se
  fija en la lectura (`readRelationsConfigSpec`/`readRelationsConfig`).
- `check:guard-mutants -- --db sqlite-file`: no corrido (ningún mutante de la guardia cambia; el de `:memory:` da 112/112).
- `linajes.md` / `decisiones-dueno-*.md`: no editados (los administra el coordinador). Texto propuesto: L8 gana la 11.ª iteración
  (N3, «una regla, no dos» estructural) y la 10.ª queda corregida en su receta (N1: `Infinity` retirado bajo M8).

## Estado del árbol al cierre

```
$ git status --short
 M CHANGELOG.md
 M CLAUDE.md
 M README.md
 M commands/authz_relations_reconcile.ts
 M index.ts
 M package.json
 M providers/authz_provider.ts
 M src/define_config.ts
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_driver.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/manager.ts
 M src/openfga.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/relations/reconcile.ts
 M src/relations_config_store.ts
 M src/scope_outbox.ts
 M src/testing/relations_contract.ts
 M src/testing/scope_outbox_contract.ts
 M src/types.ts
 M tests/command_flags.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/freeze.spec.ts
 M tests/guard_surface.spec.ts
 M tests/helpers/cutover_child.ts
 M tests/helpers/relay_child.ts
 M tests/manager.spec.ts
 M tests/openfga_driver.spec.ts
 M tests/reconcile.spec.ts
 M tests/relations.spec.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/relations_persisted_config.spec.ts
 M tests/relations_reconcile.spec.ts
 M tests/relations_reconcile_cli.spec.ts
 M tests/scope_depth.spec.ts
 M tests/scope_outbox.spec.ts
 M tests/scope_outbox_contract.spec.ts
 M tests/scope_outbox_harness.spec.ts
 M tests/scope_outbox_multiprocess.spec.ts
 M tests/upgrade_recipe.spec.ts
?? src/relations_reconcile.ts
```

(`tests/freeze.spec.ts` sigue en la lista por el cierre 1 —3 líneas cambiadas—; este cierre no lo toca.)

```
$ git diff --stat
 CHANGELOG.md                             | 290 ++++++++++++++++++++++++++
 CLAUDE.md                                |  20 +-
 README.md                                | 167 +++++++++++++--
 commands/authz_relations_reconcile.ts    | 281 +++++++++----------------
 index.ts                                 |   4 +-
 package.json                             |   1 +
 providers/authz_provider.ts              |   5 +-
 src/define_config.ts                     | 133 ++++++++++++
 src/drivers/database_relations_driver.ts |   5 +-
 src/drivers/openfga_driver.ts            |  63 +++++-
 src/drivers/openfga_relations_driver.ts  | 185 ++++++++++++++--
 src/errors.ts                            |  38 ++++
 src/manager.ts                           |   7 +-
 src/openfga.ts                           |   2 +-
 src/relations/define_relations_config.ts | 246 +++++++++++++++++++++-
 src/relations/manager.ts                 |   6 +-
 src/relations/reconcile.ts               | 247 +++++++++++++++++-----
 src/relations_config_store.ts            |  40 +++-
 src/scope_outbox.ts                      |  25 ++-
 src/testing/relations_contract.ts        |  72 ++++++-
 src/testing/scope_outbox_contract.ts     | 200 +++++++++++++-----
 src/types.ts                             |  10 +-
 tests/command_flags.spec.ts              | 193 ++++++++++++++++-
 tests/fixtures/guard_manifest.ts         |  54 +++--
 tests/fixtures/guard_mutants.json        | 164 ++++++++++++++-
 tests/freeze.spec.ts                     |   6 +-
 tests/guard_surface.spec.ts              | 110 ++++++++--
 tests/helpers/cutover_child.ts           |   4 +-
 tests/helpers/relay_child.ts             |   2 +-
 tests/manager.spec.ts                    | 120 +++++++++++
 tests/openfga_driver.spec.ts             |  84 ++++++++
 tests/reconcile.spec.ts                  |  64 +++++-
 tests/relations.spec.ts                  | 157 ++++++++++++++
 tests/relations_harness.spec.ts          |   5 +-
 tests/relations_openfga.spec.ts          | 195 ++++++++++++++++-
 tests/relations_persisted_config.spec.ts |  59 ++++++
 tests/relations_reconcile.spec.ts        | 347 ++++++++++++++++++++++++++++---
 tests/relations_reconcile_cli.spec.ts    | 125 ++++++++---
 tests/scope_depth.spec.ts                |  23 +-
 tests/scope_outbox.spec.ts               | 181 +++++++++-------
 tests/scope_outbox_contract.spec.ts      |  26 ++-
 tests/scope_outbox_harness.spec.ts       |  18 +-
 tests/scope_outbox_multiprocess.spec.ts  |   2 +-
 tests/upgrade_recipe.spec.ts             |  68 ++++++
 44 files changed, 3479 insertions(+), 575 deletions(-)
```
