# Panel «tenencia» (7.º informe de COGNITIV) — veredicto del juez

Fecha: 2026-10-14 · versión: `2.4.0-alpha.10` · entradas: `cognitiv-informe-7-tenencia.md`, `panel-tenencia-coordinador.md`,
`panel-tenencia-analista.md`, `panel-tenencia-auditor.md`, `panel-tenencia-tester.md`, `CLAUDE.md` («Cómo se decide un
cambio», 1–10) y `linajes.md`. Leí además, para resolver conflictos, `src/relations/define_relations_config.ts:265-288`,
`src/drivers/openfga_relations_driver.ts:382-388` y `providers/authz_provider.ts:58-59`.

Notación de severidad del auditor: [R n] = rojo n, [N n] = naranja n, [A n] = amarillo n, [B n] = blanco n.

---

## Veredicto

**Recomendación:** el plan del **analista** (lotes A/B/C/D: primero lo aditivo; P1 condicionado y opt-in), con un cambio de
orden: **la guardia de superficie de L1 va ANTES que cualquier operación nueva** (38 → 40 de 50; 80/100 tras los injertos).
El motivo decisivo: es el único plan que no mete un [R] sin mitigar en el ciclo, porque **saca P1 del camino crítico**. Además,
**el caso Nóminas no lo resuelve P1 en ninguna de sus variantes**: lo resuelve `inherits=false` en el evaluador del consumidor.

**Injertos de otras posturas:**
- Del **tester** y el **auditor**: la guardia de superficie por reflexión (L1, y las columnas L2/L3 para las escrituras) es el
  lote 0, antes de `checkMany`. P5-1 es obligatorio porque la línea del provider es hoy una entrada inerte. Las tablas T1 y T3
  y la matriz de monotonía son el criterio de aceptación de P1. Las tablas T4/T5 sirven para P4/P2.
- Del **auditor**: las mitigaciones de [R 2], [R 3], [N 4], [N 6], [N 7], [N 8] y [N 9] son **condiciones de entrada del lote
  de P1**, no tareas de ese lote. También entra la nota de seguridad de P2: el sujeto sale de la sesión y un userset es 422.
- Del **coordinador**: P3 no guarda `meta`; solo hay una clave pura. Sin comodín `*`.
- Del **analista**: P1 se codifica como `denied_<rel>` en la misma tabla y con el mismo nombre de relación pública; va opt-in por
  tipo, con cota 43; sin DDL en `database`. Más `decideMany` tri-estado (solo con P1). Y P2 con «directas + `includes`
  resueltos», con un cursor por clave natural.

**Condición para proceder:** con alpha.11/12 se procede ya. Con P1 **no**, hasta que haya: (a) respuesta de COGNITIV a la
pregunta C1 (abajo); (b) el lote 0 en verde con sus mutantes; (c) las decisiones del dueño D2–D5.

---

## Tabla de puntuación

Los criterios son los fijados por el encargo: cinco, de 0 a 10 y con el mismo peso (total sobre 50). Las opciones puntuadas
son los planes que existen en el debate; no hay ninguna opción inventada.

| Criterio | COGNITIV tal cual (P1→P4→P5→P3 con `meta`→P2) | Coordinador (P5→P4→P1 literal→P2→P3-clave) | Analista (A→B→C→D) | Tester (guardia→P5→P4→P1→P2→P3) | Nota |
|---|---|---|---|---|---|
| (1) Seguridad: fail-closed, sin inversión del signo | 2 | 3 | 7 | 6 | Las dos primeras meten P1 en el ciclo con [R 1] (booleanos), [R 2] (ventana de renovación) y [R 3] (reconcile sin `kind`) abiertos ⇒ **descalificadas**. El analista difiere P1, pero su «renovar = delete+write» reproduce [R 2] cuando P1 llegue (tiene que injertarse). El tester detecta [R 2] (P1-R2 en rojo) pero mantiene P1 dentro del ciclo |
| (2) Verificabilidad en la suite común | 4 | 5 | 8 | 9 | `listSubjects` que resta cuesta 1.200 checks en FGA (T2) y la atomicidad de `meta` en FGA no es observable (NO-OBS) ⇒ COGNITIV baja. El tester es el que más casos con nombre aporta |
| (3) No amarrar el paquete a COGNITIV | 4 | 7 | 9 | 7 | Comodín «solo para deny» y `meta` almacenado están hechos a medida. Opt-in por tipo + clave pura + sin noción de owner = genérico y reversible |
| (4) Coste/riesgo frente a valor | 3 | 6 | 8 | 5 | P1 cuesta 34–56 h (+50 % de cierres) y **no resuelve** el caso que lo motiva. Hacerlo primero o tercero es el peor ratio |
| (5) Linajes y regla de tres (M8) | 2 | 3 | 6 | 9 | Con una operación nueva antes de la guardia, L1 llega a su 5.ª iteración como parche. El analista pone `checkMany` (lote A) antes que la guardia (lote B): por eso no gana aquí |
| **Total /50** | **15** | **24** | **38** | **36** | |
| **Con injertos** | — | — | **40** (orden del tester + mitigaciones del auditor) | — | |

---

## Conflictos entre panelistas

1. **Deny literal (coordinador) vs. deny que sube (analista, tester, auditor y COGNITIV).** → Resuelto: **sube**. Que el
   literal rompe R-02 (`editor ⇒ viewer`) está demostrado por los tres (T1 del tester, [N 5] del auditor, §1.2 del analista).
   El precedente de roles no decide la cuestión, porque los permisos no tienen `includes`. El coordinador pierde.

2. **CONFLICTO QUE NADIE SEÑALÓ: hay dos «sube» distintos.** → Resuelto a favor del del analista, que es el medido. La T1 del
   tester tiene que reescribirse.
   - **Por consulta** (COGNITIV §2.5, columna «S» de la T1 del tester): `check(Q)` se bloquea si hay un deny en `Q` o en una
     relación más débil que `Q`. Un `owner` con `deny(editor)` sigue viendo: `check(viewer)` = T.
   - **Por grant, o corte de camino** (modelo anidado del analista, **medido** en v1.19): un deny en `Y` anula todo grant `T`
     que implique `Y`, **con todo lo que ese grant deriva hacia abajo**. El mismo `owner` con `deny(editor)` da F/F/F, y solo
     sobrevive un `viewer` directo. Lo confirma la fila *bob* del analista: `editor` = F con deny en `manager`, cuando por
     consulta saldría T.
   - Las dos son monótonas (P1-M pasa en ambas). Difieren en las celdas «deny en relación fuerte, pregunta por relación débil».
     La de consulta no se puede expresar en FGA sin separar la relación cruda de la efectiva con **nombres de almacenamiento
     nuevos**, y eso reabre [N 4] (rolling deploy y usersets por nombre). La de corte se expresa con la relación pública
     anidada y deja las tuplas existentes intactas. Además, es la más restrictiva de las dos (falla del lado cerrado).
   - Carga de la prueba: el tester rehace T1 con la semántica de corte. El analista añade a su tabla medida la fila
     `owner + deny(editor)` ⇒ F/F/F y la fila `owner + deny(owner)` ⇒ F/F/F. La elección final es del dueño (D5).

3. **Relación efectiva con nombre nuevo (`viewer_eff`, sugerencia de COGNITIV §2.6) vs. la propia.** → Resuelto: **la propia**,
   anidada (`X = (this or I…) but not denied_X`). El analista lo midió en v1.19; el auditor [N 4] demuestra que un nombre
   nuevo deja fuera a los pods viejos y a los usersets. La fila CAMINO del tester (P1-6d) era el mutante que se temía; el
   modelo medido no es CAMINO (para `D = viewer` da F/F/F, y CAMINO da F/T/T). El caso P1-6d se queda como guardián.

4. **`checkMany` booleano basta (coordinador, COGNITIV §7) vs. no basta (auditor [R 1]) vs. hace falta `decideMany` (analista).**
   → Resuelto en dos niveles:
   - Sin P1, el booleano es exacto y se publica.
   - Con P1, el booleano **no puede** implementar «deny gana» a lo largo de una cadena (auditor, por lectura, irrefutado).
     `decideMany` sí lo distingue. Pero **ni siquiera el tri-estado arregla Nóminas para los invitados cross-org**: el invitado
     no es miembro de `org#member`, así que en Nóminas sale `none` y el evaluador hereda de Finanzas (analista §1.7.2, por
     razonamiento; el componente «deny a grupo bloquea al miembro» está medido, fila *dave*). Lo único que cubre owner,
     departamento e invitados es `inherits=false`. Ver «Decisión por petición · Nóminas».

5. **`kind` obligatorio en `RelationTuple` (auditor [R 3]) vs. opcional (analista).** → Resuelto: **opcional + censo en el
   runner**. Hacerlo obligatorio rompe la compilación de drivers de terceros ⇒ major (`CLAUDE.md` punto 4). La garantía viene
   de la fila de la T3 del tester: «un driver que declara `relationDenies: true` y no marca `kind` no pasa el runner».
   Dos cosas más:
   - Con origen con denies y destino sin capacidad: 500 antes de escribir. Un deny nunca va a `skipped`.
   - Al podar se llama a `to.removeDeny`, no a `unrelate`.

6. **Tres estados de `expiresAt` iguales que en `relate` (analista) vs. invertidos para el deny (auditor [N 6]).** → No lo
   resuelve un panelista: es una **decisión del dueño (D3)**. Mi recomendación es que en `deny`, con `expiresAt` omitido, el
   deny pase a ser **permanente**, y que el resultado devuelva `previousExpiresAt`. Así se falla del lado cerrado. La asimetría
   con el invariante 10 quedaría escrita.

7. **Renovar la caducidad de un deny en openfga: P1-R2 «nunca hay ventana» (tester) vs. «marcarlo indeterminado» (auditor) vs.
   «delete+write como `relate`» (analista).** → Sigue abierto. Le toca al analista **medir** contra 1.19 si un `Write` admite
   `deletes` y `writes` de la misma clave con otra condición. Hoy solo lo dice un comentario del código
   (`openfga_relations_driver.ts:384-387`); nadie lo ha medido.
   - Si no lo admite, P1-R2 es **insatisfacible** y el dueño elige (D3) entre dos salidas: ventana declarada con
     `markPartialWrite` ⇒ `indeterminate: true` cuando el 2.º `Write` falle, o deny **sin caducidad** en v1 (el deny de roles
     tampoco caduca, `openfga_facts.ts:37`).
   - Mientras siga abierto, P1 no entra.

8. **`partitions: []` en P2: 500 (analista, precedente `enumerateRelationsMany`) vs. 422 (tester).** → Resuelto: **422**. P2
   es una lectura del camino de petición, así que es una «pregunta inválida» (invariante 5). El precedente del 500 es una API
   de plataforma (un error de config).

9. **`checkMany`: método opcional que el manager compone (analista) vs. capacidad `checkManyNative` (tester P4-9).** →
   Resuelto: **sin capacidad**. El método es opcional y el manager compone, como `authorizeMany`. El caso P4-9 se mantiene
   contra el doble MÍNIMO sin una clave de capacidad nueva. Una capacidad que no cambia la respuesta solo añade otra cara
   que mantener.

10. **`[]` en `checkMany`: `[]` sin llamadas (analista) vs. «decidir 422 o `[]`; `every([])` es verdad vacía» (auditor [A 14]).**
    → Resuelto: **422** (`E_AUTHZ_INVALID_IDENTITY` u otro código de entrada vacía). Una cadena de ancestros nunca está vacía,
    así que un `[]` es un error del llamante. Respondiendo 422, un `every([])` no puede conceder.

11. **Orden: P3-clave al final (coordinador, tester) vs. en el primer lote (analista).** → Resuelto: **primer lote**. Cuesta
    2–4 h y es el punto de paso único que P1 necesitará (`kind` en la clave, [R 3]). Antes hay que unificar `scopeKeyOf`
    (`reconcile.ts:50`) con `scopeKey` (`identity.ts:225`), por el [A 15] del auditor.

12. **«P5 es documentación» (coordinador, auditor) vs. «la línea del provider no tiene test» (tester).** → Resuelto a favor del
    tester. El ajuste es este: la línea existe (`authz_provider.ts:59`, verificado), pero si se borra **nada se pone rojo**,
    según el grep del tester. Es una entrada inerte de L5 y P5-1 es obligatorio.

13. **`listSubjects` resta denies (COGNITIV §2.3.4) vs. no resta (analista, tester T2).** → Resuelto: **no resta**. Así se
    mantienen el invariante 7 y el gemelo de roles (`listSubjects`/`hasRole` no restan; `listScopes` sí). Regla única: lo que
    enumera **hechos** no resta (`listSubjects`, `listDenies`, `enumerateRelations`) y lo que enumera **acceso efectivo** sí
    resta (`listObjects`, `membersOf`, P2). Casos P1-15b y P1-15c.

---

## Qué está MEDIDO contra OpenFGA 1.19 y qué es lectura

**Medido** (analista, OpenFGA **v1.19.0** en `127.0.0.1:8090`, `openfga-dev`; store temporal ya borrado. No es el `:8101`
canónico, pero sí la misma versión que la imagen del tope 3 de CI):
- un `difference` cuya base es `union{this, computed(I)}` se publica y se evalúa;
- las cinco filas alice/bob/carol/dave/erin (corte por grant, deny por grupo, deny caducado/futuro **con** la condición en la
  rama restada);
- `Check(user, denied_R, o)` responde con el cierre ascendente;
- `Read({user, relation, object:'type:'})` devuelve tuplas de varias particiones; sin `user` da 400;
- `Read` devuelve tuplas crudas: sin expandir `includes`, incluye las denegadas y no evalúa la caducidad;
- `ListObjects` ya es multipartición en el servidor;
- `BatchCheck` acepta ítems idénticos con distinto `correlation_id`.

**Medido** (tester, SQLite `:memory:`): las cinco specs de relaciones en verde (44/9/47/23/50), y el grep de que `clock:
config.clock` no tiene caso.

**Verificado por mí (lectura puntual):**
- `defineRelationsConfig` rechaza la autoinclusión pero **no** ciclos `A⊇B⊇A` (`define_relations_config.ts:265-288`). La
  incógnita (c) del analista es real y bloquea P1, porque con `denied_*` invertido el ciclo también se invierte.
- El comentario de FGA sobre delete+write está en `openfga_relations_driver.ts:384-387`.

**Lectura, sin medir:**
- Todo el informe del auditor (lo declara él mismo: «No ejecuté nada»): [R 1], [R 2], [R 3] y [N 4]–[N 9] salen de leer el
  código. Son sólidos como lectura y se aceptan como riesgos de diseño, no como defectos medidos.
- El driver `openfga` en el informe del tester (lo declara él mismo).

---

## Afirmaciones descartadas por falta de evidencia (o rebajadas a incertidumbre)

- **Coordinador:** «roles ya hace deny con `but not`: patrón probado para P1». Rebajada. El operador está probado; la forma no
  (la rama restada de roles no lleva ni condición ni userset, [B 18]). La forma anidada la midió el analista, no el coordinador.
- **Coordinador:** «`Read` por sujeto + tipo ⇒ P2 directo factible». Cierta solo en lo que trae (medido). Omite el filtrado
  posterior (caducidad, `includes`, deny), que es donde está el trabajo.
- **Coordinador:** «versión 2.5 porque `list*` omiten denegados». Mal fundada. El cambio observable para todos es de **tipos**
  (`RelationRef.operation`, `types.ts:1910`, se ensancha), no de comportamiento; el comportamiento solo cambia para quien
  escribe denies (analista, tester §7).
- **Auditor [A 12]:** «`ListObjects` corta en silencio al vencer el deadline». Viene de discusiones de la comunidad, no de la
  documentación oficial ni de una medición. Queda como incertidumbre: no se promete «exhaustivo» en `listObjects` de
  openfga, solo «exhaustivo o `truncated` por tope» (tester §8, NO-OBS).
- **Auditor [B 18]:** «una tupla condicional sin contexto en la rama restada podría omitirse». Sin verificar. La medición del
  analista (erin) solo cubre el caso **con** `current_time`. Sigue abierta para P2/P4 si algún camino nuevo no pasa
  contexto.
- **Analista:** «un tipo de 3 relaciones pasa de ≈1,0 a ≈2,0 permisos equivalentes en bytes». Es una estimación. Hay que
  medirla con `factsModelBytes` antes de publicar P1; las cifras del README quedan falsas hasta entonces.
- **Analista:** horas de todos los lotes (estimación). Se usan solo para ordenar, no como compromiso.
- **COGNITIV §3.3:** «`purgeScope` de la partición dueña lo retira». Lo presupone, pero no existe: `scopes.detached` no toca
  `authz_relations` (analista y auditor [A 16], por lectura y sin contradicción).

---

## Decisión por petición

### P1 · Deny en relaciones — **DESPUÉS, condicionado; no en alpha.11/12**

**Cuándo.** No ahora. Entra solo si se cumplen las cuatro condiciones:
- COGNITIV nombra un caso que necesite deny y que no sea romper la herencia (C1);
- el lote 0 está en verde;
- el dueño ha decidido D2–D5;
- están medidas cuatro incógnitas: bytes del modelo, latencia de `Check`/`ListObjects` con exclusión, ciclos de `includes` en
  el servidor y `Write` delete+write de la misma clave.

No es «nunca». Es genérico («este grupo sí, esta persona no») y útil para un segundo consumidor (regla de tres).

| Sub-decisión | Decisión | Caso con nombre que la fija |
|---|---|---|
| ¿Literal o sube? | **Sube, por corte de camino** (modelo anidado medido; D5) | *«un deny en viewer bloquea al manager»* y *«un deny en editor anula el grant de manager entero; solo un viewer directo sobrevive»*, más P1-M (64 estados) y T1 reescrita, en BRIDGE |
| ¿Relación efectiva con nombre nuevo o la propia? | **La propia, anidada**; tuplas sin migrar | P1-6d (el mutante CAMINO, en rojo) + caso de [N 4]: *«un deny sobre una relación usada en un userset se honra en paridad»* |
| ¿`kind` en reconcile? | **`kind?` opcional + censo en el runner** con `relationDenies: true`. `relationTupleKey` con `kind` como clave del reconcile. Escritura: denies primero; poda: allows primero y denies al final. Destino sin capacidad ⇒ 500 | T3 completa, incluida la fila «tercero que declara deny y no marca `kind` ⇒ no pasa» |
| ¿Renovación en openfga (ventana)? | **Abierta**: medir; si FGA no deja cerrarla, D3 (ventana declarada + `indeterminate`, o deny sin caducidad) | P1-R2 (espía con barrera) o, en su lugar, *«el 2.º Write caído deja el evento indeterminate: true»* |
| ¿`expiresAt` omitido? | **D3**; recomendación: omitido ⇒ permanente + `previousExpiresAt` | P1-12 reescrito con la rama elegida |
| ¿Activación opcional por tipo? | **Sí** (`deny: true` en el tipo). Relación denegable ≤ 43 caracteres, solo en esos tipos. Sin opt-in, el modelo FGA queda byte a byte igual | literal `DOCUMENT_DEF`/`EXPECTED_FUSED` sigue verde (tester §7) + P1-30 |
| Comodín `*` | **No** | P1-17a |
| Deny sobre el tipo built-in `group` | **422 en v1** | P1-18 (rama 422) |
| Userset de un tipo del consumidor como sujeto ([N 9]) | **422** en escrituras, en los dos drivers | caso del auditor [N 9] |
| `listSubjects` / `membersOf` | `listSubjects` no resta; `membersOf` y `listObjects` restan | P1-15b, P1-15c, P1-13, P1-14 (contra el `:8103`) |
| Purga de openfga | allows primero, denies al final | P1-21 |
| Alias de partición ([N 8]) | **condición previa**: canonizar o 422 sin guiones en todas las operaciones (D4) | *«un alias de la partición jamás evade un deny de relación»* |
| Ciclos en `includes` | **condición previa**: rechazar ciclos en `defineRelationsConfig` (hoy no lo hace, verificado) | unitario: `A⊇B⊇A` ⇒ 422 |
| `RelationRef.operation` | se ensancha; anunciado como cambio de tipo publicado | F3/F10 de `relations_events_docs.spec` reescritos |

### Caso Nóminas — **`inherits=false` en el evaluador del consumidor, sin tocar el paquete**

- **P1 + `checkMany` booleano:** **no** lo resuelve ([R 1]). El allow está en Finanzas y el deny en Nóminas, y un `false` no
  dice cuál de los dos casos es.
- **`decideMany` tri-estado:** resuelve a los miembros de la organización, pero **no** a los invitados cross-org (no son
  miembros de `org#member`). Tampoco puede eximir al owner: un deny a `org#member` le alcanza también a él (fila *dave*,
  medida).
- **`inherits=false`:** cubre a los tres actores. Es el modelo de «carpeta de acceso limitado» de Drive/SharePoint, y la
  herencia ya es del consumidor (informe §1).
- **El paquete** escribe en el README que un booleano por objeto no puede implementar «deny gana» a lo largo de una cadena
  externa. Así el siguiente consumidor no repite el plan de §7.

### P2 · `listObjectsForSubject` — **SÍ, alpha.12**

- **Sujeto:** solo holders. Un userset da 422 (P2-6). El sujeto sale de la **sesión** y el README lo dice ([N 10] b).
- **Semántica:** tuplas **directas vivas** del holder, con `includes` resueltos (P2-2a; coherente con R-09 y con
  `listObjects`, L8). Lo que llega por grupos **no** sale, y queda declarado (P2-3a).
- **Cuando exista P1:** los candidatos se verifican con `check`/`batchCheck` (P2-5, [N 10] a). En el primer corte no hay
  denies que filtrar.
- **Cursor:** por `(partition_key, object_uuid)`, nunca por `uuid` de fila (P2-9, P2-10).
- **`database`:** índice nuevo `authz_rel_subject_any_idx (subject_type, subject_uuid, object_type)`, con la receta de
  upgrade **ejecutada** en los tres motores.
- **`openfga`:** `Read({user, object:'type:'})`, sin filtro de relación, y filtrado en cliente con el reloj del driver
  (P2-13).
- **`partitions`:** `[]` ⇒ 422 (conflicto 8). Una entrada mal formada ⇒ 422.
- **Capacidad:** `listObjectsForSubject` (par). Con `false` ⇒ 500 `E_AUTHZ_UNSUPPORTED`, nunca `[]` (P2-11).
- **Particiones:** dos ortografías salen como dos particiones (declarado, P2-14).
- **No existe** «`purgeScope` de la partición dueña lo retira»: se dice a COGNITIV y se fija P2-8 con `purgeObject`.

### P3 · Metadatos — **sin `meta` en el paquete; clave pura sí, alpha.11**

- `relationTupleKey(subject, relation, object, partition, kind?)` es pura y se exporta desde la raíz. **`reconcile.ts` usa la
  misma función** (P3-4, guardia de identidad del import) y antes se unifica `scopeKeyOf` con `scopeKey`.
- Es inyectiva (P3-1), no cambia al renovar (P3-2) y la de un deny es distinta de la de un allow (P3-3).
- Las ortografías de partición dan **dos claves**, coherente con `check` (P3-5, declarado).
- `relate` sigue devolviendo `void`.

### P4 · `checkMany` — **booleano SÍ (alpha.11); `decideMany` solo con P1**

- **Tope 50** ⇒ 422 con cero llamadas (P4-5).
- **Duplicados** permitidos: se deduplican dentro y se responde por posición (P4-4a).
- **`[]`** ⇒ 422 (conflicto 10).
- **Tipos mezclados** permitidos, con F-05 **por ítem** (P4-6, P4-7).
- **Un `error` por ítem** ⇒ 503 total (P4-3).
- **FGA:** se reutiliza `batchCheckAll` + `correlateBatchResults` de roles, alineando por `correlationId` y nunca por
  posición.
- **Un solo `now`** por lote.
- **Método opcional.** Si el driver no lo trae, el manager compone, sin capacidad (P4-9 contra el doble MÍNIMO).
- **Promesa de coste:** una consulta en `database` y un `batchCheck` por cada 50 en FGA (P4-8, por espía).

### P5 · Reloj — **SÍ, alpha.11; P5-1 obligatorio**

- **Casos:**
  - P5-1: borrar `clock: config.clock` pone la suite en rojo.
  - P5-2: el helper no muta el singleton del provider.
  - P5-3: un método nuevo que llame a `systemClock()` se pone en rojo; se amplía `clock.spec` a los drivers de relaciones.
- **`createTestClock(start)`** va en `/testing`, como función estable que lee un valor mutable y se cablea **solo** con
  `app.inTest` en `config/authorization.ts`.
- **README «Testing expiry from your app»** con el aviso de que el reloj también decide el lease del freeze
  (`manager.ts:373`).

### Guardia de superficie de L1 (F-05) — **condición de entrada del lote A**

Primero, por M8: L1 lleva 4+ iteraciones y `checkMany` sería la 5.ª.

Condición de entrada, cumplida en el lote 0:
1. Un spec enumera por reflexión `Object.getOwnPropertyNames(RelationsManager.prototype)` y los prototipos de los dos drivers
   de relaciones.
2. Cada método público tiene una fila `{método → sonda con role_binding}`. Un método sin fila es rojo. Las exenciones
   (`capabilities`, `enumerateRelations*` de plataforma…) van **firmadas por el dueño** en `decisiones-dueno-*.md`
   (`CLAUDE.md` punto 6).
3. La sonda exige 422 con cero llamadas al cliente o a la conexión y cero eventos, por el manager **y** por `driver()`.
4. Hay un mutante por entrada (quitar la aserción F-05) que pone el spec en rojo.
5. Columnas L2 (`{transaction}` con driver `false` ⇒ 500 con cero llamadas) y L3 (congelado ⇒ 503) para las **escrituras
   existentes**. Las de `deny`/`removeDeny` entrarán con P1 sin tocar el spec.
6. La lista a mano de `relations_database.spec.ts:554-599` se sustituye o se encadena a la guardia.

`linajes.md` cambia en L1 «punto de paso único: pendiente» por la guardia.

---

## Lotes, versiones, horas y criterio de aceptación

| Lote | Contenido | Versión | Horas (estimación del analista, ajustada) | Criterio de aceptación |
|---|---|---|---|---|
| **0** | Guardia de superficie L1 (+ columnas L2/L3 en las escrituras actuales) | `2.4.0-alpha.11` | 6–10 | Los 6 puntos de arriba. `scripts/check_flag_mutants.mjs` y los mutantes de la guardia muertos. Las exenciones firmadas |
| **A** | P5 (P5-1/2/3, `createTestClock`, README) · P3-clave (`relationTupleKey`, reconcile la usa, `scopeKeyOf` unificado) · P4 `checkMany` booleano | `2.4.0-alpha.11` | 10–18 | P5-1 rojo con la línea del provider borrada. P3-1..5 con P3-4 por identidad. P4-1..9 en la COMÚN (2 dobles + `database` en los 4 modos + `:8101` + `:8103`). `EXPECTED_CASES`/`CAPABILITY_KEYS` actualizados con desglose. CHANGELOG problema → decisión → qué NO (sin `meta`, sin `decideMany` todavía). Modelo FGA intacto (literal fusionado en verde) |
| **C** | P2 directo + índice + receta ejecutada + par de capacidad + nota de seguridad | `2.4.0-alpha.12` | 14–22 | P2-1..14 (con las ramas elegidas arriba). T5 completa. Receta de índice ejecutada en `upgrade_recipe.spec` (pg/mysql/sqlite). Propiedad `filtrar(P2, P) = listObjects(P)` en BRIDGE. Tabla «Limits» con la cota de páginas |
| **D** | P1 opt-in (corte de camino) + `decideMany` + P2 filtrado por deny + reconcile con `kind` + mitigaciones del auditor | `2.5.0-alpha.1` (cambio de tipos publicados y del modelo FGA para quien lo active) | 34–56, +50 % de cierres ⇒ hasta ~85 | **Entrada:** C1 respondida, D2–D5 decididas, cuatro mediciones hechas, ciclos de `includes` rechazados, alias de partición resuelto. **Salida:** T1 (corte) y P1-M en BRIDGE. T3 completa por el kernel (`authz:relations:reconcile`, regla 7). La tabla de signos del auditor (2.º `Write` caído, purga cortada, reloj ±, alias, pod viejo, re-deny omitido): el deny sigue bloqueando en cada fila. P1-1..32 según ramas. `factsModelBytes` medido y README actualizado. Auditoría de sistema (punto 9) |

Total para alpha.11 + alpha.12: **30–50 h**. P1 no consume horas hasta que se cumpla su condición de entrada.

---

## Riesgos que quedan aunque se elija la ganadora

- Con P1, **el sesgo del reloj deja de ser seguro en cualquier dirección**: los denies caducan antes ([A 13]). Solo se
  documenta; el desfase entre procesos no es observable (NO-OBS).
- `ListObjects` con exclusión en FGA puede cortar por deadline sin señal (sin verificar). Se promete «exhaustivo o
  `truncated` por tope», no más.
- P2 amplía el radio de un IDOR del consumidor a todos los tenants si el consumidor pasa el sujeto desde el cuerpo. El paquete
  solo puede documentarlo.
- `relationTupleKey` con ortografías de partición distintas da claves distintas. La tabla de `meta` del consumidor puede
  quedar huérfana tras una purga que barra las dos ortografías.
- Las tuplas de una organización borrada siguen vivas en relaciones (no hay purga por partición). P2 las haría visibles a sus
  invitados.
- Añadir alpha.11/12 a la línea 2.4 alarga el camino al criterio de 2.4.0 estable (punto 10: la auditoría de sistema y el
  ensayo de COGNITIV se repiten sobre la RC). Ver D1.

---

## Preguntas para el DUEÑO (cambian el alcance)

- **D1.** ¿alpha.11/12 (lotes 0, A y C) dentro de la línea 2.4, retrasando la RC estable, o se congela 2.4 en lo que hay y
  todo esto va a `2.5.0-alpha`? Recomiendo la línea 2.4: todo es aditivo y no toca el modelo FGA.
- **D2.** ¿Se aprueba que **P1 salga del ciclo** y quede condicionado a la respuesta C1 de COGNITIV? Si COGNITIV dice que
  `inherits=false` le basta, P1 espera a un segundo consumidor.
- **D3.** Si P1 entra, la caducidad del deny:
  - (a) Permitirla, con la ventana de renovación en openfga declarada y `indeterminate` si el 2.º `Write` falla (siempre que
    la medición confirme que FGA no deja hacerlo en un solo `Write`).
  - (b) Deny **sin caducidad** en v1, como el de roles.
  - Y en ambos casos, ¿`expiresAt` omitido en un re-deny ⇒ permanente (recomendado) o preserva (invariante 10 literal)?
- **D4.** Alias de partición en relaciones ([N 8]): ¿canonizar o 422 para el uuid sin guiones **en las ocho operaciones
  actuales**? Es un cambio de comportamiento observable para cualquier consumidor que hoy escriba sin guiones. Es condición
  previa de P1, pero se puede decidir ya.
- **D5.** ¿Se acepta la semántica de **corte de camino** (medida; `owner + deny(editor)` ⇒ no ve nada salvo un `viewer`
  directo) frente a la semántica **por consulta** de COGNITIV §2.5 (el owner seguiría viendo)? La segunda obliga a renombrar
  relaciones de almacenamiento en FGA y reabre [N 4]. Recomiendo el corte.
- **D6.** Exenciones de la guardia L1: firma de la lista (`capabilities`, `enumerateRelations`, `enumerateRelationsMany` y
  las que salgan).

## Preguntas para COGNITIV (antes de comprometer P1)

- **C1.** ¿Os basta un `inherits=false` en `tenancy_nodes` dentro de vuestro evaluador para Nóminas? Si no, ¿qué caso
  necesita deny que no sea romper la herencia? ¿Y cómo excluís al owner y cubrís al invitado cross-org, que no es miembro de
  `org#member`?
- **C2.** Si necesitáis deny, ¿necesitáis deny **temporal** («bloqueado hasta el cierre contable») o os vale uno permanente?
  (decide D3)
- **C3.** ¿Escribís siempre las particiones con el uuid canónico (minúsculas, con guiones)? ¿Alguna ruta acepta la forma sin
  guiones? (decide D4)
- **C4.** ¿Os basta para «Compartido conmigo» que P2 devuelva solo lo compartido **directamente** con el usuario, con
  `includes` resueltos, más vuestro `listObjects` en la partición propia?
- **C5.** ¿Cómo retiráis hoy las tuplas de una organización borrada? El paquete no tiene purga por partición en relaciones, y
  vuestro caso «`purgeScope` de la partición dueña lo retira» supone que sí.

---

## Respuestas a las 5 preguntas de §9 del informe (cada una con su caso con nombre)

1. **¿Literal o sube por `includes`?** Sube, por corte de camino: un deny en `Y` anula todo grant que implique `Y`, con todo
   lo que ese grant deriva. Casos: *«un deny en viewer bloquea al manager»*, *«un deny en editor anula el grant de manager
   entero; solo un viewer directo sobrevive»*, y P1-M *«monotonía en los 64 estados»*. Va con P1, en `2.5.0-alpha`, si
   llega.
2. **¿Comodín `*` solo para deny?** No. Caso P1-17a: *«deny a '*' ⇒ 422 con cero llamadas»*. Con «deny gana», `*` bloquearía
   también al owner, y no es lo que pide el ejemplo.
3. **¿Usersets en `listObjectsForSubject`?** No. Solo holders, con tuplas directas y `includes` resueltos. Casos P2-6
   *«subject = userset ⇒ 422»*, P2-3a *«un objeto compartido con un grupo del que el sujeto es miembro NO aparece»* y P2-2a
   *«incluye el objeto donde el sujeto es editor»*.
4. **¿`meta` en `openfga` o `relationMeta=false` + identificador estable?** Ninguna de las dos. Sin `meta` en el paquete y sin
   cambiar el retorno de `relate`: `relationTupleKey()` pura y determinista. Casos P3-1 *«relationKey es determinista e
   inyectiva»*, P3-2 *«no cambia al renovar la caducidad»* y P3-4 *«reconcile usa relationKey (identidad de función)»*.
5. **Tope y duplicados en P4.** Tope 50 ⇒ 422; duplicados permitidos, con respuesta por posición; `[]` ⇒ 422; un error en
   un ítem ⇒ 503 para todos. Casos P4-5 *«50 responde; 51 ⇒ 422 con cero llamadas»*, P4-4a *«[a, a, b] ⇒ [x, x, y]»* y P4-3
   *«un error en UN ítem ⇒ 503 para todos»*.

---

## Borrador de respuesta a COGNITIV

> **Para:** `api-cognitiv` · **De:** `@jantstack/adonis-authz` · **Re:** 7.º informe (tenencia documental), 2026-10-14
>
> Gracias por un informe que se puede convertir directamente en casos. Hemos pasado las cinco peticiones por el panel
> (arquitectura, seguridad y contrato), con mediciones contra OpenFGA 1.19. Resumen:
>
> **Entra en `2.4.0-alpha.11`** (aditivo, sin cambio del modelo FGA):
> - **P4 `checkMany(subject, relation, objects, partition): Promise<boolean[]>`**. Su semántica es idéntica a N `check`. Tope
>   50 ⇒ 422; duplicados permitidos (respuesta por posición); `[]` ⇒ 422; un error en cualquier ítem ⇒ 503 para todos; F-05
>   por ítem. En `openfga` es un `batchCheck` por cada 50, y en `database` una consulta.
> - **P5**: `createTestClock()` en `/testing` y una sección del README, «Testing expiry from your app». Ojo: el mismo reloj
>   decide el lease del freeze; está escrito.
> - **P3**: **no** guardamos `meta`. En `openfga` serían dos escrituras sin atomicidad posible, y con `capabilities` distintas
>   por driver tendríais que mantener vuestra tabla igualmente. A cambio exportamos `relationTupleKey(subject, relation,
>   object, partition)`, pura y estable al renovar, que es la misma que usa `reconcile`. Dos ortografías del uuid de partición
>   dan dos claves: usad una.
>
> **Entra en `2.4.0-alpha.12`**:
> - **P2 `listObjectsForSubject`**: devuelve solo **holders** (un userset es 422) y tuplas **directas** vivas, con `includes`
>   resueltos, cada objeto con su partición, y con paginación estable por clave natural. Lo que os llega por grupos **no**
>   sale. Para «Compartido conmigo», combinadlo con `listObjects` en vuestra partición. Se declara por `capabilities`; sin
>   soporte, 500 `E_AUTHZ_UNSUPPORTED`, nunca `[]`. El `subject` tiene que salir de la sesión, nunca del cuerpo: el resultado
>   enseña particiones de otros tenants. En `database` hace falta un índice nuevo, con receta de upgrade.
> - Una corrección: el caso *«purgeScope de la partición dueña lo retira»* presupone una purga por partición que en
>   relaciones **no existe** (`scopes.detached` es del motor de roles). Lo fijamos con `purgeObject`.
>
> **P1 (deny en relaciones): aplazado, y queremos vuestra respuesta antes de comprometerlo.** Hemos encontrado tres cosas:
> 1. **P1 + `checkMany` booleano no implementa vuestro «deny gana» a lo largo de la cadena.** Con el grant en `Finanzas` y el
>    deny en `Nóminas`, `checkMany` da `[false, false, true]` y vuestro evaluador concedería por `Finanzas`. Un `false` no
>    distingue «aquí hay un deny» de «aquí no hay nada». Haría falta una primitiva tri-estado.
> 2. **Ni siquiera el tri-estado cubre Nóminas entero.** Un deny a `organizations:<uuid>#member` bloquea también al owner, que
>    es miembro. Y **no** cubre al invitado cross-org, que no es miembro: en Nóminas el motor no dice nada para él y vuestro
>    evaluador heredaría de Finanzas.
> 3. **Lo que pide el ejemplo es romper la herencia**, y la herencia es vuestra. Un `inherits = false` en `tenancy_nodes` hace
>    que Nóminas solo conceda lo que tenga directamente: cubre al owner, al departamento y a los invitados, sin cambiar el
>    paquete.
>
> Si aun así necesitáis deny, la forma prevista es esta (pendiente de confirmar por el mantenedor): opt-in por tipo de
> objeto; **sube por `includes`** con corte de camino (*«un deny en viewer bloquea al manager»*; un deny en `editor` anula
> entero un grant de `manager`, y solo sobrevive un `viewer` directo); misma relación pública, sin nombres nuevos; sin comodín
> `*`; `listSubjects` sigue dando hechos directos y `listObjects` resta. Iría en `2.5.0-alpha` con su suite completa.
>
> Preguntas:
> 1. ¿Os basta `inherits=false` para Nóminas? Si no, ¿qué caso necesita deny que no sea romper la herencia, y cómo excluís al
>    owner y cubrís al invitado de otra organización?
> 2. Si necesitáis deny, ¿tiene que ser temporal o os vale permanente?
> 3. ¿Escribís siempre las particiones con el uuid canónico (minúsculas, con guiones)?
> 4. ¿Os basta P2 con «solo directas + `includes`» para «Compartido conmigo»?
> 5. ¿Cómo retiráis las tuplas de relaciones de una organización borrada?
>
> Cada decisión quedará fijada en la suite común con un caso con nombre, como pedíais.
