# Repaso corto del auditor — cierre 2 de D2 (2026-10-16)

Solo lectura sobre el árbol (sin commit; base `75353fe`). Prohibido: docker restart, gates completos, mutar ficheros del repo. Permitido: SQLite `:memory:`, stores efímeros en OpenFGA `http://localhost:8090`, scripts en `.claude/reproducciones/`.

Lee: `loteD2-cierre2-coordinador.md` (brief), `loteD2-informe-cierre2.md` (informe), `loteD2-auditor-cierre.md` (tu re-ataque anterior: N1–N6).

Comprueba:
1. Cada hallazgo N1–N6 del re-ataque: ¿cerrado de verdad (efecto, no letra)? Reproduce tus reproducciones anteriores contra el árbol actual.
2. N3: el orden de `src/relations/tuple_order.ts` (grafo de precedencias). ¿La fuerza bruta (`tests/helpers/order_bruteforce.ts`) modela fielmente el motor real (database y openfga), o hay semántica que el modelo puro omite (condiciones, wildcard, `parent`, deny por grupo anidado, roles)? ¿El residuo «ciclo» está declarado y es lo único que queda?
3. TOCTOU de N1: un deny que entra mientras se renueva una membresía de un grupo SIN deny. MÍDELO contra openfga real: ¿concede algo que ni el estado inicial ni el final concedían? ¿Ventana explotable, y qué mitigación barata hay (o se declara en README)?
4. Roles: fallo del 2.º write en renovación de grant ⇒ 503 sin marca parcial. ¿Solo letra o hay efecto?
5. Lo nuevo de N4 (streaming, detección de ciclo de `continuation_token`) y N1 (`E_AUTHZ_RENEWAL_UNSAFE`, capacidad `atomicRenewal`): ¿fail-open o regresiones?

Salida: `.claude/contexto/loteD2-auditor-cierre2.md` con veredicto APTA / NO APTA y hallazgos 🔴🟠🟡⚪ con reproducción.
