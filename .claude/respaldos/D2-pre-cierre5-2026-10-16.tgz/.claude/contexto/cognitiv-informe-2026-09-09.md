# Informe de COGNITIV (09-09-2026) — prueba real de cambio de driver (`database` → `openfga`)

Recibido por chat el 2026-09-09, sobre `2.4.0-alpha.3` (`9a107ad`). Resumen fiel:

## Defecto real (confirmado por mí contra el código)
`commands/openfga_provision.ts:33` `startApp: false` + `:46` `this.app.config.get('authorization')` ⇒
`TypeError: Cannot read properties of undefined (reading 'get')`. En Adonis 7 `app.config` solo existe tras
`app.boot()`; el kernel de ace solo hace `boot()`+`start()` con `startApp: true`. Los otros OCHO comandos usan
`startApp: true`. Reproducible al 100 % en cualquier consumidor (falla antes de tocar la red o la base).
Entorno: `@adonisjs/core 7.3.3`, `@adonisjs/application 9.0.1`, Node 24.
Por qué la suite no lo cazó: `relations_provision.spec.ts` juzga los helpers con el config a mano; ningún caso
ejecuta el comando por el kernel de ace.
Propuestas: A) `startApp: true` como los demás (recomiendan A); B) `if (getState()==='initiated') await boot()`
sin `start()`. Caso pedido: ejecutar el comando de verdad (con `:8101` y una variante sin servidor que fije que
`run()` llega a leer el config).
Workaround del consumidor: comando temporal `zz_tmp_openfga_provision.ts` con `startApp: true` (stores dev/tests
creados contra OpenFGA v1.19.0 + Postgres).

## NO defectos del paquete (clasificados correctamente por ellos)
- 296 fallos `E_AUTHZ_UNSUPPORTED` por `{ transaction }` con `openfga` ⇒ conducta documentada (L-5); el consumidor
  pasa `{ transaction }` en 26 sitios de 7 servicios ⇒ su plan T-FGA-1 (receta por dirección).
- 403/200 cruzados en su suite ⇒ su arnés vacía `authz_*` a mano y no el store ⇒ T-FGA-2.
- Nunca llaman a `scopes.attached/moved/detached` ⇒ con `openfga` cada scope nuevo tras el `reconcile` no concede
  (fail-closed documentado) y los borrados no se purgan ⇒ omisión suya.
- `acceptScopeDriftRisk: true` con el árbol movido desde HTTP ⇒ firma mal puesta ⇒ outbox (T-FGA-1 · L2).
- `authz:reconcile --to=openfga` exigía `scopes.enumerateEdges` ⇒ contrato documentado; implementado por ellos
  (`enumerateScopeEdges`, UNION ALL de tres tablas); migración verificada: 448 tuplas, segunda pasada idempotente.

## Dos preguntas
1. Leer `transactionalWrites` en runtime sin `driver()` (API de plataforma): ¿`authorization.capabilities()` /
   `relations.capabilities()` de solo lectura bendecida por el README?
2. `sqlScopeEdges` no cubre un árbol de tres tablas; escribieron el suyo; sugieren mencionarlo en el README.

## Estado
Panel acotado lanzado 2026-09-09 (analista / tester / auditor; sin juez): `panel-alpha4-{analista,tester,auditor}.md`.
