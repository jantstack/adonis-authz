# Backlog para 2.6+ (apuntes del coordinador)

## Evaluar driver SpiceDB (anotado 2026-10-16, a petición del dueño)
- Motivo: OpenFGA no puede renovar la caducidad de una tupla sin ventana (issue abierto https://github.com/openfga/openfga/issues/2151, sin respuesta de mantenedores) ni garantiza que un Check vea una escritura multi-tupla completa (medido en el panel «paquete óptimo», `panel-optimo-analista-renovacion.md`).
- SpiceDB (Authzed, implementación abierta de Zanzibar) declara: caducidad nativa de relaciones (v1.40+), operación TOUCH (upsert atómico), lecturas a instantánea con `fully_consistent`/`at_exact_snapshot`. NADA medido por nosotros; la doc de TOUCH es inconsistente en un punto.
- Encaje: un driver `spicedb` que declare `atomicRenewal: true`. No sustituye a OpenFGA (COGNITIV ya opera OpenFGA).
- Evaluación propuesta: panel con mediciones reales (contenedor SpiceDB), como M5/M6 en OpenFGA: TOUCH con lectores concurrentes, consistencia de lectura, coste de Check/Lookup, operación on-premise.

## Opción B de D2 («make-before-break», ranura `member_alt` + espera G)
- Diseño y mediciones en `panel-optimo-analista-renovacion.md`, riesgos en `panel-optimo-auditor.md`, veredicto en `panel-optimo-juez.md`. Solo si COGNITIV necesita cambiar caducidades de membresías en grupos con deny.

## Otros de 2.6 (juez del panel)
- S1–S9 del analista global (`panel-optimo-analista-global.md`), R4, ranura en roles.

## Issue OpenFGA #2151 (2026-10-16)
- El dueño publicó nuestro comentario (reproducción del fail-open con `but not`) en https://github.com/openfga/openfga/issues/2151. Primer 👍 de hamilton-earthscope (quien pidió en ene-2026 el modo `replace`/`upsert`). Vigilar: si OpenFGA añade upsert, activar `atomicRenewal: true` en el driver openfga.
