# Respuesta a COGNITIV (7.º informe, tenencia) — plan 2.5 aprobado el 2026-10-14

**Para:** `api-cognitiv` · **De:** `@jantstack/adonis-authz` · **Re:** 7.º informe (tenencia), ronda 2, 2026-10-14

Cambiamos de plan: **el deny de relaciones entra en esta línea**, y la próxima estable será **`2.5.0`**. No habrá
`2.4.0` estable: la línea alpha de 2.4 termina en alpha.10 y continúa como `2.5.0-alpha.1`. Calendario previsto:

- **`2.5.0-alpha.1`**:
  - `checkMany(subject, relation, objects, partition): boolean[]` (tope 50, `[]` ⇒ 422, un error en un ítem ⇒ 503
    para todos);
  - `createTestClock()` en `/testing`;
  - `relationTupleKey()` pura y estable, la misma que usa el reconcile.

  **Ojo:** desde esta versión, una partición con el uuid **sin guiones** es 422 en todas las operaciones. Publicamos
  una receta para canonizar las filas existentes; mandadnos el resultado de la consulta de detección (pregunta 3).
- **`2.5.0-alpha.2`**: endurecimiento con rupturas que no pueden esperar a la estable:
  - ciclos de `includes` ⇒ 422 (OpenFGA ya los rechazaba al publicar);
  - claves desconocidas en la spec de relaciones ⇒ 422;
  - un userset que no sea `group#member` ⇒ 422;
  - `listObjects` en `openfga` puede devolver `truncated` por deadline (hemos medido que el servidor corta en silencio,
    y nuestro README decía lo contrario);
  - `sqlScopeOutbox` exige la trx por defecto;
  - `runRelationsReconcile` se mueve a `./relations/reconcile`.
- **`2.5.0-alpha.3`**: deny en relaciones (detalle abajo).
- **`2.5.0-alpha.4`**: `listObjectsForSubject` («Compartido conmigo»), que nace respetando el deny.
- **`2.5.0-rc.1`**: el ensayo sobre el tarball exacto, con plazo cerrado.

**Cómo será el deny:**
- **Opt-in por tipo y en dos fases.** Primero el modelo declara el deny y las lecturas lo honran. Después, en otro
  despliegue, se aceptan escrituras. Así ningún pod viejo ignora un deny ya escrito. Con deny activo, el driver
  `openfga` exigirá `modelId` fijado.
- **Corte de camino.** Un deny en `editor` anula entero un grant de `owner` sobre ese objeto; solo sobrevive un
  `viewer` directo. Un deny en `viewer` lo bloquea todo.
- **Sin caducidad en v1.** Hemos medido en OpenFGA 1.19 que no se puede renovar la caducidad de un deny vivo sin una
  ventana en la que deja de bloquear.
- **Sin comodín `*`; deny sobre `group` ⇒ 422.** `listSubjects` sigue dando hechos; `listObjects` y `membersOf`
  restan.
- **`decideMany(...)`: `allow | deny | none`** por objeto, la primitiva para vuestra cadena. Recorred de la hoja
  hacia arriba y parad en el primer valor que no sea `none`. `deny` significa «no heredéis más allá de este objeto», y
  es más amplio que `check` a propósito. **No uséis `checkMany` para eso**: un `false` no distingue «aquí hay un deny»
  de «aquí no hay nada».
- **Nóminas sigue sin resolverse con deny.** Un deny a `org#member` bloquea al owner y no llega al invitado de otra
  organización. Lo que pide el caso es romper la herencia: `inherits = false` en vuestro evaluador.
- **No hay vuelta atrás a < 2.5 con denies vivos.** Antes de un rollback, el procedimiento documentado los cuenta y
  los retira.

**Preguntas:**
1. ¿Confirmáis `inherits=false` para Nóminas? ¿Para qué casos reales usaríais el deny?
2. ¿Necesitáis un deny temporal?
3. ¿Escribís siempre la partición con el uuid canónico? Ejecutad la consulta de detección y mandadnos el número.
4. ¿Os basta «Compartido conmigo» con «directas + `includes`»? ¿Está en el camino crítico de vuestra F0?
5. ¿Cómo retiráis las tuplas de relación de una organización borrada?
6. ¿Fijáis la versión con `^`? Si es así, os llegará `2.5.0` estable sola, con las rupturas de alpha.2.
7. ¿Fijáis `modelId`? ¿Quién ejecuta `openfga:provision`, desde qué proceso y con qué versión?
8. ¿Qué tipos llevarían deny? ¿Alguna relación de más de 43 caracteres en ellos?
9. ¿Vuestros `onRelationWrite`/`assertWrite` tratan como alta todo lo que no sea `unrelate`? ¿Vuestro
   `authz:cutover:verify` compara tuplas sin `kind`?
10. ¿Usáis usersets que no sean `group#member`, `includes` cíclicos o claves extra en la spec de relaciones?
11. ¿Llamáis a `listObjects` de `openfga` sobre particiones grandes?
12. ¿Qué fechas os vienen bien para el ensayo sobre la RC (7 días)?
13. ¿Os valen la semántica de corte y la de `decideMany` descritas arriba?

Cada decisión quedará fijada en la suite común con un caso con nombre.
