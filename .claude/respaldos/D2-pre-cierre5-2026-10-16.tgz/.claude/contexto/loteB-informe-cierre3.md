# Lote B (plan 2.5) — informe del cierre 3 (último) · 2026-10-15

Brief: `loteB-cierre3-coordinador.md` (🟠 N9 + ⚪ N10–N12 del repaso final `loteB-auditor-cierre2.md`). Árbol: `main` sobre
`beb1d0a` + lote B + cierres 1, 2 y 3, en el working tree SIN commitear. Sin commit, sin `version`, sin push. Método: rojo
observado → verde → mutante por hallazgo. Logs y copia de mutantes en `scratchpad/cierre3/` (`red-n9.log`, `green-n9b.log`,
`n9-tabla.md`, `mut-*.log`, `test-*.log`, `gate-*.log`, `summary.log`).

## 0 · Rojos observados ANTES (casos nuevos sobre el árbol del cierre 2; `scratchpad/cierre3/red-n9.log`: 164 passed, 8 failed / 172)

1. `relations_reconcile.spec` · «🟠 N9 · CON toConfig (capa 1)»: `--dry-run --prune` daba `deleted 2, extra 0, details []` (la fila
   `publisher` en `toDelete`) y la pasada real LANZÓ `422 E_AUTHZ_RELATION_UNKNOWN` después de escribir W y borrar X.
2. `relations_reconcile.spec` · «🟠 N9 · SIN toConfig (capa 2)»: la real LANZÓ el mismo 422 (destino a medias).
3. `relations_reconcile.spec` · «🟠 N9 · doble de terceros»: LANZÓ el primer 422 de la familia; la sobrante buena no se borró.
4. `relations_reconcile.spec` · «🟠 N9 · tabla de verdad»: LANZÓ en la primera fila `undeclared`.
5. `relations_reconcile.spec` · «L-0 · una tupla no declarada que ya estuviera en el destino…» (reescrito): `deleted 1` por el
   driver viejo (la regla era por el driver, no por la fila).
6. `relations_reconcile_cli.spec` · «🟠 N9 · details (undeclared) destino × prune × dryRun»: sin línea propia (`reason` desconocido).
7. `command_flags.spec` · «🟠 N9 · … por el KERNEL»: `run.error` = `RelationUnknownError` — **stack crudo** del comando.
8. `relations_openfga.spec` · «🟠 N9 · relación RETIRADA … en el store» (contra `:8090`): la real LANZÓ con `toConfig` y sin ella.

N10 (`relations_openfga.spec` «⚪ N10»): `MAX_SAFE_INTEGER`, `5 001` y `timeoutMs: 2 999` con el default entraban (rojo observado en
`n10-first.log`); N11/N12 son letra (rojos de `trx_docs` y `relations_events_docs` observados con los mutantes, §4).

## 1 · Qué se hizo, por hallazgo (fichero:línea, caso, mutante, rojo)

### 🟠 N9 · la poda NUNCA lanza por un 422 de la familia de relaciones; la fila de relación/tipo retirado es el tercer motivo `undeclared`
- **Código (plan, capa 1)** `src/relations/reconcile.ts`: `RelationsReconcileDetail.reason` gana `'undeclared'` (`:145-156`, solo
  `destino`); `PartitionPlan.undeclaredResidue` (`:624`); en `planPartition` cada fila del destino pasa, tras identidad (⚪ R2) y
  forma del userset (N2/N3), por **`classifyDestinationRow(toConfig, tuple)`** (`:722-737` + función `:770-789`) = la MISMA
  `assertRelationDeclared` que corre en la primera línea de `unrelate` de los dos drivers; si F-05 la rechaza ⇒ `destResidue`
  (nunca `toDelete`, `:745-747`), `extra` y `details` con `pruned: false` bajo `prune` también en `--dry-run` (`:460-470`).
- **Código (poda, capa 2)** `reconcile.ts:471-500`: el bucle de poda llama a **`unrelateOrClassify`** (`:805-826`), que captura SOLO
  los 422 cuyo `code` está en **`RELATION_422_REASONS`** (`:792-803`: `E_AUTHZ_RELATION_TYPE_UNKNOWN`/`E_AUTHZ_RELATION_UNKNOWN` ⇒
  `undeclared`, `E_AUTHZ_RELATION_USERSET_UNSUPPORTED` ⇒ `userset-unsupported`, `E_AUTHZ_INVALID_IDENTITY` ⇒ `invalid-identity`;
  por `code` + `status === 422`, no por clase: un tercero lanza su clase con el mismo código), lo lista con `pruned: false`, lo
  descuenta de `deleted` y lo suma a `extra`, y SIGUE con las demás filas. Cualquier otro error —otro 422, 503, `Error`— se
  propaga. `#enumerateRows`/`#sweep` NO se filtran por relación (L8).
- **Letra** `commands/authz_relations_reconcile.ts:96-162` (rama `undeclared` en `:152`): tercera rama con el MISMO prefijo estable «`sobra (undeclared)
  destino:`», `error`, «--prune NO la borra»/«tampoco la borraría», receta «retírala a mano (SQL/SDK) o vuelve a declarar la
  relación en el destino (y re-guarda su config persistida)», jamás «repite con --prune», cuenta en `destResidue` (sin consejo).
  El comando ya no ve el 422 (no hay catch nuevo: la pasada no lanza).
- **Casos**: `tests/relations_reconcile.spec.ts` grupo «🟠 N9» (`:803`, 4 casos: CON `toConfig` dry/real/dry2 + sin prune; SIN `toConfig`
  dry/real/again con espía de `unrelate`; doble de terceros con los 4 códigos de la familia + 3 que se propagan; **tabla de verdad
  ejecutada**, 20 filas) + el caso L-0 reescrito (`:582`); `tests/relations_reconcile_cli.spec.ts:188` «🟠 N9 · details (undeclared)»
  (tabla de letra × prune × dry) y `undeclared` en la tabla del consejo; `tests/command_flags.spec.ts:1128` «🟠 N9 · por el KERNEL»
  (`run.error` undefined, exit 1, la línea, la sobrante buena borrada, la nueva escrita); `tests/relations_openfga.spec.ts:325` grupo
  «🟠 N9» contra el servidor (el «❓ en `openfga`» del auditor, medido: `#sweep` filtra por tipo y `unrelate` hace F-05; con y sin
  `toConfig`; la tupla retirada sigue en el store). Corren en los 4 modos (el de `openfga` con `OPENFGA_TEST_URL`).
- **Mutantes** (§4): `N9.sin-captura` ⇒ 5 rojos; `N9.sin-clasificacion-plan` ⇒ 4; `N9.captura-todo` ⇒ 1; `N9.cualquier-422` ⇒ 1;
  `N9.f05-antes-que-forma` ⇒ 1. **Rojo observado**: §0 (1–8).

#### Tabla de verdad de N9 — EJECUTADA (`relations_reconcile.spec` «tabla de verdad», volcada con `AUTHZ_N9_TABLE=1`; `scratchpad/cierre3/n9-tabla.md`)

Destino = doble con la gramática del paquete (identidad por `relationTupleKey`, forma del userset, F-05 con la config sin
`publisher` ni `folder`), una fila buena + la del motivo, `--prune` siempre. bucket = dónde cuenta la fila del motivo.

| motivo | toConfig | pasada | bucket | details | línea | exit |
|---|---|---|---|---|---|---|
| invalid-identity | sí | dry | extra | destino/invalid-identity/pruned:false | sobra (invalid-identity) destino: | 1 |
| invalid-identity | sí | real | extra | destino/invalid-identity/pruned:false | sobra (invalid-identity) destino: | 1 |
| invalid-identity | no | dry | extra | destino/invalid-identity/pruned:false | sobra (invalid-identity) destino: | 1 |
| invalid-identity | no | real | extra | destino/invalid-identity/pruned:false | sobra (invalid-identity) destino: | 1 |
| userset-unsupported | sí | dry | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| userset-unsupported | sí | real | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| userset-unsupported | no | dry | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| userset-unsupported | no | real | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| undeclared(type) | sí | dry | extra | destino/undeclared/pruned:false | sobra (undeclared) destino: | 1 |
| undeclared(type) | sí | real | extra | destino/undeclared/pruned:false | sobra (undeclared) destino: | 1 |
| undeclared(type) | no | dry | deleted | — | — | 1 |
| undeclared(type) | no | real | extra | destino/undeclared/pruned:false | sobra (undeclared) destino: | 1 |
| undeclared(relation) | sí | dry | extra | destino/undeclared/pruned:false | sobra (undeclared) destino: | 1 |
| undeclared(relation) | sí | real | extra | destino/undeclared/pruned:false | sobra (undeclared) destino: | 1 |
| undeclared(relation) | no | dry | deleted | — | — | 1 |
| undeclared(relation) | no | real | extra | destino/undeclared/pruned:false | sobra (undeclared) destino: | 1 |
| userset-unsupported+undeclared(relation) | sí | dry | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| userset-unsupported+undeclared(relation) | sí | real | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| userset-unsupported+undeclared(relation) | no | dry | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |
| userset-unsupported+undeclared(relation) | no | real | extra | destino/userset-unsupported/pruned:false | sobra (userset-unsupported) destino: | 1 |

Lectura: `invalid-identity` y `userset-unsupported` no dependen de `toConfig` (N3/N2, plan); `undeclared` (tipo o relación) lo
clasifica el plan CON `toConfig` y, SIN ella, la captura por código en la pasada real — en `--dry-run` sin `toConfig` cuenta en
`deleted` (**límite declarado**: sin config el plan no puede anticipar F-05, el mismo límite que L-0 declara para `written`; exit
≠ 0 igualmente porque un `--dry-run` que haría algo es deriva). La fila `userset-unsupported+undeclared(relation)` fija que la
FORMA se juzga antes que F-05 también en el destino (N2 extendido). En `database` real (3 motores) y en `openfga` real la misma
forma: casos «CON toConfig», «SIN toConfig» y el grupo de `relations_openfga.spec`.

### ⚪ N10 · `listObjectsDeadlineMs ≤ timeoutMs` del cliente, o 500; la letra nombra el tercer corte
- **Código** `src/drivers/openfga_relations_driver.ts:309-325`: tras la guarda de N1, `deadline > this.#timeoutMs` ⇒ 500
  `E_AUTHZ_CONFIG` con la letra «la señal tiene que poder saltar antes de que el cliente corte» (y «el MENOR de
  `--listObjects-deadline` (si ≠ 0), `--request-timeout` y, por HTTP, `--http-upstream-timeout`»). Mata `Number.MAX_SAFE_INTEGER`
  por construcción sin tope arbitrario. Docblocks de la constante (`:113-127`) y de la opción (`:180-197`) con el tercer corte.
- **Letra** README: párrafo de relaciones (`:682-683`, `:688-699`: «lower of the three … declare that lowest one», la guarda del
  cliente), fila de Limits (`:1299`), §Upgrading 7 (`:1556-1580`, con *Adapt*: un driver con `timeoutMs` < 3 000 declara un
  deadline ≤). CHANGELOG B4 reescrito (`:48-60`: sin `monotonic`, con el significado nuevo). CLAUDE.md fila de relaciones.
- **Caso** `tests/relations_openfga.spec.ts:1735` «⚪ N10» (grupo B4, sin servidor): `MAX_SAFE_INTEGER`, `5 001`, el default con
  `timeoutMs: 2 999`, `3 000/2 999` ⇒ 500 con la letra; `5 000/5 000`, `3 000/3 000`, default, `8 000/10 000` entran; el README
  nombra `--http-upstream-timeout` ≥ 3 veces, «declare that lowest one» y «cannot be lower than `listObjectsDeadlineMs`»; el
  docblock nombra el tercer corte. **Mutante** `N10.sin-guarda` ⇒ 1 rojo. **Rojo observado**: `n10-first.log`.
- **Casos existentes que la guarda puso rojos (línea (c))**: `relations_openfga.spec` «alpha.3 · C4 · servidor MUDO» (`timeoutMs:
  200` con el default 3 000: la señal era inalcanzable ahí; ahora declara `listObjectsDeadlineMs: 200`, `:1443`) y `guard_surface.spec:694`
  `fgaDriver` (`timeoutMs: 1000` ⇒ declara `listObjectsDeadlineMs: 1000`; la sonda de truncación ya pasaba 1 000). Ninguno medía
  la señal del deadline con ese timeout.

### ⚪ N11 · el límite del harness mínimo, escrito
- `src/testing/relations_contract.ts:1184-1189` (comentario junto al caso B3/N4): con `usersetSubjects: false` y
  `enumerateRelations: false` no hay puerto por el que observar la fila inerte; un tercero que guarde y DESPUÉS lance pasa.
- README «Third-party drivers» (`:252`, una frase tras la del deadline); CHANGELOG N4 (cierre 2, `:280`) matizado en su sitio.
- **Caso de letra**: `tests/trx_docs.spec.ts:257` (`has no port through which the runner can see that row`).

### ⚪ N12 · «Closure 2 of lot B» movida a `[Unreleased]`, con hash de la versión publicada
- CHANGELOG: la sección de 88 líneas sale de debajo de la cabecera `[2.5.0-alpha.1]` y queda tras «Closure 1 of lot B» (`:208`);
  «Closure 3 of lot B» detrás de ella (`:302`); la cabecera de alpha.1 queda en `:369` y su bloque exactamente como estaba publicado.
- **Caso** `tests/relations_events_docs.spec.ts:237` «⚪ N12»: los tres `### Closure N of lot B` están ENCIMA de la cabecera de
  alpha.1 (cabeceras ancladas a inicio de línea: un cierre puede citar la versión), el bloque alpha.1 no contiene `### Closure`, y
  su sha1 = `3a0d10aacac1c8be68f082f503a18c44d36c7c75` (una corrección deliberada
  de un bloque publicado actualiza el hash en el mismo commit). **Mutante** `N12.cierres-bajo-alpha1` (devolver las dos secciones
  bajo alpha.1) ⇒ 1 rojo.

### Letra transversal
- README §Upgrading 6 (`:1521-1545`): «One rule for every destination row the API does not admit» pasa a ser VERDAD (nombra `undeclared`, las dos
  capas, los cuatro códigos capturados, el límite de `--dry-run` sin `toConfig` y la historia de N9).
- README párrafo de `authz:relations:reconcile` (`:722`): `undeclared` entre los motivos; «a 422 of the relations family … never
  aborts the pass».
- CHANGELOG N3 (cierre 2, `:268`): la frase «everything in `toDelete` passed the grammar ⇒ a 422 there is the driver contradicting the plan»
  corregida EN SU SITIO como falsa (misma regla que el cierre 2 aplicó al 🟡 8 del cierre 1).
- CLAUDE.md: fila de los drivers de relaciones (N9 + N10).

## 2 · Cuatro líneas de cierre de N9 (punto 5)
- **(a) Gemelos.** `reconcile`↔`relations:reconcile`: el reconcile de ROLES no tiene el defecto —su poda borra tuplas del store por
  `deleteTuples` sin F-05 (no hay `unrelate`), y lo no declarado se gobierna por `OWN_FACTS_OBJECT_TYPES`/`foreign`—; no aplica.
  comando↔función: `runRelationsReconcile` envuelve el mismo primitivo (el caso por el kernel lo fija: sin stack crudo, exit 1).
  `database`↔`openfga`: los dos drivers tienen la MISMA forma (`#enumerateRows`/`#sweep` filtran por tipo, `unrelate` F-05 en la
  primera línea): caso real en cada uno. doble: caso con los cuatro códigos y los tres que se propagan.
- **(b) Tabla de verdad.** Arriba, ejecutada: {4 motivos + la fila de orden} × {toConfig sí/no} × {dry, real} ⇒ bucket, details,
  línea, exit. Entradas discretas: `reason` (dominio cerrado en `RELATION_422_REASONS`), `toConfig` presente, `dryRun`, `prune`
  (siempre `true` en la tabla; sin `prune` la fila es `extra` con `pruned` ausente y «tampoco la borraría», fijado en el caso CON
  `toConfig` y en la tabla de letra de `_cli`).
- **(c) Casos existentes que el arreglo puso rojos.** `relations_reconcile.spec:580` «una tupla no declarada que ya estuviera en
  el destino … (y `deleted` con --prune)»: modelaba «driver con la config vieja + `toConfig` nueva ⇒ `--prune` la borra por el
  driver viejo». Con la regla por la FILA (N3) esa misma fila es `undeclared` (`deleted 0`, `extra 1`, `pruned: false`) y la
  salida es re-declararla (fijado: con `toConfig = sourceConfig` vuelve a ser `unchanged`). Reescrito, no debilitado: afirma más
  (details, el remedio) y conserva «no cuenta como respaldada». Por N10: los dos de la línea (c) de N10.
- **(d) Linaje.** L8 («una operación destructiva lista lo que destruye» / letra ≠ efecto): N9 es la 12.ª iteración y entra por el
  punto de paso único que N3 creó —una regla por FILA del destino, `destResidue` + `details` + prefijo estable— más un segundo
  punto único para lo que el plan no puede ver (`unrelateOrClassify`, tabla cerrada `RELATION_422_REASONS`). No se parchea el
  driver (no se filtra por relación: la fila tiene que LISTARSE) ni el comando (no hay catch nuevo). Entrada en la guardia de
  superficie: no aplica (no es una guarda por operación del puerto sino del plan; el verificador es el caso por el kernel + los
  mutantes de §4). Texto para `linajes.md` (lo administra el coordinador): «L8 · 12.ª (cierre 3 del lote B, N9): la poda nunca
  lanza por un 422 de la familia; `undeclared` es el tercer motivo del punto de paso de N3».

## 3 · Decisiones nuevas del implementador (para ratificar)
1. **La regla de capa 1 es por la FILA aunque el driver pudiera borrarla** (el caso ⚪ 10 del cierre del lote 0 cambia de
   expectativa): con `toConfig` que no declara la relación/tipo, la fila es residuo `undeclared` y `--prune` no la borra ni con un
   driver viejo que la aceptaría. Alternativa descartada: «clasificar solo si el driver la rechaza» = la regla por el driver que
   N3 rechazó, y haría dry ≠ real.
2. **Captura por `code` + `status`, no por `instanceof`** (`RELATION_422_REASONS`): un driver de terceros lanza su propia clase con
   el mismo código (el brief dice «clasifica por `code`»). `relateOrSkip` sigue por `instanceof` (sin cambio: fuera de alcance).
3. **Sin `toConfig`, `--dry-run` cuenta la fila en `deleted`** (límite declarado, igual que L-0 con `written`); el comando siempre
   pasa la config persistida cuando existe, así que en el comando dry = real salvo «no hay config persistida».
4. **La guarda N10 es estricta también con el DEFAULT**: `timeoutMs: 2 999` sin tocar el deadline es 500 (antes la señal era
   inalcanzable en silencio). *Adapt* en README/CHANGELOG. Alternativa descartada (guardar solo el valor explícito): dejaba una
   letra («una llamada lenta señala `truncated`») sin efecto con `timeoutMs` corto.
5. **N12 con hash** del bloque publicado (lo que el brief sugería «si es barato»): es barato y es la única forma de que «no crece»
   sea observable; el coste es actualizar el hash en una corrección deliberada, escrito en el mensaje del caso.

## 4 · Mutantes (copia `scratchpad/cierre3/repo`, `mutants.py`; aplicados uno a uno sobre la copia y restaurados; `diff -rq src` limpio)

| Mutante | Qué cambia | Specs | Resultado | Rojos |
|---|---|---|---|---|
| `N9.sin-captura` | `unrelateOrClassify` relanza siempre (sin captura) | reconcile, command_flags, relations_openfga | **5/161 rojos** | «SIN toConfig (capa 2)», «doble de terceros», «tabla de verdad», «por el KERNEL» (`run.error` = stack crudo), «openfga · relación RETIRADA» (`:8090`) |
| `N9.sin-clasificacion-plan` | `classifyDestinationRow` no se aplica (`undeclared = null`) | reconcile, relations_openfga | **4/110 rojos** | «CON toConfig (capa 1)» (dry `deleted 2`), «L-0 · una tupla no declarada que ya estuviera…», «tabla de verdad» (bucket), «openfga · relación RETIRADA» (dry con toConfig) |
| `N9.captura-todo` | el bucle de poda absorbe CUALQUIER error | reconcile | **1/46 rojo** | «doble de terceros»: `E_AUTHZ_INVALID_SLUG` / 503 / `Error` se TRAGARON |
| `N9.cualquier-422` | cualquier 422 se clasifica (`?? 'undeclared'`) | reconcile | **1/46 rojo** | «doble de terceros»: el 422 `E_AUTHZ_INVALID_SLUG` se tragó |
| `N9.f05-antes-que-forma` | en el destino, F-05 (`classifyDestinationRow`) ANTES que la forma del userset | reconcile | **1/46 rojo** | «tabla de verdad», fila `userset-unsupported+undeclared(relation)|sí` ⇒ `undeclared` en vez de `userset-unsupported` |
| `N10.sin-guarda` | `if (false && deadline > this.#timeoutMs)` | relations_openfga | **1/64 rojo** | «⚪ N10 · listObjectsDeadlineMs > timeoutMs» (`MAX_SAFE_INTEGER` entró) |
| `N12.cierres-bajo-alpha1` | Closure 2 y 3 devueltas bajo la cabecera de alpha.1 | relations_events_docs | **1/15 rojo** | «⚪ N12 · los cierres del lote B están en [Unreleased]» |

## 5 · Cifras (4 modos + 3 gates; en SECUENCIA, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite; `scratchpad/cierre3/summary.log`)

| Modo / gate | Resultado | Log |
|---|---|---|
| `npm run build` | exit 0 (purity + typecheck + tsc + stubs) | `build.log` |
| `npm test` (`:memory:`) | **1734 passed, 2 skipped (1736)** | `test-memory.log` |
| `npm run test:sqlite-file` | **1762 passed, 2 skipped (1764)** — 2.ª corrida, en secuencia (`test-sqlite-file-2.log`); la 1.ª dio 1 rojo en «⚪ N12» por una CARRERA con mi propia edición del hash (la suite cargó el spec con el hash viejo mientras el CHANGELOG ya tenía el texto nuevo: `test-sqlite-file.log`), no por el código | `test-sqlite-file-2.log` |
| `npm run test:pg` (PG 18) | **1859 passed, 1 skipped (1860)** | `test-pg.log` |
| `npm run test:mysql` (MySQL 8.4) | **1861 passed, 1 skipped (1862)** | `test-mysql.log` |
| `npm run check:guard-mutants` | **112 muertos / 112** (0 vivos o sin casar), 106 s | `gate-guard.log` |
| `npm run check:flag-mutants` | **36 muertos / 36**, 0 vivos, 0 exentos, 2 pendientes (`--allow-drop-deny`, `--prune-undeclared`), 55 s | `gate-flags.log` |
| `TEST_DB=sqlite-file npm run cutover-runbook` | **2 passed (2)**, verde | `gate-runbook-sqlite-file.log` |
| `TEST_DB=pg npm run cutover-runbook` | **2 passed (2)**, verde | `gate-runbook-pg.log` |

Cifras finales: **1734 / 1762 / 1859 / 1861** (2/2/1/1 skipped) — +9 / +9 / +9 / +9 sobre la partida (los 8 casos nuevos
de `:memory:` que corren en todos los modos + el grupo N9 de `openfga` que corre con `OPENFGA_TEST_URL` en los cuatro; el
caso L-0 reescrito no suma).

Partida (coordinador, cierre 2): 1725 / 1753 / 1850 / 1852 (2/2/1/1 skipped); guard-mutants 112/112; flag-mutants 36/36; runbook
verde ×2. Casos nuevos: 9 por modo (4 N9 `relations_reconcile` + 1 `_cli` + 1 kernel + 1 N10 + 1 N12 + el grupo N9 de
`relations_openfga`, que corre con `OPENFGA_TEST_URL` en los cuatro); `freeze.spec`, `EXPECTED_FUSED`, `migration_stub.spec` sin tocar.

## 6 · Lo NO hecho y por qué
- `--prune-undeclared` (borrar lo que el destino no declara): lote D / roadmap 2.5; aquí nada borra una fila que la API no admite.
- Filtrar por relación en `#enumerateRows`/`#sweep`: rechazado por el brief (L8: una fila que nadie lista es peor).
- `relateOrSkip` por `code` (paridad con `unrelateOrClassify`): fuera del alcance del cierre; se deja `instanceof` como estaba.
- Un caso de `undeclared` bajo el cutover runbook: el runbook no retira relaciones; el caso por el kernel cubre la rama.
- `linajes.md` / `decisiones-dueno-*.md`: no editados (los administra el coordinador); texto propuesto en §2 (d).
- `check:guard-mutants -- --db sqlite-file`: no corrido (ningún mutante de la guardia cambia; `fgaDriver` solo añade una opción).

## Estado del árbol al cierre

```
$ git status --short
M CHANGELOG.md
 M CLAUDE.md
 M README.md
 M commands/authz_relations_reconcile.ts
 M index.ts
 M package.json
 M providers/authz_provider.ts
 M src/define_config.ts
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_driver.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/manager.ts
 M src/openfga.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/relations/reconcile.ts
 M src/relations_config_store.ts
 M src/scope_outbox.ts
 M src/testing/relations_contract.ts
 M src/testing/scope_outbox_contract.ts
 M src/types.ts
 M tests/command_flags.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/freeze.spec.ts
 M tests/guard_surface.spec.ts
 M tests/helpers/cutover_child.ts
 M tests/helpers/relay_child.ts
 M tests/manager.spec.ts
 M tests/openfga_driver.spec.ts
 M tests/reconcile.spec.ts
 M tests/relations.spec.ts
 M tests/relations_events_docs.spec.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/relations_persisted_config.spec.ts
 M tests/relations_reconcile.spec.ts
 M tests/relations_reconcile_cli.spec.ts
 M tests/scope_depth.spec.ts
 M tests/scope_outbox.spec.ts
 M tests/scope_outbox_contract.spec.ts
 M tests/scope_outbox_harness.spec.ts
 M tests/scope_outbox_multiprocess.spec.ts
 M tests/trx_docs.spec.ts
 M tests/upgrade_recipe.spec.ts
?? src/relations_reconcile.ts
```

```
$ git diff --stat (contra beb1d0a; incluye lote B + cierres 1, 2 y 3)
CHANGELOG.md                             | 366 +++++++++++++++++
 CLAUDE.md                                |  20 +-
 README.md                                | 189 ++++++++-
 commands/authz_relations_reconcile.ts    | 292 +++++--------
 index.ts                                 |   4 +-
 package.json                             |   1 +
 providers/authz_provider.ts              |   5 +-
 src/define_config.ts                     | 133 ++++++
 src/drivers/database_relations_driver.ts |   5 +-
 src/drivers/openfga_driver.ts            |  63 ++-
 src/drivers/openfga_relations_driver.ts  | 212 ++++++++--
 src/errors.ts                            |  38 ++
 src/manager.ts                           |   7 +-
 src/openfga.ts                           |   2 +-
 src/relations/define_relations_config.ts | 246 ++++++++++-
 src/relations/manager.ts                 |   6 +-
 src/relations/reconcile.ts               | 373 ++++++++++++++---
 src/relations_config_store.ts            |  40 +-
 src/scope_outbox.ts                      |  25 +-
 src/testing/relations_contract.ts        |  78 +++-
 src/testing/scope_outbox_contract.ts     | 200 ++++++---
 src/types.ts                             |  10 +-
 tests/command_flags.spec.ts              | 227 ++++++++++-
 tests/fixtures/guard_manifest.ts         |  54 ++-
 tests/fixtures/guard_mutants.json        | 164 +++++++-
 tests/freeze.spec.ts                     |   6 +-
 tests/guard_surface.spec.ts              | 112 ++++-
 tests/helpers/cutover_child.ts           |   4 +-
 tests/helpers/relay_child.ts             |   2 +-
 tests/manager.spec.ts                    | 120 ++++++
 tests/openfga_driver.spec.ts             |  84 ++++
 tests/reconcile.spec.ts                  |  64 ++-
 tests/relations.spec.ts                  | 157 +++++++
 tests/relations_events_docs.spec.ts      |  25 ++
 tests/relations_harness.spec.ts          |   5 +-
 tests/relations_openfga.spec.ts          | 307 +++++++++++++-
 tests/relations_persisted_config.spec.ts |  59 +++
 tests/relations_reconcile.spec.ts        | 676 +++++++++++++++++++++++++++++--
 tests/relations_reconcile_cli.spec.ts    | 161 ++++++--
 tests/scope_depth.spec.ts                |  23 +-
 tests/scope_outbox.spec.ts               | 181 +++++----
 tests/scope_outbox_contract.spec.ts      |  26 +-
 tests/scope_outbox_harness.spec.ts       |  18 +-
 tests/scope_outbox_multiprocess.spec.ts  |   2 +-
 tests/trx_docs.spec.ts                   |   2 +
 tests/upgrade_recipe.spec.ts             |  68 ++++
 46 files changed, 4275 insertions(+), 587 deletions(-)
```
