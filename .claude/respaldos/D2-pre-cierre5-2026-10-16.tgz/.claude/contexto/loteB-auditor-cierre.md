# Lote B (plan 2.5) — re-ataque del auditor sobre el cierre 1 (2026-10-15)

Árbol: `main` sobre `beb1d0a`, con lote B + cierre 1 en el working tree. Para aislar lo que cambió el cierre comparé contra la
copia pre-cierre del auditor-1 (`scratchpad/audB/repo`). Mis repros están en una copia aparte,
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/audB2/repo` (`node_modules` enlazado). Specs propios:
`tests/audb2_residue.spec.ts`, `tests/audb2_shape.spec.ts`, `tests/audb2_store.spec.ts`, más `../lo.py` para OpenFGA.

Qué corrí y qué no:
- Solo SQLite `:memory:` y `npx tsc` sobre la copia.
- Ni `test:pg|mysql`, ni gates, ni `docker restart`.
- Para el 🟡 8 levanté dos contenedores PROPIOS y desechables (`audb2-fga-a/b`, `openfga/openfga:v1.19.0`, datastore `memory`,
  puertos 8104/8105) y los borré al terminar. No toqué `openfga-dev :8090`; contra él solo corrí `run --help` y `version`.
- No modifiqué el repo salvo este fichero. Comprobé con `diff -rq src` que la copia quedó restaurada tras cada mutante.

## Veredicto en una línea

**Cerrado a medias: hay que corregirlo antes de sellar alpha.2.** No hay 🔴. Hay **1 🟠 nuevo**: el `Infinity` que el propio cierre
introduce para `--listObjects-deadline=0` reabre la lista parcial muda que B4 cierra; lo medí contra OpenFGA v1.19.0. Hay además
3 🟡 nuevos o abiertos a medias (el 🟠 2 sobrevive en un subconjunto, una letra contradictoria en la línea de `extra` y el runner
B3 que no ve «escribe y luego 422») y 4 ⚪.

## Tabla: hallazgos del auditor-1 → estado

| # | Estado | Evidencia (ejecutada ✅ / leída 📖) |
|---|---|---|
| 🟠 1 residuo del DESTINO con `--prune` | **Cerrado** (efecto). Letra con un residuo: N3 | ✅ `audb2_residue` A/B/D: `database` real y doble FULL con el residuo inyectado en `enumerate` + `--prune`. Sin throw, `unrelates 0` para el residuo, W escrita, `extra 1`, `details destino/userset-unsupported/pruned:false`, mismos números en dry/real, `clean=false`. Residuo en LOS DOS lados a la vez (A, 4 modos): `skipped.usersetUnsupported 1` + `extra 1` + 2 `details`, exit ≠ 0, sin throw, sin DELETE. |
| 🟠 2 residuo del ORIGEN, dry ≠ real y motivo falso | **Cerrado a medias** → N2 | ✅ Sin `toConfig` y con un `toConfig` que declara el userset: cerrado (C «sin», caso del implementador). ✅ Con un `toConfig` que **no** declara el tipo o la relación del userset: `skipped.undeclared 2`, `details: []`, sin receta y con el consejo falso «decláralos en el destino» (C «conCfg»). Es el mismo síntoma del 🟠 2 en un subconjunto. |
| 🟡 3 letra del 500 de B6 (pool) | **Cerrado** | 📖 `src/scope_outbox.ts:348-350` nombra «pool >= 2» y «pool max 1 … TODO SQLite». README §Upgrading 9 coincide. |
| 🟡 4 `Array.isArray` en `ListObjects` y en las 3 lecturas de roles | **Cerrado** para las ENUMERACIONES. Queda un ⚪: N5 | ✅ Mutante `tuplesOrThrow → []` ⇒ 2/45 rojos. ✅ Mutante `objects ?? []` sin 503 ⇒ 1/8 rojo. 📖 El caso de `purgeScope` afirma 503 y cero `deleteTuples`/`write`. Quedan dos lecturas PUNTUALES que toman `{}` por «ausente» (N5); el grep del caso (`tuples ?? []`) no ve `tuples?.[0]`. |
| 🟡 5 B3 en el runner publicado | **Cerrado a medias** → N4 | ✅ Control: un doble que guarda sin lanzar ⇒ 2/58 rojos. ✅ Mutante «guarda la fila y DESPUÉS lanza el 422» ⇒ **58/58 verdes**: un tercero que deja el residuo pasa el contrato. |
| 🟡 6 punto de paso único + guardia de TIPO | **Cerrado** para lo que promete. Bordes en N7 | ✅ Añadí un campo sin lista blanca en raíz/`openfga`/`scopes`/`hooks`/`relations` y en spec raíz/`objectTypes[i]`/`relations[j]`/`database`: `tsc` da 9/9 TS2741. ✅ `new AuthorizationManager({requireWithing})` ⇒ 500. ✅ `relations.defualt` ⇒ 500. ✅ `openfga: 1`, `hooks: 'x'`, `scopes: null/[]`, `relations: null` ⇒ 500. `buildRelationsManager` da 500 y no 422: es correcto, es el config de ROLES (familia 500, decisión 2). |
| 🟡 7 config persistida que no valida | **Cerrado**. ⚪ residual: N6 | ✅ `[]`, `"texto"`, `{}` ⇒ 422. ✅ `null`, `0`, `false`, `""` ⇒ «ninguna persistida» (la vigilancia se apaga). 📖 Solo `saveRelationsConfig` escribe `authz_relations_config`; `openfga:provision` no (`grep` en `commands/`). |
| 🟡 8 qué hacer con `--listObjects-deadline=0` | **Abierto. El arreglo introduce el 🟠 N1** | ✅ Medido: con `--listObjects-deadline=0` el `--request-timeout` (default 3 s) sigue cortando con un 200 mudo. 📖 Fuente OpenFGA. La letra «no deadline (measured)» es falsa en efecto. |
| ⚪ 9 `monotonic` fuera del tipo | **Cerrado** | 📖 `Symbol(...)` no global y no re-exportado por `/openfga`, `/testing`, `index.ts` ni `commands/*`. `exports` no tiene comodín sobre `src/`. La clave de texto da 500 (caso). |
| ⚪ 10 guardia por fuente de `client.listObjects` | **Cerrado** | 📖 Caso y mutante del implementador. No lo re-ejecuté. |
| ⚪ 11 letra de `purgeObject` | **Cerrado** | 📖 README §Upgrading 6. |
| ⚪ 12 receta SQL ejecutada | **Cerrado** | 📖 El spec extrae el bloque del README y compara byte a byte con `RELATION_USERSET_RESIDUE_SELECT/DELETE`. La línea del comando imprime la misma constante. El detector lista solo los residuos y deja holders `''` y `group#member`. No se ejecuta el holder `NULL`: el esquema ya es `NOT NULL DEFAULT ''`, y `NULL <> ''` es NULL en los tres motores, así que la letra es cierta por semántica SQL. Higiene: el caso hace `DELETE` de toda `authz_relations` al entrar y al salir. |
| ⚪ 13 bordes de B2 | **Cerrado** para lo listado. Más bordes en N7 | ✅ `database: true/null/[]` ⇒ 422. ✅ `includes: 'x'` ⇒ 422. ✅ Config ya definida ⇒ 422 con pista. |
| ⚪ 14 precio en Limits | **Cerrado**, pero la misma fila lleva el consejo `Infinity` de N1 | 📖 README:1285. |

Transversal:
- **Sin debilitamientos.** Contra la copia pre-cierre, los únicos asserts quitados son del caso B3 viejo del reconcile, reescrito
  por la decisión 4 rechazada. El caso B4 de validación de `relations_openfga` se amplió (NaN, símbolo, clave de texto), y la
  tabla B5 de `command_flags` pasa de 3 a 4 filas.
- **Fuera del diff del cierre:** `freeze.spec.ts`, `EXPECTED_FUSED` y `migration_stub.spec`.
- **Guardia de superficie:** la única cara nueva es la de `noObjects`.
- **Specs del cierre que corrí en `:memory:`:** `relations_reconcile` 29/29, `_cli` 10/10, `upgrade_recipe` 5+1 skip,
  `relations_persisted_config` 8/8.
- **¿Quién traga la clase nueva?** `grep` de `RelationUsersetUnsupportedError`/`USERSET_UNSUPPORTED` en `src commands providers
  services`. Solo la captura `classifySubject` (a propósito), y `relateOrSkip` la relanza. El catch de poda (`:433`) solo absorbe
  un 422 de tuplas `invalid`. Ni el manager ni la outbox ni los comandos la capturan. Si un driver raro la lanzara por un holder,
  el comando haría `throw error` y saldría un stack crudo; es aceptable porque no es un dato del store.

## Hallazgos NUEVOS (por severidad)

### 🟠 N1 · `listObjectsDeadlineMs: Infinity` para `--listObjects-deadline=0` produce la lista muda (incluso VACÍA) que B4 existe para impedir
- **Escenario.**
  1. Precondición: un servidor OpenFGA con `--listObjects-deadline=0` y el resto por defecto (`--request-timeout` 3 s, verificado
     en `run --help` de v1.19.0).
  2. El operador sigue el README §Upgrading 7 y la fila Limits y declara `listObjectsDeadlineMs: Infinity`.
  3. Un `ListObjects` que pasa de 3 s lo corta el interceptor de `--request-timeout`. `list_objects.go` elide `DeadlineExceeded` y
     el servidor responde **200 con lo que llevaba**.
  4. El cliente del driver tiene un timeout por defecto de 5 000 ms (`DEFAULT_TIMEOUT_MS`), mayor que 3 s, así que recibe el 200.
  5. Con `Infinity` la señal por deadline no salta nunca.
  6. Resultado: `{ objects: <parcial o []>, truncated: undefined }`, una lista completa MUDA.
  - Con el default del driver (3 000) el mismo servidor sí señala (≥ 2 700 ms ⇒ `truncated`). **El consejo nuevo es estrictamente
    peor que no hacer nada.**
- **Evidencia ✅ medida.** Dos contenedores v1.19.0 con `OPENFGA_LIST_OBJECTS_DEADLINE=0s`, mismo modelo y 40 000 tuplas
  `document#editor@group:gN#member` (`lo.py 40000`), escalando el `--request-timeout` para provocar el corte sin esperar 3 s:
  - `--request-timeout=30ms`: `status 200 objects 0 of 40000` en 45-48 ms, tres repeticiones.
  - Control con `--request-timeout=30s`: `200 objects 40000 of 40000` en 91-113 ms.
  - Arranque con `"ListObjectsDeadline":0`.
- **Evidencia 📖 en la fuente de OpenFGA:**
  - `pkg/server/commands/list_objects.go`: `if q.listObjectsDeadline != 0 { context.WithTimeout }`, y si no, el ctx del llamante.
  - `cmd/run/run.go`: `if config.RequestTimeout > 0 { NewTimeoutInterceptor }`.
  - `pkg/middleware/timeout.go`: `context.WithTimeout` + `return handler(ctx, req)`, sin mirar `ctx.Err()`.
  - La medición del implementador (lista entera en 5 ms) no podía distinguir «sin deadline» de «deadline efectivo = request
    timeout».
- **Letra contra efecto (L8):**
  - README:687-688, §Upgrading 7 (:1527-1529), fila Limits (:1285) y CHANGELOG («🟡 8 / ⚪ 14»): «has no deadline (measured …)
    — declare it with `listObjectsDeadlineMs: Infinity`».
  - El caso `tests/relations_openfga.spec.ts:1626` fija como correcto «con Infinity una hora de llamada no es un corte», que es
    justo el supuesto falso.
- **Steelman del defensor:** «si el operador pone deadline 0, sabe lo que hace; el request-timeout es otra opción del servidor».
  ¿Me convence? **No.** El paquete publica una receta medida para ese servidor exacto, con los demás defaults, y la receta da el
  200 mudo que M8 prohíbe. «Ese servidor no corta» es falso.
- **Qué exige el cierre:**
  - Retirar `Infinity` como receta. El deadline EFECTIVO del servidor es `--listObjects-deadline` si ≠ 0, y si no
    `--request-timeout` (si ≠ 0, default 3 s).
  - Escribir «con `--listObjects-deadline=0` declara tu `--request-timeout`».
  - `Infinity` solo con los dos a 0, y medir qué hace entonces el gateway HTTP (`DefaultContextTimeout`/`--http-upstream-timeout`
    5 s). Intenté medirlo: con upstream de 30-100 ms el gateway ya rompe los `Write` (500 `deadline_exceeded`), así que no pude
    aislar `ListObjects`; queda ❓.
  - Reescribir el caso `:1626` y la letra de las cuatro ubicaciones.
  - Si `Infinity` se mantiene, la letra tiene que decir las DOS condiciones.

### 🟡 N2 · El 🟠 2 sobrevive en un subconjunto: un residuo cuyo userset NO está declarado en `toConfig` vuelve a `skipped.undeclared`, sin `details`, sin receta y con el consejo falso
- **Escenario.**
  1. Origen `database` con filas pre-2.5 `document:D#viewer@folder:F#viewer` (tipo del userset no declarado en la config del
     destino) o `document:D#viewer@document:E#reader` (relación del userset no declarada).
  2. Corre `authz:relations:reconcile`. El comando pasa como `toConfig` la config PERSISTIDA, `commands/…:466`.
  3. `classifySubject` llama a `assertUsersetSubject`, que hace F-05 PRIMERO (`define_relations_config.ts:309-311`).
  4. Resultado: `kind: 'undeclared'`, `skipped.undeclared += 1`, sin `details` y sin `modelDrift`.
  5. La línea dice «su tipo de objeto o su relación no están declarados … decláralos en el destino».
  - Es falso para `document#viewer`, que SÍ están declarados: lo no declarado es la relación del userset.
  - Además es inútil: si el operador lo declara y republica el modelo, la pasada siguiente lo reclasifica como residuo.
  - Sin `toConfig`, la misma fila es `usersetUnsupported` con receta. El bucket depende de si hay config persistida.
- **Evidencia ✅** (`audb2_residue` C, dos residuos):
  - `sin`: `usersetUnsupported 2` + 2 `details`.
  - `conCfg`: `undeclared 2`, `det: []`, línea «decláralos en el destino».
  - `conFolder`: `undeclared 1` + `usersetUnsupported 1`.
  - Dry y real coinciden en los tres casos.
  - La letra lo niega: README §Upgrading 6 «on both sides and **with or without the persisted config**: one enumerated from the
    source counts in `skipped.usersetUnsupported`»; CHANGELOG «a source residue counts in `skipped.usersetUnsupported`».
- **Steelman del defensor:** «es F-05 del par y es cierto que no está declarado». ¿Me convence? **No.** B3 hace la fila inadmisible
  con cualquier config, así que ninguna declaración la vuelve escribible y la forma tiene que dominar. Es la decisión 3 del
  implementador (§6) y la rechazo tal como está.
- **Qué exige el cierre:**
  - En `classifySubject`, `assertSupportedUserset` ANTES de F-05.
  - Un caso con `toConfig` que no declara el userset.
  - El destino ya hace solo forma: queda simétrico.

### 🟡 N3 · Con un residuo en el destino, la pasada REAL imprime «no pasaste --prune: repite con --prune» aunque se pasó `--prune` y aunque `--prune` no lo borra
- **Escenario.** Destino con residuo; `authz:relations:reconcile --prune` real; es la vuelta del runbook, y el caso del kernel del
  propio cierre la reproduce. `report.extra` incluye `destUsersetResidue` (`reconcile.ts:446`). `relationsReconcileLines`
  (`commands/…`, bloque `if (report.extra > 0 && !report.dryRun)`) no sabe si hubo `prune` y añade:
  > `warning 1 tupla(s) del destino que el origen ya no respalda siguen ahí (no pasaste --prune): repite con --prune si quieres borrarlas.`

  Esa línea va justo debajo de la línea de error «--prune NO lo borra». Sin `--prune` el consejo también es falso, porque
  `--prune` tampoco lo quitaría.
- **Evidencia ✅** (`audb2_residue` B y A, real con y sin prune; las dos líneas salen juntas). La fila «destino con prune, real» de
  `relations_reconcile_cli.spec` no lo mira. El defecto ya existía con `invalid-identity` rechazada (`refused`), pero el cierre lo
  vuelve el caso NORMAL de la vuelta.
- **Steelman del defensor:** «es un warning; la línea de error y el exit son correctos». ¿Me convence? **No del todo.** El punto 7
  de CLAUDE.md pide que la salida diga qué rama corrió, y aquí dos líneas se contradicen. Mantengo 🟡, no 🟠.
- **Qué exige el cierre:**
  - El warning solo cuenta `extra − residuo − refused`, o el reporte lleva `prune`.
  - Caso de letra: `notMatch(/no pasaste --prune/)` en las filas con residuo y con `prune`.

### 🟡 N4 · El runner B3 no ve a un tercero que GUARDA la fila y luego lanza el 422 (🟡 5 cerrado a medias)
- **Escenario.** Un driver de terceros valida DESPUÉS de escribir: `relate` inserta y luego lanza 422
  `E_AUTHZ_RELATION_USERSET_UNSUPPORTED`. El runner, por el driver directo, solo exige el 422 y nunca comprueba que no quedó
  nada. El residuo existe y el contrato sale verde.
- **Evidencia ✅.** Mutante sobre el doble publicado (`src/testing/relations_contract.ts`, `relate`: `assertSubjectDeclared`
  movido detrás de `tuples.push`) ⇒ `relations_contract.spec` **58/58 verde**. Control (guarda sin lanzar) ⇒ 2/58 rojos.
  - La decisión 8 del implementador («el runner no ve el backend de un tercero») es falsa: lo ve por el puerto. `listSubjects`
    devuelve usersets y `enumerateRelations` existe con la capacidad.
  - README §Upgrading 2 y CHANGELOG («A third-party driver that stored the inert row passed the whole contract until now»)
    prometen más de lo que el runner juzga.
- **Steelman del defensor:** «D13 tampoco mira el backend». ¿Me convence? **No.** Aquí el objeto del hallazgo era precisamente
  «un tercero que guarde la fila inerte», y la lectura por el puerto es barata.
- **Qué exige el cierre:**
  - Tras los intentos por el driver directo: `listSubjects('viewer', doc, S)` no contiene `document:<other>#viewer`, y con
    `enumerateRelations` la partición sigue vacía.
  - El mutante «escribe y luego lanza» en la lista de mutantes del cierre.

### ⚪ N5 · Dos lecturas PUNTUALES siguen tomando un 200 sin `tuples` por «ausente»
- `src/drivers/openfga_driver.ts:1221` `readAssignment` (`response.tuples?.[0]` ⇒ `absent`) y
  `src/drivers/openfga_relations_driver.ts:518` `#readTuple` (`response.tuples ?? []`). El grep del caso del cierre
  (`/tuples \?\? \[\]/` solo en el driver de roles) no ve ninguna de las dos.
- 📖 Efecto por razonamiento, ❓ no medido en servidor.
  - `grant`/`relate` creen que no hay tupla y escriben.
  - Si existía con otra condición (caducidad), FGA rechaza el duplicado: bucle de relectura y 409, no una extensión silenciosa.
  - Si existía idéntica, el `IGNORE_DUPLICATE_WRITES` de la 2.ª vuelta devuelve `existed: false` y el evento sale como «creado»
    en vez de no-op.
- No es fail-open. Sube a 🟡 si alguien demuestra que FGA ignora un duplicado con distinta condición.
- **Qué exige el cierre:** el mismo `Array.isArray` en esas dos lecturas, o una línea de límite en el informe. El grep del caso
  debería ser `tuples\s*(\?\?|\?\.\[)`.

### ⚪ N6 · Una fila persistida `null`/`0`/`false`/`""` se lee como «ninguna persistida» y apaga la vigilancia en silencio
- ✅ `audb2_store`: las cuatro ⇒ `readRelationsConfig() === null`, rama «la deriva del modelo NO se vigila», y la pasada sigue.
  Solo se llega con SQL a mano: `saveRelationsConfig` valida antes.
- **Qué exige el cierre:** en `readRelationsConfigSpec`, `JSON.parse` que no da un objeto ⇒ 422 de la rama «NO valida». Solo la
  ausencia de fila (o de `spec`) es `null`.

### ⚪ N7 · L5 fuera de los cuatro bloques
- ✅ Relaciones: `holderTypes: 'user'` (cadena) ENTRA, y como se itera por caracteres DESACTIVA la colisión ⚪4. `objectTypes`
  con `{type:'user'}` + `holderTypes:'user'` entra; con `['user']` es 422. Solo es alcanzable por JS o por una fila persistida.
- ✅ Roles: entran `holderTypes: 'users'` y `drivers: 1` (fallan después, al resolver o en el driver openfga), las erratas dentro
  de `catalogs[i]` y una clave heredada por prototipo.
- Ninguna concede nada. Son la «propiedad universal» de L5 a medias.
- **Qué exige el cierre:** `Array.isArray(holderTypes)` en la spec de relaciones (422). Para roles basta una línea de límite.

### ⚪ N8 · Letra de R-17 cuando el origen solo aporta residuo
- ✅ `audb2_residue` E: con `toConfig` el 500 dice «(1 leídas, **todas de tipos que el destino no declara**)», y es falso porque
  son residuo B3. Sin `toConfig` dice «(1 leídas)» sin nombrar el residuo. El seguro hace lo correcto.
- **Qué exige el cierre:** que el desglose cuente `usersetUnsupported` e `invalid` por su nombre.

## Decisiones §6 del cierre

| # | Decisión | Veredicto | Por qué |
|---|---|---|---|
| 1 | `skipped.usersetUnsupported`; el residuo del DESTINO es deriva también SIN `--prune` | **Ratificar, con condición** | Correcto: ninguna bandera lo arregla. Pero choca con «una regla, no dos». Un `invalid-identity` del destino tampoco lo borra ningún driver del paquete (la propia línea de dry-run lo dice) y aun así sin `--prune` es solo warning, exit 0 en real, con el consejo «repite con --prune». Que el dueño decida si `invalid-identity` sin `--prune` pasa a deriva igual; si no, que se escriba por qué difieren. La letra de la línea `extra` (N3) va en este cierre. |
| 2 | `pruned: false` desde el plan, también en `--dry-run` | **Ratificar** | ✅ A/B/D: coherente dry/real y cero `unrelate` por el residuo. |
| 3 | Con `toConfig`, un userset de tipo/relación no declarados ⇒ `skipped.undeclared` | **Rechazar tal como está** | Es N2: el orden F-05 → forma reabre el motivo falso. Forma primero. Sin `toConfig` ya da `usersetUnsupported`, que es lo correcto. |
| 4 | 🟡 7 con exit 1 y línea propia; `openfga:provision` fuera de la receta | **Condicionar (exit) / Ratificar (provision)** | No se distingue por el REPORTE: la rama devuelve antes de que exista uno, así que un CI solo puede separarla parseando el texto. Todas las ramas fallidas del comando salen con 1. Vale si el coordinador escribe en CLAUDE.md punto 7 que «exit propio» = «≠ 0 con línea propia» (es como funciona todo el paquete). `provision`: 📖 no llama a `saveRelationsConfig` (solo lo hace `relations_config_store.ts:52`); ratificado. |
| 5 | 🟡 3 solo letra | **Ratificar** | La doctrina «el paquete no adivina el pool» se sostiene, y el 503 nace en la barrera. |
| 6 | ⚪ 9 por símbolo; la clave de texto da 500 | **Ratificar** | No se alcanza por ningún subpath publicado; símbolo no registrado. |
| 7 | Roles 🟡 4 sin entrada en la guardia (grep + caso) | **Ratificar, con N5** | El grep es más estrecho de lo que el informe dice cubrir (`?.[0]`). |
| 8 | El runner B3 afirma «cero llamadas» solo por el manager; por el driver directo, solo el 422 | **Rechazar la premisa** | Es N4: «el runner no ve el backend» es falso, porque `listSubjects`/`enumerateRelations` lo ven. |

## Lo que intenté y NO se rompió

- **Residuo:**
  - En los dos lados a la vez, × prune × dry-run: sin throw, sin DELETE, números estables.
  - Doble FULL como destino con residuo inyectado: cero `unrelate`.
  - Residuo caducado en el destino: listado. En el origen: `expired`, que no es deriva.
  - R-17 con un origen que solo aporta residuo: se niega, que es lo correcto.
  - Tupla a la vez `invalid-identity` y residuo con `--prune`: el catch de `invalid` absorbe cualquier 422.
- **Receta SQL:** coincide byte a byte con la línea del comando y con el README. El detector y el DELETE seleccionan exactamente lo
  que `classifySubject` llama residuo; el driver mapea `subject_relation` ≠ `''` a userset.
- **Guardia de tipo:** 9/9 rojos en `tsc` al añadir un campo sin lista blanca en cada nivel.
- **Forma del config en runtime:** constructor del manager y `buildRelationsManager` dan 500 por errata y por bloque no-objeto.
- **🟡 4:** mutantes de `tuplesOrThrow` y de `objects` muertos.
- **⚪ 9:** `MONOTONIC_CLOCK` no alcanzable desde `exports`.
- **🟡 7:** las tres variantes no-objeto de la fila persistida (`[]`, `"texto"`, `{}`) ⇒ 422.
- **Transversal:**
  - Sin `skip` ni asserts quitados para pasar.
  - `freeze.spec`, `EXPECTED_FUSED` y `migration_stub` fuera del diff del cierre.
  - La clase nueva no la traga nadie fuera de `classifySubject`.

## Preguntas abiertas que cambian el veredicto

1. Para N1: ¿se retira `Infinity`, o se mantiene exigiendo `--request-timeout=0`? En el segundo caso, alguien tiene que medir qué
   hace el gateway HTTP (5 s) con `ListObjects` antes de publicarlo como «sin deadline».

Fuentes externas usadas (N1):
- [list_objects.go v1.19.0](https://raw.githubusercontent.com/openfga/openfga/v1.19.0/pkg/server/commands/list_objects.go)
- [config.go v1.10.0](https://raw.githubusercontent.com/openfga/openfga/v1.10.0/pkg/server/config/config.go)
- [run.go v1.10.0](https://raw.githubusercontent.com/openfga/openfga/v1.10.0/cmd/run/run.go)
- [timeout.go v1.10.0](https://raw.githubusercontent.com/openfga/openfga/v1.10.0/pkg/middleware/timeout.go)
- [OpenFGA configuration](https://openfga.dev/docs/getting-started/setup-openfga/configuration)
- Comprobación en `run --help` de v1.19.0: `--request-timeout … (default 3s)`.
