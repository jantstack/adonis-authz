# Fase 6 — informe (parte DOCS + `configure`)

> Alcance ejecutado: README consolidado y honesto, guía de upgrade 1.x → 2.x, CHANGELOG
> consolidado y `configure` interactivo. **NO** se movió ningún fichero de `src/` a carpetas de
> módulo ni se separaron las migraciones por módulo (el reorg diferido, decisión del dueño).
> Trabajo sobre el árbol principal, sin commits.

## Cifras (base 994 / 999 / 1093 / 1093 — se mantienen)

| Suite | Resultado |
|---|---|
| `npm test` (sqlite memoria, con OpenFGA) | **994** passed |
| `npm run test:sqlite-file` | **999** passed |
| `npm run test:pg` (con OpenFGA) | **1093** passed |
| `npm run test:mysql` | **1093** passed |

`typecheck`, `check:purity` y `build` en verde. `configure.spec` (compila los dos stubs de config)
sigue verde dentro de la suite sqlite. `upgrade_recipe.spec` corrido aislado en PG: **1 passed**
contra el README editado (confirma que la receta SQL se sigue encontrando y ejecutando tras
promoverla a su propia sección).

## Hallazgo principal sobre el README viejo: no había MENTIRAS, había un HUECO

Rastreé las afirmaciones que el brief marcaba como sospechosas y **todas estaban ya corregidas** en
fases anteriores — no eran mentiras del código actual:

- `openfga:import`: el README ya lo daba por **eliminado** ("**`openfga:import` is gone (2.3,
  breaking).**", línea ~665). Correcto contra el código (no existe el comando).
- modo `hierarchy: 'resolver'`: el README ya lo presentaba como **retirado** ("The option is gone;
  passing it is a TypeScript error", "**2.3 removes it**"). Correcto contra `CLAUDE.md` (3b-2k: "ese
  modo ya no existe") y el código.
- techo `≈691 permisos`: ya **corregido a ~450** con nombres realistas (línea ~759), con la tabla
  medida. Correcto.
- `appAccess({ role })`: ya documentado como **500 con receta**. Correcto.

Lo que SÍ faltaba (y es el hallazgo): **el middleware `resourceAccess` de la Fase 5 no estaba
documentado en ningún sitio del README**, aunque `configure.ts` lo registra como middleware con
nombre. Un doc que omite una superficie pública publicada es tan defecto como uno que promete de más.
Añadida sección **"Per-resource enforcement: `resourceAccess` (2.5)"** (tras "Enforcing in routes"),
verificada línea a línea contra `src/middleware/resource_access_middleware.ts`: el orden
401 → 403 gate → 404 contenedor → 404 recurso → `authorize` (mismo cuerpo en los tres 404), `role`
prohibido (500 `E_AUTHZ_ROLE_IS_NOT_ACCESS`), `AuthorizationBackendError` (503) nunca disfrazado, un
solo `authorize`, y **el canal de temporización** como límite conocido (el 404 de "no existe" no
hace round-trip a `authorize`; el de "ajeno" sí — inherente a `load → authorize`, se cierra en la
capa del consumidor con un delay constante).

## Límites medidos consolidados (todos verificados contra el código)

- **Techo del modelo `facts` en bytes → ~450 permisos** con nombres realistas: ya estaba; lo dejé.
- **Profundidad de cadena en `facts` = 22** (`FACTS_MAX_RESOLVE_DEPTH`, `src/drivers/openfga_facts.ts`):
  NO estaba en el README. Añadido `#### The scope-chain depth ceiling (facts)`: 22 saltos `parent`
  resuelven SIEMPRE (medido con `--resolve-node-limit` 25, 500 resoluciones/lado; a 23 falla entre
  4 % y 26 %, a 24 siempre); pasado el techo el servidor da 400 y el paquete propaga **503, nunca
  `false`** (invariante 5); `database` no tiene ese techo — el mismo árbol es legal en un driver y
  503 en el otro. Fiel al comentario de la constante.
- **Partición obligatoria** en relaciones y **`membersOf` solo en `database`**: ya estaban en la
  sección Relations (ReBAC) — verificados, sin cambios.
- **Canal de temporización de `resourceAccess`**: añadido con la sección nueva (arriba).

## Guía de upgrade 1.x → 2.x vs lo que ejecuta `upgrade_recipe.spec`

La receta SQL del README es lo que `tests/upgrade_recipe.spec.ts` **ejecuta literalmente** (parsea el
primer bloque ` ```sql ` que empieza por `-- PostgreSQL` / `-- MySQL`, lo aplica sobre un esquema
1.1.0 y compara el resultado columna a columna con la migración publicada, corriendo el motor 2.x
encima). Ya coincidían (el test pasaba en base). Mi trabajo fue de **descubribilidad y contexto**,
sin tocar una sola sentencia SQL:

- La receta vivía enterrada dentro de `### Operational notes for the SQL engines`. La **promoví** a
  una sección de primer nivel **`## Upgrading from 1.x to 2.x`** (antes de `## Compatibility`),
  insertando la cabecera y el contexto JUSTO antes del párrafo "Upgrading a 1.x installation…", de
  modo que ese párrafo + los dos bloques ` ```sql ` quedan bajo la sección nueva **sin moverse de
  fichero** (los marcadores y las sentencias son byte-idénticos; el test los sigue encontrando —
  confirmado ejecutándolo).
- Añadí el **salto de esquema** explícito: `authz_catalog_version` (versión compartida id=1 +
  congelación durable id=2), `authz_roles.owner_scope_key` + unique `(slug, scope_type,
  owner_scope_key)`, `authz_permissions.assignable_at`, `authz_relations`/`authz_relations_config`
  (tablas nuevas: se obtienen de la migración forward, NO de la receta ALTER), identidad
  `varchar(64)` `utf8mb4_bin` (no `uuid`) y `expires_at` `DATETIME(3)`, y `authz_scope_outbox` como
  **opt-in** (lo publica `configure` bajo pregunta, o se copia el stub).
- Añadí que **2.x NO lee los ids 1.x**: un store OpenFGA de 1.x/2.0–2.1 llevaba el **slug** en el id
  del binding y las formas del modo `resolver`; 2.2+ lleva el **uuid** y el modelo `facts` no declara
  esas formas, así que esas tuplas no conceden. La migración es **`authz:reconcile --to=openfga
  --from=database --prune`**, NO un comando aparte, y NO hay `openfga:import`.

Regla aplicada: si texto y test divergieran, gana el test. No divergían; el test sigue verde.

## CHANGELOG consolidado

Añadida una **entrada de cabecera ARRIBA** (`## [Unreleased] — the 2.x release (summary)`), sin
borrar ninguna entrada por lote. Es la guía de lectura del salto 1.1.0 → 2.x para quien no siguió los
lotes, en inglés:

- **Qué es**: 2.x es un único release breaking sobre 1.x, sin flags de compatibilidad.
- **Las fases**: seguridad + `scopes.*` (2.0), primitivas (2.1), roles por scope `catalog/` (2.2),
  `openfga` = `facts` + `reconcile` (2.3), `relations/` ReBAC (2.4), `http/` `resourceAccess` (2.5).
- **BREAKING agrupados**: sin fallback plano de scope, `appAccess({ role })` retirado, identidad
  validada en todas partes, semántica de `expiresAt`, scope que no alcanza raíz no concede
  (`facts`), driver `openfga` reformado (`resolver`/`import` fuera, ids por uuid, gate de outbox),
  identidad de rol por uuid, y el salto de esquema.
- **Diferido a 2.6**: `{ trx }` + `onWriteInTrx`, `from` en `relations/`, caducidad de relación
  (R-15), y —añadido explícitamente— el reorg de ficheros por módulo, migraciones por módulo y los
  modelos Lucid de solo lectura.

Apunta a la sección `#upgrading-from-1x-to-2x` del README.

## `configure` interactivo

`configure.ts` ahora pregunta **lo mínimo que cambia lo publicado**, con `command.prompt`:

1. **Driver por defecto** (`command.prompt.choice`, `database` | `openfga`, default `database`) → fija
   el default de `AUTHZ_DRIVER` en `defineEnvVariables`. Si se elige `openfga`, avisa de instalar
   `@openfga/sdk` y aprovisionar el store.
2. **¿Publicar la migración de la outbox del árbol?** (`command.prompt.confirm`, default `false`) →
   si sí, publica `stubs/scopes_outbox_migration.stub` (tabla `authz_scope_outbox`) y recuerda
   registrar `sqlScopeOutbox()` en el config. Es opt-in real: hoy había que copiar el stub a mano.

**Lo que decidí NO preguntar y por qué** (el brief lo pide explícito): las **relaciones (Fase 4) no
se preguntan** — sus tablas ya están en la migración del motor y su config es `defineRelationsConfig`
en el propio proyecto; un prompt ahí no publicaría nada distinto. Y el **driver elegido no ramifica
el stub**: los dos configs se publican siempre con las dos costuras cableadas (el stub arranca en
cualquier driver leyendo `AUTHZ_DRIVER`), la elección solo fija el default de la env. Esto es
deliberado: **`configure.spec` compila EXACTAMENTE los mismos dos stubs** (los lee del disco, no
ejecuta `configure.ts`), así que sigue verde; un `configure` que ramificara el stub y rompiera el
arranque sería peor que uno fijo.

Balance honesto: sobre el `configure` fijo anterior, el interactivo aporta dos cosas concretas y
seguras (default de driver correcto de entrada + outbox publicable sin copiar a mano). No es un
salto grande porque el stub, por diseño, tiene que valer para los dos drivers; ese es el motivo de
que no haya más prompts.

## Diferido (fuera de esta fase, por decisión del dueño / brief)

- **Reorg de ficheros** de `src/` a carpetas de módulo (`roles/`, `relations/`, `catalog/`, `http/`)
  sin mover el export raíz: cosmético y de alto riesgo justo antes del release.
- **Separación de migraciones por módulo**: tocaría el stub que `migration_stub.spec` fija (ocho
  tablas en una migración); es parte del reorg diferido.
- (Ya en el CHANGELOG) `{ trx }` + `onWriteInTrx`, `from` en `relations/`, caducidad de relación
  R-15, modelos Lucid de solo lectura → 2.6+.

## Nota sobre la versión (para el dueño)

`package.json` sigue en `2.0.0-alpha.1` y el CHANGELOG apila entradas `[Unreleased]` (2.4 → 2.0): todo
el 2.x está sin publicar. No toqué la versión (es decisión de release del dueño). El resumen del
CHANGELOG y el README hablan de "2.x" para no clavar un número que el dueño aún no ha estampado;
cuando se libere, basta renombrar la cabecera resumen a la versión final (el roadmap apunta 2.5).
