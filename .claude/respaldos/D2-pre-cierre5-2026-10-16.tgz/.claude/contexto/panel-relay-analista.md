# Panel relay/outbox — analista (2026-09-09)

Entrada: `.claude/contexto/cognitiv-informe-2026-09-09b.md` (4 observaciones + 1 pregunta), sobre
`2.4.0-alpha.4` (`5547fa4`, árbol limpio). Todo lo que sigue está **leído en el código** o **medido**
contra los servidores reales de esta máquina. Nada recitado.

**Banco de pruebas.** PostgreSQL 18 (docker `postgres18`, base efímera `authz_test_*` del harness),
OpenFGA **v1.19.0** con datastore postgres en `http://localhost:8101` (`api-loco-base-openfga-1`),
modelo `facts` publicado por `openFgaFactsModel`, driver y manager REALES del árbol (no dobles),
outbox = `sqlScopeOutbox()` sobre la tabla del stub. Scripts en el scratchpad
(`bench_relay.mjs`, `bench_attempts.mjs`, `bench_enumerate.mjs`, `bench_enum2.mjs`, `bench_dep.mjs`).

---

## Números de cabecera (los que deciden todo lo demás)

| medida | valor |
|---|---|
| Pasada de relay con backlog ajeno (500 de otro tenant + 1 propia), **sin filtro** | **4 507 ms**, 501 aplicadas, **2 004 llamadas a FGA** (4/entrada), 9,0 ms/entrada |
| La MISMA pasada con `only=[mi id]` (filtro en SQL) | **19 ms**, 1 aplicada, 4 llamadas a FGA |
| Pasada VACÍA (suelo que paga cada petición con relay inline) | **4,3 ms**, 0 llamadas a FGA |
| Pasada de 1 entrada (el caso «crear un tenant») | **p50 13,3 ms · p95 17,0 ms** ← eso es lo que dura el lease |
| `acquire()` + `release()` | p50 **0,56 ms** |
| Store caído (connection refused), 1 entrada | **APARCADA tras 6 pasadas** (5 fallos); cada pasada fallida cuesta 2-15 ms |
| `enumerateRelations` de una partición de **5 000** tuplas (store de 15 000) | 549 ms, **151 páginas** `Read` |
| `enumerateRelations` de una partición de **10** tuplas (mismo store) | 456 ms, **151 páginas** `Read` ← O(store), no O(partición) |
| `Read` por id EXACTO | p50 **1,50 ms** |
| `pending(100)` sin filtro / con `whereIn(id)` sobre backlog de 501 | 0,89 ms / **0,20 ms** |
| Sonda «¿hay algo ANTERIOR pendiente que toque mis scopes?» | **0,69 ms** |
| Sonda «¿hay algo POSTERIOR ya aplicado que toque mis scopes?» (para `requeue`) | **0,33 ms** |

Lectura de una frase: **las cuatro observaciones son exactas, y las cuatro se arreglan sin tocar el
esquema de `authz_scope_outbox` ni romper a un tercero.** Lo caro no es el lease ni la outbox: es que
la pasada del relay **no se puede acotar a lo tuyo**, y eso es el punto 1 — que además disuelve el 5.

---

## 1. Resultado por entrada y filtro

### Lo verificado en el código

- ✅ `ScopeOutbox.enqueue(change, context): Promise<void>` (`src/types.ts:1142`) — sin id, exacto.
- ✅ `scopes.attached`/`moved` encolan **una** fila (`src/manager.ts:845, 875`); **`scopes.detached`
  encola UNA POR ORTOGRAFÍA** (`scopeSpellings`, `src/manager.ts:~930`): con la fila del consumidor
  ya borrada son **dos**. Cualquier «recibo» del encolado es por tanto **plural**, no `{ id }`.
- ✅ El reporte YA es por entrada con ids (`applied`/`deferred`/`failures`/`dead` son
  `RelayedScopeChange[]`, `src/types.ts:1053-1090`). Lo que falta **no es el resultado por entrada:
  es el enlace entre «lo que encolé» y «esos ids»**. La petición de COGNITIV, bien leída, es más
  pequeña de lo que parece.
- ✅ `pending(limit, after)` no tiene filtro; `remaining` se calcula con `pending(1)` global
  (`src/manager.ts:1141`) y `dead` con `dead(batchSize)` global (`#deadLetters`).

### Forma mínima propuesta

**(a) Recibo del encolado.**
`enqueue(...): Promise<void | { id: string | number }>` en el puerto. En TypeScript
`Promise<void>` **es asignable** a `Promise<void | {id}>` (covarianza del genérico): un tercero que
siga devolviendo `void` **compila y funciona**. → **no breaking**.
`scopes.attached/moved/detached` pasan a devolver `Promise<ScopeEnqueueReceipt>` con
`{ queued: Array<string|number> }` (plural, por el `detached` de dos ortografías). Sin outbox
—escritura en línea— el recibo es `{ queued: [] }` y el docblock lo dice: «vacío = ya está aplicado,
no hay nada que relevar». Un tercero sin id deja `queued: []` también, y entonces `only` no se puede
usar con esa outbox: el manager lo dice con 500 nombrando el puerto, **jamás relevando la cola entera
en silencio**.

**(b) `relayScopeChanges({ only })`.**
`only?: Array<string | number>` (ids). `only: []` = **no hacer nada** (nunca «sin filtro»: ese es el
footgun clásico y hay que fijarlo con un caso).
El puerto: tercer parámetro **opcional** de `pending(limit, after, filter?)` con
`filter?: { ids: Array<string|number> }`. Un tercero que lo IGNORE devolvería entradas que no se
pidieron — fail-dangerous silencioso (te aplica el backlog ajeno dentro de tu petición) — así que el
manager **lo detecta y para**, exactamente con la voz que ya usa para el `markApplied` no honrado
(`src/manager.ts:1084`): si un id devuelto ∉ `only` ⇒ 500 `E_AUTHZ_CONFIG` «tu ScopeOutbox no honra
`only`». Detección exacta, coste cero, mismo patrón de la casa. **No breaking**.

**(c) Cómo se compone con el orden por clave de scope y el aplazamiento transitivo.**
Ésta es la pregunta de verdad, y la respuesta es **aplazar, no 422 y no arrastrar la dependencia**:

- Antes de aplicar una entrada de `only`, una sonda: *¿existe alguna entrada PENDIENTE con `id` menor
  que toque alguna de mis claves de scope (`#changeKeys`: hijo, y padre si no es `detached`)?*
  Si la hay ⇒ **`deferred`** con causa explícita («hay un cambio anterior sin aplicar que toca
  `organization|…`; corre el relay completo»). Coste medido: **0,69 ms** sobre 501 pendientes, con el
  índice que ya existe (`applied_at, id`). Sin columna nueva, **sin migración**.
- **Arrastrar la dependencia** («aplica también lo que necesito») es transitivo por construcción y
  puede acabar siendo la cola entera: destruye la razón de ser de `only`. Descartado.
- **422** es desproporcionado: la pregunta no está mal formada, y el consumidor no puede hacer nada
  dentro de esa petición. Además el comportamiento resultante ya está documentado y es fail-CLOSED
  (el scope recién creado no concede hasta que pase el relay). Lo correcto es **decirlo en el reporte**
  y que el README de la receta inline diga la frase: *«si `deferred` no está vacío, tu cambio NO ha
  aterrizado: ésa es la ventana fail-closed»*.

**(d) Filtro por tenant/`organization`.** ❌ **No es viable y no se debe fingir.** La fila lleva la
clave de scope, no el subárbol; filtrar «lo de mi organización» exige el árbol, y **el árbol es
justamente lo que estas filas están cambiando** (un `moved` pendiente hace que «de qué tenant es esta
entrada» tenga dos respuestas legítimas). Lo máximo honesto sin árbol es
`only: { scopes: ScopeRef[] }` = *claves exactas*, sin descendientes: es implementable con las
columnas de hoy (mismo coste que la sonda, sub-ms) y sirve para «todo lo que toca a esta org como
padre». Recomendación: **empezar por ids** (que es lo que el consumidor acaba de recibir del recibo)
y dejar `{ scopes }` para cuando haya un segundo caso (regla de tres).

**(e) Trampa medida.** En la simulación de `only`, filtrar TAMBIÉN la sonda de `remaining` devolvió
`remaining: false` con **500 entradas pendientes**. `remaining` y `dead` **se calculan sin filtro,
siempre**; el reporte de una pasada `only` tiene que seguir gritando que la cola no está vacía.

### Coste en el esquema

**Ninguno.** `only` por ids es la PK; la sonda de dependencia usa columnas existentes con el índice
`(applied_at, id)`. **Sin columna nueva, sin migración.** (Lo cual importa: el stub de migración es
del consumidor y ya está desplegado.)

### Coste medido de la pasada con backlog ajeno

Con 500 entradas de otro tenant + 1 propia, **la petición que crea el tenant paga 4,5 s y 2 004
llamadas a FGA para aplicar lo suyo**; con `only`, **19 ms y 4 llamadas**. Es una mejora de **×237**
en el camino que el README recomienda hoy como receta interactiva. Y `--limit` **no** lo resuelve:
`pending` sirve por id ascendente (las más viejas primero), así que `limit: 1` aplica *la ajena*.

---

## 2. Aparcado sin vuelta

### Lo verificado

- ✅ `maxAttempts` default 5; `pending()` excluye `attempts >= maxAttempts`; `dead()` las enseña;
  **nada en el paquete devuelve una fila a `pending()`** (`src/scope_outbox.ts:246-268`).
- ✅ **Medido**: con el store caído (connection refused), la entrada queda **aparcada tras 6 pasadas**
  (5 `markFailed` + la 6ª ya la ve en `dead`), y cada pasada fallida cuesta **2-15 ms**. Con relay
  inline eso son **6 peticiones**: a 2 req/s ya se aparca dentro de una caída de 3 s. El default de 5
  está dimensionado para un job con ciclo de segundos, exactamente como dicen.
- ✅ **Matiz importante y medido** (`bench_attempts.mjs`, 5 entradas: 3 bajo `orgB` y 2 bajo `orgA`):
  en una pasada con el backend caído **solo la CABEZA de cada grupo de clave de scope quema intento**;
  el resto sale `deferred` con `attempts = 0`. Tras 6 pasadas: `#1=5` (aparcada), `#2=1`, `#3=0`,
  `#4=5` (aparcada), `#5=1`. O sea: una caída **no** aparca la cola entera de golpe, pero **aparca una
  entrada por grupo cada 5 pasadas, indefinidamente**, y va comiéndose el grupo entrada a entrada.
  Con relay inline y tráfico, una caída de 3 s puede aparcar varias entradas por tenant.

### El fallo de diseño real (y por qué «sube `maxAttempts`» es el parche flojo)

`maxAttempts` existe para **converger sobre lo irreparable** (el padre del `attached` se borró y no va
a volver). Una caída del store **no es irreparable**, y sin embargo consume el mismo presupuesto. La
forma mínima correcta no es un número más alto: es **no contar el intento cuando el fallo es
transitorio**.

- El manager ya distingue: `AuthorizationBackendError`/`Timeout` = 503 (transitorio) vs 422/500
  (permanente). En `#applyScopeChange` el `catch` tiene el error en la mano.
- Forma mínima, **opcional y no breaking**: `markFailed(id, error, options?: { transient?: boolean })`.
  Un tercero que ignore el tercer parámetro **cuenta el intento = comportamiento de hoy** (degrada
  hacia lo seguro, no hacia lo peligroso). `sqlScopeOutbox` no incrementa `attempts` con
  `transient: true` — pero **sí escribe `last_error`**: nada se vuelve silencioso.
- ¿Se reabre el tapón de 3b-2h · 🔴 2? No: desde 3b-2h un fallo ya **no bloquea a otros tenants**, solo
  a sus propias claves de scope. Una entrada que 503 para siempre significa «el store está caído», que
  es un incidente visible por otros diez sitios; y `dead` sigue existiendo para lo irreparable.

**Alternativa más barata si se quiere cero cambios en el puerto**:
`relayScopeChanges({ countAttempts: false })` y que la receta inline lo use. Es peor, porque el job
tiene el mismo problema con una caída larga, y porque deja la decisión en el call-site en vez de en la
naturaleza del error. La dejo como plan B explícito.

### `authz:scopes:requeue` — y un foot-gun que hay que cerrar ANTES de publicarlo

Forma mínima: `outbox.requeue?(ids): Promise<number>` (opcional en el puerto; `attempts = 0`,
`last_error` conservado) + `node ace authz:scopes:requeue --id=…` (operación de **plataforma**, como
el relay: se salta `requireActor`/`requireWithin`, no se expone por HTTP).

🔴 **Pero un `requeue` a secas reproduce el bug del doble escritor.** Verificado en código:
`onScopeAttached`/`onScopeMoved` → `reparent` **lee la arista actual y la sustituye en un solo
`Write`** (`src/drivers/openfga_driver.ts:1591-1700`). Si `#5 attached(C→P)` se aparcó y después se
aplicó `#150 moved(C→Q)`, **relanzar #5 devuelve el árbol del store al padre viejo, con un solo padre
y nada que lo delate** — que es literalmente lo que el lease de 3b-2h · 🟠 4 cierra, y lo que el
README describe como «el store se queda con el padre viejo y una sola arista». Cambiar el id (encolar
al final en vez de reactivar la fila) **no lo arregla**: el contenido es igualmente viejo.

Forma mínima segura: `requeue` comprueba antes, por cada id, si existe una entrada **posterior y ya
aplicada** que toque alguna de sus claves de scope ⇒ **se niega** nombrando esa entrada y remitiendo a
`authz:reconcile --to=<driver>` (que recalcula con el árbol de HOY y es el remedio correcto).
`--force` para el operador que sabe lo que hace. Coste medido de la sonda: **0,33 ms**.

### Nota de README para el relay inline (lo que piden, con números)

Junto a la receta inline: *«cada petición es una pasada; con el store caído, cinco peticiones aparcan
tu entrada (medido: 6 pasadas, 2-15 ms cada una). Con relay inline sube `maxAttempts` (≥ 50) o
—mejor— actualiza a la versión que no cuenta los fallos transitorios; y mira `dead` en el reporte, que
tu petición sí puede leer»*. Y la frase que falta y es la importante: **la pasada inline devuelve un
reporte, no lanza**: un `failures`/`deferred` no aborta la petición del consumidor si nadie los mira.

---

## 3. `enumerateRelations` O(store)

### Confirmado

`Read({})` paginado + filtro en JS por `parsed.partitionKey !== partitionKey`
(`src/drivers/openfga_relations_driver.ts:610-635`, `#readAll` en 761-805, `READ_PAGE_SIZE = 100`).
El id es `<tipo>:<scopeKey(partición)>|<uuid>`, o sea **la partición va DELANTE** (`#objectId`, línea
302) — el candidato natural sería un filtro por prefijo.

### Alternativas, MEDIDAS contra el `:8101` (OpenFGA v1.19.0)

| alternativa | resultado medido |
|---|---|
| Hoy: `Read({})` 100/página, store de 15 000 | **151 páginas, 456-549 ms**, *igual para una partición de 5 000 que para una de 10* |
| `pageSize: 1000` | ❌ 400 `invalid ReadRequest.PageSize: value must be inside range [1, 100]` — **100 es tope duro del servidor** |
| `Read({ object: 'document:' })` (tipo solo, sin user) | ❌ 400 «object id and user cannot be empty» — el comentario del código es exacto |
| `Read({ object: 'document:', relation: 'viewer' })` | ❌ 400, igual |
| `Read({ object: 'document:<partición>\|' })` (**prefijo de id**) | ⚠️ **200 con 0 tuplas**: el servidor trata el id como EXACTO. **El prefijo no existe en la API**, y lo peor es que no falla: devolvería «esta partición está vacía» |
| `Read({ object: '<id exacto>' })` | ✅ p50 **1,50 ms** |

**Veredicto: la opción «`Read` por `object` con tipo + prefijo» NO es viable**, y cambiar el orden del
id (partición detrás) tampoco sirve: no hay filtro por subcadena en ninguna posición. Un id compuesto
**no es un índice** en OpenFGA. Esto conviene escribirlo así de claro en el README, porque es
exactamente la mejora que cualquiera propondría al leer el formato del id.

### Lo que SÍ queda

1. **Declarar el límite** (coste 0, hazlo ya): *«`enumerateRelations` lee el store entero: O(tuplas
   del despliegue) por partición y por llamada, 100 tuplas por página (tope del servidor). Medido:
   15 000 tuplas ⇒ 151 páginas / ~0,5 s, sea cual sea el tamaño de la partición. Con K particiones un
   reconcile completo cuesta K × ese barrido»*.
2. **Una sola pasada para K particiones** (la mejora con más apalancamiento y la más barata):
   `enumerateRelations` ignora hoy su parámetro `_page` y rehace el barrido completo en cada llamada.
   Una variante que enumere **todas las particiones en un barrido** (o que honre el cursor de verdad)
   convierte K × O(store) en 1 × O(store). Con sus 3 particiones: **1,4 s → 0,46 s**; con 50
   particiones, de ~23 s a 0,5 s. Es aditivo (método/opción nueva; el actual se queda).
3. **Índice propio en FGA** (tupla `partition:<clave>#contains@<objeto>`): permite `Read` por id
   EXACTO de la partición ⇒ lista de objetos, y luego **1 request por objeto** (1,5 ms). Sale a cuenta
   solo si `objetos_de_la_partición < tuplas_del_store / 100`: con 5 000 objetos serían 5 000 requests
   (peor); con 50 objetos en un store de 500 000 sería 51 requests contra 5 000 páginas (mucho mejor).
   Además hay que escribirlo/borrarlo **en el mismo `Write`** que la tupla (invariante 6) y una deriva
   del índice **falsea el ORIGEN de una migración** — el fail-dangerous de la casa. 🟡 Documentar la
   condición, no implementarlo aún.
4. ❌ **Índice en SQL**: segunda fuente de verdad sin 2PC contra el store, justo en la pieza que es
   ORIGEN de `reconcile`. Un índice desincronizado = tuplas que desaparecen sin rastro en una
   migración. **No hacer.**

---

## 4. La profundidad 22 en el README

### Lo verificado (y una corrección al informe)

`FACTS_MAX_RESOLVE_DEPTH = 22` **sí está en el README**, y con toda la historia: sección
**«The scope-chain depth ceiling (facts)»**, README líneas 1020-1033, dentro de *Operational notes for
this driver*. Lo que **no** existe es una **tabla de límites**, y sobre todo: el número vive donde lee
quien opera OpenFGA, **no donde lee quien diseña su árbol de scopes** (§ «The scope tree», línea 78).
Su observación es correcta en el fondo aunque no en la letra: **el número está, pero no donde se
necesita**. Merece la pena decírselo así.

### Forma mínima (trivial)

1. Tabla **«Limits»** compacta y única, en *Operational notes* con enlace desde § «The scope tree»:
   22 saltos de cadena (`facts`), 100 tuplas/página en `Read`, 10 000 páginas máximas,
   50 checks/`batchCheck`, `maxScopes` 1000, `maxDescendants` 10 000, `maxLocalRoles` 10 000, bytes del
   modelo, `enumerateRelations` = O(store) (punto 3).
2. Una línea en § «The scope tree»: *«si sirves con `openfga`+`facts`, tu árbol no puede pasar de 22
   niveles bajo `app`; con `database` no hay techo»*, con enlace.
3. Mencionar el mecanismo **que ya existe**: `hierarchicalScopeResolver({ maxDepth: 22 })`
   (`src/hierarchical_resolver.ts:64`, default 64) ⇒ 500 `E_AUTHZ_SCOPE_TOO_DEEP` en vez de un 503 del
   servidor. Es tosco (500, y salta también en LECTURA de un scope profundo) pero está publicado y no
   cuesta nada recomendarlo hoy.

### El gate en `scopes.attached`/`moved`: viable y **gratis en I/O**

✅ `#assertEdge` ya resuelve **la cadena completa del padre** (`chain`, `src/manager.ts:1741`) y
`attached`/`moved` la tienen en la mano; los saltos del hijo hasta `app` son exactamente
`chain.length`. **Coste de medir la profundidad: cero consultas, una comparación de enteros.** No hace
falta leer nada del store (su intuición de «la cadena del padre ya se lee en `moved`» es correcta, y
vale igual en `attached`).

Tres cosas que hay que decir antes de firmarlo:

- **Es un gate PARCIAL.** Cubre «voy anidando un nodo cada vez». No cubre `moved` de un **subárbol de
  altura h**: las hojas acaban a `chain.length + h` y el manager no conoce `h` sin `descendantsOf`
  (que es caro y está prohibido en el camino de escritura). Un gate que se venda como garantía sería
  una promesa falsa; como red contra el caso común, vale.
- **Dónde vive el número.** El techo es del DRIVER, y el manager es agnóstico. `capabilities` no
  sirve tal cual: `normalizeAuthorizationCapabilities` colapsa **todo a booleano**
  (`declared?.[key] === true`, `src/types.ts:370-376`), así que un `maxScopeChainDepth: number` obliga
  a tocar una función publicada y su doctrina («solo `true` es `true`»). Salidas: (i) `scopes.maxDepth`
  en el config del paquete —simple, driver-agnóstico, pero «una recomendación no es un mecanismo»:
  nadie lo pondrá—; (ii) un canal nuevo `driver.limits?.maxScopeChainDepth` fuera de `capabilities`.
  **Decisión del dueño pendiente.**
- **Con outbox, `scopes.attached` hoy NO resuelve el driver.** Leer un límite del driver introduce la
  resolución del driver en el camino de encolado (sin I/O, pero es un cambio de forma). Con
  `scopes.maxDepth` en config no pasa.
- **Código y status**: sería 422 nuevo (`E_AUTHZ_SCOPE_DEPTH_LIMIT`) — `E_AUTHZ_SCOPE_TOO_DEEP` ya
  está tomado con 500 y otra semántica (`src/errors.ts:481`).

**Recomendación**: README **ya** (trivial); gate **opt-in por config** (fácil); gate declarado por el
driver, a decisión del dueño. Y en `authz:reconcile --dry-run`, que ya es read-only y camina el árbol,
**reportar como deriva las cadenas > 22** — es el sitio natural y no rompe nada.

---

## 5. Lease por pasada vs por lote (su pregunta)

### Lo verificado

`acquire()` (`src/scope_outbox.ts:270-330`): PG `pg_try_advisory_xact_lock` **dentro de una
transacción abierta que no escribe nada** y se revierte al soltar ⇒ **una conexión del pool ocupada
toda la pasada**; MySQL `GET_LOCK(name, 0)` con la sesión sostenida; SQLite/desconocido ⇒ cerrojo de
proceso. El contrato del puerto lo dice literal (`src/types.ts:1185-1200`): *el lease se toma UNA vez y
**no** se re-verifica dentro del bucle; una implementación con TTL reabriría la ventana*.

### ¿Qué pierde un lease por LOTE? — pierde la garantía, y en silencio

El estado que hace correcto el orden es **estado de PASADA, no de lote**: el conjunto `blocked` de
claves contaminadas, `parked`, y el cursor `after` (`src/manager.ts:1049-1120`). Con dos relays
alternando lotes:

1. R1 toma el lote 1, falla `#5 attached(C→P)` ⇒ contamina la clave de `C`, la aplaza y **sigue**.
2. R1 suelta el lease al acabar el lote. R2 arranca **una pasada nueva**: `blocked` vacío, `after`
   vacío ⇒ `pending()` le devuelve `#5` **la primera** y la aplica.
3. Mientras tanto R1, en su lote 2, aplica `#150 moved(C→Q)`.
4. Según el entrelazado, la última escritura sobre `C` puede ser el `attached` VIEJO. Y `reparent`
   **sustituye la arista** (lee la actual y la reemplaza en un `Write`): el store queda con **el padre
   viejo y una sola arista**. Nada lo delata. Es el mismo defecto medido en 3b-2h · 🟠 4.

O sea: **sí, dos relays alternando lotes pueden reordenar cambios de la misma clave de scope**, aunque
el orden se conserve dentro de cada lote. **El lease por lote no es una versión más barata del mismo
invariante: es otro invariante, más débil.**

### ¿Y un lease corto con `fence`, como el freeze durable?

El freeze funciona porque **su barrera se re-afirma leyendo la fila `id=2` antes de cada escritura** y
su trade-off documentado cubre «una escritura que ya pasó su barrera». Aquí el equivalente sería
comprobar el token antes de cada entrada — pero **la escritura de destino es una tupla de FGA**, que
no admite condición sobre un token de PostgreSQL: no hay *fence* de verdad, solo un check-then-write
con TOCTOU. Y el daño de la ventana no es «una escritura de más»: es **una reversión silenciosa del
árbol**. Estrictamente peor. **No hacer.**

### La respuesta honesta a COGNITIV

**El lease no es su problema, y bajar el pool por esto sería optimizar el sitio equivocado.** Medido:

- pasada de 1 entrada = **p50 13,3 ms / p95 17,0 ms** ⇒ eso es lo que dura la conexión extra;
- `acquire()` + `release()` = **0,56 ms**;
- pasada vacía = **4,3 ms**.

Por Little: `conexiones = tasa × tiempo`. A 13 ms sostenidos, **+1 conexión aguanta ~75 escrituras de
árbol por segundo**. Lo que sí rompe el pool es el caso (a): con backlog ajeno la pasada dura **4,5 s**
⇒ a 1 req/s son ~4,5 conexiones sostenidas. **La cura de eso es `only` (punto 1) y `limit`, no
degradar el lease.** Mensaje para ellos, en una frase: *el lease seguirá siendo por pasada; hagan la
pasada corta, no el lease débil* — y con `only`, la conexión extra se sostiene **19 ms**.

---

## Plan por lotes

| lote | qué entra | resultado demostrable | dificultad | breaking |
|---|---|---|---|---|
| **R0 · docs** | README: tabla «Limits» con los 22 saltos + enlace desde «The scope tree»; límite O(store) de `enumerateRelations`; nota de `maxAttempts` en la receta inline con los números medidos; frase «la pasada inline devuelve reporte, no lanza» | Un consumidor que diseña su árbol ve el techo de 22 sin leer las notas de OpenFGA | **trivial** | no |
| **R1 · «¿se aplicó lo mío?»** (camino crítico) | `enqueue` ⇒ `{ id }` opcional; `scopes.*` ⇒ `{ queued: ids[] }`; `relayScopeChanges({ only })` + guardia del `only` no honrado (500); regla de dependencia ⇒ `deferred`; `remaining`/`dead` sin filtrar; `only: []` = nada | La receta inline pasa de **4,5 s / 2 004 llamadas** a **19 ms / 4 llamadas** con backlog ajeno, con caso que lo fija | **medio** | **no** (covarianza + parámetro opcional) |
| **R2 · lo aparcado vuelve** | `markFailed(id, err, { transient })` y `sqlScopeOutbox` que no cuenta transitorios; `outbox.requeue?(ids)` + `authz:scopes:requeue --id` con **sonda anti-reversión** y `--force` | Caída de 3 s del store con relay inline ⇒ **0 aparcadas**; y un `requeue` que revertiría el árbol se niega nombrando la entrada culpable | **medio** | no |
| **R3 · reconcile de relaciones en una pasada** | `enumerateRelations` que honre el cursor / variante multi-partición en un solo barrido | Reconcile de K particiones: de K×0,5 s a 0,5 s (medido con 3) | **medio** | no |
| **R4 · gate de profundidad** | `scopes.maxDepth` opt-in en config ⇒ 422 en `attached`/`moved` (coste I/O **cero**); deriva «cadena > techo» en `authz:reconcile --dry-run` | Un `attached` que dejaría el scope a 23 saltos falla en la escritura, no como 503 en la primera pregunta | **fácil** (config) / **medio** (declarado por driver) | no |

**Empaquetado.** R0+R1+R2+R4(config) son **estrictamente aditivos** ⇒ caben en **`2.4.0-alpha.5`**.
R3 toca la forma de un método del puerto de relaciones ⇒ **2.5** (o alpha.5 si se añade método nuevo y
el viejo se queda intacto).

**Camino crítico: R1.** Desbloquea la receta inline que COGNITIV ya está montando, y **disuelve el
punto 5** (con `only` la conexión sostenida baja de 4,5 s a 19 ms y su pregunta sobre el pool
desaparece). R2 depende de R1 solo en documentación; R3 y R4 son independientes.

**Decisiones del dueño pendientes**
1. ¿El no-contar-intentos se decide por **naturaleza del error** (503 vs 422/500, recomendado) o por
   **flag del call-site** (`{ countAttempts: false }`)?
2. ¿El techo de profundidad lo declara el **driver** (canal nuevo fuera de `capabilities`, que es
   booleana por doctrina) o el **config** del consumidor?
3. ¿`requeue --force` existe, o negarse es absoluto?

## Qué NO hacer

- ❌ **Lease por lote** ni **lease con TTL/fence**: pierden el escritor único y el fallo es una
  reversión silenciosa del árbol (razonado sobre `blocked`/`after`/`reparent`).
- ❌ **Filtro por tenant/`organization`** en la outbox: exige el árbol, y el árbol es justo lo que
  estas filas están cambiando. Ids (o claves exactas), nunca subárboles.
- ❌ **`only` que arrastre sus dependencias**: es transitivo y acaba siendo la cola entera.
- ❌ **`Read` por prefijo de id / `pageSize > 100` / `Read` por tipo sin user**: los tres **medidos y
  descartados** contra v1.19.0 (el del prefijo es el peligroso: responde 200 con 0 tuplas).
- ❌ **Índice de particiones en SQL**: segunda fuente de verdad sin 2PC en el ORIGEN de una migración.
- ❌ **Columna nueva / migración de `authz_scope_outbox`**: nada de lo propuesto la necesita, y el stub
  ya está desplegado en los consumidores.
- ❌ **Subir `maxAttempts` como única respuesta** al punto 2: trata el síntoma y deja el job con el
  mismo problema en una caída larga.
- ❌ **Vender el gate de profundidad como garantía**: no ve la altura del subárbol que mueves.
