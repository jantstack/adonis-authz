# Panel 3 · Analista técnico — el `freeze()` de `authz:reconcile`

**Encargo:** viabilidad técnica, coste medido y alternativas de las opciones A/B/C/D sobre el
🟠 3 de la auditoría final (`freeze()` es de PROCESO). **No es el veredicto**: el juez sintetiza.

**Método.** Worktree de solo lectura clavado en `2507f45`
(`…/scratchpad/wt-panel-analista`, `node_modules` enlazado). Todo lo que aparece con un número
está **medido** contra los motores de esta máquina: PostgreSQL 18 (`:5432`), MySQL 8.4 (`:3306`),
OpenFGA (`:8101`), bases `analista_authz_<hex>` creadas y destruidas por script, stores
`analista-*` borrados en el `finally`. Al terminar: **0 stores** en el `:8101` y **0 bases
`analista_*`** en PostgreSQL (comprobado; la `authz_test_218f1cc4` que queda es del otro agente y
no se ha tocado). Los scripts quedan en `…/scratchpad/wt-panel-analista/repro/`
(`m1`…`m12`, `freeze_lib.ts`, `m10_hijo.ts`).

Marcas: ✅ medido en esta sesión · 🟡 leído en el código, no ejecutado · ❓ pendiente.

---

## Resumen en cinco líneas

1. **A no cuesta lo que parece.** ✅ Toda escritura ya hace **1 `SELECT` por clave primaria a
   `authz_catalog_version`** — en los tres motores y en los dos drivers. El coste real de A es
   **+1 SELECT por ESCRITURA y 0 por lectura**: +0.14 ms p50 sobre un `grant` de 2.0 ms en
   PostgreSQL (+7 %), +0.11 ms sobre 6.3 ms en MySQL (+2 %). No es un coste por request: es un
   coste por `grant`/`deny`/`revoke`.
2. **El TTL no arregla nada; el TTL RENOVADO sí, y está medido.** ✅ Prototipo de dos procesos
   reales: freeze durable con lease de 3 s renovado cada 1 s ⇒ el otro proceso queda congelado,
   el freeze sobrevive a su propio TTL mientras la pasada vive, y con **`SIGKILL` al proceso de
   la migración la app vuelve a escribir sola en 2 527 ms** sin que nadie limpie nada.
3. **El lease tiene su propio fallo y tiene su propio remedio.** ✅ Un atasco del bucle de
   eventos de 1 200 ms con lease de 400 ms deja el lease caducado y la app escribiendo **sin que
   nadie se entere** — y el **fence** (renovación condicional por número de generación) lo caza al
   cerrar: `lapsed=true`. El lease no elimina el riesgo, lo hace **acotado y detectable**.
4. **D es más débil de lo que suena, y de forma concreta.** ✅ Con el criterio literal del
   coordinador («la segunda pasada escribe cero»), **el `revoke` —el caso EXACTO del hallazgo 3—
   NO se detecta**: pasada 2 sale `w=0 u=0 del=0`, solo `extra=1`, y el destino sigue concediendo.
   Se detecta **solo con `--prune`**. Y `skipped` no sirve de criterio: es ruido estacionario.
5. **La pieza que ya existe y nadie ha nombrado**: la fila `authz_catalog_version` — la única
   señal entre procesos que el paquete ya tiene, que **toda escritura ya lee** y sobre la que
   `withAuthzCatalogWrite` ya sabe hacer cerrojo de fila. El freeze durable no hay que inventarlo:
   hay que **colgarlo de ahí**.

---

## 1 · El coste real de A, medido

### 1.1 · Cuántas consultas cuesta HOY una escritura (línea base)

`repro/m1_coste_escritura.ts`, contando el SQL de knex con `tests/helpers/spies.ts`. ✅

| motor | driver | `grant` | `revoke` | `deny` | `removeDeny` | de ellas `authz_catalog_version` |
|---|---|---|---|---|---|---|
| pg | `database` | 4 | 3 | 4 | 3 | **1** en las cuatro |
| pg | `openfga` (facts) | 2 | 2 | 2 | 2 | **1** en las cuatro |
| mysql | `database` | 4 | 3 | 4 | 3 | **1** en las cuatro |
| mysql | `openfga` (facts) | 2 | 2 | 2 | 2 | **1** en las cuatro |
| sqlite | `database` | 4 | 3 | 4 | 3 | **1** en las cuatro |
| sqlite | `openfga` (facts) | 2 | 2 | 2 | 2 | **1** en las cuatro |

Y el orden importa: ✅ el `SELECT version` sale **antes** del `INSERT`/`DELETE` en las ocho
combinaciones (salida verbosa de `m1`). Es exactamente el sitio donde va una barrera de escritura.

```
grant   SQL total= 4  de ellas authz_catalog_version=1
    · select * from "demo_scopes" where "uuid" = $1 …
    · select "version" from "authz_catalog_version" where "id" = $1      ← ya está aquí
    · select "uuid","expires_at" from "authz_assignments" where …
    · insert into "authz_assignments" …
```

### 1.2 · Lecturas por escritura, y por qué NO se puede amortizar con el memo

**La respuesta corta: 1 lectura por escritura, 0 por lectura.** Y no se amortiza. Los tres
candidatos, con el motivo por el que caen:

| ¿amortiza? | por qué no | ✅/🟡 |
|---|---|---|
| `CatalogCache` | El memo **es** el problema: sirve una foto cacheada. Un freeze cacheado 30 s no es un freeze. `catalogRevalidate: { everyMs }` es config publicada (README:463) y con ella **la fila ni se lee**: medido, `grant` pasa de 4 SQL a 3 y `authz_catalog_version=0` (`repro/m3_everyms.ts`) | ✅ |
| `forRequest()` | Una vista dura un request; un request hace 0-2 escrituras. Amortizar ahí no ahorra casi nada y mete una ventana de request entera | 🟡 |
| Colgarse del `SELECT` que el memo YA hace | Es la vía **gratis** y la exploré: leer `version` + las columnas del freeze en la misma consulta cuesta **+0.016 ms p50 en PG y +0.013 ms en MySQL** (`repro/m2b`, N=1000, intercaladas). Pero la consulta la hace el `CatalogCache` **dentro del driver**, y `#assertNotFrozen` vive en el manager **antes de validar identidad** (`manager.ts:1051`, `#writeOptions`). Para aprovecharla, o el chequeo baja al driver (y deja de ser del manager) o el manager consulta un valor que otro puso ahí = **freeze de una escritura de retraso**. Ninguna de las dos vale | ✅ + 🟡 |

**Conclusión honesta**: la variante «gratis» existe físicamente pero **no sobrevive al requisito de
frescura**. El número que hay que defender es el de la consulta propia.

### 1.3 · Lo que A añade a `grant`/`deny`/`revoke`, en milisegundos

`repro/m2_latencia.ts` (N=200) y `repro/m10_lease.ts` (N=500). ✅

| motor | `grant()` completo hoy | +1 `SELECT` por PK (lo que añade A) | % sobre `grant` |
|---|---|---|---|
| PostgreSQL 18 | avg 2.045 ms · p50 1.607 · p95 4.780 | avg 0.336 ms · **p50 0.174** · p95 1.280 | **+16 % avg · +11 % p50** |
| MySQL 8.4 | avg 6.302 ms · p50 3.585 · p95 13.142 | avg 0.464 ms · **p50 0.111** · p95 1.167 | **+7 % avg · +3 % p50** |
| sondeo del prototipo real (PG) | — | **p50 0.279 ms · p95 1.039** | — |

Y el tercer motor: **OpenFGA no paga nada.** El driver `openfga` en modo `facts` hace 2 consultas
SQL por escritura (una es ya la de la versión) más sus llamadas al store; A añade la misma consulta
SQL y **cero** llamadas a FGA. El coste de A es idéntico en los tres motores porque **el freeze vive
en SQL siempre**, que es donde el paquete ya pone su catálogo.

**Y en el camino de LECTURA: cero.** ✅ Medido: `authorize` hace 3 SQL con `{ everyMs }` y 4 con
`'always'`, y A no lo toca — el freeze solo se consulta en escrituras, que es la asimetría
deliberada que el README ya publica.

> **La frase que hay que retener:** A cuesta **una consulta por clave primaria por cada `grant`,
> `deny`, `revoke` o cambio de árbol**, y **nada** por cada `authorize`. En un motor de
> autorización la proporción lectura/escritura es de tres o cuatro órdenes de magnitud. **A es
> barato, y es barato por la razón correcta.**

---

## 2 · Los modos de fallo de A (el TTL, y la tercera vía)

### 2.1 · Primero, el tamaño de la ventana — porque decide todo lo demás

`repro/m7_coste_pasada.ts` ✅, `--to=database --from=openfga(facts)`, PG + `:8101`:

| hechos | pasada 1 (ventana congelada) | por hecho |
|---|---|---|
| 200 | **26 ms** | 0.130 ms |
| 1 000 | **136 ms** | 0.136 ms |

Extrapolado al tope declarado (`--max-tuples` 1 000 000): **≈ 136 s ≈ 2 min 16 s**. El README dice
«*a maintenance window of **seconds***» (línea 615). **A escala declarada eso es falso**, y ese dato
es el que rompe la discusión del TTL: **el TTL tiene que aguantar minutos, no segundos.**

### 2.2 · El TTL a secas: la crítica del coordinador es correcta

| variante | qué pasa | veredicto |
|---|---|---|
| Freeze durable **sin** TTL | El proceso muere ⇒ la app rechaza escrituras **para siempre** hasta que un humano borre la fila. 503 en todos los `grant` de producción | ❌ inaceptable |
| TTL **corto** (30 s) | A 0.136 ms/hecho, la garantía **caduca sola** por encima de ~220 000 hechos. La migración sigue creyéndose protegida | ❌ garantía de mentira |
| TTL **largo** (10 min) | Un proceso muerto deja la app sin escribir **10 minutos** | ❌ solo mueve el problema |

**El coordinador tiene razón: el TTL a secas solo mueve el problema.** No hay valor bueno porque
las dos magnitudes (duración de la pasada y tolerancia a la parada) son independientes.

### 2.3 · La tercera vía: lease renovado + fence. **Medida en dos procesos reales**

`repro/freeze_lib.ts` + `repro/m10_hijo.ts` + `repro/m10_lease.ts`. Un proceso hijo hace de
`node ace authz:reconcile`; el padre hace de worker HTTP. Lease 3 000 ms, renovación cada 1 000 ms.
Salida literal ✅:

```
=== dos PROCESOS reales, lease = 3000ms, renovación cada 1000ms ===
  hijo (pid 188931) congeló con lease durable
  (1) el OTRO proceso ve el freeze: true          ← lo que el freeze de hoy NO hace
  (2a) tras 3500ms (más que el TTL) el freeze SIGUE en pie: true
  (2b) SIGKILL al proceso de la migración ⇒ la app vuelve a escribir sola en 2527ms
       sin lease (freeze durable «a secas»): NUNCA, hasta que alguien lo limpie a mano
  (3) SELECT del freeze por escritura: p50 0.279ms  p95 1.039ms
  (4) UPDATE de renovación: p50 10.722ms  p95 26.532ms
  (5) el fence al cerrar: lapsed=false            ← la PRUEBA de que el lease nunca caducó
```

**Lo que cuesta de verdad, en este paquete:**

| pieza | coste medido | comentario |
|---|---|---|
| Sonda por escritura | p50 **0.279 ms** | ya contada en §1.3 |
| `UPDATE` de renovación | p50 **10.7 ms** | con lease 15 s y renovación cada 5 s, una pasada de 136 s = **28 UPDATE = 0.3 s** en total |
| Recuperación tras `SIGKILL` | **≤ leaseMs**, medido 2 527 ms con lease 3 000 | **sin intervención humana** |
| Código | 🟡 ~60 líneas (`freeze_lib.ts` es el prototipo entero) + una columna/fila + una migración | el `setInterval` va `unref()` |

### 2.4 · El fallo REAL del lease renovado (y por qué el fence no es opcional)

El lease no muere solo cuando el proceso muere: muere también cuando el proceso **se atasca**
(pausa de GC, corte de red a la base, `idle_in_transaction_session_timeout`). `repro/m11_fence.ts`,
salida literal ✅:

```
  lease 400ms, renovación cada 133ms — congelado
  … 1200ms de bucle de eventos bloqueado (pausa de GC / stop-the-world)
  el lease CADUCÓ solo: true  (until_ms - now = -813ms)
  un worker HTTP ya puede escribir: true   ← la garantía se perdió SIN que nadie se entere
  al cerrar la pasada, el fence dice lapsed=true   ← ASÍ se entera: la pasada NO se certifica
```

**Ésta es la conclusión estructural de toda la pregunta 2:** ninguna forma de freeze —de proceso,
durable, con TTL, con lease— puede *garantizar* la exclusión sin volverse frágil. Lo que sí se
puede garantizar es **saber si valió**. El fence (renovación condicional `WHERE fence = ? AND
until_ms > now`) convierte «esperemos que nadie escribiera» en **un booleano que el reporte
publica**. Y ése es exactamente el mismo movimiento que el paquete ya hace con `drift.deadRelay`,
`report.factsFrom` y el censo del contrato: **no prometer lo imposible; medir y decirlo.**

Nota táctica ✅: `pg_advisory_xact_lock` / `GET_LOCK` — la tercera vía «obvia», la que el propio
paquete usa en `scope_outbox.acquire()` — **no vale aquí**, y está medido:

```
pg  · xact:    sonda tras rollback()  false                       (bien, pero exige una
                                                                   transacción ABIERTA los 136 s)
pg  · session: sonda tras rollback()  true   ← FUGA: el cerrojo se queda en la conexión del POOL
mysql:         is_used_lock tras rollback()  1316  ← GET_LOCK es de SESIÓN, el rollback no lo suelta
sonda `pg_locks`  p50 0.270 ms   vs   SELECT por PK  p50 0.150 ms   (casi el doble, y es EXTRA)
```

Y en SQLite no hay cerrojo de servidor: el freeze volvería a ser de proceso justo donde se prometió
lo contrario. **Más caro, más frágil y desigual entre motores que la fila.**

---

## 3 · ¿D es sólido? Qué NO detecta, con precisión

He construido el escenario del auditor (ventana forzada dentro de la pasada 1, `--to=database
--from=openfga(facts)`, PG + `:8101` reales) y he corrido la **segunda pasada** en cada caso.
`repro/m5_opcion_d.ts`, `m5b`, `m6`, `m12`. Todo ✅.

### 3.1 · La tabla de detección, medida

| escritura concurrente | pasada 2 (medida) | «escribe cero» detecta | destino correcto |
|---|---|---|---|
| `grant` nuevo | `w=1 u=0 unch=1 extra=0 del=0` | ✅ **sí** | sí |
| `deny` nuevo | `w=1 u=0 unch=1 extra=0 del=0` | ✅ **sí** | sí |
| **`revoke`, SIN `--prune`** | `w=0 u=0 unch=0 extra=1 del=0 skipped={"extra-fact":1}` | ❌ **NO** | **NO** (`authorize=true` cuando toca `false`) |
| `revoke`, **CON `--prune`** | `w=0 u=0 unch=20 extra=1 **del=1**` | ✅ sí | sí |
| Escritura que la pasada 2 SALTA (`expired`) | `w=0 u=0 unch=5 del=0 skipped={"expired":1}` | ❌ **NO** | (aquí sí, por casualidad) |

**El agujero número 1, y es el caso del hallazgo.** El 🟠 3 es literalmente un `revoke` durante la
pasada. Con el criterio que propone el coordinador —«segunda pasada que escribe **cero** ⇒ nadie
escribió»— y **sin `--prune`**, D dice **limpio** con el `revoke` deshecho y el destino
concediendo. Medido, sin ambigüedad. D **solo** funciona con `--prune` puesto.

**Y eso es un problema por sí mismo:** el README describe `--prune` como el arma cargada («*a
loaded gun pointed at a store that is already live*»). Hacer que la única forma de detectar la
ventana sea encender `--prune` **empeora la postura de seguridad** de la operación. Y además el
seguro de masa dispara justo en el caso pequeño: medido ✅,
`E_AUTHZ_MASS_RECONCILE_REFUSED` cuando el `revoke` dejó el origen sin un solo hecho.

**El agujero número 2: `skipped` no puede ser el criterio.** El `clean` del comando
(`commands/authz_reconcile.ts:113`) ya incluye `Object.keys(report.skipped).length === 0`, así que
podría parecer que el `extra-fact` del `revoke` ya salta. No sirve: 🟡+✅ (a) en una pasada que **no**
es `--dry-run`, `clean` **no mira `written/updated/deleted` en absoluto** (la última cláusula es
`!report.dryRun || cambios === 0`), o sea que el caso `grant` sale `clean=true` con la escritura
migrada; y (b) `skipped` es **ruido estacionario** — con una sola pérdida DECLARADA en el origen
(una asignación caducada, que el puerto **obliga** a devolver sin filtrar) las tres pasadas dan
`skipped={"expired":1}` sin que nadie escriba (`repro/m12`):

```
pasada 1: cambios=5  skipped={"expired":1}   ⇒ «skipped vacío» = SUCIA (falso positivo)
pasada 2: cambios=0  skipped={"expired":1}   ⇒ SUCIA (falso positivo)
pasada 3: cambios=0  skipped={"expired":1}   ⇒ SUCIA (falso positivo)
```

Para que D funcione, el criterio tendría que ser un **delta entre la pasada 1 y la pasada 2** por
motivo de skip (`extra-fact` nuevo ⇒ hubo un `revoke`). Es construible, pero **no existe** y hay
que diseñarlo, escribirlo y probarlo. No es «aprovechar la idempotencia que ya está probada».

**El agujero número 3: D no converge bajo carga.** ✅ Con un `grant` en cada pasada:
`p1 w=21 · p2 w=1 · p3 w=1` — SUCIA indefinidamente. D **no es una alternativa a parar los
escritores**: es la *verificación* de haberlos parado. Sin una regla de parada, el operador entra
en un bucle. Eso hay que decirlo en la misma frase que se propone D.

**El agujero número 4, el que no está en ninguna de las cuatro opciones.** 🟡 leído en
`manager.ts:852`: `withFrozenWrites` envuelve **solo `target.reconcile()`**. La ventana peligrosa
de una migración no acaba cuando acaba la pasada: acaba cuando **todos los workers han recargado el
`config.default` nuevo**. Entre «la pasada termina» y «el último worker cambia de driver» hay una
ventana en la que las escrituras siguen yendo al driver **viejo** y se pierden igual. **Ni A ni C
ni D la cierran tal como están planteadas.** Cualquier opción que se elija tiene que decidir esto:
o el freeze lo levanta el operador (`authz:freeze` / `authz:unfreeze` como comandos separados, con
`reconcile` corriendo dentro) o la promesa sigue siendo parcial y hay que escribirla parcial.

### 3.2 · Steelman de D, que lo tiene

D es la única opción que **no añade coste al camino caliente** y la única que produce **un número
que el operador puede pegar en un ticket**. Y su lógica de fondo es la correcta y es la del
paquete: la idempotencia ya está probada, y «demostrar después» es más honesto que «impedir mal».
Mi objeción **no** es a la idea; es a la implementación tal como está enunciada: «escribe cero» es
la métrica equivocada (no ve el `revoke`), `skipped` es la métrica ruidosa, y sin regla de parada
no cierra. **D bien hecho = delta de `{written, updated, deleted, skipped-por-motivo, extra}` entre
dos pasadas consecutivas + `--prune` + una regla de parada.** Eso ya no es «gratis».

---

## 4 · La alternativa que ninguno hemos visto

Repasé las cuatro piezas que el encargo nombra. Tres no sirven, y una es **exactamente** la
respuesta:

| pieza existente | ¿resuelve el freeze? | por qué |
|---|---|---|
| La **outbox** | ❌ | Es una cola de cambios de árbol; no tiene forma de rechazar una escritura de hechos ni de decirle nada al proceso web |
| El **lease del relay** (`acquire?()`) | ❌ pero **enseña la forma** | Cerrojo de servidor: medido, en PG de sesión **fuga en el pool**, en xact obliga a una transacción abierta minutos; en MySQL `GET_LOCK` sobrevive al `rollback`; en SQLite no existe. Sonda 2× más cara que el `SELECT` por PK. **Su patrón sí sirve: escritor único + `release` en el `finally` + degradación declarada por dialecto** |
| El **censo del contrato de migración** | ❌ para prevenir, ✅ como modelo | Necesita un fixture sembrado; no se puede correr contra producción. Pero es la prueba de que el paquete ya sabe **cerrar una promesa con una medición publicada** en vez de con una garantía |
| **`authz_catalog_version`** (el cerrojo de fila del catálogo) | ✅ **SÍ. Ésta es** | Ver abajo |

### 4.1 · La propuesta: el freeze cuelga de la fila que TODA escritura ya lee

`authz_catalog_version` es, textual en `src/catalog_cache.ts:155`, «*la señal entre procesos*» del
paquete. Ya existe, ya está en la migración publicada, ya la lee cada escritura (§1.1), ya tiene un
protocolo de cerrojo de fila (`withAuthzCatalogWrite` → `FOR UPDATE`, con cortocircuito para
SQLite), y ya tiene su caso de «sin la fila, todo es 503» (`catalog_cache.spec.ts:422`). **No hay
que inventar un mecanismo nuevo: hay que añadirle columnas a la señal que ya hay.**

Con un matiz que **hay que medir antes de escribirlo**, y lo medí ✅ (`repro/m8`, `repro/m9`):

| dónde poner el freeze | coste extra sobre la consulta de hoy | contención con `withAuthzCatalogWrite` |
|---|---|---|
| **Columnas en la fila `id = 1`** | +0.005 ms p50 (PG) / +0.010 (MySQL) — bajo el ruido | ⚠️ el `SELECT` del camino de escritura **NO se bloquea** (MVCC, medido: 4.1 ms / 2.4 ms con el `FOR UPDATE` sostenido), pero **el `UPDATE` de renovación del lease SÍ**: esperó **816 ms (PG) / 805 ms (MySQL)** con un `FOR UPDATE` de 800 ms ⇒ **un `syncAuthzCatalog` lento puede hacer caducar el lease** |
| **Fila `id = 2` de la MISMA tabla, leída con `where id in (1,2)`** | **+0.016 ms p50 (PG) / +0.013 (MySQL)** — una sola consulta, cero viajes nuevos | ✅ **no se bloquea**: la renovación de `id=2` con el catálogo sosteniendo `FOR UPDATE` sobre `id=1` esperó **10 ms (PG) / 12 ms (MySQL)**, no 800 |

**La fila `id = 2` es la colocación correcta**: mismo coste que la de hoy, sin contención con el
catálogo, y el `SELECT` sigue siendo uno solo. (Recuerda §1.2: aprovechar *esa* consulta exige que
el chequeo baje al driver o que el manager acepte un valor de una escritura de retraso; si se
mantiene `#assertNotFrozen` donde está —antes de validar identidad, que es comportamiento
publicado— el coste es la consulta propia de §1.3. **Los dos números están medidos; la elección es
de arquitectura, no de rendimiento.**)

### 4.2 · La forma completa (llámala **E**)

1. **`authz_freeze`** = una fila (nueva, o `id=2` de `authz_catalog_version`) con
   `reason`, `until_ms`, `holder`, `fence`.
2. `freeze(reason, { leaseMs })` la escribe con `fence + 1` y arranca un renovador
   (`leaseMs / 3`, `unref()`), **condicional**: `WHERE fence = ? AND until_ms > now`.
3. `#assertNotFrozen` la lee **sin memo** en cada escritura y lanza el 503 `E_AUTHZ_FROZEN`
   reintentable que ya existe.
4. `unfreeze()` / el `finally` la limpian **solo si el fence sigue siendo suyo**.
5. **`report.frozen: { durable: boolean; lapsed: boolean; leaseMs: number }`** en el reporte de
   `reconcile`. `lapsed: true` ⇒ la pasada **no se certifica** y el comando sale distinto de cero.
6. **Degradación declarada**, con las palabras del paquete: en un despliegue **sin** las tablas
   `authz_*` compartidas entre el comando y los workers, el freeze es de proceso — igual que el
   lease de la outbox declara que en SQLite es de proceso.

Esto **es A + la mitad buena de D**: A previene, la línea 5 demuestra. Y cierra la frase del
README:608 sin reescribirla a la baja, porque la promesa pasa a ser verificable en el propio
reporte en vez de ser un acto de fe.

---

## 5 · Recomendación, con su condición

### La recomendación en una frase

**E** — el freeze durable colgado de la fila que toda escritura ya lee, con **lease renovado** (no
TTL a secas) y **fence publicado en el reporte**: cuesta **+0.14 ms p50 por escritura y 0 por
lectura**, recupera solo en **≤ leaseMs** tras un `SIGKILL` (medido: 2 527 ms), y es la única
opción que deja la frase del README:608 **cierta y comprobable** en vez de cierta-si-tienes-suerte.

### El orden de las cuatro, con el motivo

| | veredicto | motivo, medido |
|---|---|---|
| **A** tal cual (durable sin lease) | ⚠️ correcto pero operacionalmente inaceptable | El proceso muere ⇒ **la app no escribe hasta que un humano lo limpie**. Es cambiar un 🟠 por un incidente de disponibilidad |
| **B** (quitar la promesa) | ✅ **cumple la regla dura** y es la red de seguridad | Nada que medir: si el README lo dice, se cumple. Pero deja al operador con «para la app» como única herramienta, y `freeze()` pasa a ser una API que **no hace lo que su nombre dice** en el 100 % de los despliegues reales |
| **C** (las dos) | ⚠️ la bandera es la parte peligrosa | «Quien no quiera pagar la lectura» va a pagar **0.14 ms** (§1.3). Una bandera para ahorrar 0.14 ms en una escritura, que a cambio apaga una garantía de seguridad, es una bandera que **no debería existir**: no hay trade-off que la justifique con estos números |
| **D** (B + detección) | ❌ como está enunciada | **No detecta el `revoke`, que es el caso del hallazgo** (medido). Solo funciona con `--prune` puesto (que es el arma cargada), `skipped` es ruido estacionario (medido), y no converge bajo carga (medido) |
| **E** | ✅ recomendada | §4.2 |

### Qué tendría que ser cierto para que cambiara de opinión

Cambiaría a **B** —la opción honesta y barata— si se cumple **cualquiera** de estas tres, y las tres
son **verificables, no opinables**:

1. ❓ **Si el dueño decide que `authz_*` puede NO estar compartida entre el comando y los workers.**
   Toda E se apoya en que el `node ace` y el worker HTTP hablan con la misma base. Es cierto en
   todos los despliegues que el paquete describe (el catálogo es SQL propiedad local **siempre**,
   decisión firmada del 2026-08-28), pero **no lo he verificado como invariante declarado**. Si no
   lo es, E es de mentira en esos despliegues y B es lo único honesto.
2. ❓ **Si el agujero 4 (§3.1) no se cierra.** Si `freeze()` sigue viviendo solo dentro de
   `reconcile()`, la ventana del *cutover* queda abierta y E cierra media promesa. En ese caso
   prefiero B con la frase completa antes que E con una frase que sigue siendo optimista. Cerrarlo
   cuesta poco (`authz:freeze` / `authz:unfreeze` como comandos, con `--lease-ms`), pero es una
   decisión de alcance que no me toca a mí.
3. ❓ **Si `leaseMs` no puede tener un default defendible.** Con 0.136 ms/hecho medidos, una pasada
   al tope declarado dura **≈ 136 s**. Un default de 15 s con renovación cada 5 s cubre cualquier
   pausa razonable y limita la parada tras un `SIGKILL` a 15 s. Si el dueño considera que **15 s de
   escrituras en 503 tras un proceso muerto** es inaceptable para COGNITIV o FENIN, entonces no hay
   lease que valga y la respuesta vuelve a ser B.

### La pregunta estratégica que decide la técnica

**¿Qué es peor para el consumidor de este paquete: 15 segundos sin poder escribir tras una
migración que reventó, o un `revoke` aceptado con 200 que no llega al destino?**

Es una decisión de negocio, no de arquitectura, y toda la elección cuelga de ella. Si la respuesta
es «el `revoke`» → **E**. Si es «la parada» → **B**, con la frase escrita entera y `freeze()`
renombrado a algo que no mienta (`freezeThisProcess()`), porque una API que se llama `freeze()` y
congela un solo worker **es la misma promesa incumplida en otro sitio**.

### El siguiente paso concreto

**Antes de escribir una línea**: contestar la pregunta de arriba y el ❓1 (¿`authz_*` compartida es
invariante declarado o solo lo habitual?). Con esas dos respuestas, E son ~60 líneas
(`repro/freeze_lib.ts` es el prototipo entero y funciona), una fila nueva en la migración
publicada, un campo en `ReconcileReport` y **tres casos**: congela-a-otro-proceso, recupera-tras-
`SIGKILL`-en-≤`leaseMs`, y `lapsed=true`-cuando-el-lease-caducó. Los tres los tengo reproducidos y
son ejecutables tal cual.

---

## Anexo · Cómo re-ejecutar las medidas

Scripts en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-analista/repro/`.
Prefijo común (bases propias, se destruyen solas):

```bash
export TEST_PG_URL='postgres://postgres:<pass de postgres18>@127.0.0.1:5432/analista_authz'
export TEST_MYSQL_URL='mysql://root:root@127.0.0.1:3306/analista_authz'
export OPENFGA_TEST_URL=http://localhost:8101
```

| script | qué mide | §  |
|---|---|---|
| `m1_coste_escritura.ts` | SQL por escritura y cuántas son `authz_catalog_version` (3 motores × 2 drivers) | 1.1 |
| `m2_latencia.ts` / `m2b_columnas.ts` | latencia de `grant`, del `SELECT` por PK, y 1 col vs 3 col | 1.3, 4.1 |
| `m3_everyms.ts` | qué desaparece con `catalogRevalidate: { everyMs }` | 1.2 |
| `m4b_sonda.ts` | semántica y coste de `pg_locks` / `IS_USED_LOCK`; la fuga en el pool | 2.4 |
| `m5_opcion_d.ts` / `m5b` | detección de D por tipo de escritura, con y sin `--prune`, y bajo carga | 3.1 |
| `m6_d_ciego.ts` | el punto ciego de D: la escritura que cae en `skipped` | 3.1 |
| `m7_coste_pasada.ts` | duración de la pasada ⇒ tamaño de la ventana ⇒ el TTL que hace falta | 2.1 |
| `m8_contencion.ts` / `m9_dos_filas.ts` | contención con `withAuthzCatalogWrite`; `id=1` vs `id in (1,2)` | 4.1 |
| `m10_lease.ts` + `m10_hijo.ts` + `freeze_lib.ts` | **dos procesos reales**: freeze durable, lease, `SIGKILL` | 2.3 |
| `m11_fence.ts` | el lease caducado por atasco y el fence que lo caza | 2.4 |
| `m12_ruido_skipped.ts` | `skipped` como ruido estacionario | 3.1 |

**Higiene:** `0` stores en el `:8101` y `0` bases `analista_*` al terminar (comprobado).
