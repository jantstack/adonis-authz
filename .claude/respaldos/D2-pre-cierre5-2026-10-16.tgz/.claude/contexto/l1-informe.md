# L-1 · «¿De quién es esta conexión? ¿Quién decide la barrera?» — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `cef972d` (= L-0 commiteado, árbol limpio al empezar). Árbol principal, SIN commits (los
> hace el dueño). Alcance: el lote L-1 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-1): 🟠 8 y
> 🟠 9 del auditor (`panel-trx-auditor.md`) y J1 del juez. Tres agujeros de HOY, cerrados ANTES de
> `{trx}` (L-2 en adelante). Sin decisiones nuevas del dueño: las dos que había (pool ≥ 2 declarado; el
> breaking de despliegue) están en `decisiones-dueno-2026-08-28.md`, «Decisión del 2026-09-01 (3)».

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l1-rojo-*.log`, `l1-verde-*.log`, `l1-mutante-*.log`, `suite-*.log`). Los mutantes se plantaron con
`sed`/`perl` y se restauraron en el MISMO comando (`grep -rc MUTANT src commands tests` = 0 al final; las
cuatro líneas mutadas verificadas a mano después).

## La regla que gobierna el lote, y un hecho que el juez dio por verificado y NO lo estaba

**La ESCRITURA va por la transacción del llamante; la AUTORIDAD (leer si hay freeze) NUNCA.** Implementado
tal cual. Pero el dictamen decía: *«el juez verificó que `readFreezeRow` ya corre bajo `guardSql` con
deadline, así que con pool 1 el resultado es 503 fail-closed, no un cuelgue»*. **Medido: era falso a
efectos prácticos.** El `timeout()` de knex que `guardSql` fija solo empieza a contar cuando la consulta
TIENE conexión; con el pool agotado (el llamante sostiene la única conexión de `:memory:`) la espera la
gobierna `acquireConnectionTimeout` de knex — **60 007 ms** medidos con un spike (`tests/l1_spike.spec.ts`,
borrado) para un deadline declarado de 300 ms. Un minuto de espera es un cuelgue con otro nombre. Por eso
las cuatro consultas del freeze (`read`/`acquire`/`renew`/`release`) van ahora bajo **`withDeadline`
(deadline TOTAL, espera del pool incluida) sobre `guardSql`** (`freezeSql` en `src/freeze.ts`), y el caso
de pool 1 afirma que el 503 llega **por el deadline de la barrera (400 ms del caso), no por el del pool**
(`elapsed < 5000`). La promesa del juez («503 fail-closed, no cuelgue») es verdad DESDE este lote, no antes.

## 🟠 8 · La barrera del freeze la decide el MOTOR, nunca el cliente del llamante

**Reproducción del auditor (C1), en rojo antes** — `tests/freeze.spec.ts`, grupo «L-1 · 🟠 8», caso «un cliente
inyectado que reporta "no congelado" NO deja pasar la escritura…»: con el freeze de A vivo, B notifica las
tres del árbol con `{ transaction: liar }` (un cliente cuyo `from().where().select()` devuelve la fila SIN
freeze) y las cuatro de hechos con `{ actor, transaction: liar }` (objeto no literal: `GrantOptions` no lo
declara y TS solo rechaza el literal fresco — exactamente lo que el cast de `#writeOptions` leía).
Rojo literal (`l1-rojo-sqlite-freeze.log`, y el mismo en PG y MySQL):
```
❯ L-1 · 🟠 8 — … / un cliente inyectado que reporta «no congelado» NO deja pasar la escritura (ni se le pregunta): 503 E_AUTHZ_FROZEN en scopes.* y en grant
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'
```
(la escritura ENTRÓ: ni `scopes.attached` ni `grant` lanzaron). Verde ahora: 503 `E_AUTHZ_FROZEN`
reintentable en las siete, `driver.calls = []` y **`liar.reads() === 0`** — a la transacción del llamante ni
se le pregunta.

**El caso de MySQL (REPEATABLE READ real) que no existía** — mismo grupo, caso «el snapshot del llamante… NO
ve un freeze posterior, y AUN ASÍ la escritura es 503»: se abre la transacción del llamante (callback de
`db.transaction`, con `isolationLevel: 'repeatable read'` en PG y MySQL —la misma forma que
`withSourceSnapshot`, 3b-6—), se fija la foto con una primera lectura de la fila `id = 2`, OTRO manager pone
la ventana del operador, y el caso afirma primero **el mecanismo del bypass** (la transacción sigue viendo
`freeze_reason = null`: verificado en MySQL, en PG con el nivel explícito y en `sqlite-file` con WAL) y
después que `grant`/`deny` con `{ actor, transaction: trx }` y `scopes.moved` con `{ transaction: trx }` son
503 `E_AUTHZ_FROZEN` con «authz:unfreeze» en el mensaje y cero llamadas al driver. Rojo literal en MySQL
(`l1-rojo-mysql.log`) y en PG (`l1-rojo-pg.log`):
```
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'
```
(el snapshot dijo «no congelado» y el `grant` entró). En `:memory:` el caso no puede montarse (una sola
conexión: no caben una transacción abierta y un freeze ajeno a la vez) y afirma la cara trivial: sin
freeze, `transaction` no cambia nada. Sin `skip`.

**Pool 1 ⇒ 503 con SU deadline, jamás un cuelgue** — caso «pool 1 (`:memory:`) + la transacción del llamante
abierta ⇒ 503 E_AUTHZ_BACKEND_TIMEOUT con SU deadline…»: manager con `freezeTimeoutMs: 400` (config nueva,
ver abajo), `scopes.attached` dentro de `db.transaction`. En `:memory:` ⇒ 503 `E_AUTHZ_BACKEND_TIMEOUT`,
`elapsed < 5000`, driver sin llamadas; en `sqlite-file`/PG/MySQL (pool ≥ 2) la barrera se lee por otra
conexión y la escritura ENTRA (`onScopeAttached`). Rojo antes (`l1-rojo-sqlite-freeze.log`):
```
ℹ AssertionError: ROJO: con pool 1 la barrera se leyó por la transacción del llamante (la escritura entró): expected null to not equal null
```

**El código que lo puso verde:**
- `src/freeze.ts`: `FreezeSqlOptions.client` **desaparece**; `readFreezeRow` lee SIEMPRE por `db`; `freezeSql`
  = `withDeadline(guardSql(...))` para las cuatro consultas; y **`assertNotFrozenRow(operation, { driver,
  nowMs, timeoutMs })`**, la barrera como función compartida (lee la fila, `freezeIsLive`, lanza
  `AuthorizationFrozenError` con el «la levanta authz:unfreeze» del operador).
- `src/manager.ts`: `#assertNotFrozen(operation)` sin parámetro `transaction` (delega en
  `assertNotFrozenRow` tras el atajo de `#heldFreeze`); **`#writeOptions` sin el cast** (`await
  this.#assertNotFrozen(operation)` a secas: `transaction` solo lo consumen `scopes.*` para ENCOLAR).
- `src/define_config.ts`: **`freezeTimeoutMs?: number`** (default 5000), el deadline total de la barrera; el
  provider lo pasa también al `RelationsManager`.
- `src/types.ts`: docblock de `ScopeTreeWriteOptions.transaction` (encolar ≠ escribir; la autoridad nunca
  viaja por ella; pool ≥ 2; 🟠 9) y de `ScopeOutboxContext.transaction`.

**Mutante** (`l1-mutante-8-sqlite.log`, `l1-mutante-8-mysql.log`): volver a leer la barrera por el cliente
del llamante (`readFreezeRow` con `options.client ?? db`, `#assertNotFrozen(operation, transaction)` y el
cast en `#writeOptions`). SQLite: **2 failed** (el cliente inyectado y el de pool 1 — «la escritura entró»);
MySQL: **2 failed** (el cliente inyectado y el snapshot REPEATABLE READ — `expected undefined to equal
'E_AUTHZ_FROZEN'`). Restaurado; `MUTANT` = 0.

**El caso existente que cambió a pool ≥ 2 (el breaking de despliegue esperado):** el grupo
«3b-2d · el rollback del consumidor, contra el servidor real» de `tests/scope_outbox.spec.ts` (tres casos:
SIN outbox ⇒ escalada persistente; CON outbox + rollback; CON outbox + commit) notifica `scopes.moved`
DENTRO de la transacción del consumidor con `{ transaction: trx }` en `:memory:` — y su propio comentario
decía «desde 3b-7 la barrera del freeze lee la fila compartida y con el pool de 1 esa lectura tiene que ir
por la conexión que el consumidor ya sostiene». Eso ERA el agujero. Ahora el grupo corre solo con
`OPENFGA_TEST_URL` **y `testEngine() !== 'sqlite'`** (`sqlite-file`/PG/MySQL, precedente
`freeze_multiprocess.spec.ts`), con el porqué escrito encima; en `:memory:` la cara de esa notificación es
el 503 del caso de pool 1 de `freeze.spec.ts`. Consecuencia en las cifras: `npm test` con OpenFGA pierde
esos 3 casos y gana los nuevos. Está dicho en el CHANGELOG como **breaking de despliegue**.

## 🟠 9 · `enqueue` sabe de quién es la transacción — UNA función, pensada para L-3/L-4

**La función reutilizable:** **`assertCallerTransaction(operation, transaction, { connection })`** en
`src/shared/transaction_guard.ts` (nuevo; `src/shared/` es donde viven las utilidades SQL compartidas que
`src/drivers/*` y `src/relations/` pueden importar). Devuelve el `trx` tipado (`CallerTransaction`) o
`undefined` si no llegó ninguno; 500 `E_AUTHZ_CONFIG` si (1) no tiene `.from()`/`.table()`, (2) es el `db`
de Lucid entero (`connection()`/`primaryConnectionName`), (3) no es una transacción ABIERTA
(`isTransaction !== true`: un `QueryClient` confirma cada sentencia sola) o (4) su `connectionName` no es
la conexión de quien escribe. Es la comprobación que L-3/L-4 tienen que llamar desde
`DatabaseAuthorizationDriver.grant/...` y `DatabaseRelationsDriver.relate/...` con SU `connection`.

**Reproducción del auditor, en rojo antes** — `tests/scope_outbox.spec.ts`, grupo «sqlScopeOutbox», caso
«L-1 · 🟠 9 · un `trx` de OTRA conexión ⇒ 500…»: se registra una segunda conexión Lucid
(`db.manager.add(other, {...config de la primaria})`), y (a) cola en la primaria + `trx` de `other`;
(b) cola con `connection: other` + `trx` de la primaria (el montaje exacto del auditor). Rojo literal
(`l1-rojo-sqlite.log`):
```
ℹ AssertionError: ROJO: el trx de otra conexión se aceptó y el encolado se fue a la base equivocada: expected 503 to equal 500
```
(en `:memory:` la otra base no tiene la tabla ⇒ 503 «ruidoso»; en PG/MySQL con la misma base habría
escrito en silencio — las dos caras que describía el auditor). Verde: 500 `E_AUTHZ_CONFIG` nombrando
`'<other>'` y `'<primaria>'`, `pending()` vacía en las dos direcciones.

Caso «pasar `db` entero (o un cliente que no es transacción) como `transaction` ⇒ 500…»: rojo literal:
```
ℹ AssertionError: ROJO: `db` entero pasó por transacción y el encolado se escribió fuera de toda transacción, en silencio: debería haber lanzado: expected null to not equal null
```
Verde: 500 con «db.transaction()» en el mensaje, también para `db.connection()`; `pending()` vacía; y el
control (el `trx` de la conexión de la cola) encola.

**Código:** `src/scope_outbox.ts` — `ownConnection` = `connection ?? database.primaryConnectionName`;
`clientOf` = `assertCallerTransaction('sqlScopeOutbox.enqueue', …) ?? on(database)`. El duck-check viejo
(y su mensaje) viven ahora dentro de la función compartida. Un `database` doble sin
`primaryConnectionName` sigue exigiendo una transacción, pero no juzga su conexión (documentado).

**Mutante** (`l1-mutante-9-sqlite.log`): `clientOf` devuelve `context?.transaction` tal cual ⇒ **2 failed**,
los dos casos, con las líneas rojas de arriba. Restaurado.

## 🟠 J1 · Las relaciones pasan la MISMA barrera, y `authz:relations:reconcile` corre bajo ventana durable

Elegí la **primera** opción del juez (ventana durable), no la frase «no se certifica».

**Barrera** — `src/relations/manager.ts`: `#assertNotFrozen(op)` = `assertNotFrozenRow('relations.<op>', {
driver: 'relations', nowMs: (clock ?? systemClock)().getTime(), timeoutMs })` como PRIMERA línea de
`relate`/`unrelate`/`purgeObject`/`purgeSubject` (antes de F-05, identidad y `assertWrite`: durante una
ventana una escritura se rechaza entera). Importa `../freeze.js` (raíz de `src/`): `check:purity` verde
(regla 2 intacta). `RelationsManagerOptions.freezeTimeoutMs`; el provider pasa `config.freezeTimeoutMs`.
Casos (`tests/freeze.spec.ts`, grupo «L-1 · 🟠 J1 — las escrituras de relations pasan la MISMA barrera…»):
con el freeze de un manager de ROLES vivo, las cuatro escrituras del `RelationsManager` (doble en memoria
con espía) ⇒ 503 `E_AUTHZ_FROZEN` `retryable`, cero escrituras, `check` sigue; `unfreeze` las devuelve; la
ventana del operador también congela y el mensaje dice «authz:unfreeze». Rojo literal
(`l1-rojo-sqlite-freeze.log`, ×2 casos):
```
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'
```

**Ventana durable del reconcile** — `reconcileRelations` no puede ver al manager de roles (regla 2), así que
la ventana la abre el COMANDO: `runRelationsReconcile(authorization, options)` exportada desde
`commands/authz_relations_reconcile.ts` (juzgable sin ace, como `relationsReconcileLines`): `dryRun` ⇒
`reconcileRelations` a secas (el verificador no congela); si no, `authorization.withFrozenWrites(reason,
fn, { kind: 'reconcile', operatorAsContext: true })` y el reporte gana **`frozen: { durable, lapsed,
leaseMs, fence }`** (`RelationsReconcileReport.frozen?`). Para eso `withFrozenWrites` (manager de roles)
acepta ahora `options: { kind?, operatorAsContext? }` y le pasa a `fn` la ventana (`FrozenWindow`:
`fence`, `leaseMs`, `lapsed()`) — aditivo: quien llamaba `withFrozenWrites(reason, () => …)` no cambia.
`relationsReconcileLines`: `frozen.lapsed` ⇒ línea de error «NO se certifica» y `clean = false`; sin
lapsed, línea de log con el fence (y «ventana del operador» si `leaseMs === null`). El comando captura
además el 423 `E_AUTHZ_FREEZE_HELD` como error de comando.
Casos (grupo «L-1 · J1 — authz:relations:reconcile corre bajo la ventana durable»): el ORIGEN sondea la
barrera desde `enumerateRelations` (otro `RelationsManager` intenta `relate` a mitad de pasada) ⇒ todas las
sondas `E_AUTHZ_FROZEN`, `frozen = { durable: true, lapsed: false, leaseMs: 15000, fence }`, la ventana se
suelta al terminar; `--dry-run` ⇒ sondas `null` y sin `frozen`; ventana del operador ⇒ corre dentro
(`frozen.fence` = el del operador, `leaseMs: null`, la ventana sigue en pie), y el freeze vivo de OTRA
pasada ⇒ 423. `tests/relations_reconcile_cli.spec.ts`: `lapsed: true` ⇒ error + no limpia; `false` ⇒
limpia con la línea del fence; sin `frozen` no se afirma nada.

**Mutante** (`l1-mutante-j1-sqlite.log`): sin barrera en `relations/manager.ts` (los cuatro `await` ⇒
`void`) y sin ventana en `runRelationsReconcile` (siempre `reconcileRelations`) ⇒ **4 failed**:
```
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'          (×2, la barrera)
ℹ AssertionError: ROJO: una escritura de relations entró durante la pasada de reconcile (sondas: [null]): expected false to be true
ℹ AssertionError: la pasada corrió dentro de la ventana del operador: expected undefined to equal 11
```
Restaurado.

## Docs

- **CHANGELOG** (`[Unreleased] — 2.4.0-alpha.2`, sección «Lot L-1», antes de L-0): **BREAKING (deployment)**
  primero —`scopes.*` con `{ transaction }` exige pool ≥ 2; en pool 1, 503 `E_AUTHZ_BACKEND_TIMEOUT` a
  `freezeTimeoutMs`; el porqué (la autoridad no puede compartir snapshot con el llamante)—; después
  problema → decisión → qué NO se hace, por hallazgo, incluida la medición de los 60 s de knex.
- **README**: párrafo nuevo en «The tree outbox» (las dos reglas de la transacción: autoridad por la
  conexión del motor + pool ≥ 2 + `freezeTimeoutMs`; `assertCallerTransaction` y los tres 500); en la
  sección del freeze, «What it DOES freeze since 2.4.0-alpha.2: the relations engine too» y que la lectura
  por la transacción del llamante se fue; en `authz:relations:reconcile`, la ventana durable, `lapsed` y
  que `--dry-run` no congela; fila de `E_AUTHZ_CONFIG` en la tabla de errores. El caso de la LETRA del
  README (`freeze.spec.ts`, 3b-7) sigue verde.

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, corridas a fichero)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ · `npm run check:purity` ✔ · `npm run build` ✔.

| modo | base (L-0) | ahora | log |
|---|---|---|---|
| `npm test` (SQLite memoria) | 1020 | **1028 passed (1028)** | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1025 | **1036 passed (1036)** | `suite-sqlite-file.log` |
| `npm run test:pg` | 1119 | **1130 passed (1130)** | `suite-pg.log` |
| `npm run test:mysql` | 1119 | **1130 passed (1130)** | `suite-mysql.log` |

+11 casos nuevos en cada modo (freeze +8, outbox +2, CLI +1); en `:memory:` además −3 (el grupo del rollback
contra el servidor real, gateado a pool ≥ 2) ⇒ 1020 − 3 + 11 = 1028. Aditivo: ningún caso existente cambió
de resultado; el único que cambió de MODO es ese grupo, y está dicho. Cero rojas transitorias en las cuatro
corridas finales. Stores del `:8101` al terminar: `{"stores":[]}`.

**Una corrección a mitad, dicha:** la primera corrida de `:memory:` dio 1024, no 1028, porque el gate lo
había puesto sobre el `if (openFgaTestUrl)` entero de `scope_outbox.spec.ts`, que además del grupo del
rollback contiene el de «3b-2h · las reproducciones del auditor R2» (4 casos que NO usan `{ transaction }`).
El gate se movió al grupo del rollback solo (`if (testEngine() !== 'sqlite') test.group(...)`), y las cuatro
cifras de la tabla son de las corridas sobre el árbol final (PG y MySQL repetidas después del cambio).

## Ficheros tocados

- `src/freeze.ts` — sin `client`; `freezeSql` (deadline total); `assertNotFrozenRow`; docblock del módulo.
- `src/manager.ts` — `#assertNotFrozen(operation)`; `#writeOptions` sin cast; `withFrozenWrites(reason, fn(window), options)`; `FrozenWindow` exportado.
- `src/define_config.ts` — `freezeTimeoutMs`.
- `src/relations/manager.ts` — barrera en las cuatro escrituras; `freezeTimeoutMs`.
- `src/relations/reconcile.ts` — `RelationsReconcileReport.frozen?`.
- `src/shared/transaction_guard.ts` — **nuevo**: `assertCallerTransaction`, `CallerTransaction`.
- `src/scope_outbox.ts` — `ownConnection` + `clientOf` por la función compartida.
- `src/types.ts` — docblocks de `transaction` (árbol y outbox).
- `providers/authz_provider.ts` — pasa `freezeTimeoutMs` a relations.
- `commands/authz_relations_reconcile.ts` — `runRelationsReconcile`; líneas de `frozen`; 423 como error de comando.
- Tests: `tests/freeze.spec.ts` (+8: 🟠 8 ×3, J1 ×2, reconcile ×3; `worker()` admite config extra),
  `tests/scope_outbox.spec.ts` (+2 🟠 9; el grupo del rollback contra el servidor real gateado a pool ≥ 2),
  `tests/relations_reconcile_cli.spec.ts` (+1).
- `README.md`, `CHANGELOG.md`.

## Lo que NO hice, y por qué

- **No añadí `transaction` a `GrantOptions`/`RelationWriteOptions` ni ninguna capacidad**: es L-2. Aquí solo
  se cierra que el campo no declarado se CONSUMA (el cast). Hoy un `{ actor, transaction }` en `grant` se
  ignora por completo (no decide nada y no escribe por él); el rechazo ACTIVO (500 `E_AUTHZ_UNSUPPORTED`)
  es la puerta 1 de L-2.
- **`assertCallerTransaction` no se exporta desde `index.ts`**: nadie fuera del paquete la necesita hasta
  que L-3/L-4 la usen en los drivers; se exporta desde `src/shared/`.
- **Los drivers de relaciones no leen el freeze** (la barrera es del manager, como en roles);
  `relationsManager.driver()` sigue siendo la salida documentada. `check`/`list*`/`membersOf` no se
  congelan (lecturas).
- **`syncAuthzCatalog` sigue sin congelarse** (sin cambios respecto a 2.3; fuera del lote).
- **El deadline de la barrera no es por llamada**: es `freezeTimeoutMs` del config (uno para los dos
  motores). Bastó para el caso «con deadline propio y corto».
- **No toqué `CLAUDE.md`** (el CHANGELOG y el README llevan el detalle; si el dueño quiere, la frase del
  freeze del mapa gana «y desde L-1 también `relations/`»).
- **El caso del snapshot en `sqlite-file`** demuestra el mecanismo con WAL (verificado verde), aunque el
  juez solo pedía MySQL; en PG hace falta pedir el nivel explícitamente (su default es READ COMMITTED), y
  el caso lo pide.
