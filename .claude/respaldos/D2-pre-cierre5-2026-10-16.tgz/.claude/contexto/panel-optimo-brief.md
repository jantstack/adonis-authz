# Panel «paquete óptimo» — brief del coordinador (2026-10-16)

## Petición del dueño
«Quiero que este paquete sea lo más óptimo posible en todos los ámbitos»: máxima flexibilidad, máxima seguridad, máximo rendimiento. Analizar todo lo necesario.

## Situación
- `@jantstack/adonis-authz`, publicado hasta `2.5.0-alpha.2`. Plan 2.5: `0 → A → B → D → C → RC → 2.5.0` (ver `.claude/contexto/RETOMAR.md`, `decisiones-dueno-2026-08-28.md`, `linajes.md`, `CLAUDE.md`).
- D1 en commit `75353fe`. D2 + cierres 1–4 en el árbol SIN commit (verificado: 2046/2074/2171/2173, guardia 181/181, banderas 37/37, runbook ×2). El último repaso del auditor (`loteD2-auditor-cierre4.md`) es NO APTA: D4-1 🟠, D4-2/D4-3 🟡.
- Causa raíz de los cierres 2–4: en OpenFGA no se puede borrar y escribir la MISMA clave de tupla en un `Write` (medido M5: 400 `cannot_allow_duplicate_tuples_in_one_request`, ver `panel-tenencia-2-analista.md` §M5), así que renovar una caducidad/condición son dos `Write` con ventana fail-open. Todo lo de `renewal-unsafe`, `withheld-by-unsafe-deny`, `carrier-conflict`, `deny-conditional` y el TOCTOU de N1 nace de ahí.
- Hipótesis del coordinador (NO medida): «make-before-break» — que la tupla renovada tenga una clave DISTINTA (dos ranuras equivalentes por relación, p. ej. `member`/`member_alt`, la relación es la unión; u objetos de indirección por membresía), y renovar = write(clave nueva) + delete(clave vieja) en UN `Write` atómico ⇒ `atomicRenewal: true` en openfga ⇒ desaparece la familia entera.
- Coste de verificación creciente: guard-mutants pasó de ~6,5 min a ~17,5 min por la fuerza bruta con vigencia.

## Reglas para todos los miembros del panel
- SOLO LECTURA sobre el repo. Nada de commit, ni editar `src/`, `tests/`, README, CHANGELOG. Escribe solo tu informe en `.claude/contexto/` y scripts en `.claude/reproducciones/`.
- OpenFGA: solo stores efímeros en `http://localhost:8090` con prefijo propio, BORRADOS al acabar. Prohibido `docker restart`, prohibido correr los gates completos (`verify.sh`, guard-mutants, flag-mutants). Puedes correr specs sueltos con SQLite `:memory:`.
- Entorno: `source ~/.config/nvm/nvm.sh && nvm use 22`.
- Toda afirmación con evidencia (fichero:línea, medición con cifra, o fuente oficial con URL). «No aplica» solo con evidencia.
