# Sublote D2 — cierre 2: decisiones sobre `loteD2-auditor-cierre.md` (re-ataque, 2026-10-15)

Verificación PROPIA del cierre 1 de D2: **1987 / 2015 / 2112 / 2114** (2/2/1/1 sk.), guard-mutants 171/171, flag-mutants 37/37,
runbook ×2 verde. Re-ataque: 🟠 1/🟠 2 del auditor cerrados (🟠 2 como DECLARADO), 🟡 3 cerrado. **Nuevos: 🟠 N1, 🟡 N2, 🟡 N3, 🟡 N4,
⚪ N5, ⚪ N6.** L10 está PROMOVIDO (decisión del dueño §2026-10-15 (8)): N1 y N3 son su 5.ª aparición y su falsación ⇒ cierre ESTRUCTURAL.

## 🟠 N1 · `relate` de `openfga` renueva con dos `Write` (delete, write): una membresía que transporta un deny desaparece en el hueco
**Decisión del dueño 2026-10-15 (9): RECHAZAR la renovación.** En `openfga`, `relate` sobre una tupla EXISTENTE cuyo cambio exige
delete+write (caducidad distinta) ⇒ si la tupla es una membresía `group:*#member` y **ese grupo (el userset `g#member`) es sujeto de
algún deny vivo en la partición** ⇒ **409** con código propio (p. ej. `E_AUTHZ_RENEWAL_UNSAFE`) y CERO escrituras, con la letra: por
qué (M5: OpenFGA no reemplaza la misma clave en un `Write`), qué hacer («`unrelate` + `relate` aceptando la ventana de forma explícita,
o retirar antes el deny»). Coste: una lectura de denies del userset por renovación de membresía (solo cuando hay renovación). Las
membresías sin deny, el resto de tuplas y todo `database` siguen igual. **Además, honestidad del camino que queda en dos `Write`**
(renovaciones permitidas): si el 1.er `Write` (delete) entró y el 2.º falla ⇒ `markPartialWrite` + evento `indeterminate: true`
(hoy 503 «sin escribir» y sin evento: letra ≠ efecto). Reconcile `database → openfga` que necesita renovar una membresía portadora:
el plan lo clasifica (L9) como residuo con motivo propio (`renewal-unsafe`) y receta, nunca escribe a medias; la línea del comando
nunca dice «sin escribir nada» si escribió. Gemelo: roles (`grant` con caducidad distinta en `facts`): comprobar si renueva en dos
`Write` y si un `assignee` renovado puede transportar algo que corte (el deny de roles es `denied_<P>` sobre el scope, no viaja por
el assignee: escribir «no aplica porque…» con evidencia o cerrar igual). Casos: concurrencia con espía-barrera (check entre los dos
`Write` nunca `true` porque ya no hay dos `Write`), fallo del 2.º `Write` en una renovación permitida ⇒ parcial + evento; mutantes.

## 🟡 N3 · Las escrituras van antes que toda la poda: un ex-miembro compone con un allow nuevo (falsea la frase universal de L10)
**Cierre estructural, no residuo**: el orden total de `tuple_order.ts` se reordena para que TODO estado intermedio esté acotado por
inicial ∪ final en lo que concede. Orden candidato (derivarlo y demostrarlo): (1) escribir denies nuevos; (2) borrar allows sobrantes
(no-`group`); (3) escribir membresías nuevas; (4) borrar membresías sobrantes; (5) escribir allows nuevos; (6) borrar denies sobrantes.
**La garantía se DEMUESTRA por fuerza bruta**: un spec puro sin servidor que, sobre un universo pequeño (2 usuarios, 2 grupos con
anidamiento de 1 nivel, 2 objetos, 1 relación con deny, allows directos/por grupo, denies directos/por grupo), enumera TODOS los pares
(inicial, final) relevantes (o una muestra exhaustiva acotada y declarada), aplica el orden con la semántica de `database` (corte de
camino), y comprueba en CADA prefijo que lo concedido ⊆ concedido(inicial) ∪ concedido(final) y que ningún sujeto denegado en inicial
y final concede. Este spec es la entrada de L10 en la guardia (propiedad `relations.order.exhaustive`) con mutantes del orden que lo
ponen rojo; sustituye la confianza en tablas a mano. La purga (borrado puro) y el reconcile usan la misma función. README/CHANGELOG/título
de la guardia dicen exactamente lo demostrado; si queda un residuo (N2), con su frase exacta y su caso.

## 🟡 / ⚪
| # | Decisión |
|---|---|
| 🟡 N2 | Frase del residuo corregida («el otro grupo solo necesita transportar un deny, no ser mixto») — o desaparece si el orden de N3 lo elimina (lo dirá la fuerza bruta). |
| 🟡 N4 | `provision --store-id` tras retirar un opt-in con > 1 M tuplas queda bloqueado para siempre: el recuento de `denied_*` vivos se hace en STREAMING (página a página, sin cargar en memoria ni cota de 1 M) o, si la cota se mantiene, bandera `--max-tuples` como en `reconcile` (con su caso de efecto en flag-mutants). Nunca un exit 1 perpetuo sin salida. |
| ⚪ N5 | Letra del recuento antes de publicar: «estrecha la ventana, no la cierra; el paso 0 (flota a `'read'`) es lo que la cierra». |
| ⚪ N6 | La guardia L9 ve el residuo `deny-conditional` (y el nuevo `renewal-unsafe`). |

Reglas: rojo → verde → mutante; cuatro líneas para N1 y N3; CHANGELOG `[Unreleased]` («Closure 2 of sublot D2»; bloques publicados
intactos); verificación 4 modos + 3 gates en PRIMER PLANO, nada en segundo plano al terminar. Informe `loteD2-informe-cierre2.md`.
Sin commit, sin `version`, sin push.
