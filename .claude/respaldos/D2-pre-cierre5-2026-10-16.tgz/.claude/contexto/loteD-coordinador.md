# Lote D (plan 2.5) — brief del coordinador (2026-10-15) ⇒ `2.5.0-alpha.3`

**Base:** `main` en `493c649` (= `v2.5.0-alpha.2`, publicada). Rama en la salida: `main`. Un solo agente muta el árbol por vez;
sin commit, sin tocar `version`, sin `git push` (los hace el coordinador).

**Entrada cumplida** (juez ronda 2, fila D): D3, D5, D6, D8, D9, D10 firmadas (§2026-10-14 (2)); **M6 medida** (`m6-medicion.md`);
lote B integrado. **Sin panel nuevo**: el diseño está en `panel-tenencia-2-juez.md` (§1, §3 D3, §4 R2-1/H2/D7, fila «D» de la tabla
de lotes ~l.322, «Decisiones del DUEÑO»), `panel-tenencia-2-analista.md` §4 (diseño fichero a fichero 4.1–4.9), `panel-tenencia-2-
tester.md` §2 (T1: tabla de 64 estados con corte de camino), §3 «Lote D» (D-01…D-31), §5 (L9 = S1…S18 del tester, la guardia de
INVERSIÓN DEL SIGNO), §6 (migración), §7 (casos que se ponen rojos), y `panel-tenencia-2-auditor.md` (R2-1…R2-15).
**Ojo de numeración:** el «L9» del tester (§5, S1–S18, inversión del signo) NO es el linaje L9 de `linajes.md` (clasificación en
el punto equivocado, decisión §2026-10-15 (7)). Los dos entran en D: el primero en D1/D2 según la fila, el segundo en D2.

**Decisiones de esta ronda que ajustan el diseño del panel** (ganan sobre el texto del panel donde choquen):
- **D3**: deny SIN caducidad en v1. `deny(…, { expiresAt })` ⇒ 422 con la razón medida (M5: FGA rechaza delete+write de la misma
  clave). D-19 del tester se REESCRIBE a ese 422; S7 desaparece; S1/S2/D-25 (renovación) no aplican (no hay renovación).
- **D9**: `decideMany(subject, relation, objects, partition) ⇒ ('allow'|'deny'|'none')[]` AMPLIO e igual en los dos drivers, con las
  MISMAS garantías que `checkMany` (respuesta de COGNITIV 2026-10-15): tope 50 (`RELATIONS_CHECK_MANY_MAX` o hermano), `[]` ⇒ 422,
  error de un ítem ⇒ 503 TOTAL (nunca `none` por ítem: S15), orden de salida = entrada, `alignBatchResults` compartida.
  **Caso nombrado de COGNITIV (P-2)**: «decideMany para un holder de otra organización responde por la partición del objeto», y su
  gemelo en `check`/`checkMany`.
- **M6 ⇒ S12 obligatoria por CAMINO**: espía que QUITA `context` en `check`, `checkMany`, `decideMany`, `listObjects` ⇒ 503 (jamás
  T/F/`none`), un mutante por camino. Y el caso del deny TRANSPORTADO por una membresía de grupo con caducidad (vivo ⇒ deny,
  caducado ⇒ el allow vuelve) en los dos drivers.
- **D10**: opt-in en dos fases (fase 1 = el modelo publica `denied_<rel>` y las lecturas lo honran, `deny` ⇒ 422; fase 2 = escrituras).
- **D14**: `modelId` fijado obligatorio con un tipo deny activo en `openfga` (500 al construir/resolver si falta).
- **D15**: capacidad `relationDenies?` opcional, normalizada a `false`, con su par (D-28).
- **D8**: `database` honra `denied_*` SIEMPRE (también sin opt-in: una fila deny es un hecho).

## Partición en dos sublotes (cada uno con su auditor y cierres; se publica `alpha.3` tras D2)

**D1 · núcleo del deny** (lo que un consumidor llama):
config (`deny: true` por tipo, ≤ 43 chars en tipos denegables, sin `*`, sobre `group` ⇒ 422, fases D10; D-17, D-18, D-29 byte a byte
para tipos sin deny), generación del modelo (`denied_<rel>`, `but not`), `deny`/`removeDeny`/`listDenies` en manager + 2 drivers +
doble (F-05, puerta trx, freeze, `#write`, actor, partición: **filas nuevas en la guardia de superficie con sus mutantes**, nacen rojas),
`check` con CORTE DE CAMINO (D5; T1 de 64 estados como COMÚN + 37 filas PAR en el BRIDGE), `checkMany` sin cambio de contrato pero
honrando el deny, `decideMany` (D9 + P-2), `listObjects` resta (D-15, S16 con `:8103`), `listSubjects` NO resta (D-15), purgas
borran denies con orden (D-16, D-26, S3), D8, D14, D-31 (modelo fijado sin `denied_*` ⇒ 500 al usar), S12, S13, S14, S15, eventos
`deny`/`removeDeny` (D-20; R2-14: la frase «un handler que trate todo lo que no sea unrelate como alta concede de más»), D-22/D-23/D-24,
D-28, D-30. Filas declaradas S8–S10 en README con caso.

**D2 · migración y operación** (lo que un operador corre):
reconcile con `kind` (`relationTupleKey` ya lo lleva), puerta por driver DESTINO (S6: origen con denies y destino sin capacidad o sin
opt-in en ese tipo ⇒ 500 con CERO escrituras, jamás `skipped`), orden de escritura (denies primero; poda: allows antes que denies;
S4, S5), **guardia L9 (linaje): clasificador del plan por reflexión sobre las clases 422 del puerto**, `--dry-run` con deriva de deny,
reporte parcial por partición, guarda de `openfga:provision` con `--allow-drop-deny` (bandera `pending` del flag-mutants ⇒ juzgada) y
barrido, S11 (pod con modelo viejo), S17 (rollback < 2.5 con denies vivos PROHIBIDO, D12: fila declarada + paso del runbook),
los dos pasos `pending` del runbook (opt-in en dos fases; rollback prohibido), D-27 (T3 por el kernel), README §Upgrading
(«provision → fijar modelId → desplegar», el orden que COGNITIV escribirá en su runbook) y auditoría de sistema (punto 9).

## Entorno (medido)
`source ~/.config/nvm/nvm.sh && nvm use 22`; `OPENFGA_TEST_URL=http://localhost:8090` (`:8101` NO responde); `TEST_PG_URL=
"postgres://postgres:$(docker exec postgres18 printenv POSTGRES_PASSWORD)@127.0.0.1:5432/authz_test"`; `docker restart openfga-dev &&
sleep 8` antes de cada suite. Para S16 (tope): `docker run -d --name openfga-tiny -p 8103:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3
-e OPENFGA_LIST_USERS_MAX_RESULTS=3 -e OPENFGA_DATASTORE_ENGINE=memory openfga/openfga:v1.19.0 run`, y `docker rm -f openfga-tiny` al
terminar. Partida (alpha.2): **1734 / 1762 / 1859 / 1861** (2/2/1/1 skipped); guard-mutants 112/112; flag-mutants 36/36 (2 pending);
runbook verde ×2 (2 pasos pending).

## Reglas (CLAUDE.md «Cómo se decide un cambio», 1–11)
Rojo observado antes de cada pieza → verde → mutante. Cuatro líneas de cierre por pieza grave. Toda operación nueva nace roja en la
guardia (punto 11). `EXPECTED_FUSED` y `migration_stub.spec` **sin tocar** (D-29: un tipo sin deny genera el modelo de alpha.10 byte a
byte). CHANGELOG `## [Unreleased]` (problema → decisión → qué NO). Verificación final 4 modos + 3 gates.

## Addendum para D2 (2026-10-15, tras cerrar D1 en `75353fe`)
Partida D2 (medida por el coordinador): **1895 / 1923 / 2020 / 2022** (2/2/1/1 skipped); guard-mutants **160/160**; flag-mutants
36/36 (pending `--allow-drop-deny` ⇒ D2 lo juzga; `--prune-undeclared` sigue pending ⇒ C); runbook ×2 verde (2 pasos pending ⇒ D2
los convierte en pasos reales). Informes de D1: `loteD1-informe.md`, `loteD1-informe-cierre.md`, `loteD1-informe-cierre2.md`.
Además de lo listado arriba en «D2», entra:
- **Linaje L9 (decisión del dueño §2026-10-15 (7))**: test por reflexión sobre TODAS las clases de error 422 del puerto de
  relaciones (incluidas las nuevas de D1: `E_AUTHZ_RELATION_NOT_DENYABLE`, la de `expiresAt` en deny, etc.) que exige un
  clasificador en `planPartition`/`classifyDestinationRow` con bucket + `details` para cada una; un 422 nuevo sin clasificar
  nace rojo con su nombre. `RELATION_422_REASONS` (cierre 3 del lote B) se deriva de ese mismo registro o se cruza con él.
- **Gemelo de roles de N3 (cierre 2 de D1)**: el 400 «too many tuples» en `projectCatalog`/`reconcile` del driver de roles ⇒ 500
  `E_AUTHZ_CONFIG` con letra (hoy 503 que parece transitorio).
- **Orden de `purgeScope` (roles, `facts`) como propiedad de la guardia** (candidato a linaje L10, `linajes.md`): mismo patrón
  que `openfga.purge.order` de D1; si el estado intermedio puede conceder, cierre; si no, caso que lo fije.
- Hoy `relations:reconcile` cuenta las filas `denied_*` como `undeclared` (D1 §6): el reconcile con `kind` lo sustituye.
