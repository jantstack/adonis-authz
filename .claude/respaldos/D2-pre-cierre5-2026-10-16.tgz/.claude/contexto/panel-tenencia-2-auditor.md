# Panel tenencia · ronda 2 — auditor (atacante) del plan «una sola línea, 2.5.0»

> Fecha: 2026-10-14. Rol: atacante. Objetivo: `panel-tenencia-2-coordinador.md` (24 líneas). Leí: mi informe de la ronda 1,
> el juez, `linajes.md`, `CLAUDE.md` §«Cómo se decide un cambio» (1–10), `roadmap-2.0.md` §2.5, README §Relations y
> §cutover (1036–1132), y código de alpha.10: `src/relations/define_relations_config.ts`, `src/relations/reconcile.ts`,
> `commands/authz_relations_reconcile.ts`, `commands/openfga_provision.ts`, `src/relations_config_store.ts`,
> `src/drivers/{database,openfga}_relations_driver.ts`, `src/drivers/openfga_driver.ts` y `stubs/migration.stub`. No ejecuté
> nada contra `:8101`. También consulté `npm view` (dist-tags: `latest: 1.1.0`, `alpha: 2.4.0-alpha.10`).
> Marcas de evidencia: ✅ lo vi en el código · 🟡 depende de la implementación · ❓ no verificado.

## Veredicto en una línea

**Inseguro tal como está.** El ORDEN de los lotes es correcto: D antes que C, y la guardia L1 primero. Lo que falla es la
**transición**. El plan trata el deny como una característica y no como un **cambio de signo de la flota**. Hay tres
estados intermedios en los que se concede de más:

- un despliegue con pods de dos versiones;
- volver a una versión ≤ 2.4;
- desactivar el opt-in.

Ninguno de los tres está en el plan. Además, la mitigación de mi 🔴 1 (`decideMany` + nota en el README) ha desaparecido del
plan.

---

## Hallazgos (por severidad)

### 🔴 R2-1 · El plan publica deny SIN ninguna primitiva capaz de «deny gana» en cadena: el 🔴 1 de la ronda 1 vuelve a estar abierto
- **Escenario:** en alpha.1 se publica `checkMany` booleano y COGNITIV empieza su fase 0 con él; su §7 escribe literalmente
  «`checkMany` sobre la cadena y deny gana». Llega alpha.2 con deny. COGNITIV pone `deny(org#member, viewer, Nóminas)`.
  Con el allow en Finanzas, `checkMany(U, viewer, [informe, Nóminas, Finanzas])` devuelve `[F, F, T]`, el evaluador
  concede y su suite pasa, porque el caso «deny en el mismo objeto» sí funciona.
- **Evidencia:** ✅ `panel-tenencia-2-coordinador.md:9-10` (lote A: `checkMany` booleano) y `:11-14` (lote D). El lote D no
  contiene `decideMany` ni la frase del README que el juez exigía («un booleano por objeto no puede implementar deny gana a
  lo largo de una cadena externa»; juez §«Caso Nóminas»). Tampoco recoge el mensaje `inherits=false`.
- **Steelman:** «La herencia es del consumidor y D5 (corte de camino) ya es lo restrictivo». **¿Me convence?** No. El
  corte de camino actúa dentro de UN objeto. El fallo está entre objetos, y la única primitiva publicada para recorrer la
  cadena es la booleana.
- **Mitigación mínima:** el lote D entrega `decideMany` (tri-estado) + la frase del README + el caso; o bien el README dice
  que el deny NO sirve para cadenas externas.
- **Caso que lo fija:** *«deny en Nóminas con allow heredado de Finanzas: la primitiva PUBLICADA de cadena devuelve deny en
  Nóminas»*, en los dos drivers. Y en BRIDGE: *«con checkMany booleano el mismo escenario es indistinguible»*, para fijar la
  limitación declarada.

### 🟠 R2-2 · Despliegue con pods de dos versiones: el opt-in `deny: true` mezcla «modelo nuevo» y «se aceptan escrituras de deny», y hay una ventana en la que el deny se ignora en AMBOS drivers
- **Escenario `database`** (el driver activo hoy en COGNITIV): un despliegue progresivo de 2.4.0-alpha.10 → 2.5.0-alpha.2
  con `deny: true` en el mismo deploy.
  1. Un pod nuevo acepta `deny(U, viewer, D)` y responde éxito.
  2. Los pods de alpha.10 resuelven `check` con `relation IN expandDown(R)`, así que la fila `denied_viewer` no la mira
     nadie ⇒ `true`.
  3. La ventana dura todo el despliegue.
- **Escenario `openfga`:** cada pod fija `OPENFGA_MODEL_ID`, y lo comparten roles y relaciones. Un pod con el id viejo
  evalúa `Check` con el modelo viejo, donde `viewer` no tiene `but not denied_viewer`, y la tupla de deny se ignora. **Esto
  corrige al juez (conflicto 3):** que la relación pública sea «la propia» NO cierra el escenario A de mi 🟠 4. Lo que decide
  es el id de modelo de cada pod, no el nombre de la relación.
- **Lo que SÍ resiste:** un pod de alpha.10 con el id NUEVO es seguro en `openfga`, porque la resta la hace el servidor. Y
  el orden contrario (escritores de deny antes de publicar el modelo) falla cerrado: el modelo fijado no tiene
  `denied_viewer`, FGA responde 400 y el driver devuelve 503.
- **Evidencia:**
  - ✅ `database_relations_driver.ts:585-607` (el `check` de alpha.10 no conoce `denied_*`).
  - ✅ `openfga_relations_driver.ts:233` y `openfga_driver.ts:699` (`authorizationModelId: options.modelId`).
  - ✅ `openfga_provision.ts:141-164` (cada publicación da un id nuevo que el operador copia al `.env`).
- **Steelman:** «Pasa con toda feature nueva: se documenta en §Upgrading». **¿Me convence?** Solo para dejarlo en 🟠 y no
  en 🔴, porque la ventana está acotada por el despliegue. No para dejarlo como documentación: con un solo interruptor no
  existe una secuencia segura, salvo parar toda la flota.
- **Mitigación mínima:** dos interruptores, o tres fases documentadas y ejecutadas:
  1. publicar el modelo;
  2. TODA la flota con el código de 2.5 (`database`) o con el id nuevo (`openfga`);
  3. solo entonces se aceptan escrituras de deny.

  Además, el driver nuevo rechaza `deny` (500) si su modelo fijado no declara `denied_<rel>` para ese tipo.
- **Casos:**
  - *«driver openfga con modelId sin denied_<rel> y tipo con opt-in: arranque o deny ⇒ 500, cero escrituras»*;
  - *«dos instancias del driver sobre el mismo store, modelId viejo y nuevo: el runbook de upgrade no habilita deny hasta
    que…»*, como paso del job `cutover-runbook` (CLAUDE.md punto 9).

### 🟠 R2-3 · Volver a ≤ 2.4.0-alpha.10 (rollback) hace desaparecer todos los denies sin ruido
- **Escenario:** un incidente tras subir a 2.5 y se vuelve a alpha.10.
  - (i) `database`: el `check` de alpha.10 ignora todas las filas `denied_*` ⇒ todo deny deja de bloquear.
  - (ii) `defineRelationsConfig` de alpha.10 **descarta en silencio** la clave `deny: true` del tipo: copia solo
    `type`/`relations`, sin rechazar claves desconocidas (L5). El arranque no protesta.
  - (iii) Si el pipeline del rollback ejecuta `openfga:provision --store-id` con el binario viejo, publica un modelo SIN
    `but not`. Con un pod que no fija el modelo, el cambio es instantáneo; con el id fijado, en el siguiente cambio de env.
    Las tuplas `denied_*` quedan huérfanas.
  - (iv) `authz:relations:reconcile` de alpha.10 migra los allows y salta los denies como `skipped.undeclared`. Sale con
    exit ≠ 0, pero el destino ya está escrito y el operador lee «no declarada», no «deny perdido».
- **Evidencia:**
  - ✅ `define_relations_config.ts:300-307` (`frozenTypes` copia solo `type` y `relations`);
  - ✅ `reconcile.ts:403-406` y `:299-310`;
  - ✅ `database_relations_driver.ts:856-872` (`enumerate` filtra por TIPO declarado, no por relación ⇒ emite
    `relation: 'denied_viewer'`).
- **Steelman:** «No se garantiza volver a una alpha». **¿Me convence?** A medias. Es razonable no garantizarlo, pero hay que
  decirlo con un procedimiento: el rollback es la respuesta estándar a un incidente.
- **Mitigación mínima:** §Upgrading dice «no hay vuelta a < 2.5 con denies vivos» y da un comando o consulta que cuente los
  denies vivos (exit ≠ 0 si hay alguno) como paso previo al rollback.
- **Caso:** el de letra en `relations_events_docs`/upgrade: el README nombra el conteo previo. Y en la COMÚN: *«reconcile
  de 2.5 clasifica un deny como deny, nunca como undeclared»*.

### 🟠 R2-4 · Quitar `deny: true` de un tipo con denies vivos los apaga todos en silencio (y vuelven a la vida si se reactiva)
- **Escenario:** el consumidor quita el opt-in de `document` (refactor, prueba, otra rama del config) y republica.
  - El modelo nuevo ya no tiene `denied_viewer`: FGA no evalúa esas tuplas y todo deny de `document` deja de bloquear. El
    comando dice «success».
  - En `database`, depende de que la resta esté condicionada al opt-in: si lo está, se rompe la paridad.
  - Al reactivarlo, los denies viejos resucitan (fallo cerrado, pero sorpresa: es el mismo agujero que el «barrido de lo
    no declarado» de `roadmap-2.0.md` §2.5).
- **Evidencia:** 🟡 depende del diseño del opt-in. ✅ `openfga_provision.ts` publica desde el config estático y no lee el
  store.
- **Steelman:** «Es un cambio de config consciente». **¿Me convence?** No: el efecto es fallo abierto y en silencio.
- **Mitigación mínima:** `openfga:provision` (y el arranque) con un tipo sin opt-in y tuplas `denied_*` vivas de ese tipo ⇒
  500 que las nombra. Y `database` resta las filas `denied_*` con independencia del opt-in (el opt-in solo gobierna las
  escrituras).
- **Caso:** *«retirar el opt-in con denies vivos ⇒ 500 en provision; check sigue false en los dos drivers»*.

### 🟠 R2-5 · El reconcile con opt-in POR TIPO: la salida del 🔴 3 es por capacidad de DRIVER, y la ruta actual convierte un 422 en `skipped`
- **Escenario:** origen `database` con un deny de `document` y destino `openfga`, cuyo modelo fijado (o cuyo config) no
  tiene opt-in en `document`. La capacidad del driver (`relationDenies: true`) es estática, así que pasa la regla «destino
  sin capacidad ⇒ 500».
  1. Se escribe primero el deny: el destino responde 422 (o 400 ⇒ 503).
  2. El patrón actual `relateOrSkip` absorbe el 422 como `skipped.undeclared` y sigue.
  3. A continuación escribe los allows ⇒ el destino concede, con exit ≠ 0 y la etiqueta equivocada.
- **Agravante:** el `--dry-run` no lo ve. Su `toConfig` es la spec PERSISTIDA de `authz_relations_config`, que no escribe
  nadie en producción: `saveRelationsConfig` no tiene llamador. No es ni el modelo fijado ni el config estático.
- **Evidencia:**
  - ✅ `reconcile.ts:296-310` (el 422 del destino se cuenta y se descuenta, sin `throw`);
  - ✅ `commands/authz_relations_reconcile.ts:467-469` (`readRelationsConfig().catch(() => undefined)`: si falla la lectura,
    no hay control de deriva, en silencio);
  - ✅ `relations_config_store.ts:14-22` (el republicador se retiró en 4-8).
- **Steelman:** «Denies primero: si el deny falla, se aborta antes de los allows». **¿Me convence?** Solo si el fallo
  ABORTA. Con la ruta actual no aborta.
- **Mitigación mínima:** la capacidad de deny del destino se decide POR TIPO y contra el modelo que usa el destino, en la
  fase de PLAN y antes de escribir nada ⇒ 500. Ningún deny pasa por `relateOrSkip`.
- **Caso:** *«reconcile de un deny hacia un destino sin opt-in en ese tipo ⇒ 500 con cero escrituras; un deny jamás en
  skipped.*»*, más la fila T3 equivalente en `--dry-run` (sale como deriva).

### 🟠 R2-6 · P2 «respeta deny»: con `Read` sin filtro de relación, un objeto con SOLO un deny aparece en «Compartido conmigo»
- **Escenario:** U no tiene ningún allow sobre D y tiene `deny(U, viewer, D)`. La especificación del juez para `openfga` es
  `Read({user, object:'type:'})` **sin filtro de relación**, que devuelve `document:D#denied_viewer@user:U`. En `database`,
  `WHERE subject = U` también devuelve la fila. Si el filtrado en cliente «resuelve includes» y recoge los ids de objeto,
  o si «respeta deny» se implementa como resta de los denies DIRECTOS de la misma lectura, quedan dos agujeros:
  - D aparece en el listado (fuga del título o la miniatura de justo lo que se quiso ocultar);
  - el deny vía `org#member` no se resta (mi 🟠 10a).
- **Evidencia:** ✅ texto del juez §P2 («sin filtro de relación, y filtrado en cliente») y `coordinador:15-16` («respeta
  deny», sin decir cómo). 🟡 depende de la implementación.
- **Steelman:** «P2-5 verifica los candidatos con batchCheck». **¿Me convence?** Sí, si está en el plan. No lo está.
- **Mitigación mínima:** los candidatos se toman solo de relaciones declaradas (nunca `denied_*`) y cada candidato se
  verifica con `check`/`batchCheck`. Un error en un ítem ⇒ 503.
- **Casos:**
  - *«U con solo un deny directo sobre D ⇒ D no aparece»*;
  - *«viewer directo + deny a group:G#member con U miembro ⇒ D no aparece»*;
  - *«error en un ítem del batchCheck de P2 ⇒ 503»*;

  en los dos drivers.

### 🟠 R2-7 · El 422 de alias se promete en «las 8 operaciones»: `checkMany` (alpha.1) y P2 se quedan fuera
- **Escenario:** el allow se escribe con la partición canónica y el deny también. El evaluador llama a
  `checkMany(U, viewer, [D], org|<uuid SIN guiones>)`. Si `checkMany` no canoniza ni rechaza, compone otro id de objeto:
  no ve el deny y tampoco el allow ⇒ hoy `false`. Pero basta un allow escrito con la ortografía rara (el escenario de mi
  🟠 8) para que dé `true`. Lo mismo vale para `partitions` de P2, y para `deny`/`removeDeny`/`listDenies`, que son
  operaciones nuevas y no están entre «las 8».
- **Evidencia:** ✅ `coordinador:13` («⇒ 422 en las 8 operaciones (D4)»). `checkMany` sale en alpha.1 (`:10`), ANTES de D4.
- **Steelman:** «La guardia L1 por reflexión las encontrará». **¿Me convence?** No. La guardia del lote 0 es de F-05, no de
  la canonización. Esa columna no existe.
- **Mitigación mínima:** la canonización es una columna más de la guardia de superficie (todo método que recibe partición)
  y entra ya en alpha.1 para `checkMany`.
- **Caso:** *«un alias de la partición jamás evade un deny: check, checkMany, decideMany, P2, deny/removeDeny/listDenies»*,
  enumerado por reflexión.

### 🟠 R2-8 · La ventana de renovación del 🔴 2 tiene una segunda puerta: el `toUpdate` del reconcile
- **Escenario:** `reconcile.ts:306-309` reescribe con `relateOrSkip` las tuplas cuya caducidad difiere (`toUpdate`). Para
  un deny en `openfga` esto es la misma secuencia delete+write en dos `Write` (`openfga_relations_driver.ts:425-435`). Hoy
  ocurre contra un destino ACTIVO solo con `--allow-stale-source`; mañana, en cualquier pasada de mantenimiento que se
  añada.
- **Evidencia:** ✅ los dos ficheros citados. `coordinador:14` dice «caducidad según medición (D3)» sin nombrar las puertas.
- **Steelman:** «En el cutover el destino aún no está activo». **¿Me convence?** Para el cutover, sí. No para las pasadas
  con `--allow-stale-source` ni para el futuro sello del driver activo (roadmap §2.5).
- **Mitigación mínima:** la decisión de D3 (atómico, ventana declarada con `indeterminate`, o deny sin caducidad) se aplica
  a TODA renovación de deny: API y reconcile.
- **Caso:** la celda S1b de la tabla de abajo.

### 🟡 R2-9 · C antes que D abre una ventana. D antes que C la cierra en el paquete, pero no en el consumidor
- Detalle en la sección (c). Severidad 🟡 en el orden del plan (D → C) y 🟠 si se invierte.

### 🟡 R2-10 · El verificador de roles valida contra el ÚLTIMO modelo, y los pods usan el FIJADO
- **Escenario:** a mitad de la ventana de cutover se publica el modelo con deny, y en el mismo despliegue cambia `catalogs`.
  `modelPermissions()` lee `readLatestAuthorizationModel()`, mientras los pods siguen en el id fijado. La pasada de roles
  certifica un permiso que el modelo de los pods no tiene, o salta uno que sí tiene. Las dos cosas fallan cerradas (400 ⇒
  503, o proyección ausente ⇒ deniega), pero el verificador queda limpio sobre un modelo que nadie usa.
- **Evidencia:** ✅ `openfga_driver.ts:2692-2699`.
- **Caso o regla del runbook:** el modelo no se republica dentro de la ventana; o bien el verificador lee el modelo
  `options.modelId`.

### 🟡 R2-11 · El techo de bytes es compartido: el opt-in de deny se come margen del catálogo de roles
- **Escenario:** COGNITIV, cerca del techo (691 permisos), activa deny en 3 tipos. `openfga:provision` responde 500
  `E_AUTHZ_MODEL_TOO_LARGE` y el siguiente `authz:catalog:sync` que añada un permiso queda bloqueado. Falla cerrado, pero
  bloquea el cutover.
- **Evidencia:** ✅ `assertFactsModelPublishable(..., relations)` mide el modelo FUSIONADO. El paso 3 del plan lo mide ✅;
  falta convertirlo en una cifra del README y en un caso.
- **Caso:** *«catálogo al techo + opt-in ⇒ 500 en provision, cero requests»*.

### 🟡 R2-12 · `relationTupleKey` de alpha.1 tiene que dar la MISMA clave de un allow en alpha.2
- Si D cambia el formato (por ejemplo, añade `|allow`), las tablas de `meta` del consumidor indexadas con claves de alpha.1
  quedan huérfanas y la auditoría «grantedBy» se falsea.
- **Caso:** un literal de oro (*«la clave de un allow es byte a byte la de alpha.1»*).

### 🟡 R2-13 · Falta una medición: una tupla condicional en la rama restada SIN `current_time`
- **Escenario:** mi ⚪ 18 de la ronda 1 sigue sin medir y no está en la lista del paso 3 (`coordinador:11-12`). Si OpenFGA
  omite la tupla de deny cuando falta el parámetro de la condición, cualquier camino nuevo (`checkMany`, `decideMany`,
  `ListObjects` de P2) que olvide `context` falla ABIERTO. ❓ No lo verifiqué.
- **Mitigación:** añadirla al paso 3, y un mutante «quitar `context`» por cada camino nuevo (celda S7).

### 🟡 R2-14 · Los eventos con `operation` ensanchado alimentan índices del consumidor
- **Escenario:** un manejador escrito contra alpha.10 (`if (op === 'unrelate') quitar; else añadir`) mete un `deny` en el
  índice local de «Compartido conmigo». Es justo el índice duplicado que COGNITIV mantiene hasta tener P2. Con D → C, ese
  índice vive una release más con denies dentro. TypeScript no avisa: ensanchar una unión no rompe `if/else`.
- **Caso:** de letra en `relations_events_docs` (F3/F10 reescritos), con la frase «un handler que trate todo lo que no sea
  unrelate como alta concede de más».

### ⚪ R2-15 · Letra
- `CLAUDE.md:913` dice «Criterio de `2.4.0` estable». El plan aplica ese punto a 2.5.0 sin reescribirlo.
- `roadmap-2.0.md` §2.5 ya tiene contenido (sello durable del driver activo, `backendId`, reporte parcial K particiones,
  barrido de lo no declarado). El plan no dice si entra en 2.5.0. El límite L6 (dos factories sobre el mismo backend) con
  deny significa que un `--prune` desde un origen rancio borra denies nuevos del activo: es fallo abierto.
- `README.md:637-642` describe `republishFusedModel` con CAS, que se retiró en 4-8 (`relations_config_store.ts:14-22`).
  §Upgrading del deny se apoyará en «quién publica el modelo»: hay que corregirlo antes.
- La cabecera `README.md:377` «`resourceAccess` (2.5)» choca con el nombre de la versión 2.5.0.
- `latest` en npm sigue en `1.1.0`.

---

## (a) Deny y P2 en la misma línea que el cutover de roles de COGNITIV

| Pregunta | Respuesta | Evidencia |
|---|---|---|
| ¿Un bump del modelo por deny invalida un cutover a medias? | **No invalida las tuplas.** El deny no cambia los tipos directamente asignables (`viewer: [user with not_expired, group#member]` sigue igual), así que lo ya escrito sigue siendo válido. **Sí desalinea los verificadores:** el de roles lee el ÚLTIMO modelo (R2-10) y el de relaciones lee la spec persistida (R2-5). Y el id nuevo hay que llevarlo a TODOS los pods: el `OPENFGA_MODEL_ID` es uno para roles y relaciones. **Regla:** no publicar el modelo dentro de la ventana; publicarlo y desplegarlo ANTES del `authz:freeze`. | ✅ `openfga_driver.ts:2693`, `authz_relations_reconcile.ts:469`, `openfga_relations_driver.ts:233` |
| ¿Se pisan el reconcile de hechos y el de relaciones? | **No por tipo:** desde alpha.9 roles solo gobierna `OWN_FACTS_OBJECT_TYPES`, y `document#denied_viewer` es ajeno (ni `extra` ni se borra con `--prune`). **Sí por el techo de bytes** (R2-11) y por el modelo compartido (fila anterior). | ✅ `openfga_driver.ts:3501`, `:3519` |
| ¿Cambia el runbook? | **Sí, en cinco pasos:** (1) antes del freeze: modelo con deny publicado y TODA la flota con el id nuevo (R2-2); (2) la pasada de relaciones escribe denies primero, POR TIPO con capacidad y 500 si no la hay (R2-5); (3) el `--dry-run` compara `kind` y una deriva de deny (deny en origen, sin `denied_<rel>` en el modelo del destino) sale como deriva; (4) `deny`/`removeDeny` bajo freeze ⇒ 503 (columna L3; un deny perdido en la ventana es fallo abierto tras el cambio, igual que un `unrelate`); (5) la vuelta a `database` sigue siendo atómica, pero rollback a < 2.5 está prohibido con denies vivos (R2-3). **El job `cutover-runbook` de CI** (CLAUDE.md punto 9) siembra denies directos, vía grupo y temporales, y comprueba `check = false` después del cambio. Si no, «runbook verde» no certifica nada del deny. | — |
| ¿Y COGNITIV, con su propia migración y verificador (`authz:cutover:relations`, `authz:cutover:verify`)? | Su bucle usa `runRelationsReconcile`, así que hereda el arreglo. Su **verificador «por API»** está escrito contra los tipos de alpha.10. Si compara `enumerateRelations` por (sujeto, relación, objeto) sin `kind`, un deny y un allow con la misma clave le parecen iguales: con `kind?` opcional, ese código no se entera. Pregunta C6 abajo. | `cognitiv-informe-5-cutover.md` §5 |

## (b) Upgrade de 2.4.0-alpha.10 a 2.5.0-alpha.2 con deny opt-in: estados intermedios

| Estado | `database` | `openfga` | ¿Concede de más? |
|---|---|---|---|
| Modelo nuevo publicado; flota en alpha.10 con id viejo; nadie escribe deny | — | sin efecto | No |
| Modelo nuevo; pods en alpha.10 SIN `modelId` fijado (flotan al último) | — | evalúan el modelo nuevo y restan bien | No ✅ |
| Escritores de 2.5 con deny ANTES de publicar el modelo | escribe | 400 ⇒ 503 | No (cerrado) ✅ |
| Despliegue progresivo: un pod de 2.5 escribe deny y uno de alpha.10 hace `check` | **SÍ**: el SQL de alpha.10 ignora `denied_*` | **SÍ** si el pod tiene el id viejo fijado; no si tiene el nuevo | **R2-2** |
| alpha.10 `listObjects` | **SÍ** (SQL viejo) | resta el servidor si el id es el nuevo | R2-2 |
| alpha.10 `listSubjects` | no resta, por invariante (correcto) | ídem | No |
| alpha.10 `enumerateRelations` + reconcile | emite `relation: 'denied_viewer'` ⇒ `skipped.undeclared`, migra los allows | ídem | **SÍ** en el destino (R2-3) |
| alpha.10 `reconcile --prune` con `denied_*` sobrante | `unrelate` ⇒ 422 de F-05, sin capturar ⇒ la pasada muere | ídem | No (cerrado) |
| alpha.10 `purgeSubject`/`purgeObject` | borra también los `denied_*` (todo) | sin orden (🟠 7) ⇒ una purga cortada deja allows sin deny | **SÍ** si se corta |
| alpha.10 `defineRelationsConfig` con `deny: true` | descarta la clave en silencio | ídem y `provision` publica sin `but not` | **SÍ** (R2-3) |
| Opt-in retirado con denies vivos | depende de si la resta depende del opt-in | FGA ignora las tuplas | **SÍ** (R2-4) |
| Driver de terceros compilado contra alpha.10: `capabilities().relationDenies` vale `undefined` | si se lee `!== false` ⇒ el manager llama a un `deny` inexistente (500); si se lee `=== true` ⇒ false | — | No, si se fija `=== true` (celda S12) |
| semver: `^2.4.0-alpha.10` | NO casa con `2.5.0-alpha.x` (prerelease en otra tupla) | — | No ✅. Sí cambia `@alpha` a secas: anunciarlo |

## (c) ¿C antes o después de D?

- **C → D (C primero): hay ventana.** P2 se publica sin filtro de deny (todavía no hay denies). En el despliegue progresivo
  de D, un pod con la versión de C atiende «Compartido conmigo» mientras un pod de D escribe denies ⇒ lista objetos
  denegados. Además, P2 se diseña con el camino barato (Read + filtro en cliente) y el de D tiene que reescribirlo y
  cambiar la promesa de coste (L8). 🟠
- **D → C (el orden del plan): el paquete nunca publica una P2 sin deny.** Ninguna versión con P2 deja de conocer los
  denies, así que no hay ventana en el paquete. Quedan dos ventanas que no cierra el orden:
  - la implementación de «respeta deny» (R2-6), que es permanente y no de tiempo;
  - el índice local de COGNITIV, que vive una release más alimentado por eventos con `operation` ensanchado (R2-14).

  Respuesta: **D antes que C es lo correcto**, con R2-6 como criterio de aceptación de C y R2-14 como letra de D.

## (d) L9 «inversión del signo del fallo» como guardia M7: la tabla de inyección

**Propiedad universal:** *ningún fallo inyectado en una operación que escribe, borra, migra o lee un deny deja `check = true`
donde, sin el fallo, sería `false`; el fallo acaba en el deny vigente, en 503/500, o en un evento `indeterminate: true`, y
nunca en «no ocurrió»*.

**Forma M7:** una tabla `{fallo × operación}` recorrida por reflexión (todo método que toca un deny tiene fila), con un
mutante por celda que la pone en rojo. Sin fila ⇒ rojo. Exenciones firmadas.

| # | Fallo inyectado | Operación(es) | Resultado exigido | Caso que lo fija | Mutante que tiene que morir |
|---|---|---|---|---|---|
| S1a | 2.º `Write` caído (503, no timeout) | `deny` renovado (openfga) | deny vigente, o 503 + evento `indeterminate: true` | P1-R2 | «delete y write en dos llamadas sin marca» |
| S1b | ídem | `reconcile` `toUpdate` de un deny | ídem; la pasada no cuenta `updated` | P1-R2-reconcile (R2-8) | «renovar en reconcile por `relate` genérico» |
| S1c | timeout en el `Write` de deny | `deny`, `removeDeny` | 503 + `indeterminate`; nunca éxito | inv. 13 extendido | «clasificar el deadline como error genérico» |
| S2a | muerte tras el lote k de `deleteTuples` | `purgeObject` (openfga) | ningún allow vivo sin su deny | P1-21 | «borrar en el orden de `Read`» |
| S2b | ídem, con varios tipos × ortografías | `purgeSubject` (openfga) | allows de TODO el barrido primero, denies al final (no por lote) | P1-21b | «ordenar por lote y no global» |
| S3a | muerte a mitad de la pasada | `reconcile` (escritura) | denies escritos antes que cualquier allow, en cada partición | T3 | «allows primero» |
| S3b | muerte a mitad de la pasada | `reconcile --prune` | allows borrados antes que cualquier deny | T3 | «denies primero al podar» |
| S3c | destino sin opt-in en ese tipo, o modelo fijado sin `denied_<rel>` | `reconcile` | 500 en la fase de plan, cero escrituras; jamás `skipped` | R2-5 | «422 del destino ⇒ `relateOrSkip`» |
| S3d | driver de terceros que no marca `kind` | runner + reconcile | el runner no pasa (censo) | T3 «tercero sin kind» | «censo que solo cuenta» |
| S4 | reloj ±Δ en el proceso que decide | `check`, `checkMany`, P2, reconcile `skipped.expired` | un solo `now` por operación; la vigencia del deny se mide con el MISMO reloj que la del allow | P5-3, K9 | «`systemClock()` en un método de decisión» |
| S5 | alias de partición (sin guiones, mayúsculas) | TODO método con partición (incl. `checkMany`, `decideMany`, P2, `deny`/`removeDeny`/`listDenies`) | 422 con cero llamadas, o forma canónica; nunca `true` | R2-7 | «quitar la canonización de un método» (por reflexión) |
| S6 | pod con modelo viejo / modelo sin `denied_<rel>` | arranque y `deny` (openfga) | 500 antes de escribir | R2-2 | «no leer el modelo fijado» |
| S7 | `context`/`current_time` ausente | todo camino que evalúa en FGA (`check`, `batchCheck`, `ListObjects`, P2, `decideMany`) | `false` o 503; nunca `true` | ⚪ 18 + medición (R2-13) | «quitar `context` en el camino X» |
| S8 | `error` en UN ítem del lote | `checkMany`, `decideMany`, verificación de P2 | 503 para todo el lote; nunca `false`/`none`/«incluido» | P4-3 extendido | «error ⇒ false» (en `decideMany`, «error ⇒ none» es fallo abierto) |
| S9 | `ListObjects` cortado (tope o deadline) | `listObjects` | la exclusión la evalúa el servidor; nunca resta en cliente | P1-13/14 contra `:8103` | «restar denies en cliente con un 2.º `ListObjects`» |
| S10 | re-deny con `expiresAt` omitido sobre un deny temporal | `deny` (y `on_duplicate: ignore`, si se usa ❓) | permanente (D3) + `previousExpiresAt` | P1-12 | «preservar como `relate`»; «ignorar duplicado con condición distinta» |
| S11 | escritura bajo freeze / con `{transaction}` | `deny`, `removeDeny` | 503 / 500 con cero llamadas | columnas L2/L3 de la guardia | «quitar la barrera en `deny`» |
| S12 | capacidad ausente (`undefined`) | manager ante un driver de terceros | se trata como `false` ⇒ 500 `E_AUTHZ_UNSUPPORTED`, nunca llamada | P1-cap | «`!== false`» |
| S13 | sujeto userset de un tipo del consumidor; objeto `group`; `*` | `deny` (los dos drivers) | 422 | 🟠 9, P1-18, P1-17a | «aceptar el par declarado» |
| S14 | opt-in retirado con denies vivos | `openfga:provision`, arranque | 500 que nombra las tuplas | R2-4 | «publicar sin mirar el store» |
| S15 | `includes` en ciclo | `defineRelationsConfig` | 422 | unitario `A⊇B⊇A` | «solo autoinclusión» |
| S16 | grant fuerte + deny débil (corte) | `check` en las 3 relaciones | la tabla T1 reescrita (corte) | P1-M (64 estados), P1-6d | CAMINO |

S4 es en parte NO-OBS: el desfase entre procesos no se observa. La celda fija el reloj ÚNICO por operación, y el resto se
declara.

## (e) ¿Están mis mitigaciones de la ronda 1 en el plan del coordinador?

| Ronda 1 | En el plan | Falta (fichero:línea) |
|---|---|---|
| 🔴 1 booleano en cadena | **No** | `decideMany`, frase del README y caso Nóminas: `panel-tenencia-2-coordinador.md:11-14` (R2-1) |
| 🔴 2 ventana de renovación | Parcial: «medición» (`:11-12`) + «caducidad según medición (D3)» (`:14`) | la rama de salida si no es atómico (`indeterminate` o sin caducidad) y la segunda puerta del reconcile (R2-8): `:14` |
| 🔴 3 reconcile sin `kind` | Sí: `kind`, censo, órdenes (`:12-13`) | capacidad POR TIPO decidida en el plan, sin `relateOrSkip` (R2-5); poda con `removeDeny`, no `unrelate`; `--dry-run` con deriva de deny: `:12-13` |
| 🟠 4 nombre nuevo / pods viejos / usersets | Parcial: «propia relación» (`:12`) | el despliegue con `modelId` fijado (R2-2) y el caso «deny sobre una relación usada en un userset, en paridad»: `:12` y `:14` (§Upgrading) |
| 🟠 5 `includes` | Sí: corte de camino D5 (`:12`) | la matriz P1-M / T1 reescrita como criterio de aceptación: `:12-14` |
| 🟠 6 `expiresAt` omitido | Sí (`:14`) | `previousExpiresAt` en el resultado: `:14` |
| 🟠 7 purga sin orden | Sí: «purga openfga ordenada» (`:13`) | que el orden sea GLOBAL en `purgeSubject` (tipos × ortografías), no por lote (S2b): `:13` |
| 🟠 8 alias de partición | Parcial: «8 operaciones» (`:13`) | `checkMany` (alpha.1), P2, `deny`/`removeDeny`/`listDenies`, y la columna en la guardia (R2-7): `:10` y `:13` |
| 🟠 9 userset de tipo del consumidor | **No** (`group` como OBJETO = 422 es otra cosa) | 422 en las escrituras de deny en los dos drivers: `:12-13` |
| 🟠 10 P2 | Parcial: solo holders (`:15`) | userset ⇒ 422 con caso; el sujeto sale de la sesión (README); verificación de candidatos con `batchCheck` (R2-6); `partitions: []` ⇒ 422: `:15-16` |
| 🟠 11 L1 | Sí: lote 0 (`:8`) | las columnas L2/L3 recogen `deny`/`removeDeny` por reflexión (está en el juez; confirmarlo al cerrar D): `:8` |
| 🟡 12 deadline de `ListObjects` | Sí: medición (`:11-12`) | — |
| 🟡 13 reloj | Sí: `createTestClock` (`:9`) | P5-2 (no mutar el singleton) y P5-3 (`clock.spec` en drivers de relaciones): `:9` |
| ⚪ 17 ≤ 43 | Sí (`:12`) | — |
| ⚪ 18 rama restada sin contexto | **No** | añadirla a las mediciones (R2-13): `:11-12` |
| Juez: ciclos de `includes` | Solo como medición (`:12`) | RECHAZARLOS en `defineRelationsConfig` es condición de entrada de D, no algo que medir: `:11-12` |

## Lo que intenté y NO se rompió

- **Que el reconcile de roles borre o cuente los denies de relaciones:** no. `document#denied_*` está fuera de
  `OWN_FACTS_OBJECT_TYPES` ⇒ `foreign` (✅ `openfga_driver.ts:3501-3541`).
- **Que el bump del modelo invalide tuplas ya escritas:** no, mientras el deny no toque los tipos directamente asignables
  (🟡: es una condición de la implementación; un literal de oro sobre `directly_related_user_types` lo fija).
- **Escribir deny antes de publicar el modelo:** falla cerrado (400 ⇒ 503).
- **Un pod de alpha.10 con el modelo NUEVO en openfga:** resta bien (lo evalúa el servidor).
- **Colisión `denied_` + 43 en la columna:** cabe (`relation varchar(50)`, ✅ `stubs/migration.stub:205`).
- **Que el rango semver `^2.4.0-alpha.10` arrastre a 2.5.0-alpha:** no lo hace (prerelease en otra tupla).
- **`--prune` de alpha.10 frente a `denied_*` sobrante:** muere con el 422 de F-05 (cerrado; ruidoso, no silencioso).
- **Colisión entre `scope#denied_<P>` de roles y `document#denied_<rel>`:** son tipos distintos en FGA, no hay colisión.

## Preguntas abiertas para el arquitecto (las que cambian el veredicto)

1. ¿El opt-in separa «el modelo declara `denied_<rel>`» de «se aceptan escrituras de deny»? Sin esa separación, R2-2 no
   tiene secuencia segura.
2. En `database`, ¿la resta de `denied_*` depende del opt-in o es incondicional? Esto decide R2-4 y la paridad.
3. ¿Qué lee el reconcile para decidir si el destino admite deny en un tipo: el modelo FIJADO del destino, el config o la
   spec persistida? Solo la primera opción cierra R2-5.
4. ¿Entra `decideMany` en D? Si no, ¿el README declara que el deny no sirve para cadenas externas? (R2-1)
5. ¿Hay una ruta de rollback soportada desde 2.5 con denies vivos? (R2-3)
6. **A COGNITIV (C6, nueva):** ¿vuestro `authz:cutover:verify` compara tuplas sin `kind`? ¿Vuestros manejadores de
   `onRelationWrite` tratan como alta todo lo que no sea `unrelate`?

Fuente consultada sobre la semántica de `Write` en OpenFGA (no concluyente sobre delete+write de la misma clave; por eso
sigue como medición del paso 3):
- [OpenFGA · Transactional writes](https://openfga.dev/docs/interacting/transactional-writes)
- [OpenFGA · Update relationship tuples](https://openfga.dev/docs/getting-started/update-tuples)
- [openfga/java-sdk PR #234 (`on_duplicate`/`on_missing`)](https://github.com/openfga/java-sdk/pull/234/files)
