# Análisis de la respuesta de COGNITIV al plan 2.5 (2026-10-15)

Fuente: `cognitiv-respuesta-plan25-2026-10-15.md` (copia de `api-cognitiv/notas-internas/respuesta-paquete-authz-2026-10-15.md`).
Veredicto: **aceptan plan y calendario; las 13 respuestas confirman las decisiones firmadas D3–D16; nada reabre un lote.**
Tres peticiones nuevas, clasificadas abajo. Datos útiles que entran en el plan:

| Dato | Efecto en el plan |
|---|---|
| Versión fijada EXACTA (`2.4.0-alpha.10`, sin `^`) | C6 cerrado: las rupturas del lote B no les llegan solas. Nota de release basta. |
| Detección D4 en desarrollo: 0 tuplas no canónicas de 65; producción pendiente (lo ejecuta su owner antes de subir a alpha.1) | La receta de tres ramas cumple; si > 0 usan `--rekey`. Esperar su cifra de producción. |
| `sqlScopeOutbox` ya con `requireTransaction: true`; usersets solo `group#member`; `includes` lineales; claves de spec solo `objectTypes`/`holderTypes` | **B1, B2, B3, B6 no rompen a COGNITIV.** Lo único que adaptan en alpha.2 es el import de `runRelationsReconcile` (B7). |
| `listObjects` acotado a una partición, miles de `tenancy_node` posibles; `truncated` ⇒ 503 en su evaluador | Confirma B4 y la regla «lista truncada ⇒ denegar». Petición 3 = la misma forma en `listObjectsForSubject`. |
| `OPENFGA_MODEL_ID` hoy opcional; en alpha.3 lo hacen obligatorio con `openfga`; `provision` lo ejecuta el operador a mano desde el contenedor, una vez por instalación y por cambio de modelo | Cuadra con D14 (`modelId` fijado obligatorio con deny activo) y con la guarda de `provision` del lote D. El runbook de D debe decir «provision → fijar `modelId` → desplegar» en ese orden. |
| Deny solo en `tenancy_node` (`manager ⊇ editor ⊇ viewer`, ≤ 11 caracteres); nunca sobre `group`; sin caducidad | Cuadra con D3 y el 422 de deny sobre group. Ningún caso extra. |
| Semántica de corte de camino aceptada; `decideMany(subject, relation, objects, partition) → ('allow'|'deny'|'none')[]` con tope 50, `[]` ⇒ 422, error de ítem ⇒ 503, orden = entrada | Cuadra con D5 y D9. **Entra como requisito explícito de D**: mismas garantías que `checkMany` (reusar `alignBatchResults` y el 422 `E_AUTHZ_CHECK_MANY_BATCH` o su hermano). |
| Hooks: `assertWrite` solo mira la forma y no distingue acciones; `onRelationWrite` un único evento con `action`; eventos propios de deny en alpha.3 | Cuadra con R2-14 (eventos ensanchados con letra). |
| `authz:cutover:verify` delega en nuestro reconcile y solo clasifica residuo | `relationTupleKey` con `kind` no les rompe nada (confirmado). |
| Baja de organización: barrido propio paginado con `enumerateRelations*` + `purgeObject`/`purgeSubject` por tupla, bajo candado y estado `purging`; «agotar presupuesto sin agotar cursor lanza» | Es exactamente el riesgo «censo fuera de la transacción» que señalamos. Origen de la petición 1. |
| RC: proponen que coincida con el final de su F0 (evaluador escrito); fecha la fija su owner | D16 (7 días) sigue; la fecha queda pendiente de ellos. |

## Las tres peticiones

| # | Petición | Clasificación | Recomendación del coordinador |
|---|---|---|---|
| P-1 | `purgePartition(partition, options)`: una partición entera con prueba de conjunto vacío o `E_AUTHZ_PURGE_INCOMPLETE` | **Operación NUEVA del puerto de relaciones** (aditiva, capacidad opcional por D15). Tiene gemelo exacto en roles: `purgeScope(scope)` con demostración de cero (S6). Hoy `purgeObject`/`purgeSubject` demuestran cero por tupla; la partición entera no existe. | **Panel antes de implementar** (punto 2) y **entra en el lote C** (que ya toca la enumeración por partición y el cursor `(partition_key, object_uuid)`), como capacidad `?:` con su par; `database` en una transacción; `openfga` por lotes de `Write.deletes` con barrido y demostración de cero (`Read` vacío), orden global como las purgas del lote D. Alternativa: 2.6 opt-in. Riesgo que el panel debe medir: particiones de miles de tuplas en FGA (lotes de 100 deletes, deadline, abortada a medias ⇒ punto 8 de CLAUDE.md: antes/durante/después/abortada/repetida). **Decisión del dueño pendiente: ¿C o 2.6?** |
| P-2 | `decideMany` para un holder de otra partición (invitado) responde por la partición del objeto; que la suite común lo nombre | **Ya es cierto por construcción**: un holder es `{type, uuid}` sin partición (`RelSubject`); solo los usersets llevan partición y se cortan por string. `check`/`checkMany` ya responden por la partición del objeto. | Entra en el lote D como **caso nombrado de la suite común** («decideMany para un holder de otra organización responde por la partición del objeto») + su gemelo en `check`/`checkMany` si no existe ya con ese nombre. Coste ≈ 0,5 h. |
| P-3 | `truncated` de `listObjects` también en `listObjectsForSubject` (alpha.4), misma forma | Cubierta por la **propiedad universal de B4/M8** («toda enumeración que se puede cortar devuelve `truncated` o lanza») y por la fila «enumeración» de la guardia. | Entra en el lote C como condición de salida (la fila de la guardia la exige sola si P2 pasa por el envoltorio de lista del driver). Coste ≈ 0. |

## Qué cambia en los lotes
- **B (en curso):** nada. Confirmación de que solo B7 les toca.
- **D:** + requisito explícito «`decideMany` con las garantías de `checkMany`» (ya en D9, ahora con letra de COGNITIV); + caso P-2; runbook con el orden «provision → fijar modelId → desplegar»; esperar la cifra de D4 en producción antes de su subida a alpha.1 (no bloquea nada nuestro).
- **C:** + P-3 como condición; + P-1 si el dueño lo aprueba (panel propio dentro del de C).
- **RC:** fecha pendiente de COGNITIV (final de su F0).
