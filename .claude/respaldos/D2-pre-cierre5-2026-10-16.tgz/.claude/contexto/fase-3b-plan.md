# Fase 3b · Driver `openfga` = modo `facts` + `authz:reconcile` — plan (2.3)

> Base: Fase 3 cerrada (`f81c443`; auditor **APTA** en `fase-3-verificacion-auditor-3g.md`). Es **la fase que el dueño pidió**: simetría real — todo en un driver o todo en otro, con migración idempotente y bidireccional (`decisiones-dueno-2026-08-28.md`, DECISIÓN FINAL).
> Diseño ya validado contra el servidor real en el panel 2 (`panel2-2026-08-28-arquitectura.md`: 53/53 invariantes; `panel2-2026-08-28-juez.md`: modelo **(c2)** + 8 mitigaciones). **No se rediseña: se implementa.**
> Reglas de siempre: rojo→verde por pieza; suites en los 4 modos + `:8101` + tope 3; sin skip; errores con `status`+`code`; juez con nivel `'2.3'`; informe incremental en ruta absoluta.

## Lote 3b-0 · Simplificar antes de añadir (primero, y borra código)

Conclusión del análisis de la Fase 3: **cinco lotes tocaron `scopes.detached` y tres regresiones nacieron ahí**, siempre por composición. El requisito que las genera (un rol huérfano es indeleteable y bloquea el slug global) se resuelve más simple.

| # | Pieza | Decisión |
|---|---|---|
| **Z1** | **Rol dormido en vez de purga en cascada** | Un rol cuyo owner no resuelve queda **dormido**: ya es invisible y no concede nada; se añade que **deje de bloquear la comprobación de colisión** (`#assertNoRoleCollision` ignora los roles cuyo owner no resuelve). `scopes.detached` vuelve a purgar **solo hechos** (invariante 11 de siempre). Se borran: policy de rango en `detached`, enumeración de descendientes para roles, interacción con la degradación, semántica de `truncated` para roles, y `#assertAboveOwnedRoles`. |
| **Z2** | **`authz:catalog:prune-orphans`** | Comando de **plataforma** (no una escritura que dispara un tenant, que es lo que metía el rango en la ecuación): lista y borra roles cuyo owner no resuelve, con `--dry-run` por defecto y `--force`. Evento `onCatalogWrite` por rol. |
| **Z3** | **Prueba de que sobraba** | Los cuatro casos de composición del juez (W4) y los de S1/S2/W1/W2 deben **seguir verdes o volverse innecesarios**; los que dejen de aplicar se borran explicando por qué en el informe. Si alguno se pone rojo, Z1 está mal y se para. |

## Lote 3b-1 · Deuda heredada de la Fase 3 (del auditor, `fase-3-verificacion-auditor-3g.md`)

| # | Origen | Qué |
|---|---|---|
| **D1** 🟡 | auditor 3G | La reparación por ensombrecimiento exige superar el rango **del squatter**: con ranks no monótonos (rank 60 en una unit bajo un admin de rank 50) el dueño del árbol no puede y el recurso es la plataforma. **Corregir la frase de X1** en README/CLAUDE.md. |
| **D2** 🟡 | auditor 3G | `#shadowedBelow` con `resolveChain(otherOwner) === null` trata «no demostrable» como «no hay sombra» ⇒ W3 es fail-open en esa ventana. Debe **rechazar** (o exigir rango igual). Nota honesta: el mismo atacante logra lo mismo **yendo primero**, sin trampa. |
| **D3** 🟡 | auditor 3G | «Sobre un rol solo actúa quien lo supera en rango» **no es un invariante**: es comprobación de escritura, y `scopes.moved` crea sombras sin juicio de rango. Reescribirlo así en `CLAUDE.md`, README y CHANGELOG. |
| **D4** 🟡 | auditor 3G | La premisa publicada «un rol cuyo owner no resuelve no es visible en ninguna parte» **es falsa** (lo es desde cualquier descendiente vivo cuya ruta pase por el owner). **Z1 la hace cierta o irrelevante**; si Z1 no se hiciera, habría que medir el rango en la cadena de cualquier descendiente vivo. |
| **D5** ⚪ | auditor 3G | `reason: 'owner-detached-unknown'` significa dos cosas y no distingue cuál; `ScopeDetachOutcome` no dice **qué** roles se saltaron. (Desaparece con Z1.) |
| **D6** ⚪ | auditor 3G | `scopes.detached` pasa de O(1) a O(owners distintos) en llamadas al árbol, sin cota propia ni deadline. (Desaparece con Z1.) |
| **D7** ⚪ | auditor 3G | `types.ts`: dos docblocks seguidos de `ScopeDescendantsResolver`, el viejo contradice al nuevo. |
| **T-3b** 🟡 | tester 3E/3F | Nueve pendientes anotados en `fase-3-verificacion-tester-3f.md` §6: `runCatalogDiff` solo imprime sombras del catálogo #1; `classifyHomonyms` con global en el grupo; `shadowedByAncestor` repetido con owners anidados; la aserción de «subárboles disjuntos»; falta caso de `truncated: true` con 0 roles; T2/T4 sin oráculo; contador de `sync.role.locals`; R7 sin oráculo (declarado); degradación silenciosa. |

## Lote 3b-2 · El modo `facts` (el grueso)

Modelo **(c2)**, ya probado end-to-end contra OpenFGA v1.19 (panel 2):

```
type user / admin / integration
type role                      # id = roleUuid
  define permits_<P>: [user:*, admin:*, integration:*]     # catálogo por tuplas, editable en runtime
type role_binding              # id = <scopeKey>|<roleUuid>
  define role: [role] · define assignee: [<holders> with not_expired]
  define <P>: assignee and permits_<P> from role
type scope                     # id = 'app' | '<tipo>|<uuid>'
  define parent: [scope] · define binding: [role_binding]
  define <P>: <P> from binding or <P> from parent
  define denied_<P>: [<holders>] or denied_<P> from parent
  define can_<P>: <P> but not denied_<P>
  define ancestor: parent or ancestor from parent          # isWithin/descendantsOf nativos, 0 tuplas
```

| # | Pieza | Criterio |
|---|---|---|
| F1 | `hierarchy: 'facts'` único modo del driver `openfga` (se elimina `resolver`); el modelo se genera desde el catálogo en `syncAuthzCatalog` y se publica versionado | Los 83 casos del juez pasan contra `facts` con árbol SQL en PG y MySQL |
| F2 | `authorize` = **un solo `Check`** (memo de catálogo obligatorio para el invariante 5: permiso desconocido ⇒ `false`, no 400→503) | Espía: 1 `check`, 0 `batchCheck`, 0 `resolveChain` |
| F3 | `scopes.attached/moved/detached` escriben las aristas `parent`; **`moved` = `Read` del padre + UN `Write` atómico** (deletes+writes); anti-ciclos y validación de existencia **en el paquete** (FGA acepta ciclos y responde en 3 ms) | Casos de composición; ciclo ⇒ 422 sin escribir |
| F4 | **Outbox** opcional (`scopes.outbox`) + `authz:scopes:relay`; el driver `facts` **no se construye** sin outbox ni sin `acceptScopeDriftRisk: true` | Rollback del consumidor no deja escalada en FGA |
| F5 | Límites declarados como capacidades con caso negativo: techo de modelo **262 144 bytes ≈ 720 permisos**, profundidad **~23** (`--resolve-node-limit`), `batchCheck ≤ 50`; relación ≤ 50 chars y objeto ≤ 256 | Cada límite con su 422/500 y su caso |
| F6 | `hasRole`/`list*` **siguen usando `resolveChain`** (no hay alternativa en el modelo): capacidades `singleCheckAuthorize: true`, `roleInheritanceNative: false` con casos negativos | El README dice exactamente eso y nada más |
| F7 | `purgeRole` **pasa a estar soportado** en `openfga` (con `scope#binding` sí se enumera): retirar el 500 y la capacidad `purgeRole: false`; `defineScopedRole` deja de negarse con este driver | Casos del par invertidos |

## Lote 3b-3 · `authz:reconcile` (la simetría)

`authz:reconcile --to=openfga|database [--dry-run] [--prune]`, **única primitiva** de migración y verificación (sustituye a `openfga:import` y a un `verify` aparte):

- **DB → FGA**: hechos + **árbol** (desde `scopes.enumerateEdges`) + **proyección del catálogo**; reanudable por lotes de 100 con cursor; `--dry-run` = el verificador.
- **FGA → DB**: hechos por `Read` paginado; el árbol no se migra (lo lee el driver `database` de las tablas del consumidor).
- Reporte siempre: `{ written, updated, unchanged, extra, deleted, skipped{razón} }`. **Nunca silencioso.**
- `manager.freeze()` durante la migración: escrituras ⇒ 503 reintentable, lecturas siguen; `finally` que descongela.
- **Contrato de migración** `runMigrationContract`: siembra fija (7 nodos, 6 holders, 4 roles, 14 grants, 5 caducidades, 6 denies) → migrar → **448 preguntas idénticas** en origen y destino; 3 combinaciones; pérdidas declaradas en `expectedLosses` y contadas en `skipped`, nunca ignoradas.

## Aceptación de la fase
Cuatro modos + `:8101` + tope 3 verdes; contrato de migración verde en las tres combinaciones; bench re-medido (`facts` ≈ +0,8 ms sobre `resolver` en cadena de 3 — se acepta: el motivo es la simetría, no la latencia); tester (worktree, mutantes por pieza), auditor (drift, ciclos, outbox, consistencia eventual, límites), `/code-review`; correcciones; commit.

## No entra
`relations/` (Fase 4), `http/` (Fase 5), `{trx}` (diferido).
