# Panel «tenencia» · ronda 2 — veredicto del juez («deny AHORA, una línea, siguiente estable 2.5.0»)

Fecha: 2026-10-14 · base: `2.4.0-alpha.10` · entradas, en orden: `panel-tenencia-juez.md` (mi veredicto de ronda 1),
`panel-tenencia-2-coordinador.md`, `panel-tenencia-2-analista.md` (5 mediciones contra OpenFGA v1.19.0),
`panel-tenencia-2-auditor.md`, `panel-tenencia-2-tester.md`, `CLAUDE.md` §«Cómo se decide un cambio», `linajes.md` y
`roadmap-2.0.md` §2.5.

Para resolver conflictos leí además:
- `src/relations/define_relations_config.ts:299-308` (`frozenTypes` copia solo `type` y `relations`);
- `src/drivers/openfga_driver.ts:2692-2699` (`modelPermissions` lee `readLatestAuthorizationModel`);
- `commands/authz_relations_reconcile.ts:468-469` (`readRelationsConfig().catch(() => undefined)`);
- un grep de `saveRelationsConfig` en todo el repo: **ningún llamador de producción**, solo `index.ts:195` (export) y
  `tests/relations_persisted_config.spec.ts`;
- `README.md:635` («never a mute partial list») y `README.md:640` (`republishFusedModel`).

Notación de severidad, sin emojis: **[R]** rojo, **[N]** naranja, **[A]** amarillo, **[B]** blanco. Los ids son los de
cada panelista (R2-n del auditor, Hn del tester, Mn del analista).

---

## Veredicto

**Recomendación:** el plan del **analista** (`0 → A → B → D → C → RC`, con R en paralelo y obligatorio para la RC): 37/50
(74/100), y **44/50 (88/100)** con los injertos. Es el único plan que pone las rupturas pendientes antes de la primera
estable 2.x, que trae las mediciones ya hechas y que tiene un camino de upgrade por artefacto. Pero tal como está **no es
fail-closed en toda transición**. Tiene tres huecos y los tres se cierran con piezas que ya están en el debate:
1. **Opt-in en dos fases** (auditor R2-2).
2. **`database` honra `denied_*` siempre** (auditor R2-4, contra la D8 del analista).
3. **`decideMany` con la definición amplia de `deny`** (tester H2). Además resuelve una contradicción interna del
   analista: con su diseño, cada driver daba una respuesta distinta.

**Injertos de otras posturas:**
- **Tester:**
  - D4 sube del lote B al **A**, con la receta de canonización ejecutada (H5).
  - Claves desconocidas de la config de relaciones ⇒ 422 (H3).
  - Tabla T1 de 192 respuestas como criterio de D5 (H1: P1-M no basta).
  - Guardia de superficie con vistas `withClock` e inventario de exports (H11).
  - Corredor de mutantes propio en el lote 0 (§4.4).
  - Guardia L9 de signos, con filas declaradas (§5).
  - Conteo por cara en el runner (H9) y segundo tipo en `contractRelationsConfig` (H10).
  - Matriz de migración E0–E8 (§6).
- **Auditor:**
  - La **transición** como objeto de diseño: R2-2, R2-3, R2-4 y R2-5.
  - Columna «partición canónica» en la guardia de superficie (R2-7).
  - Candidatos de P2 solo de relaciones declaradas y verificados (R2-6).
  - Literal de oro de `relationTupleKey` (R2-12).
  - Medición M6 (R2-13).
  - Letra de los eventos ensanchados (R2-14).
  - Caso del techo compartido (R2-11).
  - El verificador de roles lee el modelo fijado (R2-10).
- **Coordinador:** una sola línea con 2.5.0 como siguiente estable; lote 0 primero; clave con `kind` desde el primer día.

**Condición para proceder:**
- **Lotes 0, A y B:** ya, en `main`, en serie. **R** en un worktree aislado, que no comparte árbol con ellos.
- **Lote D:** no arranca sin cuatro cosas:
  - (a) D3, D5, D6, D8, D9 y D10 firmadas por el dueño;
  - (b) M6 medida (una tupla condicional en la rama restada sin `current_time`);
  - (c) el lote B integrado;
  - (d) la guardia del lote 0 con todos sus mutantes muertos.
- **COGNITIV no bloquea D.** Solo C2 podría reabrir D3, y la reabriría hacia 2.6, no dentro de esta línea.

---

## Tabla de puntuación

Criterios fijados por el encargo, de 0 a 10 y con el mismo peso (total sobre 50). Puntúo los tres planes que existen en
el debate. El auditor no presentó un plan propio: suscribe el orden del coordinador y ataca la transición, así que su
aportación entra como injertos.

| Criterio | Coordinador | Analista | Tester | Nota |
|---|---|---|---|---|
| (1) Fail-closed en TODA transición (despliegue mixto, rollback, opt-in retirado, provision desde un proceso viejo) | 2 | 7 | 5 | **Coordinador descalificado**: R2-1 [R] sin mitigar (ni `decideMany` ni la frase del README), un solo interruptor de opt-in y ningún paso de rollback. **Analista**: tiene runbook en 3 pasos, la guarda perezosa del modelo y la guarda de `provision`, pero su D8 (paridad) deja el opt-in retirado en fail-open, su `decideMany` en `openfga` es estrecho (H2) y su puerta del reconcile lee una spec persistida que nadie escribe (R2-5, verificado). **Tester**: acepta E4/E5/S11/S17 como «filas declaradas» de concesión sin proponer cómo acortarlas, aunque sube D4 al lote A |
| (2) Verificabilidad por lote | 3 | 7 | 9 | El coordinador no da criterio de aceptación. El tester da `id · caso · dónde · mutante` por lote, cifras de los literales y los casos que se ponen rojos (§7) |
| (3) Genérico, no acoplado a COGNITIV | 6 | 8 | 8 | Opt-in por tipo, deny sin caducidad, nada de COGNITIV en el puerto. El coordinador hereda «`expiresAt` omitido ⇒ permanente», una pieza de diseño que solo existe si el deny caduca |
| (4) Coste/valor | 5 | 8 | 6 | El analista contabiliza la infraestructura del criterio de estable (R, 19–29 h), que **no existe**. El coordinador la omite y su RC es inalcanzable. El tester es caro en L9 y en la matriz de 192 respuestas, pero es el caro correcto. Le resto porque no ubica las rupturas del roadmap 2.5 |
| (5) Coherencia con linajes y M8 | 4 | 7 | 8 | El analista nombra L5 (`toConfig`, `frozenTypes`), L8 (README:635) y propone L9. El tester construye la guardia con inventario y meta-casos (G-M, G-X) y L9 como test. Al tester le resto porque declaró NO-OBS lo que M4 midió (conflicto 5) |
| **Total /50** | **20** | **37** | **36** | |
| **Con injertos** | — | **44** | — | Orden y contenido del analista, más la verificación del tester y la transición del auditor |

---

## Decisión por punto

### 1 · Orden y contenido de los lotes

**Orden: `0 → A → B → D → C → RC`, con R en paralelo. Se aprueba con un cambio: D4 pasa del lote B al A.**

- **D antes que C.** Lo dicen los tres: el analista por coste, el auditor por la ventana (con C antes, un pod de C lista
  objetos denegados mientras un pod de D escribe denies) y el tester por el coste de prueba. Lo que haría cambiar el
  orden es la respuesta C4b de COGNITIV (P2 en el camino crítico de su F0). Si eso pasa, C va antes con una costura
  `#verify(candidates)` y se acepta el sobrecoste de 5–8 h.
- **D4 en el lote A.** `checkMany` sale en alpha.1 y es una operación que recibe partición. Si nace sin la columna de
  canonización, la guardia L1 tiene que reabrirse en D: es exactamente el patrón de L1, y el auditor lo demuestra en
  R2-7. Además, cada día que alpha.1 acepte particiones sin guiones es población nueva que la receta de H5 tendrá que
  barrer. Coste: unas 4–6 h que salen de B.

**Qué entra en B: las rupturas antes de la primera estable 2.x.** Después de 2.5.0, cualquiera de ellas es 3.0
(`CLAUDE.md` punto 4).

| # | Contenido | Severidad hoy | Origen |
|---|---|---|---|
| B1 | Ciclos de `includes` ⇒ 422 en `defineRelationsConfig`, nombrando el ciclo | [N] (paridad: `database` sirve el ciclo y `openfga:provision` no puede publicarlo; M3 medido) | analista M3, tester H4 |
| B2 | Claves desconocidas en la spec de relaciones (tipo y relación) ⇒ 422. `frozenTypes` deja de descartar en silencio | [A] hoy, [N] con el deny (un `denny: true` sería una entrada inerte; L5, 5.ª iteración ⇒ propiedad universal: **ninguna clave de una spec de config se descarta**, caso por spec) | tester H3, auditor R2-3 (ii) |
| B3 | Userset de un tipo que no sea `group#member` ⇒ 422 en las escrituras de los dos drivers | [N] (hoy `database` lo guarda inerte y `openfga` responde 400 ⇒ 503 mal clasificado) | auditor [N 9] ronda 1, analista B(2) |
| B4 | `listObjects` de `openfga`: `truncated` por deadline (opción `listObjectsDeadlineMs`, umbral 0,9×) **y** corrección de la letra de `README.md:635` | [N] (letra ≠ efecto, medido en M4). Es la 5.ª iteración de L8 y la primera [N] del linaje, así que **M8 se activa**. Propiedad universal: «toda enumeración que se puede cortar devuelve `truncated` o lanza». Punto de paso: el envoltorio de lista del driver. Entrada en la guardia: fila «enumeración» con su mutante | analista M4 |
| B5 | `toConfig` del reconcile: un fallo de lectura es un error. `null` («no hay config persistida») sigue valiendo | [A] hoy, [N] con el deny (L5) | analista §4.7, auditor R2-5 |
| B6 | `sqlScopeOutbox({ requireTransaction })` por defecto `true`, con su prerrequisito: el `ctx()` de `runScopeOutboxContract` pasa la trx | ruptura del roadmap | analista §1.3 |
| B7 | `runRelationsReconcile` a `./relations/reconcile` | ruptura del roadmap | analista §1.3 |
| B8 | El verificador de roles (`modelPermissions`) lee el modelo `options.modelId` cuando está fijado, no el último | [A] (falla cerrado en las dos direcciones, verificado en `:2692-2699`) | auditor R2-10 |
| B9 | Letra: quitar `republishFusedModel` de `README.md:637-640`, la cabecera «(2.5)» de `README.md:377`, y `CLAUDE.md` punto 10 «2.4.0» ⇒ «2.5.0» | [B] | analista, auditor R2-15 |

**Fuera de 2.5 (a 2.6, como opt-in aditivo):**
- el sello durable del driver activo;
- la identidad de backend;
- el reconcile por subárbol;
- `limits.maxScopeChainDepth`;
- el invariante 13 en los runners.

Coincido con el analista: ninguno tiene relación con la tenencia y, hechos opt-in, ninguno rompe a nadie después de
2.5.0.

**R es condición de la RC, sin discusión.** `CLAUDE.md` punto 9 lo exige antes de publicar y el punto 10 para la estable.
El tester y el analista lo verificaron: hoy no existen ni `scripts/check_flag_mutants.mjs` ni el job `cutover-runbook`.
R contiene:
- (i) el script de mutantes de banderas, con `--allow-drop-deny` dentro;
- (ii) el job `cutover-runbook` contra pg y sqlite-fichero con OpenFGA real, **con los pasos de deny**: siembra de denies
  directos y por grupo, las dos fases del opt-in, el censo con `listDenies`, la vuelta, y la comprobación de que
  `check = false` después de cada paso;
- (iii) el resto de M7.

Los pasos de deny entran cuando D esté en `main`. El corredor de mutantes de la **guardia** no va en R: lo construye el
lote 0, porque sin él el lote 0 no tiene criterio de salida.

### 2 · Transición del deny

| Riesgo | Decisión | Por qué / qué queda |
|---|---|---|
| **R2-2** pods de dos versiones o con el `modelId` viejo | **Opt-in en dos fases**, como dos valores de la clave del tipo: «el modelo declara `denied_*` y las lecturas lo honran» y «se aceptan escrituras de deny». El nombre de los valores lo fija el dueño (D10). Runbook: (1) toda la flota en ≥ 2.5.0-alpha.3 con el tipo en la fase 1, el modelo publicado y todos los pods fijados al `modelId` nuevo; (2) se verifica; (3) un **segundo** despliegue pasa a la fase 2. Además, la guarda perezosa del analista (D-31): un tipo en cualquier fase con un modelo **fijado** sin `denied_<rel>` ⇒ 500 en lectura y en escritura, y escribir un deny contra ese modelo ⇒ 500 `E_AUTHZ_CONFIG` (no el 503 de hoy) | Con un solo interruptor no hay secuencia segura sin parar la flota (auditor, irrefutado). Con dos, la ventana del despliegue de código ocurre sin denies escritos. **Queda declarado**: la propia flota en código < 2.5 no se puede proteger. Lo cubren el runbook y el paso del job de R (S11 y E4 del tester, como filas declaradas) |
| **R2-3** rollback a < 2.5 | **No hay rollback soportado por debajo de 2.5.0-alpha.3 con denies vivos.** Antes de volver atrás hay que contar los denies (consulta SQL en §Upgrading, ejecutada en `upgrade_recipe.spec` en los 3 motores; en `openfga`, la línea de denies de `authz:relations:reconcile --dry-run`) y retirarlos con `removeDeny`/purga hasta llegar a cero. No hay comando nuevo | El código viejo no se puede arreglar. Se declara, con un procedimiento. S17 queda como fila declarada, y el caso de la COMÚN pasa a ser «el reconcile de 2.5 clasifica un deny como deny, nunca como `undeclared`» |
| **R2-4** opt-in retirado | Tres piezas: (a) **D8 = `database` honra `denied_*` siempre**; (b) `removeDeny` y `listDenies` aceptan cualquier tipo **declarado**, y solo `deny` exige la fase 2, así que retirar el opt-in es reversible y los denies se pueden borrar; (c) guarda de `openfga:provision` (analista §4.6) con un injerto del auditor: si el modelo nuevo quita un `denied_*` que el actual tiene ⇒ exit 1, salvo `--allow-drop-deny`; **y con la bandera**, `provision` barre el store (acotado por `maxTuples`) y si quedan denies vivos de esos tipos ⇒ 500 que los cuenta. La bandera nunca autoriza apagar denies vivos | El analista elegía la paridad porque «al quitar `deny: true`, `database` seguiría denegando y `openfga` no». Con (c), `openfga` no puede quitar el modelo mientras haya denies vivos, así que esa divergencia **no es alcanzable** y la paridad se mantiene en todos los estados accesibles. Precio: se pierde el caso «SQL byte a byte idéntica para tipos no denegables». Lo sustituye «sin filas `denied_*`, la respuesta es idéntica»: R-02, R-09 y la paridad de `listObjects` del BRIDGE, sin tocar |
| **H3** `provision` desde un proceso viejo republica sin `denied_*` | (a) B2: 2.5 rechaza claves desconocidas (protege a partir de ahí). (b) La guarda D-31 convierte un modelo mutilado en 500 en todo pod 2.5 que lo resuelva. (c) Runbook: `provision` solo desde la versión y la config actuales; el job de R lo ejerce. (d) **D14**: con algún tipo en fase ≥ 1, el driver `openfga` de relaciones exige `modelId` fijado (500 al construirse si no lo tiene). La guarda está memoizada por proceso, y un pod que flota a `latest` no vería una republicación posterior | Un binario viejo no se puede guardar. La defensa es que los pods nuevos fallen ruidosamente en vez de conceder |
| **R2-5** reconcile con opt-in por tipo | La pregunta «¿el destino admite deny en este tipo?» la responde el **driver destino** en la fase de plan, antes de escribir: su config de relaciones y, en `openfga`, su modelo fijado (vía la guarda D-31). **Nunca la spec persistida**: verifiqué que `saveRelationsConfig` no tiene ningún llamador de producción, así que en un despliegue normal `toConfig` vale `null` y esa puerta sería inerte. Ningún deny pasa por `relateOrSkip`: un 4xx al escribir un deny aborta la pasada con 500. `--dry-run` informa de la deriva de denies (exit ≠ 0). Orden: escritura denies → allows; poda allows → denies (`removeDeny`, jamás `unrelate`) | Cierra también la segunda puerta de R2-8: con D3 (b) un deny no tiene caducidad, así que no hay `toUpdate` de denies |

**Respuesta a «¿opt-in en dos fases?»: sí (D10). ¿Guarda en `provision` con `--allow-drop-deny`?: sí, con el injerto
del barrido.**

### 3 · D3 (forzada por M5)

**Deny sin caducidad en v1 (opción b).**

- M5 lo midió en v1.19: `deletes`+`writes` de la misma clave ⇒ 400 `cannot_allow_duplicate_tuples_in_one_request`;
  `on_duplicate: ignore` ⇒ 409. Renovar un deny vivo en `openfga` abre siempre una ventana fail-open, y si el segundo
  `Write` cae, el deny **desaparece**. Eso es peor que «indeterminado».
- La opción (b) iguala el deny de relaciones con el de roles (que tampoco caduca, `openfga_facts.ts:37`). Además cierra
  la segunda puerta del reconcile (R2-8), elimina el sesgo de reloj del deny ([A 13]) y deja sin objeto la discusión
  «`expiresAt` omitido ⇒ permanente» (D-19, S10).
- `expiresAt` en `deny` ⇒ 422, con la razón medida en el mensaje.
- La opción (c) (caducidad solo al crear y 409 al cambiarla sobre un deny vivo) **no entra en 2.5**. Si C2 dice que
  COGNITIV necesita un deny temporal, va a 2.6 como capacidad opcional, junto con «deny con caducidad» del Diferido.
- Un detalle que queda: un miembro de grupo con caducidad puede **transportar** un deny. Por eso M6 es condición de
  entrada de D.

### 4 · R2-1 [R] y H2/D7: qué devuelve la primitiva de cadena y cómo se documenta

**Conflicto que nadie nombró: el `decideMany` del analista da respuestas distintas en cada driver.**
- En `database` (§4.4), `deny` = «alguna `denied_*` alcanza», con la SQL de `check` sobre
  `IN { denied_Y : Y ∈ up*(down*(R)) }`. Es la definición **amplia**.
- En `openfga` (§4.5), `deny` = `Check(s, denied_R, o)`. Es la definición **estrecha**: por el cierre ascendente,
  `denied_viewer` solo contiene el `this`.
- Fila 35 de T1 (`owner` + deny(`editor`)), preguntada en `viewer`: `database` ⇒ `deny`, `openfga` ⇒ `none`. Es un
  defecto de paridad de diseño, y es justo la fila con la que el tester (H2) muestra que el consumidor heredaría.

**Decisión (D9): definición amplia en los dos drivers.** Por posición:
1. `allow` si `check(s, R, o) = T`. El deny ya está aplicado dentro del objeto por corte de camino; la fila 43
   (`owner` + `viewer` + deny(`editor`) ⇒ `viewer` T) sigue siendo `allow`.
2. Si no, `deny` si `s` tiene un deny vivo (directo o por grupo, también anidado) sobre **alguna relación de
   `up*(down*(R))`** en `o`.
3. Si no, `none`.

Implementación en `openfga`: un `batchCheck` con `R` más `denied_m` por cada relación **fuente** `m` de `down*(R)` (las
que no incluyen a ninguna otra). Por el cierre ascendente de `denied_*`, eso cubre todo `up*(down*(R))`. En el retículo
del contrato son 2 ítems por objeto. Se alinea por `correlationId`, y un `error` en un ítem ⇒ 503 para todo el lote (S8:
«error ⇒ `none`» es fail-open).

**Por qué la amplia.** Con la estrecha, un `owner` con deny(`editor`) en Nóminas da `none` y el evaluador concede por
Finanzas, que es justo la herencia que el corte prohíbe dentro de un objeto. La amplia puede bloquear de más: un
`viewer` heredado con un deny(`editor`) en el hijo da `deny`. Eso es fallo cerrado y respeta el criterio (1). La exacta
exigiría que el evaluador supiera qué relación concedió en el ancestro, y eso no se puede pedir.

**Entrega:**
- `decideMany` entra en **D**, obligatorio cuando `relationDenies: true`.
- En **A**, con `checkMany`, la frase del README: *«`checkMany` returns one boolean per object: `false` does not
  distinguish "denied here" from "nothing here", so it cannot implement deny-wins along a chain of objects that you
  walk yourself.»*
- En **D**, la frase completa: *«`decideMany` is the chain primitive: walk from the leaf up and stop at the first
  non-`none`. `deny` means "do not inherit past this object"; it is broader than `check` on purpose (fail-closed). A deny
  given to `org#member` does not reach a guest who is not a member: to make a folder grant only what it holds directly,
  break inheritance in your evaluator (`inherits = false`).»*
- **No se promete** «deny gana a lo largo de la cadena» (tester §8, NO-OBS).

**Casos:**
- *«deny en Nóminas con allow heredado de Finanzas: `decideMany` devuelve `deny` en Nóminas»*, en los dos drivers;
- *«fila 35 preguntada en `viewer` ⇒ `deny`»* y *«fila 43 preguntada en `viewer` ⇒ `allow`»*, que fijan D9;
- en BRIDGE, *«con `checkMany` el mismo escenario es indistinguible»*, que fija la limitación declarada;
- *«un `error` en un ítem ⇒ 503»*.

### 5 · D4 y los otros dos ejes de alias

- **422 para una partición con uuid de 32 hex sin guiones en TODAS las operaciones que reciben partición**: las ocho de
  hoy, `checkMany` y, cuando lleguen, `deny`, `removeDeny`, `listDenies`, `decideMany` y las `partitions` de P2.
- Se implementa como **columna «partición canónica» de la guardia L1**, enumerada por reflexión (R2-7). Una operación
  nueva que reciba partición sin esa fila es rojo.
- **Va en el lote A**, con la **receta de canonización** de H5 ejecutada en `upgrade_recipe.spec` (pg, mysql, sqlite):
  detectar, re-clavar a la forma con guiones y deduplicar contra el UNIQUE, quedándose con la caducidad que más dura
  (el patrón de `folded-scope`).
- En `openfga`, la receta es `authz:relations:reconcile` desde `database`, o write canónica + delete. Mientras no haya
  denies, los dos órdenes fallan cerrado.
- Los casos que hoy escriben o purgan sin guiones (`relations_database.spec.ts:206,229,252`,
  `relations_openfga.spec.ts:1069`) se reescriben como «sin guiones ⇒ 422», y solo con la receta publicada.
- **422, no canonizar**: en relaciones no hay una cadena con la que canonizar (analista, irrefutado).
- **Ids de objeto y de sujeto: declarar, no rechazar.** Rechazar los 32 hex rompería ids legítimos que no son uuid. La
  frase va al README («object and subject ids are compared byte for byte; use one spelling»), con un caso que la fije en
  las dos direcciones. Se dice que roles tiene el mismo límite con los holders.

### 6 · D8

**Siempre** (ver §2, R2-4). Es la única opción que deja fallo cerrado el opt-in retirado en `database`, y la guarda de
`provision` hace que la paridad no se rompa en ningún estado alcanzable. Caso: *«retirar el opt-in con denies vivos:
`check` sigue `false` en los dos drivers; `provision` ⇒ exit 1 / 500»*.

### 7 · Defectos de HOY que salieron

| Defecto | Medido / verificado | Severidad | Lote |
|---|---|---|---|
| M3 · `defineRelationsConfig` acepta ciclos de `includes`; `openfga` los rechaza al publicar | Medido (analista, v1.19; tester, en local) | [N] (paridad) | B1 |
| M4 · `ListObjects` parcial y mudo contra `README.md:635` | Medido (analista, contenedor con deadline de 3 ms); verifiqué la letra | [N] (L8, 5.ª iteración; primera [N] ⇒ M8) | B4 |
| `toConfig` traga el error (`authz_relations_reconcile.ts:469`) | Verificado por mí | [A] hoy, [N] con el deny | B5 |
| `frozenTypes` descarta propiedades (`define_relations_config.ts:299-304`) | Medido (tester) y verificado por mí | [A] hoy, [N] con el deny (L5) | B2 |
| El verificador de roles lee el último modelo (`openfga_driver.ts:2692-2699`) | Verificado por mí | [A] (falla cerrado) | B8 |
| P5-1 · borrar `authz_provider.ts:59` no pone nada en rojo | Medido (tester, mutante en scratch) | [N] (entrada inerte, L5) | A |
| `README.md:637-640` describe `republishFusedModel`, que ya no existe | Verificado por mí | [B] | B9 |

### 8 · Contradicciones entre panelistas

1. **`decideMany` de `database` (amplio) vs. el de `openfga` (estrecho), los dos del analista; con el tester (H2).** Lo
   resuelvo con la definición amplia en los dos (D9). La carga de la prueba es del lote D: las filas 35 y 43
   preguntadas en `viewer`, en los dos drivers y en el BRIDGE.
2. **D8: paridad (analista) vs. incondicional (auditor R2-4).** Gana el incondicional, con la guarda de `provision`
   ampliada. El argumento de la paridad cae porque la divergencia deja de ser alcanzable.
3. **La puerta del reconcile por `toConfig` (analista §4.7) vs. «esa spec no la escribe nadie» (auditor R2-5).** Gana el
   auditor; lo verifiqué con un grep (ningún llamador de producción de `saveRelationsConfig`). La puerta pasa al driver
   destino.
4. **Mi conflicto 3 de la ronda 1 («la propia relación» cierra el escenario de pods viejos) vs. el auditor R2-2.** El
   auditor tiene razón y corrijo mi veredicto: lo que decide es el `modelId` de cada pod, no el nombre de la relación.
   La relación propia solo cierra los usersets y el nombre nuevo. De ahí salen las dos fases y D14.
5. **Tester (§8: «`ListObjects` cortado por deadline, NO-OBS; no prometer») vs. analista (M4, medido).** Gana la
   medición. Es observable con un contenedor con `OPENFGA_LIST_OBJECTS_DEADLINE` de pocos ms, y la heurística se prueba
   con un reloj inyectado. Como promesa de producción sigue valiendo lo del tester: «exhaustivo, `truncated`, o 503».
6. **Dónde va D4: lote D (coordinador) vs. B (analista) vs. A (tester).** Gana A, por R2-7 y H5.
7. **Semver: «`^2.4.0-alpha.10` acepta `2.5.0`» (analista) vs. «no acepta `2.5.0-alpha.x`» (auditor).** Las dos cosas
   son ciertas y se complementan: `^` deja fuera las prereleases de otra tupla y admite la estable. Consecuencia: a
   COGNITIV le llegan las rupturas de B **con la estable** si fija con `^` (C6).
8. **Lote de D: alpha.2 (tester, coordinador) vs. alpha.3 (analista).** Gana alpha.3, porque B va en medio.
9. **D-19/S10 «`expiresAt` omitido ⇒ permanente» (tester, auditor) vs. D3 (b) (analista).** Desaparece con D3 (b).
   D-19 pasa a ser *«`expiresAt` en `deny` ⇒ 422»*.
10. **P1-M como criterio de D5 (mi ronda 1) vs. H1 (el tester).** Gana el tester: CONSULTA, GRANT-LIT y CORTE-INV son
    monótonas. El criterio es la tabla de 192 respuestas, con su oráculo TS generado por la misma función que la tabla
    del informe. P1-M queda como guardián secundario.

## Qué está MEDIDO y qué es lectura

**Medido:**
- **Analista**, contra OpenFGA **v1.19.0** (`openfga-dev` `:8090` y un contenedor efímero `:8104`; no el `:8101`
  canónico, pero sí la misma versión que la imagen de CI):
  - M1: +598 B por tipo de 3 relaciones (×2,14);
  - M2: `Check` p50 3,02 → 3,82 ms; `ListObjects` 3,85 → 4,16 ms;
  - M3: ciclos ⇒ 400;
  - M4: lista parcial muda;
  - M5: 400/409, sin renovación atómica;
  - además: un pod con el `modelId` viejo concede sobre un objeto denegado; un deny contra un modelo sin `denied_X` ⇒
    400; `denied_manager` = T con deny en `viewer`.
  - Hay que repetirlas contra el `:8101` cuando responda. No cambian el diseño.
- **Tester**, en SQLite `:memory:`:
  - cinco specs en verde;
  - el mutante P5-1 sobrevive;
  - `defineRelationsConfig` acepta claves desconocidas, ciclos y relaciones de 50 caracteres;
  - reflexión del driver `openfga`: 11 métodos;
  - `RelationsManager` no se puede importar sin la app;
  - el script de mutantes y el job del runbook no existen;
  - la tabla T1 de 64 estados × 7 semánticas, **calculada** con un script; no ejecutada contra los drivers.
- **Juez:** los cuatro puntos de lectura de la cabecera.

**Lectura, sin medir:**
- Todo el informe del auditor (lo declara él mismo; su R2-6 depende de la implementación).
- La heurística del deadline («solo da falsos positivos»): por razonamiento es sólida, porque el tiempo del cliente es
  mayor o igual que el del servidor.
- El coste de `membersOf` con deny en `database`: hay que medirlo en D (PG/MySQL, 1.000 miembros, 3 niveles).
- **M6**: no la ha medido nadie. Es condición de D.

## Afirmaciones descartadas por falta de evidencia (o rebajadas)

- **Coordinador:** «mediciones antes de comprometer» como paso del plan. Ya están hechas, salvo M6, que no aparecía.
- **Coordinador:** «`expiresAt` omitido en re-deny ⇒ permanente». Sin objeto con D3 (b).
- **Analista:** «la SQL de `check` es idéntica para un tipo sin `deny`», con un espía. La descarta D8.
- **Analista:** horas de todos los lotes y «C después de D ahorra 5–8 h». Son estimaciones; sirven para ordenar.
- **Tester:** «≈ 86 celdas» en la guardia y «≈ 25 casos por cara». Estimaciones.
- **Auditor (a):** «el verificador de COGNITIV compara sin `kind`». No verificado; pasa a pregunta (C9).
- **Auditor R2-11:** «COGNITIV cerca del techo». No hay ningún dato de su catálogo; queda el caso genérico.

---

## Plan final por lotes

Horas: estimación del analista, ajustada con los injertos. Sirven para ordenar, no para comprometer. «+50 %» es el
historial de cierres en los lotes de riesgo.

| Lote | Contenido | Versión | Horas | Criterio de aceptación |
|---|---|---|---|---|
| **0** | Guardia L1 por reflexión (manager, dos drivers, **vistas `withClock`**, inventario de exports). Columnas F-05 / L2 / L3 / `#write` / actor / **partición canónica** / G-R. Corredor de mutantes `scripts/check_guard_mutants.mjs` + manifiesto. Exenciones firmadas (D6). Sustituye la lista a mano de `relations_database.spec.ts:554-599` | `2.5.0-alpha.1` (con A) | 10–16 | Tester §3 lote 0 (G-0, G-F05-*, G-L2/L3/W/ACT-*, G-R, G-M, G-X). Todos los mutantes muertos en `:memory:` y en `sqlite-file`. `linajes.md` L1 con la guardia como punto de paso único |
| **A** | P5 (`createTestClock`, P5-1/2/3, README). `relationTupleKey` con `kind` + **literal de oro** (la clave de un allow no cambia en D) + reconcile la usa + `scopeKeyOf` unificado. `checkMany` booleano + frase del README. **D4 = 422 + receta de canonización ejecutada.** Segundo tipo en `contractRelationsConfig` (H10) | `2.5.0-alpha.1` | 14–24 | A-1…A-20 del tester. La guardia se pone **roja** al añadir `checkMany` sin su fila (rojo visto en el informe). `EXPECTED_FUSED` sin tocar. Receta de D4 en los 3 motores. Casos de alias reescritos. `EXPECTED_CASES`/REC/F10 con desglose |
| **B** | B1–B9 (§1) | `2.5.0-alpha.2` | 14–22 | Un caso por ruptura, con su mutante. B4 con un caso de reloj inyectado y la letra del README fijada (`trx_docs`/`scope_depth`). B6 con el par en el juez de la outbox. B2 con un caso por spec (tipo y relación). CHANGELOG «problema → decisión → qué NO» por ruptura. Cuatro líneas de cierre (punto 5) para B1, B2, B3 y B4 |
| **D** | Deny: corte de camino (D5); **opt-in en dos fases (D10)**; ≤ 43 caracteres; sin `*`; `group` ⇒ 422; **sin caducidad (D3 b)**; `decideMany` amplio (D9) con las frases del README; `database` honra siempre (D8); `removeDeny`/`listDenies` sobre cualquier tipo declarado; guarda perezosa del modelo fijado + 400 ⇒ 500; **D14**; guarda de `provision` con `--allow-drop-deny` y barrido; reconcile con `kind`, puerta por driver destino, sin `relateOrSkip` para denies, orden de escritura y poda; purgas de `openfga` en orden **global**; eventos ensanchados con letra (R2-14); filas declaradas S8–S10 (H6) en el README; §Upgrading con rollback y conteo; reporte parcial por partición; conteo del runner por cara (H9) | `2.5.0-alpha.3` | 45–65, +50 % ⇒ hasta ~95 | **Entrada:** D3, D5, D6, D8, D9 y D10 firmadas; M6 medida; B integrado. **Salida:** D-01…D-31 del tester con D-19 reescrito (422) y D-21 con D9; T1 (192 respuestas) en la COMÚN y las 37 filas PAR en el BRIDGE, en los 4 modos + `:8101` + `:8103`; T3 por el kernel; L9 entera (S1–S18, con S8–S11/S17 como filas declaradas, cada una con caso y línea en el README); casos de transición: «opt-in fase 1 ⇒ `deny` 422», «modelo fijado sin `denied_*` ⇒ 500», «retirar opt-in con denies vivos ⇒ `check` F en los dos drivers y `provision` exit 1 / 500», «reconcile hacia un destino sin opt-in en ese tipo ⇒ 500 con cero escrituras»; R2-11 (techo + opt-in ⇒ 500 sin requests); `membersOf` con deny medido en PG/MySQL; `factsModelBytes` en Limits; `EXPECTED_FUSED` y `migration_stub.spec` **sin tocar**; auditoría de sistema (punto 9) |
| **C** | P2 `listObjectsForSubject` (solo holders; directas + `includes`; **candidatos solo de relaciones declaradas, verificados con `decideMany`/`batchCheck`**; error ⇒ 503; cursor `(partition_key, object_uuid)`; índice ensanchado del analista; par de capacidad; nota de seguridad: el sujeto sale de la sesión) + `--prune-undeclared` | `2.5.0-alpha.4` | 18–30 | C-1…C-18 del tester + los tres casos de R2-6 en los dos drivers + `filtrar(P2) ⊆ check` en BRIDGE + receta del índice en 3 motores |
| **R** (worktree, en paralelo) | `check_flag_mutants.mjs`; job `cutover-runbook` (pg + sqlite-fichero + OpenFGA real) con los pasos de relaciones y deny; resto de M7 | sin release; puerta de la RC | 23–35 | `CLAUDE.md` punto 9 en verde; `--allow-drop-deny` en el script de banderas; las dos fases del opt-in y el rollback prohibido ejercidos en el job |
| **RC** | Auditoría de sistema sin diff, con perspectiva nueva; ensayo de COGNITIV sobre el tarball exacto, con plazo cerrado; RC-1…RC-9 del tester | `2.5.0-rc.1` (`--tag next`) → `2.5.0` (`--tag latest`, **explícito**) | 6–12 + el plazo | `CLAUDE.md` punto 10 trasladado a 2.5.0. Cualquier grave reabre la RC |

**Total: ~130–205 h**, más los cierres y el plazo del ensayo. Camino crítico: D. 0, A, B, D y C van **en serie** en
`main` (mismos ficheros). R va en su worktree y se integra antes de la RC.

**Publicación:**
- No habrá `2.4.0` estable (CHANGELOG y README).
- Las alphas se publican con `--tag alpha` y las RC con `--tag next`.
- Las prereleases se deprecan **versión a versión**, y solo después de 2.5.0.

---

## Decisiones del DUEÑO (lista cerrada)

| # | Decisión | Recomendación |
|---|---|---|
| **D3** | Caducidad del deny | **(b) sin caducidad en v1**; `expiresAt` ⇒ 422. La opción (c) va a 2.6 si C2 la exige |
| **D4** | Partición con uuid de 32 hex sin guiones | **422 en toda operación con partición, en el lote A**, como columna de la guardia, con la receta ejecutada. Ids de objeto y de sujeto: **declarar**, no rechazar |
| **D5** | Semántica del deny | **Corte de camino** (medido; T1 de 192 respuestas como contrato) |
| **D6** | Exenciones de la guardia L1 | Firmar: `driver()`, `capabilities()`, F-05 de `enumerateRelations(Many)` sustituida por la sonda de lista blanca, freeze en la capa del driver (doctrina) y `membersOf` de `openfga` |
| **D7** | Qué entra del roadmap 2.5 | Entran B6 y B7 (rupturas) y `--prune-undeclared` (C). El sello del driver activo, la identidad de backend, el reconcile por subárbol, `maxScopeChainDepth` y el invariante 13 en los runners van a 2.6 como opt-in |
| **D8** | `database` honra `denied_*` | **Siempre**, con `removeDeny`/`listDenies` sobre cualquier tipo declarado y la guarda de `provision` con barrido |
| **D9** | `deny` en `decideMany` | **Amplio** (`up*(down*(R))`), igual en los dos drivers; `allow` tiene precedencia si `check` = T |
| **D10** | Opt-in | **Dos fases** (modelo y lecturas / escrituras aceptadas), con dos despliegues en el runbook. Nombre de los valores, a elegir |
| **D11** | Claves desconocidas en la spec de relaciones | **422** en 2.5 (ruptura anunciada) |
| **D12** | Rollback a < 2.5 con denies vivos | **Prohibido**; procedimiento: contar y retirar hasta llegar a cero, documentado y ejecutado en `upgrade_recipe.spec` |
| **D13** | ¿El runner exige F-05 al driver llamado directamente (H8)? | **Sí**, con un caso nuevo en el runner antes de la estable (después sería major), en lugar de firmar la exención del doble |
| **D14** | ¿`modelId` fijado obligatorio con algún tipo en fase ≥ 1? | **Sí**: 500 al construir el driver `openfga` de relaciones sin él |
| **D15** | Regla de capacidades después de 2.5.0 | **Escribirla en `CLAUDE.md`**: hasta 2.5.0 una clave nueva puede ser obligatoria; desde 2.5.0, toda clave nueva es `?:`, se normaliza a `false` y entra con su par |
| **D16** | Plazo del ensayo de COGNITIV sobre la RC | **7 días naturales** (analista), fecha según C12 |

---

## Preguntas a COGNITIV (consolidadas)

| # | Pregunta | Qué decide |
|---|---|---|
| **C1′** | El deny entra en 2.5, pero **no arregla Nóminas**: no exime al owner y no llega al invitado cross-org. ¿Confirmáis `inherits=false` en vuestro evaluador para ese caso? ¿Para qué casos reales usaríais el deny («el grupo sí, esta persona no»)? | Realismo de los casos de D |
| **C2** | ¿Necesitáis deny **temporal**? Hemos medido que en OpenFGA no se puede cambiar la caducidad de un deny vivo sin una ventana en la que deja de bloquear. v1 va sin caducidad | D3 (c) en 2.6 o no |
| **C3** | ¿Escribís siempre la partición con el uuid canónico? Ejecutad la consulta de detección y mandadnos el número | La receta de D4 en alpha.1 |
| **C4 / C4b** | ¿Os basta P2 con «directas + `includes`»? ¿P2 está en el camino crítico de vuestra F0 o en la fase 2? | Orden C/D |
| **C5** | ¿Cómo retiráis las tuplas de relación de una organización borrada? No hay purga por partición | ¿Un lote en 2.6? |
| **C6** | ¿Fijáis la versión exacta o con `^`? Con `^2.4.0-alpha.10` os llega `2.5.0` estable sola, con las rupturas del lote B | Nota de release |
| **C7** | ¿Fijáis `modelId` en el driver `openfga`? ¿Quién ejecuta `openfga:provision`, desde qué proceso y con qué versión? | D10, D14, el runbook |
| **C8** | ¿Qué tipos llevarían deny? ¿Alguna relación de más de 43 caracteres en ellos? | Cota y opt-in |
| **C9** | ¿Vuestros `assertWrite`/`onRelationWrite` hacen `switch` sobre `operation`, o tratan como alta todo lo que no sea `unrelate`? ¿Vuestro `authz:cutover:verify` compara tuplas sin `kind`? | R2-14 y la letra de D |
| **C10** | ¿Usáis usersets de tipos que no sean `group#member`, `includes` cíclicos o claves extra en la spec de relaciones? (B los convierte en 422) | Rupturas de B |
| **C11** | ¿Llamáis a `listObjects` de `openfga` sobre particiones grandes? Desde B puede marcar `truncated` por deadline | `listObjectsDeadlineMs` |
| **C12** | ¿Qué fechas os vienen bien para el ensayo sobre la RC, con plazo cerrado (propuesta: 7 días)? | Calendario |
| **C13** | ¿Os vale la semántica de corte («un deny en `editor` anula entero un grant de `owner`; solo sobrevive un `viewer` directo») y la de `decideMany` («`deny` = no heredéis más allá de este objeto», más amplia que `check` a propósito)? | D5, D9 |

---

## Riesgos que quedan aunque se elija la ganadora

- Pods con código < 2.5 durante el primer despliegue: ninguna guarda los cubre. Solo el runbook y el job de R (filas
  declaradas S11/E4).
- Un `openfga:provision` ejecutado con un binario viejo: los pods nuevos pasan a 500 (ruidoso), no a conceder; los
  viejos, sin `modelId` fijado, conceden. D14 lo acota en los nuevos.
- `decideMany` amplio bloquea de más en las cadenas: un `viewer` heredado con un deny(`editor`) en el hijo da `deny`.
  Está declarado y es fallo cerrado.
- Tres escrituras que hoy solo quitan acceso pasan a poder darlo (H6): salir de un grupo denegado, purgar un grupo o
  purgar sus denies. Son filas declaradas con caso y README; la policy del consumidor tiene que saberlo.
- La heurística del deadline da falsos positivos cerca del umbral (la dirección ruidosa).
- `membersOf` con deny en `database` es la consulta más cara del paquete. Si la medición de D sale mal, puede pedir un
  diseño propio.
- Las cifras medidas en `:8090`/`:8104` hay que repetirlas contra el `:8101`.
- La línea sube de ~30–50 h (ronda 1) a ~130–205 h: la estable 2.5.0 se aleja semanas. Es el precio de hacer el deny
  dentro de la línea.

## Lo que preguntaría al humano antes de implementar

Nada que cambie el orden de 0, A y B. Para D: las firmas D3, D5, D6, D8, D9 y D10. Hay una que no es técnica: **¿acepta
el dueño que la primera estable 2.x se retrase por el deny (~130–205 h en lugar de ~30–50 h)?** La ronda 1 lo dejaba fuera
justo por eso. Si la respuesta es sí, este plan; si no, 0+A+B se cierran como 2.5.0 y D+C pasan a 2.6. Esa segunda vía
cambia las reglas de ruptura de D: tendría que entrar como opt-in sin claves obligatorias (D15).

---

## Borrador de respuesta a COGNITIV

> **Para:** `api-cognitiv` · **De:** `@jantstack/adonis-authz` · **Re:** 7.º informe (tenencia), ronda 2, 2026-10-14
>
> Cambiamos de plan: **el deny de relaciones entra en esta línea**, y la próxima estable será **`2.5.0`**. No habrá
> `2.4.0` estable: la línea alpha de 2.4 termina en alpha.10 y continúa como `2.5.0-alpha.1`. Calendario previsto:
>
> - **`2.5.0-alpha.1`**:
>   - `checkMany(subject, relation, objects, partition): boolean[]` (tope 50, `[]` ⇒ 422, un error en un ítem ⇒ 503
>     para todos);
>   - `createTestClock()` en `/testing`;
>   - `relationTupleKey()` pura y estable, la misma que usa el reconcile.
>
>   **Ojo:** desde esta versión, una partición con el uuid **sin guiones** es 422 en todas las operaciones. Publicamos
>   una receta para canonizar las filas existentes; mandadnos el resultado de la consulta de detección (pregunta 3).
> - **`2.5.0-alpha.2`**: endurecimiento con rupturas que no pueden esperar a la estable:
>   - ciclos de `includes` ⇒ 422 (OpenFGA ya los rechazaba al publicar);
>   - claves desconocidas en la spec de relaciones ⇒ 422;
>   - un userset que no sea `group#member` ⇒ 422;
>   - `listObjects` en `openfga` puede devolver `truncated` por deadline (hemos medido que el servidor corta en silencio,
>     y nuestro README decía lo contrario);
>   - `sqlScopeOutbox` exige la trx por defecto;
>   - `runRelationsReconcile` se mueve a `./relations/reconcile`.
> - **`2.5.0-alpha.3`**: deny en relaciones (detalle abajo).
> - **`2.5.0-alpha.4`**: `listObjectsForSubject` («Compartido conmigo»), que nace respetando el deny.
> - **`2.5.0-rc.1`**: el ensayo sobre el tarball exacto, con plazo cerrado.
>
> **Cómo será el deny:**
> - **Opt-in por tipo y en dos fases.** Primero el modelo declara el deny y las lecturas lo honran. Después, en otro
>   despliegue, se aceptan escrituras. Así ningún pod viejo ignora un deny ya escrito. Con deny activo, el driver
>   `openfga` exigirá `modelId` fijado.
> - **Corte de camino.** Un deny en `editor` anula entero un grant de `owner` sobre ese objeto; solo sobrevive un
>   `viewer` directo. Un deny en `viewer` lo bloquea todo.
> - **Sin caducidad en v1.** Hemos medido en OpenFGA 1.19 que no se puede renovar la caducidad de un deny vivo sin una
>   ventana en la que deja de bloquear.
> - **Sin comodín `*`; deny sobre `group` ⇒ 422.** `listSubjects` sigue dando hechos; `listObjects` y `membersOf`
>   restan.
> - **`decideMany(...)`: `allow | deny | none`** por objeto, la primitiva para vuestra cadena. Recorred de la hoja
>   hacia arriba y parad en el primer valor que no sea `none`. `deny` significa «no heredéis más allá de este objeto», y
>   es más amplio que `check` a propósito. **No uséis `checkMany` para eso**: un `false` no distingue «aquí hay un deny»
>   de «aquí no hay nada».
> - **Nóminas sigue sin resolverse con deny.** Un deny a `org#member` bloquea al owner y no llega al invitado de otra
>   organización. Lo que pide el caso es romper la herencia: `inherits = false` en vuestro evaluador.
> - **No hay vuelta atrás a < 2.5 con denies vivos.** Antes de un rollback, el procedimiento documentado los cuenta y
>   los retira.
>
> **Preguntas:**
> 1. ¿Confirmáis `inherits=false` para Nóminas? ¿Para qué casos reales usaríais el deny?
> 2. ¿Necesitáis un deny temporal?
> 3. ¿Escribís siempre la partición con el uuid canónico? Ejecutad la consulta de detección y mandadnos el número.
> 4. ¿Os basta «Compartido conmigo» con «directas + `includes`»? ¿Está en el camino crítico de vuestra F0?
> 5. ¿Cómo retiráis las tuplas de relación de una organización borrada?
> 6. ¿Fijáis la versión con `^`? Si es así, os llegará `2.5.0` estable sola, con las rupturas de alpha.2.
> 7. ¿Fijáis `modelId`? ¿Quién ejecuta `openfga:provision`, desde qué proceso y con qué versión?
> 8. ¿Qué tipos llevarían deny? ¿Alguna relación de más de 43 caracteres en ellos?
> 9. ¿Vuestros `onRelationWrite`/`assertWrite` tratan como alta todo lo que no sea `unrelate`? ¿Vuestro
>    `authz:cutover:verify` compara tuplas sin `kind`?
> 10. ¿Usáis usersets que no sean `group#member`, `includes` cíclicos o claves extra en la spec de relaciones?
> 11. ¿Llamáis a `listObjects` de `openfga` sobre particiones grandes?
> 12. ¿Qué fechas os vienen bien para el ensayo sobre la RC (7 días)?
> 13. ¿Os valen la semántica de corte y la de `decideMany` descritas arriba?
>
> Cada decisión quedará fijada en la suite común con un caso con nombre.
