# Fase 4 · lote 4-8 — el cableado del servicio de relaciones (⚪4, cierre de la Fase 4)

> Base: `main` @ `6e7f308` (lote 4-7 mergeado), árbol principal, sin commits (los hace el dueño).
> Insumos: `fase-4-lote-7-informe.md` (⚪4 DECLARADO) y `fase-4-auditor-final.md` (⚪4).
> Cierra el ÚLTIMO ⚪ de la Fase 4: no era un bug de seguridad (fail-closed), era wiring incompleto.

## Resumen

| Síntoma (4-7 / auditor) | Raíz | Estado |
|---|---|---|
| `openfga:provision` republica el modelo facts-ONLY (un store aprovisionado no acepta relaciones hasta un `sync`) | el modelo publicado no lleva los tipos de relación | ✅ CERRADO — el comando fusiona los tipos de relación en el modelo |
| `republishFusedModel` sin llamador de producción (4-5 lo creó, 4-6 lo dejó sin cablear) | el singleton `RelationsManager` de servicio no estaba cableado + republicador redundante | ✅ CERRADO — singleton cableado; `republishFusedModel` BORRADO (código muerto) |

**Cifras (aditivo, sin skips, rojo→verde por pieza) — TODAS con `OPENFGA_TEST_URL=:8101`:**

| Modo | Base (4-7) | Ahora | Δ |
|---|---|---|---|
| `npm test` (sqlite memoria) | 974 | **979** | +5 |
| `test:sqlite-file` | 979 | **984** | +5 |
| `test:pg` (postgres18) | 1073 | **1078** | +5 |
| `test:mysql` (mysql84) | 1073 | **1078** | +5 |

Δ neto +5 en los cuatro modos = **+9 casos nuevos** (5 del singleton de servicio + 4 de provisión, 2 de
ellos contra el `:8101`) **−4 casos borrados** (`relations_republish.spec.ts`, que probaba el
`republishFusedModel` retirado). `tsc --noEmit` (src y test), `typecheck`, `check:purity` y `build`:
verdes. Stores del `:8101` creados por las suites y borrados por sus teardown (`:8101` a **0 stores** al
cerrar).

---

## El caso clave · un store aprovisionado ACEPTA una relación sin `sync` (ROJO→VERDE)

**Reproducción del ROJO (medido contra el `:8101`).** Un store con el modelo facts-ONLY que
`openfga:provision` publicaba —`openFgaFactsModel(holders, permissions)`, SIN los tipos de relación—
rechaza una tupla `document#viewer`:

```
RECHAZADA (ROJO): validation_error - Invalid tuple 'document:app|doc1#viewer@user:alice'.
                  Reason: type 'document' not found
```

El tipo `document` no está en el modelo, así que el servidor rechaza la escritura con 400
`validation_error`. Hasta 4-8 la única forma de meter el tipo era un `authz:catalog:sync` posterior (que
republica el modelo fusionado por la proyección del catálogo) — un store recién aprovisionado NO aceptaba
relaciones.

**VERDE.** `provisionOpenFgaStore(url, name, holders, permissions, relations)` con el 5.º parámetro
—los tipos de relación— publica el modelo FUSIONADO y el mismo store acepta la tupla de salida:

```
ACEPTADA (VERDE): modelo fusionado acepta la tupla   (write + check(viewer)=allowed, SIN sync previo)
```

El caso vive en `tests/relations_provision.spec.ts`, grupo «el store aprovisionado acepta relaciones»
(contra el `:8101`): provisiona en ROJO (facts-only ⇒ la tupla se rechaza con «type 'document' not
found») y en VERDE (fusionado ⇒ `write` + `check(viewer)` = `allowed`), y comprueba que el modelo
fusionado sigue llevando **las dos mitades** (`document` de ReBAC + `role_binding`/`scope` de roles c2r,
o sea que la mitad de roles no se cae). El helper puro `relationsConfigOf(config)` (la decisión del
comando) se juzga en memoria: sin `relations.config` ⇒ `undefined` (facts-only, como hasta 4-8); con él
⇒ `{ objectTypes }`.

### Dónde salen los tipos de relación (decisión de diseño, escrita)

`openfga:provision` lee los tipos de relación del **CONFIG estático** (`config.relations.config`,
`defineRelationsConfig(...)`), NO de la tabla `authz_relations_config` de la base. **Por qué** —y por qué
me desvío del literal del encargo («leyendo `authz_relations_config`, como `sync` ya hace»)—:

- **`openfga:provision` es `startApp: false` a propósito** (bootstrap del appliance, ANTES de que haya
  base o migración). MEDIDO en el kernel de ace (`node_modules/@adonisjs/core/build/main-B2M1tZ4I.js`):
  con `startApp: false` el comando corre tras `app.init()` **sin `app.boot()`**, así que los providers no
  bootean y el servicio `db` de Lucid NO está disponible. Leer `authz_relations_config` obligaría a
  `startApp: true`, que es justo la regresión que el 4-7 señaló (un appliance sin base no arrancaría el
  comando de bootstrap).
- **Es SIMÉTRICO con los permisos**: `openfga:provision` ya lee los PERMISOS del modelo del config
  estático (`config.catalogs`, funciones del consumidor), no de `authz_permissions`. Los tipos de
  relación salen del MISMO sitio declarativo (`config.relations.config`), que es la instancia que este
  lote añade para cablear el singleton. Una fuente, no dos.

La tabla `authz_relations_config` (persistida) NO se toca: sigue siendo la config que
`authz:relations:reconcile` lee para vigilar la deriva del modelo fusionado del DESTINO en `--dry-run`.

---

## El singleton `RelationsManager` de servicio (la raíz)

El 4-6 dejó `config.relations` con solo `drivers` y el `RelationsManager` se construía a mano por el
consumidor. Ahora se resuelve como servicio, con el patrón EXACTO del `AuthorizationManager`:

- **`config.relations` gana dos claves** (`src/define_config.ts`): `config?: RelationsConfig` (la
  instancia de `defineRelationsConfig`, la MISMA que capturan las factories de `drivers`, así que la
  frontera F-05 del manager y la del driver son una sola) y `default?: string` (el driver de relaciones
  activo; cae al `default` de roles).
- **`buildRelationsManager(config)`** (`providers/authz_provider.ts`): función PURA que el provider usa
  para resolver `authz.relations`. Construye `new RelationsManager(relations.drivers[key](),
  relations.config, { requireActor })`. Sin `relations.config` o sin el driver activo lanza con la
  receta (ReBAC es opt-in). Se exporta para tener su caso sin montar la app.
- **Provider** (`providers/authz_provider.ts`): registra `authz.relations` como singleton del
  contenedor, junto a `authz.manager`.
- **Servicio** (`services/relations.ts`, subpath `@jantstack/adonis-authz/services/relations` en
  `package.json`): el análogo de `services/main.ts`, resuelto tras `app.booted()`.
- **`requireActor`** se hereda del config de roles: una sola política de auditoría.

Casos (memoria, todos los modos, `tests/relations_service.spec.ts`): el manager se cablea desde
`relations.config` + el driver activo (identidad del driver verificada); F-05 corta un tipo no declarado
con 422 ANTES del driver y un tipo declarado resuelve; `relations.default` elige el driver y sin él cae
al `default` de roles; sin `relations.config` lanza con la receta; `relations.config` sin el driver
activo lanza nombrando la clave; `requireActor` heredado ⇒ 422 `E_AUTHZ_ACTOR_REQUIRED` sin actor.

**Stub** (`stubs/config/authorization.stub`): declara `relationsConfig = defineRelationsConfig({...})`
(un tipo `document` de EJEMPLO) y la sección `relations: { config, default, drivers: { database:
() => new DatabaseRelationsDriver(relationsConfig), openfga: async () => { … /openfga … } } }`. El driver
`database` de relaciones se EXPORTA ahora desde `index.ts` (`DatabaseRelationsDriver` +
`DatabaseRelationsDriverOptions`); el `openfga` entra por el subpath `/openfga` DENTRO de la factory
(peer opcional, pureza). `configure.spec` (que compila los stubs con `tsc --noEmit`) sigue verde.

---

## `republishFusedModel` · BORRADO (no cableado), con justificación

`republishFusedModel` (la función de `src/relations_config_store.ts` y el método del driver `openfga`) se
**RETIRÓ**. Motivo: `openfga:provision` (que ahora fusiona los tipos de relación) + `authz:catalog:sync`
(que reproyecta el catálogo) **cubren TODOS los caminos de republicación de producción**, así que
`republishFusedModel` no tenía llamador y no lo iba a tener sin contorsiones:

- Su valor era el **CAS sobre `model_id`** que protege de una carrera entre dos republicaciones
  CONCURRENTES en runtime (`syncAuthzCatalog` ∥ `defineRelationsConfig` compitiendo por el `modelId`).
  Esa carrera **no ocurre en producción**: republicar el modelo es un paso MANUAL de operador
  (`openfga:provision`, un deploy), escritor único. Ni `syncAuthzCatalog` ni `saveRelationsConfig`
  reescriben el modelo (el sync solo proyecta tuplas del catálogo; `saveRelationsConfig` solo persiste el
  spec). O sea: el `model_id` pin y su CAS eran infraestructura para una carrera inexistente — justo el
  «código muerto» que ⚪4/bullet 3 pedía quitar.
- Cablearlo habría exigido flipar `openfga:provision` a `startApp: true` (regresión de bootstrap) y
  ramificar el comando (memo del catálogo vs `config.catalogs`, manejo del 409 cuando no hay fila de
  relaciones persistida). Más superficie, para code sin usuario.

Qué se borró: la función `republishFusedModel` y `FusedModelPublisher`/`readRelationsModelId`/`casModelId`
/`MAX_PIN_RETRIES` de `src/relations_config_store.ts`; el método `republishFusedModel` del driver
`openfga` (`src/drivers/openfga_driver.ts`); los exports de `index.ts` (`republishFusedModel`,
`readRelationsModelId`, `FusedModelPublisher`); y `tests/relations_republish.spec.ts` (probaba solo el
código retirado). Se CONSERVA `saveRelationsConfig`/`readRelationsConfig`/`readRelationsConfigSpec` y la
tabla `authz_relations_config` (los usa `authz:relations:reconcile` + los tests de config persistida).

**Breaking (alpha, sin consumidores):** desaparecen de la API pública `republishFusedModel`,
`readRelationsModelId` y `FusedModelPublisher`. Es 2.0.0-alpha; sin flags de compat.

---

## Lo que NO hice (y por qué)

- **NO flipé `openfga:provision` a `startApp: true`** ni lo hice leer `authz_relations_config` de la
  base: `startApp: false` (bootstrap sin base) es su contrato y el config estático es la fuente simétrica
  con los permisos. Es la desviación de diseño respecto al literal del encargo, argumentada arriba y
  MEDIDA (el kernel de ace no bootea providers con `startApp: false`).
- **NO borré la columna `model_id`** de `authz_relations_config` en la migración: quitarla es un cambio
  de esquema que tocaría `stubs/migration.stub`, `tests/helpers/schema.ts` y `migration_stub.spec`.
  Queda una columna nullable sin uso (cleanup futuro, anotado en `relations_config_store.ts`). No
  concede nada.
- **NO añadí un comando `authz:relations:sync`** ni una republicación de modelo disparada por el
  servicio: no hace falta (provision + catalog:sync cubren la republicación) y habría sido superficie
  especulativa.
- **NO cambié la política de `requireWithin`** ni añadí `within` al `RelationsManager` de servicio: el
  puerto de relaciones no lo tiene (F-05 + `assertWrite` + `actor` es su barrera) y no era del encargo.
- **NO toqué** el driver `database`/`openfga` de relaciones, `reconcileRelations`, ni el parche del
  tester (`tests/relations_harness.spec.ts`): se construyó encima.

Con esto la **Fase 4 queda CERRADA**: el último ⚪ (wiring del servicio de relaciones) está cableado y el
único código muerto que quedaba (`republishFusedModel`) retirado.
