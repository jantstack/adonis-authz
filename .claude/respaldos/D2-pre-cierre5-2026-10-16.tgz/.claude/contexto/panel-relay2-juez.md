# Panel relay 2 — JUEZ · síntesis, puntuación y decisión

Entradas: `cognitiv-informe-2026-09-10.md` (3 bloqueantes + 7 menores), `panel-relay2-analista.md`,
`panel-relay2-auditor.md`, `panel-relay2-tester.md`. Base: `main`, `2.4.0-alpha.7`, commit `13ba731`.
Marco: `CLAUDE.md` (higiene de la outbox (i)–(viii), invariantes 1, 9, 11, «Cómo se decide un cambio»)
y `decisiones-dueno-2026-08-28.md` §2026-09-09 (2), §2026-09-10 (2) y (3).

**Criterios y pesos (declarados antes de puntuar, iguales para las ocho cuestiones):**

| Criterio | Peso | Qué mide aquí |
|---|---|---|
| Seguridad | 30 | 🔴/🟠 del auditor no mitigados EN la propia opción; fail-open/fail-closed medidos que la opción deja abiertos |
| Compatibilidad con el contrato | 25 | Invariantes 1/9/11 y reglas de higiene (i)–(viii) en riesgo; ¿rompe el puerto o el contrato PUBLICADO que corren terceros? |
| Verificabilidad | 20 | Veredicto del tester + coste de prueba + si el mutante muere |
| Coste y deuda | 15 | Líneas, superficie nueva, mantenimiento, `EXPECTED_CASES` |
| Reversibilidad | 10 | ¿Se deshace sin migración de datos, sin tocar el esquema del consumidor y sin major? |

La opción «no se hace» se puntúa como cualquier otra: no penaliza en coste, pero SÍ en seguridad si
deja abierto un riesgo MEDIDO (es el caso de los tres bloqueantes de COGNITIV).

Lecturas de código propias del juez (para arbitrar dos contradicciones): `src/manager.ts:1396-1451`
(`#parkedKeys` siembra con `#changeKeys`; `#dependencyOf` construye la lista a mano en `:1432` y en su
respaldo compara con `#changeKeys` **en los dos lados**, `:1441`), `src/manager.ts:1531-1534`
(«No pasa por la barrera del freeze: no escribe en el backend» — literal en el docblock de
`requeueScopeChanges`) y `src/testing/scope_outbox_contract.ts:293`
(`const ctx = (actor?) => (actor ? { actor } : {})`: el contrato PUBLICADO nunca encola con transacción).

---

## Veredicto

**Recomendación global:** publicar **`2.4.0-alpha.8` estrictamente aditiva** con el Lote A (los tres
bloqueantes), el Lote B (menores baratos) y el Lote C (relaciones, con el bug NUEVO del analista
primero). **Supersede y `parkAfterMs` no se hacen.** La variante B del tapón entra **solo con el «sí»
del dueño** y con el caso adversarial que la ata.

| # | Cuestión | Decisión (puntuación de la ganadora) |
|---|---|---|
| 1 | Raíz `app` como clave | **Exentarla en los TRES sitios, por REF, en el MANAGER** (87/100). Puerto intacto. Conjunto mínimo: A-1, A-2, A-3, A-8 + negativos A-4/A-6/A-7 + desdoble O-07a/b (`EXPECTED_CASES` 15→16) + `CLAUDE.md:742` |
| 2 | Variante B (censo solo clave del HIJO) | **SÍ, condicionada al dueño** (81 vs 78 del statu quo). Compatible con el 🔴 1 del auditor: en ese escenario el hijo ES `unit`, que es justo la clave que retiene al `attached` de en medio. **Solo en `#parkedKeys`, jamás en `#changeKeys`** (trampa medida por el juez) |
| 3 | Supersede | **NO se hace** (95/100 para «no se hace»). Requisito que sí se registra: **`authz:reconcile` acotado por subárbol/tenant** + diagnóstico read-only `supersededBy` en `dead[]` |
| 4 | `requeue(ids, { apply: true })` | **SÍ, con cuatro condiciones bloqueantes** (83/100): sin lease propio, pasa la barrera del freeze, excluyente con `force` (500 si llegan juntos), `only` interno = exactamente los ids reencolados. **Lease tomado ⇒ `busy` con CERO filas reencoladas y exit ≠ 0** (todo o nada) |
| 5 | Edad de la cola | **`oldestPendingAt`/`pendingAgeMs` GLOBALES bajo `only` + `--max-age`; `parkAfterMs` NO** (87/100). `createdAt?` opcional en el puerto; la edad la calcula el reloj INYECTABLE con `Math.max(0, …)`, nunca `Date.now()` en `src/` |
| 6 | `enqueue` sin `{ transaction }` | **Opt-in `requireTransaction` en 2.4, default `true` anunciado para 2.5** (84 vs 52). El default inmediato rompe el contrato PUBLICADO (`ctx()` sin trx, 15 casos que corren TERCEROS) ⇒ sería major por la regla 4 |
| 7 | Menores | `origin` SÍ · `deadCount` SIEMPRE + `deadDetail: 'ids'` opt-in (el `actor` NO fuga: `change` sí) · trx cerrada ⇒ `E_AUTHZ_CONFIG` SÍ (4 líneas, los 3 puertos) · **el bug del cursor es 🟠 y va PRIMERO** (500 ruidoso, luego nativo; sin capacidad nueva) · `waitForLeaseMs` SÍ con default 0 · 422 sin nombrar el servidor + `maxDepth = N + 1` SÍ |
| 8 | Versionado y lotes | `2.4.0-alpha.8` = A + B + C. Camino crítico **A1 → A2**. Fuera: supersede, `parkAfterMs`, `blockOnParentKey`, capacidad `enumerateRelationsManyNative`, default de `enqueue`, `--apply` por defecto |

**Injertos de las opciones perdedoras** (de dónde vienen):
- del **auditor**: la exención se decide sobre el REF (`type === APP_SCOPE_TYPE && uuid === null`),
  nunca comparando la cadena `'app'`, y en UN solo `isRootRef` para los tres sitios (🟠 3);
  `apply` y `force` mutuamente excluyentes (🟠 6); el mensaje del gate de `enqueue` nombra **S5**, no
  «falta un parámetro» (🟠 7); `authz:reconcile --to=<driver>` como remedio publicado en vez de
  supersede.
- del **tester**: la exención vive en el MANAGER y el puerto queda intacto (así `scope_outbox.spec.ts:1969`
  y `:2297` siguen siendo cobertura real del SQL de la sonda); `deadCount` no basta sin la letra del
  README de qué campos son seguros (D-4); `X-1` (opción desconocida ⇒ 500) como hermano obligatorio de
  `apply` y de `waitForLeaseMs`; `R-8` (freeze) como caso bloqueante.
- del **analista**: reusar el `pending(1)` que la pasada YA hace en vez de un `MIN(created_at)`
  (1,59 vs 1,63 ms, y `MIN` degrada con la cola); `deadCount` como precio de admitir la redacción;
  el gate de `enqueue` en el config del MANAGER (vale para cualquier puerto), no solo en `sqlScopeOutbox`.
- del propio **juez**: `--wait-lease-ms` compone con `--apply` (el comando que cierra el incidente no
  debería perder contra el cron); la variante B **no puede** implementarse en `#changeKeys`.

**Condición para proceder:** ninguna para el Lote A/B/C salvo las cuatro condiciones de la cuestión 4
y los casos A-2/A-3/A-8 (sin ellos el lote se cierra en VERDE con el mutex vivo — medido por el tester).
El Lote D (variante B) **no arranca sin el «sí» del dueño** (pregunta 1).

---

## Cuestión 1 · Exentar la raíz `app` como clave

Opciones: **(A)** exención en los tres constructores (`#changeKeys`, la lista de `#dependencyOf`, la de
`requeueScopeChanges`), por REF, en el manager — analista; **(B)** `blockOnParentKey` / opción de
config; **(C)** exentar solo el TAPÓN y la SONDA y dejar el bloqueo por FALLO tal cual — auditor.

| Criterio (peso) | (A) los 3 sitios | (B) config | (C) tapón+sonda, fallo intacto | Nota |
|---|---|---|---|---|
| Seguridad (30) | 9 | 6 | 7 | (A) cierra el mutex y los tres síntomas (I, II, III). (B) deja el default roto. (C) deja el par «`attached(A,app)` falla + `attached(B,app)`» aplazado una pasada sin ganar nada: el auditor buscó y **no encontró** ningún par cuyo único cruce sea `app` y cuyo orden importe |
| Compat. contrato (25) | 9 | 7 | 8 | Ninguna toca el puerto. (A) cambia comportamiento observable = exactamente el bug. (C) introduce una TERCERA semántica («la raíz no es clave, salvo para el fallo») que ningún caso fija |
| Verificabilidad (20) | 8 | 5 | 6 | Medido por el tester: hoy **cero** casos mueren; con el mutante total mueren 18 ⇒ el mecanismo está cubierto, la raíz no. (B) duplica lo que hay que probar (dos despliegues) |
| Coste y deuda (15) | 9 | 5 | 8 | (A) +14/−6 líneas, suite 1026/1026 medida en `lab` |
| Reversibilidad (10) | 8 | 7 | 8 | Sin datos ni esquema; se deshace con un revert |
| **Total** | **87** | **60** | **73** | |

**Decisión: (A).** Forma exacta:
1. **Un solo predicado** `isRootRef(scope)` = `scope.type === APP_SCOPE_TYPE && scope.uuid === null`
   (auditor 🟠 3(b): por REF, jamás por la cadena `'app'`; el auditor ya demostró que `scopeKey` no se
   puede falsificar, pero la regla se escribe igual).
2. Se aplica en los **tres** constructores: `#changeKeys` (`src/manager.ts:1959` — de ahí lo heredan
   `#parkedKeys`, `block`, `#blockOriginOf` y el respaldo de `#dependencyOf`), la lista de scopes de
   `#dependencyOf` (`:1432`, que es la que va al SQL de `earlierPending`) y la de `requeueScopeChanges`
   (`:1577`, la que va a `laterApplied`). La lista **nunca queda vacía**: siempre va el hijo.
3. **En el MANAGER; el puerto no se toca** (tester). `sqlScopeOutbox` sigue sabiendo buscar por la raíz
   (`parent_type='app' AND parent_uuid IS NULL`), y `scope_outbox.spec.ts:1969`/`:2297` siguen verdes
   como cobertura de ese SQL, anotados con «el manager ya no se lo pide — ver A-8».
4. Se exime también el bloqueo por FALLO (contra el auditor): medido en `m2-orden.ts` que no pierde
   orden, y mantener una sola regla vale más que ahorrar una pasada de aplazamiento.

**Conjunto mínimo de casos que hace observable la raíz** (sin esto el lote es verde y falso):

| Caso | Sitio que caza | Por qué es mínimo |
|---|---|---|
| **A-1** aparcada `attached(orgA, app)` + `attached(orgB, app)` ⇒ B aplica en la 1.ª pasada | S1 `#changeKeys` | Es el síntoma que COGNITIV midió (5 pasadas `applied = []`) |
| **A-2** lo mismo con `only: [idB]` (la receta inline), contra `memoryQueue` **y** `sqlScopeOutbox` | S2 `#dependencyOf` | Sin él, exentar solo S1 deja el mutex vivo en el camino real de COGNITIV (🟠 3 del auditor, medido) |
| **A-3** aparcada `attached(orgA, app)` + `attached(orgB, app)` APLICADA ⇒ `requeue([idA])` **entra** | S3 `laterApplied` | Hoy 500 `E_AUTHZ_REQUEUE_REFUSED` por conflicto FALSO (bloque D del tester; síntoma III del analista) |
| **A-8** espía: el array de `scopes` que va a `earlierPending` **no** contiene `{type:'app'}` | S2, a nivel de llamada | Mata al mutante «exención solo en S1» aunque el resultado coincida por otra razón |
| **A-4** `detached(orgA)` que FALLA + `attached(orgA, app)` (mismo uuid) ⇒ sigue `deferred` | negativo | Fija que la exención **no** se lleva por delante la clave del HIJO (el orden que sí importa) |
| **A-6** `moved(unit1, app)` + `attached(unit2, app)` ⇒ los dos aplican | borde | El par que el auditor no consiguió romper |
| **A-7** `moved(unit1, app)` + `moved(unit1, orgB)` ⇒ la 2.ª sigue `deferred` por `unit\|1` | negativo | Mata al mutante «exención por `op`» o «vaciar las claves» |
| **O-07a/O-07b** desdoble en `src/testing/scope_outbox_contract.ts:418` | puerto | (a) tal cual; (b) dos `attached` bajo `app`, el primero falla, el segundo **se aplica**. `EXPECTED_CASES` 15 → **16** (`tests/scope_outbox_harness.spec.ts:70` y `:76,:77,:84`) |
| **A-9** letra: README/docblock dicen POR QUÉ (no se mueve, no se purga, nunca es hijo) citando los tres 422 que lo sostienen (`manager.spec.ts:1315-1317`, `scope_outbox.spec.ts:422`) | letra | La premisa de la exención es esa, no un detalle |

Corrección de letra obligatoria: **`CLAUDE.md:742`** («la raíz `app` también es clave: dos `attached`
bajo `app` se contaminan entre sí») pasa a ser FALSA ⇒ reescribir, junto con el punto (ii) del bloque
de higiene y README 139/141/145/149.

---

## Cuestión 2 · Variante B (el censo siembra solo la clave del HIJO)

| Criterio (peso) | Variante B | Statu quo (alpha.5 tal cual) | Nota |
|---|---|---|---|
| Seguridad (30) | 8 | 4 | El statu quo deja el fail-open que COGNITIV describe: una aparcada `moved(unit→orgA)` congela TODO `moved` posterior de `orgA` ⇒ el store conserva el padre VIEJO **sin caducidad**. La variante B lo cierra sin abrir nada medido: `attached(doc, unit)` y `moved(unit→orgC)` **siguen aplazados** (m7), y `detached` sigue pasando |
| Compat. contrato (25) | 8 | 10 | Cambia una decisión ESCRITA de alpha.5 (higiene (ii)) que **ningún caso fija**. No toca el puerto ni tipos |
| Verificabilidad (20) | 7 | 8 | 4–5 casos nuevos; el auditor **no la atacó** (su 🔴 1 es de supersede) ⇒ incertidumbre residual que se compra con un caso |
| Coste y deuda (15) | 9 | 10 | 1 línea en `#parkedKeys` |
| Reversibilidad (10) | 9 | 10 | Revert de una línea |
| **Total** | **81** | **78** | Diferencia dentro del ruido ⇒ es decisión del dueño, no del juez |

**¿Compatible con el 🔴 1 del auditor?** **Sí, y es el punto clave.** En el escenario del 🔴 1
(`#1 moved(unit→orgA)` APARCADA, `#2 attached(child, unit)`, `#3 moved(unit→orgB)`), el **hijo** de la
aparcada es `unit`, que es exactamente la clave que retiene a `#2` (`src/manager.ts:1245`) y, por
transitividad, a `#3`. La variante B solo deja de sembrar `organization|A` —el padre NUEVO—, y ninguna
entrada posterior que toque `orgA` como su propio padre interactúa con la arista `unit→orgA`. El 🔴 1
es un ataque a **supersede** (que vacía la clave del hijo), no a la variante B.

**Trampa de implementación (hallazgo del juez, no está en ninguna de las tres posturas):** la variante B
tiene que vivir **solo en la siembra** (`src/manager.ts:1411`, dentro de `#parkedKeys`). Si se
implementa dentro de `#changeKeys`, el respaldo de `#dependencyOf` (`:1441`) compara
`#changeKeys(earlier)` contra `#changeKeys(mine)` en los **dos** lados y se pierde la protección del
caso 1136: un `attached(org, app)` fallido dejaría de retener a `attached(unit, org)` (claves `[org]`
vs `[unit]`, sin cruce) y el hijo colgaría de un padre que no está en el store. La regla, escrita:
**al SEMBRAR sobra el padre; al COMPARAR van siempre las dos claves.**

**Decisión: SÍ, condicionada al «sí» del dueño (Lote D), con estos casos:** los cuatro de `m7`
(`attached(doc,unit)` y `moved(unit→orgC)` siguen `deferred`; `attached(otraUnit, orgA)` pasa a
`applied`; `detached(unit)` aplica) **más** el escenario literal del 🔴 1 fijado como negativo
(`#2` sigue `deferred` con la aparcada viva) **más** un caso que mate al mutante «variante B metida en
`#changeKeys`» (= el 1136 con la sonda por respaldo, sin `earlierPending`).

---

## Cuestión 3 · Supersede

| Criterio (peso) | No se hace | Con las condiciones (a)–(d) del auditor | Diagnóstico read-only |
|---|---|---|---|
| Seguridad (30) | 9 | 5 | 9 |
| Compat. contrato (25) | 10 | 5 | 10 |
| Verificabilidad (20) | 9 | 4 | 8 |
| Coste y deuda (15) | 10 | 3 | 9 |
| Reversibilidad (10) | 10 | 3 | 9 |
| **Total** | **95** | **43** | **91** |

Notas: la columna del medio arrastra el 🔴 1 medido (`relay2-auditor-3.ts`: con supersede el store
queda `child→unit→orgV→app` y `dead()` vacío, cero alarma), el 🟠 4 (si «obsoleta» se escribe como
`applied_at`, `laterApplied` miente y el operador acaba en `--force`), el 🟡 8 (borra la alarma de un
tenant con el tráfico de otro), **tres subespecificaciones abiertas** del tester (§2.1), un estado
terminal nuevo en la cola (columna ⇒ migración en una tabla que es del CONSUMIDOR), `EXPECTED_CASES`
15 → 17 y un cambio de la frase publicada «aparcar no es olvidar».

**Decisión: no se hace, ni en alpha.8 ni con condiciones.**

**Respuesta a la pregunta del auditor («¿por qué no `authz:reconcile --to=<driver>`?»):** es el remedio
correcto y ya está publicado — recalcula con el árbol de HOY, no reordena nada y es lo que el propio
500 de `requeue` recomienda. Lo que falta es su **alcance**, y eso se dice como requisito, no como
supersede:

> **Requisito registrado (2.5): `authz:reconcile` acotado.** `--to=<driver>` con un acotador por
> subárbol (`--scope=<tipo>|<uuid>`, descendientes incluidos) y `--dry-run` primero, para que un
> operador pueda reconciliar el árbol de UN tenant sin una pasada global. Sin eso, el runbook de un
> incidente de un tenant obliga a una pasada de plataforma, que es la razón por la que COGNITIV pidió
> supersede.

**Injerto barato que sí entra en alpha.8** (idea del analista, sin tocar la cola): marcar en el reporte
`dead[]` cuál tiene un cambio POSTERIOR del mismo hijo (`supersededBy: <id>`), **read-only**, para que
el operador sepa cuál no merece `requeue`. Cero estados nuevos, cero migración.

---

## Cuestión 4 · `requeueScopeChanges(ids, { apply: true })`

| Criterio (peso) | (a) Sin lease propio, dentro del lease del relay | (b) Llama a `relayScopeChanges` por dentro | (c) No se hace | Nota |
|---|---|---|---|---|
| Seguridad (30) | 9 | 3 | 4 | (b) es `busy` en VERDE medido (`relay2-auditor-4.ts` `[L]`) y, sin R-8, un bypass del freeze durante el cutover. (c) deja abierta la ventana de «padre VIEJO en el store» que el dueño ya clasificó 🔴 el 09-09 |
| Compat. contrato (25) | 8 | 6 | 10 | (a) compone `ScopeRequeueReport` con el del relay y **cambia la letra del docblock** `manager.ts:1533` («no pasa por la barrera del freeze») |
| Verificabilidad (20) | 8 | 6 | 10 | 11 casos del tester; R-2 (exactamente UNA adquisición), R-4 (orden sonda→requeue→aplicar), R-8 (freeze) son los que deciden |
| Coste y deuda (15) | 7 | 9 | 10 | +4 líneas de mecánica, el coste real son los casos |
| Reversibilidad (10) | 9 | 7 | 10 | Opción nueva; se retira sin datos |
| **Total** | **83** | **57** | **82** | (a) gana por poco; lo que lo decide es la seguridad, que es el criterio de más peso y el único donde (c) pierde |

**Decisión: (a), con cuatro condiciones BLOQUEANTES:**
1. **No toma lease propio.** El lease se adquiere UNA vez para toda la llamada y el requeue va dentro
   (auditor 🟠 5; tester R-2 con espía sobre `outbox.acquire`).
2. **Pasa la barrera del freeze.** Hoy `requeue` la salta a propósito porque no escribe; con `apply`
   escribe ⇒ la barrera se evalúa **antes** de tocar nada y el docblock se corrige (tester R-8; sin
   este caso el cambio abre un bypass del cutover).
3. **`apply` y `force` no componen**: 500 `E_AUTHZ_CONFIG` si llegan juntos, y `apply` solo por API de
   plataforma / comando ace, jamás por HTTP (auditor 🟠 6: con las dos, revertir el árbol pasa de dos
   llamadas de plataforma a una).
4. **El `only` lo construye el método** = exactamente los ids reencolados. Se **rechaza** la superficie
   R-3 del tester (`{ apply: true, only: [...] }` para arrastrar dependientes): rompe «`only` = mi
   recibo» (analista), que es la propiedad que hace defendible la receta inline. Los dependientes
   quedan `deferred` y el reporte lo dice; el operador reencola también los suyos o corre una pasada
   completa. **Ese es el caso**, no la opción.

**Comportamiento con el lease tomado (la pregunta del encargo):** **no se reencola NADA.** El lease se
intenta PRIMERO; si está ocupado, el reporte sale `busy: true`, `requeued: []`, **cero filas tocadas** y
el comando sale ≠ 0 con la letra («otra pasada tiene el lease; reintenta, o `requeue` sin `--apply`»).
Motivo: `requeue` ya es todo-o-nada, y la alternativa («reencolo y digo `busy`») deja una entrada
`pending` con `attempts = max − 1` que **se vuelve a aparcar en la primera pasada y contamina su clave
otra vez** (auditor 🟠 5, medido). Injerto del juez: `--apply` acepta `--wait-lease-ms` (cuestión 7)
para que el comando que cierra el incidente no pierda sistemáticamente contra el cron.

**`--apply` NO es el default del comando** (contra el analista, con el auditor): hoy el comando no
escribe en el backend; que pase a escribir por defecto cambia en silencio el runbook publicado y el
significado del exit code. Explícito, como `--force`.

**Prerrequisito de honestidad:** X-1 del tester (una opción desconocida ⇒ 500 `E_AUTHZ_CONFIG`
nombrándola). Hoy `{ apply: true }` **se ignora en silencio** (medido), y publicar `apply` sin cerrar
esa puerta deja a un consumidor en JS creyendo que aplica cuando no aplica.

---

## Cuestión 5 · Edad de la cola

| Criterio (peso) | (i) `oldestPendingAt`+`--max-age`, sin aparcar | (ii) + `parkAfterMs` | (iii) edad calculada por la BASE | Nota |
|---|---|---|---|---|
| Seguridad (30) | 8 | **1** | 8 | (ii) trae el 🔴 2 MEDIDO: con la cola aparcada en masa, `#parkedKeys` alcanza `PARKED_CENSUS_MAX` y **toda** pasada es 500 ⇒ los `moved` conservan el padre viejo y los `detached` no purgan nunca. Y contradice la decisión (i) del dueño del 09-09 |
| Compat. contrato (25) | 9 | 3 | 6 | (iii) rompe la inyectabilidad del reloj (invariante del `clock`) y los casos E-1/E-9 |
| Verificabilidad (20) | 9 | 5 | 4 | (i) sin `sleep`, con reloj inyectado, en los 4 motores |
| Coste y deuda (15) | 9 | 5 | 6 | (i) 0 consultas nuevas: la pasada YA hace `outbox.pending(1)` |
| Reversibilidad (10) | 9 | 4 | 6 | |
| **Total** | **87** | **17** | **62** | (ii) queda además **descalificada** por 🔴 no mitigado |

**Decisión: (i).** Forma exacta:
- **Puerto:** `createdAt?: Date` opcional en `PendingScopeTreeChange` (`rowToPending` lo mapea; la
  columna ya existe en el stub y `select *` ya la trae). Un puerto de terceros que no lo traiga deja el
  campo **ausente**, jamás `0` ni `now` (mismo patrón que `stillGranting`/`countRoleAssignments`,
  invariante 18). **No** se añade `oldestPending?()`: el `pending(1)` que la pasada ya hace es la cabeza
  global de la cola (`orderBy id asc`) y `MIN(created_at)` degrada con la cola (1,63 vs 1,59 ms medidos).
- **Reloj:** la edad la calcula la BASE del paquete con `this.#config.clock ?? systemClock`, nunca un
  `Date.now()`/`new Date()` en `src/` (lo caza el grep de `tests/clock.spec.ts` — es una red que ya
  existe). Contra el ⚪ 11 del auditor («que la mida la base con `CURRENT_TIMESTAMP`»): eso rompería la
  inyectabilidad y los casos E-1/E-9 del tester; la defensa contra el skew entre réplicas es
  `Math.max(0, …)` (E-6, nunca negativa) **más** la letra del README: «la edad es la del reloj de quien
  encoló». Contradicción resuelta a favor del tester, con la mitigación del auditor escrita.
- **Bajo `only`: GLOBAL**, agrupado en `queue: { oldestPendingAt, pendingAgeMs, pending }`. Los dos
  panelistas que la miraron coinciden y el auditor lo dice con el argumento correcto: **no filtran
  identidad de nadie** (a diferencia de `dead`, 🟡 9); como máximo publican «hay backlog». Además,
  `remaining` y `dead` ya son globales: hacerlo per-`only` inventaría una tercera política.
- **Comando:** `authz:scopes:relay --max-age=<ms>` ⇒ exit ≠ 0 solo si se supera el umbral; **sin
  umbral, solo informa** (E-10: un exit ≠ 0 por edad sin umbral deja el cron rojo para siempre).
- **Bordes fijados:** cola vacía ⇒ campo ausente (E-3); solo aparcadas ⇒ ausente (E-4: lo aparcado ya
  tiene su alarma); outbox de terceros sin `createdAt` ⇒ ausente y pasada verde (E-5).
- **`EXPECTED_CASES` no sube por esto**: `createdAt` entra como campo opcional que degrada, no como
  deber del puerto (convertirlo en par de capacidad es 2.5).

---

## Cuestión 6 · `enqueue` sin `{ transaction }`

| Criterio (peso) | Opt-in en 2.4 + default en 2.5 | 500 por defecto YA | Nota |
|---|---|---|---|
| Seguridad (30) | 7 | 9 | El 🟠 7 es real y **silencioso** (fuga S5 en el camino de uso correcto: el consumidor hace rollback y el relay aplica al store un cambio que en su base no ocurrió). El opt-in lo mitiga a medias: con `warnOnOptInSecurity` avisando y la letra en el README |
| Compat. contrato (25) | 9 | **2** | Verificado por el juez: `src/testing/scope_outbox_contract.ts:293` — el `ctx()` del contrato PUBLICADO **nunca** lleva transacción. Un default 500 pone rojos los 15 casos que corren los TERCEROS contra su propia outbox ⇒ es un cambio del contrato para drivers de terceros ⇒ **major** por «Cómo se decide un cambio» (4). Más decenas de casos propios y los seeders/comandos |
| Verificabilidad (20) | 9 | 5 | T-1 (500 y CERO filas, antes del INSERT) + T-3 (con la opción apagada, todo como hoy) |
| Coste y deuda (15) | 9 | 4 | Opt-in: ~10 líneas. Default: hay que reescribir el `ctx()` del contrato y avisar a terceros |
| Reversibilidad (10) | 9 | 4 | |
| **Total** | **84** | **52** | |

**Decisión: opt-in ahora.** Contradicción auditor↔tester resuelta **a favor del tester**, con evidencia
propia del juez (la línea 293), y con el auditor injertado en el resto:
1. `scopes.requireOutboxTransaction: true` en el config del **MANAGER** (analista: vale para cualquier
   implementación del puerto, no solo `sqlScopeOutbox`), comprobado en los tres `enqueue` justo tras
   `this.#outbox()`; y `sqlScopeOutbox({ requireTransaction })` como segunda puerta para quien use la
   outbox directa. Es el patrón de dos puertas ya publicado para `{ transaction }`.
2. **El mensaje nombra S5** (auditor): «la fila se confirmaría fuera de tu unidad de trabajo; si tu
   transacción revierte, SQL diría un padre y el PDP otro», no «falta un parámetro».
3. `warnOnOptInSecurity` avisa cuando la opción está apagada.
4. **README + CHANGELOG anuncian el default `true` para 2.5**, y el trabajo de habilitarlo (que el
   `ctx()` del contrato publicado pase una transacción, con su par de capacidad) se registra como
   prerrequisito de esa 2.5. Sin ese trabajo el default nunca podrá cambiar.

---

## Cuestión 7 · Los menores

### 7.1 · El bug NUEVO del analista (respaldo de `enumerateRelationsMany` que pierde tuplas)

Severidad: **🟠 alto, no 🔴** — y **va PRIMERO en su lote**. Razones: es una pérdida **silenciosa** en el
camino de uso correcto (medido: 6 tuplas en el store, 5 vistas, `a9` perdida al reanudar con el cursor),
pero (a) no es un bypass de autorización ni un fail-open del PDP: una tupla perdida **deniega**, no
concede; (b) `authz:reconcile` está a salvo (`relations/reconcile.ts::enumerateAllMany` pagina por
partición, verificado por el analista); (c) el daño real es una MIGRACIÓN que declara «esa tupla no
existía». No descalifica el lote, pero manda dentro de él.

| Criterio (peso) | (a) 500 ruidoso + nativo en `database` | (b) solo capacidad `…Native` | (c) no se toca |
|---|---|---|---|
| Seguridad (30) | 9 | 5 | 3 |
| Compat. contrato (25) | 8 | 8 | 10 |
| Verificabilidad (20) | 8 | 7 | 9 |
| Coste y deuda (15) | 7 | 9 | 10 |
| Reversibilidad (10) | 8 | 9 | 10 |
| **Total** | **83** | **68** | **72** |

**Decisión: (a), y en este orden**: primero **C2** (el respaldo del manager deja de mentir: 500 en cuanto
una partición devuelve cursor — misma doctrina que el barrido único de `enumerateRelations` decidido el
2026-09-10 (3): «si no puede enumerar exhaustivamente, falla ruidoso»), después **C1** (nativo en
`database_relations_driver`, ~35 líneas, con el caso M-2 del tester y su espía de consultas: UNA
consulta, salida byte a byte igual a K × `enumerateRelations`), después **C3** (el mutante «cursor de la
última partición»). **La capacidad `enumerateRelationsManyNative` NO se añade**: con los dos drivers
publicados nativos y el respaldo ruidoso, la pregunta de COGNITIV («¿estoy en el camino de respaldo?»)
deja de existir. Si un tercero la necesita, es 2.5 con su par de capacidad.

### 7.2 · El resto

| Punto | Decisión | Forma exacta / condición |
|---|---|---|
| `origin` en `entries` | **SÍ** | `blocked: Map<key,{id,parked}>` → `{id, origin: 'parked'\|'pending'\|'failed'}` con precedencia `failed > pending > parked`; el `origin` se DERIVA de `blocked`, nunca del prefijo del texto de `reason` (mutante O-1). **Cuidado**: la exención del `detached` (invariante 11) sigue mirando solo `origin === 'parked'`. Casos O-1..O-4 + ampliar `scope_outbox.spec.ts:1845` |
| `dead` bajo `only` | **`deadCount` SIEMPRE + `deadDetail: 'ids'` opt-in** | Corrección aceptada y escrita: **el `actor` no viaja** (`RelayedScopeChange` = `{id, change, attempts, error}`); lo que identifica al otro tenant es **`change`**, así que quitar solo `lastError` no cierra nada (auditor 🟡 9, tester §6). `deadCount` es aditivo y arregla además que `dead.length` MIENTE al llegar a `batchSize`. **No se hace `change?` opcional**: rompería a los lectores en compilación y contradice la adenda del dueño del 09-10 (1) («cambiar el tipo según haya filtro rompería lectores»); por eso la redacción es **opt-in** (`deadDetail: 'ids'` ⇒ `dead: []` + `deadIds` + `deadCount`) y **nunca** `dead: []` a secas. Más D-4: el README dice qué campos son seguros |
| Trx cerrada ⇒ `E_AUTHZ_CONFIG` | **SÍ** | 4.ª comprobación en `assertCallerTransaction` (`trx.isCompleted === true` ⇒ 500 nombrando la operación), **antes** de la sentencia. Una línea, tres puertos (outbox, roles L-3, relaciones L-4): C-4 del tester es quien decide el sitio. Ningún caso fija hoy el 503 |
| `waitForLeaseMs` | **SÍ, default 0** | Opt-in, sondeo cada 50 ms, `busy` al vencer y **jamás** un cuelgue. **Default 0 obligatorio**: cualquier otro pone flaky `scope_outbox.spec.ts:2460` («dos pasadas a la vez ⇒ `busy`»), que es el caso a releer (W-2). Exige **pool ≥ 2** escrito (como `{ transaction }`): con pool 1 el que espera puede estar reteniendo la conexión del que tiene el lease. El caso de verdad va a `tests/scope_outbox_multiprocess.spec.ts` (W-4), no en proceso |
| 422 de profundidad | **SÍ** | El `message` deja de nombrar `openfga`, `FACTS_MAX_RESOLVE_DEPTH` y `OPENFGA_RESOLVE_NODE_LIMIT`; queda lo accionable (profundidad alcanzada, `scopes.maxDepth`, «no se ha escrito ni encolado nada») y el porqué se va al docblock/README/log del operador. L-1 (`notInclude` ×3) + L-2 |
| `maxDepth = N + 1` | **Solo docs + caso** | No se cambia la semántica a NIVELES (breaking, y la unidad correcta es la que gasta el presupuesto de FGA). N-2 (árbol de N=3: `maxDepth: 3` ⇒ 422, `maxDepth: 4` ⇒ entra) vale más que la frase del README |
| Opciones desconocidas | **SÍ (X-1)** | `relayScopeChanges`/`requeueScopeChanges` con una opción desconocida ⇒ 500 `E_AUTHZ_CONFIG` nombrándola. Hoy `{apply:true}` y `{waitForLeaseMs}` se ignoran en silencio (medido) |

---

## Cuestión 8 · Versionado y lotes

| Criterio (peso) | (A) alpha.8 = A+B+C | (B) alpha.8 = solo A + triviales | (C) A+B+C+D+supersede | Nota |
|---|---|---|---|---|
| Seguridad (30) | 9 | 7 | 4 | (C) mete el 🔴 1 del auditor |
| Compat. contrato (25) | 9 | 10 | 4 | (A) y (B) son aditivos: campo nuevo, opción nueva o corrección de algo roto; cero cambios de firma del puerto. (C) trae migración y `EXPECTED_CASES` 15→18 |
| Verificabilidad (20) | 8 | 9 | 4 | (A) ~40 casos nuevos, todos en ficheros existentes |
| Coste y deuda (15) | 8 | 9 | 3 | |
| Reversibilidad (10) | 8 | 9 | 3 | |
| **Total** | **86** | **85** | **4·30+…= 39** | (A) y (B) empatan casi; gana (A) porque el bug del cursor (7.1) no debe esperar y el Lote B es todo trivial/fácil |

**`2.4.0-alpha.8` (aditiva). Orden por camino crítico:**

| Lote | Pasos | Dificultad | Camino crítico |
|---|---|---|---|
| **A** (bloqueantes) | A1 exención de la raíz en los 3 sitios (`isRootRef`, manager) → **A2 los 9 casos + desdoble O-07 (`EXPECTED_CASES` 15→16)** → A3 `requeue{apply}` con las 4 condiciones → A4 `createdAt` + `queue.{oldestPendingAt,pendingAgeMs}` + `--max-age` → A5 docs (README 139/141/145/149, `CLAUDE.md` (ii) y **:742**, CHANGELOG) | A1 fácil · **A2 medio (es el trabajo de verdad)** · A3 medio · A4 fácil · A5 fácil | **A1 → A2**. A3 depende de B5 (X-1). El resto paralelo |
| **B** (menores) | B5 X-1 opciones desconocidas → B1 `isCompleted` (trivial) · B2 422 + docs `maxDepth` (trivial) · B3 `deadCount` + `deadDetail` (fácil) · B4 `origin` (fácil) · B6 `waitForLeaseMs` (fácil + W-4 medio) · B7 `requireTransaction` opt-in (fácil) | trivial/fácil | B5 primero (habilita A3 y B6 sin silencios) |
| **C** (relaciones) | **C2 el respaldo falla ruidoso (500)** → C1 nativo en `database` → C3 casos | C2 fácil-medio · C1 fácil-medio · C3 medio | C2 antes que C1: primero se deja de perder, luego se hace bien |
| **D** (dueño) | Variante B (1 línea en `#parkedKeys`) + 5 casos, incluido el negativo del 🔴 1 y el mutante «metida en `#changeKeys`» | medio (son los casos) | **No arranca sin el «sí»** |

**Qué NO se hace:** `parkAfterMs` (🔴 2, contradice la decisión (i)) · supersede en cualquiera de sus
formas · `blockOnParentKey` como opción de config · `only` que arrastre las reencoladas ·
`dead: []` bajo `only` sin `deadCount` · `change?` opcional en `RelayedScopeChange` · `maxDepth` a
NIVELES · capacidad `enumerateRelationsManyNative` · `enqueue` con 500 por defecto en 2.4 · `--apply`
como default del comando · cualquier deber nuevo del juez del puerto más allá del desdoble O-07 (+1).

**A 2.5 (registrado):** `authz:reconcile` acotado por subárbol/tenant; default `true` de
`requireTransaction` (con el `ctx()` transaccional del contrato como prerrequisito); `createdAt` como
deber del puerto con par de capacidad; capacidad `enumerateRelationsManyNative` si un tercero la pide;
retirada del nombre viejo del `GET_LOCK`; invariante 13 sobre el relay (⚪ 11, sigue sin runner).

---

## Conflictos entre panelistas

1. **Analista (exentar la raíz también en el bloqueo por FALLO) vs auditor (dejarlo tal cual).**
   → Gana el analista: `m2-orden.ts` mide que el par «`attached(A,app)` falla + `attached(B,app)`» no
   pierde orden, y el **propio auditor** declara que no encontró ningún par cuyo único cruce sea `app` y
   cuyo orden importe. Mantener dos semánticas de la raíz (exenta para el tapón, clave para el fallo)
   es una tercera regla que ningún caso fijaría. **Carga de la prueba**: quien quiera conservar el
   bloqueo por fallo bajo la raíz tiene que exhibir el par; nadie lo ha exhibido.
2. **Auditor 🟠 7 (500 por defecto en `enqueue`) vs tester (opt-in).** → Gana el tester, con evidencia
   del **juez**: `src/testing/scope_outbox_contract.ts:293` — el contrato PUBLICADO encola sin
   transacción en sus 15 casos, que son los que corren los terceros. El default sería breaking del
   contrato ⇒ major (regla 4). El fondo del auditor se acepta entero: gate real, antes del INSERT, con
   S5 en el mensaje, y default anunciado para 2.5.
3. **Auditor ⚪ 11 (la edad la calcula la BASE) vs tester (rompe el reloj inyectable).** → Gana el
   tester: la hora de pared solo se lee en `src/clock.ts` y hay un grep que lo defiende; sellar
   `created_at` con `CURRENT_TIMESTAMP` mataría E-1/E-9. Se injerta la preocupación del auditor como
   defensa (`Math.max(0, …)`, E-6) y como letra («la edad es la del reloj de quien encoló»).
4. **COGNITIV punto 5 («les llega `last_error` y actor de otros tenants») vs auditor y tester.** → Los
   dos panelistas lo desmienten leyendo el mismo sitio: `RelayedScopeChange` no lleva `actor`. La
   petición se atiende, pero por otra vía: lo que fuga es `change`. **Hay que decírselo a COGNITIV con
   esa corrección**, o pedirán un arreglo que no arregla.
5. **Analista («la capacidad `…Native` sobra») vs tester M-1 («es barata») vs COGNITIV (la pide).**
   → Gana el analista, reforzado: con C2 (respaldo ruidoso) la capacidad deja de aportar información
   —el camino de respaldo ya no puede mentir— y `capabilities` no debe crecer por comodidad de
   diagnóstico (doctrina «cada valor declarado tiene un caso»).
6. **Analista (`--apply` como default del comando) vs auditor (`apply` con la misma letra que `force`).**
   → Gana el auditor: el comando pasa a ESCRIBIR en el store; un default silencioso cambia el runbook y
   el significado del exit code.
7. **Tester R-3 (superficie para arrastrar dependientes) vs analista («`only` = mi recibo»).**
   → Gana el analista. R-3 se reescribe como caso negativo: los dependientes siguen `deferred` y el
   reporte lo dice.
8. **Tester R-2b («hay que decidir qué pasa con el lease tomado») — abierto en las tres posturas.**
   → Lo decide el juez: cero filas reencoladas, `busy`, exit ≠ 0 (ver cuestión 4).

---

## Afirmaciones descartadas por falta de evidencia

- **Auditor, 🟠 5 en PG/MySQL**: autodeclarado 🟡 («el `postgres18` local rechazó las credenciales»).
  Se trata como incertidumbre, no como hecho — aunque la mitigación se exige igual porque la medida en
  sqlite existe y el argumento por construcción es sólido. Nota operativa: la contraseña está en
  `docker inspect postgres18` (`CLAUDE.md`, sección de comandos); **la medida en PG/MySQL es barata y
  debería acompañar al diff de A3**.
- **Auditor, 🟡 8 (supersede acciona borrado de alarma cruzado entre tenants)**: autodeclarado no
  medido, y depende de la config del consumidor. Irrelevante para el veredicto (supersede se rechaza).
- **COGNITIV, punto 5, «y actor de otros tenants»**: **falso**, verificado por dos panelistas en el
  código.
- **Analista, «valorar `--apply` como default del comando»**: sin evidencia ni argumento medido; se
  rechaza (ver conflicto 6).
- **Auditor, «exigir un token/flag de plataforma en la config» para `apply`**: propuesta razonable pero
  sin incidente ni medición; no entra en alpha.8. Queda como riesgo declarado (abajo).
- **Analista, variante B, «los otros tres casos no cambian»**: sí está medido (`m7-tapon.ts`), pero
  **nadie la ha atacado adversarialmente**. Por eso la decisión va condicionada y con el negativo del
  🔴 1 como caso obligatorio.
- **Tester, S-5 («¿un `detached` posterior supersede a un `moved` aparcado?»)**: marcado ❓
  subespecificado por él mismo. Moot.

---

## Riesgos que quedan aunque se elija la ganadora

1. **El lote puede cerrarse en verde con el mutex vivo.** Medido: exentar la raíz en UNO solo de los
   tres sitios deja la suite 1026/1026 en los cuatro motores. A-2, A-3 y A-8 son la única red.
2. **La carrera real (dos altas concurrentes con el store caído) no se observa.** Los casos A-* miden la
   decisión del relay, no la carrera; la infra multiproceso existe pero no tiene ningún caso sobre
   `parkedKeys`. Declarado, no propuesto (tester).
3. **`apply` sigue defendido por PROSA contra su exposición por HTTP.** Sube el premio de exponerlo: de
   «reordeno la cola» a «escribo el árbol del store de cualquiera».
4. **Un 503 eterno sigue sin converger** (precio declarado de la decisión (i)): tras alpha.8, la ÚNICA
   señal en ese hueco es la edad de la cola + el `--max-age` del cron. Si el cron no lleva umbral, no
   hay alarma.
5. **Skew de relojes entre réplicas**: la edad puede inflarse (nunca negativa, E-6). No observable en
   test; queda como letra.
6. **Cambio de comportamiento observable**: un `attached`/`moved` bajo la raíz que hoy sale `deferred`
   pasará a aplicarse. Es el bug, pero un consumidor que hoy dependa por accidente de ese aplazamiento
   lo notará. CHANGELOG con el porqué (regla 3).
7. **Invariante 13 sobre el relay sigue sin runner** (⚪ 11, Diferido 2.6+), y `{apply:true}` es la
   primera vez que un COMANDO escribe árbol fuera de una pasada de relay.
8. **Si entra la variante B mal implementada** (dentro de `#changeKeys`), se pierde la protección del
   caso 1136 en el respaldo de la sonda. El mutante que lo caza es obligatorio.

---

## Lo que preguntaría al dueño antes de implementar (tres, y solo cambian el veredicto)

1. **¿Entra la variante B?** El censo de aparcadas sembraría solo la clave del HIJO: 1 línea, cierra la
   variante fail-open que COGNITIV reporta (`moved(unit→orgA)` aparcada ⇒ todo `moved` de `orgA`
   congelado, store con el padre VIEJO sin caducidad), no toca el 🔴 1 del auditor… y **cambia una
   decisión escrita de alpha.5 que ningún caso fija**. Sin el «sí», el Lote D no arranca y ese
   fail-open sigue vivo.
2. **`enqueue` sin `{ transaction }`: ¿opt-in en 2.4 con default `true` ANUNCIADO para 2.5, o opt-in
   indefinido?** Anunciarlo compromete el trabajo de reescribir el `ctx()` del contrato publicado y
   avisar a los drivers de terceros (es un cambio del contrato). No anunciarlo deja la fuga S5 detrás
   de una opción que casi nadie encenderá.
3. **¿COGNITIV devuelve o loguea el reporte del relay dentro de la petición?** Si sí, el 🟡 9 del
   auditor sube a 🟠 y `deadDetail: 'ids'` debería ser el **default** bajo `only` (no opt-in) antes de
   añadirle un campo más al reporte. Es la única pregunta cuya respuesta cambia una decisión ya tomada
   arriba.

*(La cuarta pregunta del auditor —¿`requireWithin` en `true` en COGNITIV?— no se traslada: solo
afectaba a supersede, que se rechaza.)*
