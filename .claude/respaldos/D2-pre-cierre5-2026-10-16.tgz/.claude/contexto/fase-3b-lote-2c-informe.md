# Fase 3b · Lote 3b-2c — `authorize` de un solo `Check` (informe del implementador)

> Árbol principal, rama `v2/fase-3b`, base `aaf91dd` (3b-2b cerrado, 5 suites verdes).
> Sin commits (los hace el dueño).
> Encargo: `.claude/contexto/fase-3b-lote-2-plan.md`, sub-lote **3b-2c** y nada más.
> Diseño ya validado: `panel2-2026-08-28-juez.md`, cruce **6** (el literal del README) y cruce **1**
> (modelo (c2)).

## Cifras de partida (las que deja 3b-2b)

```
npm test              574
test:sqlite-file      576
test:pg               742
test:mysql            742
```

Todo lo de `facts` se demuestra contra el servidor real de `:8101`; los conteos de requests, contra
un doble en memoria (que es donde se pueden contar). Los stores que crea la suite se borran en el
`teardown` de cada grupo: al terminar no hay ninguno con prefijo `facts-*` en el `:8101`.

---

## Pieza 1 · `authorize` es UN solo `Check`

**Casos escritos** (`tests/openfga_facts.spec.ts`, grupo «facts · 3b-2c — `authorize` es UN solo Check»):

1. Un `check` de `can_<P>` sobre `scope:<key>` con el subject como user, con el instante de la
   operación en el `context` (K9): **1** `check`, **0** `batchCheck`, **0** `resolveChain`.
2. El `false` del Check es el `false` de la respuesta (denegación por defecto).
3. **Memo obligatorio**: un permiso desconocido es `false` y **no llega al servidor**.
4. Un fallo del backend es 503 `E_AUTHZ_BACKEND_UNAVAILABLE`, nunca un `false` silencioso.
5. En modo `resolver` (el default) nada cambia: sigue el `batchCheck` de la cadena y sí consulta el
   árbol del consumidor. Es el negativo que fija que el lote es **aditivo**.

**Rojo** (los tres que tenían que fallar; los otros dos ya pasaban porque describen el modo de hoy):

```
❯ facts · 3b-2c — `authorize` es UN solo Check / un `check` de `can_<P>` sobre `scope:<key>`: 0 batchCheck y 0 resolveChain
ℹ AssertionError: expected false to be true
❯ facts · 3b-2c — `authorize` es UN solo Check / el `false` del Check es el `false` de la respuesta (denegación por defecto)
ℹ AssertionError: expected [] to have a length of 1 but got +0
❯ facts · 3b-2c — `authorize` es UN solo Check / un fallo del backend es 503, nunca un `false` silencioso
ℹ AssertionError: el Check se cayó: debería haber lanzado: expected null to not equal null
```

Falla **por la razón correcta**: `checks` está vacío porque el `authorize` de hoy no llama a
`client.check` ni una vez (expande la cadena a un `batchCheck`), y por eso mismo tumbar `check` no
lanza nada.

**Verde** — `src/drivers/openfga_driver.ts`:

- `authorize` conserva **intacta** la guardia del catálogo (`catalog.view()` + `catalog.permission()`,
  el `if (!perm) return false` de `:962`) y, con `hierarchy === 'facts'`, delega en
  `factsAuthorize(user, permission, scope)` **antes** de tocar `this.chain(...)`.
- `factsAuthorize` (privado): un `client.check({ user, relation: can_<P>, object: scope:<key>,
  context })` con la `consistency` del driver, y `return response.allowed === true`. Nada más.

La guardia del memo no es decorativa: sin ella el permiso desconocido produce un `Check` de una
relación que el modelo no declara, y eso es un **400 del servidor**, que el cliente envuelto
convierte en 503. El caso 3 lo fija con el espía (0 llamadas) y el caso e2e lo repite contra el
servidor real, donde el 400 sería real.

## Pieza 2 · `authorizeMany` es UN `batchCheck` de N items

**Casos escritos** (grupo «facts · 3b-2c — `authorizeMany` es UN batchCheck de N items»):

1. N scopes ⇒ **1** `batchCheck` con **un item por scope** (`can_<P>@scope:<key>`), 0 `check`
   sueltos, 0 `resolveChain`, y las respuestas por posición.
2. Un scope **repetido comparte item** y respuesta: 3 scopes con uno repetido ⇒ 2 items.
3. Permiso desconocido ⇒ todo `false` sin tocar el servidor; sin scopes, `[]`.
4. Un `error` por check dentro del lote ⇒ 503 (invariante 5, D1), no un `false`.

**Rojo:**

```
❯ … / N scopes ⇒ 1 batchCheck con un item por scope (no el N×M de hoy), 0 resolveChain
ℹ AssertionError: expected [ false, false, false ] to deeply equal [ true, false, false ]
❯ … / un scope repetido COMPARTE item y su respuesta (no duplica el lote)
ℹ AssertionError: expected [ false, false, false ] to deeply equal [ true, false, true ]
```

Por la razón correcta: el `authorizeMany` de hoy pregunta por `role_binding:*#assignee`, y el espía
solo concede `can_docs_read@scope:<orgA>`, así que responde `false` a todo.

**Verde:** `factsAuthorizeMany(user, permission, scopes)`, con la misma técnica de slots que el modo
`resolver` pero reducida a lo que hace falta: un `Map<scopeKey, índice>` y `slots: number[]`. Un
instante para todo el lote (K9) y `batchCheckAll`, que ya lanza 503 ante cualquier `error` **antes**
de mirar un solo `allowed`.

## Pieza 3 · `grant`/`revoke` escriben el binding ENLAZADO

**Casos escritos** (grupo «facts · 3b-2c — `grant`/`revoke` escriben el binding ENLAZADO»):

1. `grant` deja tres tuplas: `role:<uuid>#role@role_binding:<k>|<uuid>`,
   `role_binding:<k>|<uuid>#binding@scope:<k>` y `user:u1#assignee@role_binding:<k>|<uuid>`.
2. El enlace es **idempotente**: un segundo grant (otro holder) no lo duplica ni falla.
3. `revoke` se lleva la asignación y **deja** el enlace (otro holder lo sigue usando).
4. En modo `resolver` el grant escribe **solo** el `assignee` (aditivo).

**Rojo:**

```
❯ … / `grant` enlaza el binding al scope y al rol, además del asignado
- "role_binding:organization|…|…#binding@scope:organization|…"
- "role:…#role@role_binding:organization|…|…"
  "user:u1#assignee@role_binding:organization|…|…"
ℹ AssertionError: expected [ Array(1) ] to deeply equal [ …(3) ]
❯ … / `revoke` se lleva la asignación y deja el enlace …
ℹ AssertionError: expected [ Array(1) ] to deeply equal [ …(3) ]
```

**Verde:**

- `src/drivers/openfga_facts.ts` (pieza pura, sin SDK): `FACTS_BINDING_TYPE`,
  `FACTS_BINDING_RELATION`, `FACTS_ROLE_RELATION`, `FACTS_ASSIGNEE_RELATION`,
  `factsBindingObject(scopeKey, roleUuid)` (con `assertFgaObjectId`) y
  `factsBindingTuples(scopeKey, roleUuid)`.
- `grant` escribe las **dos aristas estructurales** con `writeTuples(..., { onDuplicateWrites: Ignore })`
  justo después de resolver `target`/`roleUuid` y **antes** del camino del `assignee`, que no se toca.

## Pieza 4 · `deny`/`removeDeny` son `scope#denied_<P>`

**Casos escritos** (grupo «facts · 3b-2c — `deny`/`removeDeny` son `scope#denied_<P>`»):

1. `deny` escribe `scope:<key>#denied_<P>@<holder>` y **ningún** `deny_binding`.
2. `removeDeny` lo quita; re-denegar y re-quitar son no-ops seguros (invariante 6).
3. Un permiso fuera del catálogo sigue siendo 422 `E_AUTHZ_UNKNOWN_PERMISSION` en las dos escrituras.
4. `listDenies` lee la forma nueva (con y sin scope).
5. `listScopes` **no lista** un scope donde el deny gana.
6. `purgeScope` se lleva los denies y el enlace del scope, y **no** la arista `parent`.

**Rojo** (el 1; el 2 y el 3 pasaban ya con la forma vieja — son guardias de regresión, y los 4-6
también lo eran hasta que la forma cambió):

```
❯ … / `deny` escribe `scope:<key>#denied_<P>@<holder>` y ningún `deny_binding`
- "user:u1#denied_docs_read@scope:organization|01a05349-6489-…"
+ "user:u1#denied@deny_binding:organization|01a05349-6489-…|01a05349-6487-…"
ℹ AssertionError: expected [ Array(1) ] to deeply equal [ Array(1) ]
```

**Verde:**

- `openfga_facts.ts`: `factsDenyTuple(scopeKey, permission, user)` y `FACTS_DENIED_PREFIX`.
- `openfga_driver.ts`: `deny`/`removeDeny` construyen el hecho con un `denyTuple(...)` privado que
  elige la forma según el modo; el resto del camino (validación del permiso, `knownScope`,
  `canonicalOrSelf`, `Ignore` en duplicado/ausente) no cambia.
- **Los consumidores de la forma del deny cambian con ella**, o el lote habría dejado un fail-open:
  - `deniedScopeKeys` (el filtro de `listScopes`) en `facts` lee `{ user, relation: denied_<P>,
    object: 'scope:' }` — **una** request, y ya viene filtrada por permiso.
  - `listDenies` se parte en `factsDenies` / `legacyDenies`, que devuelven `{scope, permission}`; el
    bucle de filtrado por scope y por árbol es común. En `facts` es UNA lectura
    (`{ user, object: 'scope:' }`) y la vuelta de relación a slug la da el catálogo (un permiso
    retirado no es un deny, D5); una clave de scope que el motor no entiende se cuenta en
    `diagnostics.unparseableBindings` y se registra, nunca un `continue` mudo (L0.16).
  - `purgeScope` en `facts` purga el objeto `scope:<key>` **menos la relación `parent`** en vez de
    enumerar un `deny_binding` por permiso (una lectura en vez de O(permisos), y ya no consulta
    `authz_permissions`). La arista sigue siendo lo último y la borra `scopes.detached` **después**
    de que la purga demuestre cero (S6): si se fuera aquí y la purga muriera a medias, el scope
    quedaría sin ancestro, sus denies heredados dejarían de aplicar y esos permisos serían
    INDENEGABLES (invariante 2).

**Un caso de 3b-2b hubo que corregirlo, y es correcto que así fuera**: «si la purga de hechos NO
puede demostrar cero, la arista SIGUE en el store» sembraba el hecho vivo como un `deny_binding`.
Con la forma nueva ese objeto ya no existe, así que la purga demostraba cero de la nada y el caso
salía rojo:

```
❯ facts · 3b-2b — `detached`: hechos primero, arista al final (S6) / si la purga de hechos NO puede demostrar cero, …
ℹ AssertionError: la purga no demuestra cero: debería haber lanzado: expected null to not equal null
```

Se corrigió **el caso** (siembra `scope:<key>#denied_docs_read@user:u1`), no el código: lo que el
caso quiere fijar es el ORDEN, y el hecho que la purga tiene que demostrar a cero es ahora ese.

## Pieza 5 · La semántica, contra el `:8101`

Los espías fijan la forma; sola, la forma no demuestra que el Check responda lo que dice el
contrato. El grupo «facts · 3b-2c — un solo Check contra el servidor real» monta un store con el
modelo (c2), sincroniza el catálogo **con la proyección del driver**, cuelga el árbol con
`onScopeAttached` y a partir de ahí **todo pasa por el paquete** (ni una tupla a mano):

| Caso | Qué fija |
|---|---|
| grant → `authorize` | concede en su scope y **hacia abajo**, nunca en hermanos ni hacia arriba (invariante 1); el catálogo acota lo que el rol concede (`docs:write` = `false`); `listScopes` dice lo mismo; `revoke` lo quita también hacia abajo |
| deny | el deny del hijo gana y **no sube**; un deny arriba bloquea abajo (herencia de `denied_<P>` por `parent`); quitarlo restaura (invariante 2) |
| expiración | una asignación caducada no concede, sin scheduler; re-grant con fecha futura sí (invariante 3) |
| holders | el mismo uuid con otro `type` no se cruza (invariante 4) |
| `authorizeMany` | responde por scope **exactamente** lo mismo que `authorize`, con repetidos incluidos |
| permiso desconocido / scope que el store no conoce | `false`, no 503 |
| `purgeScope` | el scope queda a cero en el store; sobrevive **solo** `parent`; el scope de arriba no se toca |

---

## Corrección de 3b-2a encontrada aquí (bloqueaba la pieza 5)

El primer intento de e2e murió antes de empezar:

```
❯ facts · 3b-2c — un solo Check contra el servidor real / un grant concede en su scope y HACIA ABAJO …
ℹ AuthorizationBackendError: El backend de autorización 'openfga' no respondió (read)
 ⁃ at async OpenFgaAuthorizationDriver.projectCatalog (src/drivers/openfga_driver.ts:1939:23)
 ⁃ at async syncAuthzCatalog (src/catalog.ts:279:25)
[CAUSE] FgaApiValidationError … status code 400
  apiErrorMessage: "the 'tuple_key' field was provided but the object type field is
  required and both the object id and user cannot be empty"
```

`projectCatalog` (3b-2a · A5) leía el espejo con `Read({ object: 'role:' })` — objeto solo de tipo y
**sin `user`**. El doble en memoria de la suite de 2a lo aceptaba; **el servidor real lo rechaza con
un 400**, así que `syncAuthzCatalog` con proyección era un 503 en cuanto tocaba un store de verdad.
La proyección nunca se había ejercitado contra el `:8101`.

**Arreglo:** una lectura por comodín de holder (`{ user: '<holder>:*', object: 'role:' }`). Con (c2)
las tuplas de la proyección son exactamente `<holder>:*`, así que se ve el espejo entero —incluidas
las de un rol que el catálogo ya no lista, que es lo que hay que borrar— y la convergencia no
cambia. Cuesta O(holders) lecturas (3 en la suite) en vez de 1, solo en el `sync`.

**Caso nuevo que lo habría cogido:** «la proyección del catálogo converge contra el servidor real»
(sync con 2 permisos ⇒ 6 tuplas; re-sync quitando uno ⇒ quedan las 3 del permiso que sigue).

---

## Decisiones donde el plan no lo decía

1. **`authorize` en `facts` NO canoniza el scope** (no llama a `resolveChain`: es el cruce 6). El
   alias por guiones que la cadena canónica cerraba en modo `resolver` (invariante 17) aquí no se
   cierra… **hacia el lado seguro**: los hechos se escriben SIEMPRE con `chain[0]` (grant/deny
   siguen validando el scope con `knownScope`/`canonicalOrSelf`), así que preguntar por un alias no
   encuentra ni grants ni aristas y responde `false`. Es fail-CLOSED y uniforme; no hay forma de que
   un alias conceda. Queda escrito aquí porque es una divergencia observable entre modos.
2. **Las dos aristas del binding se escriben ANTES del `assignee`, y con `onDuplicateWrites: Ignore`.**
   Antes: si el `assignee` fallara después, lo que queda es estructura inerte (sin asignado no
   concede). Después: habría un instante con la asignación escrita y todavía sin efecto. Las dos
   ventanas son fail-closed, pero la primera no deja un grant "escrito y mudo". Y `Ignore` aquí es
   literalmente "ya estaba": estas tuplas no llevan condición, así que un duplicado es idéntico por
   construcción — no es el `Ignore` del importador (cruce 9 / S7), que tapaba una condición
   DISTINTA.
3. **`revoke` no borra las aristas del binding.** Son de la asignación, no del asignado: otro holder
   puede seguir usando el mismo `role_binding`, y borrarlas le quitaría el permiso a él. Sin
   `assignee` no conceden nada, y un re-grant las reescribe idempotente. Lo que sí las borra es
   `purgeScope` (el `#binding` cuelga del scope; el `#role`, del objeto binding, que la purga ya
   enumeraba).
4. **La forma del deny arrastra a sus lectores.** `listDenies`, el filtro de `listScopes` y
   `purgeScope` se cambiaron en este lote aunque el encargo listaba solo las escrituras: dejarlos
   leyendo `deny_binding` habría hecho invisible un deny vivo, que en `listScopes` es un **fail-open**
   (listar un scope donde `authorize` deniega) y en `purgeScope` una purga que "demuestra cero" sin
   haber borrado el deny (invariante 11). Son consecuencia directa del bullet, no ampliación.
5. **`purgeScope` en `facts` ya no lee `authz_permissions`.** No hay `deny_binding` que enumerar; el
   objeto `scope:<key>` los trae todos de una lectura. En modo `resolver` el camino es idéntico al
   de antes.
6. **`listDenies` sin scope sigue usando `resolveChain`** (por deny, para no listar los de un scope
   que el árbol ya no conoce, D8). No está en la lista del cruce 6, pero es un `list*`, no
   `authorize`, y el literal aprobado ya dice que los `list*` sí lo usan.

---

## Lo que NO hice, y por qué

- **2d (outbox y gate de construcción) y 2e (capacidades, límites, `purgeRole` soportado, borrado
  del modo `resolver`)**: fuera del encargo, explícitamente.
- **`hasRole`, `listRoles`, `listRoleScopes`, `listSubjects`, `listScopes`** siguen usando
  `resolveChain` en modo `facts`. Es lo medido y lo aprobado (cruce 6): en (c2) no hay alternativa,
  y convertirlos es 2e (capacidad con caso negativo). No se tocaron.
- **Nadie publica el modelo `facts`.** `provisionOpenFgaStore` publica el modelo del modo
  `resolver`; `syncAuthzCatalog` con proyección **valida** que el catálogo es publicable
  (`assertPublishable`) y escribe las tuplas, pero no escribe el authorization model. Hoy lo publica
  la suite a mano. Eso tiene que resolverlo 2d/2e: sin ello, añadir un permiso al catálogo deja el
  store con un modelo viejo y el `Check` de `can_<permiso nuevo>` es un 400 ⇒ 503.
- **Migración de la forma vieja a la nueva.** Un store escrito en modo `resolver` tiene
  `deny_binding:*` y bindings sin aristas; en `facts` esos hechos no se ven ni conceden. Es
  `authz:reconcile` (3b-3); no hay comando de migración y no lo inventé.

## Los casos del juez contra `facts`: **todavía no, y por dos razones concretas**

El criterio de aceptación del lote 3b-2 completo es que los 83 casos del juez corran contra `facts`.
Miré si se puede enganchar ya y **no**, y no es cuestión de esfuerzo sino de dos piezas que no
existen:

1. **El árbol no llega al store.** El harness del contrato inyecta un `ContractScopeTree`
   (`memoryScopeTree`/`sqlScopeTree`) y la suite llama `tree.attach(...)` **directamente**
   (`src/testing/contract.ts:359`, `:366`, y decenas de sitios más); `attach` no notifica al driver
   (`src/testing/scope_tree.ts:136`). En modo `facts` el store se quedaría sin una sola arista
   `scope#parent` y **todo** respondería `false`. Haría falta un decorador de `ContractScopeTree`
   que espeje en el driver (`onScopeAttached/Moved/Detached`) — pieza nueva del harness.
2. **El modelo no se republica por catálogo.** `seedCatalog(catalog)` corre por caso con catálogos
   distintos; el modelo tendría que republicarse con los permisos de ESE catálogo (ver arriba) y
   `seedCatalog` tendría que pasar `{ projection: driver.catalogProjection() }`, o un rol retirado
   seguiría concediendo (en `facts` el catálogo local ya no filtra el `authorize`: quien lo hace es
   la proyección).

Las dos son trabajo de **2e** (donde ya viven `singleCheckAuthorize`/`hierarchyFacts` como
capacidades con caso negativo, `src/testing/contract.ts:62`). No lo forcé.

### Un hallazgo para 2e, escrito aquí para que no se pierda

En `facts`, `authorize` **no re-decide la visibilidad de un rol local con el árbol de hoy**: el
modelo (c2) no tiene `owner`, así que un `role_binding` concede mientras su scope alcance al que
pregunta. El invariante 18 dice que mover la unit fuera del owner retira lo concedido **sin
escribir**; eso deja de ser cierto en `facts`. **Hoy es inalcanzable** —este driver no declara
`purgeRole`, así que `defineScopedRole` es 500 `E_AUTHZ_UNSUPPORTED` antes de escribir y no hay
roles locales que asignar (`src/drivers/openfga_driver.ts:1977`)—, pero 2e pasa `purgeRole` a
soportado y con eso se abre. Es un **fail-open** y necesita decisión (proyectar el owner, o
declararlo como capacidad con su caso negativo). No lo toqué: el encargo era el `Check`.

---

## Verificación

```
npx tsc --noEmit -p tsconfig.json      ✓ (sin salida)
npm run typecheck                      ✓
npm run check:purity                   ✓ el paquete no depende de ningún consumidor
```

| Suite | Antes | Después |
|---|---|---|
| `npm test` | 574 | **601** |
| `test:sqlite-file` | 576 | **603** |
| `test:pg` | 742 | **769** |
| `test:mysql` | 742 | **769** |

**+27 casos en las cuatro, y ni uno existente en rojo.** Sin `skip` en ninguna parte. Los 27 son:
5 (`authorize`) + 4 (`authorizeMany`) + 4 (`grant`/`revoke`) + 6 (`deny`/`removeDeny`) + 8 contra el
servidor real (7 de semántica + 1 de la proyección corregida).

Archivos tocados:

```
src/drivers/openfga_driver.ts | 298 +++++++++---
src/drivers/openfga_facts.ts  |  64 +++
tests/openfga_facts.spec.ts   | 734 ++++++++++++++++++++++++++++++-
```
