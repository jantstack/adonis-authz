# Sublote D2: repaso adversarial del cierre 2 (auditor, 2026-10-16)

**Árbol:** `main` sobre `75353fe`, con D2, cierre 1 y cierre 2 sin commitear.

**Cómo trabajé**
- Solo lectura sobre el repo. Escribí únicamente este fichero y dos scripts en `.claude/reproducciones/`:
  - `loteD2-auditor-cierre2-fga.ts`: R1–R7. Usa SQLite `:memory:` y stores efímeros `aud-d2c2-*` en `:8090`, que borra al terminar (comprobado: no quedan).
  - `loteD2-auditor-cierre2-orden.ts`: O1–O4, puro, sin servidor.
- Sin docker restart, sin gates y sin `test:pg|mysql`.

**Cómo se ejecutan**

```
source ~/.config/nvm/nvm.sh && nvm use 22
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre2-fga.ts
node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre2-orden.ts
```

Las repros del re-ataque anterior vivían en un scratchpad que ya no existe. Las reescribí contra el árbol actual: R1, R2 y O3.

## Veredicto en una línea

**NO APTA, por una regresión 🟠 que introduce el propio cierre de N1.**

Los hallazgos N1–N6 están cerrados en efecto, no solo en la letra. Pero el plan del reconcile trata una tupla CADUCADA del destino como si estuviera viva:
- Una membresía portadora caducada en el destino y viva en el origen se clasifica `renewal-unsafe` y no se escribe.
- El allow nuevo, en cambio, sí se escribe.
- Resultado: el destino queda **concediendo de forma persistente** a un sujeto que el origen deniega. Ninguna pasada posterior converge.
- La misma omisión (la caducidad) falsea la garantía publicada del orden («sin ciclo ⇒ ningún prefijo concede»).

La causa común: la fuerza bruta modela presencia, no vigencia. El arreglo es barato y está abajo.

---

## 1. N1–N6: ¿cerrados de verdad?

| # | Estado | Evidencia |
|---|---|---|
| 🟠 N1 (a) PDP | **Cerrado** | ✅ R1 contra `:8090`: `{"before":false,"err":"409 E_AUTHZ_RENEWAL_UNSAFE","gap":[],"after":false}`. La barrera entre los dos `Write` no llega a dispararse: ya no hay dos `Write`. |
| 🟠 N1 (b) reconcile | **Cerrado** para el caso medido | ✅ R2: `["destino:renewal-unsafe"]`, `updated 0`, el destino niega. **Pero ver 🟠 C2-1**: la misma clasificación con una membresía CADUCADA en el destino deja el destino concediendo. |
| 🟠 N1 parcial | **Cerrado** | ✅ R3 con fallo inyectado en el 2.º `Write`: `503 … partial=true`. |
| 🟡 N2 | **Cerrado** (deja de ser residuo) | ✅ O3: `walkPair(N2)` ⇒ `bad: null`, orden `+h@u1 ; +g@u1`. |
| 🟡 N3 | **Cerrado** | ✅ O3: C2 del re-ataque ⇒ `bad: null`, orden `-g@u1 ; +x@g#member`. La anidada ⇒ `bad: null`. ✅ Fuerza bruta multi-relación propia (O4, abajo): 0 sin residuo. |
| 🟡 N4 | **Cerrado** | ✅ `commands/openfga_provision.ts:400-424`: streaming, sin cota, `Set` de tokens vistos, página sin `tuples` ⇒ lanza ⇒ exit 1 «falló a medias». No hay fail-open: un deny condicional o caducado cuenta como vivo, que es la dirección fail-closed. |
| ⚪ N5 | **Cerrado** | ✅ README:2009-2010 y :2028, «The recount narrows the window, it does not close it … step 0 … is what closes it». |
| ⚪ N6 | **Cerrado** | ✅ `RELATION_RESIDUES` (`reconcile.ts:1366`). L9 enumera los dos motivos y cada uno tiene caso (`relations_reconcile_l9.spec.ts:291`, `:314`, `:360`). |

## 2. N3: ¿la fuerza bruta modela fielmente el motor?

**Lo que sí modela, comprobado por mí**
- El corte de camino con anidación.
- `--prune` y su ausencia.
- El auto-corte con `cuts`.

**`includes` multi-relación** (no estaba en ningún universo del spec)
- Monté O4: `owner ⊂ editor ⊂ viewer`, con deny en las tres relaciones, allows y denies directos y por grupo, h ⊂ g.
- 10 tuplas, recorrido exhaustivo de 4^10 pares × {`--prune`, sin} × {con `cuts`, sin `cuts`} = **4 194 304 pares**.
- El oráculo es `cutPathAllows` del paquete, aplicado a las tres preguntas.
- Resultado: `unsafeNoResidue: 0`, `unsafe: 144`, `inherent: 0`, `residuePairs: 131 040`.
- El orden por OBJETO de `tuple_order.ts` es conservador frente a `includes`. Resiste.

**Wildcard:** no aplica. La gramática de holder rechaza `*` (`identity.ts:114`, `assertDenySubject`), y el driver descarta `user:*` al enumerar (`openfga_relations_driver.ts:629`).

**`parent` / `from`:** no aplica. La config v1 lo rechaza (`define_relations_config.ts:533-543`).

**Roles:** fuera del grafo. El deny de roles es `scope#denied_<P>`, con sujetos holder y herencia por `parent`. Lo confirma el modelo y el caso del implementador.

**Condiciones (caducidad): AQUÍ ESTÁ EL HUECO.**
- El modelo puro solo conoce presencia: `context` es «existe en el estado inicial o en el final».
- La renovación (`op: 'renew'`) nunca se genera en la fuerza bruta.
- `planPartition` mete en `orderContext` TODAS las tuplas del destino, incluidas las caducadas (`reconcile.ts:1205`, `destByKey` sin filtrar). Las caducadas del origen sí se descartan (`skipped.expired`).
- Consecuencia: una membresía CADUCADA del destino, que en FGA y en `database` no conecta nada, la tratan como VIVA:
  1. el auto-corte (`kept`), que puede dar por cortado un allow que no lo está;
  2. la clasificación de portadoras;
  3. el orden, que la manda a la fase 4 como «renovación», cuando en realidad es una membresía que ENTRA.
- Ver 🟠 C2-1 y 🟡 C2-2.

**El residuo «ciclo» no es lo único que queda.** Declarados: el ciclo y la fila de más de 100 membresías de `purgeSubject`. Sin declarar: C2-2 (caducidad) y C2-3 (TOCTOU).

## 3. TOCTOU de N1, medido contra `:8090` (R3)

- **Montaje:**
  - Renovación de U ∈ G, con G SIN deny.
  - Un espía sobre `client.write` inyecta, ANTES del delete (o sea, después de que `#carriedDeny` leyó «sin deny»), un `deny(G#member, viewer, X)` desde OTRO driver sobre el mismo store.
  - U tiene allow directo sobre X.
- **Resultado:**
  - `{"init":true,"trasDenyConfirmado":false,"entreLosDosWrite":true,"final":false}`
  - Con el 2.º `Write` fallido: `{"entreLosDosWrite":true,"err":"503 … partial=true","final":true}`
- **Respuesta a la pregunta del brief:**
  - No concede nada que el estado inicial no concediera: antes del deny, U ya tenía X.
  - Lo que rompe es la LINEALIDAD del deny: tras un deny CONFIRMADO (un check posterior da `false`), otro check vuelve a dar `true` durante la ventana.
  - Si el 2.º `Write` cae, el deny confirmado queda **sin efecto de forma persistente**. La marca parcial y el evento `indeterminate` hablan de la RENOVACIÓN de la membresía, no de que un deny ha dejado de alcanzar al sujeto.
- **Explotabilidad:** requiere dos escrituras de admin concurrentes, con una ventana de milisegundos. El caso persistente requiere además un fallo del backend. Un consumidor que ofrezca autoservicio del tipo «extiende mi membresía» le da al sujeto el control de uno de los dos lados, pero aun así tiene que coincidir con el deny.
- **Mitigación barata:**
  - (a) Tras el 2.º `Write` (y también si falla), re-ejecutar `#carriedDeny`. Si ahora hay un deny, añadir la causa al error parcial o lanzar una 409 informativa: la ventana no se cierra, pero el caso persistente deja de ser mudo.
  - (b) En cualquier caso, declararlo en README junto a «Every other renewal stays two `Write`s»: un deny concurrente con la renovación de una membresía de ese grupo puede no alcanzar al sujeto durante los dos `Write`, y para siempre si el 2.º cae.
  - Cerrarlo de verdad exige serializar `deny` contra la renovación, y no hay primitiva para eso en FGA.

## 4. Roles: fallo del 2.º write en la renovación de un grant

**Solo letra; el efecto es fail-closed.**
- `replaceAssignment` (`openfga_driver.ts:1213-1222`) hace `deleteTuples([assignee])` y después `writeTuples([...structure, tuple])`.
- Si falla el segundo:
  - el `assignee` ya no está, así que `authorize`, `hasRole` y `list*` pierden el grant;
  - la estructura no se toca (solo se escribe, ignorando duplicados);
  - el `#write` del manager de roles solo notifica `indeterminate` en un timeout (`manager.ts:4396-4404`).
- Resultado: un 503 «no escrito», sin evento, con el grant borrado.
- No puede conceder: `denied_<P>` no viaja por el assignee.
- El llamante que acortaba una caducidad cree que el grant sigue como estaba y en realidad está revocado. Ver ⚪ C2-5.

## 5. Lo nuevo de N4 y N1: fail-open y regresiones

**N4**
- Sin fail-open.
- Un servidor que devuelva tokens siempre nuevos con páginas vacías itera sin fin: no hay deadline total. Es un servidor hostil, fuera del modelo de amenaza (⚪, sin hallazgo).

**N1**
- `#carriedDeny`:
  - propaga los 503 de `#readAll` (cero escrituras);
  - filtra por partición;
  - sube por la anidación;
  - cuenta un deny de un tipo en fase `'read'`, que es la dirección conservadora.
- La capacidad `atomicRenewal` es opcional y se normaliza a `false`.
- **Regresión: sí, la 🟠 C2-1.** Antes del cierre 2, esa «renovación» se hacía en la fase 4: había una ventana transitoria y el estado final era correcto. Ahora se niega y el destino concede para siempre.
- Además, ⚪ C2-4: una 409 espuria en `relate` directo.

---

## Hallazgos (por severidad)

### 🟠 C2-1 · Una membresía portadora CADUCADA en el destino se clasifica `renewal-unsafe`: el reconcile escribe el allow nuevo y deja el destino CONCEDIENDO a un denegado, para siempre

**Escenario**
- **Precondición:**
  - Origen `database`: U ∈ H vivo, `deny(H#member, viewer, X)` y allow directo `U viewer X`.
  - Destino `openfga`:
    - el mismo deny;
    - U ∈ H con caducidad YA VENCIDA (escrita en una pasada anterior; el admin la extendió en el origen después);
    - sin el allow.
  - El origen niega. El destino, al empezar, niega.
- **Acción:** `authz:relations:reconcile`, normal o con `--dry-run`, sin `--prune`.
- **Resultado (R4, medido contra `:8090`):**
  ```
  originCheck false · destBefore false
  dry  { written 1, updated 0, reasons [renewal-unsafe] }
  real { written 1, updated 0, reasons [renewal-unsafe] }
  destAfter true · 2.ª pasada { written 0, reasons [renewal-unsafe] } · destAfter2 true
  ```
  - El destino **concede** a U sobre X cuando el origen lo niega, y ninguna pasada lo repara.
  - La línea dice que la membresía no se renueva porque «entre los dos `Write` el deny no alcanzaría al sujeto». Es falso: ya no lo alcanza, porque la membresía está caducada.
  - Variante: si el allow ya estaba en el destino, este concede ANTES y DESPUÉS de la pasada, y el plan nunca lo arregla.

**Evidencia**
- ✅ R4.
- ✅ `reconcile.ts:1192-1194`: `present` con otra caducidad ⇒ `toUpdate`, sin mirar si `present` está vencida.
- ✅ `reconcile.ts:1205`: `orderContext` incluye las caducadas del destino.
- ✅ `reconcile.ts:1213-1229`: toda portadora de `toUpdate` sale como `renewal-unsafe`.
- ✅ R6: el `relate` directo hace lo mismo (⚪ C2-4).

**Steelman del defensor:** «es ruidoso (exit ≠ 0, la línea trae la receta `unrelate` + `relate`, que lo arregla), el destino no sirve todavía y el runbook verifica antes del switch».
- **¿Me convence?** No del todo. La letra atribuye el motivo al revés: dice «no se renueva para PROTEGER el deny». Un operador que lee eso concluye que el destino conserva la membresía vieja, que es más restrictiva, y que la diferencia es solo la fecha. Puede aceptar el residuo y conmutar, y el PDP nuevo concede a un denegado.
- Es una regresión del propio cierre: antes había una ventana transitoria y el final era correcto. Ahora es persistente y no converge.

**Mitigación mínima**
- En `planPartition`, una tupla del destino vencida en `now` es AUSENTE:
  - no entra en `orderContext`;
  - su reescritura es un `write` (fase 3 si es membresía, por el grafo), no un `renew`;
  - nunca es `renewal-unsafe`.
- En el driver basta con borrar y escribir: el hueco no existe, porque la tupla ya no conecta nada.
- Lo mismo en `#carriedDeny` de `relate` (C2-4).
- Caso contra `:8090` (R4) y la dimensión «caducada» en la fuerza bruta (C2-2).

### 🟡 C2-2 · La garantía publicada del orden supone que todas las tuplas del destino están VIVAS: con una caducada, un prefijo SIN residuo concede

**Escenario A: la renovación de una caducada va a la fase 4, detrás del allow nuevo** (R5)
- **Destino:** `database` (`atomicRenewal: true`), dirección openfga → database (la vuelta).
- **Precondición:** el destino tiene U ∈ H caducada y `deny(H#member, viewer, X)`. El origen tiene U ∈ H viva y `U viewer X`.
- **Resultado:**
  - prefijos `["relate(viewer) ⇒ check=true", "relate(member group) ⇒ check=false"]`;
  - el destino al empezar niega, el final niega, y el prefijo 1 **concede**;
  - sin residuo y sin línea de aviso.

**Escenario B: auto-corte con una arista caducada tomada por viva, sin ninguna renovación** (R7, en los DOS destinos)
- **Precondición:**
  - En los dos lados: `g#member viewer X`, `deny(k#member)` y `deny(h#member)`.
  - Solo en el destino, sin `--prune`: `g ⊂ k` caducada.
  - El origen añade U ∈ g y U ∈ h.
- **Cálculo del orden:** `effective(g)` da X por cortado por el deny de k, a través de una arista que no conecta. Desaparece la precedencia «h antes que g» (O1 frente a O2).
- **Resultado:**
  - `database` y `openfga`: `["relate(U member g) ⇒ check=true", "relate(U member h) ⇒ check=false"]`;
  - `orderResidue: []`.

**Evidencia**
- ✅ R5, R7 (`:8090` y SQLite).
- ✅ O1/O2: el control sin la arista ordena `h ; g`; con la arista, `g ; h`, residuo 0.
- ✅ `order_bruteforce.ts`: el universo es solo presencia y `renewals` nunca se pasa.

**Steelman del defensor:** «el destino no sirve, la ventana es transitoria y el final es correcto».
- **¿Me convence?** Para la severidad, sí: 🟡.
- Para la letra, no. README:843-845 y la propiedad `relations.order.exhaustive` afirman «no prefix grants … without a declared residue» sin la precondición de vigencia, y aquí concede sin residuo.

**Mitigación mínima:** la misma de C2-1 (vencida = ausente en el plan y en el contexto) y añadir la vigencia al universo de la fuerza bruta (un bit «caducada» por membresía del destino). Si no, declarar la precondición «tuplas vivas» en README y en el título de la guardia.

### 🟡 C2-3 · TOCTOU de N1: un deny concurrente con la renovación de una membresía de un grupo SIN deny no alcanza al sujeto en la ventana, y para siempre si cae el 2.º `Write`

- **Escenario:** precondición → acción → resultado en §3 (R3, medido).
- **Evidencia:**
  - ✅ R3.
  - ✅ `openfga_relations_driver.ts:695-707`: comprobación, y después delete y write, sin re-comprobar.
  - El informe del implementador lo deja en «No hecho».
  - README:669-674 dice «Every other renewal stays two `Write`s» sin esta ventana.
- **Steelman del defensor:** «son dos escrituras de admin concurrentes, y la ventana es de milisegundos».
  - **¿Me convence?** Sí para 🟡.
  - No para el caso persistente mudo: el error parcial no dice que un deny ha dejado de alcanzar a nadie.
- **Mitigación mínima:** re-ejecutar `#carriedDeny` tras el delete+write, o tras el fallo, y nombrar el deny en el error o el evento; declarar la ventana en README con su caso.

### ⚪ C2-4 · `relate` directo: renovar una membresía portadora CADUCADA es 409 `E_AUTHZ_RENEWAL_UNSAFE`

- **Escenario:**
  - Precondición: U ∈ H caducada y deny en H.
  - Acción: `relate(U, member, H, { expiresAt: null })`.
  - Resultado: **409** (R6). No hay ventana que proteger: el deny ya no alcanza a U.
- **Evidencia:** ✅ R6. `#readTuple` devuelve la tupla vencida como `current`.
- **Impacto:** fail-closed y usabilidad. La receta (`unrelate` + `relate`) funciona, pero dice «aceptando la ventana» cuando no existe.
- **Steelman del defensor:** «la receta lo resuelve». Me convence para ⚪.
- **Mitigación:** si `current` está vencida, no hay comprobación de portadora.

### ⚪ C2-5 · Roles `facts`: la renovación de un grant cuyo 2.º `Write` falla sale como 503 «no escrito», sin evento, con el `assignee` ya borrado

- **Escenario:**
  - Precondición: `grant` con otra caducidad sobre una asignación existente.
  - Acción: `writeTuples` falla tras `deleteTuples`.
  - Resultado: 503 sin `isPartialWrite` y sin `indeterminate`; el grant está perdido. Es fail-closed.
- **Evidencia:** ✅ `openfga_driver.ts:1213-1222` y `manager.ts:4396-4404` (solo timeout).
- **Steelman del defensor:** «fail-closed, fuera del brief, anotado para la RC». Me convence: ⚪.
- **Mitigación:** la misma marca parcial que en relaciones, y la rama `isPartialWrite` en el `#write` de roles.

---

## Lo que intenté y NO se rompió

**N1**
- Portadora directa y anidada, con barrera entre los `Write` (R1).
- Plan `renewal-unsafe` con la portadora viva (R2).
- Parcial marcado (R3).
- `#carriedDeny` propaga los 503 y filtra por partición.

**Orden**
- Los contraejemplos del re-ataque (C2/N3, la anidada, N2) dan `bad: null` contra el orden actual (O3).
- Fuerza bruta con `includes` de tres relaciones, deny en las tres y deny directo, con y sin `cuts`: **4 194 304 pares, 0 conceden sin residuo** (O4).

**Fuera de alcance por diseño**
- El comodín no es sujeto: gramática y enumeración.
- `from`/`parent` en relaciones: la config lo rechaza.

**N4**
- Streaming sin cota.
- Ciclo de tokens ⇒ lanza.
- Página sin `tuples` ⇒ lanza.
- Un deny condicional cuenta como vivo (fail-closed).

**N5 y N6:** la letra y la guardia están presentes.

**Stores:** cero residuos de stores efímeros.

## Preguntas abiertas para el arquitecto

1. 🟠 C2-1/🟡 C2-2: ¿«vencida en `now` = ausente» en el plan del reconcile y en `#carriedDeny`? Es el arreglo de una línea que cierra los dos, y exige añadir la vigencia a la fuerza bruta. Con el reloj de quién: el del paquete (`now`) frente al `current_time` del servidor FGA. Un desfase solo mueve la frontera unos milisegundos, en las dos direcciones.
2. 🟡 C2-3: ¿se declara la ventana o se añade la re-comprobación posterior para que el caso persistente no sea mudo?
