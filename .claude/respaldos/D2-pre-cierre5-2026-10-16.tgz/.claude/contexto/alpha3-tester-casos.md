# `2.4.0-alpha.3` — lista de casos del tester-contrato

**Encargo:** hacer VERIFICABLE «el evento de escritura de RELACIONES da las mismas garantías que el de
ROLES». Documento previo al lote: gobierna al implementador (rojo→verde) y al auditor.

**Base medida hoy (2026-09-02, HEAD `7e21c46` = `2.4.0-alpha.2`, árbol limpio):**

| modo | comando | casos |
|---|---|---|
| sqlite `:memory:` | `npm test` | **825 passed** |
| sqlite + openfga | `OPENFGA_TEST_URL=http://localhost:8101 npm test` | **1074 passed** |

(El `:8101` responde `SERVING`. Los 1074 del encargo son el modo con servidor; los 825, sin él.)

---

## 0 · Los hallazgos: qué confirmé, qué corrijo y qué es NUEVO

### Los cuatro del encargo — CONFIRMADOS, con la línea

| # | Hallazgo | Confirmación |
|---|---|---|
| 1 | El provider no cablea `assertWrite`/`onRelationWrite`; `defineConfig` no los expone | `providers/authz_provider.ts:47-56` pasa exactamente `requireActor`, `clock`, `freezeTimeoutMs`, `requireTransactionalWrites`, `driverName`. `src/define_config.ts:265-290` (bloque `relations`) declara `config`, `default`, `drivers`, `requireTransactionalWrites` y nada más. Por `authz.relations` **no hay auditoría posible**. ✅ |
| 2 | `RelationWriteEvent` sin `transactional` | `src/relations/manager.ts:210` y `:230` emiten `{ ...ref, actor: options?.actor }`. `src/types.ts:1501-1505`: `RelationWriteEvent extends RelationRef` + `actor?`. No hay `#transactional` (roles: `src/manager.ts:442-444`). ✅ |
| 3 | Invariante 13 no se cumple en relaciones | `grep -c indeterminate src/relations/manager.ts` = **0**. No existe el envoltorio `#write` (roles: `src/manager.ts:3257-3266`). Las cuatro llamadas al driver van desnudas (`:209`, `:229`, `:266`, `:273`). Y **sí hay deadline que vencer en los dos drivers**: `database_relations_driver.ts:291` (`guardSql(...timeoutMs...)` ⇒ `AuthorizationBackendTimeoutError`, `shared/backend_guard.ts:143-145`) y `openfga_relations_driver.ts:266-267` (`isTimeoutLike` ⇒ `AuthorizationBackendTimeoutError`, `retryParams.maxRetry: 0` en `:233`). El invariante es aplicable en ambos. ✅ |
| 4 | `purgeObject`/`purgeSubject` no emiten evento | `src/relations/manager.ts:261-267` y `:269-274`: `return this.#driver.purge*(...)`, sin `onRelationWrite`. ✅ |

**Corrección al encargo (menor):** la numeración de líneas del hallazgo 4 en el encargo dice
«`manager.ts:261/269`» — es correcta, pero el hueco real llega hasta `:266`/`:273` (el `return` directo).
Y el hallazgo 2 apunta a `210/230`: correcto.

### Cuatro hallazgos MÍOS (salieron de leer el código, no estaban en el encargo)

> Los cuatro son de la MISMA forma («¿qué tiene el evento de roles que el de relaciones no?») y tres de
> ellos son **fail-open o pérdida de auditoría**, no cosmética. Los meto en el lote porque arreglar el
> evento sin arreglarlos deja la paridad a medias y habría que volver.

**🔴 H1 · `onRelationWrite` que lanza SÍ tumba la escritura ya aplicada.**
`src/relations/manager.ts:54` lo tipa `onRelationWrite?(event: RelationWriteEvent): void` y las líneas
`:210`/`:230` lo llaman **sin `await` y sin `try/catch`**. Roles hace lo contrario y lo tiene escrito
como garantía: `#notify` (`src/manager.ts:3276-3282`) traga el error y lo registra
(`#logHookFailure`, `:3284-3293`), con su caso (`tests/manager.spec.ts:197` y `:214`) y su frase en el
README (`:238`, *"un hook que lanza NO tumba la escritura"*). Hoy, en relaciones, un sink de auditoría
caído convierte un `relate` **ya escrito** en un error para el llamante, que reintentará algo hecho. Y
un hook `async` que rechaza produce un **unhandled rejection** (no se espera la promesa): ni tumba ni se
registra — desaparece.

**🔴 H2 · `assertWrite` ASÍNCRONO es un bypass silencioso (y es justo lo que COGNITIV asumió al revés).**
`assertWrite?(ref: RelationRef): void` es síncrono a propósito (R-13), pero **TypeScript no lo defiende**:
una función que devuelve `Promise<void>` es asignable a una firma que devuelve `void`. Un consumidor que
escriba `assertWrite: async (ref) => { if (...) throw ... }` compila, la promesa se descarta en
`:208`/`:228`, y **la escritura entra**. La línea de docs del encargo («`assertWrite` es síncrono, puro y
sin actor a propósito») documenta un fail-open sin cerrarlo. **Una frase no es un diente**: propongo
detectar el *thenable* devuelto y responder 500 `E_AUTHZ_CONFIG` (precedente exacto: `clock` que no es
`() => Date` ⇒ 500 al construir, `manager.ts:88-92`; capacidad mentida ⇒ 500, nunca un skip).

**🟠 H3 · el `actor` de relaciones no se valida.**
`#assertActor` (`src/relations/manager.ts:161-167`) solo comprueba **presencia** (`!options?.actor`).
Roles valida la identidad: `#writeOptions` hace `assertSubject(options.actor)` **antes** de nada
(`src/manager.ts:1512`). Consecuencia medida por lectura: `assertSubject` **solo** se aplica al sujeto de
la tupla (`relations/manager.ts:324`), así que
`relate(..., { actor: { type: 'user', uuid: 'ACTOR MAL#FORMADO' } })` pasa y ese actor **viaja al evento**.
Para un consumidor cuyo requisito es «auditoría obligatoria de cada escritura», un actor con `#` o en
mayúsculas envenena el rastro y `requireActor: true` deja de significar lo que promete (un `actor: {}`
truthy también lo satisface).

**🟠 H4 · el README ya promete lo que el código no hace, y ningún test lo sujeta.**
`README.md:176` (escrito en L-6): *"`onWrite`/`onRelationWrite` fire when the driver returns, with
**`transactional: true`** on the event"*. Es **falso para `onRelationWrite`** desde que se escribió.
`tests/trx_docs.spec.ts` —el fichero cuyo trabajo es que lo publicado se cumpla o se reescriba— **no
sujeta esa frase** (sujeta el grep de «atómico», la letra del 500 y cinco frases de §6.2/§6.3; ninguna
es ésta). El caso de letra de la frase es parte de este lote, no un extra.

**Matiz de forma (no es bug, es un agujero de firma):** `purgeObject`/`purgeSubject` reciben
`RelationTransactionOptions` (`src/types.ts:1511-1527`), que **no tiene `actor`**. Si la purga va a
notificar, hace falta ampliar la firma; ver la decisión D-3.

---

## 1 · Decisiones de FORMA que el lote necesita ANTES de escribir código

Un caso no se puede escribir sobre una forma sin decidir. Propongo estas cinco, cada una con su simetría
y su precio. Si el coordinador cambia alguna, cambian los casos del bloque E y del bloque D.

### D-1 · Qué lleva el evento de una PURGA — **uno por llamada, con el objetivo, sin conteo**

Lo que hace roles (`src/manager.ts:907-912`): `{ action: 'scope_purged', scope: purged, ...actor }` — un
evento por purga, con el objetivo, **sin sujeto** («afecta a todos los holders del scope»,
`types.ts:1181-1186`), **sin conteo** y sin lista de lo borrado.

Lo simétrico en relaciones:

```ts
{ operation: 'purgeObject',  object,  partition, actor?, transactional?, indeterminate? }   // sin subject ni relation
{ operation: 'purgeSubject', subject, partition, actor?, transactional?, indeterminate? }   // sin object  ni relation
```

- **Nombres `purgeObject`/`purgeSubject`** (no `object_purged`): en este puerto `operation` es el nombre
  del método (`'relate' | 'unrelate'`), no un participio como el `action` de roles. Se sigue el puerto en
  el que se está, no el otro.
- **Sin conteo, y esto es una decisión, no un olvido**: `RelationsDriver.purgeObject` devuelve
  `Promise<void>` (`types.ts:1710`); un conteo obliga a romper el PUERTO para los drivers de terceros, y
  dentro de una `{ transaction }` sería un número que un rollback desmiente. Quien necesite el «cuántas»
  tiene `enumerateRelations`/`listSubjects` **antes** de la purga (y, dentro de la trx, por la trx). Va al
  README con esas palabras.
- **UN evento por llamada, aunque el driver barra DOS ortografías de la partición.** Los dos drivers
  recorren `#partitionSpellings` por dentro (`openfga_relations_driver.ts:604` y `:623`; el `database`
  igual). El manager no canoniza particiones (no hay `resolveChain` aquí), así que emite uno. **Diverge de
  roles a propósito** —`scopes.detached` emite uno por ortografía (`manager.ts:907`) porque ahí la
  canonización es del MANAGER— y la divergencia se fija con caso (E6), no se descubre.
- **La purga NO pasa por `assertWrite`.** `RelationRef.operation` es `'relate' | 'unrelate'` (`types.ts:1488`)
  y es el tipo PUBLICADO que recibe R-13; ampliarlo cambia el contrato de un hook que ya está en la suite
  publicada (`relations_contract.ts:666`). Se declara y se fija con caso negativo (E9) para que nadie lo
  «arregle» de paso. Si el dueño quiere vetar purgas, es otra decisión (2.5+), no ésta.

### D-2 · El tipo: **unión discriminada**, no campos opcionales

Roles resolvió el mismo problema con **un tipo y campos opcionales** (`AuthzWriteEvent.subject?`,
`types.ts:1185-1186`). Aquí recomiendo lo otro:

```ts
export interface RelationTupleWriteEvent extends RelationRef { actor?: SubjectRef; transactional?: true; indeterminate?: true }
export interface RelationPurgeWriteEvent  { operation: 'purgeObject' | 'purgeSubject'; object?: RelObject; subject?: RelSubject; partition: ScopeRef; actor?: SubjectRef; transactional?: true; indeterminate?: true }
export type RelationWriteEvent = RelationTupleWriteEvent | RelationPurgeWriteEvent
```

Motivo: con campos opcionales, el sink de hoy (`event.object.id`) **deja de compilar igual**, pero además
pierde el tipado para siempre; con la unión, `if (e.operation === 'relate')` lo devuelve intacto y el
compilador **obliga** a decidir qué hacer con una purga — que es exactamente el cambio de contrato que
estamos publicando. Es **breaking de tipos** (no de runtime) y va al CHANGELOG como tal, con la receta
de dos líneas.

### D-3 · `actor` en la purga y `requireActor` — **sí, y es breaking de comportamiento**

`purgeObject`/`purgeSubject` pasan a aceptar `actor` (nuevo `RelationPurgeOptions extends
RelationTransactionOptions { actor?: SubjectRef }`) y **quedan sujetas a `requireActor`**, como
`scopes.detached` en roles (`manager.ts:870` llama a `#writeOptions`, que exige el actor). Consecuencia:
un despliegue con `requireActor: true` que hoy purga sin actor pasa a recibir 422
`E_AUTHZ_ACTOR_REQUIRED`. **Es lo correcto** (un borrado masivo de llaves es la escritura que MÁS actor
necesita) y va al CHANGELOG como breaking. El caso inverso (E3) es obligatorio.

### D-4 · Dónde viven `assertWrite`/`onRelationWrite` en `defineConfig` — **en `relations`, NO en `hooks`**

Dos candidatos legítimos: `hooks.onRelationWrite` (simetría con `hooks.onWrite`/`onCatalogWrite`,
`define_config.ts:301-304`) o `relations.{assertWrite,onRelationWrite}` (el bloque ya agrupa TODO lo del
puerto: `config`, `default`, `drivers`, `requireTransactionalWrites`). Recomiendo **`relations.*`**: el
`RelationsManager` no lee `config.hooks` en ninguna parte y el bloque `relations` es la frontera del
puerto. **Lo innegociable es que haya UN solo sitio**: dos homes obligan a una regla de precedencia y eso
es una fábrica de bugs. El caso A5 (tsc sobre el stub) es el que impide que aparezca el segundo.

### D-5 · `relations.requireActor` anula el raíz por PUERTO

Simétrico a `relations.requireTransactionalWrites` (`define_config.ts:281-289`, cableado en
`authz_provider.ts:54` como `relations.X ?? config.X`, con su caso en `relations_service.spec.ts:181`).
Regla: `relations.requireActor ?? config.requireActor`. Los **tres** sentidos con caso (A3): heredar,
subir (raíz `false` + relations `true`) y **bajar** (raíz `true` + relations `false` — el opt-out
explícito, que es el que un revisor descuidado convertiría en «gana el más estricto»).

---

## 2 · Los casos, en el orden en que hay que atacarlos

Formato: **ID · título** → fichero · harness · dado→cuando→entonces · **ROJO hoy** (comprobado en el
código) · **mutante** que lo mata.

Notación de motores: `mem` = sqlite `:memory:` (pool 1), `file` = `sqlite-file`, `pg`, `mysql`,
`fga` = openfga `:8101`.

---

### Bloque A — El cableado (criterio (a) de COGNITIV). Sin BD, sin servidor. **Primero: es el bug del cliente.**

> Fichero: `tests/relations_service.spec.ts` (grupo `relaciones · singleton de servicio (4-8)`), más
> `tests/configure.spec.ts` para el stub. Harness: `buildRelationsManager(config)` + doble
> `makeRelationsDriver` (el ya usado, `CAPS` con `transactionalWrites: false`). Corren en los 4 modos.

**A1 · `relations.onRelationWrite` declarado en el config ⇒ un `relate` por el singleton lo dispara con su `actor`**
- Dado un `defineConfig({ relations: { config, drivers, onRelationWrite } })`; cuando
  `(await buildRelationsManager(cfg)).relate(u, 'viewer', doc, p, { actor })`; entonces el hook recibe
  **exactamente un** evento con `operation: 'relate'`, `subject`, `relation`, `object`, `partition` y
  `actor` deep-igual al pasado.
- **ROJO hoy**: `authz_provider.ts:47-56` no pasa el hook ⇒ `events.length === 0`. Antes, el propio
  `defineConfig` no admite la clave ⇒ `tsc` (A5) también rojo.
- **Mutante**: quitar `onRelationWrite:` de las opciones que construye el provider ⇒ rojo.

**A2 · `relations.assertWrite` declarado ⇒ rechaza ⇒ CERO llamadas al driver y CERO eventos**
- Dado `relations.assertWrite` que lanza si `ref.relation === 'owner'`; cuando `relate(..., 'owner', ...)`
  por el singleton; entonces lanza, el espía del driver cuenta 0 escrituras y el hook 0 eventos. Y un
  `relate(..., 'viewer', ...)` sí entra y notifica 1.
- **ROJO hoy**: el `assertWrite` no llega al manager ⇒ el `relate('owner')` **entra** (el driver escribe).
  Éste es el caso que demuestra que hoy el gate de policy del consumidor es inerte por la vía normal.
- **Mutante**: no pasar `assertWrite` en el provider ⇒ el `owner` entra ⇒ rojo.

**A3 · `relations.requireActor` anula el raíz por puerto (los tres sentidos)**
- (i) sin nada declarado: se hereda el raíz (**el caso de hoy, `relations_service.spec.ts:124`, no cambia**);
  (ii) raíz `false` + `relations.requireActor: true` ⇒ `relate` sin actor es 422 `E_AUTHZ_ACTOR_REQUIRED`
  antes del driver (0 escrituras); (iii) raíz `true` + `relations.requireActor: false` ⇒ el mismo `relate`
  **entra**.
- **ROJO hoy**: (ii) y (iii) no compilan (`relations.requireActor` no existe) y, en runtime, (iii) sería 422.
- **Mutante**: cablear `config.requireActor ?? relations.requireActor` (el `??` al revés) ⇒ (iii) rojo.
  Cablear `relations.requireActor || config.requireActor` ⇒ (iii) rojo (el `false` explícito se pierde).

**A4 · inverso · sin los hooks declarados, el singleton no inventa nada**
- Config sin `assertWrite`/`onRelationWrite`; `relate` entra, no lanza, no hay hook que llamar. (Fija que
  el cableado es `?.` y que no se pone un default ruidoso.)
- **ROJO hoy**: verde ya. Es el caso de NO-regresión que acompaña a A1/A2 (sin él, un implementador puede
  «cablear» con un objeto por defecto y romper a quien no declara nada).

**A5 · el stub `config/authorization` declara los tres, y COMPILA**
- Fichero: `tests/configure.spec.ts` (grupo `configure — stubs publicados`, caso `tsc --noEmit`, `:115`).
  El stub gana en su bloque `relations` un `assertWrite` de ejemplo comentado + `onRelationWrite:
  onAuthzRelationWrite` + `requireActor` documentado, y una aserción de forma como la de `:39` (regex
  sobre el stub) de que el hook está en el bloque `relations` y **no** en `hooks`.
- **ROJO hoy**: `tsc --noEmit` falla («Object literal may only specify known properties»). Éste es el
  diente de TIPOS del lote: si `defineConfig` no gana las claves, no compila.
- **Mutante**: declarar el hook también en `hooks` ⇒ la aserción de forma (un solo home, D-4) rojo.

**A6 · el ORDEN por la vía del singleton: F-05 primero, `assertWrite` después, driver al final**
- Por el singleton: `relate(u, 'assignee', { type: 'role_binding', ... })` con un `assertWrite` que
  **cuenta** sus llamadas ⇒ 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN` y `assertWrite` **no se llamó** (F-05 va
  antes, `relations/manager.ts:198` vs `:208`), 0 escrituras, 0 eventos.
- **ROJO hoy**: `assertWrite` no está cableado ⇒ el contador es 0 por el motivo equivocado. Hay que
  escribir la aserción POSITIVA («con una relación declarada, `assertWrite` sí se llamó una vez») para
  que el caso no pase por accidente. **Regla del lote: todo «no se llamó» va con su «sí se llamó».**

---

### Bloque B — `transactional` (criterio (b) de COGNITIV, paridad con L-3)

**B1 · unidad · las cuatro escrituras con `{ transaction }` marcan el evento; sin ella la marca está AUSENTE**
- Fichero: `tests/relations.spec.ts`, grupo L-2 (usa `spiedDouble({...CAPS, transactionalWrites: true})`,
  `:340`). Harness: doble + `fakeTrx()` (`:277`).
- Dado un driver que declara `transactionalWrites: true`; cuando `relate`/`unrelate` (y, tras el bloque E,
  `purgeObject`/`purgeSubject`) con `{ transaction: fakeTrx() }`; entonces cada evento lleva
  `transactional: true`. Sin `{ transaction }`: `assert.notProperty(event, 'transactional')` —
  **ausente, no `false`** (la letra de `types.ts:1238`, «Ausente en el resto»).
- Borde obligatorio: `{ transaction: undefined }` y `{ transaction: null }` cuentan como SIN transacción
  (es lo que hace `#transactional` en roles, `manager.ts:443`, y `#assertTransactional` aquí, `:123`).
- **ROJO hoy**: `relations/manager.ts:210`/`:230` no añaden nada ⇒ `transactional` `undefined`.
- **Mutante**: `{ transactional: options?.transaction !== undefined }` (sin el `null`) ⇒ el borde rojo.
  Emitir `transactional: false` sin transacción ⇒ el `notProperty` rojo.

**B2 · REAL · rollback ⇒ ni tupla NI evento contabilizado como definitivo (el criterio literal de COGNITIV)**
- Fichero: `tests/relations_database.spec.ts`, grupo `L-4 · { transaction } real…` (solo `file`/`pg`/`mysql`,
  guarda `L4_ENGINE !== 'sqlite'` en `:608`). Harness: `relationsWorker()` (`:583`) + `db.transaction()`
  real + `partitionRows(p)` (censo).
- Dado un sink de auditoría de DOS niveles: `onRelationWrite` empuja a `emitidos` y, **si**
  `event.transactional`, difiere el registro definitivo con `trx.after('commit', …)` empujando a `firmes`
  (si no, registra firme al momento). Cuando `relate` dentro de una trx que hace **rollback**: `emitidos`
  = 1 con `transactional: true`, **`firmes` = 0**, censo = 0. Cuando la misma secuencia hace **commit**:
  `firmes` = 1, censo = 1.
- Esto es lo que el cliente pidió, escrito como test: *«rollback ⇒ ni tupla NI evento contabilizado como
  definitivo»*. El sink diferido es parte del caso porque es **la receta que el README vende**
  (`README.md:176`, «hangs itself on `trx.after('commit')`»): si no se prueba la receta, la frase es un
  adorno.
- **ROJO hoy**: sin `transactional` el sink **no puede** diferir ⇒ `firmes` = 1 tras el rollback ⇒ rojo
  con el mensaje «un rollback dejó un registro de auditoría firme».
- **Mutante**: poner la marca solo en `relate` y no en `unrelate` ⇒ rojo en la segunda mitad del caso.

**B3 · el runner publicado: el par `transactionalWrites` juzga también el evento**
- Fichero: `src/testing/relations_contract.ts`. Cara `whenTrue` (`:1037`): las cuatro escrituras con
  `{ transaction }` emiten `transactional: true` (el runner ya construye el manager, `:485`, así que le
  pasa un `onRelationWrite`). Cara `whenFalse` (`:1197`): además de «cero llamadas al driver», **cero
  eventos** (hoy solo se cuenta `state.writes()`, `:1229`).
- **Es del PUERTO** — y esto lo he pensado: el marcador lo pone el MANAGER, no el driver, así que en
  rigor no es del puerto… pero es **la única cara observable de la capacidad**. `transactionalWrites: true`
  significa «los dos o ninguno»; el runner ya exige el censo, y el evento es la otra mitad de lo que un
  consumidor usa para saberlo. Precedente en el MISMO runner: R-13 (`:666`) juzga `assertWrite` y
  `onRelationWrite`, que también son puro manager. **Lo que NO va al runner**: `indeterminate` (no hay
  forma portable de provocar un deadline en un harness ajeno; el runner de roles tampoco lo tiene), el
  hook que lanza y el cableado del provider.
- **Coste declarado**: el runner corre **4 veces** (2 dobles en `relations_contract.spec.ts` + `database`
  real + `openfga`). No añado casos NUEVOS al runner en este bloque (amplío los dos existentes), así que
  `EXPECTED_CASES` (`tests/relations_harness.spec.ts:82`) **no se mueve**. Ver el bloque E, que sí lo mueve.
- **ROJO hoy**: la cara `true` la corre `database` en `file`/`pg`/`mysql` ⇒ rojo ahí; en `mem` la cara que
  corre es la `false` (que también gana la aserción de «cero eventos», hoy verde: es no-regresión).

**B4 · `openfga` no tiene esta cara y lo dice**
- Fichero: `tests/relations_openfga.spec.ts:446` (ya existe): `{ transaction }` ⇒ 500 `E_AUTHZ_UNSUPPORTED`,
  cero llamadas al cliente, **sin `onRelationWrite`**. Se conserva tal cual: con `transactionalWrites:
  false` la marca **nunca** puede aparecer en `fga`. Sin cambios; se lista para que el implementador no
  «amplíe» ese caso por simetría.

**B5 · docs con dientes: la frase del README que ya estaba escrita**
- Fichero: `tests/trx_docs.spec.ts`, grupo `L-6 · el README dice lo de L-6 con estas palabras`.
- Caso: el README contiene la frase de `:176` **y** los dos puertos aparecen en ella
  (`assert.include(text, "`onWrite`/`onRelationWrite` fire when the driver returns")` +
  `transactional: true` + `trx.after('commit')`).
- **ROJO hoy**: el caso no existe. **La frase está publicada desde L-6 y es falsa para relaciones**
  (H4). Éste es el caso que impide que vuelva a pasar: la letra existe, el diente no.

---

### Bloque C — Invariante 13 en relaciones (`indeterminate`)

**C1 · unidad · las cuatro escrituras que vencen el deadline notifican `indeterminate: true` ANTES del 503**
- Fichero: `tests/relations.spec.ts`, grupo nuevo `Invariante 13 · el deadline en relaciones`. Harness:
  **driver falso** cuyos `relate`/`unrelate`/`purgeObject`/`purgeSubject` lanzan
  `new AuthorizationBackendTimeoutError('fake-relations', op, 5)` — copia literal del patrón de roles
  (`tests/manager.spec.ts:139-195`). Sin BD para el driver; la barrera del freeze sí lee la BD del harness
  (existe en los 4 modos).
- Entonces: por cada operación, un evento con `indeterminate: true` **y el resto de campos del evento
  intactos** (`operation`, `subject`/`object`, `partition`, `actor`, y `expiresAt` si se pasó), y después
  el 503 `E_AUTHZ_BACKEND_TIMEOUT` propagado al llamante.
- **ORDEN, explícito**: el hook se llama ANTES de que el llamante vea el error. Se observa empujando a un
  array compartido desde el hook y desde el `catch`, y comparando la secuencia
  `['hook:relate', 'catch:relate', …]`. Sin esta aserción, un implementador que notifique en un
  `finally` posterior pasa el caso.
- **ROJO hoy**: cero eventos (no hay `#write`).
- **Mutante**: notificar en cualquier `catch` (no solo en el de `AuthorizationBackendTimeoutError`) ⇒ C2
  rojo. Notificar sin la marca ⇒ este caso rojo.

**C2 · inverso · lo que NO produce evento**
- Mismo fichero y harness. Cuatro negativos en un caso:
  (i) un 503 que **no** es timeout (`AuthorizationBackendError(..., new Error('ECONNREFUSED'))`) ⇒ cero
  eventos (letra de `types.ts:1222`, *«esa escritura no ocurrió»*);
  (ii) un 422 de F-05 / R-16 / `expiresAt` inválido ⇒ cero eventos, cero llamadas;
  (iii) `assertWrite` que lanza ⇒ cero eventos, cero llamadas;
  (iv) el **freeze** (503 `E_AUTHZ_FROZEN`) ⇒ cero eventos, cero llamadas.
- (iii) y (iv) están hoy medidos a medias en `relations_database.spec.ts:695-723`
  (`assert.deepEqual(events, [])`) pero **solo dentro del grupo de `{ transaction }`**, que no corre en
  `mem`. Aquí se fijan sin transacción y en los 4 modos.
- **ROJO hoy**: verde por ausencia (no hay ningún evento nunca). **Este caso pasa hoy sin la
  implementación, así que por sí solo no prueba nada** — vale únicamente como no-regresión de C1, y el
  implementador tiene que escribirlo DESPUÉS de C1 (o el auditor lo marcará como caso hueco).

**C3 · REAL · el deadline DENTRO de la transacción del llamante ⇒ `indeterminate: true` **y** `transactional: true`**
- Fichero: `tests/relations_database.spec.ts`, grupo `L-4` (`file`/`pg`/`mysql`). Harness: calcado del de
  roles (`tests/database_transaction.spec.ts:355-409`) con el mecanismo ya probado en relaciones
  (`relations_database.spec.ts:930` y `:990`): `relationsWorker({}, { timeoutMs: 400 })`, T1 escribe la
  tupla en su trx y no confirma, T2 escribe **la misma** por otra trx y espera en el UNIQUE hasta que su
  deadline de 400 ms vence.
- Entonces, por motor:
  - `pg` / `mysql`: 503 `E_AUTHZ_BACKEND_TIMEOUT` en < 5 s, eventos
    `[['relate', true, false], ['relate', true, true]]` (transactional, indeterminate). Y lo que queda de
    la trx: PG **abortada** (`25P02`), MySQL **viva** — se mide, no se supone (es lo que hizo L-3).
  - `file`: **no hay deadline que vencer** (SQLite es síncrono): sale `SQLITE_BUSY` ⇒ 503
    `E_AUTHZ_BACKEND_UNAVAILABLE` y **sin** evento indeterminado. Es la cara honesta y va en el mismo caso.
- **ROJO hoy**: sin evento en ninguno de los tres.
- **Mutante**: mantener `indeterminate` pero perder `transactional` dentro de la trx (el error que el
  auditor del panel `{trx}` objetó en su día, 🟡 12) ⇒ rojo.

**C4 · `openfga`: el deadline con SERVIDOR MUDO, sin `:8101`**
- Fichero: `tests/relations_openfga.spec.ts`, grupo nuevo **FUERA** de la guarda `if (openFgaTestUrl)`
  (`:30`). Precedente exacto y ungated: `tests/openfga_driver.spec.ts:361-437` (`net.createServer` que
  acepta y calla, `timeoutMs: 200`, `storeId` inventado, teardown que destruye los sockets).
- Dado un `RelationsManager` sobre `OpenFgaRelationsDriver({ apiUrl: mudo, timeoutMs: 200 })`; cuando
  `relate`; entonces 503 `E_AUTHZ_BACKEND_TIMEOUT` en < 1 s **y** un evento con `indeterminate: true`
  **sin** `transactional` (en `openfga` la puerta 1 hace imposible `{ transaction }`, `relations/manager.ts:122-130`).
- Corre en los **4 modos** (no necesita el `:8101`): es la respuesta a «¿hay deadline ahí?» → **sí**
  (`openfga_relations_driver.ts:266-267`), y a «¿`withDeadline` en el driver?» → el deadline es
  `baseOptions.timeout` del SDK (`:232`) con `maxRetry: 0` (`:233`) y la clasificación es propia
  (`isTimeoutLike`, `:741-746`); no usa el helper `withDeadline` de `backend_guard`, cosa que este caso
  hace observable por primera vez para RELACIONES.
- **ROJO hoy**: cero eventos.
- **Mutante**: `retryParams: { maxRetry: 1 }` ⇒ el caso tarda más del presupuesto y el «no dejamos al SDK
  reintentar» del invariante 13 se rompe visiblemente.

**C5 · `purgeObject`/`purgeSubject` también son indeterminadas** — se escribe con el bloque E (E5), pero
la implementación de `#write` tiene que envolver las CUATRO desde C1.

---

### Bloque D — Paridad del despacho: el hook que lanza, el hook async, y el actor validado

**D1 · un `onRelationWrite` que lanza NO tumba la escritura ya aplicada (paridad literal con roles)**
- Fichero: `tests/relations.spec.ts` (grupo nuevo `paridad de #notify`). Harness: doble + `captureErrorLog`
  (el helper de `tests/manager.spec.ts:33`; hay que extraerlo a `tests/helpers/` o duplicarlo — el
  implementador decide, pero el log **tiene que quedar registrado**, no tragado en silencio).
- Dado `onRelationWrite` que lanza; cuando `relate`; entonces **no lanza al llamante**,
  `check(...) === true` (la tupla está), y el log de error contiene la operación (`'relate'`).
- **ROJO hoy**: el `relate` propaga el error del hook (`relations/manager.ts:210`, sin `try/catch`) ⇒ el
  llamante ve un fallo por una escritura que sí ocurrió. **Hallazgo H1.**
- **Mutante**: quitar el `try/catch` ⇒ rojo. Tragarlo sin registrar ⇒ rojo por el `isNotEmpty(logged)`.

**D2 · un `onRelationWrite` `async` que RECHAZA tampoco propaga (y se espera)**
- Igual que D1 con un hook `async`. Fija que el hook se `await`ea: hoy no se espera
  (`onRelationWrite?(...)` es `void` y no hay `await`), así que el rechazo se convierte en un
  **unhandled rejection** — ni tumba ni se registra: desaparece. Exige ampliar el tipo a
  `void | Promise<void>` (ampliación, no breaking).
- **ROJO hoy**: `logged` vacío (nadie registró nada).
- **Mutante**: llamar al hook sin `await` ⇒ rojo.

**D3 · un `assertWrite` `async` NO es un `assertWrite`: 500 `E_AUTHZ_CONFIG`, cero escrituras**
- Fichero: `tests/relations.spec.ts`, grupo R-13. Dado `assertWrite: async (ref) => { throw ... }`; cuando
  `relate`; entonces **500 `E_AUTHZ_CONFIG`** nombrando `assertWrite`, «síncrono» y la receta, y **cero**
  llamadas al driver.
- **ROJO hoy**: la escritura **ENTRA** (la promesa devuelta se descarta, `relations/manager.ts:208`) —
  **hallazgo H2, fail-open, y es exactamente lo que COGNITIV asumió al revés**. Hoy el caso es rojo
  porque el `relate` no lanza y el espía cuenta 1.
- **Mutante**: quitar la detección del *thenable* ⇒ rojo.
- **Nota de alcance**: esto es más que «una línea de docs». Lo propongo porque documentar un fail-open sin
  cerrarlo deja el defecto y añade una frase. Si el coordinador lo saca del lote, entonces la línea de docs
  tiene que decir literalmente *«un `assertWrite` que devuelve una promesa NO se espera y la escritura
  entra»* y llevar su caso de letra — publicar el defecto, no esconderlo.

**D4 · el `actor` se valida como identidad, en las CUATRO escrituras**
- Fichero: `tests/relations.spec.ts`. Dado `{ actor: { type: 'user', uuid: 'A#B' } }` (y las variantes:
  uuid en MAYÚSCULAS, `uuid: undefined`, `actor: {}`); cuando cualquiera de las cuatro; entonces 422
  `E_AUTHZ_INVALID_IDENTITY` **antes** del driver (cero llamadas, cero eventos). Y con un actor bien
  formado, entra y viaja al evento.
- **ROJO hoy**: entra y el actor basura viaja al evento — **hallazgo H3**. Paridad con `manager.ts:1512`.
- **Mutante**: validar solo en `relate` ⇒ rojo en `unrelate`/purgas. Comprobar `requireActor` con
  truthiness antes de validar ⇒ `actor: {}` pasa ⇒ rojo.
- **Borde**: `requireActor: true` + `actor: {}` tiene que ser **422 de identidad**, no «actor requerido»:
  el orden es validar-si-viene y después exigir-si-falta (el de roles, `manager.ts:1512-1517`).

---

### Bloque E — La purga (hallazgo 4 + D-1/D-2/D-3)

**E1 · `purgeObject` y `purgeSubject` notifican UN evento con la forma decidida**
- Fichero: `tests/relations.spec.ts` (unidad, doble) **y** `src/testing/relations_contract.ts` (R-07/R-08,
  `:585`, que ya ejercen las dos purgas contra los 4 harness).
- Entonces: `purgeObject(doc, p, { actor })` ⇒ **un** evento
  `{ operation: 'purgeObject', object: doc, partition: p, actor }` **sin** `subject` ni `relation`
  (`assert.notProperty`); `purgeSubject(u, p, { actor })` ⇒ `{ operation: 'purgeSubject', subject: u,
  partition: p, actor }` **sin** `object` ni `relation`.
- **ROJO hoy**: cero eventos (`relations/manager.ts:266`, `:273`).
- **Mutante**: emitir `operation: 'unrelate'` en la purga ⇒ rojo (un sink que cuenta desasociaciones
  contaría una purga como una). Emitir un evento por tupla borrada ⇒ rojo por `lengthOf(events, 1)`.

**E2 · una purga que no borra NADA notifica igual**
- Purgar un objeto sin tuplas ⇒ un evento. Paridad con roles: `scope_purged` se notifica siempre que la
  purga vuelve OK, tenga o no hechos (`manager.ts:907-911`). Y es lo que un auditor quiere: «alguien pidió
  borrar las llaves de X» es el hecho auditable, haya o no llaves.
- **ROJO hoy**: cero eventos. **Mutante**: condicionar el evento a «borró algo» ⇒ rojo (y además exigiría
  romper el puerto para saberlo, D-1).

**E3 · inverso · `requireActor: true` alcanza a las purgas: 422 sin tocar el driver**
- `requireActor: true` (por `relations.requireActor` o heredado) + `purgeObject(doc, p)` sin actor ⇒ 422
  `E_AUTHZ_ACTOR_REQUIRED`, cero llamadas, cero eventos. Con actor, entra.
- **ROJO hoy**: la purga **entra** (`#assertActor` no se llama en `purgeObject`/`purgeSubject`,
  `relations/manager.ts:261-274`). **Es breaking** (D-3): va al CHANGELOG.
- **Mutante**: exigir el actor pero DESPUÉS de la barrera del freeze/del driver ⇒ el «cero llamadas» rojo.

**E4 · purga × `{ transaction }`: el evento marca, y el rollback lo deshace**
- Fichero: `tests/relations_database.spec.ts` (L-4, `file`/`pg`/`mysql`). `purgeObject` dentro de una trx
  con rollback ⇒ evento con `transactional: true`, sink diferido a `after('commit')` = 0 registros, censo
  intacto (las tuplas siguen). Con commit: 1 registro, censo 0. **Y las purgas revierten JUNTAS** (el
  runner ya lo fija por censo, `relations_contract.ts:1104-1106`); aquí lo que se añade es el evento.
- **ROJO hoy**: cero eventos.

**E5 · purga que vence el deadline ⇒ `indeterminate: true`**
- Con el driver falso de C1: `purgeObject`/`purgeSubject` que lanzan timeout ⇒ evento con
  `indeterminate: true` antes del 503. (Una purga a medias con un 503 es EL caso donde el auditor más
  necesita el «puede haber ocurrido»: el `#purgeByFilter` de `openfga` borra en lotes y re-lee para
  demostrar cero, `openfga_relations_driver.ts:638`.)
- **ROJO hoy**: cero eventos.

**E6 · UN evento por llamada, aunque el driver barra DOS ortografías de partición**
- Fichero: `tests/relations_database.spec.ts` (el grupo que ya cubre «el barrido de las dos ortografías del
  uuid de partición en `purge*`»). Partición con uuid en las dos formas (32 hex / 8-4-4-4-12) ⇒ el driver
  barre las dos, el manager emite **uno**.
- **ROJO hoy**: cero eventos. **Mutante**: emitir dentro del bucle de ortografías (que es lo que hace
  roles, `manager.ts:907`) ⇒ 2 eventos ⇒ rojo. Fija la divergencia decidida en D-1.

**E7 · el runner publicado gana el caso de la purga**
- `src/testing/relations_contract.ts`: R-07/R-08 (`:585`) se amplía con el evento, **o** entra un caso
  nuevo `R-17 · las purgas notifican`. Recomiendo **ampliar R-07/R-08** para no mover el contador.
- **Si se añade caso nuevo**, el coste es real y hay que pagarlo en el mismo commit:
  `tests/relations_harness.spec.ts` → `EXPECTED_CASES` 20 → 21 (`:82`), `CAPABILITY_KEYS` sin cambio, el
  `BREAKDOWN.nucleo` 11 → 12 **o** una entrada nueva en `BEYOND_JUEZ` (`:250`), y el total de la suite
  sube **+4** (el runner corre 4 veces: 2 dobles + `database` + `openfga`) o +3 sin `:8101`. Si no se paga,
  `relations_harness.spec.ts` se pone rojo — que es exactamente para lo que está.

**E8 · el tipo: un sink que discrimina por `operation` compila; uno que no, no**
- Fichero: `tests/configure.spec.ts` (el `tsc --noEmit` del stub, `:115`), con el stub trayendo un
  `onAuthzRelationWrite` de ejemplo que hace `switch (event.operation)` y usa `event.object.id` **dentro
  de la rama** `'relate' | 'unrelate' | 'purgeObject'`.
- **ROJO hoy**: no compila (el hook no existe en el config). Tras el lote, si alguien vuelve a
  `RelationWriteEvent extends RelationRef` con opcionales, el stub sigue compilando pero **pierde** el
  estrechamiento — por eso el stub tiene que acceder a `event.relation` en una rama donde la unión lo
  garantiza: con opcionales sería `string | undefined` y `tsc` lo caza.

**E9 · negativo declarado · la purga NO pasa por `assertWrite`**
- `assertWrite` que cuenta llamadas + `purgeObject`/`purgeSubject` ⇒ contador 0, purga hecha, evento
  emitido. Fija la decisión D-1 para que nadie la «complete» de paso y rompa el tipo publicado de R-13.
- **ROJO hoy**: verde (pero por ausencia de todo). Caso de forma, no de defecto: va acompañado siempre de
  E1 en el mismo grupo.

---

### Bloque F — Docs con dientes

Patrón: `tests/trx_docs.spec.ts` (grep con `assert.include` sobre `README.md` + el error real byte a byte).
Recomiendo un fichero nuevo `tests/relations_events_docs.spec.ts` para no engordar el de `{trx}` (y porque
estas frases sobreviven a `{trx}`), con el mismo estilo.

| ID | La frase que fija la garantía | Caso de letra |
|---|---|---|
| **F1** | `README.md:176` (ya escrita): *"`onWrite`/`onRelationWrite` fire when the driver returns, with `transactional: true` on the event… a sink that wants the last word hangs itself on `trx.after('commit')`"* | B5 (en `trx_docs.spec.ts`, que es donde vive §L-6) |
| **F2** | NUEVA · el invariante 13 nombrando el puerto de relaciones: *"a relation write that elapses its deadline notifies `onRelationWrite` with `indeterminate: true` before propagating the 503"*, y que en `openfga` (donde `{ transaction }` es imposible) el evento **no** lleva `transactional` | `assert.include` de la frase + el caso C1/C4 nombrado entre paréntesis, como hace el README en `:243` |
| **F3** | NUEVA · la tabla de `operation`s: `relate`, `unrelate`, `purgeObject` (sin `subject`/`relation`), `purgeSubject` (sin `object`/`relation`); **sin conteo**, y la receta para quien lo necesite (`enumerateRelations` antes de purgar) | `assert.include` de las cuatro operaciones + de «does not count» |
| **F4** | NUEVA · `assertWrite` es **síncrono, puro y sin `actor`** a propósito (R-13), corre después de F-05 y antes del driver, y **devolver una promesa es 500 `E_AUTHZ_CONFIG`** (no un rechazo ignorado) | La frase + `assert.equal(mensaje del error, …)` byte a byte, patrón `trx_docs.spec.ts:145` |
| **F5** | NUEVA · el cableado: `relations.assertWrite` / `relations.onRelationWrite` / `relations.requireActor` (este último **anula el raíz por puerto**, como `relations.requireTransactionalWrites`), y `manager.driver()` sigue saltándose los tres | La frase + la aserción de forma del stub (A5) |
| **F6** | CORRECCIÓN · `README.md:566` dice que `manager.driver()` se salta «`actor`, `assertWrite`, `onRelationWrite`» — sigue siendo cierto y hay que **conservarlo** al reescribir el párrafo | `assert.include` (no-regresión de la frase) |

**Respuesta a COGNITIV** (va con el lote, no es un test): su punto (1) es inexacto en la mitad —
`requireActor` **sí** está cableado (`authz_provider.ts:48`) desde 4-8, con caso
(`relations_service.spec.ts:124`); lo que falta son `assertWrite` y `onRelationWrite`. Y se les cuentan
los dos huecos del barrido (invariante 13 y las purgas) más los cuatro míos (H1–H4), de los que **H2 les
afecta directamente**: si su `assertWrite` es `async`, hoy no rechaza nada.

---

## 3 · Verificabilidad por backend y por motor

| caso | `mem` (pool 1) | `file` | `pg` | `mysql` | `fga :8101` | ¿mismo test? |
|---|---|---|---|---|---|---|
| A1–A6 (cableado) | ✅ | ✅ | ✅ | ✅ | ✅ (doble, no toca el servidor) | sí, uno solo |
| B1, B4 (unidad `transactional`) | ✅ | ✅ | ✅ | ✅ | ✅ | sí |
| **B2 (rollback ⇒ sink diferido)** | ❌ pool 1 ⇒ 503 de la barrera | ✅ | ✅ | ✅ | ❌ imposible por diseño (puerta 1) | sí, dentro de la guarda `L4_ENGINE !== 'sqlite'` |
| B3 (runner, cara `true`) | ❌ (declara la cara `false`) | ✅ | ✅ | ✅ | ❌ (cara `false`) | sí, es el par de capacidad |
| C1, C2 (deadline con doble) | ✅ | ✅ | ✅ | ✅ | ✅ | sí |
| **C3 (deadline dentro de la trx)** | ❌ | ⚠️ cara «no hay deadline»: `SQLITE_BUSY` ⇒ 503 sin evento | ✅ `25P02`, trx abortada | ✅ trx viva | ❌ | uno, con rama por motor (patrón L-3) |
| **C4 (servidor mudo, openfga)** | ✅ | ✅ | ✅ | ✅ | ✅ | sí, y **no necesita el `:8101`** |
| D1–D4 (hook/actor) | ✅ | ✅ | ✅ | ✅ | ✅ | sí |
| E1, E2, E3, E5, E9 | ✅ | ✅ | ✅ | ✅ | ✅ | sí |
| E4 (purga × trx) | ❌ | ✅ | ✅ | ✅ | ❌ | sí (misma guarda que B2) |
| E6 (dos ortografías) | ✅ | ✅ | ✅ | ✅ | ✅ (el driver `fga` también barre dos) | sí |
| E7 (runner) | ✅ ×2 dobles | + `database` | + `database` | + `database` | + `openfga` | sí |
| F1–F6 (docs) | ✅ | ✅ | ✅ | ✅ | ✅ | sí (leen ficheros) |

**Riesgos específicos por motor**, que el implementador NO debe descubrir a mitad:

- **`mem` (pool 1)**: cualquier caso con `{ transaction }` REAL choca con la barrera del freeze (503 a
  `freezeTimeoutMs`) — es lo decidido (invariante 14, pool ≥ 2) y por eso `TRANSACTIONAL_WRITES` es
  `testEngine() !== 'sqlite'` (`relations_database.spec.ts:30`). No se «arregla» bajando la barrera.
- **`file`**: no hay deadline SQL que vencer (SQLite es síncrono); lo que sale es `SQLITE_BUSY` ⇒ 503
  `E_AUTHZ_BACKEND_UNAVAILABLE`, que **no** es timeout ⇒ **sin** evento indeterminado. Esa es la cara
  correcta, no un fallo del caso.
- **`pg`**: tras el 503, la trx del llamante queda **abortada** (`25P02`): toda aserción posterior por esa
  trx tiene que ir por `transactionAlive()` (`database_transaction.spec.ts:109`) o hacer rollback antes.
- **`mysql`**: `KILL QUERY` mata la sentencia y la trx **sigue viva** — el caso tiene que afirmar los dos
  comportamientos, no uno.
- **`fga`**: `transactionalWrites: false` es estructural (una tupla no entra en una trx SQL). `indeterminate`
  sí aplica y se mide con el socket mudo. Las purgas de `fga` son **N Writes en bucle** por ortografía y
  por tipo (`openfga_relations_driver.ts:604`, `:623-634`): un 503 a mitad deja el store a medias — razón
  extra para E5.
- **Concurrencia**: los casos de dos transacciones (B2, C3) usan `db.transaction()` explícitas y **tienen
  que cerrar en `finally`**; una trx colgada retiene una conexión del pool y arrastra a los casos
  siguientes (el runner ya lo dice, `relations_contract.ts:1053-1055`).
- **Nada de `sleep` para caducidades**: `injectableClock`/`withClock` ya existe en los dos drivers de
  relaciones (R-15). Ninguno de estos casos necesita esperar tiempo real; los `setTimeout(300)` de B2/C3
  son **sincronización entre dos transacciones**, no relojes, y así hay que comentarlos.

---

## 4 · Orden de ataque (rojo→verde, por lotes de commit)

1. **Tipos** (`src/types.ts`): unión discriminada `RelationWriteEvent` + `transactional`/`indeterminate`
   + `RelationPurgeOptions` con `actor`. No observable por sí solo; habilita todo lo demás. (D-1, D-2, D-3.)
2. **A1–A6 + A5(tsc)** — el cableado. Es el bug del cliente, no depende de nada más y es el más barato.
3. **B1, B4, B2, B3, B5** — `transactional`. Cierra el criterio (b) de COGNITIV.
4. **C1, C2, C3, C4** — invariante 13. (`#write` envolviendo las CUATRO desde el principio.)
5. **D1, D2, D4** — paridad de despacho (`#notify` + actor validado). **D3** aquí si se acepta el 500 del
   `assertWrite` async; si no, salta a docs (F4) con la frase que publica el defecto.
6. **E1–E9** — las purgas (arrastran `actor`, `transactional` e `indeterminate` ya implementados: si se
   hacen antes, se hacen dos veces).
7. **F1–F6 + CHANGELOG** — docs con dientes, los dos breaking declarados (tipos: unión; comportamiento:
   `requireActor` alcanza a las purgas).

**Verificación de cierre exigida** (la del encargo, sin rebaja): los 4 modos
(`npm test`, `test:sqlite-file`, `test:pg`, `test:mysql`) y **cada uno además con
`OPENFGA_TEST_URL=http://localhost:8101`**. Base a superar: **825** (sqlite sin servidor) y **1074**
(sqlite con servidor). Si el total NO sube, algún caso no se registró.

---

## 5 · Lo que este lote NO cubre, y por qué

| Qué | Estado | Motivo |
|---|---|---|
| **`group#member` hardcoded** (punto #3 de COGNITIV) | ❌ fuera, **backlog 2.7** | Decisión ya tomada (`decisiones-dueno-2026-08-28.md`, 2026-09-02 (2)). Es un cambio de la arista de membresía, no del evento; mezclarlo obliga a tocar el modelo fusionado y el runner. |
| **Conteo de tuplas borradas en el evento de purga** | ❌ fuera (D-1) | Rompe el puerto (`purge*` devuelve `void`) y sería un número que un rollback desmiente. Documentado con su alternativa. |
| **`assertWrite` en las purgas** | ❌ fuera (D-1) | Cambiaría `RelationRef.operation`, que es tipo publicado del hook R-13 en la suite de contrato. Caso negativo E9 para que no se cuele. |
| **`authz:relations:reconcile` no emite eventos** | ❌ fuera, declarado | Escribe por el DRIVER de destino (`src/relations/reconcile.ts:302-305`), igual que el reconcile de roles. Es la salida documentada de las barreras (`manager.driver()`); si un día se quiere auditar, es un lote propio con su decisión (¿un evento por tupla migrada? el volumen lo hace otra cosa). |
| **`indeterminate` en el runner publicado** | ❌ fuera (B3) | No hay forma portable de provocar un deadline en el harness de un tercero. El runner de ROLES tampoco lo tiene: la simetría se conserva. |
| **El cableado del provider en el runner publicado** | ❌ fuera | El runner juzga DRIVERS; `buildRelationsManager` es del chasis. Va en `relations_service.spec.ts`. |
| **Paridad del runner de ROLES con el de relaciones** (R-13 existe en relaciones y no en roles; el marcador `transactional` no está en ninguno de los dos hoy) | 🟡 **hueco declarado, no se cierra aquí** | Añadir casos al runner de roles mueve `contract_harness.spec.ts` y afecta a drivers de terceros ya publicados. Se anota para consolidación (Fase 6). |
| **Un sink que se cuelga de `after('commit')` en `openfga`** | ❌ imposible | No hay transacción: la puerta 1 lo rechaza antes. Ya cubierto por el negativo B4. |
| **Multiproceso / dos escritores del evento** | ❌ fuera | El evento es in-process por diseño (no hay outbox de hechos ni de relaciones: decisión del panel `{trx}`). Precedente: `freeze_multiprocess.spec.ts` existe para el freeze porque ahí sí hay estado compartido. |

---

## 6 · Resumen para el implementador (checklist de «esto está probado o no está»)

- [ ] Un `relate` por `authz.relations` con `relations.onRelationWrite` declarado **dispara el hook con su actor** (A1)
- [ ] `relations.assertWrite` declarado **rechaza de verdad**, con cero escrituras (A2)
- [ ] `relations.requireActor` **anula el raíz en los dos sentidos** (A3)
- [ ] El stub publicado **compila** con las tres claves y no las duplica en `hooks` (A5)
- [ ] `transactional: true` en las **cuatro** escrituras con `{ transaction }`; **ausente** sin ella (B1, E4)
- [ ] Rollback ⇒ censo 0 **y** sink diferido a `after('commit')` con **0 registros firmes** (B2)
- [ ] Deadline ⇒ `indeterminate: true` **antes** del 503, en las **cuatro**, en `database` y en `openfga` (C1, C3, C4, E5)
- [ ] Dentro de la trx, deadline ⇒ `indeterminate` **y** `transactional` (C3)
- [ ] 422 / F-05 / `assertWrite` / freeze / 503-no-timeout ⇒ **cero eventos** (C2)
- [ ] Un hook que lanza (sync o async) **no tumba** la escritura y **queda registrado** (D1, D2)
- [ ] Un `assertWrite` async **no se ignora en silencio** (D3)
- [ ] Un `actor` mal formado es **422 antes del driver** (D4)
- [ ] Las purgas notifican **uno** por llamada, con la forma decidida, y **respetan `requireActor`** (E1, E3, E6)
- [ ] Cada frase nueva del README tiene su caso de letra (F1–F6)
- [ ] La suite sube de 825 / 1074 en los 4 modos × con y sin `:8101`
