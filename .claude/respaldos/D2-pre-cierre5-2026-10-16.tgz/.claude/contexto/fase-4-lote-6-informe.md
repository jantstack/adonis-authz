# Fase 4 · Lote 4-6 — anexo, conteo literal, CLI, README/CHANGELOG y CIERRE de fase

> Base: `main` @ `d44f49c` (4-5 mergeado). Árbol principal, SIN commits (los hace el dueño).
> Plan: `fase-4-juez.md` §4-6 + «Desglose honesto del conteo (~41)» + `fase-4-plan.md` §7 + informes 4-1…4-5.
> Alcance: R-14 confirmado, R-15 diferida y documentada, los dos casos de diseño con tablas ficticias,
> el conteo literal del juez aterrizado, el comando CLI de reconcile de relaciones, README + CHANGELOG 2.4,
> y las 5 cifras. ÚLTIMO lote de implementación de la Fase 4.

## Las 5 cifras (todas verdes, corridas a fichero, +14 aditivo)

| modo | antes (4-5) | ahora | delta |
|---|---|---|---|
| `npm test` (`:8101`) | 943 | **957** | +14 |
| `test:sqlite-file` (`:8101`) | 948 | **962** | +14 |
| `test:pg` (`:8101`) | 1042 | **1056** | +14 |
| `test:mysql` (`:8101`) | 1042 | **1056** | +14 |
| **`npm test` (`:8103`, tope 3)** | — | **957** | (todas verdes) |

`tsc` (ambos tsconfig), `typecheck`, `check:purity` y `build` limpios. `:8101` a **0 stores** al cerrar;
`openfga-tiny` eliminado. Desglose del +14: `relations_harness.spec.ts` (+4: guards «true sin soporte» +
conteo de reconcile + conteo literal del juez), `relations_reconcile_cli.spec.ts` (+4), `relations_design_cases.spec.ts` (+6).

> **Intermitente CONOCIDO (NO regresión de este lote):** en la 1.ª pasada de `test:sqlite-file` corrida justo
> tras pg+mysql, falló 1 vez `facts · 3b-2e · E5 — la cota es 22 y NO 23` (el test de profundidad del 4-1) por
> el borde PROBABILÍSTICO a 23 saltos con el `:8101` SATURADO —el propio mensaje del assert lo dice: «el :8101
> estuvo SATURADO durante toda la medida, repite con el servidor tranquilo»—. Reiniciada la corrida SOLA:
> **962 (todas verdes)**. Es el mismo flaky que anotaron 4-1/4-2/4-4/4-5; no toca profundidad este lote.

## R-14 (`membersOf`) — CONFIRMADO cubierto (sin caso nuevo del anexo que falte)

`membersOf` es la membresía TRANSITIVA (distinta de `listSubjects` directo). Su par de capacidad está
cubierto en los tres sitios:
- **Runner** (`relations_contract.ts`, `caseFor('membersOfNative', …)`): `whenTrue` (transitiva, distinta de
  `listSubjects`) y `whenFalse` (500 `E_AUTHZ_UNSUPPORTED` nombrándolo), sin skip.
- **`database`** (`relations_database.spec.ts`, `membersOfNative:true`): CTE recursiva `grp`, transitiva real.
- **`openfga`** (`relations_openfga.spec.ts`, `membersOfNative:false`): 500 `whenFalse` (la transitiva sería
  `ListUsers`, que trunca). Ningún caso del anexo quedó sin cubrir.

## R-15 (caducidad de relación) — DIFERIDA a 2.6, documentada (NO implementada)

Decisión del dueño: R-15 FUERA de la 2.4. `authz_relations` sigue INSERT/DELETE-ONLY (sin `expires_at`). Se
deja escrito como «diferida a 2.6» en: README (§Relations, «Not in 2.4 — relation expiry (R-15)»),
CHANGELOG 2.4 («What is NOT done»), y el conteo literal (`DEFERRED.r15Condicional`, ver abajo). El
«renovar = delete+insert» que su AC exigía queda moot y también se cuenta como diferido.

## Los dos casos de DISEÑO del consumidor, con tablas ficticias (plan §7) — VERDES

`tests/relations_design_cases.spec.ts` (6 casos, doble en memoria + `RelationsManager`). Cada caso lista las
**tablas ficticias del consumidor** en comentario y MAPEA cada fila a la API del paquete:

1. **Compartir documento estilo Drive (ReBAC de objetos)** — tablas `drive_documents`, `drive_groups`,
   `drive_group_members`, `drive_document_shares`. Casos: editor ⊆ viewer (y un viewer NO edita); compartir
   con un EQUIPO (userset `group#member`) ⇒ los miembros heredan; el tenant AÍSLA (otra partición no concede).
2. **«Llave COGNITIV» a un espacio (ReBAC de objetos)** — tablas `cognitiv_spaces`, `cognitiv_keys`,
   `cognitiv_space_teams`. Casos: una llave da acceso al `space` (`admin ⊆ holder`); un EQUIPO con llave
   (userset) + `membersOf` enumera la membresía; y **la constancia ejecutable de la frontera del plan §7**:
   la «llave como SCOPE» NO es este puerto (`relate` sobre `{type:'scope'}` ⇒ 422 F-05: eso lo resuelve
   `roles/`). Demuestra que la MISMA API sirve para los dos casos del roadmap sin quedar abstracta.

## El CONTEO LITERAL del juez, aterrizado — `tests/relations_harness.spec.ts`

Tres bloques, todos con su rojo por mutante del NÚMERO ESPERADO:

1. **Runner (17 casos, 6 capacidades)** — `register(FULL)`/`register(MINIMAL)` afirman `registered === 17` y
   `covered.size === 6`, cada capacidad con SU cara. Mutante (`EXPECTED_CASES 17→18`):
   ```
   ❯ … / un harness FULL registra el nº literal de casos y cubre las 6 capacidades
   ℹ AssertionError: expected 17 to equal 18
   ```
2. **Contrato de reconcile (9 casos)** — `registerRelationsReconcileContract` con fakeApi afirma
   `registered === 9` (4 por dirección × 2 + 1 negativo) y 2 casos con CENSO.
3. **El conteo del JUEZ (~41), aterrizado** — un `BREAKDOWN` con literal por componente (núcleo 11, caras
   ×2 = 8, frontera/negativos/config 9, gates 3, carrera 2, reconcile 3, solo-driver 2, anexo 1) que suma
   **39** (`landed`), más un `DEFERRED` (renovar=delete+insert 1 + R-15 condicional 1 = 2) que reconstruye el
   objetivo del juez: `landed + deferred === 41`. Mutante (`landed 39→40`):
   ```
   ❯ Fase 4 · el conteo literal del juez (~41) / los componentes suman el conteo ATERRIZADO …
   ℹ AssertionError: los casos de la Fase 4 que EXISTEN de verdad: expected 39 to equal 40
   ```
   **Los 39 EXISTEN; los 2 que faltan para el ~41 son R-15 y su renovación, DIFERIDOS a 2.6** (no huecos por
   descuido). Es la respuesta honesta al «cuenta los que hay y ancla el número; si no llegan, di cuáles faltan».

4. **«Una capacidad `true` sin su soporte se rechaza»** (paridad con el guard de roles):
   - **Registro**: `listObjectsTruncation:true` SIN `limits.listMaxResults` ⇒ el runner lanza AL REGISTRAR
     (guard nuevo en `relations_contract.ts`). Mutante (guard desactivado):
     ```
     ❯ … / listObjectsTruncation:true SIN limits.listMaxResults se rechaza AL REGISTRAR
     ℹ AssertionError: expected [Function] to throw an error
     ```
   - **Llamada**: un driver que MIENTE (`membersOfNative`/`enumerateRelations: true` sin el método) ⇒ el
     `RelationsManager` responde 500, jamás un skip (comprueba método Y capacidad). `assert.rejects` verde.

## El comando CLI `authz:relations:reconcile` (plataforma) — con su función pura

`commands/authz_relations_reconcile.ts` (registrado en `commands/main.ts`), patrón de `authz:reconcile` de
roles:
- Banderas `--to` / `--from` (claves de `relations.drivers` del config), `--dry-run`, `--prune`,
  `--partition-type`/`--partition-uuid` (default `app`: mono-tenant, el reconcile es POR partición).
- **Reporte NO silencioso**: la decisión vive en la función PURA `relationsReconcileLines(report)` (como
  `reconcileLines`), con su caso propio (`relations_reconcile_cli.spec.ts`, 4 casos): resume
  written/deleted/unchanged/extra; **`modelDrift` es SIEMPRE deriva** (un tipo del origen que el destino no
  declara no cabe en su modelo fusionado); en `--dry-run` cualquier cosa que haría (escribir/borrar/sobrar)
  es deriva (exit 1); `extra` sin `--prune` en una pasada real AVISA pero no tumba. Mutante (la función
  ignora `modelDrift`):
  ```
  ❯ authz:relations:reconcile — relationsReconcileLines / modelDrift SIEMPRE es deriva …
  ℹ AssertionError: expected true to be false
  ```
- **Wiring nuevo, mínimo y contenido**: `config.relations.drivers` (mapa clave→factory de `RelationsDriver`,
  añadido opcional a `defineConfig`; tipo `RelationsDriverFactory` en `types.ts`). El comando resuelve
  `from`/`to` de ese mapa (la factory del driver `openfga` entra por el subpath `/openfga` DENTRO de ella,
  como la de roles), lee la config PERSISTIDA del destino (`readRelationsConfig`) para vigilar `modelDrift` en
  `--dry-run`, y llama a `reconcileRelations`. **El comando NUNCA importa el SDK** (`check:purity` verde): no
  toca ni `@openfga/sdk` ni el driver openfga; los construye la factory del consumidor.

## Qué dice el README del PRESUPUESTO COMPARTIDO (§Relations (ReBAC) (2.4), nueva)

Honesto y con los números medidos: el modelo de 262.144 B lleva **permisos Y tipos de objeto** en UN
presupuesto; **~450 permisos** realistas de techo y **~0,46 permisos por tipo de objeto** (`group` ≈ 0,1),
así que un catálogo pegado al techo tiene sitio para ~20 tipos, no ilimitados; el gate del modelo FUSIONADO
lo vigila (500 antes de publicar, 80 % avisa). Además: la **partición obligatoria**; la **frontera
roles↔relations cerrada por construcción** (⚪4 + F-05, chokepoint, y el contrato planta el exploit para que
un driver de terceros que no lo cumpla NO pase); **`membersOf` es solo `database`** (en `openfga` 500); la
**config persistida** + republish sin mutilar el modelo (CAS, 409 si no cede); y el comando de reconcile. La
entrada del **CHANGELOG 2.4** sigue el estilo del paquete (problema → decisión → qué NO se hace y por qué; el
🔴 cerrado por construcción; R-15 diferida; el gap ~41→39 explicado).

## Ficheros

Nuevos: `commands/authz_relations_reconcile.ts`, `tests/relations_design_cases.spec.ts`,
`tests/relations_reconcile_cli.spec.ts`. Tocados: `src/types.ts` (`RelationsDriverFactory`),
`src/define_config.ts` (`relations.drivers`), `src/testing/relations_contract.ts` (guard de registro),
`commands/main.ts`, `tests/relations_harness.spec.ts`, `README.md`, `CHANGELOG.md`.

## Lo que la Fase 4 deja ABIERTO/DECLARADO (para la revisión de fase: tester + auditor + code-review)

1. **R-15 (caducidad de relación) DIFERIDA a 2.6** — micro-lote aditivo (`expires_at` en `authz_relations` +
   el `BEFORE UPDATE` del trigger ya existe). Con ella entra el caso «renovar = delete+insert». Es el gap
   ~41→39 del conteo, declarado.
2. **`includes` con `from` (herencia cross-objeto, `viewer from parent`) DIFERIDO a 2.6+** — mete un TTU entre
   tipos de objeto y OBLIGA a re-medir profundidad (hoy includes + un nivel de userset = 2–4 saltos fijos, y
   `can_<P>` sigue en 22). Escrito en README/CHANGELOG.
3. **`{trx}` en `relate`/`unrelate` DIFERIDO (paridad con roles, 2.6+)** — el `database` usa `{trx}` interna
   (trigger+insert), no la expone en el puerto.
4. **F-05 es un CHOKEPOINT (riesgo vivo, §8 del juez)** — el cierre del 🔴 depende de que TODO camino de
   escritura embude por el manager. Un método futuro (relate en lote, escritura de reconcile de relaciones que
   salte el manager) reabre la escalada. Mitigado por el caso-exploit publicado en el contrato; superficie a
   vigilar en cada lote posterior. **Nota para el auditor:** `reconcileRelations` (4-5) escribe con
   `to.relate(...)` sobre el DRIVER directo, NO por el `RelationsManager` — es una migración de plataforma
   entre drivers YA validados y la config del destino declara los tipos (si no, `modelDrift`), pero es un
   camino de escritura que no pasa por F-05; conviene que la revisión lo confirme aceptable (el origen solo
   produce tipos declarados; un origen envenenado con `role_binding` no puede existir porque el otro driver
   también aplica F-05 al escribir).
5. **Store COMPARTIDO = ciclo de vida de modelo compartido** — la carrera `defineRelationsConfig`↔
   `syncAuthzCatalog` (4-5) y el republish-sin-config (🟡3) viven porque el store es uno; el escape (store
   separado) queda documentado para el caso extremo «>20 tipos Y pegado al techo».
6. **`openfga` no tiene trigger de partición** — F-05 + la comparación de string son la ÚNICA defensa de
   tenant; el trigger de `database` es defensa en profundidad para el escritor «a mano».
7. **El wiring de `config.relations.drivers` es NUEVO y mínimo** — solo lo consume `authz:relations:reconcile`.
   El `RelationsManager` de servicio (un singleton de relaciones en `services/main`, análogo al de roles) NO
   se cableó: el consumidor construye el manager de relaciones a mano con `defineRelationsConfig`. Si la
   revisión de fase quiere un singleton de plataforma para relaciones, es aditivo y no rompe nada de esto.
8. **Lag del relay para relaciones** — la partición se corta por string sin `scopeOf`; hereda la ventana del
   relay del árbol como el resto de `facts`. No es nuevo; documentado.

## Cierre

Nada del plan resultó imposible ni contradijo el código. La única desviación de FORMA (no de fondo) del
encargo: el juez pedía el conteo literal «como el harness de roles fija core/2.0/2.1/2.2»; relaciones NO tiene
niveles (runner separado, sin `ContractLevel`), así que el literal por «nivel» se sustituye por el literal del
RUNNER (17, con su cara por capacidad) + el del RECONCILE (9) + el conteo del JUEZ (~41) aterrizado como
39 existentes + 2 diferidos. Es lo que el propio encargo autorizaba («o `relations_harness.spec.ts` o como
encaje»; «si no llegan a ~41, di cuáles faltan y justifica»). Los cinco modos verdes, aditivos sobre 4-5.
La Fase 4 queda lista para la revisión de fase (tester + auditor + `/code-review`).
