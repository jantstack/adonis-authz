# `2.4.0-alpha.10`: re-ataque del auditor sobre el lote sin commitear (base `7fbc638`)

## Veredicto en una línea

**APTA con cambios.** No hay 🔴. Hay un 🟠 de gemelo en relaciones, y es sobre todo de documentación: la vía «from code» que recomienda el README llega a la dirección rancia sin guard y sin freeze. Hay además cuatro 🟡 (dos con repro). El cierre estructural en `manager.reconcile` aguanta.

Repro: `.claude/reproducciones/alpha10-reataque.spec.ts`. Tiene runner propio para no tocar `tests/`, que otra corrida está usando:
`env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec .claude/reproducciones/alpha10-run.ts`.
Resultado sobre el árbol actual (SQLite `:memory:`): **4/4 VERDES = los 4 defectos presentes**. Para comprobar que el spec sabe fallar, invertí dos aserciones (R2 y R4a) y salieron ROJAS. Luego restauré el fichero.

---

## Hallazgos (ordenados por severidad)

### 🟠 R1: `reconcileRelations({ partitions })` es la vía que el README recomienda para K particiones y no pasa por el guard ni por el freeze

- **Escenario**
  - Precondición: tras el cutover, el driver de relaciones activo es `openfga` (`relations.default ?? default`). `database` sigue congelada con una compartición que ya se retiró (`u-old`), y el store tiene otra creada después (`u-new`).
  - Acción: un consumidor multi-tenant (COGNITIV lo es) sigue el README (`:656`: «from code, `reconcileRelations({ partitions: [...] })` migrates several in one pass») y ejecuta su bucle `reconcileRelations({ from: database, to: openfga, partitions, prune: true })`.
  - Resultado: `document:d1#viewer@user:u-old` resucita en el activo y `u-new` se borra. No hay `staleSource`, no hay `frozen` y la flota sigue escribiendo durante la pasada.
- **Evidencia**: ✅
  - `index.ts:182` exporta el primitivo desde la raíz.
  - `README.md:656` y `:675` lo recomiendan sin decir que va sin guard ni ventana.
  - `commands/authz_relations_reconcile.ts:51-75` pone el guard solo en `runRelationsReconcile`.
  - Repro R1 verde. Su control demuestra que `runRelationsReconcile` con las mismas opciones (y `partitions`) sí la niega.
- **Steelman del defensor**: «`reconcileRelations` es el primitivo y no puede ver el config (regla 2 de pureza). Su puerta es `runRelationsReconcile`, y así figura en la tabla de gemelos».
  - No me convence. El README público no dice eso: presenta el primitivo como la forma de migrar varias particiones desde código. La tabla A7 lo despacha con «documentado en el README», y lo documentado es justo lo contrario. Además, «nada conocido en los dos puertos» (fila 4 del linaje) es falso para la vía documentada. La severidad no llega a 🔴 porque hace falta que el consumidor escriba el bucle hacia el activo después del cutover, que es la misma precondición del 🔴 4 de COGNITIV, pero por otra puerta.
- **Mitigación mínima**: en README y JSDoc, `runRelationsReconcile(authorization, { partitions, toKey, fromKey })` pasa a ser la vía «from code» (ya acepta `partitions`). `reconcileRelations` se marca como primitivo **sin guard de dirección y sin ventana durable**, con un caso de letra. Opcional: sacarlo de la raíz en 2.5.

### 🟡 R2: S2 es check-then-act fuera del `UPDATE` atómico, así que una ventana de operador que vence entre la comprobación y el `acquire` se pisa sin 503

- **Escenario**
  - Precondición: ventana de operador abierta con `--lease-ms` que vence en T.
  - Acción: `freeze()` (lo usan `authz:freeze`, `withFrozenWrites` sin `operatorAsContext`, o una pasada cuya `freezeStatus()` ya la vio caducada) lee `lastFreezeStatus()` en T−1 (viva, pasa la comprobación) y `acquireFreeze` corre en T+1 (vencida, la toma).
  - Resultado: la fila del operador queda sustituida por `reconcile:…`. Al soltar, `lastFreezeStatus()` devuelve `null`: el rastro que S2 debía preservar desaparece. No hay `E_AUTHZ_OPERATOR_WINDOW_EXPIRED` y la salida es de éxito.
- **Evidencia**: ✅
  - `src/manager.ts:642-653`: la comprobación con `#wallMs()`.
  - `src/manager.ts:656-660`: segundo `#wallMs()` y `acquireFreeze`.
  - `src/freeze.ts:206-210`: el `WHERE` toma cualquier fila con el lease vencido, sin mirar el `kind`.
  - Repro R2 verde, determinista con un reloj de dos lecturas.
- **Steelman del defensor**: «la ventana real dura lo que un `SELECT`, del orden de milisegundos; y las dos reconcile adoptan la ventana viva por `freezeStatus()`, no pasan por aquí».
  - Me convence para bajarlo a 🟡: con reloj real el hueco es la latencia de una consulta. Aun así, el paquete presume de «condicional y atómico» (CLAUDE.md, `acquireFreeze`), y esta invariante nueva vive fuera del atómico.
- **Mitigación mínima**: llevar la condición al `WHERE` de `acquireFreeze` (en la rama «vencida», excluir `freeze_holder LIKE 'operator:%'`) y releer la fila solo para redactar el 503.

### 🟡 R3: el gemelo de S6 en `--dry-run` sigue diciendo «La outbox del árbol está vacía» en verde con `--only`

- **Escenario**
  - Precondición: cola vacía o id con errata.
  - Acción: `authz:scopes:relay --dry-run --only=999`.
  - Resultado: `[success] La outbox del árbol está vacía: nada que propagar.` con exit 0, sin nombrar `#999`, aunque el manager devuelve `missing: [999]`.
- **Evidencia**: ✅ `commands/authz_scopes_relay.ts:222-226`: la rama `dryRun` retorna antes del bloque S6 (`:275-294`) y no imprime `missing`. Repro R3 verde por el kernel real, con el manager real, sin reporte fabricado.
- **Steelman del defensor**: «S6 trataba de la pasada que aplica, y `--dry-run` bajo freeze (S4) es del lote siguiente».
  - Me convence a medias. El CHANGELOG y el informe dicen «jamás "La outbox del árbol está vacía" con `--only`», sin excepción. Fuera de un freeze esta rama se ejecuta hoy.
- **Mitigación mínima**: en la rama `dryRun`, con `only`, imprimir los `missing` y no decir «vacía». Si esto se aplaza, que el CHANGELOG lo diga.

### 🟡 R4: `runRelationsReconcile` juzga ETIQUETAS del llamante, no el origen resuelto

- **Escenario**
  - Precondición: `openfga` es el activo según el manager.
  - Acción:
    - (a) un bucle que pasa `toKey: 'openfga', fromKey: 'openfga'` (copiar y pegar) con `from: database`;
    - (b) uno que pasa `activeKey: 'database'` explícito.
  - Resultado: en los dos casos la compartición retirada se escribe en el activo.
- **Evidencia**: ✅
  - `commands/authz_relations_reconcile.ts:36`: `activeKey?` sobrescribible.
  - `:58-59`: `stale` sobre cadenas.
  - `:51`: solo se exige que sean strings.
  - No se contrasta `fromKey` con `options.from` ni `activeKey` con `authorization.relationsDriverKey()`. Repro R4 verde.
- **Steelman del defensor**: «el comando las deriva de las mismas claves que resuelven los drivers, así que en ace no hay forma de desalinearlas; la función es API de plataforma».
  - Me convence para 🟡. Pero el informe vende que el guard «mira el ORIGEN RESUELTO»: en roles es cierto, porque el manager resuelve instancias desde claves; en relaciones es una declaración del llamante. El gemelo no es exacto.
- **Mitigación mínima**:
  - Quitar `activeKey` de la firma pública, o lanzar un 500 si difiere de `relationsDriverKey()`.
  - Aceptar `fromKey === toKey` solo si `options.from === options.to`.

### 🟡 R5: el guard de roles confía en el `config.default` del PROCESO que ejecuta el comando, no en el de la flota (límite no declarado)

- **Escenario**
  - Precondición: `default: env.get('AUTHZ_DRIVER', 'database')`. La flota sirve desde `openfga` y el Job o pod de migración arranca sin esa variable.
  - Acción: `authz:reconcile --to=openfga --from=database`.
  - Resultado: `to !== config.default` en ESE proceso, así que no hay guard. Es el 🔴 4 original, que vuelve con el guard apagado en silencio.
- **Evidencia**: 🟡 razonamiento sobre `src/manager.ts:2064-2065`; no hay estado durable del «driver activo». Sin repro: el defecto está en el entorno, no en el código, y el repro sería tautológico.
- **Steelman del defensor**: «el paquete no puede saber qué sirve la flota; el `default` del config es la única fuente».
  - Cierto. Pero entonces el README y el CHANGELOG deberían decir que el guard es tan fiable como el `config.default` del proceso que corre el comando. Hoy dicen «towards the ACTIVE driver».
- **Mitigación mínima**: una frase en el README («the guard reads `config.default` of the process running the command; run it with the fleet's config»). Opcional para 2.5: sellar el driver activo en la fila `id=2`, o en una hermana, al cambiar de `default`.

### ⚪ Higiene y letra

1. **Receta del README que ahora se niega sin avisar**. `README.md:1101`: «`authz:reconcile --to=openfga --from=database --prune` rebuilds the store … because the store you are rebuilding **may already be the live one**». Con `openfga` activo, esa receta es ahora el 500 `E_AUTHZ_STALE_SOURCE_REFUSED`, y el párrafo no menciona `--allow-stale-source` ni el porqué.
2. **«verify» del runbook** (`README.md:1083`). La verificación natural después del switch, dentro de la MISMA ventana de operador viva (`--to=openfga --from=database --dry-run`), no es rancia: nadie escribió desde la migración. Aun así sale como deriva y exit 1. Un falso positivo en el paso más visible del cutover acostumbra al operador a `--allow-stale-source`. Ver pregunta 2.
3. **Docblock huérfano en `src/errors.ts`**. `:809-825` quedó encima del docblock de `OperatorWindowExpiredError` (`:826-835`), y `StaleSourceRefusedError` (`:841`) quedó sin docblock.
4. **Letras de `authz:unfreeze` bajo carrera**.
   - En la rama `expired` (`commands/authz_unfreeze.ts:105`) se ignora el booleano de `unfreeze()`: si otro tomó la fila entre medias, el mensaje afirma «La fila queda limpia» y no es verdad.
   - `:121` dice «o venció su lease» con éxito y exit 0, lo que contradice la regla nueva de «caducada ⇒ error». Además, vencer no produce `!lifted`, porque `releaseFreeze` no mira `untilMs`.
5. **Fila con `freeze_reason` puesto y `holder` NULL** (solo a mano o en datos legados). `lastFreezeStatus` devuelve `holder: '?'`, `unfreeze({holder:'?'})` no casa y el aviso `expired` se repite para siempre con exit 1. No tiene salida por el comando.
6. **CHANGELOG (🟠 S2)**: «expired **(or lifted early)**». La variante «levantada antes de tiempo» no la cubre `freeze()` (motivo NULL); solo la cubre la línea «PROPIA». La frase sugiere más de lo que hay.
7. **Rupturas menores sin nombrar en el CHANGELOG**:
   - `unfreezePlan` (exportada por `./commands/*`) gana `'expired'` en su unión y un tercer parámetro.
   - `report.frozen` gana `window`/`untilMs` en los dos puertos: rompe a quien compare con `deepEqual` (este paquete tuvo que tocar su propio caso).
   - `withFrozenWrites`/`freeze()` pueden lanzar un 503 nuevo, además del 423.
8. **Mensaje engañoso con un solo driver**. Con `default: 'database'` y solo `database` registrado, `authz:reconcile --to=database` cambia de `E_AUTHZ_UNSUPPORTED` («no hay origen») a `E_AUTHZ_STALE_SOURCE_REFUSED`, cuyo texto habla de un origen «por descarte» que no existe. Sigue siendo una negativa, pero la letra engaña.

---

## Gemelos revisados

| Pieza | Gemelo | Resultado |
|---|---|---|
| 1 · origen rancio | `manager.reconcile` (API) | ✅ resiste. El guard usa el mismo `#isMaintenancePass` que `#factsOrigin` (`manager.ts:2064`, `:2248`), va antes de `#factsOrigin` y de congelar, y `from === to` sigue siendo 500 CONFIG. |
| | vista `forRequest()` | resiste: comparte config y raíz. |
| | `authz:reconcile` | ✅ el 500 sale como error con exit 1 (`authz_reconcile.ts:157-165`); `--dry-run` marca y es deriva. |
| | `runRelationsReconcile` | 🟡 R4: etiquetas en vez de instancias; `activeKey` sobrescribible. |
| | `authz:relations:reconcile` | ✅ claves derivadas de las mismas que resuelven los drivers; `activeKey` sale del mismo `config`. |
| | **`reconcileRelations` (raíz, recomendado por el README)** | **🟠 R1** |
| | `runMigrationContract` | aceptable: `allowStaleSource: true` es explícito y el harness lo documenta; breaking declarado. |
| | `runRelationsReconcileContract` | primitivo a pelo en un harness de test: aceptable. |
| | `manager.driver().reconcile` | salida documentada. |
| | relay / `requeue --apply` | no eligen origen: no aplica. |
| 2 · unfreeze caducada | `authz:unfreeze` | ✅ salvo las letras bajo carrera (⚪ 4) y `holder` NULL (⚪ 5). |
| | `manager.unfreeze(token)` | limpia una fila caducada: `releaseFreeze` no exige vigencia (`freeze.ts:262-281`). No hay deadlock. |
| | `freezeStatus()` / barrera | sin cambios: caducada = no congelada. |
| S2 · ventana pisada | `freeze()` | 🟡 R2 (TOCTOU). |
| | `#durableFreezeContext` con operador | resiste: `freezeStatus()` viva ⇒ adopta; caducada ⇒ `freeze()` ⇒ 503. |
| | `authz:freeze` | ✅ 503 como error con exit 1. |
| 3 · lease adoptado | reportes y líneas de roles y relaciones | ✅ `leaseMs = max(0, untilMs − now)` ≥ 1 al adoptar, porque viva exige `untilMs > now`. |
| 4 · letra de mantenimiento | comando, README, docblocks | ✅ coherente con `openfga_driver` (sin `--prune` solo borra lo que prohíbe el invariante 18). |
| 5 · app + uuid | comando (`:388`) y `partitionsOf` (API, las dos formas) | ✅ |
| S5–S7 · relay | pasada que aplica | ✅ |
| | `--dry-run` con `--only` | 🟡 R3 |
| | `--max-age` | ✅ se valida antes; `NaN` también se rechaza. |
| | `requeue --apply` | no dice «vacía»: no aplica. |

## Regresiones de cierre (tests invertidos)

- **`tests/reconcile.spec.ts` «🔴 2»**: la inversión es **correcta**. El caso migraba con el manager que ya servía desde `openfga`, que es la dirección rancia. Ahora afirma el 500, con y sin `--prune`, sin tocar el store y sin congelar, y hace la migración legítima con `default: 'database'` sobre el mismo backend. No esconde nada.
- **`tests/freeze.spec.ts:~300`**: la inversión es **correcta**. El fixture `pasada` tenía `untilMs: 99` (1970) y se trataba como viva. Ahora `unfreezePlan` decide por `expired` explícito y el fixture lleva un futuro real. Un matiz: `unfreezePlan` ya no deriva la caducidad de `untilMs`, así que un llamante que le pase `freezeStatus()` sin `expired` obtiene «viva». Es aceptable porque solo el comando la llama, con `lastFreezeStatus()`.
- `freeze.spec` en relaciones: el `deepEqual(report.frozen)` añade `window: 'own'`. Es el efecto esperado, pero rompe a quien compare igual fuera del paquete (⚪ 7).

## Lo que intenté y NO se rompió

- **Roles**:
  - `from === to` hacia el activo sigue en 500 CONFIG.
  - `--from` inexistente hacia el activo da 500 STALE (solo cambia el orden del error).
  - Origen elegido por descarte con `database` activo: negado.
  - `authz_*` hacia un activo `facts` con `--from` y sin él: negado.
  - Cutover inicial y vuelta atrás antes de cambiar `default`: pasan.
  - `relations.default` distinto del `default` de roles: cada puerto usa el suyo.
  - Relaciones sin `relations`: `activeRelationsDriverKey` cae a `default`.
- **Freeze**:
  - Una fila caducada de PASADA se toma encima (lease tras SIGKILL).
  - `unfreeze` de una fila caducada contra una pasada que la tome a la vez: el `fence + 1` de `acquireFreeze` hace no-op el `releaseFreeze` rezagado, así que no se levanta la ventana nueva.
  - No hay deadlock de escrituras: una ventana caducada no bloquea la barrera; solo bloquea nuevos `freeze()` hasta que se reconoce, y lo limpian tanto `authz:unfreeze` como `manager.unfreeze(token)`.
- **Falsificar operador frente a pasada**: el `kind` sale del prefijo del holder, que solo escribe `freeze()` con `options.kind`. Es API de plataforma, no entrada de usuario.
- **Banderas**: `--allow-stale-source` sin `name:` en los dos comandos (la regla de alpha.9 se respeta).
- **Salidas**: cada 500 y 503 nuevo se imprime como error con exit 1 en `authz:reconcile`, `authz:relations:reconcile` y `authz:freeze`.

## Preguntas abiertas para el arquitecto

1. **R1**: ¿se documenta `runRelationsReconcile({ partitions })` como la vía de código y `reconcileRelations` como primitivo sin guard ni ventana, o se saca el primitivo de la raíz? Mientras el README lo recomiende, «cerrado en los dos puertos» no es cierto.
2. **⚪ 2**: ¿debe el guard aceptar `--from=<viejo>` hacia el activo cuando la pasada corre dentro de una ventana de operador **viva** abierta antes del switch (la verificación posterior al switch)? Si no, el runbook tiene que decir qué verificación usar en ese paso, para no normalizar `--allow-stale-source`.
3. **R5**: ¿basta con declarar que el guard lee el `config.default` del proceso, o se quiere un sello durable del driver activo en 2.5?
