# Panel 3 · Auditor de seguridad (adversarial) — `freeze()` de proceso vs. opciones A/B/C/D

**Fecha:** 2026-08-31 · **Worktree:** solo lectura en `2507f45` · **Motores:** OpenFGA real
`:8101`, `postgres18`, `mysql84` (bases `auditor3_*`, borradas; 0 stores residuales).
**Encargo:** romper las cuatro opciones. No escribo veredicto final: eso es del juez.

## Veredicto en una línea

**D es la peor de las cuatro** —es la única que produce un **falso verde** sobre una pérdida de
permisos, medido en las dos direcciones y en los dos motores—; **A** compra menos de lo que promete
y a cambio de un fail-closed de flota con tres agujeros documentados; **B** es honesto y no empeora
nada; y **ninguna de las cuatro cubre el intervalo que de verdad importa** (última pasada → cutover).

---

## 1 · ¿Abierto o cerrado? La clasificación que pediste

| Opción | Cómo falla | Qué se rompe cuando falla | Ruido/señal |
|---|---|---|---|
| **A · freeze durable** | **Cerrado** en el caso común (freeze pegado ⇒ la flota no escribe; la tx del consumidor aborta) · **ABIERTO en las esquinas**: `unfreeze()` sin dueño, TTL vencido, fila cacheada, y tres caminos que no cubre | Disponibilidad; y en las esquinas, escrituras que aterrizan **bajo una promesa fuerte** | Silencio: nadie mira, porque el README dice que está cubierto |
| **B · quitar la promesa** | **Abierto**, siempre, exactamente como hoy | Un `revoke` de la ventana se deshace | Silencio, pero **sin falsa garantía** |
| **C · las dos** | Hereda el fail-closed de A **y** sus esquinas abiertas | Igual que A | Peor: dos frases que se contradicen; en la práctica gana la fuerte |
| **D · B + detección a posteriori** | **Abierto Y EN VERDE** (medido) | Un `revoke` de la ventana de la **pasada 2** se pierde *y la pasada 2 lo certifica limpio* | **Falsa garantía activa**: es el peor modo de fallo de los cuatro |

Regla que aplico: un panel que dice «limpio» sobre un permiso revocado que sigue vivo es peor que
un panel que no dice nada. B no dice nada. D dice que sí.

---

## Hallazgos (ordenados por severidad)

### 🔴 1 · D certifica en VERDE una pérdida: el `revoke` que cae en la ventana de la **segunda** pasada

- **Escenario:**
  *Precondición*: migración `authz:reconcile --to=database --from=openfga`; el motor sigue sirviendo
  con `openfga`, así que los workers escriben en el ORIGEN. Pasada 1 corre **sin concurrencia**:
  limpia de verdad.
  *Acción*: el operador hace lo que D le pide —una segunda pasada `--dry-run` para demostrar que la
  primera fue limpia—. Durante **esa** pasada, un admin revoca un rol desde el worker web (otro
  proceso, `web.frozen=false`).
  *Resultado medido*: la pasada 2 sale **`written=0 updated=0 extra=0 deleted=0 skipped={} clean=true`**
  —limpia por el criterio del coordinador **y** por el criterio fuerte (`reconcileLines().clean`)—
  mientras el store ya **no** concede y la base **sí**. El operador corta el cutover con el verde en
  la mano y el usuario conserva el rol revocado.

```
=== D1.c — pasada 1 LIMPIA; el `revoke` cae en la ventana de la PASADA 2 ===   (PostgreSQL)
  pasada 1 (sin concurrencia)     written=2 ... skipped={} clean=true
  el worker revoca DURANTE la pasada 2 (200)                       aceptado
  pasada 2 --dry-run              written=0 updated=0 unchanged=2 extra=0 deleted=0 skipped={} clean=true
  store (origen) concede                                           false
  base (destino, la que quedará activa) concede                    true
  pasada 3 --dry-run              written=0 ... extra=1 skipped={"extra-fact":1} clean=false
```

  Idéntico en **MySQL** (mismos números) e idéntico en la dirección contraria
  (`--to=openfga`, D2.b): `unchanged=21, extra=0, skipped={}, clean=true` con el store concediendo
  lo que `authz_*` ya no respalda.

- **Evidencia:** ✅ medido — `repro3/d1_segunda_pasada.ts` (D1.c) y `repro3/d2_ida.ts` (D2.b), PG y
  MySQL, OpenFGA real.
- **El argumento lógico detrás del número:** la pasada 2 tiene **exactamente la misma ventana** que
  la pasada 1 (lee el origen entero, luego el destino entero, sin atomicidad entre ambas). Así que
  *«la pasada 2 demuestra que la 1 fue limpia» solo vale si nadie escribió durante la pasada 2* — y
  si el operador puede garantizar eso, ya podía garantizarlo en la pasada 1 y D sobra. **D tiene
  regresión infinita**: cada pasada testigo necesita otra pasada testigo.
- **Steelman del defensor:** *«La pasada 2 es corta y la probabilidad de que caiga justo ahí es
  baja; además una tercera pasada lo vería.»* → **No me convence.** (a) La pasada 2 no es corta: es
  O(store) —vuelca el destino ENTERO en memoria, cota declarada 1 000 000 de tuplas— y dura lo mismo
  que la 1, que es la ventana que estamos intentando cerrar; (b) la probabilidad no es baja
  precisamente durante una migración, que es cuando la plataforma avisa a los admins de que «va a
  haber cambios» y la actividad administrativa sube; (c) «una tercera pasada lo vería» es el mismo
  argumento, corrido una posición: no hay pasada final.
- **Mitigación mínima:** D no puede apoyarse en un diff de estado; si se quiere detección, tiene que
  ser sobre un **log de intervalo** (ver §5), no sobre una foto.

---

### 🔴 2 · El criterio literal de D («segunda pasada que escribe **cero**») no ve NINGÚN revoke

- **Escenario:** *Precondición*: la de siempre. *Acción*: durante la pasada 1, un `revoke` desde el
  worker. *Resultado medido*: la pasada 2 sale con **`written=0`** — el criterio que el coordinador
  enunció literalmente— y sin embargo hay 1 (vuelta) / 3 (ida) tuplas de más en el destino:

```
D1.a (--to=database)  pasada 2 --dry-run  written=0 ... extra=1 skipped={"extra-fact":1} clean=false
                      criterio del coordinador (written === 0)  →  LIMPIA ⇒ «nadie escribió»
D2.a (--to=openfga)   pasada 2 --dry-run  written=0 ... extra=3 skipped={"extra-fact":3} clean=false
```

  Un `revoke` **nunca** produce `written` en la pasada siguiente: produce `extra`. El contador que D
  mira es justo el que la operación peligrosa no toca. (Un `grant` perdido sí sale como `written=1`
  — D1.b —, o sea que D detecta bien lo que **concede** y es ciego a lo que **retira**: exactamente
  al revés de lo que este paquete existe para proteger.)
- **Evidencia:** ✅ medido, `repro3/d1_segunda_pasada.ts` (D1.a/D1.b) y `repro3/d2_ida.ts` (D2.a),
  PG y MySQL.
- **Steelman:** *«Obviamente el criterio real es `clean`, no `written`; era una forma de hablar.»* →
  **Me convence a medias.** Con `clean` la detección de este caso concreto sí funciona (`extra-fact`
  ⇒ `skipped` no vacío ⇒ `clean=false` ⇒ exit≠0). Pero entonces (a) sigue en pie el 🔴 1, que rompe
  también el criterio fuerte; y (b) `clean` es un criterio **ruidoso por construcción**: una
  asignación que caduca entre las dos pasadas produce `skipped{expired}`, un scope que el tenant
  borró produce `skipped{unknown-scope}`, un rol retirado produce `skipped{unknown-role}` — todos sin
  ninguna concurrencia. En un despliegue vivo la pasada 2 sale roja **casi siempre**, y una señal que
  siempre está roja no es una señal. Si D se adopta, el criterio hay que escribirlo **exacto** en el
  README y hay que decir qué motivos de `skipped` invalidan la prueba y cuáles no.
- **Mitigación mínima:** si D sobrevive, el criterio es `clean === true` **y** `extra === 0`, y hay
  que documentar que `skipped{expired|unknown-scope|unknown-role}` **no** invalida la prueba (o el
  operador aprenderá a ignorar el rojo, que es peor).

---

### 🔴 3 · La ventana no pierde «una escritura»: aplica MEDIA transacción y **fabrica** un permiso que nadie concedió

*(Este es el estado de HOY. Lo hereda B, lo hereda D —que solo lo detectaría en una pasada
posterior—, y es el único argumento serio a favor de A.)*

- **Escenario:**
  *Precondición*: `authz:reconcile --to=openfga`. El origen se lee en **DOS barridos separados**:
  `authz_assignments` primero (`openfga_driver.ts:2648`) y `authz_denies` después (`:2701`), con un
  hueco arbitrariamente largo entre ambos. Zoe tiene el rol `org-editor` **y** un deny explícito de
  `docs:write`: hoy no puede escribir.
  *Acción*: durante ese hueco, RR.HH. hace el offboarding completo desde la app —`revoke(zoe,
  org-editor)` + `removeDeny(zoe, docs:write)`, dos escrituras de una misma operación de negocio—.
  *Resultado medido*:

```
  ANTES · database: zoe docs:write@org                             false
  el worker hace el offboarding completo (200 + 200)               aceptado
  pasada 1     written=13 extra=0 deleted=0 skipped={} clean=true
  DESPUÉS · database (origen): zoe docs:write@org                  false
  DESPUÉS · store (destino):   zoe docs:write@org                  TRUE
  DESPUÉS · store (destino):   zoe docs:read@org                   TRUE
```

  El destino se queda con el **rol sin su deny**: concede `docs:write`, que **ni el estado de antes
  ni el de después** concedían. La migración no perdió un permiso: **inventó uno**. Y el reporte de
  la pasada dice `clean=true, skipped={}` — cero señal.
- **Evidencia:** ✅ medido, `repro3/d3_mitad_de_transaccion.ts` (OpenFGA real + PG).
- **Por qué importa para la decisión:** cambia la naturaleza del riesgo. «Un revoke de la ventana se
  deshace» suena a *deriva recuperable*; «la pasada compone dos mitades de operaciones distintas y
  produce un estado que nunca existió» es una **escalada**. Además desmonta el consuelo de D: la
  pasada 1 sale VERDE, así que el operador no tiene ningún motivo para correr la pasada 2 antes del
  cutover. D solo ayuda a quien ya desconfía de un verde.
- **Steelman:** *«Es una carrera estrecha: hay que caer justo entre los dos barridos.»* → **No me
  convence.** El hueco entre barridos no es «estrecho»: es el tiempo de pasear `authz_assignments`
  entera por lotes de 100 con cursor sobre `uuid` — segundos o minutos en una base real. Y el número
  de operaciones compuestas (revoke+removeDeny, grant+deny, mover y reasignar) en una plataforma
  multi-tenant no es marginal.
- **Mitigación mínima:** leer el origen en UNA foto consistente (una transacción de repetible
  lectura para los dos barridos en `--to=openfga`) — barato, local, y no necesita coordinación entre
  procesos. **Esto no lo arregla ninguna de las cuatro opciones.**

---

### 🟠 4 · A, atacada: el freeze **no tiene dueño**, así que cualquiera lo levanta — y con A eso es fail-open de FLOTA

- **Escenario:** `freeze()`/`unfreeze()` son un `string | null` sin token de propietario
  (`manager.ts:391-404`). Medido en el proceso actual:

```
A1.1  freeze anidado: ¿sigue congelado el de FUERA tras terminar el de dentro?   false
A1.2  dos operaciones concurrentes: escritura a mitad de la migración larga      ACEPTADA
      llamadas que llegaron al driver                                            ["grant"]
A1.3  reconcile del destino corriendo; manager.frozen                            false
      tras el reconcile de dentro, m2.frozen                                     false
A1.4  manager (raíz).frozen tras vista.freeze()                                  true
```

  A1.3 es el que duele: **`manager.reconcile()` llamado dentro de una ventana congelada la
  descongela al terminar** (su `withFrozenWrites` interno hace `unfreeze()` incondicional en el
  `finally`). Y `reconcile` **no** se congela a sí mismo —escribe por el driver, no por el manager—,
  así que **dos `authz:reconcile` simultáneos no se excluyen ni hoy ni con A**: el primero que
  termina levanta la barrera del otro. Con A, ese `unfreeze()` es una fila compartida: levanta la
  barrera de **todos los workers** mientras la migración larga sigue corriendo, y el README dice que
  no puede pasar.
- **Evidencia:** ✅ medido, `repro3/a1_freeze_sin_dueno.ts` (los cuatro casos).
- **Steelman:** *«La implementación durable llevaría un token de dueño y un `unfreeze` que solo
  levanta el suyo.»* → **Me convence como requisito, no como estado actual.** Pero entonces el
  diseño de A tiene que traer: token de propietario, `unfreeze` idempotente **por token**, y una
  respuesta a «¿qué pasa con el token del proceso que murió?» — que es el 🟠 6.
- **Mitigación mínima:** si se elige A, `freeze` devuelve un token y `unfreeze(token)` es la única
  firma; y `reconcile` toma además un **lease** (el patrón ya existe en `scope_outbox.acquire()`,
  `pg_try_advisory_xact_lock`/`GET_LOCK`) para que dos migraciones no se solapen.

---

### 🟠 5 · A, atacada: un freeze durable **no cubre** el catálogo, ni `driver()`, ni el árbol del consumidor

- **Escenario:** *Precondición*: motor congelado (`manager.freeze(...)`). *Acción*: (a)
  `syncAuthzCatalog(...)` quitándole `docs:write` a `org-editor`; (b) `(await manager.driver()).grant(...)`.
  *Resultado medido*:

```
A3.a  syncAuthzCatalog durante el freeze          no lanzó: el catálogo cambió CON el motor congelado
      authorize(ana, docs:write, org) tras el sync                false   (antes: true)
A3.b  driver().grant() durante el freeze          no lanzó: escritura ACEPTADA
      filas en authz_assignments                                 2
```

  El catálogo es **la otra mitad de una decisión**: quitarle un permiso a un rol retira acceso a
  todos sus holders, y el freeze no lo impide — ni lo impediría siendo durable, porque
  `syncAuthzCatalog` es una función libre que no ve al manager. Lo mismo `manager.driver()`, que el
  propio README documenta como «la salida explícita de las barreras del manager». Y el árbol de
  scopes del consumidor (sus tablas) cambia con su SQL, sin pasar por aquí.
- **Evidencia:** ✅ medido, `repro3/a3_agujeros.ts`; ✅ código (`manager.ts` `driver()`, `catalog.ts`
  sin barrera).
- **Steelman:** *«El freeze protege los HECHOS, que es lo que la pasada copia.»* → **No me
  convence del todo.** En `--to=openfga` la pasada copia **también** la proyección del catálogo
  (`phases.catalog`), leída en el paso 2 con una foto distinta de la del paso 4: un sync a mitad deja
  el destino con la proyección de una versión y los hechos filtrados por otra. A vendería «durante la
  migración nada cambia» y eso sería falso para el catálogo.
- **Mitigación mínima:** si se elige A, la frase del README tiene que enumerar **qué** congela y qué
  no, con esas tres excepciones por su nombre.

---

### 🟠 6 · A, atacada: ¿se puede dejar el freeze puesto? ¿se puede hacer que caduque a mitad? Sí a las dos, y el TTL solo mueve el problema

Las tres preguntas que pediste, respondidas:

1. **¿Se puede provocar que el freeze no se levante?** Sí, trivialmente: el `unfreeze()` vive en un
   `finally` de JavaScript (`manager.ts:411-417`). `SIGKILL`, OOM del contenedor, evicción del pod o
   un `process.exit()` del comando ace **no ejecutan `finally`**. Hoy eso es inocuo (el estado muere
   con el proceso); con A la fila queda puesta y **toda la flota deja de aceptar escrituras hasta que
   un humano la borre a mano**. Un fail-closed global provocado por matar un proceso batch.
   Verificado por semántica del lenguaje, ✅ código.
2. **¿Se puede provocar que caduque a mitad de una migración larga?** Con TTL, sí. La pasada es
   **O(store)** y su cota declarada es `DEFAULT_RECONCILE_MAX_TUPLES = 1_000_000` (`types.ts:642`),
   con el volcado del destino **entero en memoria** (`readEveryTuple(maxTuples)`). Medido en local:
   820 tuplas → 31 ms en `--dry-run` y 170 ms escribiendo; extrapolado linealmente al tope declarado,
   ~40 s de verificación y ~3,5 min de migración **con el servidor FGA en la misma máquina**. Con un
   FGA remoto y `--batch-size` bajo, minutos u horas. Un TTL por debajo de eso **levanta el freeze en
   silencio a mitad de la pasada** y devuelve exactamente el fail-open de hoy, ahora con el README
   prometiendo lo contrario.
3. **¿Un TTL arregla o mueve el problema?** Lo **mueve**, y lo empeora en un punto concreto: el
   renovador (heartbeat) corre en el **mismo event loop** que el volcado de hasta un millón de tuplas
   en memoria. Una pausa de GC o un `Read` lento se come la renovación mientras la pasada sigue viva
   ⇒ freeze caducado + migración en curso = el peor de los dos mundos. La renovación compite con el
   trabajo que protege.
4. **¿Quién dispara qué?** `freeze()` no está expuesto por HTTP y `AuthorizationView` no lo declara,
   así que **un tenant no puede congelar**. Ahora bien, el método **existe en runtime** en la vista
   (`typeof vista.freeze === 'function'`, y congela la RAÍZ — A1.4): cualquier código de aplicación
   con la vista en la mano, en JS o con un `as any`, congela el motor entero. Hoy eso es un proceso;
   con A es la flota. Y el radio de la **caducidad** sí es tenant-sensible: cuanto más escribe el
   tenant, más tarda la pasada, más cerca del TTL.
- **Steelman:** *«Un TTL de 30 min y un `authz:unfreeze` manual resuelven ambos extremos.»* → **No
  me convence:** un TTL de 30 min significa que un `kill -9` del comando de CI deja la plataforma sin
  escrituras media hora, y `authz:unfreeze` manual es una operación de emergencia que, por A1.3,
  cualquiera puede disparar sin saber que hay otra migración viva.

---

### 🟡 7 · A, atacada: congelado, `scopes.detached` deja **hechos huérfanos** (resurrección) y nadie reintenta

- **Escenario:** *Precondición*: freeze durable puesto; el consumidor borra un scope en el orden
  **soportado** «la fila ya no existe» (3F · S1: `detached` sin `within` no exige que el scope
  exista). *Acción*: `scopes.detached(unit)`. *Resultado medido*: `E_AUTHZ_FROZEN (503)`. Los hechos
  del scope muerto **se quedan en el backend**: si el uuid se restaura o se reutiliza, vuelven a
  conceder (la «resurrección» de 3b-0b · AA4). Y no hay quien reintente: la outbox es del **árbol**,
  no de los hechos.
- **Evidencia:** ✅ medido, `repro3/a2_coste_freeze.ts` (A2.b).
- **Steelman:** *«El consumidor debe notificar ANTES de borrar la fila; el 503 aborta su transacción
  y no pasa nada.»* → **Me convence para `attached`/`moved`, no para `detached`**, cuyo orden
  «después de borrar» está explícitamente soportado en el código y en el CHANGELOG. Para ese orden,
  A convierte un rechazo en divergencia permanente.

---

### 🟡 8 · A, atacada: el **verificador de CI** congela igual que la migración

- **Escenario:** `manager.reconcile()` envuelve en `withFrozenWrites` **siempre**, también con
  `dryRun: true` (`manager.ts:852`). El README pone `authz:reconcile --to=openfga --dry-run` en CI.
  Con A, ese comando —read-only por contrato— **congela las escrituras de toda la flota** durante lo
  que tarde en volcar los dos lados. Un job de CI mal apuntado a producción es un incidente de
  disponibilidad global.
- **Evidencia:** ✅ código (`manager.ts:852`) + ⏱ medido (`repro3/a2_coste_freeze.ts`: la pasada seca
  recorre el store entero).
- **Mitigación mínima:** si se elige A, `dryRun` **no** congela. Es gratis: no escribe nada.

---

### 🟡 9 · A, atacada: congelado, el relay no drena ⇒ la ventana de «árbol viejo» crece con la migración

- **Escenario:** `relayScopeChanges` está detrás del freeze (`manager.ts:652`). Medido:
  `authz:scopes:relay durante el freeze → E_AUTHZ_FROZEN (503)`, con la entrada del `moved`
  encolada sin aplicar. Mientras dura el freeze, el consumidor **sí** mueve sus filas (su SQL no
  pasa por aquí) y el backend sigue decidiendo con el **árbol viejo**: el tenant de origen conserva
  el acceso al subárbol movido durante toda la migración. Es un fail-open que **crece** con la
  duración del freeze — o sea, A alarga precisamente la ventana que el paquete ya documenta como su
  punto débil.
- **Evidencia:** ✅ medido, `repro3/a2_coste_freeze.ts` (A2.c).
- **Steelman:** *«Es la ventana del relay, ya documentada.»* → **Sí, pero A la multiplica**, y el
  reporte de la pasada la cuenta (`drift.pendingRelay`) **con las escrituras congeladas**, o sea que
  el número que sale es el de una cola que no puede drenarse: informativo, no accionable.

---

### 🟡 10 · B, atacada: «el operador para los escritores» y la bandera de reconocimiento

- **¿Qué pasa cuando no lo hace?** Exactamente los hallazgos 🔴 2 y 🔴 3 de este informe: pérdida
  silenciosa con `clean=true`, y media transacción aplicada. Es decir: **B no empeora nada respecto a
  hoy** (el comportamiento es idéntico), lo único que cambia es que el README deja de mentir.
- **¿Es peor o mejor que hoy?** **Mejor**, estrictamente: el riesgo es el mismo y la creencia del
  operador pasa a ser correcta. Es la única de las cuatro con coste cero y sin modo de fallo nuevo.
- **El ataque a la bandera:** una bandera de reconocimiento (`--accept-write-window` o similar)
  acaba **pegada al comando** en el runbook y en el job de CI el primer día, porque el verificador
  `--dry-run` la va a necesitar también (o si no la necesita, el operador copiará la línea de la
  migración desde el mismo sitio). A partir de ahí no reconoce nada: es ruido de línea de comandos.
  **Si se pone, que sea solo para la pasada que ESCRIBE y que el comando exija repetir a mano el
  nombre del driver destino** (patrón `--allow-mass-delete`, que ya existe y al menos nombra el
  peligro en su mensaje).
- **Evidencia:** ✅ medido (los mismos repros) + ✅ código (`commands/authz_reconcile.ts`).

---

### 🟡 11 · D, atacada: su remedio empuja al operador hacia `--prune`, que es la bandera del 🔴 2 de la auditoría final

- **Escenario:** D detecta el `revoke` perdido como `extra` + `skipped{extra-fact}` y sale con
  exit≠0. **El único remedio que el comando ofrece para `extra` es `--prune`** (`--prune`: «Also
  delete the facts the source no longer backs»; y para `unknown-scope` el propio reporte imprime
  «repite con `--prune`»). En la vuelta eso repara correctamente (medido: `deleted=1`). En la ida,
  `--prune` es exactamente la bandera que el hallazgo 🔴 2 de `fase-3b-auditor-final.md` demuestra
  que **borra los denies vivos** de un despliegue `facts` sin que el seguro de masa salte.
  D, al hacer roja una pasada que hoy sale verde, **aumenta la frecuencia con que un operador teclea
  `--prune`**.
- **Evidencia:** ✅ medido (`repro3/d2_ida.ts` D2.a: `extra-fact 3` → `--prune` → `deleted=3`) +
  hallazgo 🔴 2 de la auditoría final (ya reproducido allí).
- **Steelman:** *«Eso es un problema del 🔴 2, no de D.»* → **Cierto, pero es compositivo**: si el
  🔴 2 se arregla, esto desaparece; si no, D lo amplifica. El juez debe ordenarlos: **D no puede
  mergearse antes que la corrección del 🔴 2.**

---

### ⚪ 12 · C, atacada: dos frases contradictorias; gana la fuerte

C = A + B. El problema no es técnico sino de lectura: con un freeze durable puesto, la frase de B
(«para tus escritores o acepta el riesgo») **nadie la aplica**, porque el mecanismo fuerte existe.
Así que C tiene el perfil de riesgo de A —hallazgos 4 a 9— con el coste documental de B y sin la
detección de D. Su única ventaja real sobre A es que deja escrito el plan B para cuando el freeze
no cubra (catálogo, `driver()`, árbol). Si se elige C, **la frase de B tiene que estar en el mismo
párrafo que la de A y enumerar las tres excepciones**, o C es A con más texto.

---

## 2 · El agujero que comparten LAS CUATRO (y que nadie ha nombrado)

**La garantía no la necesita la migración: la necesita el CUTOVER.**

Congelar (A/C), documentar (B) o demostrar (D) el intervalo de la **pasada** no dice nada del
intervalo `[fin de la última pasada → cambio de `config.default`]`, que es **minutos u horas**, lo
decide un humano, y es donde todas las escrituras van al driver que está a punto de dejar de ser la
fuente de verdad. Medido implícitamente en D1.c/D2.b: la pérdida ocurre *después* de la última
prueba y *antes* del cutover, y ninguna de las cuatro opciones la mira.

Cualquiera de las cuatro que se apruebe sin decir algo sobre ese intervalo resuelve el problema
pequeño y deja el grande.

---

## 3 · La opción que ninguno habéis puesto: **E · el testigo de ventana (log de intervalo, no diff de estado)**

D falla porque compara **fotos**; una foto no sabe qué pasó entre dos fotos. La pregunta correcta
—«¿hubo alguna escritura entre t0 y t1?»— la contesta un **log append-only**, y **los dos orígenes
ya lo tienen o casi**:

- **OpenFGA: ya lo tiene.** `client.readChanges({ startTime })` devuelve el log de cambios con
  **DELETE incluido**. Medido (`repro3/e1_ventana_testigo.ts`):
  ```
  cambios desde t0 → TUPLE_OPERATION_DELETE:user:01a0…#assignee@role_binding:organization|…
  ```
  Es decir: en la dirección `--to=database`, `reconcile` puede sellar `t0` al empezar y, al terminar,
  preguntar al origen «¿cambió algo desde t0?». Si la respuesta es vacía, la pasada es **demostrable­mente**
  limpia — **sin segunda pasada, sin ventana propia y sin freeze**. Y si no lo es, el reporte puede
  nombrar **qué tupla exacta** cambió, no un contador agregado.
- **`authz_*`: lo tiene a medias, y la mitad que falta es barata.** `uuid` es **uuidv7** en
  `authz_assignments` y `authz_denies` (`database_driver.ts:683`, `:815`), o sea una marca de agua
  ordenada en el tiempo: medido, `where uuid > marca` detecta los INSERT de la ventana sin ninguna
  infraestructura nueva. Lo que **no** deja rastro es el DELETE (`revoke`/`removeDeny`): la fila se
  borra y no hay tombstone (columnas: `uuid, holder_type, holder_uuid, role_uuid, scope_type,
  scope_uuid, expires_at, created_at`). **El único trozo de estado nuevo que E necesita es un
  tombstone de revoke** — y eso es una fila que se escribe en la misma transacción que el borrado,
  no una barrera que todo el camino de escritura tiene que consultar (A) ni una promesa sobre un
  humano (B).

Comparado con las cuatro: E **detecta como D pero sin la ventana de D**, no bloquea nada (cero coste
de disponibilidad, a diferencia de A), no promete nada falso (a diferencia de C) y es honesto sobre
lo que no puede (a diferencia de D). Su punto débil: no impide, igual que D — pero a diferencia de D,
lo que afirma es **verdad**.

**E2 (complemento barato, no excluyente):** el 🔴 3 —media transacción aplicada— no lo arregla ni E ni
ninguna de las cuatro. Lo arregla leer el origen en **una sola foto consistente** (los dos barridos de
`readSourceFacts` dentro de la misma transacción de lectura repetible). Es local, no coordina nada
entre procesos y no cuesta disponibilidad.

---

## 4 · Lo que intenté y NO se rompió

- **`--to=openfga` con `--prune` como remedio del `extra-fact` de la ventana (escenario de MIGRACIÓN
  limpia, no de despliegue `facts`)**: reparó exactamente lo que debía —`deleted=3`, el store dejó de
  conceder el rol revocado— y **no** se llevó por delante el deny vivo de otro holder. El desastre
  del 🔴 2 de la auditoría final necesita la precondición de `authz_*` caduca, no se dispara aquí.
- **Divergencia entre motores**: repetí D1 completo en **MySQL 8.4** y salieron **los mismos números
  que en PostgreSQL 18**, dígito a dígito. La pérdida no es de dialecto, es de arquitectura. (Dato
  útil: la señal que delató todos los hallazgos serios de esta fase **no** aparece aquí, y eso es
  información: el problema no está en la capa SQL.)
- **`grant` perdido en la ventana**: sí lo detecta la pasada siguiente (`written=1`) y además lo
  **repara** — D funciona para lo que concede. Es solo con lo que retira con lo que es ciego.
- **Idempotencia de las dos direcciones sin concurrencia**: confirmada (`pasada 2: written=0
  extra=0 skipped={} clean=true`). La premisa sobre la que D se construye es **cierta**; lo que falla
  es la inferencia que se hace desde ella.
- **`E_AUTHZ_FROZEN` como barrera dentro del proceso que congela**: sólida. Cubre las cuatro
  escrituras de hechos, las tres del árbol y el relay; rechaza **antes** de validar identidades; y el
  `finally` de `withFrozenWrites` descongela en el camino de error. Lo que rompe es su alcance
  (proceso) y su falta de dueño, no su colocación.
- **Intenté** que el freeze de un proceso se filtrara a otro por la caché de catálogo compartida
  (`authz_catalog_version`): **no** hay ningún acoplamiento; el freeze no toca la base. (Relevante
  para A: si se decide colgar el freeze de esa fila, ojo con `revalidate: { everyMs }` — ese modo,
  ya documentado como «ventana acotada de catálogo viejo», se convertiría en una **ventana acotada de
  freeze que todavía no aplica**, o sea escrituras aceptadas después de que `freeze()` haya
  devuelto.)
- **Intenté** provocar un fail-open por identidad/mayúsculas en la ruta del freeze: no hay superficie
  (el freeze no lleva identidad).

---

## 5 · Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿El cutover entra en el alcance de esta decisión?** Si no, cualquiera de las cuatro deja el
   agujero grande abierto (§2) y el README seguirá prometiendo de más, solo que en otro párrafo.
2. **Si se elige D: ¿cuál es el criterio EXACTO y escrito?** `written===0` está medido como
   insuficiente (🔴 2). `clean===true` está medido como insuficiente (🔴 1) **y** como ruidoso
   (`expired`/`unknown-scope` sin concurrencia). Sin un criterio escrito, D es una frase, no un
   mecanismo.
3. **Si se elige A: ¿token de dueño, TTL y comportamiento ante fallo de lectura de la fila?** Las
   tres respuestas deciden si A es fail-closed (aceptable) o fail-open silencioso (inaceptable, dado
   que viene con una promesa fuerte). Y: **¿`--dry-run` congela?** Mi recomendación de auditor es que
   no, y es gratis.
4. **¿Se puede corregir el 🔴 3 (foto consistente del origen) con independencia de A/B/C/D?** Si la
   respuesta es sí, el argumento más fuerte a favor de A desaparece y B se queda solo compitiendo con
   E.
5. **¿Está el 🔴 2 de `fase-3b-auditor-final.md` (resurrección + `--prune`) en la misma tanda?**
   Si no, D no debería mergearse: aumenta la frecuencia con que un operador teclea `--prune`.

---

## Apéndice · Reproducciones

Todas en el worktree de solo lectura
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/wt-panel-auditor/repro3/`
(`harness.ts` + cinco guiones). Nombres de base propios (`auditor3_*`) y stores borrados: verificado
0 stores en `:8101` y 0 bases residuales en PG y MySQL al terminar.

```bash
export OPENFGA_TEST_URL=http://localhost:8101
export TEST_DB=pg TEST_PG_URL='postgres://postgres:<pass>@127.0.0.1:5432/auditor3'

node --import @poppinss/ts-exec repro3/d1_segunda_pasada.ts        # 🔴 1 y 🔴 2 (--to=database)
node --import @poppinss/ts-exec repro3/d2_ida.ts                   # 🔴 1 y 🔴 2 (--to=openfga) + 🟡 11
node --import @poppinss/ts-exec repro3/d3_mitad_de_transaccion.ts  # 🔴 3 (media transacción)
node --import @poppinss/ts-exec repro3/a1_freeze_sin_dueno.ts      # 🟠 4 (freeze sin dueño)
node --import @poppinss/ts-exec repro3/a2_coste_freeze.ts          # 🟡 7, 🟡 8, 🟡 9
node --import @poppinss/ts-exec repro3/a3_agujeros.ts              # 🟠 5 (catálogo y driver())
node --import @poppinss/ts-exec repro3/e1_ventana_testigo.ts       # opción E (readChanges + uuidv7)

# el mismo D1, en MySQL (mismos números):
TEST_DB=mysql TEST_MYSQL_URL='mysql://root:root@127.0.0.1:3306/auditor3' \
  node --import @poppinss/ts-exec repro3/d1_segunda_pasada.ts
```
