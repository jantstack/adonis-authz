# `2.4.0-alpha.6` (sin commitear) — AUDITOR sobre el diff

Base: `main` `85e90c3` + el lote alpha.6. Contraste: mis 🔴 3 y 🟡 8 del
`panel-relay-auditor.md` y el 🟡 «only/detached» de `alpha5-auditor-final.md`.
Medido con **PostgreSQL 18** y el **OpenFGA `:8101`** (v1.19).
Reproducciones nuevas: `relay-auditor-{12,13,14}.ts`; re-ejecutadas
`{6,7,9,10b}.ts`. Logs en `$S/a_*.log`.

## Veredicto: **APTA**

Las dos piezas hacen lo que prometen y lo verifiqué contra el servidor real:
**el reparto por `scopeKey` no se puede confundir por prefijo** (cinco claves
que se solapan, cada tupla en su sitio, un solo `read` con filtro `{}`), y
**la herencia del origen cierra mi 🟡 de alpha.5** (`only:[detached]` detrás de
una aparcada ahora purga). Los cuatro ataques nuevos —cadena larga, ciclo,
cruce por `app`, orden del memo— **no rompieron**. Queda un 🟡 de
observabilidad en el reconcile de K particiones y tres ⚪. Nada reabre.

---

## 1 · (a) El reparto por `scopeKey` — no hay sangrado por prefijo

Cinco particiones elegidas para pisarse (`relay-auditor-12.ts`, store real,
una tupla marcada por partición):

```
app                                               ⇒ app
appliance|01a08c8e-…-cededbdf9e2c                 ⇒ appliance|U
organization|01a08c8e-…-cededbdf9e2c              ⇒ organization|U
org|01a08c8e-…-cededbdf9e2c                       ⇒ org|U
org|01a08c8eddbc76198da6cededbdf9e2c              ⇒ org|Usin-guiones
```

`app` no arrastra `appliance|U`, `org|U` no arrastra `organization|U` y las dos
ortografías del MISMO uuid son dos particiones distintas (lo que ya prometía
`enumerateRelations`). Es correcto **por construcción**, no por suerte: la
clave se parsea desde la derecha (`#parseObjectId`) y el reparto es un
`Map.get(clave entera)` (`openfga_relations_driver.ts:#sweep`), nunca un
`startsWith`.

- **Filtro real de cada `read`**: `[{}]` — un solo `read` para las cinco
  particiones (`reads=1` frente a `5` con `enumerateRelations` una a una), y
  **paridad exacta** (5 tuplas = 1+1+1+1+1).
- **Una tupla de partición NO pedida**: se descarta, no se cuela (verificado).

### ⚪ 1 — el barrido lee el store entero y no dice nada de lo que dejó fuera

Lo descartado es correcto (el puerto promete «solo las pedidas»), pero el
barrido **ya tiene delante** todas las particiones del store y no las cuenta.
En una migración por tenants, olvidar un tenant en `partitions[]` es
exactamente igual de silencioso que antes, con la diferencia de que ahora una
sola pasada podría haberlo dicho gratis. Sugerencia de una línea: un
`partitionsSeen`/contador de descartadas en el reporte del reconcile.

### ⚪ 2 — el userset de una tupla CRUZADA pierde su partición (preexistente)

Medido: una tupla escrita a mano con objeto en `org|U` y sujeto
`group:organization|U|<g>#member` sale del barrido como
`subject = { object: { type: 'group', id: '<g>' }, relation: 'member' }` — sin
su partición (`#userToSubject` la descarta). Al escribirla, el destino la
re-compone con la partición **de la tupla**, así que apunta a otro userset:
**deriva fail-closed**, no escalada, y solo alcanzable con tuplas escritas
fuera del paquete (el manager exige que el userset comparta partición). No es
del lote; queda anotado porque el barrido es ahora el camino de la migración.

---

## 2 · (b) `reconcileRelations({ partitions })` con K particiones

`relay-auditor-13.ts` (dobles de driver):

| Prueba | Resultado |
|---|---|
| R-17 salta en la partición **3** | **500 `E_AUTHZ_MASS_RECONCILE_REFUSED`**, y **cero escrituras en las particiones 1 y 2** — todo-o-nada de verdad, con el mensaje diciéndolo («No se ha escrito nada en ninguna partición») |
| el `relate` de la partición **2** revienta | la 1 queda **escrita entera**, la 3 **sin tocar**, y la excepción **se lleva el reporte** |
| segunda pasada con el store sano | `written=2` (exactamente lo que faltaba); tercera pasada `written=0, unchanged=4` |

El «decide K, luego escribe» está bien puesto: los K planes y los K seguros se
evalúan antes del primer `relate`. Lo que no hay es observabilidad del fallo a
mitad:

### 🟡 3 — un fallo a mitad de una pasada de K particiones no dice por dónde iba

- **Escenario**: `reconcileRelations({ partitions: [P1, P2, P3] })`; el store
  del destino se cae al escribir P2. Resultado: P1 migrada, P2 a medias, P3
  intacta, **excepción sin reporte** (los contadores se pierden) y **el error
  no viene marcado como escritura parcial** (invariante 13: `markPartialWrite`
  no se usa aquí). Con `--prune` lo ya borrado en P1 tampoco se cuenta.
- **Evidencia**: ✅ medido (`[U]` de la repro 13).
- **Steelman**: «es idempotente: re-ejecuta». → **Me convence como reparación**
  —lo medí: la segunda pasada escribe exactamente lo que faltaba y la tercera
  es un no-op— **no como observabilidad**: el operador que no re-ejecuta deja
  tenants a medias (fail-closed: relaciones que faltan, no de más) y el reporte
  no le dice cuáles. Es la forma que ya tenía con una partición; lo que cambia
  es el radio (K tenants en una llamada) y que el reporte es una SUMA, así que
  ni siquiera en verde hay desglose.
- **Mitigación mínima**: reporte por partición (o `completedPartitions`) y
  marcar el error como parcial cuando ya se escribió algo.

---

## 3 · (c) y (d) El origen del bloqueo bajo `only`

`relay-auditor-14.ts` (`RELAY_ORIGIN_MAX_HOPS = 100`):

```
[W] cadena de   5 pendientes ⇒ detached applied                      · sondas   5 ·  6 ms · purgas 1
[W] cadena de 120 pendientes ⇒ detached deferred/depends-on:128      · sondas 101 · 73 ms · purgas 0
[X] víctima con 130 entradas ajenas colgando de `app` ⇒ applied      · sondas   1 · 10 ms
[Y] claves cruzadas A↔B ⇒ deferred · sondas 2 · 4 ms (ids estrictamente decrecientes)
[Z] #4 detached(C) ⇒ applied · #5 detached(raiz) ⇒ failed · #6 detached(C2) ⇒ deferred/depends-on
```

- **Cota**: superarla **aplaza** (fail-closed), como pide el diseño; el coste
  está acotado en 101 sondas / 73 ms por entrada pedida.
- **¿Puede un tenant empujar las purgas de OTRO por encima de la cota?** En la
  construcción natural, **no**: la sonda devuelve la pendiente **MÁS ANTIGUA**
  que comparte clave, no la inmediatamente anterior, así que las cadenas
  **colapsan** en vez de encadenarse; la víctima con 130 entradas ajenas
  colgando de `app` resolvió su purga en **UNA** sonda. Para llegar a 100
  saltos hace falta una **ruta de scopes de 100 niveles** (cada entrada
  compartiendo clave solo con su vecina), que es del propio tenant y que
  `scopes.maxDepth`/`FACTS_MAX_RESOLVE_DEPTH` desaconsejan por otros motivos.
  Y aun así el resultado es fail-closed: la purga espera a la pasada completa.
- **Ciclo de claves**: termina, y no por casualidad —`earlierPending` exige
  `id < mine`, así que la recursión decrece estrictamente; el ciclo de claves
  no es un ciclo de ids—.
- **(d) el memo**: **correcto y la limpieza es load-bearing**. El caso decisivo
  ([Z]): `#4 detached(C)` se aplica con origen aparcado (memoiza `#2`), `#5
  detached(raiz)` **falla de verdad** (`block(..., false)` ⇒ `origins.clear()`)
  y `#6 detached(C2)`, cuya cadena vuelve a pasar por `#2`, **recalcula y se
  aplaza**. Sin ese `clear` el `#6` habría purgado con un origen ya caduco. El
  orden de evaluación no puede invertirse: las entradas se procesan por id, y
  un fallo solo puede venir de una entrada pedida (las no pedidas no se
  intentan).

### ⚪ 3 — el coste de la cadena lo paga la petición

Hasta 101 sondas (`earlierPending`) por entrada pedida, **bajo el lease**. Es
del propio tenant y está acotado y documentado en «Limits»; lo anoto porque
es el único coste nuevo del camino caliente.

---

## 4 · (e) ¿Reabre algo de alpha.5? — No (re-ejecutado)

| Pieza | repro | Resultado |
|---|---|---|
| 🟠 1 de alpha.5 (purga a un salto de una aparcada) | 7 | `applied` + `purge` en las dos ramas |
| 🟠 2 (censo completo) | 9 | `deferred/parked:101`, cero llamadas |
| origen del bloqueo (fallo pisa a aparcado) | 10b | `[J1]`/`[J2]` idénticos ✔ |
| `requeue` (dos puertas, `--force`, `maxAttempts−1`) | 6 [A]/[A2] | idéntico |
| `only` + tapón + sonda | 6 [B]/[C] | idéntico salvo **el cambio buscado** |
| freeze | 6 [D] | `503 E_AUTHZ_FROZEN`, 0 escrituras |
| `maxDepth` | 6 [E], 7 [H] | idéntico (PARCIAL declarado) |
| terceros sin recibo / que ignoran `{ ids }` | 6 [F] | 500 en las dos puertas |

**El cambio buscado, medido**: `only:[#4 detached(unit)]` con `#1` APARCADA
pasó de `deferred/depends-on:10` (alpha.5) a **`applied` + `purge unit | detached unit`**.
Mi 🟡 «bajo `only` la exención no aplica» queda **cerrado**.

Y de propina, cerrados también los dos que dejé en el veredicto final de
alpha.5 sin pedirlos en este lote: **`PARKED_CENSUS_MAX` ya está en la tabla
«Limits»** (⚪ C) y hay un párrafo **«When the parked set grows»** que dice lo
que faltaba: `reconcile` no baja el contador, `requeue` no tiene `--all`, y el
remedio es SQL del operador sobre su tabla + reconcile después (🟡 B).

## 5 · Residuales, sin cambio y declarados

🟡 requeue después de un `reconcile` (la sonda solo ve la outbox) · 🟡 un 503
eterno no converge y tapona su clave · ⚪ `maxDepth` PARCIAL · ⚪ `only` con
ids ajenos aplica y enseña lo ajeno (en orden) · ⚪ el deber del puerto
(`pending()` sin esconder filas) descansa en la letra + O-08.
