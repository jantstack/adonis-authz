# Respuesta de COGNITIV al plan 2.5 (tenencia) — 2026-10-15

**Para:** `@jantstack/adonis-authz` · **De:** `api-cognitiv` · **Re:** `tenencia-respuesta-cognitiv.md` (plan 2.5
aprobado el 2026-10-14; `2.5.0-alpha.1` publicado en `beb1d0a`)

Aceptamos el plan y el calendario. Contestamos las 13 preguntas con datos de nuestro código y de nuestra base
(HEAD `8b9e7d9`, driver `database` en producción, `openfga` en CI). Al final, tres peticiones pequeñas y lo que
haremos nosotros en cada alpha.

---

## Respuestas

**1 · `inherits=false` para Nóminas, y para qué usaríamos el deny.** Confirmado: Nóminas se resuelve con
`inherits = false` en el nodo (nuestro evaluador deja de subir por la cadena en ese nodo; solo cuentan las tuplas
directas sobre él y sus descendientes). El deny lo usaríamos para **excepciones por sujeto** dentro de una herencia que
sí queremos mantener: "todo Contabilidad ve `Finanzas`, salvo este contratista externo que es miembro del grupo";
"esta integración (máquina) no entra en esta carpeta aunque su rol lo permita"; y "esta persona invitada de otra
organización deja de ver esta subcarpeta sin retirar la concesión de la carpeta padre". Siempre deny sobre un holder
directo (`users:<uuid>` o `integrations:<uuid>`); nunca sobre `group` (entendido el 422).

**2 · ¿Deny temporal?** No en v1. Un bloqueo "hasta el cierre contable" lo haremos con `inherits=false` temporal en
nuestro nodo (columna nuestra), no con una tupla. Entendida la ventana de OpenFGA 1.19 al renovar.

**3 · Partición canónica.** Nuestra partición siempre se construye desde la fila de la organización
(`partitionOf(organization.uuid)`, uuid v7 con guiones, columna `uuid` de PostgreSQL), nunca desde la URL. Consulta
de detección del README ejecutada en la base de desarrollo:

| consulta | resultado |
|---|---|
| tuplas con partición no canónica | **0** |
| tuplas totales | 65 (`group#member` 49, `space viewer` 11, `space contributor` 5) |
| particiones distintas | 20 |
| longitud máxima de `relation` | 11 (`contributor`) |

En producción la ejecuta el owner antes de subir a alpha.1; os mandamos el número. Si saliera > 0 usaríamos la rama
`--rekey` de la receta.

**4 · "Compartido conmigo".** Nos basta con **directas + `includes`** (usersets no hace falta: un invitado externo
nunca es miembro de un grupo del dueño). **No está en el camino crítico de F0**: lo necesita F2a (invitados), que
empieza después de F1 (tenencia + ACL + primer conector). Vuestra alpha.4 llega de sobra.

**5 · Retirada de tuplas de una organización borrada.** Camino único, bajo candado de la organización y con la org
marcada `purging` antes del censo (`organizations_service.ts`, `deleteOrganizationNow`): `partition_sweep.ts`
enumera la partición con `enumerateRelations`/`enumerateRelationsMany` paginado (tope de páginas; agotar el
presupuesto sin agotar el cursor **lanza**, nunca corta en silencio) y aplica `purgeObject`/`purgeSubject` por tupla
(`mirror.ts`); el reparador de membresía usa el mismo barrido. No existe en nuestro lado un `purgePartition`: si el
paquete lo ofreciera (una partición entera, con prueba de que el conjunto queda a cero como `purgeScope`), lo
adoptaríamos y retiraríamos el barrido de la baja. Con denies: entendido que el procedimiento de rollback los cuenta y
retira; lo integraremos en nuestro runbook de cutover.

**6 · Versión.** Fijada **exacta**: `"@jantstack/adonis-authz": "2.4.0-alpha.10"` (sin `^`). Subiremos a mano
alpha por alpha; las rupturas de alpha.2 no nos llegarán solas.

**7 · `modelId` y `openfga:provision`.** `OPENFGA_MODEL_ID` es hoy **opcional** (`env.get`, el compose lo pasa con
`${OPENFGA_MODEL_ID:-}`). `openfga:provision` lo ejecuta el operador a mano desde el contenedor del API
(`node ace.js openfga:provision`), una vez por instalación y cada vez que cambia el modelo, con la versión del
paquete que lleve la imagen. Para alpha.3 haremos `OPENFGA_MODEL_ID` **obligatorio** cuando `AUTHZ_DRIVER=openfga`
(fallo de arranque si falta), y documentaremos "provision → fijar `modelId` → desplegar" en nuestro runbook.

**8 · Tipos con deny.** Solo el nuevo `tenancy_node` (relaciones `manager ⊇ editor ⊇ viewer`, 7 caracteres como
máximo). `space` sigue sin deny. Ninguna relación nuestra supera los 11 caracteres; ninguna llegará a 43.

**9 · Hooks y verificación.** `assertWrite` (`assertSpaceTupleWrite`) es puro y **solo mira la forma** (tipo de
objeto frente a la ventana de escritura activa, `group` solo con `member`, lista blanca de sujetos); **no distingue
acciones**: valida igual `relate`, `unrelate` y las purgas (también al encolar en la unidad de trabajo). Con deny
añadiremos la misma validación de forma para `deny`/`removeDeny` y la ventana `tenancy`. `onRelationWrite` hoy
audita **todas** las acciones bajo un único evento `authz.relation_written` con `event.action` en el payload; para
alpha.3 añadiremos eventos propios `relation_denied`/`relation_deny_removed` (ya lo hacemos con los denies de
permisos de rol). Nuestro `authz:cutover:verify` **no compara tuplas**: delega en vuestro
`authz:relations:reconcile`/verify y solo clasifica el residuo (`undeclared-relations`, `unclaimed`); si
`relationTupleKey` lleva `kind`, nada nuestro se rompe.

**10 · Forma de la spec.** Usersets: **solo `group#member`** (lo impone `assertSpaceTupleWrite`, S-6). `includes`:
lineal, sin ciclos (`manager → contributor → viewer`). Claves de la spec: solo `objectTypes` y `holderTypes`. Alpha.2
no nos rompe nada por ahí; `sqlScopeOutbox` ya va con `requireTransaction: true`. Lo único que adaptamos es el
import de `runRelationsReconcile` al nuevo subpath.

**11 · `listObjects` en `openfga` sobre particiones grandes.** Sí lo llamamos, siempre acotado a una partición
(organización): `spaces/mine` (`access_resolver.ts`, tipo `space`) y el servicio de unidades. Particiones pequeñas
(decenas a cientos de objetos por organización). Con la tenencia el volumen de `tenancy_node` por partición puede
subir a miles: el `truncated` de alpha.2 nos viene bien, y lo trataremos como **503**, nunca como lista parcial
(ya es nuestra regla en el evaluador de la tenencia: lista truncada ⇒ denegar/503).

**12 · Fechas del ensayo sobre la RC (7 días).** Lo fija el owner; de nuestro lado proponemos que la RC coincida con
el final de nuestra F0 (contrato del puerto, evaluador puro y dobles), para ensayar con el evaluador ya escrito
contra el tarball exacto. Os mandamos la fecha cuando el owner cierre el calendario de la tenencia.

**13 · Semántica de corte y `decideMany`.** Nos valen las dos. Corte de camino: un deny en `editor` anula el `owner`
y solo sobrevive un `viewer` directo; deny en `viewer` lo bloquea todo. `decideMany(subject, relation, objects,
partition) → ('allow' | 'deny' | 'none')[]` es exactamente la primitiva de nuestra cadena: recorremos de la hoja a
la raíz y paramos en el primer valor ≠ `none`, con `deny` = "no heredéis más allá" y `inherits=false` del nodo como
segundo corte. Entendido que `checkMany` no sirve para eso. Pedimos para `decideMany` las mismas garantías que
`checkMany`: tope 50, `[]` ⇒ 422, un error en un ítem ⇒ 503 para todos, orden de salida = orden de entrada.

---

## Tres peticiones pequeñas

1. **`purgePartition(partition, options)`** (ver 5): una partición entera con prueba de conjunto vacío o
   `E_AUTHZ_PURGE_INCOMPLETE`. Nos retira el barrido paginado de la baja de organización y cierra el riesgo de "censo
   fuera de la transacción".
2. **Que `decideMany` acepte también la relación `viewer` cuando el sujeto es un invitado de otra partición**
   (holder `users:<uuid>` sin partición): es el caso normal de F2a y queremos que la suite común lo nombre
   (*"decideMany para un holder de otra organización responde por la partición del objeto"*).
3. **Que el `truncated` de `listObjects` viaje también en `listObjectsForSubject`** (alpha.4), con la misma forma.

---

## Lo que haremos nosotros, por alpha

- **alpha.1 (ya publicada):** ejecutar la detección en producción (pregunta 3) → subir el pin → sustituir en los tests
  de caducidad las fechas sembradas por `createTestClock()` → usar `checkMany` en el evaluador para las
  comprobaciones positivas de la cadena (nunca para el deny).
- **alpha.2:** adaptar el import de `runRelationsReconcile`; tratar `truncated` como 503 en `spaces/mine` y en el
  resolutor de unidades; sin más cambios previstos.
- **alpha.3:** declarar deny solo en `tenancy_node`; `OPENFGA_MODEL_ID` obligatorio con `openfga`; los dos despliegues
  del opt-in (lecturas, luego escrituras) en nuestro runbook; eventos de auditoría propios; ventana `tenancy` en
  `assertWrite`.
- **alpha.4:** "Compartido conmigo" sobre `listObjectsForSubject` (F2a), sin índice local.
- **rc.1:** ensayo de 7 días con nuestra suite completa en los dos drivers y el runbook de cutover.
