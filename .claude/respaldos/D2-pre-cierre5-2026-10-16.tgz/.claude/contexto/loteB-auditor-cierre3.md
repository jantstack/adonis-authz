# Lote B (plan 2.5) — repaso corto del auditor sobre el cierre 3 (2026-10-15)

Alcance: solo el diff del cierre 3. Para aislarlo comparé con la copia del cierre 2 (`scratchpad/audB3/repo`). Los ficheros que
cambian son exactamente los del informe: `reconcile.ts`, el comando, `openfga_relations_driver.ts`, `relations_contract.ts`,
README, CHANGELOG y CLAUDE.md, más 7 specs. Trabajé sobre la copia `scratchpad/audB4/repo` (`node_modules` enlazado), con un
repro propio en `tests/audb4_repro.spec.ts` y el log en `scratchpad/audB4/specs.log`.

Qué corrí y qué no:
- Solo SQLite `:memory:`.
- Ni pg, ni mysql, ni gates, ni docker, ni OpenFGA.
- Los mutantes los apliqué sobre la copia y la restauré (`diff -q` limpio).
- El repo no se tocó salvo este fichero.

## Veredicto en una línea

**APTA para sellar `2.5.0-alpha.2`.** N9–N12 están cerrados y no hay debilitamientos. Encontré 4 ⚪ nuevos, ninguno bloqueante: no
hay fail-open, ni escritura parcial, ni throw a mitad de pasada. Pueden ir al lote siguiente o, si se quiere, como un mini-parche
de casos antes del tag.

## Tabla N9–N12 → estado

| # | Estado | Evidencia (✅ ejecutada / 📖 leída) |
|---|---|---|
| 🟠 N9 | **Cerrado** | Detalle en los puntos de abajo. |
| ⚪ N10 | **Cerrado** | Detalle debajo de los puntos de N9. |
| ⚪ N11 | **Cerrado** | 📖 `relations_contract.ts:1184-1189` y README «Third-party drivers». El caso de letra `trx_docs.spec:257` está verde ✅. |
| ⚪ N12 | **Cerrado** | Detalle e instrucción de sellado más abajo. |

**🟠 N9, en detalle:**
- **La lista de códigos es exactamente la familia de relaciones.** 📖 `RELATION_422_REASONS` (`reconcile.ts:798-803`) tiene 4
  códigos: `TYPE_UNKNOWN`, `RELATION_UNKNOWN`, `USERSET_UNSUPPORTED` e `INVALID_IDENTITY`. Nada más.
- **Lo que no es de la familia se propaga.** Medido con ✅ `audb4` B:
  - código de la familia con status 409 ⇒ se propaga;
  - código de la familia con status `'422'` como string ⇒ se propaga;
  - `TypeError` ⇒ se propaga;
  - `throw null` ⇒ se propaga;
  - `throw 'str'` ⇒ se propaga.
  - El caso del doble (`:956`) cubre además `INVALID_SLUG` (422), 503 y `Error`.
  - Excepción: un 422 con `code` igual a una clave del prototipo se absorbe. Es el ⚪ N13.
- **Database real (✅ `audb4` A, `:memory:`), relación `publisher` retirada:**

  | `toConfig` | dry | real | dry2 | Filas al final |
  |---|---|---|---|---|
  | con | `d1 e1` + `undeclared/false` | igual que dry | `d0 e1` | `publisher` sigue, X borrada, W escrita, sin throw |
  | sin | `d2 e0`, `details []` (límite declarado) | `d1 e1 undeclared/false` | `d1` | las mismas |

- **Tabla de 20 filas:** ✅ re-ejecutada con `AUTHZ_N9_TABLE=1` y comparada línea a línea con la del informe: **idéntica, 20/20**.
- **Las demás filas siguen y todas se listan:** ✅ en el doble con los 4 códigos y una sobrante buena, la sobrante buena se borra
  y los 4 rechazos salen listados, `clean=false`.
- **Casos por el kernel y contra openfga:** existen, 📖 `command_flags:1128` y `relations_openfga:325`. El de openfga no lo
  ejecuté: no hay servidor en este repaso.
- **Driver contradiciendo al plan *con* `toConfig`:** se captura igual, pero ese camino no tiene caso. Es el ⚪ N14.

**⚪ N10, en detalle:**
- 📖 La guarda está en `openfga_relations_driver.ts:316`, con `deadline > this.#timeoutMs`.
- ✅ Casos límite del caso `:1735`:
  - igual, 5000/5000 y 3000/3000 ⇒ entra;
  - mayor por 1, 5001 con el default ⇒ 500;
  - `timeoutMs` ausente ⇒ default 5000: el default de 3000 entra y `timeoutMs: 2999` sin deadline da 500.
- La letra *Adapt* del README (`:1577`) explica la decisión (4).
- El stub `config/authorization.stub:261` no pasa ni `timeoutMs` ni deadline, así que con los defaults (3000 ≤ 5000) no se rompe.
- Ni `configure` ni el quickstart construyen el driver con `timeoutMs`.

**⚪ N12, en detalle:**
- ✅ El hash `3a0d10aa…` coincide con el bloque de alpha.1 en `beb1d0a` (= tag `v2.5.0-alpha.1`): 25 141 bytes, LF, sin `\r`.
- Las cabeceras están ancladas con `^…$/m` y el bloque va de la cabecera de alpha.1 a la de `2.4.0-alpha.10`.
- Sobrevive al sellado si se sigue la instrucción de abajo.

**Decisiones del cierre 3:**
- **(1) Coherente, no debilita.** El único assert quitado en todo el diff de tests del cierre 3 es el del caso L-0 (`deleted 1`,
  `check false`). El caso se reescribió conservando «no cuenta como respaldada» (`unchanged 1`, `extra 1`) y añadiendo `details`
  y la re-declaración.
  - El precio es que una fila de una relación retirada ya no la borra ninguna herramienta del paquete hasta
    `--prune-undeclared` (lote D).
  - Ese precio está escrito en el CHANGELOG («nothing deletes a row the destination does not declare») y es la regla «por la
    fila».
- **(3) Escrita como límite y con caso.** Está en el README §Upgrading 6 y en el CHANGELOG, y el caso es «SIN toConfig» más las
  filas `no|dry` de la tabla.
  - Matiz: no afecta solo a la API directa. También afecta al comando cuando no hay config persistida (`toConfig === null`).
    El informe lo dice («salvo no hay config persistida»); el README solo lo dice implícitamente.
- **(4) Adapt escrito y caso presente.** La regresión que la guarda puso roja la arreglaron en 2 specs, declarado en la línea (c).

**Transversal:**
- `freeze.spec`, `EXPECTED_FUSED` y `migration_stub` no aparecen en el diff del cierre 3.
- Sin `skip` nuevos.
- ✅ 9 specs tocadas o sensibles: 389/389 verdes en `:memory:`.
- CHANGELOG `[Unreleased]` en orden: B1…B9, «Surface guard figures», luego Closure 1 (`:126`), 2 (`:208`) y 3 (`:302`), y después
  la cabecera de alpha.1 (`:369`). El B4 ya no nombra la opción `monotonic`; solo «monotonic clock» como concepto.
- README §Upgrading 6 es verdad con los drivers del paquete, salvo el matiz del ⚪ N14.

## Hallazgos nuevos

### ⚪ N13 · `RELATION_422_REASONS` se consulta con el prototipo de `Object`
- **Escenario:**
  1. Un driver de terceros lanza `{ status: 422, code: 'constructor' }` (o `'toString'`, o `'__proto__'`) en `unrelate`.
  2. La poda lo absorbe con `reason` igual a una función o a un objeto.
  3. La línea sale como «sobra (function Object() { [native code] }) destino: …».
- **Evidencia:** ✅ `audb4` B. El origen es `RELATION_422_REASONS[String(error?.code)]` sobre un objeto literal congelado
  (`reconcile.ts:798`, `:821`).
- **Steelman:** ningún driver real usa esos códigos, y la fila sigue listada con exit ≠ 0. **Me convence**: no es explotable. Pero
  contradice «fuera de esta tabla NADA se absorbe».
- **Mitigación:** `Object.hasOwn(RELATION_422_REASONS, code)` o una tabla con `Object.create(null)`/`Map`.

### ⚪ N14 · «El driver contradice al plan CON `toConfig`» no tiene caso, y ahí dry ≠ real
- **Escenario:**
  1. Se retira `publisher` de la config en código y se despliega, pero no se re-ejecuta `saveRelationsConfig`, que es manual.
     La config persistida sigue declarándola.
  2. `--dry-run --prune` ⇒ `deleted 2, details []`, sin línea.
  3. La pasada real ⇒ `deleted 1, extra 1, undeclared/false`.
- **Resultado:** no hay throw y la fila se lista; el comportamiento es correcto.
- **Evidencia:**
  - ✅ `audb4` A con `toConfig` que declara `publisher`.
  - ✅ El mutante «capturar solo si `!toConfig`» **sobrevive**: 108/108 en `relations_reconcile`, `_cli`, `command_flags` y
    `relations_openfga`.
- **Letra:** el README §Upgrading 6 dice que dry y real dan «the same numbers» cuando la config persistida está a mano. En esa
  ventana no es verdad.
- **Steelman:** el brief lo admite («o si el driver contradice al plan»), y la línea real ya da la receta «re-guarda su config
  persistida». **Me convence a medias**: el comportamiento es correcto, pero un camino decidido debería tener caso.
- **Mitigación:** un caso con `toConfig` ≠ config del driver, más una frase en §Upgrading 6.

### ⚪ N15 · La mitad «`status`» de la captura no está fijada
- ✅ El mutante «quitar `error?.status === 422`» **sobrevive** (108/108).
- **Mitigación:** añadir al caso del doble un código de la familia con status 409 que debe propagarse.

### ⚪ N16 · Cosmético
- La guarda de N10 es relativa a un `timeoutMs` que nadie valida. Con `timeoutMs` y deadline iguales a `2^31-1` la guarda pasa, y
  la señal queda inalcanzable en la práctica.
  - Hace falta equivocarse en dos campos, y es el mismo error del operador que «D > S» ya declarado.
  - Con `Infinity` o `≥ 2^31`, `setTimeout` desborda a 1 ms y todo sale como 503 ruidoso.
- El hash de N12 depende de LF. No hay `.gitattributes`: un checkout de Windows con `autocrlf` lo pone rojo. Es irrelevante en el
  CI actual.

## Instrucción explícita para el sellado (caso N12)

- **Cambia SOLO la línea 3 del CHANGELOG:** `## [Unreleased] — plan 2.5 · lot B (…)` ⇒ `## [2.5.0-alpha.2] — 2026-10-15 …`.
  - Si quieres, añade encima una cabecera `## [Unreleased]` vacía.
  - Ningún test depende del literal `[Unreleased]`: solo `relations_events_docs:222/258` cortan en `## [2.4.0-alpha.2]`.
- **No toques nada entre `## [2.5.0-alpha.1]` (`:369`) y `## [2.4.0-alpha.10]` (`:605`)**, incluidas las líneas en blanco del
  final del bloque. No pases un formateador por el CHANGELOG, porque reescribiría el bloque y cambiaría el hash.
- **Los tres «### Closure N of lot B» quedan bajo `[2.5.0-alpha.2]`**, encima de alpha.1. El caso solo exige que estén por
  encima de alpha.1, así que sigue verde.
- **Comprobación:** tras sellar, corre `relations_events_docs.spec`. Si hay rojo en N12, alguien tocó el bloque de alpha.1: revierte
  ese bloque, no actualices el hash.
- **Opcional, para el lote siguiente:** fijar también el hash del bloque de alpha.2 recién sellado.

## Lo que intenté y no se rompió

- 409, `'422'` como string, `TypeError`, `null` y string lanzados en `unrelate`: todos se propagan.
- El orden forma → F-05 en el destino (fila combinada de la tabla).
- La tabla de 20 filas re-ejecutada.
- `database` real dry/real/dry2 con y sin `toConfig`: sin throw, X borrada, W escrita, `publisher` intacta.
- El residuo nunca recibe `unrelate` con `toConfig` (espía del caso `:877`).
- Casos límite de N10.
- Stubs y defaults.
- Hash de alpha.1 contra `beb1d0a`.
- Ningún assert quitado salvo el caso (c) declarado.
