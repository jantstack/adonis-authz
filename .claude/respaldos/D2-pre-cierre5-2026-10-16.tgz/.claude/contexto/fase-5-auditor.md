# Fase 5 · Auditoría de seguridad — `resourceAccess` middleware

Auditor adversarial. Objetivo: ¿puede un atacante distinguir estados que el middleware
promete indistinguibles, saltarse una comprobación, o disfrazar un 503 de 404/403?

## Veredicto en una línea

**Se cierra la fase.** No hay 🔴 ni 🟠 explotable. El orden, los cuerpos idénticos, el
no-disfraz del 503 y la clasificación read/write resisten. Un solo residual ⚪ (canal de
temporización inherente al patrón load→authorize) que conviene DOCUMENTAR, no arreglar.

## Hallazgos (ordenados por severidad)

### [⚪] Canal de temporización distingue «no existe» de «existe pero no es tuyo»

- Escenario: precondición → el atacante autentica y pasa el `gate` (o no hay `gate`) →
  acción → pide `/…/documents/<id>` variando `<id>` y MIDE la latencia → resultado →
  un `<id>` inexistente responde 404 SIN llamar a `authorize` (`load ⇒ null`, corta en
  `resource_access_middleware.ts:176` antes del `authorize` de `:185`); un `<id>` que
  EXISTE pero cuyo scope no autoriza responde 404 DESPUÉS de una llamada extra a
  `authorize` (round-trip al backend). La diferencia de tiempo (una llamada a `authorize`)
  reintroduce la enumeración que el status y el cuerpo cierran.
- Evidencia: ✅ código. `if (!loaded) return notFound()` (línea 176) retorna antes del
  `authorize` (línea 185). Confirmado además por el propio spec: en el caso «recurso
  ausente» el flujo no llega a `authorize`; en el camino con recurso presente sí (`authorized === 1`).
- Steelman del defensor: «es INHERENTE — para conocer el `{scope}` de un recurso hay que
  cargarlo, y no hay nada que autorizar de algo que no existe; además el `load` de un
  recurso inexistente suele pegar a la BD igual (SELECT vacío), así que el delta real es
  solo el `authorize`, ahogado por el ruido de red». → ¿me convence? Sí para NO tratarlo
  como bug del middleware, no para callarlo. El middleware promete literalmente «no
  distingue no-existe de no-es-tuyo»; esa promesa es cierta en status+cuerpo y FALSA en
  tiempo. Es una limitación honesta, no un defecto de implementación.
- Mitigación mínima sugerida: no cambiar el código; añadir una frase al informe/JSDoc:
  «la indistinguibilidad es de status y cuerpo; el tiempo de respuesta puede revelar
  existencia porque `authorize` solo corre para recursos que `load` encontró».

## Lo que intenté y NO se rompió

- **Escalada por method-spoofing (el vector más prometedor).** `method()` devuelve el
  método SPOOFEADO cuando `allowMethodSpoofing` está activo y el real es POST
  (`define_config…js:1877`). Intenté `POST /…/:id?_method=GET` contra una ruta de
  escritura para que el middleware clasificara la petición como SAFE y usara
  `readPermission` (más débil) mientras el controlador escribe. **Resiste**: el ROUTER
  enruta con el MISMO `ctx.request.method()` (`define_config…js:5068`) que consulta el
  middleware. Para alcanzar el handler de una ruta registrada bajo un verbo de escritura,
  `method()` debe valer ese verbo; el middleware ve ese mismo verbo y usa `permission`.
  Router y middleware leen la misma fuente, así que no hay downgrade. Un `POST?_method=GET`
  se enruta al handler de GET (lectura) y usa `readPermission` — coherente, no escala.
- **HEAD/OPTIONS/verbo no clasificado cayendo al lado permisivo.** `SAFE_METHODS =
  {GET,HEAD}`. Todo lo demás (POST/PUT/PATCH/DELETE/custom) cae en `permission` (el más
  fuerte). Un GET sin `readPermission` declarado también exige `permission` — una lectura
  NUNCA es gratis (líneas 180-183). El lado permisivo solo se alcanza con GET/HEAD + un
  `readPermission` que el consumidor eligió a propósito. No hay verbo que se cuele al lado
  débil. HEAD no puede alcanzar el handler de una ruta de escritura (el router no casa).
- **503 disfrazado de 404/403/false.** `gate` (línea 156), `load` (línea 175) y
  `authorize` (línea 185) NO están envueltos en try/catch: un throw sube tal cual (503).
  Un `gate` que devuelve `undefined`/`null` cuenta como negar (fail-CLOSED, 403), no como
  conceder. Un `load` que devuelve `null` es 404; solo un `throw` es 503. No encontré
  ningún camino que traduzca una caída a un `false`/404 silencioso.
- **Byte-a-byte del cuerpo 404.** Contenedor ausente, recurso ausente y `authorize`
  negativo usan la MISMA closure `notFound()` (líneas 162-163), que crea un literal
  idéntico `{ message:'Recurso no encontrado', statusCode:404, errors:[] }`. No se cuela
  ningún `id`/`message` dinámico ni header distinto. Indistinguibles en status y cuerpo.
- **Saltar el orden / llegar a `load` sin `gate` o a `authorize` sin comprobar
  existencia.** El flujo es estrictamente secuencial con `return` en cada rama; `load` solo
  corre tras el `gate` y la presencia del contenedor; `authorize` solo tras `load` no-null;
  `next()` SOLO se alcanza tras un `authorize` verdadero (líneas 185-193). `next()` se
  llama como mucho una vez y nunca tras una respuesta.
- **`{ role }` y config insegura.** `role` ⇒ 500 `E_AUTHZ_ROLE_IS_NOT_ACCESS` antes de
  mirar al usuario (línea 105); falta de `permission`/`param`/`load`/`resource` ⇒ 500
  `E_AUTHZ_CONFIG`. Un solo `authorize`, sin re-autorizar. Idéntico al invariante de
  `appAccess`.
- **Confusión de identidad del holder.** El subject sale de `ctx.auth.user` (lo fija el
  auth middleware, no el atacante). `uuid` vacío/ausente o modelo sin `@MorphMap` ⇒ 500,
  nunca degrada a 404 (líneas 139-151). El atacante no puede inyectar `type`/`uuid`
  arbitrarios por aquí.
- **Envenenar el scope autorizado (autorizar A, servir B).** El `authorize` corre sobre
  `loaded.scope` y se estampa exactamente `loaded` en `ctx[resource]` (líneas 185-192): el
  scope autorizado y el recurso servido son el MISMO objeto. El `param`/cuerpo no eligen un
  scope distinto del que devuelve `load`. Un `load` de ejemplo que no filtra por
  contenedor queda cubierto porque `authorize` corre sobre el scope REAL del recurso: pedir
  `/orgs/A/documents/<id-de-B>` carga el doc de B y autoriza sobre B ⇒ 404 si no tienes B.
- **El `gate` (403) como fuga de enumeración.** El 403 del `gate` se emite ANTES de
  `load`, cuando el scope del recurso aún se desconoce, así que estructuralmente NO puede
  depender de la existencia del recurso concreto: solo revela algo del contenedor/tenant,
  que el atacante ya conoce. No filtra existencia de recursos.

## Preguntas abiertas para el arquitecto

Ninguna cambia el veredicto. Única decisión editorial: ¿se acepta el canal de
temporización ⚪ como limitación documentada (recomendado) o se quiere una nota explícita
en el JSDoc del middleware?

## Redacción exacta para cerrar el ⚪ (añadir al informe de Fase 5 y/o al JSDoc)

> La indistinguibilidad que garantiza `resourceAccess` es de **código de estado y cuerpo**
> (404 idéntico byte-a-byte para contenedor ausente, recurso ausente y `authorize`
> negativo). **No cubre el tiempo de respuesta**: `authorize` solo se ejecuta para un
> recurso que `load` encontró, de modo que «existe pero no es tuyo» incurre en un
> round-trip de autorización extra frente a «no existe». Es inherente al patrón
> load→authorize (no se puede autorizar el scope de algo que no se ha cargado) y se acepta
> como tal; un consumidor con requisitos de resistencia a análisis temporal debe nivelar la
> latencia en su capa (respuesta de tiempo constante), no el middleware.
