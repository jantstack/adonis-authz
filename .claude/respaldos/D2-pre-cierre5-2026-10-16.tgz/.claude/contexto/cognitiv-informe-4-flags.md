# Cuarto informe al paquete — `name` no es `flagName` en los comandos ace (11-09-2026, sobre 2.4.0-alpha.8)

Asunto: `authz:scopes:relay --dry-run` APLICA; `--batch-size`, `--wait-lease-ms` y `--max-age` se ignoran (y `--max-age` es la alarma del runbook)

**Reproducido en `api-cognitiv` con alpha.8, driver `database`, por la vía real de ace** (`ace.create(AuthzScopesRelay, ['--dry-run'])`
y luego `exec()`): dos entradas pendientes ⇒ las dos quedan **aplicadas** (`applied_at` no nulo). Inspeccionando el comando tras
`exec()`: `cmd.parsed.flags['dry-run'] === true` pero `cmd.dryRun === undefined`.

**Causa** (`@adonisjs/ace`, `defineFlag(name, options)`): el flag se construye como `{ name, flagName: dashCase(name), ...options }`.
En `flags.boolean({ name: 'dry-run' })` la opción `name` PISA el nombre de la **propiedad** (que pasa a ser `'dry-run'`), y la
hidratación asigna `this['dry-run'] = true`; `this.dryRun` no existe. La opción para renombrar el flag en la línea de comandos es
`flagName`, no `name` (sin ninguna de las dos, `dryRun` → `--dry-run` sale solo por `dashCase`).

**Afectados (build/commands, alpha.8):**
- `authz_scopes_relay.js`: `dryRun` (`name: 'dry-run'`) ⇒ `--dry-run` **aplica**; `batchSize` (`name: 'batch-size'`), `waitLeaseMs`
  (`name: 'wait-lease-ms'`), `maxAge` (`name: 'max-age'`) ⇒ ignorados en silencio. `--only` y `--limit` no llevan `name` y funcionan.
- `authz_scopes_requeue.js`: `waitLeaseMs` (`name: 'wait-lease-ms'`) ⇒ ignorado; `--id`, `--force`, `--apply` funcionan
  (verificado: `requeue --id --apply` cierra el incidente, F-L2-16).
- Revisad el resto de comandos por el mismo patrón (`grep -n "name: '" build/commands/*.js`).

**Por qué importa para el cutover:** `--dry-run` es el paso "verificar antes de tocar" del runbook y hoy escribe; `--max-age` es la
alarma de edad que pedimos en el tercer informe y hoy nunca dispara desde el comando (la API `report.queue.pendingAgeMs` sí funciona:
nuestro job la usa). Un test que lo fije: crear el comando con `['--dry-run']`, `exec()`, y afirmar `applied_at IS NULL` en la tabla —
un test que ponga `cmd.dryRun = true` a mano no lo detecta.

**Mientras tanto** usamos la API (`relayScopeChanges({ dryRun: true })`, `queue.pendingAgeMs` en el job) y el runbook de L4 no
apoyará ningún paso en esos flags hasta la alpha que lo corrija.
