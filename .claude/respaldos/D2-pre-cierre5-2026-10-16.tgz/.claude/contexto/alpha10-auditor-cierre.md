# `2.4.0-alpha.10`: re-ataque del auditor al CIERRE (sin commitear)

## Veredicto en una línea

**Seguro con reservas.** No hay 🔴 ni 🟠. R1 queda cerrado a nivel de import y R2 es atómico de verdad. Quedan dos 🟡 con repro: el límite de identidad de R4, que no está declarado, y una letra falsa de `--only` que el cierre copió a `--dry-run`. Hay además higiene ⚪, con dos repros.

Repro: `.claude/reproducciones/alpha10-cierre-reataque.spec.ts`. Runner propio, SQLite `:memory:`, no toca `tests/`:
`env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec .claude/reproducciones/alpha10-cierre-run.ts`

**Resultado: 7/7 verdes.**
- 5 casos «DEFECTO»: defecto presente.
- 2 casos «CONTROL»: resisten.

Comprobé que el spec sabe fallar. En una copia temporal (ya borrada) invertí 4 aserciones (R4, R3 ×2 y LIKE) y salieron 4 rojos.

---

## Hallazgos (ordenados por severidad)

### 🟡 C1 · R4: la identidad es la de la FACTORY, no la del backend. Dos factories distintas que construyen el mismo store activo pasan el guard, y el límite no está declarado

- **Escenario**
  - Precondición: el driver de relaciones activo es `openfga`. El config registra además un alias escrito como se escriben los configs, con otra arrow y el mismo cuerpo: `fga: () => new OpenFgaRelationsDriver(cfg, { apiUrl: env…, storeId: env… })`. Es el mismo `OPENFGA_STORE_ID`, pero `f !== g`.
  - Acción: `runRelationsReconcile(authorization, { toKey: 'fga', fromKey: 'database', partitions, prune: true })`, o `authz:relations:reconcile --to=fga --from=database --prune`.
  - Resultado: la compartición retirada resucita en el store activo, `--prune` borra la creada después del cutover y no aparece `staleSource`. Con `toKey: 'openfga'` la misma pasada se niega.
  - El gemelo de roles (`#sameDriver`, `src/manager.ts:2294`) tiene el mismo límite: `drivers: { openfga: () => new OpenFga…(…), fga: () => new OpenFga…(…) }` hace pasar `--to=fga --from=database`.
- **Evidencia**
  - ✅ `commands/authz_relations_reconcile.ts:83`: `sameDriver = a === b || factory(a) === factory(b)`.
  - ✅ Repro «R4 cierre» en verde.
  - ✅ El README (`:660`), el CHANGELOG (`:108`) y CLAUDE.md dicen «two keys that point at the same factory are the same driver» y «an alias of the active one is refused too». Ninguno dice que un alias con otra factory **no** se detecta. La tabla de 24 filas construye el alias con la misma referencia (`{ activo: f, alias: f }`), que es justo la única forma cubierta.
- **Steelman del defensor**: «El paquete no puede saber que dos factories apuntan al mismo backend sin construirlas (y el cierre promete no construir nada antes del guard). Un alias es una configuración rara».
  - Me convence para 🟡, no para no declararlo. «An alias of the active one is refused» se lee como garantía general, y la forma natural de escribir un alias en un config de Adonis es una arrow nueva. Es el mismo tipo de límite que R5, y R5 sí se declaró.
- **Mitigación mínima**: una frase en el README, el CHANGELOG y el docblock: «identity is the factory reference; two factories that build the same backend are NOT detected». Opcional para 2.5: una identidad declarada por el driver (`capabilities.backendId`) o el sello durable de R5.

### 🟡 C2 · `--only` más allá de `--limit`: «#b no estaba ni pendiente ni aparcado… o no existe» con #b PENDIENTE, en `--dry-run` (línea nueva del cierre) y en la pasada que aplica (S6, exit 0)

- **Escenario**
  - Precondición: dos entradas pendientes, #a y #b.
  - Acción: `authz:scopes:relay [--dry-run] --only=a,b --limit=1`, o la receta inline `{ only, limit: 1 }` que el propio README cita (`:146`) con un recibo de más de un id.
  - Resultado: `[warn] #b no estaba ni pendiente ni aparcado: ya lo aplicó otra pasada, o no existe.`
    - En la pasada que aplica, además, sale `[success] 1 cambio(s) propagado(s)` con exit 0. La línea genérica «Quedan cambios pendientes» no nombra #b.
    - Es la pregunta que S6 decía responder («¿aterrizó LO QUE PEDÍ?»), respondida en falso.
- **Evidencia**
  - ✅ `src/manager.ts:1248-1267`: `pending(limit, …, filter)` y `missingOf(seen)` meten en `missing` todo lo que queda fuera del lote.
  - ✅ La pasada que aplica tiene el mismo cálculo sobre `entries` (`:1627`).
  - ✅ `commands/authz_scopes_relay.ts`: la rama `dryRun` ahora imprime esa línea por id (cierre R3).
  - ✅ Repro «R3 cierre» en verde en las dos variantes. La salida literal está en el rojo de control: `"#2 no estaba ni pendiente ni aparcado … o no existe"` con `applied_at IS NULL`.
- **Steelman del defensor**: «Con `--limit` 10 000 por defecto nadie pide más ids que el límite; y `remaining: true` avisa».
  - Me convence para 🟡, no para ⚪. El cierre R3 prometía «misma letra por id que la pasada que aplica», y la copió con su defecto. La receta inline con `limit: 1` existe en la documentación.
- **Mitigación mínima**: si el lote alcanzó `limit`, los ids no vistos no son `missing` sino «no evaluados (límite)». En el reporte: `missing` solo para lo que no está en la cola, que es un `pending(…, filter)` sin límite o un conteo. En la letra, nombrarlos y dar exit ≠ 0 bajo `--only`.

### ⚪ C3 · R2: el `WHERE` (SQL `LIKE`) y `freezeKindOf` (JS) no clasifican igual. Resultado: 423 «freeze VIVO» sobre una fila caducada, y distinto según el motor

- **Escenario**
  - Precondición: una fila caducada con holder `OPERATOR:1:ab` o `opérator:…`. Solo es posible a mano o con datos importados: `freeze()` siempre escribe `operator:` en minúsculas.
  - Acción: `freeze()` o cualquier reconcile.
  - Resultado por motor:
    - SQLite (`LIKE` insensible a mayúsculas en ASCII) y MySQL (collation `_ai_ci`): el `UPDATE` la excluye. `freezeKindOf` la clasifica como `unknown`, se reintenta una vez y el resultado es `held` ⇒ 423 «ya hay un freeze **VIVO** de otro dueño» sobre una fila caducada, en todas las pasadas, hasta que alguien ejecute `authz:unfreeze`.
    - PostgreSQL (`LIKE` sensible a mayúsculas): la toma.
  - Tres motores, dos respuestas, y la letra miente sobre la rama que corrió.
- **Evidencia**
  - ✅ `src/freeze.ts:236` frente a `:330-331` y `:252-254`: tras el reintento devuelve `held` aunque la fila no esté viva.
  - ✅ Repro «LIKE» en verde en SQLite.
  - ❓ PG y MySQL no ejecutados, por la restricción de BD compartida. El razonamiento se apoya en la semántica documentada de `LIKE` y de las collations.
- **Steelman del defensor**: «Nadie escribe esos holders».
  - Me convence: por eso es ⚪.
- **Mitigación mínima**:
  - En el `WHERE`, `substr(freeze_holder, 1, 9) = 'operator:'`, sensible a mayúsculas en los tres motores; en MySQL con `BINARY`.
  - Tras el reintento, si la fila no está viva, no devolver `held` con la letra «VIVO».

### ⚪ C4 · El token `'?'` es ambiguo: significa «holder NULL», pero una fila con holder LITERAL `'?'` queda sin salida (una variante del ⚪ 5 que el cierre decía cerrar)

- **Escenario**: una fila caducada con `freeze_holder = '?'`, escrita a mano. `lastFreezeStatus` publica `holder: '?'` y `unfreeze({ holder: '?' })` busca `row.holder === null`, así que nunca casa. `authz:unfreeze` responde «La fila NO se ha limpiado: … otro proceso la cambió y ahora es ? (…, CADUCADA)» con exit 1, en bucle. Además, la letra afirma un cambio que no ocurrió.
- **Evidencia**: ✅ `src/freeze.ts:313-314`. Repro «holder LITERAL `?`» en verde, dos pasadas.
- **Steelman del defensor**: «`freeze()` jamás escribe `'?'`».
  - Me convence: ⚪. Pero es exactamente la clase de fila (legada o manual) que motivó el ⚪ 5.
- **Mitigación mínima**: casar `'?'` con `holder IS NULL OR holder = '?'`, o publicar la fila NULL con un centinela que no pueda ser un string válido.

### ⚪ C5 · La guardia de superficie de R1 compara identidad, no alcance. No es la prueba de «ninguna vía pública al primitivo sin guard»

- **Escenario** (hipotético):
  - Un `export const x = reconcileRelations.bind(null)`, un wrapper `(o) => reconcileRelations(o)` o un objeto `{ internals: { reconcileRelations } }` en cualquier subpath pasan la guardia en verde.
  - Hoy ya existe un wrapper público sin guard: `runRelationsReconcileContract` (`./testing`, `relations_reconcile_contract.ts:30,169-277`).
- **Evidencia**:
  - ✅ `tests/command_flags.spec.ts:984-989` recorre solo los valores de primer nivel con `notStrictEqual`.
  - ✅ Probé a escapar del mapa `exports`: `…/commands/../src/relations/reconcile`, `%2e%2e` y `…/build/src/relations/reconcile.js`. Node 22 devuelve `ERR_INVALID_MODULE_SPECIFIER` o `ERR_PACKAGE_PATH_NOT_EXPORTED`: el mapa resiste.
- **Steelman del defensor**: «El harness siembra particiones uuidv7 propias y solo hace prune dentro de ellas; y la guardia es un detector de regresión, no una prueba».
  - Me convence. El harness no es un vector: su `prune` se limita a su partición sembrada. Y la capacidad de hacerlo a mano (`enumerateRelations` + `relate` sobre un driver) siempre ha sido pública.
  - Pero el informe dice «no expone el primitivo (la guardia recorre `./testing` por identidad)», y esa frase depende de la identidad, no del alcance.
- **Mitigación mínima**:
  - Complementar con una guardia por fuente: ningún módulo alcanzable desde `exports`, salvo `commands/authz_relations_reconcile` y el harness declarado, importa `relations/reconcile.js`.
  - O cambiar la letra a «detecta el re-export directo».

### ⚪ C6 · `relationsDriverFactory(key)`, `relationsDriverKeys()` y la firma `Pick<…>`: una salida de plataforma nueva sin declarar

- **Escenario**:
  - Cualquier código con el manager, incluidas las vistas `forRequest()`, puede construir un driver de relaciones **no activo** y escribir en él sin `assertWrite`, `requireActor`, freeze ni `onRelationWrite`.
  - `runRelationsReconcile` acepta cualquier objeto estructural: un `{ …authorization, relationsDriverKey: () => 'database' }` vuelve a meter la etiqueta del llamante.
- **Evidencia**:
  - ✅ `src/manager.ts:743-763` y `commands/authz_relations_reconcile.ts:40`.
  - El README declara `driver()` como «platform API, grep for it», pero no nombra los dos métodos nuevos.
- **Steelman del defensor**: «`RelationsManager.driver()` ya da el activo sin barreras y `app.config` da las factories; falsificar el `Pick` es deliberado, no un error de copiar y pegar».
  - Me convence: no añade capacidad real. Solo se pierde el «grep for `driver()`» como control de revisión.
- **Mitigación mínima**: nombrarlos junto a `driver()` como API de plataforma en el README.

### ⚪ C7 · Higiene y letra

1. **Aserción débil en el caso TOCTOU** (`freeze.spec`, «cierre · R2»): acepta `E_AUTHZ_FREEZE_HELD` o `E_AUTHZ_OPERATOR_WINDOW_EXPIRED`. Un mutante que devolviera 423 donde toca 503 pasaría. Lo cubre el caso del primitivo, así que no es un agujero de cobertura, pero el caso de `freeze()` no fija la rama.
2. **`RelationsReconcileOptions` sigue exportado desde la raíz** (`index.ts:187`, solo tipo), con `from`/`to` obligatorios. Describe una API que ya no es pública e invita a `as any`.
3. **`README.md:38`** (preexistente, no del cierre): sigue listando `importAuthzFactsToOpenFga` y `openFgaAuthorizationModel` en el subpath `/openfga`, y los dos se borraron en 3b-2k (`src/openfga.ts:33`).

---

## Lo que intenté y NO se rompió

- **R1, escape del mapa `exports`**: `..`, `%2e%2e` y la ruta `build/` directa fallan en Node 22.23.
- **R1, re-exports**:
  - `services/relations`, `authz_provider`, `commands/main` y los `./commands/*` no re-exportan el primitivo.
  - `RelationsManager` no tiene ningún método de reconcile.
  - El único import de producción del primitivo es `commands/authz_relations_reconcile.ts:50`, y va después del guard.
- **R1, opciones**: `...rest` solo transporta `partition(s)`, `dryRun`, `prune`, `allowMassDelete`, `toConfig` y `now`, y ninguna decide la dirección. `from`/`to`/`activeKey` dan 500. `allowStaleSource: 'true'` (string) y `dryRun: 'yes'` fallan hacia el lado cerrado en el guard.
- **R4, casos de borde**:
  - `toKey: '__proto__'` o `'constructor'` resuelven a `undefined` por `hasOwnProperty` y dan 500.
  - Un activo que no es clave de `relations.drivers` hace que el provider no sirva relaciones, así que no hay riesgo de dirección rancia.
  - Ningún driver se construye antes del guard.
  - El comando, con `{ openfga: f, fga: f }` y `--to=fga` sin `--from`, responde 500 CONFIG («misma factory»).
- **R4, gemelo de roles**: con la misma referencia, el guard, el mantenimiento, `from === to` y el descarte usan `#sameDriver`.
- **R2** (controles en verde, SQLite):
  - Pasada muerta caducada: se toma.
  - Holder NULL caducado: se toma.
  - Operador caducado: `expired-operator`.
  - Operador con `untilMs === now`: `expired-operator`, porque `freezeIsLive` (`>`) y el `WHERE` (`<=`) coinciden en el borde.
  - `freeze()` ya lee el reloj una sola vez.
  - La adopción de una ventana de operador que vence a mitad de la pasada queda cubierta por `lapsed` (`#tokenLapsed` relee la fila).
- **Token `'?'`**:
  - No levanta una ventana viva con holder real (`whereNull` en la lectura y en el `UPDATE`).
  - Tras tomar una fila NULL, un `'?'` con el fence viejo no toca la ventana nueva (`fence + 1`).
  - No da ningún poder que `freezeStatus()` + `unfreeze` no dieran ya: el token es fencing, no autenticación.
- **Runbook**:
  - Las verificaciones con `--from` van antes del switch y después solo la de mantenimiento.
  - `openfga` declara siempre `hierarchyFacts: true` (`openfga_driver.ts:623`), así que la verificación posterior no cae en «rancia».
  - Relaciones declara que no tiene mantenimiento.
- **Salidas del comando de relaciones**: 500 CONFIG, STALE, HELD y `OPERATOR_WINDOW_EXPIRED` salen como error con exit 1.
- **Regresiones**:
  - Los 4 ajustes de `freeze.spec` a la firma nueva no relajan nada, salvo C7.1.
  - `relationsAce` parchea los tres lectores con un manager real construido desde el config del fixture. En producción el comando y el provider usan el mismo manager de `services/main`, así que el parche no oculta una divergencia.
- **CHANGELOG**: las rupturas del cierre están nombradas: salida de la raíz, opciones nuevas, el 503 nuevo de `freeze()`, `unfreezePlan` y `report.frozen`.

## Preguntas abiertas para el arquitecto

1. **C1**: ¿basta con declarar que la identidad es la referencia de la factory, o se quiere una identidad de backend declarada por el driver en 2.5, junto al sello de R5?
2. **C2**: ¿`missing` debe distinguir «no está en la cola» de «no evaluado por `limit`»? Afecta a la API (`ScopeRelayReport`) y a la receta inline.
