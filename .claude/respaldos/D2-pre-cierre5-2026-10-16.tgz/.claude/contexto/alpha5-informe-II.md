# `2.4.0-alpha.5` — informe del implementador II (R2b + R0 + garantías) · INCREMENTAL

**Base:** HEAD `5547fa4` = `2.4.0-alpha.4` + el lote I SIN commitear (R2a + R1, `alpha5-informe-I.md`), verificado por el
coordinador en **1204 / 1228 / 1323 / 1323** con el `:8101`. Especificación: `alpha5-lote-II-spec.md`. Sin commits, sin
subir `version`, nada del lote I descartado. `$S` = `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`.
Todo caso suelto: `node --import @poppinss/ts-exec bin/test.ts --files=<spec>`; corridas en PRIMER plano y en secuencia.

Orden seguido, el de la spec: **R2b → R0 → garantías**.

---

## 0 · Hallazgo previo (para el coordinador)

`relay-auditor-5.ts` **tal cual ya no muestra la reversión** sobre el árbol del lote I (`$S/a5II_r2b_red_repro.log`:
«⇒ sin reversión»): el tapón por clave de R2a aplaza el segundo `moved(unit → orgC)` mientras el primero está
aparcado, así que al reencolar #1 la pasada aplica los dos EN ORDEN y converge en orgC. La forma peligrosa sigue viva
por dos puertas que R2a no cierra: (1) una cola heredada de alpha.4 —aparcada #1 y aplicada posterior #2 con la misma
clave, que es el estado que COGNITIV tiene hoy en producción—, y (2) un `detached` posterior, que pasa el tapón a
propósito (invariante 11) y cuyo `requeue` del `attached`/`moved` anterior resucitaría la arista de un nodo purgado.
Por eso el ROJO de R2b se construye con ese estado de filas (la sonda tiene que cazarlo venga de donde venga), no
corriendo la repro.

## 1 · R2b · `authz:scopes:requeue --id` (PRIMERO)

| Fichero | Qué |
|---|---|
| `src/types.ts` | `ScopeOutbox.requeue?(ids)` y `ScopeOutbox.laterApplied?(id, scopes, limit)` (espejo de `earlierPending`), opcionales; `ScopeRequeueConflict` `{ parked, applied[] }` y `ScopeRequeueReport` `{ requeued, overrides, forced }`. |
| `src/errors.ts` | `ScopeRequeueRefusedError` (500 `E_AUTHZ_REQUEUE_REFUSED`) con `conflicts` (el diff). |
| `src/scope_outbox.ts` | `laterApplied` (aplicadas con `id >` que nombran hijo o padre, raíz como `app` con uuid nulo, orden de id, `limit`); `requeue` todo o nada: SELECT de comprobación (existe, sin aplicar, `attempts >= maxAttempts`) ⇒ 500 nombrando los ids malos ANTES de tocar nada; `UPDATE attempts = maxAttempts − 1` con los mismos predicados; relectura y 500 si la cola cambió entre medias. `last_error` se conserva. |
| `src/manager.ts` | `requeueScopeChanges(ids, { force })`: exige `dead`/`requeue`/`laterApplied` (500 `E_AUTHZ_UNSUPPORTED` nombrando el que falte); censo `dead(DEFAULT_RELAY_LIMIT)` ⇒ un id que no está aparcado es 500 `E_AUTHZ_CONFIG` (todo o nada); sonda por aparcada contra `laterApplied` con sus claves ⇒ `ScopeRequeueRefusedError` con el diff y el remedio (`authz:reconcile`); `force: true` salta la sonda y devuelve `overrides`. No pasa la barrera del freeze (no escribe en el backend). |
| `commands/authz_scopes_requeue.ts` | `--id` (array, coma o repetido; `parseIds` estática; sin `--id` ⇒ error + exit 1, jamás «reencola todo») y `--force`; `requeueLines()` PURA: la negativa imprime el DIFF (aparcada + cada aplicada posterior que revertiría) con las dos salidas y sale 1; con `--force` el diff sale como AVISO y el éxito dice `maxAttempts − 1`. |
| `commands/main.ts` · `tests/commands.spec.ts` | Décimo comando en el loader (`TEN`, conteos 9→10 y 11→12). |
| `index.ts` | Exporta `ScopeRequeueRefusedError`, `ScopeRequeueConflict`, `ScopeRequeueReport`. |
| `README.md` | Párrafo «Requeueing a parked entry», línea en el bloque bash, lista del puerto (cinco opcionales) y fila `E_AUTHZ_REQUEUE_REFUSED`. |
| `tests/scope_outbox.spec.ts` | Grupo «alpha.5 · R2b» (9 casos) + grupo del comando (2) + letra README (1): 72 → 87 sin `OPENFGA_TEST_URL`. |

| | |
|---|---|
| **ROJO** (`$S/a5II_r2b_red.log`) | 12 rojos / 75 verdes intactos (`requeueScopeChanges is not a function`, `laterApplied is not a function`, el comando no existe, el README no lo dice). |
| **VERDE** (`$S/a5II_r2b_green.log`, `$S/a5II_r2b_commands.log`) | 87/87 y 25/25. |
| **MUTANTE 1** — sin sonda (el manager reencola sin mirar `laterApplied`; `$S/a5II_r2b_mut1_nosonda.log`) | 2 rojos: **EL CASO (auditor 🔴 2) «debería haber lanzado»** y el diff de `force` vacío. |
| **MUTANTE 2** — `attempts = 0` en vez de `maxAttempts − 1` (`$S/a5II_r2b_mut2_attempts0.log`) | 3 rojos: «le queda UN intento, ni cero ni los tres: expected +0 to equal 2», **el grifo: «vuelve a estar aparcada: UNA pasada, no cinco: expected [] to deeply equal ['553']»**, y el caso del puerto. |

Casos: 2-1/2-2 (vuelve a `pending()` con su id, `attempts = max − 1`, sale de `dead()`, la pasada siguiente la aplica);
EL CASO del auditor (aparcada #1 `moved → orgB` + aplicada #2 `moved → orgC` ⇒ 500 nombrando #2 y la clave, cero filas
tocadas, cero llamadas al driver); 2-9b inverso (aplicada posterior sin clave compartida ⇒ entra, sin diff); `force`
(entra, `overrides` con el diff, y la pasada hace la reversión pedida); el grifo (padre inexistente: se intenta UNA vez,
la purga del padre se aplaza por el FALLO en esa pasada —`depends-on:`, no `parked:`— y entra en la siguiente; tercera
pasada sin fallos ni intentos: no hay bucle); 2-3/2-4/2-6 (inexistente / pendiente viva / ya aplicada / lote mixto ⇒
500 nombrando el id, snapshot de la tabla idéntico; `[]` y no-lista ⇒ 500; el puerto solo también se niega); terceros
sin `requeue` ⇒ 500 `E_AUTHZ_UNSUPPORTED`, con `requeue` sin `laterApplied` ⇒ 500 nombrando la sonda y cero reencolados;
sin outbox ⇒ 500 `E_AUTHZ_CONFIG`; el puerto SQL (`laterApplied` por hijo/padre/raíz, ignora anteriores, pendientes y
aparcadas, `limit`; `requeue` ⇒ `attempts = 2` con `maxAttempts: 3` y un fallo más la aparca de nuevo).

## 2 · R0 · Docs y profundidad (DESPUÉS de R2b)

| Fichero | Qué |
|---|---|
| `src/define_config.ts` | `scopes.maxDepth?: number` (docblock: profundidad = saltos `parent` hasta `app`; PARCIAL; el mismo mando que usa reconcile). |
| `src/errors.ts` · `index.ts` | `ScopeDepthLimitError` **422 `E_AUTHZ_SCOPE_DEPTH_LIMIT`** (ver §5, contradicción 1: la spec decía `E_AUTHZ_SCOPE_TOO_DEEP`, que ya existe con 500 y otra semántica). |
| `src/manager.ts` | `#assertDepth(chain, child, parent, op)` dentro de `#assertEdge`, tras el anti-ciclo: `chain.length > maxDepth` ⇒ 422 con la letra (saltos, techo, remedio); opción no entera ≥ 1 ⇒ 500 `E_AUTHZ_CONFIG` nombrando `scopes.maxDepth`; cero I/O (la cadena del padre ya está). `reconcile()` pasa `maxDepth` al driver en `ReconcileSource`. |
| `src/types.ts` | `ReconcileSource.maxDepth?`; `ReconcileReport.drift.tooDeep?: string[]` + `tooDeepLimit?: number` (opcionales: un driver de terceros que no lo calcule no rompe). |
| `src/drivers/openfga_driver.ts` | En `reconcile`, tras `chainOf`: `reconcileMaxDepth(source.maxDepth)` (= `FACTS_MAX_RESOLVE_DEPTH` sin config) y `tooDeep` = claves del origen con `chain.length − 1 > techo`, ordenadas. |
| `commands/authz_reconcile.ts` | Una línea `error` por scope en `tooDeep` (techo + «503, nunca false») y **`clean = false`** (deriva: legal en `database`, un 503 en `facts`; va a CI). |
| `README.md` | **`### Limits`** (tabla de 13 filas atada a las constantes: `FACTS_MAX_RESOLVE_DEPTH` 22, `scopes.maxDepth`, `FACTS_MODEL_MAX_BYTES` 262,144, `FGA_MAX_BATCH_CHECK` 50, `Read` 100, **`enumerateRelations` O(tuples in the store) + «never from a tenant request» + el barrido único en 2.5**, `DEFAULT_RELAY_BATCH`/`LIMIT`, `maxAttempts` 5, `maxScopes`, `maxDescendants`, `maxLocalRoles`, `maxDepth` del resolver) + párrafo del gate declarado **partial** con esas palabras; línea «How deep can the tree go?» en «The scope tree» con enlace `#limits`; `maxDepth: 22` en el snippet de config; filas `E_AUTHZ_SCOPE_DEPTH_LIMIT` y `E_AUTHZ_CONFIG`. |
| `tests/scope_depth.spec.ts` (NUEVO, 7 casos) | 4-1/4-2 letra atada a 9 constantes importadas; 4-4 el 22 entra; 4-3 el 23 ⇒ 422 antes de escribir/encolar (cero llamadas, cero filas) en `attached` y `moved`, y el `moved` a destino somero entra; 4-5 sin la opción un árbol de 40 es legal; el gate es PARCIAL (la hoja queda a 23 y no lo ve: fijado, no adivinado); `maxDepth` inválido ⇒ 500; 4-6 `reconcileLines` con `tooDeep` ⇒ error + no limpio, vacío/ausente ⇒ limpio. |
| `tests/reconcile.spec.ts` (+1, `:8101`) | Árbol en memoria de 23 saltos ⇒ `drift.tooDeep = [el nodo 23]`, `tooDeepLimit 22`, exit 1; `source.maxDepth: 30` ⇒ vacío; por el manager con `scopes.maxDepth: 23` ⇒ vacío y `tooDeepLimit 23`. |

| | |
|---|---|
| **ROJO** (`$S/a5II_r0_red.log`, `$S/a5II_r0_red_reconcile.log`) | 4 rojos / 3 verdes en el spec nuevo (sin `### Limits`, 23 no lanza, `maxDepth` inválido no lanza, `clean` verde con `tooDeep`); 1 rojo / 69 verdes en reconcile (`tooDeep` undefined). |
| **VERDE** (`$S/a5II_r0_green.log`, `$S/a5II_r0_green_reconcile.log`) | 7/7 y 70/70 (con `:8101`). |
| **MUTANTE 3** — `>=` en el gate (`$S/a5II_r0_mut3_gte.log`) | 1 rojo: 4-4 «un hijo a 22 saltos ENTRA» lanza `E_AUTHZ_SCOPE_DEPTH_LIMIT` a 22. |
| **MUTANTE 4** — `FACTS_MAX_RESOLVE_DEPTH = 23` sin tocar el README (`$S/a5II_r0_mut4_const23.log`) | 1 rojo: «expected … to include '\| `FACTS_MAX_RESOLVE_DEPTH` \| 23 \|'» — la tabla es contrato, no documentación. |
| **MUTANTE 5** — `tooDeep` fuera de `clean` (`$S/a5II_r0_mut5_notclean.log`) | 1 rojo: 4-6 «expected true to be false». |

Semántica fijada: profundidad de un scope = saltos `parent` hasta `app`; la cadena del padre incluye `app`, así que la
profundidad del hijo es `chain.length` del padre. Con `maxDepth: 22`, TODA pregunta queda dentro de la cota medida sea
cual sea el ancestro que lleve el binding (la medida de `openfga_facts.spec` son 22 saltos entre el scope preguntado y el
que tiene el grant; con el grant en `app` serían 22 hasta la raíz: es la lectura conservadora, y va escrita).

## 3 · Garantías no observadas (AL FINAL)

### 3.1 · Escritor único entre PROCESOS (`tests/scope_outbox_multiprocess.spec.ts` + `helpers/relay_child.ts`)

Patrón de `freeze_multiprocess.spec.ts`: el padre encola UNA entrada con `sqlScopeOutbox`, toma `acquire()` a mano y
DESPUÉS lanza al hijo (`execFileSync`, `bootApp({ reuse })`, su propia outbox y su propio manager con driver espía), que
hace una pasada y devuelve `{ busy, applied, calls }`. Gateado a pg/mysql/sqlite-file, con la declaración en cabecera
de que `:memory:` no puede observarlo.

| | pg | mysql | sqlite-file |
|---|---|---|---|
| 5-1 control (sin lease) ⇒ el hijo aplica | ✔ | ✔ | ✔ |
| 5-2/5-3 lease sostenido ⇒ hijo `busy`, `applied: []`, `calls: []`, fila sigue pendiente; soltado ⇒ aplica | ✔ (`$S/a5II_r6_pg_green.log`) | ✔ (`$S/a5II_r6_mysql_green.log`) | — |
| 5-4 el cerrojo es de PROCESO: el hijo aplica pese al lease, y el README lo dice («a process-wide one on SQLite», «SQLite is not the engine for two replicas of the relay») | — | — | ✔ (`$S/a5II_r6_sqlitefile_green.log`) |

**MUTANTE 6** — «advisory lock → `Set` de proceso» en todos los dialectos (`if (true \|\| …)` en `acquire`): en pg,
**multiproceso 1 rojo** («el lease es del SERVIDOR: alcanza al otro proceso: expected false to be true»,
`$S/a5II_r6_mut6_pg.log`) y **`scope_outbox.spec.ts` en proceso 87/87 VERDE** (`$S/a5II_r6_mut6_pg_inprocess.log`):
exactamente el punto ciego del tester, medido.

### 3.2 · `GET_LOCK` con nombre estable y transición

`scopeOutboxLockNames(connection, table)` ⇒ `{ legacy: slice(0, 64), current: 'authz_scope_outbox:' + sha1(nombre completo) }`
(59 chars, estable, exportada). `acquire()` en MySQL toma `current` Y `legacy`; si cualquiera falla suelta lo tomado y es
`busy`; `release` suelta los dos. PG no cambia (ya era `hash32` del nombre completo). Grupo «alpha.5 · R6 — GET_LOCK» en
`scope_outbox.spec.ts` (3 casos; 2 gateados a MySQL): (1) puro: dos tablas con los mismos 64 primeros chars comparten
`legacy` y NO `current`, `current` ≤ 64 y estable; (2) MySQL: con el lease tomado `IS_USED_LOCK` de los DOS es no nulo y
una segunda `acquire()` es null; soltado, los dos nulos; (3) MySQL: otra sesión con SOLO el lock viejo (un relay de
alpha.4) ⇒ `acquire()` es null y no deja el nuevo tomado a medias; soltado, entra.

VERDE mysql 90/90 (`$S/a5II_r6_getlock_mysql_green.log`). **MUTANTE 7** — solo el lock nuevo: **2 rojos** («y el viejo
TAMBIÉN: un proceso de alpha.4 tiene que verlo», «alpha.5 ve el lock viejo y no entra: expected { release } to equal
null», `$S/a5II_r6_mut7_onlynew_mysql.log`). Incidencia: la primera corrida del mutante colgó el teardown (el caso 3
dejaba un lease tomado si `acquire()` devolvía uno) — el caso libera ahora lo que reciba en `finally`; se mató el
proceso, se restauró el fichero y se borró a mano la base `authz_test_e0f9ba51`.

### 3.3 · `runScopeOutboxContract` en `/testing` (`src/testing/scope_outbox_contract.ts`)

Harness `{ name, capabilities, makeOutbox, cleanup?, limits?: { maxAttempts }, transactions?: { begin } }`; 7 casos del
núcleo (O-01…O-07) + 7 pares (`transactionalEnqueue`, `filter`, `transient`, `dead`, `acquire`, `earlierPending`,
`requeue`) = **14 por harness**; `registerScopeOutboxContract` cuenta y lanza al registrar si una cara falta, si `dead`
llega sin `maxAttempts ≥ 3`, si `requeue` llega sin `dead`, si `transactionalEnqueue` llega sin `transactions`, o si una
capacidad no es booleana. Doble `makeScopeOutbox({ capabilities, maxAttempts })` que expone SOLO lo declarado. Exportado
desde `src/testing/main.ts`; README «The outbox contract: `runScopeOutboxContract`».

`tests/scope_outbox_contract.spec.ts`: `sqlScopeOutbox` (todo `true`, `transactionalEnqueue` con `db.transaction()`,
también en `:memory:`) + doble full + doble mínimo ⇒ **42 casos**. `tests/scope_outbox_harness.spec.ts` (4 casos):
`EXPECTED_CASES = 14`, 7 cubiertas, caras distintas, rechazos al registrar.

| | |
|---|---|
| **ROJO de diseño** (primera corrida, `$S/a5II_r5_green.log` antes de corregir) | 5 rojos que enseñaron algo del propio contrato: la RAÍZ `app` también es clave — dos `attached` bajo `app` se contaminan entre sí—, así que un caso de «independencia» tiene que usar claves de verdad independientes (`detached` de units sueltas). Corregido en O-07 y en `filter:true/false`; anotado en el mapa. |
| **VERDE** (`$S/a5II_r5_green.log`, `$S/a5II_r5_harness_green.log`) | 42/42 y 4/4 (sqlite). |
| **MUTANTE 8** — el doble ignora `after` (`$S/a5II_r5_mut8_double_after.log`) | 3 rojos (O-03 en los dos dobles + `filter:true`): el runner caza un defecto de TERCEROS. |
| **MUTANTE 9** — `laterApplied` de `sqlScopeOutbox` sin `whereNotNull('applied_at')` (`$S/a5II_r5_mut9_sql_laterApplied.log`) | Sobrevivió a la primera versión del caso (no había pendiente posterior con clave compartida); el caso se endureció (una `moved` PENDIENTE posterior que comparte `unit`) y ahora **1 rojo** («expected ['29','30'] to deeply equal ['29']»). |

## 4 · Docs

CHANGELOG `[Unreleased] — 2.4.0-alpha.5`: cabecera ampliada y bloque «Decisions (lot II)» con R2b, Limits, `scopes.maxDepth`
+ `drift.tooDeep`, multiproceso, `GET_LOCK` (con la nota de retirar el viejo en 2.5), `runScopeOutboxContract`; «What did
not change» ampliado con lo NO hecho. `CLAUDE.md`: cabecera (lotes I y II), regla de higiene de la outbox (iv)–(vii),
párrafo de cotas (Limits + `maxDepth`), mapa (`scope_outbox.ts`, `src/testing/scope_outbox_contract.ts` NUEVO, `commands/`
diez, errores). `roadmap-2.0.md`: sección «2.5 · Pendientes del panel relay» (barrido único de `enumerateRelations`,
retirar el lock viejo, canal `driver.limits`).

## 5 · Verificación final (4 modos, `:8101`, en primer plano y en secuencia)

`npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ (`$S/a5II_final_typecheck.log`; dos tipos de tests corregidos
antes: un `any` en el caso de `requeueLines` y el recibo `void | { id }` en el spec multiproceso) · `npm run check:purity` ✔
· `npm run build` ✔ (`$S/a5II_build.log`; `build/commands/authz_scopes_requeue.js` y `build/src/testing/scope_outbox_contract.js`
existen).

| modo | base (lote I) | **ahora** | Δ | exit | duración | log |
|---|---|---|---|---|---|---|
| sqlite `:memory:` | 1204 | **1271 / 1271** | +67 | 0 | 88 s | `$S/a5II_final_sqlite.log` |
| sqlite-file | 1228 | **1297 / 1297** | +69 | 0 | 86 s | `$S/a5II_final_sqlitefile.log` |
| pg | 1323 | **1392 / 1392** | +69 | 0 | 129 s | `$S/a5II_final_pg.log` |
| mysql | 1323 | **1394 / 1394** | +71 | 0 | 130 s | `$S/a5II_final_mysql.log` |

Δ desglosado: `scope_outbox.spec` +13 (R2b 9 + comando 2 + letra 1 + `GET_LOCK` puro 1; +2 más en mysql), `scope_depth.spec`
+7, `reconcile.spec` +1, `scope_outbox_contract.spec` +42 (14 × 3), `scope_outbox_harness.spec` +4,
`scope_outbox_multiprocess.spec` +2 (pg/mysql/sqlite-file). Aditivo: ningún caso borrado ni saltado. Sin bases huérfanas
(las cuatro corridas hicieron `teardown`; la del mutante colgado se borró a mano).

## 6 · Lo que NO hice (a propósito)

- Filtro por tenant; `dead` como contador; `next_attempt_at`/backoff; columna nueva o migración de `authz_scope_outbox`.
- Retirar el lock VIEJO de MySQL (2.5, CHANGELOG + roadmap); barrido único de `enumerateRelations` (2.5); canal
  `driver.limits` (2.5, decisión del dueño).
- Medir la altura del subárbol movido en el gate (prohibido: `descendantsOf` en el camino de escritura); el gate es PARCIAL
  y así se vende.
- Ejecutar `authz:scopes:requeue` por el kernel de ace real: como `relay`, va a `services/main.js` (manager del contenedor
  GLOBAL) y el harness sería bicéfalo (2.6, roadmap). Se fija por letra + `requeueLines` PURA + `parseIds`.
- Tocar el lease (por pasada), las reproducciones del auditor ni los prototipos del tester.

## 7 · Contradicciones / desviaciones respecto a la spec (PARA el coordinador)

1. **Código del error del gate**: la spec dice «422 `E_AUTHZ_SCOPE_TOO_DEEP`», pero ese código YA EXISTE en `errors.ts`
   (`ScopeTooDeepError`, **500**, `hierarchicalScopeResolver` superó `maxDepth`: «no se puede terminar una cadena que ya
   existe»). Reutilizarlo con 422 y otra semántica dejaría dos clases con el mismo `code` y distinto `status`. He seguido al
   JUEZ (cuestión 5, decisión 2, que lo dice explícitamente): **`E_AUTHZ_SCOPE_DEPTH_LIMIT`** (`ScopeDepthLimitError`, 422).
   Si el dueño prefiere el nombre de la spec, es un rename de una clase + README + tres casos.
2. **El caso «de 5 líneas» de `GET_LOCK` no puede ser verde durante la transición**: «dos tablas con los mismos 64 primeros
   chars NO comparten lease» exige NO tomar el lock viejo, y la transición (tomar los dos, que la spec y el juez recomiendan)
   hace que lo compartan por el `legacy`. He fijado lo que SÍ es cierto hoy: el nombre nuevo no colisiona (puro, en los 4
   modos) y en MySQL se toman los DOS (mutante 7) — y he escrito en README/CHANGELOG/roadmap que la colisión del viejo solo se
   cierra al retirarlo en 2.5. El caso observable «no comparten lease» se escribe entonces.
3. **`relay-auditor-5.ts` ya no es rojo tal cual** (§0): el tapón por clave de R2a lo neutraliza; el ROJO de R2b se construye
   con el estado heredado (aparcada + aplicada posterior) y con la variante del `detached`. La sonda sigue siendo necesaria
   por esas dos puertas, y así está escrito en el CHANGELOG.
4. **`drift.tooDeep` tumba la pasada (`clean = false`)**: el juez dice «reporta como deriva» y el tester 4-6 admite «avisar o
   abortar, pero fijado». Lo fijé como deriva (exit ≠ 0, como los ciclos) porque un scope legal en `database` y 503 en
   `facts` tiene que verse en CI; quien subió `OPENFGA_RESOLVE_NODE_LIMIT` sube `scopes.maxDepth` y el verificador le sigue
   (un solo mando, con caso). Si se prefiere solo aviso, es un cambio de una línea en `reconcileLines` + su caso.
5. **`requeueScopeChanges` NO pasa la barrera del freeze**: no escribe en el backend (solo cambia `attempts`); la pasada que
   aplique la entrada sí la pasa. No lo decía la spec; lo dejo escrito en el docblock por si el dueño quiere la barrera.
