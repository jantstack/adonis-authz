# Auditorías de sistema (M4) — registro de rotaciones

> Decisión: `panel-metodologia-juez.md` y `decisiones-dueno-2026-08-28.md` §2026-09-13 (4)/(5).
>
> **Reglas.** Sin diff: se audita el sistema publicado. Una pasada **por RC** y otra **tras cada grave que reporte
> COGNITIV**. Cada pasada usa una **perspectiva que no se haya usado antes** (tabla de abajo). La entrega es un **spec de
> repro** en `.claude/reproducciones/` (verde = defecto presente) que pasa a test al arreglarse, **nunca un APTA**. Una
> rotación con 0 rojos/naranjas nuevos no da permiso para publicar: solo significa que la siguiente espera a la próxima RC.
> Condición necesaria para la estable: la rotación sobre la RC termina con 0 🔴/🟠 abiertos (contando hallazgos con repro).

## Perspectivas

| Perspectiva | Usada en | Pregunta guía |
|---|---|---|
| Operador del cutover siguiendo el README al pie de la letra, después de servir | Rotación 1 | ¿Qué hace cada paso documentado cuando el mundo ya cambió (driver activo, ventana caducada)? |
| Consumidor que llama a las funciones exportadas sin pasar por los comandos (`index.ts`, `testing/*`) | — | ¿Qué guarda solo vive en el comando? |
| Incidente: backend caído una hora, proceso matado a mitad, pasada repetida | — | ¿Cada estado abortado/caducado/repetido deja al operador un paso siguiente cierto? |
| Multi-tenant hostil: otro tenant o otro despliegue en el mismo store/BD | — | ¿Qué recurso compartido (lock, store, clave raíz) cruza tenants? |
| Actualización entre versiones (alpha.N → alpha.N+1, 1.1.0 → 2.x) con datos vivos | — | ¿Qué fila, tupla o bandera antigua cambia de significado al subir? |
| Letra ↔ efecto: README, CHANGELOG, mensajes y códigos de salida | — | ¿Qué frase publicada es falsa en alguna rama? |

## Rotaciones

| # | Fecha | Sobre | Perspectiva | Auditor | Coste | Hallazgos | Repro | Estado |
|---|---|---|---|---|---|---|---|---|
| 1 | 2026-09-13 | `2.4.0-alpha.9` publicada (piloto) | Operador del cutover, README literal, después de servir | `auditor-seguridad` | ~15-20 min | 1 🔴 (S1 relaciones: dirección rancia sin `--from`), 2 🟠 (S2 ventana de operador pisada; S3 runbook sin relaciones), 🟡 S4–S8 (relay: `--dry-run` en freeze, aparcada con exit 0, `--max-age` tardío, `--only` «outbox vacía», verificador de relaciones) | `.claude/reproducciones/sistema-m4.spec.ts` | S1, S2, S3, S5–S7 arreglados en alpha.10 (7/8 repros rojos tras el lote); `--dry-run` en freeze y verificador ⇒ siguiente lote |
