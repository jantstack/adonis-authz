# Respuesta a COGNITIV (informes 4 y 5 + respuesta a alpha.8) — alpha.9 publicada el 2026-09-13

> Asunto: Re: banderas inertes y cutover — 2.4.0-alpha.9 publicada; los tres rojos eran reales, y dos cosas que tenéis que revisar

Gracias por los dos informes: los tres rojos son exactos, los verificamos contra el código antes de tocar nada, y el
patrón de test que proponíais (crear el comando con la bandera de verdad, ejecutarlo y afirmar el efecto en la base, no
la propiedad) es el que usamos. `2.4.0-alpha.9` está publicada con dist-tag `alpha`.

**Antes que nada, dos cosas que tenéis que revisar en vuestros entornos:**
1. Si en cualquier alpha entre la 4 y la 8 corristeis `authz:reconcile --dry-run` contra un destino, **ese destino fue
   escrito**: el comando que creíais de solo lectura aplicaba la migración. Revisad el estado de ese store.
2. Si corristeis `authz:reconcile --prune` sobre un store de OpenFGA compartido con relaciones, **perdisteis las tuplas
   de relación** (llaves de espacio, aristas del espejo y grupos). Se reconstruyen con `authz:relations:reconcile`
   por partición desde `database`.

**1 · Banderas inertes — era un defecto nuestro de uso de ace, y afectaba a 18 declaraciones.** Vuestro diagnóstico es
el correcto: `defineFlag` construye `{ name, flagName, ...options }` y luego hidrata con `defineProperty(this, flag.name)`,
así que `name: 'dry-run'` en las opciones pisaba el nombre de la propiedad. Eran 16 banderas multi-palabra inertes más
dos de una sola palabra (`--only`, `--id`) que funcionaban por casualidad; quitamos `name:` en las 18 y **ningún nombre
público cambia** (comparado mecánicamente). Añadimos casos que ejecutan cada comando por el kernel de ace con la bandera
de verdad y afirman el efecto (12 de 13 nacen rojos con el defecto puesto), y una guardia estática para que un comando
nuevo con el mismo error nazca rojo. Nota honesta: seis aserciones de nuestra propia suite leían `name ?? flagName` y
pasaban en verde **porque** el defecto estaba puesto.

Consecuencia al subir: las banderas ahora hacen efecto. `--dry-run` deja de escribir, `--max-age` alarma desde el
comando, y `--allow-mass-delete`/`--allow-mass-purge`, que antes fallaban hacia el lado seguro, **ahora sí levantan el
seguro** — revisad que ningún runbook o cron las pase por costumbre.

**2 · `authz:reconcile --prune` borraba las relaciones del store compartido — y era peor de lo que medisteis.** Además
de las 60 de 60, la pasada destructiva reportaba `clean = true` y exit 0 (borraba justo lo que habría delatado la deriva),
y caían también las tuplas de `group`, que el generador emite siempre para los usersets. Adoptamos vuestra sugerencia con
dos correcciones que salieron del panel: la lista blanca es **explícita** y la decisión de borrar **no lee nada en
runtime** (ni `relations.config` ni el modelo publicado — si dependiera del config, volvería a borrar justo en vuestro
caso, cuando el reconcile de hechos corre sin él); y `deny_binding` de 2.2 queda como **propio**, no ajeno, porque la
migración FGA→DB todavía lo lee como deny. Los cuatro tipos que gobierna son `scope`, `role`, `role_binding` y
`deny_binding`; lo demás va a un campo nuevo del reporte, `foreign: { tuples, types, relations?, unknown? }`, fuera de lo
que decide si la pasada está limpia. Resultado medido: `--prune` borra cero ajenas, sigue barriendo lo propio obsoleto, y
**`clean` puede volver a ser `true` en un store compartido**, así que vuestro verificador de CI vuelve a ser posible con
el nuestro. El reconcile de relaciones no tenía el defecto simétrico (ya usaba lista blanca; medido).

Un límite que dejamos declarado: las tuplas de un tipo de relación que dejéis de declarar ya no las barre nadie, y
vuelven a conceder si lo re-declaráis. La salida está en el README con sus dos trampas (el seguro de borrado masivo salta
cuando `database` no tiene esas tuplas, y levantarlo vacía las relaciones vivas de la partición a la que apuntéis);
`--prune-undeclared` va a 2.5.

**3 · Y una más que encontró nuestro auditor al revisar el arreglo**: `--partition-uuid` sin `--partition-type`
reconciliaba la partición raíz en silencio, escribía cero y decía éxito — la misma forma del segundo rojo, sobreviviendo
a una errata en el runbook. Desde alpha.9 media pareja de esas banderas sale con código ≠ 0 sin enumerar nada.

**Sobre vuestra respuesta a alpha.8**: gracias por la precisión de `maxDepth` — cuadra, era la misma cuenta con otro
origen. Y queda claro que el reporte del relay no sale por HTTP; con eso no hace falta recortarlo más.

Con esto, vuestro runbook de cutover puede volver a apoyarse en `authz:reconcile --dry-run`, en
`authz:relations:reconcile --partition-type/--partition-uuid` y en `--max-age`. Verificada en SQLite, SQLite-fichero,
PostgreSQL 18 y MySQL 8.4 contra OpenFGA, con auditoría sobre el diff.
