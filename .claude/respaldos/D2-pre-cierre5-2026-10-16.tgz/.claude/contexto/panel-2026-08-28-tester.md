# Panel 28-08-2026 · Tester de contrato — verificabilidad de las exigencias COGNITIV

> Repo: `/home/jose/proyectos/Personal/adonis-authz` v1.1.0 (`252ea8c`).
> Pregunta permanente: **¿cómo se OBSERVA cada exigencia con un test que corra en ambos drivers, y qué invariante de `CLAUDE.md` pone en riesgo?**
> Todo lo marcado como «CONFIRMADO» se ejecutó de verdad en esta sesión; los scripts están en
> `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/` (`demo_db.ts`, `demo_fga.ts`, `demo_l07.ts`, `demo_catalog.ts`, `demo_trx.ts`, `probe_trunc.ts`). **No se tocó nada del paquete.**

## 0. Resultados reales de la suite (medidos hoy)

| Comando | Resultado |
|---|---|
| `npm test` (SQLite en memoria) | **40 passed (40)** · 7 s · exit 0 |
| `OPENFGA_TEST_URL=http://localhost:8101 npm test` | **67 passed (67)** · 6 s · exit 0 |
| `OPENFGA_TEST_URL=http://localhost:8103 npm test` (2.º servidor, `OPENFGA_LIST_OBJECTS_MAX_RESULTS=3`) | **67 passed (67)** · 6 s |
| `OPENFGA_TEST_URL=http://localhost:8102 npm test` (2.º servidor, `…MAX_RESULTS=1`) | **64 passed, 3 failed** — `listScopes`, `listRoles`, `listRoleScopes` del contrato openfga |

El servidor de :8101 (`api-loco-base-openfga-1`, OpenFGA v1.19.0) sirve. Los servidores de truncamiento se levantaron con
`docker run -d -p 810X:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=N -e OPENFGA_DATASTORE_ENGINE=memory openfga/openfga:latest run`
(arranque < 5 s, sin Postgres) y se eliminaron al terminar. **Es viable y barato.**

---

## 1. Cobertura actual — invariantes de `CLAUDE.md` → test que los cubre

| # | Invariante | Estado | Dónde |
|---|---|---|---|
| 1 | Scopes jerárquicos, herencia solo hacia abajo | 🟡 **caso trivial nada más** | `src/testing/contract.ts:134` (aislamiento), `:147` (herencia abajo), `:155` (deny en el cercano). **Los 67 tests corren con el resolutor POR DEFECTO** (`database_driver.ts:52`, `openfga_driver.ts:544`): árbol de dos niveles, `app` → todo. Ningún test inyecta un `resolveAncestors` propio, ni un árbol de 3 niveles, ni ciclos, ni `null`. |
| 2 | Deny explícito gana | ✅ / 🟡 | `contract.ts:103`, `:155`, `tests/middleware.spec.ts:282`. **Hueco**: el deny NO gobierna `hasRole` y no hay un solo test que lo mire (→ L0.6). |
| 3 | Expiración observable sin scheduler | ✅ | `contract.ts:120`, y como filtro en `:177`, `:194`, `:213`, `:256`, `:276`. **Hueco**: sin reloj inyectable — todo con `Date.now() ± 60 s`; el borde «exactamente ahora» y el sesgo de reloj (README:151) no son observables. |
| 4 | Holders polimórficos, nunca se cruzan | 🟡 **cubierto solo en el caso fácil** | `contract.ts:167`, `middleware.spec.ts:297`. Ambos con `holderTypes` **inyectivo** (`contract.spec.ts:37`). Con un mapa no inyectivo el invariante se rompe (→ L0.2, CONFIRMADO). |
| 5 | Tres estados distinguibles (false / 422 / 503) | ✅ **el mejor cubierto** | false: `contract.ts:76`, `:80`. 422: `contract.ts:97`, `:116`, `contract.spec.ts:98`. 503: `contract.spec.ts:65`, `:86`. **Huecos**: el 503 solo se provoca con un puerto muerto (no 5xx, no timeout, no respuesta parcial); y hay al menos un error **semántico** que sale como 503 (→ L0.5, CONFIRMADO). |
| 6 | Escrituras idempotentes | ✅ / 🟡 | `contract.ts:177` (re-grant no duplica, cuenta holders), `:249` (revoke/removeDeny no-op), `contract.spec.ts:150-188`. **Hueco**: no hay ninguna aserción de que un **re-deny** no duplique filas (solo se comprueba que no revienta). |
| 7 | Los `list*` no enumeran herencia | ✅ (dirección) / ❌ (completitud) | `contract.ts:213`, `:232`, `:256`, `:276`. Ninguno mira si la lista está **completa**: el truncamiento silencioso de `listObjects` no lo ve nadie (→ L0.7, CONFIRMADO como *fail-open*). |
| 8 | `rank` es metadata, no se evalúa | ❌ **sin ningún test** | `manager.spec.ts:169` solo comprueba que el sync **escribe** el rank. Falta el caso que afirma que el motor **no lo usa**: dos roles (rank 100 sin el permiso, rank 0 con él) → `authorize` true por el de rank 0 y false por el de rank 100. Coste: 15 líneas, corre en los dos drivers. |

### Reglas de higiene

| Regla | Estado |
|---|---|
| Pureza (`scripts/check_purity.mjs`) | ✅ el script existe y funciona, pero **no corre en `npm test` ni en el job `test` de CI** — solo dentro de `npm run build`, es decir en el job `compat`. Un PR que rompa la pureza pasa los dos jobs que la gente mira. |
| «El catálogo es local siempre» | 🟡 implícito en `contract.spec.ts:255` (el harness openfga siembra con `syncAuthzCatalog`). Sin aserción explícita de que el driver openfga **no** escribe catálogo. |
| «La abstracción no filtra» | 🟡 `contract.spec.ts:65-96` cubre `authorize` y `grant`. La garantía es por construcción (el Proxy de `openfga_driver.ts:212`), pero **ningún test recorre los 11 puntos de invocación**. |
| «`@openfga/sdk` es peer opcional; nada en la ruta `database` lo importa» | ❌ **sin test**. Además `tests/contract.spec.ts:19` importa el driver openfga **siempre**, así que `npm test` sin OPENFGA_TEST_URL igualmente carga el SDK: la suite no puede detectar la regresión. |
| «Un cambio de driver es migración de hechos, no reescritura» | ❌ **falso en los bordes, y el juez no lo ve** (ver §2, BORDE-app-uuid y L0.5). |

### III.6.7 — ¿el README publicado promete algo que el código no hace?

**Sí, cinco cosas.** Por gravedad:

1. **README:164 «Databases: PostgreSQL, MySQL, SQLite».** La suite corre **solo SQLite en memoria**. Cero cobertura de Postgres y MySQL para un motor cuyo núcleo (`whereActive`, `database_driver.ts:71`) compara `expires_at > new Date()` — semántica de timestamp/zona distinta en los tres motores. Es una promesa de compatibilidad **sin una sola observación**.
2. **README:114 «A driver that passes honors the semantics above, so call-sites never change when you swap backends».** Falso en al menos dos bordes, ambos CONFIRMADOS hoy: `{type:'app', uuid:'X'}` da `true` en openfga y `false` en database; un `SubjectRef.uuid` con `#` se acepta en silencio en database y sale como **503** en openfga. El juez común no mira ninguno de los dos.
3. **README:126 «The import copies, it doesn't move».** `importAuthzFactsToOpenFga` (`openfga_driver.ts:268`) **no tiene ni un test**: ni dry-run, ni idempotencia, ni `skippedExpired`, ni el troceado de 50.
4. **README:97 «`rank` is metadata … the engine stores it».** Invariante 8: sin test (ver arriba).
5. **README:35 «every other level is yours, declared by the `resolveAncestors` resolver you inject».** La costura publicada como principal es la única que **nunca se ejercita**: ningún test inyecta un resolutor. También sin test: README:151 (sesgo de reloj) y README:153 (rol borrado del catálogo ⇒ tupla huérfana ⇒ `authorize` deniega) — este último es barato y debería estar.

---

## 2. D · Defectos L0.1–L0.8 — caso de contrato y evidencia

Formato: **dado → cuando → entonces** del caso que *hoy falla al escribirlo con la semántica corregida* (es decir: el caso pasa si se corrige y falla si se quita la corrección).

### L0.1 · `whereScopeIn([]) ⇒ whereRaw('1 = 0')`
- **Caso**: *dado* un filtro de scopes construido con una lista **vacía**, *cuando* se ejecuta la consulta, *entonces* no devuelve ninguna fila.
- **CONFIRMADO (SQLite)**: `whereScopeIn(db.from('authz_assignments'), 'scope', [])` produce literalmente `select * from \`authz_assignments\`` — **sin WHERE**. Con un scope sí filtra.
- **Alcance real hoy**: latente. `chain()` (`database_driver.ts:55`) nunca devuelve vacío, así que ninguna ruta pública lo alcanza. Se vuelve alcanzable en cuanto entre `descendantsOf` o `authorizedScopes`.
- **Verificabilidad**: SQLite ✅ / Postgres ✅ / MySQL ✅ (mismo SQL) / OpenFGA **N/A** (no hay cláusula SQL). Hoy solo es observable **saltándose el `private`** (`(driver as any).whereScopeIn`) o afirmando sobre el SQL generado. Eso es un olor: **la corrección debe venir acompañada de un punto de entrada público** (`descendantsOf` / `authorizedScopes`) o el test queda atado a un método privado.
- **Tipo**: unitario + de propiedad (`∀ lista: |resultado(lista)| ≤ |resultado(lista ∪ {x})|`).

### L0.2 · `holderTypes` inyectivo, verificado en boot
- **Caso A**: *dado* `holderTypes = {users:'user', admins:'user'}`, *cuando* se construye el driver openfga, *entonces* **lanza en boot**.
- **Caso B (el que demuestra el daño)**: *dado* ese mapa y un grant a `users:X`, *cuando* se pregunta por `admins:X`, *entonces* `false` (invariante 4).
- **CONFIRMADO (OpenFGA :8101)**: `authorize(admins:X) = true` tras conceder a `users:X` → **invariante 4 roto**. `listSubjects` devuelve `[{type:'admins', …}]` (miente sobre el tipo). Y `revoke(admins:X)` **borra la asignación de `users:X`**: `authorize(users:X)` pasa a `false`.
- **Verificabilidad**: SQLite/Postgres/MySQL **N/A** (el driver database guarda `holder_type` en columna propia: es inmune por construcción — eso también merece un caso explícito) / OpenFGA ✅ **hoy, sin infraestructura nueva**.
- **Invariante en riesgo**: 4 (roto ya), 7 (`listSubjects` miente).
- **Coste**: bajo. Es el defecto con mejor relación daño/coste de prueba de todo L0.

### L0.3 · `UnknownScopeError`
- **Caso A**: *dado* un `resolveAncestors` que devuelve `null` para un scope inexistente, *cuando* se llama `authorize`, *entonces* `false`; *cuando* se llama `grant`/`deny`/`hasRole`, *entonces* lanza.
- **Caso B**: *dado* un config sin resolutor que declara tipos ≠ `app`, *cuando* arranca, *entonces* lanza en boot.
- **CONFIRMADO (SQLite, comportamiento actual)**: con el resolutor por defecto, un grant en `app` **autoriza sobre una `organization` que no existió jamás** (`authorize → true`). Con `resolveAncestors` devolviendo `null`, hoy revienta con un `TypeError` de spread (`[scope, ...null]`), no con un error del paquete.
- **Verificabilidad**: SQLite ✅ / Postgres ✅ / MySQL ✅ / OpenFGA ✅ — **mismo test en los cuatro**, porque solo depende del resolutor inyectado. Necesita el harness de resolutor (ver §9.3).
- **Invariante en riesgo**: **1**. Ojo: el caso B (throw en boot si hay tipos sin resolutor) **rompería a cualquier consumidor actual** que use `organization` con el default → es breaking (III.6.2).

### L0.4 · `expiresAt`: `undefined` = no tocar · `null` = quitar
- **Caso**: *dado* una asignación con caducidad **futura**, *cuando* se re-otorga **sin opciones**, *entonces* la caducidad **sigue**; *cuando* se re-otorga con `{expiresAt: null}`, *entonces* desaparece.
- **CONFIRMADO (SQLite)**: tras `grant(..., {expiresAt: +1h})` seguido de `grant(...)` sin opciones, `expires_at = null`. La caducidad vigente se borró.
- **⚠ Lo importante: esta corrección ROMPE tests existentes.** No es invisible:
  - `src/testing/contract.ts:177` «grant duplicado es idempotente (y refresca expiresAt)»: otorga con caducidad **pasada**, re-otorga sin opciones y **espera `authorize` true**. Con la semántica nueva la caducidad pasada se mantiene → `false` → **falla en los DOS drivers**.
  - `tests/contract.spec.ts:221` «si falla la lectura sobre una asignación existente, la refresca»: mismo patrón → **falla**.
  - `tests/contract.spec.ts:182` «quitar la expiración de una asignación que la tenía»: seguiría pasando, pero **dejaría de probar lo que su nombre dice** (habría que reescribirlo con `expiresAt: null`).
  - Total: **3 casos del juez a reescribir**, 2 de ellos porque cambia la semántica publicada (README:40 «Re-granting … refreshes the expiry»). **Es breaking de contrato para drivers de terceros ⇒ major** según `CLAUDE.md`:90.
- **Verificabilidad**: SQLite ✅ / Postgres ✅ / MySQL ✅ / OpenFGA ✅ (con matiz: en openfga hay que distinguir «no tocar» de «no-op por `sameExpiry`» — el caso debe afirmar sobre la **tupla leída**, no solo sobre `authorize`).
- **Invariante en riesgo**: 3 y 6.

### L0.5 · `assertIdentityComponent` en ambos drivers
- **Caso A**: *dado* `SubjectRef.uuid` con `#` o `|`, *cuando* se llama `grant` en **cualquier** driver, *entonces* lanza **422**.
- **Caso B (paridad)**: *dado* el mismo subject, *cuando* se pregunta a los dos drivers, *entonces* **la misma clase de error**.
- **CONFIRMADO**: database acepta `uuid = 'no-es-uuid#assignee|x'` en silencio (`grant` ok, `authorize` true). OpenFGA lanza **`AuthorizationBackendError` status 503 `E_AUTHZ_BACKEND_UNAVAILABLE`** — es decir, un error **semántico** disfrazado de caída de infraestructura, exactamente lo que `contract.spec.ts:98` existe para impedir. El Proxy de `guardBackendErrors` traga también los 400 de validación.
- **Verificabilidad**: SQLite/Postgres/MySQL ✅ (caso A) / OpenFGA ✅ (casos A y B). **Se puede escribir hoy, dentro del juez común**, sin infraestructura nueva. Es el caso que convierte «la paridad entre drivers» de promesa en aserción.
- **Invariante en riesgo**: **5** (el 503 no debe cubrir errores semánticos) y 4 (`uuid#relacion` = userset accidental).

### L0.6 · `hasRole` no es decisión de acceso
- **Caso A**: *dado* un holder con el rol `editor` y un **deny** de todos sus permisos, *cuando* se llama `hasRole`, *entonces* **sigue true** (comportamiento documentado, con su caso de contrato) y `authorize` es `false`.
- **Caso B**: *dado* ese holder, *cuando* pasa por `appAccess({ role: 'editor' })`, *entonces* → hoy **403 no ocurre: pasa**. Ese es el PEP indenegable.
- **CONFIRMADO (SQLite)**: `authorize(docs:read)=false` y `authorize(docs:write)=false`, pero `hasRole(editor)=true`. `appAccess({role})` deja pasar a alguien con todos sus permisos denegados.
- **Bonus CONFIRMADO (justifica la forma `hasRole(s,{slug,scopeType},scope)`)**: con dos roles `owner` (uno `app`, otro `organization`), conceder el de **app** hace `hasRole(bob,'owner',org) = true`. El slug **no identifica al rol**: `hasRole` (`database_driver.ts:208`) filtra por `r.slug` sin `r.scope_type`.
- **Verificabilidad**: los cuatro backends ✅ — mismo test, ya escribible hoy.
- **Invariante en riesgo**: **2**. Hoy el invariante 2 está enunciado sobre `authorize` y el paquete publica un middleware que lo esquiva.

### L0.7 · Paginación + `RelationsResultTruncatedError`
- **Caso**: *dado* un servidor con `listObjectsMaxResults` pequeño, un grant en `orgA`, un deny de ese permiso en `orgA` y **ruido de denies de otros scopes** suficiente para llenar la página, *cuando* se llama `listScopes(subject, permiso)`, *entonces* **lanza** `RelationsResultTruncatedError` (hoy: devuelve `orgA` como concedido).
- **CONFIRMADO (OpenFGA con `OPENFGA_LIST_OBJECTS_MAX_RESULTS=3`)**:
  ```
  deny listObjects → [ …|0000000a…|docs~write, …|0000000b…|docs~write, …|0000000c…|docs~write ]
  authorize(docs:read, orgA) = false      ← el deny SÍ está y SÍ gobierna
  listScopes(docs:read)      = [ {organization, ffffffff-…} ]   ← el mismo scope, listado como concedido
  ```
  **Fail-open, sin ninguna señal.** La causa exacta: `listScopes` (`openfga_driver.ts:663`) pide **todos** los `deny_binding` del sujeto y filtra por permiso **en cliente**; un deny irrelevante desplaza al relevante fuera de la página.
- **¿Es viable con el local de :8101?** No: :8101 corre con el default (1000) y es un contenedor compartido de otro proyecto. **Sí es viable levantar un segundo**: `docker run -d -p 8103:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3 -e OPENFGA_DATASTORE_ENGINE=memory openfga/openfga:latest run` — arranca en < 5 s, sin Postgres. **Medido: con `=3` la suite completa pasa 67/67; con `=1` fallan 3 tests** (`listScopes`, `listRoles`, `listRoleScopes`) por incompletitud *fail-closed*, que es un ruido distinto del defecto. → **el número correcto para CI es 3, no 1.**
- **Verificabilidad**: SQLite/Postgres/MySQL **N/A** (no truncan; deben tener el caso **negativo**: «nunca lanza truncamiento») / OpenFGA ✅ **con el segundo servidor**.
- **Invariante en riesgo**: **2 y 7**. Es el único defecto de L0 que produce *fail-open* en producción con datos realistas (>1000 denies o >1000 bindings por sujeto).
- **Hueco que el plan no menciona**: el **falso positivo**. Si la corrección es «`objects.length === max` ⇒ lanza», un resultado real de exactamente `max` elementos hará caer una petición legítima. Hace falta el caso inverso: *dado* exactamente `max` objetos reales, *entonces* devuelve la lista sin lanzar. Solo se puede escribir con el segundo servidor (con `max=3`: escribir exactamente 3 bindings).

### L0.8 · Modelos exportados de solo lectura
- **Caso**: *dado* `AuthzAssignment` importado del paquete, *cuando* se llama `.create()`, *entonces* lanza.
- **Verificabilidad**: SQLite ✅ / Postgres ✅ / MySQL ✅ / OpenFGA **N/A pero crítico**: con el driver openfga, un `AuthzAssignment.create()` escribe en una tabla que **nadie lee** → asignación fantasma. Ese caso (escribir por el modelo con driver openfga ⇒ `authorize` sigue false) es el que de verdad demuestra el problema y **solo corre en openfga**.
- **Invariante en riesgo**: ninguno de los 8 directamente; sí «el catálogo es local siempre» y la contención de L1.

### Bordes CONFIRMADOS que **no están** en la lista L0

| Id | Hallazgo | Evidencia |
|---|---|---|
| **BORDE-app-uuid** | `{type:'app', uuid:'X'}` colapsa a `APP_SCOPE` en openfga (`scopeKey`, `openfga_driver.ts:84` ignora el uuid si el tipo es `app`) pero es un scope **distinto** en database. Medido: mismo grant, `authorize` → **openfga `true` / database `false`**. Divergencia de drivers que el juez no ve y que contradice README:114. | `demo_fga.ts` |
| **BORDE-centinela** | Una `organization` con uuid `00000000-0000-0000-0000-000000000000` (el centinela de `app`, `database_driver.ts:22`) hace que `listRoleScopes` devuelva `{type:'organization', uuid:null}` — un `ScopeRef` malformado. Mismo patrón que tendrá `owner_scope_key = 'global'` en `catalog/`. | `demo_db.ts` |
| **G-trx** | Con el pool 1/1 de SQLite del harness (`tests/helpers/app.ts:309`), abrir una transacción y llamar a `driver.grant()` **se bloquea para siempre** (timeout a 8 s). Es decir: **hoy no se puede escribir ni un solo test de `{trx}`** sin cambiar el harness. | `demo_trx.ts` |

---

## 3. B · Módulo `relations/` — evaluación de la suite de ~28 × 2 (§3.5)

**Casos de contrato que añade**: los ~28 de §3.5 son un buen esqueleto y cubren lo que suele olvidarse (partición, usersets en las dos direcciones, expansor que lanza, frontera). **No es completa.**

**Invariantes existentes en riesgo**
| Invariante | Riesgo | Test que lo cubre hoy |
|---|---|---|
| 1 (herencia solo abajo) | `relations/` **no** debe tener árbol; el riesgo es que `usersetsOf` del consumidor lo reintroduzca de facto | ❌ ninguno; hace falta el caso «un userset de la partición P1 nunca aparece en P2» |
| 4 (holders polimórficos) | `subject_key` serializa `tipo:uuid` en **una columna** → vuelve el problema que el driver database no tenía (→ ver L0.5) | ❌ |
| 5 (tres estados) | `RelationExpansionTooDeep` y `RelationsResultTruncatedError` son estados **nuevos**: hay que decir su status y probar que **no** son `false` ni `[]` ni 503 | ❌ |
| 7 (los `list*` no enumeran herencia) | `listObjects` **sí** expande usersets: es la excepción. Hay que documentarla o el invariante 7 queda ambiguo entre módulos | ❌ |

**Verificabilidad por backend**
| Backend | ¿Mismo test? | Riesgo específico | Notas |
|---|---|---|---|
| SQLite | sí para el núcleo | pool 1/1 impide `{trx}` y concurrencia (**medido**) | hay que subir el pool o usar fichero |
| Postgres | sí + **exclusivo** | trigger de partición, índice parcial `WHERE valid_until IS NOT NULL`, `timestamptz` | los tres son **solo Postgres**: el esquema de §3.4 no es portable tal cual |
| MySQL | sí, **con recortes** | no hay índice parcial; `BEFORE INSERT OR UPDATE` es sintaxis distinta; `timestamptz` no existe | el helper `relationPartitionTrigger` necesita **una implementación por motor** o deja de prometerse MySQL |
| OpenFGA | **no para 4 grupos** | `{trx}`, caducidad sobre usersets (spike abierto), truncamiento, `membersOf` como subquery | ver abajo |

**Lo que NO puede correr en ambos drivers** (y cómo estructurarlo)
1. **`{trx}` + rollback** → solo `database`. En openfga el caso es el **negativo**: `relate(..., {trx})` **lanza** con un error del paquete (no 503, no ignorado en silencio). *Saltar el test no es evidencia.*
2. **Caducidad en usersets** → depende del spike. Hasta que el spike responda, el caso es **no escribible** en openfga: si las conditions no aplican sobre tuplas de userset, la paridad de caducidad **no existe** y hay que dejar de prometerla en el README, no taparla con un `skip`.
3. **Truncamiento** → solo openfga (+ segundo servidor). En database el caso negativo: «con 5.000 filas devuelve 5.000 y nunca lanza».
4. **`membersOf` como fragmento de query** → **solo tiene sentido en `database`**. Con el driver openfga, `listSubjects` es `ListUsers` y el consumidor no aporta subquery. Es decir: **el mismo objeto de config (`usersets[].membersOf`) es inútil en un driver**. Eso no es un hueco de test, es un hueco de **diseño del puerto** que el test destapa: hay que decidir si `membersOf` es opcional-por-driver (y probar que openfga **lanza** si lo recibe) o si el puerto se parte.
5. **`purgeObject(): number`** → el número de tuplas borradas no es comparable entre drivers (expansión). El contrato debe afirmar **«≥ 1 y el objeto queda sin relaciones»**, no la cifra exacta, o el juez común es imposible.

**Estructura recomendada**: **núcleo común (≈ 18 casos) + anexo `database` (≈ 6) + anexo `openfga` (≈ 6) + casos negativos de capacidad (≈ 4)**, con las capacidades **declaradas por el harness** (`capabilities: {transactions, truncationSignal, usersetExpiry, membersSubquery}`) y la regla de oro: **toda capacidad declarada `false` debe tener su caso negativo**; nunca un `skip` silencioso.

**Huecos concretos que faltan en los ~28** (inversos, bordes, orden):
- *Inversos*: `unrelate` de algo inexistente = no-op; relación **no declarada** para ese `objectType` → throw; `listObjects` con `objectType` no declarado → throw; `check` con relación no declarada → throw (§3.5 solo lo pide para usersets).
- *Inverso de `includes`*: si `viewer ⊂ contributor ⊂ manager`, ¿`listSubjects('viewer', o)` devuelve a los managers? **El plan no lo dice** → subespecificado. Escríbelo o el juez no puede juzgar.
- *Idempotencia*: `relate` idéntico dos veces = una fila (§3.5 solo cubre «renovar no duplica»).
- *Orden*: `relate → unrelate → relate` (¿revive con la caducidad vieja?); `unrelate` antes del primer `relate`; `purgeObject` y después `relate` del mismo objeto; `purgeSubject` y re-alta. **El resultado no debe depender del orden de escritura** — hoy no hay ni un test de orden en todo el repo.
- *Bordes*: `validUntil` **exactamente ahora**; `validUntil` ya pasado al crear (¿se escribe o se rechaza?); lista de subjects **vacía** (§3.5 lo tiene) y con **duplicados**; lista de **> 50** subjects (el `batchCheck` trocea de 50 en 50, `openfga_driver.ts:378` — mismo riesgo aquí); `maxNodes` **exactamente en el límite** (1000 vs 1001); relación con mayúsculas; partición con `uuid: null` → throw.
- *Concurrencia*: dos `relate` simultáneos con caducidades distintas (el equivalente ya existe para roles en `contract.spec.ts:231` y es un caso excelente: **cópialo**); `purgeObject` concurrente con `relate` (¿tupla huérfana?).
- *Hook*: `onRelationWrite` que **lanza**. En `roles/` la regla es «se traga y se registra» (`manager.spec.ts:72`). Si el hook de `relations/` corre **dentro** de la trx, la regla debería ser la contraria. **El plan no lo decide** → hueco de especificación.

**Coste de prueba**: **alto**. Antes del primer caso hacen falta: reloj inyectable (0,5 d), harness con pool ≥ 2 y motor configurable (1 d), tablas ficticias del consumidor con FK y trigger (0,75 d), harness de expansor `usersetsOf`/`membersOf` con contador de nodos (0,5 d), segundo OpenFGA (0,25 d) ⇒ **≈ 3 d de infraestructura** antes de escribir un solo assert, más los 2 d que §7 asigna a la suite. La estimación de §7 (2 d de suite) **solo se cumple si la infraestructura ya está pagada**.

**Veredicto**: **verificable con cambios** — con dos condiciones bloqueantes: (a) responder los dos spikes FGA *antes* de fijar el contrato (si las conditions no aplican a usersets, cambia la mitad de los casos de caducidad), y (b) resolver el hueco de diseño de `membersOf` (§B.4), que hoy hace imposible un juez único.

---

## 4. C · Módulo `catalog/` — los +8 × 2 de §4

**Casos que añade**: los 10 listados en §4 son correctos y todos escribibles. **Faltan 12.**

**Invariantes en riesgo**
| Invariante | Riesgo | Cubierto hoy |
|---|---|---|
| 7 (`list*` directos) | `listRoles`/`listSubjects` filtrando por owner: cambia lo que devuelven | `contract.ts:213`, `:256` — cubren la forma, no el owner |
| 8 (`rank` es metadata) | `createTenantRole` **sí** evalúa rank: hay que dejar clarísimo que es policy de escritura, no de evaluación | ❌ (invariante 8 sin test) |
| 6 (idempotencia) | el sync «solo toca globales» y «falla ante colisión con un local»: dos comportamientos nuevos del mismo `syncAuthzCatalog` | `manager.spec.ts:118` cubre la idempotencia vieja |

**Verificabilidad por backend**
| Backend | ¿Mismo test? | Riesgo específico |
|---|---|---|
| SQLite | sí | el `unique(slug, scope_type, owner_scope_key)` con `owner_scope_key` NOT NULL DEFAULT 'global' funciona igual |
| Postgres | sí | migración de datos existentes al nuevo unique — **test de migración, hoy inexistente** |
| MySQL | sí | `varchar(80)` + unique de 3 columnas roza el límite de índice en utf8mb4 con collations viejas |
| OpenFGA | **sí, y es donde está el riesgo** | el binding id pasa de 3 a 4 partes |

**Hueco crítico, verificado leyendo el código**: `parseBindingId` (`openfga_driver.ts:91`) devuelve `null` si el id tiene **4 partes**. Un binding de rol local (`<scope>|<uuid>|<rolUuid>|<owner>`) sería **invisible** para `listRoles`, `listRoleScopes` y `listScopes` — y hoy se descarta **en silencio** (`if (!parsed) continue`). Casos obligatorios: (a) binding de 4 partes se parsea; (b) uno de 3 sigue leyéndose como global; (c) uno de 5 se descarta **con log de error**, no en silencio.

**¿Es reproducible HOY el `listSubjects` que cruza tenants? — Lo probé: NO.**
`listSubjects` (`database_driver.ts:284`) filtra por `r.slug` **y** `r.scope_type` **y** el scope exacto. Con el `unique(slug, scope_type)` actual no pueden existir dos roles homónimos del mismo nivel, así que dos orgs con `org-admin` comparten **el mismo `role_uuid`** y la separación la da `a.scope_uuid`. Medido: `listSubjects('org-admin', orgA)` devuelve **1** holder y **no** incluye al de orgB. **El bug nace con `owner_scope_key`**, no antes. Lo que sí procede es dejarlo escrito como **pin de regresión** hoy (el test pasa ahora y fallará el día que se resuelva por slug sin owner).

**Lo que sí es reproducible hoy y anticipa el problema (CONFIRMADO)**: con dos roles `owner` (uno `app`, otro `organization`), conceder el de app hace `hasRole(bob,'owner',org)=true` y `listRoles` devuelve `["owner"]` sin decir cuál. **El slug ya no identifica al rol hoy**; con `owner_scope_key` deja de identificarlo dos veces.

**Y otro, también CONFIRMADO, que es de §4/H (L4)**: el sync es aditivo y **nunca borra vínculos**. Quitar `docs:write` del rol `editor` en el config y volver a sincronizar deja `authorize(docs:write) = true`. Ningún test lo observa. Es exactamente lo que `authz:catalog:diff` viene a cerrar — y el caso de contrato es de tres líneas.

**Huecos que faltan en los +8**:
- **Colisión en las dos direcciones**: existe global → crear local (§4 lo tiene) **y** existe local → el sync intenta crear el global (no está).
- **`owner_scope_key = 'global'` como valor legítimo de un tenant**: mismo patrón de centinela que el `BORDE-centinela` ya CONFIRMADO. Un tenant cuyo `scopeKey` sea literalmente `global` se hace pasar por el catálogo global. Caso: *dado* un scope cuyo `scopeKey()` sea `'global'* → **throw**.
- **Bordes de rank**: `rank = 0` → throw; `rank = actorRank` → throw; `rank = actorRank − 1` → ok; actor sin rank.
- **Bordes de slug**: mayúsculas, longitud exacta 100 y 101, slug que colisiona tras normalizar. `assertValidSlug` (`catalog.ts:71`) hoy lanza **status 500**, no 422 — incoherente con el invariante 5; al exportarlo hay que fijar el status en un caso.
- **`purgeRole` con asignaciones en descendientes** (no solo en el scope propio) y **con denies** del permiso del rol.
- **Deny × rol local**: un deny sobre un permiso concedido por un rol local sigue ganando (invariante 2 en el módulo nuevo).
- **`effectivePermissions` heredado**: ¿el actor puede meter en un rol de tenant un permiso que solo tiene **heredado de `app`**? Decisión de producto sin caso.
- **Test de migración**: `migration_stub.spec.ts:359` compara columnas, no datos. Falta: dada la tabla vieja poblada, tras la migración todos los roles quedan `owner_scope_key='global'` y el unique nuevo no revienta.

**Coste**: **medio**. Casi todo corre con la infraestructura actual; solo el binding de 4 partes exige OpenFGA (ya disponible en :8101) y la migración exige Postgres (hoy inexistente en la suite).

**Veredicto**: **verificable** (el único módulo de los tres que lo es casi sin infraestructura nueva) — **y por eso confirmo el orden de §7: `catalog/` antes que `relations/`**.

---

## 5. E · L1 primitivas · F · `http/` · G · hooks · H · L4

### E · L1 — casos de contrato **mínimos** por primitiva

| Primitiva | Casos mínimos (dado → cuando → entonces) | Backends |
|---|---|---|
| `within` + `isWithin` | (1) `within ∈ chain(scope)` → concede · (2) `within ∉ chain` → **throw 422**, no false · (3) `within = scope` → ok · (4) `within = app` con scope de org → ok (está en la cadena) · (5) `requireWithin: true` sin `within` → throw · (6) **inverso**: con `requireWithin: false` (default 1.2) sigue concediendo → prueba que el flag hace algo | los 4 ✅ (depende del resolutor, no del backend) |
| `authorizedScopes` | (1) permiso a nivel `app` → `{kind:'all'}` · (2) en 2 orgs → `{kind:'some'}` con esas 2 · (3) sin nada → `{kind:'none'}` · (4) `some` **menos** los denegados · (5) `maxScopes` superado → **lanza** (nunca lista parcial) · (6) sin `descendantsOf` declarado → **lanza** (nunca `none`, que sería fail-closed mentiroso) · (7) **borde**: exactamente `maxScopes` → no lanza | los 4 ✅ con harness de `descendantsOf` |
| `descendantsOf` | (1) llamado desde `authorize` → **throw** (es la garantía «prohibido dentro de authorize») · (2) `maxNodes` → lanza · (3) implementado por el consumidor: el paquete nunca lo suple | los 4 ✅; (1) es un test de arquitectura, no de datos |
| `hierarchicalScopeResolver` | (1) cadena de 3 niveles correcta y ordenada · (2) **ciclo** A→B→A → lanza · (3) `maxDepth` 64 superado → **lanza** (truncar pierde el deny de la raíz = fail-open: el caso debe afirmar que **no** devuelve la cadena corta) · (4) `parentOf` devuelve `null` → cadena termina · (5) `parentOf` lanza → propaga, no `[]` | unitario, sin backend |
| `memoizeAncestors` | (1) dos `authorize` en el mismo request → **una** llamada a `parentOf` (spy) · (2) requests distintos → no comparten · (3) **el memo nunca cachea decisiones**: cambiar un deny entre dos `authorize` del mismo request cambia el resultado | unitario + los 4 |
| `listDenies` | (1) directos vigentes, sin herencia (invariante 7) · (2) filtrado por scope · (3) vacío → `[]` | los 4 |
| `effectivePermissions` | (1) unión de los roles vigentes en la cadena · (2) **menos** los denegados · (3) rol expirado no aporta · (4) **orden irrelevante**: mismo conjunto sin importar el orden de los grants | los 4 |
| `authorizeMany` | (1) resultado **idéntico** a N `authorize` individuales (test de propiedad) · (2) lista vacía → `[]` **sin tocar el backend** (spy) · (3) duplicados → resultado por posición · (4) un scope que lanza → lanza entero, no resultado parcial | los 4; en openfga además: **≤ ⌈N/50⌉ batchChecks** |

**Invariante en riesgo (E)**: **1 y 7**. `authorizedScopes` es la primera API que **sí** enumera descendientes; el invariante 7 dice que los `list*` no lo hacen. Hay que escribir en `CLAUDE.md` que `authorizedScopes` es la excepción explícita, y el caso que la delimita (`listScopes` sigue sin enumerar).
**Coste**: **medio-bajo**; casi todo es unitario con el harness de resolutor. **Veredicto: verificable con cambios** (necesita §9.3 y §9.7).

### F · L2 `http/` — diseño del harness `fakeCtx`

`tests/middleware.spec.ts:198` ya tiene un `fakeCtx` de 10 líneas, pero solo registra `unauthorized`/`forbidden`. Para `resourceAccess` hay que elevarlo a `tests/helpers/http.ts` con:

- `ctx.params` (`:org`, `:id`), `ctx.request.method()`, `ctx.auth.user`;
- `response` completo: `unauthorized`, `forbidden`, `notFound`, `status().send()`, `abort` — cada uno **empujando a un array ordenado** para poder afirmar sobre **cuál se llamó primero**;
- `next` como spy con contador (`advanced`, `advancedTimes`);
- distinción explícita entre **«respondió»** y **«lanzó»**: `AuthorizationBackendError` debe **propagarse** (para que el exception handler dé 503), no convertirse en `notFound`;
- un **spy del manager** para contar llamadas a `authorize` (el requisito «sin segundo `authorize` si la acción ya concedió» **solo es observable con contador**).

Casos mínimos, **en este orden** (el orden ES la aserción):
1. sin autenticar → 401, `load` **nunca se llama** (spy).
2. autenticado sin la ability → 403, `load` **nunca se llama**.
3. `tenantParam` ausente en la ruta → **throw 500** en boot/handle (error de programación, no 404).
4. recurso de **otro tenant** → **404**, nunca 403 (el inverso es el caso de seguridad: un 403 filtra existencia).
5. recurso inexistente (`load` → `null`) → 404 **idéntico** al caso 4 — *mismo cuerpo y mismo status*, o el 404 es un oráculo de existencia.
6. `tenantScope ∉ chain(scope)` → **404 antes de autorizar** (spy: `authorize` **cero** llamadas).
7. `gate(ctx)` false → **404 opaco**, no 403.
8. concede → `next()` **una** vez y `authorize` llamado **una** vez.
9. `readPermission` no declarado y método de lectura → **throw** (sin default silencioso).
10. `load` lanza `AuthorizationBackendError` → **propaga 503**, no 404 (el caso que impide disfrazar la caída).
11. `deny` sobre el permiso → 403 (invariante 2 en el borde HTTP).
12. **inverso de L0.6**: `resourceAccess` **no** admite `role` (o si lo admite, el deny lo gobierna).

**Backends**: los 12 corren en los 4 (el middleware llama al manager; el backend solo cambia el fondo). Los casos 4/5/6/7 son **puramente de orden** y no tocan el backend.
**Invariante en riesgo**: **2** (si `http/` acepta `role`, revive el PEP indenegable de L0.6) y **5** (el 503 no puede volverse 404).
**Coste**: **bajo** (0,5 d de harness + 0,5 d de casos). **Veredicto: verificable.**

### G · L3 hooks

- **`onWriteInTrx(event, trx)` con rollback**: *dado* un consumidor que abre una trx y registra `onWriteInTrx` escribiendo en su propia tabla, *cuando* el hook lanza (o el consumidor hace rollback), *entonces* **ni la asignación ni la fila del consumidor existen**. Y el inverso, que es el que de verdad prueba algo: *cuando* todo va bien, **ambas** existen.
  **Bloqueante medido**: con el pool 1/1 de SQLite del harness, ese test **se cuelga** (timeout 8 s, `demo_trx.ts`). Hay que subir el pool o pasar a SQLite en fichero **antes** de escribir el primer caso de `{trx}`.
  **Backends**: SQLite ✅ (con pool ≥ 2) / Postgres ✅ (el único que prueba aislamiento de verdad) / MySQL ✅ / OpenFGA → **caso negativo**.
- **openfga lo rechaza en boot**: *dado* un config con driver `openfga` y `hooks.onWriteInTrx` definido, *cuando* se resuelve el driver, *entonces* lanza con un mensaje que nombra el hook. Es un test de **construcción**, no de datos: `await manager.driver()` → `assert.rejects(/onWriteInTrx/)`. Corre sin servidor FGA (falla antes de la primera llamada) — **cuesta 5 líneas**. Y su inverso: con driver `database` el mismo config **no** lanza.
- **`assertWrite` puro y fail-closed**: (1) devuelve false → la escritura **no** ocurre y lanza 403/422 · (2) **lanza** → la escritura no ocurre (fail-closed, no «se traga y sigue» como `onWrite`) · (3) recibe el `actor` · (4) `requireActor: true` sin actor → throw · (5) se ejecuta **antes** de tocar el backend (spy: cero llamadas).
- **Riesgo sobre lo existente**: `manager.spec.ts:72` y `:89` fijan «un hook que lanza no tumba la escritura». `assertWrite` es lo contrario. **Son hooks distintos con reglas opuestas** — el caso que hay que añadir es el que los contrasta en el mismo test, o alguien los unificará por error dentro de seis meses.
**Coste**: **alto** (depende del harness multi-motor). **Veredicto: no verificable tal cual** hasta que exista el harness con pool ≥ 2 y, para el aislamiento real, Postgres.

### H · L4 `catalog/` — `assignableAt` + `authz:catalog:diff`

- `assignableAt` **no** es barrera de evaluación: *dado* un rol con `assignableAt: ['organization']` **ya asignado** en `app`, *cuando* se llama `authorize`, *entonces* **sigue concediendo**. Ese caso es el que impide que alguien lo lea como control de acceso (y el aviso del README se vuelve verificable). El positivo: `grant` de ese rol en un nivel no permitido → throw.
- `authz:catalog:diff`: (1) config == BD → exit 0 · (2) permiso **quitado** del config pero con vínculo vivo → exit ≠ 0 y lo nombra · (3) rol quitado del config con asignaciones vivas → exit ≠ 0 · (4) rol **añadido** → exit 0 (el sync es aditivo: añadir no es diff) · (5) rol **local** → el diff no lo cuenta como sobrante.
- **CONFIRMADO hoy**: el caso (2) es real — quitar `docs:write` del rol `editor` y re-sincronizar deja `authorize(docs:write) = true`. Es un fail-open del catálogo sin ningún test.
**Backends**: SQLite/Postgres/MySQL ✅. OpenFGA: el diff lee **solo** tablas locales ⇒ mismo test, pero hace falta el caso de que el **hecho** en FGA sobreviva al vínculo borrado (README:153, hoy sin test).
**Coste**: **bajo**. **Veredicto: verificable.**

---

## 6. A · Módulos — cómo se prueba que la frontera `roles/` ↔ `relations/` es «por construcción»

Cuatro pruebas de naturaleza distinta; hacen falta **las cuatro**, y la única que un lector se cree es la tercera:

1. **Grafo de importaciones (estático, bloqueante en CI).** Extender `scripts/check_purity.mjs` con una regla de módulos: ningún fichero de `src/relations/**` puede importar de `src/roles/**` salvo una **lista blanca explícita** (`scope_key.js`, `types.js`); y `src/roles/**` no puede importar **nada** de `src/relations/**`. Coste: ~30 líneas. **Pero antes hay que arreglar algo**: `check_purity` hoy **no corre en `npm test` ni en el job `test`** de CI, solo dentro de `npm run build` (job `compat`). Añadir `npm run check:purity` al job `test`. Coste total 0,25 d.
2. **Test de construcción (unitario).** `new RelationsManager(config)` con un `RolesManager` colado en el config → **lanza** (o, mejor, el tipo no lo admite: `@ts-expect-error` verificado por `npm run typecheck`, que ya corre en CI). Demuestra «ningún manager recibe al otro por constructor».
3. **Test de comportamiento (el que importa, y el único que corre en los dos drivers).** Son los «frontera (2)» de §3.5, y hay que escribirlos en **ambas** direcciones y con el par de datos completo:
   - *dado* una tupla `viewer` sobre el objeto O en la partición P, *cuando* se llama `roles.authorize(sujeto, 'space.read', scopeDeO)`, *entonces* **false**;
   - *dado* un rol de organización con `space.*` concedido en el scope de O, *cuando* se llama `relations.check(sujeto, 'viewer', O, P)`, *entonces* **false**;
   - y el **inverso que los hace significativos**: cada uno concede por su propio camino (si ambos dieran false siempre, el test pasaría con los dos módulos rotos).
4. **Test de aislamiento del árbol (unitario, spy).** *dado* un `resolveAncestors` instrumentado, *cuando* se ejecuta la suite completa de `relations/`, *entonces* el spy registra **cero** llamadas. Es la forma directa de observar «`relations/` nunca usa `resolveAncestors`», y es barata.

**Riesgo que ninguna cubre**: la frontera **por dato**. `relations/` acepta `role_binding:<scope>|<rolUuid>#assignee` como userset — es decir, `relations/` **sí** lee un artefacto de `roles/`, por cadena declarada. Hace falta el caso: *dado* un `role_binding` que ya no existe en el catálogo, *cuando* se hace `check` con ese userset, *entonces* **false** (fail-closed), no throw y no true.
**Coste**: **bajo** (≈ 0,75 d las cuatro). **Veredicto: verificable.**

---

## 7. J · Respuesta a III.6.4 y III.6.5

### III.6.4 — ¿se sostiene «un solo juez para los dos drivers»?

**Sí, pero solo con capacidades declaradas y casos negativos obligatorios. Un contrato bifurcado sería peor.**

La razón es la que se ve en los datos de hoy: el juez común pasa 40/40 y 67/67 y aun así **no ve** cuatro divergencias reales entre drivers (L0.2, L0.5, BORDE-app-uuid, L0.7). El problema del juez actual **no es que sea único: es que solo contiene lo fácil**. Bifurcarlo garantizaría que esas divergencias no las mire nadie.

Forma concreta:

```
runAuthorizationDriverContract({
  name, makeDriver, seedCatalog, cleanup,
  capabilities: {
    transactions: false,        // openfga
    truncationSignal: true,     // openfga con paginación
    denyExpiry: false,          // 1.2
  },
})
```

Con **tres reglas**, y la tercera es la que evita que esto sea una excusa:
1. El **núcleo semántico** (invariantes 1–8) corre siempre, sin condicionales. Si un driver no puede cumplirlo, no es un driver de este contrato.
2. Cada capacidad `true` añade su anexo.
3. **Cada capacidad `false` obliga a un caso negativo**: `openfga` con `transactions: false` debe **demostrar** que `grant(..., {trx})` **lanza** un error del paquete. Un `skip` no es evidencia — y hoy la suite no tiene ninguno, lo cual es su mayor virtud: no miente por omisión.

Y una cuarta, para lo que hoy falla de verdad: **añadir al núcleo los casos de paridad de bordes** (L0.5 y BORDE-app-uuid). Son los que convierten README:114 en algo cierto. Coste: ~0,3 d.

Sobre la caducidad de denies (1.3): mientras `database` pueda tenerla y `openfga` no (spike pendiente), **la respuesta honesta es no prometerla en ninguno** hasta que el spike responda. Dejar de prometer paridad es peor que retrasar la feature.

### III.6.5 — ¿CI con segundo OpenFGA?

**Sí, y es lo más barato de todo el informe. Medido.**

- Con `OPENFGA_LIST_OBJECTS_MAX_RESULTS=**3**` y datastore `memory`: la suite completa pasa **67/67** y el defecto L0.7 se reproduce (fail-open confirmado).
- Con `=1`: **3 tests existentes fallan** (`listScopes`, `listRoles`, `listRoleScopes`) por incompletitud *fail-closed*, que es ruido distinto del defecto. **No uses 1.**
- Arranque: < 5 s, sin Postgres, sin volumen.
- **Coste real: ~15 líneas en `.github/workflows/ci.yml`** (un `docker run` más en el job `openfga` y un segundo `npm test` con otra URL) + una variable de entorno para que el anexo de truncamiento sepa cuál es el máximo. **0,25 d.**

Recomendación exacta: **un solo job `openfga` con dos servidores** (`:8090` por defecto y `:8091` con `MAX_RESULTS=3`) y dos ejecuciones de la suite. Sin él, **el único defecto fail-open de L0 no se escribirá**, y es precisamente el que produce «scope denegado devuelto como concedido».

---

## 8. Tabla comparativa

| Ítem | Casos nuevos | Invariantes en riesgo | Coste de prueba | Veredicto |
|---|---|---|---|---|
| **D · L0.1** whereScopeIn vacío | 2 (+1 propiedad) | 1, 2 | bajo (pero hoy exige tocar un `private`) | verificable **con cambios** (necesita entrada pública) |
| **D · L0.2** holderTypes inyectivo | 3 (boot + cruce + revocación) | **4**, 7 | **bajo** — CONFIRMADO hoy, sin infra nueva | **verificable** |
| **D · L0.3** UnknownScopeError | 5 | **1** | medio (harness de resolutor) | verificable con cambios · **breaking** |
| **D · L0.4** semántica de expiresAt | 4 | 3, 6 | bajo, **pero reescribe 3 casos del juez** | verificable · **breaking ⇒ major** |
| **D · L0.5** identidad validada | 4 (2 por driver) | **5**, 4 | **bajo** — CONFIRMADO hoy | **verificable** |
| **D · L0.6** hasRole no decide | 4 | **2** | **bajo** — CONFIRMADO hoy | **verificable** |
| **D · L0.7** truncamiento | 4 (incl. el falso positivo) | **2, 7** | bajo **si** hay 2.º OpenFGA (0,25 d) | verificable **con cambios** |
| **D · L0.8** modelos read-only | 3 | «catálogo local» | bajo | verificable |
| **B · `relations/`** | ~34 (28 + 6 huecos) reagrupados en 18 núcleo + 12 anexo + 4 negativos | 1, 4, 5, 7 | **alto** (~3 d de infra + 2 d de casos) | **verificable con cambios** (bloqueado por 2 spikes + hueco de `membersOf`) |
| **C · `catalog/`** | 20 (8 + 12 huecos) | 6, 7, 8 | **medio** | **verificable** |
| **E · L1** | ~35 | 1, **7** | medio-bajo | verificable con cambios |
| **F · `http/`** | 12 | 2, 5 | **bajo** (1 d total) | **verificable** |
| **G · L3 hooks** | 10 | 5, 6 | **alto** (bloqueado por el pool 1/1) | **no verificable tal cual** |
| **H · L4** | 7 | 8 | **bajo** — el fail-open del sync CONFIRMADO hoy | **verificable** |
| **A · módulos** | 6 (4 estáticos/unitarios + 2 de comportamiento) | — | bajo (0,75 d) | **verificable** |
| **I · rechazos III.2** | — | — | — | **de acuerdo, y por razón de test**: `resourceScopes`/`scopeOf(tipo,uuid)` es **inobservable** — no se puede escribir un caso que distinga «no existe» de «es de otro tenant» sin convertir el motor en oráculo de existencia. `beforeWrite` unificado colisionaría con `manager.spec.ts:72`. `descendantsOf` en el paquete exigiría al juez conocer el árbol del consumidor. |

---

## 9. Infraestructura de test a construir **ANTES** de cualquier feature

Ordenada por bloqueo. Total ≈ **4,5 d** — coherente con los 5,0 d que III.4 asigna a «suite real», pero hay que gastarlos **antes**, no después.

| # | Pieza | Por qué es bloqueante | Coste |
|---|---|---|---|
| 1 | **Reloj inyectable** (`now()` en el puerto, inyectado en los dos drivers y en `checkContext()`) | Hoy `whereActive` (`database_driver.ts:71`) y `checkContext` (`openfga_driver.ts:116`) llaman a `new Date()` directamente. Sin esto: caducidad, renovación, `validUntil` exacto, sesgo de reloj (README:151) y purga de caducadas **no son observables sin `sleep`**. Toca `relations/` (3 casos), `catalog/` y L0.4. | 0,5 d |
| 2 | **Harness multi-motor con pool ≥ 2** (`TEST_DB=sqlite\|pg\|mysql`) | **Medido**: con el pool 1/1 actual un test de `{trx}` **se cuelga**. Además la suite no toca Postgres ni MySQL, que el README promete. Bloquea G entero y la mitad de `relations/`. La máquina ya tiene pg18 y mysql84 en Docker. | 1,0 d |
| 3 | **Harness de resolutor de ancestros** (árbol ficticio app→organization→unit, inyectable; variantes: ciclo, profundidad, `null`, lanza) | Los 67 tests corren con el resolutor por defecto: **el invariante 1 solo está probado en su caso trivial**, y es la costura que el README vende como principal. Bloquea L0.3, `within`, `authorizedScopes`, `hierarchicalScopeResolver`. | 0,5 d |
| 4 | **Segundo OpenFGA con `OPENFGA_LIST_OBJECTS_MAX_RESULTS=3`** en CI y en local | Sin él L0.7 (el único fail-open de L0) **no se escribe**. Verificado: con 3 la suite pasa 67/67 y el defecto se reproduce; con 1 rompe 3 tests por otra causa. | 0,25 d |
| 5 | **`tests/helpers/http.ts`**: `fakeCtx` completo (params, request, `notFound`, orden de respuestas, `next` con contador, propagación de excepciones) | `middleware.spec.ts:198` se queda corto para `resourceAccess`, donde **el orden de las comprobaciones ES la aserción de seguridad**. | 0,5 d |
| 6 | **Tablas ficticias del consumidor en el harness** (`demo_organizations`, `demo_units`, `demo_spaces` con FK) | Sin ellas no se pueden probar: FK de partición, `relationPartitionTrigger`, `membersOf` como subquery, el join defensivo del reader. Y el trigger **necesita Postgres** (depende de #2). | 0,75 d |
| 7 | **Espías de backend**: contador sobre el cliente FGA y sobre knex; y `withFailingX` genérico (elevar `contract.spec.ts:196` a helper y extenderlo a `listObjects`/`batchCheck`/`write`) | «Lista vacía sin ir al backend», «sin segundo `authorize`», «≤ ⌈N/50⌉ batchChecks», «`load` no se llama antes del 403» son **solo observables con contador**. | 0,25 d |
| 8 | **Test de grafo de módulos** + `check:purity` en el job `test` de CI | La frontera A «por construcción» y «`@openfga/sdk` fuera de la ruta `database`» **no tienen test hoy**, y el script de pureza no corre en el job que la gente mira. | 0,5 d |
| 9 | **Capacidades en `DriverContractHarness`** + regla «capacidad `false` ⇒ caso negativo obligatorio» | Es lo que permite mantener **un solo juez** (III.6.4) sin mentir sobre la paridad. | 0,25 d |

### Y tres casos que se pueden escribir **hoy**, en menos de una hora, sin nada de lo anterior

Son los cuatro defectos confirmados que no necesitan infraestructura nueva. Deberían entrar antes que cualquier plan:

1. **L0.2** — `holderTypes` no inyectivo rompe el invariante 4 (OpenFGA, ya disponible en :8101).
2. **L0.5** — paridad de validación de identidad + «un error semántico no es un 503» (los dos drivers).
3. **L0.6** — el deny no gobierna `hasRole`, y `appAccess({role})` deja pasar (los dos drivers).
4. **Invariante 8** — `rank` no se evalúa en `authorize` (los dos drivers): el único invariante de `CLAUDE.md` con **cero** cobertura.
