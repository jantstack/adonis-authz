# Fase 4 · lote 4-7 — correcciones de la revisión de fase 4 (antes de etiquetar 2.4)

> Base: `main` @ `2691d83` + el parche del tester ya aplicado (`tests/relations_harness.spec.ts`,
> INTACTO). Trabajo sobre el árbol principal. Sin commits (los hace el dueño).
> Insumos: `fase-4-auditor-final.md` (🟡1, 🟡2, ⚪3, ⚪4) y `fase-4-verificacion-tester.md`.

## Resumen

| Hallazgo | Qué era | Estado |
|---|---|---|
| **R-16** (🟡1) | `object.id` sin validar en el manager y en el driver `openfga` (solo longitud) | ✅ CERRADO — 422 en LOS DOS drivers, paridad |
| **R-17** (🟡2) | `reconcileRelations --prune` sin seguro de borrado masivo | ✅ CERRADO — 500 `E_AUTHZ_MASS_RECONCILE_REFUSED`, `--allow-mass-delete` |
| **⚪3** | `database.enumerateRelations` no filtra por tipos declarados | ✅ CERRADO — paridad con `openfga` |
| **⚪4** | `openfga:provision` republica facts-ONLY; `republishFusedModel` sin llamador en producción | ⏸️ DECLARADO para micro-lote (justificación abajo) |

**Cifras (aditivo, sin skips, rojo→verde por pieza):**

| Modo | Base | Ahora | Δ |
|---|---|---|---|
| `OPENFGA_TEST_URL npm test` (sqlite memoria) | 957 | **973** | +16 |
| `test:sqlite-file` | 962 | **979** | +17 |
| `test:pg` (postgres18) | 1056 | **1073** | +17 |
| `test:mysql` (mysql84) | 1056 | **1073** | +17 |

`tsc --noEmit` (src y test), `typecheck`, `check:purity` y `build`: verdes. Stores del `:8101`
creados por las suites y borrados por sus teardown.

---

## R-16 · `object.id` validado en el manager Y en cada driver (paridad, 422 no 503)

### Reproducción del auditor (ROJO ANTES)

Revertidos `src/identity.ts` + `src/relations/manager.ts` + `src/drivers/openfga_relations_driver.ts`
(la corrección) y corrido el grupo del manager:

```
RelationsManager — R-16 / relate con object.id "a|b" ⇒ 422 ... antes del driver
  AssertionError: a|b: expected undefined to equal 422
  ❯ 183 ┃  assert.equal(caught?.status, 422, bad)
(idéntico para "a:b", "a#viewer", "a b", "*")
```

El manager solo validaba tipo+relación (F-05); el `object.id` con `|`/`#`/`:`/espacio/`*` se
colaba al driver. En `openfga` (medido por el auditor contra el `:8101`) `a|b` se ESCRIBÍA,
`check` lo honraba, pero `listObjects`/`enumerateRelations` lo PERDÍAN (parse por el último `|`),
y los caracteres estructurales salían como **503** en vez de 422.

### La corrección

- `src/identity.ts`: nueva `assertRelationId(kind, value)` — la gramática compartida
  (`COMPONENT_FORMAT` = `/^[a-z0-9_.-]+$/`, longitud 64 = columna `varchar(64)` de
  `authz_relations`). La MISMA que `roles/` usa para el resto de la identidad; excluye `|`, `#`,
  `:`, `@`, `*`, `~`, espacios y control.
- `src/relations/manager.ts`: `#assertObjectId(object)` ⇒ 422 ANTES del driver, en
  `relate`/`unrelate`/`check`/`listSubjects`/`purgeObject` y en el `subject.object.id` del
  userset (`#assertSubject`).
- `src/drivers/openfga_relations_driver.ts`: la misma `assertRelationId` en `#objectId` (defensa
  en profundidad; cubre object y userset). `manager.driver()` salta el manager, así que el driver
  aplica su propia regla. El driver `database` YA la aplicaba (`RELATION_ID_FORMAT`): la paridad
  se restaura del lado de `openfga`.

### Casos (VERDE)

- `tests/relations.spec.ts` — grupo «R-16 (validación de object.id, antes del driver)»: `a|b`,
  `a:b`, `a#viewer`, `a b`, `*`, `A-B` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` con `relateCalls === 0`
  (nada tocó el driver); id válido pasa; userset con `g|evil` ⇒ 422; `check`/`listSubjects`/
  `purgeObject` con id inválido ⇒ 422.
- `tests/relations_openfga.spec.ts` — grupo «R-16 · object.id inválido ⇒ 422 (defensa en
  profundidad)» (contra el `:8101`): `relate` EN DIRECTO al driver con `a|b`/`a:b`/`a#viewer`/
  `a b`/`*` ⇒ **422 y no 503**; el store NO lo tiene; un id válido se escribe y `listObjects` lo
  ENUMERA (ya no se pierde).
- `tests/relations_database.spec.ts` — grupo «R-16 · object.id inválido ⇒ 422 (defensa en
  profundidad)»: el driver `database` rechaza `a|b` con 422 y CERO filas (el PUENTE de paridad:
  la MISMA respuesta que `openfga`).

---

## R-17 · seguro de borrado masivo en `reconcileRelations`

### Reproducción del auditor (ROJO ANTES)

Revertido `src/relations/reconcile.ts` y corrido un repro (origen vacío + `--prune`, destino con 2
tuplas):

```
reconcile report: {"dryRun":false,"written":0,"deleted":2,"unchanged":0,"extra":0,"modelDrift":[]}
ROJO R-17: destino antes=2 despues=0 lanzo=false
>>> BUG REPRODUCIDO: --prune con origen vacio VACIO el destino y NO lanzo
```

### La corrección

Portado el seguro de `authz:reconcile` de roles (`MassReconcileRefusedError`, invariante de higiene
de reconcile / AA2 / 3b-8·B1 — **sobre hechos UTILIZABLES, no el conteo crudo**):

- `src/relations/reconcile.ts`: `prune` + destino con tuplas que borrar + ORIGEN sin **ni una
  tupla utilizable** ⇒ 500 `E_AUTHZ_MASS_RECONCILE_REFUSED` antes de tocar nada, salvo
  `allowMassDelete: true`. «Utilizable» = tupla cuyo tipo cabe en el modelo del destino (los que
  `modelDrift` recoge no cuentan). `--dry-run` no lanza: lo marca en el nuevo campo
  `report.massDelete`.
- `commands/authz_relations_reconcile.ts`: flag `--allow-mass-delete`; el 500 sale como error de
  comando (exit 1), no como stack; `relationsReconcileLines` cuenta `massDelete` como deriva.

### Casos (VERDE)

`tests/relations_reconcile.spec.ts` — grupo «R-17 · seguro de borrado masivo» (dobles en memoria,
corre en todos los modos):

- `--prune` + origen vacío + destino lleno ⇒ 500 `E_AUTHZ_MASS_RECONCILE_REFUSED`, **destino
  intacto** (no borró nada antes de rechazar).
- origen que lee N tuplas pero TODAS de un tipo que el destino no declara ⇒ también se niega
  (la otra cara del from/to: el seguro cuenta lo utilizable, no el conteo crudo).
- `allowMassDelete: true` ⇒ el destino SÍ se vacía y `report.deleted === 2`.
- `--dry-run` ⇒ NO lanza, `report.massDelete === true`, destino intacto.
- origen con tuplas utilizables ⇒ NO dispara el seguro (poda solo lo que sobra: `deleted === 1`).

---

## ⚪3 · `database.enumerateRelations` filtra por tipos declarados (paridad `openfga`)

### Reproducción del auditor (ROJO ANTES)

Revertido `src/drivers/database_relations_driver.ts` y corrido el grupo ⚪3:

```
database relations — ⚪3 / una fila raw role_binding NO se emite; la declarada (document) sí
  ❯ 262 ┃  assert.notInclude(types, 'role_binding', 'el residuo del chokepoint NO se enumera')
```

El de `openfga` descarta todo `object_type` que no sea `group` ni un tipo declarado; el de
`database` devolvía TODA fila. Como `reconcileRelations` escribe `to.relate(...)` DIRECTO (salta el
manager/F-05), una fila raw `object_type='role_binding'` habría migrado al store compartido.

### La corrección

`src/drivers/database_relations_driver.ts`: `enumerateRelations` añade
`.whereIn('object_type', [group, ...config.objectTypes])`. Ambos drivers censan lo mismo; el
chokepoint F-05 no deja residuo por el camino de reconcile.

### Caso (VERDE)

`tests/relations_database.spec.ts` — grupo ⚪3: una fila raw `role_binding` sembrada a mano NO se
enumera; la declarada (`document`) sí; un userset (`group#member`) sobre un `document` declarado
SÍ se emite.

---

## ⚪4 · DECLARADO para micro-lote (con precisión)

**Qué es.** `openfga:provision` / `provisionOpenFgaStore` (`src/drivers/openfga_driver.ts:298`,
`commands/openfga_provision.ts`) publican `openFgaFactsModel(holderTypes, permissions)` SIN los
tipos de relación. Re-provisionar con `--store-id` un store que ya tiene relaciones configuradas +
tuplas republica un modelo facts-only, tira el tipo `document` y orfana las tuplas de relación.
Y `republishFusedModel` (que SÍ fusiona las dos mitades, `src/relations_config_store.ts:148` +
`src/drivers/openfga_driver.ts:2082`) **no tiene ningún llamador en producción** (`grep` en
`commands/`/`services/`/`providers/`: solo en tests) — el 4-6 ya lo declaró ABIERTO («el
`RelationsManager` de servicio NO se cableó»).

**Por qué NO cabe como bug-con-arreglo-conocido en este lote (medido, no supuesto):**

1. `openfga:provision` es `startApp: false` **a propósito**: es bootstrap de un appliance, se
   ejecuta ANTES de que haya base (o antes de la migración). Los tipos de relación viven en
   `authz_relations_config` (BASE), no en el `config` (que solo tiene `relations.drivers`,
   `src/define_config.ts:223` — comprobado: no hay `objectTypes` estáticos como en `catalogs`).
   Para que el comando incluya las relaciones tendría que **leer la base** (`readRelationsConfig`,
   que usa el servicio `db`) ⇒ flipar a `startApp: true`, lo que **regresa** el flujo
   «provisiona OpenFGA primero, base después» (un appliance sin base configurada no bootea).
2. La otra fuente (un `relations.config` estático en `config`) sería una **API de config nueva**,
   no un arreglo.
3. Añadir solo el parámetro opcional `relationsConfig` a `provisionOpenFgaStore` sin cablear el
   comando **replicaría exactamente el olor que el auditor señaló** (`republishFusedModel` con
   parámetro que nadie llama en producción): sería dejarlo a medias.

**Dónde encaja (el micro-lote).** `republishFusedModel` sin llamador y `openfga:provision`
facts-only son **la MISMA raíz**: el singleton `RelationsManager` de servicio que el 4-6 dejó sin
cablear. El micro-lote «cablear el servicio de relaciones» conecta de forma COHERENTE, contra
`authz_relations_config` persistida: (a) el `RelationsManager` de runtime, (b) toda republicación
de plataforma SIEMPRE por `republishFusedModel` (su único llamador de producción), y (c)
`openfga:provision` — resolviendo ahí la tensión bootstrap-sin-base (p. ej. `--store-id` con
`startApp: true` y lectura guardada de la config persistida, o un guard que REHÚSA republicar
facts-only sobre un store que ya declara tipos de relación no incluidos, que es la otra mitigación
que el auditor listó y convierte la pérdida SILENCIOSA en una negativa RUIDOSA — pero requiere
leer y parsear el modelo del store, alcance especulativo para un lote de correcciones).

**Riesgo interino (escrito, no escondido).** Hasta ese micro-lote, `openfga:provision --store-id`
sobre un store con relaciones vivas republica facts-only y orfana las tuplas de relación
(fail-CLOSED: `check` deja de resolver, no concede de más; y provisionar sobre un store vivo es
semi-error-de-operador). No es 🔴/🟠 explotable (el propio auditor lo clasificó ⚪).

---

## Notas

- Sin `skip`. Todos los errores con `status` + `code` (R-16: 422 `E_AUTHZ_INVALID_IDENTITY`, no
  503; R-17: 500 `E_AUTHZ_MASS_RECONCILE_REFUSED`).
- Paridad `database ↔ openfga` como puente que exige la MISMA respuesta: R-16 (los dos drivers
  rechazan `a|b` con 422) y ⚪3 (los dos censan solo tipos declarados).
- El parche del tester (`tests/relations_harness.spec.ts`) NO se tocó; se construyó encima.
</content>
</invoke>
