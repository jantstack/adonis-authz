# Fase 1 · Lote 1D — verificación del tester (2026-08-28)

Worktree aislado en `d5362b7` (`v2/fase-0`, cierre del lote 1D). Node 22.23.2, `npm ci` limpio.
OpenFGA compartido `:8101` (v1.19.0, 48 stores ajenos, intactos) y servidor **tope 3** propio
`authz-tiny-8110` (`OPENFGA_LIST_OBJECTS_MAX_RESULTS=3`, `OPENFGA_LIST_USERS_MAX_RESULTS=3`),
**eliminado al terminar** (`docker rm -f authz-tiny-8110`, comprobado).

> Nota de contexto: **mi informe anterior (`fase-1-verificacion-tester.md`) y el parche
> `tests-tester-fase-1.patch` ya no existen** — vivían en el worktree `agent-abcaaf7b01ef051e5`,
> que fue borrado, y nunca se commitearon. He reconstruido H1/H2/H3/H4/H5/H6/H7 y T1/T2 desde
> su descripción en `fase-1-correcciones.md` (E1–E3, D5, D6). Si el dueño quiere trazabilidad
> del informe original, ya no la hay: recomiendo commitear los informes de `.claude/contexto/`
> o sacarlos del `.gitignore`.

---

## 1. Suites ejecutadas (medidas, no citadas)

| Configuración | Comando | Resultado | Esperado por el informe |
|---|---|---|---|
| SQLite | `npm test` | **174 passed** (5 s) | 174 ✅ |
| OpenFGA `:8101` | `OPENFGA_TEST_URL=http://localhost:8101 npm test` | **241 passed** (14 s) | 241 ✅ |
| Tope 3 `:8110` | `OPENFGA_TEST_URL=http://localhost:8110 npm test` | **241 passed** (12 s) | 241 ✅ |
| Typecheck | `npm run typecheck` / `npm run typecheck:build` | 0 / 0 | ✅ |
| Pureza | `node scripts/check_purity.mjs` | ✔ reglas 1–3 | ✅ |
| Build | `npm run build` | ok, `build/src/openfga.js` presente | ✅ |

Con el test que añado (§5): **175 / 242 / 242**, typecheck verde.

**Carga sin SDK (D9), sobre el build, no sobre las fuentes:**

```
$ node --import @poppinss/ts-exec tests/helpers/load_without_sdk.ts ../../build/index.js
loaded:../../build/index.js
$ node --import @poppinss/ts-exec tests/helpers/load_without_sdk.ts ../../build/src/openfga.js
… code: 'ERR_MODULE_NOT_FOUND'   ← control: el subpath SÍ necesita el SDK
```

El control es lo que demuestra que el hook actúa (un `--import` sin `module.register()` da un
falso verde; el helper del repo lo hace bien). Reproduje además el bloqueo con un script propio:
al cargar `build/index.js` con el SDK bloqueado el grafo estático **resuelve entero** (el fallo
que aparece sin app booteada es de Lucid, no del SDK), que es la prueba fuerte.

**Higiene de stores `:8101`**: 48 antes → **48 después**, 0 con prefijo de la suite
(`contract-`, `regrant-`, `import-`, `orphan-`, `spies-`) tras ~14 corridas, varias con mutantes
que abortaron a mitad. Sin fugas.

**Sin `skip` ni `only`** en `tests/` ni en `src/testing/` (grep = 0).

---

## 2. Campaña de mutantes: D × mutante × resultado

Regla aplicada: la mutación va **siempre en `src/`** (o `index.ts`), nunca en un test; se restaura
con `git checkout --` antes del siguiente. "Muere" = falla al menos un caso **por la razón que la
corrección dice arreglar**.

| # | Mutante aplicado (en `src/`) | Config | Muertos | Fallo real observado | ✅/❌ |
|---|---|---|---|---|---|
| **D1** | `batchCheckAll`: elimino `const failed = results.find(r => r.error)` y su `throw` | SQLite | 3 | `expected AssertionError: debería haber lanzado … to be an instance of AuthorizationBackendError`; `expected undefined to equal 503` ×2 (rol, deny, `hasRole` devolvían **false**) | ✅ |
| **D2a** | `manager.#write`: quito `notify({...event, indeterminate: true})` | SQLite | 1 | `expected [] to deeply equal [['granted',true],['denied',true]]` | ✅ |
| **D2b** | Cliente FGA sin `maxRetry: 0` por defecto | SQLite | 1 | `expected 3 to equal +0` (el default del SDK) | ✅ |
| **D3a** | `resolveDisjointCatalogs`: quito el `throw CatalogConflictError` | SQLite | 1 | `sync: debería haber rechazado: expected undefined to equal 422` | ✅ |
| **D3b** | `syncAuthzCatalog`: comento la colisión tras codificar **contra la BD** | SQLite | 1 | `expected undefined to equal 422` | ✅ |
| **D4** | `purgeScope`: un `DELETE` fuera de `this.sql(...)` (sin `guardSql`) | SQLite | 1 | `expected [5000, …(17)] to deeply equal [5000, …(17)]` (L0.13 extendido) | ✅ |
| **D5** | Quito los **4** filtros por catálogo de openfga (`hasRole`, `listRoles`, `listRoleScopes`, `listSubjects`) | SQLite | 2 | `expected ['editor','fantasma'] to deeply equal ['editor']`; `listSubjects` devuelve al holder | ✅ |
| **D5** | idem | `:8101` | 3 | además **T1** del contrato: `expected true to be false` (`hasRole` sobre el rol retirado) | ✅ |
| **D6a** | `isDuplicateWrite` ⇒ `true` (el `catch {` desnudo de antes) | SQLite | 1 | el 400 `validation_error` se trataba como carrera y se reintentaba | ✅ |
| **D6b** | `withPreserveRecipe` no toca el mensaje | SQLite | 2 | `expected '…' to include '{ expiresAt: null }'` | ✅ |
| **D6c** | `isDuplicateWrite` ⇒ `false` (el duplicado real deja de ser carrera) | `:8101` | 3 | `FgaApiValidationError: cannot write a tuple which already exists` sale como 503 al llamante | ✅ **prueba que la carrera del contrato es real contra el servidor** |
| **D7** | `assertExpiresAt` ⇒ `return` incondicional | SQLite | 3 | `debería haber rechazado` (contrato, ambos drivers) + `expiresAt string: expected undefined to equal 422` (manager) + typecheck | ✅ |
| **D8a** | `listRoles` no corta con cadena `null` (ambos drivers) | SQLite | 1 | `expected ['org-editor'] to deeply equal []` (contrato 2.0) | ✅ |
| **D8b** | `knownOnly` devuelve los scopes sin filtrar | SQLite | 1 | `expected [ …(2) ] to deeply equal [ Array(1) ]` | ✅ |
| **D9** | `index.ts` vuelve a re-exportar `OpenFgaAuthorizationDriver` | SQLite | 1+2 | `check:purity` ✖ (`index.ts → importa la ruta openfga`), `purity.spec` `to not include 'openfga_driver'`, y la carga bloqueada: `Cannot find package '@openfga/sdk'` | ✅ (triple red) |
| **D10a** | `removeDeny` (database) vuelve al no-op silencioso | SQLite | 1 | `debería haber rechazado` | ✅ |
| **D10b** | `revoke` (openfga) sin `findRoleOrFail` | `:8101` | 1 | `debería haber rechazado` (el contrato lo juzga en los dos drivers) | ✅ |
| **D11** | `assertIdentity` deja de validar `roleSlug` | SQLite | 3 | `expected 503 to equal 422`; `expected 'E_AUTHZ_UNKNOWN_ROLE' to equal 'E_AUTHZ_INVALID_SLUG'` — exactamente H4 del auditor | ✅ |
| **D12** | `readAllTuples` sin guard de token repetido ni cota | SQLite | — | **`FATAL ERROR: Ineffective mark-compacts near heap limit — JavaScript heap out of memory`**: el runner muere | ✅ (muerte sucia, ver hueco 4) |
| **D13** | `resolveChain` no valida la respuesta del resolutor | SQLite | 1 | `[{"type":"app","uuid":"X"}]: expected 422 to equal 503` — literal H11 | ✅ |
| **D14a** | `reconcile` no enumera el store (`readPages` vacío) ⇒ `extra` siempre 0 | `:8101` | 1 | `expected { written:0, … } to deeply equal { … }` (el `extra: 3`) | ✅ |
| **D14b** | `prune` cuenta pero no borra | `:8101` | 1 | `expected [ {key…} ] to have a length of +0 but got 1` (la tupla ajena sobrevive) | ✅ |
| **D15a** | Catálogo sin `guardSql` (sync y diff) | SQLite | 1 | `no such table: authz_permissions: expected undefined to equal 503` — literal H15 | ✅ |
| **D15b** | Holder no declarado ⇒ `Error` genérico sin `code` | SQLite | 1 | `expected undefined to equal 500` | ✅ |
| **D16** | `readAllTuples`: `continuationToken = undefined` ("no seguir el token") | `:8101` | 6 | **el caso del juez**: `orgB está denegada y se listó como concedida: expected [ …(2) ] to not include 'organization:01a04a03…'` | ✅ |
| **E1** | El manager no normaliza el `void` del driver de terceros | SQLite | 1 | (H4 del parche) | ✅ |
| **E3** | `assertScope` acepta el uuid centinela | SQLite | 4 | incluido el caso nuevo: `expected 'E_AUTHZ_UNKNOWN_SCOPE' to equal 'E_AUTHZ_INVALID_IDENTITY'` — **el caso de H1 discrimina de verdad** | ✅ |
| **E4** | `TYPE_FORMAT` acepta mayúsculas | SQLite | 2 | `debería haber rechazado`; `scopeType en mayúsculas: expected undefined to equal 422` | ✅ |
| **HUECO** | Desactivo **solo** la cota `pages >= MAX_READ_PAGES` (dejo el guard de token repetido) | `:8101` | **0** | **241/241 verdes: mutante superviviente** | ❌ |

**28 mutantes, 27 muertos, 1 superviviente** (cerrado con el test de §5).

Verificación cruzada de D6 (lo más delicado del lote): la desviación 1 del implementador es
**cierta y la medí**. OpenFGA v1.19 devuelve el duplicado como HTTP **400**
`write_failed_due_to_invalid_input` / `cannot write a tuple which already exists`, no como 409;
el mutante D6c lo hace visible con el error real del servidor, y el fake de los unitarios
reproduce esa forma. El 409 tampoco es código muerto: `racingDriver(['duplicate', 409])` lo
ejercita.

---

## 3. Mis 5 tests del parche y los hallazgos H1/H5/H6/H7

| Origen | Dónde está hoy | Estado |
|---|---|---|
| **H2** — `hasRole` por nivel con una fila escrita a mano | `tests/database_driver.spec.ts:265` «un rol de nivel app asignado a un scope de organización no da hasRole» | ✅ presente y verde |
| **H3** — `purgeScope(APP_SCOPE)` en database | `tests/database_driver.spec.ts:225` «purgeScope(APP_SCOPE) es 422 y no toca los hechos del nivel app» | ✅ |
| **H4** — driver de terceros que devuelve `void` | `tests/manager.spec.ts:76` (+ E1 en `src/manager.ts:180`) | ✅ muere con el mutante E1 |
| **T1** — rol retirado del catálogo (openfga, unitario) | `tests/openfga_driver.spec.ts` grupo D5 | ✅ **con la semántica invertida** (ver abajo) |
| **T2** — rol retirado deniega (contrato con servidor) | `tests/contract.spec.ts:261` «rol borrado del catálogo: la tupla sigue en el store pero authorize deniega» | ✅ |
| **H1** — el centinela debe discriminarse de `UNKNOWN_SCOPE` | `src/testing/contract.ts:748` (caso nuevo, cuelga el centinela del árbol) | ✅ **cerrado**, y el mutante E3 lo demuestra |
| **H5** — la guarda `expiresAt === undefined` de la rama de carrera sin test | grupo D6 de `openfga_driver.spec` (4 casos) | ✅ cerrado (mutantes D6a/D6b/D6c) |
| **H6** — `IDENTITY_LIMITS.slug` muerto / "slug 100" en CLAUDE.md | campo eliminado (`src/identity.ts:32`), `CLAUDE.md` dice **42** = `MAX_SLUG_LENGTH` | ✅ cerrado |
| **H7** — `middleware.spec` sin fijar `status`/`code` | `tests/middleware.spec.ts:49-50`: `500` / `E_AUTHZ_CONFIG` | ✅ cerrado |

**Acepto el cambio de semántica de T1 (desviación 4 del implementador).** Mi parche afirmaba
`hasRole` **true** sobre la tupla huérfana ("es membresía, se lee del store"); D5 fija lo
contrario y es la decisión correcta: la paridad entre drivers vale más que mi lectura, y
*database* nunca pudo reportar esa membresía. El caso reescrito es más fuerte que el mío porque
además comprueba con un cliente crudo que **la tupla sigue en el store** — que es lo que acota
honestamente la promesa de `purgeScope`.

---

## 4. Huecos

### 4.1 Cerrado por mí — cota de páginas de `Read` no observable (era ❌, ahora ✅)

D12 promete: *"token repetido **o > 10.000 páginas** ⇒ 500 `E_AUTHZ_INTERNAL`"*. Solo la primera
mitad estaba probada. Desactivando **únicamente** `pages >= MAX_READ_PAGES` (en las dos copias:
driver e importador) la suite queda en **241/241 verdes**: un servidor —o un proxy/caché— que
devuelve un `continuation_token` **nuevo en cada página** nunca repite, así que el guard del
token no lo para y el bucle vuelve a ser el H7 del auditor. `grep MAX_READ_PAGES tests/` = 0.
Cerrado con un test (§5) que mata ese mutante.

### 4.2 🟡 D2 — el "ANTES de propagar" no se observa

El caso `manager.spec` mira `events` **después** de que la llamada rechace: fija que el evento
existe y que lleva `indeterminate: true`, no que se emitió antes de que el llamante recibiera el
503. Un `void this.#notify(...)` sin `await` pasaría igual. Cómo observarlo: hook que espera en
un *deferred*; afirmar que la promesa de `grant` **no** ha resuelto todavía; liberar el deferred
y entonces esperar el rechazo. Coste bajo. No bloqueante (el orden solo importa si el proceso
muere entre medias, y ahí no hay garantía posible).

### 4.3 🟡 D2 — `maxRetry: 0` se prueba por configuración, no por comportamiento

El test espía `client.configuration.retryParams`. Nadie prueba que un `writeTuples` que vence el
deadline **no** aterrice después (la escritura fantasma de H1). Es difícil de observar de verdad:
haría falta un servidor lento controlable (un proxy que retrase 1 s y cuente writes) + `timeoutMs`
corto + releer el store. Coste medio, se puede montar con el `net.createServer` mudo que ya existe
convertido en proxy. Hoy: 🟡 *se puede testear, propongo cómo*.

### 4.4 🟡 Los mutantes de bucle mueren por OOM, no por aserción

Tanto D12 como mi test nuevo, sin la cota, matan el **proceso entero** (`FATAL ERROR: … heap out
of memory`) en vez de fallar un caso. La regresión se ve (la suite no pasa), pero el mensaje no
dice cuál. Es inherente al defecto; lo dejo anotado para que nadie interprete un OOM futuro como
"flaky".

### 4.5 🟡 `commands/` no tiene ni un test de comportamiento

`openfga:import` decide flags (`--prune`, `--reconcile`, `--dry-run`), y tiene lógica propia: el
aviso *"N tupla(s) … SIGUEN concediendo"* cuando `extra > 0` sin `--prune`, y el `deleted` cuando
sí. D14 y el README documentan la convergencia **a nivel de CLI**; la cobertura es solo de la
función `importAuthzFactsToOpenFga`. Un `@flags.boolean` mal nombrado o cableado al campo
equivocado se publica en verde. Igual para `authz:catalog:sync --keep-links` y `openfga:provision`.
Es **preexistente**, no lo introdujo el lote D. Cómo cerrarlo: `AceFactory` de `@adonisjs/core`
(kernel de ace en memoria) + el store `:8101`; coste medio.

### 4.6 🟡 D5 — la promesa acotada de `purgeScope` no tiene caso

`types.ts`/README dicen ahora: *"purga todo hecho de ese scope cuyo rol/permiso esté en el
catálogo … los hechos de roles retirados los recoge `authz:reconcile` (3b)"*. Lo que hay probado
es que un binding huérfano **no es membresía** (T1). Nadie fija que **sobrevive a `purgeScope`**,
que es justo el borde que la frase confiesa. Un caso: grant → sacar el rol del catálogo →
`purgeScope(org)` → la tupla sigue viva (cliente crudo) y `authorize` false. Coste bajo. Lo dejo
propuesto y no escrito para no ampliar el diff del lote sin pedirlo.

### 4.7 Aserciones relajadas respecto a `188d625`: dos, ambas justificadas y todavía letales

| Qué se relajó | Compensación | Veredicto |
|---|---|---|
| L0.13: `queries.map(q => q.timeout)` → excluye `BEGIN`/`COMMIT` | fija que los excluidos son **exactamente 2**, y que existe un `DELETE … authz_denies` entre los que sí llevan deadline | Legítima: knex no permite `.timeout()` en el control de transacción. El mutante D4 sigue muriendo ✅ |
| `runCatalogDiff([before, after])` → `[after]` | pasar el mismo rol dos veces es ahora `E_AUTHZ_CATALOG_CONFLICT` (D3): el caso probaba otra cosa | Legítima; el conflicto tiene su propio caso ✅ |

No encontré ninguna otra línea de aserción eliminada o debilitada en el diff `188d625..d5362b7`
(revisé todas las líneas `-` de `tests/` y `src/testing/contract.ts`).

### 4.8 Tests que pasen por la razón equivocada: no encontré ninguno

Los sospechosos que probé con mutante dirigido —E3 (el implementador confiesa que nació verde),
E1, E4, los cuatro filtros de D5 por separado, las dos mitades de D3, las dos de D14— **mueren
todos**. El único que pasaba por no probar nada era la cota de páginas (4.1).

### 4.9 `contract_harness` coherente

`assert.lengthOf(core, 36)` / `assert.lengthOf(full, 49)` y, además, que **todo caso core está en
2.0** y que el par de capacidad se juzga en todos los niveles. Coincide con el informe (32/44 →
36/49) y con `CLAUDE.md`. Un caso nuevo del juez sin actualizar el conteo rompe la suite: la
guarda funciona. ✅

### 4.10 README / CLAUDE.md: ninguna afirmación sin test

Comprobé **las 55 citas** de nombres de test que el README pone entre comillas contra `tests/` y
`src/testing/`: **55/55 existen** (la única que no casó literal, *"todo check lleva
context.current_time; toda llamada HIGHER_CONSISTENCY"*, es el mismo caso con el título abreviado:
`openfga_driver.spec.ts:263`). Las promesas nuevas de `CLAUDE.md` (invariantes 9–13) tienen todas
un caso: 9 → D8/L0.3, 10 → tres estados, 11 → purga + `E_AUTHZ_PURGE_INCOMPLETE`
(`openfga_driver.spec.ts:465`), 12 → D3/D5, 13 → D2. La única frase que va por delante de la
cobertura es la de `maxRetry` (4.3), y es honesta en lo que afirma (el default, no el efecto).

---

## 5. Parche entregado (1 test, nada en `src/`)

Aplicado en mi worktree y guardado en
`/home/jose/proyectos/Personal/adonis-authz/.claude/worktrees/agent-a5980f2326c467bf2/tests-tester-fase-1d.patch`.
Verificado: **verde con el código actual (175/242/242) y muerte del mutante** que desactiva
`pages >= MAX_READ_PAGES` (sin la cota, OOM). No toca `src/`: la implementación ya era correcta,
lo que faltaba era la prueba.

```diff
diff --git a/tests/openfga_driver.spec.ts b/tests/openfga_driver.spec.ts
--- a/tests/openfga_driver.spec.ts
+++ b/tests/openfga_driver.spec.ts
@@ -12,6 +12,9 @@ import {
   correlateBatchResults,
   parseBindingId,
 } from '../src/openfga.js'
+// La cota no se re-exporta por el subpath (es un detalle del driver): el
+// test la importa de donde vive para no fijar el número a mano.
+import { MAX_READ_PAGES } from '../src/drivers/openfga_driver.js'
 import { AuthorizationBackendError } from '../src/errors.js'
 import { APP_SCOPE } from '../src/types.js'
 import { withTableMissing } from './database_driver.spec.js'
@@ -1049,6 +1052,37 @@ test.group('openfga — la paginación de Read está acotada (D12)', (group) =>
     assert.isBelow(reads, 10)
   })
 
+  test('un continuation_token que SIEMPRE cambia se corta en MAX_READ_PAGES, no gira para siempre', async ({
+    assert,
+  }) => {
+    // El guard del token repetido no cubre la otra mitad de H7: un servidor
+    // (o un proxy) que devuelve un token NUEVO en cada página nunca repite,
+    // así que solo la cota de páginas lo para. Sin ella el bucle crece hasta
+    // reventar el heap, que es como se reprodujo el hallazgo original.
+    const driver = unreachableDriver()
+    let reads = 0
+    ;(driver as any).client.read = async () => {
+      reads += 1
+      return {
+        tuples: [{ key: { user: 'user:u', relation: 'assignee', object: 'role_binding:app|editor' } }],
+        continuation_token: `token-${reads}`,
+      }
+    }
+    let caught: any
+    try {
+      await driver.listRoles({ type: 'users', uuid: uuidv7() }, APP_SCOPE)
+      assert.fail('debería haber lanzado')
+    } catch (error) {
+      caught = error
+    }
+    assert.equal(caught.status, 500)
+    assert.equal(caught.code, 'E_AUTHZ_INTERNAL')
+    assert.include(caught.message, 'páginas')
+    // Se para EN la cota: ni antes (rompería una enumeración legítima grande)
+    // ni después (no hay segunda vuelta).
+    assert.equal(reads, MAX_READ_PAGES)
+  }).timeout(30_000)
+
   test('una tupla sin user/relation/object se cuenta en diagnostics y se registra, no se descarta en silencio', async ({
     assert,
   }) => {
```

Al aplicarlo hay que subir el conteo del informe a **175 / 242 / 242**. No afecta a
`contract_harness` (no es un caso del juez).

---

## 6. Veredicto

### **APTA CON CORRECCIONES** para cerrar la Fase 1.

La única corrección es **aplicar el parche de §5** (un test, cero cambios en `src/`). Con él, la
Fase 1 queda cerrada por lo que a verificabilidad se refiere.

Fundamento:

- Las **16 correcciones D1–D16 son observables y letales**: 27 de 28 mutantes muertos, cada uno
  por la razón que la corrección declara arreglar, y en la configuración que corresponde (D5, D6,
  D10, D14 y D16 se juzgan **contra el servidor real**, no solo con fakes).
- El caso del juez de D16 mata el mutante "no seguir el token" — el objetivo explícito de la
  corrección — y el de D6c demuestra que la carrera del contrato es una carrera **real** de
  OpenFGA v1.19, con el error del servidor de verdad.
- Los tres conteos del informe (174 / 241 / 241) son **exactos**, en las tres configuraciones, y
  `build/index.js` carga con `@openfga/sdk` bloqueado **con el control negativo** que hace la
  prueba honesta.
- Mis siete hallazgos anteriores están cerrados; el único desacuerdo (T1) se resolvió a favor de
  la paridad entre drivers, con un caso más fuerte que el mío.
- El resto de huecos (4.2–4.6) son 🟡: se pueden testear, ninguno oculta un comportamiento
  incorrecto de hoy, y 4.5 es deuda preexistente. Los llevo a la Fase 2 como propuestas, no como
  bloqueo.

Lo que **no** juzgo aquí: arquitectura (subpath, modelo FGA) y seguridad — son del analista y del
auditor. Mi veredicto es exclusivamente sobre si el lote se puede demostrar. Se puede.
