# Panel de metodología: veredicto del juez (2026-09-13)

Entradas: `09-METODOLOGIA-DE-DESARROLLO.md`, `CLAUDE.md` § «Cómo se decide un cambio», `metodologia-diagnostico-coordinador.md`,
`panel-metodologia-{analista,auditor,tester}.md`, `decisiones-dueno-2026-08-28.md` §2026-09-13 (2) y (3). He comprobado
en el código dos premisas de las que depende el veredicto:
- Las guardias por enumeración que cita el analista existen: `uncoveredCapabilities`/`BOTH_FACES_REQUIRED` en
  `src/testing/contract.ts:4708,4726`, C-5 en `tests/commands.spec.ts:112` y A-G-2 en `tests/command_flags.spec.ts:163`.
- El hueco `--to=database` sin `--from` aparece como cerrado en el lote alpha.10: el guard mira el origen RESUELTO
  (`alpha10-informe.md` §A1, `:161-184`). Lo he leído en el informe y no lo he medido.

Criterios y pesos, fijados según la sugerencia del encargo antes de puntuar:

| Criterio | Peso | Qué mide |
|---|---|---|
| Defectos evitados, medidos | 35 | Contrafactual del analista sobre 34 graves, más lo que midieron el auditor y el tester |
| Riesgo de ceremonia o de falsa seguridad | 25 | Si un verde puede leerse como permiso sin cubrir lo que dice cubrir |
| Verificabilidad | 20 | Si tiene un pasa/falla sin opinión y no se puede burlar |
| Coste | 20 | Horas de construcción, horas recurrentes y segundos de suite con la RAM justa (10 = lo más barato) |

**Regla de descalificación** (el equivalente del «rojo no mitigado»): **una medida cuyo verde se usaría como permiso sin
cubrir lo que dice cubrir queda descalificada en esa forma.** Puede adoptarse transformada, pero no tal cual.

---

## Veredicto

**Recomendación.** Adoptar la **guardia estructural de superficie (M7)**, que puntúa 78/100, con cuatro piezas:
- la **regla de tres (M8)** como disparador;
- el **mutante por bandera** como la forma en que M7 prueba la cobertura de la CLI (así M7 absorbe a M2);
- la **tabla de verdad (M3)** en los cierres;
- **el runbook ejecutable (M1) alimentado por la lista de estados (M5)**.

La razón decisiva: **los «círculos» del dueño son linajes medidos.** Son 6 linajes que explican 17 de los 34 graves, y la
causa es que cada cierre tapa un punto de llamada y elige a mano su alcance. M7 es la única medida que convierte ese alcance
en una enumeración que falla sola.

**Injertos de otras posturas:**
- Del auditor: **listar gemelos** en cada cierre y **«la salida dice qué rama corrió»** como convención con caso de letra.
- Del auditor: **la auditoría de sistema sin diff (M4) se queda, pero periódica y con rotación de perspectiva**. No es un gate.
- Del tester: la dirección contraria de M6 («casos existentes que el arreglo pone rojos, justificados») como una línea del
  cierre. El resto de M6 se descarta.
- Del analista: la **peor instancia de todo precio declarado**, dentro de M5.

**Condición para proceder:** M7 solo cuenta si la cobertura de cada entrada se demuestra con un **mutante que la mata**, no
con presencia. El tester midió que la presencia se burla: 5 de 27 presencias de banderas son decorativas. M7 empieza con un
piloto sobre F-05 y sobre el origen del reconcile, con un tope de 3 h. Si no se consigue expresar cobertura por mutante, M7
se limita a las guardas donde sí se consigue.

## Tabla de puntuación

Escala 0–10 por criterio, total ponderado sobre 100. Cuando una medida tiene dos formas, se puntúan las dos por separado.

| Medida (forma) | Defectos (35) | Ceremonia/falsa seg. (25) | Verificab. (20) | Coste (20) | **Total** | Nota |
|---|---|---|---|---|---|---|
| **M7** guardia de superficie, cobertura por mutante | 10 | 6 | 9 | 5 | **78** | 11,0 en el contrafactual y 5 defectos que no toca ninguna otra (nº 7, 11-14). 6-10 h [A]. Riesgo: que las exenciones acaben siendo un sello |
| **M1+M5** runbook con pasos sacados de los estados, relaciones cableadas y job obligatorio | 7,5 | 7 | 9 | 4 | **70** | El tester lo diseña y el contrafactual da 4 de 4 de alpha.9/10. El auditor da la condición: relaciones y ventana caducada ANTES de la pasada |
| **M2** mutante inerte por bandera | 4 | 8 | 10 | 7 | **68** | 22/34 protegidas hoy. 29 s. Pasa a ser la entrada CLI de M7 |
| **M3** tabla literal con guardia de producto | 6,5 | 5 | 8 | 8 | **67** | El prototipo dio rojas las filas `app`+uuid. Los ejes se eligen por intuición, así que el exit y el estado externo son obligatorios |
| **M4** periódica, rotando perspectiva, entrega repro | 8 | 5 | 5 | 6 | **62,5** | Piloto medido: 15-20 min, 1 rojo y 2 naranjas |
| **M8** regla de tres | 2 | 8 | 6 | 10 | **59** | Sola se queda en intención; es el disparador de M7 |
| **M5** estados más peor instancia, como entrada de M1 | 6 | 4 | 6 | 8 | **59** | Sin destino ejecutable se rellena mecánicamente |
| **Gemelos** con tabla fija de pares | 5 [A] | 5 | 5 | 9 | **58** | S1 rojo y S3 naranja del auditor. Réplicas roles↔relaciones: nº 5, 8, 10-14 (estimación mía) |
| **Rama en la salida** con caso de letra | 3 [A] | 7 | 8 | 7 | **58** | S2, S5, S6 del auditor; nº 31, 33 y 34 en parte |
| M4 **como gate APTA** | 8 | 1 | 2 | 6 | 46,5 | **Descalificada como gate**: tras las 5 APTA finales llegó un grave |
| M1 **tal cual** (runbook del README) | 4 | 2 | 8 | 5 | 45 | **Descalificada**: pasaría en verde con S3 y S2 (auditor) |
| M2 **presencia** (≥ 1 `exec`) | 3 | 2 | 5 | 9 | 43,5 | **Descalificada**: la engañan `skip`, un `exec` sin aserción o un caso bajo `if` (tester) |
| M6 transformada (parche por mutación y dirección contraria) | 1 | 4 | 7 | 4 | 35,5 | Lo útil ya existe: el mutante del rojo→verde |
| M6 **tal cual** | 0 | 1 | 3 | 4 | 16,5 | **Descartada**: tres lecturas falsas medidas y 0 decorativos reales |

Cómo se convierten las puntuaciones del analista a la columna «Defectos»: 11→10, 9→8, 7→6,5, 6→5,5, 5,5→5, 3→3, 0→0.
M1+M5 sube a 7,5 porque el tester muestra que con los pasos de M5 caza los cuatro de alpha.9/10. «Gemelos» y «rama» no
están en el contrafactual del analista: su 5 y su 3 son estimaciones mías sobre la tabla del §1 del analista y los hallazgos
del auditor, y las marco [A].

## Decisión 1 · Qué se adopta, qué se transforma y qué se descarta

| Medida | Decisión | Forma adoptada |
|---|---|---|
| M1 | **transformar** | Runbook como **un test con pasos numerados**. Los pasos salen de la lista de estados de M5 × comandos, **no del README**. Condiciones: relaciones cableadas en dos particiones; ventana caducada ANTES y DURANTE la pasada; repetida en dirección rancia en las dos direcciones. Hijo por fase y reloj por IPC. Job `cutover-runbook` obligatorio (pg y sqlite-file; mysql si cabe). La sección «Cutover runbook» del README se afirma igual a la tabla de pasos: **la tabla es la fuente y el README la sigue**. Sin `.skip` y con presupuesto de 30 s |
| M2 | **transformar y absorber en M7** | Mutante inerte por bandera (`scripts/check_flag_mutants.mjs`): cada bandera booteada tiene ≥ 1 rojo. Una excepción necesita razón escrita. `--from` se prueba con 3 drivers en vez de exceptuarse. Corre en el job con `OPENFGA_TEST_URL` |
| M3 | **adoptar en los cierres** | Solo cuando el arreglo depende de ≥ 2 entradas discretas o de estado externo. Dominios declarados y guardia de producto cartesiano. **Exit code y rama son ejes obligatorios**, igual que el estado externo (`default`, ventana, cola). Una fila cuya fuente es «lo que hace hoy» no vale. Cada fila dice en qué capa se juzga |
| M4 | **transformar: periódica, no gate** | Una pasada por RC y otra tras cada grave que reporte COGNITIV. **Cada pasada con una perspectiva distinta**, registrada en `auditorias-sistema.md`. Entrega repro (verde = defecto) que pasa a test. **Nunca entrega APTA** |
| M5 | **adoptar como entrada de M1 y de M3** | En paneles de operación larga: estados antes, durante, después, abortada, caducada y repetida, más la peor instancia de todo precio declarado. Cada estado tiene destino: paso del runbook, caso, o «imposible porque» |
| M6 | **descartar** | Se injerta una sola línea en el cierre: los casos existentes que el arreglo puso rojos, cada uno justificado |
| M7 | **adoptar** | Guardias sobre F-05, freeze, `transaction`, actor, evento (inv. 13/14), entrada desconocida, origen del reconcile y banderas. Enumeración por reflexión. **Cobertura = mutante que la mata**. Exención con motivo y firma del dueño |
| M8 | **adoptar** | `linajes.md` con los 6 linajes y su propiedad en forma universal. La 3.ª iteración no se parchea: punto de paso único más su entrada en M7 |
| Gemelos | **adoptar** (ya aplicado en caliente) | Tabla fija de pares: roles↔relaciones, comando↔manager↔función exportada, `reconcile`↔`relations:reconcile`, `relay`↔`requeue --apply`. Un par que produce dos defectos pasa a ser guardia de paridad en M7 |
| Rama en la salida | **adoptar** | Cada rama de un comando imprime una línea distinta con exit propio y tiene caso de letra. Ejemplos de ramas: ventana propia, ajena o caducada; cola vacía, aplazada o `missing` |

**¿M7 absorbe a M2 y a M3?** **A M2 sí**, con una condición: la cobertura de las banderas dentro de M7 es el mutante inerte
y no la presencia. Si fuera la presencia, M7 heredaría la burla que midió el tester. **A M3 no.**
- M7 cubre el eje de **superficie**: qué operación, qué capa o qué puerto quedan sin la guarda.
- M3 cubre el eje de **valores dentro de una entrada**: `app` × uuid no es una entrada sin guarda, es una combinación.

La evidencia es el prototipo de M3 del tester: sus filas rojas no las habría dado ninguna enumeración de entradas.

## Conflictos entre panelistas

- **M6. Analista: 0 / Tester: «solo con mutación mínima o no adoptar».** No hay contradicción de fondo: los dos llegan a
  descartarla como medida. El tester midió 0 decorativos reales en 4 defectos y tres lecturas falsas. La mutación mínima ya
  es regla vigente (principio 2: «un test que nunca estuvo rojo no cuenta»). Queda la dirección contraria como una línea del
  cierre, con coste cero: la suite ya corre. Resuelto con la medición del tester.
- **M4. Analista: «no como gate» / Auditor: «vale, rotando perspectiva».** Son compatibles: es buen **detector** (3 graves
  en 15-20 min, medidos) y mal **gate** (el historial de las 5 APTA). La estimación del analista de 3-6 h por pasada [A] la
  contradice el tiempo medido del piloto, y gana lo medido. El propio auditor avisa de que la primera pasada recoge lo
  acumulado. Por eso M4 queda periódica, con rotación y con repro como entrega. **Condición necesaria, nunca suficiente.**
- **M1. Auditor: «falsa seguridad» / Tester: «verificable, necesita M5».** Atacan formas distintas. El auditor ataca el
  runbook copiado del README, que codifica sus omisiones (S3: relaciones; S2: ventana vencida antes de la pasada). El tester
  diseña un runbook cuyos pasos vienen de M5. Se adopta la del tester con las dos filas del auditor dentro, y **la tabla es
  la fuente del README, no al revés**. Lo decide la evidencia: el contrafactual del tester muestra que alpha.10 · 2 y 3 solo
  salen rojos «si el paso existe».
- **M2. Analista: 3,0 y «~80 % hecha» / Tester: guardia de mutante por bandera.** El 3,0 es retrospectivo y es correcto:
  los nº 19, 20 y 30 también los dan M1 y M4. El «80 %» es la cifra de **presencia** (27/34 = 79 %). La protección real,
  medida con mutante, es 22/34 (65 %), con 5 presencias decorativas, entre ellas `relations:reconcile --dry-run`, gemela de
  la que escribía. **Sin el mutante, «M2 hecha» es falso.** Gana la medición del tester.
- **M3. Analista: «riesgo medio-alto, solo útil dentro de M8» / Tester: «muy baja, verificable, dio rojas filas reales».**
  Gana lo medido: el prototipo sobre alpha.9 da rojas las dos filas `app` que COGNITIV encontró después. La objeción de
  los ejes (analista y auditor) se incorpora como regla: exit y estado externo son ejes obligatorios y una fuente «hoy» no
  vale.
- **Coste de M1. Analista: 4-8 h y +3-6 s / Tester: infraestructura nueva y 6-10 s por motor, sin `:memory:`.** Las
  sub-mediciones del tester (50-75 ms por pasada, 1,4 s por dirección de paridad) respaldan su cifra de segundos. Uso
  6-10 h [A], porque el hijo por fase con reloj por IPC no existe todavía.
- **Criterio de estable. Coordinador: «M1 + M4 APTA» / Analista: su criterio de cuatro condiciones.** Resuelto en la
  Decisión 4, con una corrección al analista: «M1 verde en 4 modos» no es posible con el diseño medido, porque el hijo no
  abre `:memory:`.

## Afirmaciones descartadas por falta de evidencia (o refutadas)

- **Coordinador:** «los defectos se han mudado a la frontera». Refutado en cuanto a cuándo nacieron: 9 de los 12 de
  COGNITIV son anteriores a alpha.1 [V del analista].
- **Coordinador, P2:** «auditamos cambios, no el sistema». Falso tal como está escrito: 6 defectos viejos cazados fuera del
  diff y 3 banderas inertes AÑADIDAS en un diff que salió APTA.
- **Coordinador:** que M6 cazaría P5. Refutado: los 5 casos medidos están verdes sin el arreglo.
- **Analista:** «M2 ya hecha en ~80 %». Es presencia, no protección (ver conflictos).
- **Analista:** M4 cuesta 3-6 h por pasada [A]. Lo contradice el piloto medido.
- **Analista:** M7 cuesta 6-10 h y puntúa 11,0. La puntuación supone que «caso registrado» protege. **No está demostrado**
  para guardas de seguridad: las tres guardias existentes son estructurales (capacidades, loader, `dashCase`) y ninguna
  prueba que un caso *mate* la guarda. Lo trato como incertidumbre y de ahí sale la condición del piloto. Sí hay un indicio
  medido de que se puede hacer: el tester apagó F-05 por capa (`M6_REVERT_F05=manager|drivers|all`, 7 s por modo).
- **Analista:** los totales S/P tienen sesgo retrospectivo, que él mismo declara. Los uso como orden, no como cifra exacta.
- **Juez (yo):** los defectos evitados de «gemelos» y «rama» son estimación, y van marcados [A].
- **Tester:** arranque del hijo 1-3 s, estimado y no medido.

## Decisión 2 · Integración en el proceso

| Momento | Qué | Quién ejecuta | Artefacto | Regla de parada |
|---|---|---|---|---|
| Panel de diseño (operación larga o guarda transversal) | M5 (estados y peor instancia) | Analista lista, auditor aporta la peor instancia | Tabla de estados en el diseño; cada fila con destino | La tabla se cierra cuando ninguna fila queda sin destino |
| Implementación | Entrada nueva registrada en M7; rama nueva con línea y caso | Implementador | El test M7 falla solo si falta | Automática |
| Cierre de un rojo/naranja | Gemelos; M3 si aplica; casos que el arreglo puso rojos; M8 si es la 3.ª iteración | Implementador; el tester verifica con mutante | 4 líneas fijas en el informe de cierre | La regla de parada vigente. El re-ataque del auditor se limita a gemelos y filas nuevas |
| Antes de publicar (alpha y RC) | M7, mutantes de banderas, job `cutover-runbook` | CI; el coordinador verifica | Checks en verde | Automática: rojo = no se publica |
| Periódica (una por RC y tras cada grave de COGNITIV) | M4 con perspectiva distinta | `auditor-seguridad` | Spec de repro más una fila en `auditorias-sistema.md` | Una rotación con 0 rojos/naranjas nuevos: la siguiente espera a la próxima RC |

Con la RAM justa:
- M7 (< 2 s) y M3 (ms) van en `npm test`.
- Los mutantes de banderas (29 s) y el runbook (6-10 s por motor, más el `:8101`) van en jobs de CI.
- En local, esas dos solo antes de publicar, reiniciando los servicios antes, y nunca en paralelo con agentes que mutan
  código (higiene vigente).

### Texto que se añade a `CLAUDE.md` § «Cómo se decide un cambio» (tras el punto 4)

```markdown
5. **Cierre de un 🔴/🟠: cuatro líneas fijas en el informe.** (a) *Gemelos* (roles↔relaciones, comando↔manager↔función
   exportada, `reconcile`↔`relations:reconcile`, `relay`↔`requeue --apply`): caso o «no aplica porque…». (b) *Tabla de
   verdad* si el arreglo depende de ≥ 2 entradas discretas o de estado externo: dominios declarados, guardia de producto,
   exit y rama como ejes; una fila con fuente «lo que hace hoy» no vale. (c) *Casos existentes que el arreglo puso rojos*,
   justificados. (d) *Linaje*: si es la 3.ª iteración de uno de `.claude/contexto/linajes.md`, no se parchea — propiedad
   universal, punto de paso único y entrada en la guardia de superficie.
6. **Guardia de superficie.** Cada guarda transversal registrada tiene un test que enumera sus entradas por reflexión; una
   entrada sin mutante que la mate, o sin exención firmada por el dueño, es rojo. En banderas, la prueba es el mutante
   inerte (`scripts/check_flag_mutants.mjs`), jamás la presencia.
7. **Toda salida dice qué rama corrió**: línea distinta y exit propio por rama, con caso de letra.
8. **Operaciones largas**: el panel enumera antes/durante/después/abortada/caducada/repetida y la peor instancia de cada
   precio declarado; cada estado acaba en un paso del runbook ejecutable o en un caso.
9. **Antes de publicar**: guardia de superficie, mutantes de banderas y job `cutover-runbook` en verde. **Por RC y tras
   cada grave de COGNITIV**: auditoría de sistema sin diff con perspectiva nueva (`auditorias-sistema.md`), que entrega
   repro. Ninguna APTA es condición suficiente para publicar.
```

### Cambios a `09-METODOLOGIA-DE-DESARROLLO.md`

1. **Cabecera:** mantener «no es teoría», con el dato honesto: 34 graves entre alpha.1 y alpha.10, 12 encontrados por el
   consumidor, 9 de ellos anteriores a alpha.1. La metodología funcionaba donde se ejecutaba.
2. **Principio 3 («Mide contra lo real»):** «real» incluye el **framework anfitrión**: kernel de ace, provider, `boot()`.
   Los nº 8, 19, 20 y 30 vivían ahí (analista §3.3).
3. **Circuito:** añadir la casilla **CIERRE** con las cuatro líneas y la casilla **ANTES DE PUBLICAR** con gates
   automáticos. Añadir fuera del circuito la **auditoría de sistema periódica con rotación**.
4. **Sección nueva «Los círculos son linajes»:** la definición, la regla de tres, la guardia de superficie con cobertura
   por mutante, y por qué «barrer la forma con un grep» no basta: el alcance se decide a mano.
5. **«La composición es el enemigo»:** añadir la asimetría entre gemelos y las salidas que no dicen qué rama corrió.
6. **Regla de parada:** diferir un menor exige medir antes la **peor instancia** de su precio (nº 25 y 27): el impacto
   operativo cuenta, no solo la explotabilidad.
7. **«Señal de convergencia»:** pasa a número. Guardia de superficie sin entradas sin cubrir, y ningún grave nuevo de un
   linaje registrado durante la RC.
8. **«Verifica tú»:** un APTA no es un gate. Hubo 5 de 5 APTA seguidas de un grave.
9. **Adaptación a COGNITIV:**
   - guardia de superficie sobre sus PEP (cada endpoint que decide acceso);
   - runbook ejecutable para sus migraciones de datos;
   - gemelos Python↔Adonis como tabla fija de pares.

## Decisión 3 · Orden de adopción (camino crítico)

| # | Paso | Depende de | Dificultad | Horas |
|---|---|---|---|---|
| 0 | `linajes.md` (6 linajes y propiedad universal) y `auditorias-sistema.md` (rotación 1 = piloto del 09-13). Gemelos y M8 sobre el origen rancio: **ya aplicados** | — | baja | 0,5 |
| 1 | Cerrar alpha.10 con S1/S2/S3/S5-S7 dentro, más la convención de rama aplicada a los comandos restantes | 0 | baja | 2-3 [A] |
| 2 | Mutantes de banderas: 7 banderas sin caso, 5 presencias por reforzar y montaje con 3 drivers | 1 | baja | 2-4 [A] |
| 3 | Piloto M7 sobre F-05 y el origen del reconcile, cobertura por mutante. **Tope 3 h: si no se expresa, se reduce el alcance** | 2 (misma forma de mutante) | media-alta | ≤ 3 |
| 4 | M7 sobre el resto de guardas (freeze, `transaction`, actor, evento, entrada desconocida) | 3 | media | 4-7 [A] |
| 5 | Lista de estados del cutover (M5) más peor instancia, con las filas S2 y S3 del auditor | 1 | baja | 1 |
| 6 | Runbook M1: hijo por fase, reloj por IPC, job `cutover-runbook`, README afirmado | 5 | media-alta | 6-10 [A] |
| 7 | Primera RC, rotación 2 de M4 (perspectiva nueva) y ensayo de COGNITIV sobre el tarball | 4, 6 | — | 1 h de agente por rotación [A] |

M3 no tiene paso propio: rige desde el siguiente cierre, sin coste previo.

Los pasos 3-4 y 5-6 pueden ir en paralelo, pero **en worktrees separados** (regla de agentes no concurrentes). Total hasta la
RC: **~19-29 h**.

## Decisión 4 · Criterio de salida a `2.4.0` estable

**Se rechaza «M1 + M4 APTA» (coordinador):**
- M1 sin M5 da falsa seguridad, medida por el auditor.
- «APTA» es un juicio con historial de 5 de 5 seguidas de un grave.

**Se adopta el del analista, con dos correcciones y una adición.** Todas las condiciones son necesarias:

1. **Runbook M1+M5 en verde** en el job `cutover-runbook`: pg y sqlite-file contra `:8101`; mysql si el job lo admite.
   *Corrección:* no «4 modos», porque el diseño medido no corre en `:memory:`.
2. **M7 en verde:** cero entradas sin un mutante que las mate y exenciones firmadas por el dueño. **Mutantes de banderas:**
   cero supervivientes sin razón escrita.
3. **Linajes quietos:** ningún grave nuevo de un linaje registrado durante la RC. *Adición:* **cualquier grave**, sea de
   linaje o no, reabre la RC (`rc.N+1`).
4. **Rotación de M4 sobre la RC con 0 rojos o naranjas abiertos.** Es necesaria y no suficiente, y no es un APTA: cuenta
   hallazgos con repro. *Corrección al analista:* dejarla fuera sería renunciar al detector interno que más rindió medido.
5. **Ensayo del cutover de COGNITIV sobre el tarball exacto de la RC**, con plazo cerrado y sin graves. Si es condición o
   informativo lo decide el dueño (pregunta 1). Mi recomendación es condición: ningún defecto de las capas
   comando/integración/operación se encontró dentro sin un aviso previo de COGNITIV (analista §1.1).

## Riesgos que quedan aunque se elija lo anterior

- **6 de 34 no los cubre ninguna medida** (nº 3, 4, 6, 22, 27, 29): semántica de infraestructura y decisiones ya
  declaradas. Solo los alcanzan «mide contra lo real» y la peor instancia.
- **Entradas que nadie concibió** (tester): el runbook lo escribe el paquete y puede no reproducir el uso del consumidor.
  Por eso sigue el ensayo de COGNITIV.
- **Las exenciones de M7 pueden acabar siendo un sello**, y M4 puede volverse teatro si la rotación no se respeta.
- **Instrumentación que miente:** el tester se equivocó dos veces (regex de reversión y fuga asíncrona del contador). Todo
  script de mutantes tiene que fallar de forma ruidosa si un parche no aplica o si un mutante no altera nada.
- Mis puntuaciones de «gemelos» y «rama» son estimaciones.
- `latest` (1.1.0) sigue publicando el loader roto y el TypeError de `openfga:provision`.

## Lo que preguntaría al humano antes de implementar

1. **¿El ensayo de COGNITIV sobre el tarball de la RC es condición de la estable o informativo, y con qué plazo?** Si es
   informativo, el criterio 5 desaparece y el runbook (criterio 1) pasa a cargar con la capa operativa sin respaldo externo.
2. **¿Aceptas firmar cada exención de la guardia de superficie?** Si no, la exención degrada a sello y M7 baja en
   «ceremonia». Entonces el criterio 2 tendría que ser «cero exenciones».
3. **¿`npm deprecate` también de `1.1.0` (`latest`), además de las alphas 4-8?** No cambia la metodología, pero sí el riesgo
   residual publicado mientras no hay estable.

---

## Resumen

| Medida | Decisión | Cuándo | Coste | Defectos que habría evitado |
|---|---|---|---|---|
| M7 guardia de superficie (cobertura por mutante) | adoptar | implementación y antes de publicar | 7-10 h y < 2 s | 11,0 (6 S y 10 P); únicos: nº 7, 11-14 |
| M2 mutante por bandera | transformar (dentro de M7) | antes de publicar (CI) | 2-4 h y 29 s | 3,0 retrospectivo; hoy 12 banderas sin protección real |
| M3 tabla de verdad | adoptar (cierres con ≥ 2 entradas o estado externo) | cierre | ~30 min por cierre y ms | 7,0; filas `app`+uuid medidas |
| M1 runbook | transformar (pasos de M5, relaciones, job obligatorio) | antes de publicar (CI) | 6-10 h y 6-10 s por motor | 6,0 solo; con M5, los 4 de alpha.9/10 más S1-S3 |
| M5 estados y peor instancia | adoptar (entrada de M1/M3) | panel de diseño | 20-40 min por panel | 5,5; con peor instancia, nº 25 y 27 |
| M4 auditoría de sistema | transformar (periódica, rotación, repro, no gate) | una por RC y tras cada grave de COGNITIV | ~15-20 min medidos, más verificación | 9,0; piloto: 1 rojo y 2 naranjas publicados desde alpha.1 |
| M6 retirar el arreglo | descartar (se queda una línea de dirección contraria) | cierre | 0 | 0 |
| M8 regla de tres | adoptar | cierre | ~0 | nº 18 y 25 (P); corta los linajes |
| Gemelos | adoptar (ya aplicado) | cierre | minutos | S1 rojo, S3 naranja; nº 5, 8, 10-14 [A] |
| Rama en la salida | adoptar | implementación | 2-3 h de retrofit [A] | S2, S5, S6; nº 31, 33, 34 en parte [A] |
