# Lote alpha.5 · Implementador II — R2b `requeue` + R0 docs/profundidad + garantías no observadas

Prerrequisito: el implementador I terminó R2a (aparcado: 503 no consume intento; tapón por clave para
`attached`/`moved`, `detached` pasa) y R1 (recibo `{ queued }`, `only` con sonda contra la cola entera, `entries`
por entrada), verificado en los 4 modos. Leer `alpha5-informe-I.md` y el diff antes de tocar nada. Decisiones:
`decisiones-dueno-2026-08-28.md` §2026-09-09 (2); veredicto: `panel-relay-juez.md` cuestiones 2, 4, 5 y 6.

## R2b · `authz:scopes:requeue --id` (fácil)
- `outbox.requeue?(ids)` OPCIONAL en el puerto (`sqlScopeOutbox`: `attempts = maxAttempts − 1`, sin migración;
  un id inexistente o no aparcado ⇒ error claro). Sin él, el comando dice 500 `E_AUTHZ_UNSUPPORTED`.
- **Sonda anti-reversión EN EL MANAGER** (`manager.requeueScopeChanges(ids, { force })`, API de PLATAFORMA junto a
  `driver()`, jamás por HTTP): se NIEGA si existe una entrada APLICADA posterior (id mayor) que comparta clave de
  scope con la aparcada (rojo: `relay-auditor-5.ts` — reaplicar un `moved` viejo tras otro `moved` aplicado deja el
  store con el padre viejo y UN solo padre: `assertOneParent` no lo delata). `--force` SOLO en el comando ace: imprime
  el diff (qué entrada aplicada posterior se revertiría) y exige el flag explícito (decisión del dueño).
- Caso: aparcada vuelve a `pending()` y la pasada siguiente la aplica; requeue con aplicada posterior ⇒ se niega y
  nombra la entrada; `--force` ⇒ entra con el diff en la salida; un requeue de una entrada cuyo padre ya no existe
  vuelve a aparcarse (no hay bucle infinito) y NO contamina la clave más de una pasada (auditor 🔴 2 «grifo»).

## R0 · Docs y profundidad (trivial + fácil)
- README: **tabla de límites** («Limits», junto al techo de bytes) con la profundidad 22 (`FACTS_MAX_RESOLVE_DEPTH`),
  atada a la constante con caso de letra; una línea en § «The scope tree» que enlace a la tabla; límite de
  `enumerateRelations` en `openfga` (O(store); no dispararlo desde una petición de tenant; barrido único en 2.5).
- **Gate opt-in por CONFIG** (no `capabilities`: booleana por doctrina): `scopes.maxDepth?: number` — si está, el
  manager rechaza con 422 `E_AUTHZ_SCOPE_TOO_DEEP` en `attached`/`moved` cuando la cadena del PADRE + 1 supera el
  techo (cero I/O: la cadena del padre ya se resuelve), declarado PARCIAL en el README (no ve la altura del subárbol
  movido). `authz:reconcile --to=openfga` avisa de las cadenas > techo en `drift`. Casos: 22 entra, 23 ⇒ 422 antes
  de escribir; sin la opción, nada cambia.

## Garantías no observadas (fácil)
- **Escritor único multiproceso**: `tests/scope_outbox_multiprocess.spec.ts` + `helpers/relay_child.ts` (patrón
  `freeze_multiprocess.spec.ts`; gateado a pg/mysql/sqlite-file): dos PROCESOS relayan la misma cola ⇒ exactamente
  uno aplica, el otro `busy`; mutante «advisory lock → `Set` de proceso» ⇒ rojo (hoy queda verde en los 4 motores).
- **`GET_LOCK` recortado a 64 chars** (`scope_outbox.ts:329`): nombre = hash estable de la tabla; TRANSICIÓN: tomar
  el lock viejo Y el nuevo durante alpha.5 (dos despliegues mezclados no se pisan; +0,56 ms), con caso de 5 líneas
  (dos tablas con los mismos primeros 64 chars NO comparten lease) y nota en CHANGELOG para retirar el viejo en 2.5.
- **`runScopeOutboxContract` en `/testing`** (esqueleto de `relations_contract.ts`, 14–18 casos): los deberes del
  puerto — `enqueue` por la trx del contexto, `pending` ordenado por id y sin lo aparcado, `markApplied` idempotente,
  `markFailed` con y sin `transient`, `dead`, `acquire` exclusivo, `requeue` si existe (par de capacidad). Corre
  contra `sqlScopeOutbox` en los 4 modos y contra los dobles de la suite. `EXPECTED_CASES` como en los otros runners.

## Docs / cierre
CHANGELOG `[Unreleased] — 2.4.0-alpha.5` (continuar la sección del I); `CLAUDE.md` (mapa: `requeue`, `maxDepth`,
contrato outbox, multiproceso); `roadmap-2.0.md`: barrido de `enumerateRelations` ⇒ 2.5, retirar lock viejo ⇒ 2.5.
Base: las cifras del informe I. Informe INCREMENTAL en `alpha5-informe-II.md`. Verificación: las 4 corridas.
