# Fase 3b · Hallazgos del /code-review de fin de fase (rama v2/fase-3b, HEAD 49f3010)

Revisión nivel `high`: 8 ángulos → ~30 candidatos → 26 verificados. Refutados con motivo: colación MySQL `_ci` (el esquema fuerza `utf8mb4_bin`), renew de freeze sin lease y acquire con cliente mixto (inalcanzables), aviso de outbox sin transacción (el docblock dice «si puede»), roles dormidos tras `detached` y borrado de `--store-id` (decisiones documentadas del dueño), `stillGranting` derivable (contrato documentado). Quedan **10 confirmados** (el tope del informe cortó 3 de corrección menos severos + la limpieza D/E/F, que van al final de este lote si da tiempo).

## Orden de arreglo: FAIL-OPEN primero, luego pérdida de datos, luego arranque.

### Grupo A · Fail-open
| # | Fichero:línea | Qué |
|---|---|---|
| A1 | `commands/authz_catalog_sync.ts:37` | No pasa `catalogProjection()`: en `facts` la proyección `role#permits_<P>` no se reescribe por CLI. Un permiso quitado del catálogo SIGUE concediendo; un rol nuevo no concede nada. README:577 dice que este comando «rewrites the derived projection» — el camino de recuperación documentado NO existe. |
| A2 | `src/drivers/openfga_driver.ts:3068` | `enumerateFacts` descarta en silencio los deny del modo `resolver` (relación `denied` sobre `deny_binding:*`): ni migrados ni contados en `skipped`. Migrar desde 2.2 pierde denies explícitos con verificador verde (rompe invariante 2). El CHANGELOG nombra `reconcile` como el sustituto del import sin declarar esta limitación. |
| A3 | `src/drivers/openfga_driver.ts:1647` | El early-return idempotente de `reparent` (arista ya == wanted) se salta `sweepLocalRoleBindings`: un `moved` reintentado cuyo primer intento escribió la arista pero murió antes del barrido no corre nunca el barrido del invariante 18 ⇒ rol de tenant A concede en el subárbol de B. |
| A4 | `src/drivers/openfga_driver.ts:1139` (y `:1187` removeDeny) | `revoke`/`removeDeny` sobre un scope que el árbol ya no conoce caen en la ortografía única del llamante (`canonicalOrSelf`) con `onMissingDeletes: Ignore`. El fan-out `scopeSpellings` del lote 2h vive SOLO en `scopes.detached`: un alias hace el delete un no-op silencioso. Contradice la nota de divergencia «la ESCRITURA sí canoniza en los dos drivers». |
| A5 | `src/drivers/openfga_driver.ts:1562` | El anti-ciclos de `assertEdge` recorre la cadena del CONSUMIDOR (`knownScope`/`chain` vía `resolveChain`), no el árbol del store. Outbox aplicada en desorden (un `moved` aparcado + un move inverso posterior) escribe un ciclo real; `storeChain` en el barrido solo lanza DESPUÉS de escribir la arista y no la deshace. |

### Grupo B · Pérdida de datos / disponibilidad
| # | Fichero:línea | Qué |
|---|---|---|
| B1 | `src/drivers/database_driver.ts:1433` (espejo en `openfga_driver.ts:2491`) | El seguro de borrado masivo mira el conteo CRUDO de hechos de origen (incrementado antes de cada skip, `:1261`), así que un origen cuyos hechos se descartan todos esquiva `MassReconcileRefusedError` y `--prune` vacía el destino. Es el primo del 🔴 del lote 5, un escalón abajo. No hay segundo seguro (ratio de skip, umbral de borrado). |
| B2 | `commands/authz_reconcile.ts:144` | `clean` exige `report.skipped` completamente vacío, y las dos direcciones cuentan las asignaciones ya caducadas en `skipped['expired']` mientras nada borra las filas caducadas. Una vez que algo caduca, `reconcile` (dry-run incluido) sale 1 para siempre. El verificador de CI que el CHANGELOG promete verde es inalcanzable con datos reales. |
| B3 | `src/manager.ts:892` (patrón en `pruneOrphanRoles:2242`) | `relayScopeChanges` mira el freeze durable una vez al entrar y luego aplica hasta `DEFAULT_RELAY_LIMIT`=10.000 escrituras de árbol sin re-mirar. Un freeze adquirido a mitad de drenaje no para el resto de la pasada — escrituras que no aparecen en ningún contador y pueden invalidar el resultado certificado. El trade-off documentado (freeze.ts:84-87) cubre «una escritura que ya pasó su barrera», no una pasada de 10.000. Fix: re-afirmar la barrera por lote dentro del bucle (0,14 ms/escritura, ya medido). |

### Grupo C · Arranque / operabilidad
| # | Fichero:línea | Qué |
|---|---|---|
| C1 | `stubs/config/authorization.stub:128` | El template firma `acceptScopeDriftRisk` solo dentro de la factory del driver `openfga`, pero el gate del manager `#assertScopeDriftGuarded` lee `config.scopes.outbox`/`config.scopes.acceptScopeDriftRisk`. Una app recién scaffoldeada en modo `openfga` da 500 (`ScopeDriftUnguardedError`) en cada request hasta editar a mano config que los comentarios del stub no mencionan. |
| C2 | `src/drivers/openfga_driver.ts:1966` | `purgeScope` cuenta como residuo las aristas `scope#binding` de roles fuera de `authz_roles WHERE scope_type = scope.type` pero NO tiene camino que las borre (paso 1 borra solo los del `scope.type`; el predicado de residuo excluye solo `parent`). Un rol cuya fila se borró/cambió de `scope_type` entre el commit y el barrido no atómico deja un huérfano ⇒ `PurgeIncompleteError` para siempre ⇒ `detached` bloqueado, solo `reconcile` lo desatasca. |

## Además, no del review: el intermitente E5
El caso de profundidad 22 (500 resoluciones) falla esporádicamente bajo contención del `:8101`. Tiene nombre por fin. Aislar el caso de la contención, o ajustar lo que afirma a lo que se puede prometer en un servidor compartido. **Antes de publicar.**
