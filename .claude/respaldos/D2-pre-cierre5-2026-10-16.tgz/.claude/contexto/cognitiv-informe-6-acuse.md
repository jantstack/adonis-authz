# Sexto informe al paquete — acuse de `2.4.0-alpha.9` y lo que salió al cerrar (13-09-2026)

Asunto: alpha.9 instalada y ensayada en COGNITIV — gracias; cuatro detalles nuevos, uno medido

**Instalada y cerrada.** COGNITIV corre `2.4.0-alpha.9` (pin exacto). Con vuestra versión y sin tocar
nada nuestro: `database` idéntico a alpha.8; `openfga` solo cayeron nuestras dos alarmas puestas para el día
del arreglo. Hemos retirado nuestro reparto de familias y nos apoyamos en `report.foreign`. Reensayo de
cutover ida y vuelta contra alpha.9 en desarrollo: `--dry-run` con 0 escrituras, `--prune` respetando las
60 ajenas, media pareja de `--partition-*` rechazada. Revisamos vuestros dos avisos: no nos alcanzan (esos
comandos solo corrieron en stores de ensayo ya borrados).

Y vuestra lección nos sirvió: con vuestro arreglo retirado a mano, **nuestros dos casos viejos seguían
verdes** mientras un `--prune` real vaciaba las relaciones. Eran alarmas del defecto, no guardianes del
comportamiento. Los hemos sustituido.

## 1 · `authz:reconcile` dice «no escribe ni borra un solo hecho» y los borra (medido)

Autocomprobación del driver activo (`--to=openfga`, sin `--from`) con `--prune`, sobre un store con un
binding de un scope que ya no existe (3 tuplas sobre una organización inexistente):

```
hechos: los del propio 'openfga' — es el driver ACTIVO … no escribe ni borra un solo hecho …
hechos: escritas 0, actualizadas 0, iguales 78, sobran 3, borradas 3
```

El comportamiento es el que queremos (barre el `unknown-scope` y respeta las 60 relaciones); la frase es
falsa en ese caso. Probablemente sea el mismo matiz del README (`:1033`). Sugerencia: «no escribe hechos;
con `--prune` borra los de scopes que ya no resuelven».

## 2 · `authz:unfreeze` responde éxito con la ventana ya caducada

`unfreezePlan(null, …)` ⇒ `noop` ⇒ `success` (`commands/authz_unfreeze.ts:24-26, 75-77`). Con `--lease-ms`
ya funcional, el último paso de un cutover no delata que la ventana venció a mitad — y en un cutover eso
significa escrituras que el motor nuevo no vio. Nosotros prohibimos `--lease-ms` en el runbook y nuestro
verificador rechaza una ventana con caducidad, pero el aviso natural es vuestro: «no había ventana que
cerrar: ¿caducó?».

## 3 · Una ventana de operador adoptada se reporta con `leaseMs: null` aunque tenga `untilMs`

`src/manager.ts:767`. Quien adopta la ventana (`operatorAsContext`) no ve que caduca. Menor, pero es la
misma familia del punto 2.

## 4 · La dirección equivocada con `openfga` activo no se rechaza en código

Con `openfga` sirviendo, `authz:reconcile --to=openfga --from=database` lee `authz_*` sin objeción
(`manager.ts:2079-2097`) y **reescribe en el store vivo los roles revocados desde el cutover** — siguen
vivos en `authz_assignments` porque esa tabla dejó de escribirse —, con o sin `--prune`; y el seguro de
borrado masivo no salta porque el origen no está vacío. Nosotros lo tenemos como regla escrita del runbook.
Sugerencia: que el manager lo rechace cuando `to` es el driver por defecto y `from` no lo es, salvo bandera
explícita.

## 5 · Una trampa que queda en el comando de relaciones

`--partition-type=app --partition-uuid=<org>` es pareja completa y cae en la raíz en silencio
(`commands/authz_relations_reconcile.ts:278-294`). La media pareja ya la cazáis; esta variante, no.

**Lo que nos queda pendiente de vuestro lado, sin prisa:** `--prune-undeclared` (2.5), y `2.4.0` estable,
que es una de las dos condiciones que hemos puesto para fijar fecha de un cutover real en producción.
