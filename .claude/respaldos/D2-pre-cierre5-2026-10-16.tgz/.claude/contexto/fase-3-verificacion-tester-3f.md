# Fase 3 · Lote 3F — verificación del tester (ronda final)

> Worktree aislado en `ae3a7a8` (Lote 3F). Node 22.23.2, `npm ci` limpio.
> Motores: SQLite (memoria y fichero), PostgreSQL 18 (`postgres18`), MySQL 8.4 (`mysql84`),
> OpenFGA `:8101` y tope 3 efímero (`openfga-tiny-tester3f`, `:8133`, **creado y borrado**).
> Alcance: SOLO el delta `git diff 5b4f3c2..ae3a7a8` (S1–S4, T1–T5, U1–U5). No se repite el 3E.
> Parche: `.claude/contexto/tests-tester-fase-3f.patch`.

## Veredicto: **APTA CON CORRECCIONES**

Lo que el 3F declara arreglado **tiene juez**: los 16 mutantes que apuntan a cada pieza nueva
mueren, y el único que sobrevive (R7) es el que el propio informe declara equivalente — lo he
medido y es cierto. Pero **sí hay una promesa nueva sin juez y una aserción que el código ya no
sostiene**, y no es un hueco de cobertura: es un caso del **juez publicado** que pasa por suerte
del planificador y que se rompe con **2 ms** de jitter, en PostgreSQL *y* en MySQL.

Va con parche verificado que lo cierra sin relajar nada (mata los mismos mutantes que antes y dos
más). Todo lo demás que encontré son 🟡/⚪ y va **a la Fase 3b**.

---

## 1 · Suites (sin parche, tal como llega `ae3a7a8`)

| Comando | Esperado (informe 3F) | Medido | |
|---|---|---|---|
| `OPENFGA_TEST_URL=:8101 npm test` | 514 | **514 passed** | ✅ |
| `OPENFGA_TEST_URL=:8101 npm run test:sqlite-file` | 516 | **516 passed** | ✅ |
| `TEST_PG_URL=… OPENFGA_TEST_URL=:8101 npm run test:pg` | 681 | **681 passed** | ✅ |
| `TEST_MYSQL_URL=… OPENFGA_TEST_URL=:8101 npm run test:mysql` | 681 | **681 passed** | ✅ |
| `OPENFGA_TEST_URL=:8133 npm test` (tope 3) | 514 | **514 passed** | ✅ |
| `npm run typecheck` | — | ✅ | |

Sin `.only`, sin `.skip`, sin `test.failing`. Residuos al terminar: **0** bases `authz_test_*` en
PostgreSQL y MySQL (borré una, `authz_test_6aafeade`, que dejó *mi* propia batería de mutantes al
abortar; no había ninguna al empezar), **0** stores nuevos en OpenFGA `:8101` (el más reciente es
`steal-…` de las 02:22 UTC, de otro agente), contenedor tope 3 eliminado. Los conteos del juez del
3F son **exactos**.

> Nota de higiene (⚪, no del 3F): una corrida de `test:pg` que **falla** puede dejar su base
> `authz_test_*` sin destruir — las cinco que limpié al final salieron de mis propias baterías de
> mutantes, no de la suite verde, que sí imprime `[suite] base destruida` siempre. Merece mirarse
> si el CI llega a correr en rojo a menudo.

---

## 2 · Un mutante por pieza nueva

21 mutantes aplicados sobre `src/`, suite completa por mutante, árbol restaurado entre cada uno.

| # | Mutante (lo que revierte) | Fichero | Resultado | Quién lo mata |
|---|---|---|---|---|
| **S1a** | `#assertAboveOwnedRoles` vuelve a lanzar `UnknownScopeError` sin cadena | `manager.ts` | ☠️ **muere** | `3F · S1` |
| **S1b** | el rango **no** se exige aunque el scope SÍ resuelva (`!chain \|\| true`) | `manager.ts` | ☠️ muere (3 casos) | `3F · S1`, `3E · P2/P3`, stubs |
| **S1parcial** | con `reason`, purga solo el **primer** rol (purga a medias) | `manager.ts` | ⚠️ **SOBREVIVÍA** → ☠️ con el parche | (hueco H1, ver §5) |
| **S2a** | la **purga** vuelve a propagar en vez de degradar | `manager.ts` | ☠️ muere | `3F · S2` |
| **S2b** | la **regla de nivel** vuelve a propagar en vez de degradar | `manager.ts` | ☠️ muere | `3F · S2` |
| **S2c** | `truncated` deja de calcularse (`= false`) | `manager.ts` | ☠️ muere | `3F · S2` |
| **S3a** | la colisión por autoridad **vuelve a lanzar** (`un descendiente (…)`) | `manager.ts` | ☠️ muere (2 casos) | juez `serializedCatalogWrites` + `colisiones` |
| **S3b** | `shadowedByAncestor` **no se reporta** en `role_defined` | `manager.ts` | ☠️ muere | `colisiones` |
| **S3c** | `catalogInSync` vuelve a contar `shadowedByGlobal` | `catalog.ts` | ☠️ muere | `3D · M2 d + 3F · S3` |
| **S3d** | `catalogInSync` vuelve a contar `shadowedByAncestor` | `catalog.ts` | ☠️ muere | idem |
| **S3e** | el diff clasifica el par ancestro/descendiente como `ambiguousRoles` | `catalog.ts` | ☠️ muere | idem |
| **S4** | la ambigüedad deja de ser fail-closed (elige el primero visible) | `catalog_cache.ts` | ☠️ muere (6 casos) | `3F · S4` + juez + memo |
| **U3** | la rama «no juzgable» deja de rechazar (sin el 422 genérico) | `manager.ts` | ☠️ **muere en SQLite** | juez `serializedCatalogWrites` |
| **U4a** | `revoke` por slug notifica **uno** (`[visible[0]]`) | `manager.ts` | ☠️ muere | `3F · U4` |
| **U4b** | la rama `{ uuid }` no comprueba el owner en el evento | `manager.ts` | ☠️ muere | `3F · U4` |
| **U5** | orden de `readRolesOwnedBy` invertido | `catalog_cache.ts` | ☠️ muere | `3E · P2/P3` |
| **U5débil** | *solo* se quita `orderBy('uuid')` + el `sort` final (sin invertir) | `catalog_cache.ts` | ☠️ **muere ya en SQLite** | `3E · P2/P3` |
| **U1·Q1** | el mensaje de `AMBIGUOUS_ROLE` vuelve a «renombra uno de ellos» | `catalog_cache.ts` | ☠️ muere | `colisiones` |
| **U1·Q2a** | el 422 `ROLE_NOT_VISIBLE` por slug vuelve a nombrar owners/uuids | `database_driver.ts` | ☠️ muere | `defineScopedRole escribe…` |
| **U1·Q2b** | el 422 `AMBIGUOUS_ROLE` enumera **todos** los homónimos, no los visibles | `catalog_cache.ts` | ☠️ muere | `colisiones` |
| **U1·Q2c** | la ruta `{ uuid }` vuelve a revelar slug/owner de un rol ajeno | `database_driver.ts` | ☠️ muere | `colisiones` |
| **U1·P3** | la policy de rango se comprueba **rol a rol** en vez de sobre todos | `manager.ts` | ☠️ muere | `3E · P2/P3` |
| **R7** | `purgeRole` **olvida borrar los vínculos** | `database_driver.ts` | 🟢 **sobrevive** (412/412) | — *equivalente, declarado* |

Notas de valor:

- **U3 muere ya en SQLite**, donde `serializedCatalogWrites` es `false` y la carrera de arriba ni
  siquiera se juzga. Es la prueba de que la rama «no juzgable» del re-chequeo transaccional pasó de
  depender de una carrera a ser determinista: **muere sin la carrera**. ✅
- **U5débil muere en SQLite** (no hacía falta PG/MySQL): sin `ORDER BY` el conjunto sale por lotes
  de `owner_scope_key`, y el nieto se cuela fuera de orden. El caso es genuinamente sensible al
  orden, no un `sort()` que se afirma a sí mismo. ✅
- **R7**: confirmo con dato propio lo que el 3F declara. Borrada la sentencia
  `purgeRole.links`, la suite entera pasa **412/412**: el `ON DELETE CASCADE` del esquema borra los
  vínculos por el driver. La corrección de U2 (mover la afirmación del código al esquema en
  `README`, `contract.ts` y `CHANGELOG`) es **honesta y correcta**. Sigue sin oráculo, y eso está
  dicho donde toca.

---

## 3 · El hallazgo del implementador (`serializedCatalogWrites`): **medio arreglado**

El 3F reporta que la parte en SERIE de ese caso dependía de quién ganase la carrera, y que ahora
lee el owner del ganador. **Eso es correcto y lo confirmo.** Pero la parte que sigue dependiendo del
ganador es **la carrera misma**, y ahí la aserción es de las que fallan.

### 3.1 · Tres corridas por motor, sin tocar nada

| | PG #1 | PG #2 | PG #3 | MySQL #1 | MySQL #2 | MySQL #3 |
|---|---|---|---|---|---|---|
| `--files=contract.spec.ts` | ✅ 247 | ✅ 247 | ✅ 247 | ✅ 247 | ✅ 247 | ✅ 247 |

6/6 verdes. Pero eso no es determinismo: es que **el primero del array suele ganar**.

### 3.2 · Forzando cada ganador (lo que responde la pregunta de verdad)

| Escenario | PG | MySQL |
|---|---|---|
| **A** — 500 ms de retraso en el define del **ancestro** (gana el descendiente) | ❌ **FALLA** | ❌ **FALLA** |
| **B** — 500 ms de retraso en el define del **descendiente** (gana el ancestro) | ✅ | ✅ |
| **C** — solo se invierte el orden de lanzamiento, sin retrasos | ✅ | ✅ |
| **D** — **2 ms** de retraso en el define del ancestro | ❌ **FALLA** | ❌ **FALLA** |

```
AssertionError: exactamente un ganador (["ok","ok"]):
  expected [ { status: 'fulfilled', …(1) }, …(1) ] to have a length of 1 but got 2
  at src/testing/contract.ts:3238
```

En **D** falló solo uno de los dos harness dentro de la misma corrida (`database` en MySQL,
`database (árbol SQL)` en PG) y el otro pasó: está exactamente en el filo.

### 3.3 · Por qué falla, y por qué importa

**La regla de autoridad de S3 no es conmutativa.** Con dos `defineScopedRole` del mismo
`(slug, nivel)` cuyos owners están en relación **ancestro→descendiente**, el estado final depende
del ORDEN en que confirmen:

- confirma primero el del **ancestro** ⇒ el del descendiente choca, 422, **queda 1 rol**;
- confirma primero el del **descendiente** ⇒ el del ancestro **ya no choca**: entra y lo
  **ensombrece**, **quedan 2 roles** y el slug es ambiguo dentro del subárbol.

Los dos finales son legales bajo S3. Lo que **no** es legal es lo que afirma el juez
(`assert.lengthOf(ok, 1, 'exactamente un ganador')`) ni lo que promete el README:

> `README.md:249` — *"Two concurrent `defineScopedRole` end with exactly one role and a 422
> `E_AUTHZ_CATALOG_CONFLICT` for the loser"*

y `CLAUDE.md` («la unicidad `(slug, nivel)` por cadena se DEFIENDE»). Ese texto **no se actualizó**
en 3F, y el caso que lo juzga es hoy **flaky** en el artefacto que se publica para que terceros
certifiquen sus drivers: un CI cargado lo pone en rojo sin que nadie haya roto nada.

Es el patrón exacto que el coordinador pedía vigilar: *el informe afirma más de lo que la suite
demuestra*. El 3F vio la mitad del problema (§S3, «Efecto colateral obligado») y concluyó «es más
fuerte, no más laxo». Cierto para el bloque en serie; **falso para la carrera**.

### 3.4 · Lo que hace el parche

En `src/testing/contract.ts`, dentro del mismo caso:

1. La carrera con owners **ancestro/descendiente** acepta los **dos finales legales** —y los afirma
   fuerte: en la base está *exactamente* lo confirmado (uuid a uuid), **nunca dos roles con el mismo
   owner**, y si son dos, el que convive es el **del ancestro** y el slug es 422 `AMBIGUOUS_ROLE`
   dentro del subárbol del descendiente. Después purga el ensombrecido para que el resto del caso
   parta de un estado conocido venga de donde venga.
2. Se añade la **promesa fuerte donde sí es verdad**: dos `defineScopedRole` del **MISMO owner**, en
   paralelo y con memos distintos — ahí la autoridad es la misma y el segundo choca gane quien gane:
   `assert.lengthOf(ganan, 1)` + 422 `E_AUTHZ_CATALOG_CONFLICT` para el perdedor. Eso es lo que la
   capacidad `serializedCatalogWrites` dice, y ahora hay un caso que lo sostiene siempre.
3. `README.md:249`: la frase se acota al mismo owner y se dice qué pasa con ancestro→descendiente.

**Verificación del parche** (no relaja: mata lo mismo y más):

| | PG | MySQL |
|---|---|---|
| escenario **A** (gana el descendiente) | ✅ ahora pasa | ✅ |
| escenario **D** (2 ms) | ✅ ahora pasa | ✅ |
| mutante «**sin re-chequeo transaccional**» (`if (false && fresh.length)`) | ☠️ sigue muriendo | ☠️ |
| mutante **S3a** (la colisión por autoridad vuelve a lanzar) | ☠️ sigue muriendo | ☠️ |

---

## 4 · Verificabilidad por backend

| Pieza | SQLite mem | SQLite fichero | PostgreSQL | MySQL | OpenFGA | Nota |
|---|---|---|---|---|---|---|
| S1 (`detached` de scope desconocido) | ✅ mismo caso | ✅ | ✅ | ✅ | n/a | el catálogo es SQL en los dos drivers |
| S2 (degradación + `truncated`) | ✅ | ✅ | ✅ | ✅ | n/a | el desbordamiento lo simula el árbol del harness, no el motor |
| S3 (autoridad + diff) | ✅ | ✅ | ✅ | ✅ | ✅ (juez) | el juez lo comprueba en **los dos drivers** |
| S4 (ensombrecimiento) | ✅ | ✅ | ✅ | ✅ | — | manager, no driver |
| U3 (rama no juzgable) | ✅ **muere aquí** | ✅ | ✅ | ✅ | — | independiente de `serializedCatalogWrites` |
| U5 (orden estable) | ✅ **muere aquí** | ✅ | ✅ | ✅ | — | |
| Carrera `serializedCatalogWrites` | par `false` | par `false` | par `true` | par `true` | — | **era flaky en PG/MySQL** (§3) |
| R7 (todo o nada de los vínculos) | ❌ | ❌ | ❌ | ❌ | ❌ | mutante **equivalente** por el `CASCADE`; declarado |

---

## 5 · Huecos que el parche cierra

### H1 · `owner-detached-unknown`: la purga completa no tenía juez, y la puerta que abre no estaba dicha

El mutante **S1parcial** —cuando la policy de rango no se pudo medir, purgar **solo el primer rol**
y seguir reportando `purgedRoles: N`— **pasa la suite entera del 3F** (412/412). El caso `3F · S1`
solo tiene **un** rol local en el scope desconocido, así que «purga completa» no es observable ahí.

Y falta lo que de verdad cambia S1 respecto a 3E · P3: **un actor de rango insuficiente**. Hoy el
caso usa `admin` (rango de sobra), así que la aserción «se salta la comprobación» no se distingue de
«la comprobación pasa». Que un actor de rank 5 pueda purgar por esta vía el rol de rank 40 que
`deleteScopedRole` le niega es una decisión tomada y defendida por el auditor — pero es una decisión
que **debe fallar si alguien la revierte a medias, en un sentido o en el otro**, y hoy no lo hace.

El parche añade al caso `3F · S1`: `deleteScopedRole` del rol de rank 40 por el actor de rank 5
sigue siendo 422 `RANK_EXCEEDED`; con la fila del scope ya borrada, el mismo actor obtiene
`reason: 'owner-detached-unknown'`, `purgedRoles: 2` y **los dos roles** (rank 40 y rank 5) fuera.
Con esto, **S1parcial muere**.

### H2 · El 422 de ambigüedad sigue mandando al operador a un exit ≠ 0 que ya no existe

`src/catalog_cache.ts` — el mensaje de `AmbiguousRoleError` termina en:

```
authz:catalog:diff los lista como deriva.
```

Desde S3(b) eso es **falso**: los ensombrecidos por autoridad se listan y `authz:catalog:diff` sale
**0**. Un operador que reciba ese 422 y vaya a mirar el gate de CI no encontrará nada. El parche
corrige la frase y la fija con una aserción (`assert.notInclude(ambiguo.message, 'como deriva')`)
junto a las de Q1.

---

## 6 · Huecos sin comportamiento incorrecto → **a la Fase 3b**

Ninguno de estos reabre la fase.

1. 🟡 **`runCatalogDiff` solo imprime las sombras del catálogo #1** (`if (index === 0) shadowed = …`,
   `catalog.ts:937`). `diff.shadowedByGlobal` tiene una fuente **dependiente del spec**
   (`catalog.ts:620`: un rol del spec que ensombrece a un local), así que con varios catálogos una
   sombra causada por un rol del catálogo #2 **ya no se imprime en ningún sitio** — antes salía como
   línea de diferencias de ese catálogo *y* ponía `inSync: false`. Es pérdida de observabilidad, no
   de decisión. Arreglo: acumular sobre todos los `index` con deduplicación.
2. 🟡 **`classifyHomonyms` hace `continue` cuando hay un global** (`catalog.ts:785`): si en el mismo
   `(slug, nivel)` hay además dos locales anidados, `shadowedByAncestor` no se calcula para ellos.
   Informativo.
3. 🟡 **`shadowedByAncestor` se repite** con owners anidados a>b>c (3 líneas para 3 roles). Ruido.
4. 🟡 **Aserción perdida en el caso del diff**: `subárboles disjuntos: legal` cambió de comprobar
   `ambiguousRoles` a comprobar `shadowedByAncestor` — ahora nadie mira que un árbol disjunto no
   genere deriva. Una línea.
5. 🟡 **No hay caso de `truncated: true` con 0 roles purgados** (el retorno lo lleva; nadie lo mira).
6. ⚪ **T2** (503 `E_AUTHZ_BACKEND_TIMEOUT` para quien *espera* en el cerrojo) y **T4** (coste de
   `onWrite`): documentación sin oráculo. El primero es observable con un pool de 1 y un deadline
   corto; el segundo con `tests/helpers/spies.ts` (contar `resolveChain` por escritura).
7. ⚪ **La consulta en lote de `sync.role.locals`** (T2) no tiene contador: si mañana vuelve a ser
   una por rol, ningún caso lo nota. `spies.ts` ya cuenta operaciones SQL por nombre; sería un
   `assert.equal(spy.count('sync.role.locals'), 1)` con un spec de varios roles homónimos.
8. ⚪ **R7 sin oráculo** — confirmado, declarado y correctamente documentado. Cerrarlo pide
   infraestructura nueva (FK desactivadas, o espiar el SQL): decisión de diseño de la suite.
9. ⚪ **La degradación de S2 es silenciosa** para quien ignore el retorno (lo dice el propio informe).

---

## 7 · Aserciones relajadas respecto a `5b4f3c2`

Repasadas **todas** las líneas `-` de `tests/` y `src/testing/`. Trece aserciones eliminadas; **doce
son consecuencia directa y correcta del cambio de comportamiento decidido en S3** (`catalogInSync`
pasa de `false` a `true`, `ambiguousRoles` pasa a `shadowedBy*`, `rolesNamed('scribe')` pasa de 1 a
2), y todas están sustituidas por una aserción del comportamiento nuevo, más específica que la que
sustituyen. La única relajación neta es la **#4 de §6** (una línea, informativa).

En `src/testing/contract.ts`, `rejectsWith` pasó de `Promise<void>` a `Promise<any>` para poder
inspeccionar el error: no relaja, habilita (Q1/Q2).

---

## 8 · Parche

`.claude/contexto/tests-tester-fase-3f.patch` — `git apply` limpio sobre `ae3a7a8`.

```
 README.md               |  2 +-      (la unicidad tras la carrera se acota al MISMO owner)
 src/catalog_cache.ts    |  2 +-      (H2: el 422 ya no manda a un exit ≠ 0 inexistente)
 src/testing/contract.ts | 63 ++++--  (§3.4: la carrera deja de ser flaky + la promesa fuerte con el mismo owner)
 tests/manager.spec.ts   | 19 ++++    (H1 + la aserción de H2)
```

**Sin casos nuevos: los conteos no se mueven.** Suites con el parche aplicado:

| Comando | Sin parche | Con parche |
|---|---|---|
| `npm test` (+`:8101`) | 514 | ✅ **514** |
| `test:sqlite-file` (+`:8101`) | 516 | ✅ **516** |
| `test:pg` (+`:8101`) | 681 | ✅ **681** |
| `test:mysql` (+`:8101`) | 681 | ✅ **681** |
| tope 3 (`:8133`) | 514 | ✅ **514** |
| `npm run typecheck` | ✅ | ✅ |

Y no pierde fuerza: con el parche siguen muriendo **S3a** y el mutante «sin re-chequeo
transaccional» en PG y MySQL, y además muere **S1parcial** (que antes sobrevivía) y los escenarios
**A** y **D** de la carrera dejan de romper el juez.

---

## 9 · Resumen

| | |
|---|---|
| Piezas nuevas con juez | **S1, S2, S3, S4, U1, U3, U4, U5 — todas** (20/21 mutantes muertos) |
| Mutante superviviente | **R7**, equivalente bajo el esquema — declarado por el 3F y **confirmado por mí** |
| Comportamiento incorrecto | ninguno en `src/` de producción |
| **Aserción que el código no sostiene** | **sí**: `serializedCatalogWrites` (§3) — flaky con 2 ms, y el README lo promete mal |
| Promesa nueva sin juez | `owner-detached-unknown` no exigía purga **completa** ni actor de rango insuficiente (H1) |
| Aserciones relajadas | 1 línea informativa (§7 #4) |
| Huecos 🟡/⚪ | 9, ninguno bloqueante → **Fase 3b** |
| Residuos | 0 bases, 0 stores nuevos, 0 contenedores |

**APTA CON CORRECCIONES**: aplicar `tests-tester-fase-3f.patch`. Con él aplicado, la Fase 3 cierra.
