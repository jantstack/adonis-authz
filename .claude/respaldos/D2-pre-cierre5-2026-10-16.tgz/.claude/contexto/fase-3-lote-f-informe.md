# Fase 3 · Lote 3F — informe (cierre del cierre)

> Rama `v2/fase-0`, sobre `5b4f3c2` (árbol limpio al empezar). **Sin commits.**
> Spec: `.claude/contexto/fase-3-correcciones-3f.md` (S1–S4, T1–T5) + piezas del tester del 3E
> reenviadas por el coordinador (U1–U5, informe `fase-3-verificacion-tester-3e.md`).
> Método: rojo→verde por pieza, ejecutando primero el script del auditor que corresponde
> (`…/scratchpad/v8/`) y pegando su salida literal antes y después; typecheck + `npm test` +
> `OPENFGA_TEST_URL=:8101 npm test` tras cada pieza.

## Resumen

| # | Qué | Estado |
|---|---|---|
| **S1** | `scopes.detached` de un scope que el árbol ya no conoce purga igual (rol, asignaciones y denies), saltándose la policy de rango y diciéndolo | ✅ |
| **S2** | El subárbol que no se puede enumerar DEGRADA (`truncated`, regla de nivel mínima) en vez de tumbar la operación | ✅ |
| **S3** | Colisión por AUTORIDAD (global > local de un ancestro > local de un descendiente) + el diff deja de contar como deriva lo ensombrecido | ✅ |
| **S4** | La frase del ensombrecimiento, corregida y fijada con un caso | ✅ |
| **T1–T5** | `listRoles` no desambigua · el 503 del cerrojo · cambio de driver sin `purgeRole` · coste de `onWrite` · CHANGELOG/CLAUDE.md | ✅ |
| **U1** | Parche del tester (`tests-tester-fase-3e.patch`): Q1, Q2 ×2 y las dos de P3 «nada a medias» | ✅ |
| **U2** | R7: corregida la afirmación (el garante es el `CASCADE` del ESQUEMA, no el puerto) | ✅ |
| **U3** | La rama «no juzgable» del re-chequeo transaccional, determinista y en serie | ✅ |
| **U4** | Las dos mitades de Q7 (`AuthzWriteEvent.roles`): pluralidad del `revoke` por slug y owner en la ruta `{ uuid }` | ✅ |
| **U5** | `readRolesOwnedBy` con orden estable (uuid) + nota | ✅ |

Desviaciones: ninguna sobre lo pedido. Un efecto colateral obligado de S3 se documenta en §S3.

---

## S1 · `scopes.detached` sobre un scope ya borrado (auditor N2 · regresión de 3E)

**Decisión aplicada** (respuesta 1 de la spec): si `resolveChain(scope) === null`, el `detached`
procede —purga hechos y roles de ese owner— y **se salta** la comprobación de rango; el evento y el
valor de retorno lo dicen (`reason: 'owner-detached-unknown'`). Con el scope todavía en el árbol el
rango se exige como hasta ahora.

**Rojo de partida** (`v8/n6_actor_sin_within.ts`, PG):

```
=== requireActor: true, SIN within · scope ya borrado del árbol ===
    scopes.detached(U1, { actor }) -> 422 E_AUTHZ_UNKNOWN_SCOPE: scopes.detached: unit:01a04e88-… tiene 1 rol(es) LOCAL(es) que purgar y el árbol ya no lo conoce, así que no se puede medir el rango del actor ahí. Notifica el detached ANTES de borrar la fila del scope, o hazlo sin actor (operación d
  filas de v5: 1 · asignaciones: 1
  denies vivos: 1

=== el mismo caso SIN roles locales en el scope ===
    scopes.detached(U2, { actor }) = undefined

=== salida: otro manager (sin requireActor) ===
    laxo.scopes.detached(U1) sin actor = undefined
  filas de v5: 0 · asignaciones: 0 · denies: 0
```

**Verde** (mismo script, sin tocarlo):

```
=== requireActor: true, SIN within · scope ya borrado del árbol ===
    scopes.detached(U1, { actor }) = {"purgedRoles":1,"truncated":false,"reason":"owner-detached-unknown"}
  filas de v5: 0 · asignaciones: 0
  denies vivos: 0

=== el mismo caso SIN roles locales en el scope ===
    scopes.detached(U2, { actor }) = {"purgedRoles":0,"truncated":false}

=== salida: otro manager (sin requireActor) ===
    laxo.scopes.detached(U1) sin actor = {"purgedRoles":0,"truncated":false}
  filas de v5: 0 · asignaciones: 0 · denies: 0
```

**Código**: `src/manager.ts` — `#assertAboveOwnedRoles` devuelve el motivo en vez de lanzar
`UnknownScopeError`; `#purgeRolesOwnedBy` lo propaga; `scopes.detached` devuelve
`ScopeDetachOutcome` (**breaking**: era `Promise<void>`) y añade `reason` al evento `scope_purged`.
`src/types.ts`: `ScopeDetachOutcome` + `AuthzWriteEvent.reason`. Exportado en `index.ts`.

**Caso**: `tests/manager.spec.ts` → `3F · S1 (auditor N2)`. Fija los tres finales de la spec:
scope desconocido + `requireActor: true` ⇒ purga completa (rol, asignación **y denies**), retorno y
evento con `reason`, `role_purged` notificado; scope **conocido** + actor de rango insuficiente ⇒
sigue 422 `E_AUTHZ_RANK_EXCEEDED` sin purgar nada; el caso sin actor ya lo cubría el grupo.

## S2 · `descendantsOf` degrada, no tumba (auditor N3 · regresión de 3E)

**Decisión aplicada** (respuesta 2): *declarar `descendantsOf` nunca puede dejarte peor que no
declararlo*. En `detached`, purgar el scope exacto y marcar el resultado como parcial
(`truncated: true` en el evento y en el retorno); en la comprobación de nivel, caer a la **regla
mínima** (rechazar solo tipos de ancestros).

**Rojo de partida** (`v8/n7_cotas.ts`, PG):

```
org con 6 units · maxDescendants: 3 · descendantsOf declarado
    defineScopedRole(orgA, lead@unit) [nivel de un descendiente] -> 503 E_AUTHZ_RESOLVER_FAILED: El resolutor de ancestros de scopes falló (descendantsOf)
    defineScopedRole(orgA, jefe@organization) [nivel del propio owner] = {"uuid":"…","slug":"jefe",…}
    scopes.detached(orgA) con 6 descendientes y la cota en 3 -> 503 E_AUTHZ_RESOLVER_FAILED: El resolutor de ancestros de scopes falló (descendantsOf)
  filas de purga: 1
  asignaciones vivas: 2
    scopes.detached(orgA) con el manager SIN descendantsOf = undefined
  filas de purga: 0
```

**Verde**:

```
org con 6 units · maxDescendants: 3 · descendantsOf declarado
    defineScopedRole(orgA, lead@unit) [nivel de un descendiente] = {"uuid":"…","slug":"lead","scopeType":"unit",…}
    defineScopedRole(orgA, jefe@organization) [nivel del propio owner] = {"uuid":"…","slug":"jefe",…}
    scopes.detached(orgA) con 6 descendientes y la cota en 3 = {"purgedRoles":3,"truncated":true}
  filas de purga: 0
  asignaciones vivas: 0
    scopes.detached(orgA) con el manager SIN descendantsOf = {"purgedRoles":0,"truncated":false}
  filas de purga: 0
```

**Código**: `src/manager.ts` — `#descendantsOrDegrade(scope, operation)` ⇒
`{ below, declared, enumerated }`; degrada ante `TooManyScopesError` (la cota la caza el manager) y
ante `ScopeResolverError` (el `descendantsOf` del consumidor lanza al pasarse, que es lo que hace el
árbol del harness). **No** degrada un `AuthorizationConfigError` de `#scopeBounds`: un
`maxDescendants` fuera de rango es un bug del consumidor y sigue siendo 500.
`#purgeRolesOwnedBy` reporta `truncated = declared && !enumerated`; `#assertLevelUnderOwner` cae a la
regla mínima con `!enumerated` (que es también el caso «sin `descendantsOf`», donde ya era la regla).

**Caso**: `tests/manager.spec.ts` → `3F · S2 (auditor N3)`, con las dos formas de desbordar (el árbol
que lanza y el `descendantsOf` que devuelve de más), la regla mínima que sigue cerrando el nivel de un
ANCESTRO, el `detached` parcial (con los hechos del scope purgados y el evento con `truncated: true`)
y —por debajo de la cota— el comportamiento fuerte de 3E intacto.

## S3 · La colisión se decide por AUTORIDAD (auditor N1)

**Decisión aplicada** (respuesta 3): *una definición más autorizada gana y ensombrece a la menos
autorizada*: **global > local de un ancestro > local de un descendiente**. (a) `defineScopedRole`
desde un ANCESTRO del owner de un homónimo ya no colisiona: crea el suyo y el del descendiente queda
ensombrecido (`shadowedByAncestor`); (b) el `diff` no cuenta como deriva lo ensombrecido por
autoridad: lo lista y sale 0.

**Rojo de partida** (`v8/n1_nivel.ts` §3, PG):

```
    subU1 vuelve a ocupar n-galaxia@galaxia = {"uuid":"…","slug":"n-galaxia","scopeType":"galaxia","owner":"unit|…","rank":2}
    orgA (dueño del árbol) define SU n-galaxia@galaxia -> 422 E_AUTHZ_CATALOG_CONFLICT: Ya existe un rol 'n-galaxia' de nivel 'galaxia' visible desde organization:…
```

y el gate de CI, medido con un script propio (`scratchpad/f/s3_diff.ts`) contra **el árbol de HEAD
`5b4f3c2`** (`git archive` en `scratchpad/f/base`, para tener un «antes» real):

```
=== y el gate de CI del deploy (authz:catalog:diff) ===
  runCatalogDiff(inSync) = true · exit = 0
=== la otra salida de la plataforma: un GLOBAL del deploy con ese nombre ===
  runCatalogDiff(inSync) = false · exit = 1
    catálogo #1: DIFERENCIAS
      rol local ENSOMBRECIDO por el global del spec: n-galaxia@galaxia (owner unit|…)
      rol AMBIGUO (dos visibles en la misma cadena): n-galaxia@galaxia owners=global, unit|…
```

**Verde** (los dos scripts, sin tocarlos):

```
    subU1 vuelve a ocupar n-galaxia@galaxia = {"uuid":"…","owner":"unit|…","rank":2}
    orgA (dueño del árbol) define SU n-galaxia@galaxia = {"uuid":"…","slug":"n-galaxia","scopeType":"galaxia","owner":"organization|…","rank":2}
```

```
=== y el gate de CI del deploy (authz:catalog:diff) ===
  runCatalogDiff(inSync) = true · exit = 0
    catálogo #1: en sync
    roles locales ENSOMBRECIDOS por una definición más autorizada (no son deriva: 3F · S3):
      rol local ENSOMBRECIDO por el de un ancestro: n-galaxia@galaxia (owner unit|…, ensombrecido por organization|…)
=== la otra salida de la plataforma: un GLOBAL del deploy con ese nombre ===
  runCatalogDiff(inSync) = true · exit = 0
    catálogo #1: en sync
    roles locales ENSOMBRECIDOS por una definición más autorizada (no son deriva: 3F · S3):
      rol local ENSOMBRECIDO por un global homónimo: n-galaxia@galaxia (owner unit|…)
      rol local ENSOMBRECIDO por un global homónimo: n-galaxia@galaxia (owner organization|…)
```

**Código**:

- `src/manager.ts` — `#assertNoRoleCollision` deja de rechazar el homónimo de un DESCENDIENTE y lo
  DEVUELVE; `defineScopedRole` lo pasa al evento `role_defined` (`shadowedByAncestor`). Hacia ARRIBA
  (global o ancestro-o-igual) el 422 `E_AUTHZ_CATALOG_CONFLICT` es idéntico. La rama «sin-árbol» del
  re-chequeo transaccional no cambia: dentro del cerrojo no se resuelven cadenas, así que lo que no
  se puede juzgar se rechaza pidiendo reintentar (ver U3).
- `src/types.ts` — `AuthzCatalogWriteEvent.shadowedByAncestor?: CatalogRoleRef[]`.
- `src/catalog.ts` — `CatalogDiff.shadowedByAncestor`; `findAmbiguousRoles` pasa a ser
  `classifyHomonyms`, que reparte cada grupo `(slug, nivel)` en `shadowedByGlobal` (hay un global),
  `shadowedByAncestor` (un owner está en la cadena del otro) y `ambiguousRoles` (los dos se declaran
  ancestro del otro: un árbol que se contradice). `catalogInSync` deja de contar las dos listas de
  sombras; las líneas salen de `formatCatalogDiff` a `formatShadowedRoles` (nuevo, exportado) y
  `runCatalogDiff` las imprime bajo su propio epígrafe informativo.

**Casos**: `tests/manager.spec.ts` → el caso de colisiones (reescrito: el descendiente ya no
colisiona, el evento dice a quién ensombrece, dentro del subárbol el slug es 422 `AMBIGUOUS_ROLE` y
`{ uuid }` responde, y hacia arriba sigue habiendo 422) y `3D · M2 d + 3F · S3` (el diff clasifica
por autoridad: `shadowedByGlobal`/`shadowedByAncestor` listados con `inSync: true`, y el árbol
contradictorio como única deriva). En el juez, `src/testing/contract.ts` añade la dirección de la
autoridad al caso de `serializedCatalogWrites`, con el 422 `AMBIGUOUS_ROLE` observado en **los dos
drivers**.

**Efecto colateral obligado** (lo anoto porque no estaba en la spec): la parte en SERIE de ese caso
del juez afirmaba que el segundo `define` choca «venga del owner que venga», y eso depende de quién
gane la carrera de arriba — con S3, si gana el del descendiente, el ancestro ya no choca. Se ha hecho
**determinista** (se lee el owner del ganador y se prueban el mismo scope y un descendiente, que
siempre chocan) y se ha añadido la dirección nueva con otro slug. Es más fuerte, no más laxo: antes
la mitad de las aserciones dependía del scheduler. Lo destapó `test:mysql`.

## S4 · La frase del ensombrecimiento (auditor N4)

Lo medido: dentro del subárbol ensombrecido, **toda** ruta por slug del rol GLOBAL muere para todos,
la plataforma incluida (5/5 en `v8/n3_shadow.ts` §3), no solo para el tenant que ocupó el nombre.
Sin escalada: el hecho apunta al uuid del rol.

Corregido en README (§«Global roles win…») y en el CHANGELOG del 3E; el comportamiento no cambia —
`n3_shadow.ts` da la misma salida antes y después—, lo que cambia es que ahora **hay un caso** que lo
fija: `tests/manager.spec.ts` → `3F · S4 (auditor N4)`, que recorre `grant`/`hasRole`/`listSubjects`
por slug dentro de la cadena ocupada (422), el mismo slug fuera del subárbol (funciona), `{ uuid }`
dentro (funciona y concede lo del global), el `revoke` por slug (que ni elige ni falla: quita los
hechos de todos los homónimos) y la ausencia de escalada (`effectivePermissions` del holder local
sigue siendo `['docs:read']`).

## T1–T5

- **T1** (N5): línea en el README junto a `shadowedByGlobal`/`shadowedByAncestor`: `listRoles`
  devuelve **slugs**, así que un par ensombrecido es indistinguible ahí (`['soporte']` para los dos
  holders, con permisos efectivos distintos) — se ramifica por permisos, o se lee la identidad con
  `rolesInChain`/`{ uuid }`, nunca por nombre de rol. El caso de S4 lo respalda.
- **T2** (N6): README, junto a `serializedCatalogWrites` — el 422 es lo que recibe el perdedor que
  *llega* al cerrojo; el que **espera** en él más que el deadline recibe 503
  `E_AUTHZ_BACKEND_TIMEOUT` (`catalog.lock`) sin escribir. Y era barato sacarlo del cerrojo: la
  consulta `sync.role.locals` era **una por rol del spec** y ahora es **una sola** (`whereIn` sobre
  los slugs + filtro en memoria), que era lo que 3E había alargado; `sync.revalidate` ya era una.
- **T3** (N7): README, receta escrita y ejecutable — un rol local creado con `database` y un deploy
  que pasa a `openfga` deja el scope MUERTO (`deleteScopedRole` y `scopes.detached` 500, hechos sin
  purgar, y no se puede definir otro rol allí); la salida es instanciar el driver `database`, purgar
  con él y seguir. Con la nota de planificar el cambio de driver como una migración de hechos.
- **T4** (N7 ⚪): README, junto a `onWrite` — el hook cuesta un `resolveChain` **fresco** (no el memo
  de `forRequest()`) más una vista de catálogo **por escritura**; se declara para tener auditoría, no
  por defecto.
- **T5**: `CHANGELOG.md` con la entrada «Lot 3F» completa (S1–S4, T1–T4 y U1–U5) y `CLAUDE.md` con el
  invariante 18 ampliado (degradación de S2, autoridad de S3, `ScopeDetachOutcome`/`reason` de S1) y
  el mapa (`#descendantsOrDegrade`, `shadowedByAncestor`, `formatShadowedRoles`, el orden de
  `readRolesOwnedBy`) y el roadmap actualizados.

## U1–U5 (piezas del tester del 3E)

- **U1** — `git apply .claude/contexto/tests-tester-fase-3e.patch` limpio (solo
  `tests/manager.spec.ts`, +37/−3, sin casos nuevos: los conteos del juez no se mueven). Verde a la
  primera. Mata los cinco mutantes que sobrevivían: Q1 (el mensaje de `AMBIGUOUS_ROLE` aconsejaba lo
  imposible), Q2 ×2 (el 422 filtraba clave de scope, uuid y slug de otro tenant) y las dos de P3
  («nada a medias» solo era observable con un rol que el actor SÍ podía purgar y llegando primero).
- **U2** — **corregida la afirmación sobre R7, sin fingir que hay test.** El mutante que hace que
  `purgeRole` olvide los vínculos pasa la suite entera en los tres motores porque
  `authz_role_permissions.role_uuid` es `ON DELETE CASCADE` (y `authz_assignments.role_uuid` es
  `ON DELETE RESTRICT`): es un mutante **equivalente** bajo este esquema. Ahora se dice donde toca:
  `README.md` (sección del puerto: el garante es el ESQUEMA, vigilado por K11; un driver de terceros
  sobre un esquema sin esas acciones tiene que borrar los vínculos él y **ningún test de este paquete
  se lo va a decir**), `src/testing/contract.ts` (docblock de `linksOf` + el comentario del caso) y
  `CHANGELOG.md` (la frase del 3E que decía «until now that was the schema's CASCADE, not the code»
  ya no está). También en `.claude/contexto/fase-3-lote-e-informe.md`, con la corrección explícita.
- **U3** — la rama «no juzgable» del re-chequeo transaccional (el `throw` genérico «El catálogo
  cambió mientras se validaba…») **ya no depende de la carrera**: en la parte en SERIE del caso de
  `serializedCatalogWrites` se recalienta el memo, se inserta con `insertRoleUnseen` un homónimo cuyo
  owner es una unit **HERMANA** —que no es global ni ancestro-o-igual, así que no se puede clasificar
  sin resolver su cadena, y resolverla con el cerrojo sostenido sería un abrazo mortal con un pool de
  1— y se afirma el 422 **con su mensaje** y que no escribe. Determinista en SQLite, PG y MySQL.
- **U4** — las dos mitades de Q7, en `tests/manager.spec.ts` → `3F · U4`: un `revoke` por slug con
  dos homónimos visibles notifica **los dos** en `event.roles`, y un `revoke` por `{ uuid }` de un rol
  cuyo owner no está en la cadena **ocurre** (quitar nunca concede) pero el evento **no** lo nombra —
  ni su slug ni su owner: es Q2 por la puerta del hook. Comprobado que mata los dos mutantes:
  `[visible[0]]` en `#resolvedRoles` ⇒ falla; quitar la comprobación de owner de la rama `{uuid}` ⇒
  falla.
- **U5** — `readRolesOwnedBy` ordena por `uuid` (en la consulta y, por los lotes de 500, también
  sobre el conjunto), con la nota de por qué: el orden no decide QUÉ se purga (la policy de rango se
  comprueba sobre TODOS antes de tocar ninguno) sino lo que se REPRODUCE — la secuencia de
  `role_purged` que ve el hook de auditoría. Fijado con una aserción en el caso de P2/P3.

---

## Verificación

| Comando | Resultado |
|---|---|
| `npm run typecheck` | ✅ |
| `npm run build` (purity + typecheck + tsc + stubs) | ✅ |
| `npm test` (SQLite memoria) | ✅ **412 passed** |
| `OPENFGA_TEST_URL=:8101 npm test` | ✅ **514 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:sqlite-file` | ✅ **516 passed** |
| `TEST_PG_URL=… OPENFGA_TEST_URL=:8101 npm run test:pg` | ✅ **681 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` | ✅ **681 passed** |
| `OPENFGA_TEST_URL=:8103 npm test` (tope 3: `openfga-tiny`) | ✅ **514 passed** |

`openfga-tiny` borrado al terminar. Sin `.only`, sin `.skip`, sin commits.

**Higiene**: 0 bases `authz_test_*` en PostgreSQL y MySQL al terminar; 0 stores nuevos en OpenFGA
`:8101` (el más reciente es de las 04:09 UTC, de otro agente; los míos se borran solos). No se tocó
`.claude/worktrees/`.

## Ficheros tocados

`src/manager.ts`, `src/types.ts`, `src/catalog.ts`, `src/catalog_cache.ts`, `src/testing/contract.ts`,
`index.ts`, `tests/manager.spec.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`, y la corrección de
`.claude/contexto/fase-3-lote-e-informe.md` (U2).

## Cambios BREAKING de este lote

1. `scopes.detached` devuelve `ScopeDetachOutcome` (`{ purgedRoles, truncated, reason? }`) en vez de
   `void`. Compatible para quien lo ignoraba.
2. `defineScopedRole` desde un ancestro sobre un homónimo de un descendiente **ya no lanza**: crea y
   ensombrece. Quien dependiera del 422 para «reservar» un nombre hacia abajo tiene que mirar
   `shadowedByAncestor`.
3. `CatalogDiff` gana `shadowedByAncestor` y `catalogInSync` deja de contar las sombras: un
   `authz:catalog:diff` que antes salía 1 por una sombra ahora sale 0 (y las lista).

## Lo que este lote NO cierra (para el auditor)

- **R7 sigue sin oráculo** y ahora está dicho: el «todo o nada» de los vínculos de `purgeRole` lo
  garantiza el esquema. Cerrarlo de verdad pide infraestructura nueva (correr el caso con las FK
  desactivadas, o espiar el SQL), que es una decisión de diseño de la suite.
- **La degradación de S2 es silenciosa para quien no mire el retorno o el evento**: no hay warning
  por consola. Es deliberado (`truncated` es el canal), pero un consumidor que ignore el resultado no
  se entera de que su subárbol quedó a medias.
- **`ambiguousRoles` queda estructuralmente casi vacío**: con la autoridad ordenando todas las
  parejas posibles, solo lo alcanza un `resolveChain` contradictorio. Se ha conservado el campo (y su
  caso) porque ese árbol roto existe y es la única deriva real que queda ahí.
