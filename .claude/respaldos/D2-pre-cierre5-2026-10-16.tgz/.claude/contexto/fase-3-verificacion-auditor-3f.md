# Fase 3 · Lote 3F — Auditor de seguridad, ronda final (delta `5b4f3c2..ae3a7a8`)

> Contra el código real en `v2/fase-0`, HEAD `ae3a7a8`. **No se tocó ni un archivo del repo.**
> Scripts nuevos en `…/scratchpad/v9/` (`x1c_detached.ts`, `x2_autoridad.ts`, `x3_degrada.ts`,
> `x4_truncated.ts`, `x5_reparacion.ts`, `x6_canal.ts`, `run9.sh`); los cinco del 3E re-ejecutados
> **tal cual** desde `…/scratchpad/v8/`. Motor: **PostgreSQL 18** + OpenFGA `:8101`.
> Suite completa `TEST_DB=pg` + `:8101`: **681 passed (681)** — coincide con el informe del lote.
> `repro5_resiste.ts` (`…/scratchpad/v6/`): **22 barreras, 22 `ok`, 0 `ROTO`** (el script declara 22
> `intento(...)`; la línea 23 de mi informe anterior contaba la línea informativa).
> Higiene: 0 bases `authz_test*` en PostgreSQL y MySQL, 0 stores propios en OpenFGA `:8101`
> (borré los dos `auditor-n1-*` que dejaron mis scripts; los de otro agente, intactos).

## Veredicto en una línea

**APTA CON CORRECCIONES** — y la respuesta a la pregunta prioritaria es **sí: el 3F introdujo una
tercera regresión**, un 🟠 que reabre por la puerta de atrás exactamente lo que P3 (auditor A3) vino a
cerrar: `scopes.detached` de un ancestro que el árbol ya no conoce purga los roles locales de sus
**descendientes VIVOS** —de cualquier rango— **sin ninguna comprobación de rango**. Lo demás es 🟡/⚪
de disponibilidad y de honestidad del canal nuevo: a la Fase 3b.

---

## Misión 1 · Los cinco scripts del 3E, re-ejecutados TAL CUAL

Salidas literales en `…/scratchpad/v9/n1.txt`, `n3_shadow.txt`, `n6_actor_sin_within.txt`,
`n7_cotas.txt`, `n4_pg.txt`. Coinciden con lo que el informe del lote pegó.

| # | Hallazgo 3E | ANTES (`5b4f3c2`) | AHORA (`ae3a7a8`) | Estado |
|---|---|---|---|---|
| **N1** 🟡 | mina de slug para tipos no-ancestro: ocupa el nombre del dueño del árbol y deja el CI rojo | `orgA define SU n-galaxia@galaxia -> 422 CATALOG_CONFLICT` · `diff` exit 1 | `orgA … = {"owner":"organization\|…"}` · `catalogInSync = true` (medido en `x5`) | ✅ **cerrado** — coste: 🟡 P3′ y ⚪ P5 |
| **N2** 🟡 regresión | `detached` con `requireActor` sobre un scope ya borrado no purga NADA | `422 UNKNOWN_SCOPE` · `filas 1 · asignaciones 1 · denies 1` | `{"purgedRoles":1,"truncated":false,"reason":"owner-detached-unknown"}` · `0 · 0 · 0` | ✅ **cerrado** — coste: 🟠 **P1** |
| **N3** 🟡 regresión | `descendantsOf` + subárbol > cota ⇒ 503 en `define` y en `detached`, sin purgar | `503 RESOLVER_FAILED` ×2 · `filas de purga 1 · asignaciones 2` | `define … = {…}` · `detached = {"purgedRoles":3,"truncated":true}` · `0 · 0` | ✅ **cerrado** — coste: 🟡 P2 y 🟡 P4 |
| **N4** 🟡 | la frase «the tenant only hurts itself» | README sin corregir | `README.md:237` «unusable by slug for everyone — the platform included» + caso `3F · S4` | ✅ cerrado (comportamiento idéntico: `n3_shadow` da lo mismo, 5/5) |
| **N5** ⚪ | `listRoles` no desambigua | sin línea | `README.md:237` y `:247` | ✅ cerrado |
| **N6** ⚪ | el cerrojo promete 422 y bajo espera es 503 | sin línea · `sync.role.locals` una consulta **por rol** | `README.md:249` explícito · `catalog.ts:322` una sola consulta (`whereIn` + filtro en memoria) | ✅ cerrado · R2 re-medido: **8 carreras en PG, 8 con 1 ganador y el 422 exacto** (`n4_pg.txt`) |
| **N7** ⚪ | driver sin `purgeRole` congela el scope · coste de `onWrite` | solo «filas escritas a mano» | `README.md:276-285` (receta) y `:119` («It is not free») | ✅ cerrado |

Detalle de N4 re-medido: `n3_shadow.ts` §1 sigue dando `authorize(holderLocal,'billing:write'|'admin:todo') = false`
y `effectivePermissions = ['docs:read']`. **El ensombrecimiento sigue sin conceder nada de más.**

---

## Misión 2 · Hallazgos nuevos (solo el delta)

### 🟠 P1 · `detached` de un ancestro desconocido purga los roles de descendientes VIVOS sin policy de rango (tercera regresión)

- **Escenario**: consumidor con `scopes.descendantsOf` declarado (lo que el invariante 18 pide) y
  `requireActor: true` sin `requireWithin` (la config para la que se escribió S1). Árbol
  `app → orgA → unitU1`; `unitU1` tiene un rol local `caro@unit` **rank 40** con holders vivos. El
  atacante es `adminU1`, **rank 20**.
  → **precondición**: la plataforma borra la **fila de orgA** y notifica después (el orden que S1
  admite explícitamente). `unitU1` sigue viva y con cadena completa (`unit → organization → app`,
  ruta materializada, que es lo normal en SaaS); `descendantsOf(orgA)` —un `where parent_id = orgA`,
  que **no necesita la fila del padre**— devuelve `[unitU1]`.
  → **acción**: `scopes.detached(orgA, { actor: adminU1 })`.
  → **resultado**: `{"purgedRoles":1,"truncated":false,"reason":"owner-detached-unknown"}`. El rol
  rank 40 y su asignación **desaparecen**; `authorize(holder,'docs:read',U1)` pasa de `true` a
  `false`. Las **dos** puertas que P3 defiende niegan la misma operación: `detached(u1,{actor})` ⇒
  422 `RANK_EXCEEDED` («rank 20 … no puede tocar 'caro' (rank 40)») y `detached(orgA,{actor})` con el
  árbol completo ⇒ 422 igual.
- **Evidencia**: ✅ `…/scratchpad/v9/x1c_detached.ts`, salida literal:
  ```
  === control (árbol completo): las dos puertas de P3 ===
      scopes.detached(u1,   {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED …
      scopes.detached(orgA, {actor: adminU1}) -> 422 E_AUTHZ_RANK_EXCEEDED …
  === la plataforma borra la FILA de la org; la unit conserva su ruta ===
      resolveChain(orgA) = null
      resolveChain(u1)   = unit → organization → app   <-- unit VIVA con cadena completa
      authorize(holder, docs:read, U1) ANTES del ataque = true   <-- el rol SIGUE concediendo
      ATAQUE: scopes.detached(orgA, {actor: adminU1}) = {"purgedRoles":1,"truncated":false,"reason":"owner-detached-unknown"}
      filas de "caro": 0 · asignaciones: 0
      authorize(holder, docs:read, U1) DESPUÉS = false
  ```
  (`x1_detached_mentira.ts` da lo mismo con `memoryScopeTree` + `descendantsFrom`.)
  Código: `src/manager.ts:452-457` — el orden es
  `#descendantsOrDegrade(scope)` → `ownerKeys = [scope, ...below]` → `readRolesOwnedBy(ownerKeys)` →
  `reason = actor ? await #assertAboveOwnedRoles(driver, actor, **scope**, owned…) : undefined`, y
  `#assertAboveOwnedRoles` (`:496-502`) hace `if (!chain) return 'owner-detached-unknown'`.
  **La decisión de saltarse el rango se toma sobre la cadena del scope NOTIFICADO y se aplica a roles
  cuyos owners son OTROS scopes, cuyas cadenas nunca se consultan.** Es un fail-open de manual:
  `resolveChain === null` ⇒ la policy no corre.
- **Steelman del defensor**: *«está escrito y razonado en tres sitios (`manager.ts:439-445`,
  `README.md:257`, `CLAUDE.md:115`): "un rol cuyo owner no está en el árbol no es visible en ninguna
  parte", así que saltarse el rango no concede nada; y sin esto, con `requireActor: true` el rol, sus
  asignaciones y los denies de un scope borrado no tenían salida por el manager (N2)»* → **no me
  convence**: la premisa es cierta del scope notificado y **falsa de los roles que se purgan**. Medido
  arriba: el owner (`unitU1`) SÍ está en el árbol, el rol SÍ es visible y SÍ concedía en el instante
  en que se destruye. La justificación cubre el caso `detached(u1)` —donde efectivamente da igual— y
  no el caso `detached(padre)`, que es justo el que 3E añadió con `descendantsOf`. Las dos piezas del
  lote (S1 y S2) son correctas por separado y se rompen al componerse.
- **Alcance**: sin `within` obligatorio, el llamante no tiene que ser del tenant víctima (`x6_canal.ts`:
  un forastero llega a `scopes.detached` de scopes ajenos), así que si el ancestro borrado tenía hijos
  de más de un tenant, la destrucción los cruza. Con `requireWithin: true` la rama nueva es
  inalcanzable (`#assertWithin` → `assertKnownScope` ⇒ 422) — es decir, **la config endurecida no
  tiene el agujero y tampoco tiene el arreglo de N2**.
- **Mitigación mínima**: medir el rango en la cadena del **owner de cada rol** (lo que ya hace
  `deleteScopedRole`) y saltarse la comprobación **solo** para los roles cuyo owner tampoco resuelve.

### 🟡 P2 · El canal nuevo (`truncated`) miente justo en el caso estrella de S1

- **Escenario**: mismo consumidor, pero con un `descendantsOf` **coherente** (devuelve `null` para un
  scope que no conoce, que es lo que hace el propio helper publicado `descendantsFrom`). Se borra la
  fila de `orgB`, se notifica `detached(orgB)` → `#descendants` traduce `null` a `[]` con
  `unknown: 'empty'` (`manager.ts:1821`), así que `enumerated: true` y `truncated = declared && !enumerated = false`.
  → **resultado**: `{"purgedRoles":0,"truncated":false}` —«purga completa»— mientras el rol local de
  la unit hija sigue vivo, con su asignación, y **sigue concediendo**. Tampoco sale `reason`, porque
  con `owned.length === 0` se vuelve antes de la comprobación (`manager.ts:456`).
- **Evidencia**: ✅ `…/scratchpad/v9/x4_truncated.ts`:
  `descendantsOf(orgB) = null` · `scopes.detached(...) = {"purgedRoles":0,"truncated":false}` ·
  `filas de 'huerfano': 1 · asignaciones vivas: 1 · authorize = true`.
- **Steelman**: *«`truncated` documenta "el subárbol no se pudo enumerar", y aquí sí se enumeró: no
  había nada que enumerar según el árbol»* → **me convence a medias**: literalmente sí, pero el campo
  se creó para que el consumidor sepa «si su subárbol quedó a medias» (`types.ts:519`) y en la
  situación para la que existe `reason` responde que todo fue bien. Los dos `descendantsOf` naturales
  dan resultados opuestos y ninguno de los dos está exigido por el puerto: el que responde por el
  padre borrado da P1, el que responde `null` da P2.
- **Mitigación mínima**: cuando `resolveChain(scope) === null`, `truncated` debería ser `true` salvo
  que el subárbol se haya enumerado de verdad; y emitir `reason` también con `purgedRoles: 0`.

### 🟡 P3′ · La autoridad de S3 es por POSICIÓN y no mira el rango: un rank 3 inutiliza un rol rank 40 y la víctima no puede repararlo

- **Escenario**: `orgA → unitU1`. La plataforma define `critico@unit` **rank 40** owner `unitU1`
  (con `admin:todo`) y se lo da a un holder. El atacante tiene `org-pobre` **rank 3** en `orgA` y un
  permiso delegable.
  → `deleteScopedRole` y `scopes.detached(u1)` le responden 422 `RANK_EXCEEDED` (P3 funciona).
  → **acción**: `defineScopedRole(pobre, orgA, {slug:'critico', scopeType:'unit', rank:1, …})`. Hasta
  3E era 422 `CATALOG_CONFLICT`; con S3 **se crea** y devuelve `shadowedByAncestor`.
  → **resultado**: en toda la cadena de `unitU1`, `hasRole`, `grant` y `listSubjects` por slug pasan a
  422 `AMBIGUOUS_ROLE`. El admin de la unit (rank 20) **no puede quitar la sombra**: `deleteScopedRole`
  mide el rango en la cadena del owner (`orgA`), donde vale 0 ⇒ 422. Y `authz:catalog:diff` sale
  **verde** (`catalogInSync: true`), así que no hay señal automática.
- **Evidencia**: ✅ `…/scratchpad/v9/x2_autoridad.ts` y `x5_reparacion.ts`:
  `defineScopedRole(pobre, orgA, 'critico@unit' rank 1) = {…"owner":"organization|…","rank":1}` ·
  `hasRole/grant/listSubjects -> 422 E_AUTHZ_AMBIGUOUS_ROLE` ·
  `deleteScopedRole(adminU1 rank20, sombra) -> 422 … (rank 0 en el owner del rol)` ·
  `catalogInSync = true`. Código: `manager.ts:1438-1443`.
  **Sin escalada, verificado**: `authorize(holder,'admin:todo',U1) = true` y
  `effectivePermissions = ["docs:read","admin:todo"]` (los del rol de la unit, no los del ancestro);
  el hermano `u2` no se ve afectado (`grant(otro,'critico',U2) = {existed:false}`); y la dirección
  contraria sigue cerrada (`defineScopedRole(subU2, u2, 'arriba@unit') -> 422 CATALOG_CONFLICT: es un
  ancestro`).
- **Steelman**: *«es la decisión 3 escrita y el ancestro ya podía hacerle cosas peores: `revoke` por
  slug no evalúa rango y le quita la asignación igual (medido: `authorize` pasa a `false`)»* →
  **me convence a medias**. Es cierto que el `revoke` por slug ya lo permitía **sin** la sombra (con
  un solo homónimo el slug resuelve al rol de la unit), así que S3 no abre esa puerta. Lo que S3 abre
  es un estado **persistente** que el rango protege en las otras dos puertas y que la víctima no puede
  deshacer: el paquete decide «quién manda» por posición en el árbol y en el resto del lote decide lo
  mismo por `rank`. Y el comentario que 3E dejó en `catalog.ts` («`defineScopedRole` SIGUE rechazando
  colisiones: un tenant no puede crear ambigüedad a propósito») ya no es verdad.
- **Mitigación mínima**: exigir en el ensombrecimiento el mismo umbral que `deleteScopedRole` —rank
  del actor mayor que el del rol que va a ensombrecer— o dejarlo escrito como capacidad del ancestro.

### 🟡 P4 · La regla FUERTE de nivel la apaga el propio actor, y también se apaga sola si `descendantsOf` falla

- **Escenario (a)**: `descendantsOf` declarado, `maxDescendants` = N. Con el subárbol de `unitU1` por
  debajo de N, la mina de N1 está cerrada (`galaxia`, `proyecto` ⇒ 422 `ROLE_LEVEL_ABOVE_OWNER`). El
  actor crea **N+1 hijos de su propia unit** (crear scopes es una función normal del producto) y los
  mismos dos `define` **pasan**: `#descendantsOrDegrade` cae en `TooManyScopesError` y
  `#assertLevelUnderOwner` hace `if (!enumerated) return`.
- **Escenario (b)**: sin tocar el árbol, con `descendantsOf` **lanzando** (réplica caída): el mismo
  `define` que era 422 con el árbol sano pasa. Es fail-open ante una condición de error.
- **Evidencia**: ✅ `…/scratchpad/v9/x3_degrada.ts` §2 y §3:
  `descendientes de u1 = 4 (cota 3)` ⇒ `define galaxia@galaxia … = {…}` (era 422) ·
  `define … con descendantsOf CAÍDO = {…}` (con el árbol sano, 422). El nivel de un **ancestro** sigue
  cerrado con la regla mínima (`organization@organization -> 422`).
- **Steelman**: *«la regla mínima es la que corre en todo consumidor con el stub publicado y no
  concede nada; degradar es la decisión 2, y desde S3 la mina solo se ensombrece a sí misma»* →
  **me convence en el resultado, no en la forma**: el daño residual es pequeño (ocupar un nombre que
  el ancestro puede ensombrecer), pero es un control de seguridad que el sujeto vigilado puede
  desactivar creando filas, y que además se desactiva cuando una dependencia se cae. Merece estar
  escrito así, no como «degradar nunca deja peor».
- **Efecto lateral medido**: la misma degradación convierte en éxito lo que en 3E era 503 —
  `scopes.detached(orgA)` por un **forastero** devuelve `{"purgedRoles":0,"truncated":true}` y purga
  los hechos de `orgA` (`x6_canal.ts`), porque con `below = []` no hay roles que leer y la policy de
  rango no llega a correr.
- **Mitigación mínima**: una línea en el README y en el invariante 18 diciendo que con el subárbol no
  enumerable la regla de nivel es la mínima **y por qué eso es aceptable**, en vez de «degradar nunca
  deja peor».

### ⚪ P5 · `catalogInSync` deja de contar `shadowedByGlobal`: se pierde la única señal automática de que las rutas por slug de la plataforma están muertas

- Antes: un local que ocupa el `(slug, nivel)` de un global del spec ⇒ `diff` exit 1. Ahora ⇒ exit 0 y
  una línea informativa (`formatShadowedRoles`). Lo que hay detrás de esa línea es lo que N4 midió:
  **5/5 slugs globales muertos por slug dentro del subárbol, para la plataforma también**. La decisión
  (que un tenant no pueda dejar el CI rojo) es correcta; el efecto es que nadie se entera por CI.
- **Evidencia**: ✅ `catalog.ts:687-690` (`catalogInSync` sin `shadowedByGlobal`) y `x5_reparacion.ts`
  (`catalogInSync = true` con la sombra puesta). **A la Fase 3b**: bastaría un exit code distinto
  (o un flag `--fail-on-shadows`) para que el operador pueda elegir.
- Segundo efecto ⚪ de `classifyHomonyms` (`catalog.ts:782`): cuando en el grupo hay un global se hace
  `continue`, así que una pareja de locales **contradictoria** dentro de ese mismo `(slug, nivel)` ya
  no se detecta. No es explotable (esa deriva exige un árbol con ciclo), pero es un caso ciego nuevo.

### ⚪ P6 · `CLAUDE.md` se contradice consigo mismo en el invariante 18

- `CLAUDE.md:95` sigue diciendo «colisión con global/**ancestro/descendiente** ⇒ 422» y trece líneas
  más abajo «La colisión se decide por AUTORIDAD … el del descendiente queda ensombrecido». La línea
  de resumen es la que un agente lee primero.

### ⚪ P7 · (no es del delta) el 422 de P3 filtra slug y rank de roles de otro tenant

- `scopes.detached(unitDeOtroTenant, { actor })` sin `within` responde
  `El actor (rank 0 en el owner del rol) no puede tocar 'secreto-de-a' (rank 49)`. Es enumeración de
  catálogo ajeno sin escribir nada. Viene de 3E (el parche del tester U1 arregló el mensaje de
  `AMBIGUOUS_ROLE`, no este) y lo dejo anotado porque es la misma puerta del 🟠 P1.
- **Evidencia**: ✅ `…/scratchpad/v9/x6_canal.ts`.

---

## Lo que intenté y NO se rompió

- **Fabricar el desconocimiento por identidad**: uuid en **mayúsculas** ⇒ 422 `INVALID_IDENTITY` en la
  puerta (`identity.ts:110`, `COMPONENT_FORMAT` solo minúsculas), así que el alias por caja —que en
  MySQL con collation `_ci` habría hecho casar `owner_scope_key` y saltarse el rango— **no existe**.
  Alias por guiones de un scope que el árbol funde ⇒ `canonicalScope` lo canoniza y el rango se exige
  igual. Un `resolveChain` que miente sobre el **tipo** del propio scope ⇒ 503 (`backend_guard.ts:204`).
  Cadena vacía ⇒ 503, no «desconocido».
- **La ambigüedad de S3, como vía de escalada**: ninguna. El hecho apunta al uuid del rol
  (`effectivePermissions` del holder del rol de la unit = los suyos, con el ancestro homónimo puesto),
  el hermano sin homónimo no se entera, y la dirección descendiente→ancestro sigue siendo 422.
- **La carrera del `sin-árbol`** (`n4_race.ts`, 8 carreras en PG, dos procesos reales): 1 fila, 1
  ganador, 422 exacto en las 8. Con S3 la carrera ancestro-vs-descendiente puede ganarla el
  descendiente y el ancestro recibe el 422 genérico «reintenta» — **fail-closed**, y el reintento
  aplica la autoridad. Dentro de la transacción no se resuelve ninguna cadena y lo que no se puede
  juzgar se rechaza (`manager.ts:1021-1026`): no hay rama que escriba a ciegas.
- **`#descendantsOrDegrade` como fail-open general**: solo traga `TooManyScopesError` y
  `ScopeResolverError`; un `AuthorizationConfigError` de `#scopeBounds` sigue siendo 500 y un error
  del paquete lanzado por el `descendantsOf` del consumidor pasa sin envolver (`manager.ts:1817`).
- **`ScopeDetachOutcome` como canal entre tenants**: `purgedRoles`/`truncated` solo se obtienen
  ejecutando la operación destructiva; no hay sonda no destructiva. El único canal limpio que
  encontré es el mensaje del 422 (P7), que ya existía.
- **Las 22 barreras de delegación** (`repro5_resiste.ts`): 22/22 intactas, incluidas las de rango,
  deny en ancestro, `assignableAt`, tenant hermano y raíz.
- **Regresión**: suite completa `TEST_DB=pg` + `:8101` ⇒ **681/681**.

---

## Preguntas abiertas para el arquitecto

1. **¿El salto de rango de S1 debe decidirse por rol o por scope?** Hoy se decide con la cadena del
   scope notificado y se aplica a roles de owners que sí están en el árbol (P1). Medirlo en la cadena
   del **owner de cada rol** cierra el 🟠 sin perder nada de lo que S1 vino a arreglar: los roles
   huérfanos de verdad siguen purgándose (su owner tampoco resuelve).
2. **¿Qué le exige el paquete a `descendantsOf` sobre un scope que `resolveChain` ya no conoce?** Hoy
   nada, y las dos respuestas naturales dan resultados opuestos: devolver los hijos ⇒ P1; devolver
   `null` ⇒ P2. Esto es contrato del puerto y debería estar en el docblock de `ScopeDescendantsResolver`.
3. **¿La autoridad de S3 debe mirar el rank?** Si la respuesta es «no, la posición manda», hay que
   escribir que un actor de rank 1 en un ancestro puede dejar inutilizable por slug cualquier
   `(slug, nivel)` de todo su subárbol sin que el descendiente pueda repararlo — hoy el README dice lo
   contrario para los globales («the tenant that took the name…») y nada para este caso.
