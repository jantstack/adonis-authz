# Fase 3 · Lote 3G — cierre (auditor 3F; tester por incorporar)

> Auditor sobre `ae3a7a8`: **APTA CON CORRECCIONES** con un 🟠 reproducido (P1) que es la **tercera regresión seguida introducida al corregir**. Las tres tienen la misma forma: **dos piezas correctas por separado que se rompen al componerse** (S1 salta el rango cuando el scope no resuelve + S2 enumera descendientes ⇒ se purgan roles de descendientes VIVOS sin rango). Este lote cierra el 🟠 **y** ataca esa causa con casos de composición.

## Respuestas a sus tres preguntas (decididas)

1. **¿El salto de rango de S1 se decide por rol o por scope?** **Por rol.** El rango se mide en la cadena del **owner de cada rol a purgar** (igual que `deleteScopedRole`), y la comprobación solo se salta para los roles cuyo **propio owner** tampoco resuelve — que son los realmente inalcanzables. Cierra el 🟠 sin perder nada de S1.
2. **¿Qué le exige el puerto a `descendantsOf` sobre un scope que `resolveChain` ya no conoce?** Se documenta en el docblock de `ScopeDescendantsResolver`: **puede devolver los hijos** (el consumidor es la autoridad sobre su tabla) y el paquete no asume nada. Consecuencia obligatoria: cuando el scope **no** resuelve y `descendantsOf` devuelve vacío o `null`, el paquete **no puede demostrar que la purga fue completa** ⇒ `truncated: true`, nunca `false` (cierra P2).
3. **¿La autoridad de S3 debe mirar el rango?** **Sí.** Ensombrecer es tan destructivo como borrar: un ancestro solo puede ensombrecer un rol de un descendiente si su actor **supera el rango** del rol ensombrecido, igual que en `deleteScopedRole`. Cierra P3′ y deja la regla uniforme: *sobre un rol solo actúa quien lo supera en rango*.

## Bloqueantes

| # | Hallazgo | Decisión |
|---|---|---|
| **W1** 🟠 regresión | (P1) `scopes.detached` de un ancestro que el árbol ya no conoce purga los roles locales de descendientes **vivos**, de cualquier rango, sin comprobación — mientras `deleteScopedRole` y el `detached` del propio scope lo niegan con 422. Reproducido: rol rank 40 destruido por un actor rank 20; `authorize` pasa de `true` a `false`. | Respuesta 1. Casos: (a) el escenario exacto de `x1c_detached.ts` ⇒ 422 `RANK_EXCEEDED` y el rol sobrevive; (b) el mismo con un rol cuyo owner **tampoco** resuelve ⇒ se purga (S1 intacta); (c) mezcla de ambos en una llamada ⇒ 422 y **no se purga ninguno** (todo o nada); (d) el control de `x1c` (árbol completo) sigue en 422. |
| **W2** 🟡 | (P2) `truncated: false` con la purga incompleta: con `descendantsOf` coherente (`null` para lo desconocido) el resultado dice «completa» mientras el rol de la unit hija sigue vivo y concediendo. | Respuesta 2: si `resolveChain(scope) === null` y no se pudo enumerar por debajo, `truncated: true` **siempre**, y `reason` presente aunque `purgedRoles === 0`. Docblock de `ScopeDescendantsResolver` con el contrato. Caso con el helper publicado `descendantsFrom`. |
| **W3** 🟡 | (P3′) La autoridad de S3 es por posición y no mira el rango: un actor rank 3 en un ancestro inutiliza por slug un rol rank 40 de una unit en toda la cadena, y **la víctima no puede repararlo** (su rango se mide en la cadena del owner del rol que ensombrece). | Respuesta 3: `defineScopedRole`/`updateScopedRole` que ensombrecen un rol de un descendiente exigen `actorRank > shadowedRole.rank` ⇒ si no, 422 `E_AUTHZ_RANK_EXCEEDED` nombrando que hay un rol de mayor rango con ese nombre por debajo. Casos: rank 3 no ensombrece un rank 40; rank 50 sí; y el ensombrecido puede seguir usándose por `{ uuid }`. Actualizar el comentario de `catalog.ts` que dice «un tenant no puede crear ambigüedad a propósito». |
| **W4** ⚠️ causa | Las tres regresiones nacen de componer piezas correctas. Hoy cada una tiene su caso, ninguna tiene caso **junto a las otras**. | **Casos de composición** en el juez (`since('2.2')`), que son los que habrían cazado las tres: (i) `detached` con `requireActor` + `descendantsOf` + scope desconocido + roles de descendientes vivos de distinto rango (W1); (ii) `detached` con la cota superada **y** actor con rango insuficiente (¿degrada antes de comprobar? debe comprobar primero); (iii) `define` que ensombrece **y** supera la cota de descendientes a la vez; (iv) `detached` de un scope desconocido cuyo `descendantsOf` lanza. Cada uno con las dos caras. |

## Obligatorias (rápidas)

| # | Qué |
|---|---|
| X1 | (P4) Documentar que la degradación de `descendantsOf` (cota superada o resolutor caído) **relaja la regla de nivel a la mínima**, y que el actor puede provocarla creando descendientes: la mina residual sigue siendo reparable por autoridad+rango (W3). No cambiar el comportamiento. |
| X2 | (P4 efecto lateral) Con `below = []` por degradación, la policy de rango del `detached` **no llega a correr**: con W1 debe correr igual sobre los roles del scope exacto. Caso. |
| X3 | (P5) `authz:catalog:diff --fail-on-shadows` (exit ≠ 0 si hay `shadowedByGlobal`/`shadowedByAncestor`), documentado como el gate para quien quiera enterarse por CI. Y `classifyHomonyms` no debe dejar de detectar dos locales contradictorios por el hecho de que exista un global en el grupo. |
| X4 | (P6) `CLAUDE.md:95` contradice al invariante 18 trece líneas más abajo («colisión con descendiente ⇒ 422» vs «se decide por autoridad»): corregir. |
| X5 | (P7) El 422 de `RANK_EXCEEDED` filtra slug y rank de roles de otro tenant cuando no hay `within`: nombrar solo lo que está en la cadena preguntada, como ya se hizo con `AMBIGUOUS_ROLE`. |
| X6 | CHANGELOG «Lot 3G» con el breaking de W3; README §Scoped roles (rango para ensombrecer, contrato de `descendantsOf`, `truncated`). |

## Entrega
`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-3-lote-g-informe.md` incremental. Sin commits.
