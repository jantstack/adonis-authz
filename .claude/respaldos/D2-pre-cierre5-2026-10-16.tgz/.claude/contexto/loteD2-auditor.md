# Lote D · sublote D2 — auditoría adversarial · 2026-10-15

Árbol: `main` sobre `75353fe`, con D2 en el working tree (diff + 4 specs sin seguimiento). No toqué el repo: todo lo
ejecutado corrió en copias, en `scratchpad/audD2/{tree,l9}/`, con SQLite `:memory:`. Usé dos stores efímeros en `:8090`
(`aud-d2-probe`, `aud-d2-probe2`); los creó y los borró el script (DELETE 204). No hice restarts, gates ni contenedores.

## Veredicto en una línea

**Inseguro tal cual en un punto (🟠1).** La propiedad publicada «una pasada cortada nunca concede lo que el origen niega»
es falsa para el deny transportado por grupo. La fila de la guardia solo pasa por el orden de inserción. Además, el
procedimiento de retirada/rollback deja abierta una carrera con la flota en `'write'` (🟠2). Lo demás resiste o es 🟡/⚪.

---

## Hallazgos

### 🟠 1 · El reconcile cortado concede si la membresía que TRANSPORTA el deny se enumera después del allow directo

**Escenario**
- Origen `database` (real, SQLite).
- El lunes se comparte `document:D#viewer@user:U`. El martes U entra en `group:G`. `G#member` está denegado en `D#viewer`.
- El origen niega: `check = false`.
- `authz:relations:reconcile` hacia otro driver se corta tras la 2.ª escritura (503 del destino).
- Resultado: el destino tiene el deny de `G#member` y el allow directo de U, pero no la membresía. **`check` del destino =
  true.**

**Evidencia** (✅ ejecutado en `scratchpad/audD2/tree/tests/zz_aud_a1.spec.ts`; A1 con dobles, A1b con
`DatabaseRelationsDriver` real de origen):
```
k=1 [deny document#viewer]                                          -> check=false (503 partial=true)
k=2 [deny document#viewer | relate document#viewer]                 -> check=true  (503 partial=true)
k=3 [deny document#viewer | relate document#viewer | relate group#member] -> check=false (ok)
```

**Causa**
- `src/relations/reconcile.ts:584-596`: la fase 2 escribe `toWrite` en el orden de enumeración del origen
  (`planPartition`, `:1013-1028`, sobre un `Map` en orden de inserción).
- `database` enumera `orderBy('uuid')` (uuid v7 = orden de creación, `database_relations_driver.ts:1158`). En `openfga`,
  el orden es el del `Read`.
- Las fases «denies → allows» ordenan las tuplas `denied_*`. Las membresías que hacen falta para que esas tuplas corten
  son allows y no tienen orden propio.

**La guardia no lo ve.** La fila «deny transportado por grupo» de `relations.reconcile.order`
(`tests/guard_surface.spec.ts:1756-1757`) siembra la membresía ANTES que el allow. Con el mismo estado sembrado al revés,
el caso se pone rojo. Ni el runner publicado (`denies: true`) ni el runbook (ver 🟡5) siembran esa forma.

**La letra es técnicamente cierta y el efecto es falso.** README §«Denies migrate as denies» y CHANGELOG dicen «never an
allow without its deny». La tupla deny SÍ está; lo que falta es la membresía. El listón del lote (y la propiedad L10) es
el efecto («ningún estado intermedio concede»), no la letra.

**Steelman del defensor:** «el destino de una pasada nunca es el driver activo (STALE guard), así que el estado
intermedio no lo sirve nadie; una pasada cortada sale exit 1 y se repite».
- ¿Me convence? No del todo.
- (a) El límite R5 está declarado: el «activo» es el del config del PROCESO que corre la pasada, así que una pasada lanzada
  desde un proceso con otro `default` escribe en el store que sirve la flota.
- (b) `--allow-stale-source` es una salida documentada.
- (c) La propiedad publicada y su fila de guardia afirman algo que no se cumple, y eso es un linaje L10 (4.ª iteración)
  «cerrado estructuralmente» con un agujero.
- Lo bajo de 🔴 a 🟠 por (a)/(b): hacen falta corte + servicio del destino.

**Qué exige el cierre**
- En la fase 2, primero las membresías (`group#member`, y su cierre transitivo por grupos anidados) cuyo grupo sea SUJETO
  de algún deny del plan o del destino. Después, el resto de membresías. Al final, los demás allows.
- Fila nueva en la propiedad con el origen sembrado en orden inverso, y otra con origen `database` real.
- Mutante «membresías en orden de enumeración» que muera.
- Corregir la letra en README/CHANGELOG: «ningún estado intermedio concede», no «nunca un allow sin su deny».

### 🟠 2 · Retirar el opt-in / volver a < 2.5: el cero se comprueba en un instante con la flota todavía en `'write'`

**Escenario.** README §Upgrading, procedimiento de rollback (líneas ~1947-1955):
1. `removeDeny` + `--prune` hasta que la consulta dé 0.
2. `openfga:provision --allow-drop-deny`, que barre y re-comprueba el cero.
3. Rollback / redeploy.

Entre 1-2 y el final del despliegue, los pods siguen con `deny: 'write'` y un tenant puede hacer `deny()`:
- En `openfga`, los pods ya redesplegados sin opt-in y con el `modelId` nuevo (sin `denied_*`) ignoran ese deny.
- En `database`, los pods de alpha.10 ignoran toda fila `denied_*` (✅ leído: `git show v2.4.0-alpha.10:…database_relations_driver.ts:585-608`,
  `relation IN (down*)`).
- **El deny escrito en la ventana deja de negar en silencio, y para siempre.**

El TOCTOU del barrido (`commands/openfga_provision.ts:214` → `:153`) es la versión de milisegundos del mismo hueco. El
grande es el del despliegue.

**Evidencia**
- ✅ README §Upgrading: el procedimiento no tiene ningún paso «primero toda la flota a `deny: 'read'`» (en `'read'`,
  `deny()` es 422 en los dos drivers; paso 20b del runbook) ni un freeze que cubra cuenta → publicación → despliegue.
- ✅ Paso 21 del runbook (`tests/cutover_runbook.spec.ts`, bloque `step(21…)`): mantiene vivo el proceso `fase2` (config
  `'write'`) durante todo el procedimiento y nunca afirma qué pasa con un deny escrito después del cero. Afirma letra/exit
  y «store intacto», pero no el efecto tras publicar.
- 🟡 Depende del despliegue del consumidor.

**Steelman:** «es una operación de mantenimiento; el operador congela».
- ¿Me convence? No. El README describe el procedimiento paso a paso y no menciona ni la fase `'read'` ni `authz:freeze`.
  Un operador que lo sigue al pie de la letra abre la ventana.

**Qué exige el cierre**
- Paso 0 escrito: desplegar TODA la flota en `deny: 'read'` antes de contar (o mantener `authz:freeze` de cuenta a
  despliegue).
- El paso 21 del runbook lo ejecuta y afirma el EFECTO: un `deny()` intentado tras el cero es 422, y tras publicar,
  `check` sigue siendo coherente.
- Opcional: `--allow-drop-deny` imprime el aviso «la flota tiene que estar en 'read' o congelada».

### 🟡 3 · La guarda de `provision` compara con el ÚLTIMO modelo del store, no con el estado del store

**Escenario**
- Un ensayo de rollback ejecuta `openfga:provision --store-id` con el binario alpha.10. Es exactamente R2-3 (iii) del
  panel. Eso publica M_old sin `denied_*`; los pods siguen fijados al modelo bueno.
- Más tarde, con 2.5, alguien publica desde una config sin el opt-in.
- Resultado: `droppedDenyRelations(M_old, next) = []` ⇒ publica «success», y al fijar ese modelo los denies vivos dejan de
  negar.

**Evidencia:** ✅ `commands/openfga_provision.ts:191` (`readLatestAuthorizationModel`) y `:200`. La mitigación del panel
R2-4 era por ESTADO: «un tipo sin opt-in y tuplas `denied_*` vivas de ese tipo ⇒ 500 que las nombra». Lo implementado es
un diff de modelos contra el último. Es el gemelo de R2-10 (verificador contra el último modelo frente al fijado).

**Steelman:** «barrer el store en cada provision es O(store)». ¿Me convence? Para el coste, sí. Pero hay una alternativa
barata: comparar contra TODOS los modelos del store (`readAuthorizationModels`, unos pocos) o contra el `modelId` fijado
del config. Si alguno declaró `T#denied_R` y el nuevo no, se exige el barrido.

**Qué exige el cierre:** comparar contra la unión de los modelos del store (o el pin), más un caso con un modelo
intermedio sin `denied_*`.

### 🟡 4 · `denyUpdate` hacia `openfga` no rehace nada: 409 ⇒ 503 «transitorio» para siempre, y el deny caduca

**Escenario**
- El destino `openfga` tiene un deny con caducidad (solo es posible a mano: el modelo admite `denied_<rel>` `with
  not_expired`, `openfga_facts.ts:1028/1058`).
- El origen tiene el mismo deny permanente.
- Lo que promete la tabla §3.1 del informe y el CHANGELOG: «`to.deny` lo rehace permanente».

**Evidencia** (✅ medido contra `:8090`, store efímero): escribir la tupla sin condición y con `on_duplicate: ignore`
sobre la misma clave con condición da `HTTP 409 Aborted … already exists with a different condition` (es la M5 del panel).
`#guard` (`openfga_relations_driver.ts:446-454`) lo convierte en 503 `E_AUTHZ_BACKEND_UNAVAILABLE`. En consecuencia:
- La fase 1 revienta en ese deny, y toda pasada repetida revienta igual. Los allows de la partición no se migran nunca.
- El deny con caducidad sigue ahí y, al vencer, el destino concede lo que el origen niega.
- El caso del implementador corre solo sobre dobles. `database` sí funciona (delete + insert en una trx).

**Steelman:** «un deny con caducidad solo existe escrito a mano». ¿Me convence? Para la severidad, sí (🟡). Para la letra,
no: CHANGELOG y tabla afirman un efecto que en `openfga` no ocurre.

**Qué exige el cierre:** en `openfga`, `denyUpdate` debe ser una negativa del PLAN con motivo propio y receta (borrar a
mano y repetir), no un 503 a mitad de la fase 1. Fila de la tabla de verdad por driver, con caso contra `:8090`.

### 🟡 5 · El paso 20 del runbook solo siembra UN deny directo; el panel exigía «directos, vía grupo y temporales»

**Evidencia:** ✅ `panel-tenencia-2-auditor.md:236`, fila «¿Cambia el runbook?»: «siembra denies directos, vía grupo y
temporales, y comprueba `check = false` después del cambio. Si no, "runbook verde" no certifica nada del deny». El paso
20c siembra solo `users:holder(0)` en `docA1`.

**Efecto:** el 🟠1 habría salido con drivers reales.

**Cierre:** sembrar en el paso 20 un deny por grupo con la membresía creada DESPUÉS del allow, y afirmar `check` en
`openfga` tras la migración (el efecto, no la letra).

### 🟡 6 · Decisión 3 (`undeclared` niega aunque en el origen sea inerte): la receta impresa no funciona por la API

**Escenario**
- Una relación `approver` se retira de la config con denies vivos en `database`. Allí son inertes: `down*` ya no la
  alcanza.
- Toda pasada hacia cualquier destino se niega con `undeclared`.
- La receta de la letra (`reconcile.ts:723-729` y la línea `deny NO migrable` del comando) dice «pon el tipo en deny:
  'write' en el DESTINO … o retira esos denies del origen».
- `removeDeny(…, 'approver', …)` en el origen es 422 por F-05 (`database_relations_driver.ts:533`).

**Resultado:** la migración queda imposible sin salida escrita. Las salidas reales son re-declarar la relación →
`removeDeny` → retirarla, o SQL a mano. `--prune-undeclared` es del lote C. La misma receta genérica sale para `invalid`
y `unmarked`, donde tampoco aplica.

**Steelman:** «la salida existe: re-declarar». ¿Me convence? Existe, pero no está escrita, y la letra manda a una que
falla.

**Cierre:** una receta por motivo en la línea y en el README. Para `undeclared`: re-declarar + `removeDeny`, o la consulta
SQL por motor.

### ⚪ 7 · Guardia L9: la «reflexión» es por NOMBRE sobre una lista de ficheros a mano, no sobre el grafo de imports

**Repro** (✅ ejecutado en `scratchpad/audD2/l9/`). Añadí `RelationAuditProbeError` (422) a `src/errors.ts`:
- Nombrada en `database_relations_driver.ts` ⇒ **ROJO con su nombre** («SIN clasificar … RelationAuditProbeError
  (E_AUTHZ_AUDIT_PROBE)»). Resiste.
- Nombrada solo en `src/shared/backend_guard.ts`, que importan los dos drivers de relaciones (`withDeadline`, `guardSql`,
  `isServerWriteLimit`) ⇒ **9/9 verdes**.

Hoy ningún 422 de `src/shared/*` llega a relaciones, así que no es explotable (por eso ⚪). Las clases 422 SÍ se recorren
por reflexión sobre `src/errors.ts`, y `RELATION_422_REASONS` se deriva de verdad (`reconcile.ts:1139-1143`).

**Cierre:** recorrer los ficheros alcanzables por import desde los dos drivers, o añadir `src/shared/` a la lista.

### ⚪ 8 · Un deny del DESTINO sin `kind` se planifica como allow y se poda con `unrelate(denied_*)`

**Repro** (✅ `zz_aud_a3.spec.ts`, `--dry-run --prune`): con un destino de terceros que enumera `denied_viewer` sin
`kind`, el plan dice «borradas 1». En la pasada real pediría `unrelate('denied_viewer')`. D-04 dice que `unrelate` nunca
toca `denied_*`; con F-05 en el driver, es un 422 clasificado como `undeclared` (motivo equivocado).

Es asimétrico con el origen, que se niega con `unmarked`. Para conceder hace falta un tercero que viole F-05, y eso lo
juzga el runner.

**Cierre:** `unmarked` también del lado del destino (negativa o residuo con motivo propio, nunca `allowDelete`).

### ⚪ 9 · `denyPhase` no está en `runRelationsDriverContract`

Un tercero puede pasar el contrato del driver y mentir en `denyPhase`. Lo medí leyendo: en el peor caso, `'write'` donde
`deny()` da 422 ⇒ la fase 1 aborta tras escribir denies (fallo cerrado y ruidoso), o `null` donde sí admite ⇒ negativa.
No encontré un camino a conceder con `denyPhase` mintiendo y `check` honrando (lo juzga D1).

**Cara propuesta** (con `relationDenies: true`): por cada tipo de la config del harness,
- `denyPhase` = la fase de la config;
- `'write'` ⇒ `deny()` entra y `check` = false;
- `'read'` ⇒ `deny()` 422 `NOT_DENYABLE` y un deny sembrado a mano niega;
- `null` ⇒ `deny()` 422;
- más las tres variantes F-05.

### ⚪ 10 · Letra y punto 7 en las ramas de error

- **(a)** `report.partial = true` también con 0 escrituras (`reconcile.ts:532`): el comando imprime `pasada PARCIAL:
  escritas 0 …` cuando la marca `markPartialWrite` dice lo contrario.
- **(b)** Las líneas `pasada PARCIAL` no dicen en qué ventana del freeze corrió la pasada (el reporte de éxito sí).
- **(c)** Si el barrido de `--allow-drop-deny` falla a medias (`liveDeniesOf`, `openfga_provision.ts:326`), el error del
  SDK sale crudo, sin el prefijo `provision NEGADO:`. Es fallo cerrado (no publica), pero la rama no se identifica.

### ⚪ 11 · Un destino `database` sin opt-in con el deny ya presente se niega (`phase`), aunque D8 lo honra

`reconcile.ts:707`: `phase === null` ⇒ negativa para `denyPresent`. `database` honra `denied_*` siempre. Es fallo cerrado
y ruidoso (la vuelta openfga → database tras retirar el opt-in no verifica). Basta con declararlo.

### ⚪ 12 · Decisión 5: el CHANGELOG llama «additive» a `report.denies`, pero los totales cambian de significado

Antes de D2, un deny del origen era `skipped.undeclared`; ahora suma a `written`, `unchanged` y `extra`. No encontré que
COGNITIV lea esos contadores como «allows» (grep en sus informes: no). Aun así, el CHANGELOG debe decir que `written`,
`unchanged` y `extra` ahora incluyen denies.

---

## Las 14 decisiones de §4

| # | Decisión | Veredicto |
|---|---|---|
| 1 | `denyPhase` como método opcional del puerto | **Condicionar**: con la cara del runner del driver (⚪9). Es método, no clave de capabilities; D15 no aplica. |
| 2 | `'write'` para escribir, cualquier opt-in para conservar | **Ratificar**. Declarar ⚪11 (D8 en `database`). |
| 3 | `undeclared` niega aunque sea inerte en el origen | **Condicionar**: receta por motivo que funcione (🟡6). |
| 4 | `unmarked` ⇒ negativa | **Condicionar**: simétrica en el destino (⚪8). |
| 5 | Totales con denies, `report.denies` como subconjunto | **Ratificar** con la letra del CHANGELOG corregida (⚪12). |
| 6 | Fases por partición | **Ratificar**: medido que la membresía es de la MISMA partición (`partition_key = ?` en el CTE de grupos). Pero el orden DENTRO de la fase 2 es 🟠1. |
| 7 | El parcial no cambia clase ni `code` | **Ratificar**. ⚪10a. |
| 8 | Guarda de `provision`: `--store-id`, tipos de relación, por nombre, contra el último modelo | **Rechazar en la parte «contra el último modelo»** (🟡3). Lo demás, ratificar. |
| 9 | Gemelo N3 en `guardBackendErrors` | **Ratificar**. Medido contra `:8090`: el 400 de `batch-check` > 50 es `validation_error`, no `exceeded_entity_limit`; ninguna lectura cae en el 500. |
| 10 | `RELATION_REJECTIONS` privado; el escaneo incluye `identity.ts` | **Ratificar** con ⚪7. |
| 11 | `substr(relation,1,7)` | **Ratificar**: ejecutada en los 4 modos contra el bloque del README. |
| 12 | Pasos 20/21 con `default: 'database'` | **Ratificar**. Condición aparte: 🟡5 y el paso 0 de 🟠2. |
| 13 | `DenyMigrationRefusedError` exportado | **Ratificar**. |
| 14 | `relateOrSkip` por `code` | **Ratificar**: `status` + `Object.hasOwn`, no se absorbe un `code` heredado. |

---

## Lo que intenté y NO se rompió

- **Puerta S6 con cero escrituras**: deny de origen con sujeto comodín `*` (origen de terceros) ⇒ negativa `invalid` en el
  plan. La real es 500 sin escribir nada; el dry-run da `denyRefused` y exit ≠ 0 (✅ `zz_aud_a2.spec.ts`).
- **`removeDeny` sin opt-in**: no exige fase (`database_relations_driver.ts:532-538`), así que la fase 4 no aborta por
  eso.
- **Fases cruzadas entre particiones**: no hay deny transportado desde otra partición (el CTE de membresía filtra
  `partition_key`).
- **Poda cuando el origen QUITÓ un deny y el allow sigue**: el estado final concede igual que el origen y ningún
  intermedio concede de más.
- **Gemelo N3**: solo `exceeded_entity_limit` (escrituras). `batch-check` da `validation_error` (medido).
- **R-1 de `command_flags_r` y ⚪11 de `guard_surface`**: las dos justificaciones son verdaderas. R-1 sigue cazando la
  bandera inerte (iría a `POST /stores`). La excepción de ⚪11 nombra una sola operación sin partición.
- **Debilitamientos**: `EXPECTED_FUSED` sin tocar (0 líneas en el diff); `migration_stub.spec` y `freeze.spec` sin diff;
  CHANGELOG con un solo hunk en `[Unreleased]`; el `pending` de `--allow-drop-deny` se retiró y ahora se juzga.
- **Fila S17**: alpha.10 ignora `denied_*` en `database` (leído en el tag); la fila declarada dice la verdad. Para
  `database`, la consulta del README es la barrera y está ejecutada en los 4 modos. Para `openfga`, la barrera es el
  barrido global de `--allow-drop-deny`: la cuenta del README por `--dry-run` es por partición.
- **S11 / D-31**: paso 20d con efecto (pin viejo concede, pin nuevo niega, config nueva + pin viejo ⇒ 500).

## Preguntas abiertas para el arquitecto

1. 🟠1: ¿membresías de grupos denegados primero (orden del plan) o el destino congelado de lecturas durante la pasada?
   Solo la primera hace verdadera la propiedad publicada.
2. 🟠2: ¿el paso 0 «flota en `'read'`» es requisito del procedimiento (y del runbook), o se exige `authz:freeze` vivo para
   `--allow-drop-deny`?
