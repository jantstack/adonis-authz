# Propuesta: jerarquía de scopes como hechos del contrato (`hierarchy: 'resolver' | 'facts'`)

> 28-08-2026 · Propuesta surgida en conversación con el dueño del paquete. **No está decidida**: este documento es la entrada al panel para verificar si es posible y a qué precio.

## Lo que el dueño quiere (requisitos, en sus palabras)

1. "Que en el caso de que se quiera usar OpenFGA **al 100 % de sus capacidades** se pueda" — es decir, `authorize` = un solo `Check` nativo, sin SQL en el camino caliente, con FGA recorriendo roles → permisos → jerarquía → deny.
2. "Que **también se pueda usar el driver db**" — el driver `database` sigue existiendo, intacto, autosuficiente.
3. "Que la **migración de uno a otro sea posible**" — en ambas direcciones.
4. (De la conversación previa, ya decidido) Habrá más consumidores reales; hoy no hay ninguno ⇒ romper es gratis; Fases 0+1 salen como 2.0.0.
5. Filosofía intacta: usable en cualquier proyecto, maleable, sin acoplarse a ningún sistema ni vocabulario de dominio. Cambiar de driver no puede obligar a reescribir call-sites.

## Diagnóstico que motiva la propuesta

Hoy el árbol de scopes es **el único hecho de autorización que no pasa por el paquete**: grants, denies y catálogo entran por el manager (por eso se pueden migrar); el árbol lo lee cada driver por su cuenta vía `resolveAncestors` (`database_driver.ts:50-56`, `openfga_driver.ts:361-363`). Por eso FGA no puede evaluar solo: no conoce `parent`. Si el árbol también entra por el manager como hecho, FGA puede hacerlo todo.

## Diseño propuesto

### Config (compartido por todos los drivers)

```ts
export default defineConfig({
  default: env.get('AUTHZ_DRIVER', 'database'),
  holderTypes: { users: 'user', admins: 'admin', integrations: 'integration' },
  scopes: {
    resolveAncestors,   // lectura fresca desde la BD del consumidor (hoy existe, por driver; sube al config)
    enumerateEdges,     // ⭐ AsyncIterable<{ child: ScopeRef; parent: ScopeRef }> — bootstrap y reconcile. OBLIGATORIO en modo facts
  },
  drivers: {
    database: () => new DatabaseAuthorizationDriver(),
    openfga: () => new OpenFgaAuthorizationDriver({ apiUrl, storeId, modelId, hierarchy: 'facts' }), // default 'resolver'
  },
})
```

### API nueva en el manager — igual para todos los drivers

```ts
await authorization.scopes.attached(child, parent)   // al crear un nodo
await authorization.scopes.moved(child, newParent)   // al mover
await authorization.scopes.detached(child)           // al borrar: purgeScope (grants+denies) + arista
```

Puerto del driver: `purgeScope(scope)` **obligatorio** (hoy no existe: N5); `onScopeAttached?/onScopeMoved?/onScopeDetached?` **opcionales** (database no los implementa ⇒ no-op en el manager).

Recomendación al consumidor: llamar a `scopes.*` **siempre**, aunque esté en `database` (le da `purgeScope` y le deja listo para cambiar de driver sin tocar código).

### Comportamiento por driver/modo

| Driver / modo | `authorize` | `scopes.*` | Necesita del consumidor |
|---|---|---|---|
| `database` | join SQL sobre `resolveAncestors` (como hoy) | `detached` → `purgeScope`; resto no-op | `resolveAncestors` |
| `openfga` `'resolver'` (default) | batchCheck sobre `resolveAncestors` (hoy + memo de catálogo + batch único) | igual que database | `resolveAncestors` |
| `openfga` `'facts'` | **un solo `Check`** sobre `scope:<key>` con relación `can_<permiso>` | escribe/borra tuplas `scope:child#parent@scope:parent`; fail-loud (lanza si FGA falla) | `resolveAncestors` (solo escrituras + verify) y `enumerateEdges` |

En modo `facts`, `grant`/`deny` **siguen llamando a `resolveAncestors`** para validar existencia del scope (FGA acepta tuplas sobre ids inexistentes).

### Modelo FGA generado en modo facts (borrador — el panel debe fijarlo contra el servidor)

```
type user / admin / integration
type role                                   # id = roleUuid
  define assignee: [user, admin, integration, user with not_expired, ...]
type scope                                  # id = 'app' | 'organization|<uuid>' | 'unit|<uuid>'
  define parent: [scope]
  # por cada permiso P del catálogo (regenerado en syncAuthzCatalog; FGA versiona modelos):
  define P: (assignee from P_role) or P from parent          # herencia solo hacia abajo
  define P_role: [role]                                       # catálogo: qué roles conceden P en este scope ← DUDA: ¿tupla por scope? ¿wildcard scope:*? ¿role como tipo con relaciones computadas?
  define denied_P: [user, admin, integration] or denied_P from parent
  define can_P: P but not denied_P                            # deny gana y hereda
```

**Incógnita central**: cómo expresar "el rol R concede P" (catálogo global) sin escribir una tupla por scope. Opciones: (a) tuplas con wildcard de objeto (`scope:*`) — ¿soportado en el lado objeto?; (b) `role` como tipo con relación por permiso (`role:<uuid>#grants_P@role:<uuid>` autorreferencial + tuple-to-userset); (c) bindings `role_binding:<scopeKey>|<roleUuid>` como hoy + `scope#has_binding` + TTU dos niveles. Con roles por tenant (`catalog/`), el catálogo cambia en runtime sin redeploy de modelo ⇒ (a)/(b)/(c) tienen que funcionar con **tuplas**, no con modelo.

Codificación de slugs: `docs:write` → `docs_write` (FGA no admite `:` en relaciones) ⇒ colisión posible `docs:write` vs `docs_write` ⇒ el sync debe rechazarla.

### Migración

- **DB → FGA facts**: `openfga:provision --hierarchy=facts` + `openfga:import` (hechos + ⭐ catálogo + ⭐ aristas desde `enumerateEdges`), con dry-run y conteos. Exige ventana (sin dual-write).
- **FGA → DB**: `authz:export --from=openfga --to=database` vía `Read` paginado → `authz_assignments`/`authz_denies`. El árbol no se migra (database lo lee de las tablas del consumidor).
- **resolver ↔ facts**: solo aristas.
- **Garantía ejecutable**: caso de contrato de migración — sembrar N hechos en A, migrar, mismas respuestas en B para un set fijo de preguntas. Tres combinaciones en CI.
- **Red de seguridad**: `authz:scopes:verify` — `enumerateEdges` vs tuplas `parent`; exit ≠ 0 con las aristas que difieren.

## Problemas reconocidos (lo que el consumidor tiene que aceptar en modo facts)

1. **Árbol en dos sitios sin transacción común.** `scopes.*` dentro de la trx del consumidor y antes del commit; fallo ⇒ lanza ⇒ rollback del consumidor. Cambios del árbol fuera del servicio (UPDATE a mano, seeders, fixtures) ⇒ drift ⇒ denies de la org nueva no aplican / grants de la vieja siguen. `verify` como red.
2. **Backup/restore descoordinado** entre Postgres y el store FGA ⇒ hechos de una hora, catálogo/árbol de otra. Con `database` no existe.
3. **Borrado en cascada** de subárboles: N purgas en chunks sin transacción; puede quedarse a medias; el paquete lanza; `verify` detecta.
4. **Un `move` cambia permisos del subárbol al instante** (también en resolver, pero más visible).
5. **Permisos como relaciones del modelo** ⇒ añadir un permiso = publicar modelo nuevo + apuntar al id (o "latest"); catálogos distintos por entorno ⇒ modelos distintos.
6. **Existencia del scope**: FGA no la conoce ⇒ `resolveAncestors` sigue en escrituras.
7. **Consistencia eventual** de FGA (`HIGHER_CONSISTENCY` o aceptar ms de retraso). `ListObjects` sigue truncando a 1000 / 3 s.
8. **Infra**: T0b prerrequisito; CI del consumidor necesita FGA.
9. **Migración con ventana**; FGA → DB pierde lo que solo FGA expresa (usersets con condición en `relations/`).

## Preguntas al panel

- **P1** ¿Es expresable en FGA (versión del `:8101`) el modelo completo con catálogo por tuplas (no por modelo), herencia solo hacia abajo, deny-wins heredado, caducidad por condición, y roles por tenant? **Construirlo y probarlo**, no razonarlo.
- **P2** ¿La suite `runAuthorizationDriverContract` actual (y la 2.0 con `capabilities`) puede correr contra el modo `facts` sin bifurcar? ¿Qué casos negativos/anexos necesita?
- **P3** ¿La migración en ambas direcciones es realmente sin pérdida para `roles/`? ¿Y para `relations/` después?
- **P4** ¿La API `scopes.*` + `enumerateEdges` respeta la filosofía (sin vocabulario de dominio, sin obligar al consumidor mono-tenant, sin reescritura al cambiar de driver)? ¿Debe ser opcional llamar a `scopes.*` en `database`?
- **P5** ¿Hay una forma de cerrar el drift (problema 1) mejor que `verify`? ¿Outbox en la BD del consumidor? ¿Vale la pena que el paquete la provea?
- **P6** ¿Qué NO se puede hacer aunque queramos? (Lo que FGA no expresa, lo que rompe el juez único, lo que obliga a reescribir call-sites.)
- **P7** Coste real y en qué fase entra (la estimación de conversación fue ~5 d: spike 0,5 + scopes/purgeScope 1 + modo facts 2 + import/export/verify 1 + contrato de migración 0,5).
