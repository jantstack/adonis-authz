# Repaso corto del auditor — cierre 4 de D2 (2026-10-16)

Mismas reglas que los repasos anteriores (solo lectura; reproducciones en `.claude/reproducciones/`; SQLite `:memory:` y stores efímeros en `:8090`, borrarlos; sin docker restart ni gates).

Lee: `loteD2-cierre4-coordinador.md` (brief con el PRINCIPIO RECTOR: el destino igual o más restrictivo que el origen en todo instante futuro), `loteD2-informe-cierre4.md`, tu `loteD2-auditor-cierre3.md`.

Coordinador verificó: 2046/2074/2171/2173, guardia 181/181, banderas 37/37, runbook ×2 (sin timeouts).

Comprueba:
1. C3-1…C3-4 cerrados en efecto (re-ejecuta `loteD2-auditor-cierre3.ts` y los scripts de cierre 2).
2. `relationWithheldWrites` y la retención en cascada: ¿algún camino donde el destino conceda en algún t ≥ now lo que el origen niega en t sin residuo declarado? Busca fuera del universo de la fuerza bruta (varias relaciones, varios niveles, retención que deja una membresía sin escribir que era la que cortaba OTRO allow, `--prune` sí/no, dirección openfga→database).
3. `carrier-conflict` (negativa con cero escrituras): ¿realmente cero escrituras? ¿Puede un atacante con escritura en el origen forzarlo para bloquear un cutover (DoS) — severidad?
4. Orden con renovaciones en el grafo y `RelationTransition.shortening`: regresiones en la propiedad de prefijos.
5. Tres mutantes mueren solo por cifras fijadas (`c41.order.without-ignored`, `c4h.order.renewals-not-changing`, `c41.plan.withhold-off`): ¿hay una propiedad semántica que debería matarlos? Si es así, dila.
6. `E_AUTHZ_RENEWAL_RACED` vs `E_AUTHZ_RENEWAL_UNSAFE` y la marca parcial de `purgeScope` de roles.

Salida: `.claude/contexto/loteD2-auditor-cierre4.md`, veredicto APTA / NO APTA y hallazgos 🔴🟠🟡⚪ con reproducción.
