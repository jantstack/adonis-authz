# Fase 4 · `relations/` — VEREDICTO DEL JUEZ y PLAN DEFINITIVO

> Base: `main` @ `76c5846` (Fase 3b mergeada, `2.3.0-alpha`). Insumos: `fase-4-plan.md` (analista),
> `fase-4-auditor.md` (atacante, 🔴 reproducido contra `:8101`), `fase-4-tester.md` (verificador).
> Este documento **decide**: cierra el 🔴 en el diseño, resuelve las contradicciones con evidencia,
> toma las decisiones de mecanismo que el plan no tomó, puntúa el plan del analista y entrega el plan
> por lotes con criterios de aceptación. No re-litiga ninguna decisión firmada del dueño.
> Verificado en código por el juez: el mecanismo del 🔴 (`openfga_facts.ts:352`, `assignee` acepta la
> tupla PLANA) y el hueco de mecanismo del harness (`contract.ts:203`/`:219`, unión cerrada, sin
> `makeRelationsDriver`). Los dos hallazgos que deciden la fase son CIERTOS.

---

## Veredicto

**Recomendación:** el plan del analista es **APTO CON CAMBIOS BLOQUEANTES** (puntuación **55/100**). La
medición del desconocido (tamaño, profundidad, un Check/un store, DDL del trigger en tres motores) es de
primera y **se acepta entera**; pero el plan **embarcó un 🔴 explotable** (§5 sobrevende `check_purity` y da
la frontera de ESCRITURA por hecha) y **dejó sin decidir el mecanismo por el que el juez ejecuta un
`RelationsDriver`**. Ambos se cierran sin rediseñar el fondo.

**Con estos injertos de otras opciones (todos bloqueantes):**
- **F-05** del auditor (whitelist de `object.type`+`relation` en `relate`/`unrelate`) — **al puerto y al
  contrato**, no a un solo caso.
- **⚪4** del auditor (`defineRelationsConfig` rechaza los tipos reservados de `facts`) — es la pieza que,
  junto con F-05, cierra el 🔴 **estructuralmente en el store compartido** (un `role_binding` no se puede
  declarar ⇒ su id no se puede componer ⇒ la colisión desaparece por construcción, no por vigilancia).
- **⚪5 / 🟡2 / 🟡3** del auditor (parseo canónico de partición; barrido de ambas ortografías del uuid en
  `purge*`; config de relaciones persistida bajo el gate de versión).
- **Del tester:** `runRelationsDriverContract` como runner SEPARADO; `membersOf` como método del puerto
  distinto de `listSubjects`; anclar F-01/F-02 en `openfga` con mutante de conflación; caso de carrera
  `defineRelationsConfig`↔`syncAuthzCatalog`; gate del modelo FUSIONADO con dos caras; conteo del juez
  aterrizado en un `relations_harness.spec.ts` propio.

**Condición para proceder:** el 🔴 queda cerrado **en el diseño** con F-05 + ⚪4 (ver §1); el diseño es
seguro **en el store compartido** y **el 🔴 NO obliga a separar el store** (ver §2, dictamen con números).
La única condición dura: el caso-exploit del auditor (`relate(evil, assignee, {role_binding}, S)` ⇒ 422 y
`check(evil, can_<P>, S)` sigue `false`) tiene que quedar **VERDE en `openfga`** (lote 4-4); si no se
lograra, y solo entonces, se reabre la separación de store.

---

## Tabla de puntuación — el plan del analista contra criterios declarados

Criterios fijados **antes** de puntuar (no los de una comparación A/B: aquí se evalúa la CALIDAD de un
único plan). 0–10 por criterio; total ponderado.

| Criterio (peso) | Nota | Puntos | Por qué |
|---|---|---|---|
| **Seguridad del diseño (30)** | 4/10 | 12,0 | Embarcó un **🔴 explotable reproducido**: en mono-tenant (`app`) `relate` escribe `role_binding#assignee` plano y `roles.authorize`⇒`true`. §5 declara la frontera «garantizada por construcción» cuando `check_purity` solo aísla el BUNDLE (verificado). Recuperable: F-05+⚪4 lo cierran sin restructurar, y el plan sí acertó en desmontar el boceto de la regla de pureza. |
| **Verificabilidad (20)** | 5/10 | 10,0 | Buen instinto de contrato, pero **hueco de mecanismo**: puerto separado sin `makeRelationsDriver`, `ContractLevel` cerrado; `membersOf` sin método; R-10 usa una cara de truncado hoy VACÍA; **cero casos de carrera**; conteo «estima 34» sin aserción. |
| **Coste medido (15)** | 9/10 | 13,5 | La fortaleza. Todo contra `:8101`/pg18/mysql84 con delta 0: presupuesto de bytes, profundidad 22 sobre el FUSIONADO, DDL divergente del trigger en tres motores, single-store/single-Check. Rigor de 3b. |
| **Honestidad de lo que promete (15)** | 5/10 | 7,5 | Marca bien ✅/❓ y admite el trade-off del store; pero **documenta el 56 % (19/34)** de los casos que cuenta, el split 18/12/4 no cuadra con lo enumerado, y el «34» es aspiracional. Sobreventa en §5 (frontera «por hecho»). |
| **Mantenimiento del contrato para terceros (20)** | 6/10 | 12,0 | Puerto nuevo + runner + 4 capacidades es superficie real. El patrón (capacidad con caso, `whenFalse` nunca skip) es el correcto de 3b, pero no aterriza el mecanismo que un tercero consume, y el 🔴 significa que un driver de relaciones de terceros que no implemente F-05 **publica la escalada**: el runner tiene que fallarle. |
| **Total** | | **55,0/100** | Medir de lujo; embarcó un 🔴 y no especificó cómo se le juzga. Apto con cambios bloqueantes. |

---

## 1 · El 🔴 cerrado EN EL DISEÑO (no en un caso)

El plan tenía la frontera roles↔relations como «garantizada por construcción + `check_purity`». **Falso en
la dirección de ESCRITURA**, y medido: la composición `<type>:<scopeKey(partition)>|<id>` reproduce byte a
byte el id de un `role_binding` real, y `assignee` acepta la tupla plana (`openfga_facts.ts:352`,
verificado por el juez). El invariante que faltaba entra **en el puerto y en el contrato**, no en un caso
suelto:

### Invariante nuevo (al puerto `RelationsDriver` y a `CLAUDE.md`)

> **Frontera de escritura de relaciones.** `relate`/`unrelate` solo aceptan un `object.type` **declarado en
> `defineRelationsConfig`** y una `relation` **declarada para ese tipo**; todo lo demás es **422 ANTES de
> tocar el store** (`E_AUTHZ_RELATION_TYPE_UNKNOWN` / `E_AUTHZ_RELATION_UNKNOWN`). Y `defineRelationsConfig`
> **rechaza (422)** todo `objectType`/relación que colisione con un tipo o familia reservados de `facts`
> (`scope`, `role`, `role_binding`, `group`, holder types; `RESERVED_SLUGS`/`RESERVED_SLUG_PREFIXES`). Las
> dos reglas rigen en **ambos drivers** (paridad). La gramática (R-12) y la partición-por-string **no
> bastan**: en el store compartido los tipos de `facts` viven en el MISMO espacio de ids.

### F-05 (redacción de contrato, ambos drivers, bloqueante)

Se adopta **literal** la redacción del auditor para el caso, con dos observaciones del juez:
- El **422 en `relate`** vive en el runner de relaciones (`runRelationsDriverContract`, ambos drivers).
- La **prueba completa de la escalada** (`relate` bloqueado ⇒ `roles.authorize` sigue `false` con el binding
  legítimo intacto) es un caso PUENTE que construye a la vez un `AuthorizationDriver` y un `RelationsDriver`
  sobre el mismo backend, y en `openfga` sobre el MISMO store. Se planta el exploit exacto del auditor y se
  ve `check(evil, can_<P>, S) = false`.

### ¿El diseño es seguro con esto, o el 🔴 obliga a más de fondo?

**Es seguro con esto, en el store compartido, y el 🔴 NO obliga a separar el store.** La clave estructural:
con ⚪4, `role_binding` (y `scope`/`role`) **no se puede declarar** como tipo de relaciones; con F-05,
`relate` **no puede** dirigirse a un tipo no declarado. Por tanto el id `role_binding:...` **nunca lo
compone el driver de relaciones**: la colisión no se vigila, **deja de existir**. Sumado a que los
componentes no admiten `|`/`#`/`:` (`assertComponent`, ya verificado por el auditor en «lo que no se rompió»)
y a ⚪5 (parseo canónico de partición = todo menos el último segmento), el namespace de ids de relaciones
queda **demostrablemente disjunto** del de `facts`. Eso es cierre por construcción, no por check.

Residuo aceptado y mitigado: F-05 es un chokepoint; si un camino de escritura futuro (relate en lote,
escritura de reconcile de relaciones) lo salta, reabre la escalada. Mitigación: **una sola validación por la
que embudan TODOS los caminos de escritura**, y el caso-exploit publicado en el runner ⇒ un driver de
terceros que no lo satisface **no pasa el contrato**.

---

## 2 · Contradicciones entre panelistas, resueltas con evidencia

- **Analista «store COMPARTIDO» vs Auditor «los ids colisionan en el store compartido» → gana el store
  COMPARTIDO, con guardas.** El 🔴 es real, pero su causa raíz (colisión de id-space) la cierra ⚪4+F-05 por
  construcción (arriba). Pesado con los números del analista: separar el store cuesta **un segundo `modelId`
  y un segundo store a coordinar en freeze/backup/reconcile** — la coordinación que en 3b produjo **tres de
  cuatro regresiones de fase «por composición de piezas correctas»** — a cambio de una **defensa en
  profundidad** que el par ⚪4+F-05 ya da estructuralmente. El margen medido (447 permisos ⇒ 6.247 B ≈ 23
  tipos de objeto) dice que la colisión de TECHO es un caso extremo. **Dictamen: compartido**, con el escape
  documentado (§0.4 del plan) reservado al caso «>20 tipos Y pegado al techo de permisos». El 🔴 **no**
  decide esta pregunta.

- **Analista «F-01…F-04 fijan la frontera» vs Tester «F-01/F-02 son decorativos en `database`» → gana el
  tester.** En `database`, `authz_assignments` y `authz_relations` son tablas disjuntas: F-01/F-02 pasan en
  verde **sin implementar frontera**. Solo tienen dientes en `openfga` (modelo/store único). **Resolución:**
  F-01/F-02 se **anclan** con un mutante de conflación (p.ej. el generador emitiendo la relación de objeto
  también como `can_<P>`, o `factsRelationMap` incluyendo un tipo de objeto) y se ven **ROJOS**, como el par
  [22,23] de 3b; si no se puede plantar el mutante, se degradan a documentación. F-03/F-04 sí tienen dientes.

- **Analista «membersOf como capacidad» vs Tester «capacidad sin método = skip disfrazado» → gana el
  tester.** Ver §3.

- **Analista «~34 casos, split 18/12/4» vs Tester «19 enumerados, no cuadra» → gana el tester.** El número
  REAL, una vez que caen las caras de capacidad (×2 cada una), la carrera, los gates y los añadidos del
  auditor (F-05, ⚪4, ⚪5, 🟡2, 🟡3), es **~41**, no 34 (desglose en §6). No se fija literal hasta que existan
  (lote 4-6). El «34» del plan era optimista en estructura y BAJO en total.

- **Analista «juez '2.4'» vs Tester «`ContractLevel` cerrado, sin `makeRelationsDriver`» → se resuelve con un
  runner SEPARADO (§3), que además vuelve moot el salto de nombre `'2.2'→'2.4'`.**

---

## 3 · Decisiones de mecanismo que el plan no tomó (las tomo yo)

**(A) Runner de contrato: SEPARADO, `runRelationsDriverContract` — NO un nivel `'2.4'`.**
Decisivo el precedente: `runMigrationContract` **ya** es un runner separado publicado en `/testing` para una
preocupación separada, y `RelationsDriver` es un puerto separado (§2 del plan, decisión de higiene «todo en
un driver o todo en otro»). Plegarlo en `runAuthorizationDriverContract` conflaría dos puertos y obligaría a
`ContractLevel` a cargar un nivel que mezcla dos interfaces. Consecuencias:
- Nace `runRelationsDriverContract(harness)` con `makeRelationsDriver(tree)`, publicado en `/testing`, y su
  propio `relations_harness.spec.ts` con conteo literal por cara de capacidad.
- **Los conteos existentes NO cambian** (core=40/2.0=53/2.1=71/2.2=81 con `listDenies`, etc.): relaciones no
  añade nada a esos niveles. Esto elimina el riesgo que el tester señaló de tocar `contract_harness.spec.ts`.
- La **versión del PAQUETE** es 2.4; el runner de relaciones no es un `ContractLevel`. Desaparece el problema
  del salto `'2.2'→'2.4'`.
- Las cuatro caras de frontera (F-01…F-05) que cruzan roles↔relations viven en un **spec puente** que
  construye ambos puertos sobre el mismo backend (en `openfga`, mismo store).

**(B) `membersOf`: AL PUERTO, opcional, y DISTINTO de `listSubjects`.**
Una capacidad `membersOfNative: true` sin método que llamar no tiene qué observar en `whenTrue`. Se añade
`membersOf` como método **opcional** del puerto (como `purgeRole`/`countRoleAssignments` en
`AuthorizationDriver`), con **las dos caras pobladas**: `whenTrue` (`database` lo demuestra), `whenFalse`
(`openfga` ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrándolo, **nunca un skip** — el guard de `contract.ts:4415` solo
obliga a `whenTrue`, así que la cara `whenFalse` ausente se salta en silencio: hay que poblarla). Y se
**desambigua**: `membersOf` devuelve la membresía **TRANSITIVA** (todos los sujetos de un grupo, incluidos
los grupos anidados — CTE recursiva en `database`); `listSubjects(member, group)` devuelve **hechos
DIRECTOS** (invariante 7). Esa diferencia (transitivo vs directo) es lo que justifica la capacidad nativa: en
`openfga` la transitiva sería `ListUsers`, que trunca — de ahí `whenFalse` = 500.

**(C) El conteo del juez: aterrizado, no estimado.**
No se fija un literal ahora; se fija el MECANISMO: cada lote añade sus casos al runner de relaciones, y el
lote 4-6 clava el conteo literal en `relations_harness.spec.ts` con **una aserción por cara de capacidad** y
un `assert.throws` de «capacidad `true` sin soporte se rechaza». Estimación honesta: **~41** (§6), no 34.

---

## 4 · Las tres decisiones del dueño — recomendación, condición y si bloquean 4-1

| # | Decisión | Recomendación del juez | Condición que la cambiaría | ¿Bloquea 4-1? |
|---|---|---|---|---|
| **(a)** | Store **compartido** vs separado | **COMPARTIDO** (§2). El 🔴 no lo fuerza; los números del analista lo favorecen; ⚪4+F-05 lo hacen seguro por construcción. Escape documentado para el caso extremo. | Un consumidor de día 1 que necesite **>20 tipos de objeto Y pegado al techo de permisos**; o que el caso-exploit no se logre poner VERDE en `openfga` (lote 4-4). | **NO** — resuelta como compartido. 4-1 (generador FUSIONADO) procede bajo esa premisa. |
| **(b)** | `{trx}` en `relations/` ahora vs diferido | **DIFERIDO en el PUERTO** (paridad con `roles/`, 2.6+). El driver `database` usa `{trx}` **internamente** para su atomicidad (trigger+insert), pero `relate`/`unrelate` no lo exponen todavía. Adelantarlo solo en relaciones deja `roles/` desparejo y crea un contrato que 2.6 tendría que honrar en ambos. | Un consumidor de primera mano (COGNITIV) que necesite `relate()` atómico con sus escrituras de app ⇒ se adelanta `{trx}` para **los dos** puertos, no solo relaciones. | **NO** — toca 4-2/4-3. |
| **(c)** | `authz_relations` insert/delete-only vs con UPDATE | **INSERT/DELETE-ONLY** (un trigger por dialecto; menos superficie de divergencia de motor — la lección de los 8 defectos de 2.5; paridad con los hechos de `roles/`). La renovación de caducidad es **delete+insert**, y eso se PRUEBA con un caso (observabilidad de la decisión, exigencia del tester). | Que se adopte caducidad de relaciones (R-15) **y** se mida que el churn delete+insert es un problema real — perf, no corrección; hoy sin medir. | **NO** — toca 4-3 (trigger). |

---

## 5 · Conflictos entre panelistas (a quién le toca probar qué)

- **Analista (§5: «la frontera la garantiza la construcción + `check_purity`») vs Auditor (🔴 1: `relate`
  escala a `roles.authorize`).** → **Gana el auditor**, reproducido contra `:8101` y **confirmado por el
  juez** en `openfga_facts.ts:352` (la tupla `assignee` plana se acepta). Carga de la prueba del cierre: el
  **lote 4-4** con el caso-exploit VERDE en `openfga`.
- **Analista («F-01…F-04 fijan la frontera») vs Tester («F-01/F-02 decorativos en `database`»).** → **Gana el
  tester.** Le toca al **lote 4-5** anclar F-01/F-02 con el mutante de conflación en `openfga` y verlos
  rojos, o degradarlos a documentación.
- **Analista («cero casos de carrera necesarios; §0.4 solo coste») vs Tester («carrera
  `defineRelationsConfig`↔`syncAuthzCatalog` sin juez»).** → **Gana el tester.** El plan DESCRIBE la carrera
  como coste; no la pone bajo contrato. Le toca al **lote 4-5** el caso análogo a `contract.ts:2315`.
- **Analista («R-10 truncado ✅») vs Tester («la cara `whenTrue` de truncado está hoy VACÍA,
  `contract.ts:4357`; R-10 es 🟡 no ✅»).** → **Gana el tester.** Capacidad NUEVA (`listObjectsTruncation`,
  no reusar `truncationSignal`) con `whenTrue` contra el `:8101` de tope 3. Le toca al **lote 4-4**.

---

## 6 · Afirmaciones descartadas por falta de evidencia (o corregidas)

- **Analista: «`check_purity` regla 2 hace nacer `src/relations/` vigilado ⇒ la frontera está preparada».**
  Descartada como suficiente: `check_purity` aísla el **bundle**, no la semántica (el propio plan lo admite a
  medias en §5, pero mantiene «garantizada por construcción»). Confirmado por el juez leyendo el contrato.
- **Analista: «~34 casos (18 núcleo / 12 anexo / 4 negativos)».** Descartada como conteo: el tester grep-eó
  19 enumerados; el número real ronda 41 una vez contadas las caras de capacidad. Es aspiracional.
- **Analista: «store compartido es la elección segura por defecto» (implícito, sin F-05).** Corregida, no
  descartada: es segura **con** ⚪4+F-05; sin ellas embarcaba el 🔴.
- Ninguna afirmación del **auditor** ni del **tester** se descarta: el 🔴 está reproducido, el hueco de
  mecanismo está en el código (verificado), y sus 🟡/⚪ están razonados con precondición explícita.

---

## 7 · El plan por lotes (formato 3b-lote-2, con criterios de aceptación)

**7 lotes** (el plan tenía 6; se separa el runner+frontera del reconcile por la regla de no-concurrencia).
Cada lote: rojo→verde + typecheck + `npm test` + `:8101` + tope-3 + tester (worktree, mutantes) + auditor
(árbol principal, **nunca en paralelo** con quien mide) + `/code-review`. Camino crítico marcado.

### 4-1 · Modelo FUSIONADO + generador + gate de bytes fusionado (CAMINO CRÍTICO — desbloquea todo) · **puede empezar YA**
Pieza pura, sin `check`. `openFgaFactsModel` emite además los `type_definitions` de `group` + los tipos de
`defineRelationsConfig`; el gate mide el modelo **fusionado**.
- **AC:** modelo fusionado = literal de §1 del plan para `group`+1 tipo; **se publica en `:8101`** (201);
  **gate de bytes FUSIONADO como caso unitario con DOS caras** (rebasa ⇒ 500 nombrando bytes; **justo por
  debajo ⇒ publica**; 80 % ⇒ avisa) — hoy `factsModelBytes` mide solo `facts`; **⚪4 a nivel de modelo**: un
  `objectType` que duplica/colisiona con un tipo o familia reservados de `facts` ⇒ **422 del paquete**
  (no el 400 opaco del servidor), en el generador; **F-04** (colisión permiso↔relación) detectada; depth
  `can_<P>` intacta (22, medida sobre el FUSIONADO con **500 reps**, no una tirada). **0 tuplas, `authorize`
  de `roles/` sin tocar.**

### 4-2 · Puerto `RelationsDriver` + `defineRelationsConfig` + manager + runner de contrato
Interfaz, tipos (`RelSubject` holder|userset), `assertWrite` puro, `actor`/`onRelationWrite`, capacidades con
caso; **F-05 en el puerto** (whitelist de type+relation); **`membersOf` como método opcional distinto de
`listSubjects`**; **`runRelationsDriverContract` + `makeRelationsDriver`** (esqueleto del runner separado).
- **AC:** un driver falso satisface el puerto; `defineRelationsConfig` valida (includes sin `from`,
  `usersetsOf` un nivel, `membersOf` solo en opciones de `database`, **⚪4 reservados**); **F-05**: `relate`/
  `unrelate` con type/relation no declarados ⇒ 422 antes de tocar el driver falso; R-13 (`assertWrite`,
  `actor`); capacidades `singleCheckRelations`/`listObjectsInherited:false`/`usersetSubjects`/
  `membersOfNative`/`enumerateRelations`/`listObjectsTruncation` declaradas **cada una con sus DOS caras**;
  el runner falla si una capacidad `true` no trae su `whenTrue` **o** su `whenFalse`.

### 4-3 · Driver `database` (`authz_relations` + CTE + trigger por dialecto, INSERT/DELETE-ONLY)
Migración/stub de `authz_relations`, `relate/unrelate/check/list*/purge*/membersOf`, CTE recursiva por
dialecto, `relationPartitionTrigger` (SQLite/PG/MySQL o throw), `{trx}` INTERNA.
- **AC:** R-01…R-12 + F-05 verdes en **SQLite + PG + MySQL**; **trigger cross-partición ⇒ error de motor
  clasificado** (medido: los tres rechazan; caso de DRIVER con `knex.raw`, no de contrato — defiende al
  escritor a mano); **dialecto ajeno ⇒ throw** `E_AUTHZ_UNSUPPORTED_DIALECT`; **INSERT/DELETE-ONLY: caso que
  prueba que renovar caducidad es delete+insert** (decisión (c) observable); `membersOf` transitivo
  (`whenTrue`); `purge*` demuestra cero o 500; 🟡2 (`purge*` barre ambas ortografías del uuid de partición).

### 4-4 · Driver `openfga` (fusión con `facts`) + el 🔴 PROBADO + truncado
`relate/unrelate` = `Write`/delete en el MISMO store/`modelId`; `check` = 1 `Check`; `list*` =
`Read`/`ListObjects` paginado con señal de truncado; `purge*` exhaustiva que lanza si no demuestra cero;
partición por string en el id (⚪5 parseo canónico).
- **AC:** R-01…R-12 + F-05 verdes contra `:8101`; **paridad con `database`** (misma pregunta ⇒ misma
  respuesta); **el caso-exploit del auditor VERDE**: `relate(evil, assignee, {type:'role_binding',
  id:<roleUuid>}, S)` ⇒ **422** y `check(evil, can_<P>, S)` sigue `false` con el binding legítimo intacto
  (spec PUENTE, ambos puertos, mismo store) — **este es el cierre del 🔴 y la condición dura del veredicto**;
  **capacidad NUEVA `listObjectsTruncation`** con `whenTrue` contra el `:8101` de tope 3 (R-10 medido de
  verdad, no ❓); `membersOf` ⇒ 500 `E_AUTHZ_UNSUPPORTED` (`whenFalse`); `check` = 1 `Check` (espía).

### 4-5 · Frontera anclada + carrera + `reconcile` de relaciones
F-01/F-02 **anclados en `openfga`** con mutante de conflación (vistos rojos) o degradados a documentación;
F-03/F-04; **caso de carrera** `defineRelationsConfig`↔`syncAuthzCatalog` (análogo a `contract.ts:2315`);
🟡3 (config de relaciones persistida y bajo el gate de versión, invariante 14); `enumerateRelations` +
destino en `reconcile`; `--dry-run` vigila la deriva del modelo fusionado.
- **AC:** F-01…F-05 verdes en ambos drivers, **con F-01/F-02 demostrados con dientes**; **carrera**:
  `modelId` final consistente, **ninguna proyección se pierde** (ni relaciones ni permisos), contención que
  no cede ⇒ **409**, nunca modelo mutilado; **🟡3**: republicar desde un proceso **sin**
  `defineRelationsConfig` en memoria **no** deja caer los tipos de relaciones; `reconcile` de relaciones
  **idempotente y bidireccional** con la lección M1/M3/T4 de 3b (un tramo omisivo o una pérdida de
  `subject_relation`/partición **se ve ROJA** vía censo, no basta preguntar al origen lleno).

### 4-6 · Anexo, negativos, conteo del juez, README/CHANGELOG y cierre
R-14 (`membersOf`, ya con su par en 4-3/4-4), R-15 (caducidad de relación **si** el dueño la mete en 2.4);
tablas ficticias del consumidor para los dos casos de diseño (§7 del plan); **conteo literal aterrizado en
`relations_harness.spec.ts`**; README honesto del presupuesto compartido y de la partición; CHANGELOG 2.4.
- **AC:** el runner de relaciones con su **conteo literal por cara de capacidad** + `assert.throws` de
  «`true` sin soporte se rechaza»; ~41 casos cubiertos (desglose abajo); suite entera verde en los 5 modos;
  tester + auditor + `/code-review` cerrados.

### Desglose honesto del conteo (~41, no 34)
Núcleo (11): R-01…R-09, R-11, R-12. — Caras de capacidad ×2 (8): `listObjectsTruncation`, `membersOfNative`,
`usersetSubjects`, `enumerateRelations`. — Frontera/negativos/config (9): F-01…F-05, ⚪4, ⚪5, 🟡2, 🟡3. —
Gates unitarios (3): bytes fusionado (2 caras) + depth 500 reps (1). — Carrera (1–2). — Reconcile (3). —
Solo-driver (3): trigger raw, renovar=delete+insert, dialecto ajeno. — Anexo (2): R-13, R-15 condicional.

### Camino crítico y orden
`4-1` → `4-2` → { `4-3`, `4-4` } → `4-5` → `4-6`. **4-3 y 4-4 NO se corren en paralelo por agentes que mutan
el árbol** (regla de revisiones no concurrentes): o worktrees aislados o en secuencia. El cierre del 🔴 vive
en **4-4**; la frontera con dientes y la carrera en **4-5**.

---

## 8 · Riesgos que quedan aunque se implemente todo

- **F-05 es un chokepoint.** El cierre del 🔴 depende de que TODOS los caminos de escritura embuden por la
  misma validación en ambos drivers. Un método futuro (relate en lote, escritura de reconcile de relaciones)
  que lo salte reabre la escalada. Mitigado por el caso-exploit publicado en el runner (un tercero que no lo
  cumple no pasa el contrato), pero es superficie a vigilar en cada lote posterior.
- **Store compartido = ciclo de vida de modelo compartido.** La carrera `defineRelationsConfig`↔
  `syncAuthzCatalog` (4-5) y el republicar-sin-config (🟡3) son reales y viven porque el store es uno. Si el
  caso de carrera resulta más difícil de lo previsto, es el candidato a reabrir la separación de store.
- **`openfga` no tiene trigger de partición.** Ahí F-05 + la comparación de string son la ÚNICA defensa de
  tenant; el trigger de `database` es defensa en profundidad solo para el escritor a mano.
- **Mantenimiento para terceros.** Puerto nuevo + runner + capacidades nuevas es carga real; el 🔴 la agrava
  (un driver de relaciones de terceros que no implemente F-05 publica la escalada). El runner debe fallarle,
  y el README debe decirlo con esas palabras.
- **Lag del relay para relaciones.** La partición se corta por string sin `scopeOf`; hereda la ventana del
  relay del árbol como el resto de `facts`. No es nuevo, pero va documentado.

---

## 9 · Lo que preguntaría al dueño antes de implementar (solo lo que cambia la decisión)

1. **¿Caducidad de relaciones (R-15) entra en 2.4?** Si NO, R-15 cae e INSERT/DELETE-ONLY es trivialmente
   limpio (la renovación ni existe). Si SÍ, el caso «renovar = delete+insert» de 4-3 es obligatorio. Es lo
   único que cambia el alcance del lote 4-3.
2. **Store (a):** nada que preguntar salvo que el dueño ya sepa de un consumidor de día 1 con **>20 tipos de
   objeto pegado al techo de permisos**. Si no lo sabe, **compartido** y no hace falta respuesta.

Las decisiones (b) y (c) las resuelvo yo (diferir `{trx}`; INSERT/DELETE-ONLY) y no bloquean el arranque.

---

## Lista ordenada de lotes

1. **4-1** · Modelo fusionado + generador + gate de bytes fusionado + ⚪4/F-04 a nivel de modelo · *camino crítico*
2. **4-2** · Puerto `RelationsDriver` + `defineRelationsConfig` + F-05 + `membersOf` + `runRelationsDriverContract`
3. **4-3** · Driver `database` (CTE + trigger INSERT/DELETE-ONLY, tres motores)
4. **4-4** · Driver `openfga` (store compartido) + **🔴 probado VERDE** + `listObjectsTruncation`
5. **4-5** · Frontera anclada (F-01/F-02 con dientes) + carrera config↔catálogo + reconcile de relaciones
6. **4-6** · Anexo + conteo literal del juez + README/CHANGELOG 2.4 + cierre

---

**El lote 4-1 puede empezar YA.** Su premisa (store COMPARTIDO, modelo FUSIONADO) queda resuelta por el juez
—el 🔴 no fuerza separar el store—, y las otras dos decisiones del dueño ({trx} diferido, INSERT/DELETE-ONLY)
tocan los lotes 4-2/4-3, no el 4-1. Lo único que 4-1 debe incorporar sobre el plan original: el gate de bytes
del modelo **fusionado** como caso de dos caras, ⚪4/F-04 a nivel de modelo, y la profundidad con **500 reps**.
El cierre del 🔴 (F-05 + el caso-exploit VERDE en `openfga`) es la **condición dura** y vive en los lotes 4-2
y 4-4, no en el arranque.
