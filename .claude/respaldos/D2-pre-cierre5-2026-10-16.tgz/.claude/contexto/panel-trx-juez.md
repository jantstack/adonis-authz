# Panel `{trx}` · VEREDICTO DEL JUEZ

> Insumos: `panel-trx-analista.md` (arquitecto, mediciones contra `:8101`/pg18/SQLite) y
> `panel-trx-auditor.md` (atacante, 7 reproducciones contra `:8101`). Este documento **decide**.
> **Encuadre corregido por el dueño antes de emitir** (2026-09-01): *«No te tienes que basar en el
> código de COGNITIV. Tiene que funcionar ya sea si el cliente quiere usar un driver o el otro, y
> que él sea el que ajuste según lo quiera manejar.»* ⇒ **el criterio «lo que COGNITIV despliega»
> queda fuera de la puntuación**. Las mediciones de los dos panelistas siguen valiendo: son
> propiedades del paquete.
>
> **Verificado por mí, leyendo el árbol de trabajo** (solo lectura; hay un implementador de R-15
> en el árbol, así que los números de línea son los de HOY y pueden moverse):
> `src/types.ts:1521` (el docblock que promete re-validación en el driver), `src/types.ts:1413`
> (`RelationWriteOptions` **no** declara `transaction`), `src/types.ts:131` (solo
> `ScopeTreeWriteOptions` lo declara), `src/manager.ts:1435` (el cast que lo lee igual),
> `src/manager.ts:663-670` (la barrera del freeze se lee **por el cliente del llamante**),
> `src/freeze.ts:116-124` (`readFreezeRow` ya corre bajo `guardSql` con deadline),
> `src/scope_outbox.ts:221` (`on()` devuelve el `trx` tal cual ⇒ ignora `connection`),
> `src/catalog/catalog_cache.ts:588` (`view()` no acepta cliente) y `src/drivers/database_driver.ts:652`
> (`grant` la usa), `src/drivers/openfga_relations_driver.ts:342-367` y
> `src/drivers/database_relations_driver.ts:303-367` (**ninguno** de los dos comprueba
> `hasType`/`isDeclared`), `src/relations/manager.ts:110-152` (F-05 vive **solo** ahí),
> `src/relations/reconcile.ts:229` (`reconcileRelations` escribe con `to.relate(...)`, o sea **por el
> driver**, saltándose F-05), constructores de los dos drivers de relaciones (`…:198` y `…:165`:
> **ambos ya reciben `RelationsConfig`**), y `src/relations/` + `commands/authz_relations_reconcile.ts`
> (**cero** barrera de freeze).

---

## Veredicto

**Recomendación:** **(C) — `{trx}` real en `database` y RECHAZO ACTIVO en `openfga`, con capacidad
declarada y dos puertas** (puntuación **90/100**). El porqué decisivo, sin nombrar a ningún
consumidor: **una tupla no entra en una transacción SQL** — no hay 2PC entre FGA y la base del
llamante — así que la única promesa honesta en `openfga` es «no puedo, y te lo digo antes de
escribir nada». Las alternativas que sí «aceptan» `{trx}` en `openfga` compran esa aceptación con
**fail-OPEN medido** (A: `revoke`/`deny`/`unrelate` encolados ⇒ el store responde `true` durante
1,16 s de mediana / 2,28 s de cola, y una entrada APARCADA es un `revoke` que no ocurre jamás) o
con **una firma que miente** (B: cero filas SQL que inscribir ⇒ el parámetro no hace nada).

**Con estos injertos de otras opciones:**
1. **La forma del rechazo la fija el auditor, no el roadmap**: rechazo **por LLAMADA**, no
   «falla al construirse» (⚪ 15 del auditor + §4 del analista). El roadmap se reescribe.
2. **La receta por DIRECCIÓN** de la opción (D) del auditor (= §2.4 del analista): permisivo
   **después** del commit, restrictivo **antes/dentro** ⇒ los dos modos de fallo caen fail-CLOSED,
   con cero mecanismo nuevo. Va al README como lo que `openfga` **sí** puede ofrecer, con su límite
   escrito (**no compone**: `grant`+`revoke` del mismo hecho en la misma transacción acaban
   concediendo).
3. **La mitigación del 🟠 9 del auditor, ascendida a regla del puerto nuevo**: `{transaction}` se
   valida contra la conexión del driver (500 si es de otra) — sin eso, «los dos o ninguno» es falso
   también en `database`.
4. **La segunda puerta del analista** (`requireTransactionalWrites` en config ⇒ 500 al RESOLVER):
   entra ahora. Es lo que convierte una sorpresa a las 3 de la mañana en un despliegue que no
   arranca.
5. **Contra los dos panelistas a la vez, la resolución del pool**: la barrera del freeze y el
   catálogo **NO** se leen por la transacción del llamante (eso es justo el 🟠 8 del auditor); se
   leen por la conexión propia, que ya tiene deadline (`freeze.ts:119`) ⇒ con pool 1 el resultado es
   **503 fail-closed**, no un cuelgue. `{transaction}` **exige pool ≥ 2**, declarado. Esto sustituye
   al spike T-0 del analista y le quita la apuesta (i) (vista de catálogo no memoizable): **no se
   toca el invariante 14**.

**Condición para proceder:** los **lotes L-0 y L-1 (agujeros de HOY) van ANTES** de una sola línea
de `{trx}`. Dos de ellos son independientes del panel y uno de ellos —F-05 ausente en los drivers
con un docblock publicado que afirma lo contrario, más `reconcileRelations` escribiendo por el
driver— **incumple la condición dura del veredicto de la Fase 4** («una sola validación por la que
embudan TODOS los caminos de escritura»).

---

## Criterios (fijados antes de puntuar, con el encuadre del dueño)

| Criterio | Peso | Qué mide |
|---|---|---|
| **Cómo falla** | 30 | Si el modo de fallo (lag, rollback, caída, aparcado) concede de MÁS o de MENOS. Un fail-open no mitigado descalifica. |
| **Honestidad de lo publicado** | 25 | Que la firma, la capacidad y el README digan exactamente lo que el mecanismo hace, en LOS DOS drivers. «Lo publicado se cumple o se reescribe». |
| **Verificabilidad** | 20 | Que exista un caso de contrato con mutante que lo mate, en los dos drivers, sin `skip`. |
| **Coste y deuda medidos** | 15 | Latencia, superficie nueva, mantenimiento para terceros. Con cifra o no cuenta. |
| **Reversibilidad / no-breaking** | 10 | Deshacerlo sin migración de datos ni major. |

---

## Tabla de puntuación

| Criterio (peso) | (A) outbox de hechos | (B) `{trx}` solo-SQL | **(C) rechazo activo** | (D) asimetría por dirección | (E) grant provisional 30 s | (F) `authz_*` log durable |
|---|---|---|---|---|---|---|
| Cómo falla (30) | **0** | 5 | **9** | 7 | 3 | 5 |
| Honestidad (25) | 3 | **0** | **10** | 8 | 4 | 8 |
| Verificabilidad (20) | 3 | 6 | **9** | 5 | 5 | 7 |
| Coste medido (15) | 2 | 9 | 8 | 9 | 5 | 1 |
| Reversibilidad (10) | 4 | 3 | 8 | 10 | 6 | 1 |
| **Total** | **20,5** | **43,5** | **90,0** | **74,5** | **42,5** | **51,5** |

**Notas de puntuación (lo que sostiene cada 0):**

- **(A) = 0 en «cómo falla».** No es opinión: está medido. `revoke`/`deny`/`unrelate` encolados ⇒
  el store dice `true` y la BD dice `false` (tabla de §2.1 del analista, caso `A1` del auditor);
  drenaje real 131,5 entradas/s **no paralelizables** (escritor único, `scope_outbox.ts:297`) ⇒ 38 s
  de ventana con 5.000 altas; y una entrada aparcada (`maxAttempts` 5) **no la repara nada**: en un
  despliegue `facts` la pasada de mantenimiento no escribe ni borra un solo hecho
  (`manager.ts:1199`, `openfga_driver.ts:2488-2495`) y `--from=database` está cerrado por
  `E_AUTHZ_MASS_RECONCILE_REFUSED`. Súmese la **resurrección MEDIDA** (🔴 1 del auditor) y que la
  base del consumidor pasa a ser **escritor privilegiado del PDP** (🔴 3: `relayScopeChanges` se
  salta `requireActor`/`within` a propósito, `manager.ts:847-850`). Tres 🔴 no mitigados ⇒
  **descalificada por la regla de parada**, no por puntuación.
- **(B) = 0 en honestidad.** Verificado: en `openfga` con `facts` las escrituras de hechos y de
  relaciones tocan **cero filas SQL**; lo único SQL es una **lectura** del catálogo
  (`openfga_driver.ts:952`). No hay «parte SQL» que inscribir. Aceptar el parámetro y no cumplirlo
  es publicar con nuestra firma la fuga del cruce 4 · S5 — la misma que motivó que el driver `facts`
  **se niegue a construirse** sin outbox («una recomendación no es un mecanismo»).
- **(D) no compite: se injerta.** No entrega `{trx}` —no hay atomicidad en ninguna de sus dos
  ramas—, así que no responde la pregunta del panel; pero sus dos modos de fallo son fail-CLOSED y
  su coste es una sección de README. Va dentro de (C).
- **(E) descalificada, y con un motivo que el auditor no vio.** Su rollback deja **hasta 30 s de
  acceso concedido**: es una escalada temporal *creada por el paquete*, no heredada. Y colisiona con
  el invariante 10 / R-15: una tupla provisional con `valid_until = now+30 s` es indistinguible de
  una caducidad legítima de 30 s, así que el siguiente `grant`/`relate` con `expiresAt` **omitido**
  la «preserva» (`resolveGrantExpiry`) y convierte lo provisional en lo definitivo. Razonado sobre
  código, no medido — pero basta para no construirlo.
- **(F) es la única que algún día podría dar `{trx}` REAL en `openfga`**, y por eso no la entierro:
  la entierro **para este alcance**. Deroga `#factsOrigin` caso 1 y la propiedad «los hechos viven
  en el PDP», que es media Fase 3b y una decisión firmada; y aun así **no da «los dos o ninguno» en
  el PDP** (el store sigue siendo una proyección con lag ⇒ el `revoke` sigue con ventana abierta).
  Va a la lista de preguntas de 3.0, no a un `alpha.2`.

---

## 1 · La decisión, driver por driver (y la respuesta a la pregunta 5 del auditor)

### 1.1 · Qué significa «atómico», y cuál de los dos significados promete cada driver

La pregunta 5 del auditor —*«¿atómico es "los dos o ninguno" o "no se pierde"?»*— **no se le
pregunta a un consumidor: la contesta el paquete y el consumidor elige driver.** Las dos lecturas
son:

| Promesa | Qué exige | Quién puede darla |
|---|---|---|
| **(i) «los dos o ninguno»** | que el hecho del paquete y la escritura del consumidor confirmen o reviertan **en el mismo motor transaccional** | **`database`**, y solo si el `trx` es de **la misma conexión** que usa el driver |
| **(ii) «no se pierde»** | durabilidad eventual: la escritura llega *después*, sí o sí | **nadie**, hoy: (A) la compraría a cambio de fail-open y de un aparcado irreparable |

**Dictamen:** la capacidad `transactionalWrites: true` significa **exactamente (i)**, jamás (ii). No
hay valor intermedio y no se publica ninguno. `openfga` declara `false` y ofrece la receta por
dirección (§1.3), que **no es atomicidad: es un orden de escritura que hace que el fallo caiga del
lado cerrado**. Escrito con esas palabras en el README.

Corolario que ningún panelista puso, y que hay que implementar: **(i) es falso en `database` si el
`trx` es de otra conexión.** Es el 🟠 9 del auditor generalizado (verificado en
`scope_outbox.ts:221`: con un `trx` la conexión con nombre se ignora en silencio). El puerto nuevo
comprueba la pertenencia y responde **500 `E_AUTHZ_CONFIG`** si no cuadra; pasar `db` entero como
`transaction` (que hoy pasa el duck-check `.from`/`.table`) es el mismo 500.

### 1.2 · `database`: `{trx}` real, con tres cosas que NO viajan por la trx del llamante

Reciben `{transaction}`: `grant`, `revoke`, `deny`, `removeDeny` (puerto `roles/`) y `relate`,
`unrelate`, `purgeObject`, `purgeSubject` (puerto `relations/`).

**Lo único que va por la transacción del llamante es la ESCRITURA.** Por su conexión propia siguen:

1. **La barrera del freeze.** Es autoridad: si la decide el snapshot del llamante, no es una
   barrera — el auditor lo midió (`C1`) y en producción es literalmente el REPEATABLE READ de
   InnoDB. Con la conexión propia y pool 1 no se cuelga: `readFreezeRow` ya corre bajo `guardSql`
   con deadline (`freeze.ts:119`) ⇒ **503, fail-closed**. Esto **revierte** el atajo que
   `manager.ts:663-670` introdujo por el pool.
2. **La lectura del catálogo** (`catalog_cache.ts:588`). Leerla dentro de una transacción ajena
   sería superficie nueva alrededor del invariante 14 —el que más ha costado del paquete— para
   ahorrar una conexión. No.
3. **`resolveChain`**, que además ni siquiera puede recibirla (`types.ts:843`: la firma es
   `(scope) => Promise<ScopeRef[] | null>`). Ver §6, riesgo residual.

**Precio, declarado:** `{transaction}` **exige pool ≥ 2**. Con pool 1 la escritura es un 503 limpio,
nunca un `false` ni un cuelgue. Los casos del par de capacidad se gatean a `sqlite-file`/pg/mysql
(precedente: `freeze_multiprocess.spec.ts`), **y eso se dice en el README** porque un driver de
terceros juzgado solo en `:memory:` no vería esos casos.

**Cambio de comportamiento que hay que fijar con caso** (lo aporta el analista, lo confirmo):
`relate` abre HOY una transacción interna (`database_relations_driver.ts:320-324`); con una externa
presente deja de abrirla, así que el `check-then-insert` idempotente pasa a correr en el aislamiento
que eligió el consumidor y un choque del UNIQUE **envenena la transacción del consumidor** en vez de
absorberse en el driver. Es correcto y es observable ⇒ documentado y con caso. Lo mismo el reintento
K4 de `grant`.

### 1.3 · `openfga`: rechazo activo, y la receta que sí existe

- `{transaction}` en cualquier escritura de hechos o de relaciones ⇒ **500 `E_AUTHZ_UNSUPPORTED`**
  nombrando driver y operación, **antes de tocar el backend** (cero llamadas al cliente FGA,
  verificable con espía). **Nunca** un `logger.warn`, nunca ignorarlo.
- **Conflicto resuelto: 500, no 422.** El auditor pedía 422; el analista, 500. Gana el analista **por
  precedente**: `E_AUTHZ_UNSUPPORTED` es el 500 con el que el paquete ya dice «este driver no sabe
  hacer esto» (`membersOf`, `purgeRole` antes de 3b-2e, `enumerateRelations`). 422 está reservado a
  «tu pregunta está mal» (invariante 5), y pasar `{trx}` no es una pregunta mal formada: es un
  despliegue que no case con lo que se pidió. La letra del error lleva la salida: «usa el driver
  `database`, o declara `requireTransactionalWrites` para que esto falle al arrancar».
- **Lo que sí se le ofrece** (injerto de (D)/§2.4, documentación pura):

| Dirección | Con `openfga` | Si la transacción del consumidor revierte |
|---|---|---|
| **Permisiva** (`grant`, `relate`, `removeDeny`) | escribir **DESPUÉS del commit** | no se concedió nada ⇒ **fail-CLOSED** |
| **Restrictiva** (`revoke`, `deny`, `unrelate`) | escribir **ANTES/dentro**, en línea | se revocó algo que SQL sigue concediendo ⇒ **fail-CLOSED**, y reparable |

  Con su límite en la misma sección: **no compone** (un `grant` y un `revoke` del mismo hecho en la
  misma transacción se aplican en orden invertido y acaban concediendo). Un caso fija que **el
  paquete no lo automatiza**.

### 1.4 · Lo que NO recibe `{transaction}`, y por qué

- **`defineScopedRole`/`updateScopedRole`/`deleteScopedRole`/`purgeRole`/`syncAuthzCatalog`**:
  escriben por `withAuthzCatalogWrite`, que **es** el serializador del catálogo entre procesos
  (cerrojo de la fila de versión + bump como última sentencia, invariante 14 / 3D · M2). Moverlas al
  commit del consumidor lo anula. **Fuera de alcance, dicho en el README.**
- **`scopes.attached/moved/detached`**: ya tienen `transaction` desde 3b-2d con **otra semántica**
  (*«mete el ENCOLADO en mi trx»*, `types.ts:131`). No se toca, y el docblock del nuevo tiene que
  decir en voz alta que **encolar ≠ escribir** o alguien los confundirá.
- **`relayScopeChanges` / `reconcile` / `pruneOrphanRoles`**: plataforma. No.

---

## 2 · La semántica de la capacidad: la forma honesta

**La frase del roadmap (`roadmap-2.0.md:103`, «el manager falla al construirse si el driver no la
soporta») es incorrecta y los dos panelistas la tumbaron por caminos distintos y compatibles:** el
analista, porque haría `openfga` **inconstruible** en cualquier app que solo lo tenga registrado en
`config.drivers`; el auditor, porque el driver se resuelve **perezosamente y por nombre**
(`reconcile --to=`, `--from=`, `forRequest`), así que en el momento de construir no se sabe si
alguien pasará `{trx}`. **Se reescribe.** Forma aprobada:

```ts
/**
 * El driver puede inscribir sus escrituras en la transacción del consumidor
 * (`{ transaction }`). `true` significa EXACTAMENTE «los dos o ninguno con TU
 * transacción», nunca «no se pierde». `database` = true (con el `trx` de SU
 * conexión). `openfga` = false, y no puede ser otra cosa: una tupla no entra en
 * una transacción SQL — el store es otro servicio y no hay 2PC.
 */
transactionalWrites: boolean
```
en **`AuthorizationDriverCapabilities` y `RelationsDriverCapabilities`, con el mismo nombre** (un
driver de terceros no debe aprender dos).

- **Puerta 1 · por llamada, siempre activa.** `transactionalWrites !== true` + `{transaction}` ⇒ 500
  `E_AUTHZ_UNSUPPORTED`, cero escrituras.
- **Puerta 2 · por config, opt-in.** `requireTransactionalWrites: true` ⇒ al **RESOLVER** el driver,
  si no lo declara ⇒ 500 `E_AUTHZ_CONFIG`. Mismo patrón que el gate `hierarchyFacts ⇒ scopes.outbox`
  (3b-2e · E3) y que el de `withClock`. **Entra ahora** (≈1 h dentro de su lote): es lo que hace que
  un despliegue equivocado no arranque **en toda la flota** en vez de fallar en una ruta poco
  transitada. No lo pregunto al dueño; lo decido.
- **Las DOS caras pobladas a mano** en los dos runners: el guard de `contract.ts:4415` solo obliga a
  `whenTrue`, así que una `whenFalse` ausente se salta en silencio (lección de 4-2). `whenTrue`:
  escritura + rollback ⇒ `authorize`/`check` `false` **y cero filas** (el censo, no solo la
  respuesta). `whenFalse`: 500 con **cero llamadas al backend** (espía).
- **`{transaction}` se declara en los tipos** (`WriteOptions`/`RelationWriteOptions`). Hoy NO está
  declarado en `GrantOptions` ni en `RelationWriteOptions` y sin embargo `manager.ts:1435` lo
  consume con un cast: eso es el 🟠 8 y se arregla en L-1, **antes** de publicar nada.

---

## 3 · Los hallazgos de HOY (independientes de `{trx}`): dictamen

| # | Hallazgo | Verificado por mí | ¿Bloquea? | Dónde |
|---|---|---|---|---|
| **🔴 2 (auditor)** | F-05 solo en `RelationsManager`; los DOS drivers no re-validan tipo/relación, y `types.ts:1521` publica que sí | **Sí** (drivers + docblock + `relations/reconcile.ts:229`) | **SÍ, y va PRIMERO** | L-0 |
| **🟠 8 (auditor)** | La barrera del freeze la decide el cliente que pasa el llamante; `#writeOptions` lee `transaction` con un cast aunque el tipo no lo declare | **Sí** (`manager.ts:663-670` y `:1435`) | **SÍ** | L-1 |
| **🟠 9 (auditor)** | `scope_outbox` ignora `connection` con un `trx` ⇒ encola en la base equivocada | **Sí** (`scope_outbox.ts:221`) | **SÍ** (misma familia que 🟠 8) | L-1 |
| **🔴 5.1 (analista)** | Pool 1 + trx del llamante ⇒ la conexión propia se cuelga; `CatalogCache.view()` sin cliente | Sí el mecanismo (`catalog_cache.ts:588`); **matizo la consecuencia** | No es seguridad: es **diseño de `{trx}`**, y queda **resuelto** (§1.2) | L-2/L-3 |
| **🟠 J1 (mío, nuevo)** | `RelationsManager` **no tiene barrera de freeze** y `authz:relations:reconcile` **no congela nada** | Sí (grep en `src/relations/` y en el comando) | **SÍ** (cheap; y con `{trx}` empeora) | L-1 |

### 🔴 2 · Por qué bloquea y por qué va antes que `{trx}`

Dos de los tres caminos son «documentados» y uno **no**:

1. `manager.driver()` es la salida documentada de todas las barreras (invariante 15). Por ahí, esto
   **no** es un bypass. Pero
2. **`types.ts:1521` publica** que «el driver la re-valida por defensa en profundidad». Es **falso en
   los dos drivers del paquete**, verificado. Regla dura: *lo publicado se cumple o se reescribe*. Y
   la frase no es decorativa: es lo que un **driver de relaciones de terceros** lee para saber qué le
   exigen, y el veredicto de la Fase 4 dijo que el runner debe fallarle a quien no implemente F-05.
3. **`reconcileRelations` escribe con `to.relate(...)` (`relations/reconcile.ts:229`), o sea por el
   DRIVER.** Eso es código del paquete, no una salida de plataforma. La Fase 4 cerró el 🔴 del
   store compartido con la premisa *«el id `role_binding:...` nunca lo compone el driver de
   relaciones»* y con la AC *«una sola validación por la que embudan TODOS los caminos de
   escritura»*. **La premisa es falsa hoy y la AC no se cumple**: una tupla de tipo no declarado que
   llegue del origen (o que un escritor a mano dejó en `authz_relations`) se propaga al destino sin
   pasar por F-05. El propio veredicto de la Fase 4 lo anticipó como el riesgo residual: *«si un
   camino de escritura futuro —escritura de reconcile de relaciones— lo salta, reabre la escalada»*.
   Pues lo salta.

**Coste del arreglo: bajo.** Los DOS drivers ya reciben `RelationsConfig` en el constructor
(`openfga_relations_driver.ts:198`, `database_relations_driver.ts:165`): son dos guardas de tres
líneas. No hay excusa de coste para diferirlo.

### 🟠 8 · El dictamen que contradice a los dos panelistas a la vez

El analista propone **generalizar** «leer por la trx del llamante» (lo que ya hace la barrera) a la
lectura del catálogo. El auditor demuestra que **leer la barrera por la trx del llamante es el
agujero**. Ninguno de los dos vio que estaban tirando de la misma cuerda en direcciones opuestas.
**Resuelvo a favor del auditor**: la barrera es autoridad y se lee por la conexión del motor, con su
deadline; el pool 1 se paga con un 503 declarado, no con un bypass. El comentario de
`manager.ts:663-665` («exigir una segunda conexión con la suya abierta interbloquea un pool de 1»)
describe un problema real y eligió la salida equivocada: cambió disponibilidad por autoridad.

Efecto colateral que hay que declarar en el CHANGELOG: **hoy** `scopes.attached/moved/detached` con
`{transaction}` en un despliegue de pool 1 dejará de funcionar (503) hasta que se suba el pool. Es
breaking de despliegue, es ruidoso y es la dirección segura.

### 🟠 9 · Ascendido de bug a regla del puerto

No se arregla solo en `sqlScopeOutbox`: la **misma comprobación** («este `trx` es de MI conexión, y
no es el `db` entero») es la que hace verdadera la promesa (i) del puerto nuevo (§1.1). Se
implementa una vez, se usa en los dos sitios.

### 🟠 J1 · Mi hallazgo: las relaciones no están congeladas por nada

Verificado por grep: no hay una sola referencia al freeze en `src/relations/` ni en
`commands/authz_relations_reconcile.ts`. Consecuencias: (a) durante una ventana de cutover, las
escrituras de relaciones **entran** mientras las de roles reciben 503; (b) una pasada de
`authz:relations:reconcile` **certifica** un estado que puede haber cambiado debajo. No lo he
medido y no le pongo 🔴; lo que sí digo es que es **superficie que la Fase 4 no cubrió** y que
publicar `{trx}` en `relations/` sin resolverlo empeora el cuadro (la ventana entre barrera y commit
pasa a fijarla el consumidor). `src/freeze.ts` está en la raíz de `src/`, así que `src/relations/`
puede importarlo sin romper la regla 2 de pureza.

---

## 4 · Contradicciones entre panelistas, resueltas con evidencia

1. **Analista «leer por la trx del llamante es el precedente a generalizar» vs Auditor «leer por la
   trx del llamante ES el agujero (🟠 8, medido)».** → **Gana el auditor** para la BARRERA; gana el
   analista para la ESCRITURA. Regla que los ordena: *la escritura va por tu transacción; la
   AUTORIDAD que decide si puedes escribir, nunca*. Carga de la prueba del cierre: un caso con un
   cliente inyectado que reporta «no congelado» debe ver la escritura **rechazada** (mutante:
   volver a pasar el cliente ⇒ ROJO).
2. **Analista «500 `E_AUTHZ_UNSUPPORTED`» vs Auditor «422 en la llamada».** → **Gana el analista**,
   por precedente del paquete (`membersOf`, `purgeRole`, `enumerateRelations`) y por la semántica del
   invariante 5. Verificado: `UnsupportedOperationError` es 500 en `errors.ts`.
3. **Analista «(A) conserva la higiene "un cambio de driver es migración, no reescritura"» vs
   Auditor «(A) tiene tres 🔴».** → **Gana el auditor**, y el steelman del analista se paga en otro
   sitio: la asimetría de call-site se declara y se hace fallar al ARRANCAR
   (`requireTransactionalWrites`), que es lo más cerca de la higiene que se puede llegar sin mentir.
4. **Analista «el spike T-0 decide el alcance; mi apuesta es la vista de catálogo no memoizable» vs
   la evidencia.** → **Descartada la apuesta.** `readFreezeRow` y el memo ya corren con deadline
   (`freeze.ts:119`, `catalog_cache.ts`), así que el modo de fallo con pool 1 es **503**, no el
   cuelgue que midió con knex crudo. T-0 deja de ser una incógnita que decide el alcance y pasa a ser
   un caso: *pool 1 + `{transaction}` ⇒ 503 clasificado, con deadline propio del caso para que no
   sea un timeout de CI*.
5. **Auditor «(C) "rechazar" no se consigue no declarando `transaction`; hoy el campo ya se consume»
   (⚪ 15 + 🟠 8) vs Analista «(C) no rompe a nadie».** → **Gana el auditor**: sin rechazo ACTIVO,
   (C) es una etiqueta. Por eso L-1 (quitar el cast) es **prerrequisito** de (C), no un extra.

---

## 5 · Afirmaciones descartadas, retiradas o degradadas

- **Analista §1 entera («COGNITIV despliega `database` ⇒ la pregunta de `openfga` no desbloquea a
  nadie»).** **RETIRADA por el encuadre del dueño**, no por falta de evidencia (la evidencia es
  buena y está bien citada): el criterio es inadmisible. La decisión de (C) se sostiene sola —una
  tupla no entra en una trx SQL— y **habría sido la misma** con un consumidor que desplegara
  `openfga`: lo que ese consumidor recibiría es el 500 y la receta por dirección, y ajusta.
- **Analista: «con el pool a 1 la suite se CUELGA ⇒ timeout de CI».** Degradada: medido con knex
  crudo, fuera de los guards del paquete. Por los caminos del paquete es 503. La conclusión
  operativa (`{transaction}` exige pool ≥ 2) **sobrevive**; la dramatización, no.
- **Auditor 🟠 5, 🟡 13, 🟡 14 y las preguntas 1-4.** Están **precondicionadas a (A)**, que queda
  descalificada. No se juzgan y no son deuda de hoy. (Si (A) volviera alguna vez, vuelven con ella.)
- **Auditor 🟡 12 (deadlock del UNIQUE de `authz_relations` con dos trx externas).** ❓ no medido
  (hace falta pg/mysql con pool ≥ 2). **No se descarta**: se convierte en caso obligatorio de L-3/L-4
  (dos `relate` A→B y B→A en trx externas ⇒ error **clasificado**, nunca un 503 disfrazado de
  indeterminado). Su corolario sí lo acepto entero: con `{trx}`, un 503 por deadline notifica
  `onWrite` con `indeterminate: true` (invariante 13) cuando la escritura **no** es indeterminada —el
  rollback la determina—; hay que decidir y fijar con caso qué se publica ahí.
- **Auditor 🟡 11 (`resolveChain` no recibe la transacción).** **NO se descarta: es el límite real de
  la ganadora** y aplica también al `database` «trivial» (verificado: `types.ts:843`). Ver §6.
- **Auditor ⚪ 16 (no hay marca de agua pública).** Sin efecto: solo importa con lag, y la ganadora no
  introduce ninguno.
- Del **analista** no descarto ninguna medición: las cinco tablas de latencia y el drenaje de 300
  hechos son el mejor insumo del panel y son lo que descalifica (A) con número en vez de con
  adjetivo.

---

## 6 · Riesgos que quedan aunque se implemente la ganadora

1. **`{trx}` es la primera capacidad NO portable entre drivers del paquete.** El mismo call-site es
   200 en `database` y 500 en `openfga`. Es el precio de no mentir y **el encuadre del dueño lo
   convierte en el diseño, no en un defecto** («cada driver declara, el cliente ajusta»). Mitigado
   con `requireTransactionalWrites` (falla al arrancar), no eliminado. Va al README con estas
   palabras y con un **caso de PARIDAD que fija la asimetría a propósito**.
2. **La decisión que autoriza la escritura no es atómica aunque la fila lo sea** (🟡 11). Dentro de
   `db.transaction`, crear el scope y conceder en él da **422 `E_AUTHZ_UNKNOWN_SCOPE`**, porque el
   `resolveChain` del consumidor lee por `db` y no ve su fila sin confirmar; y `within` se contrasta
   contra el árbol de ANTES. Es fail-CLOSED, pero es justo el caso de uso que se le supone a
   `{trx}`. **No cambio el puerto** (`ScopeChainResolver` es del consumidor y ya puede cerrar sobre
   su transacción — el propio paquete lo hace en su suite): se **DECLARA en el README con la
   receta**, y se fija con un caso que el 422 es el comportamiento correcto. Si algún día se decide
   pasarle el cliente, es cambio de config port ⇒ breaking ⇒ otra fase.
3. **La ventana del freeze se alarga a discreción del consumidor**: una escritura que pasó la
   barrera confirma cuando confirme *su* transacción, que pueden ser minutos. No es un defecto
   nuevo (`freeze()` promete «otro proceso recibe 503», no «ninguna escritura entra»), pero el brazo
   es más largo y la frase del README hay que ampliarla.
4. **`database` gana formas nuevas de envenenar la transacción del consumidor**: choque de UNIQUE,
   deadline vencido, `E_AUTHZ_FROZEN` tardío. Ninguna es incorrecta; todas son observables y nuevas.
5. **Pool ≥ 2 es un requisito de despliegue nuevo**, y los casos del par de capacidad **no corren en
   el modo por defecto de la suite**. Es exactamente el punto ciego de `freeze_multiprocess.spec.ts`:
   los jobs de motor de CI dejan de ser opcionales para esta capacidad también.
6. **F-05 sigue siendo un chokepoint** aun después de L-0: cada camino de escritura nuevo (relate en
   lote, otro reconcile) puede volver a saltárselo. El caso-exploit publicado en el runner es la
   única red.

---

## 7 · LOS LOTES, EN ORDEN

Cada lote: rojo→verde con mutante + typecheck + `npm test` + los 5 modos + `:8101` + tester +
auditor (**nunca en paralelo con quien mide ni con el implementador de R-15**) + `/code-review`.

### L-0 · F-05 con dientes en los DOS drivers de relaciones · **BLOQUEA, va primero**
Independiente de `{trx}`. Cierra la AC incumplida de la Fase 4.
- **AC:** `relate`/`unrelate` de `database` y de `openfga` rechazan **422** un `object.type` no
  declarado y una `relation` no declarada para ese tipo, **antes de tocar el backend** (cero
  `Write`, cero INSERT; espía); el **caso-exploit del auditor por el camino del DRIVER**:
  `driver.relate(evil,'assignee',{type:'role_binding',id:<roleUuid>},S)` ⇒ 422 y
  `roles.authorize(evil, …, S)` sigue `false` con el binding legítimo intacto, contra `:8101` y en
  el MISMO store; **`reconcileRelations` embuda por la misma validación** —una tupla de tipo no
  declarado NO se escribe en el destino y se **cuenta** (`skipped`, motivo declarado; hoy solo la
  reporta `modelDrift` y la escribe igual)—; el docblock de `types.ts:1521` pasa a ser **verdad**
  (no se borra: se cumple); **mutante:** quitar la guarda del driver ⇒ el caso-exploit ROJO en los
  dos drivers.

### L-1 · «¿De quién es esta conexión? ¿Quién decide la barrera?» · **BLOQUEA**
Los tres agujeros de la misma familia, antes de multiplicar su superficie con `{trx}`.
- **AC (🟠 8):** la barrera del freeze se lee **siempre por la conexión del motor**; un cliente
  inyectado que reporte «no congelado» **no** deja pasar la escritura (mutante: volver a pasarlo ⇒
  ROJO); con pool 1 la escritura sale **503 clasificado** con su deadline, jamás un cuelgue (caso
  con deadline propio); **desaparece el cast** de `manager.ts:1435`: `transaction` solo se lee de
  tipos que lo declaran; caso en **MySQL** (REPEATABLE READ real) que hoy no existe.
- **AC (🟠 9):** `enqueue` con un `trx` de otra conexión ⇒ **500 `E_AUTHZ_CONFIG`** nombrando las dos
  conexiones; pasar `db` entero como `transaction` ⇒ el mismo 500 (hoy pasa el duck-check y escribe
  fuera de toda transacción en silencio); la comprobación queda en **una sola función** reutilizable
  por el puerto nuevo.
- **AC (🟠 J1):** las escrituras de `RelationsManager` pasan la MISMA barrera del freeze que las de
  roles (503 `E_AUTHZ_FROZEN`, reintentable), con caso; `authz:relations:reconcile` corre bajo
  ventana durable **o** el README dice, con esas palabras, que su pasada **no se certifica**.
- **CHANGELOG:** el 503 nuevo con pool 1 y `{transaction}` en `scopes.*` va como **breaking de
  despliegue**, con el porqué.

### L-2 · La capacidad y las dos puertas, en los DOS puertos (pieza pura, sin BD) · camino crítico
- **AC:** `transactionalWrites` en las dos interfaces de capacidades; `transaction` **declarado** en
  `WriteOptions`/`RelationWriteOptions` con el docblock que distingue **encolar ≠ escribir**; driver
  falso con `false` + `{transaction}` ⇒ **500 `E_AUTHZ_UNSUPPORTED`** nombrando driver y operación,
  **cero llamadas al driver** (espía); `requireTransactionalWrites: true` + ese driver ⇒ **500
  `E_AUTHZ_CONFIG` al RESOLVER**; con el driver capaz, resuelve; el runner **falla** si se declara
  `true` sin `whenTrue` **y** si se declara `false` sin `whenFalse`; conteos de
  `contract_harness.spec.ts` y `relations_harness.spec.ts` actualizados **a literal**.

### L-3 · `database` · `roles/`: `grant`/`revoke`/`deny`/`removeDeny`
- **AC:** en **SQLite-file + PG + MySQL**: escritura en trx + `rollback` ⇒ `authorize` `false` **y
  cero filas** en `authz_assignments` (censo, no solo respuesta), para las cuatro; **caso de
  COMPOSICIÓN**: `revoke` + un `UPDATE` del consumidor + `rollback` ⇒ ni lo uno ni lo otro;
  `{transaction}` de otra conexión ⇒ 500 (§1.1); `E_AUTHZ_FROZEN` con `{transaction}` ⇒ **cero
  sentencias** por la trx del llamante; choque de UNIQUE de dos `grant` concurrentes ⇒ error
  **clasificado** y documentado como «envenena tu transacción»; **qué se publica en `onWrite` cuando
  vence el deadline dentro de una trx externa** (invariante 13 vs 🟡 12), decidido y fijado;
  **mutante obligatorio**: ignorar `{transaction}` y escribir por la conexión propia ⇒ el caso del
  rollback ROJO.

### L-4 · `database` · `relations/`: `relate`/`unrelate`/`purgeObject`/`purgeSubject`
**En SECUENCIA con el implementador de R-15** (toca el mismo `relate`).
- **AC:** mismos tres motores; `relate` + `rollback` ⇒ `check` `false` y cero filas; **el trigger de
  partición sigue disparando dentro de la trx del llamante** (caso de driver con `knex.raw`);
  `assertWrite`/F-05 que lanzan ⇒ **cero sentencias** por la trx del llamante; `purge*` con trx
  externa borran y revierten juntos; **caso de caducidad × trx** (R-15: renovar = delete+insert
  dentro de la trx del llamante, y el rollback devuelve la caducidad anterior); **deadlock A→B/B→A
  en PG y MySQL ⇒ error clasificado** (cierra el ❓ del auditor 🟡 12); **mutante**: reabrir la
  transacción interna con una externa presente ⇒ ROJO (con deadline propio del caso).

### L-5 · `openfga` · el rechazo con dientes, en los dos puertos
- **AC:** contra `:8101`, `grant`/`relate` con `{transaction}` ⇒ **500 `E_AUTHZ_UNSUPPORTED`** con
  **cero llamadas al cliente FGA** (espía) — la cara `whenFalse` poblada, **nunca un skip**;
  `requireTransactionalWrites: true` + `default: 'openfga'` ⇒ **no arranca**; **caso de PARIDAD que
  fija la asimetría a propósito**: la misma llamada es 200 en `database` y 500 en `openfga`, **y esa
  es la respuesta correcta**.

### L-6 · Docs: la receta por dirección, el README, el roadmap y el CHANGELOG
- **AC:** la tabla de §1.3 en el README, con su límite («no compone») y un caso que fija que el
  paquete **no lo automatiza**; el README no contiene la palabra «atómico» aplicada a `openfga` en
  ninguna forma (**grep**); la frase del freeze ampliada (§6.3); el límite de `resolveChain` dentro
  de una trx (§6.2) con su receta; `{transaction}` **exige pool ≥ 2** y los casos gateados, dicho en
  voz alta junto a la limitación para drivers de terceros; **`roadmap-2.0.md:103` reescrito**
  («falla al construirse» ⇒ «500 por llamada + 500 al resolver con `requireTransactionalWrites`»);
  CHANGELOG en el estilo 1.1.0 (problema → decisión → **qué NO se hace y por qué**) con **(A) y sus
  números como parte del "qué NO se hace"**; un caso fija la LETRA del 500 (patrón de
  `freeze.spec.ts`).

**Orden:** `L-0` → `L-1` → `L-2` → { `L-3`, `L-4` } → `L-5` → `L-6`.
L-3 y L-4 **no en paralelo**; L-4 **después** de R-15.

---

## 8 · Lo que necesita decisión del dueño (solo lo que cambia algo)

1. **¿Se acepta que `{transaction}` exija pool ≥ 2, y que sus casos NO corran en el modo por defecto
   de la suite (`:memory:` 1/1)?** Es el precio de que la barrera del freeze no la decida el
   llamante (🟠 8). Incluye un **breaking de despliegue de HOY**: `scopes.*` con `{transaction}` y
   pool 1 pasará a dar 503. *Mi recomendación: sí, con los jobs de motor de CI declarados
   obligatorios para esta capacidad.* Si la respuesta fuera «no», la única alternativa coherente es
   **no publicar `{trx}` en ningún puerto** y quedarse con la receta por dirección para los dos
   drivers — porque la otra salida (seguir leyendo la barrera por la trx del llamante) es publicar
   un bypass conocido.
2. **¿Se abre (F) —`authz_*` como log durable de hechos también en `facts`— como pregunta de 3.0, o
   se cierra?** Es la **única** vía por la que `openfga` podría llegar a tener `{trx}` de verdad, y
   su precio es la propiedad «los hechos viven en el PDP», firmada el 28-08. No afecta a este
   alcance en ningún caso. *Mi recomendación: anotarla como pregunta abierta de 3.0 y no tocarla
   ahora.*

**Lo que NO pregunto porque ya está contestado:** si `{trx}` puede ser no portable entre drivers.
La corrección del dueño de hoy —*«cada driver declara lo que puede y el cliente ajusta»*— **es** esa
respuesta, y es la que sostiene (C).
