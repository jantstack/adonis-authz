# Panel 2 · 28-08-2026 · Arquitectura — P1 construido, P4, P6, P7

> Entrada: `propuesta-jerarquia-hechos-2026-08-28.md`, `decisiones-dueno-2026-08-28.md`,
> `panel-2026-08-28-juez.md`, `CLAUDE.md`.
> **Todo el bloque P1 está EJECUTADO contra el OpenFGA de `:8101`** (`v1.19.0`, build
> `130c30ae`, datastore Postgres 18, `OPENFGA_PLAYGROUND_ENABLED=true`, sin
> `check-query-cache`). Stores temporales creados y **borrados** (verificado: `0` stores
> `p1-*` vivos al terminar).
> Leyenda: ✅ ejecutado · 🟡 razonado · ❌ no expresable / medido como imposible.

---

## 0. Titular (lo que cambia la decisión)

1. ✅ **El modelo `facts` completo ES expresable.** 53/53 aserciones verdes contra el
   servidor real: herencia solo hacia abajo, deny-wins heredado, caducidad por
   condición, holders polimórficos, deny por defecto, catálogo por tuplas editable en
   runtime, `move`, y `ListObjects` que sí enumera herencia.
2. ✅ **Las tres variantes de catálogo de la propuesta NO funcionan tal como están
   escritas.** (a) es imposible (error literal abajo), (b) valida pero siempre da
   `false`, (c) funciona pero con explosión O(scopes × roles × permisos). **La que
   funciona es una cuarta que no está en la propuesta**: el catálogo como *wildcard de
   usuario* en el tipo `role` (`role:<uuid>#permits_P@user:*`) intersectado con el
   binding. Una tupla por (rol, permiso, tipo de holder), global, editable en runtime.
3. ❌ **El "100 % de OpenFGA" NO es más rápido en la topología real del dueño.**
   Medido, cadena de 3 niveles: `facts` = **4,59 ms** p50 (1 Check) vs
   `resolver` con **un solo batchCheck** = **3,76 ms** p50 (18 checks). El cruce está
   en **profundidad ≈ 9**, cuando `cadena × (1+roles)` supera el tope duro de **50
   checks por batchCheck** y hace falta un segundo round-trip.
4. ❌ **El SQL del camino caliente que la propuesta quiere eliminar no es el coste.**
   `resolveAncestors` como CTE recursiva sobre un árbol de **9.841 scopes, profundidad
   9** en PostgreSQL 18: **0,07–0,14 ms** de servidor (medido, tres ejecuciones). El
   coste son los round-trips a FGA, no la base de datos.
5. ✅ **La ganancia grande está en el injerto ya decidido, no en `facts`:** pasar de los
   **2 batchCheck secuenciales de hoy** (6,35 ms p50) a **uno solo** (3,76 ms p50) es
   **−41 % con ~0,5 d**. El modo `facts` es **−22 % *peor*** en profundidad 3 y cuesta
   ~8 d.
6. 🟡 **`facts` rompe una regla de `CLAUDE.md`**: «El catálogo es local siempre… con
   OpenFGA solo se trasladan los HECHOS». En modo `facts` el catálogo (permisos como
   relaciones + vínculos rol→permiso como tuplas) **vive también en FGA**. Eso no es un
   detalle de implementación: es el invariante de propiedad de datos del paquete. Si el
   dueño aprueba `facts`, esa regla hay que reescribirla explícitamente.
7. ✅ **La ventaja real de `facts` no es latencia, es autonomía y enumeración**:
   `authorize` sin tocar la BD del consumidor (PDP separable — relevante para el
   appliance COGNITIV), `ListObjects` con herencia, e `isWithin`/`descendantsOf`
   **nativos y gratis** (relación `ancestor` computada de `parent`, **0 tuplas extra**,
   medido).

---

## 1. P1 · Las cuatro variantes de catálogo — resultado ejecutado

Store limpio por variante, modelo escrito, tuplas escritas, `Check` real.

| Variante | ¿Modelo aceptado? | ¿Funciona? | Evidencia |
|---|---|---|---|
| **(a)** wildcard en el lado **objeto** (`scope:*`) | ✅ el modelo sí | ❌ **la tupla no** | error literal abajo |
| **(b)** `role:R#grants_P@role:R` autorreferencial + TTU | ✅ | ❌ **check siempre `false`** | dead-end semántico |
| **(c1)** `role_binding` + `scope#<perm>_binding` (catálogo por scope) | ✅ | ✅ | pero O(scopes × roles × permisos) |
| **(c2)** `role_binding` + `scope#binding` + catálogo por **wildcard de usuario** en `role` | ✅ | ✅ **GANADORA** | 53/53 invariantes |

### (a) ❌ — error literal de FGA

```
POST /stores/<id>/write
{"writes":{"tuple_keys":[{"user":"role:editor","relation":"docs_read_role","object":"scope:*"}]}}

400 {"code":"validation_error","message":"Invalid tuple 'scope:*#docs_read_role@role:editor'.
     Reason: the 'object' field cannot reference a typed wildcard"}
```

Control ejecutado en el mismo store: la misma tupla con objeto concreto (`scope:app`)
**se acepta**. ⇒ el wildcard existe **solo en el lado usuario**. La opción (a) de la
propuesta está muerta, y lo está por diseño del servidor, no por versión.

### (b) ❌ — valida pero es un callejón semántico

Modelo aceptado (`01M14AZK3SF8DHPX8V1KENW4FY`). Tuplas escritas:

```
role:editor                     #grants_docs_read @ role:editor
role:editor                     #role             @ role_binding:org|A|editor
user:alice                      #assignee         @ role_binding:org|A|editor
```
con `define docs_read: assignee and grants_docs_read from role`.

`Check(user:alice, docs_read, role_binding:org|A|editor)` → **`false`**.

Razón: `grants_docs_read from role` devuelve un conjunto de objetos **de tipo `role`**
(`{role:editor}`), no de usuarios. Intersectarlo con `assignee` (usuarios) da siempre
vacío. **FGA no avisa**: el modelo se publica sin error y el sistema deniega en
silencio. Es exactamente el tipo de fallo que un spike de 30 minutos habría dado por
bueno leyendo la DSL.

### (c1) ✅ funciona, pero explota

`define <perm>: assignee from <perm>_binding or <perm> from parent`. Tupla de catálogo
por **(scope, rol, permiso)**. Funciona (`check = true` verificado). Coste medido en el
banco: 77 tuplas para 3 niveles × 5 roles × 4 permisos/rol. **Cambiar "el rol R concede
P"** obliga a reescribir tuplas en **todos** los scopes donde R está vinculado ⇒ es
runtime, sí, pero con fan-out O(scopes).

### (c2) ✅ **la que gana** — catálogo global por wildcard de usuario

El truco: la relación de catálogo vive en el tipo `role` y su *user* es el wildcard
tipado; la intersección con `assignee` en el binding recupera exactamente los sujetos
asignados **si y solo si** el rol concede el permiso.

```
type role
  define permits_docs_read: [user:*, admin:*, integration:*]

type role_binding
  define role: [role]
  define assignee: [user, admin, integration, ... with not_expired]
  define docs_read: assignee and permits_docs_read from role
```

Secuencia ejecutada en un store limpio (misma sesión, mismo store):

| paso | tuplas | `Check(alice, can_docs_read, scope:org\|A)` |
|---|---|---|
| árbol + binding + asignación, **sin catálogo** | 4 | **`false`** ✅ |
| `+ user:* #permits_docs_read @ role:editor` (**1 tupla**) | 5 | **`true`** ✅ |
| `- user:* #permits_docs_read @ role:editor` | 4 | **`false`** ✅ |

**Roles por tenant sin redeploy de modelo: ✅ confirmado.** El id del rol es su uuid
(`role:t1-admin`, `role:t2-admin`); dos roles con el mismo nombre lógico y permisos
distintos conviven y no se cruzan (casos 6.4–6.7). Encaja exactamente con el binding id
`role_binding:<scopeKey>|<roleUuid>` que el juez ya aprobó para `catalog/`.

**Nota de seguridad medida (caso 5.7):** el wildcard **no concede por sí solo**. Un
sujeto sin binding (`user:extranio`) da `false` aunque `role:R#permits_P@user:*` exista.
La intersección es la barrera. Verificado explícitamente porque un wildcard mal colocado
sería un fail-open global.

---

## 2. P1 · El modelo final

### 2.1 En DSL

Generado con `@openfga/syntax-transformer` **a partir del JSON que el servidor aceptó**
(no transcrito a mano). Mostrado con 2 permisos (`docs:read`, `docs:write`); el bloque
por permiso se repite:

```dsl
model
  schema 1.1

type user

type admin

type integration

type role
  relations
    define permits_docs_read: [user:*, admin:*, integration:*]
    define permits_docs_write: [user:*, admin:*, integration:*]

type role_binding
  relations
    define role: [role]
    define assignee: [user, admin, integration, user with not_expired, admin with not_expired, integration with not_expired]
    define docs_read: assignee and permits_docs_read from role
    define docs_write: assignee and permits_docs_write from role

type scope
  relations
    define parent: [scope]
    define binding: [role_binding]
    define docs_read: docs_read from binding or docs_read from parent
    define denied_docs_read: [user, admin, integration] or denied_docs_read from parent
    define can_docs_read: docs_read but not denied_docs_read
    define docs_write: docs_write from binding or docs_write from parent
    define denied_docs_write: [user, admin, integration] or denied_docs_write from parent
    define can_docs_write: docs_write but not denied_docs_write
    define ancestor: parent or ancestor from parent

condition not_expired(current_time: timestamp, valid_until: timestamp) {
  current_time < valid_until
}
```

Round-trip DSL→JSON verificado: idéntico salvo el **orden de claves** dentro de
`tupleToUserset` (`tupleset` / `computedUserset`) — semánticamente el mismo modelo.

**Coste en relaciones:** 5 por permiso (`permits_P` en `role`, `P` en `role_binding`,
`P` + `denied_P` + `can_P` en `scope`) + 5 fijas.

**`ancestor` no cuesta tuplas.** Es puramente computada de `parent` y da
`isWithin`/`descendantsOf` nativos (§5.4).

### 2.2 En JSON (lo que se `POST`ea a `/authorization-models`, 1 permiso)

```json
{
  "schema_version": "1.1",
  "type_definitions": [
    { "type": "user", "relations": {}, "metadata": null },
    { "type": "admin", "relations": {}, "metadata": null },
    { "type": "integration", "relations": {}, "metadata": null },
    {
      "type": "role",
      "relations": { "permits_docs_read": { "this": {} } },
      "metadata": { "relations": { "permits_docs_read": { "directly_related_user_types": [
        { "type": "user", "wildcard": {} },
        { "type": "admin", "wildcard": {} },
        { "type": "integration", "wildcard": {} }
      ] } } }
    },
    {
      "type": "role_binding",
      "relations": {
        "role": { "this": {} },
        "assignee": { "this": {} },
        "docs_read": { "intersection": { "child": [
          { "computedUserset": { "relation": "assignee" } },
          { "tupleToUserset": { "tupleset": { "relation": "role" },
                                "computedUserset": { "relation": "permits_docs_read" } } }
        ] } }
      },
      "metadata": { "relations": {
        "role": { "directly_related_user_types": [ { "type": "role" } ] },
        "assignee": { "directly_related_user_types": [
          { "type": "user" }, { "type": "admin" }, { "type": "integration" },
          { "type": "user", "condition": "not_expired" },
          { "type": "admin", "condition": "not_expired" },
          { "type": "integration", "condition": "not_expired" }
        ] },
        "docs_read": { "directly_related_user_types": [] }
      } }
    },
    {
      "type": "scope",
      "relations": {
        "parent": { "this": {} },
        "binding": { "this": {} },
        "docs_read": { "union": { "child": [
          { "tupleToUserset": { "tupleset": { "relation": "binding" },
                                "computedUserset": { "relation": "docs_read" } } },
          { "tupleToUserset": { "tupleset": { "relation": "parent" },
                                "computedUserset": { "relation": "docs_read" } } }
        ] } },
        "denied_docs_read": { "union": { "child": [
          { "this": {} },
          { "tupleToUserset": { "tupleset": { "relation": "parent" },
                                "computedUserset": { "relation": "denied_docs_read" } } }
        ] } },
        "can_docs_read": { "difference": {
          "base": { "computedUserset": { "relation": "docs_read" } },
          "subtract": { "computedUserset": { "relation": "denied_docs_read" } }
        } },
        "ancestor": { "union": { "child": [
          { "computedUserset": { "relation": "parent" } },
          { "tupleToUserset": { "tupleset": { "relation": "parent" },
                                "computedUserset": { "relation": "ancestor" } } }
        ] } }
      },
      "metadata": { "relations": {
        "parent":  { "directly_related_user_types": [ { "type": "scope" } ] },
        "binding": { "directly_related_user_types": [ { "type": "role_binding" } ] },
        "docs_read": { "directly_related_user_types": [] },
        "denied_docs_read": { "directly_related_user_types": [
          { "type": "user" }, { "type": "admin" }, { "type": "integration" } ] },
        "can_docs_read": { "directly_related_user_types": [] },
        "ancestor": { "directly_related_user_types": [] }
      } }
    }
  ],
  "conditions": { "not_expired": {
    "name": "not_expired",
    "expression": "current_time < valid_until",
    "parameters": {
      "current_time": { "type_name": "TYPE_NAME_TIMESTAMP" },
      "valid_until":  { "type_name": "TYPE_NAME_TIMESTAMP" }
    }
  } }
}
```

### 2.3 Forma de las tuplas (el "hecho" que se migra)

| Hecho | Tupla(s) | Quién la escribe |
|---|---|---|
| arista del árbol | `scope:<padre> #parent @ scope:<hijo>` | `scopes.attached/moved` |
| catálogo rol→permiso | `<holder>:* #permits_<P> @ role:<roleUuid>` (1 por holder type) | `syncAuthzCatalog` |
| binding activo en un scope | `role_binding:<scopeKey>\|<roleUuid> #binding @ scope:<scopeKey>` | `grant` (idempotente) |
| binding → rol | `role:<roleUuid> #role @ role_binding:<scopeKey>\|<roleUuid>` | `grant` (idempotente) |
| **asignación** | `<holder>:<uuid> #assignee @ role_binding:<scopeKey>\|<roleUuid>` `[with not_expired{valid_until}]` | `grant` |
| **deny** | `<holder>:<uuid> #denied_<P> @ scope:<scopeKey>` | `deny` |

`authorize` = **`Check(<holder>:<uuid>, can_<P>, scope:<scopeKey>, context={current_time})`**.

Un `grant` cuesta **3 tuplas** (dos idempotentes compartidas + la asignación). Hoy
cuesta 1. Es el precio de que FGA conozca el árbol y el catálogo.

---

## 3. P1 · Los 8 invariantes, con tuplas y resultado ✅

Store `p1-facts-invariantes`, modelo §2 con 3 permisos (`docs:read`, `docs:write`,
`audit:read`) y 3 holder types. Árbol:
`app → organization|org-a → {unit|unit-a1, unit|unit-a2}` y `app → organization|org-b`.
Catálogo: `r-editor` concede `docs:read` + `docs:write`; `r-viewer` no concede nada.

**Resultado global: `53/53 aserciones OK`.**

### 3.1 Herencia solo hacia abajo ✅

Tuplas: `role:r-editor#role@role_binding:organization|org-a|r-editor`,
`role_binding:…#binding@scope:organization|org-a`,
`user:alice#assignee@role_binding:organization|org-a|r-editor`.

| # | Check | Resultado |
|---|---|---|
| 1.1 | `can_docs_read @ scope:organization\|org-a` | `true` ✅ |
| 1.2 | `can_docs_read @ scope:unit\|unit-a1` (descendiente) | `true` ✅ |
| 1.3 | `can_docs_read @ scope:unit\|unit-a2` (descendiente) | `true` ✅ |
| 1.4 | `can_docs_read @ scope:organization\|org-b` (**hermana**) | `false` ✅ |
| 1.5 | `can_docs_read @ scope:app` (**ancestro**) | `false` ✅ |
| 1.6 | `can_audit_read @ org-a` (el rol no lo concede) | `false` ✅ |
| 1.7 | `can_docs_write @ org-a` (el rol sí lo concede) | `true` ✅ |

### 3.2 Deny explícito gana y hereda hacia abajo ✅

| # | Acción | Check | Resultado |
|---|---|---|---|
| 2.1 | `+ user:alice#denied_docs_read@scope:organization\|org-a` | org-a | `false` ✅ |
| 2.2 | (mismo) | unit-a1 | `false` ✅ |
| 2.3 | (mismo) | `can_docs_write` org-a | `true` ✅ (el deny es por permiso) |
| 2.4 | `- deny` | org-a | `true` ✅ **restaura** |
| 2.5 | `- deny` | unit-a1 | `true` ✅ |
| 2.6 | `+ deny en unit-a1` | org-a | `true` ✅ (**no sube**) |
| 2.7 | (mismo) | unit-a1 | `false` ✅ |
| 2.8 | (mismo) | unit-a2 (**hermana**) | `true` ✅ |

### 3.3 Caducidad por condición `not_expired` ✅

Tupla: `user:bob#assignee@role_binding:organization|org-b|r-editor with not_expired{valid_until}`.

| # | `valid_until` | `context.current_time` | Resultado |
|---|---|---|---|
| 3.1 | `2020-01-01T00:00:00Z` (**pasada**) | ahora | `false` ✅ |
| 3.3 | `2099-01-01T00:00:00Z` (**futura**) | ahora | `true` ✅ |
| 3.4 | `2099-01-01T00:00:00Z` | `2100-01-01T00:00:00Z` | `false` ✅ (**reloj inyectable gratis**) |
| 3.5 | `2099-…` | **sin `context`** | **400** ✅ |

Error literal de 3.5 — importante, es la bomba del riesgo 9 del juez:

```
400 {"code":"validation_error","message":"failed to evaluate relationship condition:
     'not_expired' - tuple 'role_binding:organization|org-b|r-editor#assignee@user:bob'
     is missing context parameters '[current_time]'"}
```

⇒ **en modo `facts`, TODA llamada (`Check`, `BatchCheck`, `ListObjects`) debe llevar
`context.current_time` siempre**, porque `can_P` atraviesa `assignee` condicionada. Hoy
el driver lo pone en los checks de rol pero **no** en los de deny (`openfga_driver.ts:441-445`
y `:670-674`); en `facts` eso deja de ser un bug latente y pasa a ser un 400 seguro.

### 3.4 Holders polimórficos ✅

`user:same-uuid` asignado en `unit|unit-a2`. Mismo uuid, otro tipo:

| # | Check | Resultado |
|---|---|---|
| 4.1 | `user:same-uuid` | `true` ✅ |
| 4.2 | `admin:same-uuid` | `false` ✅ |
| 4.3 | `integration:same-uuid` | `false` ✅ |
| 4.4 | deny sobre `admin:same-uuid` no afecta a `user:same-uuid` | `true` ✅ |

### 3.5 Denegación por defecto ✅ (con una salvedad de contrato)

| # | Situación | Resultado |
|---|---|---|
| 5.1 | sujeto sin ninguna asignación | `false` ✅ |
| 5.2 | rol sin permisos en el catálogo | `false` ✅ |
| 5.3 | **permiso desconocido** (`can_permiso_inexistente`) | **400, no `false`** ⚠️ |
| 5.4b | scope inexistente para FGA | `false` ✅ |
| 5.5 | binding sin la arista `scope#binding` | `false` ✅ **fail-closed** |
| 5.6 | al escribir la arista | `true` ✅ |
| 5.7 | wildcard del catálogo sin binding | `false` ✅ **no concede solo** |

Error literal de 5.3:

```
400 {"code":"validation_error","message":"invalid relation: relation 'scope#can_permiso_inexistente' not found"}
```

⇒ El invariante 5 («permiso desconocido → `false`, nunca throw») **lo cumple el driver,
no FGA**: el driver debe seguir consultando el catálogo local (o su memo) y devolver
`false` antes de llamar. Confirma que `findPermission` (o el memo) **sigue siendo
obligatorio en el camino caliente incluso en modo `facts`** — la promesa "un solo Check
sin SQL" es exacta solo con el memo del catálogo en memoria.

### 3.6 Catálogo por tuplas, no por modelo ✅

| # | Acción | Resultado |
|---|---|---|
| 6.1 | `r-viewer` sin vínculos | `false` ✅ |
| 6.2 | `+ user:*#permits_docs_read@role:r-viewer` (**1 tupla, runtime**) | `true` ✅ |
| 6.3 | `- ` la misma tupla | `false` ✅ |
| 6.4 | `role:t1-admin` (tenant 1) concede `docs:read` | `true` ✅ |
| 6.5 | `role:t1-admin` **no** concede `docs:write` | `false` ✅ |
| 6.6 | `role:t2-admin` (tenant 2, mismo nombre lógico) concede `docs:write` | `true` ✅ |
| 6.7 | `role:t2-admin` **no** concede `docs:read` | `false` ✅ |

**Roles por tenant sin tocar el authorization model: ✅ demostrado.**
Lo que **sí** obliga a modelo nuevo es **añadir un permiso** (§5.1).

### 3.7 `move` ✅

| # | Acción | Check | Resultado |
|---|---|---|---|
| 7.3 | `- scope:org-a#parent@scope:unit-a1`, `+ scope:org-b#parent@scope:unit-a1` | alice (grant en org-a) | `true → false` ✅ |
| 7.4 | (mismo) | bob (grant en org-b) | `false → true` ✅ |
| 7.5 | (mismo) | dora (grant **directo** en unit-a1) | `true` ✅ sobrevive |
| 7.6 | move de vuelta | alice | `true` ✅ restaura |

**Nota operativa medida:** FGA **rechaza borrar una tupla inexistente** —
`400 {"code":"write_failed_due_to_invalid_input","message":"cannot delete a tuple which does not exist…"}`.
⇒ `scopes.moved` no puede ser "borra la vieja y escribe la nueva" a ciegas: necesita
**leer el padre actual** (`Read({object:'scope:<hijo>', relation:'parent'})`, 1
round-trip, verificado) o tolerar el 400. Coste real de un `move`: **2 requests**.

### 3.8 `ListObjects` con herencia ✅ y truncamiento ✅

`ListObjects(user:alice, can_docs_read, scope)`
→ `scope:organization|org-a, scope:unit|unit-a1, scope:unit|unit-a2`

| # | Aserción | Resultado |
|---|---|---|
| 8.1–8.3 | incluye el scope del grant **y sus descendientes heredados** | ✅ |
| 8.4 | no incluye la hermana `org-b` | ✅ |
| 8.5 | no incluye el ancestro `app` | ✅ |
| 8.6 | con deny en `unit-a2`, lo **excluye** | ✅ |
| 8.7 | con **1.205 scopes** en el subárbol → devuelve **1.000**, en **13 ms**, **sin error ni token** | ✅ (trunca) |
| 8.8 | `Check` puntual sobre el hijo #1199 (fuera del truncado) → `true` | ✅ |

Esto es **la ventaja funcional real de `facts`**: hoy `listScopes` no puede enumerar
herencia (invariante 7 de `CLAUDE.md`), y en `facts` sí puede. Pero **el truncamiento
silencioso sigue exactamente igual que en el L0.7 que el juez ya aprobó corregir** —
1.000 de 1.205 sin señal alguna. `facts` **amplía la superficie del bug**, no lo cierra:
ahora hay una primitiva atractiva que devuelve la respuesta incompleta.

---

## 4. P1 · Latencia — facts vs resolver, medido contra el mismo servidor

Método: mismo proceso Node, mismo OpenFGA, un store por modo, 30 iteraciones de warmup
+ N medidas, round-trip HTTP incluido. Topología pedida: **cadena de 3 niveles, 5 roles
por nivel, 20 permisos** (4 permisos por rol). Permiso TRUE = solo lo concede un rol de
la **raíz** (peor caso: hay que subir toda la cadena). Permiso FALSE = no lo concede
nadie (peor caso: recorrido exhaustivo sin corto-circuito).

### 4.1 Profundidad 3 (la topología del enunciado) · N=200

| Modo | Requests | p50 | p95 | media |
|---|---|---|---|---|
| **`facts` (c2) · 1 Check · TRUE** | 1 | **4,59 ms** | 6,37 | 4,74 |
| `facts` (c2) · 1 Check · FALSE | 1 | 5,05 ms | 6,98 | 5,15 |
| `facts` (c2) · 1 Check · `HIGHER_CONSISTENCY` | 1 | 4,44 ms | 5,90 | 4,43 |
| `facts` (c1) · 1 Check · TRUE | 1 | 3,79 ms | 5,78 | 3,89 |
| **`resolver` · 1 BatchCheck (18 checks) · TRUE** | 1 | **3,76 ms** | 5,13 | 3,84 |
| `resolver` · 1 BatchCheck (18 checks) · FALSE | 1 | 3,78 ms | 5,37 | 3,87 |
| **`resolver` HOY · 2 BatchCheck secuenciales** | 2 | **6,35 ms** | 8,50 | 6,44 |
| línea base · Check trivial (1 tupla directa) | 1 | 2,85 ms | 3,51 | 2,69 |

**`facts` es un 22 % MÁS LENTO que el resolver con batch único.** Y `HIGHER_CONSISTENCY`
no cuesta nada medible (la caché de check está desactivada por defecto en este
servidor).

### 4.2 Escalado con la profundidad de la cadena

| Profundidad | checks del resolver | `facts` p50 | `resolver` p50 (nº requests) | Gana |
|---|---|---|---|---|
| 3 | 18 | 4,59 ms | **3,76 ms** (1) | resolver |
| 6 | 36 | 6,08 ms | **4,37 ms** (1) | resolver |
| 8 | 48 | 6,79 ms | **4,91 ms** (1) | resolver |
| **10** | **60** | **7,26 ms** | 8,41 ms (**2**) | **facts** |
| 20 | 120 | **10,52 ms** | 13,60 ms (**3**) | **facts** |

**El cruce está en el tope duro de `batchCheck`**, error literal:

```
400 {"code":"validation_error","message":"batchCheck received 60 checks, the maximum allowed is 50"}
```

`facts` gana **exactamente cuando `profundidad × (1 + roles_que_conceden) > 50`**. Con 5
roles eso es profundidad ≥ 9. Con 3 niveles y 5 roles (el caso del dueño), **no llega**.

### 4.3 El coste del SQL que se quiere eliminar

`resolveAncestors` como CTE recursiva, PostgreSQL 18, tabla `scopes(uuid, type,
parent_uuid)` con índice en `parent_uuid`, **9.841 nodos, profundidad 9**, hoja más
honda:

```
Time: 0.139 ms
Time: 0.084 ms
Time: 0.072 ms
```

**0,07–0,14 ms de servidor.** Más el round-trip local del pool (~0,2–0,5 ms). Es
**≈ 2 % del presupuesto de un `authorize`**. Las otras dos consultas SQL del camino
caliente (`findPermission` + `rolesGranting`) las elimina el **memo del catálogo** ya
decidido en `decisiones-dueno-2026-08-28.md`, y en `facts` **siguen haciendo falta de
todos modos** (§3.5, caso 5.3).

### 4.4 Lectura honesta para el dueño

> "El 100 % de OpenFGA" te cuesta **+0,8 ms por `authorize`** en tu topología y ~8 días
> de trabajo. La optimización que ya aprobaste (**un solo batchCheck** + memo) te quita
> **2,6 ms** por medio día. Si el objetivo era velocidad, `facts` es la opción cara y
> peor.

Lo que `facts` **sí** compra, y esto sí es real:

| Ganancia | Verificada |
|---|---|
| `authorize` **sin tocar la BD del consumidor** en el camino caliente (con memo de catálogo) — el PDP puede vivir separado | ✅ 1 solo Check |
| Latencia **constante** en profundidad y en nº de roles (no crece con el árbol) | ✅ §4.2 |
| `ListObjects` con **herencia** (hoy imposible) | ✅ §3.8 |
| `isWithin` / `descendantsOf` **nativos, 0 tuplas extra** | ✅ §5.4 |
| Reloj inyectable en el evaluador (`current_time` en context) | ✅ caso 3.4 |
| Deja de crecer el nº de checks al añadir roles por tenant | ✅ §4.2 |

Para el appliance COGNITIV (PDP soberano, on-premise, que no debe depender de la BD de
la app para decidir) **la primera línea es el argumento fuerte**. Para el resto de
proyectos del dueño, no compensa.

---

## 5. P6 · Qué NO se puede hacer (todo medido salvo donde se indica)

### 5.1 ❌ Un permiso nuevo es un authorization model nuevo

No hay forma de que el permiso sea un dato: es una **relación**. Consecuencias medidas:

- `syncAuthzCatalog` pasa a **publicar un modelo** además de escribir tablas.
- Catálogos distintos por entorno ⇒ **modelos distintos** ⇒ el `modelId` pineado en
  config deja de ser el mismo entre dev/CI/prod. O se usa "latest" (y se pierde el pin,
  que es una garantía de seguridad) o se gestiona un id por entorno.
- **Rompe la regla de `CLAUDE.md`**: «El catálogo es local siempre… con OpenFGA solo se
  trasladan los HECHOS». En `facts` el catálogo se **replica** en FGA. La regla hay que
  reescribirla, no interpretarla.
- Colisión de slugs (`docs:write` vs `docs_write` → misma relación `docs_write`): el
  sync **debe** rechazarla. 🟡 no ejecutado, pero es aritmética de la codificación.

### 5.2 ❌ Tope duro de ~720 permisos por el tamaño del modelo

Medido, mismo servidor, 3 holder types:

| Permisos | Relaciones | JSON | Resultado |
|---|---|---|---|
| 100 | 504 | 105 KB | ✅ 22 ms |
| 500 | 2.504 | 527 KB | ✅ 104 ms |
| **700** | 3.505 | 738 KB | ✅ |
| **750** | 3.755 | 791 KB | ❌ `272444 bytes vs 262144` |
| 1000 | 5.004 | 1.054 KB | ❌ `363694 bytes vs 262144` |

(las filas de 100/500/1000 se midieron sobre el modelo **sin** la relación `ancestor`; +1 relación y ~250 bytes, irrelevante para el techo)

```
400 {"code":"exceeded_entity_limit","message":"model exceeds size limit: 272444 bytes vs 262144 bytes"}
```

Límite del servidor: **262.144 bytes** de modelo serializado
(`OPENFGA_MAX_AUTHORIZATION_MODEL_SIZE_IN_BYTES`, subible pero es **dependencia de
infra del consumidor**). La variante (c1) aguanta algo más (~900 permisos) porque tiene
4 relaciones/permiso en vez de 5. **Un paquete genérico que no controla cuántos permisos
declara su consumidor tiene aquí un techo que debe validar y reportar en `sync`.**

### 5.3 ❌ Los límites de enumeración no mejoran; empeoran en superficie

- `ListObjects` **trunca a 1.000 sin señal** (medido: 1.000 de 1.205). Igual que hoy.
- `batchCheck` **tope 50 por request** (error literal §4.2).
- `Read` **no admite filtrar por `user` solo, ni por `relation` sola, ni por prefijo de
  tipo sin `user`**. Error literal:

```
400 {"code":"validation_error","message":"the 'tuple_key' field was provided but the object type
     field is required and both the object id and user cannot be empty"}
```

Lo que **sí** funciona (medido): `Read({object:'scope:', user:'scope:<X>', relation:'parent'})`
→ hijos directos de X. Y `Read` **sin `tuple_key`** → scan completo del store paginado.
⇒ **`authz:scopes:verify` es O(nodos) requests o un scan completo del store.** Es una
operación de mantenimiento, no algo que corra por request ni en cada deploy grande.
La propuesta la vende como "red de seguridad" sin dar su coste.

### 5.4 ✅ Lo que SÍ se puede y la propuesta no menciona: `ancestor` gratis

```dsl
define ancestor: parent or ancestor from parent
```

**0 tuplas propias.** Medido sobre `app → org|A → unit|1 → {team|x, team|y}`, `unit|2`, `org|B`:

- `ListObjects(scope:organization|A, ancestor, scope)` → `unit|1, unit|2, team|x, team|y` ✅
- `Check(scope:organization|A, ancestor, scope:team|x)` → `true` ✅ = **`isWithin` nativo**
- `Check(scope:organization|A, ancestor, scope:organization|B)` → `false` ✅

Es decir: en modo `facts`, las primitivas `isWithin`, `descendantsOf` y el purgado en
cascada de `scopes.detached` **salen del propio modelo**, sin CTE por dialecto y sin
`sqlDescendantsOf`. Eso es una **capacidad divergente entre drivers** que el
`capabilities` de la Fase 0 tiene que declarar.

### 5.5 ❌ `Write` no es idempotente — hay ventana de fail-closed

```
400 {"code":"write_failed_due_to_invalid_input","message":"cannot write a tuple which already
     exists: user: 'user:a', relation: 'assignee', object: 'role_binding:app|r1'…"}
```

Reescribir una tupla existente falla **aunque cambie la condición**. Un re-`grant` con
nueva `expiresAt` es **delete + write sin transacción de dos pasos**: entre ambos, el
sujeto **no tiene el rol**. Ya pasa hoy; en `facts` pasa igual. El invariante 6 del
contrato se cumple por trabajo del driver, no por el backend, y **tiene una ventana
observable**. Merece un caso del contrato con reloj/concurrencia (Fase 2.5).

### 5.6 🟡 Ciclos en `parent`: FGA los acepta y no cuelga, pero mienten

Escritas `scope:A#parent@scope:B` y `scope:B#parent@scope:A`: el `Check` devuelve
`false` sin colgarse (medido). Pero `ancestor` y `ListObjects` sobre un ciclo dan
resultados sin sentido. **El anti-ciclos sigue siendo responsabilidad del paquete**
(`hierarchicalScopeResolver` de la Fase 2), y en `facts` hay que ejecutarlo **en la
escritura** (`scopes.attached/moved`), no solo en la lectura.

### 5.7 ❌ El drift produce divergencia entre drivers con los MISMOS hechos

Escenario medido indirectamente por el caso 5.5: un scope que **existe en la BD** pero
cuya arista `parent` **no se escribió en FGA** ⇒ `database` hereda de `app`, `facts`
no. Mismo hecho, dos respuestas. Es fail-**closed** (bueno para seguridad) pero **rompe
la premisa del juez único**: la suite del contrato solo lo ve si hay un caso que fuerce
la desincronización a propósito. La propuesta lo llama "problema 1" y lo despacha con
`verify`; el coste real de `verify` está en §5.3.

### 5.8 ❌ Sin transacción común Postgres ↔ FGA

Ni con outbox se arregla del todo: el outbox convierte la inconsistencia inmediata en
consistencia eventual, no en atomicidad. (Fuera del alcance de P1; es P5.)

### 5.9 Lo que **no** rompe nada (buenas noticias verificadas)

- **No obliga a reescribir call-sites** — si `scopes.*` es obligatorio desde 2.0 en
  ambos drivers (§6).
- **No rompe el juez único** en ninguno de los 53 casos ejecutados.
- **No obliga a modelo nuevo por rol** (§3.6) — solo por permiso.
- El invariante 5 (deny por defecto) se cumple, con la salvedad de que el permiso
  desconocido lo filtra el driver, no FGA.

---

## 6. P4 · ¿La API `scopes.*` + `enumerateEdges` respeta la filosofía?

### 6.1 Sí en el fondo — y además cierra una incoherencia que ya existe

El diagnóstico de la propuesta es correcto y es el mejor argumento que tiene: **el árbol
es hoy el único hecho de autorización que no pasa por el paquete**. Grants, denies y
catálogo entran por el manager (por eso son migrables); el árbol lo lee cada driver por
su cuenta. `scopes.attached/moved/detached` habla en `ScopeRef`, que ya está en el
contrato: **cero vocabulario de dominio, cero acoplamiento a multi-tenancy**. Un
consumidor mono-scope llama a `attached` cero veces y no se entera.

### 6.2 No, ¿debe ser opcional en `database`? — **NO, y es el punto que decide**

**Steelman de "opcional":** obligar a `scopes.*` en `database` es imponer ceremonia a
quien nunca usará FGA; el driver SQL ya lee el árbol de las tablas del consumidor y no
necesita que nadie le avise. Es trabajo sin contraprestación.

**Por qué pierde:** si `scopes.*` es opcional en `database`, entonces migrar de
`database` a `openfga:facts` **obliga a añadir llamadas en todos los `create` / `move` /
`delete` de nodos del consumidor**. Eso es exactamente lo que prohíbe la regla de
`CLAUDE.md`: *«Un cambio de driver es migración de hechos, no reescritura. Si un plan
obliga a cambiar call-sites al cambiar de driver, está mal.»* La propuesta **se rompe a
sí misma** si `scopes.*` es opcional, y el propio requisito 3 del dueño ("que la
migración de uno a otro sea posible") deja de cumplirse en la dirección que importa.

**Y no es ceremonia gratuita:** en `database`, `scopes.detached` ejecuta `purgeScope`,
que es el hallazgo **N5** del auditor ya aprobado por el juez (hoy borrar un tenant deja
grants y denies vivos para siempre). El consumidor que llama a `scopes.*` en `database`
**gana algo hoy**, no solo opcionalidad futura.

**Recomendación:**

| Método | `database` | `openfga:resolver` | `openfga:facts` |
|---|---|---|---|
| `scopes.attached(child, parent)` | no-op + validación anti-ciclo | no-op | escribe `parent` |
| `scopes.moved(child, newParent)` | no-op + validación anti-ciclo | no-op | `Read` padre actual + delete + write (**2 requests**) |
| `scopes.detached(child)` | **`purgeScope` (real)** | `purgeScope` | `purgeScope` + borrar aristas del subárbol vía `ancestor` |

**Obligatorio en el contrato documentado para todos los drivers; barato en los que no lo
necesitan.** El `capabilities` de la Fase 0 declara `hierarchyFacts: true|false` y el
juez escribe el caso negativo correspondiente en vez de un `skip`.

### 6.3 `enumerateEdges` — sí, con tres correcciones

1. ✅ Es de la **misma naturaleza que `resolveAncestors`** (el consumidor declara su
   árbol), así que no introduce un concepto nuevo. Coherente.
2. 🟡 **Debe ser opcional en el tipo y obligatorio en la construcción**: el manager
   **falla al construirse** si `hierarchy:'facts'` y no hay `enumerateEdges`. Mismo
   patrón que el juez ya fijó para `requireTransactionalWrites`. Nunca un fallo en
   runtime en la primera escritura.
3. ❌ **Debe aceptar un filtro de subárbol**: `enumerateEdges(under?: ScopeRef)`. Sin
   él, `verify` y `reconcile` obligan a un scan completo del árbol del consumidor
   (millones de filas en un multi-tenant) y no hay forma de verificar un solo tenant
   tras un incidente.
4. ❌ **Falta una operación que la propuesta no tiene**: el bootstrap escribe **una
   tupla `parent` por nodo**, en lotes de ≤100 (límite de `Write`). Para 100k scopes son
   1.000 requests. `openfga:import` debe reportar progreso y ser **reanudable**, no un
   comando de un solo disparo con dry-run.

### 6.4 Un agujero de diseño que la propuesta no nombra

`scopes.attached` es **obligatorio también para los hijos directos de `app`**. FGA no
conoce la existencia del scope (caso 5.4b); si el consumidor crea una organización y
olvida llamar a `attached`, **los grants a nivel `app` no bajan a esa organización** y
nadie se entera: es un fail-closed silencioso. Caso del contrato obligatorio:
*"scope creado sin `attached` ⇒ `authorize` false en `facts` y true en `database`"* —
y es precisamente el caso que demuestra que el juez único necesita `capabilities`.

---

## 7. P7 · Coste real y en qué fase entra

### 7.1 Revisión de la estimación de conversación (~5 d)

| Partida de la propuesta | Estimado | Real | Por qué |
|---|---|---|---|
| Spike FGA | 0,5 d | **0 d** | ✅ hecho: este informe |
| `scopes.*` + `purgeScope` (manager + `database`) | 1,0 d | **1,0 d** | correcto; `purgeScope` en cascada necesita `enumerateEdges` o `descendantsOf` |
| Modo `facts` en el driver | 2,0 d | **3,0 d** | desglose abajo |
| `import` / `export` / `verify` | 1,0 d | **1,5 d** | `verify` necesita scan paginado (§5.3), `import` reanudable (§6.3.4) |
| Contrato de migración | 0,5 d | **0,75 d** | 3 combinaciones en CI |
| **No contabilizado** · pasar `runAuthorizationDriverContract` entero contra `facts` | — | **+1,5 d** | aparecen los casos 3.5, 5.3, 5.5, 6.4, deny+caducidad |
| **No contabilizado** · tercer job de CI (`database` / `openfga-resolver` / `openfga-facts`) | — | **+0,25 d** | |
| **Total** | **5,0 d** | **8,0 d** | |

Desglose del "modo `facts` = 3,0 d":

- generador del modelo desde `holderTypes` **+ catálogo de permisos** (hoy solo holders) — 0,5 d
- `syncAuthzCatalog` publica modelo + reconcilia tuplas `permits_*` + rechaza colisión de
  slugs + valida el techo de §5.2 — 1,0 d
- `grant`/`revoke` con 3 tuplas, idempotencia y limpieza del binding huérfano — 0,5 d
- `authorize` con `context` **siempre** + traducción del 400 de relación desconocida a
  `false` vía memo de catálogo — 0,25 d
- pin de `modelId` + "el store tiene un modelo que no cuadra con el catálogo" — 0,5 d
- `listScopes`/`listSubjects` sobre el modelo nuevo (los ids de binding cambian) — 0,25 d

### 7.2 Prerrequisitos duros (no negociables)

1. **Fase 0 del juez (2 d)** — `level` + `capabilities` + "capacidad `false` ⇒ caso
   negativo". Sin esto, `facts` es un tercer driver **sin juez**, y ya se ha visto que
   diverge en casos reales (§6.4, §5.7).
2. **Fase 3 · `catalog/` (binding id por uuid)** — el modelo `facts` usa
   `role_binding:<scopeKey>|<roleUuid>` y `role:<roleUuid>` (probado con uuids).
   Hacer `facts` **antes** de C obliga a migrar los ids de las tuplas **dos veces**.
3. **Decisión del dueño sobre la regla de `CLAUDE.md`** (§5.1). Es una decisión de
   arquitectura, no de implementación.

### 7.3 Dónde entra

| | Recomendación |
|---|---|
| **Versión** | **2.2** (después de `catalog/` = 2.1) |
| **Fase** | Nueva Fase 3b, **después** de la Fase 3 y **antes** de `relations/` |
| **Coste total** | **8 d** + los prerrequisitos ya planificados |
| **Camino crítico** | No lo es. Nada de lo aprobado por el juez depende de `facts` |

Y una precisión importante: **`facts` NO sustituye al modo `resolver`; lo añade.** El
paquete pasa a tener **tres** configuraciones evaluables por el contrato
(`database`, `openfga:resolver`, `openfga:facts`), lo que multiplica por 1,5 el coste de
mantenimiento de cada caso nuevo del juez, para siempre. Con **un solo consumidor real**
(COGNITIV), eso es exactamente el argumento que el propio juez usó contra `relations/`
(riesgo 8).

---

## 8. Lo que recomiendo al dueño

### ✅ Hacer ya (ya decidido, no depende de esto) — ~0,5 d, ganancia medida

- **Fusionar los dos `batchCheck` en uno**: **6,35 ms → 3,76 ms p50** (−41 %), medido.
- **Memo del catálogo** invalidado en `syncAuthzCatalog`: −2 SQL por `authorize`.
- **Trocear el batch a 50** y **poner `context` también en los checks de deny** — hoy no
  lo lleva (`openfga_driver.ts:441-445`, `:670-674`) y con deny+caducidad da 400 → 503.

### 🟡 Aprobar `facts` sí, pero por la razón correcta y en su sitio

Apruébalo si lo que quieres es **un PDP que decide sin tocar la BD de la aplicación**
(el appliance COGNITIV) y **enumeración con herencia**. **No** lo apruebes si lo que
quieres es latencia: en tu topología es más lento.
Sitio: **2.2, después de `catalog/`**, 8 d, con `capabilities` de la Fase 0 ya en su
sitio.

### ❌ No hacer

- No hacer `scopes.*` opcional en `database` (§6.2) — rompe la propia propuesta.
- No usar la variante (a) ni la (b) del documento: (a) es imposible, (b) deniega en
  silencio.
- No hacer `facts` el default. El default sigue siendo `database`.

### ❓ Lo que necesito que decidas antes de que esto se implemente

1. **¿Aceptas reescribir la regla «el catálogo es local siempre» de `CLAUDE.md`?** En
   modo `facts` el catálogo se replica en FGA. Es la única incoherencia de fondo, y es
   tuya, no técnica.
2. **¿Cuál es la profundidad máxima real de tus jerarquías?** Si es ≤ 8 niveles con ≤ 5
   roles por nivel, `facts` no te da latencia. Si tienes un caso de 10+, cambia el
   cálculo.
3. **¿Cuántos permisos declara COGNITIV?** Si se acerca a 700, el techo de §5.2 pasa de
   nota a bloqueante y hay que tocar la config del servidor FGA.

---

## Anexo A · Cómo reproducirlo

Scripts en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/p1/`
(efímeros): `fga.mjs` (cliente HTTP crudo), `models.mjs` (generadores A/B/C1/C2 y el del
driver actual), `variants.mjs`, `invariants.mjs` (53 aserciones), `bench.mjs`
(`DEPTH=n N=m node bench.mjs`), `limits.mjs`, `ceiling.mjs`, `read.mjs`, `read2.mjs`,
`read3.mjs`, `dsl.mjs`.

Todos crean su store, lo usan y lo **borran en `finally`**. Verificado al terminar:
`0` stores `p1-*` vivos.

## Anexo B · Hallazgo de higiene (fuera de P1)

`GET :8101/stores` devuelve **92 stores llamados `authz-contract`** + 6 `contract-<ts>`,
todos del 26-08. **La suite del contrato crea un store por ejecución y no lo borra
nunca.** Con `MAX_RESULTS=3` en el segundo OpenFGA de CI (Fase 0) esto crecerá más
rápido. Arreglo trivial: `teardown` que llame a `DELETE /stores/<id>`. Debería entrar en
la Fase 0 junto con el harness.
