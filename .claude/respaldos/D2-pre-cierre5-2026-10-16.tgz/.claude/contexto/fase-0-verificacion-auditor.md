# Fase 0 · Verificación adversarial (auditor-seguridad) — 2026-08-28

Rama `v2/fase-0`, working tree sin commit. Node 22.23.2, OpenFGA local `:8101` (29 stores al empezar).
Misión: romper la **garantía** de la fase, no el paquete. Nada del repo fue modificado; todos los
experimentos corren sobre copias en el scratchpad.

## Veredicto en una línea

**APTA CON CORRECCIONES** — producción intacta y verificable, pero la garantía de la fase ("suite verde")
no es reproducible (rojo intermitente ~30-40 % bajo carga) y tres piezas prometen en CHANGELOG/comentarios
más de lo que los tests demuestran.

---

## Hallazgos (ordenados por severidad)

### 🟠 A1 · La suite entregada no es determinista: roja bajo contención de máquina

- **Escenario**: máquina cargada (durante mi ventana de medición había ~40 procesos node de otros
  agentes en la caja, 11:19–11:26) → `npm test` sin OpenFGA y sin tocar nada → **rojo**, y el rojo
  se atribuye al DRIVER, no al arnés:
  - `authorization contract [database] / listSubjects: holders vigentes del rol en el scope exacto`
    → `expected [ …(3) ] to deeply equal [ …(2) ]`: aparece un tercer holder (el **expirado**).
    Leído literalmente, eso es una violación del invariante 3.
  - `truncationSignal:false + listas exhaustivas: 1.200 …` → `expected [ …(1000) ] to deeply equal [ …(1200) ]`.
  - En otras ejecuciones, 7–10 casos caen con
    `memoryScopeTree: el padre organization:<uuid> no existe en el árbol` dentro de `unitUnder`
    (`src/testing/contract.ts:123`). Ese error **solo** puede ocurrir si `tree` (el `let` del grupo,
    `src/testing/contract.ts:160`) se reasigna entre dos `await` del mismo test — es decir, si un
    `group.each.setup` corre solapado con un test en vuelo.
- **Evidencia**: ✅ observación — 16 ejecuciones rojas (`63` tests: 10, 7, 7, 3, 1, 2 fallos según la
  corrida) sobre el working tree sin modificar; control: `git archive HEAD` a scratchpad → **10/10 verde**;
  working tree en máquina tranquila → ~90 ejecuciones verdes (30 seguidas, 16 en paralelo, con 24 quemadores
  de CPU, con heap de 48 MB, pinned a 1 core). ❓ **causa raíz no confirmada**: descarté timeout de Japa
  (`--timeout 1` produce otro patrón de fallos, en `manager`/`middleware`), colisiones de `uuidv7`
  (0 duplicados en 200.000) y un tope de 1.000 en el driver (con 20.000 filas en una copia devuelve las
  20.000). El test de `listSubjects` aislado pasa 15/15.
- **Steelman del defensor**: *"Es ruido de tu máquina; en un runner limpio la suite es verde, y de hecho
  tú mismo la has visto verde 90 veces."* → **No me convence**. Primero, los runners de GitHub son 2 vCPU
  compartidos y el job `openfga` ahora corre **dos** suites completas seguidas. Segundo, y más grave: el
  modo de fallo no es un timeout honesto, es un **resultado falso atribuido al driver** — un `listSubjects`
  que devuelve un holder expirado. Un juez que produce falsos negativos indistinguibles de defectos reales
  destruye exactamente lo que la Fase 0 vende. Y si puede dar un falso negativo, la simetría obliga a
  preguntarse por el falso positivo.
- **Mitigación mínima**: estado por test en lugar de `let tree/driver` del grupo (crearlos dentro del caso,
  o un objeto por test), y un `group.each.teardown` que afirme que las tablas `authz_*` quedan vacías: si
  hay contaminación, falla el test culpable y no el siguiente.

### 🟠 A8 · `openfga_prune_stores.mjs` borra por defecto, contra una URL de entorno, y `--prefix ""` lo borra todo

- **Escenario**: precondición → el script se commitea con `--dry-run` **no** por defecto y `options.url`
  tomado de `process.env.OPENFGA_TEST_URL` (la misma variable que exporta `.github/workflows/ci.yml`).
  Acción → `node scripts/openfga_prune_stores.mjs --prefix ""`. Resultado → el guard
  `if (options.prefixes.length === 0)` pasa (longitud 1) y `store.name.startsWith('')` es `true` para
  todos: borra los **29** stores de `:8101`, incluido `api-loco-base` (de otro proyecto).
- **Evidencia**: ✅ reproducido en dry-run contra `:8101`:
  `http://localhost:8101: 29 stores, 29 con prefijo '' (dry-run: no se borra nada)`.
  Variantes también verificadas: `--prefix` como último argumento → `startsWith(undefined)` → prefijo
  literal `'undefined'`; `--prefix --dry-run` consume el flag como valor y **pierde el dry-run**.
- **Steelman**: *"es una herramienta one-shot de mantenimiento que ejecuta el dueño una vez."* → **A medias**.
  El fichero entra en el repo con un comentario que promete "Solo toca stores cuyo nombre empieza por alguno
  de los prefijos dados: nunca borra 'todo'", y eso es falso. El riesgo real no es el prefijo vacío
  deliberado: es `OPENFGA_TEST_URL` apuntando a un servidor compartido y un prefijo genérico
  (`--prefix contract` también casaría con un store `contracts-prod`).
- **Mitigación mínima**: rechazar prefijos vacíos/`undefined` y exigir `--force` para borrar (o invertir el
  default a dry-run).

### 🟡 A2 · Los casos "reescritos sobre el árbol" no castigan a un driver que ignora el árbol

- **Escenario**: precondición → driver cuyo `makeDriver(tree)` **descarta** el árbol inyectado y usa el
  resolutor plano de 1.x (`app → []`, resto → `[APP_SCOPE]`). Acción → correr el juez a nivel `'2.0'`.
  Resultado → **28 de 32 verdes**, incluidos los 19 `core` completos (casos 9, 10, 11, 14, 15, 16, 18, 19,
  los ocho que F0.2 dice haber "reescrito sobre `tree`"), **N1** ("herencia de dos niveles: grant en app
  autoriza en una unit bajo una org"), **N6** e **I7set**. Solo lo detectan 4 casos: N1b, N2, N4 y N5.
- **Evidencia**: ✅ reproducido (copia del working tree con `ancestorsFrom` sustituido por el resolutor
  plano): `Tests 28 passed, 4 failed (32)`.
- **Por qué importa**: el comentario de N1 en `src/testing/contract.ts:434-437` afirma *"El resolutor plano
  de 1.x solo producía cadenas de longitud 2; con el árbol del juez la cadena es unit → org → app. Este caso
  ES el par `hierarchyFacts: false`"*. No lo es: N1 concede `editor@app` y pregunta en `unit`; el resolutor
  plano devuelve `[app]` para `unit` y el caso pasa igual. El CHANGELOG lo repite hacia fuera:
  *"Verified: with an empty tree, the inheritance cases now fail in both drivers — they no longer pass by
  accident"*. El informe del implementador es honesto (hizo falta cambiar además el fallback a `[]`); el
  CHANGELOG, que es lo que lee un tercero, no.
- **Steelman**: *"el fallback `?? [APP_SCOPE]` es obligatorio hasta L0.3 (Fase 1), y con 4 casos rojos ya
  basta para detectar a ese driver."* → **A medias**: basta para detectarlo, sí. Pero entonces la frase del
  CHANGELOG y el comentario de N1 son falsos, y son justamente lo que un autor de driver de terceros usará
  para creer que está cubierto.
- **Mitigación mínima**: que N1 conceda `org-editor@org` (como N1b) en vez de `editor@app`, y corregir la
  frase del CHANGELOG a lo que dice el informe.

### 🟡 A3 · "Jamás un `skip`" es falso: 4 de 5 capacidades no tienen ningún caso, y la quinta la apaga el propio harness

- **Escenario**: precondición → harness de tercero con las 5 capacidades en `false` y sin `exhaustiveLists`
  (el valor por defecto, y exactamente lo que declara el harness `openfga` de este repo). Acción → correr el
  juez. Resultado → se registran **cero** casos de capacidad. `caseFor` solo existe para `truncationSignal`
  (`src/testing/contract.ts:579-610`) y su rama `whenFalse` empieza con `if (!harness.exhaustiveLists) return`.
  `hierarchyFacts`, `transactions`, `singleCheckAuthorize` e `injectableClock` no tienen caso ni `true` ni `false`.
- **Evidencia**: ✅ lectura del código + `npm test` (el caso de 1.200 solo aparece para `database`) y
  `OPENFGA_TEST_URL=… npm test` → 101 tests, ninguno de capacidad para `openfga`.
- **Lo que sí responde a tu pregunta 3**: el par `false` **no** codifica el fail-open del truncamiento como
  aceptado — pero tampoco lo niega: no afirma nada. Y ningún test verde de hoy tendría que estar rojo para
  ser honesto: hoy nada enumera más de 3 objetos, así que el defecto L0.7 simplemente no se toca. La forma
  de esquivar el par no es "declarar `true`" (eso lo rechaza `PENDING_TRUE_PAIRS`, que cubre las 5): es
  **omitir `exhaustiveLists`**, un flag fuera de `DriverCapabilities` y por tanto fuera de la regla.
  La opción segura por defecto es la de ser juzgado menos.
- **Steelman**: *"los pares llegan en su fase y está documentado en el código, con `PENDING_TRUE_PAIRS`
  como guardia ejecutable."* → **Convence para el código**, no para el CHANGELOG, que afirma *"For every
  capability the suite holds a pair of cases `{whenTrue, whenFalse}` … declaring `false` is verified too,
  and there is never a `skip`"*. Eso es cierto para 0 de 5 capacidades hoy.
- **Mitigación mínima**: mover `exhaustiveLists` dentro de `DriverCapabilities` (para que la regla lo
  gobierne) y ajustar el CHANGELOG a "hoy solo `truncationSignal` tiene par, y solo para harness sin tope".

### 🟡 A4 · `level` por defecto `'core'`: el veredicto más débil es el default y no se anuncia

- **Escenario**: un tercero migra a 2.0 (obligado, porque `capabilities` es requerido), no escribe `level`
  → corre 19 casos que, por A2, ni siquiera exigen que el driver mire el árbol → publica "pasa el contrato
  de @jantstack/adonis-authz 2.0". Nada en el nombre del grupo ni en la salida dice a qué nivel se le juzgó.
- **Evidencia**: ✅ `src/testing/contract.ts:147` (`harness.level ?? 'core'`) y `163-165` (`since`).
- **Steelman**: *"sin el default `core`, cada caso nuevo del juez sería un major para terceros."* →
  **Convence el mecanismo**, no la ausencia de señal: en un major que ya rompe la firma, el default podría
  ser el nivel máximo y la degradación explícita.
- **Mitigación mínima**: incluir el nivel en el título del grupo (`authorization contract [x · core]`).

### 🟡 A5 · Llamar al juez fuera del top level produce un juicio vacío y silencioso

- **Escenario**: precondición → un harness llama a `runAuthorizationDriverContract` dentro de un test o de
  un hook (es lo que hace `tests/contract_harness.spec.ts`, a propósito). Acción → si la llamada no lanza,
  Japa **descarta** los casos registrados tarde. Resultado → suite verde con **cero** casos de contrato
  ejecutados.
- **Evidencia**: ✅ reproducido: en una copia, cambiando `truncationSignal: true → false` en
  `tests/contract_harness.spec.ts`, el juez registra sus 19 casos `core` y el total sigue siendo **63**
  (`62 passed, 1 failed` — el único fallo es el `assert.throws`). Los 19 no corren y nadie lo dice.
- **Steelman**: *"nadie llama al juez desde dentro de un test."* → **No me convence**: el propio repo lo
  hace, y la firma pública no documenta que deba invocarse en el top level del `.spec`.
- **Mitigación mínima**: una línea en el docblock de `runAuthorizationDriverContract` ("invócalo en el nivel
  superior del fichero de test").

### 🟡 A6 · `check_purity.mjs` se auto-desactiva en silencio si se invoca por una ruta con symlink

- **Escenario**: precondición → el repo (o el script) se alcanza a través de un symlink: `/var/www/pkg ->
  /home/jose/…`, un workspace enlazado en CI, `npm --prefix`. Acción → `node scripts/check_purity.mjs`
  (lo que hace `npm test` y `npm run build`). Resultado → `path.resolve(process.argv[1])` (ruta con symlink)
  ≠ `fileURLToPath(import.meta.url)` (ruta real que Node resuelve al cargar el módulo) → `invokedDirectly`
  es `false` → **el script no imprime nada y sale 0**. El guard queda desactivado sin un solo mensaje.
- **Evidencia**: ✅ reproducido:
  `node <scratch>/link-repo/scripts/check_purity.mjs` → salida vacía, `exit=0`;
  `node /home/jose/proyectos/Personal/adonis-authz/scripts/check_purity.mjs` → `✔ purity: …`, `exit=0`.
- **Y responde a tu pregunta 4 sobre el falso verde en CI**: `tests/purity.spec.ts` **no puede** detectarlo,
  porque construye `SCRIPT` desde `new URL('../scripts/check_purity.mjs', import.meta.url).pathname`, es
  decir siempre invoca el script por su realpath. Además, los dos casos "positivos" del spec
  (`status === 0`) pasarían aunque el script estuviera completamente muerto; solo los dos negativos lo
  detectan. Los fixtures en `os.tmpdir()` en sí no son el problema.
- **Steelman**: *"es higiene de build, no autorización, y nadie ejecuta por symlink."* → **No me convence**:
  es un *fail-open silencioso* de la única barrera que la fase acaba de meter en `npm test`. Un guard que
  falla abierto sin ruido es peor que no tenerlo, porque se confía en él.
- **Mitigación mínima**: comparar contra `fs.realpathSync(process.argv[1])`.

### 🟡 A7 · Las dos reglas de pureza se esquivan con las formas de import que este mismo repo usa

- **Escenario**: precondición → un módulo futuro bajo `src/relations/`. Acción → escribir sus imports así:
  `await import('../manager.js')` · `import x from "../manager.js"` (comillas dobles) ·
  `import y from '../manager'` (sin extensión) · re-export transitivo vía `src/shared/reexport.ts` ·
  `await import('#config/authorization')` · `import '#start/kernel'` (efecto lateral, sin `from`) ·
  `require('#models/user')`. Resultado → `node scripts/check_purity.mjs --root <fixture> --module relations`
  → **`✔ purity: …`, exit 0**. Las siete formas pasan.
- **Evidencia**: ✅ reproducido con fixture en scratchpad. Las regex son `from\s+'#[^']+'` (regla 1) y
  `from\s+'(\.{1,2}\/[^']+)'` + `^src\/manager\.(ts|js)$` (regla 2). Nota: `src/drivers/` **sí** se detecta
  sin extensión, porque su patrón es un prefijo; `src/manager` sin extensión no.
- **Agravante**: el import dinámico es *el* idiom de este paquete (`await import('@openfga/sdk')` en el
  driver, `await import('@adonisjs/lucid/services/db')` en `tests/helpers/schema.ts`), o sea que la forma
  más probable de introducir la violación es justo la que no se vigila.
- **Steelman**: *"es higiene, y `tests/purity.spec.ts` demuestra que la regla detecta la violación."* →
  **No me convence**: los 4 casos del spec solo cubren la forma canónica, y la regla 2 es nueva: nace con
  seis agujeros y con un test que certifica que funciona.
- **Mitigación mínima**: añadir `import\s*\(` y comillas dobles a ambas regex y normalizar la extensión al
  resolver el destino de la regla 2.

### ⚪ A9 · El segundo OpenFGA de CI no ejercita nada hoy (y el primero está calibrado al filo)

`harness.limits` se declara (`src/testing/contract.ts:77`) y se asigna (`tests/contract.spec.ts:305`) pero
**nunca se lee** (grep exhaustivo: esas dos únicas apariciones). Con `MAX_RESULTS=3` ningún caso enumera más
de 3 objetos (`listScopes` como mucho 2, `listRoleScopes` 1), así que la segunda pasada es verde por
construcción y **seguiría verde si el driver truncara**. El comentario del YAML ("con 3 se reproduce con
cuatro tuplas") describe la Fase 1, no lo que hace el job. Coste: duplica el job `openfga`. Y el propio
informe avisa de que con `=1` caen 3 casos: el margen es de exactamente una tupla, así que cualquier caso
nuevo con 4 asignaciones directas pondrá CI en rojo por una causa ajena al caso.

### ⚪ A10 · `memoryScopeTree`: colisión de claves, rama muerta y API sin uso

`key(scope)` concatena `${type}:${uuid ?? ''}` sin escapar, así que dos `ScopeRef` distintos pueden colisionar
(`{organization, null}` vs `{organization, ''}`; `{'a:b','c'}` vs `{'a','b:c'}`). Una colisión rompe el
anti-ciclo de `link()` y `ancestorsOf` no tiene conjunto de visitados → bucle infinito. Es árbol de test, pero
se **publica en `./testing`** como referencia. Además: la rama
`chain.at(-1)?.type === APP_SCOPE_TYPE ? chain : null` (líneas 97-99) es inalcanzable — `detach` borra los
descendientes y `link` exige padre conocido, así que toda cadena termina en `app` por inducción; y `edges()`
no lo usa nadie. Sobre tus preguntas concretas: **no** acepta ciclos, **no** deja huérfanos que hereden de
`app` (un scope desconocido devuelve `null`, y el `?? [APP_SCOPE]` que lo convierte en herencia de `app` está
en el harness, no en el árbol), y **rechaza** `app` como hijo. Los tres están cubiertos por
`tests/scope_tree.spec.ts`.

### ⚪ A11 · Higiene del commit

`CLAUDE.md` sigue **sin trackear** (`?? CLAUDE.md`): los invariantes innegociables viven solo en esta máquina
y no entran en el commit salvo que se añadan a mano. `.gitignore` pasa a excluir `.claude/contexto/`
(plan, informe, paneles y este informe quedan fuera de git, coherente con CLAUDE.md pero conviene decidirlo
explícitamente). `package-lock.json` **elimina** campos `libc` de dependencias opcionales: artefacto de una
versión distinta de npm que entra como ruido en el diff de la fase.

### ⚪ A12 · Un parche de espía sin `finally`

`tests/contract.spec.ts:276-283` (test de escritura concurrente) sustituye `client.read` y restaura *dentro
del propio fake*: si `grant` dejara de llamar a `read`, el parche sobrevive al resto del test. Radio de daño:
un test, porque el driver se reconstruye en cada `each.setup`. `withFailing` (restaura en `finally`) y
`countCalls` (usado con `try/finally` en `tests/spies.spec.ts`) sí están bien.

### ❓ A13 · Anomalía sin explicar en el conteo de tests

La **primera** ejecución de `npm test` de mi sesión reportó `Tests 82 passed (82)`; las ~90 posteriores,
`63`. `82 = 63 + 19`, y 19 es exactamente el número de casos `core` de un harness adicional. No lo pude
reproducir en ninguna de las ~90 ejecuciones siguientes, ni forzando el registro tardío (ver A5, que da 63).
Lo dejo anotado porque, si el conteo de casos del juez no es determinista, la métrica "63/63" del informe no
es verificable.

---

## Lo que intenté y NO se rompió

- **Producción intacta**: `git diff --stat` + `git status --short src/` → bajo `src/` solo
  `src/testing/contract.ts`, `src/testing/main.ts` y el nuevo `src/testing/scope_tree.ts`.
  `src/drivers/*`, `src/manager.ts` y `src/catalog.ts` sin tocar. `npm run typecheck` exit 0.
- **`./testing` no arrastra el peer opcional**: `contract.ts` y `scope_tree.ts` solo importan `../types.js`,
  `@japa/*` y `uuid`. Ningún camino de `./testing` importa `@openfga/sdk` ni un driver.
- **OpenFGA verde y sin fugas**: `OPENFGA_TEST_URL=http://localhost:8101 npm test` → **101/101**, stores
  **29 → 29** medido con `curl :8101/stores` antes y después. El teardown de F0.6 funciona.
- **CI**: los dos contenedores tienen nombre (`openfga` / `openfga-tiny`) y puerto (8090 / 8091) distintos;
  el bucle de healthz falla el job con `exit 1` si cualquiera de los dos no responde (el bug del `exit 0`
  dentro del bucle de la versión anterior está corregido); el segundo `npm test` es un step normal, así que
  su fallo pone el job en rojo. No encontré forma de que un fallo de `:8091` pase inadvertido.
- **`PENDING_TRUE_PAIRS`** cubre las cinco capacidades declaradas; desde TypeScript no encontré forma de
  declarar `true` y esquivar el rechazo (un getter malicioso sería posible, pero es escenario de sabotaje,
  no de descuido).
- **`memoryScopeTree`**: no conseguí construir un ciclo, colgar `app`, ni dejar huérfanos que heredaran de
  `app` por vías normales. `detach` borra el subárbol entero y `move` sobre un nodo borrado lanza.
- **El caso de 1.200 escala**: subido a 20.000 filas en una copia, `listScopes` sigue devolviendo el conjunto
  completo — no hay tope de 1.000 en el driver `database` (el `1000` observado en A1 es contaminación, no un
  límite).
- **`uuidv7` no duplica**: 0 duplicados en 200.000 generaciones (descartado como causa de A1).
- **Un harness con firma 1.1 no compila**: `capabilities` es obligatorio; un harness JS que la omita revienta
  ruidosamente en `runAuthorizationDriverContract` (TypeError), no en silencio.

---

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿Se acepta commitear una suite que es roja de forma intermitente bajo carga?** Si el dueño reproduce A1,
   la respuesta debería ser no: la Fase 0 entrega precisamente la garantía, y una garantía no determinista
   no lo es.
2. **¿Qué explica que `listSubjects` devolviera el holder EXPIRADO?** Si no es contaminación entre tests
   (mi hipótesis, no confirmada), es un defecto del driver `database` sobre el invariante 3 y sería 🔴.
   Merece un test dirigido antes del commit.
3. **¿El default de `level` debe ser `'core'` en un major que ya rompe la firma?** Cambiar el default a
   `'2.0'` con degradación explícita eliminaría A4 y parte de A2 sin coste, porque el tercero está obligado
   a editar el harness de todas formas.

---

## Tabla de cierre

| # | Sev | Hallazgo | Evidencia | Bloqueante para commit |
|---|---|---|---|---|
| A1 | 🟠 | Suite no determinista bajo carga; el rojo se atribuye al driver | ✅ obs. / ❓ causa | **Sí** |
| A8 | 🟠 | `prune_stores` borra por defecto; `--prefix ""` borra todo | ✅ reproducido | **Sí** |
| A2 | 🟡 | Los casos del árbol no castigan a un driver que lo ignora (28/32 verdes) | ✅ reproducido | No (corregir texto) |
| A3 | 🟡 | "Jamás un skip": 4/5 capacidades sin caso; `exhaustiveLists` fuera de la regla | ✅ código | No (corregir CHANGELOG) |
| A4 | 🟡 | `level` default `'core'` sin señal en el reporte | ✅ código | No |
| A5 | 🟡 | Juez llamado fuera del top level ⇒ juicio vacío silencioso | ✅ reproducido | No |
| A6 | 🟡 | `check_purity` fail-open silencioso vía symlink; el spec no puede verlo | ✅ reproducido | No |
| A7 | 🟡 | 7 formas de import esquivan ambas reglas de pureza | ✅ reproducido | No |
| A9 | ⚪ | 2.º OpenFGA de CI no ejercita nada; `limits` nunca se lee; margen de 1 tupla | ✅ grep + código | No |
| A10 | ⚪ | `memoryScopeTree`: colisión de claves, rama muerta, `edges()` sin uso | ✅ código | No |
| A11 | ⚪ | `CLAUDE.md` sin trackear; `.claude/contexto/` ignorado; ruido en el lockfile | ✅ git | No |
| A12 | ⚪ | Parche de `client.read` sin `finally` | ✅ código | No |
| A13 | ❓ | Una ejecución reportó 82 tests en vez de 63; no reproducible | ❓ | No |

**Veredicto final: APTA CON CORRECCIONES.** El compromiso central de la fase se cumple —
`src/drivers/*`, `src/manager.ts` y `src/catalog.ts` están intactos y lo verifiqué por diff y por tipos— y
el trabajo real está hecho. Lo que no se sostiene es la *garantía*: la suite no es reproduciblemente verde
(A1) y tres textos públicos (CHANGELOG, comentario de N1, comentario del script de prune) afirman más de lo
que el código demuestra. Corregir A1 y A8 antes del commit; A2/A3 son correcciones de texto de 10 minutos y
deberían entrar en el mismo commit para no publicar una promesa falsa a drivers de terceros.
