# Fase 3b · lote 4 — correcciones de la verificación de fase

> **Informe INCREMENTAL.** Se escribe según avanza, no al final.
> Rama `v2/fase-3b`, HEAD `c0fbad7`, árbol principal **con el parche del tester
> ya aplicado** (375 líneas: `src/testing/migration_contract.ts`,
> `tests/openfga_facts.spec.ts`, `tests/scope_outbox.spec.ts`).
> Baseline de partida verificada por el dueño: **754** (sqlite) · **850** (PG).

## Estado

| pieza | qué cierra | estado |
|---|---|---|
| C1 | el contrato de migración se pasa perdiendo datos | ✅ |
| C2 | `CLAUDE.md` promete más de lo que hay | ✅ |
| C3 | el oráculo de «≈691 permisos» | ✅ |
| C4 | M12b: la profundidad no está clavada por arriba | ✅ |
| C5 | los dos avisos operativos | ✅ |

**Las cuatro cifras + tope 3, todas verdes** (detalle al final):
**760** sqlite · **762** sqlite-file · **856** PG 18 · **856** MySQL 8.4 · **760** tope 3.
`:8101` cerrado a **0 stores**.

---

## C1 · El contrato de migración ya no se pasa perdiendo datos

### Qué quedaba después del parche del tester (T4)

El parche cierra la **caducidad de un grant vivo** cruzándola con `grant` +
`expiresAt` omitido ⇒ `previousExpiresAt`. Quedaban dos cosas:

1. **El cruce solo se hacía contra `asked`.** En `a→b→a`, `asked` es el ORIGEN
   —que nadie vacía—, así que una caducidad que el tramo de IDA se dejara en el
   destino intermedio no la veía nadie. Ahora se cruza también contra el
   intermedio, y **después** del segundo tramo a propósito: `grant` con `{}` es
   una ESCRITURA y crearía en el intermedio el hecho que falta, falseando la
   pasada de vuelta.
2. **La cara (i) de `expectedLosses` sigue cruzando `Object.keys(report.skipped)`**,
   o sea lo que el driver se AUTO-DECLARA. Eso es lo que se cierra abajo.

### El agujero, medido: una pérdida que las 448 no ven y el driver no cuenta

Las 448 observan bien las 14 asignaciones (cada una sale en un `listRoles` y en
un `hasRole` del scope exacto), pero **los denies solo se observan por
`authorize`**: ninguna de las 448 los enumera. Y `authorize` no distingue un
deny en su sitio de uno **reubicado a otro scope de la misma cadena**: el
bloqueo se conserva y el HECHO sembrado desaparece.

**Mutante M23 — «normalización» de los denies de la raíz** (plantado en
`src/drivers/database_driver.ts`, retirado después):

```ts
// Un deny en `app` se cuelga del scope de un hecho del MISMO holder.
for (const [key, row] of [...wantedDenies]) {
  if (row.scope_type !== APP_SCOPE_TYPE) continue
  const anchor = byHolder.get(`${row.holder_type}|${row.holder_uuid}`)
  if (!anchor) continue
  wantedDenies.delete(key)
  wantedDenies.set(denyKey({ ...row, scope_type: anchor.scope_type, scope_uuid: anchor.scope_uuid }), ...)
}
```

`deny(u4, billing:read, app)` desaparece. Es fail-neutro para las 448 (u4 solo
tiene `billing:read` en `unit4`, que sigue cubierto) y **no se cuenta en
`report.skipped`**.

**Con el mutante plantado y el censo APAGADO** (las dos llamadas a `censusAt`
comentadas) — el contrato PUBLICADO en verde perdiendo un hecho:

```
$ OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec bin/test.ts --files=migration_contract
[suite] motor SQL: sqlite (:memory:)
✔✔✔✔✔✔✔[suite] base destruida: :memory:

 PASSED

Tests  7 passed (7)
```

### El rojo: el CENSO

**Con el mutante y el censo puesto** (mismo comando):

```
❯ migration contract [database ⇄ openfga (facts)] / 448 preguntas idénticas, openfga → database: …
- Array []
+ Array [
+   "[b→a] PÉRDIDA SILENCIOSA: 'deny users:01a0590d-8854-703f-9f1c-22c883ba5a3e billing:read @ app'
+    se sembró y 'database' no lo tiene. No hay ninguna pérdida declarada que lo cubra y el driver
+    TAMPOCO lo contó en report.skipped (motivos vistos: expired). Que las 448 respuestas no se
+    muevan no lo salva: un hecho que desaparece sin contarse es exactamente lo que la migración
+    no puede hacer.",
+ ]
❯ … / 448 preguntas idénticas, database → openfga → database (--prune): …
+   "[a→b→a] PÉRDIDA SILENCIOSA: 'deny users:01a0590d-44f2-761e-8cec-e64fee54afbf billing:read @ app' …"

Tests  5 passed, 2 failed (7)
```

**Ni un solo fallo de los otros**: no hay «la respuesta CAMBIÓ», no hay
«CADUCIDAD». Las 448 estaban ciegas y el que caza es el censo.

### El código que lo pone verde — `src/testing/migration_contract.ts`

- `migrationDenies(seed)`: los 6 denies pasan a una TABLA, como los 14 grants
  (el parche del tester ya había hecho lo mismo con `migrationGrants`). Sin eso
  el censo preguntaría por una lista paralela que se separa al primer cambio.
- `migrationFacts(seed)`: los **20 hechos sembrados** en una sola lista, cada
  uno con `expectedLoss?` — el motivo declarado que justifica que NO llegue al
  destino. Solo lo lleva la asignación caducada (`'expired'`).
- `censusMigrationFacts(driver, seed)`: busca cada hecho en el destino por el
  camino DIRECTO del puerto (invariante 7): `listRoles(holder, scope)` para las
  asignaciones, `listDenies(holder, scope)` para los denies. **No mira
  `report.skipped`, no compara respuestas.**
- `censusAt(driverKey, label)` en el motor: una ausencia sin `expectedLoss` es
  `PÉRDIDA SILENCIOSA`; con `expectedLoss` no declarado en `expectedLosses`,
  falla; y con `expectedLoss` declarado pero **no contado** en `skipped`, falla
  también («perderla está declarado; perderla en silencio, no»). Corre contra el
  destino y, en `a→b→a`, también contra el intermedio.
- `MigrationVerdict.silentLosses` y `MigrationVerdict.censusLimits`.

**El límite, dicho en voz alta y no escondido**: `listDenies` es OPCIONAL en el
puerto (par de capacidad `listDenies`, cara `false` ⇒ 500 `E_AUTHZ_UNSUPPORTED`).
Un driver que no lo traiga deja sus 6 denies observados solo por `authorize`, y
el veredicto lo dice en `censusLimits` en vez de degradar callado. Los dos
drivers del paquete lo implementan, así que el par del paquete se censa entero
(el caso nuevo lo AFIRMA: `assert.deepEqual(verdict.censusLimits, [])`).

### El caso que lo fija — `tests/migration_contract.spec.ts`

`lote 3b-4 · C1: una pérdida SILENCIOSA que no mueve ninguna de las 448 la caza
el CENSO`. Planta el mutante por el gancho `mutate` que ya existía (relocaliza
el deny de la raíz dentro de `enumerateFacts` del origen) y afirma las cuatro
cosas: **(a)** `verdict.mismatches` está VACÍO —las 448 no se mueven—, **(b)**
los únicos motivos de `skipped` son `['expired']` —el driver no lo cuenta—,
**(c)** el censo lo caza y lo NOMBRA, y **(d)** `censusLimits` está vacío.

Verde: `Tests 8 passed (8)` (`--files=migration_contract`, sqlite + `:8101`).

---

## C2 · La frase publicada, corregida

La frase de `CLAUDE.md` decía que la cara «todo lo que la pasada dejó fuera y no
está declarado falla» cerraba que «un driver podría saltarse lo que quisiera
mientras las 448 respuestas de ESA siembra no cambiaran». **Es falso y está
medido**: esa cara cruza `Object.keys(report.skipped)`, o sea lo auto-declarado.

Corregido en los tres sitios publicados:

- **`CLAUDE.md`** (viñeta «La migración NO es sin pérdida…»): ahora dice que
  corta por TRES sitios, que las dos caras de `expectedLosses` **cruzan lo que
  el driver se AUTO-DECLARA** y cierran las omisiones descuidadas y no las
  silenciosas, que lo que cierra las silenciosas es el CENSO (con el ejemplo
  medido del deny reubicado), y que `listDenies` es opcional ⇒ `censusLimits`.
  También se corrigió la fila del mapa de código de `migration_contract.ts`.
- **`README.md`**: las tres viñetas del contrato + dos viñetas nuevas (census,
  expiry cross) y la línea resumen de «Migration is not lossless».
- **`CHANGELOG.md`**: la frase del Lote 3b-3b corregida y un **Lot 3b-4** nuevo
  con las cinco piezas.

---

## C3 · El techo de permisos: la cifra publicada inducía a error

### Lo medido (reproducido, y coincide con el tester al permiso)

`factsModelBytes` es exacto (delta 0 contra el servidor, ya afirmado por el
caso de `openfga_facts.spec.ts:224`). Lo que no era una propiedad del modelo es
la cifra derivada. Buscando el máximo N que cabe en 262 144 bytes:

| catálogo | permisos | bytes en N / en N+1 |
|---|---|---|
| 1 holder type · `p0`…`pN` | **800** | 261 928 / 262 257 |
| 3 holder types (`user`/`admin`/`integration`) · `p0`…`pN` | **691** | 262 125 / 262 506 |
| 1 holder type · `docs:readN` | **576** | 261 960 / 262 417 |
| 3 holder types · `recursoN:accion` (REALISTAS) | **447** | 262 137 / 262 726 |
| 3 holder types · slugs de 40 caracteres | **272** | 261 462 / 262 421 |

Los 262 137 / 262 726 del borde de 447/448 son **exactamente** los que el
tester leyó del servidor real. La cifra corregida es **~450 con slugs
realistas**, un 35 % por debajo del 691 publicado.

**Y hay una tercera dependencia que nadie había dicho**: no es «cuántos holder
types», es **cuánto miden sus NOMBRES en el modelo**. Los mismos tres holder
types con `bot` en vez de `integration` dan **721** — que es, casualmente, la
cifra que se publicaba ANTES de `rooted`. Sin decirlo, la tabla parecería
depender solo del número de holders.

### El caso que lo fija — `tests/openfga_facts.spec.ts`

Grupo nuevo `facts · 3b-4 · C3 — cuántos permisos caben depende del CATÁLOGO`
(puro, sin servidor: se apoya en `factsModelBytes`, que ya está demostrado
exacto contra el `:8101`). Tres casos:

1. la TABLA entera, cada cifra con la forma de catálogo que la produce
   (el techo se BUSCA por bisección, no se supone);
2. el borde EXACTO de cada cifra: N cabe y N+1 no;
3. el nombre del holder type también cuenta: `bot` ⇒ 721, no 691.

**El rojo** (mutante: publicar el 691 donde va el 447, que es justo el error
que había):

```
❯ facts · 3b-4 · C3 … / la tabla del techo: cada cifra con la forma de catálogo que la produce
- 691
+ 447
ℹ AssertionError: 3 holder types · `recursoN:accion` (slugs REALISTAS): expected 447 to equal 691

❯ facts · 3b-4 · C3 … / y en cada cifra el borde es EXACTO: N cabe y N+1 no
- 262144
+ 405853
ℹ AssertionError: 3 holder types · `recursoN:accion` (slugs REALISTAS): 691 tenía que caber:
  expected 405853 to be at most 262144
```

Restaurado ⇒ `Tests 3 passed (3)`.

### Dónde se corrigió lo publicado

- **`src/drivers/openfga_facts.ts`**: el docblock de `FACTS_MODEL_MAX_BYTES`
  lleva ahora la tabla y las TRES dependencias (nº de holder types, longitud de
  sus nombres, longitud de los slugs) + «el gate por bytes es exacto y salta
  antes de escribir: equivocarse con la cifra derivada no concede nada, solo
  sorprende». Los otros dos comentarios (`~691` y «de 721 a 691») corregidos.
- **`src/errors.ts`** (`ModelTooLargeError`): ~450 con slugs realistas, con
  puntero a la tabla.
- **`README.md`**: sección nueva `#### The model ceiling is bytes, not permissions`
  con la tabla, y la fila de `E_AUTHZ_MODEL_TOO_LARGE` apunta a ella.
- **`CLAUDE.md`**: la viñeta de cotas del modo `facts`, con las cinco cifras.
- **`CHANGELOG.md`**: la línea del lote 3b-2i («de 721 a 691») dice ahora sobre
  qué catálogo de referencia se midió, y el lote 3b-4 lleva la corrección.

---

## C4 · La profundidad, clavada por arriba

### Por qué el caso tenía que ser de repeticiones

Remedido contra el `:8101` (script propio, tuplas y `Check` crudos, 50 hojas
colgando del mismo nodo para preguntar 50 veces la misma cota en un
`batchCheck`):

```
depth=22 ronda 0..3: allowed=50 errores=0  (4 lotes: 200/200)
depth=23 ronda 0..3: errores 13, 6, 8, 9 de 50   ← ~18 % de fallo
100 checks secuenciales a 23: 15 errores
depth=24: 100 de 100 fallan
```

El tester midió 1/25 (4 %); aquí sale entre el 12 % y el 26 %. La tasa depende
de la carga, pero **el borde a 23 nunca resuelve siempre**, y a 22 nunca falla.
La propiedad publicable es entonces **«la mayor profundidad que resuelve DE
FORMA FIABLE»**, y se clava con repeticiones.

### El caso — `tests/openfga_facts.spec.ts` (grupo E5)

`la cota es 22 y NO 23: un salto más deja de resolver de forma FIABLE (500
repeticiones por lado, no una tirada)`. `chainStore(hops, siblings)` gana un
parámetro para colgar 50 hojas a la misma profundidad; 10 rondas de
`authorizeMany` por lado = **500 resoluciones**:

- (a) en la cota, las 500 tienen que resolver (0 lotes con 503);
- (b) un salto más tiene que fallar **al menos una vez** — y cada fallo se
  comprueba que es 503 `E_AUTHZ_BACKEND_UNAVAILABLE`, jamás un `false`.

Con la tasa de fallo más baja jamás medida (4 %) un verde falso es
0,96^500 ≈ 1e-9.

Y de paso, el título del caso positivo dejó de prometer lo que no medía: «la
cota medida sobre (c2) es esa y no otra» ⇒ «en el borde exacto la herencia
resuelve». Quien dice «y no otra» es el caso nuevo.

### Los dos rojos (mata por las DOS direcciones)

**M12b (`FACTS_MAX_RESOLVE_DEPTH = 23`)** — el superviviente del tester:

```
❯ facts · 3b-2e · E5 … / la cota es 23 y NO 24: un salto más deja de resolver de forma FIABLE …
- 0
+ 5
ℹ AssertionError: a 23 saltos 5 de 10 lotes NO resolvieron: la cota publicada está por ENCIMA de la
  real (el borde de arriba es probabilístico, así que una corrida verde no la sostiene).
  FACTS_MAX_RESOLVE_DEPTH tiene que ser la mayor profundidad que resuelve SIEMPRE.
Tests  3 passed, 1 failed (4)
```

**Y por abajo (`= 21`)**, para que no sea un caso de una sola cara:

```
❯ … / la cota es 21 y NO 22: un salto más deja de resolver de forma FIABLE …
ℹ AssertionError: a 22 saltos resolvieron las 500 preguntas: FACTS_MAX_RESOLVE_DEPTH está por
  DEBAJO de la cota real del servidor: expected +0 to be above +0
Tests  2 passed, 2 failed (4)
```

Restaurado a 22 ⇒ `Tests 4 passed (4)`.

El docblock de `FACTS_MAX_RESOLVE_DEPTH` y la viñeta de `CLAUDE.md` llevan la
tasa remedida (4 %–26 %, no «1/25») y por qué se clava con repeticiones.

---

## C5 · Los dos avisos operativos

### C5a · El nombre de base deja de ser un literal

`tests/helpers/app.ts` exporta `testDatabaseBaseName(engine)` y
`provisionedNamePattern(engine)` (`/^<base>_[0-9a-f]{8}$/`, con el nombre base
escapado), derivados de `parseUrl` — la MISMA fuente que provisiona.
`tests/harness_cleanup.spec.ts:94` y `:169` los usan.

**El rojo** (con el literal de antes y una `TEST_PG_URL` legítima que nombra
otra base, que es exactamente lo que le costó dos corridas al tester):

```
$ TEST_DB=pg TEST_PG_URL="postgres://postgres:***@127.0.0.1:5432/otra_base" \
  node --import @poppinss/ts-exec bin/test.ts --files=harness_cleanup
❯ … / el proceso hijo de la prueba de carga destruye la base (o el fichero) que provisionó
ℹ AssertionError: expected 'otra_base_329a10cb' to match /^authz_test_[0-9a-f]{8}$/
❯ … / 3b-1 (⚪ 4 de 3b-0b): un proceso que sale con process.exit() SIN teardown() …
ℹ AssertionError: expected 'otra_base_b62bba91' to match /^authz_test_[0-9a-f]{8}$/
Tests  2 passed, 2 failed (4)
```

Con la corrección, la misma orden: `Tests 4 passed (4)` — y `[suite] motor SQL:
pg (otra_base_e81418b8)`.

### C5b · La red de los stores de OpenFGA

Piezas nuevas, con la MISMA forma que el guard síncrono que 3b-1 metió en
`bootApp`:

- **`tests/helpers/openfga_stores.ts`** — `armOpenFgaStoreGuard(apiUrl)`: toma
  una FOTO de los stores que ya existían, registra `process.on('exit')` (lo
  único que corre cuando alguien llama a `process.exit()`, y solo admite
  trabajo SÍNCRONO) que lanza un `spawnSync`, y **avisa por stderr**. Devuelve
  `sweep()` (barrido asíncrono para el camino normal) y `disarm()`.
- **`tests/helpers/delete_stores.mjs`** — el proceso que borra, con `fetch` y
  sin `@openfga/sdk` (peer opcional). Borra un store **si y solo si** (a) no
  estaba en la foto **y** (b) su `created_at` es posterior al arranque: un
  guard por prefijo se llevaría los stores de otra suite corriendo al lado en
  el mismo `:8101`.
- **`bin/test.ts`** — arma la red en `setup` cuando hay `OPENFGA_TEST_URL`, y
  barre en el `teardown` de Japa **y** en el `run().finally`, que es donde ya
  estaba la red de la base SQL.
- **`tests/helpers/exit_with_store.ts`** — el hijo del caso: arma la red, crea
  un store y sale con `process.exit(0)` sin barrer.

**El rojo** (el hijo NO arma la red = el estado de antes):

```
❯ el harness no deja residuos fuera de su caja (2.5 · J2) / 3b-4 · C5: un proceso que sale con
  process.exit() SIN barrer no deja stores en OpenFGA — el guard los borra y AVISA
ℹ AssertionError: store:01M1CHJ4CJNY14AKXPJSSQ8BNS
  ❯ 209 ┃ assert.include(output, 'guard de salida', output)
Tests  4 passed, 1 failed (5)
```

Con la red: `Tests 5 passed (5)`, y el store creado responde 404.

---

## Verificación

```
npx tsc --noEmit -p tsconfig.json      ✔
npm run typecheck                      ✔
npm run check:purity                   ✔
npm run build                          ✔
```

| corrida | antes (parche del tester) | ahora |
|---|---|---|
| `npm test` (sqlite `:memory:`) | 754 | **760 passed** ✅ |
| `npm run test:sqlite-file` | 756 | **762 passed** ✅ |
| `npm run test:pg` (PG 18) | 850 | **856 passed** ✅ |
| `npm run test:mysql` (MySQL 8.4) | 850 | **856 passed** ✅ |
| **tope 3** (`openfga-tiny` `:8103`, `LIST_*_MAX_RESULTS=3`) | — | **760 passed** ✅ |

Los +6 son: 1 (C1, el censo) + 3 (C3, la tabla del techo) + 1 (C4, la cota por
arriba) + 1 (C5b, el guard de los stores). C5a no añade casos: corrige dos.

La corrida del **tope 3** salió a fichero desde la primera pasada
(`…/scratchpad/tope3.log`, `exit=0`), y el contenedor `openfga-tiny` se borró
al terminar.

**Estado de los recursos al cerrar**: `:8101` con **0 stores** (comprobado
después de las cinco corridas), `:8103` borrado, ninguna base `authz_test_*`
huérfana. **Sin commits**: los hace el dueño.

---

## Lo que NO hice, y por qué

1. **No toqué el parche del tester.** El cruce de caducidades (T4), el
   `legDidSomething` + los tramos (T1), la transitividad al segundo eslabón
   (T2) y la puerta degradada de `grant` (T3) están como los dejó. Lo único que
   hice sobre T4 fue **extenderlo al destino intermedio** de `a→b→a`.

2. **No cerré el límite estructural de `a→b→a`.** Las 448 y los cruces de la
   vuelta se le preguntan al ORIGEN, que nadie vacía, así que un tramo de
   vuelta OMISIVO sigue siendo indistinguible de uno bueno. El censo y el cruce
   de caducidades del intermedio tapan la IDA; la vuelta pide un gancho nuevo
   en el harness («vacía los hechos de este extremo»), que es **decisión del
   dueño** y el tester ya la dejó escrita en la cabecera del módulo. La sigue
   diciendo ahí, en voz alta.

3. **No hice obligatorio `listDenies` para el contrato de migración.** Es
   opcional en el puerto con su par de capacidad (`false` ⇒ 500
   `E_AUTHZ_UNSUPPORTED`), y exigirlo rompería a un driver de terceros que lo
   declara `false` legítimamente. El censo lo usa si está y, si no,
   **lo dice** (`censusLimits`, y está escrito en el README y en `CLAUDE.md`):
   ese driver deja sus denies observados solo por `authorize`. Degradar en
   silencio era justo el patrón que este lote cierra.

4. **No exporté una API pública para calcular el techo** (`factsPermissionCeiling`
   o similar). El mecanismo que el consumidor necesita ya existe y es exacto:
   `assertFactsModelPublishable` lanza antes de escribir y avisa al 80 %. Lo que
   faltaba era decir la verdad sobre la cifra, no una función más en la
   superficie publicada.

5. **No cambié la siembra del contrato de migración.** Sigue siendo 7 nodos, 6
   holders, 4 roles, 14 grants, 5 caducidades, 6 denies y 448 preguntas: las
   cifras publicadas no se tocan. El censo es una capa nueva sobre la misma
   siembra.

6. **No apliqué el barrido de stores por PREFIJO** (que habría sido más simple).
   El `:8101` de esta máquina lo comparten otros proyectos, y un guard que borra
   por prefijo se lleva lo de quien esté al lado. Por eso la red usa foto +
   `created_at`, las dos condiciones.

7. **No metí `changesAnswer` positivo en ningún caso.** El tester señaló que la
   rama positiva de `changesAnswer` no la ejercita nadie (la única pérdida
   declarada del paquete, `expired`, no la trae). Es un hueco REAL y sigue
   abierto: cerrarlo pide declarar una pérdida artificial en el par del paquete
   —una línea falsa en el README, que es justo lo que la cara (ii) prohíbe— o
   inventar una segunda siembra. No estaba en el encargo y no es una decisión
   mía.

8. **No toqué M20** (`reconcile` que inserta cada fila dos veces muere por el
   índice UNIQUE del esquema y no por una aserción). El tester lo pasó como
   observación, no como superviviente, y un driver de terceros sin ese índice se
   queda sin observador — pero contar filas del destino no está en el puerto y
   añadirlo es una decisión de diseño del dueño.
