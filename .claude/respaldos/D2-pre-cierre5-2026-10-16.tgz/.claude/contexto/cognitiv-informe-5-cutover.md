# Quinto informe al paquete — el cutover no se puede hacer con `2.4.0-alpha.8` (11-09-2026)

Asunto: `authz:reconcile --dry-run` **escribe** · `authz:relations:reconcile` migra **cero** y reporta
éxito · `authz:reconcile --prune` **borra todas las tuplas de relación** de un store compartido

Todo lo de abajo está **medido** en `api-cognitiv` contra OpenFGA 1.19.0, driver `openfga`, por la vía
real de ace, durante el ensayo de cutover del lote L4. Los tres primeros son variantes del defecto del
cuarto informe (`name` no es `flagName`), que ya está reportado; van aquí porque su alcance es mayor del
que dijimos y porque uno de ellos —el tercero— no es de banderas.

---

## 1 · 🔴 `authz:reconcile --dry-run` escribe (el verificador no es de solo lectura)

Store recién provisionado, 0 tuplas. `node ace authz:reconcile --to=openfga --from=database --dry-run`
⇒ **463 tuplas en el store** y la salida es la rama de ÉXITO, no la de dry-run:

```
[ success ] 'openfga' reconciliado: escritas 463, actualizadas 0, iguales 0, sobran 0, borradas 0.
```

`this.dryRun` es `undefined` (el valor cae en `this['dry-run']`), así que `report.dryRun` es falso y
`authz_reconcile.js:254` toma la rama equivocada. La cabecera del comando dice «`--dry-run` es el
verificador y es **read-only por contrato** (panel 2)»: hoy eso es falso.

Por qué es el peor de los tres: el paso «`reconcile --dry-run` en cron» que el propio README sugiere
**reconstruiría el driver inactivo** en cada pasada en vez de reportar deriva, y con `--prune` borraría.

## 2 · 🔴 `authz:relations:reconcile` migra 0 tuplas y reporta éxito

`--partition-type` y `--partition-uuid` son inertes, así que `authz_relations_reconcile.js:218-220`
siempre construye `{ type: 'app', uuid: null }`. Con 60 relaciones vivas particionadas por organización:

```
node ace authz:relations:reconcile --to=openfga --from=database \
  --partition-type=organization --partition-uuid=01a07c68-…
relaciones: escritas 0, actualizadas 0, borradas 0, iguales 0, sobran 0
[ success ] Relaciones de 'openfga' reconciliadas desde 'database': escritas 0 …
```

Un cutover que siga el runbook aterriza en OpenFGA **sin una sola llave de espacio ni arista del
espejo**, y ningún comando lo dice.

## 3 · 🔴 `authz:reconcile --prune` borra TODAS las tuplas de relación del store

Este **no es de banderas**. Con `openfga` los dos subsistemas comparten store; el reconcile de hechos
enumera el store entero y toda tupla que no esté en su `wanted` cae en `phases.facts.extra`
(`openfga_driver.js:2138-2144`). Sin `--prune` la anota `extra-fact` y la respeta; **con `--prune` la
mete en `deletes`**.

Medido: store con 523 tuplas (463 de hechos/árbol/catálogo + 60 de relaciones) ⇒
`node ace authz:reconcile --to=openfga --from=database --prune` ⇒ **463 tuplas**, salida
`hechos: … sobran 60, borradas 60`, `[ success ]`, exit 0. El seguro de borrado masivo no salta (el
origen sí tiene hechos).

Y el corolario: como `skipped['extra-fact']` no queda vacío, `reconcileLines` da `clean = false`
(`authz_reconcile.js:155-165`) ⇒ **un cutover perfecto reporta deriva para siempre**, así que el
verificador de CI que el CHANGELOG promete verde tampoco existe con un store compartido.

Sugerencia: el reconcile de hechos debería reconocer como AJENAS las tuplas cuyo tipo de objeto no
gobierna (hoy los suyos son `role_binding`, `role` y `scope`) — ni borrarlas con `--prune` ni contarlas
como deriva. Nosotros lo hemos hecho así en nuestro verificador, repartiendo por el tipo del objeto que
va tras la última `@` del `detail`, y funciona.

## 4 · alcance completo del defecto de banderas: 17 banderas en 7 comandos

Barrido sobre `build/commands/*.js` de alpha.8 (toda bandera cuyo `name:` es multi-palabra):

| comando | banderas inertes |
|---|---|
| `authz:reconcile` | `--dry-run`, `--allow-mass-delete`, `--batch-size`, `--max-tuples` |
| `authz:relations:reconcile` | `--dry-run`, `--allow-mass-delete`, `--partition-type`, `--partition-uuid` |
| `authz:scopes:relay` | `--dry-run`, `--batch-size`, `--wait-lease-ms`, `--max-age` |
| `authz:scopes:requeue` | `--wait-lease-ms` |
| `authz:freeze` | `--lease-ms` |
| `authz:catalog:diff` | `--fail-on-shadows` |
| `authz:catalog:prune-orphans` | `--allow-mass-purge` |

Dos fallan hacia el lado seguro (`--allow-mass-delete`, `--allow-mass-purge`: el seguro no se puede
levantar). `--lease-ms` también, y el comando lo dice en voz alta («La ventana NO caduca sola»), pero
deja al operador sin la red que cree tener.

**Un test que los fije todos**: crear cada comando con `ace.create(Cmd, ['--<flag>=<valor>'])`, `exec()`
y afirmar el EFECTO (no `cmd.<prop>`, que un test puede fijar a mano). O, más barato, una guardia
estática: para cada `flags.*({ name: 'x-y' })`, que `dashCase(propiedad) === 'x-y'`.

## 5 · lo que sí funciona y nos ha servido

- `authz:reconcile` corre con la ventana abierta y repone el marcador de raíz avisando de que sin él el
  store deniega en silencio. Es exactamente el aviso que hace falta.
- `runRelationsReconcile` y `relationsReconcileLines` están EXPORTADOS del módulo del comando: hemos
  podido montar nuestro bucle por particiones encima sin duplicar la ventana durable, el seguro de
  borrado masivo ni la decisión de «limpia». Gracias por exportarlos.
- `report.frozen.lapsed` y la línea «la ventana aguantó entera» son la garantía que un cutover necesita
  y casi nadie publica.
- `partitions?: ScopeRef[]` en `reconcileRelations` (alpha.6) hace que el bucle por tenant sea un
  barrido y no K barridos.

**Mientras tanto**, en `api-cognitiv`: el runbook no apoya ni un paso en esas banderas, el verificador es
nuestro (`authz:cutover:verify`, por API), la migración de relaciones es nuestra
(`authz:cutover:relations`, todas las particiones) y `--prune` del reconcile de hechos está PROHIBIDO
por escrito mientras el store sea compartido.
