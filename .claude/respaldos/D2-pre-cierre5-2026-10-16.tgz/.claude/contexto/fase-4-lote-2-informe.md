# Fase 4 · Lote 4-2 — puerto `RelationsDriver` + `defineRelationsConfig` + F-05 + `membersOf` + runner de contrato

> Base: `main` @ `25d2be9` (4-1 mergeado). Árbol principal, SIN commits (los hace el dueño).
> Plan: `fase-4-juez.md` §4-2 + `fase-4-plan.md` §2/§4 + `fase-4-auditor.md` (F-05, el 🔴).
> Alcance: el CONTRATO (puerto + config + runner) SIN drivers reales. Verificado con un
> DOBLE en memoria; lo que necesita el `:8101`/paridad con `database` es 4-4.

## Qué se implementó (todo aditivo)

- **El puerto `RelationsDriver`** en `src/types.ts` (el contrato ya vive ahí, junto a
  `AuthorizationDriver`): `relate`/`unrelate`/`check`/`listObjects`/`listSubjects`/`purgeObject`/
  `purgeSubject`, con `partition: ScopeRef` OBLIGATORIA en TODA operación (`APP_SCOPE` válida para
  mono-tenant). Métodos OPCIONALES `membersOf` (transitivo) y `enumerateRelations` (origen de
  reconcile). Tipos nuevos: `RelObject`, `RelUserset`, `RelSubject` (holder | userset, con guard
  `isRelUserset`), `RelationRef` (la tupla completa que ve `assertWrite`/`onRelationWrite`),
  `RelationWriteEvent`/`RelationWriteOptions`, `RelationsDriverCapabilities`, y las páginas
  (`RelationObjectsPage`/`RelationSubjectsPage`/`RelationTuplePage`, con `truncated?`).
- **`defineRelationsConfig`** (`src/relations/define_relations_config.ts`): valida y CONGELA la
  config; devuelve `hasType`/`isDeclared` (lo que consume F-05) y `membersOf`. Rechaza (422
  `E_AUTHZ_RELATION_CONFIG`, la clase del 4-1) tipos/relaciones reservados (⚪4), includes con `from`,
  `membersOf` fuera de `database`, duplicados y tipos sin relaciones. **`group` es el tipo BUILT-IN**
  (portador de usersets): declarado por el generador, no por el consumidor, así que es válido para
  F-05 pero `role_binding`/`scope`/`role`/`deny_binding` siguen FUERA — la frontera del 🔴 intacta.
- **`RelationsManager`** (`src/relations/manager.ts`): la fachada. Aplica **F-05** (cierre del 🔴),
  `assertWrite` PURO (R-13, obligatorio aquí), `actor` en `onRelationWrite`, y despacha `membersOf`
  (500 `E_AUTHZ_UNSUPPORTED` si el driver no lo trae, jamás un skip). `driver()` = salida documentada.
- **F-05 en el puerto**: dos códigos nuevos en `src/errors.ts` — `RelationTypeUnknownError`
  (`E_AUTHZ_RELATION_TYPE_UNKNOWN`, 422) y `RelationUnknownError` (`E_AUTHZ_RELATION_UNKNOWN`, 422),
  la redacción que el juez adoptó del auditor.
- **`runRelationsDriverContract` + `makeRelationsDriver`** (`src/testing/relations_contract.ts`):
  runner SEPARADO (precedente `runMigrationContract`), NO un nivel `'2.4'` del runner de roles ⇒ los
  conteos de `contract_harness.spec.ts` NO cambian. `makeRelationsDriver` es el DOBLE en memoria que
  satisface el puerto y HONRA las capacidades. Cada capacidad se registra con SUS DOS CARAS y el
  runner FALLA si una falta (más estricto que el guard de roles).
- **`RESERVED_FACTS_TYPES`** se MOVIÓ a `src/identity.ts` (fuente única) y `openfga_facts.ts` lo
  re-exporta: lo consumen dos módulos que la frontera de pureza mantiene disjuntos (el generador en
  `drivers/`, `defineRelationsConfig` en `relations/`). Ver «frontera de pureza» abajo.

Ficheros nuevos: `src/relations/define_relations_config.ts`, `src/relations/manager.ts`,
`src/testing/relations_contract.ts`, `tests/relations.spec.ts`, `tests/relations_contract.spec.ts`,
`tests/relations_harness.spec.ts`. Tocados: `src/types.ts`, `src/errors.ts`, `src/identity.ts`,
`src/drivers/openfga_facts.ts`, `src/testing/main.ts`, `index.ts`.

## F-05 — el cierre del 🔴 (lo más importante del lote), con su rojo-antes

El auditor reprodujo contra el `:8101`: `relate(evil, assignee, {type:'role_binding', id:<roleUuid>},
S)` componía byte a byte el id de un `role_binding` real y `check(evil, can_<P>, S)` daba `true`.
El cierre: **el `RelationsManager` rechaza con 422 ANTES de tocar el driver** todo `object.type` no
declarado (`#assertDeclared`), y `defineRelationsConfig` (⚪4) impide declarar `role_binding`.

**Rojo-antes (mutante: `#assertDeclared` desactivado ⇒ la escalada llega al driver):**
```
❯ relations contract [doble en memoria (full)] / F-05 · relate(evil, assignee, role_binding, S) ⇒ 422 E_AUTHZ_RELATION_TYPE_UNKNOWN, driver intacto
  Comparing two different types of values. Expected number but received undefined.
ℹ AssertionError: expected undefined to equal 422
   525 ┃  await state.manager.relate(evil, 'assignee', { type: 'role_binding', id: roleUuid }, S)
   526 ┃  assert.fail('debería haber lanzado')
```
(Sin F-05, `relate` NO lanza: la tupla `assignee` se escribiría — el 🔴 exacto del auditor.)

**Verde**: 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN` y `state.writes() === 0` (el driver NUNCA se llamó, así
que no pudo componer el id del binding). El código:
```ts
if (!this.#config.hasType(object.type)) {
  throw new RelationTypeUnknownError(`El tipo de objeto '${object.type}' no está declarado …(F-05)…`)
}
if (!this.#config.isDeclared(object.type, relation)) {
  throw new RelationUnknownError(`La relación '${relation}' no está declarada para el tipo '${object.type}' …`)
}
```
Segundo mutante (solo la cara del TIPO desactivada) ⇒ `role_binding` cae en la cara de la RELACIÓN:
```
- E_AUTHZ_RELATION_TYPE_UNKNOWN
+ E_AUTHZ_RELATION_UNKNOWN
ℹ AssertionError: expected 'E_AUTHZ_RELATION_UNKNOWN' to equal 'E_AUTHZ_RELATION_TYPE_UNKNOWN'
```
El par ⚪4 (config) + F-05 (escritura) hace la colisión IMPOSIBLE por construcción, no vigilada.

## Rojo→verde por pieza (mutante y salida roja literal)

### P1 · `defineRelationsConfig` ⚪4 (tipos reservados)
Mutante: no rechazar tipos reservados (`if (reservedTypes.has(type))` → `if (false)`).
```
ℹ AssertionError: role_binding: expected undefined to equal 422
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_RELATION_CONFIG'
 Tests  5 passed, 2 failed (7)
```
Verde: `role_binding`/`scope`/`role`/`group`/`deny_binding` y un holder type ⇒ 422 `E_AUTHZ_RELATION_CONFIG`;
relación `parent`/`assignee`/`rooted`/`can_*`/`permits_*`/`denied_*` ⇒ 422; includes con `from` ⇒ 422;
`membersOf` en la raíz ⇒ 422 nombrando `database.membersOf`.

### P2 · includes sin `from` (R-02), en el doble
Mutante: `expandDown` no sigue los includes (`queue.length = 0`).
```
❯ relations contract [doble en memoria (full)] / R-02 · includes: relate(editor) ⇒ check(viewer) true; el inverso NO
- Expected  - 1
 Tests  13 passed, 4 failed (17)
```
Verde: `relate(editor)` ⇒ `check(viewer)=true` (editor⊆viewer); el inverso NO. (4 casos rojos: los que
dependen de derivación por includes/userset — R-02, R-03/04, singleCheck whenTrue, listObjects.)

### P3 · R-13 · `assertWrite` PURO
Mutante: se llama al driver ignorando `assertWrite`.
```
ℹ AssertionError: expected false to be true
 Tests  1 passed, 1 failed (2)
```
Verde: si `assertWrite` lanza, `writes()===0` y NINGÚN `onRelationWrite`; una escritura permitida
notifica con el `actor`.

### P4 · `membersOf` distinto de `listSubjects`, cara whenFalse
Mutante: el manager no comprueba la capacidad y delega aunque el driver no traiga `membersOf`.
```
ℹ AssertionError: expected undefined to equal 500
 Tests  1 passed, 1 failed (2)
```
Verde: con `membersOfNative:false` ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrando `membersOf`. Con `true`,
`membersOf(g2, member)` da la membresía TRANSITIVA (el holder anidado) y `listSubjects(member, g2)`
NO (solo el userset directo `g1#member`): la desambiguación transitivo vs directo, observable.

### P5 · el runner FALLA si una capacidad no trae SUS DOS CARAS (exigencia del tester)
Mutante: quitar la cara `whenFalse` de `membersOfNative` en el runner.
```
ℹ Error: [contrato doble en memoria (full)] la capacidad 'membersOfNative' no declara sus dos caras
  (whenTrue Y whenFalse): una cara ausente es un skip disfrazado.
```
Verde: cada `caseFor` exige `whenTrue` Y `whenFalse` definidas en el código (throw al registrar), y el
teardown falla si una capacidad no quedó cubierta. Nunca un skip silencioso.

## Qué se prueba con el DOBLE y qué queda para el `:8101` en 4-4

**Con el doble en memoria (este lote, corre en TODOS los modos, sin servidor):**
- F-05 (el cierre del 🔴): el corte es ANTES del driver, así que un doble lo prueba entero —el caso
  `relate(evil, assignee, role_binding, S)` ⇒ 422 con `writes()===0`—.
- La validación de `defineRelationsConfig` (⚪4, includes, membersOf, duplicados): es pura.
- Las 6 capacidades con sus DOS caras (dos harnesses: «full» y «mínimo»), el conteo literal (17
  casos/harness) y el guard «sin skip».
- La semántica del puerto: denegación por defecto, includes, usersets anidados, aislamiento de
  partición, idempotencia, purga, `membersOf` transitivo vs `listSubjects` directo, truncado simulado.

**Necesita el `:8101` (o `database`) en 4-4, NO probado aquí:**
- Que `check` sea **UN solo `Check`** (aquí `singleCheckRelations` prueba que la DERIVACIÓN resuelve;
  el «un Check» es un espía contra el servidor).
- El truncado REAL de `listObjects` vía `ListObjects` contra el `:8101` de tope 3 (aquí se SIMULA con
  `limits.listMaxResults`).
- La **paridad** `database`↔`openfga` (misma pregunta ⇒ misma respuesta) y el caso-exploit VERDE
  contra el store COMPARTIDO (spec puente, condición dura del veredicto — lote 4-4).
- El modelo FUSIONADO real (profundidad 22, bytes): eso es 4-1 + 4-4, no un doble.

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, servidor tranquilo)

| modo | antes (4-1) | ahora | delta |
|---|---|---|---|
| `npm test` | 810 | **858** | +48 |
| `test:sqlite-file` | 815 | **863** | +48 |
| `test:pg` | 909 | **957** | +48 |
| `test:mysql` | 909 | **957** | +48 |

+48 = 11 (unidad: `relations.spec.ts`) + 34 (contrato: 17×2 harnesses) + 3 (conteo:
`relations_harness.spec.ts`). Aditivo puro: las suites de 3b + 4-1 idénticas. `tsc`, `typecheck`,
`check:purity` y `build` limpios. 0 stores creados en el `:8101` (los tests son in-memory).

> **Nota de robustez del oráculo (heredada del 4-1, NO de este lote):** corriendo los 3 motores casi
> a la vez contra el MISMO `:8101`, el test de profundidad del 4-1 (`FACTS_MAX_RESOLVE_DEPTH` a 23
> saltos) falló 1 vez por SATURACIÓN del servidor («ninguna de las 500 preguntas devolvió veredicto»),
> exactamente el flaky que el informe del 4-1 anotó para plegar en 4-4. Con el `:8101` tranquilo,
> `test:sqlite-file` vuelve a **863 (todas verdes)**. No es un fallo de este lote ni de mi código.

## Frontera de pureza (lo que el encargo pidió verificar)

`check:purity` regla 2 vigila que `src/relations/` **no importe `src/manager` ni `src/drivers/*`**
(aislamiento de BUNDLE). Lo confirmé: `define_relations_config.ts` y `manager.ts` solo importan
`../types.js`, `../errors.js` y `../identity.js`. **Gap documentado (ya señalado por auditor/tester):**
la regla solo aísla el BUNDLE, no la frontera SEMÁNTICA roles↔relations (que una tupla de relación no
conceda en `roles.authorize`) — eso son F-01/F-02, que son del **lote 4-5**, no de este. Además el
docstring de la regla dice «solo puede depender del puerto, errores y `src/shared/`», pero el CÓDIGO
solo bloquea `manager` + `drivers/*`; importar `src/identity.ts` (gramática compartida) está permitido
por el código y es lo que hago —moví `RESERVED_FACTS_TYPES` ahí como FUENTE ÚNICA para no duplicar la
lista de reservados a ambos lados de la frontera—. No toqué la regla; si el dueño quiere que el
docstring y el código coincidan (whitelist explícita de `src/shared/`), es una decisión suya.

## Lo que NO se hizo, y por qué

- **Los drivers reales `database`/`openfga`**: son 4-3 y 4-4. Este lote es puerto + config + doble.
- **El caso-exploit VERDE en el store COMPARTIDO (spec puente ambos puertos)**: es la condición dura
  del veredicto y vive en **4-4** (necesita el `:8101` y el driver openfga real). Aquí F-05 se prueba
  con el doble porque corta ANTES del driver.
- **`{trx}` en `relate`/`unrelate`**: DIFERIDO (decisión (b) del juez: paridad con `roles/`, 2.6+). El
  puerto no lo expone; el driver `database` lo usará INTERNAMENTE en 4-3.
- **Caducidad de relación (R-15) / `authz_relations` insert-delete-only**: es 4-3 (driver `database`).
- **Anclar F-01/F-02 con mutante de conflación / la carrera `defineRelationsConfig`↔`syncAuthzCatalog`
  / `reconcile` de relaciones**: son 4-5.
- **El conteo literal del juez `'2.4'`**: el juez decidió runner SEPARADO, así que NO hay nivel `'2.4'`
  ni se toca `contract_harness.spec.ts`. El conteo de relaciones vive en `relations_harness.spec.ts`
  (17 casos/harness, cobertura de las 6 capacidades), que es el mecanismo que 4-6 clavará entero.
- **`enumerateRelations` como método real de reconcile**: el puerto lo declara y el doble lo cumple
  (capacidad con sus dos caras), pero el uso en `authz:reconcile` es 4-5.

Nada del plan resultó imposible ni contradictorio con el código.
