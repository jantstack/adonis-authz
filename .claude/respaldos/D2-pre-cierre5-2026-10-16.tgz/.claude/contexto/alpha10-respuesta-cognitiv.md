# Respuesta a COGNITIV (sexto informe, acuse de alpha.9) — alpha.10

> Asunto: Re: alpha.9 instalada — 2.4.0-alpha.10 publicada: los cinco detalles cerrados, la dirección rancia en código y dos rupturas que tocan vuestro runbook

Gracias por el acuse y por la lección de vuelta: «alarmas del defecto, no guardianes del comportamiento» es exactamente
lo que nos pasó a nosotros también en esta ronda (abajo). `2.4.0-alpha.10` está publicada con dist-tag `alpha`.

**Antes que nada, dos rupturas que pueden tocar vuestro código o runbook:**
1. **La dirección rancia se rechaza en código.** Si `to` es el driver activo, el único origen aceptado es `to` mismo
   (la pasada de mantenimiento). Cualquier otro origen —por `--from`, elegido por descarte o las tablas `authz_*`— sale
   con 500 `E_AUTHZ_STALE_SOURCE_REFUSED` antes de leer o congelar nada. Vale igual para `authz:reconcile` y
   `authz:relations:reconcile`. Si algún script lo hacía a propósito, necesita `--allow-stale-source`.
   Consecuencia en el runbook: las verificaciones con `--from … --dry-run` van **antes** de cambiar `default`; después
   del cambio solo queda el `--dry-run` de mantenimiento, sin `--from`. El README trae el runbook reordenado.
2. **Si llamáis al reconcile de relaciones desde código:** `reconcileRelations` ya no se exporta desde la raíz. La vía
   pública es `runRelationsReconcile(authorization, { toKey, fromKey, partitions })`, que resuelve los drivers por el
   manager (sin instancias ni `activeKey`) y aplica la guarda y la ventana. Era una puerta real: vuestro bucle por
   partición escrito según nuestro propio README habría resucitado lo retirado tras el cutover.

**Vuestros cinco puntos**
1. **«no escribe ni borra un solo hecho»**: la frase era falsa, como medisteis. Ahora dice lo que `--prune` borra de
   verdad en la pasada de mantenimiento (hechos de scopes que ya no resuelven, caducados, de roles o permisos retirados,
   y sobrantes), en el comando, el README y la documentación interna; un caso contra OpenFGA real reproduce vuestro
   «sobran 3, borradas 3».
2. **`authz:unfreeze` con la ventana caducada**: ahora es error con exit ≠ 0, con la hora de caducidad y cuánto tiempo
   estuvieron abiertas las escrituras, y limpia la fila (un segundo `unfreeze` ya sale en verde). Además —lo encontramos
   al auditar—, ninguna pasada toma ya una ventana de **operador** caducada: 503 `E_AUTHZ_OPERATOR_WINDOW_EXPIRED`, con
   la comprobación dentro del mismo UPDATE atómico. Antes, un reconcile lanzado tras vencer vuestra ventana la pisaba, se
   certificaba en verde y borraba la evidencia.
3. **`leaseMs: null` en la ventana adoptada**: el reporte trae `untilMs` real y el lease restante, y los dos comandos
   dicen cuándo vence la ventana en la que corrió la pasada (la vuestra o una propia).
4. **Dirección equivocada con `openfga` activo**: el punto 1 de arriba. La guarda mira el origen RESUELTO, no la
   bandera, y compara drivers por identidad, no por nombre (registrar el mismo driver con otro alias ya no la salta).
   Dos límites declarados: lee el `config.default` del proceso que ejecuta el comando (un Job con otro entorno la
   apaga), y no detecta dos factories distintas que construyen el mismo store. Un sello durable del driver activo va a 2.5.
5. **`--partition-type=app --partition-uuid`**: exit ≠ 0, y la misma trampa en la función de relaciones da 500.

**Y lo que salió al barrer**, además de lo anterior: el runbook del README no incluía `authz:relations:reconcile` por
partición (ahora sí, con qué driver sirve relaciones); `authz:scopes:relay --dry-run` con una aparcada sale ≠ 0;
`--only` nombra cada id que no aterrizó —distinguiendo «no está en la cola» de «no evaluado por `--limit`», nuevo
campo `notEvaluated` en el reporte— y nunca dice «outbox vacía»; un `--max-age` inválido se rechaza antes de tocar la
cola.

**Nota honesta, en el sentido de vuestra lección**: dos casos de nuestra suite eran la especificación del defecto —uno
migraba con un manager que ya servía desde `openfga` (vuestro punto 4) y otro trataba una ventana caducada como «nunca
hubo» (vuestro punto 2)—. Los hemos dado la vuelta.

**Sobre `2.4.0` estable**: hemos cambiado cómo cerramos. Además de lo de siempre, la estable exige un runbook de cutover
ejecutable en CI, una auditoría de sistema sobre la RC sin hallazgos graves abiertos, y **un ensayo vuestro sobre el
tarball exacto de la RC, con plazo cerrado**. Os avisaremos con la RC y el plazo.

Verificada en SQLite, SQLite-fichero, PostgreSQL 18 y MySQL 8.4 contra OpenFGA, con auditoría y dos re-ataques sobre el
diff.
