# Panel «tenencia» · ronda 2 — tester de contrato (deny AHORA, línea única, siguiente estable 2.5.0)

> Fecha: 2026-10-14. Entradas: `panel-tenencia-2-coordinador.md`, mi ronda 1 (`panel-tenencia-tester.md`), veredicto
> `panel-tenencia-juez.md` (D5 = corte de camino), `panel-tenencia-analista.md` §1.2–1.5 (modelo anidado medido en v1.19),
> `panel-tenencia-auditor.md`, `CLAUDE.md` «Cómo se decide un cambio» 1–10, `linajes.md`, `RETOMAR.md`. Leído código:
> `src/relations/{manager,reconcile,define_relations_config}.ts`, los dos drivers de relaciones, `src/identity.ts`
> (`scopeSpellings`), `src/testing/relations_contract.ts`, `tests/relations_{harness,database,events_docs}.spec.ts`,
> `tests/command_flags.spec.ts` (guardia R1), `providers/authz_provider.ts`, `.github/workflows/ci.yml`.
> Solo lectura salvo este fichero. Nada contra OpenFGA (`:8101`/`:8103`): todo lo de `openfga` es lectura de código o
> la medición del analista.
>
> Marcas: **HOY** (tiene test hoy, archivo:línea) · **PROP** (se puede testear; digo cómo) · **NO-OBS** (no observable
> con la infraestructura actual; digo qué faltaría) ⇒ no se promete.

---

## 0 · Lo que he corrido y medido (resultado real, sqlite `:memory:`, specs sueltos)

| Qué | Resultado |
|---|---|
| `relations_harness` / `relations_contract` / `relations_database` / `relations_events_docs` / `relations_service` / `clock` / `capabilities` | 9 / 44 / 47 / 14 / 11 / 1 / 9 — todo verde en alpha.10 sin tocar |
| **Mutante P5-1** (borrar `clock: config.clock`, `providers/authz_provider.ts:59`) en una copia en scratch | **sobrevive**: `relations_service` 11/11, `command_flags` 46/46, `reconcile` 65/65, `configure` 4/4 verdes (los specs que cargan el provider; `relations_openfga` sin servidor = 3 skips). Lo que en ronda 1 era un grep ahora está medido |
| `defineRelationsConfig` con claves desconocidas (`deny: true`, `denny: 1`), un ciclo `editor ⊇ viewer ⊇ editor` y una relación de 50 caracteres | **las tres se aceptan**; las claves desconocidas se TIRAN en silencio de la config congelada (ver H3) |
| Reflexión: `Object.getOwnPropertyNames(OpenFgaRelationsDriver.prototype)` | `withClock, relate, unrelate, check, listObjects, listSubjects, membersOf, enumerateRelations, enumerateRelationsMany, purgeObject, purgeSubject` (11) |
| Reflexión sobre `RelationsManager` y `DatabaseRelationsDriver` fuera del harness | **no se pueden importar sin app booteada** (`@adonisjs/lucid/services/db` lanza en el import, vía `src/freeze.ts`). La guardia tiene que ir dentro de `bootApp()` |
| `scripts/check_flag_mutants.mjs` | **no existe** (CLAUDE.md:910 y `linajes.md` L5 lo citan; `RETOMAR.md` lo da como «siguiente del orden»). Tampoco hay job `cutover-runbook` en `ci.yml` (jobs: `test`, `openfga`, `engines`, `compat`) |
| T1 por corte, 64 estados × 7 semánticas candidatas (script en scratch, abajo) | la fila 35 (`owner` + deny(`editor`)) mata sola a los 7 mutantes; **P1-M (monotonía) NO fija la semántica**: CONSULTA, GRANT-LIT y CORTE-INV son monótonas (0 estados no monótonos) |

Cifras de cabecera de alpha.10 (de `RETOMAR.md`, no re-medidas: correr la suite completa está fuera de lo permitido):
**1437 / 1463 / 1559 / 1561**.

---

## 1 · Hallazgos nuevos (cambian el plan o su criterio)

- **H1 · La monotonía no basta como criterio de D5.** P1-M (`owner ⇒ editor ⇒ viewer` en los 64 estados) pasa con la
  semántica por CONSULTA (la de COGNITIV §2.5), con «el deny anula solo el grant de su misma relación» (GRANT-LIT) y con
  el corte en la dirección equivocada (CORTE-INV). Lo que fija D5 es la **tabla exacta** de §2 (192 respuestas), no la
  propiedad. P1-M se queda como guardián secundario (mata LITERAL, CAMINO y CONS-INV).
- **H2 · `decideMany` tri-estado + corte de camino deja pasar la herencia del consumidor.** Si el tri-estado se define
  como el analista (`deny` ⇔ `Check(s, denied_R, o)`), con `owner` + deny(`editor`) y la pregunta en `viewer` sale
  `check = F` y `denied_viewer = F` (en el modelo anidado `denied_viewer` solo lleva el `this`: `viewer` es la cima) ⇒
  **`none`** ⇒ el evaluador de cadena del consumidor hereda del padre. El deny que cortó el grant no corta la cadena. Es
  una decisión nueva del dueño (**D7**): ¿`deny` en el tri-estado = «deny en `up*(R)`» (la del analista, hoy medida) o
  «deny vivo sobre cualquier relación de `up*(down*(R))`» (cualquier deny comparable)? Las dos se pueden fijar con un
  caso; lo que no vale es no decidirlo.
- **H3 · alpha.10 tira en silencio las claves desconocidas de la config de relaciones** (medido). Consecuencias: (a) un
  `denny: true` en 2.5 es una entrada inerte de L5 salvo que 2.5 rechace claves desconocidas; (b) **un proceso alpha.10
  que lea una config 2.5** (pod viejo en rolling deploy, CLI viejo, o la config PERSISTIDA de `relations_config_store`)
  pierde `deny: true` y un `openfga:provision` desde ahí **republica el modelo sin `denied_*`**: fail-open en todo el
  store. Va en la migración (§6, E7) y en la guardia L9 (§5, S11).
- **H4 · Las tres precondiciones del juez están confirmadas como agujeros reales hoy**: ciclo de `includes` aceptado,
  relación de 44–50 caracteres aceptada (no cabe con `denied_`), claves desconocidas aceptadas.
- **H5 · D4 = 422 deja inalcanzables las tuplas viejas con partición sin guiones.** `scopeSpellings` solo expande
  32-hex ⇒ 8-4-4-4-12 (`identity.ts:261-267`), **nunca al revés**. Hoy la única forma de barrer una fila escrita sin
  guiones es purgar con la ortografía sin guiones (`relations_database.spec.ts:206,229`). Con D4 = 422 esa entrada
  muere y la purga canónica no la ve: quedan filas que nadie lee ni borra, y los allows de esas filas dejan de conceder
  en silencio (fail-closed, pero pérdida no declarada). Hace falta una receta de canonización ejecutada (§6, E2) o una
  operación de plataforma. Y como 2.5.0-alpha.1 (lote A) todavía las aceptaría, **D4 debería entrar en el lote A**, no
  en el D: así COGNITIV arranca su fase 0 sin crear población nueva sin guiones.
- **H6 · Tres escrituras que hoy solo QUITAN acceso pasan a poder DARLO**, y no están en la lista del auditor:
  `unrelate(u, member, group:g)` (u sale de un grupo denegado ⇒ su allow directo vuelve), `purgeObject(group:g)` (borra
  las membresías ⇒ el deny al grupo deja de alcanzar a nadie) y `purgeSubject(group:g#member)` (borra los denies del
  grupo). Es correcto por diseño, pero es inversión de signo: una policy de `assertWrite` del consumidor que deje a
  cualquiera «salir de un grupo» creyendo que reduce acceso pasa a ser una escalada. Filas S8–S10 de §5 + README.
- **H7 · Las piezas de infraestructura que el criterio del juez da por existentes no existen**: el script de mutantes de
  banderas y el job `cutover-runbook`. El lote 0 tiene que construir su propio corredor de mutantes (§4.4) y la RC el
  job.
- **H8 · El doble publicado `makeRelationsDriver` no aplica F-05 por sí mismo** (no hay `assertRelationDeclared` en
  `src/testing/relations_contract.ts`) y el runner solo exige el corte en el MANAGER («driver intacto»). Un driver de
  terceros puede no re-validar F-05 y pasar el contrato; los dos del paquete sí lo hacen. La guardia necesita una
  decisión: fila con sonda (y caso nuevo en el runner) o exención firmada (D6).
- **H9 · La doctrina del runner de relaciones «cada cara es UN caso; el total no se mueve»**
  (`relations_harness.spec.ts:103`) es incompatible con ~15 casos de deny colgados de `relationDenies: true`. Hay que
  pasar a conteo por cara (como roles: 83 sin `purgeRole`, 88 con) y decirlo en el comentario del literal.
- **H10 · P4-7 (tipos mezclados en `checkMany`) no es observable con la config fija del contrato**: solo hay
  `document` y el `group` built-in, que no comparten nombre de relación. Hace falta un segundo tipo declarado en
  `contractRelationsConfig` (export publicado de `/testing`; cambio anunciado).
- **H11 · Las vistas de `withClock` no están en ningún inventario.** Las dos clases devuelven una instancia nueva; un
  `withClock` que envuelva en un objeto sin las guardas pasaría todo. La guardia corre también sobre
  `driver.withClock(now)`.

---

## 2 · (1) T1 rehecha con CORTE DE CAMINO

### 2.1 Definición y semánticas candidatas (todas como mutantes)

Retículo del contrato (`contractRelationsConfig`): `owner ⇒ editor ⇒ viewer` (`editor includes owner`, `viewer includes
editor`). `up*(o)={o,e,v}`, `up*(e)={e,v}`, `up*(v)={v}`; `down*(v)={v,e,o}`, `down*(e)={e,o}`, `down*(o)={o}`.
A = relaciones con allow directo vivo del holder; D = relaciones con deny directo vivo del holder; Q = la pregunta.

| Semántica | `check(s, Q, o)` = T sii | Quién la cometería |
|---|---|---|
| **CORTE (D5, la buena)** | ∃ T ∈ A ∩ down*(Q) con up*(T) ∩ D = ∅ | — (≡ modelo anidado medido: `X = (this ∨ I…) but not denied_X`, `denied_X = this ∨ denied_P` para P ⊇ X; lo comprobé en los 64 estados) |
| CONSULTA | A ∩ down*(Q) ≠ ∅ ∧ up*(Q) ∩ D = ∅ | `database` que resta por pregunta (COGNITIV §2.5) |
| LITERAL | A ∩ down*(Q) ≠ ∅ ∧ Q ∉ D | postura del coordinador ronda 1 |
| CAMINO | ∃ T ∈ A ∩ down*(Q) con (up*(T) ∩ down*(Q)) ∩ D = ∅ | FGA con `denied_X` sin cierre (solo `this`) |
| GRANT-LIT | ∃ T ∈ A ∩ down*(Q) con T ∉ D | `database` que solo resta la fila de la misma relación |
| CORTE-INV | ∃ T ∈ A ∩ down*(Q) con down*(T) ∩ D = ∅ | `database` que copia `#expandDown` para el deny (mutante del auditor 🟠 5) |
| CONS-INV / FGA-INV | por consulta con down*(Q) / modelo anidado con `denied_X` cerrado hacia abajo | grafo de `includes` invertido al generar |

Monotonía (estados no monótonos de 64): CORTE 0 · CONSULTA 0 · GRANT-LIT 0 · CORTE-INV 0 · LITERAL 20 · CAMINO 18 ·
CONS-INV 14 ⇒ **H1**.

### 2.2 Tabla de 64 estados (holder directo, sin caducidad). Respuesta esperada por fila

«PAR» = alguna semántica plausible en UN solo driver da otra respuesta en esa fila ⇒ la fila **detecta paridad
database ↔ openfga** en el BRIDGE (`relations_bridge.spec.ts`) y es el mutante que mata en la COMÚN. «ctl» = todas las
semánticas coinciden: control (si sale rojo, el fallo es del allow, no del deny). 37 PAR / 27 ctl.

| # | allows A | denies D | v / e / o esperado | mutantes que la delatan (relación) | tipo |
|---|---|---|---|---|---|
| 1 | ∅ | ∅ | F / F / F | — | ctl |
| 2 | ∅ | {v} | F / F / F | — | ctl |
| 3 | ∅ | {e} | F / F / F | — | ctl |
| 4 | ∅ | {e,v} | F / F / F | — | ctl |
| 5 | ∅ | {o} | F / F / F | — | ctl |
| 6 | ∅ | {o,v} | F / F / F | — | ctl |
| 7 | ∅ | {o,e} | F / F / F | — | ctl |
| 8 | ∅ | {o,e,v} | F / F / F | — | ctl |
| 9 | {v} | ∅ | T / F / F | — | ctl |
| 10 | {v} | {v} | F / F / F | — | ctl |
| 11 | {v} | {e} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 12 | {v} | {e,v} | F / F / F | — | ctl |
| 13 | {v} | {o} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 14 | {v} | {o,v} | F / F / F | — | ctl |
| 15 | {v} | {o,e} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 16 | {v} | {o,e,v} | F / F / F | — | ctl |
| 17 | {e} | ∅ | T / T / F | — | ctl |
| 18 | {e} | {v} | F / F / F | LITERAL(e), CAMINO(e), GRANT-LIT(ve), CORTE-INV(ve), CONS-INV(e), FGA-INV(e) | PAR |
| 19 | {e} | {e} | F / F / F | CONSULTA(v), LITERAL(v) | PAR |
| 20 | {e} | {e,v} | F / F / F | — | ctl |
| 21 | {e} | {o} | T / T / F | CORTE-INV(ve), CONS-INV(ve), FGA-INV(ve) | PAR |
| 22 | {e} | {o,v} | F / F / F | LITERAL(e), CAMINO(e), GRANT-LIT(ve) | PAR |
| 23 | {e} | {o,e} | F / F / F | CONSULTA(v), LITERAL(v) | PAR |
| 24 | {e} | {o,e,v} | F / F / F | — | ctl |
| 25 | {e,v} | ∅ | T / T / F | — | ctl |
| 26 | {e,v} | {v} | F / F / F | LITERAL(e), CAMINO(e), GRANT-LIT(ve), CORTE-INV(ve), CONS-INV(e), FGA-INV(e) | PAR |
| 27 | {e,v} | {e} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 28 | {e,v} | {e,v} | F / F / F | — | ctl |
| 29 | {e,v} | {o} | T / T / F | CORTE-INV(ve), CONS-INV(ve), FGA-INV(ve) | PAR |
| 30 | {e,v} | {o,v} | F / F / F | LITERAL(e), CAMINO(e), GRANT-LIT(ve) | PAR |
| 31 | {e,v} | {o,e} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 32 | {e,v} | {o,e,v} | F / F / F | — | ctl |
| 33 | {o} | ∅ | T / T / T | — | ctl |
| 34 | {o} | {v} | F / F / F | LITERAL(eo), CAMINO(eo), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(eo), FGA-INV(eo) | PAR |
| 35 | {o} | {e} | F / F / F | CONSULTA(v), LITERAL(vo), CAMINO(o), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(o), FGA-INV(o) | PAR |
| 36 | {o} | {e,v} | F / F / F | LITERAL(o), CAMINO(o), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(o), FGA-INV(o) | PAR |
| 37 | {o} | {o} | F / F / F | CONSULTA(ve), LITERAL(ve) | PAR |
| 38 | {o} | {o,v} | F / F / F | LITERAL(e) | PAR |
| 39 | {o} | {o,e} | F / F / F | CONSULTA(v), LITERAL(v) | PAR |
| 40 | {o} | {o,e,v} | F / F / F | — | ctl |
| 41 | {o,v} | ∅ | T / T / T | — | ctl |
| 42 | {o,v} | {v} | F / F / F | LITERAL(eo), CAMINO(eo), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(eo), FGA-INV(eo) | PAR |
| 43 | {o,v} | {e} | T / F / F | LITERAL(o), CAMINO(o), GRANT-LIT(eo), CORTE-INV(eo), CONS-INV(vo), FGA-INV(vo) | PAR |
| 44 | {o,v} | {e,v} | F / F / F | LITERAL(o), CAMINO(o), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(o), FGA-INV(o) | PAR |
| 45 | {o,v} | {o} | T / F / F | CONSULTA(e), LITERAL(e), CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 46 | {o,v} | {o,v} | F / F / F | LITERAL(e) | PAR |
| 47 | {o,v} | {o,e} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 48 | {o,v} | {o,e,v} | F / F / F | — | ctl |
| 49 | {o,e} | ∅ | T / T / T | — | ctl |
| 50 | {o,e} | {v} | F / F / F | LITERAL(eo), CAMINO(eo), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(eo), FGA-INV(eo) | PAR |
| 51 | {o,e} | {e} | F / F / F | CONSULTA(v), LITERAL(vo), CAMINO(o), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(o), FGA-INV(o) | PAR |
| 52 | {o,e} | {e,v} | F / F / F | LITERAL(o), CAMINO(o), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(o), FGA-INV(o) | PAR |
| 53 | {o,e} | {o} | T / T / F | CORTE-INV(ve), CONS-INV(ve), FGA-INV(ve) | PAR |
| 54 | {o,e} | {o,v} | F / F / F | LITERAL(e), CAMINO(e), GRANT-LIT(ve) | PAR |
| 55 | {o,e} | {o,e} | F / F / F | CONSULTA(v), LITERAL(v) | PAR |
| 56 | {o,e} | {o,e,v} | F / F / F | — | ctl |
| 57 | {o,e,v} | ∅ | T / T / T | — | ctl |
| 58 | {o,e,v} | {v} | F / F / F | LITERAL(eo), CAMINO(eo), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(eo), FGA-INV(eo) | PAR |
| 59 | {o,e,v} | {e} | T / F / F | LITERAL(o), CAMINO(o), GRANT-LIT(eo), CORTE-INV(eo), CONS-INV(vo), FGA-INV(vo) | PAR |
| 60 | {o,e,v} | {e,v} | F / F / F | LITERAL(o), CAMINO(o), GRANT-LIT(veo), CORTE-INV(veo), CONS-INV(o), FGA-INV(o) | PAR |
| 61 | {o,e,v} | {o} | T / T / F | CORTE-INV(ve), CONS-INV(ve), FGA-INV(ve) | PAR |
| 62 | {o,e,v} | {o,v} | F / F / F | LITERAL(e), CAMINO(e), GRANT-LIT(ve) | PAR |
| 63 | {o,e,v} | {o,e} | T / F / F | CORTE-INV(v), CONS-INV(v), FGA-INV(v) | PAR |
| 64 | {o,e,v} | {o,e,v} | F / F / F | — | ctl |

**Filas con nombre** (casos sueltos de la COMÚN además del barrido; cada una se lee sola cuando falla):

| fila | caso con nombre | mata |
|---|---|---|
| 34 | *«un deny en viewer bloquea al owner: F/F/F»* | LITERAL, CAMINO, GRANT-LIT, CORTE-INV, CONS-INV, FGA-INV |
| 35 | *«un deny en editor anula el grant de owner entero: F/F/F»* (la fila del juez; **mata a los 7 sola**) | todas |
| 43 | *«…salvo un viewer directo: owner + viewer + deny(editor) ⇒ T/F/F»* | LITERAL, CAMINO, GRANT-LIT, CORTE-INV, CONS-INV, FGA-INV |
| 37 | *«deny en owner sin otro grant: F/F/F (no sobrevive ni viewer derivado)»* | CONSULTA, LITERAL |
| 45 | *«owner + viewer + deny(owner) ⇒ T/F/F»* | CONSULTA, LITERAL, CORTE-INV, CONS-INV, FGA-INV |
| 11 | *«un deny en una relación más fuerte no toca un grant más débil: viewer + deny(editor) ⇒ T/F/F»* | CORTE-INV, CONS-INV, FGA-INV |

**Dónde corre.** El barrido entero (64 estados × 3 preguntas = 192 `check`) es UN caso de la COMÚN bajo
`relationDenies: true` (nombre: *«D5 · corte de camino: las 192 respuestas de T1»*), un objeto por estado en una
partición, todas las tuplas escritas antes de preguntar (≤ 192 tuplas; 64 objetos). Lo corren los dos dobles,
`database` en los 4 modos, `:8101` y `:8103`. El BRIDGE repite las 37 filas PAR contra los dos drivers reales con el
mismo reloj y exige igualdad celda a celda (esa es la paridad; la COMÚN da la corrección).

### 2.3 Ejes de T1 (T1-b): se reducen a T1 por SUSTITUCIÓN, no hacen falta tablas nuevas

| Eje | Regla que da la respuesta esperada | Filas mínimas | Dónde |
|---|---|---|---|
| deny transportado por `g#member` (u ∈ g) | igual que la fila T1 con el deny directo | las 37 PAR | COMÚN |
| deny por grupo anidado (g1 ⊂ g2, deny a `g2#member`) | igual que la fila T1 | 34, 35, 43 | COMÚN (DB: 3 motores, CTE) |
| allow transportado por `g#member`, deny directo | igual que la fila T1 | 34, 35, 43 | COMÚN |
| deny con `expiresAt = T` (reloj inyectado) | en T−1 ms = fila T1 con D; en T y T+1 = fila T1 con D \ {esa relación} | 35, 43, 11 | COMÚN, cara `injectableClock: true` |
| membresía con `expiresAt = T` que transporta el deny | en T−1 = fila con D; en T = fila sin ese deny | 35 | COMÚN (`injectableClock: true`) |
| sujeto = userset `g#member` con deny a u ∈ g | `check(g#member, Q)` = fila T1 de **g** (el deny del miembro no sube al grupo) | 35 | COMÚN |
| partición sin guiones | 422 en `deny`/`check`/… (D4); nunca una respuesta | 35 | COMÚN (núcleo, no de capacidad) |
| escritura en orden deny→allow vs allow→deny | misma fila | 35, 43 | COMÚN |

Coste: medio. Infra existente (doble, `withClock`, `:8103`); lo nuevo es el doble con deny y el generador de estados.
El script que genera la tabla (`t1.py`, 50 líneas) se puede portar al spec como oráculo TS: la tabla del informe y el
oráculo del test tienen que salir de la misma función, o divergen (L8).

---

## 3 · (2) Criterio de aceptación POR LOTE

Convención: `id · frase` — **dónde** — *mutante que lo mata*. COMÚN = `runRelationsDriverContract`; DB / FGA = spec del
driver; BRIDGE = `relations_bridge.spec.ts`; REC = `relations_reconcile_contract.ts`; GS = guardia de superficie (§4);
L9 = guardia de signos (§5). «Rojo visto» = el informe del lote pega la ejecución en rojo antes de la línea que lo arregla.

### Lote 0 · guardia de superficie L1 (+ columnas L2/L3/inv. 13/actor) ⇒ sin versión propia (entra en 2.5.0-alpha.1)

| id | caso | dónde | mutante |
|---|---|---|---|
| G-0 | *«el inventario por reflexión = las filas de la tabla»* (manager, dos drivers, sus vistas `withClock`, clases y funciones de relaciones exportadas) | GS | método nuevo sin fila; clase exportada nueva que implemente una operación del puerto |
| G-F05-* | una por operación × capa (§4.2) | GS | quitar la línea F-05 de esa operación |
| G-L2-*, G-L3-*, G-W-*, G-ACT-* | una por escritura × columna | GS | quitar `#assertTransactional` / `#rejectTransaction` / `#writer` / `#assertNotFrozen` / `#write` / `#assertActor` de esa escritura |
| G-R-* | *«una lectura no escribe ni notifica»* (sonda con entrada válida: cero eventos, cero llamadas a escrituras del driver) | GS | reclasificar en la tabla una escritura como lectura (meta-mutante) |
| G-M | *«cada celda no exenta tiene ≥ 1 mutante en el manifiesto y cada mutante del manifiesto existe en la fuente»* | GS (cruce tabla ↔ manifiesto) | borrar una entrada del manifiesto; mutante cuyo `find` ya no casa |
| G-X | *«las exenciones son exactamente las firmadas»* (lista literal con la referencia a `decisiones-dueno-*.md`) | GS | añadir una exención sin firma |

**Salida:** guardia verde; corredor de mutantes (§4.4) con **todos los mutantes muertos** en `:memory:` y `sqlite-file`;
`relations_database.spec.ts:554-599` (la lista a mano) sustituida por la guardia (borrado declarado: −1 caso); `linajes.md`
L1 «M7: guardia de superficie (lote 0)». Cifras: las cuatro de cabecera suben en **N_GS** (= filas de la tabla, ≈ 86 con
las vistas `withClock`, §4.2) − 1, idénticas en los 4 modos (la guardia no depende del motor salvo la columna L2 de
`database`, que en `:memory:` declara `transactionalWrites: false` y sondea la puerta 1). Ningún conteo del runner cambia.

### Lote A · P5 + clave + `checkMany` booleano (+ D4 si el dueño lo adelanta, H5) ⇒ 2.5.0-alpha.1

| id | caso | dónde | mutante |
|---|---|---|---|
| A-1 | *«P5-1 · config.clock llega a authz.relations: reloj fijado en T, una tupla con expiresAt = T no concede por el singleton»* | `relations_service.spec` | borrar `authz_provider.ts:59` (**hoy sobrevive, medido**) |
| A-2 | *«P5-2 · createTestClock devuelve una función estable sobre un valor mutable y no muta el singleton»* | `relations_service.spec` / `clock.spec` | helper que reasigna `config.clock` |
| A-3 | *«P5-3 · ningún método de decisión de src/relations ni de los drivers de relaciones llama a systemClock()»* (solo defaults de constructor, lista literal) | `clock.spec` | método nuevo con `systemClock()` |
| A-4 | *«P5 · el reloj de test gobierna también el lease del freeze»* (letra del README + caso: avanzar 16 s ⇒ la pasada ve su lease vencido) | `freeze.spec` + docs | frase borrada / reloj distinto en la barrera |
| A-5 | *«P3-1 · relationTupleKey es determinista e inyectiva»* (exhaustivo: holder vs userset mismo uuid, tipos distintos mismo uuid, `app` vs partición tipada, `kind` allow/deny, relación) | unitario | quitar cualquier componente de la clave |
| A-6 | *«P3-2 · la clave no cambia al renovar la caducidad (database cambia el uuid de fila) y reconcile cuenta updated, no extra+missing»* | REC (11 → 12) | clave = uuid de fila |
| A-7 | *«P3-4 · reconcile.ts no define clave propia: importa relationTupleKey y scopeKey»* (por fuente, ruta resuelta, patrón C5) | `command_flags.spec` o spec propio | reintroducir `tupleKey`/`scopeKeyOf` local |
| A-8 | *«P3-5 · dos ortografías ⇒ dos claves»* (si D4 entra aquí: *«ortografía sin guiones ⇒ 422»*) | unitario | — |
| A-9 | *«P4-1 · checkMany ≡ N check, posición a posición»* (allow, includes, userset anidado, caducado en el pasado, nada) | COMÚN | mapear por orden de fila de SQL |
| A-10 | *«P4-2 · el orden de la respuesta es el de la petición (F,T,F,T con ids en orden inverso)»* | COMÚN | idem |
| A-11 | *«P4-4a · [a, a, b] ⇒ [x, x, y]»* | COMÚN | `correlationId` = id de objeto; deduplicar sin re-expandir |
| A-12 | *«P4-5 · 50 responde; 51 ⇒ 422 y [] ⇒ 422, ambos con cero llamadas»* | COMÚN | `>` por `>=`; `[]` ⇒ `[]` |
| A-13 | *«P4-6 · F-05 por ítem: un role_binding en la posición 21 de 21 ⇒ 422, cero llamadas»* | COMÚN + GS (fila nueva) | validar solo `objects[0]` |
| A-14 | *«P4-7 · tipos mezclados con la misma relación responden por ítem»* | COMÚN (exige 2.º tipo en `contractRelationsConfig`, H10) | F-05 con el tipo del primero para todos |
| A-15 | *«P4-9 · sin checkMany en el driver el manager compone; el primer 503 propaga y ningún booleano sale»* | COMÚN (lo ejerce el doble MÍNIMO, que no lo implementa) | respaldo que traga errores |
| A-16 | *«P4-3 · un error en UN ítem del batchCheck ⇒ 503 para todos»* | FGA (espía) | `error ⇒ false` |
| A-17 | *«P4-8 · un batchCheck por cada 50, alineado por correlationId con la respuesta barajada»* / *«database: una consulta»* | FGA / DB (espías) | alinear por posición / N consultas |
| A-18 | *«un solo now por lote»* (reloj que avanza 1 ms por lectura; tupla que caduca entre ítems) | COMÚN, cara `injectableClock: true` (se amplía, no suma caso) | `now()` por ítem |
| A-19 | *«current_time viaja en cada ítem del batchCheck»* | FGA (espía) | ítem sin contexto |
| A-20 | README «Testing expiry from your app» y fila `checkMany` (tope 50) en «Limits» atada a la constante | docs + `scope_depth.spec` | cifra del README sin constante |

**Salida:** la guardia se puso **roja** al añadir `checkMany` sin fila (rojo visto) y verde con la fila. Modelo FGA
intacto: `openfga_facts.spec.ts:4304-4330` (`DOCUMENT_DEF`/`EXPECTED_FUSED`) verde sin tocar y `factsModelBytes` igual.
Cifras: `EXPECTED_CASES` 22 → **28** (A-9…A-14 son núcleo; A-15 es A-9 corrido sobre el MÍNIMO, no suma),
`CAPABILITY_KEYS` 8 (sin capacidad nueva, conflicto 9 del juez), REC 11 → 12, `relations_contract.spec` 44 → 56;
README: «F-05 covers all eight operations» ⇒ «nine» (F10 de `relations_events_docs.spec.ts:196` reescrito). Cabecera:
+ (6 × harnesses que corren la COMÚN en ese modo) + unitarios + DB/FGA, con desglose en el informe.

### Mediciones (entre A y D; condición de entrada de D, cada una con artefacto ejecutable, no prosa)

| id | qué | artefacto | decide |
|---|---|---|---|
| M1 | bytes del modelo fusionado con deny en 1, 5, 24 tipos | caso en `openfga_facts.spec` con `OPENFGA_TEST_URL` (delta 0 contra el servidor) | cifras README «24 tipos» y techo |
| M2 | latencia `Check`/`ListObjects` con `but not` | `scripts/bench_*.mjs` (número, no promesa) | nada contractual (NO-OBS como promesa) |
| M3 | qué hace el servidor con `includes` cíclico, con y sin `denied_*` | caso contra `:8101` | justifica el 422 de ciclos en config |
| M4 | `ListObjects` parcial por deadline | contenedor con `OPENFGA_LIST_OBJECTS_DEADLINE` de pocos ms | si se reproduce, caso; si no, queda NO-OBS |
| M5 | ¿un `Write` admite delete + write de la misma clave con otra condición? | caso contra `:8101` | rama de D3 (P1-R2 posible o ventana declarada) |
| **M6** (nuevo) | `Check` con una tupla de deny CONDICIONAL y **sin** `current_time` en el contexto: ¿error, se omite o cuenta? (auditor ⚪ 18, nadie lo midió) | caso contra `:8101` | si «se omite» ⇒ fail-open en cualquier camino que olvide el contexto ⇒ fila S12 de §5 obligatoria con espía |

### Lote D · deny completo (corte de camino) ⇒ 2.5.0-alpha.2

**Entrada (bloquea el lote si falta):** M1, M3, M5, M6 hechas; D2–D5 y D7 decididas; ciclos de `includes` ⇒ 422 en
`defineRelationsConfig` con caso; claves desconocidas ⇒ 422 (H3); D4 resuelto (idealmente ya en A).

| id | caso | dónde | mutante |
|---|---|---|---|
| D-01 | *«deny gana sobre el allow directo; removeDeny lo restaura»* | COMÚN | `check` sin resta |
| D-02 | *«el orden de escritura no importa»* | COMÚN | deny solo si es más reciente |
| D-03 | *«deny y removeDeny idempotentes: un removeDeny levanta un deny repetido; re-removeDeny no-op»* | COMÚN | insert sin «¿ya existe?» |
| D-04 | *«allow y deny del MISMO hecho conviven: unrelate no levanta el deny, removeDeny no quita el allow, listDenies lo sigue viendo»* | COMÚN | DELETE sin filtrar `denied_` |
| D-05 | *«D5 · corte de camino: las 192 respuestas de T1»* | COMÚN + BRIDGE (37 PAR) | las 7 semánticas de §2.1 |
| D-06…D-11 | las seis filas con nombre de §2.2 | COMÚN | ver tabla |
| D-12 | *«P1-M · monotonía en los 64 estados»* | COMÚN | LITERAL, CAMINO, CONS-INV |
| D-13 | *«deny a g#member bloquea a sus miembros, también anidados; deny directo bloquea aunque el allow llegue por grupo»* | COMÚN | CTE del deny sin recursión |
| D-14 | *«check de un USERSET: el deny de un miembro no sube al grupo»* | COMÚN | resta de los denies de miembros |
| D-15 | *«listObjects resta (con más denegados que el tope: :8103); listSubjects NO resta; sigue listando el userset con allow; listDenies da hechos directos completos»* | COMÚN | resta mal colocada |
| D-16 | *«purgeObject/purgeSubject borran también los denies»* | COMÚN | DELETE con `relation NOT LIKE 'denied_%'` |
| D-17 | *«deny sobre un tipo sin deny:true ⇒ 422 E_AUTHZ_RELATION_NOT_DENYABLE; sobre group ⇒ 422; '*' ⇒ 422; userset de un tipo que no es group#member ⇒ 422 (auditor 🟠 9); todos con cero llamadas y cero eventos»* | COMÚN + GS (columna opt-in) | quitar `assertRelationDenyable` |
| D-18 | *«relación denegable > 43 caracteres ⇒ 422 al definir; en un tipo SIN deny una de 50 sigue valiendo»* | unitario | cota global (breaking) o sin cota |
| D-19 | *«expiresAt del deny según D3: omitido en re-deny ⇒ permanente y el resultado devuelve previousExpiresAt; null ⇒ permanente; Date fija; T−1/T/T+1 estricto»* | COMÚN (`injectableClock` ambas caras) | `resolveGrantExpiry` tal cual |
| D-20 | *«eventos: operation deny/removeDeny con actor y expiresAt; requireActor alcanza; assertWrite recibe operation 'deny'; indeterminate en deadline»* | COMÚN | evento sin `operation` nueva |
| D-21 | *«decideMany: 'allow' / 'deny' / 'none' según D7»* — con la fila 35 preguntada en `viewer` fijando la rama (H2) | COMÚN | tri-estado = `(check, denied_R)` si D7 dice lo contrario |
| D-22 | *«un deny de relación no toca roles.authorize ni hasRole; un deny de rol no toca relations.check»* | BRIDGE (store compartido) | modelo que cruza familias |
| D-23 | *«un deny sobre una relación usada en un userset se honra en paridad»* (auditor 🟠 4 B) | BRIDGE | relación efectiva con nombre nuevo |
| D-24 | *«un check con deny + includes + userset anidado sigue siendo UN Check»* | FGA (espía) | resta en cliente |
| D-25 | *«renovar un deny: M5 = sí ⇒ un check entre las llamadas nunca da true (espía con barrera); M5 = no ⇒ el 2.º Write caído deja el evento indeterminate: true»* | FGA | delete-then-write de `relate` sin marca |
| D-26 | *«purga de openfga: allows primero, denies al final; cortada tras el 1.er deleteTuples ningún sujeto denegado concede»* | FGA (espía) | orden del `Read` |
| D-27 | T3 completa (abajo) | REC + kernel (`authz:relations:reconcile`) | ver T3 |
| D-28 | *«relationDenies: false ⇒ deny/removeDeny/listDenies/decideMany ⇒ 500 E_AUTHZ_UNSUPPORTED nombrándolos, cero llamadas»* | COMÚN (cara false; MÍNIMO) | deny que devuelve `void` sin escribir |
| D-29 | *«un tipo sin deny:true genera el modelo byte a byte de alpha.10»* | `openfga_facts.spec` (el literal fusionado existente, verde sin tocar) + literal nuevo `DENY_DEF` | opt-in que se filtra |
| D-30 | *«un alias de la partición jamás evade un deny de relación»* (núcleo, D4) | COMÚN | canonizar solo en escrituras |
| D-31 | *«el driver openfga con un tipo deny:true y un modelo publicado SIN denied_<rel> ⇒ 500 al usarlo»* (cierra H3 b) | FGA | sin comprobación del modelo |
| L9 | la guardia de signos de §5 entera | L9 | ver §5 |

**T3 · reconcile × deny (D-27), por el kernel con la bandera de verdad (regla 7: línea y exit propios por rama):**

| origen | destino | situación | exigido | exit |
|---|---|---|---|---|
| deny | deny | deny vivo | `to.deny`, contado aparte (`written.denies` o equivalente) | 0 |
| deny | deny | deny caducado | `skipped.expired` | 0 |
| deny | deny | allow + deny del mismo hecho | dos escrituras (la clave lleva `kind`) | 0 |
| deny | **sin capacidad** | ≥ 1 deny | **500 antes de escribir**; nunca `skipped` | ≠ 0 |
| tercero que declara `relationDenies: true` sin marcar `kind` | — | — | **no pasa el runner** (censo por `listDenies`) | — |
| deny | deny | deny sobrante con `--prune` | `to.removeDeny`, jamás `unrelate` | 0 |
| deny | deny | pasada cortada (espía) al escribir / al podar | escribe denies antes que allows; poda allows antes que denies; nunca un allow sin su deny | ≠ 0 |
| deny | deny | `--dry-run` | denies a escribir/borrar = deriva | ≠ 0 |
| deny | deny | `massDelete` | cuenta solo allows utilizables | — |

**Salida y cifras:** `CAPABILITY_KEYS` 8 → **9** (`relationDenies`; `RELATIONS_DRIVER_CAPABILITY_KEYS` en el mismo
commit o `capabilities.spec` D-3 lo caza). `EXPECTED_CASES` deja de ser un número (H9): **núcleo 28 + 1 (D-30)** y por
cara `relationDenies: true` ⇒ +n_true (≈ 25: D-01…D-21 y D-30 van a la COMÚN; D-22/D-23 al BRIDGE; D-24…D-26 y D-31 a FGA) / `false` ⇒ +1 (D-28); el literal pasa a
`{ full: 29 + n_true, minimal: 30 }` con el desglose en el comentario. REC 12 → ≈ 18 (T3 por dirección). README:
«F-05 covers all N operations» con N = 13 (las 8 + `checkMany`, `deny`, `removeDeny`, `listDenies`, `decideMany`);
coste por tipo denegable medido (M1) en «Limits» y en la frase de bytes; §Upgrading nueva con caso de letra.
`migration_stub.spec` **no cambia** (sin DDL: si se pone rojo es un defecto). Auditoría de sistema (punto 9).

### Lote C · `listObjectsForSubject` ⇒ 2.5.0-alpha.3

Con D antes que C, P2 nace con el filtro de deny (más barato de probar: cada caso se escribe una vez).

| id | caso | dónde | mutante |
|---|---|---|---|
| C-1…C-14 | P2-1…P2-14 de mi ronda 1 con las ramas del juez (holders, directas + `includes`, `partitions: []` ⇒ 422, cursor `(partition_key, object_uuid)`, userset ⇒ 422, dos ortografías: según D4) | COMÚN / DB / FGA | los de ronda 1 |
| C-15 | *«todo objeto listado tiene check = true, también con deny por grupo»* (propiedad sobre un estado aleatorio sembrado) | BRIDGE | omitir la verificación por `check`/`batchCheck` |
| C-16 | *«filtrar(P2, P) = listObjects(P) para cada partición P»* | BRIDGE | `includes` sin resolver |
| C-17 | *«receta del índice authz_rel_subject_any_idx ejecutada»* | `upgrade_recipe.spec` (pg/mysql/sqlite) | receta que no crea el índice |
| C-18 | *«el stub y el espejo declaran el índice»* | `migration_stub.spec` (hoy compara columnas y FKs: hay que extender K11 a índices o afirmarlo explícito) | índice solo en el stub |

Cifras: `CAPABILITY_KEYS` 9 → 10 (`listObjectsForSubject`, par); `EXPECTED_CASES` + cara true / +1 cara false;
`migration_stub.spec` rojo hasta tocar el espejo (correcto).

### RC 2.5.0 (CLAUDE.md punto 10, trasladado a 2.5.0)

| id | criterio | estado hoy |
|---|---|---|
| RC-1 | job `cutover-runbook` verde contra pg y sqlite-fichero con OpenFGA real | **no existe** (H7) |
| RC-2 | guardia de superficie sin celdas sin mutante; exenciones firmadas | se construye en lote 0 |
| RC-3 | mutantes de banderas: cero vivos sin razón escrita | **el script no existe** (H7) |
| RC-4 | corredor de mutantes de la guardia + L9 en CI, todos muertos | lote 0 / D |
| RC-5 | la migración de §6 ejecutada (E0–E3 en los 3 motores + `:8101`; E4/E5/E7 con el tarball de alpha.10 en proceso hijo) | PROP |
| RC-6 | *«el artefacto publicado sabe fallar»*: el runner del tarball de la RC, contra un driver con CORTE-INV, se pone rojo | PROP |
| RC-7 | auditoría de sistema sobre la RC con 0 🔴/🟠 | — |
| RC-8 | ensayo de COGNITIV sobre el tarball exacto, con plazo | — |
| RC-9 | T1 (D-05) verde en `:memory:`, `sqlite-file`, pg, mysql, `:8101`, `:8103` | — |

---

## 4 · (3) Guardia de superficie del lote 0

### 4.1 Qué enumera por reflexión (dentro de `bootApp()`: sin app no se importan, medido en §0)

1. `Object.getOwnPropertyNames(RelationsManager.prototype)` menos `constructor`.
2. Los prototipos de `DatabaseRelationsDriver` y `OpenFgaRelationsDriver` (este último medido: 11 métodos).
3. **Las vistas**: `Object.getOwnPropertyNames(Object.getPrototypeOf(driver.withClock(c)))` tiene que ser el mismo
   conjunto, y las sondas de las filas del driver corren también sobre la vista (H11).
4. **Exports**: recorrer `package.json#exports` como hace `command_flags.spec.ts:980-1030` (identidad, profundidad 6) y
   recoger toda **clase** cuyo prototipo tenga ≥ 1 nombre de operación del puerto (`relate`, `unrelate`, `check`,
   `listObjects`, `listSubjects`, `purgeObject`, `purgeSubject`, `membersOf`, y las que vayan entrando) y toda
   **función** exportada que reciba un objeto de relación. Ese conjunto tiene que ser exactamente el de la tabla: hoy
   `{RelationsManager, DatabaseRelationsDriver, OpenFgaRelationsDriver, makeRelationsDriver}`. Un wrapper nuevo
   exportado (p. ej. un driver con caché) nace rojo.
5. La instancia de `services/relations` es un `RelationsManager`: cubierta por la clase (se afirma `instanceof`).

### 4.2 La tabla: operaciones × {F-05, puerta trx (L2), freeze (L3), `#write` (inv. 13), actor}

Celdas: ✔ = sonda + mutante · N/A(r) = lectura (la cubre G-R) · EX = exención a firmar (D6) · — = no aplica por firma.

| Operación | Capa | F-05 | L2 | L3 | `#write` | actor |
|---|---|---|---|---|---|---|
| `relate`, `unrelate` | manager | ✔ | ✔ puerta 1 | ✔ | ✔ | ✔ |
| `purgeObject` (tipo), `purgeSubject` (userset) | manager | ✔ | ✔ | ✔ | ✔ | ✔ |
| `check`, `listObjects`, `listSubjects`, `membersOf` | manager | ✔ | N/A(r) | N/A(r) | N/A(r) | N/A(r) |
| `enumerateRelations`, `enumerateRelationsMany` | manager | EX → sustituida por *«no devuelve tipos no declarados»* (lista blanca) | N/A(r) | N/A(r) | N/A(r) | N/A(r) |
| `driver()`, `capabilities()` | manager | EX (salida documentada / sin backend) | — | — | — | — |
| `relate`, `unrelate`, `purgeObject`, `purgeSubject` | `database` | ✔ | ✔ `#writer` (trx ajena/cerrada ⇒ 500, cero sentencias) | EX (doctrina: el freeze no congela `manager.driver()`, ya escrito en CLAUDE.md) | — | — |
| idem | `openfga` | ✔ | ✔ `#rejectTransaction` (500, cero llamadas al cliente con `spyFgaClient`, sin servidor) | EX (idem) | — | — |
| `check`, `listObjects`, `listSubjects`, `membersOf` | `database` | ✔ | — | — | — | — |
| idem salvo `membersOf` | `openfga` | ✔ | — | — | — | — |
| `membersOf` | `openfga` | EX (no recibe argumentos; siempre 500 `E_AUTHZ_UNSUPPORTED`; la sonda afirma el 500 con cero llamadas) | — | — | — | — |
| `enumerateRelations(Many)` | ambos | lista blanca (sonda: una fila `role_binding` sembrada no sale) | — | — | — | — |
| `withClock` | ambos | la tabla entera del driver re-corrida sobre la vista | — | — | — | — |
| `makeRelationsDriver` (doble publicado) | doble | **decisión** (H8): sonda + caso nuevo del runner «driver directo» o EX | — | — | — | — |

Filas que entran después sin tocar el spec (solo la tabla y el manifiesto): `checkMany` (F-05 por ítem, A), `deny` /
`removeDeny` (las 5 columnas + columna nueva **opt-in** 422 `E_AUTHZ_RELATION_NOT_DENYABLE`, D), `listDenies` (F-05 +
opt-in), `decideMany` (F-05 por ítem + opt-in), `listObjectsForSubject` (F-05 de tipo + 422 userset, C).

### 4.3 Cómo se prueba cada columna (una sonda por celda, `test.with(dataset)` para que el rojo nombre la fila)

| Columna | Sonda (entrada mínima que solo esa guarda corta) | Afirma | Mutante |
|---|---|---|---|
| F-05 | objeto `role_binding` (o userset `role_binding#assignee`; o relación `assignee` en `document`; o relación `undefined`) | 422 con `code` exacto; manager: cero llamadas al driver (Proxy espía) y cero eventos; `database`: cero accesos a la conexión; `openfga`: cero llamadas al cliente | borrar `this.#assertDeclared(...)` / `assertRelationDeclared(...)` de ESA operación |
| L2 | manager: `{ transaction: trx }` sobre driver con `transactionalWrites: false` · `database`: trx de otra conexión / cerrada · `openfga`: cualquier `{ transaction }` | 500 `E_AUTHZ_UNSUPPORTED` / `E_AUTHZ_CONFIG`, cero llamadas | borrar `#assertTransactional` / el `#writer` de esa operación (usar `db` directo) / `#rejectTransaction` |
| L3 | otro manager sostiene `freeze()` sobre la misma base | 503 `E_AUTHZ_FROZEN`, cero llamadas, cero eventos | borrar `await this.#assertNotFrozen(op)` |
| `#write` | driver espía que lanza `AuthorizationBackendTimeoutError` | evento con `indeterminate: true` ANTES del 503 | llamar al driver sin `#write` |
| actor | `requireActor: true` sin actor; y `actor: { uuid: 'A#B' }` | 422 `E_AUTHZ_ACTOR_REQUIRED` / `E_AUTHZ_INVALID_IDENTITY`, cero llamadas | borrar `#assertActor` |
| orden | role_binding **y** congelado a la vez | 503 (el freeze va antes que F-05: lo fija el orden de hoy) | invertir dos líneas |
| G-R | entrada válida a cada lectura | cero eventos, cero llamadas a escrituras del driver | meta-mutante: reclasificar una escritura como lectura en la tabla |

### 4.4 Corredor de mutantes (no existe; lo construye el lote 0)

`scripts/check_guard_mutants.mjs` + `tests/fixtures/guard_mutants.json` (`{ id, celda, file, find, replace, expectRed:
<título del caso> }`). Copia el árbol a un directorio temporal (jamás muta el working tree: regla de revisiones no
concurrentes), aplica un mutante, corre solo el spec de la guardia, exige que falle **el caso nombrado** (no
cualquiera), y reporta vivos. G-M cruza celdas ✔ ↔ manifiesto en el propio spec (sin correr mutantes), así que «celda
sin mutante» es rojo en `npm test`, y el corredor va en un job de CI. Un mutante que sobrevive es equivalente-con-razón
escrita o rojo.

**Exenciones a firmar (D6):** `driver()`, `capabilities()`, F-05 de `enumerateRelations(Many)` (sustituida por la sonda
de lista blanca), freeze en la capa driver (ya es doctrina), `membersOf` de `openfga`, y la decisión sobre
`makeRelationsDriver` (H8).

---

## 5 · (4) Guardia L9 (inversión del signo) como test

`tests/deny_sign_guard.spec.ts`. **Propiedad universal**: *ningún fallo inyectado deja a un sujeto que tenía un deny
vivo antes del fallo con `check = true` después, salvo las filas declaradas, que tienen caso y línea en el README.*
Cada fila: estado previo sembrado (por defecto la fila 43 de T1 para u y la fila 35 para w) → fallo → afirmación sobre
`check`, evento y salida. Además, la guardia enumera por reflexión las **escrituras** de la tabla de §4.2 y exige que
cada una aparezca en ≥ 1 fila («fallo a mitad») o declare «una sola petición» (G-L9-0).

| # | Fallo inyectado | Cómo | Afirma | Dónde |
|---|---|---|---|---|
| S1 | 2.º `Write` de la renovación de un deny cae (503 no-timeout) | espía sobre el cliente FGA | M5 sí: no hay 2.º `Write`; M5 no: `check(u)` sigue F **o** evento `indeterminate: true` (jamás «no ocurrió» con `check = T`) | FGA |
| S2 | `check` lanzado entre las dos llamadas de la renovación | espía con barrera | `check = F` (o fila declarada si D3 elige ventana) | FGA |
| S3 | purga cortada tras el 1.er `deleteTuples` | espía | ningún sujeto denegado concede; `indeterminate: true` | FGA |
| S4 | reconcile cortado al escribir (tras k escrituras) | espía en `to` | en el destino ningún allow sin su deny | REC |
| S5 | reconcile `--prune` cortado | espía | idem (allows podados primero) | REC |
| S6 | origen con denies, destino sin `relationDenies` | doble MÍNIMO | 500 antes de la 1.ª escritura | REC |
| S7 | re-deny con `expiresAt` omitido sobre deny temporal | API | permanente + `previousExpiresAt` (D3) | COMÚN |
| S8 | `unrelate(u, member, g)` con deny a `g#member` | API | **fila declarada**: u recupera su allow directo; caso con nombre + README («salir de un grupo denegado da acceso») | COMÚN |
| S9 | `purgeObject(group:g)` | API | **fila declarada** idem | COMÚN |
| S10 | `purgeSubject(g#member)` | API | **fila declarada**: borra los denies del grupo | COMÚN |
| S11 | pod/driver con el modelo VIEJO (`modelId` sin `denied_*`) | dos drivers sobre el mismo store, uno pineado al modelo anterior | lector viejo: `check = T` (**fila declarada**, ventana del rolling deploy, runbook); escritor con tipo `deny: true` sobre modelo sin `denied_*`: 500 al usarlo (D-31), nunca un deny «escrito» que no existe | FGA |
| S12 | contexto sin `current_time` | espía que lo quita en `check`/`batchCheck`/`listObjects` | según M6: nunca `T` para u (503 o F) | FGA |
| S13 | reloj adelantado / atrasado en UN proceso | `withClock` | borde estricto T−1/T/T+1 del deny; un `now` por operación (`checkMany`/`decideMany`) | COMÚN |
| S14 | partición sin guiones en cada operación | API | 422 (D4), jamás una respuesta | COMÚN (núcleo) |
| S15 | `error` en un ítem de `batchCheck` (`checkMany`/`decideMany`) | espía | 503 total; nunca `false`/`none` por ítem | FGA |
| S16 | `ListObjects` al tope con más denegados que el tope | `:8103` | ningún denegado aparece; `truncated` solo si hay allows de más | FGA (`:8103`) |
| S17 | proceso alpha.10 sobre datos con denies (rollback) | hijo con el tarball 2.4.0-alpha.10 | **fila declarada**: concede (DB ignora `denied_*`; FGA si se republica el modelo viejo); su reconcile cuenta `denied_*` en `skipped.undeclared`, jamás como allow | `upgrade_recipe.spec` (hijo) |
| S18 | config con `denny: true` (typo) / clave desconocida | `defineRelationsConfig` | 422 (H3) | unitario |

Mutantes que la guardia tiene que matar (uno por fila no declarada): orden deny→allow en la purga, renovación sin marca
de parcial, poda denies→allows, `skipped` en vez de 500, `resolveGrantExpiry` sin inversión, `now()` por ítem,
`error ⇒ false`, canonizar solo escrituras, resta de denies en cliente con un `ListObjects` aparte.

---

## 6 · (5) Migración 2.4.0-alpha.10 → 2.5.0-alpha.2

Fixture: `tests/fixtures/relations-2.4.0-alpha.10.*` = esquema publicado de alpha.10 + tuplas sembradas (holders,
usersets, anidados, caducadas, caducidad futura, **filas con partición sin guiones**, y **la misma tupla en las dos
ortografías**) + la config de alpha.10 (sin `deny`). Para FGA: store sembrado con el modelo de alpha.10. Oráculo: la
foto de respuestas (las 8 filas de T1 con D = ∅, por holder y por grupo, más listas) tomada **antes** con el código de
alpha.10.

| Estado | Qué debe pasar | Caso / marca |
|---|---|---|
| **E0** fixture alpha.10 | foto de respuestas | oráculo |
| **E1** paquete 2.5.0-alpha.2, config sin tocar, sin receta | `database`: misma foto byte a byte (sin DDL); FGA: `factsModelBytes` y definiciones idénticas (no hace falta republicar); `deny()` ⇒ 422 NOT_DENYABLE con cero llamadas; config con ciclo de `includes` ⇒ 422 al arrancar nombrando el ciclo; config con clave desconocida ⇒ 422 (BREAKING anunciado); filas sin guiones: la operación con esa ortografía ⇒ 422 y por la canónica ⇒ F (**pérdida no declarada si no hay receta**, H5) | PROP, `upgrade_recipe.spec` 3 motores + `:8101` |
| **E2** receta de canonización aplicada | filas sin guiones reescritas a la canónica; la tupla en dos ortografías colapsa en UNA con la caducidad que más dura (como `folded-scope`); la foto por la canónica = unión de E0 por las dos ortografías; detector (consulta de la receta) da 0 tras aplicarla; FGA: write canónica antes de delete (sin denies todavía, ambos órdenes son fail-closed) | PROP, receta ejecutada en el spec |
| **E3** opt-in `deny: true` en un tipo, modelo republicado | foto de E0 intacta (D = ∅); tuplas viejas válidas bajo el modelo nuevo sin migrar (`this` en la base del `difference`); T1 verde; relación > 43 en ese tipo ⇒ 422 | PROP (`:8101`) |
| **E4** mixto: lector con el modelo viejo | concede pese al deny (S11, fila declarada); runbook: publicar modelo → rodar todos los pods → primer deny | PROP (dos drivers pineados) |
| **E5** rollback a alpha.10 con denies escritos | concede (S17, declarada); su reconcile no convierte denies en allows; runbook: sin rollback tras el primer deny, o `removeDeny`/purga previa (decisión del dueño) | PROP (hijo con tarball) |
| **E6** reconcile entre versiones | origen con forma alpha.10 (sin `kind`) ⇒ solo allows; origen 2.5 con denies ⇒ destino sin capacidad: 500 antes de escribir | REC |
| **E7** config persistida (`saveRelationsConfig`) con `deny` leída por un proceso alpha.10 | la pierde en silencio (medido el mecanismo); un `openfga:provision` desde ahí republica sin `denied_*` ⇒ D-31 hace que los pods 2.5 den 500 en vez de conceder | PROP (hijo con tarball) |
| **E8** 2.5.0-alpha.1 → alpha.2 | lo mismo que E1–E3; si D4 entró en A, cero filas nuevas sin guiones | PROP |

---

## 7 · (6) Casos existentes que se ponen rojos, por lote

| Lote | Caso | Por qué | ¿Correcto? |
|---|---|---|---|
| 0 | `relations_database.spec.ts:554-599` (lista a mano) | se borra o se encadena a la guardia | sí (declarado en el informe) |
| 0 | ninguno más | la guardia es aditiva. Si sale rojo algo existente, es un agujero real (H8/H11), no un rojo esperado | — |
| A | `relations_harness.spec.ts:84` `EXPECTED_CASES = 22` | 6 casos núcleo | sí, literal 28 con desglose |
| A | REC `relations_harness.spec.ts:203` (11) | P3-2 | sí, 12 |
| A | `relations_events_docs.spec.ts:196` (F10 «all eight operations») | la letra pasa a nueve | sí, reescrita |
| A | `scope_depth.spec` (tabla «Limits») | constante nueva del tope 50 | sí |
| A | `relations_contract.spec` 44 | 2 dobles × 28 = 56 | sí |
| A | casos que usen `contractRelationsConfig` con aserciones sobre el modelo publicado (`relations_openfga.spec`, `openfga_driver.spec:90`) | si entra el 2.º tipo (H10) | sí si es deliberado; `openfga_facts.spec:4283` usa su propio `RELATIONS` y **no** debe cambiar |
| A (o D) | `relations_database.spec.ts:206`, `:229`, `:252` (E6) y `relations_openfga.spec.ts:1069` | purgan / escriben con la ortografía sin guiones ⇒ 422 con D4 | sí **solo** con la receta de E2 publicada y ejecutada; se reescriben como «sin guiones ⇒ 422» |
| D | `CAPABILITY_KEYS = 8`, `EXPECTED_CASES`, REC 12 | capacidad y casos nuevos (conteo por cara, H9) | sí |
| D | `relations_events_docs.spec.ts` F3 (tabla de `operation`), F10, y la justificación de E9 («`RelationRef.operation` es `'relate' \| 'unrelate'`») | el tipo publicado se ensancha | sí, cambio de tipos anunciado |
| D | `openfga_facts.spec.ts:4304-4330` (`DOCUMENT_DEF` / `EXPECTED_FUSED`) | **NO debe ponerse rojo**: es el control del opt-in | si se pone rojo, defecto |
| D | `migration_stub.spec` | **NO debe ponerse rojo** (sin DDL) | si se pone rojo, defecto |
| D | frase de bytes del README (`README.md:569-574`) | solo si hay tipos denegables; la cifra para tipos sin deny no cambia | sí, con M1 |
| C | `migration_stub.spec`, `CAPABILITY_KEYS` 9, `EXPECTED_CASES` | índice y capacidad nuevos | sí |

R-02, R-09 y la paridad de `listObjects` del BRIDGE **no** se ponen rojos en ningún lote: no escriben denies. Si se
ponen rojos, el deny se filtró a quien no lo usa.

---

## 8 · (7) Lo que NO se puede observar y no debe prometerse

- **NO-OBS** `ListObjects` con `but not` cortado por el deadline del servidor (sin tope alcanzado no hay señal). Se
  promete «exhaustivo o `truncated` por tope»; si M4 lo reproduce, pasa a caso.
- **NO-OBS** el desfase de reloj ENTRE procesos al caducar un deny. Se promete el borde con un reloj (S13).
- **NO-OBS en producción** el rolling deploy: qué pods tienen el modelo viejo. En test se fija el comportamiento (S11,
  E4); en producción solo el runbook y D-31.
- **NO-OBS** lo que hace por dentro un driver de terceros: el runner exige el censo de denies (T3), no la atomicidad.
- **NO-OBS** el evaluador de cadena del consumidor (Nóminas, invitados cross-org, herencia). El paquete fija el
  tri-estado por objeto (D-21) y nada más. No prometer «deny gana a lo largo de la cadena».
- **NO-OBS** quien escribe en FGA sin el paquete (otro cliente sobre el store): ningún caso lo ve.
- **NO-OBS** latencia de `but not`, `checkMany` o P2: se promete número de requests (espía), no milisegundos.
- **NO-OBS** la identidad de backend en reconcile (límite C1 de alpha.10, sigue igual).
- **No prometer** «el deny de relaciones se comporta como el de roles»: difiere en `includes`, caducidad y usersets.
- **No prometer** que la renovación de un deny en FGA no tiene ventana si M5 dice que no se puede (se declara, S1/S2).
- **No prometer** que una escritura de relaciones solo puede quitar acceso (H6, S8–S10).

---

## 9 · Preguntas nuevas para el dueño

- **D7** (H2): definición de `deny` en `decideMany` bajo corte de camino.
- **D4-cuándo** (H5): ¿D4 al lote A (2.5.0-alpha.1)? ¿Receta de canonización o operación de plataforma para las filas
  sin guiones? ¿422 o canonizar?
- **H3**: ¿claves desconocidas de la config de relaciones ⇒ 422 en 2.5 (BREAKING anunciado)?
- **H8**: ¿el runner exige F-05 en el driver directo (caso nuevo para terceros) o se firma la exención del doble?
- **E5**: ¿rollback a 2.4 tras el primer deny: prohibido (runbook) o con receta de retirada de denies?

## 10 · Veredicto

| Lote | casos nuevos (aprox.) | invariantes en riesgo | coste de prueba | veredicto |
|---|---|---|---|---|
| 0 | ≈ 86 celdas + 4 meta | L1, L2, L3, inv. 13 | medio (corredor de mutantes nuevo) | **verificable** |
| A | ≈ 20 | 3, 5, L5 (P5-1), L1 | bajo-medio (2.º tipo en el contrato) | **verificable**; P5-1 hoy rojo-sobrevive (medido) |
| Mediciones | 6 artefactos | — | medio (`:8101`, contenedor de deadline) | condición de D |
| D | ≈ 31 + T1 (192) + T3 + L9 (18) | 2, 3, 5, 6, 7, 10, 13, 17, R-02, L1–L3, L6, L8, L9 | alto | **verificable con cambios**: D7, H3, H5, H9 antes de codificar |
| C | ≈ 18 | 7, R-05, R-15, L8 | medio | **verificable** (más barato con D antes) |
| RC | 9 criterios | todos | alto (job runbook y script de banderas inexistentes) | **no verificable tal cual** hasta construir RC-1/RC-3 |
