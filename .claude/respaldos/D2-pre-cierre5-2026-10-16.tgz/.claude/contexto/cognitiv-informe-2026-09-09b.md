# Informe de COGNITIV (09-09-2026, 2º) — alpha.4 verificada; cuatro observaciones del relay/outbox para 2.5/2.6

Verificación: alpha.4 en su repo real (`9a2090b`); `openfga:provision` provisiona a la primera; envoltorio
`ListLoader` retirado; typecheck limpio; 735/735 con `database`; aceptan B y retiran la sugerencia del `default`;
usarán `capabilities()` y `driver()` desaparece de su `app/`.

Cuatro observaciones (contexto: van a usar «relay inline en la misma petición» para `attached`, como recomienda
el README). Verificadas por mí contra el código — las cuatro son exactas:
1. **No hay forma de saber si «mi» cambio se aplicó.** `enqueue` ⇒ `Promise<void>` (sin id); `relayScopeChanges()`
   reporta `applied`/`failed`/`remaining` GLOBALES (`pending(1)` sin filtro de tenant). Con backlog de otro tenant y
   `limit` acotado, aplica las más viejas y devuelve sin fallos aunque la suya siga pendiente. Workaround: comparar
   `applied[].change` con lo encolado. Petición: `enqueue` devuelva id/clave; `relayScopeChanges({ only | organization })`
   con resultado por entrada.
2. **`maxAttempts: 5` está dimensionado para job, no para relay inline.** Una caída corta del store aparca en segundos
   y lo aparcado NO vuelve a `pending()` jamás (`scope_outbox.ts:259`). No piden cambiar el default; sí nota en README
   junto a la receta inline y un comando `authz:scopes:requeue --id` (lo escribirán ellos; mejor en el paquete).
3. **`enumerateRelations(partition)` en `openfga` = lectura del store entero filtrada en JS** por partición
   (`openfga_relations_driver.ts:610-621`). Lo usan en purga de partición y en su reconcile de llaves: O(tuplas del
   despliegue) por operación. Lo anotan como límite declarado; mejora si hay salida (`Read` por tipo + prefijo, índice).
4. **`FACTS_MAX_RESOLVE_DEPTH = 22` no está en la tabla de límites del README** (sí en CLAUDE.md). Su árbol admitía
   32 niveles: legal en `database`, 503 en `openfga`. Lo bajaron ellos; piden que el README lo diga.
Pregunta: ¿`relayScopeChanges` seguirá tomando el lease para TODA la pasada? Con relay inline cada petición de
escritura de árbol sostiene una conexión extra mientras dura; subieron el pool. Si fuera por lote, lo bajarían.
