# Auditoría adversarial FINAL de la Fase 3b — ¿se mergea a `main`?

**Encargo:** la pasada final antes de mergear. Superficie: `authz:reconcile` en las dos
direcciones, la COMPOSICIÓN, `rooted`, el fail-CLOSED del lag del relay y las capacidades
declaradas. Solo un 🔴/🟠 explotable reabre la fase.

**Método:** HEAD `2507f45`, copia de solo lectura en scratchpad con `node_modules` enlazado.
Todo lo que se afirma está **medido contra el OpenFGA real del `:8101`** (modelo (c2r) publicado
por `openFgaFactsModel`, store nuevo por script, borrado en el `finally`) y contra el driver
`database` sobre el **mismo catálogo y el mismo árbol SQL** (`demo_scopes`, `sqlScopeTree`), en la
misma ejecución. Cero stores huérfanos al terminar; ninguna base `authz_test*` tocada.

---

## Veredicto en una línea

**NO se mergea a `main` tal cual.** Dos 🔴 reproducidos en los tres motores, con la misma raíz:
**`authz:reconcile --to=openfga` lee los hechos de `authz_assignments`/`authz_denies` sin
comprobar que esas tablas sean la fuente de verdad de los hechos en ESTE despliegue** — y en
`hierarchy: 'facts'`, que es lo que la fase entera compró, no lo son. De ahí salen las dos cosas
que el encargo preguntaba: **conseguir un permiso que no te corresponde** (un rol local que
concede dentro de otro tenant; un `revoke` deshecho) y **impedir que se te retire uno** (un `deny`
borrado por `--prune`). Ninguno necesita una bandera de peligro, ninguno lo cuenta el reporte, y
el comando que los provoca es el que el README pone en CI.

| # | Hallazgo | Clas. | ¿Reabre? |
|---|---|---|---|
| 1 | `reconcile` aplica la mitad que CONCEDE de un `moved` perdido y no la que retira; `drift.roleVisibility: 0` | 🔴 | **Sí** |
| 2 | `reconcile --to=openfga` resucita lo revocado; `--prune` borra los denies vivos; el seguro no salta | 🔴 | **Sí** |
| 3 | El `freeze()` de la migración es de PROCESO: un `revoke` de la ventana se deshace sin contarse | 🟠 | **Sí** |
| 4 | Una fila mal formada en `authz_*` tumba `reconcile` entero, también en `--dry-run` | 🟡 | No |
| 5 | Una entrada APARCADA no contamina: la garantía de orden del relay es nula para ese scope | 🟡 | No |
| 6 | El contrato de migración publicado no tiene NI UN rol local: el invariante 18 no se juzga | ⚪ | No |

**Lo que sí resiste** (medido, no razonado): `rooted` en todas sus caras, `--dry-run` como
read-only de verdad en las dos direcciones, la detección de ciclos, el marcador de raíz por holder
type, el seguro de masa con `authz_*` completamente vacía, y —el dato que más dice— `reconcile`
**sí** repara la visibilidad de rol **en el escenario de migración**. El mecanismo está bien
construido; lo que falta es la barrera que impide usarlo donde no vale.

## Hallazgos

### 🔴 1 · `authz:reconcile` completa la mitad que CONCEDE de un `moved` perdido y deja la que retira; cruza tenants y es permanente

**Escenario (precondición → acción → resultado)**

- *Precondición*: despliegue en `hierarchy: 'facts'` (el driver `openfga` es el ACTIVO), con
  `scopes.outbox` como manda el gate. En ese despliegue **los hechos viven en el store** y
  `authz_assignments`/`authz_denies` están **vacías** (`grant` del driver `openfga` no escribe una
  sola fila ahí — `src/drivers/openfga_driver.ts:911`). Hay un rol **LOCAL** de `orgA`
  (`defineScopedRole`, nivel `unit`) asignado a un holder en `unitU`, que cuelga de `orgA`.
- *Acción*: el consumidor mueve `unitU` a `orgB` (otro tenant) y **el relay pierde la entrada**
  (aparcada tras `maxAttempts`, que es el comportamiento diseñado en 3b-2h para una entrada
  irreparable). El operador hace lo que dice el invariante 18: `authz:reconcile --to=openfga`.
- *Resultado*: la pasada **escribe la arista nueva del árbol** (`scope:unitU#parent@scope:orgB`) y
  **borra la vieja** —fase `tree`: `written 1, extra 1, deleted 1`—, pero la arista de visibilidad
  `scope:unitU#binding@role_binding:unitU|<rolLocalDeA>` **no la toca** (fase `facts`:
  `extra 6, deleted 0`) y `drift.roleVisibility` sale **0**. Resultado medido:

  ```
  authorize(victima,'docs:write',unitU)   facts=true   database=false
  ```

  El rol local de `orgA` sigue concediendo dentro de `orgB`. Repetir la pasada no lo arregla
  (es idempotente): `drift.roleVisibility: 0` en todas.

**Por qué falla el remedio.** El conjunto `forbidden` —lo único que borra una arista de
visibilidad sin `--prune`— se construye **leyendo `authz_assignments`** (`readSourceFacts`,
`openfga_driver.ts:2632-2700`). En modo `facts` esa tabla está vacía, así que `forbidden` es
vacío, `wanted.facts` es vacío y **todos** los hechos del store salen como `extra-fact`. El árbol,
en cambio, se rehace siempre porque es «derivado». O sea: la pasada aplica la parte del `moved`
que **abre** (recolgar el nodo bajo el tenant nuevo, con lo que hereda sus permisos y sus denies)
y no la que **cierra** (retirar el rol local del tenant viejo).

**Evidencia:** ✅ medido. `repro/a1b.ts` (abajo). Salida literal:

```
=== 2. El consumidor mueve unit a orgB. El relay PIERDE la entrada (aparcada) ===
  outbox: pending=0 dead=1
  authorize(...) antes de reconcile                 facts=true
=== 3. `authz:reconcile --to=openfga` ===
  fases: {"tree":{"written":1,"updated":0,"unchanged":2,"extra":1,"deleted":1},
          "facts":{"written":0,"updated":0,"unchanged":0,"extra":6,"deleted":0}}
  skipped: {"extra-fact":6}
  drift: {"rootMarker":false,"multiParent":[],"roleVisibility":0,"pendingRelay":0,"deadRelay":1}
  authorize(...) DESPUES de reconcile               facts=true
=== 5. tras limpiar el dead-letter y repetir ===
  drift: {"rootMarker":false,"multiParent":[],"roleVisibility":0,"pendingRelay":0,"deadRelay":0}
=== 6. paridad ===
  authorize(victima,'docs:write',unit)   facts=true   database=false  *** FACTS FAIL-OPEN ***
```

Contraste (control): con el driver `database` activo y `authz_*` poblada —el escenario de
MIGRACIÓN— la misma pasada **sí** repara: `skipped: {"role-not-visible":1}`,
`drift.roleVisibility: 1`, y `authorize` converge a `false` en los dos drivers (`repro/a1_reconcile_no_repara_visibilidad.ts`).
O sea: el mecanismo existe y funciona **exactamente en el escenario donde no hace falta** (durante
la migración no hay relay que perder nada del despliegue final) y **no funciona en el único
escenario donde el invariante 18 lo invoca**.

**La frase que lo desmiente** (CLAUDE.md, invariante 18, y el mismo texto en el README):
> «Esa escritura va por el mismo camino que cualquier cambio de árbol: con `scopes.outbox` la
> aplica `authz:scopes:relay` … y **`authz:reconcile` la reconcilia si el relay se perdió**.»

Es falsa en `facts`, que es el único modo donde el barrido existe.

**Agravante — el reporte es 100 % ruido en `facts`.** En un despliegue `facts` la pasada marca
**todos** los hechos del store como `extra-fact` (6 de 6 en el repro) y sale con `clean=false`,
así que `authz:reconcile --to=openfga --dry-run` —el verificador que el README pone en CI— está
**siempre en rojo**. Las señales que sí importan (`roleVisibility`, `multiParent`, `cycles`) se
ahogan en ese ruido permanente.

**Steelman del defensor:** *«`--to=openfga` es la dirección de MIGRACIÓN desde `database`; contra
un store que ya es el activo no está pensada, y el dead-letter (`deadRelay: 1`) ya avisa.»* →
**No me convence.** (a) El invariante 18 y el README nombran `authz:reconcile` como el remedio de
esa escritura concreta, sin decir «solo durante la migración»; (b) nada en el código impide
`--to=<driver activo>` ni lo advierte; (c) el aviso del dead-letter no dice *qué* quedó mal y se va
en cuanto el operador limpia la fila, que es lo único que puede hacer con una entrada aparcada
—`pending()` la excluye a propósito—; (d) tras esa limpieza el reporte queda «sin deriva de
visibilidad» con la deriva viva.

**Mitigación mínima:** o el barrido de visibilidad se recalcula desde el ESTADO DEL STORE cuando el
origen no aporta hechos (recorrer los `assignee` del store y aplicarles `declaredRoleAt` con la
cadena del store), o la fase `tree` **no** se aplica cuando `wanted.facts` está vacío y el store sí
tiene hechos, o `reconcile` se niega en voz alta si el destino es un driver `hierarchyFacts` con
hechos y el origen no trae ninguno.

---

### 🔴 2 · `authz:reconcile --to=openfga` RESUCITA lo revocado y `--prune` BORRA los denies vivos, sin ninguna bandera de peligro

**Escenario (precondición → acción → resultado)**

- *Precondición*: se hizo la migración documentada `database` → `openfga` con
  `authz:reconcile --to=openfga` y se cortó a `facts`. **Nadie vacía
  `authz_assignments`/`authz_denies`** — ni el README ni el comando lo piden, y esas tablas siguen
  siendo las del catálogo, así que no se borran «por limpieza». Después del cutover se **revoca** un
  rol y se **deniega** un permiso; los dos cambios viven solo en el store.
- *Acción*: meses después alguien corre el verificador que el README pone en CI
  (`authz:reconcile --to=openfga --dry-run`, README:583 y README:150). Sale
  `escribiría 1 … clean=false` → «DERIVA». El operador hace lo natural: quita el `--dry-run`. Si
  además le hace caso al aviso del propio comando ante `unknown-scope` («repite con `--prune`»),
  añade `--prune`.
- *Resultado medido*:

  ```
  FASE 4 — authz:reconcile --to=openfga  (SIN --prune, SIN --allow-mass-delete)
    escritas 1, borradas 0, sobran 1 ; massDelete=false
    authorize(despedido,'docs:write',org)  facts=true   database=false   ← el REVOKE deshecho
  FASE 5 — …--prune
    NO se negó: escritas 0, borradas 1, massDelete=false
    authorize(empleado,'docs:write',org)   facts=true   database=false   ← el DENY borrado
  ```

  Quedan en el store los dos `assignee` de la era `database` y **ningún** `denied_<P>`.

**Por qué el seguro no salta.** `massDelete = prune && factsDeleted > 0 && facts.rows === 0`
(`openfga_driver.ts:2481`). `facts.rows` cuenta filas de `authz_assignments` **y**
`authz_denies`: con **una sola** fila vieja el seguro se calla. El seguro está diseñado para «la
base equivocada» (vacía) y es ciego a «la base CADUCA», que es el estado normal de un despliegue
`facts` que se migró desde `database`. Y la resurrección de la FASE 4 **no necesita `--prune` ni
ninguna otra bandera**: los hechos de `authz_*` entran en `wanted`, no están en el store y salen
como `written`.

**Evidencia:** ✅ medido, `repro/a2_reconcile_resucita.ts`.

**Contradicción documental.** README:616 dice «`authz:reconcile --to=openfga --prune` reconstruye
el store desde `authz_*`, **que es la fuente de verdad**». En `hierarchy: 'facts'` `authz_*` **no
es** la fuente de verdad de los hechos —lo dice el propio README en la tabla de capacidades
(`enumerateFacts: true` en `openfga`, «sus hechos son tuplas del store»)—, y el README nunca dice
que haya que vaciar esas tablas tras el cutover ni que `--to=openfga` sea ilegal contra el driver
activo.

**Steelman del defensor:** *«`--to=openfga` significa "reconstruye el store desde authz_*"; si
authz_* está caduca, el operador se lo ha buscado. Y el `--dry-run` avisa: sale rojo.»* → **No me
convence.** El `--dry-run` avisa **al revés**: llama «deriva» a lo que es el estado correcto y
empuja a repararlo. En este estado el reporte de un despliegue `facts` es rojo **siempre** (todos
los hechos vivos salen como `extra-fact`, hallazgo 1), así que ni siquiera se distingue el día en
que la deriva es real. Un comando de plataforma que, ejecutado tal como lo documenta el README,
deshace un `revoke` y borra un `deny` no es un footgun del operador: es un **mecanismo de
concesión**, justo lo que la regla S18 prohíbe para el `--fix`.

**Mitigación mínima:** que `reconcile` se niegue (o exija `--allow-mass-delete`/una bandera nueva)
cuando el DESTINO declara `hierarchyFacts` y tiene hechos que el ORIGEN no respalda **en absoluto**
—no solo cuando el origen está vacío—; y que el README diga, con esas palabras, que tras el cutover
a `facts` las tablas de hechos hay que vaciarlas o `--to=openfga` queda prohibido.

---

### 🟠 3 · El `freeze()` de la migración es de PROCESO: un `revoke` aceptado durante la pasada se deshace y no sale en ningún contador

**Escenario**

- *Precondición*: `authz:reconcile` es un comando **ace** ⇒ un proceso aparte del worker HTTP.
  `freeze()` guarda el motivo en `this.#root().#frozenReason`, estado de la **instancia**
  (`manager.ts:391`), y `#root()` es `this.#parent ?? this`: dos `AuthorizationManager` distintos —o
  sea dos procesos— no se ven.
- *Acción*: mientras corre `node ace authz:reconcile --to=database --from=openfga`, un
  administrador hace `revoke(ana, 'org-admin', org)` desde la aplicación.
- *Resultado medido*:

  ```
  … la pasada ya leyó el origen; ahora el WORKER (otro proceso) revoca:
    revoke ACEPTADO por el motor (200). worker.frozen=false
    authorize en el store tras el revoke: false
  reporte: escritas 1, borradas 0, skipped {}
  DESPUÉS de la migración: authorize(ana,'docs:read',org) en `database`  →  true
  ```

  El `revoke` respondió 200, el store dejó de conceder y la migración escribió la asignación
  revocada en `authz_assignments`. El reporte dice `escritas 1` y `skipped {}`: **nada** señala que
  se escribió un hecho que ya no existe. Tras el cutover, ana conserva el rol.

**Evidencia:** ✅ medido, `repro/b3_freeze.ts`. Y la sonda directa (`repro/b1_sondas.ts`):

```
instancia que congela  → revoke: E_AUTHZ_FROZEN
OTRA instancia         → revoke: no        (managerA.frozen=true  managerB.frozen=false)
```

**Lo que desmiente** (README:608, literal): «A `grant` landing between the read of the source and
the write of the destination would not reach the destination *and* would not appear in any counter,
**which is the one thing the report promises cannot happen**». Esa promesa solo se cumple en un
despliegue de UN proceso, que no es ninguno.

**Steelman del defensor:** *«El freeze es de proceso a propósito; una migración se hace con la app
parada o repitiendo la pasada, que es idempotente.»* → **Me convence a medias.** Que sea de proceso
es defendible; lo que no es defendible es la **frase**, que vende el freeze como la garantía de que
esa escritura no se pierde. Y «repite la pasada» no repara este caso: la segunda pasada ve la fila
en el destino y el hecho ya no en el origen, así que sin `--prune` la deja donde está (y con
`--prune` la borra… junto a todo lo demás que el origen no respalde).

**Mitigación mínima:** o el freeze se apoya en algo compartido (una fila de `authz_*`, la misma
`authz_catalog_version` que ya se contrasta en cada pregunta) o el README dice, con esas palabras,
«el freeze es de proceso: para la aplicación o acepta que las escrituras de la ventana no llegan al
destino y no salen contadas».

---

### 🟡 4 · Una sola fila mal formada en `authz_denies`/`authz_assignments` tumba `authz:reconcile` entero, también en `--dry-run`

**Escenario:** una fila con `scope_uuid` en MAYÚSCULAS (una migración de datos, un script, otra
versión) → `readSourceFacts` hace `scopeKey(scope)` **sin `try`**
(`openfga_driver.ts:2666` y `:2718`), y `scopeKey` → `assertScope` → 422 `E_AUTHZ_INVALID_IDENTITY`.
Medido:

```
B1.4 · la pasada MURIÓ: E_AUTHZ_INVALID_IDENTITY / 422 —
  UUID del scope 'organization' inválido: 'AAAAAAAA-BBBB-…'
```

Contraste: la fase del ÁRBOL sí lo protege (`isValidScope` ⇒ `note('edge','invalid-scope')`) y la
del holder también (`try { this.fgaSubject(...) } catch ⇒ 'unknown-holder-type'`). La del scope de
un hecho, no. Es fail-CLOSED (no escribe nada) y el mensaje nombra el valor, pero deja la migración
y el verificador **muertos** hasta que alguien encuentre la fila — misma clase que el 🔴 2 del
auditor R2 (la fila envenenada que tapaba el relay), que se cerró.

*Nota de precisión:* un `holder_uuid` mal formado se cuenta como **`unknown-holder-type`**, que es un
motivo equivocado (el holder type sí está declarado).

**Steelman:** *«Esa fila no la puede escribir el paquete.»* → cierto, y por eso es 🟡 y no 🟠; pero
el README contempla explícitamente escritores «a mano» de `authz_*` (invariante 14) y el resto de la
pasada ya trata cada entrada mala como un `skip` contado. **Mitigación mínima:** envolver ese
`scopeKey` como los otros dos y contarlo (`invalid-scope`).

---

### 🟡 5 · Una entrada APARCADA no contamina nada: la garantía de orden del relay es nula para ese scope, y nadie lo dice

**Escenario:** `moved(unit → orgB)` se aparca tras `maxAttempts`. Después llega
`detached(unit)` — el MISMO scope. Medido (`repro/c1_orden_aparcado.ts`):

```
pending=0  dead=1
applied=["detached"]   deferred=[]   dead=1
```

El `detached` se aplica **fuera de orden**, sin aplazarse. `blocked` solo se siembra con lo que
falla o se aplaza *en esa pasada* (`manager.ts:733-751`); `dead` se lee aparte, solo para el
reporte. El razonamiento que sostiene la garantía —«dos cambios que pueden interactuar comparten
siempre un scope, así que el orden RELATIVO que hay que conservar es exactamente este»— deja de
valer en cuanto `pending()` excluye una entrada a propósito, que es justo lo que hace el aparcado
que introdujo 3b-2h.

En las dos ordenaciones que probé el resultado fue fail-CLOSED o paridad (no conseguí convertirlo
en concesión), por eso es 🟡 y no 🟠. Lo que sí es seguro es que la propiedad publicada no se
cumple. **Mitigación mínima:** sembrar `blocked` con las claves de las entradas `dead()` al empezar
la pasada, y decirlo en el README.

---

### ⚪ 6 · El CONTRATO DE MIGRACIÓN publicado no tiene NI UN rol local: toda la superficie del invariante 18 está sin cubrir

`MIGRATION_CATALOG` (`src/testing/migration_contract.ts:148`) declara cuatro roles y **los cuatro
son globales** (vienen del `CatalogSpec`, `owner_scope_key = 'global'`). Consecuencias:

- ningún motivo `role-not-visible` puede aparecer nunca en las tres combinaciones;
- `drift.roleVisibility` no se observa jamás;
- el barrido `scope#binding` (3b-2e · E1 y 3b-2g · R1), que es *la* pieza que en `facts` sustituye a
  una regla que `database` evalúa en cada pregunta, **no entra en el contrato que corre un driver de
  terceros**.

Y el **censo** solo busca lo que FALTA (`census.missing`): un destino que gana hechos —el 🔴 2— no
lo ve, y las 448 preguntas solo cubren los 6 holders y los 7 scopes de la siembra, sobre un destino
que el `cleanup` deja limpio antes de cada combinación (nunca se migra sobre un destino con estado
previo, que es la precondición de los dos 🔴).

No es explotable por sí mismo: es la explicación de por qué el 🔴 1 llegó vivo al lote 4.
**Mitigación mínima:** añadir a la siembra un rol LOCAL de `org1` a nivel `unit` con una asignación
en `unit1`, y una combinación que migre sobre un destino NO vacío.

---

## Lo que intenté y NO se rompió

Vale como información: esto resiste, y resiste **medido**, no razonado.

1. **`--dry-run` es read-only de verdad, en las DOS direcciones y con `--prune` puesto.** Comparé
   byte a byte el store entero, `authz_assignments`, `authz_denies` y `authz_scope_outbox` antes y
   después de `reconcile({to:'openfga', dryRun:true, prune:true})` y
   `reconcile({to:'database', from:'openfga', dryRun:true, prune:true})`: **idénticos los tres**.
   No hay `--fix` ni camino que escriba. `#relayWindow()` usa `pending()`/`dead()`, que no reservan
   nada. (`repro/b1_sondas.ts` · B1.2.)
2. **`rooted` aguanta.** Planté a mano `scope:<X>#rooted@user:*` sobre un scope desgajado: concede
   mientras esté (era de esperar: es el mecanismo), pero `familyOfTuple` la clasifica como familia
   `root` **por la relación, no por el objeto**, así que `reconcile` la cuenta como `extra` y la
   **borra siempre**, sin `--prune` (`fase root: extra 1, deleted 1`). No encontré ninguna ruta del
   paquete que escriba una `rooted` fuera de `scope:app`.
3. **Desenraizar no crea permisos indenegables.** Borré a mano la arista `org → app` con un deny
   vivo en `org`: `authorize` cae a `false` en `org` y en `unit`, igual que `database`. El 🔴 1 del
   auditor R2 está cerrado de verdad: perder la raíz se lleva el grant *antes* que el deny.
4. **Quitar el marcador de raíz de UN holder type** deniega solo para ese holder type (`admins`
   `false`, `users` intacto), y `--dry-run` lo canta (`drift.rootMarker: true`). Fail-closed y
   ruidoso, como se declara.
5. **El seguro `E_AUTHZ_MASS_RECONCILE_REFUSED` sí salta** cuando `authz_*` está **completamente**
   vacía. Lo que no cubre es la base CADUCA (🔴 2).
6. **En el escenario de MIGRACIÓN (`database` activo, `authz_*` poblada) `reconcile` SÍ repara la
   visibilidad de rol**: con la entrada del relay aparcada, la pasada reporta
   `skipped {role-not-visible: 1}`, `drift.roleVisibility: 1`, borra la arista y los dos drivers
   convergen a `false`. El mecanismo existe y funciona; el 🔴 1 es que no se activa donde hace falta.
7. **`authorize` con la cadena rota**: un scope cuya fila del consumidor ya no existe pero cuya
   arista sigue en el store responde según el árbol del STORE (es la propiedad comprada), y sin
   arista responde `false`. No hallé forma de que responda `true` sin una cadena a `app` **en el
   store**.
8. **Los ciclos.** `readSourceTree` detecta el ciclo lo escriba en el orden que lo escriba (la
   arista que cierra es siempre la última en entrar) y borra la arista de **todos** los nodos del
   ciclo, no solo del que la cerró; esos nodos se quedan sin `rooted` ⇒ deniegan. No conseguí que
   una arista de un ciclo llegara al store.
9. **Reproducido en los tres motores.** Los dos 🔴 salen idénticos en **SQLite**, **PostgreSQL 18**
   y **MySQL 8.4**: no dependen de la collation ni del tipo `uuid`, dependen de *qué tabla se lee*.
10. **`purgeScope` / alias del uuid / dos padres / tapón del relay**: los cinco hallazgos del auditor
    R2 los di por cerrados y no los volví a atacar salvo donde se cruzaban con lo mío (`rooted` en el
    punto 3, el aparcado en el 🟡 5, `assertOneParent` en el árbol de reconcile).

---

## Preguntas abiertas para el arquitecto

Solo las que cambian el veredicto:

1. **¿`authz:reconcile --to=<driver>` puede apuntar al driver ACTIVO?** Hoy sí, y ahí está todo el
   daño de los dos 🔴. Si la respuesta es «no debería», hace falta la barrera, no la nota.
2. **En un despliegue `facts`, ¿cuál es el remedio de una escritura de visibilidad perdida?** Hoy no
   hay ninguno: el relay la aparcó, `reconcile` no la ve y `--prune` se lleva el store entero. Si la
   respuesta es «no hay», el invariante 18 y el README tienen que dejar de nombrar `authz:reconcile`.
3. **¿Se declara que tras el cutover a `facts` hay que VACIAR `authz_assignments`/`authz_denies`?**
   Si sí, tiene que salir en el README y —mejor— en un aviso del propio comando. Si no, `--to=openfga`
   contra un destino `hierarchyFacts` con hechos que el origen no respalda tiene que ser un error.
4. **¿El `freeze` tiene que ser compartido?** Si la respuesta es no, la frase del README:608 hay que
   reescribirla; si es sí, hay una fila donde ponerlo (`authz_catalog_version` ya se contrasta en
   cada pregunta).
5. **Alias del uuid, la cara que NO medí (❓):** si dos ortografías del mismo scope acaban en el
   store —un deny bajo `unit|<sin guiones>` y un grant bajo `unit|<con guiones>`—, `facts` respondería
   `true` a quien pregunte con la ortografía del grant y `database` `false`. No conseguí llegar a ese
   estado con el resolutor canónico (PG y MySQL devuelven siempre la misma forma), así que **no lo
   afirmo**: lo dejo como la única vía por la que la divergencia (c), declarada fail-CLOSED, sería
   fail-OPEN.

---

## La redacción que yo pondría en el README

Sustituye la frase del invariante 18 / README:301 («*and `authz:reconcile` reconciles it if the
relay was lost*») por:

> **There is no repair for a lost visibility write once you are running on `facts`.**
> `authz:reconcile --to=openfga` rebuilds the store **from `authz_assignments`/`authz_denies`**, and
> in a `facts` deployment those tables hold no facts at all — the store does. So the pass will
> rebuild your tree, report every live fact as `extra-fact`, and **not** touch the
> `scope#binding` edges: `drift.roleVisibility` will read `0` whether or not the write was lost.
> While the `openfga` driver is the one writing your facts, `authz:reconcile --to=openfga` is not a
> repair tool, it is a **loaded gun**: without `--prune` it re-writes every row those tables still
> hold — resurrecting grants you revoked after the cutover — and with `--prune` it deletes every
> fact of your store that those tables do not back, **denies included**. The
> `E_AUTHZ_MASS_RECONCILE_REFUSED` guard only fires when the tables are *completely* empty; one
> stale row is enough to disarm it.
> **If you cut over to `facts`, empty `authz_assignments` and `authz_denies` first**, and treat
> `--to=openfga` as a one-way migration command, never as a verifier.

Y en la sección del `freeze` (README:608), sustituir la última frase por:

> `freeze()` is **per process**. `authz:reconcile` runs as an ace command, so your HTTP workers are
> not frozen: a `grant` or a `revoke` they accept while the pass runs answers 200, is applied to the
> live driver, and **does not reach the destination nor appear in any counter**. Stop the
> application for the window, or accept that the pass's snapshot is the source as of the moment it
> read it.

---

## Reproducciones ejecutables

```bash
cp -a /home/jose/proyectos/Personal/adonis-authz /tmp/atk && rm -rf /tmp/atk/.git /tmp/atk/node_modules
ln -s /home/jose/proyectos/Personal/adonis-authz/node_modules /tmp/atk/node_modules
mkdir -p /tmp/atk/repro   # y dentro los ficheros de abajo
cd /tmp/atk

OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/a1b.ts                    # 🔴 1
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/a1_reconcile_no_repara_visibilidad.ts                    # control de 🔴 1 (migración: SÍ repara)
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/a2_reconcile_resucita.ts  # 🔴 2
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/b3_freeze.ts              # 🟠 3
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/b1_sondas.ts              # 🟡 4 + dry-run read-only
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/b2_rooted.ts              # `rooted` (no se rompió)
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/c1_orden_aparcado.ts      # 🟡 5

# y los dos 🔴 en los otros dos motores (idénticos):
PGPW=$(docker inspect postgres18 --format '{{range .Config.Env}}{{println .}}{{end}}' | grep POSTGRES_PASSWORD | cut -d= -f2)
TEST_DB=pg TEST_PG_URL="postgres://postgres:$PGPW@127.0.0.1:5432/auditor_final" \
  OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/a2_reconcile_resucita.ts
MYPW=$(docker inspect mysql84 --format '{{range .Config.Env}}{{println .}}{{end}}' | grep MYSQL_ROOT_PASSWORD | cut -d= -f2)
TEST_DB=mysql TEST_MYSQL_URL="mysql://root:$MYPW@127.0.0.1:3306/auditor_final" \
  OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec repro/a2_reconcile_resucita.ts
```

Todos los scripts borran su store en el `finally` y la app destruye su base en `teardown()`.
Los ficheros (`harness.ts`, `a1_reconcile_no_repara_visibilidad.ts`, `a1b.ts`, `a2_reconcile_resucita.ts`, `b1_sondas.ts`,
`b2_rooted.ts`, `b3_freeze.ts`, `c1_orden_aparcado.ts`) quedan en el scratchpad de esta sesión:
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/atk/repro/`.

---

## Higiene

- OpenFGA `:8101`: **0 stores** al terminar (`GET /stores` ⇒ `{"stores":[]}`). Cada script borra los
  suyos en el `finally`.
- PostgreSQL 18 y MySQL 8.4: ninguna base `auditor_final*` superviviente; **ninguna base
  `authz_test*` tocada** (los scripts usan el nombre base `auditor_final` y `bootApp` le añade un
  sufijo por corrida que destruye en `teardown()`).
- El árbol del repo no se modificó: la copia de trabajo vive en el scratchpad y el único fichero
  escrito en el repo es este informe.

---

## Los ficheros

### `repro/harness.ts`

```ts
/**
 * Harness del auditor FINAL de la Fase 3b. Driver `openfga` en modo `facts`
 * contra el :8101 REAL + driver `database` sobre el MISMO catálogo y el MISMO
 * árbol (SQL, `demo_scopes`), para que toda comparación sea de paridad.
 */
const apiUrl = process.env.OPENFGA_TEST_URL ?? 'http://localhost:8101'
const stores: string[] = []

export const HOLDERS = { users: 'user', admins: 'admin', integrations: 'integration' }

export async function boot() {
  const { bootApp } = await import('../tests/helpers/app.js')
  const app = await bootApp()
  const schema = await import('../tests/helpers/schema.js')
  await schema.createAuthzSchema(app.db)
  await schema.createDemoScopesTable(app.db)
  await schema.createScopeOutboxTable(app.db)
  await schema.cleanAuthzTables()
  return { app, schema }
}

export async function newStore(permissions: string[], holders: any = HOLDERS) {
  const { OpenFgaClient } = await import('@openfga/sdk')
  const { openFgaFactsModel } = await import('../src/openfga.js')
  const store = await new OpenFgaClient({ apiUrl }).createStore({
    name: `auditor-final-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
  })
  stores.push(store.id!)
  const client = new OpenFgaClient({ apiUrl, storeId: store.id })
  const model = await client.writeAuthorizationModel(openFgaFactsModel(holders, permissions))
  return { storeId: store.id!, modelId: model.authorization_model_id!, client, apiUrl }
}

export async function dropStores() {
  const { OpenFgaClient } = await import('@openfga/sdk')
  while (stores.length) {
    try { await new OpenFgaClient({ apiUrl, storeId: stores.pop()! }).deleteStore() } catch {}
  }
}

/** Todas las tuplas del store, `user#relation@object`, ordenadas. */
export async function allTuples(client: any): Promise<string[]> {
  const out: string[] = []
  let continuationToken: string | undefined
  do {
    const page = await client.read({}, { pageSize: 100, continuationToken })
    for (const t of page.tuples ?? []) out.push(`${t.key.user}#${t.key.relation}@${t.key.object}`)
    continuationToken = page.continuation_token || undefined
  } while (continuationToken)
  return out.sort()
}

export function report(name: string, facts: any, database: any) {
  const same = JSON.stringify(facts) === JSON.stringify(database)
  const flag = same ? 'PARIDAD' : facts === true ? '*** FACTS FAIL-OPEN ***' : '*** DIVERGE ***'
  console.log(`  ${name.padEnd(62)} facts=${String(facts).padEnd(6)} database=${String(database).padEnd(6)} ${flag}`)
  return same
}

export function head(title: string) {
  console.log(`\n=== ${title} ===`)
}
```

### `repro/a1b.ts`

```ts
/**
 * A1 — `authz:reconcile --to=openfga` NO reconcilia la escritura de
 * visibilidad de rol (invariante 18) que el relay perdió, y encima aplica la
 * MITAD del `moved` que concede (la arista del árbol) dejando sin aplicar la
 * mitad que retira (el barrido `scope#binding`).
 *
 * Precondición: driver `openfga` con `hierarchy: 'facts'` ACTIVO (los hechos
 * viven en el store; `authz_assignments`/`authz_denies` están vacías) + outbox.
 */
import { boot, newStore, dropStores, allTuples, report, head, HOLDERS } from './harness.js'

const run = async () => {
  const { app, schema } = await boot()
  const db = app.db
  try {
    const { sqlScopeTree, cleanSqlScopeTree } = await import('../tests/helpers/sql_scope_tree.js')
    const { resolveChainFrom } = await import('../src/testing/main.js')
    const { AuthorizationManager } = await import('../src/manager.js')
    const { syncAuthzCatalog } = await import('../src/catalog.js')
    const { OpenFgaAuthorizationDriver } = await import('../src/openfga.js')
    const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
    const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
    const { sqlScopeEdges } = await import('../src/sql_descendants.js')
    const { APP_SCOPE } = await import('../src/types.js')
    const { v7: uuidv7 } = await import('uuid')

    const tree = sqlScopeTree(db)
    const chain = resolveChainFrom(tree)
    const CATALOG: any = {
      permissions: [{ slug: 'docs:write' }],
      roles: [{ slug: 'root-admin', scopeType: 'app', rank: 90, permissions: ['docs:write'] }],
    }
    await syncAuthzCatalog(CATALOG)

    const store = await newStore(['docs:write'])
    const facts: any = new OpenFgaAuthorizationDriver({
      apiUrl: store.apiUrl, storeId: store.storeId, modelId: store.modelId,
      holderTypes: HOLDERS, resolveChain: chain, hierarchy: 'facts',
      outbox: sqlScopeOutbox(), logger: { warn: () => {} },
    })
    await syncAuthzCatalog(CATALOG, { projection: facts.catalogProjection() })
    const sql: any = new DatabaseAuthorizationDriver({ resolveChain: chain })

    const outbox = sqlScopeOutbox()
    const manager = new AuthorizationManager({
      default: 'openfga',
      drivers: { openfga: () => facts },
      scopes: {
        resolveChain: chain,
        outbox,
        enumerateEdges: sqlScopeEdges({ table: 'demo_scopes', uuidColumn: 'uuid', parentColumn: 'parent_uuid', typeColumn: 'type' }),
      },
      delegablePermissions: ['docs:write'],
      warnOnOptInSecurity: false,
    } as any)

    const relay = async () => { await manager.relayScopeChanges() }

    const orgA = { type: 'organization', uuid: uuidv7() }
    const orgB = { type: 'organization', uuid: uuidv7() }
    const unit = { type: 'unit', uuid: uuidv7() }
    const jefe = { type: 'users', uuid: uuidv7() }     // actor con el rol global
    const victima = { type: 'users', uuid: uuidv7() }  // el que recibe el rol LOCAL de orgA

    await tree.attach(orgA, APP_SCOPE); await manager.scopes.attached(orgA, APP_SCOPE)
    await tree.attach(orgB, APP_SCOPE); await manager.scopes.attached(orgB, APP_SCOPE)
    await tree.attach(unit, orgA);      await manager.scopes.attached(unit, orgA)
    await relay()

    await manager.grant(jefe, 'root-admin', APP_SCOPE)
    // await sql.grant(jefe, 'root-admin', APP_SCOPE, {})

    head('1. Un rol LOCAL de orgA, nivel unit, asignado en unit (que cuelga de orgA)')
    const local = await manager.defineScopedRole(jefe, orgA, {
      slug: 'unit-lead', scopeType: 'unit', rank: 10, permissions: ['docs:write'],
    }, { actor: jefe } as any)
    console.log(`  rol local: ${local.slug}@${local.scopeType} uuid=${local.uuid} owner=${local.owner}`)
    await manager.grant(victima, { uuid: local.uuid }, unit)
    // await sql.grant(victima, { uuid: local.uuid }, unit, {})
    report('authorize(victima, docs:write, unit) con unit BAJO orgA',
      await facts.authorize(victima, 'docs:write', unit), '(pendiente)')

    head('2. El consumidor mueve unit a orgB (otro tenant). El relay PIERDE la entrada (aparcada)')
    await tree.move(unit, orgB)
    await manager.scopes.moved(unit, orgB)
    // Se aparca: 5 intentos fallidos = lo que hace `sqlScopeOutbox` con una
    // entrada irreparable (3b-2h). Aquí se simula directamente.
    await db.from('authz_scope_outbox').whereNull('applied_at').update({ attempts: 5, last_error: 'simulado: el relay la aparcó' })
    console.log(`  outbox: pending=${(await outbox.pending(10)).length} dead=${(await outbox.dead!(10)).length}`)
    report('authorize(victima, docs:write, unit) con unit BAJO orgB, antes de reconcile',
      await facts.authorize(victima, 'docs:write', unit), '(pendiente)')

    head('3. `authz:reconcile --to=openfga` — el remedio que documenta el invariante 18')
    const r1 = await manager.reconcile({ to: 'openfga' })
    console.log(`  fases: ${JSON.stringify(r1.phases)}`)
    console.log(`  skipped: ${JSON.stringify(r1.skipped)}`)
    console.log(`  drift: ${JSON.stringify(r1.drift)}`)
    report('authorize(victima, docs:write, unit) DESPUES de reconcile',
      await facts.authorize(victima, 'docs:write', unit), '(pendiente)')

    head('4. El árbol del store SÍ se movió (la mitad que concede), la arista de visibilidad NO')
    const t = await allTuples(store.client)
    for (const line of t.filter((x) => x.includes('#parent@') || x.includes('#binding@'))) console.log(`  ${line}`)
    console.log(`  orgA=organization|${orgA.uuid}`)
    console.log(`  orgB=organization|${orgB.uuid}`)
    console.log(`  unit=unit|${unit.uuid}`)

    head('5. El operador limpia el dead-letter (no hay otra salida) y repite reconcile')
    await db.from('authz_scope_outbox').delete()
    const r2 = await manager.reconcile({ to: 'openfga' })
    console.log(`  drift: ${JSON.stringify(r2.drift)}`)
    console.log(`  skipped: ${JSON.stringify(r2.skipped)}`)
    const { reconcileLines } = await import('../commands/authz_reconcile.js')
    const { lines, clean } = reconcileLines(r2)
    console.log(`  clean=${clean}`)
    for (const l of lines) console.log(`  [${l.level}] ${l.message}`)
    report('authorize(victima, docs:write, unit) FINAL',
      await facts.authorize(victima, 'docs:write', unit), '(pendiente)')

    head('6. Ahora SÍ: la respuesta del driver `database` sobre el MISMO árbol y el MISMO catálogo')
    // El mismo hecho, escrito por el driver `database` cuando unit todavía
    // colgaba de orgA (que es como llegó a existir), y luego el mismo `moved`.
    await tree.move(unit, orgA)
    await sql.grant(jefe, 'root-admin', APP_SCOPE, {})
    await sql.grant(victima, { uuid: local.uuid }, unit, {})
    await tree.move(unit, orgB)
    console.log(`  filas en authz_assignments: ${(await db.from('authz_assignments').select('uuid')).length}`)
    report('authorize(victima, docs:write, unit)',
      await facts.authorize(victima, 'docs:write', unit), await sql.authorize(victima, 'docs:write', unit))
    await cleanSqlScopeTree(db)
  } finally {
    await dropStores()
    await app.teardown()
  }
}
run().then(() => process.exit(0), (e) => { console.error(e); process.exit(1) })
```

### `repro/a2_reconcile_resucita.ts`

```ts
/**
 * A2 — En un despliegue `facts`, `authz:reconcile --to=openfga` (SIN --prune,
 * SIN --allow-mass-delete) RESUCITA en el store todo lo que quedó en
 * `authz_assignments`/`authz_denies`, y con --prune borra lo vivo. El seguro
 * `E_AUTHZ_MASS_RECONCILE_REFUSED` solo cubre el caso de la tabla VACÍA.
 */
import { boot, newStore, dropStores, allTuples, report, head, HOLDERS } from './harness.js'

const run = async () => {
  const { app } = await boot()
  const db = app.db
  try {
    const { sqlScopeTree, cleanSqlScopeTree } = await import('../tests/helpers/sql_scope_tree.js')
    const { resolveChainFrom } = await import('../src/testing/main.js')
    const { AuthorizationManager } = await import('../src/manager.js')
    const { syncAuthzCatalog } = await import('../src/catalog.js')
    const { OpenFgaAuthorizationDriver } = await import('../src/openfga.js')
    const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
    const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
    const { sqlScopeEdges } = await import('../src/sql_descendants.js')
    const { APP_SCOPE } = await import('../src/types.js')
    const { v7: uuidv7 } = await import('uuid')

    const tree = sqlScopeTree(db)
    const chain = resolveChainFrom(tree)
    const CATALOG: any = {
      permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
      roles: [{ slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read', 'docs:write'] }],
    }
    await syncAuthzCatalog(CATALOG)
    const sql: any = new DatabaseAuthorizationDriver({ resolveChain: chain })

    const org = { type: 'organization', uuid: uuidv7() }
    const despedido = { type: 'users', uuid: uuidv7() }
    const empleado = { type: 'users', uuid: uuidv7() }
    await tree.attach(org, APP_SCOPE)

    head('FASE 1 — la era `database`: dos empleados con org-admin; se migra al store')
    await sql.grant(despedido, 'org-admin', org, {})
    await sql.grant(empleado, 'org-admin', org, {})
    console.log(`  filas en authz_assignments: ${(await db.from('authz_assignments').select('uuid')).length}`)

    const store = await newStore(['docs:read', 'docs:write'])
    const facts: any = new OpenFgaAuthorizationDriver({
      apiUrl: store.apiUrl, storeId: store.storeId, modelId: store.modelId,
      holderTypes: HOLDERS, resolveChain: chain, hierarchy: 'facts',
      outbox: sqlScopeOutbox(), logger: { warn: () => {} },
    })
    await syncAuthzCatalog(CATALOG, { projection: facts.catalogProjection() })
    const outbox = sqlScopeOutbox()
    const manager = new AuthorizationManager({
      default: 'openfga', drivers: { openfga: () => facts },
      scopes: { resolveChain: chain, outbox,
        enumerateEdges: sqlScopeEdges({ table: 'demo_scopes', uuidColumn: 'uuid', parentColumn: 'parent_uuid', typeColumn: 'type' }) },
      warnOnOptInSecurity: false,
    } as any)
    const m = await manager.reconcile({ to: 'openfga' })
    console.log(`  migración: escritas ${m.written}, iguales ${m.unchanged}`)
    report('authorize(despedido, docs:write, org) tras migrar', await facts.authorize(despedido, 'docs:write', org), true)

    head('FASE 2 — CUTOVER: el motor sirve desde `facts`. Se despide a uno y se le DENIEGA al otro')
    console.log('  (nadie trunca authz_assignments: nada lo pide, y el catálogo vive en las mismas tablas)')
    await manager.revoke(despedido, 'org-admin', org)
    await manager.deny(empleado, 'docs:write', org)
    report('authorize(despedido, docs:write, org)', await facts.authorize(despedido, 'docs:write', org), false)
    report('authorize(empleado,  docs:write, org)', await facts.authorize(empleado, 'docs:write', org), false)
    console.log(`  filas que quedaron en authz_assignments: ${(await db.from('authz_assignments').select('uuid')).length}`)
    console.log(`  filas en authz_denies: ${(await db.from('authz_denies').select('uuid')).length}`)

    head('FASE 3 — meses después, `authz:reconcile --to=openfga --dry-run` (el VERIFICADOR de CI)')
    const seco = await manager.reconcile({ to: 'openfga', dryRun: true })
    const { reconcileLines } = await import('../commands/authz_reconcile.js')
    console.log(`  escribiría ${seco.written}, borraría ${seco.deleted}; clean=${reconcileLines(seco).clean}`)
    console.log(`  skipped: ${JSON.stringify(seco.skipped)}`)

    head('FASE 4 — el operador «arregla la deriva»: `authz:reconcile --to=openfga` (sin --prune)')
    const r = await manager.reconcile({ to: 'openfga' })
    console.log(`  escritas ${r.written}, borradas ${r.deleted}, sobran ${r.extra}`)
    console.log(`  massDelete=${r.massDelete}`)
    report('authorize(despedido, docs:write, org)  [REVOCADO hace meses]',
      await facts.authorize(despedido, 'docs:write', org), false)
    report('authorize(empleado,  docs:write, org)  [DENEGADO hace meses]',
      await facts.authorize(empleado, 'docs:write', org), false)

    head('FASE 5 — y si además usa --prune (lo que el propio comando sugiere ante `unknown-scope`)')
    try {
      const p = await manager.reconcile({ to: 'openfga', prune: true })
      console.log(`  NO se negó: escritas ${p.written}, borradas ${p.deleted}, massDelete=${p.massDelete}`)
    } catch (e: any) {
      console.log(`  se negó: ${e.code} — ${String(e.message).slice(0, 120)}`)
    }
    report('authorize(despedido, docs:write, org)  [REVOCADO]', await facts.authorize(despedido, 'docs:write', org), false)
    report('authorize(empleado,  docs:write, org)  [DENEGADO]', await facts.authorize(empleado, 'docs:write', org), false)
    console.log('  tuplas de hechos que quedan:')
    for (const t of (await allTuples(store.client)).filter((x) => x.includes('#assignee@') || x.includes('#denied_'))) console.log(`    ${t}`)

    await cleanSqlScopeTree(db)
  } finally {
    await dropStores()
    await app.teardown()
  }
}
run().then(() => process.exit(0), (e) => { console.error(e); process.exit(1) })
```

### `repro/b3_freeze.ts`

```ts
/**
 * B3 — El `freeze()` de `authz:reconcile` es de INSTANCIA (⇒ de PROCESO). El
 * comando ace no congela a los workers HTTP, así que la promesa del README
 * («un grant que aterrice entre la lectura del origen y la escritura del
 * destino … es lo único que el reporte promete que no puede pasar») es falsa
 * en cualquier despliegue con más de un proceso. Demostrado con la ventana
 * forzada: el `revoke` ocurre DENTRO de la pasada, y la pasada lo deshace.
 */
import { boot, newStore, dropStores, report, head, HOLDERS } from './harness.js'

const run = async () => {
  const { app } = await boot()
  const db = app.db
  try {
    const { sqlScopeTree, cleanSqlScopeTree } = await import('../tests/helpers/sql_scope_tree.js')
    const { resolveChainFrom } = await import('../src/testing/main.js')
    const { AuthorizationManager } = await import('../src/manager.js')
    const { syncAuthzCatalog } = await import('../src/catalog.js')
    const { OpenFgaAuthorizationDriver } = await import('../src/openfga.js')
    const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
    const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
    const { sqlScopeEdges } = await import('../src/sql_descendants.js')
    const { APP_SCOPE } = await import('../src/types.js')
    const { v7: uuidv7 } = await import('uuid')

    const tree = sqlScopeTree(db)
    const chain = resolveChainFrom(tree)
    const CATALOG: any = {
      permissions: [{ slug: 'docs:read' }],
      roles: [{ slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read'] }],
    }
    await syncAuthzCatalog(CATALOG)
    const sql: any = new DatabaseAuthorizationDriver({ resolveChain: chain })
    const store = await newStore(['docs:read'])
    const facts: any = new OpenFgaAuthorizationDriver({
      apiUrl: store.apiUrl, storeId: store.storeId, modelId: store.modelId,
      holderTypes: HOLDERS, resolveChain: chain, hierarchy: 'facts',
      outbox: sqlScopeOutbox(), logger: { warn: () => {} },
    })
    await syncAuthzCatalog(CATALOG, { projection: facts.catalogProjection() })
    const edges = sqlScopeEdges({ table: 'demo_scopes', uuidColumn: 'uuid', parentColumn: 'parent_uuid', typeColumn: 'type' })

    const org = { type: 'organization', uuid: uuidv7() }
    const ana = { type: 'users', uuid: uuidv7() }
    await tree.attach(org, APP_SCOPE)

    // El motor VIVO: driver `facts`, en el proceso del worker HTTP.
    const worker = new AuthorizationManager({
      default: 'openfga', drivers: { openfga: () => facts },
      scopes: { resolveChain: chain, outbox: sqlScopeOutbox(), enumerateEdges: edges },
      warnOnOptInSecurity: false,
    } as any)
    await worker.scopes.attached(org, APP_SCOPE); await worker.relayScopeChanges()
    await worker.grant(ana, 'org-admin', org)
    report('antes: authorize(ana, docs:read, org) en el store', await facts.authorize(ana, 'docs:read', org), 'n/a')

    head('El proceso de `node ace authz:reconcile --to=database --from=openfga` migra la VUELTA')
    let hecho = false
    // El ORIGEN es el driver `facts` real; solo se fuerza la VENTANA: el
    // revoke del worker ocurre después de que la pasada haya leído la página.
    const origenConVentana: any = new Proxy(facts, {
      get(target, prop, receiver) {
        if (prop !== 'enumerateFacts') return Reflect.get(target, prop, receiver)
        return async (page: any) => {
          const res = await target.enumerateFacts(page)
          if (!hecho) {
            hecho = true
            console.log('  … la pasada ya leyó el origen; ahora el WORKER (otro proceso) revoca:')
            try {
              await worker.revoke(ana, 'org-admin', org)
              console.log('    revoke ACEPTADO por el motor (200). worker.frozen=' + worker.frozen)
            } catch (e: any) {
              console.log(`    revoke rechazado: ${e.code}`)
            }
            console.log(`    authorize en el store tras el revoke: ${await facts.authorize(ana, 'docs:read', org)}`)
          }
          return res
        }
      },
    })
    const ace = new AuthorizationManager({
      default: 'database', drivers: { database: () => sql, openfga: () => origenConVentana },
      scopes: { resolveChain: chain, outbox: sqlScopeOutbox(), enumerateEdges: edges },
      warnOnOptInSecurity: false,
    } as any)
    const r = await ace.reconcile({ to: 'database', from: 'openfga' })
    console.log(`  reporte: escritas ${r.written}, borradas ${r.deleted}, skipped ${JSON.stringify(r.skipped)}`)
    console.log(`  filas en authz_assignments: ${(await db.from('authz_assignments').select('uuid')).length}`)
    report('DESPUÉS de la migración: authorize(ana, docs:read, org) en `database`',
      await sql.authorize(ana, 'docs:read', org), false)

    await cleanSqlScopeTree(db)
  } finally {
    await dropStores()
    await app.teardown()
  }
}
run().then(() => process.exit(0), (e) => { console.error(e); process.exit(1) })
```

### `repro/b1_sondas.ts`

```ts
/** B1 — sondas varias: freeze, dry-run read-only, rooted, fila envenenada. */
import { boot, newStore, dropStores, allTuples, report, head, HOLDERS } from './harness.js'

const run = async () => {
  const { app } = await boot()
  const db = app.db
  try {
    const { sqlScopeTree, cleanSqlScopeTree } = await import('../tests/helpers/sql_scope_tree.js')
    const { resolveChainFrom } = await import('../src/testing/main.js')
    const { AuthorizationManager } = await import('../src/manager.js')
    const { syncAuthzCatalog } = await import('../src/catalog.js')
    const { OpenFgaAuthorizationDriver } = await import('../src/openfga.js')
    const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
    const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
    const { sqlScopeEdges } = await import('../src/sql_descendants.js')
    const { APP_SCOPE } = await import('../src/types.js')
    const { v7: uuidv7 } = await import('uuid')

    const tree = sqlScopeTree(db)
    const chain = resolveChainFrom(tree)
    const CATALOG: any = {
      permissions: [{ slug: 'docs:read' }, { slug: 'docs:write' }],
      roles: [{ slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read', 'docs:write'] }],
    }
    await syncAuthzCatalog(CATALOG)
    const sql: any = new DatabaseAuthorizationDriver({ resolveChain: chain })
    const store = await newStore(['docs:read', 'docs:write'])
    const facts: any = new OpenFgaAuthorizationDriver({
      apiUrl: store.apiUrl, storeId: store.storeId, modelId: store.modelId,
      holderTypes: HOLDERS, resolveChain: chain, hierarchy: 'facts',
      outbox: sqlScopeOutbox(), logger: { warn: () => {} },
    })
    await syncAuthzCatalog(CATALOG, { projection: facts.catalogProjection() })
    const edges = sqlScopeEdges({ table: 'demo_scopes', uuidColumn: 'uuid', parentColumn: 'parent_uuid', typeColumn: 'type' })
    const cfg = (): any => ({
      default: 'database', drivers: { database: () => sql, openfga: () => facts },
      scopes: { resolveChain: chain, outbox: sqlScopeOutbox(), enumerateEdges: edges },
      warnOnOptInSecurity: false,
    })
    const managerA = new AuthorizationManager(cfg())
    const managerB = new AuthorizationManager(cfg())

    const org = { type: 'organization', uuid: uuidv7() }
    const ana = { type: 'users', uuid: uuidv7() }
    await tree.attach(org, APP_SCOPE); await managerA.scopes.attached(org, APP_SCOPE)
    await managerA.relayScopeChanges()
    await managerA.grant(ana, 'org-admin', org)

    /* ── B1.1 · ¿el freeze cubre a los DEMÁS procesos? ─────────────── */
    head('B1.1 · freeze() — ¿congela el motor o solo esta instancia?')
    managerA.freeze('authz:reconcile de prueba')
    let bloqueadaA = 'no'
    try { await managerA.revoke(ana, 'org-admin', org) } catch (e: any) { bloqueadaA = e.code }
    let bloqueadaB = 'no'
    try { await managerB.revoke(ana, 'org-admin', org) } catch (e: any) { bloqueadaB = e.code }
    console.log(`  instancia que congela  → revoke: ${bloqueadaA}`)
    console.log(`  OTRA instancia (= otro proceso: el ace vs el worker HTTP) → revoke: ${bloqueadaB}`)
    console.log(`  managerA.frozen=${managerA.frozen}  managerB.frozen=${managerB.frozen}`)
    managerA.unfreeze()
    // rehacer el grant que B se llevó por delante
    await managerA.grant(ana, 'org-admin', org)

    /* ── B1.2 · ¿el --dry-run escribe algo? ────────────────────────── */
    head('B1.2 · --dry-run read-only, las dos direcciones')
    const antesStore = await allTuples(store.client)
    const antesSql = JSON.stringify([
      await db.from('authz_assignments').select('*').orderBy('uuid'),
      await db.from('authz_denies').select('*').orderBy('uuid'),
    ])
    const antesOutbox = await db.from('authz_scope_outbox').select('*')
    await managerA.reconcile({ to: 'openfga', dryRun: true, prune: true })
    await managerA.reconcile({ to: 'database', from: 'openfga', dryRun: true, prune: true })
    const despuesStore = await allTuples(store.client)
    const despuesSql = JSON.stringify([
      await db.from('authz_assignments').select('*').orderBy('uuid'),
      await db.from('authz_denies').select('*').orderBy('uuid'),
    ])
    const despuesOutbox = await db.from('authz_scope_outbox').select('*')
    console.log(`  store igual: ${JSON.stringify(antesStore) === JSON.stringify(despuesStore)}`)
    console.log(`  authz_* igual: ${antesSql === despuesSql}`)
    console.log(`  outbox igual: ${JSON.stringify(antesOutbox) === JSON.stringify(despuesOutbox)}`)

    /* ── B1.3 · rooted a mano ──────────────────────────────────────── */
    head('B1.3 · ¿se puede quedar «enraizado» un scope que no cuelga de app?')
    const huerfano = { type: 'organization', uuid: uuidv7() }
    await tree.attach(huerfano, APP_SCOPE)
    await managerA.grant(ana, 'org-admin', huerfano)
    await db.from('demo_scopes').where('uuid', huerfano.uuid).delete() // el árbol lo pierde
    // el store SIGUE teniendo su arista: `authorize` responde con el árbol del store
    report(`authorize sobre un scope cuya fila ya no existe (arista viva en el store)`,
      await facts.authorize(ana, 'docs:read', huerfano), 'n/a')
    // Ahora: una tupla `rooted` DIRECTA sobre un scope cualquiera, ¿la escribe alguien?
    const rootedTuples = (await allTuples(store.client)).filter((t) => t.includes('#rooted@'))
    console.log(`  tuplas #rooted en el store: ${rootedTuples.length}`)
    for (const t of rootedTuples) console.log(`    ${t}`)
    // ¿reconcile borraría una `rooted` plantada en otro scope?
    await store.client.writeTuples([{ user: 'user:*', relation: 'rooted', object: `scope:organization|${huerfano.uuid}` }])
    report('con `scope:<huerfano>#rooted@user:*` plantada a mano, authorize',
      await facts.authorize(ana, 'docs:read', huerfano), 'n/a')
    const rr = await managerA.reconcile({ to: 'openfga' })
    console.log(`  reconcile: fase root ${JSON.stringify(rr.phases.root)}  drift=${JSON.stringify(rr.drift)}`)
    report('tras reconcile (la `rooted` plantada debería haberse ido)',
      await facts.authorize(ana, 'docs:read', huerfano), 'n/a')

    /* ── B1.4 · fila envenenada en authz_* ──────────────────────────── */
    head('B1.4 · una fila de authz_* con identidad mal formada, ¿tumba la pasada?')
    const permRow: any = await db.from('authz_permissions').where('slug', 'docs:read').first()
    await db.table('authz_denies').insert({
      uuid: uuidv7(), holder_type: 'users', holder_uuid: uuidv7(),
      permission_uuid: permRow.uuid, scope_type: 'organization', scope_uuid: 'AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE',
      created_at: new Date(),
    })
    try {
      const r = await managerA.reconcile({ to: 'openfga', dryRun: true })
      console.log(`  la pasada TERMINÓ: skipped=${JSON.stringify(r.skipped)}`)
    } catch (e: any) {
      console.log(`  la pasada MURIÓ: ${e.code} / ${e.status} — ${String(e.message).slice(0, 140)}`)
    }
    await db.from('authz_denies').delete()

    await cleanSqlScopeTree(db)
  } finally {
    await dropStores()
    await app.teardown()
  }
}
run().then(() => process.exit(0), (e) => { console.error(e); process.exit(1) })
```

### `repro/b2_rooted.ts`

```ts
/** B2 — `rooted`: ¿se puede enraizar lo que no debe, o desenraizar lo que sí? */
import { boot, newStore, dropStores, allTuples, report, head, HOLDERS } from './harness.js'

const run = async () => {
  const { app } = await boot()
  const db = app.db
  try {
    const { sqlScopeTree, cleanSqlScopeTree } = await import('../tests/helpers/sql_scope_tree.js')
    const { resolveChainFrom } = await import('../src/testing/main.js')
    const { AuthorizationManager } = await import('../src/manager.js')
    const { syncAuthzCatalog } = await import('../src/catalog.js')
    const { OpenFgaAuthorizationDriver } = await import('../src/openfga.js')
    const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
    const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
    const { sqlScopeEdges } = await import('../src/sql_descendants.js')
    const { APP_SCOPE } = await import('../src/types.js')
    const { v7: uuidv7 } = await import('uuid')

    const tree = sqlScopeTree(db)
    const chain = resolveChainFrom(tree)
    const CATALOG: any = {
      permissions: [{ slug: 'docs:read' }],
      roles: [{ slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read'] }],
    }
    await syncAuthzCatalog(CATALOG)
    const sql: any = new DatabaseAuthorizationDriver({ resolveChain: chain })
    const store = await newStore(['docs:read'])
    const facts: any = new OpenFgaAuthorizationDriver({
      apiUrl: store.apiUrl, storeId: store.storeId, modelId: store.modelId,
      holderTypes: HOLDERS, resolveChain: chain, hierarchy: 'facts',
      outbox: sqlScopeOutbox(), logger: { warn: () => {} },
    })
    await syncAuthzCatalog(CATALOG, { projection: facts.catalogProjection() })
    const edges = sqlScopeEdges({ table: 'demo_scopes', uuidColumn: 'uuid', parentColumn: 'parent_uuid', typeColumn: 'type' })
    const manager = new AuthorizationManager({
      default: 'openfga', drivers: { openfga: () => facts },
      scopes: { resolveChain: chain, outbox: sqlScopeOutbox(), enumerateEdges: edges },
      warnOnOptInSecurity: false,
    } as any)

    const org = { type: 'organization', uuid: uuidv7() }
    const ana = { type: 'users', uuid: uuidv7() }
    await tree.attach(org, APP_SCOPE); await manager.scopes.attached(org, APP_SCOPE)
    await manager.relayScopeChanges()
    await manager.grant(ana, 'org-admin', org)
    await sql.grant(ana, 'org-admin', org, {})
    report('control: authorize(ana, docs:read, org)', await facts.authorize(ana, 'docs:read', org), await sql.authorize(ana, 'docs:read', org))

    head('B2.1 · una tupla `rooted` PLANTADA sobre un scope desgajado')
    const suelto = { type: 'organization', uuid: uuidv7() }
    await tree.attach(suelto, APP_SCOPE)              // existe para el consumidor
    await manager.grant(ana, 'org-admin', suelto)     // hechos escritos
    await sql.grant(ana, 'org-admin', suelto, {})
    // …pero su ARISTA nunca llega al store (relay perdido / attached nunca notificado)
    report('sin arista en el store: authorize', await facts.authorize(ana, 'docs:read', suelto), await sql.authorize(ana, 'docs:read', suelto))
    await store.client.writeTuples([{ user: 'user:*', relation: 'rooted', object: `scope:organization|${suelto.uuid}` }])
    report('con `scope:<suelto>#rooted@user:*` plantada a mano: authorize',
      await facts.authorize(ana, 'docs:read', suelto), await sql.authorize(ana, 'docs:read', suelto))
    const rr = await manager.reconcile({ to: 'openfga' })
    console.log(`  reconcile fase root: ${JSON.stringify(rr.phases.root)}  (¿borra la plantada?)`)
    report('tras reconcile', await facts.authorize(ana, 'docs:read', suelto), await sql.authorize(ana, 'docs:read', suelto))

    head('B2.2 · un DENY de un ancestro, ¿sobrevive a perder la raíz? (¿deny sin grant?)')
    const unit = { type: 'unit', uuid: uuidv7() }
    await tree.attach(unit, org); await manager.scopes.attached(unit, org); await manager.relayScopeChanges()
    await manager.deny(ana, 'docs:read', org)
    await sql.deny(ana, 'docs:read', org)
    report('deny en org ⇒ authorize en unit', await facts.authorize(ana, 'docs:read', unit), await sql.authorize(ana, 'docs:read', unit))
    // se rompe la cadena: se borra la arista org→app A MANO (deriva)
    await store.client.deleteTuples([{ user: 'scope:app', relation: 'parent', object: `scope:organization|${org.uuid}` }])
    report('con org desenraizada (deriva): authorize en unit', await facts.authorize(ana, 'docs:read', unit), await sql.authorize(ana, 'docs:read', unit))
    report('con org desenraizada (deriva): authorize en org', await facts.authorize(ana, 'docs:read', org), await sql.authorize(ana, 'docs:read', org))
    const rr2 = await manager.reconcile({ to: 'openfga' })
    console.log(`  reconcile fase tree: ${JSON.stringify(rr2.phases.tree)}`)
    report('tras reconcile: authorize en unit', await facts.authorize(ana, 'docs:read', unit), await sql.authorize(ana, 'docs:read', unit))

    head('B2.3 · marcador de raíz de un holder type que el config declara y el store no')
    const bea = { type: 'admins', uuid: uuidv7() }
    await manager.grant(bea, 'org-admin', org)
    await sql.grant(bea, 'org-admin', org, {})
    report('control admins', await facts.authorize(bea, 'docs:read', org), await sql.authorize(bea, 'docs:read', org))
    await store.client.deleteTuples([{ user: 'admin:*', relation: 'rooted', object: 'scope:app' }])
    report('sin marcador de raíz para `admin`: authorize', await facts.authorize(bea, 'docs:read', org), await sql.authorize(bea, 'docs:read', org))
    report('  …y `users` sigue: authorize(ana)', await facts.authorize(ana, 'docs:read', org), await sql.authorize(ana, 'docs:read', org))
    const rr3 = await manager.reconcile({ to: 'openfga', dryRun: true })
    console.log(`  --dry-run lo dice: drift.rootMarker=${rr3.drift.rootMarker}`)

    await cleanSqlScopeTree(db)
  } finally {
    await dropStores()
    await app.teardown()
  }
}
run().then(() => process.exit(0), (e) => { console.error(e); process.exit(1) })
```

### `repro/c1_orden_aparcado.ts`

```ts
/**
 * C1 — La garantía de ORDEN del relay (3b-2h) se apoya en que «dos cambios
 * que pueden interactuar comparten siempre un scope», pero `blocked` solo se
 * siembra con lo que falla o se aplaza EN ESA PASADA: una entrada APARCADA
 * no contamina nada, así que los cambios posteriores sobre el MISMO scope se
 * aplican fuera de orden, en silencio, en todas las pasadas siguientes.
 */
import { boot, newStore, dropStores, allTuples, report, head, HOLDERS } from './harness.js'

const run = async () => {
  const { app } = await boot()
  const db = app.db
  try {
    const { sqlScopeTree, cleanSqlScopeTree } = await import('../tests/helpers/sql_scope_tree.js')
    const { resolveChainFrom } = await import('../src/testing/main.js')
    const { AuthorizationManager } = await import('../src/manager.js')
    const { syncAuthzCatalog } = await import('../src/catalog.js')
    const { OpenFgaAuthorizationDriver } = await import('../src/openfga.js')
    const { DatabaseAuthorizationDriver } = await import('../src/drivers/database_driver.js')
    const { sqlScopeOutbox } = await import('../src/scope_outbox.js')
    const { sqlScopeEdges } = await import('../src/sql_descendants.js')
    const { APP_SCOPE } = await import('../src/types.js')
    const { v7: uuidv7 } = await import('uuid')

    const tree = sqlScopeTree(db)
    const chain = resolveChainFrom(tree)
    const CATALOG: any = {
      permissions: [{ slug: 'docs:read' }],
      roles: [{ slug: 'org-admin', scopeType: 'organization', rank: 50, permissions: ['docs:read'] }],
    }
    await syncAuthzCatalog(CATALOG)
    const sql: any = new DatabaseAuthorizationDriver({ resolveChain: chain })
    const store = await newStore(['docs:read'])
    const facts: any = new OpenFgaAuthorizationDriver({
      apiUrl: store.apiUrl, storeId: store.storeId, modelId: store.modelId,
      holderTypes: HOLDERS, resolveChain: chain, hierarchy: 'facts',
      outbox: sqlScopeOutbox(), logger: { warn: () => {} },
    })
    await syncAuthzCatalog(CATALOG, { projection: facts.catalogProjection() })
    const outbox = sqlScopeOutbox()
    const manager = new AuthorizationManager({
      default: 'openfga', drivers: { openfga: () => facts },
      scopes: { resolveChain: chain, outbox,
        enumerateEdges: sqlScopeEdges({ table: 'demo_scopes', uuidColumn: 'uuid', parentColumn: 'parent_uuid', typeColumn: 'type' }) },
      warnOnOptInSecurity: false,
    } as any)

    const orgA = { type: 'organization', uuid: uuidv7() }
    const orgB = { type: 'organization', uuid: uuidv7() }
    const unit = { type: 'unit', uuid: uuidv7() }
    const ana = { type: 'users', uuid: uuidv7() }   // empleada de A
    for (const [c, p] of [[orgA, APP_SCOPE], [orgB, APP_SCOPE], [unit, orgA]] as any[]) {
      await tree.attach(c, p); await manager.scopes.attached(c, p)
    }
    await manager.relayScopeChanges()
    await manager.grant(ana, 'org-admin', orgA)
    await sql.grant(ana, 'org-admin', orgA, {})
    report('control: ana lee en unit (heredado de orgA)', await facts.authorize(ana, 'docs:read', unit), await sql.authorize(ana, 'docs:read', unit))

    head('1. `detached(unit)` se encola y se APARCA (5 fallos: caída del store, purga que no cerró…)')
    await db.from('demo_scopes').where('uuid', unit.uuid).delete()
    await manager.scopes.detached(unit)
    await db.from('authz_scope_outbox').whereNull('applied_at').update({ attempts: 5, last_error: 'aparcada' })
    console.log(`  pending=${(await outbox.pending(10)).length}  dead=${(await outbox.dead!(10)).length}`)

    head('2. Un cambio POSTERIOR que nombra el MISMO scope: orgB crea SU unit con ese uuid')
    await tree.attach(unit, orgB)
    await manager.scopes.attached(unit, orgB)
    const rep = await manager.relayScopeChanges()
    console.log(`  applied=${JSON.stringify(rep.applied.map((a: any) => a.change.op))}`)
    console.log(`  deferred=${JSON.stringify(rep.deferred.map((d: any) => d.change.op))}  (¿aplazó el attached por depender del detached aparcado?)`)
    console.log(`  dead=${rep.dead.length}`)

    head('3. ¿ana —empleada de orgA— lee dentro de la unit de orgB?')
    report('authorize(ana, docs:read, unit-de-orgB)', await facts.authorize(ana, 'docs:read', unit), await sql.authorize(ana, 'docs:read', unit))
    head('4. Estado del store')
    for (const t of await allTuples(store.client)) console.log(`    ${t}`)
    console.log(`  orgA=organization|${orgA.uuid}  orgB=organization|${orgB.uuid}  unit=unit|${unit.uuid}`)

    await cleanSqlScopeTree(db)
  } finally {
    await dropStores()
    await app.teardown()
  }
}
run().then(() => process.exit(0), (e) => { console.error(e); process.exit(1) })
```
