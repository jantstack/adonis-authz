# Lote D · sublote D2 — re-ataque del cierre 1 (auditor) · 2026-10-15

**Árbol:** `main` sobre `75353fe`, con D2 + cierre 1 sin commitear.

**Cómo trabajé**
- No toqué el repo salvo este fichero.
- Todo lo ejecutado corrió en una copia: `scratchpad/audD2c/tree/` (node_modules enlazado), con SQLite `:memory:`.
- **OpenFGA `:8090`:** cuatro stores efímeros (`aud-d2c-*`). Los creó y los borró el propio script.
  - Corrí SIN `OPENFGA_TEST_URL`, para que la red de `bin/test.ts` no borrase los stores de la verificación paralela del coordinador.
- Sin restarts, gates, contenedores ni `test:pg|mysql`.

**Repros** (en `scratchpad/audD2c/tree/tests/`):

| Fichero | Qué contiene |
|---|---|
| `zz_aud_a{1,2,3}.spec.ts` | Los del predecesor, re-ejecutados |
| `zz_aud_c1.spec.ts` | Orden, sobre dobles |
| `zz_aud_c2.spec.ts` | Renovación de `relate` en `openfga`, contra `:8090` |
| `zz_aud_c3.spec.ts` | Receta `undeclared` con origen `openfga`, contra `:8090` |
| `../m5.mjs` | Un Write con delete + write de la misma clave |

## Veredicto en una línea

**NO apta para sellar alpha.3.**
- 🟠 1 y 🟠 2 están cerrados tal como se pidieron.
- Pero hay una **5.ª aparición del linaje L10 fuera de `tuple_order.ts`**: en `openfga`, `relate` renueva una membresía con DOS `Write`.
  - Una membresía que TRANSPORTA un deny desaparece entre los dos.
  - En el PDP que sirve: un denegado concede durante esa ventana.
  - Si el 2.º `Write` falla: el deny queda perdido para ese sujeto, sin marca `partial`.
  - En el reconcile: el destino cortado concede y el reporte dice «sin escribir nada».
- Lo demás resiste o es 🟡/⚪.

---

## Tabla hallazgo → estado

| # | Hallazgo previo | Estado | Evidencia |
|---|---|---|---|
| 🟠 1 | Orden del reconcile | **Cerrado**, con residuo y letra inexacta (🟡 N2, 🟡 N3) | ✅ A1/A1b re-ejecutados: `check=false` en k = 0…3, con dobles y con origen `database`. ✅ (ii) anidado a 3 niveles (U ∈ kk ⊂ zz ⊂ hh, deny en hh): la membresía `hh#member@zz#member` se clasifica como portadora (va 2.ª, justo tras el deny) y ningún k concede. ✅ (iii) deny sobre `g#member` sin miembros + membresía en la misma pasada: deny → membresía → F. ✅ `tuple_order.ts` sin imports; `check_purity` verde. (iv) **Hay otro camino: 🟠 N1** |
| 🟠 2 | Rollback | **Cerrado como DECLARADO** | ✅ README §Upgrading paso 0: «Skipping this leaves a window … switched off in silence, for good». ✅ Paso 21 con efecto (21b detecta, 21c 422). ✅ `recountBeforePublish` (`openfga_provision.ts:158`, `:278`). La ventana no es mínima (⚪ N5), pero el código dice «estrecha, no cierra» y el README pone la garantía en el paso 0 |
| 🟡 3 | `provision` contra el último modelo | **Cerrado** | ✅ `droppedEver` = unión de toda la historia (`:213`): sigue negando con alpha.10 en medio. Coste: paginado de 50 en 50, tope 10 000 (≤ 200 `ReadAuthorizationModels`). Nuevo: **🟡 N4** (bloqueo perpetuo con > 1 M tuplas) |
| 🟡 4 | Re-deny condicional | **Cerrado**; L9 no lo clasifica (⚪ N6) | ✅ `openfga_relations_driver.ts:756-767`, `reconcile.ts:666`. El catch por `denyConditional` es un bucket fuera de la reflexión de L9 (solo mira 422), y `--dry-run` ≠ pasada real (declarado) |
| 🟡 5 | Runbook 20 por grupo + M6 | **Cerrado** | Leído. No lo ejecuté (gate prohibido) |
| 🟡 6 | Receta `undeclared` | **Cerrado en los dos drivers** | ✅ `database`: caso del repo. ✅ `openfga` (medido por mí, `zz_aud_c3`): negativa `undeclared`; `removeDeny` ingenuo = 422; re-declarar sin opt-in + `removeDeny` = ok; la 2.ª pasada `written 1`. No hay caso `openfga` en el repo (⚪) |
| ⚪ 7 | L9 y `src/shared/` | Cerrado | ✅ `relations_reconcile_l9.spec.ts:33-39` |
| ⚪ 8 | Destino sin `kind` | Cerrado | ✅ A3 da ahora la negativa `unmarked` |
| ⚪ 9 | Cara `denyPhase` | Cerrado | ✅ H9 22 → 23: refuerzo, no debilitamiento (se añade `'denyPhase ·'` a la lista y FULL = 52) |
| ⚪ 10 | «PARCIAL» con 0 escrituras | **Cerrado para los dobles; falso en `openfga`** | Ver 🟠 N1-b: un `relate` de renovación borra y da `partial: false`, `written 0` ⇒ «pasada FALLIDA sin escribir nada» con el destino modificado |
| ⚪ 11 | Letra de la fase | Cerrado | Leído |
| ⚪ 12 | CHANGELOG, totales | Cerrado | ✅ CHANGELOG:320 «a change of meaning, not an addition» |

**Transversal**
- ✅ `EXPECTED_FUSED`: 0 apariciones en el diff.
- ✅ `migration_stub.spec` y `freeze.spec`: sin diff.
- ✅ CHANGELOG: un solo hunk `@@ -180,0 +181,142 @@` dentro de `[Unreleased]`, cero líneas borradas.
- ✅ Pasos 20 y 21: cada aserción vieja sigue presente, endurecida (cuentas 1 → 2, más 21b y 21c).
- ✅ Mutantes de orden: los `rec.order.*` y `fga.purge.*` se reescribieron sobre `tuple_order.ts`/`purgeWrites`. Un bypass de `relationWriteOrder` en `applyPartition` lo caza la fila «orden INVERSO».
- ⚪ El título de `relations.reconcile.order` sigue siendo universal («no concede lo que no concedían…»):
  - no menciona el residuo;
  - ninguna fila lo fija como declarado;
  - C2 (🟡 N3) también lo falsea.

---

## Hallazgos nuevos (por severidad)

### 🟠 N1 · L10, 5.ª aparición: `relate` de `openfga` RENUEVA con dos `Write` (delete, write)

Una membresía que transporta un deny desaparece entre los dos.

**Escenario (a), PDP que sirve**
- **Precondición:** `openfga` activo, con `document` en `deny: 'write'`.
  - `relate(U, viewer, X)`.
  - `relate(U, member, G, { expiresAt: +1 h })`.
  - `deny(G#member, viewer, X)`.
  - `check = false`.
- **Acción:** un admin extiende o hace permanente la membresía de U: `relate(U, member, G, { expiresAt: null | Date })`.
- **Resultado:**
  - Entre el delete y el write, un `check` concurrente da **true**.
  - Si el 2.º `Write` falla (503 no-timeout):
    - la membresía queda borrada;
    - `check(U, viewer, X)` = **true** de forma persistente;
    - el error es 503 con `isPartialWrite = false`, o sea «esa escritura no ocurrió» (invariante 13 falso) y sin evento `indeterminate`.
  - El deny de G deja de alcanzar a U en silencio.

**Escenario (b), reconcile**
- **Precondición:**
  - Origen `database`: membresía permanente de U en G.
  - Destino `openfga`: la misma membresía, con caducidad.
  - Deny en `G#member`. U tiene allow directo.
  - El inicial y el final niegan.
- **Acción:** la pasada (`toUpdate` ⇒ `relate`) se corta entre los dos `Write`.
- **Resultado:**
  - El destino **concede**.
  - El error lleva `partial: false`, `written 0` ⇒ el comando imprime «pasada FALLIDA sin escribir nada».

**Evidencia**
- ✅ Medido contra `:8090` (`zz_aud_c2.spec.ts`):
  - (a): `{"before":false,"gapEntreLosDosWrite":true,"after1":false,"err":{"status":503,"partial":false},"after2":true}`
  - (b): `{"init":false,"fin":false,"err":{"partial":false,"written":0,"updated":0},"destinoTrasElCorte":true}`
- ✅ Código: `src/drivers/openfga_relations_driver.ts:682-685`:

  ```ts
  if (current) {
    await this.#guard('relate', () => this.client.write({ deletes: [key] }, IGNORE_MISSING_DELETES))
  }
  await this.#guard('relate', () => this.client.write({ writes: [tuple] }, IGNORE_DUPLICATE_WRITES))
  ```
- ✅ No se puede hacer en un solo `Write` (`m5.mjs`): `400 … Error duplicate tuple in write`. Es la M5 del panel, que se resolvió solo para la tupla de DENY (D3: sin caducidad).
- El juez del panel 2 (línea 160) ya vio que «un miembro con caducidad puede transportar un deny», pero solo se midió la evaluación (M6), no la renovación.
- **Antes de D1 esto solo quitaba acceso** (fail-closed y una escritura parcial sin marcar). Desde que un deny viaja por `group#member` (D1, sin publicar), **concede**. O sea, lo introduce el lote D.

**Steelman del defensor:** «la ventana son milisegundos, renovar es una operación de admin, y el 2.º `Write` rara vez falla; quien recibe un 503 reintenta».
- **¿Me convence?** No.
  - El invariante 13 le dice al llamante que un 503 no-timeout de `relate` NO escribió nada, así que no tiene por qué reintentar. El estado persistente es fail-open y sin evento.
  - En (b) la letra afirma lo contrario de lo ocurrido.
  - El listón del lote («ningún estado intermedio concede a un denegado; ningún deny se pierde en silencio») cae en los dos.
- Lo dejo en 🟠 y no en 🔴: hace falta una carrera o un fallo entre dos requests, y el atacante no lo provoca.

**Mitigación mínima:** cuando el delete ya se aplicó, marcar `markPartialWrite` + `indeterminate` y reintentar o compensar el write; si no, declarar la ventana en el README, con caso.
- En el reconcile: contar el delete para el ⚪ 10.
- Quizá: una membresía PORTADORA no se renueva por delete+write.
- El diseño es del arquitecto.

### 🟡 N2 · La frase del residuo es inexacta: «el OTRO grupo» no necesita ser mixto

**Escenario**
- **Precondición:**
  - El destino ya tiene `aa#member viewer X`.
  - `aa` es portador porque tiene un deny en Y (o sea, mixto).
  - `hh` SOLO deniega en X (no es mixto).
- **Acción:** el origen añade U a `aa` y a `hh`. Es una pasada incremental o repetida, sin `--prune`.
- **Resultado:** tras k = 1, `[relate(U,member,aa)]` ⇒ **true**. El inicial y el final dan false.

**Evidencia**
- ✅ `zz_aud_c1.spec.ts` C1-i.
- README:824-826 dice «before the deny-carrying membership of **another such group** arrives». Basta con que el otro sea PORTADOR.
- Es alcanzable en la migración real: un destino no vacío (pasadas repetidas del cutover) y un origen que gana miembros entre pasadas.

**Steelman del defensor:** «está declarado y el destino no sirve». **¿Me convence?** En la severidad, sí; en la letra, no.

**Mitigación mínima:** «… of any other deny-carrying group», más una fila de la guardia que fije el residuo como declarado.

### 🟡 N3 · Segundo residuo NO declarado: escrituras + `--prune` componen estados (sin deny)

**Escenario**
- **Precondición:**
  - Destino: U ∈ g.
  - Origen: U ya no está en g, y `g#member viewer X` es nuevo.
- **Acción:** `--prune`, cortado tras la 1.ª escritura.
- **Resultado:** el ex-miembro **concede** sobre X, y ni el inicial ni el final lo hacen.

**Evidencia**
- ✅ `zz_aud_c1.spec.ts` C2: k = 1 ⇒ `true <== CONCEDE`.
- La causa es estructural: todas las escrituras van antes que toda la poda, y la unión de los dos estados compone membresías viejas con allows nuevos.
- No conseguí convertirlo en «concede a un DENEGADO». C2b, con un deny que se mantiene, sale F en todo k: el deny se escribe antes y se borra el último.
- La garantía publicada (README:823, CHANGELOG:267, título de la guardia) es universal y es falsa.
- Es anterior a D2, pero la frase la estrena este cierre.

**Steelman del defensor:** «no hay deny en juego y el destino no sirve». **¿Me convence?** Sí para 🟡; no para dejar la frase como está.

**Mitigación mínima:** declararlo como 2.º residuo («with `--prune`, a stale membership can compose with a new allow»), o intercalar la poda de membresías antes de los allows nuevos.

### 🟡 N4 · `provision --store-id` queda bloqueado PARA SIEMPRE en un store con más de 1 M tuplas, tras haber retirado un opt-in

**Escenario**
- **Precondición:** algún modelo de la historia declaró un `<tipo>#denied_<rel>` que el config actual ya no declara. Es un opt-in retirado bien, con 0 denies.
- **Acción:** cualquier `provision --store-id` posterior, con el store por encima de `PROVISION_DROP_DENY_SWEEP_MAX`.
- **Resultado:** exit 1 «el barrido no termina», sin bandera que lo salve: ni `--allow-drop-deny` lo evita. La historia no se puede borrar en FGA.

**Evidencia:** ✅ `openfga_provision.ts:213` (`droppedEver` ⇒ `sweep`) y `:259` (`truncated` ⇒ `null`). El informe declara el coste O(store), pero no este callejón.

**Steelman del defensor:** «es fail-closed». **¿Me convence?** Es disponibilidad, no seguridad. Lo dejo en 🟡 por no tener salida escrita.

**Mitigación mínima:** declararlo en Limits y en §Upgrading, con una salida (por ejemplo, migrar a un store nuevo).

### ⚪ N5 · La ventana del recuento no es mínima

- `recountBeforePublish` es otro barrido O(store) entero. Un deny que cae en una página ya leída del recuento, o entre el recuento y el `writeAuthorizationModel`, no se ve.
- El código lo dice («estrecha, no cierra») y el README pone la garantía en el paso 0.
- Pero la frase del README «Right before `writeAuthorizationModel` the sweep is repeated (… if a deny arrived meanwhile …)» se lee como detección completa.
- Además, sin el paso 0, un deny entre el paso 4 (contar) y el 5 (fijar y desplegar) entra contra el modelo viejo fijado y se apaga al re-fijar. Nada lo detecta. Está cubierto por la frase del paso 0.

**Mitigación:** media frase: «the recount narrows, it does not close the window: step 0 does».

### ⚪ N6 · `deny-conditional` es un bucket por `catch` fuera de la guardia L9

- `reconcile.ts:666` convierte un 500 marcado en residuo durante la PASADA, no en el plan.
- La reflexión de L9 solo enumera 422, y su punto 2 («mismos números en `--dry-run` y real») tiene aquí una excepción declarada en el README pero no registrada en la guardia.
- No es explotable: el resultado es ruidoso, con exit ≠ 0.

**Mitigación:** una entrada o excepción en L9 con caso.

---

## Lo que intenté y NO se rompió

**Orden y portadoras**
- A1/A1b del predecesor: verdes con el código del cierre.
- Anidado a 3 niveles: la clausura de portadoras baja correctamente por `X#member@Y#member`.
- Deny en un grupo sin miembros + membresía en la misma pasada: deny primero.
- Primera migración a destino vacío: ningún allow sobre un no-`group` llega antes de todas las membresías.

**Purgas y vistas**
- `purgeWrites`: con ≤ 100 tuplas es un solo `Write` transaccional. Con más, cada clase va en su propio `Write`, y las membresías de un sujeto caben en uno salvo más de 100 (residuo declarado de D1).
- `purgeSubject(U)` con membresías portadoras: van juntas en un `Write`.
- Vistas con partición en el id (`group:<pk>|<id>`): la clase y las portadoras se detectan igual (prefijo `group:` y sufijo `#member`).
- Un tipo de dominio llamado `group2`: no se confunde (`startsWith('group:')`).

**Otros caminos multi-request**
- `database` renueva en una transacción.
- `deny` y `removeDeny` de `openfga` son un `Write`.
- `unrelate` es un `Write`.
- `provision` solo publica el modelo.
- `authz:reconcile` es de roles.

**`provision` y debilitamientos**
- `provision` con un modelo alpha.10 en medio sigue negando (unión de la historia).
- Ningún debilitamiento: H9 sube; los pasos 20/21 se endurecen; `EXPECTED_FUSED`, `migration_stub` y `freeze.spec` siguen intactos; CHANGELOG solo en `[Unreleased]`.

## Preguntas abiertas para el arquitecto

1. 🟠 N1: ¿se marca como parcial + indeterminate y se compensa, se declara la ventana, o se prohíbe renovar en `openfga` una membresía portadora (422 con receta)? Sin una de las tres, el listón del lote no se cumple en el driver que sirve.
2. 🟡 N3: ¿se declara como 2.º residuo o se reordena la poda de membresías respecto de los allows nuevos? Solo lo segundo hace verdadera la frase universal.
