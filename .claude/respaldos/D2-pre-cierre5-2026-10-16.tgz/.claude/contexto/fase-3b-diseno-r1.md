# Diseño del arreglo del hallazgo 🔴 1 — el modelo **(c2r)**

**Encargo:** diseñar (no implementar) el cierre del 🔴 1 de `fase-3b-auditor-r2.md`, la escalada
que reabre R2 por la corrección del dueño del 2026-08-31. Propiedad a restaurar, literal:
*un scope cuya cadena no llega a la raíz `app` no debe conceder nada en `facts`, igual que en
`database`.*

**Método.** Worktree de solo lectura en `737c03f` (3b-2g), copia propia en scratchpad con
`node_modules` enlazado. **Todo lo que se afirma con ✅ está medido contra el OpenFGA real del
`:8101` (v1.19)**: cinco variantes de modelo publicadas en stores propios, el escenario del auditor
reproducido con el driver `facts` y el driver `database` en la misma ejecución sobre el mismo
catálogo y el mismo árbol, la profundidad medida con la metodología del 2e·E5 (25 repeticiones por
punto), el techo de tamaño contrastado con el número que el propio servidor reporta al rechazar
(**delta 0**), y **la suite completa corrida con el modelo cambiado** en SQLite+OpenFGA y en
PostgreSQL 18. Cero stores huérfanos en el `:8101` al acabar (0 con el prefijo `diseno-r1`), cero
bases residuales, ninguna base `authz_test*` tocada, cero ficheros del repo principal modificados.

---

## Veredicto en una línea

**El arreglo cabe en UNA relación más del modelo y NO hay conflicto con la promesa central de la
fase:** `authorize` sigue siendo **un solo `Check`** (medido: 1 `check`, 0 `batchCheck`, 0
`resolveChain`), el **techo de profundidad NO baja** (sigue siendo 22, con el mismo borde
probabilístico en 23), y el precio es **30 permisos de techo** (721 → 691) y **≤ 0,15 ms** a la
profundidad del dueño. Lo que sí cambia de comportamiento —y es la única decisión que queda para el
dueño— es que **durante el lag del relay un scope nuevo pasa a denegar** en vez de conceder.

| Lo que se preguntaba | Respuesta medida |
|---|---|
| ¿Lo acepta el servidor? | ✅ sí, y el transformador oficial lo renderiza a DSL y lo vuelve a parsear |
| ¿Cierra el escenario del auditor? | ✅ sí: `facts=false`, `database=false`, **PARIDAD** |
| ¿Sigue siendo UN solo `Check`? | ✅ sí — `{check:1, batchCheck:0}`, `resolveChain` 0 veces |
| ¿Cuántos ms añade? | ✅ +0,00–0,13 ms p50 a 3 saltos; +0,09–0,25 a 8; +0,27–0,41 a 20 |
| ¿Baja el techo de profundidad? | ✅ **no**: 22 sólido / 23 probabilístico / 24 nunca, igual que hoy |
| ¿Baja el techo de tamaño? | ✅ sí, poco: 721 → **691** permisos (−4,2 %) |
| ¿Cuántas tuplas por scope? | ✅ **cero**. Una tupla por holder type en todo el store (1–3) |
| ¿Qué se rompe? | ✅ exactamente **4 casos** de 667 (SQLite) / de 841 (PG); ninguno del juez |

---

## 1 · La opción recomendada: **(c2r)** = (c2) + `rooted`

Una relación nueva en `scope` —«desde aquí se llega a la raíz»— y `can_<P>` pasa a exigirla.
El nombre corto que uso en el resto del informe es **(c2r)**.

### El modelo literal (el mismo formato que el plan del lote 2)

```
type user / admin / integration                      # los holderTypes del consumidor
type role                                            # id = roleUuid
  define permits_<P>: [user:*, admin:*, integration:*]
type role_binding                                    # id = <scopeKey>|<roleUuid>
  define role: [role]
  define assignee: [<holders> with not_expired]
  define <P>: assignee and permits_<P> from role
type scope                                           # id = 'app' | '<tipo>|<uuid>'
  define parent: [scope]
  define binding: [role_binding]
  define <P>: <P> from binding or <P> from parent
  define denied_<P>: [<holders>] or denied_<P> from parent
  define rooted: [user:*, admin:*, integration:*] or rooted from parent     # ← NUEVO
  define can_<P>: (<P> but not denied_<P>) and rooted                       # ← CAMBIA
  define ancestor: parent or ancestor from parent
```

Y **una** tupla por holder type en todo el store, el *marcador de raíz*:

```
scope:app#rooted@user:*
scope:app#rooted@admin:*
scope:app#rooted@integration:*
```

Todo lo demás de (c2) queda intacto: mismos objetos, mismos ids, mismas tuplas de catálogo, misma
arista `scope#parent`, mismo `grant` de tres tuplas en un `Write`, mismo `ancestor`.

### El DSL, tal cual lo devuelve el transformador oficial de OpenFGA

✅ Medido con `@openfga/syntax-transformer` (`transformJSONToDSL` → `transformDSLToJSONObject`,
ida y vuelta idéntica salvo el orden de claves dentro de `tupleToUserset`, que ya difiere hoy):

```
type scope
  relations
    define parent: [scope]
    define binding: [role_binding]
    define docs_write: docs_write from binding or docs_write from parent
    define denied_docs_write: [user, admin] or denied_docs_write from parent
    define can_docs_write: (docs_write but not denied_docs_write) and rooted
    define ancestor: parent or ancestor from parent
    define rooted: [user:*, admin:*] or rooted from parent
```

Esto importa: el paréntesis mezclando `but not` y `and` **es DSL legal** en la sintaxis actual, así
que el modelo se puede leer con `fga model get`, pegar en el Playground y versionar como texto. Era
la única duda seria contra la forma anidada y **queda descartada por medida**, no por opinión.

### El JSON exacto que tendría que emitir `openFgaFactsModel` (lo único que cambia)

```jsonc
// type scope → relations[`can_${base}`]  (sustituye al `difference` de hoy)
{ "intersection": { "child": [
    { "difference": { "base":     { "computedUserset": { "relation": "docs_write" } },
                      "subtract": { "computedUserset": { "relation": "denied_docs_write" } } } },
    { "computedUserset": { "relation": "rooted" } }
] } }

// type scope → relations["rooted"]  (nueva)
{ "union": { "child": [
    { "this": {} },
    { "tupleToUserset": { "tupleset": { "relation": "parent" },
                          "computedUserset": { "relation": "rooted" } } }
] } }

// type scope → metadata.relations["rooted"]
{ "directly_related_user_types": [
    { "type": "user", "wildcard": {} },
    { "type": "admin", "wildcard": {} },
    { "type": "integration", "wildcard": {} }
] }
```

### Por qué esto restaura la propiedad, en dos frases

`rooted` es la **alcanzabilidad de la raíz materializada por el propio modelo**: solo `scope:app`
la tiene directa, y todo lo demás la hereda por `parent` exactamente igual que `denied_<P>`. Al
volver `can_<P>` una intersección con ella, un scope cuya cadena se rompió deja de conceder **sin
que nadie tenga que enumerar su subárbol ni escribir una sola tupla**, que es justo lo que hacía
que `scopes.detached` de un nodo intermedio fuese una primitiva de borrado de denies.

---

## 2 · Las alternativas, medidas y descartadas

Las cinco se publicaron en el servidor real y se midieron con el mismo guion. **Ninguna falló al
publicarse**: la decisión no es "cuál se puede", es "cuál cuesta menos".

| # | Opción | Techo permisos | Techo profundidad | `Check` único | Tuplas por scope | Veredicto |
|---|---|---|---|---|---|---|
| **A** | **(c2r) anidada** — `can_<P>: (<P> but not denied_<P>) and rooted` | **691** (−30) | **22** (igual) | ✅ sí | **0** | **ELEGIDA** |
| B | `flat` — relación intermedia `granted_<P>` + `can_<P>: granted_<P> and rooted` | 608 (−113) | 22 (igual) | ✅ sí | 0 | Descartada |
| C | `inBase` — `<P>: (<P> from binding and rooted) or <P> from parent` | 691 (−30) | 22 (igual) | ✅ sí | 0 | Descartada |
| D | `matRooted` — `rooted` **directo por scope**, escrito por el driver | 691 (−30) | 22 (igual) | ✅ sí | **1 × holders** | Descartada |
| E | Segundo `Check` (`ancestor` desde `scope:app`), **sin tocar el modelo** | 721 (igual) | 22 (igual) | ❌ **no** | 0 | Descartada |
| F | Lápida (`tombstoned`) escrita por `detached`, heredada hacia abajo | ~691 | 22 | ✅ sí | 1 × holders **por detach** | Descartada |

**Por qué cada una cae, con el dato que la tumba:**

- **B (`flat`)** era la candidata "por si el anidado no fuese DSL". Es DSL legal, sí, pero **cuesta
  83 permisos más de techo que (c2r)** (608 vs 691, medido: el servidor acepta 608 y rechaza 609
  con «model exceeds size limit: 262221 bytes vs 262144»). Como el anidado **también** es DSL legal
  (medido con el transformador oficial), B paga 83 permisos por nada. *Steelman:* una relación con
  un solo operador es más fácil de leer y de razonar, y `granted_<P>` sería un nombre útil en un
  informe de `reconcile`. **No compensa**: ese nombre se puede documentar sin publicarlo, y el techo
  de permisos es una cota dura que ya está declarada en el README.
- **C (`inBase`)** es idéntica a A en las cuatro cifras. Cae por **claridad y por radio de
  explosión**: mete la condición dentro de `<P>`, que es la relación que también leen `denied_<P>`
  y cualquier cosa futura que herede por `parent`, mientras que A la deja en `can_<P>`, que es
  **exactamente** lo que responde `authorize` y nada más. Con A, «lo que decide» y «lo que se
  hereda» siguen separados; con C se funden. Y A hace verdadera la frase corta que va al README
  («`can_<P>` = lo concedido, menos lo denegado, y solo si el scope llega a la raíz»).
- **D (`matRooted`)** —marcar cada scope con su propia tupla `rooted` en `attached`— es la opción
  "sin recursión". Mide igual de bien y encima es la que menos ruido dio a 23 saltos. Cae porque
  **rompe la propiedad que se está comprando**: la marca la escribe el paquete, así que la
  alcanzabilidad vuelve a ser un hecho que hay que mantener a mano — `detached` tendría que
  **recorrer y desmarcar el subárbol entero** (O(subárbol) lecturas + escrituras, por la outbox,
  con su propio lag y su propio "se me olvidó un nodo"), que es literalmente el bug que se está
  arreglando, movido de sitio. Con A la alcanzabilidad la calcula el servidor en cada pregunta y
  **no hay nada que mantener**.
- **E (segundo `Check`)** es la única que no toca el modelo y por eso hay que mirarla en serio.
  Medido: dos `Check` secuenciales cuestan **5,48 ms p50 vs 2,79** (casi ×2); metidos en **un
  `batchCheck` de 2 items** cuestan **2,93 ms**, o sea prácticamente lo mismo que hoy. O sea que
  **el argumento de latencia no la tumba**. La tumba el **cruce 6 del panel**, que es un literal
  aprobado del README: *«en modo `facts`, `authorize` es un único `Check`»*. Un `batchCheck` es una
  request, pero **son dos checks**, y `singleCheckAuthorize: true` dejaría de ser cierto; además
  `authorizeMany` pasaría de N a **2N items**, chocando con el tope de 50 por lote a la mitad de
  scopes. Y hay una arruga: `Check(scope:app, ancestor, scope:app)` es `false`, así que la raíz
  necesitaría un caso especial en el camino caliente. **No la descarto por el coste; la descarto
  porque cambia una promesa publicada para comprar algo que A da gratis.**
- **F (lápida)** cerraría el caso del auditor sin tocar el lag del relay, que es su única ventaja
  real. Cae porque **no restaura la propiedad pedida**: solo cubre el camino `detached`. Medido en
  el escenario E de la comparativa de paridad: un scope cuya arista **nunca llegó al store** sigue
  concediendo (`facts=true`) — con lápidas seguiría igual, porque no hay lápida que escribir. La
  frase del encargo dice *«un scope cuya cadena no llega a la raíz»*, no *«un scope que alguien
  detachó»*.

---

## 3 · Las mediciones

### 3.1 · El servidor acepta las cinco (control)

```
base       bytes= 1916 (0.73% del techo)  ACEPTADO
nested     bytes= 2056 (0.78% del techo)  ACEPTADO      ← (c2r)
flat       bytes= 2269 (0.87% del techo)  ACEPTADO
inBase     bytes= 2056 (0.78% del techo)  ACEPTADO
matRooted  bytes= 2028 (0.77% del techo)  ACEPTADO
```

### 3.2 · Cierra el escenario del auditor (`repro/a2_escalada_within.ts`, mismo guion)

Con `requireWithin: true`, `app ← org A (deny docs:write a alice) ← division D ← unit U`:

```
=== VARIANTE: base (el modelo de HOY) ===
1) El actor manda en la DIVISION (within: div). ¿Qué puede hacer?
  removeDeny(docs:write, org)  → 422 E_AUTHZ_NOT_WITHIN
  grant(org-admin, org)        → 422 E_AUTHZ_NOT_WITHIN
  scopes.detached(div)         → OK (purgada)
2) Después de detachar SU division:
  authorize(alice, docs:write, unit)   facts=true  database=false *** FACTS FAIL-OPEN ***

=== VARIANTE: nested (c2r) ===
1) (las tres barreras responden igual: 422, 422, OK)
2) Después de detachar SU division:
  authorize(alice, docs:write, unit)   facts=false database=false PARIDAD
   deny en la org tras la operación: scope:app #parent | user:… #denied_docs_write
```

El deny sigue escrito (no se ha borrado nada de la org): lo que se ha restaurado es que **el camino
por el que se heredaba ya no se puede romper para conceder**.

### 3.3 · Paridad completa `facts` vs `database` (lo que el arreglo podía romper)

Mismo catálogo, mismo árbol, misma ejecución. `bob` tiene un grant local en la unit, `carol` uno en
la org (hereda 2 saltos), `dave` uno en la raíz `app`:

| Caso | base (hoy) | **(c2r)** |
|---|---|---|
| A · camino feliz: grant local, heredado 2 saltos, en su propio scope, y que NO sube | PARIDAD ×4 | **PARIDAD ×4** |
| B · grant en la RAÍZ `app`: decide en `app` y baja a la unit | PARIDAD ×2 | **PARIDAD ×2** |
| C · la division se detacha: los 3 sujetos + un control en la org intacta | **1 de 4 FAIL-OPEN** | **PARIDAD ×4** |
| D · reparación: el consumidor recuelga la unit de la org | PARIDAD ×2 | **PARIDAD ×2** |
| E · scope nuevo cuya arista aún no llegó al store (**lag del relay**) | PARIDAD (los dos `true`) | ⚠️ **FACTS FAIL-CLOSED** (`facts=false`, `database=true`) |

**E es el único cambio de comportamiento del diseño y está en §4.**

### 3.4 · El coste: sigue siendo UN solo `Check`

Contando llamadas sobre el cliente del driver (`countCalls`, el mismo espía de la suite), con el
modelo (c2r) publicado y el driver **sin tocar**:

```
authorize                ⇒ {"check":1,"batchCheck":0,"read":0,"write":0,"listObjects":0}
authorizeMany(4 scopes)  ⇒ {"check":0,"batchCheck":1,"read":0,"write":0,"listObjects":0}
resolveChain llamado en authorize: 0 veces
```

**La promesa del cruce 6 sobrevive intacta y sin cambiar una línea de `factsAuthorize`.**

Latencia, benchmark **pareado** (las dos variantes intercaladas muestra a muestra, dos tandas
independientes de 500 muestras, `HIGHER_CONSISTENCY`):

| profundidad | caso | base p50 | (c2r) p50 | **Δ p50** |
|---|---|---|---|---|
| 3 saltos (la topología del dueño) | concede | 2,79 / 2,81 ms | 2,93 / 2,80 ms | **+0,13 / −0,01 ms** |
| 3 saltos | deniega por deny | 1,89 / 1,65 | 1,88 / 1,71 | −0,01 / +0,05 |
| 8 saltos | concede | 3,78 / 3,82 | 4,03 / 3,93 | +0,25 / +0,12 |
| 20 saltos | concede | 6,52 / 6,49 | 6,79 / 6,90 | +0,27 / +0,41 |

A la profundidad real del dueño el coste **está por debajo del ruido de medida** (< 5 %). Para
calibrar: (c2) le costó **0,8 ms** a (c1) y se aceptó.

### 3.5 · El techo de profundidad **no se mueve** (lo importante del informe)

Metodología del 2e·E5 (grant en la raíz, `Check` a profundidad creciente, **25 repeticiones por
punto**), dos tandas con el orden de variantes invertido para descartar calentamiento:

| variante | 15–22 saltos | 23 saltos (tanda 1 / tanda 2) | 24 saltos |
|---|---|---|---|
| base (hoy) | 25/25 | 10/25 · 19/25 | 0/25 |
| **nested (c2r)** | **25/25** | 20/25 · 0/25 | 0/25 |
| flat | 25/25 | 23/25 · 0/25 | 0/25 |
| inBase | 25/25 | 14/25 · 21/25 | 0/25 |
| matRooted | 25/25 | 25/25 · 16/25 | 0/25 |

**`FACTS_MAX_RESOLVE_DEPTH = 22` sigue siendo exacto y no hay que tocarlo**, y el borde de 23 sigue
siendo probabilístico —esta vez se ve mejor que en el 2e: el **mismo** modelo base dio 10/25 y
19/25 en dos tandas separadas por minutos—. El motivo de que no cueste saltos es que
`--resolve-node-limit` acota la **profundidad** del árbol de resolución, no el número de nodos, y
`rooted` es una rama **paralela** al `difference` y más barata que él (es la misma forma que
`denied_<P>`, que llegaba a 25). El techo lo sigue marcando la rama cara, que no ha cambiado.

> Ojo con el detalle metodológico, que vale para quien implemente: **medir el borde con 25
> repeticiones o no medirlo**. Con una sola llamada, `nested` "habría fallado" a 23 en una tanda y
> "habría pasado" en la otra. Es la lección de 3G·Y1 otra vez.

### 3.6 · El techo de tamaño del modelo

`factsModelBytes` **sigue siendo exacto sin tocarla** para las cinco variantes: se contrastó con el
número que el servidor reporta al rechazar, en el permiso exacto del borde. **Delta 0 en las cinco.**

```
base       n=722 servidor=262292 factsModelBytes=262292 delta=0
nested     n=692 servidor=262506 factsModelBytes=262506 delta=0
flat       n=609 servidor=262221 factsModelBytes=262221 delta=0
inBase     n=692 servidor=262506 factsModelBytes=262506 delta=0
matRooted  n=692 servidor=262478 factsModelBytes=262478 delta=0
```

Techos verificados por los dos lados (el servidor acepta N y rechaza N+1), 3 holders y slugs cortos
—la misma forma con la que se midió el ≈720 del 2a—:

| variante | techo de permisos | bytes en el techo | vs hoy |
|---|---|---|---|
| base (hoy) | **721** | 261 927 | — |
| **(c2r)** | **691** | 262 125 | **−30 permisos (−4,2 %)** |
| flat | 608 | 261 788 | −113 (−15,7 %) |

El coste de (c2r) en bytes es **92 fijos + 16 por permiso** (3 holders; 64 + 16 con un holder). Con
slugs de 40 caracteres —la forma que usan los casos A3— el techo pasa de **277 a 272** permisos.

**Consecuencia para la suite: los casos A3 siguen verdes tal cual.** Medido: con 289 permisos
largos el modelo sigue pasándose (277 765 bytes > 262 144) y con 230 sigue estando en el 84,4 %,
o sea por encima del aviso del 80 % y por debajo del techo. No hay que retocar ni un número.

---

## 4 · Tuplas nuevas, quién las escribe, y el lag del relay

### 4.1 · Por scope: **cero**

`attached`, `moved` y `detached` **no escriben ni una tupla más**. La outbox no lleva entradas
nuevas, el relay no aplica operaciones nuevas y `purgeScope` no tiene nada más que borrar. Ésta es
la diferencia práctica entre (c2r) y la variante D, y es la razón por la que se elige.

### 4.2 · Por store: una tupla por holder type, una vez

El marcador de raíz (`scope:app#rooted@<holder>:*`): tantas tuplas como holder types, típicamente 1–3. Propuesta de quién lo escribe:

| Momento | Quién | Qué hace |
|---|---|---|
| Provisión del store | `openfga:provision` / `provisionOpenFgaStore` | publica el modelo **y** escribe el marcador en el mismo paso |
| Cada `syncAuthzCatalog` con proyección | `projectCatalog` → `ensureFactsRoot()` | 1 `Read({object:'scope:app', relation:'rooted'})` + `Write` **solo de lo que falte** (idempotente; 0 escrituras en el caso normal) |
| `authz:reconcile` (3b-3) | el comando | lo **reporta como drift** si falta, y lo repone en `--to=openfga` |

`ensureFactsRoot()` en `projectCatalog` es lo que cubre el caso operativo real: **añadir un
holderType** al `config`. Sin él, el holder nuevo denegaría en todo el store aunque el modelo se
haya republicado.

> ⚠️ **Modo de fallo nuevo, y hay que declararlo:** sin marcador, **todo el store deniega**. Medido:
> `can_docs_write` = `false` en `app`, en la org y en la unit. Es fail-**closed** (no es una fuga) y
> es ruidoso a la primera pregunta, pero es una caída total y silenciosa desde el punto de vista del
> log. Por eso el marcador va en **tres** sitios y no en uno, y por eso `reconcile` tiene que
> mirarlo. En la práctica es el mismo tipo de riesgo que "el modelo no está publicado", que ya se
> asume.

### 4.3 · Qué pasa durante el lag del relay — **el único cambio de comportamiento**

✅ Medido (caso E de §3.3), con la outbox declarada y el relay sin pasar todavía:

| Situación | Hoy (base) | Con **(c2r)** | `database` |
|---|---|---|---|
| Scope **nuevo** creado + `grant`, `attached` **encolado sin relevar** | `true` (fail-open: no hereda los denies de arriba) | **`false`** (fail-closed: aún no llega a la raíz) | `true` |
| `detached` encolado sin relevar | sigue concediendo | sigue concediendo (igual) | `false` |
| `moved` encolado sin relevar | decide con el árbol viejo | igual | árbol nuevo |
| Entre el `detached(D)` relevado y el `moved(hijos)` todavía en cola | los hijos conceden | **los hijos deniegan** (transitorio) | según el árbol del consumidor |

O sea: **(c2r) convierte el fail-open del lag en fail-closed**. Es más seguro y es lo que hace que
el arreglo funcione, pero **es una regresión de disponibilidad medible para el consumidor**: entre
crear un tenant y el siguiente pase del relay, su admin no puede hacer nada en ese scope. Tres
cosas atenúan y hay que escribirlas:

1. **Sin outbox** (`acceptScopeDriftRisk: true`) el manager llama al driver **en línea** (verificado
   en `src/manager.ts`, rama `if (outbox) … return` / `await driver.onScopeAttached?.()`): la
   ventana es **cero**.
2. Con outbox, el consumidor puede **drenar la cola en la misma petición**, después del commit, en
   el camino interactivo de "crear scope". Eso reduce la ventana a un ciclo de relay solo para lo
   que falle. **Esto tiene que ir al README con esas palabras.**
3. La ventana ya está declarada como riesgo 🟠 del cruce 4; lo que cambia es **el signo**, y el
   README dice hoy lo contrario ("fail-open temporal"). Hay que reescribir esa frase.

---

## 5 · Qué se rompe

### 5.1 · La suite: exactamente **4 casos**, y ninguno es del juez

✅ Medido de verdad: apliqué (c2r) sobre una copia del árbol (`openFgaFactsModel` + un
`ensureFactsRoot()` mínimo en `projectCatalog`) y corrí la suite entera.

```
SIN el cambio:   Tests  667 passed (667)
CON el cambio:   Tests  663 passed, 4 failed (667)

PostgreSQL 18:   Tests  835 passed, 6 failed (841)
                 ↳ 4 son los mismos; los otros 2 son artefacto de mi nombre de base
                   propio (el caso J2 exige que la base case /^authz_test_[0-9a-f]{8}$/)
```

Los cuatro, y qué hay que hacer con cada uno:

| Caso | Por qué falla | Qué se hace |
|---|---|---|
| `facts · A1 / openFgaFactsModel(...) es el literal del plan` | compara el modelo con el literal escrito a mano | **reescribir el literal** con `rooted` y el `can_<P>` anidado. Es el caso que fija el modelo: tiene que cambiar a sabiendas |
| `facts · A1 / la semántica de (c2): el catálogo concede, el árbol hereda, el deny gana` | escribe tuplas a pelo con el SDK, sin pasar por `syncAuthzCatalog` ⇒ sin marcador de raíz | **añadir el marcador** al montaje del caso (y así el caso documenta que hace falta) |
| `facts · 3b-2b / attached/moved/detached … y la herencia lo sigue` | igual: store montado a mano | **añadir el marcador** al montaje |
| `facts · 3b-2b` / el ciclo `parent` escrito a mano que concede hacia ARRIBA (fail-open del cruce 3) | el ciclo del caso está **huérfano** (no cuelga de `app`) y con (c2r) deja de conceder | **reescribir el caso colgando el ciclo del árbol** (ver §6) — el fail-open del ciclo **sigue vivo** y el caso tiene que seguir documentándolo |

**Los 83 casos del juez contra `facts`, el contrato entero y todo el resto pasan sin tocar nada.**
Ése era el riesgo grande del diseño (que el espejo del árbol del harness dejara scopes sin raíz) y
está **descartado por medida**: `memoryScopeTree` nace vacío y todo nodo entra por `attach`, que el
harness espeja.

### 5.2 · Invariantes y documentación que hay que reescribir

| Dónde | Qué dice hoy | Qué pasa a decir |
|---|---|---|
| **Invariante 9** (`CLAUDE.md:52`) | «Scope desconocido = no existe. `resolveChain ⇒ null` deniega» — y en `facts` no lo hacía `authorize` | añadir: en `facts` lo hace el **modelo** (`can_<P>` exige `rooted`), no `resolveChain`. **Un scope que no alcanza `app` en el store deniega**, tenga los bindings que tenga |
| **Invariante 1** | herencia solo hacia abajo | matizar: en `facts`, hacia abajo **desde la raíz**. Un subárbol desgajado no concede |
| **Invariante 11** (purga) | el orden S6 (hechos primero, arista al final) | el motivo ya no es «los denies dejarían de aplicar»: con (c2r) el subárbol deniega. El orden **se mantiene igual** (una purga a medias sigue teniendo que dejar denies de más), pero el docblock de `onScopeDetached` miente y hay que corregirlo |
| **R2 (a)** | la redacción que el auditor propuso, y la del dueño | **desaparece**: deja de ser una divergencia declarada y pasa a ser paridad. Queda R2 (b) —que no se discute— y R2 (c) —que es del lote de bugs— |
| `openfga_facts.ts:37, :100` · `errors.ts:514` · `README.md:377` | «≈720 permisos» | **≈691** |
| `openfga_facts.ts` docblock del modelo · `CLAUDE.md:345` | el literal de (c2) | el literal de (c2r) |
| `CLAUDE.md:317-319` (profundidad) | 22 / borde probabilístico en 23 | **no cambia** (remedido) |
| README · *The tree outbox* | «fail-open temporal» durante el lag | **fail-closed** para scopes nuevos; fail-open sigue para `detached`/`moved`. Con la receta de drenar la cola en la misma petición |
| Capacidades | `hierarchyFacts`, `singleCheckAuthorize`… | **no cambian**. `singleCheckAuthorize: true` sigue siendo cierto (medido) |

### 5.3 · ¿Es breaking para un consumidor?

**Sí, y hay que decirlo con esas palabras** — pero cae dentro de lo que el dueño ya firmó
(«2.0.0 breaking; hoy no hay consumidores ⇒ romper es gratis»):

1. **Un store existente en modo `facts` deja de conceder al republicar el modelo hasta que se
   escriba el marcador.** Mitigación: la republicación y el marcador van en la misma operación, y
   `authz:reconcile` lo repone. **Debe ir en el CHANGELOG como paso de migración, no como nota.**
2. **Un consumidor que no notificaba `attached` de todos sus nodos** (el descuido que el auditor
   llama «lo normal con rutas materializadas») pasaba a conceder de más y ahora **deja de conceder**.
   Es el arreglo, pero se ve como «se me han caído permisos», así que el CHANGELOG tiene que decir
   *cómo se diagnostica*: `reconcile --dry-run` lista los scopes no alcanzables.
3. **La ventana del relay cambia de signo** (§4.3). Es lo único que puede obligar a un consumidor a
   cambiar su código (drenar la cola tras crear un scope).

---

## 6 · Lo que el arreglo **NO** cierra (para que nadie lo dé por cerrado)

✅ Todo medido:

- **El ciclo colgado del árbol sigue siendo fail-open.** Un nodo con **dos padres** —`app` y un
  descendiente suyo— hace que el ciclo entero sea `rooted`, y un grant dentro del ciclo sigue
  concediendo hacia arriba (`can@ancestro = true` en base **y** en (c2r)). La mitigación sigue
  siendo la del cruce 3: anti-ciclos en el paquete. Lo que sí cierra es el **ciclo huérfano**
  (X→Y→X sin colgar de `app`): pasa de `true` a `false`.
- **El hallazgo 🟠 3 (alias del uuid en escritura) queda igual.** Si `purgeScope` se dirige a la
  ortografía equivocada, el scope real conserva `parent` y `binding`, sigue siendo `rooted` y sigue
  concediendo. Es del lote de bugs, no de aquí.
- **El hallazgo 🔴 2 (tapón de la outbox) queda igual**, y **empeora de forma interesante**: con el
  relay atascado, los scopes nuevos ahora **no funcionan** en vez de funcionar de más. Sigue siendo
  un DoS al alcance de cualquier tenant y sigue siendo del lote de bugs, pero el síntoma que verá el
  operador cambia (de «fuga silenciosa» a «los tenants nuevos no pueden hacer nada»), lo cual
  probablemente sea bueno: se detecta.
- **`hasRole` / `list*` no cambian.** Siguen enumerando por `assignee` + catálogo y siguen usando
  `resolveChain`. Un binding en un scope desgajado **sigue siendo membresía** aunque no conceda —
  exactamente igual que en `database`, donde `listRoles` sobre un scope desconocido no lista pero el
  hecho existe. Es coherente con la nota del invariante 18 («la arista `scope#binding` significa *el
  rol es visible aquí*, no *la asignación existe*»), pero **conviene un caso que lo fije**.

---

## 7 · El plan por piezas

Propuesto como **lote 3b-2i**, después del **3b-2h** que la corrección del dueño asignó a los
hallazgos 🔴 2 / 🟠 3 / 🟠 4. *(El orden 2h↔2i es del coordinador. Argumento para adelantar éste:
es la escalada, y es lo que bloquea la redacción del README; argumento para dejarlo detrás: 2h
toca `manager.ts`/`scope_outbox.ts` y este lote toca `openfga_facts.ts`/`openfga_driver.ts`, así que
**no hay solape de ficheros** y el orden es indiferente para los conflictos.)*

> Base: `737c03f`. Diseño **medido, no supuesto**: modelo **(c2r)**, §1 de este informe.
> El literal del modelo no se renegocia dentro del lote: se implementa.

### 3b-2i · `can_<P>` exige alcanzar la raíz

| # | Pieza | Criterio de aceptación (rojo→verde) |
|---|---|---|
| **I1** | `openFgaFactsModel` emite `scope#rooted` (unión de directo con comodín de holder + TTU por `parent`) y `can_<P>` como `intersection(difference(<P>, denied_<P>), rooted)`. `'rooted'` entra en `OWN_RELATIONS` (un permiso llamado `rooted` ⇒ 422, como `ancestor`) | El caso del literal (`facts · A1`) se reescribe con el modelo de §1 y **falla antes / pasa después**; el modelo **se escribe sin error contra el `:8101`**; caso negativo: permisos `['rooted']` ⇒ 422 nombrando la relación propia |
| **I2** | `factsRootTuples(holderTypes)` + `ensureFactsRoot()` en el driver: `Read({object:'scope:app', relation:'rooted'})` y `Write` **solo de lo que falte**. Se llama desde `projectCatalog` y desde la provisión del store | Espía: `sync` en un store virgen ⇒ **1** `Write` con una tupla por holder type; `sync` otra vez ⇒ **0** escrituras (idempotente); añadir un holderType al config ⇒ **1** `Write` con **1** tupla. Mutante obligatorio: `ensureFactsRoot` desactivado ⇒ el caso de I3 se pone rojo |
| **I3** | **El caso del auditor, de punta a punta.** `app ← org A (deny) ← D ← U`, `requireWithin: true`, `scopes.detached(D, {within: D})` | Caso de **paridad entre drivers**: `authorize(alice,'docs:write',U)` ⇒ `false` en `facts` **y** en `database`, con el deny **todavía escrito** en `scope:organization\|A` (se lee y se afirma). Y las tres barreras siguen respondiendo 422/422/OK: el arreglo **no** es "cerrar `detached`" |
| **I4** | **La paridad que el arreglo podía romper**, en un solo caso por fila de §3.3 | A (grant local / heredado 2 saltos / en su scope / no sube), B (**grant en la raíz `app`**, que es el que muere si falta el marcador), C (detach ⇒ el subárbol deja de conceder, con control de que la org intacta sigue concediendo), D (recolgar restaura). Los cuatro con los dos drivers respondiendo lo mismo |
| **I5** | **El caso negativo del marcador**: sin `scope:app#rooted`, el store deniega **todo** | Caso: se borra el marcador a mano ⇒ `authorize` en `app`, en la org y en la unit ⇒ `false` (fail-closed, **nunca** un 503 ni un throw); tras `syncAuthzCatalog` vuelve a conceder. Es lo que documenta el modo de fallo de §4.2 |
| **I6** | **La ventana del relay cambia de signo.** Caso explícito, no una nota | Caso: `attached` encolado y **sin relevar** + `grant` ⇒ `facts=false` / `database=true`, marcado como **fail-CLOSED declarado**; tras `relayScopeChanges()` ⇒ los dos `true`. Y el control de que **sin outbox** la ventana es cero |
| **I7** | **El ciclo del cruce 3 sigue documentado, con el montaje correcto.** El caso de hoy usa un ciclo huérfano y ahora daría `false` por el motivo equivocado | Se reescribe colgando el ciclo del árbol (nodo con dos padres: `app` y un descendiente) ⇒ **sigue concediendo hacia ARRIBA** y sigue respondiendo en ms. Y **caso hermano nuevo**: el ciclo **huérfano** ⇒ `false` (lo que (c2r) sí cierra) |
| **I8** | Cotas y documentación: `FACTS_MODEL_MAX_BYTES` **no cambia**, `FACTS_MAX_RESOLVE_DEPTH` **no cambia** (22), y el «≈720» pasa a **≈691** en los cuatro sitios donde está escrito | Los casos A3 (289 ⇒ 500 `E_AUTHZ_MODEL_TOO_LARGE`; 230 ⇒ avisa) **siguen verdes sin retocar números** (verificado); los casos de profundidad (22 decide / 24 es 503) **siguen verdes sin retocar números** (verificado). Si alguno cambia, es que el modelo no es el de §1 |
| **I9** | Invariantes 1, 9 y 11 reescritos en `CLAUDE.md`; R2 (a) **retirado** de la redacción pendiente del README; la frase del lag reescrita con el signo correcto y con la receta de drenar la cola | Revisión del diff: no queda ninguna frase que prometa que un scope huérfano concede, ni ninguna que llame fail-**open** al lag de un `attached` |

**Fuera de este lote:** los hallazgos 🔴 2 / 🟠 3 / 🟠 4 (lote 2h), `authz:reconcile` (3b-3) —aunque
este lote le deja **dos deberes escritos**: reportar el marcador de raíz ausente, y listar los
scopes **no alcanzables** desde `app`, que es la única herramienta que un consumidor va a tener para
diagnosticar «se me han caído permisos»—.

**Aceptación del lote:** los 83 casos del juez verdes contra `facts` en PG y MySQL; los 5 modos
verdes; **exactamente 4 casos existentes cambian y son los de §5.1** (si cambia un quinto, hay algo
sin entender); mutante obligatorio por pieza (I2 sin `ensureFactsRoot`, y el `can_<P>` sin la
intersección ⇒ I3 rojo); tester en worktree + auditor sobre el árbol **en secuencia, nunca en
paralelo**; `/code-review`; correcciones; commit.

---

## 8 · Lo que decide el dueño (no lo decido yo)

**No hay conflicto entre la seguridad del modelo y la promesa de la fase**: el `Check` único
sobrevive, medido. Así que la única pregunta que queda no es técnica:

> **¿Se acepta que, con la outbox declarada, un scope recién creado NO conceda nada hasta que pase
> el relay?** Hoy concede (y por eso hay una escalada). Con (c2r) deniega. Es fail-closed, es más
> seguro y es lo que hace que el arreglo funcione — pero para el consumidor es «he creado el tenant
> y su admin no puede entrar durante N segundos».

Tres salidas, por si ayuda: (a) aceptarlo y documentar la receta de drenar la cola en la misma
petición (lo que yo recomiendo, y no cuesta código del paquete); (b) aceptarlo y además hacer que
el manager drene la cola de forma síncrona **solo** para `attached` cuando el consumidor lo pida
con una opción explícita; (c) no aceptarlo, lo que obliga a la variante F (lápidas) y a renunciar a
la propiedad general —cerraría el caso del auditor y dejaría abierto el scope que nunca se
notificó—. **(c) no la recomiendo**: es volver a declarar media divergencia, que es justo lo que la
corrección del 2026-08-31 rechazó.

Y una pregunta menor, para el 3b-3: **¿`reconcile --to=openfga` repone el marcador de raíz por su
cuenta, o solo lo reporta?** Reponerlo es una escritura que concede en todo el store; hoy la regla
del cruce 4 es que `verify` es read-only por contrato y un `--fix` está prohibido. Yo lo reportaría
en `verify`/`--dry-run` y lo repondría **solo** en `--to=openfga`, que ya es un camino de escritura
declarado.

---

## 9 · Reproducciones ejecutables

Desde una copia del worktree con `node_modules` enlazado (el worktree no los trae):

```bash
cp -a <worktree> /tmp/lab && rm -f /tmp/lab/.git
ln -s <repo>/node_modules /tmp/lab/node_modules
mkdir -p /tmp/lab/lab      # y dentro los ficheros de abajo
cd /tmp/lab
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/01_accept.ts     # §3.1
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/02_ceiling.ts    # §3.6
VARIANT=base   OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/04_auditor.ts   # §3.2
VARIANT=nested OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/04_auditor.ts
VARIANT=base   OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/05_paridad.ts   # §3.3
VARIANT=nested OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/05_paridad.ts
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/03_depth.ts      # §3.5 (25 reps)
VARIANTS=matRooted,inBase,flat,nested,base … lab/03_depth.ts                                 #      (orden invertido)
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/07_pareado.ts    # §3.4
VARIANT=nested OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/10_un_check.ts  # §3.4
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/08_bordes.ts     # §4.2, §6
OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec lab/09_ciclo_colgado.ts  # §6
```

Todos crean su store y lo borran en el `finally`; los que arrancan la app usan **SQLite en
memoria** (`TEST_DB` por defecto) y destruyen todo en `teardown()`.

### `lab/variants.ts` — el generador de las cinco variantes

```ts
import { openFgaFactsModel, factsRelationsOf } from '../src/drivers/openfga_facts.js'

const ttu = (tupleset: string, relation: string) => ({
  tupleToUserset: { tupleset: { relation: tupleset }, computedUserset: { relation } },
})
const computed = (relation: string) => ({ computedUserset: { relation } })
const NO_DIRECT = { directly_related_user_types: [] as unknown[] }

export type VariantName = 'base' | 'nested' | 'flat' | 'inBase' | 'matRooted'
export const ROOTED = 'rooted'

const scopeType = (model: any) => model.type_definitions.find((t: any) => t.type === 'scope')

function addRooted(model: any, holderTypes: string[], recursive: boolean) {
  const s = scopeType(model)
  s.relations[ROOTED] = recursive
    ? { union: { child: [{ this: {} }, ttu('parent', ROOTED)] } }
    : { this: {} }
  s.metadata.relations[ROOTED] = {
    directly_related_user_types: holderTypes.map((type) => ({ type, wildcard: {} })),
  }
}

export function buildModel(
  variant: VariantName,
  holderTypeMap: Record<string, string>,
  permissions: readonly string[]
): any {
  const model = openFgaFactsModel(holderTypeMap, permissions)
  if (variant === 'base') return model
  addRooted(model, Object.values(holderTypeMap), variant !== 'matRooted')
  const s = scopeType(model)
  for (const p of permissions) {
    const r = factsRelationsOf(p)
    if (variant === 'nested' || variant === 'matRooted') {
      s.relations[r.can] = {
        intersection: {
          child: [
            { difference: { base: computed(r.base), subtract: computed(r.denied) } },
            computed(ROOTED),
          ],
        },
      }
    } else if (variant === 'flat') {
      const granted = `granted_${r.base}`
      s.relations[granted] = { difference: { base: computed(r.base), subtract: computed(r.denied) } }
      s.metadata.relations[granted] = NO_DIRECT
      s.relations[r.can] = { intersection: { child: [computed(granted), computed(ROOTED)] } }
    } else if (variant === 'inBase') {
      s.relations[r.base] = {
        union: {
          child: [
            { intersection: { child: [ttu('binding', r.base), computed(ROOTED)] } },
            ttu('parent', r.base),
          ],
        },
      }
    }
  }
  return model
}

/** El marcador de raíz: una tupla por holder type sobre `scope:app`. */
export function rootMarkerTuples(holderTypes: string[]) {
  return holderTypes.map((type) => ({ user: `${type}:*`, relation: ROOTED, object: 'scope:app' }))
}
```

### `lab/harness.ts` — driver `facts` con modelo variante + driver `database`

Es el harness del auditor (`fase-3b-auditor-r2.md`, §Reproducciones) con **tres** cambios:
`buildModel(options.variant, …)` en vez de `openFgaFactsModel(...)`; después de publicar el modelo,
`if (variant !== 'base') await raw.write({ writes: rootMarkerTuples(Object.values(HOLDERS)) })`; y
`attach()` escribe además el marcador por scope cuando la variante es `matRooted`. El resto
—catálogo, `bootApp`, `syncAuthzCatalog` con proyección, `memoryScopeTree`, `report()`— es idéntico.

### `lab/03_depth.ts` — la profundidad (lo que más importa reproducir)

```ts
import { OpenFgaClient, ConsistencyPreference } from '@openfga/sdk'
import { buildModel, rootMarkerTuples, type VariantName } from './variants.js'

const apiUrl = process.env.OPENFGA_TEST_URL ?? 'http://localhost:8101'
const HOLDERS = { users: 'user', admins: 'admin', bots: 'integration' }
const HOLDER_TYPES = Object.values(HOLDERS)
const ROLE = '0198f000-0000-7000-8000-000000000001'
const DEPTHS = 28
const REPS = 25                                   // ← el borde es probabilístico: 25 o nada
const variants: VariantName[] =
  (process.env.VARIANTS?.split(',') as VariantName[]) ?? ['base', 'nested', 'flat', 'inBase', 'matRooted']
const stores: string[] = []

try {
  for (const v of variants) {
    const store = await new OpenFgaClient({ apiUrl }).createStore({ name: `diseno-r1-depth-${v}-${Date.now()}` })
    stores.push(store.id!)
    const c0 = new OpenFgaClient({ apiUrl, storeId: store.id })
    const model = await c0.writeAuthorizationModel(buildModel(v, HOLDERS, ['docs:read']))
    const c = new OpenFgaClient({ apiUrl, storeId: store.id!, authorizationModelId: model.authorization_model_id })

    const tuples: any[] = [
      { user: 'user:*', relation: 'permits_docs_read', object: `role:${ROLE}` },
      { user: `role:${ROLE}`, relation: 'role', object: `role_binding:app|${ROLE}` },
      { user: `role_binding:app|${ROLE}`, relation: 'binding', object: 'scope:app' },
      { user: 'user:alice', relation: 'assignee', object: `role_binding:app|${ROLE}` },
    ]
    if (v !== 'base') tuples.push(...rootMarkerTuples(HOLDER_TYPES))
    for (let i = 1; i <= DEPTHS; i++) {
      tuples.push({ user: i === 1 ? 'scope:app' : `scope:n|s${i - 1}`, relation: 'parent', object: `scope:n|s${i}` })
      if (v === 'matRooted') for (const t of HOLDER_TYPES) tuples.push({ user: `${t}:*`, relation: 'rooted', object: `scope:n|s${i}` })
    }
    for (let i = 0; i < tuples.length; i += 100) await c.write({ writes: tuples.slice(i, i + 100) })

    const row: string[] = []
    for (let d = 15; d <= DEPTHS; d++) {
      let ok = 0
      for (let r = 0; r < REPS; r++) {
        try {
          const res = await c.check(
            { user: 'user:alice', relation: 'can_docs_read', object: `scope:n|s${d}` },
            { consistency: ConsistencyPreference.HigherConsistency }
          )
          if (res.allowed === true) ok++
        } catch { /* 400 «too many rewrite rules» = no resuelve */ }
      }
      row.push(`${d}:${ok}/${REPS}`)
    }
    console.log(`${v.padEnd(10)} ${row.join('  ')}`)
  }
} finally {
  for (const id of stores) { try { await new OpenFgaClient({ apiUrl, storeId: id }).deleteStore() } catch {} }
}
```

### El parche con el que se corrió la suite entera (§5.1)

Dos cambios mínimos sobre una **copia** del árbol, para medir qué se rompe de verdad:

```ts
// src/drivers/openfga_facts.ts — dentro de openFgaFactsModel, sustituyendo al `difference`
scopeRelations[r.can] = {
  intersection: {
    child: [
      { difference: { base: computed(r.base), subtract: computed(r.denied) } },
      computed(FACTS_ROOTED_RELATION),
    ],
  },
}
// …y junto a `ancestor`:
scopeRelations[FACTS_ROOTED_RELATION] = { union: { child: [{ this: {} }, ttu('parent', FACTS_ROOTED_RELATION)] } }
scopeMetadata[FACTS_ROOTED_RELATION] = { directly_related_user_types: wildcards }
// 'rooted' añadido a OWN_RELATIONS, y factsRootTuples(holderTypeMap) exportada.

// src/drivers/openfga_driver.ts — al principio de projectCatalog
private async ensureFactsRoot(): Promise<void> {
  if (this.hierarchy !== 'facts') return
  const wanted = factsRootTuples(this.holderTypes)
  const current = await this.readAllTuples(
    { object: factsScopeObject('app'), relation: FACTS_ROOTED_RELATION },
    { includeExpired: true }
  )
  const have = new Set(current.map((t) => t.user))
  const missing = wanted.filter((t) => !have.has(t.user))
  if (missing.length) await this.client.write({ writes: missing, deletes: [] })
}
```

Con eso: **663/667 en SQLite+OpenFGA y 835/841 en PG**, con los cuatro fallos de §5.1 y ninguno más.

---

## Higiene

- Stores en el `:8101` con el prefijo `diseno-r1` al terminar: **0** (58 stores en el servidor, los
  mismos que había al empezar, ninguno mío).
- Bases de datos: la suite corrió con **SQLite en memoria**; la tanda de PG usó un nombre base
  propio (`diseno_r1_pg_<sufijo>`) para **no tocar ninguna `authz_test*`**, y `pg_database` no
  conserva ni una `diseno_r1%` ni ninguna `authz_test%` al acabar.
- Ficheros del repo principal modificados: **ninguno** salvo este informe. El parche de §9 se aplicó
  sobre una copia en scratchpad, nunca sobre el worktree ni sobre `/home/jose/proyectos/Personal/adonis-authz`.
