# Respuesta a COGNITIV (3er informe, 10-09) — alpha.8 (enviar tras el publish)

> Asunto: Re: la raíz como mutex, `requeue` que no cierra solo, alarma ciega — los tres bloqueantes entran (uno con
> forma distinta), dos peticiones no, y una pregunta

Gracias por el informe y por verificar las tres alphas. Los tres bloqueantes son exactos; los pasamos por panel
completo contra el paquete real y esto es lo que sale:

**1 · La raíz `app` deja de ser clave de bloqueo — y era peor de lo que medisteis.** Nuestro analista lo midió sin
nada aparcado: dos altas de tenant concurrentes bajo `app` ya dejaban la segunda `deferred` (la receta inline no
servía para el registro de tenants ni en el caso feliz), y `requeue` de la aparcada se negaba con un conflicto FALSO
(la única clave común era la raíz), así que el runbook acababa en `--force`. En alpha.8 la raíz queda exenta en los
tres sitios donde contaba (las claves de contaminación, la sonda de `only` y la sonda anti-reversión del `requeue`),
por referencia y no por el nombre. Medido par a par por los tres panelistas: no se pierde ningún orden — la raíz solo
puede ser padre, no se mueve ni se purga; el par que sí importa (`detached(P)` seguido de `attached(Y, P)`) se
conserva por la clave del hijo. Además el tapón de una entrada aparcada pasa a ser por la clave del HIJO solamente:
un `moved(unit → orgA)` aparcado ya no congela todos los `moved` de orgA, solo los de esa unit (y sigue protegiendo
al `attached` de en medio, que es lo que el tapón existe para proteger).

**2 · `requeue --apply`** (`requeueScopeChanges(ids, { apply: true })`): reencola y relaya esos ids en la misma
llamada, bajo el mismo lease. Con cuatro condiciones que el auditor exigió y medimos: no toma un lease propio (si el
lease está tomado devuelve `busy` y NO reencola nada, todo o nada), pasa la barrera del freeze (durante un
`reconcile` congelado es 503 con cero filas), es excluyente con `--force` (los dos juntos ⇒ 500), y el `only` lo
construye el propio método. `--apply` es explícito, no default. Y un prerrequisito que descubrió el tester: hoy una
opción desconocida (`{ apply: true }` en alpha.7, o `{ waitForLeaseMs }`) se ignoraba en silencio; desde alpha.8 es
500 nombrándola.

**3 · Edad de la cola, sí; aparcar por tiempo, no.** El reporte trae `queue.oldestPendingAt` y `queue.pendingAgeMs`
(globales, también bajo `only`: no identifican a nadie), y `authz:scopes:relay --max-age=<ms>` sale con código ≠ 0
al superarlo — ahí va vuestra alarma. Aparcar por tiempo (`parkAfterMs`) NO: nuestro auditor lo midió — en una caída
larga se aparca la cola entera y, al volver el store, el censo de aparcadas (50.000) niega todas las pasadas: el árbol
deja de sincronizar hasta cirugía manual, y `requeue` no reencola en masa a propósito. Es exactamente lo que
«un 503 no consume intento» evita, por otro reloj. La ceguera era de la alarma, no del aparcado.

**Lo que no hacemos, con la medida:**
- **Supersede** (que un `moved` posterior reemplace al aparcado): reproducido como fail-open cruzado — libera la
  clave, la pasada aplica el `attached` de en medio, falla el `moved` nuevo (503) y el hijo queda colgado del padre
  VIEJO con `dead` vacío: cero alarma. Solo sería seguro manteniendo el tapón hasta que el reemplazo esté aplicado, que
  es lo que ya pasa hoy. Lo que sí entendemos que necesitáis es un `authz:reconcile` **acotado por subárbol/tenant**
  con `--dry-run`: va a 2.5 como requisito.
- `enqueue` sin `{ transaction }`: coincidimos en que es la fuga que la outbox existe para evitar (un rollback vuestro
  deja el cambio en la cola y el relay lo aplica). En alpha.8 es 500 antes del INSERT con `requireTransaction: true`
  (opt-in: como default rompería el contrato publicado que corren terceros); en 2.5 pasa a ser el default, y queda
  anunciado.

**Menores que entran en alpha.8**: `origin` (`parked`/`pending`/`failed`) en cada entrada del reporte; `deadCount`
siempre y, bajo `only`, `dead[]` sin `lastError` por defecto (corrección: el actor no viaja en el reporte; lo que
identifica a otro tenant es el `change`); transacción ya cerrada ⇒ `E_AUTHZ_CONFIG`; `enumerateRelationsMany` nativo
en `database` — y un bug nuestro que salió al mirarlo: el camino de respaldo perdía tuplas al reanudar con el cursor
(medido: 6 en el store, 5 vistas); ahora reanuda bien o falla ruidoso; `waitForLeaseMs` (default 0); el 422 de
profundidad sin nombrar el servidor en el mensaje público; y la doc de `maxDepth` con caso ejecutable — **con una
corrección a vuestro informe**: medido antes de escribirla, `maxDepth` cuenta `N`, no `N + 1` (con un árbol de tres
niveles, `maxDepth: 2` rechaza el tercero y `maxDepth: 3` lo admite; la condición es «saltos de la cadena del padre + 1 >
techo», igual que en `hierarchicalScopeResolver`). El caso ejecutable del README lo fija.

**Una pregunta**: ¿devolvéis o logueáis el reporte del relay inline en la petición del tenant? Bajo `only` ya no
llevará `lastError` ajeno por defecto, pero `queue.*` y `deadCount` son globales a propósito; si el reporte sale por
HTTP, quedaos con `entries` (lo vuestro) y nada más.

Publicada: `2.4.0-alpha.8` con dist-tag `alpha` (`npm i @jantstack/adonis-authz@alpha`), aditiva, sin migración ni breaking del
puerto para terceros (los métodos nuevos son opcionales). Lo que os toca al subir: `scopes.*` bajo la raíz ya no se bloquean
entre sí; una opción desconocida en `relayScopeChanges`/`requeueScopeChanges` ahora es 500 (antes se ignoraba); y leed la
regla medida de `maxDepth = N`. Verificada en SQLite, SQLite-fichero, PostgreSQL 18 y MySQL 8.4 contra OpenFGA, con auditoría
sobre el diff; los tres 🟡 que dejó el auditor se cerraron antes de publicar (tope de `waitForLeaseMs`, `--max-age` ruidoso
con edad desconocida, `details` del 422 no serializable). Con esto, vuestros tres bloqueantes del cutover están cerrados.
