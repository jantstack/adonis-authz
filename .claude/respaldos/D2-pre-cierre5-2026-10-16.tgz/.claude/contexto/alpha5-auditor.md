# `2.4.0-alpha.5` (lotes I + II, sin commitear) — AUDITOR sobre el diff

Base: `git diff HEAD` sobre `5547fa4`. Contraste: mis condiciones de
`panel-relay-auditor.md` §«Condición para que cada cambio sea seguro».
Medido con **PostgreSQL 18**, **MySQL 8.4** y el **OpenFGA `:8101`**.
Reproducciones: `.claude/reproducciones/relay-auditor-{1..9}.ts`
(1–5 re-ejecutadas; 6–9 nuevas, de este lote). Logs en `$S/re_*.log`.

## Veredicto

**NO APTA — por DOS 🟠 acotados y baratos de cerrar.** El lote hace lo que
pedí y en dos sitios más de lo que pedí; lo que falla son **dos huecos del
tapón por clave de R2a**, los dos medidos, los dos con la consecuencia exacta
que el propio lote existe para cerrar (fail-open persistente / aplicación
fuera de orden). Todo lo demás que ataqué resistió, incluidas las dos puertas
del `requeue`, la transición del `GET_LOCK` y las tres puertas del `maxDepth`.

---

## 1 · Mis condiciones, una por una

| # | Condición del panel | Estado | Evidencia |
|---|---|---|---|
| 1a | `enqueue` devuelve id | ✅ | `{ queued: [id] }` medido en repro 6 [B]/[C] |
| 1b/1c | `only` **no filtra `pending()`**; si acota trabajo, que sea un PREFIJO | ⚠️ **cumplida por otra vía, mejor**: filtra en el puerto (`whereIn`) **y** sonda la cola ENTERA (`earlierPending`) antes de aplicar. Verificado: el dependiente se aplaza aunque su bloqueante no esté en `only`, y también a DOS eslabones (`depends-on` vía sonda) | repro 6 [B]: `only:[#2]` ⇒ `deferred/parked:9`; `only:[#3]` ⇒ `deferred/depends-on:10`, cero llamadas al driver |
| 1d | `remaining`/`dead` nunca filtrados | ✅ | `manager.ts:1257` (`pending(1)` sin filtro), `dead` global; README lo dice |
| 2a | un 503 no consume intento | ✅ | `#isTransientRelayFailure` (`manager.ts:1323`) + `markFailed(..., {transient})`. Nota: mi repro 1 lanza un `Error` **sin status**, que por la regla decidida SÍ cuenta — por eso sigue viéndose 1..5 en su log; es correcto, no un fallo |
| 2b | las claves de `dead()` siembran `blocked` | ⚠️ **parcial** ⇒ 🟠 1 y 🟠 2 abajo | repro 7 [G], repro 9 [I] |
| 2c | `requeue` se niega si hay aplicada posterior con la misma clave | ✅ **las DOS puertas** (cola heredada de alpha.4 y `detached` posterior) | repro 6 [A]: 500 `E_AUTHZ_REQUEUE_REFUSED`, `conflicts=1`, fila intacta (`attempts=5`) |
| 2d | `--force` solo en ace, nada por HTTP; diff impreso | ✅ | repro 6 [A2]: 3 aplicadas ⇒ 3 líneas `revertiría`; `force` ⇒ `attempts=4` (`maxAttempts−1`) |
| 3 | lease: si no se toca, nada que exigir | ✅ | no se tocó; además ahora hay caso multiproceso (mutante 6 del lote II) y `GET_LOCK` con transición **verificada por mí** (repro 8) |
| 4 | `enumerateRelations`: límite declarado, prefijo PROHIBIDO, no disparable por petición de tenant | ✅ | tabla `### Limits` del README; mi medida se mantiene: 2 / 72 / 221 ms con 0 / 2 000 / 6 000 tuplas ajenas (repro 3 [F]) |
| 5 | `maxDepth` opt-in + tabla de límites | ✅ (PARCIAL declarado) | repro 6 [E] (422 antes de encolar, 0 filas de más) y repro 7 [H] (el hueco PARCIAL, medido) |

---

## 2 · Hallazgos que REABREN

### 🟠 1 — «un `detached` de esa clave se aplica igual» es falso a UN salto: la purga se aplaza para siempre

- **Escenario**: precondición — `#1 moved(unit → orgB)` **APARCADA** y `#2
  attached(child, unit)` pendiente (se aplaza por `parked:#1`, correcto).
  Acción — el tenant BORRA la unit y notifica `#3 detached(unit)`. Resultado —
  `#3` no se aplaza por la aparcada (eso funciona) sino por **`#2`, que a su
  vez está aplazado por la aparcada**: `defer()` contamina las claves para
  TODAS las operaciones (`manager.ts:1153`), así que el `detached` sale
  `deferred/depends-on:#2` **en todas las pasadas**. La purga no ocurre nunca:
  el scope que el tenant borró **conserva sus hechos y su arista `parent` en
  el store, y sigue concediendo**, hasta que un humano reencole.
- **Evidencia**: ✅ medido, pasada COMPLETA sin `only` (`relay-auditor-7.ts`):
  ```
  [G] SIN un attached pendiente entre medias: detached ⇒ applied/     ¿purgó?: purge unit:b2b7
  [G] CON un attached pendiente entre medias: detached ⇒ deferred/depends-on:4
  [G]    segunda pasada: deferred/depends-on:4
  [G]    ¿purgó?: NO — el scope borrado conserva sus hechos en el store
  ```
- **Es una REGRESIÓN del lote**: en alpha.4 (sin siembra) `#2` se aplicaba
  —fuera de orden, que es el 🔴 que R2a cierra— y `#3` purgaba a continuación.
  Ahora el orden se respeta y **la purga se pierde**: se cambió un fail-open
  por otro, y el README promete lo contrario con estas palabras: *«A `detached`
  of that key is applied anyway — a purge never waits (invariant 11)»*.
- **Steelman del defensor**: «hay una aparcada: el comando sale ≠ 0 y el
  operador tiene que mirar; el precio del tapón está declarado». → **No me
  convence del todo**: el precio declarado es «congela los grants y los moves
  de esa clave», y aquí congela **la retirada**, que es justo lo que el
  invariante 11 manda no bloquear nunca; y el operador que lee el README cree
  que la purga ya pasó.
- **Mitigación mínima**: que la exención del `detached` sea transitiva — un
  `deferred` cuya causa raíz es `parked:` no debe contaminar la clave para
  `detached` (o marcar el aplazamiento con su causa y consultarla).

### 🟠 2 — El censo de claves aparcadas está ACOTADO: con `limit ≤ batchSize` el tapón es ciego

- **Escenario**: precondición — más de `batchSize` (100 por defecto) entradas
  aparcadas; la 101ª es `moved(unit → orgNew)`. Acción — un relay con `limit`
  pequeño: la receta inline con recibo (`{ only, limit: 1 }`) o el propio
  comando publicado (`authz:scopes:relay --limit 50`). Resultado — el censo se
  queda en el `dead` ya leído (`manager.ts:1340`:
  `dead.length < batchSize || limit <= batchSize ? dead : dead(limit)`), la
  clave de la 101ª no tapona, **y la sonda de `only` tampoco la ve** porque
  `earlierPending` excluye lo aparcado (`scope_outbox.ts:363`,
  `attempts < maxAttempts`): los DOS guardianes fallan a la vez y el
  `attached` se aplica colgando del padre VIEJO.
- **Evidencia**: ✅ medido (`relay-auditor-9.ts`):
  ```
  [I] 101 aparcadas · relay({ only, limit: 1 }) ⇒ applied/
  [I] llamadas al driver: attached unit:cb7a→unit:8e15
  ⇒ el attached se aplicó: cuelga del padre VIEJO en el store
  ```
- **Steelman**: «una cola con más de 100 aparcadas ya es un incidente por sí
  sola». → Cierto y está en el docblock, pero (a) el resultado no es
  degradación, es **la escalada del 🔴 1** aplicada en silencio, y (b) el
  `--limit` que lo dispara es una bandera publicada del comando, no un abuso.
- **Mitigación mínima**: el censo de `dead()` no debe depender de `limit` —
  léelo hasta agotarlo con su propia cota y, si la cota se alcanza, para con
  500 en vez de aplicar con un tapón incompleto.

---

## 3 · Hallazgos que NO reabren

### 🟡 3 — La garantía del orden descansa en un deber del PUERTO que no está escrito

`relay-auditor-2.ts` (sin tocar) **sigue reproduciendo la escalada completa
contra el `:8101`** con alpha.5:

```
relay({ only: [2] }) ⇒ applied=attached ... remaining=false
authorize(A@orgA, docs:read, child) = true   ← A ya NO es dueño de nada de esto
```

porque esa repro no usa la API `only`: filtra dentro de un `ScopeOutbox` de
terceros. Con `only === undefined` no hay sonda (`manager.ts:1212`) ni
`#assertOnlyHonoured`. Es decir: **la sonda protege al que usa `only`; al que
esconde filas en su `pending()` no lo protege nadie**, y ningún caso de
`runScopeOutboxContract` lo caza (el harness no tiene contexto de tenant).
Precondición: un consumidor que escriba su propia outbox con filtro — que es
lo que COGNITIV pidió y se le negó *para `only`*, no para su puerto.
**Mitigación mínima**: una frase en el docblock del puerto y en el README
(«`pending()` no puede esconder una entrada sin aplicar que el relay no haya
filtrado: el orden se apoya en eso») y, si se quiere con dientes, un caso del
contrato que encole desde dos «tenants» y exija los dos en `pending()`.

### 🟡 4 — La sonda anti-reversión solo ve la OUTBOX; `authz:reconcile` no está en ella

`laterApplied` compara contra filas `applied_at` de la cola. `authz:reconcile`
no escribe en la outbox, así que **reencolar después de un reconcile puede
revertir el árbol reconciliado y la sonda no tiene con qué verlo** — y el
remedio que el propio error recomienda es precisamente `authz:reconcile`. Se
suma que `requeueScopeChanges` **no pasa la barrera del freeze** (decisión
declarada, informe II §7.5): se puede reencolar durante la ventana certificada.
Medido (repro 6 [D]): `requeue` durante el freeze **ENTRA**, el relay inline
del tenant es **503 `E_AUTHZ_FROZEN` con cero escrituras al store**, y al
levantar el freeze la entrada aterriza. O sea: **no hay escritura dentro de la
ventana** (la pregunta 3 del coordinador es «no»), pero sí queda armada una
escritura vieja que caerá sobre lo recién certificado.
**Mitigación mínima**: una línea en el docblock/README —«reencolar después de
un `reconcile` no está cubierto por la sonda; reconcilia DESPUÉS, no antes»— o
la barrera del freeze en `requeueScopeChanges`.

### 🟡 5 — Un 503 eterno ya no converge (el precio de mi propia condición 2a)

Con `transient` una entrada que falla siempre con 503 **nunca se aparca**, se
reintenta en cada pasada y **contamina su clave en todas**: aplazamiento
indefinido de esa clave (ruidoso: sale en `failures` y el comando sale ≠ 0).
El caso realista no es «el store caído» sino un `resolveChain` del consumidor
que **lanza** (503 `E_AUTHZ_RESOLVER_FAILED`) para un scope concreto —una fila
borrada que su query no tolera— mientras el resto de la cola va bien. Es el
trade-off que yo mismo pedí; queda dicho, no reabierto. ❓ no lo he medido
end-to-end (razonamiento sobre `#isTransientRelayFailure` + la contaminación de
`manager.ts:1153`).

### ⚪ 6 — El diff de `--force` está acotado a 100 y no lo dice

`laterApplied(item.id, scopes, DEFAULT_RELAY_BATCH)` (`manager.ts:1465`): con
más de 100 aplicadas posteriores sobre la clave, el diff que el operador lee
antes de forzar está truncado **sin marca**. Medido completo con 3 (repro 6
[A2]: `applied=3`, 3 líneas). Mitigación: un «+N más» o subir la cota.

### ⚪ 7 — `maxDepth` es PARCIAL, y se mide

Con `maxDepth: 4`, mover una rama de altura 2 bajo el nivel 3 **entra** y la
hoja acaba a **5 saltos** (repro 7 [H]). Está declarado con esas palabras en
el README («partial: it does not see the height of a moved subtree») y es la
decisión del dueño (no meter `descendantsOf` en el camino de escritura). Las
otras dos puertas: por la outbox **no** se cuela (el gate está antes de
encolar: repro 6 [E], 422 y 3 filas, ni una de más) y por `manager.driver()`
sí, que es la salida documentada de todas las barreras.

### ⚪ 8 — `only` con ids AJENOS: aplica lo del otro, y lo enseña

Medido (repro 6 [C]): `only:[#1 ajeno]` ⇒ `applied`, y el reporte devuelve el
`change` completo (uuids de scope) del otro tenant. **No es escalada**: la
sonda mantiene el orden (`only:[#2 ajeno]` ⇒ `deferred/depends-on:13`) y el
relay aplica lo que la plataforma ya aceptó. Queda el canal de enumeración,
que el README ataja con «Do not return the relay report over HTTP» y con
«`only` nunca del cuerpo de la petición».

---

## 4 · Respuestas directas a las siete preguntas

1. **`only` + `earlierPending`.** ¿Ve las APARCADAS? **No** (`attempts < maxAttempts`,
   `scope_outbox.ts:363`); las cubre el censo de `parkedKeys` — salvo cuando el
   censo está truncado (🟠 2). ¿Ve las `deferred` de la misma pasada? **Sí**, por
   dos caminos: el `blocked` en la pasada y la sonda entre pasadas (medido:
   `depends-on:10` sobre una entrada que quedó aplazada). ¿Un id ajeno sigue
   aplicando lo de otro? **Sí, en orden**; daño = enumeración + elegir el momento
   (⚪ 8).
2. **Tapón solo para `attached`/`moved`.** El `detached` directo pasa (correcto);
   **a un salto se queda bloqueado para siempre** y la purga no ocurre (🟠 1).
   No he encontrado inconsistencia en el `detached` que SÍ pasa: `purgeScope`
   borra por identidad del scope, no por padre, así que el padre viejo no
   contamina la purga.
3. **`requeue` sin barrera del freeze.** `relayScopeChanges` está tras
   `#assertNotFrozen` **dos veces** (`manager.ts:1054` y por lote en `:1172`), y
   medido da 503 con cero escrituras: **un tenant no puede escribir en el store
   durante la ventana**. Lo que queda es 🟡 4 (armar una reversión que caerá
   después del reconcile).
4. **`--force`.** El diff imprime **todas** las aplicadas posteriores que el
   puerto devuelva (3 de 3 medidas), no solo la primera; reaplica y deja el árbol
   revertido con un solo padre, y el README lo dice con esa frase exacta
   («the store reverted, with a single edge»). Único pero: el corte a 100 sin
   marca (⚪ 6).
5. **`GET_LOCK` en transición.** Verificado **por mí, contra MySQL 8.4**
   (`relay-auditor-8.ts`): un alpha.4 sosteniendo el nombre VIEJO ⇒ `acquire()`
   de alpha.5 es `null` **y no deja el nuevo tomado a medias**; alpha.5
   sosteniendo los dos ⇒ el `get_lock` viejo de un alpha.4 no entra; dos alpha.5
   ⇒ el segundo es `null`. Se excluyen de verdad.
6. **`maxDepth`.** Por la outbox no se salta (gate antes de encolar, medido);
   por `manager.driver()` sí (doctrina); el hueco real es el PARCIAL del subárbol
   movido, declarado y medido (⚪ 7). `reconcile` no lo salta: lo reporta como
   deriva (`drift.tooDeep`, `clean = false`).
7. **`runScopeOutboxContract`.** Un tercero **puede** pasar con `enqueue ⇒ void` y
   sin `earlierPending`, y eso es **seguro**: sin recibo `queued: []` ⇒ `only: []`
   ⇒ 500 `E_AUTHZ_CONFIG`, y si devuelve id pero ignora `{ ids }` ⇒ 500
   `E_AUTHZ_CONFIG` antes de aplicar nada (los dos medidos, repro 6 [F]); sin
   `earlierPending` el manager pagina y el veredicto no cambia. Lo que el
   contrato **no** caza es un `pending()` que esconde filas por su cuenta (🟡 3).

---

## 5 · Lo que intenté y NO se rompió

- Reencolar sobre las dos puertas del informe II (cola heredada de alpha.4 y
  `detached` aplicado después): **500 y cero filas tocadas** en las dos.
- `relay-auditor-5.ts` tal cual: ya no revierte (el tapón ordena los dos `moved`
  y converge en orgC) — coincide con lo que reporta el lote II.
- `relay-auditor-1.ts`: el `attached` dependiente **ya no se aplica** tras el
  aparcado (`applied: —`, cero llamadas al driver): el 🟠 4 de mi panel está
  cerrado. (El contador 1..5 de intentos sigue subiendo porque la repro lanza un
  `Error` sin status: por la regla decidida eso cuenta, y es lo correcto.)
- Lease: 10 relays concurrentes ⇒ `busy=9`, un intento consumido (sin cambios).
- `only: []`, ids desconocidos (`missing`), outbox que ignora el filtro, outbox
  sin recibo: los cuatro paran con 500 o lo dicen, ninguno drena la cola.
- Profundidad contra el `:8101`: rompe en **24** (23 responde `true`), 503
  fail-closed, y **sin amplificación cruzada** (vecino ×1,12 con la misma
  concurrencia). `enumerateRelations` sigue siendo O(store): 2 / 72 / 221 ms.

## 6 · Preguntas abiertas (solo las que mueven el veredicto)

1. 🟠 1: ¿la exención del `detached` se hace transitiva (mi mitigación) o se
   corrige el README y se declara que una aparcada **también** congela la
   retirada de su clave? Las dos son defendibles; lo que no puede quedarse es la
   frase actual con este comportamiento.
2. 🟠 2: ¿el censo de aparcadas pasa a tener cota propia (y 500 al alcanzarla) o
   se prohíbe `limit ≤ batchSize` cuando `dead` viene lleno?
