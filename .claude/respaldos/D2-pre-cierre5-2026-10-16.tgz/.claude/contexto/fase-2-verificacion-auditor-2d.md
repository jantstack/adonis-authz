# Fase 2 · Lote 2D (HEAD `4346bcc`) — verificación del auditor de seguridad

Reproducciones en `scratchpad/v4/` (SQLite en memoria, **SQLite en FICHERO con dos procesos `node` reales**,
OpenFGA `:8101`). Árbol del repo intacto (`git status` limpio; nada escrito fuera de `.claude/contexto/`).
Suite de referencia re-ejecutada: `OPENFGA_TEST_URL=http://localhost:8101 npm test` ⇒ **332 passed, exit 0**.

## Veredicto en una línea

**APTA CON CORRECCIONES** — el 🔴 y los dos 🟠 anteriores están cerrados y verificados (el 🔴 con dos procesos
`node` reales sobre una BD compartida, en ambos drivers); lo nuevo introduce dos 🟠 propios: `within` no protege
el ORIGEN en `scopes.moved/attached` (robo de subárbol entre tenants) y un `bumpAuthzCatalogVersion()` que llega
antes que su escritura envenena el memo de los demás procesos **para siempre**.

## Misión 1 — prueba de cierre (hallazgo × antes × ahora)

| # | Sev. previa | Hallazgo | Antes (`bf3fac9`) | Ahora (`4346bcc`) | |
|---|---|---|---|---|---|
| 1 | 🔴 | memo del catálogo ⇒ revocación fail-open entre procesos | `openfga` A y B `true` tras retirar el vínculo; `database` `false` (divergencia) | **dos procesos `node` REALES** sobre `shared.sqlite` + FGA `:8101`: tras el `DELETE` + `bumpAuthzCatalogVersion()` del proceso B, el proceso A responde `authorize=false`, `authorizeMany=[false,false]`, `effectivePermissions=["docs:read"]` en **database y openfga**; `docs:read` sigue `true` (no es un fail-closed global) | ✅ |
| 2 | 🟠 | `requireWithin` solo cubría `grant`/`deny` | `revoke`/`removeDeny`/`scopes.detached` con `within` ajeno ⇒ ACEPTADO | las **seis** con `within: orgA` sobre algo de B ⇒ 422 `E_AUTHZ_NOT_WITHIN` (incluida `scopes.moved`); las seis sin `within` con `requireWithin: true` ⇒ 422 `E_AUTHZ_WITHIN_REQUIRED` y nada escrito; `within: APP_SCOPE` con `'non-root'` ⇒ 422 `E_AUTHZ_WITHIN_ROOT_FORBIDDEN` en las siete llamadas; `within` mentiroso también se mira con `requireWithin: false` | ✅ |
| 3 | 🟠 | `authorizedScopes` lista lo que `authorize` niega | `some{[team:A1a]}` bajo una unit denegada; unit de otro tenant listada | deny **intermedio** (grant en orgA, deny en unitA1): `authorizedScopes ≡ { s ǀ authorize(s) }` en `unit`, `team` y `organization`; deny en el propio concedente ⇒ `none`; `descendantsOf` que devuelve una unit de **otro tenant**, un **fantasma** o un `orgB` de otro tipo ⇒ 503 `E_AUTHZ_RESOLVER_FAILED`; `descendantsOf → null` en el concedente ⇒ `none` (conservador) | ✅ |
| 4 | 🟡 | `effectivePermissions` contradecía a `authorize` con memo frío | reproducido | cae con F1 (verificado en los dos procesos reales, ambos drivers) | ✅ |
| 5 | 🟡 | vista de `forRequest()` reutilizada sirve la cadena vieja | `true` con la unit ya movida a otro tenant | `E_AUTHZ_VIEW_EXPIRED` en las 7 lecturas (`authorize`, `hasRole`, `listRoles`, `listScopes`, `listDenies`, `effectivePermissions`, `authorizeMany`, `authorizedScopes`); escrituras e `isWithin` siguen (documentado); `maxAgeMs` inválido ⇒ 500 `E_AUTHZ_CONFIG`; `0` = sin límite a sabiendas; **renovar con `view.forRequest()` da un memo NUEVO** (no hereda el viejo) | ✅ |
| 6 | 🟡 | `authorizedScopes` pasea todo el árbol antes de acotar | — | corta antes de bajar (`maxScopes` del config = 1 con llamada `100` ⇒ 422) pero **sigue paseando todos los candidatos de otros tipos**: 303 `resolveAncestors` para responder 1 scope con `maxScopes: 2` (ver 🟡‑3) | ⚠️ |
| 7 | 🟡 | `excludedSubtrees` se leía como scopes, no subárboles | — | `ExcludedSubtree{ scope, includesDescendants: true }`; `all ∖ expandExcludedSubtrees ≡ { s ǀ authorize(s) }` verificado nodo a nodo; un subárbol excluido no enumerable (`descendantsOf → null`) ⇒ 503 | ✅ |
| 8 | 🟡 | `manager.driver()` esquiva actor/within/onWrite | — | documentado (jsdoc + README §Actor) y **ningún camino del propio paquete lo usa**: `grep '\.driver()'` en `src/`, `commands/`, `providers/`, `services/`, `stubs/`, `index.ts` solo devuelve dos menciones en comentarios; el middleware `appAccess` pasa por `authorization.authorize` (manager) | ✅ |
| 9 | 🟡 | `within: APP_SCOPE` satisface siempre | ACEPTADO | 422 con `'non-root'`… pero `within` = el propio scope o su padre sigue satisfaciendo siempre (ver ⚪‑1) | ⚠️ |
| 10 | ⚪ | `hierarchicalScopeResolver` (clave sin separador, `{app,uuid}`) | 422 falso de ciclo | `org`+`a-1` vs `o`+`rga-1` ⇒ cadena correcta; `{app,'X'}` ⇒ 503; ciclo real ⇒ 422; profundidad ⇒ 500 `E_AUTHZ_SCOPE_TOO_DEEP` (nunca cadena corta) | ✅ |
| 11 | ⚪ | `sqlDescendantsOf` sin validar `scopeType`; cota por llamada | construía | `'Node'`, `'app'`, `'a b'`, 30 chars ⇒ 500 `E_AUTHZ_CONFIG` al construir; `table` con espacios/`;`/comillas ⇒ 500; `maxScopes` por llamada solo baja | ✅ |

Extra de cierre verificado: `authorizeMany` con posiciones repetidas y un fantasma (`[orgA, orgB, orgA, unitA1, ghost, unitA1, orgA]`) ≡ N `authorize` en **ambos** drivers, con y sin deny intermedio (G2 no desalinea posiciones); un driver de terceros que devuelve `[true]`, `"nope"`, `null`, `[true,'yes']` o 3 posiciones para 2 scopes ⇒ 500 `E_AUTHZ_INTERNAL` (F5).

## Misión 2 — hallazgos nuevos (ordenados por severidad)

### 🟠 1 · `within` no mira el ORIGEN: `scopes.moved`/`attached` se lleva un subárbol de otro tenant

- **Escenario**: `requireWithin: 'non-root'`; Mallory es `admin` **solo** de `organization:A`; `unit:B1` cuelga de `organization:B`. Su endpoint "mover scope" llama `authorization.scopes.moved(unitB1, orgA, { within: orgA })` con el `within` de su sesión → **ACEPTADO** (el paquete solo contrasta el DESTINO). Tras el movimiento, `authorize(mallory, 'docs:read', unitB1)` pasa de `false` a **`true`**.
- **Evidencia**: ✅ `scratchpad/v4/a5_move_steal.mjs` (driver `database`): `antes: false` → `moved ⇒ ACEPTADO` → `después: true`. En código: `src/manager.ts:271-276` — `moved` resuelve `#assertEdge(child, newParent)` y contrasta `#assertWithinChain(newParent, chain(newParent))`; la cadena ACTUAL del hijo no se consulta en ningún punto. `attached` (`:265-270`) es idéntico y el `ContractScopeTree` define `attach` sobre un hijo existente como un `move`. `detached`, en cambio, sí contrasta el hijo (`:292`) — la asimetría es el hueco.
- **Steelman**: *"El invariante 15 dice literalmente «`scopes.attached`/`moved` (contra el padre)», el consumidor ya movió el nodo en SU árbol antes de notificar y hoy ningún driver implementa `onScopeMoved`, así que el paquete no mueve nada."* → **No me convence**: F2 vende `within` como *la* barrera de contención de las seis escrituras y el README dice que es lo que impide "purgar la unit de B"; permitir *anexionarse* la unit de B es peor que purgarla (se hereda todo el árbol robado). Además en **3b** (`facts`) `onScopeMoved` escribirá la arista `parent` en FGA y entonces esto lo ejecuta el paquete: hoy 🟠, ahí 🔴.
- **Mitigación mínima**: en `moved` (y en `attached` si el hijo ya existe) exigir además que `within ∈ chain(child)` con el árbol fresco *antes* de la notificación.

### 🟠 2 · Un `bumpAuthzCatalogVersion()` que llega ANTES que su escritura envenena el memo de los demás procesos de forma permanente

- **Escenario**: proceso B (seeder/migración de datos) hace, dentro de una transacción Lucid, `await trx.from('authz_role_permissions').delete(...)` y `await bumpAuthzCatalogVersion()` **sin pasarle `client: trx`** (la firma lo permite: `client` es opcional y por defecto es el `db` global) ⇒ el `UPDATE` de la versión **se confirma antes** que el `DELETE`. Entre ambos instantes, el proceso A pregunta una vez: revalida, ve la versión nueva, **recarga los datos VIEJOS** y etiqueta la foto con la versión nueva. A partir de ahí las versiones coinciden para siempre y A **nunca vuelve a recargar**: el permiso retirado sigue concediendo indefinidamente.
- **Evidencia**: ✅ dos procesos `node` REALES sobre `shared.sqlite` + FGA `:8101` (`scratchpad/v4/c5_reader.mjs` / `c5_writer.mjs`, driver `openfga`, `revalidate: 'always'` por defecto):
  `[A] fase 0: true` → `[B] versión subida a 2 (la escritura aún no ha ocurrido)` → `[A] fase 1: true` → `[B] vínculo docs:write retirado` → `[A] fase 2 #0/#1/#2: true, true, true`, mientras un proceso con memo frío responde `false`. También en un proceso (`c_catalog_fga.mjs` C5).
  Código: `src/catalog_cache.ts:289-312` lee la versión **antes** de las tablas, lo que protege el caso "datos nuevos con etiqueta vieja" pero no el inverso, que es el que abre el agujero.
- **Steelman**: *"`syncAuthzCatalog` lo hace bien (bump como última sentencia de SU transacción, test incluido); quien escribe `authz_*` a mano y ordena mal el bump tiene un bug suyo."* → **Me convence a medias**: el jsdoc solo dice «llama a `bumpAuthzCatalogVersion()`», sin exigir *cuándo* ni *con qué cliente*, y el fallo es silencioso, permanente y fail-open en TODOS los procesos salvo el que reinicie. Es un hueco del propio invariante 14: la versión coincide con la de la base y aun así la decisión se toma con datos que la base ya no tiene.
- **Mitigación mínima**: documentar y forzar el orden (bump como **última** sentencia de la MISMA transacción; hacer `client` obligatorio o avisar si no llega); estructuralmente, derivar la versión del contenido (`count(*)` + `max(updated_at)` de las tres tablas) elimina la obligación del consumidor —hoy olvidarse del bump también es fail-open permanente, verificado en `A_nobump.log`: `authorize=true`, `authorizeMany=[true,true]` tras la retirada ajena—.

### 🟡 3 · Reloj hacia atrás: la ventana de `{ everyMs }` no se cierra y una vista caducada resucita

- **Escenario A**: `catalogRevalidate: { everyMs: 400 }`; otro proceso retira el vínculo y sube la versión; el reloj del host retrocede 1 h (paso de NTP, restauración de snapshot, sincronización del contenedor). Tras **dos** ventanas completas el proceso sigue respondiendo `true`; al restaurar el reloj, `false`.
- **Escenario B**: `forRequest({ maxAgeMs: 20 })`; la vista caduca; el reloj retrocede 1 h ⇒ la vista **vuelve a leer** y sirve la cadena memoizada de un scope que ya cambió de tenant (`true` donde el manager fresco dice `false`).
- **Evidencia**: ✅ `c_catalog_fga.mjs` C2 (`tras 2 ventanas con el reloj atrasado: true/true; con el reloj bien: false`) y `f9_view.mjs` (`con el reloj atrasado, la vista de 20 ms responde true`). Código: `src/catalog_cache.ts:261-264` (`Date.now() - #checkedAt >= everyMs`) y `src/manager.ts:197,241` (`Date.now() + maxAgeMs`, `Date.now() >= #readsUntil`).
- **Steelman**: *"`{ everyMs }` ya es una ventana fail-open aceptada a sabiendas y las vistas viven segundos; un salto de reloj es un fallo del host."* → **Me convence sólo para B** (una vista vive un request). Para A no: lo que el consumidor acepta es una ventana **acotada**, y con el reloj atrasado deja de estarlo sin ninguna señal.
- **Mitigación mínima**: medir ambas vidas con un reloj monótono (`performance.now()`/`process.hrtime`), no con `Date.now()`.

### 🟡 4 · `authorizedScopes` cuesta O(descendientes), no O(respuesta): amplificación de un request a miles de consultas del consumidor

- **Escenario**: `organization:X` con 300 `team` y 1 `unit`; `maxScopes: 2`; una petición de `authorizedScopes(subject, 'docs:read', 'unit')` ⇒ **303 llamadas a `resolveAncestors`** para devolver 1 scope. La cota `maxScopes` solo cuenta candidatos **del tipo pedido**, así que no corta; el único techo real es `maxDescendants` (default **10 000**) × nº de scopes concedentes directos. Con el `resolveAncestors` típico (una consulta SQL o `hierarchicalScopeResolver`, que sube nodo a nodo) eso es un request HTTP → decenas de miles de consultas.
- **Evidencia**: ✅ `f3_scopes.mjs`, bloque `[NUEVO/DoS]`: `respuesta some (1 scopes) con 303 llamadas a resolveAncestors para 301 descendientes`.
- **Steelman**: *"F3 pactó ≤ 1 `resolveAncestors` por candidato y el memo por request evita repetirlos; la cota es sobre la RESPUESTA por decisión explícita de F8."* → **Me convence como diseño, no como defensa**: el coste lo fija el atacante (quien controle cuántos hijos cuelgan del subárbol donde tiene permiso) y no hay ninguna cota sobre el trabajo.
- **Mitigación mínima**: contar también los candidatos **paseados** (no solo los del tipo pedido) contra una cota, o filtrar por tipo dentro de `descendantsOf` (el puerto ya recibe `maxNodes`).

### 🟡 5 · MySQL con collation `*_ci`: dos uuids que solo difieren en mayúsculas son el MISMO hecho en `database` y hechos DISTINTOS en `openfga`

- **Escenario**: el consumidor identifica scopes/holders con ids sensibles a mayúsculas (nanoid, base62, ULID) — el contrato solo exige `uuid` ≤ 36 y no lo normaliza (`src/identity.ts`: los TIPOS se fuerzan a minúsculas por esta misma razón; el uuid "es del consumidor y se respeta tal cual"). En MySQL 8.4 con la collation por defecto, `WHERE scope_uuid = 'Ab3XY'` casa con la fila `aB3xY`: un grant sobre un scope autoriza en otro, y `holder_uuid` cruza dos holders. En `openfga` (comparación byte a byte) no.
- **Evidencia**: ✅ para la collation (`docker exec mysql84 … select count(*) … where uuid='Ab3XY'` ⇒ **1**, `collation_server = utf8mb4_0900_ai_ci`). ❓ **no verificado extremo a extremo por el driver**: el harness del paquete es SQLite y no cablé Lucid a MySQL; el defecto es de la Fase 1 (identidad), no del lote 2D.
- **Steelman**: *"El campo se llama `uuid`, y un UUID canónico es hexadecimal: no hay colisión posible."* → **No me convence del todo**: nada en la gramática (`^[A-Za-z0-9_.-]+$`) obliga a un UUID canónico y el propio código ya reconoce el problema de collation para los tipos.
- **Mitigación mínima**: decidir explícitamente (documentar "uuid case-sensitive: usa una columna/collation binaria" o normalizar) y fijarlo con un caso del contrato.

### ⚪ 6 · `within` = el propio scope (o su padre) satisface siempre: `requireWithin` es "declara dónde escribes", no una autorización

- **Escenario**: `requireWithin: 'non-root'`; el controlador toma el scope y el `within` de la MISMA entrada del request ⇒ `grant(victim, 'admin', unitB1, { within: unitB1 })` y `{ within: orgB }` son **ACEPTADOS**. `'non-root'` cierra el comodín `app`, pero `within: <el padre del objetivo>` es un comodín igual de bueno para cualquier tenant.
- **Evidencia**: ✅ `f2_within.mjs`, bloque `[NUEVO A4]`. Es inherente: la cadena incluye al propio scope (`resolveChain` ⇒ `[scope, ...ancestors]`).
- **Steelman**: *"Obvio: `within` tiene que venir de la sesión, como el `currentOrg` del README."* → Me convence como diseño; lo dejo en ⚪ porque la precondición ("`within` NUNCA puede venir de la misma entrada que el scope") es la que sostiene toda la barrera y no está escrita en ningún sitio.

### ⚪ 7 · Invariante 14 dice "sin fila de versión legible ⇒ 503"; el código devuelve versión `0`

- `readAuthzCatalogVersion` (`src/catalog_cache.ts:118-121`) convierte "sin fila" y "columna nula/no numérica" en `0`. Borrar la fila con el memo caliente **no** sirve el memo viejo (recarga; verificado: `false`), y sin la TABLA sí es 503 `E_AUTHZ_BACKEND_UNAVAILABLE` (verificado). No encontré camino fail-open, pero el invariante y el código no dicen lo mismo: o se corrige el texto o se lanza cuando la fila falta.

### ⚪ 8 · `all` incluye scopes que el árbol NO conoce, donde `authorize` dice `false`

- Con grant en la raíz: `kind: 'all'`, `excludedSubtrees: []`, y una `unit` huérfana (fila del consumidor fuera de `resolveAncestors`) queda **dentro** del `all` aunque `authorize` la deniegue (✅ `f10_orphan.mjs`). Solo alcanzable con un grant en la raíz y solo afecta a scopes huérfanos, pero rompe la promesa "≡ `{ s ǀ authorize(s) }`" en la rama `all`.

### ⚪ 9 · Un `move` legítimo durante la vida de una vista convierte `authorizedScopes` en 503

- Dentro de una vista: `authorize(unitX)` memoiza su cadena; el consumidor mueve `unitX` a otra org; `authorizedScopes` usa `descendantsOf` **fresco** + ancestros **memoizados** ⇒ los dos resolutores discrepan ⇒ 503 `E_AUTHZ_RESOLVER_FAILED` (✅ `e_mix.mjs`). Es fail-closed y se cura en el siguiente request, pero el 503 acusa al consumidor de tener dos árboles incoherentes cuando lo que hay es un memo de 30 s.

### ⚪ 10 · `expandExcludedSubtrees` es la única lectura de la vista que no respeta `maxAgeMs`

- En una vista caducada, las 7 lecturas dan `E_AUTHZ_VIEW_EXPIRED` y `expandExcludedSubtrees` **responde** (✅ `f9_view.mjs`). Hoy es inocuo (no usa el memo de ancestros, resuelve con `descendantsOf` fresco), pero es una excepción no escrita a "todas las lecturas pasan por `#reader()`".

### ⚪ 11 · Un `catalog` compartido ignora en silencio el `catalogRevalidate` del driver

- `new DatabaseAuthorizationDriver({ catalog: sharedEveryMs, catalogRevalidate: 'always' })` usa la ventana del compartido: el `'always'` del config no se aplica ni avisa (✅ `g_race.mjs` G‑d). Está documentado ("solo aplica al memo que construye este driver"), pero un `catalogRevalidate` explícito junto a un `catalog` debería ser 500 `E_AUTHZ_CONFIG`.

## Lo que intenté y NO se rompió

- **Versión compartida (F1)**: 200 `view()` en paralelo con un bump en medio ⇒ ninguna sirve la versión vieja; un sync que FALLA (`E_AUTHZ_UNKNOWN_PERMISSION`) no sube la fila; un sync que confirma la sube y se ve con el memo caliente; la versión se lee SIEMPRE antes que las tablas (una foto nunca queda etiquetada más nueva que sus datos salvo por el 🟠‑2); un `#load` que falla no deja nada cacheado ni servido; la tabla ausente ⇒ 503.
- **F2**: las seis escrituras rechazan `within` ajeno, `within` fantasma (`E_AUTHZ_NOT_WITHIN`), escritura sobre scope fantasma (`E_AUTHZ_UNKNOWN_SCOPE`) y `scopes.detached` de un hijo ya fuera del árbol con `within` (`E_AUTHZ_UNKNOWN_SCOPE`); nada se escribe cuando el 422 salta; `within` se contrasta con el resolutor FRESCO también dentro de una vista.
- **F3/F8/F10**: coherencia `authorizedScopes ≡ authorize` con deny intermedio a tres niveles y con deny en el propio concedente; cruce de tenant, fantasma y tipo ajeno ⇒ 503; `null` conservador en el concedente y 503 en el excluido; `all ∖ expandExcludedSubtrees` nodo a nodo; `maxScopes` por llamada no sube la del config; un deny sobre un scope ya borrado del árbol no aparece en `excludedSubtrees` (coherente con `authorize`).
- **F9**: las 7 lecturas caducan; escrituras e `isWithin` no; `maxAgeMs` inválido ⇒ 500; **una vista no se puede "renovar" heredando el memo viejo** (`view.forRequest()` construye un memo nuevo).
- **F5/G2**: `authorizeMany` ≡ N `authorize` con duplicados, fantasmas y deny intermedio en ambos drivers; respuestas malformadas del driver ⇒ 500 nombrando al culpable.
- **F6/G1**: colisión de clave, `{app,uuid}`, ciclo real, profundidad; `scopeType`/`table`/columnas validados al construir (inyección por identificadores cerrada).
- **G4**: ningún camino del paquete (middleware, comandos, providers, services, stubs) usa `manager.driver()`.
- **Suite**: 332 tests verdes con OpenFGA, purity incluida.

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **`scopes.moved`**: ¿se acepta exigir `within` también sobre la cadena ACTUAL del hijo (y en `attached` cuando el hijo ya existe), o el invariante 15 se queda como está y se documenta que `within` NO autoriza un movimiento? Con 3b a la vista, esto decide si el 🟠‑1 se convierte en 🔴.
2. **Versión del catálogo**: ¿la garantía del invariante 14 depende de que el consumidor ordene bien su `bumpAuthzCatalogVersion()` (entonces hay que exigir `client` y documentar "última sentencia de la transacción"), o se sustituye por una versión derivada del contenido que no dependa de nadie?
