# Panel alpha.4 — analista técnico

Fecha: 2026-09-09. Base: `main`, `2.4.0-alpha.3`, commit `9a107ad`, árbol limpio.
Entrada: `.claude/contexto/cognitiv-informe-2026-09-09.md`.

Convención de este informe (sin emojis, por petición del entorno):

- `[VERIF]` — verificado leyendo código o midiendo una ejecución real. Se cita fichero:línea o la salida.
- `[ASUM]` — razonado sobre lo verificado, no ejecutado.
- `[ABIERTO]` — incógnita que decide alguien, no yo.

## Cómo se midió

No hay en el repo ninguna app Adonis real que ejecute un comando por el kernel de ace
(`tests/helpers/app.ts` monta `AppFactory` + Lucid a pelo, sin ace; `tests/configure.spec.ts` solo
hace `tsc --noEmit` sobre los stubs). Así que se construyó una en el scratchpad:

- `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/app/`
- `node_modules` de la app = enlaces a **los del repo** (`@adonisjs/core 7.3.5`, `@adonisjs/application 9.0.1`,
  `@adonisjs/lucid 22.4.2`, `@adonisjs/ace`), más `@jantstack/adonis-authz -> <repo>` (usa `build/`, del 2026-09-02).
- `bin/console.js` = `new Ignitor(...).ace().handle(argv)`, el camino real del consumidor.
- Node local `v22.23.2` (COGNITIV usa 24; ver «límite de la medición» al final).
- Variantes del comando: copias literales de `build/commands/openfga_provision.js` con el `commandName`
  cambiado y solo el `startApp` / el shim tocados —`prov:base` (hoy), `prov:a` (A), `prov:b` (B en `run()`),
  `prov:c` (B en `prepare()`)—. No se tocó `src/`, `commands/` ni `tests/`.

---

# 0. Hallazgo que NO venía en el informe y bloquea todo lo demás

**El subpath `@jantstack/adonis-authz/commands` NO es un loader de ace válido: el kernel revienta antes de
mirar ningún comando.** `[VERIF]`, medido:

```
$ node bin/console.js openfga:provision
[FATAL] TypeError: loaderInstance.getMetaData is not a function
    at Kernel$1.boot (node_modules/@adonisjs/ace/build/index.js:2452:26)
    at async AceProcess.handle (node_modules/@adonisjs/core/build/main-B2M1tZ4I.js:89:3)
```

Cadena verificada:

- `configure.ts:47` hace `.addCommand('@jantstack/adonis-authz/commands')`.
- `package.json` mapea `"./commands": "./build/commands/main.js"`.
- `build/commands/main.js` exporta **nueve clases** (`export { default as OpenFgaProvision } from ...`) y nada más.
- `@adonisjs/core/build/create_kernel-Bx7xtr5F.js:31-33`:
  `kernel.addLoader(() => typeof commandModule === 'function' ? commandModule() : app.import(commandModule))`.
- `@adonisjs/ace/build/index.js:2445-2452`: `loaderInstance = await loader()` y acto seguido
  `await loaderInstance.getMetaData()`. **El módulo importado ES el loader.**
- Contraste: `@adonisjs/lucid/build/commands/main.js` y `@adonisjs/core/build/commands/main.js` exportan
  `getMetaData()` / `getCommand(metaData)` y leen un `commands.json` que genera `@adonisjs/assembler`
  (`index-commands`). El `npm run build` de este paquete es `check:purity && typecheck && tsc && copy:stubs`:
  **nunca genera ese índice**. `ls build/commands/*.json` no devuelve nada.

Consecuencia: **ningún comando del paquete arranca en un consumidor que siguiera `node ace configure`**,
no solo `openfga:provision`. COGNITIV no lo reportó porque su workaround fue un comando propio
(`zz_tmp_openfga_provision.ts`) dentro de su proyecto — que se carga por el `FsLoader` de `app.commandsPath()`,
otro camino. `[ASUM]` sobre el porqué; el defecto en sí es `[VERIF]`.

**Arreglo (trivial, sin dependencias nuevas)**: que `commands/main.ts` sea el loader.

```ts
const commands = [OpenFgaProvision, AuthzCatalogDiff, /* ... los nueve */]
export async function getMetaData() { return commands.map((c) => c.serialize()) }
export async function getCommand(metaData: { commandName: string }) {
  return commands.find((c) => c.commandName === metaData.commandName) ?? null
}
```

`BaseCommand.serialize()` existe (`@adonisjs/ace/build/index.js:451`) y es lo que usa el `ListLoader` del propio
ace (`:1748`). Se puede seguir exportando las clases con nombre además, para quien las importe suelto.
Medido: con ese loader escrito a mano en la app de medición, los nueve comandos se registran y
`node ace openfga:provision` llega a `run()`.

Juez propuesto (unos 8 renglones, sin ace, sin red): importar `../commands/main.js`, llamar `getMetaData()`
y afirmar que salen los nueve `commandName` y que `getCommand({ commandName: 'openfga:provision' })` devuelve
la clase. Hoy ese test es rojo.

> Si esto no entra en alpha.4, el arreglo de `startApp` no se puede comprobar de punta a punta en un
> consumidor real. Es el **camino crítico** del lote.

---

# 1. Defecto 1 — la tesis de Adonis, verificada

## 1.1 ¿Cuándo existe `app.config`?

`[VERIF]` en `@adonisjs/application 9.0.1`, `build/application-BCWLhWpE.js`:

| línea | hecho |
|---|---|
| `2086-2088` | `get config() { return this.#configManager.config }` |
| `2399-2422` | `async init()`: `#instantiateContainer()`, hooks `initiating`, `#rcFileManager.process()`, `#state = 'initiated'`. **Ni una mención a `#configManager`.** |
| `2445-2472` | `async boot()`: hooks `booting`, `#nodeEnvManager.process()`, **`await this.#configManager.process(this.rcFile.directories.config)`**, `providersManager.register()`, `.boot()`, hooks `booted`, `#state = 'booted'` |
| `849, 886` | `ConfigManager#config` es un campo sin inicializar; solo `process()` hace `this.config = new Config(...)` |

O sea: entre `init()` y `boot()`, `app.config` es literalmente `undefined`, y `undefined.get(...)` es el
TypeError del informe. Medido en aislado (`AppFactory`, sin ficheros):

```
estado tras create: created
estado tras init(): initiated | config: undefined
estado tras boot(): booted  | config.get(authorization): {"default":"openfga","catalogs":[]}
```

Nota lateral `[VERIF]`: el docblock de `get config()` en `application-BCWLhWpE.js:2078-2082` dice
*"The value is available after the `init` method has been called"* — **es falso en 9.0.1**. Quien escribió
`startApp: false` probablemente leyó eso. No es culpa del paquete y no hay que arreglarlo aquí, pero explica
el bug y conviene que el docblock nuestro lo desmienta con la línea concreta.

## 1.2 Qué hace exactamente el kernel de ace

`[VERIF]` `@adonisjs/core/build/main-B2M1tZ4I.js:54-96` (`AceProcess.handle`):

```js
const app = this.#ignitor.createApp('console')
await app.init()                                   // <- SIEMPRE, y nada más
...
kernel.loading(async (metaData) => {
  if (metaData.options.startApp && !app.isReady) {
    if (metaData.commandName === 'repl') app.setEnvironment('repl')
    await app.boot()
    await app.start(() => {})                      // <- callback VACÍO: no hay servidor HTTP
  }
})
```

Con `startApp: true` corre, además de `boot()`, todo `Application.start()`
(`application-BCWLhWpE.js:2510-2545`), **en este orden**:

1. `#providersManager.start()` — el hook `start()` de **cada provider del consumidor**.
2. hooks `starting` de la app.
3. `#preloadsManager.use(this.rcFile.preloads).import()` — **los `start/*` del consumidor**, filtrados por
   entorno (`PreloadsManager#filterByEnvironment`, `:1512-1515`): un preload sin `environment` declarado
   incluye `console`, así que `start/routes.ts` y `start/kernel.ts` **sí se importan** en un comando.
4. el callback (vacío).
5. `#providersManager.ready()` — el hook `ready()` de cada provider del consumidor.
6. hooks `ready`; `#state = 'ready'`.

Con B (`boot()` a secas) corre 1 sola cosa más que hoy: cargar todo `config/` y `register()`+`boot()` de los
providers. **Nada del consumidor en `start`/`ready`, ningún preload.**

## 1.3 ¿Puede A fallar por culpa del consumidor? Sí. Medido.

Providers del ecosistema, `[VERIF]`:

- **Este paquete** (`providers/authz_provider.ts`): solo `register()`, y los dos bindings son
  `container.singleton(...)` perezosos. No tiene `boot`/`start`/`ready`/`shutdown`. **No toca nada.**
- **Lucid** (`@adonisjs/lucid/build/providers/database_provider.js`): `register()` (singletons),
  `boot()` (`make('lucid.db')`, `BaseModel.$adapter`, repl/vine/test-utils) y `shutdown()`. **No tiene
  `start` ni `ready`.** Y `new Database(...)` solo hace `manager.add(name, config)`
  (`build/src/database/main.js:52-61`): registra, no conecta. `manager.connect()` se llama en
  `db.connection()`, y knex/tarn no abre socket hasta la primera consulta. **Lucid no consulta al arrancar.**
- **`@adonisjs/core/providers/app_provider.js`**: `ready()` (`:341-346`) hace
  `await this.app.container.make('router')` cuando `!app.inProduction`. El router arrastra `encryption`
  (`:165-170`). **Esto sí es una query al ecosistema en `ready()`, aunque no a la base.**

Entonces el riesgo de A no es Lucid; es (a) `app_provider.ready()` y (b) **el código del consumidor**.
Matriz medida (`prov:a` = A, `prov:c` = B en `prepare()`; el `[tiempo]` incluye el ECONNREFUSED del SDK de FGA,
que ambos pagan igual):

| escenario | A (`startApp: true`) | B (`boot()` sin `start()`) |
|---|---|---|
| **1.** app sana y completa, sin provider que toque la base | llega a `run()`, `estado app: ready`, config leído, muere en el FGA. `2.30 s` | llega a `run()`, `estado app: booted`, config leído, muere en el FGA. `2.10 s` |
| **2.** appliance en bootstrap: **falta `config/encryption.ts`** | **NO llega a `run()`**: `RuntimeException: Invalid "config/encryption.ts" file` desde `app_provider.js:170` (vía `ready()` -> `make('router')`). `0.30 s`, exit 1 | llega a `run()`, config leído, muere en el FGA. `2.20 s` |
| **3.** un provider del consumidor consulta la base en `ready()`, **sin base** | **NO llega a `run()`**: se ven `[provider] start()`, `[preload] start/noisy.js IMPORTADO`, `[provider] ready() ... voy a consultar la base` y `Error: connect ECONNREFUSED 127.0.0.1:59999`. `0.30 s`, exit 1 | llega a `run()`, config leído, muere en el FGA. `2.70 s` |

Salida literal del escenario 3, lado A:

```
[provider] start() del consumidor
[preload] start/noisy.js IMPORTADO
[provider] ready() del consumidor: voy a consultar la base…
ℹ Error: connect ECONNREFUSED 127.0.0.1:59999
```

y lado B:

```
[C] boot()
[C] estado tras prepare(): booted
[cmd] estado app: booted
[cmd] config authorization leído: SI
ℹ FgaError: FGA Error: connect ECONNREFUSED 127.0.0.1:59998
```

**La respuesta a la pregunta es sí, con reproducción: A entrega al consumidor la posibilidad de romper el
comando de bootstrap desde código que no tiene nada que ver con OpenFGA, y B no.** Y no hace falta ni un
provider raro: el escenario 2 solo necesita un `.env` incompleto en el primer arranque del appliance, que es
literalmente el caso de uso que el docblock declara.

## 1.4 Coste de B, medido

`app.terminate()` funciona desde `booted` (`application-BCWLhWpE.js:2574-2588`: solo se niega desde `created`
y `terminated`), y `shutdown()` de Lucid (`closeAll()`) es un no-op sin conexiones. No se observó ningún
cuelgue: los procesos terminan con exit 1 en todos los casos.

Coste puro de las fases, `[VERIF]` (media de 3 corridas, app de medición con 4 providers y 1 preload):

```
init:  init=0.8ms  boot=0.0ms   start=0.0ms   total=0.8ms
boot:  init=0.8ms  boot=75.4ms  start=0.0ms   total=76.2ms
start: init=0.8ms  boot=82.9ms  start=3.1ms   total=86.8ms
```

- **B cuesta ~75-85 ms más que hoy.** Eso es leer `config/` entero + `register()`+`boot()` de los providers.
- **A cuesta ~2-3 ms más que B en una app trivial**, y ese es exactamente el tramo donde corre el código del
  consumidor: sin cota, y en el caso real de COGNITIV, mortal.

## 1.5 El límite honesto de B (hay que escribirlo en el docblock)

`boot()` llama a `#configManager.process(...)`, que hace `fsImportAll` del **directorio `config/` completo**.
Medido: con un `config/broken.js` que lanza al importarse, B muere.

```
### B con un config/ que LANZA al importarse ###
[C] boot()
ℹ Error: E_MISSING_ENV_VARIABLE: DB_HOST no está en .env (config que no se puede importar)
 ⁃ (config/broken.js:1:7)
```

Es decir: con B, «ANTES de que haya base» **sigue siendo verdad** (cero conexiones, cero consultas, cero
providers en `start`/`ready`), pero «antes de que haya `.env`» **no lo es**: `config/database.ts` tiene que
poder importarse. Es una restricción mucho más débil que la de A (que además exige que el `.env` sea válido
para el `router`/`encryption` y que todo `ready()` del consumidor sobreviva sin base) y es la misma que ya
tiene cualquier comando `startApp: true` del paquete, así que no rompe a nadie.

## 1.6 Recomendación: **B**, con el shim en `prepare()`, no en `run()`

```ts
static options: CommandOptions = { startApp: false }

/**
 * `openfga:provision` es bootstrap: crea el store ANTES de que haya base, de
 * migraciones y de providers que consulten nada. Por eso NO es `startApp: true`
 * (el kernel de ace haría boot()+start(), y `start()` corre el `start()`/`ready()`
 * de TUS providers y tus preloads de `start/*`: medido, un provider que consulta
 * la base en `ready()` mata este comando antes de que se ejecute).
 *
 * Pero `app.config` no existe hasta `app.boot()` — `Application.init()` no llama a
 * `#configManager.process()`, `boot()` sí (@adonisjs/application 9.0.1,
 * application.js:2399-2422 vs :2445-2472; el docblock de `get config()` dice
 * "after init" y es falso). Así que el comando bootea la app y NO la arranca.
 * Coste medido: ~80 ms (leer config/ + register()+boot() de los providers).
 * Lo que sí exige: que todo `config/*` se pueda IMPORTAR (un `.env` que falte y
 * haga lanzar a config/database.ts rompe esto igual).
 */
async prepare() {
  if (this.app.getState() === 'created') await this.app.init()
  if (this.app.getState() === 'initiated') await this.app.boot()
}
```

Por qué `prepare()` y no las primeras líneas de `run()`, `[VERIF]`
(`@adonisjs/core/build/main-DvUje0hm.js:60-72`): `BaseCommand.exec()` llama
`prepare()` -> `interact()` -> `run()` dentro del mismo `try`, así que el fallo se
reporta igual y `run()` queda limpio de fontanería del ciclo de vida. Medido con
`prov:c`: `[C] boot()` / `estado tras prepare(): booted` / `config leído: SI`.

Por qué el `getState() === 'created'` extra sobre la propuesta de COGNITIV: por el kernel de ace la app
siempre llega `initiated`, pero si alguien ejecuta el comando desde el contenedor (`ace.exec(...)`) sobre una
app cruda, `boot()` desde `created` es un **no-op silencioso** (`:2445-2447`: `if (this.#state !== 'initiated') return`)
y volveríamos al mismo TypeError con otro disfraz. Dos líneas, cierra el caso. Y desde `booted`/`ready`
(comando invocado dentro de una app ya arrancada) las dos guardas no hacen nada: idempotente.

**Steelman de A, que es lo que ellos recomiendan.** Es más simple, homogéneo con los otros ocho comandos, no
mete lógica de ciclo de vida en un comando, y no puede quedarse desactualizado si Adonis cambia `boot()`.
Es un argumento bueno y no lo descarto por gusto: lo descarto porque **el caso 3 está medido y es el suyo**
(un appliance que aprovisiona el store antes de migrar) y porque el escenario 2 convierte un fallo de
configuración del consumidor en «el comando de OpenFGA no existe». Con A, el docblock `:69` y `:153`
(«bootstrap del appliance, ANTES de que haya base») pasaría a ser **falso** y habría que borrarlo y avisar en
el README de que hay que tener la app entera arrancable primero; con B se mantiene y solo se matiza (1.5).

Los otros ocho comandos se quedan como están: **todos leen o escriben `authz_*`**, así que `startApp: true` es
correcto para ellos. No hay inconsistencia que arreglar; hay un comando que es distinto porque su trabajo es
distinto, y eso debe decirlo su docblock.

## 1.7 El juez, medido y barato

Reproducción hermética del defecto **sin ficheros, sin base, sin red**, con las peers del repo:

```js
import { AppFactory } from '@adonisjs/core/factories/app'
import { Kernel } from '@adonisjs/core/ace'
import OpenFgaProvision from '../commands/openfga_provision.js'

const app = new AppFactory().create(new URL('./', import.meta.url), (f) => import(f))
app.rcContents({ providers: [], preloads: [], commands: [] })
app.useConfig({ authorization: { default: 'openfga', catalogs: [async () => ({ permissions: [{ slug: 'p' }] })] } })
await app.init()                                   // el estado en el que ace deja la app con startApp:false
const kernel = new Kernel(app)
const cmd = await kernel.create(OpenFgaProvision, [])
await cmd.exec()
```

Salida HOY (medida):

```
error: TypeError | Cannot read properties of undefined (reading 'get')
exitCode: 1 | estado app después: initiated
```

Con el arreglo debe salir `estado app después: booted` y el error debe ser el del backend (no un `TypeError`).
Segundo caso, el que fija la DECISIÓN y no solo el síntoma: registrar un provider con `ready()` que lance, y
afirmar que **no se llama** — eso es lo que distingue B de A y lo que un `startApp: true` futuro rompería en rojo.
Tercer caso (regresión de idempotencia): invocar el comando con la app ya en `ready` y comprobar que `prepare()`
no relanza nada.

Recuerdo de por qué faltaba `[VERIF]`: `tests/relations_provision.spec.ts` y `tests/openfga_facts.spec.ts:3890`
juzgan `relationsConfigOf` y `permissionsOfCatalogs` —las funciones PURAS que el comando exporta— y ninguna
línea de la suite instancia el comando. La cultura del repo («la decisión vive en una función pura y se juzga
sin montar un ace», `tests/relations_reconcile_cli.spec.ts:1-6`) es buena, pero **aquí la decisión ES el ciclo
de vida**, y eso no se puede extraer a una función pura. Este es el caso que justifica la excepción.

---

# 2. Pregunta 2 — `capabilities()` en los dos managers

## 2.1 Qué hay hoy `[VERIF]`

- `AuthorizationManager.driver()` (`src/manager.ts:368-395`) es **async y perezoso**: resuelve la factory,
  aplica `withClock`, corre `#assertTransactionalWritesRequired` (`:409-419`, puerta 2) y
  `#assertScopeDriftGuarded` (`:468-483`), y **solo entonces** cachea en `#driver`. Con `forRequest()` la vista
  delega en el padre (`:369`), así que hay una sola resolución por manager.
- `RelationsManager.driver()` (`src/relations/manager.ts:256-258`) es **síncrono**: el driver ya viene resuelto
  del constructor (`providers/authz_provider.ts:52`, `buildRelationsManager`), y la puerta 2 se aplica ahí
  mismo (`src/relations/manager.ts:122-131`).
- Los dos `capabilities` publicados ya son inmutables: `Object.freeze` en
  `src/drivers/database_driver.ts:499`, `src/drivers/openfga_driver.ts:609-610` (getter que congela),
  `src/drivers/database_relations_driver.ts:219`, `src/drivers/openfga_relations_driver.ts:179`.
- La regla «un driver sin `capabilities` se trata como todo `false`» **ya está publicada**
  (`src/types.ts:238-242`) y **ya se aplica** (`src/manager.ts:469`).
- `src/manager.ts:353-367` documenta `driver()` como salida de TODAS las barreras, y el README `:285` lo
  refuerza («a tenant call-site should never call it, and a code review can grep for it»).
- **`AuthorizationDriverCapabilities` NO se exporta de `index.ts`** (grep vacío), mientras
  `RelationsDriverCapabilities` sí (`index.ts:244`). Asimetría real: hoy el consumidor **no puede ni nombrar
  el tipo** de lo que lee.

## 2.2 Viabilidad y forma mínima

Sí, es viable y es pequeño. Forma que recomiendo:

```ts
// src/types.ts — un solo sitio para la regla que ya estaba escrita en prosa
export const DEFAULT_DRIVER_CAPABILITIES: Readonly<AuthorizationDriverCapabilities> = Object.freeze({
  hierarchyFacts: false, singleCheckAuthorize: false, roleInheritanceNative: false,
  listObjectsInherited: false, purgeRole: false, countRoleAssignments: false,
  canonicalScopeReads: false, enumerateFacts: false, transactionalWrites: false,
})

// src/manager.ts
async capabilities(): Promise<Readonly<AuthorizationDriverCapabilities>> {
  const driver = await this.driver()
  return Object.freeze({ ...DEFAULT_DRIVER_CAPABILITIES, ...driver.capabilities })
}

// src/relations/manager.ts  (síncrono, igual que su driver())
capabilities(): Readonly<RelationsDriverCapabilities> {
  return Object.freeze({ ...DEFAULT_RELATIONS_CAPABILITIES, ...this.#driver.capabilities })
}
```

Las cinco decisiones, con su porqué:

| decisión | recomendación | porqué |
|---|---|---|
| método o getter | **método** | El de roles tiene que ser `async` (resuelve el driver perezoso). Un getter async es una mentira sobre el coste; un getter sync obligaría a resolver el driver en el constructor y eso rompe la resolución perezosa por nombre que `driver()` defiende explícitamente (`src/manager.ts:404-408`). Método en los dos, por simetría de nombre. |
| ¿resuelve el driver? ¿pasa la puerta 2? | **sí, resuelve, y por tanto pasa las dos puertas** | No hay alternativa correcta: las capacidades son **de la instancia**, no de la clase — `database` decide `transactionalWrites: this.transactionalWrites` desde sus opciones (`database_driver.ts:498` -> `:520`), así que un despliegue con pool 1 declara `false`. Leerlas sin resolver sería inventárselas. Y que herede las puertas es **deseable**: con `requireTransactionalWrites: true` y un driver que no la cumple, el despliegue ya no arranca (`:409-419`); un `capabilities()` que respondiera ahí sería la única cosa del paquete que funciona en un despliegue declarado inconstruible. En relaciones no se plantea: la puerta 2 ya corrió en `buildRelationsManager`. |
| ¿copia congelada? | **sí** | Los cuatro drivers del paquete ya congelan, así que el coste es un spread por llamada tras la primera resolución (`#driver` cacheado). Lo que compra es el driver de terceros: (a) que no devuelva un objeto vivo que el consumidor pueda mutar, y (b) que un `capabilities` a medias no deje huecos `undefined` sueltos. |
| driver sin `capabilities` | **todo `false` (`DEFAULT_*`), nunca `undefined`** | Es la regla YA publicada (`src/types.ts:238-242`) y la que ya aplica el manager (`:469`). Devolver `undefined` reproduciría exactamente el bug de `stillGranting` del invariante 18 («"no lo sé" no puede degradar a...»), pero al revés: obligaría al consumidor a escribir `caps?.transactionalWrites ?? false`, o sea, a re-implementar la regla en cada call-site. Ojo, el trade-off hay que documentarlo: un driver de 2.x que **sí** sabe purgar roles se reporta `purgeRole: false`. No es nuevo —es la regla vigente— pero al hacerla API se vuelve más visible. Contrapartida a favor: es fail-closed en las nueve. |
| mensajes de las puertas | **no tocar** | `#assertTransactionalWritesRequired` distingue `false` de «nada (sin capabilities)» en el texto del error (`:413`). Si se refactoriza para leer del `DEFAULT_*`, ese matiz se pierde. Consolidar es tentador y **no vale la pena en alpha.4**. |

## 2.3 La alternativa sin API nueva, y por qué no

Documentar `driver()` como lectura legítima cuesta cero y es honesta: leer `capabilities` por ahí **no** salta
ninguna barrera (no hay ninguna sobre una propiedad de solo lectura). El argumento a favor es real y hay que
decirlo: menos superficie pública, cero riesgo de romper a un driver de terceros.

Lo descarto por una razón concreta y no estética: **el paquete ha invertido en que `driver()` sea greppable**
(README `:285`: «a code review can grep for it»; invariante 15: «`manager.driver()` es la salida documentada de
todas las barreras»). Bendecirlo para una lectura que el consumidor necesita **en su camino de request**
—COGNITIV quiere ramificar por `transactionalWrites` en el código de sus servicios— convierte ese grep en ruido
y pone `driver()` a un `.grant(` de distancia del código de tenant. Nueve líneas de API compran que el grep
siga significando lo que significa. Ese es todo el argumento; si el dueño no lo compra, documentar `driver()`
es defendible y no rompe ningún invariante.

## 2.4 Lo que hay que añadir sí o sí, aunque se elija la alternativa

`export type { AuthorizationDriverCapabilities }` en `index.ts` (junto al `RelationsDriverCapabilities` de
`:244`). Hoy el consumidor no puede tipar lo que ya lee. **Trivial** y es un bug de empaquetado, no una feature.

`[ABIERTO]` para el dueño: ¿`capabilities()` también en `AuthorizationView`? Sale gratis (misma clase, `driver()`
delega en el padre) y no hay motivo para quitarlo, pero conviene decidirlo a propósito y documentarlo, no
descubrirlo.

---

# 3. Pregunta 3 — `sqlScopeEdges` y el árbol de tres tablas

## 3.1 El problema es más gordo que «no lo cubre» `[VERIF]`

`src/sql_descendants.ts:288-292` genera **un `LEFT JOIN` de la tabla consigo misma**:

```
FROM <table> t LEFT JOIN <table> p ON t.<parentColumn> = p.<uuidColumn>
```

y `:315-317` descarta la fila cuando el padre no tiene pareja:

```ts
// Padre declarado que no tiene fila: el nodo NO está en el árbol
if (row.parent_row === null || row.parent_row === undefined) continue
```

En el árbol de COGNITIV (`organizations` -> `organization_units` autorreferencial -> `ia_spaces`) el padre de
un `ia_space` vive en **otra tabla**. Resultado si alguien intentara la vía obvia («declaro tres
`sqlScopeEdges`, uno por tabla»): las aristas `ia_space -> organization_unit` y `organization_unit -> organization`
**no se emiten**, en silencio, y `sqlScopeEdges` no tiene forma de distinguir «huérfano» de «el padre está en
otra tabla». Con `authz:reconcile --to=openfga` eso no es «faltan aristas»: el destino las ve como sobrantes y
las borra, y por el invariante 9 / 3b-2i (`rooted`) **todo el subárbol pasa a denegar**.

Es fail-CLOSED —ruidoso, total, nadie escala privilegios— pero es un pie de guerra. Y el `typeColumn`/`scopeType`
tampoco cubre el caso: el tipo del padre saldría del mismo `scopeType` fijo de la tabla del hijo (`:319-321`),
o sea mal.

Por eso COGNITIV escribió su `enumerateScopeEdges` con UNION ALL. **No es que el helper «no llegue»: es que
componerlo ingenuamente es incorrecto**, y hoy nada lo dice. Ese es el hallazgo real de su pregunta 3.

## 3.2 Las tres salidas, con coste

| opción | qué es | coste | qué compra |
|---|---|---|---|
| **(a) Docs** | un párrafo en `SqlScopeEdgesOptions` y en el README: «una tabla con columna padre **de la misma tabla**; si tu padre vive en otra tabla, este helper **no emite esa arista y no avisa** — escribe `enumerateEdges` a mano (UNION ALL con un cursor propio) y compara con `--dry-run` antes de la primera pasada real». Más el mismo aviso en el docblock de `ScopeEdgesEnumerator` (`src/types.ts:961-962`). | **trivial**. Cero código, cero contrato. | Que el siguiente consumidor no pierda un día ni borre su árbol. |
| **(b) Helper de composición** `composeScopeEdges([...])` con cursor compuesto (`"<i>:<inner>"`), drenando cada enumerador en orden. | El contrato de `ScopeEdgesEnumerator` (`src/types.ts:952-956`) exige orden **total y estable**; una concatenación de enumeradores estables lo es. Es correcto. | **fácil** (unas 25 líneas) **pero no resuelve el caso**: sin (c) los tres `sqlScopeEdges` siguen sin emitir las aristas entre tablas. Compone lo que ya funciona, no lo que falta. | Poco, por sí solo. |
| **(c) `parentTable` + `parentScopeType` en `sqlScopeEdges`** | LEFT JOIN contra otra tabla y tipo del padre distinto del del hijo. Con (b) encima, el caso de COGNITIV queda cubierto de config. | **medio**: opciones nuevas, validación de exclusividad como la de `typeColumn`/`scopeType` (`:252-256`), y **casos de contrato en los tres dialectos** (PG/MySQL/SQLite) — el helper ya los tiene en `tests/reconcile.spec.ts`. Más el caso «padre en otra tabla que no existe -> sigue sin emitir». | El caso real, sin que nadie escriba SQL. |

## 3.3 Recomendación: **(a) ahora, (b)+(c) diferido**

Ellos **no lo piden** y ya tienen su implementación funcionando (informe: 448 tuplas, segunda pasada
idempotente). La regla de tres del repo dice esperar a un segundo consumidor: hoy hay **uno**, y su forma de
árbol (tres tablas, dos saltos entre tablas) no sabemos si es la común o la suya. Además (c) es API pública
nueva sobre un helper que sirve al camino más destructivo del paquete (`--prune`), y meterlo en la alpha que
arregla dos defectos de arranque es cambiar el riesgo del lote.

Lo que **no** es opcional es (a): el modo de fallo es silencioso y su consecuencia es «todo deniega en ese
subárbol». Un helper que puede callarse tiene que decirlo en su propio docblock.

`[ABIERTO]` para el dueño: si (c) entra alguna vez, la pregunta previa es si `sqlScopeEdges` debería
**lanzar** en vez de saltar cuando el padre declarado no tiene fila y no hay `parentTable` (un
`onMissingParent: 'skip' | 'throw'`, `'skip'` por defecto para no romper). Eso convierte el silencio en ruido
y es probablemente más valioso que el helper de composición. No lo meto en el plan: es una decisión de contrato.

---

# 4. Plan por lotes para `2.4.0-alpha.4`

Orden = camino crítico. Cada lote tiene un resultado demostrable.

### Lote 1 — «los comandos del paquete existen» (camino crítico)

- **1.1** `commands/main.ts` pasa a ser un loader de ace (`getMetaData` / `getCommand`), manteniendo los
  exports con nombre. **Dificultad: trivial.**
- **1.2** Caso: `getMetaData()` devuelve los nueve `commandName` y `getCommand({commandName:'openfga:provision'})`
  devuelve la clase. **Trivial.** Hoy rojo.
- **Resultado demostrable**: `node ace list` en un consumidor recién `configure`-ado enseña los nueve comandos.
- **Por qué primero**: sin esto, el lote 2 no se puede comprobar de punta a punta en un consumidor.

### Lote 2 — `openfga:provision` arranca (el defecto reportado)

- **2.1** `prepare()` con las dos guardas de estado (`created` -> `init()`, `initiated` -> `boot()`).
  **Dificultad: trivial** (4 líneas).
- **2.2** Reescribir los docblocks `:69` y `:153` y el de `static options`: por qué NO es `startApp: true`
  (con el hecho medido: `start()` corre `start`/`ready` de los providers del consumidor y sus preloads de
  `start/*`), por qué `app.config` no existe antes de `boot()` (con la línea de
  `@adonisjs/application 9.0.1`), y **el límite**: «ANTES de que haya base» sigue siendo verdad, «antes de que
  haya `.env`» no — todo `config/*` tiene que poder importarse. **Fácil**, pero es la mitad del valor del lote.
- **2.3** Casos, con `AppFactory` + `Kernel` en memoria (sin red ni base): (i) `run()` llega y lee el config y
  la app queda `booted`; (ii) un provider con `ready()` que lanza **no se llama** (es el caso que fija B frente
  a A y lo que se pondría rojo si alguien «homogeneiza» a `startApp: true`); (iii) idempotencia con la app ya
  `ready`. **Fácil.**
- **Resultado demostrable**: `node ace openfga:provision --url ...` provisiona contra un OpenFGA vivo en un
  proyecto sin migrar y sin `.env` completo más allá de lo que sus `config/*` importen.

### Lote 3 — `capabilities()` en los dos puertos

- **3.1** `export type { AuthorizationDriverCapabilities }` en `index.ts`. **Trivial.** (Va aunque se caiga
  todo lo demás del lote: es un bug de empaquetado.)
- **3.2** `DEFAULT_DRIVER_CAPABILITIES` / `DEFAULT_RELATIONS_CAPABILITIES` congelados en `src/types.ts`.
  **Trivial.**
- **3.3** `AuthorizationManager.capabilities()` (async) y `RelationsManager.capabilities()` (sync).
  **Trivial** (3 líneas cada uno).
- **3.4** Casos: los dos drivers de cada puerto declaran lo que declaran; un driver sin `capabilities` da
  **todo `false`, nunca `undefined`**; el resultado es inmutable (mutarlo lanza en strict mode); en roles,
  con `requireTransactionalWrites: true` y un driver que no la cumple, **`capabilities()` lanza igual que
  `driver()`** (esa es la decisión, y sin caso se «arregla» sola en la primera refactorización). **Fácil.**
- **3.5** README: una sección corta junto a la tabla de capacidades de `:746` — «cómo pregunto esto en runtime»,
  con el ejemplo de ramificar por `transactionalWrites`, y una frase que diga que **esto no ablanda `driver()`**.
  **Fácil.**
- **Resultado demostrable**: el mismo código del consumidor sirve a los dos drivers sin un solo `driver()` en
  su capa de servicios.

### Lote 4 — docs de `sqlScopeEdges`

- **4.1** Docblock de `SqlScopeEdgesOptions` y de `ScopeEdgesEnumerator` (`src/types.ts:961-962`) + párrafo en
  el README: una tabla con padre **en la misma tabla**; padre en otra tabla = arista **no emitida y sin aviso**;
  receta = `enumerateEdges` propio (UNION ALL + cursor), y **verificar con `authz:reconcile --dry-run` antes de
  la primera pasada real**. **Trivial.**
- **Resultado demostrable**: el siguiente consumidor con un árbol multitabla lo lee antes de escribirlo.

### Lote 5 — CHANGELOG

- **5.1** Entrada en el estilo del 1.1.0 (problema -> decisión -> qué NO se hace y por qué) para: el loader de
  comandos, `startApp` (con la matriz medida y el porqué de B sobre A), `capabilities()` (con el porqué de
  «resuelve el driver» y de «todo `false`»), y la nota de `sqlScopeEdges`. **Fácil.**
- Ninguno de los cuatro cambios rompe el contrato de un driver de terceros: `capabilities()` **lee** un campo
  que ya era opcional y no añade nada al puerto. **No es major.**

## Qué NO hacer en alpha.4

1. **No pasar `openfga:provision` a `startApp: true`.** Medido en dos escenarios: rompe el caso de uso que el
   propio comando declara.
2. **No «homogeneizar» los otros ocho comandos.** Todos tocan `authz_*`; `startApp: true` es correcto ahí.
3. **No refactorizar las puertas 1/2 para leer de `DEFAULT_DRIVER_CAPABILITIES`.** Funciona igual y se pierde
   el matiz «nada (sin capabilities)» del mensaje de `src/manager.ts:413`. Cambio invisible, riesgo gratis.
4. **No añadir `parentTable`/`composeScopeEdges` todavía.** Un consumidor, ya resuelto por él, API pública
   nueva sobre el camino de `--prune`. Regla de tres.
5. **No exponer nada más por `capabilities()`** (ni `driverName`, ni «flags de despliegue», ni un `supports(x)`).
   El puerto ya tiene el tipo; publicarlo tal cual es todo el valor.
6. **No tocar `driver()`**, ni su docblock ni el README `:285`. Lo que se añade es una puerta nueva, no una
   suavización de esa.
7. **No meter `@adonisjs/assembler` al build** para generar `commands.json`. El loader a mano son 6 líneas y
   no añade una dependencia de build a un paquete que hoy solo necesita `tsc`.

---

# 5. Decisiones que necesito del dueño

1. **B frente a A** en `openfga:provision`. Mi recomendación es B con el shim en `prepare()`, con la matriz de
   1.3 como evidencia. `[ABIERTO]`
2. **`capabilities()` nuevo** frente a **documentar `driver()` para lectura**. Recomiendo el método nuevo;
   la alternativa es defendible y no rompe ningún invariante. `[ABIERTO]`
3. **`capabilities()` en `AuthorizationView`** (`forRequest()`): sale gratis, pero que sea a propósito. `[ABIERTO]`
4. **`sqlScopeEdges`**: docs ahora, `parentTable`+composición diferido. Si se quiere adelantar, la pregunta
   previa es el `onMissingParent: 'throw'`. `[ABIERTO]`

---

# 6. Límites de esta medición (lo que NO pude verificar)

- **Node 22.23.2, no 24.** `@adonisjs/application 9.0.1` declara `engines: { node: ">=24.0.0" }`. Todo lo medido
  arrancó sin avisos y el defecto reproduce igual, y ninguna de las rutas tocadas (ciclo de vida, `ConfigManager`,
  loaders de ace) usa nada específico de 24. **Pero la matriz de 1.3 no se ha repetido en Node 24.** Pendiente
  de repetir antes de cerrar el lote 2.
- **`@adonisjs/core 7.3.5` en el repo, `7.3.3` en COGNITIV.** Verifiqué contra 7.3.5. `[ASUM]` que el
  `AceProcess.handle` no cambió entre esos dos parches; no lo comprobé.
- La app de medición usa `build/` del 2026-09-02 (mismo commit publicado como alpha.3), no `src/` con ts-exec.
  Coinciden en lo relevante (`build/commands/openfga_provision.js:42` es `commands/openfga_provision.ts:46`).
- **No se probó contra un OpenFGA vivo**: no hay ninguno escuchando en `:8101` ni en `:8080` en esta máquina.
  Todos los casos terminan en `ECONNREFUSED` del SDK, que es exactamente la señal de «el comando llegó a
  hacer su trabajo». La verificación con servidor sigue pendiente y es del tester.
- No se ejecutó `npm test`: el encargo era de solo lectura fuera de `.claude/contexto/`.
