# Re-ataque del auditor al CIERRE del lote A (2.5.0-alpha.1, árbol sin commit sobre 645af34) — 2026-10-15

Alcance: regresiones del propio cierre (sección «Cierre (auditor)» de `loteA-informe.md`, decisiones §2026-10-15).
Solo `:memory:`, dobles y `check:guard-mutants --only`. Repro: `.claude/reproducciones/loteA-cierre-reataque.spec.ts`
(runner `loteA-cierre-run.ts`, VERDE = defecto): **2/2 verdes** sobre una copia del árbol en el scratchpad.
Repro anterior `loteA-run.ts` sobre la copia: **3 failed / 3** (A1, A2, A3 cerrados, como dice el informe).

## Veredicto en una línea

Seguro con reservas: el cierre no introduce regresiones; el 🟠 que queda (R1) viene de antes, pero el cierre dijo que
en roles «no aplica» y en la rama sin cadena sí aplica.

## Hallazgos (ordenados por severidad)

### 🟠 R1 · El gemelo de A2 en ROLES: `scopeSpellings` solo expande el alias sin guiones, no `8-4-4-16`

- Escenario: el consumidor guarda los tenants/units en una columna `uuid` de PG. El controlador hace
  `DELETE /units/<8-4-4-16>` y PG funde esa forma con la canónica (el propio cierre lo midió en A2). La fila se borra.
  Después llama a `scopes.detached({ type: 'unit', uuid: '<8-4-4-16>' })` con el id de la URL. Como no hay cadena,
  `manager.ts:1123` usa `scopeSpellings(child)` = `[<8-4-4-16>]` y nada más (`identity.ts:261-266`: solo se activa con
  `DASHLESS_UUID`). La purga demuestra cero sobre una clave sin hechos. **Los hechos canónicos sobreviven**:
  - en `facts`, las aristas `parent`/`binding` del nodo canónico siguen ahí y el scope sigue concediendo para siempre.
    Es el 🟠 3 de 3b-2h, con otra ortografía;
  - en `database`, deniega mientras no exista la fila y resucita si se restaura el mismo uuid (viola «nada resucita»
    del invariante 11).
  El mismo agujero existe en `canonicalScopeTargets` (`backend_guard.ts:297-309`), que es el fan-out de
  `revoke`/`removeDeny` cuando la cadena es `null`.
- Evidencia: ✅ `loteA-cierre-reataque.spec.ts` «R1»: el control `scopeSpellings(dashless)` devuelve 2 ortografías;
  con `8-4-4-16`, `isNonCanonicalUuid` da `true` y las llamadas son exactamente `[purgeScope unit:<alias>, detached
  unit:<alias>]`, sin la canónica. En `facts` el «concede para siempre» no lo he medido contra un servidor (`:8090` está
  ocupado): ❓, pero es el mismo mecanismo que 3b-2h midió contra el `:8101`.
- No es una regresión del cierre. Es un defecto previo. Lo que el cierre añade es la línea (a) de A2, que dice «Roles:
  no aplica (invariante 17 canoniza por la cadena)», y es falsa justo en la rama donde NO hay cadena. Esa rama es la que
  3b-2h cerró solo para el sin guiones.
- Steelman del defensor: «nadie escribe `8-4-4-16` en una URL». **No me convence**: el que elige la ortografía es el
  atacante (el id viaja en la URL). A2 se clasificó 🟠 por eso mismo, y 3b-2h 🟠 3 era idéntico con la otra forma.
- Mitigación mínima: que `scopeSpellings` expanda con la misma regla que `isNonCanonicalUuid` (si es no canónica, añadir
  la canónica). Además, una sonda `misdashed` en el caso 3b-2h · 🟠 3 de `scope_outbox.spec.ts` y en el fan-out de
  `revoke`/`removeDeny`.

### 🟡 R3 · La receta por defecto borra TODAS las relaciones de la población que A6 nombra, y el README no lo dice

- Escenario: un consumidor cuyos tenant ids son `randomBytes(16).toString('hex')` (la población declarada en A6) sube a
  2.5.0 y sigue el README. El detector lista todas sus particiones y el DELETE por defecto vacía `authz_relations` entero.
  En ese caso lo correcto era `--rekey` y pasar los ids en forma 8-4-4-4-12. El README solo dice «A partition id that is
  not a uuid (e.g. 32 characters that are not all hex) is untouched: it is a legal id», y eso da a entender que los ids
  no-uuid están a salvo. Un id de 32 hex no-uuid no lo está.
- Evidencia: ✅ README §«Upgrading to 2.5.0», paso 3, y CHANGELOG l. 61-63, donde A6 nombra la población pero no la
  conecta con lo que hace la receta. Es fail-closed y no es un bypass, por eso va como 🟡 y no más. Hay una variante ⚪:
  los ids de 32 hex con guiones en posiciones no-uuid (`xxxxxxxx-xxxxxxxx-…`) también son ahora 422 y también se borran,
  y esa población no está nombrada en ningún sitio.
- Steelman del defensor: «el paso 1 enseña los conteos, el operador lo ve». **Me convence a medias**: lo ve si sabe
  interpretarlo. Una frase lo arregla.
- Mitigación mínima: una línea en el README: «si el detector lista todas tus particiones, tus ids son 32-hex no-uuid: usa
  `--rekey` y pasa a escribirlos en 8-4-4-4-12; el default los borra todos».

### ⚪ R2 · A9 convierte basura del BACKEND en un 422 del llamante y bloquea el reconcile de la partición

- Escenario: en el store hay una tupla de un tipo declarado con un id fuera de la gramática, por ejemplo
  `document:unit|<key>|ABC` escrita a mano con el SDK o por otro proceso. `#sweep` (`openfga_relations_driver.ts:707-740`)
  no filtra por la gramática. `planPartition` aplica `relationTupleKey` a las tuplas del destino, y ahora esa función
  valida cada componente. Resultado: `authz:relations:reconcile --prune` sobre esa partición es 422
  `E_AUTHZ_INVALID_IDENTITY`, también con `--dry-run`. Antes del cierre la tupla salía como `extra` y `--prune` la
  barría. Ahora nadie la barre, y el código dice «pregunta inválida» cuando el dato malo es del backend (invariante 5).
- Evidencia: ✅ repro «R2»: con un doble `fake([good, garbage])` la pasada lanza 422; con `fake([good])` da
  `unchanged: 1`. No concede nada, porque la API no puede preguntar por `ABC`.
- Steelman del defensor: «es basura escrita a mano; que la borre a mano». **Me convence para la severidad, no para el
  código**: debería contarse (`skipped`/`extra`) o ser un 503 que nombre la tupla, no un 422.
- Mitigación mínima: en `planPartition`, validar con `isValidRelationId` y contar o desechar antes de llamar a
  `tupleKey`, o capturar el error y reclasificarlo.

### ⚪ R4 · Higiene de letra

- `--rekey` dice «delete one of them by hand first» y no dice cuál. Si se conserva la de caducidad más lejana (o `NULL`)
  no se alarga nada respecto a lo que esa fila ya tenía, pero conviene escribir «conserva la más cercana».
- La colisión de UN tenant bloquea el `--rekey` de TODOS: el UPDATE es atómico, medido en SQLite (la fila de otro tenant
  tampoco se re-clava). Es la dirección segura y el README lo dice («nothing is re-keyed until…»). Lo anoto solo para que
  quede.
- El informe da dos cifras para `identity.misdashed.A2`: «43 rojos» en el texto y «42» en la tabla de gates. El gate
  medido hoy con `--only` da 42.

## Lo que intenté y NO se rompió

- **A1, la rama por defecto borrando una canónica.** Fuzz de 20 000 particiones (canónicas, sin guiones, guiones al azar,
  ids de la gramática, 31/33 hex, 31 hex + no-hex) contra el DELETE literal del bloque `D4 · SQLite` del README: **0
  discrepancias** con `isNonCanonicalUuid` y **0 canónicas borradas**. En PG y MySQL lo comprobé leyendo: las regex son
  equivalentes, `partition_key` es `utf8mb4_bin` y la gramática prohíbe `\n` y `|`, así que ni el `$` de ICU ni
  `split_part`/`SUBSTRING_INDEX` divergen.
- **A1, `--rekey` borrando la canónica.** El paso 1 solo borra la fila `d` NO canónica, y la definición de gemelo coincide
  columna a columna con `authz_rel_tuple_uq`. La canónica no casa el predicado. El orden de asignación del UPDATE en MySQL
  (de izquierda a derecha, `subject_partition` antes que `partition_key`) está bien puesto para el trigger.
- **A1, dos alias sin gemelo.** El UPDATE falla entero y no deja el store a medias (medido en SQLite; en PG/InnoDB es
  rollback de sentencia). El paso 1 ya aplicado es idempotente. El default borra los dos.
- **A1, `NULL` de caducidad.** Con gemelo, la no canónica se borra y el gemelo queda intacto (`NULL` no gana). Sin gemelo
  se re-clava con su propia caducidad. Ninguna rama alarga nada.
- **A2, mayúsculas.** `A0EEBC99-…` es 422 por `assertScope` (gramática K1) antes de llegar a `isNonCanonicalUuid`.
- **A3.** `everyPositionBoolean` usa `typeof === 'boolean'` por índice: `new Boolean(true)` (`object`), `0`/`1`, huecos y
  `undefined` dan 500. Los dos gemelos son idénticos.
- **A10.** `alignBatchResults` es la única ruta en los dos drivers. Una respuesta sin `allowed` y sin `error` da `false`,
  pero en `facts` el deny está dentro de `can_<P>`, así que eso es fail-closed.
- **A4.** La letra de la línea la decide `report.dryRun`. `pruned: true` solo existe con `prune && originIsSelf`, y si la
  pasada aborta (mass-delete) se lanza antes de imprimir. No encontré forma de que un dry-run diga «BORRADO».
- **A5.** `exports["./testing/clock"]` apunta a `build/src/testing/test_clock.js`, que existe en el build actual. Su
  único import es `../clock.js`, que no importa nada, y `files: ["build"]` lo publica.
- **A9.** El único llamador interno es `reconcile.ts`, que pasa `kind: 'allow'` explícito en las tres llamadas. No hay
  otro uso en `src/` ni en `commands/`.
- **Guardia.** `check:guard-mutants --only identity.misdashed.A2,identity.dashless.D4`: 2/2 muertos, 42 rojos cada uno,
  línea base 165.

## Preguntas abiertas para el arquitecto

- R1: ¿`scopeSpellings` adopta la regla de A2 (toda forma no canónica añade la canónica)? Si sí, entra en el mismo lote
  con su sonda. Si no, hace falta una exención firmada y quitar el «Roles: no aplica» del informe y de `CLAUDE.md`.
