# Fase 3 · Lote 3D — verificación del tester de contrato

Commit verificado: **`56094ac`** (worktree aislado `agent-a46906ae00a7eb35f`, checkout detached).
Base de comparación `f563465`. Node 22.23.2, `npm ci` limpio, `npm run typecheck` limpio.
Motores: OpenFGA `:8101` (compartido, sin borrar stores ajenos), PostgreSQL 18 (`postgres18`),
MySQL 8.4 (`mysql84`), SQLite memoria y fichero. Tope 3 en un contenedor propio (`:8113`, borrado).
Spec: `fase-3-correcciones.md` (M1–M6, N1–N7). Informe del lote: `fase-3-lote-d-informe.md`
(diez desviaciones). Auditor: `fase-3-verificacion-auditor.md`. Mi verificación 3A/3B:
`fase-3-verificacion-tester.md`.

**Veredicto: APTA CON CORRECCIONES.** Todo lo que el lote dice haber arreglado está arreglado y
tiene juez, salvo **una mitad de M1(c)**: la ruta `{ uuid }` de `RoleQuery` comprueba el nivel del
rol pero **no había ningún caso que observara la comprobación del owner** — tres mutantes vivos en
`grant`, `hasRole` y `listSubjects`, en los dos drivers y en los cuatro modos. Se cierra con el
parche adjunto (`tests-tester-fase-3d.patch`, solo `src/testing/contract.ts`, sin cambiar conteos).
Quedan tres promesas sin juez que NO bloquean pero deben constar (§5).

---

## 1. Suites — medidas, no citadas

| Ejecución | Informe 3D | Medido |
|---|---|---|
| `npm test` (SQLite `:memory:`) | 399 | **399 passed** ✅ |
| `OPENFGA_TEST_URL=:8101 npm test` | 504 | **504 passed** ✅ |
| `:8101 npm run test:sqlite-file` #1 | 506 | **506 passed** ✅ |
| `:8101 npm run test:sqlite-file` #2 | 506 | **506 passed** ✅ |
| `:8101 npm run test:sqlite-file` #3 | 506 | **506 passed** ✅ |
| `:8101 npm run test:pg` (PG 18) | 674 | **674 passed** ✅ |
| `:8101 npm run test:mysql` (MySQL 8.4) | 674 | **674 passed** ✅ |
| `OPENFGA_TEST_URL=:8113 npm test` (tope 3, MAX_RESULTS=3) | 504 | **504 passed** ✅ |
| `npm run typecheck` | limpio | **limpio** ✅ |

**Flakes**: las tres corridas de `sqlite-file` fueron consecutivas, con `:8101`, y las tres verdes.
El caso de la carrera de M2 pasó las tres veces. **El informe dice la verdad sobre los flakes en
verde.** Matiz importante (§2, M2): el caso no es flaky en verde pero **sí lo es en su capacidad de
matar mutantes** — con `sqlite-file`, el mutante «sin re-chequeo» murió en el harness `openfga` y
**sobrevivió** en el harness `database` de la misma corrida.

**Residuos**: cero de los míos. Cada una de mis corridas imprimió su `[suite] base destruida: …`
(9 en PG, 4 en MySQL) y MySQL termina con **0** bases `authz_test%`. En PostgreSQL queda **una**,
`authz_test_3beaf8e3`, **que no es mía** — no aparece en ninguno de mis logs y no había ningún
proceso de la suite corriendo al comprobarlo: es del auditor, que trabaja en paralelo en el árbol
principal. **No la he tocado.** Contenedor `openfga-tiny-tester` borrado; ningún store ajeno de
`:8101` tocado.

Con el parche aplicado: 504 (sqlite+FGA), 506 (sqlite-file+FGA), 674 (pg), 674 (mysql), typecheck
limpio. El parche no añade tests nuevos (solo asertos), así que `contract_harness.spec.ts` sigue
verde sin tocar los conteos.

---

## 2. Mutantes en `src/` — pieza × mutante × motor × resultado

Los números son tests muertos medidos en ese motor. `≡` = mutante equivalente (no observable por
construcción).

| Pieza | Mutante en `src/` | sqlite | sqlite-file | pg | mysql | Resultado |
|---|---|---|---|---|---|---|
| **M1 a** | `roleVisible` vuelve a «el owner más cercano gana» | 4 | — | 6 | — | **MUERTO** |
| **M1 b** | el manager compone por slug (`rolesInChain` fuera de juego) | 4 | — | — | — | **MUERTO** |
| **M1 a+b** | los dos: la escalada V1 original | 8 | — | — | — | **MUERTO** (con el veredicto exacto) |
| **M1 c** | `RoleQuery {uuid}` sin comprobar el **nivel** | 3 | — | — | — | **MUERTO** (D11 reescrito) |
| **M1 c2** | `resolveRoleQuery`: `{uuid}` sin comprobar el **owner** (grant) | **0** | — | **0** | — | **VIVO** 🔴 → parche |
| **M1 c3** | `visibleRoleFor`: `{uuid}` sin owner (listSubjects) | **0** | — | — | **0** | **VIVO** 🔴 → parche |
| **M1 c4** | `hasRoleTargets`: `{uuid}` sin owner (hasRole) | **0** | — | — | — | **VIVO** 🔴 → parche |
| **M2 a** | quitar el `SELECT … FOR UPDATE` del catálogo | n/a (1) | n/a (1) | 4 | 4 | **MUERTO** |
| **M2 b** | quitar el re-chequeo de colisión dentro de la transacción | 2 | 1 (2) | 4 | — | **MUERTO** |
| **M2 b'** | ídem, con el caso **forzado a serie** | — | — | **0** | — | **VIVO**: la parte en serie NO lo caza |
| **M2 c** | la colisión de la transacción lanza **503** en vez de 422 | — | — | **0** | — | **VIVO** 🟠 (§5.2) |
| **M3** | quitar `#assertWithinChain` de `defineScopedRole` | 1 | — | — | — | **MUERTO** |
| **M3** | quitar `#assertWithinChain` de `updateScopedRole` | 1 | — | — | — | **MUERTO** |
| **M3** | quitar `#assertWithinChain` de `deleteScopedRole` | 1 | — | — | — | **MUERTO** |
| **M4 a** | `scopes.detached` no purga los roles del owner | 3 | — | — | 3 | **MUERTO** (las dos caras del par) |
| **M4 b** | `detached` purga **de más** (todo owner del mismo tipo) | 2 (3) | — | — | — | **MUERTO**, pero no por el caso de M4 |
| **M6 a** | espejo con FKs sin `onDelete` (como antes de 3D) | **0** (4) | — | 1 | 1 | **MUERTO** en PG/MySQL (K11) |
| **M6 b** | `purgeRole` olvida los **vínculos** | **0** | — | **0** | — | **VIVO ≡** (lo tapa el CASCADE, §5.3) |
| **M6 c** | `purgeRole` olvida las **asignaciones** | 5 | — | — | — | **MUERTO**, por la FK RESTRICT (503), no por el puerto |
| **N2** | `updateScopedRole` vuelve a ignorar claves desconocidas | 1 | — | — | — | **MUERTO** |
| **D4** | `revoke` por slug quita solo el primer homónimo | 6 | — | — | — | **MUERTO** |

(1) En SQLite `lockCatalogForWrite` retorna sin hacer nada por diseño: el mutante es idéntico al original.
(2) No determinista: en la misma corrida murió el harness `openfga` y sobrevivió el `database` (el
perdedor recibió `SQLITE_BUSY`, que el caso acepta como 503 legítimo).
(3) Muere por el unitario `tests/catalog_cache.spec.ts` (`rolesOwnedBy`) y por la cara
`purgeRole: false`; **el caso del juez de M4 no lo observa** (el único rol que ese caso protege es
el del ANCESTRO, `orgA`; no hay rol local de un hermano ni de un descendiente en él).
(4) Documentado en el código: SQLite no expone las acciones de FK en `information_schema`.

### Fallos literales de los mutantes clave

**M1 a** (`src/catalog_cache.ts`), 4 muertos en sqlite / 6 en PG. Títulos: «CatalogView por uuid
(3A · A3) / 3B · B7 + 3D · M1: … roleVisible … lanza 422 E_AUTHZ_AMBIGUOUS_ROLE …» y, en `database`,
`database (sin listDenies)` y `openfga`, «un scopes.moved legítimo junta dos homónimos … TODA ruta
por slug falla cerrada con 422 …»:

```
AssertionError: expected undefined to equal 422        (tests/catalog_cache.spec.ts:753)
AssertionError: debería haber rechazado                (src/testing/contract.ts:316)
```

**M1 a+b** (la escalada V1 del auditor, reproducida como mutante):

```
authorization contract [database · 2.2] / effectivePermissions es EXACTAMENTE {p | authorize(p)}…
- Expected  - 1        Array [
+ Received  + 1        -   "docs:read",
                       +   "docs:write",   ]
AssertionError: exactamente {p | authorize(p)}: expected [ 'docs:write' ] to deeply equal [ 'docs:read' ]
```

**M2 a / M2 b** (PG y MySQL), el rojo exacto del auditor V2-A:

```
authorization contract [database · 2.2] / dos defineScopedRole del MISMO (slug, nivel)…
AssertionError: nunca dos ganadores (["fulfilled","fulfilled"]): expected 2 to be at most 1
```

**M1 b** (el manager compone por slug), que además mata los espías de coste («≤ 2 lecturas»):

```
AmbiguousRoleError: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles en esta cadena
  (…owner=organization|…; …owner=unit|…)
  at async AuthorizationManager.#rolesAlong (src/manager.ts:742:13)
  at async AuthorizationManager.effectivePermissions (src/manager.ts:705:25)
```

**M6 a** (PG), K11 con acciones de FK:

```
AssertionError: expected [ … ] to deeply equal [ … ]
    "column": "role_uuid",  "table": "authz_assignments",
-   "deleteRule": "NO ACTION",
+   "deleteRule": "RESTRICT",
```

**M6 c** (`purgeRole` olvida asignaciones) — muere, pero **por el motor**, no por la aserción del
puerto público:

```
AuthorizationBackendError: El backend de autorización 'database' no respondió (purgeRole.role.delete)
  stack: "SqliteError: delete from authz_roles where uuid = '…' - FOREIGN KEY constraint failed"
```

**M1 c2 / c3 / c4 — los tres vivos (antes del parche)**: suite entera verde (504 / 674 / 487) con
`grant(alice, { uuid: <rol local de OTRO tenant> }, miScope)` **escribiendo**, y con `hasRole` /
`listSubjects` por `{ uuid }` respondiendo por roles cuyo owner no está en la cadena.

---

## 3. El juez: conteos, anidamiento y alcance de los casos 2.2

`tests/contract_harness.spec.ts` **se ejecuta** en todos los modos y fija los cuatro números con
literales, no solo con aritmética:

| Registro | Literal en el harness | Ejecutado |
|---|---|---|
| `'2.2'` con `listDenies: true`, `purgeRole: false` | `assert.lengthOf(scoped, 78)` | ✅ |
| `'2.2'` con `purgeRole: true` | `assert.lengthOf(withPurge, scoped.length + 1)` ⇒ **79** | ✅ |
| `'2.2'` sin `listDenies` | `assert.lengthOf(withoutDenies, 70)` | ✅ |
| `'2.2'` con `injectableClock: true` | `assert.lengthOf(…, 82)` | ✅ |
| core / 2.0 / 2.1 | 36 / 49 / 66 | ✅ |

**Niveles anidados**: verificado por `for (const title of core) assert.include(full, title)`,
`full ⊂ primitives` y `primitives ⊂ scoped`. Un harness de 2.1 no puede saltarse nada de 2.0. ✅

**Asimetría del par `purgeRole`**: el harness la fija con nombre (los títulos «scopes.detached purga
también…» y el de la cara `false`, ausente en `withPurge`), no solo con el `+1`. ✅

**¿Algún caso 2.2 pasa con un driver que ignore la ambigüedad?** Sí: **todos menos uno**. La regla
de M1(a) cuelga de **un solo caso por harness** («un scopes.moved legítimo junta dos homónimos…»);
el resto de los casos `'2.2'` pasan con `roleVisible` eligiendo «el más cercano» (medido: el mutante
M1-a mata 3 casos del contrato — uno por harness — más el unitario del memo). Es exactamente la
misma fragilidad que N6 documenta para la regla de owner en `authorize`, y merece la misma nota
explícita: hoy no está dicha para la ambigüedad. Un driver de terceros con su propio `roleVisible`
puede pasar 77 de 78 casos con la escalada dentro.

---

## 4. Las diez desviaciones del informe 3D, una a una

✅ *tiene juez hoy* / 🟡 *observable pero sin caso, propongo cómo* / ❌ *promesa sin juez*

**1. El cerrojo va sobre la fila de versión, no sobre `authz_roles`.** ✅ **con juez.** El mutante
que lo quita mata 4 casos en PG y 4 en MySQL. El razonamiento («cuando el rol no existe no hay filas
que bloquear, y PostgreSQL no tiene gap locks») es correcto y el mutante lo confirma: sin cerrojo,
los dos `define` confirman. La desviación **mejora** la spec, no la esquiva.

**2. `updateScopedRole` no re-comprueba colisión.** ✅ Su premisa —que no puede cambiar slug, nivel
ni owner— la fija el caso de N2: el mutante «ignora claves desconocidas» muere. Se apoya en un test,
no en un comentario.

**3. El re-chequeo no resuelve el árbol; rechaza igual con 422 «reintenta».** 🟡 La rama juzgable
(global o ancestro) se ejercita; la rama «no juzgable ⇒ 422 genérico» no tiene caso que la distinga.
Coste de cerrarla: alto (haría falta un homónimo cuyo owner sea un descendiente aparecido justo en la
ventana). Riesgo: bajo — las dos ramas son fail-closed.

**4. `revoke` por slug quita TODOS los homónimos, sin 422.** ✅ El mutante «solo el primero» mata
**6 tests** en dos casos distintos del juez y en los dos drivers.

**5. Un driver de terceros sin `rolesInChain` compone por slug.** ❌ **promesa sin juez.** No hay
harness sin `rolesInChain`: ese camino no se ejecuta nunca en verde. Al forzarlo (mutante M1-b),
`effectivePermissions` **lanza 422** donde el contrato promete una lista. Es fail-closed, sí, pero
nadie fija que lo sea, ni que sea aceptable que un puerto legal deje de responder
`effectivePermissions` cuando hay un homónimo. Propuesta: registrar un harness con `rolesInChain`
escondido (un `Proxy`) y un caso «sin `rolesInChain`, con homónimo visible ⇒ 422
`E_AUTHZ_AMBIGUOUS_ROLE`, nunca los permisos del homónimo». Coste: bajo.

**6. `AuthzCatalogWriteEvent.actor` pasa a opcional.** 🟡 Hay caso para `role_purged` **con** actor
(`tests/manager.spec.ts:2078`, vía `deleteScopedRole`). El `role_purged` **sin** actor que emite
`scopes.detached` no lo afirma nadie: el caso M4 del juez no mira `hooks.onCatalogWrite`. Propuesta:
un aserto en `tests/manager.spec.ts` sobre el evento del `detached` sin actor. Coste: bajo.

**7. La purga de roles del owner no comparte transacción con `purgeScope`.** ❌ No es observable con
la infraestructura actual: haría falta hacer fallar un `purgeRole` a mitad de la lista (inyección de
fallo en el puerto). El argumento («un rol sin owner no es visible: una purga a medias no cambia
ninguna decisión») es sólido y coincide con el invariante 18, pero **no hay juez**. Para tenerlo:
un driver de prueba que falle en el N-ésimo `purgeRole` y un aserto de «lo que quedó no concede ni
es membresía». Coste: medio.

**8. El caso de la carrera afirma «nunca DOS», no «exactamente uno».** 🟡 **Es el punto débil.** Tres
hallazgos medidos: (a) forzado a serie, el caso **no caza** el mutante «sin re-chequeo» (674 passed
en PG): la parte en serie **no ejercita el re-chequeo transaccional** —ahí el 422 lo produce el
chequeo previo con el memo ya revalidado—, así que todo el poder de detección está en la carrera;
(b) `assert.oneOf(error?.status, [422, 503])` deja **vivo** un mutante que convierte la colisión en
un 503 (PG: 674 passed); (c) `isAtMost(ok.length, 1)` acepta **cero** ganadores y el fallback
reintenta, así que un «nadie puede escribir» pasaría en PG/MySQL, donde el README promete
«exactamente uno». Propuesta en §5.2.

**9. Tres casos reescritos (catalog_cache, D11, manager).** ✅ **suman.** El de `catalog_cache` mata
M1-a y M4-b; **D11 reescrito es el único que mata M1-c** (el `{uuid}` de otro nivel) — sin él ese
mutante también estaría vivo; la lista de identidades inválidas de `manager.spec.ts` cambia 3 objetos
legales por 5 mal formados y el mutante N2 la usa.

**10. `AuthzWriteEvent.role`: `string` ⇒ `RoleQuery`.** ❌ Ningún test afirma **qué** lleva
`event.role`. El caso B7 («el evento onWrite lleva actor en todas las escrituras») solo mira
`action` y `actor?.uuid`. Un `grant` por `{ uuid }` podría emitir `role: undefined` y la suite
entera seguiría verde. Impacto: auditoría, no acceso. Propuesta: extender el aserto de B7 a
`[e.action, e.actor?.uuid, e.role]` con las tres formas. Coste: bajo.

### Aserciones relajadas respecto a `f563465`

Revisadas una a una TODAS las líneas `-` del diff en `tests/` y `src/testing/`:

- `contract.ts` D11: sustituye «un `RoleQuery` objeto ⇒ 422» (que dejó de ser cierto con `{uuid}`)
  por 7 formas mal formadas × 4 rutas, las 3 formas legales apuntando al mismo rol, y el `{uuid}` de
  otro nivel ⇒ 422 `E_AUTHZ_ROLE_NOT_VISIBLE`. **Suma** (y es el único que mata M1-c).
- `catalog_cache.spec.ts`: sustituye «el más cercano gana» por «ambigüedad ⇒ 422 con uuids y owners
  en el mensaje» + `rolesOwnedBy`. **Suma** (mata dos mutantes distintos).
- `contract_harness.spec.ts`: `primitives.length + 7` ⇒ `+ 12` y `73/67/77` ⇒ `78/70/82`. Cambio de
  número, no de fuerza; los literales siguen ahí y ahora fija además los títulos del par asimétrico.
- `helpers/schema.ts`: las FKs **ganan** las acciones (se alinean con el stub); el `-` es la versión
  sin `onDelete`. **Suma** (K11 las compara ahora).
- `manager.spec.ts`: los tres «RoleQuery objeto ⇒ 422» desaparecen porque ahora son legales; los
  sustituyen cinco mal formados, incluida la mezcla `{uuid} + slug`. **Suma.**
- `migration_stub.spec.ts`: el título de K11 crece con «y ACCIONES de las claves ajenas». **Suma.**

**No he encontrado ninguna aserción debilitada.** La única pérdida real de fuerza no está en una
línea `-` sino en el nuevo `assert.oneOf(error?.status, [422, 503])` de la carrera (§4.8).

### Promesas nuevas del README contrastadas

| Promesa | Juez |
|---|---|
| «All **nine** writes accept `within`… the role's **owner** for the delegation API» | ✅ (3 mutantes M3) |
| «`{ uuid }`… the role must be **visible in that scope**, else 422 E_AUTHZ_ROLE_NOT_VISIBLE» | ❌ **sin juez para el owner** → parche |
| «`revoke` by slug removes the facts of **every** homonym» | ✅ (mutante D4) |
| «Two concurrent defineScopedRole… end with **exactly one** role and a **422** for the loser» | 🟡 el caso admite 0 ganadores y 503 (§4.8) |
| «…**or a defineScopedRole racing a syncAuthzCatalog**» | ❌ **esa carrera no existe en la suite**: solo la secuencial. Las tres únicas carreras del juez son dos `grant`, purga vs `grant` y dos `define` |
| «a driver that cannot purge roles says 500 without having touched anything» | ✅ (cara `purgeRole: false`, mutante M4-a) |
| «`purgeRole`… delete its links and the role row, **atomically**» | 🟡 los vínculos los borra el CASCADE, no el código (§5.3) |
| «`updateScopedRole`… passing one of those is 422 rather than a silent no-op» | ✅ (mutante N2) |
| «the owner rule in `authorize` hangs on **one case per harness**» | ✅ honesto y ahora escrito (N6). Falta decir lo mismo de la **ambigüedad** (§3) |

---

## 5. Huecos

### 5.1 🔴 `{ uuid }` no comprobaba el OWNER en ninguna ruta juzgada — CERRADO por el parche

**El hueco.** M1(c) de la spec dice: «el uuid debe ser visible en el scope o 422
`E_AUTHZ_ROLE_NOT_VISIBLE`»; el invariante 18 y el README dicen lo mismo. El código lo hace (en tres
sitios: `resolveRoleQuery`, `visibleRoleFor`, `hasRoleTargets`), pero **el único caso que lo observa
es el D11 reescrito, y solo por la mitad del NIVEL**. Quitar `isRoleVisibleWith` de esas tres
funciones deja la suite entera verde en sqlite, sqlite-file, PG y MySQL, y en los dos drivers.

**Por qué importa.** El uuid de un rol local **es público**: sale en `rolesInChain`, en el evento
`role_defined` y —desde 3D— en el propio mensaje del 422 de ambigüedad. Con esos tres mutantes,
`grant(holder, { uuid: <rol de otro tenant> }, miScope)` **escribe la fila**, y `hasRole` /
`listSubjects` por uuid responden por roles cuyo owner no está en la cadena. Es la misma clase de
agujero que V3 (la escalada por homónimo), por la puerta que 3D abrió para cerrarla.

**Dado → cuando → entonces** (el caso que faltaba):

- *dado* dos tenants con un rol local homónimo (`lead@unit` en orgA y en orgB), *cuando* se hace
  `grant(alice, { uuid: leadB }, unitA1)`, *entonces* 422 `E_AUTHZ_ROLE_NOT_VISIBLE` y **nada
  escrito** (`listRoles` no cambia, `authorize` sigue en false).
- *dado* lo mismo, *cuando* se pregunta `hasRole` / `listSubjects` por el uuid del rol del otro
  tenant, *entonces* false y [] (membresía: nunca throw); y por el uuid propio, true y [alice].
- *dado* un rol local de orgA asignado en unitA1, *cuando* la unit se mueve fuera de orgA, *entonces*
  `hasRole(alice, { uuid: leadA }, unitA1)` es false y `listSubjects({uuid}, unitA1)` es [] — la
  misma regla que ya se exigía por slug, decidida con el árbol de HOY.

**Parche**: `/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/tests-tester-fase-3d.patch`
(solo `src/testing/contract.ts`, +35/−3). Amplía dos casos `'2.2'` ya existentes en vez de crear
otros, así que **los conteos del juez no cambian** (78/79/70/82 intactos) y
`contract_harness.spec.ts` sigue verde.

Verificación del parche (rojo→verde):

| Mutante | Sin parche | Con parche |
|---|---|---|
| `resolveRoleQuery` sin owner (grant) | 504 passed (VIVO) | **3 muertos** (database, database sin listDenies, openfga) |
| `visibleRoleFor` sin owner (listSubjects) | 504 passed (VIVO) | **3 muertos** |
| `hasRoleTargets` sin owner (hasRole) | 504 passed (VIVO) | **3 muertos** («expected true to be false») |

Y en verde con el parche: sqlite **504**, sqlite-file **506**, PG **674**, MySQL **674**, typecheck
limpio.

**Nota adicional, no parcheada**: `rolesToRevoke` por `{ uuid }` **tampoco** comprueba el owner, y
esto es **deliberado** (desviación 4: quitar nunca concede, y el scope puede ya no existir para el
árbol). Está razonado, pero no lo dice ningún caso ni el README. Merece un comentario.

### 5.2 🟠 La carrera de M2: el caso no distingue «colisión» de «caída»

Tres cosas medidas, no supuestas:

1. Forzado a serie, el caso **no caza** el mutante «sin re-chequeo en la transacción»: 674 passed en
   PG. El 422 de la parte en serie lo produce el chequeo PREVIO (el memo del segundo manager
   revalida contra la versión y ya ve el rol). El re-chequeo transaccional **solo lo ejercita la
   carrera**.
2. `assert.oneOf(error?.status, [422, 503])` deja vivo el mutante «la colisión de la transacción
   lanza 503»: en PG, 674 passed. Un consumidor que reintente ante 503 y no ante 422 (o al revés)
   vería otro comportamiento y la suite no se entera.
3. `assert.isAtMost(ok.length, 1)` acepta **cero** ganadores, y el fallback («si no quedó ninguno,
   define otra vez») hace que un «nadie puede escribir» pase inadvertido en PG/MySQL, donde el
   README promete «exactamente uno».

**Propuesta** (no la meto en el parche para no arriesgar un flake que no puedo medir en CI): añadir
al juez la capacidad `serializedCatalogWrites` como par de `'2.2'`, que `tests/contract.spec.ts`
declara `true` en PG/MySQL y `false` en SQLite. Cara `true`: `assert.lengthOf(ok, 1)` **y** el
perdedor es 422 `E_AUTHZ_CATALOG_CONFLICT`. Cara `false`: lo de hoy («nunca dos»; un 503 es un fallo
de backend legítimo). Coste: bajo; hace determinista lo que hoy depende del scheduler y cierra el
mutante (2).

### 5.3 🟡 `purgeRole`: el «todo o nada» sigue siendo del ESQUEMA, no del código

M6 alineó las FKs y K11 las compara (mutante M6-a muerto en PG y MySQL). Pero:

- El mutante «`purgeRole` olvida los **vínculos**» sigue **vivo** — ahora por *equivalencia*: el
  `onDelete CASCADE` de `authz_role_permissions.role_uuid` los borra igual (comprobado también en
  SQLite: better-sqlite3 trae `foreign_keys = 1`). No hay diferencia observable, así que no es un
  defecto; pero **el código dejó de ser el garante**, y M6 nació justamente para que el «todo o nada»
  no dependiera de un accidente del esquema. Hoy depende del esquema **a propósito y con guard**
  (K11), que es mejor que antes; conviene que el CHANGELOG lo diga con esas palabras.
- El mutante «olvida las **asignaciones**» muere por la FK RESTRICT (503 del motor), **no** por la
  aserción del puerto público de M6(c). M6(c) refuerza el caso, pero el oráculo efectivo sigue
  siendo el motor.
- Consecuencia práctica: un consumidor con un esquema propio sin esas acciones (o con FKs
  desactivadas) tendría un `purgeRole` que deja vínculos huérfanos y **ningún test del paquete lo
  detectaría**. Propuesta barata: en el caso `purgeRole` `whenTrue`, contar las filas de
  `authz_role_permissions` del rol purgado antes/después (el juez ya escribe en `authz_*` con
  `localRole`/`linkByHand`, así que leerlas no rompe ninguna abstracción).

### 5.4 🟡 `scopes.detached` que purga de más

El caso de M4 protege el rol del **ancestro** (orgA) pero no crea ningún rol local de un **hermano**
ni de un **descendiente**. El mutante «purga todos los owners del mismo tipo» muere, pero por el
unitario del memo y por la cara `purgeRole: false`, no por el caso del juez. Un mutante que purgara
exactamente los descendientes (más plausible como bug: recorrer el subárbol) sería más difícil de
cazar. Propuesta: en el caso de M4, añadir un rol local cuyo owner sea `unitA1x` (descendiente del
scope desprendido) y afirmar qué le pasa — **y decidirlo primero**: hoy el paquete NO lo purga (el
consumidor purga nodo a nodo, invariante 7), pero eso no está escrito en ningún sitio y es justo la
pregunta de quien implemente el borrado en cascada de un tenant.

### 5.5 Otros huecos menores (detallados en §4)

- Desviación 5: el camino «driver sin `rolesInChain`» no se ejecuta nunca en verde ❌.
- Desviación 7: la purga parcial de roles no es observable ❌.
- Desviación 10: `AuthzWriteEvent.role` no lo afirma nadie ❌.
- Desviación 6: el `role_purged` sin actor del `detached` no lo afirma nadie 🟡.
- La ambigüedad (M1 a) cuelga de **un solo caso por harness**: merece la misma nota que N6 dio a la
  regla de owner en `authorize`, en `CLAUDE.md` y en §Custom drivers del README.
- No hay carrera `define` vs `sync` en la suite, y el README la promete.

---

## 6. Veredicto

**APTA CON CORRECCIONES** para cerrar la Fase 3.

Lo que sostiene el «apta»: las seis piezas bloqueantes están implementadas y **todas menos una mitad
tienen mutante muerto y reproducible**; los cuatro modos, el tope 3 y `:8101` están verdes con los
números que el informe declara; `sqlite-file` ×3 sin flakes; residuos 0; los conteos del juez están
fijados con literales y con títulos, no con aritmética; y las diez desviaciones son reales y están
razonadas — ninguna esconde un atajo, y la del cerrojo sobre la fila de versión es además **la
correcta**: el mutante demuestra que el cerrojo que pedía la spec no habría cerrado el caso.

Lo que exige las correcciones:

1. **Obligatoria**: aplicar `tests-tester-fase-3d.patch`. Sin él, la regla de owner por `{ uuid }`
   —la puerta que 3D abrió para cerrar V1/V3— **no tiene juez en ninguna de sus tres rutas**, y tres
   mutantes de seguridad viven en los cuatro motores y en los dos drivers.
2. **Obligatoria**: endurecer el caso de la carrera de M2 (§5.2) o, como mínimo, dejar de aceptar un
   503 indistinguible de la colisión. Hoy el README promete «exactamente uno y 422» y el juez admite
   «ninguno, o un 503».
3. **Recomendadas**: la nota de fragilidad de la ambigüedad (§3), el caso del driver sin
   `rolesInChain` (§4.5), el conteo de vínculos en `purgeRole` (§5.3) y el rol de un descendiente en
   el caso de M4 (§5.4).

Nada de esto es una objeción a la implementación de 3D: el código hace lo que dice. Es que, en tres
sitios, **lo que dice no lo demuestra nadie**.

---

## 7. Entregables

- Informe: `/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-3-verificacion-tester-3d.md`
- Parche: `/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/tests-tester-fase-3d.patch`
  (`git apply` sobre `56094ac`; toca solo `src/testing/contract.ts`).
- Sin commits. Árbol del worktree con el único cambio del parche.
