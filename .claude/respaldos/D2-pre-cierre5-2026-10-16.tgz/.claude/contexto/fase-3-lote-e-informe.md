# Fase 3 · Lote 3E — cierre final (auditor 3D + code-review + tester 3D)

> Sobre `56094ac` (rama `v2/fase-0`, sin commits). Rojo→verde por pieza, reproduciendo primero el
> escenario del auditor donde existía. Español en código y tests; README/CHANGELOG en inglés.
> **Sin `skip`/`only`.** Todos los errores nuevos con `status` + `code`.

## Resumen

| # | Pieza | Estado |
|---|---|---|
| **P1 a** | Un rol local nunca vive POR ENCIMA de su owner ⇒ 422 `E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER` (**regla mínima, corregida por el coordinador**) | ✅ |
| **P1 b** | El `sync` deja de abortar por un local homónimo: los globales ganan y se REPORTA (`shadowedByGlobal`) | ✅ |
| **P2** | `scopes.detached`: scope canónico, roles leídos de la BASE, subárbol con `descendantsOf` | ✅ |
| **P3** | `scopes.detached` con `actor`: policy de rango sobre TODOS los roles antes de tocar ninguno | ✅ |
| **P4** | `defineScopedRole` exige `purgeRole` ANTES de escribir; `openfga` deja de traerlo; **caso `whenFalse` del juez reescrito** | ✅ |
| **P5** | `diffAuthzCatalog` tolera la fila corrupta que existe para reportar | ✅ |
| **P6** | El `sync` revalida TODOS los roles contra el `assignableAt` nuevo y lo reporta | ✅ |
| **Q1** | Fuera el consejo «renombra uno de ellos»; la salida real documentada | ✅ |
| **Q2** | Los 422 no nombran identificadores de otro tenant | ✅ |
| **Q3** | `AmbiguousRoleError` exportado (+ test que vigila TODOS los errores) | ✅ |
| **Q4** | `listSubjects(role: RoleQuery)` en openfga; `purgeRole` opcional en el puerto | ✅ |
| **Q5** | `dialectOf` reconoce `better-sqlite3` en el cerrojo del catálogo | ✅ |
| **Q6** | `runCatalogDiff` no recalcula el diff y las líneas informativas van bajo su epígrafe | ✅ |
| **Q7** | El evento lleva el rol RESUELTO (`roles: CatalogRoleRef[]`), no la pregunta cruda | ✅ |
| **Q8** | CHANGELOG «Lot 3E», `CLAUDE.md` (invariantes 15/18, conteos, aviso de fragilidad), README | ✅ |
| **R1** | Parche del tester (`tests-tester-fase-3d.patch`) aplicado | ✅ |
| **R2** | Par de capacidad `serializedCatalogWrites` + re-chequeo transaccional ejercitado | ✅ |
| **R3** | `effectivePermissions` sin `rolesInChain` ya no lanza 422 (bug real) | ✅ |
| **R4** | Caso que fija la forma resuelta del evento | ✅ (con Q7) |
| **R5** | Carrera `defineScopedRole` × `syncAuthzCatalog` escrita | ✅ |
| **R6** | Nota de fragilidad (ambigüedad de M1) en `CLAUDE.md` y README | ✅ |
| **R7** | `purgeRole`: conteo de vínculos por el puerto; M4 con un rol de un DESCENDIENTE | ⚠️ (el conteo documenta, el `CASCADE` garantiza — corregido en 3F · U2) |

Suite final: **510** (`npm test`) · **512** (`test:sqlite-file`) · **677** (`test:pg` y `test:mysql`), todas con
`OPENFGA_TEST_URL=:8101`; y **510** contra el OpenFGA con tope 3 (`:8103`). Detalle abajo.

---

## Pieza por pieza

### P5 · `diffAuthzCatalog` moría con la fila que existe para reportar

**Rojo** (script propio, PG): con `authz_permissions.assignable_at = 'no-es-json'`

```
  diffAuthzCatalog -> 500 E_AUTHZ_INTERNAL: authz_permissions.assignable_at del permiso 'docs:read' no es una lista JSON no vacía de tipos de scope válidos (llegó no-es-json); corrige
```

**Verde**

```
  diff OK -> [{"permission":"docs:read","expected":null,"actual":null,"corrupt":true}]
```

El diff usaba `parseAssignableAt` (500) mientras el sync ya la trataba como distinta con
`storedAssignableAt`: el comando que iba a repararla moría antes de decir qué reparar. Ahora el diff
lee con un parser tolerante, la cuenta como diferencia (`corrupt: true`) y `formatCatalogDiff` la
nombra; leerla para DECIDIR sigue siendo 500 (el memo). Caso en `tests/manager.spec.ts` (grupo
«catálogo»), que además fija Q6.

### Q5 · el cortocircuito de SQLite en `lockCatalogForWrite` no se disparaba nunca

**Rojo** (script propio): `dialectOf(trx) = "better-sqlite3"` · `¿startsWith("sqlite")? false`.

`isSqliteDialect(connection)` en `src/drivers/sql_expiry.ts` reconoce `sqlite*` y `better-sqlite3`.
Caso en `tests/catalog_cache.spec.ts`: en SQLite `withAuthzCatalogWrite` **no** emite el `select … from
authz_catalog_version`; en PG/MySQL emite exactamente uno y lleva `for update` (verde en los dos).

### Q6 · `runCatalogDiff` recalculaba el diff entero y colgaba sus líneas del catálogo equivocado

`scoped` sale del primer diff que ya se calcula (una ronda de consultas menos por ejecución) y las
líneas van bajo `roles locales (no son deriva del config):`. El caso comprueba con DOS catálogos que
la línea anterior al epígrafe es la última diferencia del catálogo #2.

### Q3 · `AmbiguousRoleError` no era exportable

Exportado en `index.ts`. En vez de una lista a mano, el test nuevo de `tests/purity.spec.ts` compara
`export class …Error` de `src/errors.ts` con el bloque de exportación de `index.ts`: cualquier error
nuevo entra o el test falla. Verificado rojo quitando la exportación:

```
ℹ AssertionError: errores de src/errors.ts que index.ts no exporta: expected [ 'AmbiguousRoleError' ] to deeply equal []
```

### Q4 · firma de `listSubjects` y `purgeRole` opcional

`OpenFgaAuthorizationDriver.listSubjects(role: RoleQuery, …)`. `AuthorizationDriver.purgeRole?` es
**opcional**: como obligatorio rompía al compilar a todo driver de terceros de 2.0/2.1, y el manager
ya lo trataba con `#optional`. Esto habilita P4 (abajo): **no implementarlo es la forma de decir «no
sé purgar»**.

### Q1 + Q2 · mensajes 422

- `AmbiguousRoleError` ya no aconseja «renombra uno de ellos» (la API prohíbe renombrar): dice que
  `{ uuid }` sigue funcionando y que para deshacer la ambigüedad hay que PURGAR uno
  (`deleteScopedRole` con rank suficiente, o `driver().purgeRole`). Igual la línea del diff.
- `visibleRoleOrFail` ya no imprime los owners de los homónimos: si ninguno es visible desde el scope
  preguntado, todos son de OTRO árbol. La ruta `{ uuid }` tampoco devuelve slug ni owner de un rol
  ajeno (era una sonda: pruebo uuids y aprendo el catálogo de otro tenant); cuando el owner SÍ está en
  la cadena, el rol es del llamante y se nombra entero. `AMBIGUOUS_ROLE` solo lista los visibles en la
  cadena preguntada, que el llamante ya puede ver.

Reproducción del auditor (`a6_varios.ts` §i), antes y después, más abajo.

### P1 a · un rol local nunca vive POR ENCIMA de su owner

**Rojo** (`a1_ambiguo.ts` §1):

```
  ...y "operador@organization" (nivel POR ENCIMA de su owner) = {"uuid":"…","slug":"operador","scopeType":"organization","owner":"unit|…","rank":2}
```

**Verde**: 422 `E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER` (error nuevo, exportado).

> **Nota**: la primera implementación siguió la decisión 1 al pie de la letra
> (`scopeType ∈ {owner.type} ∪ tipos del subárbol`, y sin `descendantsOf` solo el nivel del owner). Eso
> rompía el caso común —una organization definiendo `lead@unit` con el stub publicado, que no declara
> `descendantsOf`— y lo reporté; **el coordinador corrigió su decisión** y esta es la regla final.

Regla **mínima**, decidida con la cadena del owner que ya está resuelta (coste cero, sin pedirle nada
al consumidor):

| `spec.scopeType` | Resultado |
|---|---|
| el nivel del owner | ✅ |
| el nivel de un **ancestro** del owner (`app` incluida, que está en toda cadena) | ❌ 422 `E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER` — **es la mina** |
| cualquier otro tipo | ✅ (se presume descendiente) |
| …y con `scopes.descendantsOf` declarado | se ENDURECE: el tipo tiene que aparecer de verdad bajo el owner en el árbol de HOY |

Se aplica en `defineScopedRole` y en `updateScopedRole` (un rol con nivel imposible escrito a mano o
antes de 3E no se perpetúa: lo que toca es purgarlo, y eso sí se puede). Los tres escenarios que pidió
el coordinador están como casos:

- `operador@organization` con owner una unit ⇒ **422** (mina cerrada), también **sin** `descendantsOf`.
- `lead@unit` con owner una organization **sin** `descendantsOf` ⇒ **aceptado** (caso común recuperado;
  el caso además comprueba que el rol concede de verdad en la unit).
- `x@app` con owner una organization ⇒ **422** — muere aún antes, en `#parseScopedRoleSpec`
  (`E_AUTHZ_INVALID_IDENTITY`: la raíz no cuelga de ningún owner); si llegara al chequeo de nivel sería
  un ancestro, porque `app` está en todas las cadenas.
- Y el endurecimiento: `fantasma@team` con owner una organization **con** `descendantsOf` ⇒ 422 (no hay
  ningún `team` bajo ella).

Ya **no hay ningún requisito de declarar `descendantsOf` para delegar hacia abajo**: el stub, el README
y `CLAUDE.md` lo dicen así (lo que sí cambia con `descendantsOf` es la purga del subárbol en
`scopes.detached`, P2).

### P1 b · el `sync` deja de abortar por un rol local

**Rojo** (`a1_ambiguo.ts` §1):

```
  la PLATAFORMA sincroniza un global "admin@unit" (deploy) -> 422 E_AUTHZ_CATALOG_CONFLICT: … colisiona con un rol LOCAL …
  ¿el resto del deploy entró? false
```

**Verde**:

```
  la PLATAFORMA sincroniza un global "admin@unit" (deploy) = {"shadowedByGlobal":[{"uuid":"…","slug":"admin","scopeType":"unit","owner":"unit|…"}],"assignableAtViolations":[]}
  ¿el resto del deploy entró? true
```

`syncAuthzCatalog` devuelve **`CatalogSyncReport`** (breaking: era `void`) y `syncCatalogs` devuelve
`{ count, ...reporte }` (breaking: era `number`); `authz:catalog:sync` los imprime como *warning* y
`authz:catalog:diff` los lista como deriva (`shadowedByGlobal`, exit ≠ 0). `defineScopedRole` **sigue
rechazando** colisiones: un tenant no puede crear ambigüedad a propósito.

### P6 · estrechar `assignableAt` ya no rompe en silencio

El sync revalida TODOS los vínculos vivos de los permisos cuyo `assignableAt` declara el spec —los
roles del spec ya se validan con 422 antes de escribir— y reporta los que la restricción nueva no
admite (`assignableAtViolations`, misma política que P1 b: **reportar y seguir**, nunca borrar: lo
asignado sigue concediendo, invariante 1). El diff los anuncia antes del deploy. Caso propio con un
rol LOCAL y un global de otro catálogo.

### P2 · `scopes.detached` cumple la promesa del invariante 18

Tres agujeros, los tres silenciosos:

| Antes (`a3_detached.ts`) | Ahora |
|---|---|
| §b `filas de "alias" tras el detached por alias: 1` (los hechos se canonizaban, los roles no) | `0` |
| §iv (`a6_varios.ts`) `fila de "tardio" tras el detached del proceso con memo de ventana: 1` | `0` |
| §c `filas de "nieto" (owner U2): 1` | `0` **con `descendantsOf` declarado**; sin él sigue siendo 1 y la promesa está acotada por escrito |

Implementación: `canonicalScope` UNA vez en `detached` y ese `chain[0]` va a la purga de roles **y** a
la de hechos; los roles se leen de la BASE con `readRolesOwnedBy(ownerKeys)` (nuevo en
`catalog_cache.ts`, con sus permisos, por lotes de 500 owners); con `scopes.descendantsOf` los owners
incluyen todo el subárbol. La ventana residual (un `define` confirmado entre el SELECT y la purga) está
documentada en el código: no la cierra ningún cerrojo razonable —`purgeRole` abre su propia transacción
con el cerrojo del catálogo— y es una carrera que el tenant pierde igual.

### P3 · `scopes.detached` con `actor` lleva policy de rango

**Rojo** (`a3_detached.ts` §a):

```
  subU1: deleteScopedRole(caro) -> 422 E_AUTHZ_RANK_EXCEEDED …
  subU1: scopes.detached(U1) [misma within] = undefined
  filas de "caro" tras el detached: 0
```

**Verde**: el `detached` responde el mismo 422 y `filas de "caro" … : 1`. Se comprueban TODOS los roles
a purgar antes de tocar ninguno. El rango se mide en la cadena ACTUAL del scope: con `actor` y un scope
que el árbol ya no conoce es 422 `E_AUTHZ_UNKNOWN_SCOPE` con receta («notifica el detached ANTES de
borrar la fila, o hazlo sin actor»), para que notificar tarde no sea la forma de saltarse la policy.
Sin `actor` se comporta como antes (operación de plataforma), y el README lo dice.

### P4 · el callejón sin salida de `openfga`, y el caso del juez que lo fijaba

`purgeRole` era un método que existía y lanzaba 500 al llamarlo, así que el manager no podía protegerte:
`defineScopedRole` creaba tan tranquilo un rol local que **nada** podría borrar nunca —`deleteScopedRole`
y `scopes.detached` de ese scope quedaban muertos para siempre, hechos incluidos—.

- `OpenFgaAuthorizationDriver` **ya no implementa** `purgeRole` (con Q4 es opcional; el comentario de
  clase explica por qué y hasta cuándo).
- `defineScopedRole` hace `#optional(driver, 'purgeRole', 'defineScopedRole', …)` **antes de escribir
  nada**: 500 `E_AUTHZ_UNSUPPORTED` nombrando que los roles por scope llegan a `openfga` con el modo
  `facts` (3b). `UnsupportedOperationError` admite ahora un `hint`.

**Reescritura del caso del juez (lo que el spec exige explícitamente).** El `whenFalse` del par
`purgeRole` decía: *«sin purgeRole … `scopes.detached` responde 500 sin tocar nada»* y ahí se quedaba —
fijaba como comportamiento esperado un scope que jamás podría purgarse. El caso nuevo juzga lo
contrario, en cinco tramos:

1. `driver.purgeRole` es `undefined` (`purgeRole: false` ⇒ el puerto no lo trae).
2. `defineScopedRole` ⇒ 500 **antes de escribir** (0 filas): ese estado no se crea.
3. Si llega por otra vía (catálogo escrito a mano), se LEE con normalidad y `deleteScopedRole` /
   `scopes.detached` lo dicen con 500 sin tocar nada (uuid mal formado sigue siendo 422).
4. **La salida, demostrada**: la plataforma borra la fila del rol (el catálogo es suyo y es SQL) y el
   scope se purga con normalidad. Nadie queda encerrado.
5. Un scope sin roles locales se purga siempre.

Como consecuencia, la **API de delegación entera** (los tres casos `'2.2'` de `defineScopedRole`,
`effectivePermissions` por uuid y la carrera de dos `define`) pasa a colgar del par `purgeRole`: a un
driver que no sabe purgar no se le juzga una policy que no puede tener. Conteos actualizados en
`tests/contract_harness.spec.ts` y en `CLAUDE.md`: **75** casos en `'2.2'`, **79** con `purgeRole: true`
(el par pasa de asimétrico +1 a +4), 79 con reloj, 70 sin `listDenies`.

### Q7 + R4 · el evento habla del rol resuelto

`AuthzWriteEvent.role` (`RoleQuery`) → **`roles: CatalogRoleRef[]`** (breaking). Es una lista porque un
`revoke` por slug quita los hechos de TODOS los homónimos del scope; un `grant` resuelve exactamente
uno. Se resuelve **best-effort** —nunca cambia el resultado de la escritura, solo enriquece el evento— y
**solo si hay `hooks.onWrite`**: sin hook no cuesta ni una consulta. Ausente si no se puede resolver.
El caso B7 de `manager.spec` lo fija (incluida la igualdad entre preguntar por slug y por `{ uuid }`, y
que un rol desconocido no notifica nada). Los `role_purged` de `detached` siguen llevando el `actor`
cuando lo hay, y ahora cada uno lleva **su** owner (el del rol, no el scope notificado).

### R1 · parche del tester

`git apply .claude/contexto/tests-tester-fase-3d.patch` (solo `src/testing/contract.ts`, +48/−9 con el
contexto ya movido). Cierra el hueco 🔴: la comprobación de owner en la ruta `{ uuid }` no la observaba
ningún caso. Verde en `database`, `database (árbol SQL)`, `openfga` y `openfga (árbol SQL)`.

### R2 · la carrera de M2, endurecida

Par de capacidad nuevo **`serializedCatalogWrites`** (`true` en PG/MySQL, `false` en SQLite y en los
harness que no pueden observarlo):

- `true`: **exactamente un ganador** y 422 `E_AUTHZ_CATALOG_CONFLICT` exacto para el perdedor (mata el
  mutante que convierte la colisión en 503).
- `false`: la forma laxa de hoy (nunca dos, el perdedor no escribe; su transacción puede morir con
  `SQLITE_BUSY`).

Y la parte «en serie» ejercita ahora el **re-chequeo transaccional**: se inserta el homónimo **sin subir
la versión del catálogo** (`insertRoleUnseen`), que es exactamente lo que ve un escritor cuya foto se
tomó antes de que otro proceso confirmara; el chequeo barato contra el memo lo deja pasar y solo la
relectura de la BASE dentro de la transacción puede pararlo.

### R3 · bug real: `effectivePermissions` lanzaba 422 donde promete una lista

Con un driver sin `rolesInChain` (opcional en el puerto), el manager compone desde `listRoles` (slugs) y
usaba `roleVisible`, que desde M1 **lanza** con dos homónimos visibles. Nuevo `#rolesFromSlugs`: con
homónimos visibles pregunta al driver por `{ uuid }` cuál tiene de verdad — ni elige (sería la escalada
V1) ni adivina. Verificado rojo restaurando `roleVisible`:

```
ℹ AmbiguousRoleError: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles en esta cadena …
```

### R5 · la carrera `define` × `sync` que el README prometía

Escrita en `manager.spec`. Con P1 b tiene **dos** finales legítimos y los dos son ruidosos: si el sync
confirma primero, el define choca con 422; si confirma primero el define, el sync escribe el global
igual y **reporta** al local ensombrecido. Lo que no puede pasar es un local del que nadie hable. El
README dice ahora exactamente eso (antes prometía «exactamente un rol y 422 para el perdedor», que ya no
es cierto para esta carrera).

### R6 · nota de fragilidad

En `CLAUDE.md` (bloque de `contract_harness`) y en el README (§Scoped roles, «a note for driver
authors»): la regla de owner en `authorize` **y** la de ambigüedad de `RoleQuery` cuelgan cada una de UN
solo caso por harness; un driver de terceros con su propio `roleVisible` pasa 78 de 79 con la escalada
dentro.

### R7 · `purgeRole` y el «todo o nada»

- El conteo de **vínculos** se afirma por el catálogo SQL (`linksOf`) antes y después de `purgeRole`, y
  en los dos roles que purga `scopes.detached`.
  **CORRECCIÓN (3F · U2, tester 3E · R7)**: esta frase decía «no por el `CASCADE` del esquema» y era
  FALSA. El mutante que hace que `purgeRole` se olvide de los vínculos pasa la suite entera en SQLite,
  PostgreSQL y MySQL: `authz_role_permissions.role_uuid` es `ON DELETE CASCADE` (y `authz_assignments`
  `ON DELETE RESTRICT`), así que el motor los borra igual y `linksOf` da 0 en los dos mundos — mutante
  EQUIVALENTE bajo este esquema. Quien garantiza el «todo o nada» es el ESQUEMA, vigilado por K11; el
  conteo lo documenta sin poder falsarlo. Un driver de terceros sobre un esquema sin esas acciones tiene
  que borrar los vínculos él. Corregido en README, CHANGELOG y el comentario del caso del juez.
- El caso de M4 cubre además un rol local cuyo owner es un **descendiente** del scope notificado.

---

## Verificación

### Suites

| Comando | Resultado |
|---|---|
| `npm test` | 408 passed |
| `OPENFGA_TEST_URL=:8101 npm test` | **510 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:sqlite-file` | **512 passed** |
| `TEST_PG_URL=… OPENFGA_TEST_URL=:8101 npm run test:pg` | **677 passed** |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` | **677 passed** |
| `OPENFGA_TEST_URL=:8103 npm test` (tope 3, contenedor `openfga-tiny`) | **510 passed** · contenedor eliminado |
| `npm run build` (purity + typecheck + tsc + stubs) | ✅ |

### Los tres scripts del auditor, re-ejecutados TAL CUAL (PG, `sqlScopeTree`/`memoryScopeTree` según el script)

Con la regla mínima de P1 a los tres corren enteros **sin tocar nada**: ningún manager modificado.
(Solo `a3_detached.ts` §c necesita además una copia con `descendantsOf` para enseñar la purga del
subárbol, porque esa parte de la promesa sí depende de declararlo — es la acotación de la decisión 4.)

#### `a1_ambiguo.ts` (tal cual)

```
=== (1) squatting DESDE ABAJO: la unit ocupa el slug de su org y del global ===
  subU9 rank efectivo: 9 · permisos: [ 'docs:read' ]
  subU9 define "admin@unit" owner=unitU9 (squat) = {"uuid":"01a04e64-b1bd-74c6-b686-3895fdf47f50","slug":"admin","scopeType":"unit","owner":"unit|01a04e64-b1ab-7078-a32a-774bcae15deb","rank":2}
  ...y "operador@organization" (nivel POR ENCIMA de su owner) -> 422 E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER: defineScopedRole: un rol local de nivel 'organization' está POR ENCIMA de su owner unit:01a04e64-b1ab-7078-a32a-774bcae1
  orgA (dueño del árbol) intenta SU "admin@unit" -> 422 E_AUTHZ_CATALOG_CONFLICT: Ya existe un rol 'admin' de nivel 'unit' visible desde organization:01a04e64-b1ab-7078-a32a-6a3c02597b19: es un descendi
  la PLATAFORMA sincroniza un global "admin@unit" (deploy) = {"shadowedByGlobal":[{"uuid":"01a04e64-b1bd-74c6-b686-3895fdf47f50","slug":"admin","scopeType":"unit","owner":"unit|01a04e64-b1ab-7078-a32a-774bcae15deb"}],"assignableAtViolations":[]}
  ¿el resto del deploy entró? true
  roles del deploy en la base: org-admin@g org-jefe@g org-pobre@g jefe-unit@local admin@local admin@g nuevo-rol-del-deploy@g

=== (2) 422 permanente: homónimo de rank ALTO que aterriza en el árbol de A ===
  leadB rank 89 (owner unit U1, tenant B) ·  leadA rank 9 (owner org A)
  la plataforma transfiere U1 a A
  A: grant(alguien, "lead", U1) [su propio slug] -> 422 E_AUTHZ_AMBIGUOUS_ROLE: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles en esta cadena (01a04e64-b1c8-7614-8279-ae2db8f3328a owner=u
  A: hasRole(alguien, lead@unit, U1) -> 422 E_AUTHZ_AMBIGUOUS_ROLE: …
  A: deleteScopedRole(leadB) [limpiar el intruso] -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 10 en el owner del rol) no puede tocar 'lead' (rank 89): hace falta rank mayor que el del rol.
  A: define "lead@unit" de repuesto en orgA -> 422 E_AUTHZ_CATALOG_CONFLICT: … es un descendie
  A: updateScopedRole(leadA) para renombrar el suyo -> 422 E_AUTHZ_INVALID_IDENTITY: Cambios de rol local inválidos: 'slug' no se puede cambiar …
  A: grant por {uuid} (la salida documentada) = {"existed":false,"expiresAt":null}
  authorize(alguien, docs:read, U1) con el slug ambiguo = true

=== (3) ¿se puede TAPAR un rol global creando ambigüedad? ===
  define local "admin@unit" en orgA (hay global admin@unit? ver arriba) -> 422 E_AUTHZ_CATALOG_CONFLICT: … es global (cat
  (inyectado a mano un GLOBAL lead@unit junto a los locales: estado heredado)
  grant(alguien, "lead", U9) con global+local -> 422 E_AUTHZ_AMBIGUOUS_ROLE: … hay 2 roles visibles en esta cadena (01a04e64-b1d7-7202-84ac-c0321f1ccf7c owner=g
  authorize(alguien, docs:read, U9) = false
  grant(alguien, "lead", orgA)  [nivel organization] -> 422 E_AUTHZ_UNKNOWN_ROLE: Rol 'lead' no existe en el catálogo para el nivel 'organization'

=== (4) authz:catalog:diff ===
  inSync: false
   | catálogo #1: DIFERENCIAS
   |   rol AMBIGUO (dos visibles en la misma cadena): admin@unit owners=global, unit|01a04e64-… — toda ruta por slug ahí responde 422 E_AUTHZ_AMBIGUOUS_ROLE; se opera por { uuid } y se deshace PURGANDO uno (un rol local no se renombra)
   |   rol AMBIGUO (dos visibles en la misma cadena): lead@unit owners=global, organization|01a04e64-…, unit|01a04e64-… — …
   | roles locales (no son deriva del config):
   |   rol local (propio de unit|01a04e64-…): jefe-unit@unit
   |   rol local (propio de unit|01a04e64-…): admin@unit
   |   rol local (propio de unit|01a04e64-…): lead@unit
   |   rol local (propio de organization|01a04e64-…): lead@unit
```

*(La mina de A1 está cerrada por los dos lados: el nivel imposible es 422 —también sin `descendantsOf`—
y el deploy de la plataforma entra entero. El «422 permanente» de A5 sigue siendo 422 —es la decisión de
seguridad de M1— pero el mensaje ya no aconseja lo imposible y el README documenta la salida real. Nótese
que §1 vuelve a mostrar el `E_AUTHZ_CATALOG_CONFLICT` «es un descendiente» del auditor: `defineScopedRole`
sigue rechazando colisiones, que es lo decidido; lo que ya no ocurre es que el DEPLOY caiga con ellas.)*

#### `a3_detached.ts` (tal cual)

```
=== (a) rank: el sub-admin de la unit destruye el rol del org-admin por la vía del árbol ===
  rank del sub-admin en U1: 5 · rol a destruir: caro (rank 40)
  subU1: deleteScopedRole(caro) -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 5 en el owner del rol) no puede tocar 'caro' (rank 40): hace falta rank mayor que el del rol.
  subU1: scopes.detached(U1) [misma within] -> 422 E_AUTHZ_RANK_EXCEEDED: El actor (rank 5 en el owner del rol) no puede tocar 'caro' (rank 40): hace falta rank mayor que el del rol.
  filas de "caro" tras el detached: 1
  filas de "chico" tras el detached: 1
  ¿U1 sigue en el árbol del consumidor? true

=== (c) roles de un DESCENDIENTE del scope detached ===
  scopes.detached(U1) con un rol owner=U2 (hijo de U1) = undefined
  filas de "nieto" (owner U2): 1
  ¿U2 sigue en el árbol? false
  deleteScopedRole(nieto) con el owner ya fuera del árbol -> 422 E_AUTHZ_UNKNOWN_SCOPE: El scope unit:01a04e5b-d9e8-… no existe para el resolutor de la cadena (deleteScopedRole). No se escribe sobr
  sync global "nieto@unit" con el local huérfano vivo = {"shadowedByGlobal":[{"uuid":"01a04e5b-da09-…","slug":"nieto","scopeType":"unit","owner":"unit|01a04e5b-d9e8-…"}],"ass

=== (b) alias del uuid del scope (PG: tipo uuid funde el guion) ===
  scope canónico: 01a04e5b-da18-749a-8e10-1a4282a86cc2 · alias: 01a04e5bda18749a8e101a4282a86cc2
  ¿el árbol resuelve el alias? true · chain[0]: 01a04e5b-da18-749a-8e10-1a4282a86cc2
  scopes.detached(alias sin guiones) = undefined
  filas de "alias" tras el detached por alias: 0
  asignaciones del holder tras el detached por alias: 0
  deleteScopedRole(alias) con el owner ya borrado -> 422 E_AUTHZ_UNKNOWN_ROLE: Rol con uuid '01a04e5b-da1b-…' no existe en el catálogo
  fila del rol "alias": 0
  sync global "alias@unit" = {"shadowedByGlobal":[],"assignableAtViolations":[]}
```

**(a)** cerrado (era `= undefined` y `filas de "caro": 0`). **(b)** cerrado (era `filas … : 1` y el sync
422 para siempre). **(c)** sigue abierto **sin `descendantsOf`** — es la acotación por escrito de la
decisión 4 — y con él se cierra:

#### `a3_detached_3e.ts` (mismo script + `descendantsOf`, único que sigue haciendo falta)

```
=== (c) roles de un DESCENDIENTE del scope detached ===
  scopes.detached(U1) con un rol owner=U2 (hijo de U1) = undefined
  filas de "nieto" (owner U2): 0
  ¿U2 sigue en el árbol? false
  deleteScopedRole(nieto) con el owner ya fuera del árbol -> 422 E_AUTHZ_UNKNOWN_ROLE: Rol con uuid '01a04e5c-1fd0-…' no existe en el catálogo
  sync global "nieto@unit" con el local huérfano vivo = {"shadowedByGlobal":[],"assignableAtViolations":[]}
```

#### `a6_varios.ts` (tal cual)

```
=== (i) fuga de identificadores en los mensajes 422 ===
  grant de un slug que solo existe en B, desde A:
    E_AUTHZ_ROLE_NOT_VISIBLE · El rol 'secreto-de-b' (nivel 'unit') no existe en unit:01a04e64-d6e7-7108-a9ee-20fd974a3b4c: hay 1 rol con ese nombre en el catálogo, local a un scope que no está en la cadena de este. Un rol local solo se asigna en su owner o en sus descendientes.
  (orgB = organization|01a04e64-d6e7-7108-a9ee-1e349b1f5484 )

=== (ii)/(iii) dos homónimos asignados en el mismo scope ===
  listRoles(holder, U1): [ 'lead' ]
  authorize docs:read = true · billing:write = true
  effectivePermissions = [ 'billing:write', 'docs:read' ]

=== (iv) M4 con memo de ventana: ¿purga lo que otro proceso acaba de definir? ===
  hijo: RESULT {"mode":"define","ok":true,"uuid":"01a04e64-d900-70db-b40e-546d5cd063c7","owner":"unit|01a04e64-d774-7448-a6c5-51ea6a88327e"}
  fila de "tardio" tras el detached del proceso con memo de ventana: 0
```

**(i)** cerrado: el 422 ya no imprime `organization|01a04e64-…-1e349b1f5484` (la clave de scope del
tenant B, que sigue apareciendo en la línea siguiente solo porque el script la imprime él). **(iv)**
cerrado (era `1`). **(ii)/(iii)** sin cambios: con la ambigüedad viva, `authorize`,
`effectivePermissions` y `listRoles` siguen respondiendo y coinciden entre sí.

### Comprobaciones rojo→verde hechas a mano (mutantes)

Para no dejar casos vacuos, verifiqué que cada pieza nueva falla sin su arreglo:

| Cambio revertido | Caso que se pone rojo |
|---|---|
| `#purgeRolesOwnedBy(driver, child, …)` (sin canonizar) | `el alias ya no deja vivo el rol del owner` |
| `descendantsOf` ignorado en la purga | `ni el del descendiente (descendantsOf declarado)` |
| roles leídos del memo en vez de la base | `la purga lee la base, no la foto` |
| `roleVisible` en `#rolesFromSlugs` | `AmbiguousRoleError` en `effectivePermissions` |
| `AmbiguousRoleError` fuera de `index.ts` | el test de superficie pública |
| el rechazo del nivel de un ANCESTRO en `#assertLevelUnderOwner` | la mina de A1 (con y sin `descendantsOf`) |

---

## Ficheros tocados

`src/manager.ts` · `src/catalog.ts` · `src/catalog_cache.ts` · `src/types.ts` · `src/errors.ts` ·
`src/drivers/database_driver.ts` · `src/drivers/openfga_driver.ts` · `src/drivers/sql_expiry.ts` ·
`src/testing/contract.ts` · `index.ts` · `commands/authz_catalog_sync.ts` ·
`stubs/config/authorization.stub` · `tests/manager.spec.ts` · `tests/catalog_cache.spec.ts` ·
`tests/purity.spec.ts` · `tests/contract.spec.ts` · `tests/contract_harness.spec.ts` ·
`README.md` · `CHANGELOG.md` · `CLAUDE.md`. **Sin commits.**

## Lo que queda dicho, no arreglado

1. **`descendantsOf` sigue cambiando dos cosas** (ya no la definición de roles hacia abajo, corregido):
   `scopes.detached` purga el SUBÁRBOL solo si está declarado —sin él la promesa del invariante 18 está
   acotada al scope exacto y hay que notificar nodo a nodo— y el nivel de un rol local se endurece al
   árbol de hoy. Está en el stub, el README y `CLAUDE.md`.
2. **Con `descendantsOf` declarado, `updateScopedRole` revalida el nivel contra el árbol de HOY**: un
   owner que se quedó sin descendientes de ese nivel no puede editar su rol (sí purgarlo). Sin
   `descendantsOf` no aplica. Es coherente con «el árbol de hoy decide», pero es una arista nueva.
3. **La ventana entre el SELECT de `readRolesOwnedBy` y `purgeRole`** (un `define` confirmado justo en
   medio) no la cierra ningún cerrojo sin arriesgar un abrazo mortal con pool 1. Documentada en el
   código; la recoge la siguiente notificación o `authz:reconcile` (3b).
4. **`assignableAtViolations` no se repara sola**: `authz:catalog:diff` seguirá saliendo con código ≠ 0
   hasta que el operador quite el vínculo o amplíe el `assignableAt`. Es deliberado (reportar y seguir,
   nunca borrar lo asignado), pero significa un CI rojo que el sync no arregla.
