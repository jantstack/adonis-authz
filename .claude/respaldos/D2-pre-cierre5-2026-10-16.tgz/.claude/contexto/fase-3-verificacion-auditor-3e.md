# Fase 3 · Lote 3E — Auditor de seguridad, verificación de cierre (delta `56094ac..5b4f3c2`)

> Contra el código real en `v2/fase-0`, HEAD `5b4f3c2`. **No se tocó ni un archivo del repo.**
> Reproducciones nuevas en `…/scratchpad/v8/`: `n1_nivel.ts`, `n2_p4.ts`, `n3_shadow.ts`, `n4_race.ts`
> (+ `…/v7/a2_child.ts`), `n5_indeleteable.ts`, `n6_actor_sin_within.ts`, `n7_cotas.ts`; y los tres
> scripts del auditor 3D re-ejecutados **tal cual** desde `…/scratchpad/v7/`.
> Motores: **PostgreSQL 18** (árbol en memoria y árbol SQL), **MySQL 8.4**, **OpenFGA `:8101`**.
> Suite completa `TEST_DB=pg` + `OPENFGA_TEST_URL=:8101`: **677 passed (677)** — coincide con el informe
> del lote. Residuos: 0 (borré la base huérfana de un script mío que murió; `authz_test_3beaf8e3`, del
> tester, intacta; 0 stores propios en OpenFGA).

## Veredicto en una línea

**APTA CON CORRECCIONES**: A1–A8 están cerrados o acotados por escrito tal como se decidió, no encontré
ningún 🔴 ni ninguna escalada nueva (el ensombrecimiento **no** da un permiso de más: verificado), pero el
lote introduce dos regresiones 🟡 de disponibilidad en la propia promesa que venía a arreglar —
`scopes.detached` con `requireActor: true` sobre un scope ya borrado **no purga nada** (rol,
asignaciones y denies sobreviven) y declarar `descendantsOf` (la receta del invariante 18) rompe
`defineScopedRole` hacia abajo y el `detached` entero cuando el subárbol supera `maxDescendants`.

---

## Misión 1 · Los tres scripts del auditor, re-ejecutados TAL CUAL (PG, sin managers modificados)

Salida literal de `a1_ambiguo.ts`, `a3_detached.ts` y `a6_varios.ts` en `…/scratchpad/v8/a1.txt`,
`a3.txt`, `a6.txt`. Coincide **línea por línea** con lo que el informe del lote pegó (uuids aparte).

```
=== a1 §1 ===
  subU9 define "admin@unit" owner=unitU9 (squat) = {"uuid":"…","slug":"admin","scopeType":"unit",…}
  ...y "operador@organization" (nivel POR ENCIMA de su owner) -> 422 E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER
  orgA (dueño del árbol) intenta SU "admin@unit" -> 422 E_AUTHZ_CATALOG_CONFLICT: … es un descendi
  la PLATAFORMA sincroniza un global "admin@unit" (deploy) = {"shadowedByGlobal":[{…"admin"…}],"assignableAtViolations":[]}
  ¿el resto del deploy entró? true
  roles del deploy en la base: org-admin@g org-jefe@g org-pobre@g jefe-unit@local admin@local admin@g nuevo-rol-del-deploy@g

=== a1 §2 (A5) ===
  A: deleteScopedRole(leadB) -> 422 E_AUTHZ_RANK_EXCEEDED
  A: updateScopedRole(leadA) para renombrar el suyo -> 422 E_AUTHZ_INVALID_IDENTITY: … 'slug' no se puede cambiar …
  A: grant por {uuid} (la salida documentada) = {"existed":false,"expiresAt":null}
  authorize(alguien, docs:read, U1) con el slug ambiguo = true

=== a3 §a (A3) ===
  subU1: deleteScopedRole(caro) -> 422 E_AUTHZ_RANK_EXCEEDED
  subU1: scopes.detached(U1) [misma within] -> 422 E_AUTHZ_RANK_EXCEEDED
  filas de "caro" tras el detached: 1 · filas de "chico": 1

=== a3 §c (A4) ===
  scopes.detached(U1) con un rol owner=U2 (hijo de U1) = undefined
  filas de "nieto" (owner U2): 1          <-- sin descendantsOf (acotado por escrito)
  sync global "nieto@unit" con el local huérfano vivo = {"shadowedByGlobal":[{…}],"ass…

=== a3 §b (A2) ===
  scopes.detached(alias sin guiones) = undefined
  filas de "alias" tras el detached por alias: 0
  fila del rol "alias": 0 · sync global "alias@unit" = {"shadowedByGlobal":[],"assignableAtViolations":[]}

=== a6 §i (A6) ===
  E_AUTHZ_ROLE_NOT_VISIBLE · El rol 'secreto-de-b' (nivel 'unit') no existe en unit:…: hay 1 rol con ese
  nombre en el catálogo, local a un scope que no está en la cadena de este.      <-- ya no imprime el owner de B

=== a6 §iv (A2 bis) ===
  fila de "tardio" tras el detached del proceso con memo de ventana: 0
```

| # | Hallazgo 3D | ANTES (`56094ac`) | AHORA (`5b4f3c2`) | Estado |
|---|---|---|---|---|
| **A1 a** | mina de slug: rol de nivel POR ENCIMA del owner | `operador@organization` con owner unit ⇒ **creado** | 422 `E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER` (también sin `descendantsOf`) | ✅ cerrado (la variante «tipo no-ancestro» sigue: 🟡 N1) |
| **A1 b** | el `sync` revertía el deploy entero | `422 CATALOG_CONFLICT` · `¿el resto del deploy entró? false` | `shadowedByGlobal:[…]` · `¿entró? true` · exit 0 del comando | ✅ cerrado |
| **A2** | alias del uuid en `detached` | `filas de "alias": 1`, `sync ⇒ 422` para siempre | `filas: 0`, `sync ⇒ {shadowedByGlobal:[]}` | ✅ cerrado |
| **A2 bis** | roles leídos del memo (ventana `everyMs`) | `fila de "tardio": 1` | `0` | ✅ cerrado |
| **A3** | `detached` sin policy de rango | `detached = undefined`, `caro`: 0 filas | 422 `E_AUTHZ_RANK_EXCEEDED`, `caro`: 1 fila, nada tocado | ✅ cerrado (efecto lateral: 🟡 N2) |
| **A4** | `detached(padre)` no alcanza al nieto | `filas de "nieto": 1` | `1` sin `descendantsOf` · `0` con él (`a3_detached_3e.ts`) | ⚠️ acotado por escrito (CLAUDE.md inv. 18 + README) — coste: 🟡 N3 |
| **A5** | ambigüedad irreversible; el mensaje aconsejaba renombrar | «renombra uno de ellos» | el 422 sigue (decisión de M1) y el mensaje dice la salida real (`{uuid}` / purgar) | ⚠️ documental, como se decidió |
| **A6** | los 422 nombraban owners de otro tenant | `… es local a organization\|…-742cbd07940b` | «hay 1 rol con ese nombre …, local a un scope que no está en la cadena» | ✅ cerrado |
| **A7/A8** | coste del cerrojo · higiene del evento | 503 a los 5 s, sin escribir | idéntico (re-medido) · el evento lleva `roles: CatalogRoleRef[]` resueltos | ✅ / ⚪ N6, N7 |

---

## Misión 2 · Hallazgos nuevos (ordenados por severidad)

### 🟡 N1 · La mina de slug sigue abierta para todo tipo que no sea el de un ANCESTRO

- **Escenario**: `subU1`, rank 5, un permiso delegable, `within` = su unit (lo mínimo que permite
  delegar) → `defineScopedRole(subU1, unitU1, { slug:'n-galaxia', scopeType:'galaxia' })` ✅ (un tipo que
  **no existe en el árbol**) y `{ scopeType:'proyecto' }` ✅ (un tipo **hermano**, que cuelga de la org, no
  de la unit) → el rol no es visible en ninguna parte, no concede nada, **solo ocupa el nombre** → (a) el
  dueño del árbol, `orgA`, ya no puede definir SU `n-galaxia@galaxia`: 422 `E_AUTHZ_CATALOG_CONFLICT` «es
  un descendiente»; (b) `authz:catalog:diff` sale con exit ≠ 0 mientras el rol viva, y el README manda
  correrlo en CI («exit 1 on drift — run it in CI»): el gate del deploy queda rojo por decisión de un
  actor de rank 5, y volver a ponerlo verde exige purgar rol a rol.
- **Evidencia**: ✅ `n1_nivel.ts` §1 y §3, salida literal: `galaxia (tipo INEXISTENTE en el árbol) = {…}`
  · `proyecto (tipo HERMANO …) = {…}` · `orgA (dueño del árbol) define SU n-galaxia@galaxia -> 422
  E_AUTHZ_CATALOG_CONFLICT`. Código: `src/manager.ts:1309-1334` (`#assertLevelUnderOwner`: solo rechaza
  `chain.slice(1).find(type === scopeType)`; «cualquier otro tipo se presume DESCENDIENTE y vale»), y
  `src/catalog.ts:598` + `commands/authz_catalog_diff.ts:43` (la sombra es deriva con exit 1).
- **Steelman del defensor**: *«es la regla mínima que el coordinador decidió a propósito para no exigir
  `descendantsOf`; el deploy ya no se cae, el rol no concede nada y cualquier ancestro con rank lo borra
  (`deleteScopedRole` ✅ verificado, rank 50 > 2)»* → **me convence a medias**: la mina dejó de ser
  «paro el deploy» y pasó a «ocupo el nombre de mi dueño y le dejo el CI en rojo», que es exactamente lo
  que N3 (`permissions: []`) se cerró por ser. Con `descendantsOf` declarado la regla SÍ lo mata
  (`galaxia` y `proyecto` ⇒ 422, verificado en `n1_nivel.ts` §2), así que la puerta que queda es la del
  consumidor que sigue el stub publicado.
- **Mitigación mínima**: que el rol local de un tipo que no es el del owner exija `descendantsOf` **o**
  se marque en el diff como «rol local de nivel no comprobable» sin contarlo como deriva.

### 🟡 N2 · `scopes.detached` con `requireActor: true` sobre un scope ya borrado no purga NADA (regresión de P3)

- **Escenario**: config `requireActor: true` **sin** `requireWithin` (config legal y recomendada en el
  README) → el consumidor borra la fila del scope y **después** notifica, que es el orden que el paquete
  admitía hasta 3D (`canonicalScope` devuelve el scope tal cual cuando el árbol no lo conoce) →
  `scopes.detached(U1, { actor })` ⇒ **422 `E_AUTHZ_UNKNOWN_SCOPE`** y no se purga *nada*: el rol local
  sigue (1 fila), **su asignación sigue viva** (1) y **los denies del scope también** (1). `purgeScope`
  ni se llama, porque los roles van primero. `deleteScopedRole` responde 422 `UNKNOWN_SCOPE` (resuelve el
  owner en fresco) y `detached` sin actor es 422 `E_AUTHZ_ACTOR_REQUIRED` por el propio config.
- **Evidencia**: ✅ `n6_actor_sin_within.ts`, salida literal:
  `scopes.detached(U1, { actor }) -> 422 E_AUTHZ_UNKNOWN_SCOPE: … tiene 1 rol(es) LOCAL(es) que purgar y
  el árbol ya no lo conoce …` · `filas de v5: 1 · asignaciones: 1` · `denies vivos: 1`; y el control:
  `laxo.scopes.detached(U1) sin actor = undefined` ⇒ `filas: 0 · asignaciones: 0 · denies: 0`.
  Comparación con el código anterior: `git show 56094ac:src/manager.ts` — el `detached` de 3D no resolvía
  ninguna cadena (`#purgeRolesOwnedBy(driver, child, actor)` a secas), así que este caso **funcionaba**.
  Nuevo: `src/manager.ts:466-480` (`#assertAboveOwnedRoles` ⇒ `UnknownScopeError`).
- **Steelman del defensor**: *«el README lo dice: “with an actor the scope must still be in the tree when
  you notify” y “without an actor it behaves as before”; además `manager.driver()` es la salida
  documentada de `requireActor`»* → **no me convence del todo**: con `requireActor: true` la frase «sin
  actor se comporta como antes» **no es alcanzable** por la API del manager (422 `ACTOR_REQUIRED`,
  verificado), así que la salida real es `CatalogCache().view().rolesOwnedBy(scopeKey(scope))` +
  `driver().purgeRole(uuid)` + `driver().purgeScope(scope)` — tres llamadas de bajo nivel, sin
  `role_purged` en la auditoría, y ninguna está escrita en ese párrafo. Encima el fallo NO es silencioso
  (bien) pero deja hechos vivos de un scope borrado: si el consumidor restaura la fila con el mismo uuid
  (papelera, undelete), las asignaciones vuelven a conceder.
- **Mitigación mínima**: si el árbol no conoce el scope y hay `actor`, medir el rango en la cadena del
  **owner del rol** (que es la que usa `deleteScopedRole`) o permitir el `detached` sin actor pese a
  `requireActor` documentándolo como operación de plataforma; y escribir la receta de purga manual.

### 🟡 N3 · Declarar `descendantsOf` (la receta del invariante 18) rompe el `define` hacia abajo y el `detached` entero por encima de `maxDescendants`

- **Escenario**: consumidor que declara `scopes.descendantsOf` (lo que 3E pide para que `detached(padre)`
  alcance al nieto) con una org de 6 units y `maxDescendants: 3` (por defecto 10 000, misma forma) →
  (a) `defineScopedRole(orgA, { scopeType:'unit' })` ⇒ **503 `E_AUTHZ_RESOLVER_FAILED`**: el tenant grande
  no puede delegar hacia abajo, solo a su propio nivel; (b) `scopes.detached(orgA)` ⇒ **503**, y no se
  purga nada: `filas de purga: 1`, `asignaciones vivas: 2` — ni roles ni **hechos**. El mismo `detached`
  con un manager sin `descendantsOf` purga con normalidad.
- **Evidencia**: ✅ `n7_cotas.ts`, salida literal. Código: `src/manager.ts:1324` y `:442`
  (`this.#scopeBounds(op, {})` — la cota se lee del config y **no se puede subir en la llamada**) y
  `:1760` (`TooManyScopesError` cuando el resolutor propio devuelve de más; con un `descendantsOf` que
  lanza él, como el del harness, sale 503 `RESOLVER_FAILED`).
- **Steelman del defensor**: *«`descendantsOf` es opt-in, la cota es del consumidor y un subárbol de más
  de 10 000 nodos con `detached` es un problema suyo; fail-closed es lo correcto»* → **me convence a
  medias**: fail-closed sí, pero el resultado es que la configuración que 3E recomienda para cumplir el
  invariante 18 **empeora** el caso grande respecto a 3D (donde `detached` no miraba el subárbol y
  purgaba el scope exacto) y deja al tenant grande sin delegación hacia abajo. Además el nivel del rol se
  paga con un recorrido del subárbol **en cada `define`/`update`** cuyo `scopeType` no es el del owner:
  es trabajo O(subárbol) que dispara el actor de menor privilegio (fuera de la transacción, eso sí).
- **Mitigación mínima**: en `#purgeRolesOwnedBy` y en `#assertLevelUnderOwner`, degradar a la promesa
  acotada (purgar/aceptar el scope exacto) cuando el subárbol excede la cota, en vez de tumbar la
  operación entera; o admitir `maxDescendants` en `ScopedWriteOptions`.

### 🟡 N4 · El ensombrecimiento en masa mata los slugs GLOBALES dentro del subárbol también para la plataforma

- **Escenario**: `subU1` (rank 5) define los cinco slugs que el próximo deploy va a traer
  (`soporte`, `auditor`, `facturacion`, `operador`, `lector`) en su unit, cada uno con un permiso de
  adorno → el deploy escribe los globales y **reporta** (`shadowedByGlobal: 5`, exit 0: correcto) → dentro
  de esa cadena **toda** ruta por slug del rol GLOBAL es 422: `grant(nuevo,'soporte',U1)`,
  `hasRole`, `listSubjects('soporte',U1)` — `slugs GLOBALES muertos por slug dentro de U1: 5/5`. Fuera del
  subárbol funciona (`grant(nuevo,'soporte',U3) = {existed:false}`), así que está contenido, pero el
  onboarding de la propia plataforma en ese tenant deja de funcionar por slug hasta que alguien purgue.
- **Evidencia**: ✅ `n3_shadow.ts` §3. Y lo importante: **no hay escalada** — `authorize(holderLocal,
  'billing:write'/'admin:todo', U1) = false`, `effectivePermissions(holderLocal, U1) = ['docs:read']`
  (el hecho apunta al uuid del rol local, no al global homónimo). La limpieza funciona: `orgAdmin`
  (rank 50) borra los cinco y `grant(nuevo2,'soporte',U1)` vuelve a responder.
- **Steelman del defensor**: *«es la decisión 2 escrita: los globales ganan, el perjuicio queda en quien
  ocupó el nombre, y con M1 la ambigüedad es fail-closed»* → **me convence en lo esencial** (no hay
  cruce de datos ni permiso de más, que es lo que audito), **no en la redacción**: el README dice «the
  tenant that took the name only hurts itself», y lo medido es que la **plataforma** pierde sus rutas por
  slug dentro de ese subárbol. Es una línea de documentación, no un cambio de diseño.
- **Mitigación mínima**: corregir esa frase del README y del CHANGELOG («…y la plataforma pierde las
  rutas por slug de ese rol dentro de la cadena afectada: opera por `{ uuid }` o purga»).

### ⚪ N5 · `listRoles` no desambigua: el holder de un local es indistinguible del holder del global homónimo

- **Escenario**: `listRoles(holderLocal, U1) = ['soporte']` y `listRoles(holderGlobal, U3) = ['soporte']`,
  con permisos efectivos distintos (`['docs:read']` vs `['docs:read','billing:write','admin:todo']`). Un
  consumidor que ramifique por nombre de rol (`if (roles.includes('soporte'))`) trata como soporte de
  plataforma a quien tiene el rol de adorno del tenant. Hasta 3E el `sync` **impedía** que ese par
  existiera (abortaba); ahora lo crea la propia plataforma.
- **Evidencia**: ✅ `n3_shadow.ts` §2. `hasRole` por slug sí es fail-closed (422), que es lo que evita
  que esto sea un 🟠.
- **Steelman**: *«`listRoles` es API de membresía y el README dice que se autoriza por permiso; la forma
  inequívoca es `{ uuid }`/`rolesInChain`»* → **me convence**, pero conviene una línea junto a
  `shadowedByGlobal` avisando de que el ensombrecimiento crea homónimos que `listRoles` no distingue.

### ⚪ N6 · `serializedCatalogWrites: true` promete «el perdedor es 422», y bajo contención del cerrojo es 503

- **Verificado que SÍ se cumple** con dos procesos `node` reales, los dos con la **misma foto vieja** del
  catálogo (memo de ventana) y soltados a la vez: **8 carreras en PG y 8 en MySQL**, en tres formas
  (owners distintos de la misma cadena, **mismo** owner —que además choca con el unique— y `define`
  contra `sync`): siempre **1 fila, 1 ganador y el perdedor 422 `E_AUTHZ_CATALOG_CONFLICT` exacto**
  (`n4_race.ts`). En MySQL dos de ellas cayeron por el **re-chequeo transaccional** («El catálogo cambió
  mientras se validaba…»), que es el mismo 422.
- El matiz: con la fila de versión bloqueada por otra transacción más que el deadline, el segundo
  escritor recibe **503 `E_AUTHZ_BACKEND_TIMEOUT` (`catalog.lock`)** sin escribir (re-medido con
  `a7_cerrojo.ts`: 12 s de cerrojo ⇒ 503 a los 5 s, `fila del rol "bloqueado": 0`). Y 3E **alargó** la
  sección crítica del `sync` (una consulta `sync.role.locals` por rol + el join `sync.revalidate` sobre
  todos los vínculos de los permisos con `assignableAt`), así que un deploy grande hace más probable ese
  503 en los `define` concurrentes. Es fail-closed y reintentable; solo pide una línea junto a la
  capacidad, que hoy se lee como incondicional.

### ⚪ N7 · P4 protege la escritura, no el cambio de driver

- Verificado que `defineScopedRole` se niega **siempre y antes de escribir** con `openfga`: directo
  (500 `E_AUTHZ_UNSUPPORTED`, 0 filas), por `forRequest()` (idéntico), y `driver().purgeRole` es
  `undefined` (`n2_p4.ts` §a/§b). No hay selector de driver por llamada (`driver()` usa
  `config.default`), así que no hay tercera vía.
- Lo que queda: un rol creado con `database` y un despliegue que pasa a `openfga` (catálogo SQL
  compartido) deja ese scope **muerto**: `deleteScopedRole` 500, `scopes.detached` 500 **y los hechos sin
  purgar** (`authorize` sigue `true`), y ni siquiera se puede definir otro rol allí. La salida existe y
  la comprobé (instanciar el driver `database` y purgar; después `detached` con openfga funciona y
  `authorize` pasa a `false`), pero el README solo la menciona para «filas escritas a mano». No es
  regresión —en 3D el `purgeRole` de openfga lanzaba 500 igual— y no crea estado nuevo: es una línea de
  documentación («cambiar de driver a uno sin `purgeRole` congela los scopes con roles locales»).
- ⚪ además: con `hooks.onWrite` declarado, cada `grant`/`revoke` paga ahora un `resolveChain` **fresco**
  (no memoizado) más una vista de catálogo para enriquecer el evento (`#resolvedRoles`, `manager.ts:873`).
  Está bien aislado (todo el cuerpo va en `try/catch` que devuelve `undefined`: comprobado que no puede
  convertir una escritura confirmada en un error), pero es una consulta al árbol por escritura que antes
  no existía.

---

## Lo que intenté y NO se rompió

- **La regla de nivel, atacada por todos los lados** (`n1_nivel.ts`, `n5_indeleteable.ts` §D):
  `scopeType` = el del owner ✅; = el de un **ancestro** ⇒ 422 `ROLE_LEVEL_ABOVE_OWNER` (con y sin
  `descendantsOf`); `app` ⇒ 422 `INVALID_IDENTITY` antes aún; con `descendantsOf` declarado, tipo
  inexistente y tipo hermano ⇒ 422 y descendiente real ✅. **Resolutor mentiroso**: una cadena a la que
  le falta la organization deja pasar `slug@organization` con owner una unit (garbage-in del invariante
  17, no lo cuento como hallazgo: el árbol es del consumidor); una cadena con **tipos repetidos** no
  rompe nada (el rol se crea al nivel del owner, que es lo correcto); y un resolutor que **miente sobre
  el tipo del propio scope** es 503 `E_AUTHZ_RESOLVER_FAILED` (la comprobación de canonicidad de
  `resolveChain` lo caza, `backend_guard.ts:204`).
- **Tumbar el `sync` por otra vía** (`n1_nivel.ts` §4): retirar del config un permiso que un rol LOCAL
  usa ⇒ el sync pasa (los permisos nunca se podan, no hay violación de FK); estrechar `assignableAt` con
  locales que lo llevan ⇒ pasa y **reporta** (`assignableAtViolations`), y el tenant puede repararlo él
  con `updateScopedRole`; bajar el rank global ⇒ pasa; el `(slug, nivel)` ocupado ⇒ el global entra y se
  reporta. Los slugs de rol **no** se contrastan contra la base (solo los permisos, `catalog.ts:255`), y
  un tenant no puede crear permisos: no encontré ninguna fila escribible por un tenant que haga lanzar al
  `sync`. El comando sale con **exit 0** e imprime warnings (`authz_catalog_sync.ts:44-56`).
- **Escalada por ensombrecimiento**: ninguna. El hecho apunta al uuid del rol, así que el holder del
  local no hereda nada del global (verificado con `admin:todo`), y `effectivePermissions` = exactamente
  `{p | authorize(p)}`. El `revoke` por slug quita los dos homónimos, pero eso ya era así antes del squat
  (las seis escrituras no evalúan actor: es contención por `within`, no policy).
- **P3, la policy de rango del `detached`**, medida en la cadena del scope notificado y no en la del rol:
  es la medida **conservadora** (chain(descendiente) ⊇ chain(scope) ⇒ el rank del actor en el hijo es
  ≥ que en el padre), así que no abre ninguna vía para purgar un rol que `deleteScopedRole` niegue.
- **R2 con dos procesos reales** (arriba, N6): 16 carreras, 16 con un solo ganador y el 422 exacto.
- **Regresión**: suite completa `TEST_DB=pg` + OpenFGA `:8101` ⇒ **677/677**.

## Preguntas abiertas para el arquitecto

1. **¿`requireActor: true` debe impedir el `detached` de plataforma?** Hoy sí, y con eso el rol, sus
   asignaciones y los denies de un scope ya borrado sobreviven sin ninguna vía de manager (N2). Si la
   respuesta es «se purga con `driver()`», hay que escribir la receta de tres llamadas en el README.
2. **¿`descendantsOf` puede degradar en vez de fallar** cuando el subárbol pasa de `maxDescendants`
   (N3)? Hoy declararlo empeora al tenant grande respecto a no declararlo.
3. **¿Un rol local de un tipo que el árbol no conoce debería exigir `descendantsOf`?** Es lo único que
   queda de la mina de A1 (N1) y lo que mantiene el gate de `authz:catalog:diff` rojo.
