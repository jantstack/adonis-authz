# Panel metodología — auditor: piloto de M4 (auditoría de SISTEMA sin diff) sobre `2.4.0-alpha.9`

Objeto auditado: árbol PUBLICADO `7fbc638` (`git archive HEAD` en el scratchpad, `node_modules` enlazado; el working
tree del implementador de alpha.10 no se tocó). Reproducción: `.claude/reproducciones/sistema-m4.spec.ts` (8 casos por
el kernel de ace con `aceFor`/`AppFactory`, SQLite `:memory:`; **verde = defecto reproducido**; se corre copiándola a
`tests/` y `node --import @poppinss/ts-exec bin/test.ts --files tests/sistema-m4.spec.ts`). Resultado: 8/8 verdes.

## Veredicto en una línea
**M4 vale**: una pasada corta sin diff sacó 1 🔴 y 2 🟠 nuevos, publicados desde alpha.1 (12 días), que ninguna de
las ~15 rondas por diff vio — y uno de ellos ya derrota el arreglo que alpha.10 está escribiendo.

---

## (a) Hallazgos NUEVOS (ordenados por severidad)

### 🔴 S1 · `authz:relations:reconcile --to=openfga` tras el cutover resucita comparticiones retiradas (y con `--prune` borra las nuevas), sin `--from`
- **Escenario**: despliegue con `relations/` y `config.default` ya en `openfga` (las relaciones cambian de driver
  con él, ver 🟠 S3) → tras el cutover un usuario pierde el acceso a `document:d1` (`unrelate` va solo al store;
  `authz_relations` quedó congelada) → el operador corre la forma literal del README/docblock,
  `node ace authz:relations:reconcile --to=openfga` → el comando elige solo el origen (`database`, «el ÚNICO que no es
  el destino»), reescribe `document:d1#viewer@user:u-old` en el PDP vivo y sale **en verde** (`reconciliadas desde
  'database': escritas 1`). Con `--prune`, además borra `document:d2#viewer@user:u-new` (compartida después del
  cutover). Medido: S1a/S1b.
- **Evidencia**: ✅ `commands/authz_relations_reconcile.ts:249-261` (auto-elección del origen), `:291-319` (nada mira
  `relations.default`/`config.default`); `src/relations/reconcile.ts:221-330` (no hay noción de «destino activo» ni
  de pasada de mantenimiento). Es el gemelo EXACTO de los 🔴 de 3b-5 (roles) y del punto 4 del informe 6 (que alpha.10
  cierra SOLO en `manager.reconcile`, `alpha10-informe.md` §1) — y peor: no hace falta `--from`.
- **Publicado desde**: `2691d83` (Fase 4 lote 6, 2026-09-01) ⇒ en `v2.4.0-alpha.1`…`alpha.9`.
- **Steelman**: «tras el cutover nadie migra relaciones; se usa `--dry-run`». → **No convence**: el `--dry-run` en esa
  posición reporta como deriva cada cambio posterior al cutover (exit 1 para siempre), que es exactamente lo que
  empuja al operador a correrlo sin `--dry-run`; y el README (`:645-649`) lo vende como «idempotent, bidirectional».
- **Mitigación mínima**: la misma regla de 3b-5/alpha.10 en el comando de relaciones (destino = driver activo de
  relaciones ⇒ negarse a leer del otro sin bandera explícita).

### 🟠 S2 · `authz:reconcile` con la ventana del operador vencida (o levantada) antes de la pasada: se certifica con SU freeze, lo suelta y borra la evidencia
- **Escenario**: `authz:freeze --reason=cutover --lease-ms=60000` (proceso aparte) → el lease vence →
  `authz:reconcile --to=openfga --from=database` → `#durableFreezeContext` no ve ventana viva, **toma un freeze propio
  de 15 s**, corre, publica `frozen = { lapsed: false, leaseMs: 15000, fence: 4 }`, sale 0 y **al soltar deja
  `freeze_reason = NULL`** → la flota escribe en `database` antes del cambio de `default` → `authz:unfreeze` responde
  «nada que levantar» en verde. Tras el switch, las revocaciones hechas en ese hueco no existen en el store
  (fail-open) y el verificador de mantenimiento sale limpio. Medido: S2 (fila borrada, `unfreezePlan` ⇒ `noop`).
- **Agravante medido (S2-control)**: con la ventana VIVA la salida del comando es **letra a letra la misma**
  (`reconcileLines` solo imprime `frozen` si `lapsed`, `commands/authz_reconcile.ts:170-178`); el comando de relaciones
  sí distingue «ventana del operador» de «lease N ms» (`authz_relations_reconcile.ts:144-151`). Asimetría otra vez.
- **Evidencia**: ✅ `src/manager.ts:761-788` (rama 3: freeze propio), `src/freeze.ts:208-209` (un lease vencido se
  pisa) y `:278` (el release anula la fila). **Derrota el arreglo en curso de alpha.10 §2**: `lastFreezeStatus()`
  devuelve `null` con motivo `NULL`, que es justo lo que deja la pasada.
- **Publicado desde**: `49f3010` (3b-7, 2026-08-31) la rama silenciosa; por el COMANDO con `--lease-ms` solo desde
  alpha.9 (antes la bandera era inerte); por «alguien levantó la ventana antes de la pasada», desde alpha.1.
- **Steelman**: «`--lease-ms` lleva su contra declarada (README:1078)». → **No convence**: la contra declarada es
  «los escritores vuelven», no «la pasada se certifica y borra la única prueba»; y la variante sin lease (unfreeze
  prematuro) no está declarada en ninguna parte.
- **Mitigación mínima**: `reconcile`/`relations:reconcile` imprimen SIEMPRE en qué ventana corrieron, y una fila con
  holder `operator:` vencida no se pisa sin avisar (ni la limpia el release de otro).

### 🟠 S3 · El runbook de cutover omite `relations/`, y las relaciones cambian de driver con `config.default`
- **Escenario**: consumidor con `relations.config` y los dos drivers de relaciones, sin `relations.default` (que el
  README no menciona ni una vez) → sigue README:1071-1076 (freeze → `authz:reconcile` → switch → unfreeze) → el
  `RelationsManager` pasa a `openfga` con **cero tuplas de relación** → todo `check` es `false` (caída total de
  compartición, fail-closed) → `authz:reconcile --to=openfga --dry-run` sale **limpio** (`foreign` = 0 no imprime
  nada) → el arreglo natural después del unfreeze es S1.
- **Evidencia**: ✅ `providers/authz_provider.ts:43` (`relations.default ?? config.default`); `src/define_config.ts:300-305`;
  `grep relations.default README.md` = 0; README:1067-1086 sin `authz:relations:reconcile`. Sin servidor: hipótesis en
  el efecto de flota, determinista por código.
- **Publicado desde**: `7b5d4db` (Fase 4 lote 8, 2026-09-01) el acoplamiento; el runbook es de 3b-7.
- **Steelman**: «las relaciones son otro puerto y su migración está documentada en su sección». → **No convence**: el
  interruptor que las mueve es el MISMO `default` que el runbook manda cambiar, y ningún verificador lo delata.
- **Mitigación mínima**: el runbook nombra `authz:relations:reconcile` (por partición) dentro de la ventana, y el
  README documenta `relations.default`.

### 🟡 S4 · `authz:scopes:relay --dry-run` es 503 `E_AUTHZ_FROZEN` durante la ventana
- **Escenario**: ventana de operador abierta → el operador quiere ver la cola («list what is still unpropagated»,
  README:130; «the report counts it», README:1061) → 503 antes de leer nada. Medido: S3 del spec.
- **Evidencia**: ✅ `src/manager.ts:1112` (barrera) antes de `:1132` (rama `dryRun`). Mientras, `requeue` SIN `--apply`
  (que escribe la cola) sí pasa (`:1778`): la barrera está invertida respecto a «lee/escribe».
- **Desde**: `49f3010` (2026-08-31). **Steelman**: «el relay es escritura». → no para `--dry-run`, que no escribe.
- **Mitigación**: la barrera después de la rama `dryRun`.

### 🟡 S5 · `authz:scopes:relay --dry-run` sale 0 con entradas APARCADAS si además hay pendientes
- **Escenario**: 1 aparcada + 1 pendiente → imprime «APARCADO» en rojo y sale **0**; con la aparcada sola sale 1
  (control medido). Un cron que vigila con `--dry-run` pierde la «divergencia permanente» justo cuando hay tráfico.
- **Evidencia**: ✅ `commands/authz_scopes_relay.ts:210-221` (solo pone `exitCode` si `wouldApply` está vacío) vs
  README:140 «exits non-zero while any exists». **Desde** `2ef4f6b` (3b-2d, 2026-08-30).
- **Steelman**: «`--dry-run` no es la alarma». → el README no lo excluye y el propio texto dice «on every pass».

### 🟡 S6 · `authz:scopes:relay --only=<id>` con la entrada APLAZADA (o un id inexistente) imprime «La outbox del árbol está vacía: nada que propagar» y sale 0
- **Escenario**: script de alta de tenant que releva su recibo y mira el exit code → `#12` sale `deferred ·
  depends-on:3` → verde + frase falsa; el tenant nuevo deniega (fail-closed) y nadie lo sabe. Con `--only=999` (errata)
  lo mismo. Medido: S6.
- **Evidencia**: ✅ `commands/authz_scopes_relay.ts:226-260` (sin rama para «nada aplicado pero hay aplazados/missing»).
  README:142 advierte a la API («if `entries` says your change is deferred, it has not landed»); el comando lo contradice.
- **Desde**: `--only` en alpha.5 (`09b3186`), la frase en 3b-2d.

### 🟡 S7 · `authz:scopes:relay --max-age=-1` (o `1.5`) se valida DESPUÉS de relevar
- **Escenario**: el cron lleva un umbral mal escrito → la pasada aplica y marca entradas → `queueAgeLines` lanza
  `TypeError` → el comando revienta sin imprimir qué aplicó. Medido: S5 (1 llamada al relay, `TypeError`, sin «aplicado»).
- **Evidencia**: ✅ `commands/authz_scopes_relay.ts:171-182` y `:24-26`. **Desde** `b5868d8` (alpha.8, 2026-09-10).
  El resto de opciones se validan antes de escribir (`requeueScopeChanges`, `:1765-1776`): este es el único orden roto.

### 🟡 S8 · El verificador de relaciones solo ve `modelDrift` si la config está PERSISTIDA, y se traga el error al leerla
- **Escenario**: consumidor con `relations.config` estático (sin `saveRelationsConfig`) → `--dry-run` nunca reporta
  `modelDrift` y cuenta como `written` lo que la pasada real contará como `skipped.undeclared` (contra README:555
  «so `--dry-run` and the real pass report the same numbers»); con la base respondiendo mal, `.catch(() => undefined)`
  apaga el chequeo en silencio.
- **Evidencia**: ✅ `commands/authz_relations_reconcile.ts:298-299, 318` (tiene `config.relations.config` en la mano y no
  lo usa). Hipótesis en el efecto (no medido). **Desde** `2691d83`.

### ⚪ Higiene / divergencias de letra
- **S9** `authz:reconcile --batch-size` dice «operations per destination write»; las escrituras van SIEMPRE en lotes
  de 100 (`openfga_driver.ts:3382-3390`, `PURGE_BATCH_SIZE`). ✅.
- **S10** `saveRelationsConfig` (republica el modelo fusionado) no pasa la barrera del freeze y no está en la lista
  «What the freeze does NOT freeze, by name» (README:1061). ✅ `src/relations_config_store.ts:51-68`.
- **S11** README:1003-1005 «`authz:catalog:sync` …and projects the catalog into it» justo tras aprovisionar: con
  `default` aún en `database` no proyecta nada (`commands/authz_catalog_sync.ts:22-29` usa el driver ACTIVO). Inocuo
  porque `reconcile` lo escribe, pero la frase es falsa en el orden del runbook. ✅.
- **S12** (hipótesis) la receta inline «the inline pass returns a report, it does not throw» (README:142) no es cierta
  si el freeze aterriza entre el commit y el relay: 503 `E_AUTHZ_FROZEN` tras un commit hecho, y reintentar la PETICIÓN
  no es idempotente.

### Reencontrado (ya reportado / en curso) — una línea cada uno
- Dirección rancia en roles (`--to=<activo> --from=<otro>`): informe 6 · 4, alpha.10 §1. Su variante
  `--to=database` sin `--from`: ya la anota el implementador en `alpha10-informe.md`.
- `unfreeze` con ventana caducada: informe 6 · 2 — S2 es una composición NUEVA que lo derrota.
- Letra de la pasada de mantenimiento, `leaseMs` en ventana adoptada, `--partition-type=app` con uuid: vistos, fuera.

---

## (b) Coste y rendimiento del piloto — la evidencia para decidir M4

- **Tiempo**: reloj de pared de herramientas 14:30 → ~14:45 (≈ 15-20 min de agente, ~25 llamadas: lectura de los 10
  comandos, ~350 líneas de README operativo, `freeze.ts`, las rutas de `manager.reconcile/relay/requeue`,
  `relations/reconcile.ts`, el provider; un spec de 8 casos por kernel). Un humano con el mismo perímetro: medio día.
- **Resultado**: **1 🔴 + 2 🟠** (y 5 🟡, 4 ⚪). Los tres graves llevan publicados **desde alpha.1** (12 días, 9
  versiones, ~15 rondas de auditoría por diff). Ninguno lo tocaba un diff. Uno (S2) invalida el arreglo en curso.
- **Dónde salió el rendimiento** (útil para repetirlo): (1) el subsistema GEMELO del que se arregló (S1, S3, S2-letra);
  (2) las ramas de salida de los comandos —exit code y frase— en estados mixtos (S5, S6, S7); (3) la máquina de
  estados del cutover leída en orden, incluido «la ventana ya no está».
- **Caveat honesto**: el primer M4 cosecha lo acumulado. El segundo, con el mismo auditor y la misma lista, rendirá
  mucho menos; si M4 se adopta, cada pasada debe rotar perspectiva (otro rol de operador, otro subsistema primero) o
  degenera en teatro.

## (c) Perímetro NO cubierto
- Nada contra OpenFGA real (`:8101`), PG ni MySQL: S1/S2/S4-S7 son por kernel con dobles + SQLite `:memory:`; S3 y S8
  son por código.
- No leí: README 188-500 (trx, catálogo, roles locales), 660-1000 (contratos) ni 1171-1365 (upgrades). La tabla
  «Limits» solo muestreada.
- `openfga:provision`, `authz:catalog:sync/diff/prune-orphans`: leídos, no ejecutados con combinaciones.
- Relay inline con el store caído y vuelta; `requeue` tras `reconcile`; `--only` con ids no numéricos en PG (bigint);
  multiproceso real del freeze: no medidos.

## (d) Opinión adversarial sobre M1, M2, M3, M5, M6

- **M1 (runbook ejecutable) es la que MÁS falsa seguridad puede dar.** Si el runbook que se ejecuta es el del README,
  codifica sus omisiones: hoy pasaría en verde con `relations/` sin cablear (S3) y sin «la ventana venció antes de la
  pasada» (S2). Es P5 a escala de runbook. Y «M1 pasa» como criterio de `2.4.0` estable convierte ese verde en permiso.
  Condición para que no sea teatro: el runbook de test lleva `relations/` cableado y los estados abortada/caducada/
  repetida de M5, contra `:8101`.
- **M2 (≥ 1 caso por bandera por kernel)** garantiza que la bandera LLEGA, no qué hace en cada estado: S5, S6 y S7
  tienen sus banderas ejercitadas y fallan en combinaciones (`--dry-run` + aparcada + pendiente; `--only` + aplazada).
  S1 ni siquiera es una bandera: es la AUSENCIA de `--from`. Una guardia «cada bandera cubierta» en verde se leerá
  como «los comandos están cubiertos».
- **M3 (tabla de verdad)** cazaría S5/S6 si los ejes incluyen el exit code. Pero elegir los EJES es otra vez intuición
  (P3 un nivel más arriba): `config.default`/`relations.default` y «la ventana existía y ya no» no son entradas del
  comando y no aparecerían en su tabla.
- **M5 (estados en el panel de diseño)** habría evitado S2 en 3b-7, pero solo mira lo NUEVO: no revisita lo publicado
  (P2 intacto) y no cruza subsistemas.
- **M6 (retirar el arreglo)** mide la fuerza de los casos de un arreglo existente. No encuentra lo que NUNCA se arregló
  en el gemelo (S1): no hay arreglo que retirar.

**Patrón que ninguna medida cubre: la asimetría de gemelos.** Un 🔴 se cierra en roles (3b-5: fuente de verdad del
destino activo; 3b-7: la letra de la ventana) y el subsistema paralelo nacido un día después (`relations/`, Fase 4) no
lo hereda; alpha.10 repite el patrón hoy (arregla `manager.reconcile`, no `authz:relations:reconcile`). Ni M1-M6 ni
M4 tal como está escrita lo obligan. Medida mínima que propongo al juez: **al cerrar un 🔴/🟠, el informe lista sus
gemelos por `grep` (roles↔relations, reconcile↔relations:reconcile, relay↔requeue --apply, comando↔API) y cada uno
lleva caso o «no aplica, porque…»**. Coste: minutos por cierre. Segundo patrón no cubierto: **salidas que no dicen QUÉ
rama corrió** (S2: ventana ajena vs propia; S6: vacía vs aplazada) — un verde con la letra de otra rama es
indistinguible de un verde correcto para cualquier test que mire solo el exit code.

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)
1. ¿`authz:relations:reconcile` debe tener «destino activo» (`relations.default ?? default`) y pasada de mantenimiento
   como roles, o basta con negarse? Cambia si S1 entra en alpha.10 o espera.
2. ¿Una fila `operator:` vencida puede pisarla un `reconcile`? Si sí, el arreglo de alpha.10 §2 necesita otra fuente de
   evidencia que la fila.
