# Fase 2.5 · Infraestructura de test — informe final

> Implementador único sobre `v2/fase-0` (base `4d1d3b6`, Fase 2 cerrada). Spec: `fase-2.5-plan.md` (J1–J6).
> Regla cumplida: rojo → verde por pieza con el fallo anotado; tras cada pieza `typecheck` + `npm test` + `:8101`;
> al cierre `test:pg`, `test:mysql` (con y sin `OPENFGA_TEST_URL`), `sqlite-file` y tope 3 (`:8103`). Sin skip/only,
> sin commits, sin aserciones relajadas. Árbol listo para revisión (tester en worktree, auditor sobre J3/J4, code-review).

## 1. Tabla pieza × rojo × estado × conteos

Conteos = tests de Japa (toda la suite, no solo el juez). Antes de la fase: 313 en SQLite / 396 con `:8101`.

| Pieza | Rojo anotado (motor · error literal) | Estado |
|---|---|---|
| **J1** reloj inyectable | `tests/clock.spec.ts`: 13 lecturas sueltas de `new Date()`/`Date.now()` en `src/` (catalog ×5, database_driver ×3, openfga_driver ×3, catalog_cache ×2, expiry ×2, traits ×2). Juez: `TS2339 Property 'withClock' does not exist on type 'AuthorizationDriver'`; `'clock' does not exist in type 'Partial<AuthorizationConfig>'`. Primer verde parcial: 317/318 (el caso del `clock` del manager usaba `effectivePermissions`, 500 por diseño en el harness «sin listDenies»; se cambió a `hasRole`/`listRoles`). | ✅ |
| **J2** harness multi-motor | Antes de la pieza la suite no podía correr en PG/MySQL (`PRAGMA table_info` en `migration_stub.spec`; `bootApp` cableado a `:memory:`). Hallazgo propio: `tests/helpers/load_without_sdk.ts` (proceso hijo del test de pureza) heredaba `TEST_DB`, provisionaba SU base y solo cerraba el pool ⇒ **16 bases `authz_test_*` huérfanas** (8 PG + 8 MySQL) tras las primeras ejecuciones; corregido con `teardown()` en el hijo y borradas a mano (solo las de mi sufijo; verificado 0 restantes). | ✅ |
| **J3** defectos PG/MySQL | Ver §3 (5 defectos, 2 no previstos). | ✅ |
| **J4** concurrencia | Los tres casos salieron verdes a la primera en los cuatro modos (los drivers ya cerraban las carreras): el rojo de la pieza es de **infraestructura** (con pool 1 en memoria la concurrencia a nivel de conexión no era observable). Discriminación demostrada con mutante en `sqlite-file` (pool ≥ 2): sin el fallback `grant.race` del driver `database`, J4(a) ⇒ `ronda 0: El backend de autorización 'database' no respondió (grant.insert): expected 503 to equal 409` (2 fallos, ambos harness `database`). Restaurado. | ✅ |
| **J5** CI | Job `engines` (matriz `pg`/`mysql`, servicios oficiales `postgres:18`/`mysql:8.4` con healthcheck, OpenFGA `:8090`); YAML validado (`jobs: test, openfga, engines, compat`). No ejecutado en GitHub (no hay push en esta fase). | ✅ |
| **J6** docs | README (`Driver options` → `now`/`withClock`/`clock`; `Custom drivers` → motores y par `injectableClock`; nueva §«Operational notes for the SQL engines»; §Compatibility con la tabla real; tabla de errores; comentario de `sqlDescendantsOf`), CHANGELOG `[Unreleased] — 2.1.0` «Lot 2.5», CLAUDE.md (mapa, comandos, roadmap). | ✅ |

### Conteos por motor y configuración (estado final)

| Configuración | Sin OpenFGA | Con `OPENFGA_TEST_URL=:8101` | Tope 3 (`:8103`) |
|---|---|---|---|
| `npm test` (SQLite memoria, pool 1/1) | **335/335** | **425/425** | **425/425** |
| `npm run test:sqlite-file` (fichero, pool 2..5, WAL) | **335/335** | **425/425** | — |
| `npm run test:pg` (PostgreSQL 18, `postgres18`) | **335/335** | **425/425** | — |
| `npm run test:mysql` (MySQL 8.4, `mysql84`) | **335/335** | **425/425** | — |

`npm run build` (purity + typecheck + tsc + stubs) verde. Casos del juez: 36 core / 49 en 2.0 / 65 en 2.1 (`listDenies: true`, `injectableClock: false`); 68 con `injectableClock: true`; 59 sin `listDenies` (`contract_harness.spec`).

## 2. J1 — reloj inyectable (qué se hizo)

- `src/clock.ts` (nuevo): `Clock`, `systemClock` (= el ÚNICO `new Date()` de `src/` fuera de `src/testing/`), `isClock`. `tests/clock.spec.ts` lo vigila por grep (comentarios excluidos; `new Date(valor)` no cuenta).
- Puerto: `AuthorizationDriver.withClock?(now)` (opcional, misma técnica que `withAncestorsResolver`: vista por prototipo). Ambos drivers lo implementan y aceptan `now?` en opciones (500 `E_AUTHZ_CONFIG` si no es función).
- `database`: `whereActive` = `expires_at > now()` (estricto), `created_at` = `now()`, `refreshAssignment` pasa `now()` a `resolveGrantExpiry`.
- `openfga`: `checkContext(now)` recibe el instante; `this.checkContext()` en checks de roles/denies y en `hasRole`; `readAllTuples` filtra con el mismo reloj; `grant` pasa `now()` a `resolveGrantExpiry` (ruta normal y carrera). El importador acepta `now?` (`skippedExpired`).
- Manager: `config.clock?: () => Date` (validado en constructor); `driver()` aplica `withClock(clock)` al resolver; driver sin `withClock` ⇒ 500 `E_AUTHZ_CONFIG` nombrándolo; las vistas de `forRequest()` leen el driver del padre ⇒ lo comparten (unitarios en `manager.spec`: «config.clock (2.5 · J1)», 4 casos).
- `expiry.ts`, `catalog.ts`, `catalog_cache.ts`, `traits/authz_scopes.ts` leen la hora por `systemClock()`.
- Juez: par `injectableClock` en todos los niveles. `true`: «tres estados con el reloj inyectado» (core; igualdad EXACTA; T−1 concede / T no), «caducidad exacta …» (2.1: T−1/T/T+1 sobre `authorize`, `hasRole`, `listSubjects`, `listRoles`, `listRoleScopes`, `listScopes`; renovación y revivir sin dormir), «el manager expone el reloj (config.clock) …» (2.1). `false`: el caso de 1,5 s de espera real (+ `withClock` ausente: «declara lo observable»). `contract.spec` declara `injectableClock: true` en `database`, «database (sin listDenies)» y `openfga`.

## 3. Defectos J3 × motor

| # | Defecto | Motor que lo mostró | Rojo (literal) | Corrección | Verde en |
|---|---|---|---|---|---|
| 1 | `expires_at` redondeado al segundo | MySQL (`timestamp` de knex = `TIMESTAMP(0)`) | 4 casos del juez: `expected 1893456002000 to equal 1893456001500`; `T: el que expira ahora ya no cuenta: expected {…} to deeply equal { authorize: false, …}`; `lo que se lee es lo que se escribió, al milisegundo: expected 1893456001000 to equal 1893456000600`; `expected false to be true` (config.clock). Evidencia directa: `INSERT '2030-01-01 00:00:00.600'` en `TIMESTAMP` ⇒ `2030-01-01 00:00:01`. | `expires_at` ⇒ `datetime(…, { precision: 3 })` en stub y espejo (MySQL `DATETIME(3)`, PG `timestamptz(3)`, SQLite `datetime`). Caso del juez «la caducidad guarda milisegundos y fechas más allá de 2038 …» (= `subSecondExpiry` de la spec). | SQLite, PG, MySQL |
| 2 | `expires_at` sin fechas > 2038 | MySQL (`TIMESTAMP`) | Evidencia directa: `ERROR 1292 (22007): Incorrect datetime value: '2040-01-01 00:00:00' for column 'x'` (no previsto en la spec; en la suite el caso 1 fallaba antes de llegar a este assert). | Misma corrección (`DATETIME(3)`); el mismo caso del juez concede hasta `2040-01-01` y deniega en ese instante. | SQLite, PG, MySQL |
| 3 | Collation `*_ci` funde `abc`/`ABC` | MySQL (`@@collation_database = utf8mb4_0900_ai_ci`) | Juez «la identidad es una cadena validada …»: `el de mayúsculas no está denegado: expected false to be true` (el deny de `abc.def_42` bloqueaba a `ABC.DEF_42`). | `collate('utf8mb4_bin')` en `holder_type`, `holder_uuid`, `scope_type`, `scope_uuid` (assignments y denies) y `slug` (roles y permissions), stub + espejo; knex solo lo compila en MySQL (PG/SQLite ya comparan por bytes). | SQLite, PG, MySQL |
| 4 | Tipo `uuid` rechaza ids válidos por gramática | PostgreSQL | Juez: `AuthorizationBackendError: El backend de autorización 'database' no respondió (grant.find)`; causa: `invalid input syntax for type uuid: "abc.def_42"`. | `holder_uuid`/`scope_uuid` ⇒ `string(…, 64)` (decisión de la spec: cadena validada por gramática, ≤ 36). `migration_stub.spec` fija además en el TEXTO del stub las tres decisiones (varchar(64)+bin, collation en tipos y slugs, `datetime('expires_at', { precision: 3 })`). | SQLite, PG, MySQL |
| 5 | `sqlDescendantsOf` sin MySQL | MySQL | 7 casos: `UnsupportedDialectError: sqlDescendantsOf: dialecto 'mysql' sin observación en la suite …` (`expected 500 to equal 422`, etc.). Tras el quoting: `expected [ 'undefined:', 'undefined:' ] to deeply equal […]` — **mysql2 devuelve `[rows, fields]` en `rawQuery`** (no previsto). | Cita de identificadores por dialecto (backticks en `mysql`/`mysql2`), SQL construido una vez por dialecto, `rowsOf` que reconoce `[rows, fields]`; `mssql`/`oracledb`/desconocido siguen siendo 500 (unitario, con espía de 0 consultas). | SQLite, PG, MySQL |
| 6 | **Hallazgo:** tope de profundidad de la CTE | MySQL (`@@cte_max_recursion_depth = 1000`) | Nuevo caso `un ciclo con una cota por encima de 1000 …`: `El backend de autorización 'sqlDescendantsOf' no respondió (descendantsOf) · causa: … Recursive query aborted after 1001 iterations. Try increasing @@cte_max_recursion_depth to a larger value.: expected 503 to equal 422`. Con el `maxDescendants` por defecto (10 000) un ciclo era un 503 «backend caído» en vez del 422 «posible ciclo» del contrato. | Hint `/*+ SET_VAR(cte_max_recursion_depth = cap+2) */` en la sentencia (solo MySQL); el entero viene de la cota, nunca del consumidor. | SQLite, PG, MySQL |
| — | `whereRaw`/`LIMIT`/`.timeout({ cancel: true })` | PG, MySQL | Sin defecto: «toda consulta sale con el timeout configurado» verde en ambos (PG cancela con `pg_cancel_backend`, MySQL con `KILL QUERY`). | — | — |

## 4. Desviaciones respecto a la spec (con porqué)

1. **`TEST_DB=sqlite-file` como cuarto modo explícito** (la spec lo describía como «SQLite en fichero cuando se pida concurrencia» dentro de `sqlite`). Un modo con nombre es reproducible desde CI y desde la línea de comandos sin magia; `npm test` sigue siendo memoria + pool 1/1.
2. **El reloj llega al driver por un método opcional del puerto, `withClock(now)`**, y el manager lo aplica al resolver el driver (`driver()`), no solo «a las vistas»: las vistas comparten el driver del padre, así que lo heredan; y `driver()` —salida de las barreras— también lo lleva, porque el reloj no es una barrera sino la hora con la que se decide. Un driver de terceros sin `withClock` con `clock` declarado es 500 (nunca un reloj ignorado).
3. **Caducidad estricta explícita**: «vence en T» ⇒ en T ya no concede, en los dos drivers (`>` en SQL, `<` en la condición FGA). No es un cambio de semántica (ya era así), pero ahora está fijado al milisegundo.
4. **J4 sin rojo en los drivers**: los casos discriminan (mutante en (a)); (b) y (c) se apoyan en aserciones de coherencia de estado (`listRoles`/`hasRole`/`authorize`/`listSubjects` de acuerdo; secuencia monótona) y no tienen mutante determinista. `transactions` sigue `false`; no se tocó el puerto.
5. `created_at`/`updated_at` siguen como `timestamp` (la spec solo pedía `expires_at`; MySQL `TIMESTAMP` vale hasta 2038 y los sellos son «ahora»). `demo_scopes` (tabla ficticia del harness) conserva columnas `uuid` (ejercita el tipo nativo de PG en la CTE).
6. La contraseña de `postgres18` **no** está en el repo: el default de `TEST_PG_URL` es `postgres:postgres` (el de CI) y el README/CLAUDE.md dicen cómo pasarla. Ver §6.
7. En CI ambos servicios (PG y MySQL) arrancan en cada entrada de la matriz (`services:` no admite condicionales por matriz); coste aceptable frente a duplicar el job.

## 5. Archivos

Nuevos: `src/clock.ts`, `tests/clock.spec.ts`. Modificados (27): `src/types.ts` (`withClock?`), `src/define_config.ts` (`clock`), `src/manager.ts` (validación + aplicación del reloj), `src/drivers/database_driver.ts`, `src/drivers/openfga_driver.ts` (reloj; importador `now?`), `src/expiry.ts`, `src/catalog.ts`, `src/catalog_cache.ts`, `src/traits/authz_scopes.ts` (`systemClock`), `src/sql_descendants.ts` (MySQL: quoting, `[rows, fields]`, hint), `src/testing/contract.ts` (par `injectableClock`, `fixedClock`, casos J3 y J4), `stubs/migration.stub` (J3), `tests/helpers/schema.ts` (espejo), `tests/helpers/app.ts` (harness `TEST_DB`), `tests/helpers/load_without_sdk.ts` (teardown), `bin/test.ts`, `tests/contract.spec.ts` (`injectableClock: true`), `tests/contract_harness.spec.ts` (conteos + par del reloj), `tests/manager.spec.ts` (grupo `config.clock`), `tests/migration_stub.spec.ts` (`columnsInfo`; decisiones J3 en el texto), `tests/sql_descendants.spec.ts` (dialectos; ciclo > 1000), `package.json` (`test:pg`, `test:mysql`, `test:sqlite-file`; devDeps `pg`, `mysql2`), `package-lock.json`, `.github/workflows/ci.yml` (job `engines`), `README.md`, `CHANGELOG.md`, `CLAUDE.md`. Total `git diff --stat`: 27 archivos, +1514 −203 (más los 2 nuevos).

## 6. Cómo levantar los motores (esta máquina y CI)

- **PostgreSQL**: contenedor `postgres18` (imagen `postgres:18`, `127.0.0.1:5432`, usuario `postgres`, base admin `postgres`). Contraseña en `docker inspect postgres18 --format '{{range .Config.Env}}{{println .}}{{end}}' | grep POSTGRES_PASSWORD`. Ejecutar:
  `TEST_PG_URL='postgres://postgres:<POSTGRES_PASSWORD>@127.0.0.1:5432/authz_test' npm run test:pg` (añadir `OPENFGA_TEST_URL=http://localhost:8101` para el driver openfga). Si está parado: `docker start postgres18`.
- **MySQL**: contenedor `mysql84` (imagen `mysql:8.4`, `127.0.0.1:3306`, `root`/`root` = el default de `TEST_MYSQL_URL`). `npm run test:mysql`. Si está parado: `docker start mysql84`.
- Si no existieran: `docker run -d --name postgres18 -e POSTGRES_PASSWORD=postgres -p 127.0.0.1:5432:5432 postgres:18` y `docker run -d --name mysql84 -e MYSQL_ROOT_PASSWORD=root -p 127.0.0.1:3306:3306 mysql:8.4` (los defaults de las URLs ya apuntan ahí).
- La base de la URL (`authz_test`) es solo el NOMBRE BASE: cada ejecución crea `authz_test_<8 hex>` desde la conexión administrativa (`postgres` / sin base) y la borra en `teardown()` (`DROP DATABASE … WITH (FORCE)` en PG). Nunca se toca una base existente. Comprobación de residuos tras el cierre: 0 en PG, 0 en MySQL, 0 directorios `authz-sqlite-*` en `/tmp` (los 2 que quedaron eran de la ejecución `sqlite-file` anterior a la corrección del proceso hijo —las dos cargas de `purity.spec`, mismo segundo—; borrados, y verificado con `purity.spec` en `sqlite-file` que ya no fuga).
- **OpenFGA**: `:8101` (compose de `api-loco-base`); tope 3: `docker run -d --name openfga-tiny -p 8103:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3 -e OPENFGA_LIST_USERS_MAX_RESULTS=3 -e OPENFGA_DATASTORE_ENGINE=memory openfga/openfga:v1.19.0 run` → `OPENFGA_TEST_URL=http://localhost:8103 npm test` → `docker rm -f openfga-tiny` (hecho y eliminado).
- **CI** (`.github/workflows/ci.yml`, job `engines`): servicios `postgres:18` (`POSTGRES_PASSWORD=postgres`) y `mysql:8.4` (`MYSQL_ROOT_PASSWORD=root`) con healthcheck; OpenFGA `:8090` a mano; `npm run test:<engine>` sin y con `OPENFGA_TEST_URL`. Tiempo local por motor: ≈ 9–14 s sin FGA, ≈ 30 s con FGA (muy por debajo de los 3 min objetivo).

## 7. Pendiente para el dueño

Revisión de `tester-contrato` (mutantes sobre J1 y J3), `auditor-seguridad` (J3: collation, precisión, `varchar` vs `uuid`; J4) y `code-review`; commit. No hay release en esta fase.
