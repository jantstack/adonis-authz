# Síntesis del panel alpha.4 (coordinador, 2026-09-09) — sobre `panel-alpha4-{analista,tester,auditor}.md`

## Lo que hay (por gravedad), verificado por mí contra código y node_modules

1. **🔴 NUEVO, no reportado: `@jantstack/adonis-authz/commands` no es un loader de ace.** `configure.ts:47` registra
   ese módulo; ace exige `getMetaData()`/`getCommand()` (Lucid: `commands.json` + `main.js`; ace trae `ListLoader`).
   Nuestro `commands/main.ts` re-exporta clases ⇒ en un consumidor configurado con `node ace configure`, **`node ace`
   entero revienta** (`TypeError: loaderInstance.getMetaData is not a function`, medido por analista y tester contra
   el build). COGNITIV llegó a la línea 46 solo porque su workaround vive en SU `commands/` (FsLoader). Pregunta
   pendiente a COGNITIV: cómo tienen registrados nuestros comandos.
2. **Defecto reportado: `openfga:provision` con `startApp: false` lee `app.config` antes de `boot()`.** Confirmado.
   **Decisión: B, no A** (los tres coinciden, medido): `await this.app.boot()` en `prepare()` sin `start()`, con guarda
   de estado y `exitCode 1` si el config sigue sin existir. A (`startApp: true`) ejecuta preloads + `start`/`ready` del
   consumidor sin base (ECONNREFUSED antes de `run()`, medido), puede ser circular (`OPENFGA_STORE_ID`), y arrastra
   `lucid/services/db` pidiendo `Database` del contenedor (tester). El docblock «antes de que haya base» sigue siendo
   verdad con B; matiz: todo `config/*` debe poder importarse.
3. **Punto ciego de método: ningún caso ejecuta un comando por el kernel de ace** (nueve comandos, nueve helpers
   juzgados con config a mano; tres módulos no los importa ningún spec). Harness del tester, prototipado y ejecutado:
   `AppFactory` en proceso (jamás `IgnitorFactory`: reemplaza el `app` global), `kernel.exec` NO relanza (aserción
   sobre `cmd.error`), stub HTTP local (133 ms) y espía en `catalogs` («leyó ESTE config»). Rojo literal observado.
4. **`capabilities()`** (pregunta 1 de COGNITIV): sí. Método async en roles = `(await this.driver()).capabilities`
   — pasa la puerta 2 A PROPÓSITO (las capacidades son de la instancia); **jamás resolver el driver por otro camino
   ni tocar `#driver`** (🔴 del auditor: envenenaría la caché y apagaría el gate de deriva); sync en relaciones (driver
   eager). Devuelve copia CONGELADA y NORMALIZADA (`undefined` → `false`, todas las claves conocidas presentes; nunca
   `undefined`: repetiría el bug de `stillGranting`). Caso D-5 primero: `capabilities()` antes de `driver()` ⇒
   `driver()` sigue dando su 500. Bug aparte: `AuthorizationDriverCapabilities` no se exporta de `index.ts`.
5. **`sqlScopeEdges` multi-tabla** (pregunta 2): solo docs ahora, pero con la TRAMPA que encontró el analista: componer
   tres `sqlScopeEdges` ingenuamente NO emite las aristas entre tablas (silencio) y `--prune` las borra ⇒ subárbol
   entero denegando. README: «si tu árbol vive en más de una tabla, escribe tu `enumerateEdges` (UNION ALL, cursor por
   uuid) — la concatenación de helpers no vale, y por qué». Caso de letra E-1. Helper `composeScopeEdges` + caso
   ejecutable E-2 (dos tablas nuevas en el espejo, ×4 motores) ⇒ 2.6.
6. ⚪ del auditor: `provisionOpenFgaStore` crea el store ANTES de validar el modelo (store huérfano con catálogo
   inválido) y no pasa por `assertFactsModelPublishable` (techo de bytes como error crudo del SDK). Barato: invertir
   el orden y validar; entra si el implementador lo ve trivial, si no, 2.6.

## Lote `2.4.0-alpha.4` (un implementador; tester+auditor ya han dado casos y restricciones; auditor sobre el diff)
| pieza | dificultad |
|---|---|
| L-A loader de comandos (`ListLoader` sobre las nueve clases) + caso C-1 (barrel) + C-2 (metadata de los nueve) | trivial |
| L-B `openfga:provision` opción B + docblocks + caso 1 (sin servidor, harness del tester) + caso 2 (`:8101`) | fácil |
| L-C casos C-3/C-5: seis comandos con bail-out pre-base ejecutados por el kernel + diente estático | fácil |
| L-D `capabilities()` en los dos managers + export del tipo + ~10 casos (D-5 primero) + README | fácil |
| L-E README `sqlScopeEdges` multi-tabla con la trampa + E-1 | trivial |
| L-F ⚪ provisión: validar antes de crear el store | trivial |
| CHANGELOG (problema → decisión → qué NO), respuesta a COGNITIV | trivial |
**Total: ~28 casos, < 1 s en sqlite; un día. Sin breaking.**

## Qué NO se hace
`startApp: true`; homogeneizar los otros ocho; leer config «a mano» desde disco; `parentTable`/`composeScopeEdges`
ahora; tocar `driver()`; assembler en el build; tres comandos sin guarda pre-base (`unfreeze`, `prune-orphans`,
`scopes:relay`) siguen sin caso de ejecución (harness bicéfalo) — 2.6.

## Límites medidos
Analista midió en Node 22.23.2 / core 7.3.5 (COGNITIV: Node 24 / 7.3.3); repetir el caso 1 en Node 24 antes de
cerrar. El `:8101` estaba caído durante el panel: reiniciar contenedores antes del lote.
