# Lote B (plan 2.5) — cierre 1: informe del implementador (2026-10-15) ⇒ `2.5.0-alpha.2`

**Árbol `main` sobre `beb1d0a` + lote B (working tree, sin commit).** Único agente que muta el árbol; **sin commit, sin
tocar `version`, sin `git push`**. Entorno medido: Node 22 (`nvm use 22`), `postgres18`, `mysql84`, OpenFGA **`:8090`**
(`docker restart openfga-dev && sleep 8` antes de CADA suite). Brief: `loteB-cierre-coordinador.md` (dos 🟠, seis 🟡, seis ⚪,
dos respuestas, decisión 4 RECHAZADA). Método por hallazgo: **rojo observado** (los casos nuevos corridos sobre la copia
PRE-cierre del auditor, `scratchpad/audB/repo`, y los repros `audb_b3/b4/b6.spec.ts` como punto de partida) → verde →
**mutante** (aplicado y revertido sobre una copia aparte, `scratchpad/cierre1/repo`, script `mutants.py`; 20 mutantes de
comportamiento + 4 de TIPO sobre `typecheck`; todos muertos, tabla en §4).

## 0 · Rojos observados ANTES (casos nuevos sobre el árbol pre-cierre; `audB/repo`)

| Spec | Rojo observado |
|---|---|
| `relations_reconcile` | **3 failed / 29**: 🟠 2 «dry1 … expected 2 to equal 1» (el residuo se vendía como escritura pendiente); 🟠 1 «dry-run: X se pedirá borrar: expected 2 to equal 1» (el residuo iba a `toDelete`; la real lanzaba 422 a mitad); «relateOrSkip no traga: expected null to not equal null». |
| `relations_reconcile_cli` | **1 / 10**: «origen: ROJO si limpia — expected true to be false» (sin `details` ni contador, la pasada era limpia). |
| `command_flags` | **2 / 50**: 🟠 1 por el kernel «el comando REVENTÓ: E_AUTHZ_RELATION_USERSET_UNSUPPORTED …» (stack crudo, el `throw error`); 🟡 7 fila `novalida` «[error] No se pudo leer la con…» (vendida como lectura fallida). |
| `openfga_driver` | **3 / 45**: `readAllTuples (listRoles)` con `read ⇒ {}` ⇒ `[]` mudo; `purgeScope` «demostró cero con una respuesta sin tuples»; grep `tuples ?? []` presente. |
| `manager` | **2 / 97**: `new AuthorizationManager({ requireWithing: true })` entró; `buildRelationsManager({ relations: { denny } })` entró. |
| `relations` | **1 / 62**: `database: true` «entró en silencio: expected undefined to equal 422» (`includes: {}` era `TypeError`, ya DEFINIDA moría en «'membersOf' … no existe»). |
| `relations_persisted_config` | **2 / 8**: `saveRelationsConfig(configYaDefinida)` sin pista; JSON corrupto salía como `SyntaxError` crudo, no 422. |
| `upgrade_recipe` | **1 / 6**: «el README no tiene el bloque ```sql que empieza por "-- B3 · userset residue"» (la receta no existía como bloque ejecutable). |
| `scope_outbox` | **2 / 148**: el 500 no nombraba `pool >= 2`; el README no decía `pool max 1`. |
| `scope_depth` | **1 / 9**: el README no decía `listObjectsDeadlineMs: Infinity`. |
| `relations_harness` | **3 / 10**: `expected 28 to equal 29`. |
| `relations_openfga`, `guard_surface` | No ejecutables sobre el árbol viejo (importan `MONOTONIC_CLOCK`, que no existe ahí ⇒ rojos de carga); el rojo de 🟡 4 relaciones es el repro del auditor `audb_b4.spec.ts` (`{"objects":[]}` sin `truncated`). |

## 1 · Qué se hizo, por hallazgo (fichero:línea, caso, mutante, rojo)

### 🟠 1 · residuo del DESTINO en `--prune` ⇒ `extra` + `details`, cero throw, cero DELETE de plataforma
- **Código**: `src/relations/reconcile.ts:479` `classifySubject(tuple, toConfig)` (sujeto de cada tupla enumerada: `ok` /
  `userset-unsupported` / `undeclared`); destino `:638-640` el residuo va a `destResidue` y `usersetResidue` (NUNCA a
  `destByKey`), `:657` `toDelete` lo EXCLUYE (`!destResidue.has(tuple)`), `:446` suma a `extra` con o sin `prune`
  (`plan.destUsersetResidue`), `details` con `pruned: false` desde el plan cuando hay `prune` (también en `--dry-run`).
  `src/relations/define_relations_config.ts:323` `assertSupportedUserset` (la mitad de B3 sin config) y `:350`
  `RELATION_USERSET_RESIDUE_SELECT/DELETE` (la receta como constantes). Letra: `commands/authz_relations_reconcile.ts:119`
  (una línea `error` por residuo con lado, tupla y la receta literal; «--prune NO lo borra» / «tampoco lo borraría»),
  `:245` `clean` exige cero residuos, `:501` resumen «con sujeto userset no admitido en el origen N».
- **Caso**: `tests/relations_reconcile.spec.ts:373` (destino `database` REAL, residuo sembrado por SQL, `--prune`: sin throw,
  W escrita, X borrada, residuo intacto, `extra 1`, `details` `pruned:false`, mismos números en dry-run, idempotente, sin
  `--prune` también listado, y tras la receta ⇒ limpia; corre en los 4 modos = 3 motores) +
  `tests/command_flags.spec.ts:1948` (por el KERNEL: `--to=database --from=openfga --prune` ⇒ `run.error` undefined, exit 1,
  línea del residuo con receta, lo bueno escrito, residuo sigue) + `tests/relations_reconcile_cli.spec.ts:159` (letra × 5
  filas, la receta de la línea == la del README).
- **Mutante** (medido, copia): `O1.residuo-en-toDelete` (quitar `!destResidue.has`) ⇒ **2 rojos** (reconcile + kernel).
- **Rojo observado**: §0 (`relations_reconcile` 🟠 1, `command_flags` kernel).

### 🟠 2 · residuo del ORIGEN: clasificación en el PLAN; decisión 4 RECHAZADA
- **Código**: `src/errors.ts:969` `RelationUsersetUnsupportedError extends Exception` (422 propio, YA NO hereda de
  `RelationUnknownError`); `src/relations/reconcile.ts:593` origen ⇒ `skipped.usersetUnsupported += 1` + `details`
  `{ side: 'origen', reason: 'userset-unsupported' }` (con `toConfig` corre `assertUsersetSubject` entero: un userset de
  tipo/relación NO declarados ⇒ `skipped.undeclared` también en el plan, mismos números dry/real); `:698` `relateOrSkip`
  RELANZA la clase explícitamente. **Contador elegido**: `skipped.usersetUnsupported` (opcional, ausente = 0; camelCase
  como `undeclared`/`invalid`), `reason: 'userset-unsupported'` en `details`.
- **Caso**: `tests/relations_reconcile.spec.ts:319` (origen `database` REAL con residuo por SQL ⇒ dry1 = real = dry2:
  `written 1/1/0`, `skipped.usersetUnsupported 1` en los tres, `undeclared 0`, `details` origen, el `relate` del destino
  recibe SOLO lo bueno una vez, letra con residuo+lado+receta y sin el consejo falso, `clean=false`; con y sin `toConfig`)
  + `:444` («relateOrSkip no traga»: un destino que lanza la clase por un HOLDER propaga el 422).
- **Mutantes**: `O2.sin-clasificar-origen` ⇒ 1 rojo; `O2.relateOrSkip-traga` ⇒ 1 rojo; `O2.letra-sin-linea` ⇒ 1 rojo.
- **Rojo observado**: §0.

### 🟡 3 · letra del 500 de B6 (pool)
- `src/scope_outbox.ts:349`: el 500 dice «`{ transaction }` por el manager exige un pool >= 2 (… 503 `E_AUTHZ_BACKEND_TIMEOUT` a
  `freezeTimeoutMs`); con pool max 1 —el default de knex en TODO SQLite, fichero o :memory:— usa `requireTransaction: false`».
  README §Upgrading 9 y el párrafo de `requireTransaction` (:164): «pool max 1 — knex's default for every SQLite connection,
  file or `:memory:`» y que seguir solo el primer consejo lleva al 503.
- **Caso**: `tests/scope_outbox.spec.ts:4196` (letra del 500) + el caso de letra del README (`pool max 1`, `notInclude` de la
  frase vieja). **Mutante** `Y3.letra-pool` ⇒ 1 rojo. **Rojo**: §0.
- **No hecho**: detectar el pool al construir la outbox. Razón: (a) el 503 lo levanta la BARRERA del manager (`freeze`), no
  la outbox, que con trx y pool 1 encola bien; (b) doctrina publicada de `transactionalWrites` («el driver declara lo que su
  despliegue puede; el paquete no adivina el pool», README :207). Solo letra.

### 🟡 4 · `Array.isArray` en `ListObjects` y en las TRES lecturas de roles (gemelo de M8)
- `src/drivers/openfga_relations_driver.ts:647`: `!Array.isArray(response?.objects)` ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE`.
  Guardia: cuarta cara de la sonda `truncation` de `listObjects` (`tests/guard_surface.spec.ts:838`, mismo caso) y mutante
  **`openfga.listObjects.truncation.noObjects`** (`guard_mutants.json:1828`, `edits` de dos líneas) ⇒ corredor: muerto (1 rojo);
  **112 / 112**. Caso fuera de la guardia: `tests/relations_openfga.spec.ts:1639`.
- Roles: `src/drivers/openfga_driver.ts:3486` `tuplesOrThrow(response, what)` — punto de paso ÚNICO usado en `:3285`
  (`enumerateFacts`), `:3400` (`readEveryTuple`), `:3516` (`readAllTuples`) ⇒ 503. Caso: `tests/openfga_driver.spec.ts:1416`
  (las tres ⇒ 503; `purgeScope` con `read ⇒ {}` ⇒ 503 y CERO `deleteTuples`/`write`; grep: cero `tuples ?? []` en el
  fichero y exactamente 3 `this.tuplesOrThrow(`).
- **Mutantes**: `Y4.relations-objects-default` ⇒ 1 rojo; `Y4.roles-tuples-default` ⇒ 2 rojos. **Rojo**: §0.
- **Línea (a) de B4 reescrita con la verdad**: «roles: el driver de roles NO usa `ListObjects`; sus TRES `Read` hacían
  `response.tuples ?? []` —un 200 sin cuerpo era una enumeración vacía MUDA y `purgeScope` demostraba cero sobre ella,
  invariante 11 abierto desde antes de este lote—; desde el cierre 1 son exhaustivos o 503 por `tuplesOrThrow`, con caso
  y grep.» (CHANGELOG y README lo dicen así.)

### 🟡 5 · B3 en el runner PUBLICADO
- `src/testing/relations_contract.ts:1150`: caso del NÚCLEO «B3 · userset ≠ group#member» — por el MANAGER (espía:
  cero llamadas, cero eventos) y por el DRIVER en directo (`state.base`), seis operaciones, 422 con el `code`; control
  `group#member` entra por los dos caminos. Recuento **28 → 29** (`tests/relations_harness.spec.ts`). README §Upgrading 2
  (D13) ampliado. Nota: por el driver directo el runner no ve su backend (D13 tampoco): exige el 422 antes de cualquier
  efecto; «cero llamadas» se observa por el manager.
- **Mutante** `Y5.doble-sin-userset` (el doble vuelve al F-05 a secas) ⇒ **2 rojos** en `relations_contract.spec` (los dos
  harnesses del doble). **Rojo**: `relations_harness` 28≠29 (§0).

### 🟡 6 · punto de paso único de la forma del config de roles + guardia de TIPO
- `src/define_config.ts:506` `assertAuthorizationConfigShape` (exportada), llamada por `defineConfig`, por el CONSTRUCTOR de
  `AuthorizationManager` (`src/manager.ts:378`; cubre el provider) y por `buildRelationsManager`
  (`providers/authz_provider.ts:37`). `:461` `assertConfigBlock` (⚪ 13 gemelo: `scopes: true` ⇒ 500).
- **Guardia de tipo en compilación**: `src/define_config.ts:448-458` (`_exhaustiveRoot/OpenFga/Scopes/Relations/Hooks` =
  `Record<Exclude<keyof T, Known>, never> = {}` + `satisfies` por lista) y `src/relations/define_relations_config.ts:75-83`
  (raíz de la spec, `objectTypes[i]`, `relations[j]`, `database`). **Medido** sobre la copia: quitar `'clock'` de la raíz ⇒
  `TS2741 Property 'clock' is missing in type '{}'`; añadir `'onFoo'` a `hooks` ⇒ `TS1360`; en relaciones quitar
  `'relations'` ⇒ TS2741; añadir `deny?: boolean` al TIPO sin entrar en la lista ⇒ `TS2741 Property 'deny' is missing`.
- **Caso**: `tests/manager.spec.ts:4185` (constructor con `requireWithing`/`scopes.resolveChainz` ⇒ 500; `buildRelationsManager`
  con `relations.denny` ⇒ 500 ANTES de invocar la factory; los cuatro bloques con `true` ⇒ 500 nombrándolos).
- **Mutantes**: `Y6.constructor-sin-forma` ⇒ 2 rojos; `Y6.provider-relaciones-sin-forma` ⇒ 1 rojo; `W13.roles-bloque-no-objeto`
  ⇒ 1 rojo. **Rojo**: §0.

### 🟡 7 · config persistida que NO valida: rama propia
- `src/relations_config_store.ts:79`: JSON corrupto ⇒ `RelationConfigError` (422; «la lectura SÍ terminó»);
  `commands/authz_relations_reconcile.ts:427`: `error instanceof RelationConfigError` ⇒ «La config de relaciones persistida en
  authz_relations_config NO valida en 2.5: <motivo>. … Re-guárdala con `saveRelationsConfig(<spec corregida>)` —la spec, no la
  config ya definida— … No se ha construido, congelado ni escrito nada.», exit 1 (DISTINTA de «No se pudo leer…» 503 y de
  «ninguna persistida»). **Decisión**: exit 1 (como toda rama del comando; «exit propio» = su propia salida ≠ 0 con línea
  propia, no un código distinto de 1 — ningún comando del paquete usa otro). `openfga:provision` NO se nombra en la receta:
  no escribe `authz_relations_config` (comprobado: `commands/openfga_provision.ts` solo lee el config estático).
- **Caso**: `tests/command_flags.spec.ts:1895` tabla B5 de **4 filas** × modo (+ variante ciclo) por el kernel, fila sembrada
  TAL CUAL (`{...spec, deny: true}`), y `tests/relations_persisted_config.spec.ts:89` (fila pre-2.5 ⇒ 422
  `E_AUTHZ_RELATION_CONFIG_UNKNOWN_KEY`; JSON corrupto ⇒ 422; tabla ausente ⇒ 503). README §Upgrading 5 y 8.
- **Mutantes**: `Y7.sin-rama-no-valida` ⇒ 1 rojo; `Y7.json-corrupto-503` ⇒ 1 rojo. **Rojo**: §0.

### 🟡 8 · `--listObjects-deadline=0` ⇒ `listObjectsDeadlineMs: Infinity`; terceros
- **Medido** (no la memoria): `docker exec openfga-dev /openfga run --help` (v1.19.0): `--listObjects-deadline duration …
  (default 3s)` — a diferencia de `--listUsers-deadline`, su ayuda NO documenta el 0. Contenedor aparte
  `OPENFGA_LIST_OBJECTS_DEADLINE=0s`: arranca con `"ListObjectsDeadline":0` y `ListObjects` devuelve la lista entera en 5 ms
  (sin corte) ⇒ **0 = sin deadline**; control con `1ns` ⇒ `{"code":"deadline_exceeded"}` (error, no un 200 parcial).
- `src/drivers/openfga_relations_driver.ts:274`: `Infinity` aceptado (solo el tope señala); `0` sigue 500. Caso
  `tests/relations_openfga.spec.ts:1626`. README: §Upgrading 7, párrafo de relaciones (:688), Limits, y «Third-party drivers»
  (:252) «**the runner does not judge the deadline**» (letra fijada en `tests/scope_depth.spec.ts:105`).
- **Mutante** `Y8.sin-Infinity` ⇒ 1 rojo. **Rojo**: `scope_depth` (§0).

### ⚪ 9 · `monotonic` fuera del tipo publicado
- `src/drivers/openfga_relations_driver.ts:128` `MONOTONIC_CLOCK: unique symbol` (exportado por el módulo del driver, NO por
  `/openfga`); `:286` la clave de texto `monotonic` ⇒ 500 (L5: una opción inerte no cae en silencio); la vista `withClock`
  hereda el símbolo por el spread. Casos: `tests/relations_openfga.spec.ts:1601` (clave de texto ⇒ 500; README sin
  `monotonic:`/`MONOTONIC_CLOCK`; el símbolo no sale por `/openfga`); guardia y B4 pasan el símbolo. **Mutante**
  `W9.monotonic-por-texto` ⇒ 1 rojo.

### ⚪ 10 · guardia por fuente de `client.listObjects`
- `tests/relations_openfga.spec.ts:1654`: UNA ocurrencia de `client.listObjects(` en el driver y DENTRO de `#listObjectsPage`
  (patrón C5). **Mutante** `W10.segunda-llamada-listObjects` (una segunda llamada en `listSubjects`) ⇒ 1 rojo.

### ⚪ 11 · letra de `purgeObject`
- README §Upgrading 6: «`purgeObject(<the tuple's own object>)` removes them only together with every legitimate share of
  that object (`purgeObject` on the userset's object does not touch them)».

### ⚪ 12 · receta SQL de B3 EJECUTADA en los 3 motores
- README §Upgrading 6: la receta pasa a un bloque ```sql con marcador `-- B3 · userset residue` (detector + DELETE, las
  MISMAS dos sentencias en los tres motores). `tests/upgrade_recipe.spec.ts:705` (los 4 modos): las sentencias del README ==
  `RELATION_USERSET_RESIDUE_SELECT/DELETE` byte a byte; el detector lista exactamente los dos residuos (no los holders ni el
  `group#member`), el DELETE los quita y solo a ellos, lo legítimo sigue concediendo, idempotente. **Mutante**
  `W12.receta-sin-excluir-group` (README sin el `AND NOT (…)`) ⇒ 1 rojo. **Rojo**: §0.

### ⚪ 13 · bordes de B2
- `src/relations/define_relations_config.ts:86` `assertObjectBlock` (`database: true` ⇒ 422 nombrando el bloque), `:473`
  `includes` no-array ⇒ 422 con la ruta (antes `TypeError`), `:366` config YA DEFINIDA (lleva `isDeclared`/`hasType`) ⇒ 422
  «parece una config YA DEFINIDA … pasa la spec — también a saveRelationsConfig». Casos: `tests/relations.spec.ts:259`,
  `tests/relations_persisted_config.spec.ts:75`. Gemelo roles (`assertConfigBlock`) en 🟡 6. **Mutantes**:
  `W13.database-no-objeto` 1 rojo, `W13.includes-no-array` 1 rojo, `W13.config-ya-definida` 2 rojos.

### ⚪ 14 · precio en «Limits»
- README fila `ListObjects deadline`: «with the default, every `ListObjects` that takes 2,700 ms or more comes back
  `truncated` even when complete; a consumer that treats `truncated` as a 503 pays that p99 as user-facing 503s — raise the
  server's deadline (and this value) or handle `truncated` as a partial list». Fijado en `tests/scope_depth.spec.ts` (umbral
  calculado de las constantes + `p99`).

### Letra transversal
- `CHANGELOG.md:123` «### Closure 1 of lot B» (una entrada por hallazgo, estilo problema → decisión → qué NO se hace).
- README §Upgrading 2, 5, 6, 7, 8, 9 corregidos; párrafo de relaciones; Limits; Third-party drivers.
- `CLAUDE.md`: cifra 112 mutantes; regla del residuo de B3 en la fila de `src/relations/` (decisión 4 rechazada).
- `tests/freeze.spec.ts`, `EXPECTED_FUSED`, `migration_stub.spec`: **sin tocar**.

## 2 · Cuatro líneas de cierre (punto 5)

**🟠 1**
- (a) *Gemelos*: origen ↔ destino: los dos lados clasificados por la MISMA función (`classifySubject`); comando ↔ manager ↔
  función: `reconcileRelations` (plan), `runRelationsReconcile` (sin cambios: no toca el reporte) y el comando (letra) — caso
  por el kernel; `database` ↔ `openfga`: en `openfga` el residuo NO existe (el servidor rechazó esas tuplas: README) — el
  destino `openfga` con un origen `database` con residuo es el caso 🟠 2 (el origen lo descarta antes); doble: `makeRelationsDriver`
  rechaza el userset por B3, así que un doble como destino nunca lo contiene; `authz:reconcile` de roles: **no aplica** (sus
  hechos no tienen sujeto userset; lo no parseable ya cuenta en `diagnostics`). `--dry-run` ↔ real: mismos números (caso).
- (b) *Tabla de verdad*: §3.
- (c) *Casos existentes puestos rojos*: el caso «B3 · gemelo en el reconcile» del lote B (`skipped.undeclared = 1`, el driver
  recibía el `relate`) — **reescrito** como 🟠 2 (es la consecuencia directa de rechazar la decisión 4: ahora `usersetUnsupported
  = 1`, el driver NO lo recibe). Ningún otro.
- (d) *Linaje*: L8 («una operación destructiva lista lo que destruye», 10.ª iteración) — y R2-5 (lote D): «el plan clasifica, el
  driver no absorbe» aplicado hoy en vez de ampliarse el patrón «422 ⇒ skipped vía el driver». Es la misma regla del cierre-2
  del lote A (⚪ R2) extendida a un segundo motivo con un solo mecanismo (`details` + `pruned`).

**🟠 2**
- (a) *Gemelos*: dry-run ↔ real ↔ dry-run siguiente (caso, los tres iguales); con `toConfig` ↔ sin (caso, ambos); origen
  `database` real ↔ doble (el doble no puede contener residuo: B3); `relateOrSkip` ↔ plan (caso «no traga»).
- (b) *Tabla de verdad*: §3 (filas `origen`).
- (c) *Casos existentes rojos*: el B3 del lote B (arriba). El resto de `relations_reconcile`/`relations_reconcile_cli` verdes
  (los reportes sin `details`/`usersetUnsupported` siguen limpios: control existente).
- (d) *Linaje*: idem 🟠 1; además L1 (F-05) deja de ser la clase padre del userset: «una pregunta inválida del llamante» y «un
  dato del store que la API no admite» son dos cosas y se dicen con dos palabras.

**🟡 4** (gemelo de roles)
- (a) *Gemelos*: relaciones `#listObjectsPage` (objects) ↔ relaciones `#readAll` (tuples, ya existía) ↔ roles `tuplesOrThrow`
  (las TRES lecturas, una función); `purgeScope` (demostración de cero) con caso.
- (b) *Tabla de verdad* respuesta × envoltorio: {array (0..n) ⇒ lista/página; sin campo ⇒ 503; campo no array ⇒ 503} × {ListObjects
  relaciones, Read relaciones, Read roles ×3} — todas las celdas «sin campo» con caso (guardia + spec + roles).
- (c) *Casos existentes rojos*: ninguno (la sonda `truncation` de `listObjects` ganó una cara en el MISMO caso: 171 casos; el
  corredor 112 mutantes).
- (d) *Linaje*: L8/M8 — propiedad universal ahora cierta para los DOS puertos; punto de paso único por API; entrada en la guardia
  (mutante `noObjects`) para relaciones y grep por fuente para roles (sin guardia de superficie de roles: límite declarado).

## 3 · Tabla de verdad del reconcile con residuo de B3 (ejecutada: `relations_reconcile.spec` 🟠 1/🟠 2, `relations_reconcile_cli.spec`, `command_flags.spec` kernel)

| lado | modo | prune | bucket | `details` | línea (nivel `error`) | exit |
|---|---|---|---|---|---|---|
| origen | dry-run | sin | `skipped.usersetUnsupported` (no `written`) | `{origen, userset-unsupported}` (sin `pruned`) | «sin migrar (userset-unsupported) origen: … residuo pre-2.5 (B3) … ningún --prune lo toca. Bórrala a mano: DELETE …» | 1 |
| origen | dry-run | con | ídem | ídem | ídem | 1 |
| origen | real | sin | ídem (el driver NO recibe el `relate`) | ídem | ídem | 1 |
| origen | real | con | ídem | ídem | ídem | 1 |
| destino | dry-run | sin | `extra` | `{destino, userset-unsupported}` (sin `pruned`) | «sobra (userset-unsupported) destino: … y --prune tampoco lo borraría … Bórrala a mano: DELETE …» | 1 |
| destino | dry-run | con | `extra` (NO `deleted`) | `pruned: false` | «… --prune NO lo borra (nunca un DELETE de plataforma …) … DELETE …» | 1 |
| destino | real | sin | `extra` | sin `pruned` | «… tampoco lo borraría …» | 1 |
| destino | real | con | `extra`; cero `unrelate` por él; lo demás se escribe/poda | `pruned: false` | «… --prune NO lo borra …» | 1 |

Regla única (respuesta 1 del coordinador): el residuo se lista, exit ≠ 0 en los cuatro modos y los dos lados, se borra a mano
con la receta de la línea (== README, ⚪ 12); ninguna bandera lo toca. Tras la receta la pasada es limpia (caso).
Con `toConfig`, además: userset de tipo/relación NO declarados en el destino ⇒ `skipped.undeclared` en el plan (mismos
números dry/real); sin `toConfig` esa cara la embuda el 422 del driver como hasta hoy (docblock de `toConfig`).

## 3b · Tabla B5 (🟡 7), 4 filas × modo, por el kernel (`command_flags.spec:1895`)

| config persistida | dry-run | real |
|---|---|---|
| leída | exit 1 (deriva) · 0 escr. · «leída de authz_relations_config (N tipo(s)): la deriva del modelo se vigila» | exit 0 · 1 escr. · misma línea |
| `null` | exit 1 · 0 · «ninguna persistida … NO se vigila» | exit 0 · 1 · misma línea |
| **no valida** (`deny: true` pre-2.5; ciclo) | **exit 1 · 0 · «La config … persistida en authz_relations_config NO valida en 2.5: <'deny' en la raíz … / forman un ciclo> … re-guárdala con saveRelationsConfig(<spec corregida>) … No se ha construido, congelado ni escrito nada»** (sin «No se pudo leer», sin «ninguna persistida») | ídem |
| lectura falla (tabla ausente) | exit 1 · 0 · «No se pudo leer la config de relaciones persistida … NO es «no hay config»» (sin «NO valida») | ídem |

## 4 · Mutantes (copia `scratchpad/cierre1/repo`, `mutants.py`; aplicados uno a uno y revertidos)

| id | qué quita | rojos |
|---|---|---|
| O1.residuo-en-toDelete | el residuo del destino vuelve a `toDelete` | 2 / 79 |
| O2.sin-clasificar-origen | el origen no clasifica el userset | 1 / 29 |
| O2.relateOrSkip-traga | `relateOrSkip` devuelve `false` para la clase | 1 / 29 |
| O2.letra-sin-linea | el comando no imprime la línea del residuo | 1 / 10 |
| Y3.letra-pool | el 500 sin «pool >= 2» | 1 / 148 |
| Y4.roles-tuples-default | `tuplesOrThrow` ⇒ `?? []` | 2 / 45 |
| Y4.relations-objects-default | `objects ?? []` sin 503 | 1 / 8 |
| Y5.doble-sin-userset | el doble publicado vuelve al F-05 a secas | 2 / 58 |
| Y6.constructor-sin-forma | el constructor del manager no valida | 2 / 97 |
| Y6.provider-relaciones-sin-forma | `buildRelationsManager` no valida | 1 / 97 |
| Y7.sin-rama-no-valida | el comando sin la rama 422 | 1 / 50 |
| Y7.json-corrupto-503 | JSON corrupto como 503 | 1 / 8 |
| Y8.sin-Infinity | `Infinity` ⇒ 500 | 1 / 8 |
| W9.monotonic-por-texto | la clave `monotonic` aceptada en silencio | 1 / 8 |
| W10.segunda-llamada-listObjects | otra `client.listObjects(` fuera del envoltorio | 1 / 8 |
| W12.receta-sin-excluir-group | README sin `AND NOT (group#member)` | 1 / 5 |
| W13.database-no-objeto / includes-no-array / config-ya-definida / roles-bloque-no-objeto | cada guarda | 1 / 1 / 2 / 1 |
| Tipo (typecheck): quitar `'clock'`; añadir `'onFoo'`; quitar `'relations'` (spec); añadir `deny?` al tipo | guardia de TIPO | TS2741 / TS1360 / TS2741 / TS2741 |
| Corredor: `openfga.listObjects.truncation.noObjects` | el `?? []` de objects | muerto (1 rojo), 112/112 |

## 5 · Cifras (4 modos + 3 gates; en SECUENCIA, primer plano, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite)

| Qué | Resultado |
|---|---|
| `npm run build` | ✔ exit 0 (purity + typecheck + tsc + stubs) |
| `npm test` (`:memory:` + OpenFGA) | **1718 passed, 2 skipped (1720)**, 1 m 26 s (partida 1698: **+20**) |
| `npm run test:sqlite-file` | **1746 passed, 2 skipped (1748)**, 1 m 37 s (partida 1726: +20) |
| `npm run test:pg` | **1843 passed, 1 skipped (1844)**, 2 m 33 s (partida 1823: +20) |
| `npm run test:mysql` | **1845 passed, 1 skipped (1846)**, 2 m 33 s (partida 1825: +20) |
| `check:guard-mutants` (`:memory:`) | **112 / 112 muertos**, 0 vivos, 0 sin casar, 100 s (171 casos) |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes (`--allow-drop-deny`, `--prune-undeclared`), 47,6 s |
| `TEST_DB=sqlite-file cutover-runbook` | **VERDE**: 20 pasos + 2 pendientes, 13,8 s |
| `TEST_DB=pg cutover-runbook` | **VERDE**: 20 pasos + 2 pendientes |
| Bases huérfanas PG / MySQL · stores en `:8090` | 0 / 0 · 5 (los mismos de antes; ninguno creado por estas corridas) |

Desglose del **+20** (`:memory:`): `relations_reconcile` +2 (3 casos nuevos, 1 reescrito); `relations_reconcile_cli` +1;
`command_flags` +1 (kernel 🟠 1; la tabla B5 ampliada no suma); `openfga_driver` +3; `manager` +2; `relations` +1;
`relations_persisted_config` +2; `upgrade_recipe` +1; `relations_openfga` +3 (🟡 8, 🟡 4, ⚪ 10; el de opciones ampliado no suma);
runner de relaciones +1 × 4 harnesses = +4. `guard_surface` 171 (la cara nueva vive en el caso existente). `check:guard-mutants
-- --db sqlite-file` no se corrió (tiempo; el de `:memory:` cubre el mutante nuevo, que no toca SQL).

## 6 · Decisiones nuevas tomadas por el implementador (para ratificar)

1. **Contador `skipped.usersetUnsupported`** (opcional, ausente = 0) y `reason: 'userset-unsupported'`; el residuo del DESTINO
   es deriva también SIN `--prune` (a diferencia de `invalid-identity`, donde «repite con --prune» es un paso válido): aquí
   ninguna bandera lo arregla, así que `clean=false` en los cuatro modos con la receta en la línea. Alternativa descartada:
   warning sin prune (mentiría: la pasada siguiente con `--prune` tampoco lo quitaría).
2. **`pruned: false` desde el plan** para el residuo del destino con `prune` (también en `--dry-run`): «nadie lo borra».
3. **Con `toConfig`, el userset de tipo/relación NO declarados ⇒ `skipped.undeclared` en el plan** (`assertUsersetSubject`
   entera): cierra el mismo hueco dry≠real para esa cara; sin `toConfig` sigue el driver (documentado).
4. **🟡 7 con exit 1** y línea propia (no un código ≠ 1): coherente con todo el comando; el «exit propio» es la salida ≠ 0 con su
   rama nombrada (punto 7). `openfga:provision` no entra en la receta (no persiste la config).
5. **🟡 3 solo letra** (razones en §1).
6. **⚪ 9 por símbolo** (`MONOTONIC_CLOCK` del módulo del driver, no de `/openfga`) y la clave de texto `monotonic` ⇒ 500.
7. **Roles 🟡 4 sin entrada en la guardia de superficie** (no hay guardia de roles): el gemelo lo sujetan el caso del
   `purgeScope` + el grep por fuente (`tuples ?? []` = 0, `tuplesOrThrow` = 3). Límite declarado.
8. El runner B3 (🟡 5) afirma «cero llamadas» POR EL MANAGER (espía) y, por el driver directo, el 422 antes de cualquier
   efecto (como D13): el runner no ve el backend de un driver de terceros.

## 7 · Lo NO hecho y por qué

- Detección del pool 1 al construir la outbox (🟡 3): doctrina «el paquete no adivina el pool» y el 503 nace en la barrera
  del manager, no en la outbox. Solo letra (con caso).
- `check:guard-mutants -- --db sqlite-file`: no corrido por tiempo (el mutante nuevo no toca SQL; el de `:memory:` lo mata).
- Caso de `listObjects` contra un servidor real con `--listObjects-deadline=0` dentro de la suite: la medición se hizo A MANO
  en un contenedor aparte (§1 🟡 8) y queda escrita en README/CHANGELOG; el caso `Infinity` corre con reloj inyectado.
- `linajes.md` y `decisiones-dueno-*.md`: no editados (los administra el coordinador). Texto propuesto: L8 gana la 10.ª
  iteración (residuo de B3 en el reconcile, un solo mecanismo `details`/`pruned`) y M8 pasa a ser cierto en los DOS puertos
  (gemelo de roles por `tuplesOrThrow`); L5 gana la «entrada en la guardia» de TIPO (🟡 6, en compilación).

## Estado del árbol al cierre

```
$ git status --short
 M CHANGELOG.md
 M CLAUDE.md
 M README.md
 M commands/authz_relations_reconcile.ts
 M index.ts
 M package.json
 M providers/authz_provider.ts
 M src/define_config.ts
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_driver.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/manager.ts
 M src/openfga.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/relations/reconcile.ts
 M src/relations_config_store.ts
 M src/scope_outbox.ts
 M src/testing/relations_contract.ts
 M src/testing/scope_outbox_contract.ts
 M src/types.ts
 M tests/command_flags.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/freeze.spec.ts
 M tests/guard_surface.spec.ts
 M tests/helpers/cutover_child.ts
 M tests/helpers/relay_child.ts
 M tests/manager.spec.ts
 M tests/openfga_driver.spec.ts
 M tests/reconcile.spec.ts
 M tests/relations.spec.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/relations_persisted_config.spec.ts
 M tests/relations_reconcile.spec.ts
 M tests/relations_reconcile_cli.spec.ts
 M tests/scope_depth.spec.ts
 M tests/scope_outbox.spec.ts
 M tests/scope_outbox_contract.spec.ts
 M tests/scope_outbox_harness.spec.ts
 M tests/scope_outbox_multiprocess.spec.ts
 M tests/upgrade_recipe.spec.ts
?? src/relations_reconcile.ts

$ git diff --stat
 CHANGELOG.md                             | 201 ++++++++++++++++++++++++++
 CLAUDE.md                                |  15 +-
 README.md                                | 139 +++++++++++++++---
 commands/authz_relations_reconcile.ts    | 224 ++++++++++-------------------
 index.ts                                 |   4 +-
 package.json                             |   1 +
 providers/authz_provider.ts              |   5 +-
 src/define_config.ts                     | 133 +++++++++++++++++
 src/drivers/database_relations_driver.ts |   5 +-
 src/drivers/openfga_driver.ts            |  58 ++++++--
 src/drivers/openfga_relations_driver.ts  | 152 +++++++++++++++++---
 src/errors.ts                            |  38 +++++
 src/manager.ts                           |   7 +-
 src/openfga.ts                           |   2 +-
 src/relations/define_relations_config.ts | 235 +++++++++++++++++++++++++++++--
 src/relations/manager.ts                 |   6 +-
 src/relations/reconcile.ts               | 157 ++++++++++++++++++---
 src/relations_config_store.ts            |  23 ++-
 src/scope_outbox.ts                      |  25 ++--
 src/testing/relations_contract.ts        |  60 +++++++-
 src/testing/scope_outbox_contract.ts     | 200 +++++++++++++++++++-------
 src/types.ts                             |  10 +-
 tests/command_flags.spec.ts              | 193 +++++++++++++++++++++++--
 tests/fixtures/guard_manifest.ts         |  54 +++++--
 tests/fixtures/guard_mutants.json        | 164 ++++++++++++++++++++-
 tests/freeze.spec.ts                     |   6 +-
 tests/guard_surface.spec.ts              | 110 ++++++++++++---
 tests/helpers/cutover_child.ts           |   4 +-
 tests/helpers/relay_child.ts             |   2 +-
 tests/manager.spec.ts                    | 120 ++++++++++++++++
 tests/openfga_driver.spec.ts             |  57 ++++++++
 tests/reconcile.spec.ts                  |  64 ++++++++-
 tests/relations.spec.ts                  | 136 ++++++++++++++++++
 tests/relations_harness.spec.ts          |   5 +-
 tests/relations_openfga.spec.ts          | 136 +++++++++++++++++-
 tests/relations_persisted_config.spec.ts |  36 +++++
 tests/relations_reconcile.spec.ts        | 173 +++++++++++++++++++++++
 tests/relations_reconcile_cli.spec.ts    |  39 +++++
 tests/scope_depth.spec.ts                |  14 +-
 tests/scope_outbox.spec.ts               | 181 ++++++++++++++----------
 tests/scope_outbox_contract.spec.ts      |  26 +++-
 tests/scope_outbox_harness.spec.ts       |  18 ++-
 tests/scope_outbox_multiprocess.spec.ts  |   2 +-
 tests/upgrade_recipe.spec.ts             |  68 +++++++++
 44 files changed, 2859 insertions(+), 449 deletions(-)
```
(El stat es acumulado lote B + cierre 1 sobre `beb1d0a`; el cierre tocó 28 de esos ficheros, `tests/freeze.spec.ts` /
`EXPECTED_FUSED` / `migration_stub.spec` no.)
