# Fase 2 (HEAD `4346bcc`) — verificación del tester de contrato

> Worktree aislado `agent-ae6fe05683b14012c`, `npm ci`, Node 22.23.2, OpenFGA `:8101` compartido
> y un tope-3 propio en `:8112` (`openfga-tiny-tester`, ya borrado).
> **Nota de arranque:** el worktree se creó apuntando a `252ea8c` (main), no a `4346bcc`.
> Lo reseteé a `4346bcc` antes de medir. Todo lo de abajo es sobre `4346bcc`.

---

## 1. Suites (ejecutadas, no leídas)

| Configuración | Resultado | Esperado |
|---|---|---|
| `npm run typecheck` | ✅ sin errores | — |
| `npm test` (SQLite) | ✅ **250 passed** / 250, 5 s | 250 |
| `OPENFGA_TEST_URL=http://localhost:8101 npm test` | ✅ **332 passed** / 332, 16 s | 332 |
| tope 3 (`:8112`, `OPENFGA_LIST_*_MAX_RESULTS=3`, memory) | ✅ **332 passed** / 332, 14 s | 332 |

`check:purity` ✅ en las tres. Sin skips. El único ruido en stdout es el aviso de seguridad opt-in,
que es intencionado.

**Stores en `:8101`:** 48 antes / 54 después, pero los 6 nuevos son del **auditor** (`auditv4-*`,
`steal-*`, `cat-*`, `many-*`, timestamps 02:18–02:32). Mis corridas (suite y bench) no dejaron
huérfanos: la suite borra sus stores y el bench borra el suyo (lo imprime). **Neto mío: 0.**

## 2. Bench (`scripts/bench_authorize.mjs`, N=200, warmup=30, cadena 3, 5 roles/nivel, `:8101`)

Dos corridas (la 1.ª con ruido de arranque):

| Caso | factura por decisión | p50 (1.ª / 2.ª) | p95 | baseline `bf3fac9` |
|---|---|---|---|---|
| `openfga` TRUE | 1 SQL (**0 catálogo, 1 de versión**) + 1 batchCheck | 2,30 / **1,93 ms** | 4,29 / 3,72 | 1,92 · 4,07 |
| `openfga` FALSE | 1 SQL (1 versión) + **0 FGA** | **0,06 ms** | 0,07 | 0,00 |
| `database` TRUE | 3 SQL (**0 catálogo, 1 de versión**) | **0,35 ms** | 1,03 / 0,89 | 0,29 |
| `database` FALSE | 3 SQL (1 versión) | **0,25 ms** | 0,35 | 0,20 |

**Coherente con lo prometido**: exactamente **+1 SELECT por clave primaria por decisión**
(`authz_catalog_version`), 0 lecturas de catálogo en régimen estable, 1 batchCheck. Coste real de
F1: **+0,05–0,06 ms en `database`** y **≈0 en `openfga`** (1,93 vs 1,92; la diferencia entre mis dos
corridas —0,37 ms— es mayor que el efecto que se mide, así que el número del README, 2,35 p50, es
conservador y no optimista). El README §Performance no exagera.

---

## 3. Mutantes por pieza (siempre en `src/`, nunca en tests; revertido tras cada uno)

Método: sustitución exacta en `src/`, suite completa (SQLite y, cuando la pieza lo pide, `:8101`),
y se anota **qué test muere**. `✅` = el mutante muere (hay contrato que lo observa).

| Pieza | Mutante aplicado | sqlite | fga | Test que lo mata (abreviado) | R |
|---|---|---|---|---|---|
| **F1** | `CatalogCache.view()` sirve la foto sin revalidar | 12 ✗ | 14 ✗ | juez «el catálogo que decide es el de la base…» + 9 de `catalog_cache` + espías | ✅ |
| F1 (detalle) | idem, ¿y en `database`? | — | — | **sí**: en openfga muere en `there.authorize` (l.1369 del juez); en **database** muere en `there.effectivePermissions` (l.1371) — el join vivo de `authorize` no lo nota, `effectivePermissions` sí | ✅ |
| **F2** | quitar `#assertWithin` de `removeDeny` | 2 ✗ | 4 ✗ | juez «within en las otras cuatro escrituras» + «requireWithin: true ⇒ las seis…» | ✅ |
| F2b | `'non-root'` deja pasar `within: APP_SCOPE` | 1 ✗ | 2 ✗ | juez «…'non-root' rechaza además within: app» | ✅ |
| F2c | `scopes.attached` contrasta contra el **hijo** | 2 ✗ | — | juez «…attached/moved contra el padre» | ✅ |
| F2d | `scopes.detached` no contrasta | 1 ✗ | — | idem | ✅ |
| F2e | `revoke` no contrasta | 1 ✗ | — | idem | ✅ |
| **F3a** | quitar el contraste de pertenencia con `resolveAncestors` | 1 ✗ | — | juez «authorizedScopes ≡ { s \| authorize(s) }… (nodo ajeno)» | ✅ |
| **F3b** | deny aplicado solo al nodo, no a su cadena | 2 ✗ | — | «≡ authorize» (deny intermedio) + «some = directos ∪ descendientes menos denegados» | ✅ |
| F3c | subárbol excluido desconocido (`null` strict) ⇒ `[]` | 1 ✗ | — | manager «F10: … 503 (no se resta a medias)» | ✅ |
| F4 | generación de instancia tomada **después** de leer | 1 ✗ | — | `catalog_cache` «F4: invalidate() durante una carga en vuelo…» | ✅ |
| F5 | `authorizeMany` no valida el `boolean[]` del driver | 1 ✗ | — | manager «F5: … 500 E_AUTHZ_INTERNAL nombrando el driver» | ✅ |
| F6a | clave de visitados **sin separador** | 1 ✗ | — | `hierarchical_resolver` «F6: la clave lleva separador…» | ✅ |
| F6a′ | separador `` → `:` | 0 | — | **equivalente**: `:` está prohibido por la gramática (`TYPE_FORMAT`/`COMPONENT_FORMAT`), no hay colisión posible ⇒ no es hueco | ⚪ |
| F6b | el padre no pasa por `assertScope` | 1 ✗ | — | `hierarchical_resolver` «F6: un padre mal formado… 503» | ✅ |
| **F7** | el espía del juez vuelve a `value.apply(target, args)` | 1 ✗ | 2 ✗ | juez «authorizeMany: … vacío ⇒ [] sin backend ni árbol» | ✅ |
| F8a | no cortar por `maxScopes` antes de bajar | 2 ✗ | — | juez «maxScopes superado ⇒ 422…» + manager «F8» | ✅ |
| F8b | `maxScopes` por llamada puede **subir** el del config | 2 ✗ | — | idem | ✅ |
| F9 | la vista de `forRequest()` no caduca | 1 ✗ | — | manager «F9: … 500 E_AUTHZ_VIEW_EXPIRED» | ✅ |
| F10 | `expandExcludedSubtrees` no expande el subárbol | 2 ✗ | — | juez «all SOLO con excludedSubtrees…» + manager «F10» | ✅ |
| G1 | `sqlDescendantsOf` no valida `scopeType` al construir | 1 ✗ | — | `sql_descendants` «sin typeColumn, scopeType fija el tipo…» | ✅ |
| G2 | `authorizeMany` openfga sin dedupe de scopes repetidos | 1 ✗ | 1 ✗ | `openfga_driver` «N scopes ⇒ 1 batchCheck… un resultado por posición» | ✅ |
| G5 | `effectivePermissions` ignora `rolesInChain` | 2 ✗ | 3 ✗ | espías «lee roles y denies UNA vez (≤ 2 lecturas)» en **ambos** drivers | ✅ |
| **A1** | el motor memoiza **decisiones** (`authorize` cacheado) | 32 ✗ | — | `catalog_cache` «el memo nunca cachea hechos ni decisiones» + 31 más (deny gana, moved, expiresAt…) | ✅ |
| **A2** | `authorize` openfga vuelve a **dos** batchCheck | 3 ✗ | 4 ✗ | `openfga_driver` «un solo batchCheck» ×2 + espías + `catalog_cache` | ✅ |
| **A3** | las **escrituras** usan el resolutor memoizado | 2 ✗ | — | manager «B1/A3: la contención resuelve el árbol en FRESCO» + «F9» | ✅ |
| B1a | `within` hermano: no se comprueba pertenencia | 5 ✗ | — | los 3 casos del juez de `within` + manager B1/A3 | ✅ |
| B1b | escribir sobre scope **desconocido** no se rechaza | 2 ✗ | — | juez «within: grant/deny…» y «…otras cuatro escrituras» | ✅ |
| B2a | CTE pide `maxNodes` filas en vez de `maxNodes+1` | 2 ✗ | — | `sql_descendants` «maxNodes superado…» + «un ciclo… termina y lanza» | ✅ |
| B2b | no lanzar al superar la cota | 2 ✗ | — | idem | ✅ |
| B2c | el manager acepta más de `maxDescendants` nodos | 2 ✗ | — | manager «B3: clasifica las respuestas de descendantsOf» | ✅ |
| **B2d** | los `ScopeRef` de `descendantsOf` no pasan por `assertScope` | **0** | — | **SOBREVIVÍA** (hueco 2, ver §5) — cerrado por el parche | ❌→✅ |
| B3 | `authorizedScopes` devuelve lista **parcial** en vez de lanzar | 1 ✗ | — | manager «F8: … nunca parcial» | ✅ |
| B4 | `maxDepth` trunca en vez de lanzar (profundidad 65) | 1 ✗ | — | `hierarchical_resolver` «maxDepth (default 64) superado ⇒ lanza…» | ✅ |
| B5 | `rolesInChain` no filtra por expiración | 1 ✗ | — | juez «effectivePermissions: … roles **vigentes**…» | ✅ |
| B6a | `authorizeMany([])` no corta y va al backend | 2 ✗ | — | juez «vacío ⇒ [] sin backend ni árbol» + manager B6 | ✅ |
| B6b | error de un scope tragado (parcial en vez de lanzar) | 2 ✗ | — | juez «un scope que lanza ⇒ lanza entero» + manager B6 | ✅ |
| B7 | `requireActor` validado **después** de tocar el driver | 4 ✗ | — | manager «B7: … sin llamar al driver ni al hook» (+3 de coste) | ✅ |
| B7b | `requireActor: true` no exige actor | 1 ✗ | — | idem | ✅ |

**Cobertura de mutantes: 39 de 41 mueren.** Los dos supervivientes están en §5 (uno es
equivalente, el otro es hueco real y va con parche).

---

## 4. El juez

| Pregunta | Respuesta (medida) |
|---|---|
| `contract_harness` 36 / 49 / 60 | ✅ `assert.lengthOf(core, 36) / (full, 49) / (primitives, 60)`, y **es load-bearing**: añadir un `since('2.1', …)` al juez sin tocar el harness pone la suite en rojo (mutante `JUEZ-caso-nuevo`, 251 tests, 1 ✗). |
| `core ⊂ 2.0 ⊂ 2.1` | ✅ afirmado por título en el harness **y comprobado ejecutando**: `level:'core'` ⇒ **284 passed**, `'2.0'` ⇒ **310**, `'2.1'` ⇒ **332**. Deltas exactos: 13×2 = 26 (core→2.0) y 11×2 = 22 (2.0→2.1). |
| ¿Un driver que **ignora la primitiva** (`listDenies ⇒ []` siempre) pasa algún caso 2.1? | **No.** `database.listDenies ⇒ []`: **5 casos 2.1 mueren** (`authorizedScopes ≡ authorize`, `all/excludedSubtrees`, `some`, `effectivePermissions`, `listDenies`) + el espía de G5. Idéntico en `openfga` (5 casos + espía). Simular la primitiva con `[]` no cuela. |
| ¿`level: '2.0'` de un tercero sigue verde? | ✅ **310 passed, 0 failed** con `level:'2.0'` en `contract.spec.ts` (ambos drivers). La promesa del README «a driver without them keeps passing the same suite at `'2.0'`» está **verificada por ejecución**, no solo escrita. |
| ¿El espía de arquitectura de `descendantsOf` es vacuo? | **No.** El caso pone `descendantsCalls = 0`, corre `authorize`, `authorizeMany`, `hasRole`, los cuatro `list*`, `effectivePermissions`, `listDenies`, `isWithin`, `grant`, `deny` ⇒ `=== 0`, y **cierra con `assert.isAbove(descendantsCalls, 0)`** tras un `authorizedScopes`: si el espía no viera nada, el propio caso fallaría. |

---

## 5. Huecos

### 🟠 Hueco 1 — «identidad inválida ⇒ 0 llamadas al backend» quedó **relajada** en 2A/2D
`tests/spies.spec.ts` cambió `backendCalls` de `queries.length` a `factsQueries(queries)`
(= total − catálogo − `authz_catalog_version`). El caso *«una identidad inválida se rechaza con 0
llamadas al backend»* sigue usando `backendCalls`, así que **ya no observa lo que su comentario
promete** («Cero consultas es la prueba de que no hay rastro»).

Reproducido con dos mutantes que **sobrevivían** en HEAD:
- `database.authorize` llama a `findPermission` (catálogo + revalidación de versión) **antes** de
  `assertIdentity` ⇒ **250 passed**.
- `database.grant` llama a `catalog.view()` antes de `assertIdentity` ⇒ **250 passed**.

No es fail-open de autorización (sigue siendo 422), pero es la barrera L0.5/L0.10/L0.15 —
"validar antes de tocar la base" — que dejó de tener juez, en el único test que la vigilaba.
**Cerrado por el parche** (ambos mutantes mueren ahora).

### 🟡 Hueco 2 — un `ScopeRef` mal formado devuelto por `descendantsOf` se cuela en `expandExcludedSubtrees`
`#descendants` valida cada nodo con `assertScope`, pero quitarlo **no rompía ningún test**
(mutante `B2d`, 250 passed). En `authorizedScopes` el caso `[{type:'Unit',…}]` del manager
**pasa por la razón equivocada**: el 503 lo produce el contraste F3 con `resolveAncestors`
(que no conoce ese nodo), no la gramática. En `expandExcludedSubtrees` **no hay contraste**, así que
sin `assertScope` el consumidor recibiría scopes que el motor rechazaría — y construiría su
`NOT IN` con ellos. **Cerrado por el parche.**

### ⚪ Observaciones menores (sin parche)
- **Relajación honesta y compensada:** `openfga_driver.spec` bajó `assert.isAtLeast(batches.length, 3)`
  a `2` — es la consecuencia directa de A2 y está compensada con dos casos de **conteo exacto**
  (`1 llamada`) en el grupo nuevo. No es un hueco.
- El README promete «at `'2.1'` the cases that need `listDenies` fail with 500 `E_AUTHZ_UNSUPPORTED`
  naming it — never a skip». Está cubierto **en el manager** (`manager.spec`, «sin listDenies ⇒ 500
  UNSUPPORTED»), no como caso del **juez** con un harness cuyo driver carece del método. 🟡
  proponible para 2.5: registrar el contrato 2.1 sobre un driver-proxy sin `listDenies` y afirmar
  que los 5 casos fallan con ese código (hoy hay que creerse la composición).
- Mutante equivalente detectado y descartado: cambiar el separador `` por `:` no es
  observable, porque `:` está prohibido en `type` y `uuid` por la gramática. El mutante honesto
  (sin separador) sí muere.
- El aviso `warnOnOptInSecurity` ensucia la salida de la suite (una línea entre los `✔`). No es
  un defecto de contrato; sí es ruido que en Fase 1 se corrigió para el hook (`cba4678`).

---

## 6. Parche

`.claude/contexto/tests-tester-fase-2d.patch` (solo `tests/`, ninguna línea de `src/`):

1. `tests/spies.spec.ts` — el caso «una identidad inválida se rechaza con 0 llamadas al backend»
   envuelve la medida en un `countQueries` adicional y afirma `queries.length === 0`: ni hechos, ni
   catálogo, ni versión. Rojo con los dos mutantes del hueco 1, verde en HEAD.
2. `tests/manager.spec.ts` — el caso F10 añade tres `descendantsOf` que devuelven descendientes
   mal formados (`{type:'Unit'}`, `{type:'app', uuid:'X'}`, `{uuid: null}`) ⇒ 503
   `E_AUTHZ_RESOLVER_FAILED`. Rojo con el mutante `B2d`, verde en HEAD.

Verificación del parche: `npm run typecheck` ✅, `:8101` ⇒ **332 passed** (no sube el conteo: son
aserciones dentro de casos existentes, así que `contract_harness` no se toca).

---

## 7. Veredicto

# APTA CON CORRECCIONES

Las 16 piezas del lote 2D (F1–F10, G1–G6) y las de 2A/2B están **observadas por un contrato que
mata su mutante**, en los dos drivers y en las tres configuraciones. F1 mata en `openfga` por
`authorize` y en `database` por `effectivePermissions` — la divergencia que reportó el auditor está
cerrada por los dos lados. El juez no se puede engañar simulando `listDenies`, los niveles anidan y
un tercero en `'2.0'` sigue verde (ejecutado, no supuesto). El bench cobra exactamente lo prometido.

Las «correcciones» son las dos del §5, ambas **ya escritas y verificadas rojo→verde** en el parche;
son de cobertura, no de comportamiento (ningún fail-open en HEAD). Aplicando el parche, la Fase 2
se puede cerrar.
