# L-3 · `{transaction}` REAL en el driver `database`, puerto de ROLES — informe (para `2.4.0-alpha.2`)

> Base: `main` @ `c2937db` (= L-2 commiteado, árbol limpio al empezar; `git status` vacío). Árbol principal, SIN
> commits (los hace el dueño). Alcance: el lote L-3 del juez del panel `{trx}` (`panel-trx-juez.md` §7 · L-3,
> §1.1, §1.2 y §6.2). Regla que gobierna: **la ESCRITURA va por tu transacción; la AUTORIDAD (freeze,
> catálogo, `resolveChain`) NUNCA.** Decisión del dueño: `{ transaction }` exige **pool ≥ 2**.

Corridas a fichero en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`
(`l3-rojo-*.log`, `l3-verde-*.log`, `l3-mutante-*.log`, `suite-*.log`).

(Informe INCREMENTAL: se completa pieza a pieza según avanza el lote. El intento anterior de este lote se
perdió al apagarse la máquina; este arranca de cero sobre `c2937db`.)

## Plan de piezas (escrito antes de tocar código)

1. **Driver + runner**: `DatabaseAuthorizationDriver.grant/revoke/deny/removeDeny` escriben por la transacción
   del llamante (`assertCallerTransaction` contra `db.primaryConnectionName`); `transactionalWrites: true`;
   la cara `whenTrue` de `runAuthorizationDriverContract` (rollback ⇒ `authorize` false Y censo cero, para las
   cuatro; `{ transaction }` ajena/`db` entero ⇒ 500 `E_AUTHZ_CONFIG` con cero sentencias por ella). Rojo con el
   harness `database` declarando `true` antes de tocar el driver. Mutante obligatorio: ignorar `{ transaction }`.
2. **Casos de motor** (`tests/database_transaction.spec.ts`, gateado a pool ≥ 2): composición (`revoke` + UPDATE
   del consumidor + rollback ⇒ ni lo uno ni lo otro), otra conexión REAL, choque de UNIQUE de dos `grant`
   concurrentes en trx externas (medido por motor), deadline dentro de la trx externa + lo que publica
   `onWrite`, y la cara de `:memory:` (pool 1 ⇒ 503 por la barrera, cero sentencias por la trx).
3. **`freeze.spec.ts`**: los dos casos de L-2 se flipan para el driver capaz (`E_AUTHZ_FROZEN` con
   `{ transaction }` ⇒ cero sentencias por la trx del llamante).
4. Conteos de `contract_harness.spec.ts`; docs (CHANGELOG, README, docblocks).

## Pieza 1 · La escritura va por tu transacción (driver) y la cara `whenTrue` del runner ✅

**Código:**
- `src/drivers/database_driver.ts`:
  - `capabilities.transactionalWrites` pasa a **`true`** (default). La capacidad se construye en el
    constructor a partir de la opción nueva **`DatabaseDriverOptions.transactionalWrites?: boolean`** (default
    `true`): un despliegue con **pool 1** declara `false` y la puerta 1 del manager responde 500 al instante en
    vez de un 503 a `freezeTimeoutMs` (es la respuesta a «`:memory:` ⇒ `false`… o `true` gateado»: el DRIVER
    declara lo que su despliegue puede; el paquete no adivina el pool). Con `false` declarado, un
    `{ transaction }` que llegue igual al driver (saltándose el manager) también es 500 `E_AUTHZ_UNSUPPORTED`.
  - **`writer(operation, options)`**: `assertCallerTransaction('database.<op>', options.transaction, { connection:
    db.primaryConnectionName })` ⇒ `{ client: trx, external: true }` o `{ client: db, external: false }`. Lo usan
    `grant` (el «¿ya existe?», el INSERT y el UPDATE de `refreshAssignment`), `revoke` (DELETE), `deny` (el
    «¿ya existe?» y el INSERT) y `removeDeny` (DELETE). **Lo que NO pasa por él**: `knownScope`/`resolveChain`,
    `catalog.view()`, `findPermission`, `canonicalTargets` — autoridad, por `db`. La lectura «¿ya existe?» SÍ va
    por la trx porque forma parte de la misma escritura (un `grant` y su re-grant dentro de la misma
    transacción tienen que verse).
  - **`poisoned(operation, error)`**: dentro de una trx externa un INSERT que falla NO se relee (en PG la trx ya
    está abortada; en REPEATABLE READ la relectura no vería al ganador): choque del UNIQUE ⇒ **409
    `E_AUTHZ_WRITE_CONFLICT`** («envenena tu transacción: haz rollback y reintenta»); deadline ⇒ el 503
    `E_AUTHZ_BACKEND_TIMEOUT` que ya clasificó `sql()`; otro ⇒ su 503. Nunca una segunda sentencia sobre una
    trx que puede estar abortada. (Los casos por motor son la pieza 2.)
  - `revoke`/`deny`/`removeDeny` reciben `options?: WriteOptions` (el puerto ya lo declaraba desde L-2).
- `src/shared/backend_guard.ts`: **`isUniqueViolation(error)`** (PG `23505`, MySQL `errno 1062`, SQLite
  `SQLITE_CONSTRAINT_UNIQUE`/`SQLITE_CONSTRAINT` + «UNIQUE»), mirando la cadena de `cause`.
- `src/testing/contract.ts`: **`DriverContractHarness.transactions?: ContractTransactions`** (`begin()` ⇒
  `{ client, commit, rollback }` y `census(subject)` ⇒ `{ assignments, denies }`), con default
  **`lucidContractTransactions()`** (`db.transaction()` + `authz_assignments`/`authz_denies`; exportado desde
  `/testing`). Un driver de terceros con otra conexión u otras tablas trae el suyo. La cara **`whenTrue`** del
  par `transactionalWrites` (todos los niveles: es composición del manager):
  «`transactionalWrites: true · grant/revoke/deny/removeDeny con { transaction } + rollback ⇒ authorize sin
  cambio Y CERO filas (censo); + commit ⇒ aplicado; una transacción ajena, un cliente sin transacción o el
  `db` entero ⇒ 500 E_AUTHZ_CONFIG sin UNA sentencia por ella`». Para cada una de las cuatro: rollback ⇒
  **censo** intacto + `authorize` sin cambio + **mientras la trx está abierta la autoridad (que lee por la
  conexión del motor) no ve la escritura**; commit ⇒ censo y `authorize` cambian. Y tres transacciones que no
  son la del driver (otra `connectionName`, `isTransaction: false`, la forma del `db` entero) ⇒ 500
  `E_AUTHZ_CONFIG` nombrando la operación, con un espía que cuenta `from/table/raw/query/knexQuery` = `[]`.
  El rollback va en `finally` (lección de la primera corrida: una trx que se queda abierta tras una aserción
  fallida retiene una conexión del pool de `sqlite-file` y la corrida se colgó hasta el `timeout` externo).
- `tests/contract.spec.ts`: `TRANSACTIONAL_WRITES = testEngine() !== 'sqlite'`; los tres harness `database`
  lo declaran y construyen el driver con `transactionalWrites: TRANSACTIONAL_WRITES`; el harness `openfga`
  (facts) fija `transactionalWrites: false` explícito (antes heredaba el literal por spread).

**Rojo literal** (`l3-rojo-censo-sqlite-file.log`, el driver declaraba `true` y escribía por `db`):
```
ℹ AssertionError: ROJO: la asignación sobrevivió al rollback (la escritura NO fue por la transacción del llamante): expected { assignments: 1, denies: +0 } to deeply equal { assignments: +0, denies: +0 }
Tests  91 passed, 1 failed (92)
```
**Verde**: `l3-verde-censo-sqlite-file.log`, `l3-verde-censo-pg.log`, `l3-verde-censo-mysql.log` — «Tests 92
passed (92)» en los tres motores (grupo `authorization contract [database · 2.2]`).

**MUTANTE OBLIGATORIO** (`l3-mutante-ignora-trx-sqlite-file.log`): `writer()` devuelve `{ client: db, external:
true }` (valida la transacción y la ignora al escribir) ⇒ **1 failed**, exactamente el rojo de arriba (la fila
sobrevive al rollback). Restaurado desde copia; `grep -rc MUTANT src` = 0.

## Pieza 2 · Los casos de motor (`tests/database_transaction.spec.ts`, nuevo) ✅ — y la decisión sobre `onWrite`

**La decisión sobre `onWrite` + deadline dentro de una trx externa** (invariante 13 vs 🟡 12 del auditor):
`indeterminate: true` SE MANTIENE (invariante 13 intacto) **y el evento gana `transactional: true`**
(`AuthzWriteEvent.transactional?: boolean`, nuevo, aditivo): lo llevan TODOS los eventos de una escritura
inscrita en la transacción del llamante (`granted`/`extended`/`revoked`/`denied`/`deny_removed`), porque en el
instante del evento la fila existe SOLO dentro de esa transacción y es un hecho si y solo si el llamante
confirma — cosa que el paquete no ve. El argumento del auditor («el rollback la determina») es cierto para el
LLAMANTE, no para el paquete: en el 503 la sentencia puede haber aterrizado en la trx (SQLite no cancela; MySQL
la mata y la trx sigue viva; PG deja la trx abortada) y confirmar o no es del llamante. Lo honesto es el mismo
«no lo sé» más la marca de que la última palabra es su commit; un sink que quiera la última palabra se cuelga
de `trx.after('commit')`. `manager.ts`: `#transactional(options)` + docblock de `#write`; `types.ts`: docblocks
de `indeterminate` y `transactional`. El encolado de `scopes.*` NO lleva la marca (encolar ≠ escribir).

**Casos (7 en pool ≥ 2, 1 en `:memory:`; verde a la primera en los cuatro modos: `l3-motor-{sqlite,sqlite-file,
pg,mysql}.log`):**

1. **COMPOSICIÓN**: `revoke` + `UPDATE` de `l3_consumer_rows` (tabla del consumidor creada en el `group.setup`)
   en la MISMA `db.transaction` + `throw` ⇒ `authorize` sigue `true`, censo `{1,0}`, la fila `'con acceso'`;
   dentro de la trx el UPDATE ya es visible POR ELLA y el revoke NO lo ve la autoridad (por `db`); + commit ⇒
   los dos. El evento `revoked` lleva `transactional: true` y sin `transaction` no la lleva.
2. **Re-escritura dentro de la misma trx**: `grant` + re-`grant` con caducidad + `deny` ×2 en la misma trx ⇒
   `existed: true` y UNA fila de cada (la lectura «¿ya existe?» va por la trx: ve lo que la trx escribió);
   rollback ⇒ censo `{0,0}`.
3. **Otra conexión REAL** (`db.manager.add(other, node.config)` + `db.connection(other).transaction()`): las
   cuatro ⇒ 500 `E_AUTHZ_CONFIG` nombrando `'<other>'`, `'<primaria>'` y `database.<op>`; espía sobre la trx real
   (Proxy que cuenta `from/table/query/raw/…`) = 0; censo `{0,0}`.
4. **`transactionalWrites: false` declarado** (pool 1): puerta 1 ⇒ 500 nombrando `transactionalWrites`, 0
   sentencias; y saltándose el manager (`driver.grant` directo) el driver también responde 500 («pool 1» en el
   mensaje); sin `transaction` entra.
5. **Choque del UNIQUE de dos `grant` concurrentes en dos trx externas** — T1 inserta sin confirmar, T2 inserta lo
   mismo, 300 ms, T1 confirma. **Medido por motor:**

   | motor | qué hace el INSERT de T2 | error de T2 | ¿T2 sigue viva después? | tiempo |
   |---|---|---|---|---|
   | **PG** | ESPERA en el índice único hasta que T1 confirma; `23505` | **409 `E_AUTHZ_WRITE_CONFLICT`** («haz rollback y reintenta») | **NO: abortada** (`25P02` en la siguiente sentencia hasta el rollback) | 324 ms |
   | **MySQL** | ESPERA (S-lock en el registro duplicado) hasta que T1 confirma; `1062` | **409 `E_AUTHZ_WRITE_CONFLICT`** | **SÍ**: solo se deshace la sentencia | 329 ms |
   | **sqlite-file (WAL)** | NO espera: T2 ya tiene snapshot de lectura y no puede subir a escritor mientras T1 tiene el RESERVED; SQLite no invoca el busy-handler ahí (evita el deadlock) ⇒ `SQLITE_BUSY` inmediato, ANTES de que T1 confirme | **503 `E_AUTHZ_BACKEND_UNAVAILABLE`** (causa `SQLITE_BUSY`) | SÍ | 309 ms (los 300 del sleep) |

   En los tres, `onWrite` publica UN solo evento (el `granted` de T1 con `transactional: true`): el perdedor no
   es un deadline y no publica indeterminado; el censo es la fila de T1.
6. **Deadline vencido DENTRO de la trx externa** (`timeoutMs: 400` en el driver, T2 esperando en el UNIQUE):

   | motor | qué pasa a los 400 ms | error | `onWrite` | ¿T2 viva? |
   |---|---|---|---|---|
   | **PG** | knex cancela (`pg_cancel_backend`), `57014` | 503 `E_AUTHZ_BACKEND_TIMEOUT` (430 ms: por el deadline del driver, no por el lock-wait del motor) | `['granted', transactional, false]` (T1) + `['granted', transactional, **indeterminate**]` (T2) | **NO: abortada** (`25P02`) |
   | **MySQL** | knex mata la consulta (`KILL QUERY`), `1317` | 503 `E_AUTHZ_BACKEND_TIMEOUT` (423 ms) | ídem | **SÍ** |
   | **sqlite-file** | no hay deadline que vencer (better-sqlite3 es síncrono): `SQLITE_BUSY` inmediato | 503 `E_AUTHZ_BACKEND_UNAVAILABLE` (7 ms) | solo el de T1: sin deadline no hay indeterminado | SÍ |

7. **La cara de `:memory:`** (corre en los CUATRO modos, con rama por motor como el caso de pool 1 de L-1):
   `freezeTimeoutMs: 400`, el llamante sostiene la única conexión, `grant` con `{ transaction: spy(trx) }` ⇒ en
   `:memory:` 503 `E_AUTHZ_BACKEND_TIMEOUT` en 416 ms (por la barrera, no por los 60 s del pool), **0 sentencias
   por la trx**, censo `{0,0}`, `onWrite` vacío; en pool ≥ 2 la misma escritura entra POR la trx (>0 sentencias)
   y confirma con ella.

**Mutante de `poisoned`** (`l3-mutante-poisoned-{pg,mysql}.log`: `grant` absorbe el UNIQUE dentro de la trx como
fuera de ella, releyendo): PG ⇒ **2 failed** — el 409 pasa a ser 503 `E_AUTHZ_BACKEND_UNAVAILABLE` por `grant.race`
(la relectura muere con `25P02`: la trx ya estaba abortada) **y el deadline también** (tras el timeout la relectura
falla igual y el 503 pierde su código de TIMEOUT); MySQL ⇒ **1 failed** — la relectura en REPEATABLE READ no ve al
ganador, `raced` es null y sale el 503 crudo de `grant.insert`. Es la demostración de que «no releer dentro de la
trx» no es estilo: son dos motores que fallan de forma distinta si se relee. Restaurado; `MUTANT` = 0.

## Pieza 3 · Los dos casos de L-2 en `freeze.spec.ts`, FLIPADOS para el driver capaz ✅

`tests/freeze.spec.ts` gana `databaseWorker()` (manager sobre el `DatabaseAuthorizationDriver` REAL), `L3_CATALOG`,
`spyTransaction()` y `factRows()`. Los dos casos del grupo «L-1 · 🟠 8» conservan lo que L-2 fijó (con el
`spyDriver()` sin capacidades, `{ transaction }` es el 500 de la puerta 1) **y ganan el flip**:

- **Caso 1 (cliente mentiroso)**: con el driver `database` (`true`) y el freeze de A vivo, las CUATRO de hechos con
  `{ actor, transaction: liar }` ⇒ **503 `E_AUTHZ_FROZEN` reintentable**, `liar.reads() === 0` (la barrera manda
  otra vez y sigue sin leerse por el cliente del llamante), censo 0. Tras el `unfreeze` el mismo cliente llega al
  driver y **lo juzga `assertCallerTransaction`**: no es una transacción ABIERTA de Lucid ⇒ 500 `E_AUTHZ_CONFIG`
  («isTransaction» en el mensaje), `liar.reads()` sigue en 0 (juzgar no es escribir). Corre en los cuatro modos.
- **Caso 3 (snapshot; PG/MySQL/sqlite-file)**: dentro de la trx del llamante (REPEATABLE READ en PG/MySQL) con el
  freeze del operador puesto DESPUÉS de su primera lectura, las cuatro con `{ actor, transaction: spy(trx) }` ⇒
  503 `E_AUTHZ_FROZEN` con «authz:unfreeze» y **`spy.statements() === 0`** (ni un SELECT del paquete por la trx del
  consumidor). Tras el `unfreeze`, la MISMA llamada **entra POR la trx** (>0 sentencias), la conexión del motor no
  la ve hasta el commit (`authorize` false, censo 0) y al confirmar `db.transaction` queda escrita (censo 1,
  `authorize` true) — en PG y MySQL. **En `sqlite-file` NO entra, y es del motor**: la trx del llamante leyó antes
  de que el freeze y el unfreeze confirmaran, su snapshot quedó atrás y SQLite no la deja subir a escritora
  (`SQLITE_BUSY`, BUSY_SNAPSHOT) ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE` clasificado, censo 0. Medido y fijado con rama
  por motor (primera corrida en `sqlite-file` roja por esto: `AuthorizationBackendError … (grant.insert)`).

**Rojo literal del flip** (`l3-rojo-flip-{sqlite,pg}.log`: el driver en el estado de L-2, `transactionalWrites ??
false` como default): SQLite **1 failed**, PG **2 failed**, todos con
```
ℹ AssertionError: expected 'E_AUTHZ_UNSUPPORTED' to equal 'E_AUTHZ_FROZEN'
```
**Verde** (`l3-verde-flip-{sqlite,sqlite-file,pg,mysql}.log`): 19/19 en los cuatro modos.

## Pieza 4 · Conteos, capacidades literales y docs ✅

- `tests/contract_harness.spec.ts`: el caso L-2 pasa a «L-2/L-3»: `transactionalWrites: true` ya NO se rechaza al
  registrar; registra la cara `true` (título `transactionalWrites: true · grant/revoke/deny/removeDeny con
  { transaction } + rollback ⇒ authorize sin cambio Y CERO filas (censo)…`) en core y en 2.2, la `false` no, y
  **las cuentas no se mueven** (core 41, 2.2 con `purgeRole: true` 88 = 83 + 5): el par es UN caso por cara. Las
  ocho cifras literales de L-2 siguen iguales. Rojo intermedio real: mi primera aserción decía 83 y el harness
  respondió 88 (`expected [ …(88) ] to have a length of 83`): 83 es 2.2 SIN `purgeRole`; corregido.
- `tests/openfga_facts.spec.ts` («las capacidades declaradas del driver son las de la tabla del README»): el literal
  de `database` pasa a `transactionalWrites: true`; añade que `{ transactionalWrites: false }` declara `false` y que
  la vista por prototipo (`withClock`) declara lo MISMO (única roja de la primera corrida completa en
  `:memory:`/`sqlite-file`: `expected { hierarchyFacts: false, …(8) } to deeply equal …`).
- **README**: fila `transactionalWrites` (`database` = **`true`**, con la opción para pool 1); fila
  `E_AUTHZ_WRITE_CONFLICT` (el UNIQUE dentro de tu transacción envenena la trx: rollback y reintenta); sección
  nueva **«Writing facts inside your transaction (2.4.0-alpha.2, lot L-3)»** tras las dos reglas de L-1: qué va
  por la trx y qué no, pool ≥ 2 y la opción del driver, freeze ⇒ 503 antes de la primera sentencia, la tabla por
  motor del UNIQUE / deadline / qué queda de la trx, el BUSY_SNAPSHOT de SQLite, y el límite conocido de
  `resolveChain` (§6.2) con la salida (la receta completa es L-6); párrafo de `transactional: true` junto al de
  `indeterminate`; el snippet del harness gana `transactions` y el comentario de la cara `true`.
- **CHANGELOG** (`[Unreleased] — 2.4.0-alpha.2`, sección «Lot L-3» ANTES de L-2): problema → decisión → las
  consecuencias medidas (pool ≥ 2 y la opción, freeze, conexión, el UNIQUE por motor con el mutante, el deadline y
  la decisión de `onWrite`, la cara `true` del runner y el hook) → **qué NO se hace** (L-4, L-5, L-6, `resolveChain`
  sin trx, delegación).
- Docblocks: `AuthorizationDriverCapabilities.transactionalWrites` (types.ts), `DriverCapabilities.transactionalWrites`
  (contract.ts), `DatabaseDriverOptions.transactionalWrites`, `writer()`/`poisoned()`, `AuthzWriteEvent.transactional`
  e `indeterminate`, `#write` del manager.

## Cómo quedó el harness `database` (true/false por motor)

| modo | harness `database` ×3 (`database`, `sin listDenies`, `árbol SQL` en PG/MySQL) | driver | cara juzgada |
|---|---|---|---|
| `:memory:` (pool 1/1) | `transactionalWrites: false` | `new DatabaseAuthorizationDriver({ transactionalWrites: false })` — lo que un despliegue con pool 1 declara | `whenFalse` (500 al instante, cero llamadas; puerta 2) + la cara honesta de pool 1 en `database_transaction.spec.ts` (503 por la barrera, cero sentencias por la trx) |
| `sqlite-file`, PG, MySQL | `transactionalWrites: true` | default (`true`) | `whenTrue` (rollback ⇒ censo cero ×4, commit, invisible sin confirmar, trx ajena ⇒ 500 sin sentencia) |
| `openfga` (facts) | `transactionalWrites: false` explícito | `false` | `whenFalse` |

Decisión, en una frase: **el DRIVER declara lo que su despliegue puede** (opción `transactionalWrites`, default
`true`); el paquete no adivina el pool, y `:memory:` declara `false` porque con pool 1 la cara `true` no se
puede juzgar sin colgarse (lo que haría es el 503 de la barrera, fijado aparte).

## Las 4 cifras (todas con `OPENFGA_TEST_URL=:8101`, corridas a fichero)

Antes: `npx tsc --noEmit -p tsconfig.json` ✔ · `npm run typecheck` ✔ (0 errores) · `npm run check:purity` ✔ ·
`npm run build` ✔ (`l3-build.log`).

| modo | base (L-2) | ahora | log |
|---|---|---|---|
| `npm test` (SQLite memoria) | 1046 | **1047 passed (1047)** | `suite-sqlite.log` |
| `npm run test:sqlite-file` | 1054 | **1061 passed (1061)** | `suite-sqlite-file.log` |
| `npm run test:pg` | 1149 | **1156 passed (1156)** | `suite-pg.log` |
| `npm run test:mysql` | 1149 | **1156 passed (1156)** | `suite-mysql.log` |

+1 en `:memory:` (la cara de pool 1 de `database_transaction.spec.ts`); +7 en los motores con pool ≥ 2 (los 6 del
grupo gateado + la cara de pool 1, que en ellos afirma que la escritura entra por la trx). Los tres harness
`database` cambian de cara (`whenFalse` → `whenTrue`) sin mover la cuenta; los dos casos de `freeze.spec.ts`
cambian de contenido sin cambiar de número. Aditivo: ningún caso existente cambió de resultado salvo el literal
de capacidades de `openfga_facts.spec.ts` (dicho arriba). Cero rojas transitorias en las cuatro corridas
finales (PG y MySQL corrieron tras la corrección del literal; SQLite y `sqlite-file` se repitieron después).
Stores del `:8101` al terminar: `{"stores":[]}`. `grep -rc MUTANT src tests` = 0.

## Ficheros tocados

- `src/drivers/database_driver.ts` — `writer()`, `poisoned()`, escrituras por la trx, `transactionalWrites` (opción
  + capacidad construida en el constructor), `options` en `revoke`/`deny`/`removeDeny`.
- `src/shared/backend_guard.ts` — `isUniqueViolation`.
- `src/manager.ts` — `#transactional(options)`, la marca en los cinco eventos de hechos, docblock de `#write`.
- `src/types.ts` — `AuthzWriteEvent.transactional`, docblocks de `indeterminate` y de la capacidad.
- `src/testing/contract.ts` — `ContractTransactions`, `lucidContractTransactions`, `harness.transactions`, la cara
  `whenTrue`, docblock de la capacidad. `src/testing/main.ts` — exporta los dos.
- Tests: `tests/database_transaction.spec.ts` (**nuevo**, 7 + 1), `tests/contract.spec.ts` (`TRANSACTIONAL_WRITES`
  por motor, opción del driver, `openfga` explícito), `tests/freeze.spec.ts` (dos casos flipados + helpers),
  `tests/contract_harness.spec.ts` (la cara `true` registra; cuentas), `tests/openfga_facts.spec.ts` (literal).
- `README.md`, `CHANGELOG.md`.

## Lo que NO hice, y por qué

- **`relations/` no se tocó** (`relate`/`unrelate`/`purge*` siguen declarando `false`): es L-4, en secuencia tras
  R-15. `openfga` sigue en `false` (no puede ser otra cosa) y su rechazo con dientes contra el `:8101` es L-5.
- **`resolveChain` no recibe la transacción** (§6.2 del juez): crear un scope y conceder en él dentro de la misma
  trx sigue siendo 422 `E_AUTHZ_UNKNOWN_SCOPE` (fail-closed). No hay caso nuevo que lo fije: el juez lo asigna a
  L-6 junto con la receta; el README lo DECLARA ya como límite conocido con la salida en una frase.
- **La receta por dirección de `openfga`, la frase del freeze ampliada (§6.3) y la reescritura de
  `roadmap-2.0.md:103`** son L-6.
- **No deferí `onWrite` al commit** (`trx.after('commit')`): habría cambiado el momento del evento para todos y
  atado el paquete a la forma de Lucid; elegí notificar al volver el driver con la marca `transactional: true` y
  decir en el docblock cómo colgarse del commit. Es aditivo y reversible.
- **El deadlock A→B/B→A** (🟡 12) es del UNIQUE de `authz_relations` (L-4); aquí lo medido es el UNIQUE de
  `authz_assignments` con dos trx externas, en las dos formas (choque y deadline).
- **No generalicé `transactionalWrites` a lectura del pool**: el driver no inspecciona el pool de knex; el
  despliegue declara. Si el dueño prefiere que sea automático, es una línea (`db.connection().getWriteClient()
  .client.pool.max`), pero la capacidad dejaría de ser una declaración.
- **No toqué `CLAUDE.md`** (el CHANGELOG y el README llevan el detalle; si el dueño quiere, la fila de
  `database_driver.ts` del mapa gana «`writer()`: la escritura por la trx del llamante, L-3»).
