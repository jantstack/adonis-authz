# Fase 4 · Lote 4-3 — driver `database` de relaciones (`authz_relations` + CTE + trigger por dialecto)

> Base: `main` @ `b8cf492` (4-2 mergeado). Árbol principal, SIN commits (los hace el dueño).
> Plan: `fase-4-juez.md` §4-3 + `fase-4-plan.md` §3 + informes 4-1/4-2.
> Alcance: el driver `database` del puerto `RelationsDriver` (SQL propio), probado contra
> `runRelationsDriverContract` en los TRES motores, INSERT/DELETE-ONLY.

## Qué se implementó (todo aditivo)

- **`src/drivers/database_relations_driver.ts`** — `DatabaseRelationsDriver implements RelationsDriver`:
  `relate`/`unrelate`/`check`/`listObjects`/`listSubjects`/`purgeObject`/`purgeSubject`/`membersOf` sobre
  `authz_relations`. `check`/`listObjects` resuelven includes + usersets anidados con una **CTE recursiva
  `principal`** (backward desde el sujeto); `membersOf` con una **CTE recursiva `grp`** (forward por los
  usersets). Capacidades: `singleCheckRelations:true`, `listObjectsInherited:false`, `usersetSubjects:true`,
  `membersOfNative:true`, `enumerateRelations:false` (es 4-5), `listObjectsTruncation:false` (sin tope de
  servidor). `{trx}` INTERNA en `relate` (atomicidad trigger+insert), NO expuesta en el puerto (decisión (b)).
- **`src/relation_partition_trigger.ts`** — módulo PURO (sin el servicio `db`) con
  `relationPartitionTrigger(dialect)` / `relationPartitionTriggerDrops(dialect)` / `triggerDialectOf`. La DDL
  del trigger por dialecto; dialecto ajeno ⇒ `throw E_AUTHZ_UNSUPPORTED_DIALECT`. Vive fuera del driver porque
  lo importa también el espejo del esquema (`tests/helpers/schema.ts`), que se carga ANTES de bootear la app
  (importar el driver arrastraría `@adonisjs/lucid/services/db` y revienta con `Cannot read 'booted'`). El
  driver lo re-exporta.
- **Tabla `authz_relations`** en `stubs/migration.stub` + su espejo en `tests/helpers/schema.ts`
  (`createAuthzRelationsTable`), añadida a `AUTHZ_TABLES` y a `cleanAuthzTables`. Columnas: `uuid` (PK),
  `partition_key`, `object_type`, `object_uuid`, `relation`, `subject_type`, `subject_uuid`,
  `subject_relation` (nullable = holder), `subject_partition` (nullable), `created_at`. **Sin FK** (las
  relaciones no cuelgan del catálogo), **sin `expires_at`** (INSERT/DELETE-ONLY, R-15 fuera de la 2.4).
  Identidad `utf8mb4_bin`. El trigger de partición se aplica por `rawQuery` (sentencia entera) en el `defer`
  del stub y en el espejo.

Ficheros nuevos: `src/drivers/database_relations_driver.ts`, `src/relation_partition_trigger.ts`,
`tests/relations_database.spec.ts`. Tocados: `stubs/migration.stub`, `tests/helpers/schema.ts`,
`tests/migration_stub.spec.ts` (seis→siete tablas), `tests/upgrade_recipe.spec.ts` (la equivalencia de la
receta 1.x→2.x se afirma sobre las tablas que transforma, no la nueva `authz_relations`), y
`src/testing/relations_contract.ts` (el `spy` — ver abajo).

## El `spy` del runner 4-2 (un arreglo necesario, documentado)

El `spy` de `runRelationsDriverContract` (4-2) envolvía el driver con `{ ...driver }`, que solo copia
propiedades PROPIAS. El doble en memoria es un objeto literal (métodos propios), así que funcionaba; pero el
driver `database` es una CLASE con los métodos en el PROTOTIPO, y `{...driver}` los perdía ⇒ `manager.check`
llamaba a `undefined`. Se cambió el `spy` a un `Proxy` que cuenta `relate`/`unrelate` y delega el resto
enlazado al `target` (para que los campos privados `#…` del driver de clase sigan funcionando). No cambia el
conteo ni la semántica del contrato; los dos dobles de 4-2 siguen verdes.

## Rojo→verde por pieza (mutante y salida roja literal)

### P1 · el contrato R-01…R-12 + F-05 sobre el driver REAL
Mutante: `check` ignora los `includes` (`expandDown` devuelve solo `[relation]`).
```
❯ relations contract [database (sqlite)] / R-02 · includes: relate(editor) ⇒ check(viewer) true; el inverso NO
  assert.isTrue(await state.manager.check(u, 'viewer', doc, p))
ℹ AssertionError: expected false to be true
```
Verde: la CTE `principal` expande `RS = expandDown(objectType, relation)` en el ancla, así `relate(u,editor)`
⇒ `check(u,viewer)=true` (editor⊆viewer) y el inverso no. R-01…R-12 + F-05 (F-05 y R-12 los corta el manager
antes del driver) verdes en SQLite, PG y MySQL.

### P2 · usersets anidados (R-03/R-04, membersOf transitivo)
Mutante: la CTE `principal` no recursa (quita el término recursivo).
```
❯ relations contract [database (sqlite)] / R-03/R-04 · userset: relate(group#member, viewer) + membresía anidada ⇒ check true
ℹ AssertionError: expected false to be true
```
Verde: `principal` sube por `member(g1#member, g2)` (grupos anidados) con `UNION` (dedup ⇒ termina en ciclos);
`membersOf(g2)` trae los holders de g1 y `listSubjects(member, g2)` solo el userset `g1#member` (transitivo
vs directo, `membersOfNative` whenTrue).

### P3 · el trigger de partición — INSERT y UPDATE, tres motores (caso de DRIVER)
Mutante: no aplicar el trigger en el espejo (`createAuthzRelationsTable` sin el bucle `rawQuery`).
```
❯ database relations — el trigger de partición... / INSERT de un userset de OTRA partición ⇒ el motor lo RECHAZA
ℹ AssertionError: expected [Function] to throw an error
```
Verde: un INSERT (y un UPDATE que MUEVE el userset) con `subject_partition ≠ partition_key` lo rechaza el
motor; un holder (sin `subject_relation`) no lo mira; un userset de la misma partición pasa. **La DDL por
motor (medida, INSERT y UPDATE):**

- **SQLite** (un trigger por evento; `IS NOT` = distinto null-safe):
  ```sql
  CREATE TRIGGER authz_relations_partition_bi BEFORE INSERT ON authz_relations FOR EACH ROW
  WHEN NEW.subject_relation IS NOT NULL AND NEW.subject_partition IS NOT NEW.partition_key
  BEGIN SELECT RAISE(ABORT, '…'); END
  ```
  (y `…_bu BEFORE UPDATE …` idéntico).
- **PostgreSQL** (función plpgsql SEPARADA + `CREATE TRIGGER … EXECUTE FUNCTION`, un solo trigger
  `BEFORE INSERT OR UPDATE`; `IS DISTINCT FROM`):
  ```sql
  CREATE OR REPLACE FUNCTION authz_relations_partition_guard() RETURNS trigger LANGUAGE plpgsql AS $authz$
  BEGIN IF NEW.subject_relation IS NOT NULL AND NEW.subject_partition IS DISTINCT FROM NEW.partition_key
  THEN RAISE EXCEPTION '… (%, %)', NEW.subject_partition, NEW.partition_key; END IF; RETURN NEW; END; $authz$;
  CREATE TRIGGER authz_relations_partition_biu BEFORE INSERT OR UPDATE ON authz_relations
  FOR EACH ROW EXECUTE FUNCTION authz_relations_partition_guard()
  ```
- **MySQL** (un trigger por evento; `SIGNAL SQLSTATE '45000'`; `<=>` = igual null-safe, `NOT (a<=>b)` = distinto):
  ```sql
  CREATE TRIGGER authz_relations_partition_bi BEFORE INSERT ON authz_relations FOR EACH ROW
  BEGIN IF NEW.subject_relation IS NOT NULL AND NOT (NEW.subject_partition <=> NEW.partition_key)
  THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '…'; END IF; END
  ```
  (y `…_bu BEFORE UPDATE …`). El cuerpo `BEGIN…END` va como UNA sentencia `rawQuery` (nunca por un runner que
  trocea por `;`, sin `DELIMITER`).

### P4 · dialecto ajeno ⇒ throw
Mutante: `triggerDialectOf` devuelve `'sqlite'` por defecto en vez de lanzar.
```
❯ database relations — dialecto no medido / relationPartitionTrigger(dialecto ajeno) ⇒ 500 E_AUTHZ_UNSUPPORTED_DIALECT
ℹ AssertionError: expected [Function] to throw an error
```
Verde: `relationPartitionTrigger('oracledb')` y `driver.check(...)` con una conexión de dialecto `'oracledb'`
lanzan `E_AUTHZ_UNSUPPORTED_DIALECT` (500) — la CTE recursiva no se declara igual en dos motores, se niega
antes de construirla.

### P5 · 🟡2 · `purge*` barre AMBAS ortografías del uuid de partición
Mutante: `#partitionSpellings` devuelve solo `[scopeKey(partition)]` (sin `scopeSpellings`).
```
❯ database relations — purge barre las dos ortografías... / purgeObject borra la fila escrita con el uuid CON guiones aunque se purgue el SIN guiones
ℹ AssertionError: expected true to be false
```
Verde: se escribe en la partición CON guiones y se purga con la SIN guiones; `purge*` barre `scopeSpellings`
(dashless ⇒ también 8-4-4-4-12), reusando la pieza de `identity.ts` del fix 3b-2h.

### La CTE por dialecto (medido)
Un único árbol de CTEs, quoting por dialecto (`"` PG/SQLite, `` ` `` MySQL) y **CAST del ancla** al tipo del
motor (`varchar(64)` PG, `text` SQLite, `CHAR(64)` MySQL): sin él MySQL/PG rechazan la CTE recursiva porque la
columna del término no-recursivo (literales) y la del recursivo (columnas de la tabla) difieren de tipo. Hint
`SET_VAR(cte_max_recursion_depth = 50000)` solo en MySQL (como `sql_descendants`). Ancla de UN solo `SELECT`
en las dos CTEs (MySQL no mezcla `UNION ALL` de varias filas de ancla con la recursión).

## Las 4 cifras (todas verdes; con `OPENFGA_TEST_URL=:8101`)

| modo | antes (4-2) | ahora | delta |
|---|---|---|---|
| `npm test` | 858 | **883** | +25 |
| `test:sqlite-file` | 863 | **888** | +25 |
| `test:pg` | 957 | **982** | +25 |
| `test:mysql` | 957 | **982** | +25 |

+25 = contrato del puerto sobre el driver real (17, una cara por capacidad + núcleo) + trigger (4: misma
partición, holder no mirado, INSERT cross, UPDATE cross) + dialecto ajeno (2) + 🟡2 dos ortografías (2).
`tsc` (ambos tsconfig), `typecheck`, `check:purity` (la ruta `database` NO importa `openfga`) y `build`
limpios. Sin `:8101` en el camino (SQL puro); los números incluyen el contrato openfga sin tocar.

> Corridas a fichero desde la primera pasada. El test de profundidad del 4-1 (`facts · 4-1 — profundidad…`)
> no flaqueó en estas pasadas.

## Lo que NO se hizo, y por qué

- **`authz_relations` NO lleva `expires_at`, y NO hay caso «renovar = delete+insert».** Decisión del dueño:
  la caducidad de relaciones (R-15) queda FUERA de la 2.4. **El AC del juez (§4-3) que exigía el caso
  «renovar caducidad es delete+insert» queda ANULADO por esta decisión.** Si el dueño mete R-15 después, es un
  micro-lote aditivo (columna `expires_at` + el `BEFORE UPDATE` del trigger ya cubre el UPDATE) — no se
  implementa hoy.
- **`enumerateRelations` (origen de `authz:reconcile` de relaciones)**: capacidad `false` (whenFalse ⇒ 500).
  Es 4-5 (reconcile de relaciones).
- **Driver `openfga` de relaciones, el 🔴 probado VERDE en el store compartido, `listObjectsTruncation` real,
  paridad `database`↔`openfga`**: son 4-4.
- **F-01/F-02 con dientes, la carrera `defineRelationsConfig`↔`syncAuthzCatalog`**: son 4-5.
- **Paginación real de `listObjects`/`listSubjects`/`membersOf` (cursor)**: el puerto acepta `page?` pero el
  driver devuelve la página completa (sin tope, exhaustiva) — coherente con `listObjectsTruncation:false` y con
  el driver `database` de roles, cuyos `list*` tampoco paginan de verdad. El cursor opaco «que avanza» es del
  driver `openfga` (4-4), donde el backend sí trunca.

## Notas de diseño / decisiones

- **`subject_partition`**: columna añadida (la lista de columnas del encargo era abreviada; el plan §3 la
  lista). Es lo que da al trigger algo que comparar: para un userset, el driver la fija = `partition_key`; el
  escritor «a mano» que la ponga distinta es a quien el trigger caza. Holder ⇒ null.
- **Idempotencia (R-06) por check-then-insert dentro de la transacción**, no por el UNIQUE: el UNIQUE incluye
  `subject_relation` (nullable) y los motores tratan cada NULL como distinto (la lección del centinela de
  `authz_assignments`), así que para holders el UNIQUE no dispararía; el `SELECT … LIMIT 1` + INSERT en la
  misma transacción lo garantiza. El UNIQUE queda como defensa para usersets.
- **El trigger vive en el stub publicado** (inline en un `defer`, misma DDL que `relationPartitionTrigger`,
  sin `import` porque `runMigrationSource` los quita): así un consumidor real obtiene la defensa en
  profundidad. La correctness se fija por comportamiento (los tests de trigger corren sobre el espejo, que usa
  la función del paquete).
