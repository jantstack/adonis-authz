# Panel `{trx}` · ANALISTA — cómo se hace `{trx}` en las escrituras, y sobre todo en `openfga`

> Base: worktree read-only en `242d846` (= `2.4.0-alpha.1`). Mediciones contra el `:8101`
> (stores `trxan_*`, borrados), PostgreSQL 18 (`postgres18`, bases `trxan_*`, borradas) y
> SQLite `:memory:` pool 1/1 (el modo por defecto de `npm test`).
> Soy **un panelista de dos**. No escribo el veredicto.

---

## Recomendación en una frase

**`{trx}` se implementa de verdad en `database` para los dos puertos, y en `openfga` se RECHAZA
en voz alta por llamada (capacidad `transactionalWrites: false` ⇒ 500 `E_AUTHZ_UNSUPPORTED` antes
de escribir nada) — porque la opción (A) «outbox para hechos» convierte `revoke`/`deny`/`unrelate`
en FAIL-OPEN durante 1,16 s de mediana y 2,28 s de cola (medido), y un aparcado en fail-open
PERMANENTE que la pasada de mantenimiento de `reconcile` no repara por diseño.**

**Condición que la cambiaría (una sola):** que aparezca un consumidor que despliegue **`openfga`
como driver activo** *y* necesite `relate()`/`grant()` transaccional. Hoy no existe: COGNITIV corre
`database` (verificado en su `.env`, abajo §1). Si apareciera, lo que se adelanta NO es (A) sino la
receta dirigida por SIGNO de §2.4, y con la ventana de `revoke` declarada como breaking.

**Siguiente paso concreto:** resolver el 🔴 de implementación de §5.1 (con el pool a 1 y la trx del
llamante abierta, **cualquier** consulta por la conexión propia del driver se cuelga — no falla,
se cuelga) *antes* de escribir una sola línea del lote. Decide si `{trx}` puede tener casos en el
modo por defecto de la suite o si nace gateado a `sqlite-file`/pg/mysql.

---

## 0 · Qué verifiqué y qué asumo

| Marca | Significado |
|---|---|
| ✅ | Leído en el código de `242d846` o medido contra `:8101`/pg18/sqlite, con la cifra |
| 🟡 | Diseño propuesto por mí; no existe |
| ❓ | Incógnita que hay que resolver antes de comprometerse |
| ❌ | Verificado que NO existe / que es falso |

Ficheros leídos enteros o en la parte que cito: `src/scope_outbox.ts`, `src/manager.ts`
(`#assertNotFrozen`, `scopes.*`, `relayScopeChanges`, `#factsOrigin`), `src/relations/manager.ts`,
`src/drivers/database_relations_driver.ts`, `src/drivers/openfga_relations_driver.ts`,
`src/drivers/openfga_driver.ts` (`reconcile`, `grant`), `src/relations/reconcile.ts`,
`src/relation_partition_trigger.ts`, `src/types.ts`, `src/catalog/catalog_cache.ts`,
`commands/authz_reconcile.ts`, `stubs/migration.stub`, `tests/helpers/app.ts`.
Contexto: `fase-4-juez.md`, `decisiones-dueno-2026-08-28.md`, `exigencias-cognitiv-2026-08-27.md`,
`roadmap-2.0.md`. Y el repo del consumidor: `/home/jose/proyectos/ullswater/adonisjs/api-cognitiv`.

---

## 1 · Qué pide COGNITIV de verdad — «atómico» para ellos, con su propio código delante

Esto es lo que decide el panel, y estaba a un `grep` de distancia. Tres hechos verificados **en el
repo del consumidor**, no en el nuestro:

### ✅ 1.1 · `pdp_version` es una columna SQL suya, y su semántica es *época de caché*, no de acceso

`/home/jose/proyectos/ullswater/adonisjs/api-cognitiv/database/migrations/1810000000000_add_cognitiv_columns_to_organizations_table.ts:14-16`:

> `pdp_version`: versión de la caché de decisiones del PDP. Sube en la misma transacción que
> cualquier cambio de llaves o de niveles; **toda entrada cacheada con versión anterior es un miss**.

Es `table.integer('pdp_version')` sobre `organizations`. O sea: **no es un permiso, es un
invalidador**. Los dos modos de fallo NO son simétricos:

| Se pierde… | Consecuencia | Signo |
|---|---|---|
| El bump, y la llave sí se escribe | la caché sigue sirviendo decisiones viejas ⇒ si el cambio era un **revoke**, sigue concediendo | **FAIL-OPEN, persistente** |
| El bump, y la llave NO se escribe | miss de caché, se recalcula, se ve el estado viejo | inocuo (más lento) |

Por eso su requisito real no es «atomicidad» en abstracto: es **«que el bump no se pierda cuando la
llave sí se escribe»**. En `database` eso es exactamente una transacción SQL y punto. En `openfga`
la atomicidad no existe y ellos ya lo sabían (1.3).

### ✅ 1.2 · COGNITIV despliega el driver `database`. `openfga` es un profile de docker opt-in

| Evidencia | Contenido |
|---|---|
| `api-cognitiv/.env:65` | `AUTHZ_DRIVER=database` |
| `api-cognitiv/.env.test:24` | `AUTHZ_DRIVER=database` |
| `api-cognitiv/.env.example:87` | `AUTHZ_DRIVER=database` |
| `api-cognitiv/docker-compose.prod.yml:37` | `AUTHZ_DRIVER: ${AUTHZ_DRIVER:-database}` |
| `api-cognitiv/docker-compose.prod.yml:35-36` | *«Motor de autorización: database (default, autosuficiente) \| openfga (levantar con `--profile openfga`…)»* |
| `api-cognitiv/config/authorization.ts:58-61` | *«`database` (default): motor propio sobre las tablas `authz_*` — **cero piezas extra en el appliance**»* |
| `api-cognitiv/package.json:76` | `"@jantstack/adonis-authz": "^1.1.0"` (aún no han subido a 2.x) |

Los servicios `openfga`/`openfga-migrate`/`openfga-initdb` del compose llevan `profiles: ['openfga']`
y sin `ports` publicados. Para un **appliance soberano on-premise**, «cero piezas extra» es el
argumento de producto, no una preferencia.

**Consecuencia para el panel:** el requisito #6 de COGNITIV se cumple **entero y sin mentiras** con
`{trx}` real en `database`. La pregunta de `openfga` es importante para el paquete, pero **no es la
que desbloquea a COGNITIV**, y por tanto no puede justificar tragarse un fail-open.

### ✅ 1.3 · COGNITIV ya escribió, en su propio documento de exigencias, que `openfga` rechaza `{trx}`

`exigencias-cognitiv-2026-08-27.md`, tres veces, en su sección de diseño del puerto:

- línea 80: *«**`{trx}` externa** en el driver `database` (no abre la suya si la recibe); **el driver
  `openfga` la rechaza explícitamente (documentado)**»*
- línea 252 (bundle L3): *«`{trx}` en `GrantOptions` **rechazada explícitamente por `openfga`**»*
- línea 161 (la fila de `pdp_version`): *«✅ con `database` (`{trx}`); con `openfga` → outbox: `INCR`
  **antes** en revoke y **después** en grant (o antes y después siempre)»*
- línea 299 (su propia pregunta abierta): *«¿Se sostiene "un solo juez para los dos drivers"? `{trx}`…
  no pueden correr en ambos: **contrato bifurcado por driver o dejar de prometer paridad**»*

Y la línea 177: *«`pdp_version + 1` en la misma trx **en el store**, nunca en un hook»* — el bump es
suyo, en su servicio, y el paquete solo tiene que dejar que la escritura de la llave caiga en la
misma transacción.

> **La opción (C) no es un «no» del paquete al cliente: es la que el cliente escribió.** El gatillo
> del juez de la Fase 4 se disparó por el requisito #6, pero el requisito #6 se satisface en el
> driver que el cliente despliega. Lo que el gatillo obliga es a hacerlo **en los DOS puertos** (eso
> sí, sin discusión), no a inventar atomicidad donde no la hay.

**Lo que su línea 161 sí pide y hay que atender:** que la receta de `openfga` esté **publicada**, no
que el paquete la implemente. Su outbox es SUYA (el `INCR` de su Redis/columna), no la del paquete.

---

## 2 · Las tres opciones para `{trx}` en `openfga`

### 2.1 · Opción (A) — extender la outbox a los HECHOS. **Descalificada, con números**

La idea: `grant`/`deny`/`revoke`/`removeDeny`/`relate`/`unrelate` con `{transaction}` ENCOLAN en la
trx del consumidor y `authz:*:relay` los aplica después. Es el mecanismo que ya funciona para el
árbol, reutilizado.

**Steelman (y es fuerte):** (A) es la única de las tres que conserva la regla de higiene *«un cambio
de driver es migración de hechos, no reescritura»*: el mismo call-site `grant(..., {transaction})`
funciona en los dos drivers. Es la misma tensión que 3b-2d resolvió a favor de la outbox, y quien la
descarte tiene que decir por qué aquí no vale el mismo argumento.

**Por qué aquí no vale: el signo del lag se invierte.** Lo medí contra el `:8101` con el modelo
FUSIONADO real (`openFgaFactsModel` con 40 permisos × 3 holders + `ia_spaces`), encolando la entrada
y preguntando al store antes de relevarla (`trx_relay.mjs`, §1 de su salida):

| Operación encolada, sin relevar | Pregunta | Store responde | La BD del consumidor dice | Signo |
|---|---|---|---|---|
| `grant` | `authorize` | `false` | `true` | fail-CLOSED ✅ |
| **`revoke`** | `authorize` | **`true`** | `false` | **FAIL-OPEN** 🔴 |
| **`deny`** | `authorize` | **`true`** | `false` | **FAIL-OPEN** 🔴 |
| `relate` | `relations.check` | `false` | `true` | fail-CLOSED ✅ |
| **`unrelate`** | `relations.check` | **`true`** | `false` | **FAIL-OPEN** 🔴 |

*(y tras aplicar el `revoke`, `authorize(alice) = false`: el efecto es del lag, no del montaje).*

En el ÁRBOL, la decisión del dueño del 2026-08-31 (2) pudo comprar el fail-CLOSED con **una relación
más** del modelo (`rooted`) y **cero tuplas por scope**. Aquí **no hay equivalente**: la ausencia de
un `delete` es la presencia de una tupla, y una tupla presente concede. Para invertir ese signo haría
falta que toda tupla de hecho llevara una condición de vigencia renovada continuamente (lápidas /
leases sobre cada `assignee`), lo que rompe `singleCheckAuthorize` y multiplica las escrituras: es
más caro que el problema.

**Coste medido de (A).**

*a) Cuántas escrituras más pasan por la cola.* Hoy la cola lleva **solo** `scopes.attached/moved/
detached`. En `api-cognitiv/app/` hay, contados: **0 call-sites de `scopes.*`** y **9 de
`grant`/`revoke`** en 4 servicios (`organizations_service`, `organization_units_service`,
`organization_members_service`, `organization_invitations_service`), uno de ellos en bucle
(`organization_members_service.ts:127`, un `revoke` por rol al expulsar a un miembro). Es decir:
(A) lleva la cola de **~0 entradas** a **el 100 % de las escrituras de autorización**, y las de árbol
son de ciclo de vida (crear/mover/borrar org o unit) mientras las de hechos son de operación diaria.

*b) Qué lag añade a un `grant` que hoy es inmediato.* Medido:

| Pieza | p50 | p95 |
|---|---|---|
| `Write` de 3 tuplas = `grant` en facts (hoy, en línea) | **6,93 ms** | 9,19 ms |
| `Write` de 1 tupla = `relate` (hoy, en línea) | **6,01 ms** | 9,68 ms |
| `Write` delete de 1 tupla = `revoke`/`unrelate` | 3,78 ms | 5,03 ms |
| `Check` (= `authorize` / `relations.check`) | 11,03 ms | 18,37 ms |
| INSERT de encolado, dentro de una trx abierta (pg18) | **0,326 ms** | 1,342 ms |
| `UPDATE markApplied` (pg18) | 0,172 ms | 0,237 ms |
| `SELECT pending` (lote de 100) (pg18) | 1,059 ms | 1,308 ms |
| `SELECT` de la fila del freeze `id=2` (pg18) | 0,048 ms | 0,055 ms |
| `UPDATE pdp_version + 1` (lo que COGNITIV ya hace) | 0,351 ms | 1,985 ms |

Aquí está la parte **seductora** de (A), y hay que decirla: el `grant` aparente pasa de **6,93 ms a
0,33 ms** — 21× más rápido. **Eso no es una optimización: es la garantía desapareciendo.** El trabajo
total SUBE (0,33 + 6,93 + 0,17 ≈ 7,4 ms frente a 6,93), solo que ahora ocurre en otro proceso y más
tarde.

*c) Cuánto dura «más tarde».* Drenaje real de 300 hechos con la mecánica del relay (escritor único
con lease, `Write` + `markApplied`, lotes de 100):

```
encolar 300 hechos en la trx del consumidor: 50,1 ms  (0,167 ms/entrada)
drenar 300 hechos:                           2.282 ms
⇒ 131,5 entradas/s · 7,61 ms por entrada
⇒ retraso de la ÚLTIMA entrada de la ráfaga: 2,28 s
⇒ retraso MEDIANO:                           1,16 s
```

El relay es **escritor ÚNICO por diseño** (`scope_outbox.ts:297`, `acquire()` con
`pg_try_advisory_xact_lock`/`GET_LOCK`), así que **131,5 entradas/s no se paralelizan**. Un alta
masiva de 5.000 membresías = **38 s** de cola, y durante esos 38 s **cada `revoke` de cualquier
tenant concede**.

*d) El caso que no tiene reparación.* Una entrada **APARCADA** (`attempts >= maxAttempts`, default 5;
`scope_outbox.ts:82`, sale por `dead()`) no se aplica nunca. Para el árbol eso es, bajo (c2r), un
nodo que no alcanza la raíz ⇒ **deniega**. Para un hecho es **un `revoke` que no ocurre jamás**. Y
verifiqué que **la reparación no existe**: en un despliegue `facts`, `manager.reconcile` con
`--to=<driver activo>` toma `factsOrigin` = el propio store (`manager.ts:1199`) y el driver
`readOriginFacts` compara el store contra sí mismo (`openfga_driver.ts:2488-2495`) — la pasada de
mantenimiento **no escribe ni borra un solo hecho**, por decisión explícita de 3b-5. Y `--from=database`
está cerrado por el seguro `E_AUTHZ_MASS_RECONCILE_REFUSED` (3b-8 · B1) porque en `facts` esas tablas
no tienen ni un hecho. **Un `revoke` aparcado en (A) sería un fail-open permanente sin camino de
reparación en el paquete.**

**Veredicto (A):** descalificada por la regla dura del encargo. No promete una atomicidad falsa —
promete algo peor: convierte la revocación en eventualmente consistente en el signo malo, con la
ventana medida y el caso irreparable, para resolver un requisito que el consumidor que lo pide no
tiene (§1.2).

### 2.2 · Opción (B) — `{trx}` cubre «la parte SQL» y la tupla va en línea. **Descalificada, y además es un no-op**

✅ Verificado: en `openfga` con `facts`, `grant`/`revoke`/`deny`/`removeDeny`/`relate`/`unrelate`
escriben **cero filas SQL**. Lo único SQL que tocan es una **LECTURA** del catálogo
(`openfga_driver.ts:952`, `await this.catalog.view()`). **No hay «parte SQL» que inscribir en la
transacción del llamante.** (B) es literalmente un parámetro que no hace nada.

Y ese «no hace nada» es exactamente la forma del defecto que el paquete ya juzgó dos veces:
- `countRoleAssignments` (decisión del dueño 2026-08-31 (3)): *«"no lo sé" nunca puede degradar a
  `false`»* — un valor que el llamante lee justo antes de una operación destructiva.
- La regla del cruce 4 · S5 entera: el problema NO es el mal uso, es que **el uso correcto fuga**.

Un consumidor que escribe `relate(..., { transaction: trx })` está declarando «esto se va con mi
rollback». Aceptar el parámetro y no cumplirlo es publicar esa fuga con nuestra firma. Descalificada
por la regla dura.

### 2.3 · Opción (C) — rechazar `{trx}` en `openfga`. **La recomendada, con una corrección importante**

La corrección: **no como capacidad de CONSTRUCCIÓN, sino como rechazo por LLAMADA** (ver §4). Con
esa forma:

- No miente: el paquete dice exactamente lo que puede.
- No rompe a nadie que hoy funciona: quien no pasa `{transaction}` no nota nada.
- Es lo que el consumidor pidió (§1.3, tres veces en su propio documento).
- El coste real —la asimetría entre drivers— se paga **con ruido, no con silencio**, que es el patrón
  de todo el paquete (`E_AUTHZ_UNSUPPORTED` de `membersOf`, de `purgeRole` antes de 3b-2e, de
  `enumerateRelations`…).

**Contra de (C), honesto:** rompe la regla *«si un plan obliga a cambiar call-sites al cambiar de
driver, está mal»*. Un consumidor que escribe `{transaction}` en `database` y luego pone
`AUTHZ_DRIVER=openfga` se lleva un 500 en cada escritura. Lo mitigo en §4 con el gate de CONFIG:
quien necesita transacciones lo DECLARA y entonces el fallo es de **arranque**, en toda la flota, no
una sorpresa a las 3 de la mañana en una ruta poco transitada.

### 2.4 · Lo que sí se le puede dar a `openfga` sin mentir: la receta por SIGNO (documentación, cero mecanismo)

No es una cuarta opción: es lo que va en el README junto al 500, para que el rechazo no sea un
callejón. Sale de los datos de §2.1 y de la línea 161 de COGNITIV:

| Dirección | Qué hacer con `openfga` | Si la trx del consumidor revierte |
|---|---|---|
| **Permisiva** (`grant`, `relate`, `removeDeny`) | escribir **DESPUÉS del commit** (un `after commit` del consumidor) | no se concedió nada ⇒ **fail-CLOSED** |
| **Restrictiva** (`revoke`, `deny`, `unrelate`) | escribir **ANTES/dentro**, en línea | se revocó algo que SQL sigue concediendo ⇒ **fail-CLOSED**, y reparable |

Los dos modos de fallo caen del lado seguro **sin ningún mecanismo nuevo del paquete**. Su único
límite, y va escrito: **no compone** —un `grant` y un `revoke` del mismo hecho en la misma
transacción se aplican en orden invertido y acaban concediendo—; para eso, `database`.

🟡 Es diseño mío, no código. Su coste es una sección del README y **un caso** que fije que el
paquete no lo automatiza.

---

## 3 · La misma decisión para `roles/` (el juez exigió los dos puertos a la vez)

El gatillo del juez (`fase-4-juez.md` §4, decisión (b)) es explícito: *«se adelanta `{trx}` para LOS
DOS puertos, no solo relaciones»*. Se cumple, y la decisión es **idéntica en forma**:

| Puerto | Escrituras que reciben `{transaction}` | `database` | `openfga` |
|---|---|---|---|
| `roles/` | `grant`, `revoke`, `deny`, `removeDeny` | ✅ trivial: 1–2 sentencias sobre `authz_assignments`/`authz_denies` | ❌ 500 `E_AUTHZ_UNSUPPORTED` |
| `relations/` | `relate`, `unrelate`, `purgeObject`, `purgeSubject` | ✅ pero con un cambio real (§5.2) | ❌ 500 `E_AUTHZ_UNSUPPORTED` |

**Lo que NO recibe `{transaction}`, y por qué** (esto es la mitad del trabajo de diseño):

- **`defineScopedRole`/`updateScopedRole`/`deleteScopedRole`/`purgeRole`**: ya escriben por
  `withAuthzCatalogWrite`, que **abre su propia transacción, bloquea la fila de versión y sube el
  bump como última sentencia** (invariante 14; `catalog_cache.ts`). Meterlas dentro de la trx del
  consumidor mueve el bump a *su* commit y anula el serializador del catálogo entre procesos (3D · M2).
  ⇒ **fuera de alcance**, y dicho en el README.
- **`syncAuthzCatalog`**: lo mismo, y además el freeze no lo cubre por su nombre.
- **`scopes.attached/moved/detached`**: ya tienen `transaction` desde 3b-2d, con otra semántica
  (encolar). **No se toca.** Ojo con el nombre: `ScopeTreeWriteOptions.transaction` significa *«mete
  el encolado en mi trx»* y el nuevo significará *«mete la escritura en mi trx»*. Son distintos, y
  el docblock tiene que decirlo o alguien lo confundirá.
- **`relayScopeChanges` / `reconcile` / `pruneOrphanRoles`**: operaciones de PLATAFORMA. No.

**Asimetría que hay que declarar en `roles/`:** en `database`, `grant` lleva el reintento K4
(`UPDATE` toca 0 filas ⇒ INSERT) y una LECTURA del catálogo. Dentro de la trx del llamante, un
choque de UNIQUE (dos `grant` idénticos concurrentes) **envenena la transacción del consumidor** en
PG (`25P02`) en vez de resolverse dentro del driver. Es correcto —el llamante hará rollback— pero es
un cambio de comportamiento observable y necesita su caso.

---

## 4 · La capacidad: la semántica honesta

### ❌ La frase del roadmap, tal cual, es incorrecta

`roadmap-2.0.md:103`: *«`{trx}` en `GrantOptions` + `onWriteInTrx` (capacidad `transactions`; **el
manager falla al construirse si el driver no la soporta**; necesita Fase 2.5)»*.

Esa frase **fusionó dos cosas distintas** de `exigencias-cognitiv:252`, donde sí estaban separadas:

- `onWriteInTrx(event, trx)` **solo `database`** — *«registrarlo con `openfga` falla en boot»*. Correcto:
  es un **hook del CONFIG**, declarativo, comprobable en el arranque.
- `{trx}` en `GrantOptions` — *«rechazada explícitamente por `openfga`»*. Es una **opción por
  llamada**, y no es comprobable en el arranque.

Aplicada tal cual, la frase del roadmap **haría `openfga` inconstruible en cualquier app que
simplemente lo tenga registrado en `config.drivers`** — incluida la de COGNITIV, que lo tiene como
segunda opción sin usarlo. Sería el mismo error que 3b-2e · E3 corrigió al revés: un gate en el sitio
equivocado.

### 🟡 La semántica que propongo — **dos puertas, ninguna silenciosa**

**Capacidad** (en `AuthorizationDriverCapabilities` y en `RelationsDriverCapabilities`, con el mismo
nombre para que un driver de terceros no tenga que aprender dos):

```ts
/**
 * El driver puede inscribir sus escrituras en la transacción del consumidor
 * (`{ transaction }` en las opciones de escritura). `database` = true.
 * `openfga` = false y NO puede ser otra cosa: una tupla no entra en una
 * transacción SQL — el store es otro servicio y no hay 2PC.
 */
transactionalWrites: boolean
```

**Puerta 1 · por llamada (siempre activa).** Pasar `{ transaction }` a un driver con
`transactionalWrites: false` ⇒ **500 `E_AUTHZ_UNSUPPORTED`** nombrando la operación y el driver,
**antes de tocar el backend** (cero escrituras, verificable con espía). Jamás un warning, jamás
ignorarlo.

**Puerta 2 · por config, opt-in.** `config.requireTransactionalWrites: true` ⇒ al **resolver** el
driver, si `transactionalWrites !== true`, **500 `E_AUTHZ_CONFIG`**. Esto es lo que rescata la frase
del roadmap y la pone donde funciona: un consumidor que NECESITA `{trx}` (COGNITIV) lo declara y el
despliegue equivocado **no arranca**, en toda la flota. Es exactamente el patrón del gate de
`hierarchyFacts` ⇒ `scopes.outbox` de 3b-2e · E3, y del que exige `withClock` cuando hay
`config.clock`.

**Por qué esta forma y no «capacidad = false ⇒ inconstruible»:** porque `transactionalWrites` es una
propiedad del par (driver, llamada), no del driver a secas. `openfga` sin `{trx}` es perfectamente
usable —es lo que hace hoy toda la 2.3— y romperlo sería cobrarle la factura a quien no pidió nada.

**Caras de la capacidad en los dos runners** (la regla de 3b-2e · E2: cada valor con su caso,
`whenFalse` poblada o el runner falla — el guard de `contract.ts:4415` solo obliga a `whenTrue`, así
que la cara `false` hay que poblarla a mano):

| | `whenTrue` (`database`) | `whenFalse` (`openfga`) |
|---|---|---|
| roles | `grant` en una trx + rollback ⇒ `authorize` = `false` y **cero filas** en `authz_assignments` | `grant(..., {transaction})` ⇒ 500 `E_AUTHZ_UNSUPPORTED`, **cero llamadas al cliente FGA** (espía) |
| relations | `relate` en una trx + rollback ⇒ `check` = `false` y cero filas en `authz_relations` | `relate(..., {transaction})` ⇒ 500, cero `Write` |

---

## 5 · Interacción con lo que ya existe

### 🔴 5.1 · El hallazgo que decide el plan: con el pool a 1, la conexión propia del driver se CUELGA

Medido (`trx_pool.mjs`, `trx_sqlite_pool.mjs`), con la transacción del llamante abierta:

| Escenario | Resultado |
|---|---|
| pg18, pool `max: 1`, abrir una 2.ª transacción | **COLGADO > 2.500 ms** |
| pg18, pool `max: 2`, abrir una 2.ª transacción | OK |
| pg18, pool `max: 1`, *savepoint* sobre la trx del llamante | OK |
| SQLite `:memory:`, pool 1/1, abrir una 2.ª transacción | **COLGADO > 2.500 ms** |
| **SQLite `:memory:`, pool 1/1, un `SELECT` suelto por la conexión propia** | **COLGADO > 2.500 ms** |
| SQLite `:memory:`, pool 1/1, el mismo `SELECT` por la trx del llamante | OK |

`tests/helpers/app.ts:205` y `:312`: el modo por defecto de `npm test` es SQLite `:memory:` con
`pool: { min: 1, max: 1 }`. O sea: **no es que un caso de `{trx}` salga rojo — es que la suite se
cuelga**, que es peor (no hay mutante ni oráculo, hay un timeout de CI).

El paquete YA se topó con esto en un sitio y lo resolvió bien: `manager.ts:663-669`, en
`#assertNotFrozen`, *«si la escritura llegó con la TRANSACCIÓN del consumidor, la fila se lee por
ella: exigir una segunda conexión con la suya abierta interbloquea un pool de 1»*. Ese precedente hay
que generalizarlo. Lo que hay que enrutar por la trx del llamante en una escritura con `{transaction}`:

1. la escritura en sí (obvio);
2. la fila del freeze `id=2` — ✅ ya resuelto, `readFreezeRow({ client })`;
3. ❌ **la lectura del catálogo** — `CatalogCache.view()` (`catalog_cache.ts:588`, `:640`) **no acepta
   un cliente**: llama a `readAuthzCatalogVersion({ driver, timeoutMs })` por la conexión propia. Y
   `database_driver.grant` la usa (`:652`), igual que `revoke` (`:748`) y el resto. Sin esto,
   `grant(..., {transaction})` se cuelga en el modo por defecto de la suite.

❓ **La incógnita que hay que resolver antes de comprometerse**, y que puede cambiar el alcance del
lote: si la revalidación del catálogo se lee por la trx del llamante, **no puede poblar el memo
compartido del proceso** — sería exactamente el veneno que el invariante 14 persigue («un bump que se
confirma antes que su escritura envenena el memo de los demás procesos para siempre»), solo que en
la otra dirección (datos aún sin confirmar). Las dos salidas:

- **(i)** `CatalogCache.view({ client })` con una vista **NO memoizable** cuando llega un cliente
  ajeno. Cuesta más código y hay que probar que el memo compartido no se contamina.
- **(ii)** declarar que `{transaction}` **exige pool ≥ 2** y gatear los casos de la capacidad a
  `sqlite-file`/pg/mysql — hay precedente (`freeze_multiprocess.spec.ts`), pero **el contrato
  publicado para terceros no se puede gatear igual de fácil**, y un driver de terceros que solo se
  juzgue en `:memory:` no vería el caso.

Mi apuesta es **(i)**, pero es una apuesta: **mídase en el lote 1 antes de comprometer los demás.**

### 5.2 · El driver `database` de relaciones abre HOY su propia transacción

`database_relations_driver.ts:255-259`, con el comentario que lo dice:

```ts
// Transacción INTERNA: la atomicidad trigger+insert (el trigger corre en el
// mismo INSERT; el check-then-insert idempotente va dentro de la misma
// transacción). `{trx}` NO se expone en el puerto (decisión (b), diferido).
this.#connection().transaction(async (trx: any) => { … })
```

Con `{transaction}` esto **tiene** que pasar a usar la trx del llamante (savepoint o sentencias
directas), o cuelga (§5.1). Y hay una consecuencia semántica: hoy el `check-then-insert` idempotente
está aislado en su propia transacción; dentro de la del consumidor, **su aislamiento es el que el
consumidor eligió** (`READ COMMITTED` por defecto en PG). Con dos `relate` idénticos concurrentes
ambos ven «no existe» y el segundo choca contra el UNIQUE de `stubs/migration.stub:205`. El choque ya
no lo absorbe el driver: **envenena la transacción del consumidor**. Es aceptable y es un caso.

### 5.3 · El freeze: ¿al encolar o al aplicar?

✅ Hoy, para el árbol, **en los dos sitios**: `#writeOptions` → `#assertNotFrozen` antes de encolar
(`manager.ts:1435`), y `relayScopeChanges` lo comprueba a la entrada (`:892`) **y se re-afirma por
lote** (`:970`, 3b-8 · B3, precisamente porque una sola mirada dejaba colarse hasta 10.000
escrituras).

Para `{trx}` en `database` la respuesta es más simple y **no cambia nada**: no hay «encolar», hay
escribir. La barrera ya está en `#writeOptions` y ya sabe leer la fila por la trx del llamante. Lo
único que hay que fijar con un caso: **la barrera corre ANTES de tocar la trx del llamante**, para
que un `E_AUTHZ_FROZEN` no deje la transacción del consumidor en un estado a medias que él no espera.

🟡 Punto fino y real: `freeze()` promete *«otro proceso recibe 503»*, jamás *«ninguna escritura entra
en la ventana»*. Con `{trx}`, la ventana entre la barrera y el commit del consumidor **la fija el
consumidor**, no el paquete: puede tardar minutos. La frase del README hay que ampliarla — *«y con
`{transaction}`, una escritura que ya pasó la barrera se confirma cuando TU transacción confirme»*.
Eso no es un defecto nuevo, es el mismo trade-off ya declarado en `freeze.ts`, pero con un brazo más
largo.

### 5.4 · `reconcile`: ¿ve lo encolado y sin aplicar como deriva?

✅ Hoy: `pendingRelay` **avisa** (exit 0) y `deadRelay` **es deriva** (exit ≠ 0) —
`commands/authz_reconcile.ts:107-118`, `:157`. Con la decisión recomendada **nada cambia**: no hay
hechos en ninguna cola.

Y esto es un argumento más contra (A), no un detalle: si los hechos entraran en la cola,
`pendingRelay > 0` dejaría de ser un aviso y pasaría a significar *«esta pasada certificó un store al
que le faltan revocaciones»* ⇒ tendría que **tumbar** la pasada (exit ≠ 0), y con la cola llevando el
100 % de las escrituras eso sería casi siempre. (A) rompe el verificador además del PDP.

Para `relations/`: `src/relations/reconcile.ts` exige `from` y `to`; en un despliegue de un solo
driver `from === to` ⇒ pasada trivialmente limpia. Mismo agujero que §2.1(d).

### 5.5 · La partición de relaciones y `assertWrite`

- ✅ **El trigger de partición NO se ve afectado.** `relation_partition_trigger.ts` genera un
  `BEFORE INSERT OR UPDATE` **sobre `authz_relations`** en los tres motores. Un trigger de motor
  dispara igual dentro de la trx del consumidor. Es la única garantía de esta historia que no cambia.
- ✅ **`assertWrite` es PURO y corre antes del driver** (`relations/manager.ts:136`, tras F-05 y
  `#assertObjectId`). Con `{transaction}` **el orden no se toca**: F-05 → `assertObjectId` → actor →
  `assertWrite` → driver. Un caso lo tiene que fijar: si `assertWrite` lanza, **la trx del consumidor
  no se ensucia** (cero sentencias por ella).
- ⚠️ **En `openfga` no hay trigger**: F-05 + la comparación de string son la única defensa de tenant
  (así lo dice el docblock del driver). Nada de esto cambia con `{trx}`, pero refuerza que la salida
  documentada `manager.driver()` sigue siendo la puerta trasera de siempre.

---

## 6 · Plan por lotes (formato `fase-4-juez.md`)

Camino crítico marcado. Cada lote: rojo→verde con mutante + typecheck + `npm test` + los 5 modos +
`:8101` + tester + auditor (nunca en paralelo con quien mide) + `/code-review`.

### T-0 · ❓ Spike de 2 h: el pool y el catálogo · **CAMINO CRÍTICO, bloquea todo lo demás**
No es un lote de features: es la medición que decide el alcance. Resolver §5.1.
- **AC:** con SQLite `:memory:` pool 1/1 y la trx del llamante abierta, un `grant(..., {transaction})`
  **completa** (no se cuelga) leyendo el catálogo por esa trx; y se demuestra con un caso que el
  **memo compartido del proceso NO queda contaminado** por una lectura dentro de una trx que después
  revierte (dos managers, patrón `twinOf`). Si no se logra ⇒ se adopta la salida (ii) y **se escribe
  en el README** que `{transaction}` exige pool ≥ 2, con los casos gateados y la limitación del
  contrato publicado dicha en voz alta.

### T-1 · La capacidad y el rechazo, en los DOS puertos (pieza pura, sin BD) · **CAMINO CRÍTICO**
`transactionalWrites` en las dos interfaces de capacidades; `TransactionalWriteOptions` (o
`transaction?: unknown` en `WriteOptions`/`RelationWriteOptions`); el 500 por llamada; el 500 de
config con `requireTransactionalWrites`.
- **AC:** un driver falso con `transactionalWrites: false` ⇒ `grant`/`relate` con `{transaction}` es
  **500 `E_AUTHZ_UNSUPPORTED`** nombrando driver y operación, con **cero llamadas al driver** (espía);
  `requireTransactionalWrites: true` + ese driver ⇒ **500 `E_AUTHZ_CONFIG` al resolver** (arranque),
  y con el driver capaz, resuelve; el runner **falla** si se declara `transactionalWrites: true` sin
  caso `whenTrue`, **y** si se declara `false` sin caso `whenFalse`; los conteos de
  `contract_harness.spec.ts` y `relations_harness.spec.ts` se actualizan **a literal**.

### T-2 · `database` · `roles/`: `grant`/`revoke`/`deny`/`removeDeny`
La escritura, la fila del freeze y la lectura del catálogo por la trx del llamante (según T-0).
- **AC:** en **SQLite + PG + MySQL**: `grant` dentro de una trx + `rollback` ⇒ `authorize` = `false`
  **y cero filas** en `authz_assignments` (el censo, no solo la respuesta); lo mismo para
  `deny`/`revoke`/`removeDeny`; **un caso de COMPOSICIÓN**: `revoke` + `UPDATE pdp_version` +
  `rollback` ⇒ ni el revoke ni el bump (es literalmente el requisito #6 de COGNITIV, con su forma);
  `E_AUTHZ_FROZEN` con `{transaction}` ⇒ **cero sentencias** por la trx del llamante; el choque de
  UNIQUE de dos `grant` concurrentes con trx externa ⇒ error **clasificado**, documentado como
  «envenena tu transacción»; **mutante obligatorio**: ignorar el `{transaction}` (escribir por la
  conexión propia) ⇒ el caso del rollback tiene que verse **ROJO**.

### T-3 · `database` · `relations/`: `relate`/`unrelate`/`purgeObject`/`purgeSubject`
Retirar la transacción INTERNA de `relate` cuando llega una externa (§5.2).
- **AC:** los mismos tres motores; `relate` + `rollback` ⇒ `check` = `false` y cero filas;
  **el trigger de partición sigue disparando dentro de la trx del llamante** (caso de driver con
  `knex.raw`, como el de 4-3); `assertWrite` que lanza ⇒ **cero sentencias** por la trx del llamante;
  `purgeObject`/`purgeSubject` con trx externa borran y revierten juntos; **mutante**: volver a abrir
  la transacción interna con la externa presente ⇒ en `:memory:` pool 1/1 el caso **se cuelga** ⇒
  el caso lleva su propio deadline para que eso salga como fallo y no como timeout de CI.

### T-4 · `openfga` · el rechazo con dientes, en los dos puertos
- **AC:** contra el `:8101`: `grant`/`relate` con `{transaction}` ⇒ **500 `E_AUTHZ_UNSUPPORTED`** con
  **cero llamadas al cliente FGA** (espía) — la cara `whenFalse` de la capacidad, poblada, nunca un
  skip; `requireTransactionalWrites: true` + `default: 'openfga'` ⇒ **no arranca**; y un caso de
  PARIDAD que fija la asimetría a propósito: la misma llamada es 200 en `database` y 500 en
  `openfga`, **y eso es la respuesta correcta**.

### T-5 · Docs, README y CHANGELOG · la receta por signo
La tabla de §2.4 en el README; la ampliación de la frase del freeze (§5.3); la advertencia de que
`ScopeTreeWriteOptions.transaction` (encolar) y el nuevo `transaction` (escribir) **no significan lo
mismo**; el CHANGELOG en el estilo 1.1.0 (problema → decisión → qué NO se hace y por qué), con la
opción (A) y sus números **como parte del «qué NO se hace»**.
- **AC:** el README no contiene la palabra «atómico» aplicada a `openfga` en ninguna forma (grep);
  un caso fija la LETRA del 500 (patrón de `freeze.spec.ts`, que ya juzga la letra del README).

**Orden:** `T-0` → `T-1` → { `T-2`, `T-3` } → `T-4` → `T-5`. T-2 y T-3 **no en paralelo** por agentes
que mutan el árbol.

---

## 7 · Qué NO hacer

1. **No extender la outbox a los hechos.** Ni «solo para relaciones», ni «solo opt-in»: la ventana
   de fail-open de `revoke` es la misma y el aparcado no tiene reparación (§2.1d).
2. **No aceptar `{transaction}` en `openfga` y documentar que no es atómico.** Es un parámetro que no
   hace nada (§2.2) y es la fuga del cruce 4 · S5 con nuestra firma.
3. **No hacer que la capacidad falle en la CONSTRUCCIÓN por defecto.** Dejaría `openfga`
   inconstruible en apps que solo lo tienen registrado — incluida la de COGNITIV (§4).
4. **No meter `{transaction}` en la API de delegación ni en `syncAuthzCatalog`.** `withAuthzCatalogWrite`
   es el serializador del catálogo entre procesos; moverlo al commit del consumidor rompe 3D · M2 y el
   invariante 14 (§3).
5. **No reutilizar el nombre `transaction` sin distinguir su significado** del de
   `ScopeTreeWriteOptions` (encolar ≠ escribir).
6. **No inventar «leases/lápidas sobre cada tupla» para invertir el signo del lag en `openfga`.**
   Rompe `singleCheckAuthorize` (la promesa central de la 3b) y multiplica las escrituras.
7. **No dejar que el 500 sea un warning ni un log.** Es el patrón que el paquete ya juzgó dos veces.
8. **No implementar el bump de `pdp_version` en el paquete.** Es del consumidor
   (`exigencias-cognitiv:177`, *«en el store, nunca en un hook»*), y `onWrite` explícitamente **no
   puede** ser su fuente (`exigencias-cognitiv:32`).

---

## 8 · Riesgos que quedan aunque se implemente todo

- **La asimetría entre drivers es real y sobrevive.** `{trx}` es la primera funcionalidad del paquete
  donde el call-site **no** es portable entre drivers. La regla de higiene *«un cambio de driver es
  migración de hechos, no reescritura»* queda con una excepción declarada. Mitigado con
  `requireTransactionalWrites` (falla al arrancar, no en producción), pero no eliminado. **Va al
  README con esas palabras**, y es la pregunta que el juez debería contestar explícitamente.
- **La ventana del freeze se alarga a discreción del consumidor** (§5.3): una escritura que pasó la
  barrera confirma cuando confirme su transacción, que puede ser dentro de minutos.
- **El memo del catálogo es el punto frágil** (§5.1): si T-0 sale por (i), hay una vista de catálogo
  leída dentro de una transacción ajena. Es superficie nueva alrededor del invariante 14, que es el
  que más ha costado del paquete.
- **`database` gana una forma nueva de envenenar la transacción del consumidor** (UNIQUE, deadline
  vencido, `E_AUTHZ_FROZEN` tardío). Ninguna es incorrecta; todas son observables y nuevas.
- **La receta de §2.4 no compone**: `grant` + `revoke` del mismo hecho en la misma transacción, en
  `openfga`, acaban concediendo. Va escrito o alguien lo descubrirá en producción.

---

## 9 · Lo que preguntaría al dueño (solo lo que cambia la decisión)

1. **¿Se acepta que `{trx}` sea la primera funcionalidad no portable entre drivers?** Es el precio de
   no mentir. Si la respuesta es «no, la portabilidad manda», la única salida coherente es **no
   publicar `{trx}` en ningún puerto** y quedarse con la receta de §2.4 para los dos drivers — que
   deja el requisito #6 de COGNITIV en ❌. No hay tercera.
2. **¿`requireTransactionalWrites` entra ahora o se difiere?** Es lo que convierte el 500 por llamada
   en un fallo de arranque. Sin él, (C) cumple igual pero la sorpresa llega más tarde. Es un lote de
   ~1 h dentro de T-1.
3. **Nada más.** El alcance de `openfga` no depende de ninguna respuesta: no hay opción que le dé
   atomicidad, y el consumidor que dispara el gatillo no lo despliega.

---

## Apéndice · Reproducción de las mediciones

Scripts en el scratchpad del panelista (fuera del repo):
`trx_bench.mjs` (latencias FGA con el modelo fusionado), `trx_sql.mjs` (pg18: encolado, markApplied,
freeze, `pdp_version`), `trx_relay.mjs` (**el signo del lag** + drenaje end-to-end de 300 hechos),
`trx_pool.mjs` / `trx_sqlite_pool.mjs` (el interbloqueo del pool).

```
node --import @poppinss/ts-exec trx_bench.mjs     # N=200, WARMUP=20
node trx_sql.mjs                                  # N=500, WARMUP=50
node --import @poppinss/ts-exec trx_relay.mjs     # DEPTH=300
node trx_pool.mjs ; node trx_sqlite_pool.mjs
```

Todos los stores `trxan_*` del `:8101` y todas las bases `trxan_*` de pg18 se borran en el `finally`.
Verificado al terminar: `GET /stores` ⇒ `{"stores":[]}` y `datname like 'trxan%'` ⇒ 0 filas. El único
store ajeno que había al empezar (`fused-depth-1788293907500-0`, de otro agente) **no se tocó**; su
dueño lo retiró durante la sesión.
