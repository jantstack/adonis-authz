# Fase 3 · Lote 3E — cierre final (auditor 3D + code-review; tester por incorporar)

> Auditor sobre `56094ac`: **APTA CON CORRECCIONES** — V1/V2/V3 cerrados y demostrados (carrera con dos procesos reales y ventana forzada en PG y MySQL; las 23 barreras de `repro5` siguen en pie). Code-review: 8 hallazgos. Mismas reglas de siempre; los scripts del auditor están en `…/scratchpad/v7/`.

## Respuestas a sus cuatro preguntas de diseño (decididas)

1. **¿Un rol local puede tener `scopeType` por encima de su owner?** **No.** `spec.scopeType` debe ser el nivel del owner o uno por debajo (`scopeType ∈ {owner.type} ∪ tipos descendientes declarados`; sin `descendantsOf` declarado, solo el nivel del owner). Un rol invisible que solo ocupa un nombre es la forma limpia de la mina de A1.
2. **¿El `sync` debe abortar el catálogo entero por chocar con un local?** **No: los globales siempre ganan.** Con M1 la ambigüedad ya es fail-closed en lectura, así que el `sync` deja de tratar la colisión con un local como error: crea/actualiza el global, **reporta** el local afectado (`shadowedByGlobal`) y sigue. El tenant que ocupó el nombre solo se perjudica a sí mismo (sus lecturas por slug pasan a 422 y debe usar `{uuid}` o pedir el borrado). `defineScopedRole` **sigue rechazando** colisiones (un tenant no puede crear ambigüedad a propósito).
3. **¿`scopes.detached` es API de plataforma o puede colgar de una sesión de tenant?** Puede colgar de una sesión, así que **lleva policy de rango**: purga solo roles cuyo `rank` sea menor que el del actor; si alguno no lo es ⇒ 422 `E_AUTHZ_RANK_EXCEEDED` **antes de tocar nada**. Sin `actor` (config sin `requireActor`) se comporta como hoy y el README lo dice.
4. **¿Se mantiene "un rol cuyo owner sale del árbol no sobrevive"?** **Sí, con las tres piezas**: canonizar el scope, releer de la base (no del memo) y bajar por `descendantsOf` cuando esté declarado. Si no lo está, se purga el scope exacto y **la promesa se acota por escrito** (invariante 18).

## Bloqueantes

| # | Hallazgo | Decisión |
|---|---|---|
| **P1** 🟠 | (Auditor A1) Mina de slug: un actor de rank bajo define un rol de nivel superior a su owner (invisible, solo ocupa el nombre) y bloquea el `admin@unit` del dueño **y revierte el `sync` completo del siguiente deploy**. | Respuestas 1 y 2: (a) `defineScopedRole`/`updateScopedRole` ⇒ 422 `E_AUTHZ_ROLE_LEVEL_ABOVE_OWNER` si `scopeType` no es el del owner ni un descendiente declarado; (b) `syncAuthzCatalog` deja de lanzar por colisión con un local: escribe el global, lo cuenta en el reporte (`shadowedByGlobal: CatalogRoleRef[]`) y `authz:catalog:diff` lo lista con exit ≠ 0. Casos: el deploy entra entero con la mina puesta; un rol de nivel superior al owner ⇒ 422; el local ensombrecido pasa a ambiguo en lectura por slug y sigue resolviendo por `{uuid}`. |
| **P2** 🟡 | (Auditor A2 + A4) `scopes.detached`: `#purgeRolesOwnedBy` usa la clave **cruda** (un alias del uuid deja el rol vivo y bloquea el slug global) y lee del **memo** (un rol confirmado por otro proceso sobrevive); tampoco alcanza a los descendientes. | Respuesta 4: resolver la cadena **una vez** en `detached` y pasar `chain[0]` a la purga de hechos **y** a la de roles; los roles se leen **de la base** dentro de la misma transacción; con `descendantsOf` declarado se purgan también los owners descendientes. Casos: alias del uuid ⇒ el rol se purga y el slug global queda libre; rol confirmado por otro proceso con `{everyMs}` ⇒ purgado; nieto ⇒ purgado con `descendantsOf`, y sin él la promesa acotada en `CLAUDE.md`/README. |
| **P3** 🟡 | (Auditor A3) `detached` destruye roles que `deleteScopedRole` protege por rango. | Respuesta 3: `#assertAboveRole` sobre cada rol a purgar, antes de escribir nada. Caso: actor de rank 5 no puede tumbar por `detached` un rol de rank 40 (422), y sí uno de rank 2. |
| **P4** medio | (Code-review) Con el driver `openfga`, `defineScopedRole` crea estado que **nada puede borrar** (`purgeRole` ⇒ 500 siempre): `deleteScopedRole` y **`scopes.detached` de esa org** quedan muertos para siempre. | `defineScopedRole` comprueba la capacidad antes de escribir: si el driver activo no soporta `purgeRole` ⇒ 500 `E_AUTHZ_UNSUPPORTED` **antes** de crear nada, nombrando que los roles por scope llegan a `openfga` con el modo `facts` (3b). Reescribir el caso `whenFalse` del juez, que hoy **fija el callejón como comportamiento esperado**. |
| **P5** medio | (Code-review) `diffAuthzCatalog` revienta con 500 en la fila corrupta que existe para reportar (usa `parseAssignableAt` en vez del lector tolerante `storedAssignableAt`). | Usar `storedAssignableAt` en el diff; la fila corrupta se reporta como diferencia. Caso con `assignable_at` a mano. |
| **P6** medio | (Code-review) Estrechar `assignableAt` en el config rompe en silencio los roles locales que ya llevaban el permiso: el `sync` no los revalida y el diff no los menciona. | El `sync` revalida **todos** los roles (globales y locales) contra el `assignableAt` nuevo y falla con la lista de roles locales afectados (o los reporta junto a `shadowedByGlobal`, coherente con P1(b): decidir una sola política y aplicarla — **reportar y seguir**, nunca romper en silencio). Caso. |

## Obligatorias (rápidas)

| # | Qué |
|---|---|
| Q1 | (Auditor A5) Quitar del mensaje de `AMBIGUOUS_ROLE` el consejo de "renombra uno de ellos" (la API prohíbe renombrar) y documentar la salida real: `{ uuid }`, o que la plataforma borre uno. |
| Q2 | (Auditor A6) Los 422 no nombran identificadores de otro tenant: `ROLE_NOT_VISIBLE`, `AMBIGUOUS_ROLE` y `CATALOG_CONFLICT` listan **solo** los owners que están en la cadena preguntada. |
| Q3 | (Code-review) Exportar `AmbiguousRoleError` en `index.ts` (es el 422 que el README manda capturar). |
| Q4 | (Code-review) `OpenFgaAuthorizationDriver.listSubjects(role: RoleQuery, …)` en la firma; `purgeRole` **opcional** en `AuthorizationDriver` (el manager ya lo trata por `#optional`; como obligatorio rompe a terceros al compilar). |
| Q5 | (Code-review) `dialectOf` reconoce `better-sqlite3` en `lockCatalogForWrite` (hoy el cortocircuito nunca se dispara y solo es inocuo porque knex compila `forUpdate` a vacío en sqlite3). |
| Q6 | (Code-review) `runCatalogDiff` no recalcula el diff entero para extraer `scopedRoles`; y esas líneas no se imprimen dentro del bloque de diferencias de otro catálogo. |
| Q7 | (Auditor A8) `AuthzWriteEvent.role` pasó de `string` a `RoleQuery`: documentarlo en el CHANGELOG como pérdida de auditoría para sinks que filtraban por slug, y emitir siempre la forma resuelta (`CatalogRoleRef`) en el evento, no la pregunta cruda. Los `role_purged` de `detached` llevan `actor` cuando lo hay. |
| Q8 | CHANGELOG 2.2 "Lot 3E"; `CLAUDE.md` invariantes 15/18 con las acotaciones de P2/P3; README §Scoped roles (nivel del rol ≤ owner; globales ganan; salida de la ambigüedad). |

## Entrega
`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-3-lote-e-informe.md` incremental. Sin commits.
