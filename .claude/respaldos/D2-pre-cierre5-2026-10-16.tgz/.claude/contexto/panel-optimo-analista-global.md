# Panel «paquete óptimo» — analista global (2026-10-16)

> Miembro de SOLO LECTURA. Árbol medido: `main` en `75353fe` + D2 y cierres 1–4 SIN commit (el estado del brief).
> El problema de la renovación en OpenFGA lo mide otro miembro; aquí solo se considera como dependencia (§7).
> Leyenda: **✅ medido/verificado en código** · **🟡 inferido o estimado (se dice de qué)** · **❓ pendiente de verificar**.
> Scripts (todos con stores efímeros `optglobal-*` en `:8090`, borrados; 0 vivos al terminar, comprobado):
> `.claude/reproducciones/optimo-global/{bench_authorize.mjs, bench_authorize_sqltree.mjs, bench_relations.mjs, bench_batch.mjs, bench_batch2.mjs, db_down_authorize.mjs}`.
> Máquina: 16 núcleos, carga ~0,3; Node 22.23.2; OpenFGA v1.19.0 con datastore **postgres** y flags por defecto (`docker inspect openfga-dev`).

## 0. Resumen en cinco líneas

1. **El camino caliente está bien.** `database` resuelve `check`/`checkMany`/`decideMany`/`listObjects` en **1 SQL** cada uno (≤ 1,4 ms con 599 objetos); `openfga` hace `authorize` y `check` con **1 `Check`**. No hay N+1 en el paquete salvo `membersOf` con deny (declarado) y la resolución de cadena del CONSUMIDOR.
2. **Hay una letra falsa en el README** (linaje L8): «*no SQL per request in `authorize`*» y «*`authorize` survives your application database being down*» son falsas con el default `catalogRevalidate: 'always'` — medido: 1 SQL por `authorize` y **503** con la lectura de versión caída (con `{ everyMs }` sí sobrevive).
3. **Un lote de 50 en `batchCheck` es 4× más lento que 5 lotes de 10 en serie** en este servidor (126 ms frente a 31 ms con grupos anidados). La constante `FGA_MAX_BATCH_CHECK = 50` no es neutra.
4. **La verificación tiene ~25 min de desperdicio por pasada, sin perder ni un ápice de detección**: la guardia corre la fuerza bruta (3,1 s de 3,6 s del spec) en los 181 mutantes cuando solo 19 la necesitan, y el spec exhaustivo de orden (89 s, sin base de datos) corre en los 4 motores (y 8 veces en CI).
5. **Empaquetado**: `@openfga/sdk` no tiene rango declarado (peer pre-1.0 sin fijar), `engines: >=20.6` contradice a los peers (Adonis 7 exige Node ≥ 24) y el 28 % del tarball son source maps que apuntan a `src/` no publicado.

---

## 1. Rendimiento en caliente

### 1.1 Mediciones (p50 / p95, N=150–200 tras calentamiento)

| Operación | `database` (SQLite `:memory:`) | factura | `openfga` (`:8090`) | factura |
|---|---|---|---|---|
| `authorize` (roles, árbol en memoria) TRUE / FALSE | 0,42 / 0,32 ms | **3 SQL** (versión + denies + asignaciones) | 3,90 / 4,39 ms | **1 SQL (versión) + 1 `Check`** |
| `authorize` con árbol SQL (`hierarchicalScopeResolver`, 3 niveles) | 0,57 / 0,43 ms | **6 SQL** (3 del paquete + 3 del resolutor) | — | — |
| `check` relaciones (3 saltos de grupo) | 0,31 ms | 1 SQL | 2,71 ms | 1 `Check` |
| 50 × `check` en serie | 13,2 ms | 50 SQL | 154,9 ms | 50 `Check` |
| `checkMany(50)` | **0,66 ms** | 1 SQL | **118,9 ms** (p95 217) | 1 `batchCheck` |
| `decideMany(50)` | 0,65 ms | 1 SQL | 52,5 ms | 2 `batchCheck` |
| `listObjects` (599 objetos) | 1,40 ms | 1 SQL | 6,44 ms | 1 `ListObjects` |
| `membersOf` (101 miembros, sin deny) | 0,66 ms | 1 SQL | 500 (declarado) | — |
| `membersOf` (objeto con deny, ~100 candidatos) | **21,1 ms** | **103 SQL** | — | — |

Fuente: `bench_authorize.mjs`, `bench_authorize_sqltree.mjs`, `bench_relations.mjs`. Siembra `openfga`: 704 escrituras en 3,5 s (~5 ms/escritura: barrera del freeze en SQL + `Read` + `Write`); `database`: 704 en 0,46 s.

### 1.2 Cuellos de botella con cifra

**P-1 · `batchCheck` grande es superlineal en este servidor (✅ medido; 🟡 depende del servidor).** `bench_batch.mjs`/`bench_batch2.mjs`, mismo sujeto, documentos alcanzados por 3 grupos anidados:

| Forma | modelo con deny | modelo sin deny |
|---|---|---|
| `checkMany(10)` | 5,1–6,6 ms | 3,8–4,2 ms |
| `checkMany(25)` | 26,3 ms | 22,4 ms |
| `checkMany(50)` (1 `batchCheck`) | **126–134 ms** | 71–86 ms |
| 5 × `checkMany(10)` **en serie** | **31,1 ms** | 22,9 ms |
| 5 × `checkMany(10)` en paralelo | 111 ms | 79 ms |
| 50 × `check` en paralelo | 147 ms | 83 ms |
| `checkMany(50)` con 50 directos (sin grupos) | 10,8 ms | 5,6 ms |

Lectura: el coste no es el round-trip sino la **concurrencia dentro del servidor** (50 resoluciones anidadas a la vez contra un datastore postgres con el pool por defecto). Por eso `decideMany(50)` (100 ítems en DOS `batchCheck` de 50, de los que solo 25 por lote son caros) sale a 52 ms, la mitad que `checkMany(50)`. El troceo vive en `src/drivers/openfga_relations_driver.ts:944` (`FGA_MAX_BATCH_CHECK`) y el mismo en `decideMany` (`:997`) y en `authorizeMany` de roles. **No** es una propiedad del paquete sino de la configuración del servidor (`OPENFGA_DATASTORE_MAX_OPEN_CONNS`, límites de concurrencia de check), así que la recomendación es **opción del driver + medición en un servidor tipo producción**, no cambiar el número a ciegas. Impacto para COGNITIV hoy: bajo (sus cadenas de `decideMany` son cortas, §3).

**P-2 · `authorize` en `database` = 3 SQL del paquete + D del resolutor (✅ medido).** La cadena la resuelve el consumidor y el único helper ascendente publicado, `hierarchicalScopeResolver`, hace una lectura por nivel (`src/hierarchical_resolver.ts`, `nodeOf` por ancestro). Con árbol SQL de 3 niveles: **6 SQL por `authorize`**. En SQLite local son 0,57 ms; con PostgreSQL en red cada SQL es un round-trip (🟡 0,3–1 ms típicos ⇒ 2–6 ms por `authorize`). El paquete ya publica la CTE DESCENDENTE (`sqlDescendantsOf`, `src/sql_descendants.ts`) y las aristas (`sqlScopeEdges`), pero no la ASCENDENTE. Además denies y asignaciones son dos sentencias separadas (`src/drivers/database_driver.ts:699-740`) que podrían ser una (`EXISTS grant AND NOT EXISTS deny`). Techo alcanzable: **2 SQL** (versión + decisión con CTE de cadena), o 1 con `{ everyMs }`.

**P-3 · `membersOf` con deny es N+1 (✅ medido, ya declarado).** `src/drivers/database_relations_driver.ts:1004-1025`: con un deny vigente en el objeto, un `check` por candidato (103 SQL, 21 ms con 101 candidatos en SQLite; ×RTT en red), con cota `RELATIONS_MEMBERS_DENY_CHECK_MAX` y deadline total. Está acotado y documentado; se puede hacer en 1–2 consultas aplicando la regla de corte por candidato sobre la misma CTE.

**P-4 · `listObjects` de `openfga` consume el tope del servidor ENTRE particiones (✅ código, ya declarado).** El holder no lleva partición (`#subjectUser`, `openfga_relations_driver.ts:575-593`: `user:<uuid>`), `ListObjects` devuelve objetos de TODAS las particiones y se filtra después (`:1141`). Un invitado presente en muchas organizaciones (la F2a de COGNITIV) trunca antes. Está señalado con `truncated` (B4); no es un defecto, es el precio del diseño de un store compartido.

**P-5 · La barrera del freeze cuesta 1 SQL por escritura también en `openfga` (✅).** Es deliberado (invariante 14, +0,14 ms p50 medido en PG por el lote 3b-7). No tocar.

**Lo que NO es cuello de botella (✅):** índices. `authz_assignments`/`authz_denies` se consultan por `(holder_type, holder_uuid, …)` y el UNIQUE de cinco columnas empieza por esas dos (`stubs/migration.stub:112-118`, `:136-140`); `authz_relations` se consulta por `(partition_key, object_type, object_uuid, relation)` y por `(partition_key, subject_type, subject_uuid)` en la recursión de la CTE `principal` (`database_relations_driver.ts:1202-1225`), y los dos tienen índice. Hallazgo menor: **tres índices son prefijo exacto de un UNIQUE** y no aportan lectura, solo coste de escritura: `authz_asg_holder_idx` ⊂ `authz_asg_holder_role_scope_uq`, `authz_deny_holder_idx` ⊂ `authz_deny_holder_perm_scope_uq`, `authz_rel_object_idx` ⊂ `authz_rel_tuple_uq`. (El `COALESCE(subject_relation,'')` del JOIN es tolerancia a filas pre-L-4b; no impide usar el prefijo del índice.) Tocar la migración publicada tiene receta y caso (`migration_stub.spec`), así que es 2.6, no RC.

---

## 2. Arquitectura y complejidad

| Módulo | Líneas | Observación (✅ código) |
|---|---|---|
| `src/manager.ts` | 4 439 | Mezcla cinco responsabilidades: PDP (authorize/grant…), **freeze** (~400 l., 644–1003), **relay/requeue de la outbox** (~930 l., 1164–2095: `#drainScopeChanges` 209 l., `relayScopeChanges` 157, `#blockOriginOf` 94), **orquestación de reconcile** (~400 l., 2095–2470), **delegación de roles locales** (~900 l., 3126–3900). Las cuatro últimas son API de PLATAFORMA con frontera limpia. |
| `src/drivers/openfga_driver.ts` | 3 785 | Driver + reconcile + enumerateFacts + proyección. |
| `src/relations/reconcile.ts` | 1 606 | `planPartition` es UNA función de **372 líneas** (1041–1413). |
| `src/relations/tuple_order.ts` | 739 | Motor de orden topológico con residuo/retención/horizonte — existe por la no-atomicidad multi-request de FGA (§7). |
| `src/types.ts` | 2 431 | Limpio: 0 `any`. |
| `src/testing/contract.ts` | 4 726 | Publicado en `/testing`. |
| `src/errors.ts` | 1 112 | **59 clases de error exportadas en la raíz.** |

**Superficie pública (✅ medido por importación):** `index.ts` exporta **140 símbolos en runtime** (69 clases —59 `*Error`—, 49 funciones, 12 números, 5 cadenas, 5 objetos); `/openfga` 37; `/testing` 32. Comandos: 10 con **37 banderas** (8 en cada reconcile). `defineConfig`: ~41 claves.

**Gemelos roles↔relaciones (✅ código).** El embudo de escritura está copiado: `#write`/`#notify`/`#logHookFailure`/`#transactional` existen en `src/manager.ts:4400-4439,570` y en `src/relations/manager.ts:249-300,218`, con comentarios que dicen «el MISMO `#notify` de roles». Y ya divergen: relaciones copia el evento antes de entregarlo al hook (`#copyEvent`, `relations/manager.ts:268`, ⚪ 8 de alpha.3) y roles entrega las referencias del llamante (`src/manager.ts:4022`, `{ action: 'granted', subject, scope, … }`). Es un ⚪ (el sink puede mutar el `subject` del llamante), pero es exactamente la clase de divergencia que la línea (a) «gemelos» del punto 5 de CLAUDE.md persigue a mano.

**Qué sobra o está mal ubicado:**
- `RelationPage` se acepta y **se ignora** en `listObjects`/`listSubjects`/`membersOf`/`listDenies` de los DOS drivers (`_page`, `database_relations_driver.ts:815,861,875,930`; `openfga_relations_driver.ts` ídem). Es una **entrada inerte silenciosa en la API pública** — linaje **L5**. O se honra o se rechaza.
- Tres índices redundantes (§1.2).
- 59 clases de error en la raíz: el consumidor discrimina por `code` (lo dice el README); las clases son superficie que fija la major.

---

## 3. Flexibilidad / API (consumidor: COGNITIV, `cognitiv-respuesta-plan25-2026-10-15.md`)

- **Lo que ya encaja (✅):** `decideMany` es literalmente su primitiva de cadena (respuesta 13); `checkMany` para positivos; `createTestClock`; `assertWrite` puro y síncrono (respuesta 9); `truncated` como 503 (respuesta 11).
- **Lo que les cuesta código propio hoy:** `partition_sweep.ts` (barrido paginado + `purgeObject`/`purgeSubject` por tupla) ⇒ `purgePartition` (lote C, ya planificado). Es la petición de mayor apalancamiento: elimina el «censo fuera de la transacción».
- **Coste para su caso real:** cadenas de tenencia cortas (hoja→raíz, decenas de nodos como mucho) ⇒ `decideMany(≤10)` en `openfga` ≈ 5–7 ms medido; en `database` < 1 ms. No necesitan P-1 para F0/F1.
- **F2a (invitados entre organizaciones):** les afecta P-4 (el tope de `ListObjects` se reparte entre particiones) en `listObjectsForSubject`; ya piden `truncated` ahí (petición 3).
- **Extensibilidad de drivers (✅):** puerto con capacidades opcionales normalizadas (D15), jueces publicados por puerto. El coste real para un tercero es el deber de **re-validar** (F-05, partición, trx) dentro de su driver, porque `manager.driver()` es una salida documentada (§4).
- **Configurabilidad:** falta un mando de troceo de `batchCheck` (P-1) y el helper de cadena ascendente (P-2). Sobra la paginación inerte (§2).

---

## 4. Seguridad estructural — dónde depende de disciplina

1. **Las guardas transversales se replican en 3–4 capas por operación** (manager + driver `database` + driver `openfga` + doble): `assertRelationDeclared`, `assertPartition`, `#assertObject`/`#assertObjectId`, sujeto, trx, freeze. La guardia de superficie las vigila con **181 mutantes** (`tests/fixtures/guard_mutants.json`: 59 en `relations/manager.ts`, 47 en `openfga_relations_driver.ts`, 38 en `database_relations_driver.ts`, 29 en `identity.ts`, …). La guardia es buena, pero es el síntoma: el linaje L1 tuvo 6+ iteraciones porque cada capa nueva es un sitio más donde olvidar. **Propuesta estructural:** invertir la relación manifiesto→código — una tabla declarativa por operación (`op → {f05: 'pair'|'type'|'userset', partition, trx, freeze, write, actor}`) que GENERA un `GuardedRelationsDriver` (decorador), aplicado por el manager al construir y devuelto también por `driver()`. Los drivers dejan de re-validar; la matriz pasa de operaciones × 4 capas a operaciones × 1; los mutantes de «quitar la guarda en la capa X» desaparecen porque no hay capa X. Steelman del statu quo: la re-validación en el driver protege a quien construye el driver crudo en su factory y lo usa directamente; respuesta: eso se puede documentar como «sin garantías», igual que hoy se documenta que `driver()` se salta `actor`/`within`/`onWrite`.
2. **Embudo de escritura duplicado** (§2): un `WriteFunnel` compartido por los dos managers (puerta trx → freeze → actor → `assertWrite` → `#write` con indeterminado → copia del evento → `#notify`) convierte la línea «gemelos» de cada cierre en una propiedad del tipo.
3. **La seguridad que depende del ORDEN de operaciones multi-request** (L10: `tuple_order.ts`, `relationWithheldWrites`, `renewal-unsafe`) depende de que FGA no sea atómico entre requests. Si la hipótesis «make-before-break» del coordinador se confirma (otro miembro), gran parte de esa maquinaria se BORRA, que es la mejor simplificación posible de seguridad (§7).
4. **Letra que promete más de lo que el default cumple** (`authorize` sin SQL / sobrevive a la base caída, §0.2): no es un agujero de concesión (falla cerrado con 503), pero una decisión de arquitectura del consumidor (desplegar `openfga` para que `authorize` sobreviva a su base) se basaría en una frase falsa.

---

## 5. Coste de la verificación

### 5.1 Dónde se va el tiempo (✅ medido)

Verificación completa en serie (`scratchpad/lD2c4/SUMMARY`, la última del coordinador): build 9 s, typecheck 5 s, `:memory:` **198 s**, `sqlite-file` **215 s**, pg **264 s**, mysql **263 s**, **guard-mutants 1 049 s**, flag-mutants 143 s, runbook 18 + 21 s, más 11 × 8 s de `docker restart` ⇒ **≈ 38 min**. Evolución: guard-mutants 393 s (176 mutantes, cierre 2) → 767 s (178) → 1 049 s (181): **+167 % con +3 % de mutantes**.

Causas, medidas:
- **Guardia**: una corrida de `tests/guard_surface.spec.ts` = 6,25 s de pared, 236 casos, 3,6 s de casos, de los que **3,12 s son UNO**: `GS · P · relations.order.exhaustive` (fuerza bruta 131 072 pares + 2 × 50 000 de vigencia). Solo **19 de 181** mutantes lo esperan en rojo (`order.*`, `rec.*`). Una corrida filtrada a un caso (`--tests=…`) cuesta **0,64 s** de pared.
- **Spec exhaustivo** `tests/relations_order_exhaustive.spec.ts`: **89 s** en `:memory:` (`scratchpad/specs.tsv`, medición por spec de esta sesión) = ~45 % de `npm test`; es **sin base y sin servidor** (lo dice su docblock) y corre idéntico en los 4 motores ⇒ 267 s redundantes por verificación local; en CI corre **8 veces** (`test` ×2, `openfga` ×2, `engines` pg/mysql × 2 pasos).
- **CI `engines`**: el paso «database» (`ci.yml:154`) es un subconjunto del paso «database + openfga» (`:157`) — el harness `database` corre en los dos; la única rama que solo existe sin servidor es un `assert.isUndefined` trivial (`tests/harness_cleanup.spec.ts:191`).

### 5.2 Qué acelerar sin perder poder de detección

| Cambio | Ahorro | Pérdida de detección |
|---|---|---|
| **G1** `check_guard_mutants.mjs`: por mutante, correr solo `expectRed` (`--tests`) | 181 × 6,25 s → 162 × ~0,7 + 19 × ~3,8 ≈ **3 min** (de 17,5) | **Ninguna en el veredicto** (`notSeen`/`stillGreen` siguen igual). Se pierde el informe de colaterales, que hoy es informativo (`check_guard_mutants.mjs:168-171`): mantenerlo en una pasada completa nocturna. |
| **G2** N copias del árbol en paralelo (16 núcleos; 354 MB por corrida) | ×6–8 adicional ⇒ **< 1 min** | Ninguna (cada copia es independiente; ya se copia el árbol). |
| **G3** spec exhaustivo solo en `:memory:` (tag `@pure` o filtro por `TEST_DB`) y en un job propio en CI | 267 s locales; ~10 min de CPU en CI | Ninguna: no toca base ni servidor. |
| **G4** CI: quitar el paso «database» de `engines`; el job `openfga-tiny` solo con los specs de `openfga` | ~2 suites por motor | Ninguna (subconjunto estricto). |
| **G5** flag-mutants en paralelo | 143 s → ~30 s 🟡 | Ninguna. |

Resultado estimado (🟡, suma de lo medido): **38 min → ~17 min** en serie local con G1–G3, sin un solo mutante menos.

**No hacer:** muestrear mutantes (un 30 % aleatorio pierde detección justo en la columna que se olvida); paralelizar los 4 motores en local mientras haya casos que juzgan el truncado de `ListObjects` por TIEMPO (`#listObjectsPage`, reloj monótono) contra un `:8090` compartido y con `docker restart` entre pasos — primero medir su flakiness bajo carga.

---

## 6. Empaquetado y operación

| Hallazgo | Evidencia | Peso |
|---|---|---|
| **`@openfga/sdk` sin rango.** Está en `peerDependenciesMeta` (optional) pero NO en `peerDependencies` (`package.json`; confirmado en el registro: `npm view …@2.5.0-alpha.2`). El driver usa tipos internos del SDK pre-1.0 (`ClientBatchCheckItem`, `correlationId`, `continuation_token`); un `npm i @openfga/sdk` que traiga una 0.10/1.0 rompe sin aviso. Hoy: SDK 0.9.7 publicado, el repo prueba 0.9.6. | ✅ | 🟠 operación (regla de la casa: fijar pre-1.0) |
| **`engines.node: >=20.6.0` contradice a los peers**: `@adonisjs/core` y `@adonisjs/lucid` exigen `>=24.0.0`, `@openfga/sdk` `>=20.19.0`. El job `compat` (20/22/24) solo hace `node --check` (sintaxis). Y la verificación local del brief corre en **Node 22** (`nvm use 22`), por debajo de lo que Adonis 7 declara; CI usa 24. | ✅ | 🟡 |
| **Source maps muertos.** `sourceMap` + `declarationMap` (`tsconfig.json`) apuntan a `../../src/*.ts`, que no se publica (`files: [build, README.md]`). Build del árbol actual en el scratchpad: 3,97 MB / **947 KB gz** con maps; 2,70 MB / **685 KB gz** sin ellos (**−28 %**). Tarball actual (`npm pack --dry-run`): 275 ficheros, 1,09 MB empaquetado, 4,39 MB desempaquetado, de ellos 1,26 MB `.map`. | ✅ | 🟡 |
| `/testing` = 1,07 MB desempaquetados (24 %), se instala en producción pero no se carga (subpath). | ✅ | ⚪ (no separar ahora) |
| Dependencias runtime: solo `uuid ^14` (v7). Correcto. | ✅ | — |
| **README de 381 KB** (2 124 líneas). npm muestra el README desde los metadatos, históricamente truncados a 64 KB ([blog de npm](https://blog.npmjs.org/post/153186129005/zero-one-infinity-readmes), [nesbitt.io 2026](https://nesbitt.io/2026/04/10/package-registries-and-pagination)). | ❓ no verificado contra npmjs.com hoy (el `latest` sigue en 1.1.0) | 🟡 |
| **CLAUDE.md de 171 KB (~24 000 palabras)** que carga cada agente; los tests leen su punto 6 (la guardia lo copia). Es coste de verificación/agentes, no del paquete. | ✅ | 🟡 proceso |
| ESM/tipos: `exports` sin condición `types`, pero `.d.ts` hermanos ⇒ resuelve con `NodeNext`. Correcto. | ✅ | — |

---

## 7. Dependencia con la renovación (lo mide otro miembro)

La maquinaria de orden multi-request (`src/relations/tuple_order.ts` 739 l., `relationWithheldWrites`, motivos `renewal-unsafe`/`withheld-by-unsafe-deny`/`deny-conditional`) y la mitad de la fuerza bruta de vigencia de la guardia (el modo «dos Write»: `renewalUnsafe 59 798`, `withheld 86 516`… en `guard_surface.spec.ts:2000-2010`) existen porque renovar en FGA son dos `Write`. **Si «make-before-break» resulta atómico**, el paquete gana por los tres ejes a la vez: borra código de seguridad por disciplina, el modo «dos Write» de la fuerza bruta sobra (la propiedad de la guardia baja a la mitad) y desaparece la familia de 409/retenciones que el consumidor tiene que entender. Esa decisión **condiciona** las tareas 2.6 de simplificación del reconcile (S8): no descomponer `planPartition` antes de saber qué ramas sobreviven.

---

## 8. Lista priorizada (impacto × esfuerzo × riesgo)

### Antes de la RC (baratas, sin cambio de semántica en `src/` salvo lo marcado)

| # | Qué | Impacto | Esfuerzo | Riesgo | Por qué antes de la RC |
|---|---|---|---|---|---|
| **R1** | Corregir la letra de `authorize` en `openfga` (README §«What the driver actually promises», línea ~1166–1170): con `'always'` es **1 SQL por PK por pregunta** y con la base caída es **503**; «sobrevive a la base caída» solo con `{ everyMs }` dentro de la ventana. Caso de letra + caso de factura (1 SQL / 0 SQL). | Alto (decisión de arquitectura del consumidor) | Bajo | Nulo | L8; la RC se ensaya contra la letra. |
| **R2** | `peerDependencies["@openfga/sdk"] = ">=0.9.6 <0.10.0"` (meta optional ya está). | Alto (operación) | Mínimo | Nulo | Lo que entre en la RC es lo que COGNITIV fija. |
| **R3** | `engines.node` alineado con los peers (`>=24`), job `compat` honesto, verificación local en Node 24. | Medio | Mínimo | Bajo | Ruptura de metadato: mejor en alpha que tras la estable. |
| **R4** | `RelationPage` inerte en `listObjects`/`listSubjects`/`membersOf`/`listDenies`: decidir **honrar** o **rechazar** (`page` ≠ `undefined` ⇒ 500 `E_AUTHZ_UNSUPPORTED` nombrando la operación). Lo barato y coherente con L5 es rechazar. | Medio | Bajo | Bajo (entra en la guardia como columna) | Es firma pública: cambiarla tras 2.5.0 es major. |
| **R5** | Guard-mutants G1 + G2 (filtro por `expectRed` + copias en paralelo; pasada completa con colaterales en nocturno). | Alto (17,5 → < 3 min por gate) | Bajo–medio (solo el script) | Bajo si el script lleva su propio caso «un mutante vivo sale VIVO» | La RC necesitará varias pasadas del gate. |
| **R6** | G3 + G4: spec exhaustivo solo en `:memory:`/job propio; quitar el paso redundante de `engines`. | Medio (−267 s local, −~10 min CPU CI) | Bajo | Nulo | Igual. |
| **R7** | Quitar `sourceMap`/`declarationMap` del build publicado (o `inlineSources`). | Bajo–medio (−28 % gz) | Mínimo | Bajo (trazas apuntan al `.js`) | Decisión del dueño; si se hace, en la RC. |

### 2.6

| # | Qué | Evidencia | Nota |
|---|---|---|---|
| **S1** | Helper `sqlScopeChain(...)` = CTE ASCENDENTE (espejo de `sqlDescendantsOf`, mismo manejo de dialectos). | P-2: 6 → 4 SQL por `authorize` con árbol de 3 niveles | Aditivo. Mayor ganancia por esfuerzo en `database`. |
| **S2** | Plegar denies + asignaciones en UNA sentencia en `database.authorize`. | P-2: 3 → 2 SQL del paquete | Riesgo medio (deny-wins en SQL); lo juzga el contrato. Medir en PG en red antes. |
| **S3** | Opción `batchCheckChunk` en los drivers `openfga` (roles y relaciones) + medición en un servidor tipo producción para fijar el default. | P-1: 126 ms → 31 ms (×4) | La correlación por id ya existe; el número sí es semántico para el rendimiento. |
| **S4** | `membersOf` con deny en 1–2 consultas. | P-3: 103 SQL / 21 ms | Mantener la cota. |
| **S5** | `WriteFunnel` compartido por los dos managers (y el ⚪ del evento sin copiar en roles). | §2, `manager.ts:4022` vs `relations/manager.ts:268` | Reubica `find` de mutantes: con R5 hecho, re-anclar el manifiesto es barato. |
| **S6** | Partir `manager.ts` en módulos de plataforma: `ScopeRelay` (1164–2095), `FreezeController` (644–1003), `ReconcileOrchestrator`, `Delegation`. Monolito modular, sin cambio de API. | §2 | Mecánico; mismo comentario de mutantes. |
| **S7** | Índices redundantes (3) con receta de migración y caso. | §1.2 | Solo coste de escritura. |
| **S8** | Descomponer `planPartition` (372 l.). | §2 | **Después** de la decisión de la renovación (§7). |
| **S9** | README → índice ≤ 60 KB + `docs/`, con los tests de letra apuntando a los nuevos ficheros; CLAUDE.md → invariantes + mapa (historia a `.claude/contexto/`), preservando los fragmentos que los tests leen. | §6 | Verificar antes el truncado de npm. |

### 3.0 (estructural)

- **T1** Guardas generadas desde una tabla declarativa + `GuardedRelationsDriver` también tras `driver()` (§4.1). Es lo que dobla la curva de coste de L1 y de la guardia.
- **T2** Errores: un `AuthzError` con `code` discriminante; las 59 clases como alias deprecados (en 2.6 se puede añadir `isAuthzError(e, code)` sin romper).
- **T3** Si se confirma make-before-break: borrar la maquinaria de retención/renovación (§7).

### No hacer

- **Cambiar el default de `catalogRevalidate` a `{ everyMs }`** para que R1 «sea verdad»: compra latencia con una ventana fail-open. Se corrige la letra, no el default.
- **Muestrear mutantes** para acelerar: G1+G2 dan más velocidad sin perder detección.
- **Paralelizar los 4 motores en local** sin medir antes la flakiness de los casos de truncado por tiempo contra el `:8090` compartido.
- **Refactors de `src/` (S5, S6, T1) antes de la RC**: cada uno re-ancla decenas de `find` del manifiesto de mutantes justo cuando se congela el código.
- **Separar `/testing` en otro paquete** ahora: solo ahorra disco y rompe imports de terceros.
- **Bajar `FGA_MAX_BATCH_CHECK` a 10 sin medir en producción**: lo medido es de un servidor con datastore postgres y pool por defecto; en otro puede invertirse.

---

## 9. Pendientes de verificar (❓)

- P-1 en un OpenFGA con datastore y pool de producción (y en `memory`), para fijar el default de S3.
- P-2 en PostgreSQL en red (aquí solo SQLite local): el beneficio real de S1/S2 es proporcional al RTT.
- Truncado del README en npmjs.com (§6) cuando `latest` pase a 2.x.
- La cifra de 89 s del spec exhaustivo viene de `scratchpad/specs.tsv` (medición por spec de esta sesión); la de la propiedad de la guardia (3,12 s) la medí yo.

**Recomendación en una frase:** antes de la RC, solo letra, metadatos y velocidad del gate (R1–R7: ninguna toca la semántica); el rendimiento (S1–S4) y la simplificación estructural (S5–S6, T1) van a 2.6/3.0, y la simplificación grande del reconcile espera al veredicto de la renovación.

**Siguiente paso concreto:** que el dueño firme R1–R4 (dos de ellas son metadatos de una línea) y que R5 se haga primero, porque abarata todas las verificaciones que vienen hasta la estable.
