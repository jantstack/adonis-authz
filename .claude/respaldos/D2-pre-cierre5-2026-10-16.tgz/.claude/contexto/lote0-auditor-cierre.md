# Auditor · re-ataque del CIERRE del lote 0 (2026-10-14)

Árbol sin commitear sobre `0fbee6e`. Objetivo: regresiones del propio cierre y si la guardia
(`tests/guard_surface.spec.ts` + `tests/fixtures/guard_manifest.ts`) sigue siendo engañable. Repro nueva:
`.claude/reproducciones/lote0-cierre-reataque.spec.ts` (verde = defecto). Todo corrido en copias del árbol en el
scratchpad, sqlite `:memory:`; mutantes con `check_guard_mutants.mjs --only`.

## Veredicto en una línea
Seguro con reservas: los dos 🟠 están cerrados y no encontré ningún 🔴/🟠 nuevo. Quedan cuatro 🟡 en los que la
guardia se puede engañar, todos con una condición: una edición deshonesta o un copy-paste en el spec o en el
closure del provider. Ninguno abre un bypass en runtime con los drivers publicados.

## Repro original sobre el árbol cerrado
`lote0-reataque.spec.ts` sobre una copia: **Tests 1 passed, 6 failed (7)**. 🟠1, 🟠2, 🟡3, 🟡4, ⚪5 y 🟡7 salen ROJOS.
El único verde es 🟡6, y la explicación del cierre es correcta: ese caso afirma un hecho de JavaScript (una subclase
puede llamar a `driver()`), no corre la guardia. El cierre de lo que señalé (que «el servicio» solo afirmaba
`instanceOf` + identidad) es real para `buildRelationsManager`: exige el prototipo exacto, `MANAGER_BUILDS` sondea las
dos vías y el mutante `provider.wrapped` muere. Lo que queda abierto está en 🟡B, más abajo.

## Hallazgos (ordenados por severidad)

### 🟡A · INVOKE es la única puerta entre la fila y el método, y nadie comprueba que llame a SU método
- Escenario: lectura nueva `probeMany` en `RelationsManager` sin ninguna guarda (sin F-05, sin `assertScope`) + fila
  `managerRead('probeMany')` + `INVOKE.probeMany = (t, v) => t.check(...)` (el copy-paste natural de la línea de
  `check`) + `F05_VARIANTS.probeMany` + las celdas añadidas a los mutantes de `manager.check.*` ⇒ **guardia VERDE** (las
  celdas f05/partition y G-R de `probeMany` se corren y pasan) **y** `check_guard_mutants --only
  manager.check.f05,manager.check.partition` sobre ese árbol: «2 muertos / 2», línea base 150 verdes. Es decir, el job
  `guard-mutants` de CI también queda verde. Mientras tanto, el manager pasa `role_binding` y una partición `A#B` al
  driver (caso BYPASS, verde).
- Evidencia: ✅ repro 🟡A + mutantes medidos (`tests/guard_surface.spec.ts:119` INVOKE, `:949` G-R por fila, `:965`
  G-R meta: los dos llaman a `INVOKE[op]`, nunca a `t[op]`).
- Lo que SÍ resiste: si la operación nueva es una ESCRITURA y su INVOKE se enruta a `relate`, la columna `write` la
  caza, porque compara `events[0].operation` con `op`. Medido: «GS · manager.relateMany · write» ROJO. Esa es la razón
  de bajar el hallazgo de 🟠 a 🟡: la vía solo queda abierta para lecturas.
- Steelman del defensor: «quien escribe un INVOKE falso está editando el test; lo verá el diff». → Me convence a
  medias. El fallo aquí no es malicioso, es un copy-paste, y lo que sostiene el cierre («G-R invoca TODO el
  inventario») es justo lo que el copy-paste anula. El impacto en runtime es nulo con `database` y `openfga`, porque los
  dos aplican F-05 y `assertScope` por su cuenta (`src/drivers/database_relations_driver.ts:586`). Por eso queda en 🟡.
- Mitigación mínima: en G-R (o en un caso G-0), envolver el target en un Proxy que registre qué propiedad pública se
  lee y exigir que `INVOKE[op]` acceda a `t[op]`.

### 🟡B · Lo que sirve el contenedor no es lo que se sondea
- Escenario: el closure de `this.app.container.singleton('authz.relations', …)` deja de devolver
  `buildRelationsManager(config)` tal cual y lo envuelve (en la repro, con `Object.setPrototypeOf` a una subclase cuyo
  `relate` escribe por `driver()`) ⇒ **guardia VERDE**. «El servicio», `MANAGER_BUILDS` y `provider.wrapped` llaman
  todos a `buildRelationsManager` directamente; ninguno resuelve el singleton.
- Evidencia: ✅ repro 🟡B; `providers/authz_provider.ts:97`.
- Steelman: «el closure es una línea y está a la vista». → Sí, pero ese era el argumento contra el 🟡6 original, y el
  cierre lo dio por cerrado con «lo que el provider construye». Lo que el usuario recibe es lo que sirve el contenedor.
- Mitigación mínima: que «el servicio» registre el provider en un contenedor mínimo (o llame a `register()` con un
  fake de `app`) y afirme que el singleton es `strictEqual` a la salida de `buildRelationsManager` (o que tiene el
  prototipo exacto).

### 🟡C · El inventario no ve accessors de instancia ni objetos-namespace
- Escenario: el constructor de `RelationsManager` define `relateRaw` como GETTER de instancia (devuelve una función
  que llama a `driver.relate`) y `admin` como objeto con `{ relate }`. Ninguno tiene fila ⇒ **guardia VERDE**.
- Evidencia: ✅ repro 🟡C y un script aparte sobre una copia literal de `surfaceOperations`. Resultado:
  `[Symbol(x), relate, driver, static factory]`, sin `relateRaw` ni `admin`. En el spec, la línea 763 solo cuenta
  descriptores con `value` de tipo función. Un Proxy devuelto por el constructor tampoco se ve, y mantiene el
  prototipo exacto. Lo que pedías y SÍ resiste: campo arrow (también en subclase), estático (también getter
  estático), símbolo y getter en el PROTOTIPO, que aparece por nombre.
- Steelman: «nadie escribe así un método público». → Es cierto para el getter. El namespace (`manager.admin.x`) es un
  patrón real de API. Queda en 🟡.
- Mitigación mínima: contar también descriptores `get` y valores objeto no nulos (y, para estos, recorrer un nivel) en
  los propios de la instancia; hoy la superficie real no tiene ninguno, así que el cambio no da falsos rojos.

### 🟡D · 🟠1: fuera del árbol principal, la firma D6 = extracto + dos literales del spec (límite NO escrito)
- Escenario: sexta exención `D6-check-double` (quita la sonda F-05 de `double.check`). Para meterla hay que editar el
  extracto, `SIGNED_EXEMPTIONS`, `FIVE_SIGNED`, el `assert.lengthOf(extract, 5, …)` del caso «en local…» y re-apuntar
  el mutante `double.check.f05` hacia `double.relate.f05`. Con eso, **sin fichero de decisiones (CI, y también
  cualquier worktree) la guardia queda VERDE**; en el árbol principal es ROJA, y solo por el cruce `d6Violations`
  («en local, el extracto coincide…»).
- Respuestas a tus preguntas:
  - En LOCAL, ¿se puede cambiar una exención sin que falle el cruce? `d6Violations` (`:1200`) solo coteja la fecha,
    el fragmento `d6` como subcadena y el CONJUNTO de operaciones nombradas. **No coteja `layers` ni `column`**, porque
    el texto de D6 no nombra capas, salvo «de openfga». Ensanchar `layers` de una exención existente pasa en local.
    Hoy no es explotable: `enumerateRelations` ya cubre las 4 capas, el doble no tiene `enumerateRelationsMany`,
    `driver`/`capabilities` solo existen en el manager y `membersOf` está blindada por el caso fijo «SOLO de
    openfga». Lo será el día que el doble gane `enumerateRelationsMany`.
  - En CI, ¿qué impide que el extracto crezca? Nada, salvo la revisión del diff: `FIVE_SIGNED` y el `lengthOf(…, 5)`
    viven en el mismo spec que se edita. **Ese límite no está escrito** en el manifiesto, ni en CLAUDE.md, ni en el
    informe: el caso solo dice «en CI vale el extracto solo».
  - Agravante: los implementadores trabajan en worktrees (`../adonis-authz-loteR` existe) y ahí no hay
    `.claude/contexto` (verificado). El cruce local se salta EN SILENCIO justo donde se hacen los cambios; solo corre
    en `main`.
- Efecto colateral: la sonda de una exención no ejercita la operación exenta. `probeDouble`, ante cualquier
  `exempt`, sondea la lista blanca de `enumerateRelations`, y `probeManager` con `whitelist` hace lo mismo. Por eso
  `double.check` exenta con `probe: 'whitelist'` pasa sin invocar `check`.
- Evidencia: ✅ repro 🟡D (CI verde; local rojo solo en el cruce D6).
- Steelman: «cuatro ediciones coordinadas, una de ellas en el propio test, son un cambio deliberado que se ve en la
  PR». → Me convence en cuanto a la severidad (🟡, no 🟠). No me convence en cuanto a callar el límite: hay que
  escribirlo.
- Mitigación mínima: declarar el límite (que en CI y en worktrees la firma es el diff de tres ficheros versionados) y
  avisar con un `console.warn` visible, o con un rojo opt-in, cuando el fichero de decisiones falta fuera de CI
  (`!process.env.CI`). Opcional: que la sonda `whitelist` exija `op ∈ {enumerateRelations, enumerateRelationsMany}`.

### 🟡E · G-R clasifica «escritura» con una lista de nombres fija (`WRITES`) y solo cuenta las operaciones de `PORT_OPERATIONS`
- Escenario (❓ hipotético, lote D): `deny`/`removeDeny` entran en el puerto y en `PORT_OPERATIONS`, pero no en `WRITES`
  (`:72`). Una operación del manager que llama a `driver.deny` sin emitir evento cuenta como LECTURA en G-R. La fila
  `managerRead` le da `na: read` en trx/freeze/write/actor, y `NA_MATRIX` lo admite. Resultado: una escritura sin
  freeze, sin puerta trx y sin actor, con la guardia verde.
- Evidencia: 🟡 depende de cómo se implemente D. No lo reproduje porque hoy no hay ninguna escritura del puerto fuera
  de `WRITES`.
- Steelman: «cuando llegue D se añadirá a `WRITES`». → Es el mismo patrón de lista mantenida a mano que el cierre
  quería eliminar.
- Mitigación mínima: derivar `WRITES` de las filas `write` de las capas driver del manifiesto, o detectar la escritura
  por diferencia de estado del doble (`enumerateRelations` antes y después).

## Lo que intenté y NO se rompió
- `kind` inventado: con cualquier `na`, `NA_MATRIX` no lo admite ⇒ rojo; con todo `probe`, las sondas exigen las
  guardas reales (más estricto, no menos). TS tampoco lo deja pasar.
- Fila `probe` con sonda trivial SIN tocar INVOKE: `f05VariantsOf` y G-R exigen la entrada ⇒ rojo.
- Método en el driver y no en el manager: G-0 por capa + «todo método de los drivers se invoca» ⇒ rojo sin fila o
  sin INVOKE (con INVOKE enrutado vale lo dicho en 🟡A).
- Método solo en la vista `withClock` (database/openfga): `sameMembers(surfaceOperations(view), ops)` lo caza si es
  una propiedad de datos; como getter de instancia o como Proxy, no (es el mismo hueco que 🟡C).
- `platform`/`view`/`doctrine` fuera de su celda; `f05: na` en cualquier capa ⇒ rojo (caso invertido 🟠2 y
  `manifestViolations`).
- Exención usada en otra capa o columna, sexta exención CON fichero de decisiones, extracto ausente ⇒ rojo.
- Escritura nueva con INVOKE enrutado a `relate` ⇒ rojo por `events[0].operation`.
- Subclase o envoltorio devuelto por `buildRelationsManager` ⇒ rojo («el servicio» + `MANAGER_BUILDS`).

## Preguntas abiertas para el arquitecto
1. ¿Se acepta 🟡D como límite declarado (CI y worktrees = revisión del diff)? Si la respuesta es sí, hay que
   escribirlo; si es no, la firma necesita una fuente que no se edite en la misma PR.
2. ¿«El servicio» tiene que juzgar el singleton del contenedor (🟡B) o basta con `buildRelationsManager`? Cambia si el
   🟡6 original está cerrado del todo o solo en parte.
