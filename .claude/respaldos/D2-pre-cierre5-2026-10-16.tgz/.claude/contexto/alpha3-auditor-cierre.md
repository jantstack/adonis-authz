# `2.4.0-alpha.3` — AUDITOR, segunda pasada sobre el lote de CIERRE

Ataque al árbol de cierre (sin commitear) con **mis propias reproducciones**, re-ejecutadas contra
sqlite `:memory:` y contra el `:8101` real, más cinco frentes nuevos (los que pidió el coordinador).
Nada tocado fuera de `.claude/`.

**Escala** (equivalencia con la del encargo): CRÍTICO = 🔴 · ALTO = 🟠 · MEDIO = 🟡 · BAJO = ⚪.

**Reproducciones** (todas ejecutables, en `/home/jose/proyectos/Personal/adonis-authz/.claude/reproducciones/`):

| fichero | qué mide |
|---|---|
| `alpha3-auditor.ts` | los 12 casos de la primera pasada (sqlite) |
| `alpha3-f05-purge.ts` | el 🔴 1 / 🟠 2 contra el `:8101`, en el store COMPARTIDO |
| `alpha3-cierre-auditor.ts` | frentes 1-5 del cierre (sqlite + dobles) |
| `alpha3-cierre-openfga.ts` | los mismos contra el `:8101` (F-05 en las siete + `manager.driver()`) |
| `alpha3-cierre-parcial.ts` | `markPartialWrite` con una purga REAL que muere tras borrar |

**Sanidad del árbol:** `OPENFGA_TEST_URL=http://localhost:8101 npm test` ⇒ **1133/1133**, cero ✖
(alpha.2 = 1074, alpha.3 pre-cierre = 1107).

---

## 1 · Lo que rompí antes y ya NO se rompe (verificado con MIS repros)

| hallazgo previo | estado | evidencia |
|---|---|---|
| **🔴 1** F-05 no cubría `purgeObject` | **CERRADO** | `alpha3-f05-purge.ts` contra el `:8101`: `purgeObject(role_binding) ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422`, `authorize` **sigue** `true`, el binding conserva sus tuplas. Y `alpha3-cierre-openfga.ts` O3: las cinco rutas 422 **y también por `manager.driver()`** (el driver re-valida) |
| **🟠 2** fuga por `listSubjects` | **CERRADO** | mismo fichero: `listSubjects(assignee, role_binding) ⇒ 422`; `check`/`listObjects`/`purgeSubject`-userset, igual |
| **🟠 3** `assertWrite` que devuelve `false` | **CERRADO** | A1: `error=E_AUTHZ_CONFIG ESCRITURA ENTRÓ=false` (antes: `ENTRÓ=true`) |
| **🟡 4** thenable-FUNCIÓN | **CERRADO** | A2: `error=E_AUTHZ_CONFIG ENTRÓ=false` (antes: `ENTRÓ=true`) |
| **🟡 6** purga parcial sin evento | **CERRADO en el driver real** | `alpha3-cierre-parcial.ts` C (falla la lectura de RESIDUO, tras un `deleteTuples` real): `partialWrite=true`, `indeterminate=true`, `tuplas que quedan=0`. Control A (purga normal) y B (falla antes de borrar) se distinguen. El caso publicado del paquete es honesto: usa `ECONNRESET` y **afirma** `E_AUTHZ_BACKEND_UNAVAILABLE` (no timeout) + un CONTROL de «murió antes de borrar ⇒ cero eventos» |
| **⚪ 7** `purgeSubject` sin validar sujeto | **CERRADO** | D1/D2/D3: `E_AUTHZ_INVALID_IDENTITY` / `E_AUTHZ_RELATION_TYPE_UNKNOWN`, **0 eventos** (antes: 1 evento con el sujeto envenenado) |
| **⚪ 8** aliasing del evento | **CERRADO en identidad** | 5a/5b/5c/5e: `object.id`, `partition.uuid`, `actor.uuid` y `expiresAt` son COPIA; 5f: un sink hostil que muta `event.object.id` deja el objeto del llamante **intacto** |
| **⚪ 10/12** `actor: null`, anulación de `requireActor` | **DOCUMENTADOS** | `CHANGELOG.md:77` (BREAKING) y `:159` |
| **⚪ 11** invariante 13 sin runner | **DECLARADO** | `CLAUDE.md` invariante 13 lo dice ahora con todas las letras y lo difiere a 2.6+ |
| **🟡 5** hook sin deadline | **DECISIÓN, no cierre** | sigue reproducible (B: `relate NO volvió` a los 1500 ms con la tupla ya escrita); la decisión (paridad con roles) está tomada y la frase publicada. **No lo reabro** |

Respuestas directas a las preguntas (4) y (5) del coordinador:

- **(4) El `indeterminate` parcial NO esconde ni cambia el 503.** Caso 4a: el error propagado es **el mismo
  objeto** (`r.e === original`), conserva `code`/`status` (`E_AUTHZ_PURGE_INCOMPLETE` 500), y `partialWrite`
  es **no enumerable** (no se cuela en `JSON.stringify(error)`). Caso 4b: un hook que lanza SOBRE el evento
  parcial tampoco lo esconde (se propaga el 500 y el fallo del sink se registra).
- **(5) La copia cierra el aliasing de identidad**, con **un residuo de un nivel**: 5d, `actor.session.ip`
  mutado después sí se ve en el evento (`#copyEvent` es un spread por nivel). Es coherente con lo decidido
  («el `actor` conserva los campos de más, se documenta, no se poda»), así que lo dejo en ⚪.

---

## 2 · Hallazgos NUEVOS del cierre

### [ALTO 1] REGRESIÓN: la `relation` opcional abrió F-05 en `relate`/`unrelate` — un `relation: undefined` ya no es 422, y sale como 503

- **Escenario:** un controlador hace `authz.relations.relate(subject, request.input('relation'), object, partition)`
  y el campo **falta** ⇒ `relation === undefined`.
  - **HEAD (alpha.2/alpha.3 pre-cierre):** `assertRelationDeclared` hacía
    `if (!config.isDeclared(object.type, relation)) throw RelationUnknownError` y `isDeclared('document', undefined)`
    es `false` (**medido**, `scratchpad/isdec.ts`) ⇒ **422 `E_AUTHZ_RELATION_UNKNOWN`, cero llamadas al backend**.
  - **Con el cierre:** `define_relations_config.ts` añade `if (relation === undefined) return` **antes** de la
    comprobación del par, y esa rama la comparten las SIETE operaciones. `relate`/`unrelate` pasan la barrera.
- **Resultado medido:**
  - `:8101` (`alpha3-cierre-openfga.ts` O1a): `relate(U, undefined, DOC, P) ⇒ **E_AUTHZ_BACKEND_UNAVAILABLE 503**`
    (la pregunta inválida llega al servidor y vuelve como caída del backend). Igual `check` (O1c) y
    `listObjects` (O1d): **503 donde antes había 422 o un `false`**.
  - dobles (`alpha3-cierre-auditor.ts` 2e/2f/2g): `relate`, `unrelate` y el userset de `purgeSubject` con
    `relation: undefined` **no lanzan nada**; el doble publicado escribe la tupla.
  - `database`: lo salva el driver (`#assertId` ⇒ 422), así que **los dos drivers responden distinto a la misma
    entrada** (paridad rota).
- **Por qué es ALTO y no BAJO:** (i) es un **fail-open reproducido en la barrera que este lote estaba
  ensanchando** — F-05 es la frontera del 🔴 del panel `{trx}` y el manager deja de aplicarla en `relate`;
  (ii) viola el invariante 5 en su punto exacto: *pregunta inválida ⇒ 422*, *backend no responde ⇒ 503*;
  convertir lo primero en lo segundo es lo que el invariante prohíbe (y además despierta a la guardia por una
  petición mal formada); (iii) lo introduce este lote.
- **Por qué NO es CRÍTICO, dicho igual de claro:** con `relation: undefined` **no se compone nada peligroso**
  (el TIPO se sigue validando, así que no hay `role_binding` ni cruce de puerto) y **ninguna tupla aterriza**
  en los drivers del paquete (FGA responde 400, `database` 422). El daño real hoy es clasificación + paridad +
  una barrera que dejó de cortar.
- **Steelman del defensor:** «`relation` es `string` en la firma; pasar `undefined` es saltarse los tipos, y el
  backend lo rechaza igual». → **No me convence**: exactamente el mismo argumento valía para `assertWrite: (ref) => false`
  (que también «se salta los tipos» y que este lote cerró con un 500 ruidoso), y para el `actor` mal formado de
  H3. `request.input('x')` devuelve `undefined` sin ningún cast. Y aunque se aceptara el argumento, el 503 en
  lugar del 422 hay que arreglarlo igual.
- **Corrección mínima (una línea, sin tocar las siete llamadas):** que la rama corta no dependa de `undefined`
  sino del CALL-SITE. P. ej. `assertRelationDeclared(config, object, relation?, { typeOnly }: …)`, o partir en
  `assertObjectTypeDeclared(config, object)` (purgas y `listObjects`) + `assertRelationDeclared(config, object, relation: string)`
  (las que sí nombran relación), de modo que `undefined` en `relate`/`unrelate`/`check`/`listSubjects` vuelva a
  ser 422.

### [MEDIO 2] `listSubjects` sin relación enumera la UNIÓN de todas las relaciones del objeto

- **Escenario:** `listSubjects(request.input('relation'), object, partition)` con el campo ausente. Precondición:
  `doc` tiene `U` como `viewer` y `V` como `owner`.
- **Resultado medido contra el `:8101`** (`alpha3-cierre-openfga.ts` O1b): devuelve **los dos** holders —el
  `Read` sale sin filtro de relación—, sin error. Un panel de «quién tiene la relación X» pasa a listar a
  todo el mundo. Es el invariante 7 («hechos DIRECTOS vigentes» de la relación preguntada) ensanchado por un
  campo que falta. Misma raíz que el ALTO 1.
- **Alcance:** dentro del MISMO objeto y la MISMA partición ⇒ **no cruza tenants**; por eso MEDIO y no ALTO.
- **Steelman:** «pre-existente: antes de este lote `listSubjects` no tenía F-05 en absoluto». → Cierto y lo
  digo: **no es regresión**. Pero el barrido que se acaba de hacer es justo el momento de cerrarlo, y la
  corrección es la misma línea del ALTO 1.

### [MEDIO 3] `membersOf` es la operación que se quedó fuera de «las SIETE»

- **Escenario:** `membersOf({ type: 'role_binding', id: R }, 'assignee', partition)` y
  `membersOf(doc, 'relacion-no-declarada', partition)`.
- **Resultado medido** (`alpha3-cierre-auditor.ts` 1a/1b, con el doble PUBLICADO `makeRelationsDriver`, que
  declara `membersOfNative: true`): **ninguno de los dos lanza**; devuelven `{"subjects":[]}`. Ni el manager
  (`manager.ts:504-526`, solo `assertScope`) ni el driver `database` (`database_relations_driver.ts:680-688`,
  solo `#assertObject`) aplican F-05. `enumerateRelations` sí está bien (1c: filtra por tipos declarados y por
  partición, `openfga_relations_driver.ts:585-610`) y `reconcileRelations` entra por ahí.
- **Por qué no es ALTO hoy:** en `openfga` `membersOf` es 500 `E_AUTHZ_UNSUPPORTED` **antes** del driver
  (medido, O1e), y en `database` la tabla es propia ⇒ **cero alcance cruzado hoy**.
- **Por qué sí es un hallazgo:** el doble publicado y **cualquier driver de terceros que declare
  `membersOfNative: true` sobre un store compartido reabre el 🟠 2 tal cual** — `membersOf` toma
  `(object, relation)`, que es exactamente la forma que F-05 guarda. Y la letra publicada dice «las SIETE
  operaciones del puerto» cuando el puerto tiene ocho con objeto+relación.
- **Corrección mínima:** `this.#assertDeclared(object, relation)` en `RelationsManager.membersOf` y
  `assertRelationDeclared` en `DatabaseRelationsDriver.membersOf`; y «siete» → «ocho» en los docblocks.

### [BAJO 4] `markPartialWrite` lanza `TypeError` sobre un error no extensible, y ahí SUSTITUIRÍA al 503 original

- **Escenario:** `markPartialWrite(Object.freeze(new Error(...)))`.
- **Resultado medido** (3a): `LANZA TypeError: Cannot define property partialWrite, object is not extensible`.
  En `#partialIfDeleted` (`openfga_relations_driver.ts`) ese `TypeError` **reemplazaría** al 503/500 real y
  saldría al llamante sin `code` ni `status`, justo en el camino de una purga que ya borró.
- **Alcance:** hipotético — ninguna de las clases de error del paquete se congela; haría falta un SDK o una
  capa intermedia que congele sus errores. Por eso BAJO, pero la corrección es un `try/catch` de tres líneas
  dentro de `markPartialWrite` (devolver el error sin marcar es peor que perderlo).

### [BAJO 5] `isTimeoutLike` DUPLICADO en el driver de relaciones, y por substring del mensaje

- **Hallazgo:** `openfga_relations_driver.ts:799` define su propio `isTimeoutLike` que clasifica como TIMEOUT
  cualquier error **cuyo mensaje contenga la palabra «timeout»** (`/timeout/i.test(current.message)`), y su
  docblock dice *«mismo criterio que el driver de roles»* — **falso**: el driver de roles importa el estricto
  de `src/shared/backend_guard.ts:104` (`KnexTimeoutError`, `typeof .timeout === 'number'`,
  `ECONNABORTED`/`ETIMEDOUT`), sin mirar el mensaje.
- **Resultado medido** (`alpha3-cierre-parcial.ts` caso B): un error lanzado **ANTES de borrar nada** cuyo
  mensaje contiene la palabra ⇒ `E_AUTHZ_BACKEND_TIMEOUT` y `indeterminate: true` con **`tuplas que quedan=2`**
  (no se borró nada). La frase publicada dice que ese caso «no emite nada». Un 400 de validación de FGA o el
  cuerpo de un 502 de proxy que mencionen «timeout» caen aquí.
- **Dirección segura** (sobre-reporta «puede haber ocurrido»), pre-existente, y el caso propio del paquete
  para el 🟡 6 **no depende de esto** (usa `ECONNRESET` y afirma el código no-timeout). Por eso BAJO. Aun así:
  el mensaje al operador («el backend no respondió en 5000 ms») miente sobre un error que sí respondió.
- **Corrección mínima:** importar el `isTimeoutLike` de `backend_guard.ts` (o borrar la rama del mensaje) y
  quitar el docblock que afirma paridad.

### [BAJO 6] `markPartialWrite` es deber SOLO del driver, y eso sigue sin juez (respuesta a la pregunta 3)

- **No es falsificable por el CONSUMIDOR:** 3d ⇒ un `assertWrite` que lanza un error **marcado** corre ANTES
  de `#write`, así que da **0 eventos**. Bien.
- **Sí es falsificable por el DRIVER**, en los dos sentidos y los dos medidos:
  - un driver de terceros que **borra 3 tuplas y no marca** ⇒ `EVENTOS=0` (3b), o sea el 🟡 6 intacto para él;
  - un driver que **marca sin haber borrado** ⇒ evento `indeterminate: true` fabricado (3c).
- **El deber está escrito** (`errors.ts`, `CLAUDE.md` invariante 13: *«un driver de terceros con purga
  multi-request tiene el mismo deber»*) y la ausencia de juez está **declarada** y diferida a 2.6+. Es honesto;
  lo dejo en ⚪ y solo lo registro para que nadie lo lea como garantía verificada.

### [BAJO 7] Las LECTURAS pasaron de responder a lanzar, y eso no está en la lista de BREAKING

- `check`/`listSubjects` sobre un tipo DECLARADO con una relación **no declarada** son ahora 422
  `E_AUTHZ_RELATION_UNKNOWN` (2d, medido) donde antes había un `false`/lista vacía. Es fail-closed y encaja
  con el invariante 5 («pregunta inválida ⇒ 422»), pero es un cambio de comportamiento del camino de LECTURA
  para cualquier consumidor con un `if (await check(...))` sin `try`. El CHANGELOG anuncia como BREAKING el
  `requireActor` de las purgas y el `actor: null`, y no esto.
- **Corrección mínima:** una viñeta más en la lista de BREAKING.

---

## 3 · Lo que intenté y NO se rompió (en el cierre)

- **F-05 por las cinco rutas nuevas Y por `manager.driver()`**: 422 en todas, contra el `:8101` y con el
  espía de tuplas intacto (`O3`). La defensa en profundidad (manager + los dos drivers) está.
- **`assertWrite`**: no encontré ninguna forma de que un retorno se cuele — probé `false`, thenable-función,
  `async`. La condición `result === undefined` no deja huecos.
- **`markPartialWrite` desde el consumidor**: imposible por `assertWrite` (corre antes de `#write`).
- **El 503/500 bajo `indeterminate` parcial**: intacto en clase, `code`, `status` e identidad de objeto, y
  `partialWrite` no enumerable (no ensucia un `JSON.stringify` del error en un log).
- **Un hook que lanza** sobre el evento parcial o sobre el de timeout: no esconde el error original ni cambia
  su código; el fallo del sink se registra.
- **Aliasing**: un sink hostil ya no puede mutar el objeto del llamante.
- **`enumerateRelations`**: filtra por tipos declarados y por partición; no es una ruta de fuga.
- **Suite entera con el `:8101`**: 1133/1133.

---

## 4 · Veredicto

**NO APTA para publicar como `2.4.0-alpha.3`.**

El cierre resuelve **de verdad** el CRÍTICO y los dos ALTOS de la primera pasada —lo comprobé con mis propias
reproducciones, contra el servidor real y por las dos puertas (manager y `manager.driver()`)—, y los casos que
lo sujetan son honestos (el del 🟡 6 afirma el código NO-timeout y trae su control). El trabajo está bien hecho.

Lo que lo deja fuera es la **regresión ALTO 1**, que por la regla de parada del paquete («solo 🔴/🟠 reabren el
lote») basta por sí sola: el ensanchamiento de F-05 se hizo haciendo `relation` opcional, y esa opcionalidad
apagó la comprobación en `relate`/`unrelate`, que es donde F-05 nació. No es explotable hoy —no compone un
`role_binding` y ninguna tupla aterriza—, pero es un fail-open reproducido en la barrera y un 422 convertido
en 503, y se arregla separando «solo el tipo» (un call-site) de «el par» (el otro) en vez de deducirlo de
`undefined`. Con esa línea caen también el MEDIO 2 y, con una llamada más, el MEDIO 3.

Si el dueño prefiere publicar y arreglar en un `alpha.4`, la decisión es suya y está informada: el riesgo
efectivo del ALTO 1 es de clasificación y de paridad entre drivers, no de escalada. Mi veredicto, con la regla
escrita, es **NO APTA**; lo publicable es el mismo lote con la comprobación del par restituida.
