# Fase 3 · Lote 3E — verificación del tester de contrato (solo el delta)

> Sobre `5b4f3c2` (worktree aislado, `git checkout --detach`), Node 22.23.2, `npm ci`.
> Motores reales: OpenFGA `:8101`, PostgreSQL 18 (`postgres18`), MySQL 8.4 (`mysql84`), y un
> OpenFGA efímero con tope 3 en `:8123` (`openfga-tiny-t3e`, **eliminado**; puerto libre para no
> pisar a nadie). Verificación **acotada al diff `56094ac..5b4f3c2`**; lo del 3D no se repite
> (informe en `fase-3-verificacion-tester-3d.md`).

---

## 1. Suites — medidas, no citadas

| Comando | Declarado 3E | Medido | ¿Coincide? |
|---|---|---|---|
| `OPENFGA_TEST_URL=:8101 npm test` | 510 | **510 passed** (17 s) | ✅ |
| `OPENFGA_TEST_URL=:8101 npm run test:sqlite-file` | 512 | **512 passed** (17 s) | ✅ |
| `TEST_PG_URL=… OPENFGA_TEST_URL=:8101 npm run test:pg` | 677 | **677 passed** (51 s) | ✅ |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` | 677 | **677 passed** (56 s) | ✅ |
| Tope 3 (`:8123`, `LIST_OBJECTS/USERS_MAX_RESULTS=3`) | 510 | **510 passed** (14 s) | ✅ |
| `npm run build` (purity + typecheck + tsc + stubs) | ✅ | **exit 0** | ✅ |

**Residuos: 0.** Antes de tocar nada ya existía en PG una base `authz_test_3beaf8e3` (de otra
sesión, no mía); tras mis 12 ejecuciones de PG/MySQL sigue siendo la única, MySQL no tiene ninguna
`authz%`, `/tmp` sin ficheros sqlite y `docker ps -a | grep tiny` = 0. **La base `authz_test_3beaf8e3`
es basura preexistente que conviene borrar** (`DROP DATABASE authz_test_3beaf8e3`): no es mía y no
la toco.

Con el parche del tester aplicado (§5): 510 / 512 / 677 / 677 / 510 y `typecheck` limpio, los mismos
números — el parche **no añade casos**, solo aserciones dentro de tres casos existentes.

---

## 2. Un mutante por pieza — pieza × mutante × motor × resultado

Método: sustitución textual en `src/`, suite completa, restauración desde copia limpia. `sqlite`
cubre 4 harness del juez (`database`, `database (sin listDenies)`, `openfga`, `openfga (árbol SQL)`);
`pg`/`mysql` añaden `database (árbol SQL)`.

| # | Pieza | Mutante | Motor | Resultado | Fallo literal |
|---|---|---|---|---|---|
| 1 | **P1a** | `above` siempre `undefined` (quita el rechazo de nivel-ancestro) | sqlite | 🟢 **muerto** (509/1) | `AssertionError: expected 'defineScopedRole: un rol local de niv…' to include 'POR ENCIMA de su owner'` |
| 2 | **P1a** | el rechazo de ancestro **solo con `descendantsOf`** (el hueco «sin `descendantsOf`») | sqlite | 🟢 **muerto** | `AssertionError: debería haber rechazado` (rama `sinMina`, manager sin `descendantsOf`) |
| 3 | **P1a** | quita el endurecimiento contra el árbol de hoy (`below.some(...)`) | sqlite | 🟢 **muerto** | `AssertionError: debería haber rechazado` (`fantasma@team`) |
| 4 | **P1a** | `updateScopedRole` deja de revalidar el nivel | sqlite | 🟢 **muerto** | `AssertionError: debería haber rechazado` (el rol heredado escrito a mano) |
| 5 | **P1b** | el sync **vuelve a abortar** por colisión con un local | sqlite | 🟢 **muerto** (508/2) | `CatalogConflictError: El rol lead@unit del spec colisiona con un rol LOCAL del mismo nombre.` — en `catálogo/B6` **y** en el caso de colisiones del manager |
| 6 | **P1b** | no aborta pero **tampoco reporta** `shadowedByGlobal` (silencio) | sqlite | 🟢 **muerto** (508/2) | `expected [] to deeply equal [ 'lead@unit:organization\|org-a' ]` |
| 7 | **P2** | la purga de roles vuelve a la **clave cruda** (`child` en vez de `purged`) | sqlite | 🟢 **muerto** | `el alias ya no deja vivo el rol del owner: expected { …(5) } to equal null` |
| 8 | **P2** | vuelve a leer del **memo** (`view()` + `rolesOwnedBy`) | sqlite | 🟢 **muerto** | `la purga lee la base, no la foto: expected { …(5) } to equal null` |
| 9 | **P2** | deja de bajar por **`descendantsOf`** | sqlite | 🟢 **muerto** (506/4) | `ni el del descendiente (descendantsOf declarado)` + **el juez**: `ni la del rol de un descendiente del scope notificado` en `database` y `database (sin listDenies)` |
| 10 | **P3** | quita el rango en `detached` | sqlite | 🟢 **muerto** | `AssertionError: debería haber rechazado` |
| 11 | **P3** | el rango se comprueba **rol a rol** (orden natural) | sqlite | 🔴 **VIVO** (510) → 🟢 **muerto con parche** | con parche: `tampoco el que el actor SÍ podría tumbar: o se purgan todos o ninguno: expected null to not equal null` |
| 12 | **P3** | rol a rol y **de menor a mayor rank** (purga a medias de verdad) | sqlite | 🔴 **VIVO** (510) → 🟢 **muerto con parche** | ídem |
| 13 | **P4** | `defineScopedRole` **no** comprueba la capacidad `purgeRole` | sqlite | 🟢 **muerto** | `AssertionError: debería haber rechazado` — en `openfga · 2.2 / sin purgeRole: el puerto NO lo trae …` |
| 14 | **P5** | el diff vuelve a `parseAssignableAt` | sqlite | 🟢 **muerto** (507/3) | `AuthorizationInternalError: authz_permissions.assignable_at del permiso 'docs:read' no es una lista JSON no vacía…` (y arrastra los casos de P6 y N3) |
| 15 | **P6** | el sync no revalida los roles vivos (`limited = []`) | sqlite | 🟢 **muerto** | `expected [] to deeply equal [ …(2) ]` |
| 16 | **R1** | `resolveRoleQuery` sin owner (grant por `{uuid}`) | sqlite | 🟢 **muerto** (507/3) | `debería haber rechazado` en `database`, `database (sin listDenies)` y `openfga` |
| 17 | **R1** | `visibleRoleFor` sin owner (`listSubjects`) | sqlite | 🟢 **muerto** (507/3) | `expected [ { type: 'users', …(1) } ] to deeply equal []` ×3 harness |
| 18 | **R1** | `hasRoleTargets` sin owner (`hasRole`) | sqlite | 🟢 **muerto** (507/3) | `expected true to be false` ×3 harness |
| 19 | **R2** | la colisión **juzgable** de la transacción devuelve 503 | pg | 🟢 **muerto** (676/1) | `el perdedor choca, no se cae: E_AUTHZ_BACKEND …: expected 503 to equal 422` (solo `database (árbol SQL)`) |
| 19b | **R2** | ídem | mysql | 🟢 **muerto** (676/1) | idéntico; y **reproducido 2 veces en PG**, estable |
| 20 | **R2** | **todo** el bloque de colisión transaccional devuelve 503 | pg | 🟢 **muerto** (675/2) | mismo literal, ahora en `database` **y** `database (árbol SQL)` |
| 21 | **R2** | sin **re-chequeo** dentro de la transacción | pg | 🟢 **muerto** (674/3) | `exactamente un ganador (["ok","ok"]): … to have a length of 1 but got 2` (+ la carrera R5 del manager) |
| 21b | **R2** | ídem, **con la carrera neutralizada** (medición) | pg | 🟢 **muerto** (674/3) | `debería haber rechazado` en `contract.ts:3277` = la línea `insertRoleUnseen` → `sigiloso`. **La parte en serie SÍ ejercita el re-chequeo.** |
| 22 | **R3** | `#rolesFromSlugs` vuelve a `catalog.roleVisible` (que lanza) | sqlite | 🟢 **muerto** | `AmbiguousRoleError: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles…` |
| 23 | **R7** | `purgeRole` **olvida los vínculos** | sqlite | 🔴 **VIVO** (510) | — |
| 23b | **R7** | ídem | pg | 🔴 **VIVO** (677) | — |
| 23c | **R7** | ídem | mysql | 🔴 **VIVO** (677) | — |
| 24 | **R7** | `purgeRole` olvida las **asignaciones** | pg | 🟢 muerto (669/8) | `AuthorizationBackendError: … no respondió (purgeRole.role.delete)` — **el oráculo sigue siendo el FK RESTRICT del motor, no la aserción** |
| 25 | **Q1** | el mensaje vuelve a aconsejar «renombra uno de ellos» | sqlite | 🔴 **VIVO** (510) → 🟢 **muerto con parche** | con parche: `… to not include 'renombra uno de ellos'` |
| 26 | **Q2** | `ROLE_NOT_VISIBLE` por slug vuelve a nombrar los owners ajenos | sqlite | 🔴 **VIVO** (510) → 🟢 **muerto con parche** | con parche: `el 422 no regala la clave de scope del otro tenant` |
| 27 | **Q2** | la ruta `{uuid}` vuelve a devolver slug+owner de un rol AJENO | sqlite | 🔴 **VIVO** (510) → 🟢 **muerto con parche** | con parche: `el uuid de un rol ajeno no revela su owner` |
| 28 | **Q5** | `isSqliteDialect` deja de reconocer `better-sqlite3` | sqlite | 🟢 **muerto** | `SQLite serializa por sí solo: ni cerrojo ni consulta de más: expected [ Array(1) ] to deeply equal []` |
| 29 | **Q7** | el evento deja de llevar los roles resueltos | sqlite | 🟢 **muerto** | `expected undefined to deeply equal [ { …(4) } ]` (B7) |
| 30 | **Q7** | el `revoke` por slug notifica **uno** de los homónimos, no todos | sqlite | 🔴 **VIVO** (510) | — |
| 31 | **Q7** | `#resolvedRoles` deja de comprobar el owner por `{uuid}` | sqlite | 🔴 **VIVO** (510) | — |

**Respuesta directa a las preguntas del encargo:**

- **P1a con y sin `descendantsOf`**: sí, las dos mitades tienen mutante muerto (filas 1–3). El caso
  las separa a propósito con dos managers (`localManager()` con `descendantsOf` y `sinArbol` sin él)
  y distingue el 422 correcto del 422 «por la otra razón» comparando el TEXTO
  (`include(mina.message, 'POR ENCIMA de su owner')`), que es lo que mata la fila 1.
- **P1b, las dos caras**: abortar ⇒ muerto; no reportar ⇒ muerto (filas 5–6).
- **P2, los tres agujeros**: muertos por separado (filas 7–9), y el de `descendantsOf` además **por
  el juez** en dos harness, no solo por el unitario.
- **P3**: el rango ⇒ muerto; **el «nada a medias» NO estaba observado** (filas 11–12) — cerrado por
  el parche.
- **P4 y el `whenFalse` reescrito**: el caso lo caza (fila 13) **y demuestra la salida**: el tramo (4)
  borra la fila del rol con `forgetRoleByHand` y hace `scopes.detached` con normalidad, afirmando
  `listRoles = []` y `authorize = false`. El caso viejo fijaba el callejón; el nuevo lo desmonta.
- **P5**: muerto (fila 14).
- **P6**: muerto (fila 15).
- **R1, los tres mutantes de owner por `{uuid}`**: **mueren ahora**, cada uno en tres harness
  (filas 16–18). Era el 🔴 del 3D y está cerrado.
- **R2, el 503 y la parte en serie**: el 503 muere (filas 19–20) **con un matiz importante** (§4.2);
  y la parte en serie **sí** ejercita el re-chequeo transaccional, medido aislando la carrera (21b).
- **R3**: muerto (fila 22) — `effectivePermissions` devuelve lista, no 422.
- **R7 (`purgeRole` que olvida vínculos)**: **NO muere**, ni en PG ni en MySQL ni en SQLite (filas
  23a–c). Detalle en §4.1.

---

## 3. El juez: conteos, anidamiento y asimetría

Medido **ejecutando** el registro del juez con las capacidades REALES de `tests/contract.spec.ts`
(sonda temporal en `tests/`, borrada después; el harness ya ejecuta `register(...)`, pero quería el
número contra los harness de producción, no contra `NONE`):

```
[SONDA] motor=sqlite database=83  sinDenies=75  openfga=79
        duplicados(database)=0    duplicados(openfga)=0
```

Con `injectableClock: true` (que es lo real) esos números son los literales del harness **+4**:

| Combinación | Literal en `contract_harness.spec.ts` | Sonda (con reloj) | ✔ |
|---|---|---|---|
| `'2.2'`, `listDenies:true`, `purgeRole:false` | **75** | 79 | ✅ |
| ídem con `purgeRole:true` | **79** (`scoped + 4`) | 83 | ✅ |
| ídem con reloj | **79** | — | ✅ |
| sin `listDenies` | **70** | 75 (con purgeRole+reloj) | ✅ |

- **Anidamiento**: el harness lo afirma ejecutando (`for (const title of primitives) assert.include(scoped, title)`,
  y la cadena core ⊂ 2.0 ⊂ 2.1). La sonda confirma además **0 títulos duplicados** en los dos
  harness reales: los conteos no se están cuadrando con repeticiones.
- **El par `purgeRole` sigue siendo asimétrico y correcto**: la cara `false` aporta **1** caso
  (`sin purgeRole: el puerto NO lo trae…`) y la cara `true` aporta **5**:
  `purgeRole(uuid) revoca…`, `scopes.detached purga también…`, `defineScopedRole:…`,
  `dos defineScopedRole del MISMO (slug, nivel)…` y `effectivePermissions es EXACTAMENTE…`.
  Neto **+4**, que es exactamente lo que afirma `assert.lengthOf(withPurge, scoped.length + 4)`.
  La asimetría está **razonada** (P4: a un driver que no sabe purgar no se le juzga una policy de
  delegación que no puede tener) y no es un skip: la cara `false` juzga el 500 antes de escribir Y
  la salida del callejón.
- **`serializedCatalogWrites`** es un par exacto (`assert.lengthOf(estricto, laxo.length)`) y su
  `true` sin caso que lo observe se rechaza en dos combinaciones. Bien construido.
- Detalle menor: `README.md:278` dice «a driver … can pass **78 of 79** cases». Es coherente con el
  harness de `purgeRole: true` (79), pero conviene releerlo si los conteos vuelven a moverse.

---

## 4. Huecos

### 4.1 🟠 R7: el «todo o nada» de `purgeRole` **sigue sin oráculo** — la promesa nueva no se cerró

El informe 3E dice: *«El conteo de vínculos se afirma por el catálogo SQL (`linksOf`), no por el
`CASCADE` del esquema»*. La aserción existe (`assert.equal(await linksOf(lead), 0, …)`), pero
**no cambia nada**: el mutante que borra la línea

```ts
await this.sql('purgeRole.links', () => trx.from('authz_role_permissions').where('role_uuid', roleUuid).delete())
```

pasa la suite **entera** en SQLite (510), PostgreSQL (677) y MySQL (677). Motivo medido: el espejo y
el stub declaran `authz_role_permissions.role_uuid … onDelete('CASCADE')`
(`tests/helpers/schema.ts:246`), así que el motor borra los vínculos igual y `linksOf` devuelve 0 en
los dos mundos. **Es un mutante equivalente bajo este esquema**, exactamente lo mismo que reporté en
3D §5.3: el garante sigue siendo el esquema, no el código.

Lo mismo con las **asignaciones**: el mutante muere, pero por el `RESTRICT` del motor
(`AuthorizationBackendError … purgeRole.role.delete`, 503), no por la aserción del puerto.

Consecuencia real: un consumidor con esquema propio sin esas acciones, o con FKs desactivadas,
tendría un `purgeRole` que deja vínculos huérfanos y **ningún test del paquete lo detectaría**.

**No lo parcheo** porque cerrarlo de verdad exige infraestructura nueva (correr el caso con
`PRAGMA foreign_keys=OFF` / FKs desactivadas, o espiar el SQL emitido), y eso es una decisión de
diseño de la suite, no una aserción más. Lo que **sí** pido: que el CHANGELOG deje de decir que el
conteo por el puerto sustituye al CASCADE, y diga lo que es verdad — *el «todo o nada» de
`purgeRole` está garantizado por el ESQUEMA (`CASCADE`/`RESTRICT`), vigilado por K11, y el conteo de
`linksOf` documenta la promesa sin poder falsarla*.

### 4.2 🟡 R2: el 503 muere por la CARRERA, no por el caso determinista

Medido con dos mutantes distintos:

- Si el 503 sustituye a **todo** el bloque de colisión transaccional (incluida la rama juzgable),
  muere en los dos harness estrictos, de forma determinista.
- Si el 503 sustituye **solo** al `throw new CatalogConflictError('El catálogo cambió mientras se
  validaba…')` — la rama del homónimo que **no** se puede juzgar dentro de la transacción —, muere
  **solo en `database (árbol SQL)`**, y con la carrera neutralizada **no muere en absoluto** (677
  passed).

Es decir: la parte determinista del caso (`insertRoleUnseen` → `sigiloso`) ejercita el re-chequeo,
pero llega al 422 por `#assertNoRoleCollision(..., 'sin-árbol')`, no por ese `throw` genérico. Ese
`throw` **solo lo observa la carrera**, y solo en el harness cuyo árbol SQL ensancha la ventana.
Es reproducible (3 ejecuciones, PG y MySQL), pero es un oráculo que depende del scheduler.

**Propuesta barata** (no parcheada, para no arriesgar un flake que no puedo medir en CI): en la
parte en serie, insertar con `insertRoleUnseen` un homónimo cuyo owner **no** sea ancestro-o-igual
del owner pedido (p. ej. un slug que ya existe en una unit hermana): ese caso entra por la rama
genérica y hace determinista el «422, no 503».

### 4.3 🟡 P3 «nada a medias» dependía del ORDEN — cerrado a medias por el parche

`readRolesOwnedBy` (`catalog_cache.ts:323`) **no lleva `ORDER BY`**: el orden en que se recorren los
roles a purgar es el del motor. Antes del parche, el único rol distinto de `caro` que había en el
owner era `chico` con rank 5 = el rank del actor, así que **tampoco era purgable** y «nada a medias»
no se ejercitaba nunca. El parche añade `barato` (rank 2, definido **antes** que `caro`), y con él
mueren los dos mutantes de comprobación rol-a-rol (orden natural y orden ascendente por rank).
**Queda vivo** un mutante que recorriera los roles en orden **descendente por rank**: con `caro`
primero, cualquier implementación rol-a-rol se detiene antes de tocar nada. Es una variante menos
plausible, pero conviene saber que el caso apoya en el orden de la BD.

### 4.4 🟠 Q1 y Q2 no tenían juez — cerrado por el parche

Tres mutantes vivos antes del parche, los tres sobre promesas **nuevas de 3E**:

- **Q1**: devolver el consejo imposible «renombra uno de ellos» al mensaje de `AMBIGUOUS_ROLE`.
- **Q2 (slug)**: que `ROLE_NOT_VISIBLE` vuelva a listar los `owner_scope_key` de roles de otro árbol.
- **Q2 (uuid)**: que la ruta `{uuid}` vuelva a devolver **slug y owner** de un rol ajeno — la sonda
  de catálogo que el propio informe 3E describe («pruebo uuids y aprendo el catálogo de otro
  tenant»).

Q2 es una promesa de **seguridad**: un 422 es lo que un framework Adonis devuelve tal cual al
cliente. Que la implementación esté bien y nadie lo observe es exactamente el patrón que ya costó el
🔴 del 3D. Cerrado con el parche (§5).

### 4.5 🟡 Q7: dos mitades sin juez (bajo riesgo)

- El mutante «el `revoke` por slug notifica **uno** de los homónimos en vez de todos» sobrevive: el
  caso B7 fija la forma del evento, pero no la pluralidad que el informe justifica.
- El mutante «`#resolvedRoles` deja de comprobar el owner por `{uuid}`» sobrevive. Es **casi**
  equivalente (si la escritura se rechaza no hay evento), pero **no del todo**: `rolesToRevoke` por
  `{uuid}` no comprueba el owner a propósito, así que un `revoke` de un uuid ajeno sí llega a
  notificar — y con el mutante el sink de auditoría del tenant A vería el slug y el owner de B. Es
  Q2 por la puerta del hook. Coste de cerrarlo: una aserción en B7.

### 4.6 Aserciones relajadas respecto a `56094ac` — ninguna real

Comparé multiconjuntos de líneas con `assert.`/`rejectsWith`/`rejects(`, normalizando la
indentación (muchos casos se anidaron más hondo bajo el par `purgeRole`, lo que produce cientos de
`-`/`+` cosméticos). Perdidas de verdad:

| Fichero | «Perdidas» | Veredicto |
|---|---|---|
| `src/testing/contract.ts` | 5 | 3 son del `whenFalse` reescrito (P4) y están **sustituidas por equivalentes o más fuertes**: `deleteScopedRole(admin,'lead')` ⇒ 422 `INVALID_IDENTITY`, y el 500 `UNSUPPORTED` se pide ahora al manager, no al driver. 1 es `isAtMost(ok.length,1)` con **otro mensaje** (sigue viva en la cara laxa). Ninguna relajación. |
| `tests/manager.spec.ts` | 3 | `syncCatalogs(...)` ⇒ `.count` (cambio de tipo, misma fuerza); `role('lead','unit')` ⇒ `rolesNamed('lead','unit')` (**más fuerte**: cubre locales); 1 es formato. |
| `tests/contract_harness.spec.ts` | 7 | Todas son los literales viejos de conteo (78/82/+12/+1), sustituidos por los nuevos y por dos filtros por regexp **más precisos**. |
| `tests/contract.spec.ts` / `catalog_cache` / `purity` | 0 | — |

Sigue en pie, como en 3D, que la cara **laxa** de la carrera admite **cero** ganadores
(`isAtMost(ok.length, 1)` + fallback). En SQLite es defendible (`SQLITE_BUSY` es un 503 legítimo) y
en PG/MySQL ya lo cierra la cara estricta; lo dejo anotado, no lo cuento como relajación.

### 4.7 Notas de fragilidad de R6 — **escritas**

- `CLAUDE.md`, bloque de `contract_harness`: *«**Aviso 3D · N6 / 3E · R6**: la regla de owner en
  `authorize` Y la regla de ambigüedad de `RoleQuery` cuelgan cada una de UN solo caso por harness
  … un refactor del SQL/checks —o un driver de terceros con su propio `roleVisible`— puede pasar la
  suite entera con la regla rota»*. ✅
- `README.md:278`, §Scoped roles: *«A note for driver authors (fragility…)»*, con la misma advertencia
  y la recomendación de no fiarse de una suite verde. ✅

Ambas nombran las dos reglas y el riesgo concreto. Cumplido.

### 4.8 Promesas nuevas de 3E, una a una

| Promesa | Juez |
|---|---|
| P1a nivel ≤ owner (ancestro, con y sin `descendantsOf`, `update` incluido) | ✅ 4 mutantes muertos |
| P1b globales ganan + `shadowedByGlobal` | ✅ 2 mutantes muertos |
| P2 canónico / base / subárbol | ✅ 3 mutantes muertos (uno también por el juez) |
| P3 rango en `detached` | ✅ muerto |
| P3 «nada a medias» | ❌→✅ **con el parche** |
| P4 capacidad antes de escribir + salida del callejón | ✅ muerto y demostrada |
| P5 diff tolerante | ✅ muerto |
| P6 revalidación de `assignableAt` | ✅ muerto |
| Q1 mensaje sin «renombra uno de ellos» | ❌→✅ **con el parche** |
| Q2 los 422 no nombran otro tenant (slug y uuid) | ❌→✅ **con el parche** |
| Q3 `AmbiguousRoleError` exportado | ✅ (test de superficie que compara `errors.ts` con `index.ts`: cualquier error nuevo entra o falla) |
| Q4 `purgeRole` opcional / firma de `listSubjects` | ✅ typecheck + `assert.isUndefined(driver.purgeRole)` |
| Q5 `better-sqlite3` en el cerrojo | ✅ muerto |
| Q6 `runCatalogDiff` sin recálculo y bajo su epígrafe | ✅ muerto (arrastrado por el mutante P5) |
| Q7 evento con el rol resuelto | ✅ muerto (forma) / 🟡 pluralidad y owner sin juez |
| Q8 CHANGELOG / CLAUDE.md / README | ✅ leídos; invariantes 15/18 y §Scoped roles actualizados |
| R5 carrera `define` × `sync` | ✅ muere con P1b-report y con R2-recheck |

---

## 5. Parche

`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/tests-tester-fase-3e.patch`
(`git apply` sobre `5b4f3c2`; **solo `tests/manager.spec.ts`**, +37/−3, 86 líneas de patch).

Cierra dos huecos y **no toca `src/` ni el juez**, así que los conteos del juez y
`contract_harness.spec.ts` quedan intactos.

1. **«Nada a medias» en `scopes.detached`** (caso 3E · P2/P3): añade `barato` (rank 2) definido
   **antes** que `caro`, afirma que sobrevive al `detached` rechazado y que **no se notificó ningún
   `role_purged`**; lo suma a la purga posterior y a la lista de eventos.
2. **Q1 + Q2** (casos de `defineScopedRole` y de colisiones): el mensaje de `AMBIGUOUS_ROLE` no
   aconseja «renombra uno de ellos», sí nombra la salida (`{ uuid }` / `PURGAR`), lista el homónimo
   visible y **no** el de la organización hermana; el `ROLE_NOT_VISIBLE` por slug no imprime la
   clave de scope ni el uuid del rol de otro árbol; y la ruta `{ uuid }` con el uuid de un rol ajeno
   no devuelve su slug ni su owner.

Rojo→verde medido:

| Mutante | Sin parche | Con parche |
|---|---|---|
| P3 rango rol a rol (orden natural) | 510 passed (VIVO) | **muerto** — `tampoco el que el actor SÍ podría tumbar: o se purgan todos o ninguno` |
| P3 rango rol a rol (rank ascendente) | 510 passed (VIVO) | **muerto** — mismo literal |
| Q1 «renombra uno de ellos» | 510 passed (VIVO) | **muerto** — `… to not include 'renombra uno de ellos'` |
| Q2 slug: owners ajenos en el 422 | 510 passed (VIVO) | **muerto** — `el 422 no regala la clave de scope del otro tenant` |
| Q2 uuid: slug+owner de un rol ajeno | 510 passed (VIVO) | **muerto** — `el uuid de un rol ajeno no revela su owner` |

Y en verde con el parche: sqlite **510**, sqlite-file **512**, PG **677**, MySQL **677**, tope 3
**510**, `typecheck` limpio, residuos 0.

---

## 6. Veredicto

**APTA CON CORRECCIONES** para cerrar la Fase 3.

**Lo que sostiene el «apta».** El delta 3E es el mejor lote de la fase en verificabilidad: de 31
mutantes ejecutados, **24 mueren**, y entre ellos están los tres de R1 que en 3D vivían en cuatro
motores y dos drivers (el 🔴 del informe anterior, **cerrado y comprobado**). Las seis piezas
bloqueantes tienen mutante muerto con fallo literal reproducible; P1a y P1b mueren por **las dos
caras**; P2 muere por sus **tres** agujeros por separado, y el de `descendantsOf` además desde el
juez y no solo desde un unitario; el `whenFalse` reescrito de P4 no solo caza el mutante, sino que
**demuestra la salida del callejón**, que era el defecto de diseño del caso viejo; R3 era un bug
real y su mutante muere con el error exacto que lo delataba. Los cinco modos corren con los números
declarados, sin flakes y con residuos 0. Los conteos del juez (75 / 79, +5/−1 asimétrico) están
**medidos ejecutando** y sin títulos duplicados, y el par nuevo `serializedCatalogWrites` está bien
construido (par exacto, `true` sin observador rechazado). Las notas de fragilidad de R6 están
escritas en los dos sitios. Y ninguna aserción se relajó: las 15 líneas `-` que parecen pérdidas son
reindentación, renombres de tipo o sustituciones por algo más fuerte.

**Lo que exige las correcciones.**

1. **Obligatoria — aplicar `tests-tester-fase-3e.patch`.** Sin él, **tres promesas nuevas del 3E no
   las observa nadie**: el «nada a medias» de P3 (dos mutantes de rango rol-a-rol vivos), Q1 y
   **Q2 en sus dos rutas**. Q2 es seguridad: un 422 sale tal cual al cliente y la ruta `{uuid}` sin
   ella vuelve a ser una sonda del catálogo ajeno. Coste: cinco aserciones en tres casos que ya
   existen, cero casos nuevos, cero cambios en el juez.
2. **Obligatoria — corregir el CHANGELOG sobre R7.** El «todo o nada» de `purgeRole` **no** lo
   garantiza el código ni lo falsa el conteo de `linksOf`: el mutante que olvida los vínculos pasa
   la suite entera en los **tres** motores, porque lo hace el `ON DELETE CASCADE`. Decirlo con esas
   palabras (esquema + K11 como garante, `linksOf` como documentación) es correcto; decir que el
   conteo por el puerto sustituye al CASCADE, no. Es lo único del informe 3E que afirma más de lo
   que la suite demuestra.
3. **Recomendadas.** (a) Hacer determinista el 422 de la rama genérica de la colisión transaccional
   (§4.2): hoy solo lo observa la carrera, y solo en el harness del árbol SQL. (b) Cerrar las dos
   mitades de Q7 (§4.5), una de las cuales es Q2 por la puerta del hook de auditoría. (c) Anotar en
   el caso de P3 que el orden de `readRolesOwnedBy` viene del motor (sin `ORDER BY`), para que nadie
   crea que «nada a medias» está probado en todos los órdenes. (d) Borrar la base huérfana
   `authz_test_3beaf8e3` de `postgres18`, que no es de esta sesión.

Como en 3D: ninguna de estas objeciones es a la implementación. El código de 3E hace lo que dice.
Es que, en cinco sitios, **lo que dice no lo demostraba nadie** — y en uno de ellos (R7) el informe
afirma una garantía que la suite no puede sostener.

---

## 7. Entregables

- Informe: `/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/fase-3-verificacion-tester-3e.md`
- Parche: `/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/tests-tester-fase-3e.patch`
  (`git apply` sobre `5b4f3c2`; toca solo `tests/manager.spec.ts`).
- Sin commits. Worktree con el único cambio del parche; contenedor efímero eliminado; `src/`
  restaurado byte a byte tras cada mutante.
