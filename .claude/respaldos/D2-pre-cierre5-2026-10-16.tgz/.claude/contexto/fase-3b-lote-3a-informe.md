# Fase 3b · Lote 3a — `authz:reconcile --to=openfga` (DB → FGA)

> Base: `464f7b7` (lote 2k), rama `v2/fase-3b`, **árbol principal**, sin commits.
> Encargo: `.claude/contexto/fase-3b-plan.md` §«Lote 3b-3», **solo la dirección
> DB → FGA y la infraestructura común**. La dirección inversa (`--to=database`)
> y `runMigrationContract` son el 3b-3b y no entran aquí.

Es el lote por el que existe la fase: *«que podamos tener o todo en un driver o
todo en otro y sea posible una migración idempotente y bidireccional entre
drivers»*.

## Resumen

| Pieza | Estado |
|---|---|
| P1 · `manager.freeze()` / `unfreeze()` / `withFrozenWrites()` | ✅ |
| P2 · `scopes.enumerateEdges` (puerto + `sqlScopeEdges` + casos en los 4 motores) | ✅ |
| P3 · `driver.reconcile()` — marcador de raíz, catálogo, árbol y hechos | ✅ |
| P4 · `manager.reconcile()` + `node ace authz:reconcile` | ✅ |
| Idempotencia demostrada (2ª pasada = 0 escrituras) | ✅ |
| `--dry-run` read-only, **sin `--fix`** (S18) | ✅ |
| `--prune` cierra AA4 (resurrección) | ✅ |
| Ciclos reportados (cruce 3 · ii) | ✅ |
| Ventana del relay + escritura del invariante 18 como deriva | ✅ |
| Store con basura del formato viejo ⇒ vía de salida | ✅ |
| 4 motores + `:8101` + tope 3 | ✅ |

**Cifras**: `sqlite` **720** (partía de 691) · `sqlite-file` **722** (693) ·
`pg` **815** (786) · `mysql` **815** (786) · tope 3 (`:8103`, memoria)
**720 passed**. 29 casos nuevos, todos en `tests/reconcile.spec.ts`.
`npx tsc --noEmit -p tsconfig.json`, `npm run typecheck`, `npm run check:purity`
y `npm run build` verdes. **Cero stores huérfanos en el `:8101`** (los 58 que
quedan son del 28–29 de agosto, de los scripts del auditor; ninguno de hoy).

---

## Qué se decidió antes de escribir código (y por qué)

Tres decisiones de diseño que no estaban literalmente en el plan y que
condicionan todo lo demás. Ninguna contradice el encargo; si alguna se
considera mal tomada, se cambia aquí y no en el 3b-3b.

### 1. El destino se nombra por el REGISTRO, no por el driver activo

`--to=openfga` resuelve `config.drivers['openfga']` y construye ESE driver,
aunque `config.default` sea `database`. Es la única forma de que la migración
real —«el motor sigue sirviendo con `database` mientras se llena el store»—
tenga un vocabulario; con `config.default` no habría manera de nombrar al
destino. Consecuencia simétrica para el 3b-3b: `--to=database` construirá el
driver `database` del registro.

### 2. Qué borra la pasada sola y qué exige `--prune`

El plan pide `{ written, updated, unchanged, extra, deleted, skipped }` y dice
que `--prune` borra «los hechos cuyo scope ya no resuelve». Pero el cruce 9 ·
S7 exige además «borrado de aristas no reportadas por `enumerateEdges`» **sin
bandera**, y `openfga_driver.ts:1475` ya manda «reconstruye el árbol con
authz:reconcile» para el nodo con dos padres. O sea que hay dos clases de cosa
sobrante y no una. La regla que se implementa:

- **Lo DERIVADO se rehace siempre**: marcador de raíz, proyección del catálogo
  y árbol. Son espejos de datos locales que nadie más escribe
  (`holderTypes`, `authz_roles`/`authz_permissions`,
  `scopes.enumerateEdges`), exactamente igual que `syncAuthzCatalog` ya borra
  los vínculos que el spec no lista. Aquí es donde se repara el nodo con DOS
  padres y donde se van las aristas que el consumidor ya no respalda.
- **Los HECHOS solo con `--prune`**: los del scope que ya no resuelve (AA4) y
  los sobrantes (basura de una versión anterior del store). Son
  irreversibles y su origen depende de qué driver esté vivo.
- **Una excepción, a propósito**: la arista `scope#binding` que el origen SÍ
  respalda pero cuya regla de visibilidad (invariante 18) dice que no, se
  borra **sin `--prune`**. Dejarla es fail-**open** y es justo la escritura que
  `scopes.moved`/`projectCatalogRole` pierden si el relay no pasa, que es lo
  que el punto 8 del encargo manda reportar. Se cuenta aparte en
  `drift.roleVisibility`.

Con esta regla, una pasada por defecto **no puede vaciar** los hechos de un
store vivo, y `--dry-run` sin `--prune` es completamente inocuo.

### 3. Un seguro nuevo: `E_AUTHZ_MASS_RECONCILE_REFUSED`

`--prune` sobre un store lleno con `authz_assignments`/`authz_denies` **vacías**
lo dejaría sin nada concedido y sin desde dónde reconstruirlo. Y es un
escenario normal, no rebuscado: con el driver `openfga` activo los hechos viven
en el store y NO en esas tablas, así que apuntar el comando a la base
equivocada —o correrlo creyendo que `authz_*` es la fuente cuando ya no lo es—
tiene exactamente esa firma. Se cierra con el mismo patrón ya aprobado en
3b-0b · AA2 (`E_AUTHZ_MASS_PURGE_REFUSED`): 500 antes de escribir nada,
`--allow-mass-delete` como decisión humana, y `--dry-run` no lanza, lo marca
(`massDelete: true`). No es una pieza del plan; es el guardarraíl que ese plan
necesitaba y no nombraba.

---

## P1 · `manager.freeze()` — la migración no compite con las escrituras

**Casos**: `tests/reconcile.spec.ts` grupo `3b-3a · freeze()` (4).

🔴 **Rojo literal** (antes de escribir una línea de implementación):

```
❯ 3b-3a · freeze() / congelado: las ESCRITURAS son 503 reintentable y no llegan al driver
ℹ TypeError: manager.freeze is not a function
❯ 3b-3a · freeze() / congelado: las LECTURAS siguen funcionando
ℹ TypeError: manager.freeze is not a function
❯ 3b-3a · freeze() / unfreeze devuelve las escrituras, y una vista de forRequest hereda el estado del manager
ℹ TypeError: manager.freeze is not a function
❯ 3b-3a · freeze() / la excepción de dentro del freeze no deja el motor congelado
ℹ AssertionError: expected [Function] to throw error including 'la migración explotó a la mitad' but got 'manager.withFrozenWrites is not a fun…'
Tests  4 failed (4)
```

**Verde con**: `AuthorizationFrozenError` (503 `E_AUTHZ_FROZEN`, con
`retryable = true` en la instancia) en `src/errors.ts`; en `src/manager.ts`,
`#frozenReason` en el manager RAÍZ (`#root()`), `freeze(reason?)`,
`unfreeze()`, `get frozen()`, `withFrozenWrites(reason, fn)` y la barrera
`#assertNotFrozen(operation)` colocada en **`#writeOptions`** (cubre las
siete: `grant`/`revoke`/`deny`/`removeDeny` y las tres `scopes.*`), en
**`#requireActor`** (la API de delegación) y explícitamente en
`relayScopeChanges` y `pruneOrphanRoles({force})`.

Las tres cosas que el encargo pide están medidas en el mismo caso: **503
reintentable** (`error.retryable === true`), **las lecturas siguen** (los tres
`list*`/`authorize` llegan al driver con el motor congelado) y **el `finally`
descongela tras una excepción**. El estado vive en el manager raíz a propósito:
una vista de `forRequest()` comparte driver, así que congelar el motor tiene que
alcanzarla —si no, el request que ya tenía su vista seguiría escribiendo durante
toda la migración—, y el caso lo fija.

🔴 **Mutante que lo confirma** (`#assertNotFrozen` devuelve siempre):

```
== M11-freeze
❯ 3b-3a · freeze() / congelado: las ESCRITURAS son 503 reintentable y no llegan al driver
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'
❯ 3b-3a · freeze() / unfreeze devuelve las escrituras, y una vista de forRequest hereda el estado del manager
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_FROZEN'
❯ 3b-3a · manager.reconcile / durante la pasada las escrituras están congeladas y las lecturas no; el finally descongela
ℹ AssertionError: una escritura durante la migración es 503 reintentable: expected undefined to equal 'E_AUTHZ_FROZEN'
Tests  26 passed, 3 failed (29)
```

---

## P2 · `scopes.enumerateEdges` — el árbol entero, paginado

**Puerto** (`src/types.ts`): `ScopeEdge`, `ScopeEdgePage`,
`ScopeEdgesEnumerator = ({ limit, after }) => Promise<{ edges, cursor? }>`;
opcional en `config.scopes` (`src/define_config.ts`). Contrato: como mucho
`limit` aristas por página (más ⇒ 500), orden total y estable, cursor opaco que
tiene que AVANZAR (repetirlo ⇒ 500, nunca un bucle), y **una arista cuyo padre
no existe no se emite** (es un nodo que `resolveChain` tampoco resuelve).

**Implementación publicada**: `sqlScopeEdges({ table, uuidColumn, parentColumn,
typeColumn | scopeType })` en `src/sql_descendants.ts`, junto a
`sqlDescendantsOf` y con sus mismas reglas (identificadores validados al
construir, mismos tres dialectos, `E_AUTHZ_UNSUPPORTED_DIALECT` en cualquier
otro). Exportada en `index.ts`.

**Casos** (3, sobre `demo_scopes`, o sea que corren en los CUATRO motores):
paginación completa por cursor con `limit=2` = el mismo conjunto que con
`limit=100`; la fila con el padre colgando no produce arista; y **el cursor
avanza aunque la página no haya emitido ninguna arista**.

🔴 **Rojo (mutante)**: el cursor sale de la última arista EMITIDA en vez de la
última FILA leída — que es el error natural al escribirlo:

```
== mutante «cursor desde la última arista»
❯ 3b-3a · scopes.enumerateEdges / el cursor avanza aunque la última fila de la página no produzca arista
ℹ AssertionError: sin cursor aquí, el resto del árbol no se enumera nunca: expected undefined to not equal undefined
Tests  6 passed, 1 failed (7)
```

Con ese mutante, un huérfano al principio de la tabla **para la paginación en
seco** y el resto del árbol no se migra nunca. Restaurado ⇒ 7/7.

---

## P3 · `driver.reconcile()` — DB → FGA contra el `:8101`

Método **opcional del puerto** (`AuthorizationDriver.reconcile?`), implementado
solo en `openfga`. No se añade una capacidad a `AuthorizationDriverCapabilities`
a propósito: las capacidades describen divergencias de comportamiento con caso
por las dos caras, y esto es un método opcional del puerto, que ya tiene su
vocabulario (`E_AUTHZ_UNSUPPORTED` nombrando el método, como `purgeRole` o
`listDenies`) y su caso negativo.

Todo el origen se escribe con el API del paquete: catálogo por
`syncAuthzCatalog`, árbol por `sqlScopeTree` sobre `demo_scopes`, hechos por
`DatabaseAuthorizationDriver.grant/deny`. Ni una fila a mano salvo donde el
caso es precisamente «alguien escribió a mano».

🔴 **Rojo literal** (antes de implementar):

```
❯ 3b-3a · reconcile --to=openfga (servidor real) / el store vacío no concede NADA, y una pasada de reconcile lo pone a la par del driver database
ℹ TypeError: fga.reconcile is not a function
❯ 3b-3a · reconcile --to=openfga (servidor real) / idempotencia: la SEGUNDA pasada escribe cero
ℹ TypeError: fga.reconcile is not a function
❯ 3b-3a · reconcile --to=openfga (servidor real) / --dry-run es el verificador: mismo recorrido, CERO escrituras
ℹ TypeError: fga.reconcile is not a function
Tests  7 passed, 3 failed (10)
```

**Verde con** (`src/drivers/openfga_driver.ts`, +660 líneas):
`reconcile(source, options)` y sus piezas — `readSourceTree` (páginas con
cursor, anti-ciclos incremental con `walkUpTo`), `readSourceFacts` (`eachRow`
con cursor sobre la PK y `sqlExpiryCodec` para leer `expires_at` sin depender
de la zona del cliente), `readEveryTuple` (volcado ENTERO del store),
`modelPermissions`, `familyOfTuple`, `applyReconcileWrites`— más
`readCatalogProjectionSnapshot` extraída de `src/catalog.ts` (la MISMA foto que
usa el sync: si fueran dos funciones, reconcile «arreglaría» en cada pasada lo
que el sync acaba de dejar bien).

### Lo que cada caso fija, con el mutante que lo pone rojo

**(a) Migración y paridad.** Store vacío ⇒ `authorize` falso; una pasada ⇒ las
seis preguntas responden **lo mismo** que el driver `database` (herencia hacia
abajo y deny explícito incluidos).

```
== M1-marcador-de-raiz   (no se escribe scope:app#rooted)
❯ … el store vacío no concede NADA, y una pasada de reconcile lo pone a la par del driver database
ℹ AssertionError: faltaba el marcador de raíz: sin él el store entero deniega: expected false to be true
… (7 casos rojos: sin marcador, (c2r) deniega TODO)
Tests  22 passed, 7 failed (29)
```

**(b) Idempotencia** — la palabra del dueño, con sus dos recuentos:
`primera.written > 0` y **`segunda.written === 0`**, `updated === 0`,
`deleted === 0`, `extra === 0` y `segunda.unchanged === primera.written +
primera.unchanged` (o sea: todo lo que se escribió sigue exactamente igual).
En la corrida real de este árbol la primera pasada escribe **21** tuplas y la
segunda **0**.

```
== M2-idempotencia   (se reescribe lo que ya estaba)
❯ … idempotencia: la SEGUNDA pasada escribe cero
ℹ AssertionError: la segunda pasada no escribe NADA: expected 21 to equal +0
Tests  25 passed, 4 failed (29)
```

**(c) `--dry-run` es el verificador.** Dice lo que escribiría (mismos números)
y el store se queda con **0 tuplas**; sobre un store ya reconciliado no ve
deriva (`written 0`, `extra 0`, `cycles []`, `multiParent []`).

```
== M3-dry-run   (aplica el plan igualmente)
❯ … --dry-run es el verificador: mismo recorrido, CERO escrituras
ℹ AssertionError: y no ha escrito ni una tupla: expected [ { key: { …(4) }, …(1) }, …(20) ] to have a length of +0 but got 21
Tests  26 passed, 3 failed (29)
```

**No hay `--fix` ni nada preparado para uno** (hallazgo S18, cruce 4): el
comando no tiene bandera de reparación, `reconcile` no acepta ninguna opción
que lo parezca, y el docblock del método y el del comando lo dicen con esas
palabras.

**(d) Lo que no se migra sale contado y con su motivo.** `skipped{razón}` +
`details` con la fila nombrada (acotado a 200). Motivos que produce hoy:
`expired`, `unknown-scope`, `unknown-role`, `unknown-permission`,
`unknown-holder-type`, `role-not-visible`, `permission-not-in-model`,
`invalid-scope`, `root-child`, `two-parents-in-source`, `cycle` y `extra-fact`
(tupla del destino que solo se va con `--prune`).

```
== M4-caducada   (no se filtra la asignación caducada)
❯ … lo que NO se migra sale contado y con su motivo
ℹ AssertionError: la caducada tiene que salir contada: expected +0 to be at least 1
Tests  28 passed, 1 failed (29)
```

**(e) `--prune` cierra AA4.** Con la unit borrada del árbol del consumidor y
sus hechos vivos en `authz_assignments`: sin `--prune`,
`phases.facts.deleted === 0` y las tuplas siguen ahí (solo se reportan); con
`--prune` no queda ninguna, y la tercera pasada vuelve a ser 0/0.

```
== M5-prune   (se borran los hechos sin la bandera)
❯ … lo que NO se migra sale contado y con su motivo
ℹ AssertionError: sin --prune no se borra ni un hecho: expected 4 to equal +0
❯ … --prune borra los hechos del scope que ya no resuelve; sin él solo se reportan
ℹ AssertionError: expected 4 to equal +0
Tests  27 passed, 2 failed (29)
```

**(f) El seguro del origen ciego.**

```
== M6-mass-delete   (se quita el 500)
❯ … --prune con `authz_*` VACÍO se niega (origen ciego), y --allow-mass-delete es la salida
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_MASS_RECONCILE_REFUSED'
Tests  28 passed, 1 failed (29)
```

**(g) El árbol: dos padres y aristas sobrantes** (cruce 9 · S7 + 3b-2h · 🟠 4).
Se escriben a mano en el store un segundo `parent` para la unit y la arista de
un nodo fantasma; `--dry-run` los denuncia (`drift.multiParent`), la pasada
real los borra **sin `--prune`**, la herencia buena sigue en pie y el
verificador siguiente ya no ve nada.

```
== M7-aristas-sobrantes   (la familia `tree` no se borra)
❯ … el árbol: repara un nodo con DOS padres y borra las aristas que el consumidor ya no respalda
ℹ AssertionError: lo derivado se rehace entero, sin --prune: expected +0 to be at least 2
❯ … un CICLO en el árbol del origen se reporta y NINGUNA de sus aristas se escribe
ℹ AssertionError: no puede quedar ninguna arista del ciclo: scope:app#parent@scope:organization|… : expected … to equal undefined
Tests  26 passed, 3 failed (29)
```

**(h) Ciclos** (mitigación obligatoria del cruce 3, parte ii). Se cierra el
ciclo tocando `demo_scopes` a mano; la pasada lo **reporta** (`cycles`, con los
dos nodos) y **no escribe ninguna** de sus aristas, ni la que lo cierra ni las
demás — el criterio es el subárbol entero para que no dependa del orden de
enumeración—. Sin arista no hay `rooted`, así que ese subárbol **deniega**:
fail-CLOSED, que es lo que (c2r) compró.

```
== M8-ciclo   (se escriben igual)
❯ … un CICLO en el árbol del origen se reporta y NINGUNA de sus aristas se escribe
ℹ AssertionError: ciclos: []: expected [] to have a length of 1 but got +0
Tests  28 passed, 1 failed (29)
```

**(i) La escritura del invariante 18 que el relay pudo perder** (consecuencia 4
de la decisión del dueño del 2026-08-30). Una asignación escrita a mano en
`authz_*` con un rol de nivel `unit` sobre una `organization`, y su arista
`scope#binding` en el store: **el store concede lo que `database` no**. Una
pasada normal —sin `--prune`— la borra, cuenta la deriva aparte
(`drift.roleVisibility`) y **el `assignee` NO se toca** (la asignación existe;
lo que no existe es su visibilidad ahí, que es exactamente lo que la arista
significa desde 3b-2g · R1).

```
== M9-invariante-18   (la arista prohibida se trata como un sobrante más)
❯ … invariante 18: la arista de visibilidad que el relay pudo perder se borra SIN --prune
ℹ AssertionError: la deriva de visibilidad se cuenta aparte: expected +0 to be at least 1
Tests  28 passed, 1 failed (29)
```

**(j) La vía de salida de un store de la versión anterior.** El caso monta el
store con un modelo VIEJO (declara `role_binding#assignee` y
`deny_binding#denied`), escribe la asignación como la dejaba el importador
borrado —sin las dos aristas de (c2)— y un `deny_binding` que (c2r) ni declara;
publica encima el modelo de hoy y comprueba que **no concede nada**. Una pasada
con `--prune` lo reconstruye desde `authz_*` ⇒ concede otra vez, la basura del
modelo viejo desaparece, la única tupla que ya estaba bien se cuenta
`unchanged` (no se reescribe) y la pasada siguiente escribe 0.

Antes de escribir el caso se midió contra el `:8101` que una tupla de un tipo
que el modelo actual NO declara **se puede leer y borrar** aunque no se pueda
escribir (400 `type 'deny_binding' not found` al escribir; 200 al borrar). Sin
eso el caso no era realizable y habría habido que declararlo.

```
== M10-volcado-entero   (el volcado se filtra por `object: 'scope:'`)
❯ … (los 11 casos contra el servidor real)
ℹ AuthorizationBackendError: El backend de autorización 'openfga' no respondió (read)
Tests  18 passed, 11 failed (29)
```

Ese mutante deja escrito por qué el volcado es `Read` sin filtro: el servidor
rechaza con un 400 un `Read` cuyo objeto es solo el tipo y no trae `user`
(mismo hallazgo que corrigió 3b-2a), y además un filtro por objeto **no puede
ver lo que sobra**, que es la mitad del trabajo.

### Lo que se cambió de un test existente

`tests/openfga_facts.spec.ts` · «guardia de fuente: el driver solo mira el tipo
`role` en la proyección»: contaba **6** apariciones de `` `${FACTS_ROLE_TYPE}:` ``
en el driver y ahora hay **8**. Las dos nuevas son de `reconcile` y ninguna
pregunta qué permisos vincula un rol (que es lo que A6 protege): la arista
`role_binding#role` que se **escribe** por cada asignación del origen, y
`familyOfTuple`, que mira el TIPO del objeto para clasificar una tupla del
store. El test se actualiza a 8 **y se le añade una aserción**: el cuerpo de
`readSourceFacts` incluye `relation: FACTS_ROLE_RELATION` y **no** menciona
`FACTS_PERMITS_PREFIX`. Es el único test preexistente tocado.

---

## P4 · `manager.reconcile()` y `node ace authz:reconcile`

`manager.reconcile({ to, dryRun?, prune?, allowMassDelete?, batchSize? })`:
resuelve el destino por `config.drivers[to]`, le aplica `config.clock`, exige
`scopes.enumerateEdges`, **congela**, delega en `driver.reconcile` y añade al
reporte lo único que el driver no puede ver: la **ventana del relay**
(pendientes sin relevar) y lo **aparcado**. Se mide con las escrituras
congeladas, así que la cola no crece durante la cuenta.

`commands/authz_reconcile.ts` imita en forma a `authz:scopes:relay` y
`authz:catalog:prune-orphans`, con `reconcileLines(report)` como función PURA
que decide qué se imprime y si la pasada es limpia (mismo patrón que
`orphanLines`, y por eso tiene casos sin montar un ace). Códigos de salida:
en `--dry-run` **cualquier cosa que haría** es deriva (exit 1: es el gate de
CI); siempre lo son los ciclos, lo aparcado, los dos padres y lo que quede en
`skipped`; la ventana del relay **avisa pero no tumba** (es una ventana de
segundos por diseño). El comando no importa nada de openfga: habla con el
manager, así que la regla 3 de pureza se cumple sola.

**Casos** (11): destino por registro; driver sin `reconcile` ⇒ 500
`E_AUTHZ_UNSUPPORTED` nombrando el método; destino no registrado ⇒ 500
nombrando los registrados; sin `enumerateEdges` ⇒ 500 **antes de construir el
destino**; congelado dentro y descongelado fuera; excepción a mitad ⇒ no queda
congelado; la ventana del relay medida con una outbox SQL real; las cuatro
decisiones de `reconcileLines`; y **uno de punta a punta contra el `:8101`** con
un manager cuyo driver activo es `database` (migra, sigue escribiendo después y
el verificador ve el `grant` nuevo como deriva).

```
== M12-ventana-relay   (se devuelve 0 siempre)
❯ 3b-3a · manager.reconcile / la VENTANA del relay se reporta como deriva (y lo aparcado, aparte)
ℹ AssertionError: la ventana del relay se MIDE, no se supone: expected +0 to equal 2

== M13-destino-por-defecto   (se usa `this.driver()` en vez del registro)
❯ … de punta a punta por el manager: `authz:reconcile --to=openfga` con el motor congelado
ℹ UnsupportedOperationError: authz:reconcile --to=openfga necesita 'reconcile' y el driver 'openfga' no lo implementa…
❯ 3b-3a · manager.reconcile / el destino se nombra por el REGISTRO, no por el driver activo
ℹ UnsupportedOperationError: …
Tests  23 passed, 6 failed (29)
```

---

## Qué entra en `skipped`, y con qué motivo

| Motivo | Qué es | ¿Se borra su rastro en el destino? |
|---|---|---|
| `expired` | asignación con `expires_at` pasado: no concede | solo `--prune` |
| `unknown-scope` | el árbol del consumidor ya no resuelve ese scope (AA4) | **solo `--prune`** (es lo que cierra la resurrección) |
| `unknown-role` | `role_uuid` que el catálogo ya no declara | solo `--prune`. **Nota honesta**: con el esquema publicado esta rama es defensiva — `authz_assignments.role_uuid` tiene FK `RESTRICT`, así que no se puede borrar un rol con asignaciones vivas. Los hechos de un rol retirado en modo `facts` viven en el STORE, y se recogen por el lado del destino (`extra-fact`) |
| `unknown-permission` | `permission_uuid` que el catálogo ya no declara | solo `--prune` |
| `unknown-holder-type` | morph name que `holderTypes` no declara: no hay usuario FGA que escribir | solo `--prune` |
| `role-not-visible` | la asignación existe, pero el rol no es visible ahí (invariante 18) | su `scope#binding` **sí, sin `--prune`** |
| `permission-not-in-model` | el modelo publicado del store es más viejo que el catálogo | no se toca (escribirlo sería un 400 a media migración) |
| `invalid-scope` / `root-child` / `two-parents-in-source` | lo que `enumerateEdges` devolvió y no es una arista legal | la arista sobrante, sí (familia derivada) |
| `cycle` | arista de un ciclo del árbol del consumidor | sus aristas se borran (familia derivada) ⇒ ese subárbol deniega |
| `extra-fact` | tupla de hechos del destino que el origen no respalda | solo `--prune` |

---

## Lo que NO hice, y por qué

1. **`--to=database`** (FGA → DB). Es el 3b-3b por encargo explícito. Hoy el
   camino existe y es ruidoso: `manager.reconcile({ to: 'database' })` resuelve
   el driver y responde 500 `E_AUTHZ_UNSUPPORTED` nombrando `reconcile` como el
   método del puerto que falta. Tiene su caso.
2. **`runMigrationContract`** (las 448 preguntas, la siembra fija, las tres
   combinaciones, `expectedLosses`). Es del 3b-3b: es el contrato de la
   migración BIDIRECCIONAL y no se puede escribir con una sola dirección. Lo
   que sí hay aquí es un caso de **paridad** con seis preguntas idénticas
   contra los dos drivers después de migrar, que es la forma pequeña de lo
   mismo.
3. **Capacidad `reconcile` en `AuthorizationDriverCapabilities`**. Se decidió
   usar el patrón de método opcional del puerto (`E_AUTHZ_UNSUPPORTED`), que
   ya es el vocabulario de `purgeRole`/`listDenies`/`countRoleAssignments`
   cuando faltan. Añadir una capacidad obliga a las dos caras con caso en la
   suite de contrato publicada, y el 3b-3b puede querer esa entrada con el
   contrato de migración entero, no con media dirección.
4. **`enumerateEdges` en `ContractScopeTree`** (el harness del juez). No hizo
   falta: los casos usan `sqlScopeEdges` sobre `demo_scopes`, que es el árbol
   SQL del harness, así que la paginación se observa en PostgreSQL y MySQL de
   verdad y no en un `Map` de JS.
5. **Nada de `--fix`, ni preparado.** Prohibición explícita (S18).
6. **No se tocó `configure.ts`**: los comandos se registran con
   `addCommand('@jantstack/adonis-authz/commands')`, así que el export nuevo en
   `commands/main.ts` basta.

## Límites conocidos (escritos, no escondidos)

- **El volcado del destino entra en memoria.** `readEveryTuple` trae el store
  entero (acotado por `MAX_READ_PAGES` × 100 = 1 000 000 de tuplas, que es la
  misma cota que ya tenían las demás enumeraciones del driver). El ORIGEN sí se
  lee por lotes de 100 con cursor, que es lo que pedía el encargo. Un store de
  millones de tuplas necesitaría un reconcile por particiones, y eso no está.
- **«Reanudable» es «idempotente y se repite»**, no «guarda un cursor entre
  ejecuciones». Una pasada interrumpida se retoma volviendo a ejecutarla: la
  segunda converge y lo ya escrito sale como `unchanged`. Hay caso.
- **El orden de aplicación es deletes → writes.** Si la pasada muere en medio,
  el destino queda de MENOS (fail-closed), nunca con una tupla vieja
  conviviendo con la nueva.
- **`Ignore` sigue puesto en el `Write`**, pero como red contra una carrera, no
  como política: el plan sale de un diff sobre el estado leído y la migración
  corre con las escrituras congeladas. Es justo lo contrario de S7, donde el
  `Ignore` decidía (y se quedaba la caducidad vieja contándola como escrita).

## Verificación

```
npx tsc --noEmit -p tsconfig.json && npm run typecheck && npm run check:purity && npm run build   ✔
OPENFGA_TEST_URL=http://localhost:8101 npm test                    → 720 passed  (partía de 691)
OPENFGA_TEST_URL=http://localhost:8101 npm run test:sqlite-file    → 722 passed  (partía de 693)
TEST_PG_URL=… OPENFGA_TEST_URL=… npm run test:pg                   → 815 passed  (partía de 786)
OPENFGA_TEST_URL=http://localhost:8101 npm run test:mysql          → 815 passed  (partía de 786)
OPENFGA_TEST_URL=http://localhost:8103 npm test   (tope 3)         → 720 passed
```

`docker rm -f openfga-tiny` hecho. Stores en el `:8101`: ninguno creado hoy
sigue vivo (los 58 que quedan son del 28–29 de agosto, de los scripts del
auditor de R2).

## Ficheros

| Fichero | Qué |
|---|---|
| `src/errors.ts` | `AuthorizationFrozenError` (503, `retryable`), `MassReconcileRefusedError` (500) |
| `src/types.ts` | `ScopeEdge`/`ScopeEdgePage`/`ScopeEdgesEnumerator`; `ReconcileSource`/`ReconcileOptions`/`ReconcileCounts`/`ReconcileSkip`/`ReconcileReport`; `AuthorizationDriver.reconcile?` |
| `src/define_config.ts` | `scopes.enumerateEdges` |
| `src/manager.ts` | `freeze`/`unfreeze`/`frozen`/`withFrozenWrites` + la barrera; `reconcile({to,…})`, `#edgesEnumerator`, `#relayWindow` |
| `src/drivers/openfga_driver.ts` | `reconcile()` y sus piezas (+660 líneas) |
| `src/catalog.ts` | `readCatalogProjectionSnapshot` extraída (la usan el sync y reconcile) |
| `src/sql_descendants.ts` | `sqlScopeEdges` |
| `commands/authz_reconcile.ts` · `commands/main.ts` | el comando y su registro |
| `index.ts` | los dos errores, `sqlScopeEdges` y los tipos nuevos |
| `tests/reconcile.spec.ts` | 29 casos |
| `tests/openfga_facts.spec.ts` | la guardia A6, de 6 a 8, con la aserción nueva |
| `README.md` · `CHANGELOG.md` · `CLAUDE.md` · `stubs/config/authorization.stub` | documentación |
