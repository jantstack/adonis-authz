# Fase 3b · lote 2i — el modelo **(c2r)**: `can_<P>` exige alcanzar la raíz

**Base:** `v2/fase-3b` @ `0359b56` (3b-2h), árbol limpio, trabajo SOBRE EL ÁRBOL PRINCIPAL.
**Sin commits: los hace el dueño.**
**Diseño que se implementa (no se rediseña):** `.claude/contexto/fase-3b-diseno-r1.md`.
**Decisión del dueño que va con él:** `decisiones-dueno-2026-08-28.md`, §«Decisión del 2026-08-31 (2)».

---

## Veredicto en una línea

El 🔴 1 está **cerrado y demostrado contra el servidor real**, y **las cinco propiedades que el
diseño midió siguen en pie con los mismos números**: `authorize` es UN solo `Check`, el techo de
profundidad sigue en 22, el de tamaño baja a **691** con `factsModelBytes` en **delta 0**, y el
recuento de casos que cambian de respuesta es **exactamente los 4 previstos, ninguno del juez**.
Del juez contra `facts`, **R2-a se pone verde** — y al ponerse verde **destapa una aserción del
MISMO caso que llevaba tapada desde 3b-0b y que es una divergencia real del puerto** (§7): no la
rompe (c2r), la hace visible. Va como hallazgo, no como arreglo.

---

## 1 · La reproducción del auditor: antes y después

Guion literal del diseño (§3.2) / del auditor (`repro/a2_escalada_within.ts`), con
`requireWithin: true`, `app ← orgA (deny docs:write a alice) ← D ← U`, los dos drivers sobre el
mismo catálogo y el mismo árbol. Script en `.claude/reproducciones/2i/a2_escalada_within.ts`.

**ANTES (HEAD `0359b56`)** — `OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec …`:

```
1) El actor manda en la DIVISION (within: div). ¿Qué puede hacer?
  removeDeny(docs:write, org)  → 422 E_AUTHZ_NOT_WITHIN
  grant(org-admin, org)        → 422 E_AUTHZ_NOT_WITHIN
  scopes.detached(div)         → OK (purgada)

2) Después de detachar SU division:
  authorize(alice, docs:write, unit)   facts=true  database=false *** FACTS FAIL-OPEN ***
   deny en la org tras la operación: scope:app #parent | user:01a05629-…-3d0eed6f20e0 #denied_docs_write
```

**DESPUÉS (este lote)** — mismo script, mismo servidor:

```
1) El actor manda en la DIVISION (within: div). ¿Qué puede hacer?
  removeDeny(docs:write, org)  → 422 E_AUTHZ_NOT_WITHIN
  grant(org-admin, org)        → 422 E_AUTHZ_NOT_WITHIN
  scopes.detached(div)         → OK (purgada)

2) Después de detachar SU division:
  authorize(alice, docs:write, unit)   facts=false database=false PARIDAD
   deny en la org tras la operación: scope:app #parent | user:01a05648-…-ac2b6abd6f73 #denied_docs_write
```

Las **tres barreras responden igual** (el arreglo NO es «cerrar `detached`»), el **deny sigue
escrito** (no se ha reparado borrando nada de la org) y lo que se restauró es **el camino por el que
se heredaba**. Queda como caso de la suite: `facts · 3b-2i … / I3 · scopes.detached de un nodo
INTERMEDIO ya no borra los denies de su subárbol (el 🔴 1)`.

---

## 2 · Qué se implementó

### I1 · `openFgaFactsModel` emite (c2r)

`src/drivers/openfga_facts.ts`:

```ts
scopeRelations[r.can] = {
  intersection: {
    child: [
      { difference: { base: computed(r.base), subtract: computed(r.denied) } },
      computed(FACTS_ROOTED_RELATION),
    ],
  },
}
scopeRelations[FACTS_ROOTED_RELATION] = { union: { child: [{ this: {} }, ttu('parent', FACTS_ROOTED_RELATION)] } }
scopeMetadata[FACTS_ROOTED_RELATION] = { directly_related_user_types: wildcards }
```

Más: `FACTS_ROOTED_RELATION`, `'rooted'` en `OWN_RELATIONS` (relación propia ⇒ 422 como `ancestor`)
y en `RESERVED_SLUGS` del **núcleo** (`src/identity.ts`), para que un catálogo legal en `database`
siga siendo publicable en `openfga`. Exportados por el subpath: `factsRootTuples`,
`FACTS_ROOTED_RELATION`.

**ROJO literal** (el caso del literal, reescrito ANTES del código):

```
❯ facts · A1 — el generador del modelo (c2) / openFgaFactsModel(...) es el literal del plan
ℹ AssertionError: expected { schema_version: '1.1', …(2) } to deeply equal { schema_version: '1.1', …(2) }
   ❯ 168 ┃      assert.deepEqual(openFgaFactsModel(HOLDERS, PERMISSIONS), EXPECTED)
Tests  1 failed (1)
```

**Casos negativos** (`facts · A2`), rojos con el mutante «`rooted` fuera de `OWN_RELATIONS` y de
`RESERVED_SLUGS`»:

```
ℹ AssertionError: rooted: expected undefined to equal 422        ← permisos ['rooted'] ⇒ 422
ℹ AssertionError: expected undefined to equal 422                ← assertValidSlug('permiso'|'rol', 'rooted')
Tests  2 passed, 2 failed (4)
```

### I2 · `factsRootTuples` + `ensureFactsRoot()` en el driver

`src/drivers/openfga_driver.ts`, al principio de `projectCatalog` (o sea en cada `syncAuthzCatalog`
con proyección), y **solo en modo `facts`**:

```ts
private async ensureFactsRoot(): Promise<void> {
  if (this.hierarchy !== 'facts') return
  const wanted = factsRootTuples(this.holderTypes)
  const current = await this.readAllTuples(
    { object: factsScopeObject(APP_SCOPE_TYPE), relation: FACTS_ROOTED_RELATION },
    { includeExpired: true }
  )
  const have = new Set(current.map((tuple) => tuple.user))
  const missing = wanted.filter((tuple) => !have.has(tuple.user))
  if (missing.length) await this.client.write({ writes: missing, deletes: [] })
}
```

**Cuatro casos nuevos** (`facts · 3b-2i — el marcador de raíz \`scope:app#rooted\``): store virgen ⇒
1 `Write` con una tupla por holder type; segundo sync ⇒ 0 escrituras; **añadir un holderType al
config ⇒ 1 `Write` con SOLO la tupla que falta**; modo `resolver` ⇒ ni se pregunta por `rooted`.

**ROJO literal antes del código** (2 de 4; los otros dos pasaban en vacío y se cubren con mutante):

```
❯ … / un sync en un store virgen escribe UNA tupla `rooted` por holder type sobre `scope:app`
❯ … / añadir un holderType al config ⇒ 1 Write con SOLO la tupla que falta
Tests  2 passed, 2 failed (4)
```

**MUTANTE** (`if (wanted.length) write(wanted)` en vez de `missing`) ⇒ rojo el de idempotencia y el
del holderType:

```
ℹ AssertionError: el marcador ya estaba: no se reescribe: expected [ Array(1) ] to have a length of +0 but got 1
Tests  2 passed, 2 failed (4)
```

### I3–I5, I7 · el grupo `facts · 3b-2i — (c2r): sin cadena a la raíz no se concede`

Contra el `:8101` real, dos drivers (`facts` + `database`), mismo catálogo y mismo árbol, **ni una
tupla a mano** salvo donde el caso lo dice. Cinco casos:

| # | Caso | Qué fija |
|---|---|---|
| I3 | el escenario del auditor | barreras 422/422/OK + `{facts:false, database:false}` + el deny leído del store |
| I4 A/B | grant local, heredado 2 saltos, **en la raíz `app`**, nunca a hermanos ni hacia arriba | la paridad que el arreglo podía romper |
| I4 C/D | detach del intermedio apaga el subárbol (3 sujetos), la org intacta sigue, recolgar restaura | filas C y D de §3.3 del diseño |
| I5 | se borra el marcador a mano ⇒ `false` en `app`, org y unit; `sync` lo repone | el modo de fallo declarado (fail-closed, nunca 503) |
| I7 | ciclo **huérfano** X↔Y ⇒ `false` dentro y hacia arriba, en ms | lo que (c2r) SÍ cierra del cruce 3 |

**MUTANTE A** — `can_<P>` sin la intersección (el modelo de HOY):

```
❯ I3 · …   ℹ AssertionError: PARIDAD: la unit ya no alcanza `app`…: expected { facts: true, database: false } to deeply equal { facts: false, database: false }
❯ I4 C/D · …  ℹ AssertionError: expected { facts: true, database: false } to deeply equal { facts: false, database: false }
❯ I5 · …   ℹ AssertionError: la raíz tampoco: expected true to be false
❯ I7 · …   ℹ AssertionError: ni en su propio scope: el ciclo no alcanza la raíz: expected true to be false
Tests  1 passed, 4 failed (5)
```

**MUTANTE B** — `ensureFactsRoot` desactivado:

```
❯ I4 A/B · …  ℹ AssertionError: expected { facts: false, database: true } to deeply equal { facts: true, database: true }
❯ I4 C/D · …  ℹ AssertionError: expected { facts: false, database: true } to deeply equal { facts: true, database: true }
❯ I5 · …      ℹ AssertionError: precondición: expected false to be true
Tests  2 passed, 3 failed (5)
```

Los dos mutantes juntos son la prueba de que **cada mitad del arreglo tiene su caso**: sin la
intersección se abre el 🔴 1; sin el marcador el store entero deniega.

### I6 · la ventana del relay cambia de signo (la decisión del dueño, con caso)

`tests/scope_outbox.spec.ts`, grupo `3b-2i · I6 — el lag del relay es fail-CLOSED para un scope
NUEVO`, contra el servidor real y con los dos drivers:

- **con outbox**: `attached` encolado **sin relevar** + `grant` ⇒ `{facts:false, database:true}`,
  marcado como *fail-CLOSED declarado*; tras `relayScopeChanges()` ⇒ `{true, true}`;
- **sin outbox**: el manager llama al driver en línea ⇒ `{true, true}` ya: **la ventana es cero**.

**MUTANTE** (`can_<P>` sin `rooted`) ⇒ reaparece el fail-open que se está cerrando:

```
ℹ AssertionError: FAIL-CLOSED declarado: hasta el relevo la unit no alcanza `app`, así que no concede:
  expected { facts: true, database: true } to deeply equal { facts: false, database: true }
Tests  1 passed, 1 failed (2)
```

### I8/I9 · cotas y documentación

- `FACTS_MODEL_MAX_BYTES` **no cambia**; `FACTS_MAX_RESOLVE_DEPTH` **no cambia** (22).
- «≈720» → «≈691» en los cuatro sitios: `openfga_facts.ts` (docblock del modelo y de la cota),
  `src/errors.ts` (`ModelTooLargeError`), `README.md` (tabla de errores), `CLAUDE.md` (cotas).
- **CLAUDE.md**: invariante **1** (herencia hacia abajo **desde la raíz**), invariante **9** (en
  `facts` lo hace el MODELO, no `resolveChain`; el marcador; el signo del lag), invariante **11**
  (el orden S6 no cambia y su MOTIVO sí), el párrafo de la outbox (los **dos signos**, la receta,
  «sin outbox la ventana es CERO»), el mapa de `openfga_facts.ts` y el roadmap (3b-2i ✅ + los dos
  deberes que le deja a `reconcile`).
- **Docblock de `onScopeDetached`**: decía que sin ancestro «los denies dejarían de aplicar y esos
  permisos serían INDENEGABLES». Eso **era el 🔴 1**. Reescrito: el orden se mantiene por otra razón
  (una purga a medias tiene que dejar denies de MÁS, no un nodo con hechos vivos que ya nadie purga)
  y se dice que los hijos, mientras nadie los recuelga, **deniegan**.
- **README**: la sección del outbox se renombra a *«The tree outbox, and the relay lag you are
  accepting»* (con sus dos anclas internas actualizadas) y el párrafo del lag pasa a describir los
  **dos signos**, con la receta de drenar la cola tras el commit y con «**Without an outbox the
  window is zero**». Sección nueva **«What a scope that is not attached grants»** con la propiedad,
  las dos consecuencias operativas y el modo de fallo del marcador. `rooted` añadido a la lista de
  slugs reservados.
- **CHANGELOG**: entrada `Lot 3b-2i`, **breaking dos veces** (un scope nunca notificado deja de
  conceder; la ventana del relay cambia de signo) y con el **paso de migración** escrito: republicar
  el modelo sin escribir el marcador deja el store entero denegando.

El caso que vigila la redacción del README se reescribe con el signo correcto y **`'inherited denies
do not apply'` pasa a ser una aserción NEGATIVA** (`notInclude`): esa frase describía el defecto.
Rojo con el mutante que devuelve la redacción del 2d:

```
ℹ AssertionError: con (c2r) un `attached` sin relevar no concede: no hay denies que dejen de aplicar:
  expected '# @jantstack/adonis-authz…' to not include 'inherited denies do not apply'
```

---

## 3 · Las cinco propiedades medidas, con sus números

### (1) Cierra el escenario del auditor · ✅ §1 de este informe, PARIDAD con el deny escrito

### (2) `authorize` sigue siendo UN solo `Check` · ✅ intacto

Espía sobre el cliente del driver **real** y sobre el resolutor del consumidor, contra el `:8101`
(`.claude/reproducciones/2i/un_check.ts`):

```
authorize                ⇒ {"check":1,"batchCheck":0,"read":0,"write":0,"listObjects":0}
  resolveChain llamado: 0 veces
authorizeMany(4 scopes)  ⇒ {"check":0,"batchCheck":1,"read":0,"write":0,"listObjects":0}
  resolveChain llamado: 0 veces
```

Idénticos a los del diseño. **No se tocó una línea de `factsAuthorize`**, y el caso de la suite que
lo fija (`facts · 3b-2c … 0 batchCheck y 0 resolveChain`) sigue verde. `singleCheckAuthorize: true`
sigue siendo cierto.

### (3) El techo de PROFUNDIDAD no se mueve · ✅ 22 sólido / 23 probabilístico / 24 nunca

Metodología del 2e·E5 con el modelo (c2r) publicado y **25 repeticiones por punto**
(`.claude/reproducciones/2i/depth.ts`):

```
(c2r)  20:25/25  21:25/25  22:25/25  23:16/25  24:0/25  25:0/25
```

`FACTS_MAX_RESOLVE_DEPTH = 22` sigue siendo exacto y **no se toca**. Los casos de profundidad de la
suite (22 decide / 24 ⇒ 503) siguen verdes **sin retocar un número**.

### (4) El techo de TAMAÑO baja a 691, con `factsModelBytes` en delta 0 · ✅

Verificado por los dos lados contra el servidor (`.claude/reproducciones/2i/ceiling.ts`):

```
techo aceptado por el servidor: 691 permisos
  factsModelBytes(691)   = 262125
  rechazo de 692: "model exceeds size limit: 262506 bytes vs 262144 bytes"
  servidor=262506 factsModelBytes=262506 delta=0
```

721 → **691** (−30, −4,2 %), y los tres números coinciden con el diseño al byte. El caso de la suite
que contrasta `factsModelBytes` con el servidor en cuatro formas de catálogo **sigue verde**, y los
casos A3 (289 permisos largos ⇒ 500; 230 ⇒ avisa al 80 %) también, **sin retocar números**.

### (5) Cuántos casos cambian de respuesta · ✅ exactamente 4, ninguno del juez

Medido con el modelo cambiado y ANTES de tocar ningún caso (SQLite + OpenFGA):

```
Tests  687 passed, 3 failed (690)
❯ facts · A1 — el servidor real acepta el modelo (c2) / la semántica de (c2): …
❯ facts · 3b-2b — el ciclo que FGA acepta (cruce 3) / un ciclo `parent` escrito a mano …
❯ facts · 3b-2b — el árbol del driver contra el servidor real / attached/moved/detached …
```

Tres, más el literal del modelo que ya había arreglado antes = **los 4 de §5.1 del diseño, y ni uno
más**. (690 y no 686 porque los 4 casos de I2 ya estaban dentro.) Qué se hizo con cada uno:

| Caso | Por qué falla | Qué se hizo |
|---|---|---|
| `A1 / el literal del plan` | compara con un literal escrito a mano | **reescrito** con `rooted` y el `can_<P>` anidado; es el caso que fija el modelo y tenía que cambiar a sabiendas |
| `A1 / la semántica de (c2)` | monta las tuplas a pelo, sin `syncAuthzCatalog` ⇒ sin marcador | **se añade el marcador al montaje**, y el comentario documenta por qué hace falta |
| `3b-2b / attached-moved-detached contra el servidor real` | igual, store montado a mano | **se añade el marcador al montaje** |
| `3b-2b / el ciclo que FGA acepta` | igual (el ciclo **cuelga** del árbol: nodo con dos padres, `app` y un descendiente) | **se añade el marcador**; el fail-open del ciclo colgado **sigue vivo y sigue documentado**, que es lo que se quería |

El cuarto no era «el ciclo huérfano» como suponía el diseño: en la suite ese ciclo **sí cuelga de
`app`**, así que es la variante que (c2r) **no** cierra (§6 del diseño) y solo le faltaba el
marcador. El ciclo **huérfano** —el que (c2r) sí cierra— no tenía caso: **se añade** (I7).

---

## 4 · Las cuatro cifras (y el «tope 3»)

Partida declarada: 686 / 688 / 860 / 860. Final:

| Modo | Antes | Ahora | Δ |
|---|---|---|---|
| `npm test` (SQLite memoria + OpenFGA) | 686 | **698 passed (698)** | +12 |
| `npm run test:sqlite-file` | 688 | **700 passed (700)** | +12 |
| `npm run test:pg` (PG 18) | 860 | **872 passed (872)** | +12 |
| `npm run test:mysql` (MySQL 8.4) | 860 | **872 passed (872)** | +12 |

Los 12 casos nuevos: 4 del marcador de raíz (I2), 5 del grupo (c2r) (I3, I4 A/B, I4 C/D, I5, I7),
2 de la ventana del relay (I6) y 1 del slug reservado en el núcleo. Ningún caso del juez.

`npx tsc --noEmit -p tsconfig.json`, `npm run typecheck`, `npm run check:purity` y `npm run build`:
**verdes**.

### Modo «tope 3» (`OPENFGA_LIST_*_MAX_RESULTS=3`, `:8103`)

Con la salida a fichero **desde la primera pasada**, como pidió el coordinador, y con margen para el
contenedor (espera activa al endpoint + 10 s):

```
tope3 pasada 1: Tests  698 passed (698)
tope3 pasada 2: Tests  698 passed (698)
tope3 pasada 3: Tests  698 passed (698)   (tanda anterior, mismo resultado)
```

**Cinco pasadas en total en este lote, cinco verdes. El rojo intermitente del 2h NO reapareció** en
tope 3. Logs conservados. Sigue sin identificarse; lo que este lote añade es que, con margen de
arranque, no se reproduce en 5 pasadas.

### PERO: hay OTRO rojo intermitente, y éste sí queda IDENTIFICADO

En la primera tanda de PG salió `871 passed, 1 failed (872)`:

```
❯ 3b-2h · las reproducciones del auditor R2, contra el servidor real /
  🟠 4 · un nodo con DOS padres se repara con `scopes.detached` + `attached` (y `moved` lo denuncia)
ℹ AssertionError: la carrera a padres distintos deja las dos aristas: expected 1 to equal 2
```

Medido: **2 fallos de 9 pasadas** del grupo en PG con este árbol; **0 de 6** en `0359b56` (con
`git stash`, mismo servidor, misma sesión) — o sea que es **timing**, no el cambio: el diff no toca
`reparent` ni `onScopeAttached`.

**El mecanismo, nombrado.** El caso lanza `Promise.allSettled([onScopeAttached(unit, orgA),
onScopeAttached(unit, orgB)])` y afirma que quedan DOS aristas. `reparent` es *Read-luego-Write* y
FGA no tiene compare-and-set, así que la carrera tiene **dos entrelazados igual de legales**:

- **(a)** los dos `Read` ven 0 padres ⇒ los dos escriben sin deletes ⇒ **dos aristas** (la deriva
  que el caso repara);
- **(b)** el segundo `Read` llega después del primer `Write` ⇒ ve 1 padre, lo trata como un `moved`
  (delete + write) ⇒ **una arista**.

Exigir (a) era **una aserción de moneda al aire en el artefacto publicado**, que es exactamente la
lección de 3G · Y1. **Arreglado sin perder lo que el caso juzga**: se afirma lo que de verdad es
cierto (1 o 2 aristas, los dos finales son legales) y el ESTADO que el caso repara —el nodo con dos
padres— **se garantiza** (si la carrera salió benigna, la arista que falta se escribe con el cliente
crudo, que es lo mismo que deja el otro entrelazado, o un operador con el SDK). Verificado: **6/6
verdes en PG** tras el arreglo, y **verde también forzando el entrelazado (b)** (mutante que
secuencializa las dos llamadas), o sea que la rama nueva se ejecuta y el caso sigue probando su
tesis.

---

## 5 · El juez contra `facts` (`AUTHZ_CONTRACT_FACTS=1`)

**SQLite** — antes (HEAD `0359b56`) y después, mismo comando:

```
HEAD  : Tests  771 passed, 2 failed (773)
        ❯ … / authorizeMany: … un scope que lanza ⇒ lanza entero
        ❯ … / scopes.detached purga los HECHOS del scope y SOLO los hechos …
        ℹ AssertionError: debería haber rechazado
        ℹ AssertionError: el nieto pierde su cadena y con ella todo: expected true to be false   ← R2-a

AHORA : Tests  783 passed, 2 failed (785)
        ❯ … / authorizeMany: … un scope que lanza ⇒ lanza entero
        ❯ … / scopes.detached purga los HECHOS del scope y SOLO los hechos …
        ℹ AssertionError: debería haber rechazado
        ℹ AssertionError: el del nieto conserva su hecho; el del scope purgado, no: expected [] to deeply equal [ Array(1) ]
```

**PostgreSQL 18**: `Tests 956 passed, 3 failed (959)` — R2-c (alias del uuid, árbol SQL), R2-b
(`authorizeMany`) y el mismo caso de `detached`.

**Lo importante y lo que hay que leer con cuidado:**

- **R2-a está CERRADO.** La aserción `assert.isFalse(await driver.authorize(alice, 'docs:read',
  unitA1x), 'el nieto pierde su cadena y con ella todo')` **pasa** con (c2r). Era la que el 2h dejó
  roja a propósito.
- **R2-b** (`authorizeMany` con un scope que lanza) y **R2-c** (alias del uuid, solo árbol SQL)
  **siguen pendientes, y es correcto**: no son de este lote.
- **El recuento no baja (2 en SQLite, 3 en PG) porque el MISMO caso, al avanzar, choca con una
  aserción posterior.** No es una regresión: estaba **tapada**. Ver §7.

El docblock de `factsHarness` en `tests/contract.spec.ts` —que enumeraba las cinco divergencias de
3b-2e· E6— queda **reescrito y honesto**: qué se cerró en 2f/2g/2i y qué sigue rojo hoy, con el
tercero explicado.

---

## 6 · Higiene

- **Stores en el `:8101`: 58 al empezar y 58 al acabar.** Ninguno con prefijo mío; el más reciente
  del servidor es del 2026-08-29 (anterior a esta sesión). Los scripts borran su store en el
  `finally` y los grupos de la suite en su `teardown`.
- **Contenedor `openfga-tiny` borrado** tras cada tanda de tope 3.
- **Bases**: cero `authz_test%` residuales en PG 18 y en MySQL 8.4 al terminar.
- **Reproducciones** (ignoradas por git) en `.claude/reproducciones/2i/`: `harness.ts`,
  `a2_escalada_within.ts`, `un_check.ts`, `depth.ts`, `ceiling.ts`. Verificadas ejecutables desde su
  ubicación final.
- **Diff**: `CHANGELOG.md`, `CLAUDE.md`, `README.md`, `src/drivers/openfga_driver.ts`,
  `src/drivers/openfga_facts.ts`, `src/errors.ts`, `src/identity.ts`, `src/openfga.ts`,
  `tests/contract.spec.ts`, `tests/openfga_facts.spec.ts`, `tests/scope_outbox.spec.ts`
  (11 ficheros, +945 / −51). **Sin commits.**

---

## 7 · Hallazgo NUEVO que este lote destapa (no lo arregla, y explica por qué)

> **`pruneOrphanRoles().stillGranting` es SIEMPRE `false` con el driver `openfga`, y su contrato
> dice «falso ⇒ no concede SEGURO».**

Al cerrarse R2-a, el caso del juez `scopes.detached … los roles locales sobreviven DORMIDOS` avanza
y llega por primera vez a la aserción que 3b-0b · AA1 añadió:

```ts
assert.deepEqual(
  seco.orphans.filter((o) => o.stillGranting).map((o) => o.role.uuid).sort(),
  [delNieto].sort(),
  'el del nieto conserva su hecho; el del scope purgado, no'
)
// AHORA: expected [] to deeply equal [ Array(1) ]
```

**La causa está localizada:** `stillGranting` = `assignments > 0`, y `assignments` sale de
`readLocalRoles()` (`src/catalog_cache.ts`), que **cuenta filas de `authz_assignments`**. En el
driver `openfga` los hechos **no viven ahí** — viven en el store (split de propiedad de datos). Así
que el barrido de plataforma dice «esto es basura inerte» justo antes de un borrado destructivo,
sobre roles que **sí están concediendo**. Es el fail-open de un marcador de seguridad operativa,
que es exactamente lo que AA1 se inventó para evitar.

**Por qué no lo arreglo aquí:**

1. **No lo causa (c2r)**: existe desde 3b-0b y es igual de cierto en modo `resolver` (allí no se ve
   porque sin `purgeRole` el juez se salta la API de delegación entera, 3E · P4). Este lote lo hace
   **observable**, que es lo contrario de romperlo.
2. **El arreglo es del PUERTO, no del modelo**: contar hechos por rol sin bajar a SQL exige o bien
   un método nuevo en `AuthorizationDriver` (algo como `countAssignmentsOfRole(uuid)`), o bien que
   `pruneOrphanRoles` enumere por el driver. Las dos cosas son **breaking para drivers de terceros**
   y son decisión del dueño, no de un lote que implementa un diseño ya firmado.
3. La regla del encargo era explícita sobre qué rojos del juez quedaban pendientes (R2-b y R2-c).
   Éste es un tercero, y **prefiero nombrarlo que arreglarlo a escondidas**.

**Recomendación**: que entre en el lote de bugs junto a R2-b/R2-c. Mientras tanto queda escrito en el
docblock de `factsHarness` (que es lo que lee quien corre el juez) y aquí.

---

## 8 · Lo que NO hice, y por qué

1. **No toqué `provisionOpenFgaStore` / `openfga:provision` para escribir el marcador.** El diseño
   (§4.2) lo propone como uno de los tres sitios, pero **en el árbol de hoy esa herramienta publica
   el modelo del modo `resolver`** (`openFgaAuthorizationModel`), no el de `facts`: nunca crea un
   store en el que `rooted` exista. Añadirle un modo `facts` es una feature nueva (bandera del
   comando, qué permisos publica, de dónde saca el catálogo) sin caso que la dirija. El marcador
   queda con **un** escritor automático, `projectCatalog`, que es el que cubre el caso operativo real
   (añadir un holderType), y con **el deber escrito** para `authz:reconcile` (3b-3). Está dicho en el
   CHANGELOG como paso de migración: *republicar el modelo y correr `authz:catalog:sync`*.
2. **No implementé los dos deberes de `reconcile`** (reportar el marcador ausente; listar los scopes
   no alcanzables desde `app`): son de 3b-3, que aún no existe. Quedan escritos en CLAUDE.md, en el
   README (como la herramienta de diagnóstico que se le promete al consumidor) y en el CHANGELOG.
3. **No arreglé el hallazgo de §7** — motivos arriba.
4. **No toqué R2-b ni R2-c**: fuera del lote por el encargo.
5. **No arreglé el fail-open del ciclo COLGADO del árbol** (nodo con dos padres): §6 del diseño dice
   que (c2r) no lo cierra, la mitigación sigue siendo el anti-ciclos del paquete, y su caso sigue
   documentándolo. Lo que sí se añade es el caso hermano del ciclo **huérfano** (I7).
6. **No cambié `FACTS_MAX_RESOLVE_DEPTH` ni `FACTS_MODEL_MAX_BYTES`**: remedidos, no se mueven.
7. **No añadí un caso al conteo del juez** (`contract_harness.spec`): ningún caso nuevo es del
   contrato de drivers, así que los conteos declarados (36/49/66/75…) no cambian y no hubo que
   tocarlos.
8. **No llevé la expansión de ortografías a `revoke`/`removeDeny`** (pendiente declarado del 2h):
   sigue pendiente y sigue sin reproducción que lo dirija.
