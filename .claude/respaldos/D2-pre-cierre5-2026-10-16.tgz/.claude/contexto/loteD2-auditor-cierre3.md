# Sublote D2: repaso adversarial del cierre 3 (auditor, 2026-10-16)

**Árbol:** `main` sobre `75353fe`, con D2 y los cierres 1, 2 y 3 sin commitear.

**Cómo trabajé**
- Solo lectura sobre el repo. Escribí este fichero y un script, `.claude/reproducciones/loteD2-auditor-cierre3.ts` (C3-1…C3-4).
- El script usa SQLite `:memory:` y stores efímeros `aud-d2c3-*` en `:8090`, que borra al terminar. Comprobado: no quedan stores `aud*`.
- Sin docker restart, sin gates y sin `test:pg|mysql`.

**Cómo se ejecuta**

```
source ~/.config/nvm/nvm.sh && nvm use 22
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre2-fga.ts
node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre2-orden.ts
OPENFGA_URL=http://localhost:8090 node --import @poppinss/ts-exec .claude/reproducciones/loteD2-auditor-cierre3.ts
```

## Veredicto en una línea

**NO APTA.**
- C2-1…C2-5 están cerrados en efecto.
- Pero el cierre 3 solo cerró el subconjunto «YA vencida en `now`» del mecanismo de C2-1.
- La misma portadora, **viva pero con una caducidad más corta que la del origen**, sigue saliendo como `renewal-unsafe` mientras el allow sí se escribe. Cuando vence la caducidad vieja, el destino `openfga` concede a un sujeto que el origen deniega (🟠 C3-1, medido).
- La fuerza bruta con vigencia no lo ve: evalúa un único `now` y nunca el horizonte de lo que deja sin renovar.

---

## 1. C2-1…C2-5: re-ejecución de mis reproducciones

`loteD2-auditor-cierre2-fga.ts` contra `:8090`:

| Repro | Antes (cierre 2) | Ahora |
|---|---|---|
| R1 | 409, sin hueco | 409 `E_AUTHZ_RENEWAL_UNSAFE`, `gap: []`, `after: false` |
| R2 | `renewal-unsafe` | `["destino:renewal-unsafe"]`, `updated 0`, el destino niega |
| R3 (TOCTOU) | 409 mudo | `409 E_AUTHZ_RENEWAL_UNSAFE partial=true`, final `false` |
| R3, 2.º `Write` caído | — | `503 partial=true`, final `true` (persistente, ahora anotado: ver §5) |
| R4 | `renewal-unsafe`, el destino concede para siempre | dry y real `written 2, updated 0, reasons []`, `destAfter false`, 2.ª pasada `written 0` |
| R5 | el prefijo 1 concedía | `relate(member group) ⇒ false ; relate(viewer) ⇒ false` |
| R6 | 409 | sin error |
| R7, `database` y `openfga` | `g` primero y concedía | `h ⇒ false ; g ⇒ false`, `orderResidue []` |

`loteD2-auditor-cierre2-orden.ts`:
- O3 sigue con `bad: null`.
- O4 da 4 194 304 pares con `unsafeNoResidue: 0`.
- O1/O2 son puros (solo presencia, sin `planPartition`), así que siguen mostrando el orden de presencia. Es lo esperado: la regla de vigencia vive en el plan, no en `relationTransitionOrder`.

**C2-1, C2-2 (en su universo), C2-3, C2-4 y C2-5: cerrados en efecto.** Lo que queda abierto es la generalización del mecanismo, abajo.

## 2. `liveInDestination`: la frontera `now`

**Empate exacto** (C3-4, reloj inyectado)
- `isActiveExpiry` es estricta (`>`). Coincide con la condición de FGA (`current_time < valid_until`) y con `whereActive` de `database`.
- Con el reloj del driver en `T-1`: la renovación de una portadora con `expiresAt = T` da 409. En `T`: se reescribe sin comprobar. Es coherente.

**Tuplas que vencen ENTRE el plan y la aplicación, o después:** sí pasan a conceder. Es el 🟠 C3-1.
- El caso extremo es que venzan durante la pasada.
- El general es que venzan cualquier día después: la caducidad vieja que `renewal-unsafe` deja intacta es la que manda.

**Relojes distintos** (paquete frente a servidor FGA)
- El plan y la guarda de `relate` usan el reloj del paquete; la conectividad, el `current_time` del servidor.
- C3-4 lo enseña de rebote. Con el reloj del driver adelantado hasta `T`, `relate` reescribe con delete + write una portadora que el SERVIDOR aún tiene viva, y lo hace sin comprobar portadora. Hay hueco de dos `Write`.
- Con desfase NTP (milisegundos) solo afecta a tuplas que vencen justo dentro de ese desfase, y la ventana es de milisegundos: ⚪, sin hallazgo propio.
- Con un `config.clock` de test en un despliegue real sería mayor. Es un mal uso documentado.

## 3. `expiredDelete`: borrado previo y fuera de orden

**¿Borra algo vivo?** Solo si el reloj del paquete va por delante del servidor y la tupla vence dentro de ese desfase.
- En ese caso, un deny sobrante «vencido para el plan» pero vivo para el servidor se borra ANTES que los allows sobrantes que cortaba.
- La ventana es del orden del desfase: ⚪.
- La pasada corre bajo el freeze durable, así que ningún `relate` del manager puede revivir una tupla del destino entre el plan y el borrado.

**¿Un deny vencido que el origen renueva?**
- La sobrante solo entra en `expiredDelete` si el origen NO tiene la clave (`sourceByKey.has` la excluye antes). Un deny vencido que el origen tiene vivo va por `denyWrite`, no por el borrado previo.
- En `database`, `deny` lo rehace permanente (`#upsert` con `requested = null`).
- En `openfga`, si ese deny es CONDICIONAL (escrito a mano), la reescritura falla y la pasada escribe el allow igualmente: 🟡 C3-2, medido. Es preexistente (camino `denyUpdate` del cierre 1); el cierre 3 solo lo movió a `denyWrite`.

## 4. La fuerza bruta con vigencia: ¿modela plan y apply reales?

**Modela fielmente:**
- La derivación del plan, por el mismo `liveInDestination`.
- El contexto (`sourceTuples ∪ vivas del destino`).
- El borrado de vencidas fuera del orden.
- `renewal-unsafe` vía `denyCarrierGroups` y el hueco de dos `Write` como prefijo.

**Omite tres cosas.** La primera produce un contraejemplo real fuera del universo:

1. **El horizonte temporal.**
   - El oráculo evalúa cada prefijo y el final en el MISMO `now`.
   - Una portadora `renewal-unsafe` queda en el final con su caducidad VIEJA (`expiry.live` = now+1h), mientras el origen dice `other` (now+2h). El bit de presencia coincide (`mask === final`), pero entre now+1h y now+2h el destino deja de transportar el deny y el allow escrito concede.
   - La propiedad «el final es el del origen» es falsa en el tiempo, y el universo no lo puede ver.
   - Contraejemplo: C3-1.
2. **Escrituras de deny que fallan.** El universo da por hecho que `deny` siempre entra. En `openfga` un deny condicional preexistente no se puede rehacer: la pasada lo lista y sigue con los allows (C3-2).
3. **El desfase de relojes** plan/servidor (⚪, §2).

`malformed = 0` y «0 sin residuo» son ciertos para lo que modela. La frase del README («Validity is part of the universe … 0 grant without a declared residue») es cierta en `now`. No dice que `renewal-unsafe` deja una concesión diferida.

## 5. C2-3: re-comprobación y rama `carriedDenyUnknown`

Medido en C3-3, inyectando un fallo en TODA lectura posterior al 2.º `Write`:

| Situación | Resultado | Estado final |
|---|---|---|
| Los dos `Write` entran, la re-lectura falla | `503 E_AUTHZ_BACKEND_UNAVAILABLE partial=true carriedDenyUnknown=true`, nota «SE APLICÓ, pero la re-comprobación falló» | niega (el deny concurrente sí está) |
| El 2.º `Write` cae y la re-lectura también | `503 partial=true carriedDenyUnknown=true`, nota «quedó BORRADA … también falló» | concede (el caso persistente), con receta |

- Ninguna rama sale como éxito y ninguna es un `false` silencioso: **sin fail-open**.
- Una renovación de una membresía YA vencida (`guarded = false`) no re-comprueba. Es correcto: esa membresía no transportaba nada durante el hueco.
- Higiene: ⚪ C3-3.

## 6. C2-5 en roles

- `replaceAssignment` marca parcial solo el fallo del 2.º `writeTuples`. El fallo del delete sigue siendo «no escrito», que es correcto.
- `#write` notifica `indeterminate` UNA vez, tanto para timeout como para parcial: el timeout marcado parcial no notifica dos veces.
- Los otros usos de `#write` son `revoke`/`deny`/`removeDeny`, `purgeScope` (detached en línea y en el relay) y la delegación. Ningún driver del paquete marca parciales ahí, y un driver de terceros que lo haga recibe ahora el `indeterminate` que el invariante 13 ya le exigía. **Sin regresión.**
- Preexistente, fuera del brief (⚪ C3-4): `purgeScope` del driver `openfga` de ROLES borra por lotes de `PURGE_BATCH_SIZE` (`openfga_driver.ts:~2091`) sin `markPartialWrite`. El gemelo de relaciones sí la pone (`openfga_relations_driver.ts:1363`).

---

## Hallazgos (por severidad)

### 🟠 C3-1 · Portadora VIVA con caducidad más corta que la del origen: `renewal-unsafe` la deja con la caducidad vieja, el allow se escribe, y al vencer la vieja el destino `openfga` concede a un denegado

**Escenario**
- **Precondición:**
  - Origen `database`: `deny(H#member, viewer, X)`, U ∈ H hasta mañana y allow directo `U viewer X`.
  - Destino `openfga`: el mismo deny y U ∈ H **viva** con caducidad +6 s (una pasada anterior; el admin extendió después la membresía en el origen); sin el allow.
- **Acción:** `authz:relations:reconcile` (database → openfga, la dirección del cutover), `--dry-run` y real.
- **Resultado (C3-1, `:8090`):**
  ```
  originCheck false
  dry  { written 1, updated 0, reasons [destino:renewal-unsafe] }
  real { written 1, updated 0, reasons [destino:renewal-unsafe] }
  destJustAfter false · (7 s) destAfterOldExpiry TRUE
  2.ª pasada { written 1 } · destAfter2 false
  ```
  - Control con destino `database` (`atomicRenewal`): `updated 1`, `destAfterOldExpiry false`.
  - El allow que la pasada escribe solo está cortado por un deny que llega a través de una membresía que la pasada se ha negado a extender.
  - Cuando vence la caducidad vieja (6 s aquí; en la vida real, días), el destino concede.
  - Solo converge si otra pasada corre DESPUÉS de la caducidad vieja. Tras el cutover, una pasada hacia el driver activo es `E_AUTHZ_STALE_SOURCE_REFUSED`.

**Evidencia**
- ✅ C3-1.
- ✅ `reconcile.ts` `planPartition`: el bucle `renewalUnsafe` saca la portadora de `toUpdate` y no toca `toWrite`.
- ✅ `order_bruteforce.ts`: el final se evalúa en el mismo `now` (`expiry.live` frente a `expiry.other`, el bit de presencia es el mismo).

**Steelman del defensor:** «es ruidoso: exit ≠ 0 en cada pasada mientras no venza, con receta (`unrelate` + `relate`), y el runbook verifica antes del switch».
- **¿Me convence?** No.
- Es exactamente la defensa de C2-1, que el cierre aceptó como 🟠.
- La letra sigue atribuyendo el riesgo solo a la ventana («entre los dos el deny no alcanzaría al sujeto. No se renueva»). Un operador que acepta el residuo cree que el destino queda MÁS restrictivo (conserva la membresía vieja), cuando en una EXTENSIÓN queda menos restrictivo a partir de una fecha.
- Hoy no concede: concede la semana que viene, sin ninguna pasada de por medio. Y el cierre 2 convirtió aquí una ventana de milisegundos en una concesión diferida.

**Mitigación mínima:** si `renewal-unsafe` es una EXTENSIÓN (la del origen es posterior o `null`), la partición no escribe los allows que ese deny corta, o se niega entera con cero escrituras. La línea dice la fecha a partir de la cual el destino concedería. En la fuerza bruta, evaluar además el final en el horizonte (las `renewal-unsafe` vencidas).

### 🟡 C3-2 · Deny CONDICIONAL vencido en el destino `openfga` y vivo en el origen: la pasada no puede rehacerlo, lo lista, y escribe el allow igual; `--dry-run` y la real dan números distintos

**Escenario**
- **Precondición:**
  - Origen: `deny(U, viewer, X)` y `U viewer X`.
  - Destino `openfga`: `denied_viewer@U` escrito a mano con `not_expired` ya vencido. El modelo lo admite: `denied_<rel>` acepta `with not_expired`.
- **Acción:** reconcile.
- **Resultado (C3-2):**
  - `dry { written 2, reasons [] }` frente a `real { written 1, reasons [destino:deny-conditional] }`.
  - `destBefore false → destAfter TRUE`, `originCheck false`.
  - La letra dice «el deny sigue negando mientras viva», y está muerto.

**Evidencia**
- ✅ C3-2.
- ✅ `applyPartition`: la rama `denyConditional` hace `continue` y los allows siguen.
- Preexistente desde el cierre 1 (antes iba por `denyUpdate`). La fuerza bruta no lo modela.

**Steelman del defensor:** «solo existe escrito a mano en FGA; es ruidoso (residuo, exit ≠ 0)».
- **¿Me convence?** Para la severidad, sí: configuración inusual ⇒ 🟡.
- No para la paridad: `--dry-run` no lo detecta, lo que rompe «mismos números en dry y real», y el verificador del runbook es justo el `--dry-run`.

**Mitigación mínima:**
- En el plan, un deny del destino con caducidad (viva o vencida) que el origen tiene es una negativa de la puerta del deny (500, cero escrituras) o un residuo decidido en el PLAN.
- Si se mantiene como residuo, los allows que corta no se escriben.

### ⚪ C3-3 · El mismo `code` 409 `E_AUTHZ_RENEWAL_UNSAFE` significa «cero escrituras, aplica la receta» y «se aplicó»

- **Escenario:** un consumidor que automatiza la receta del 409 (`unrelate` + `relate`) ante `.raced` re-abre la ventana con el deny ya dentro del grupo. Esa es justo la operación insegura.
- **Evidencia:** ✅ R3 (`409 … partial=true`) y `RenewalUnsafeError.raced`. Se distinguen solo por `renewalApplied`/`isPartialWrite`.
- **Steelman del defensor:** «la letra y `renewalApplied` lo dicen». Me convence: ⚪.
- **Mitigación:** un `code` propio para `.raced`, o documentar que la receta solo vale si `renewalApplied !== true`.

### ⚪ C3-4 · (preexistente, fuera del brief) `purgeScope` de roles en `openfga` es multi-lote sin `markPartialWrite`

- **Escenario:** un fallo en el lote 2 tras borrar el 1 da un 503 sin `indeterminate`.
- **Por qué no es grave:** el orden fijo (estructura, hechos, denies) deja denies de más, así que es fail-closed.
- **Evidencia:** ✅ `openfga_driver.ts:~2091`.
- **Mitigación:** la misma marca que relaciones (`#partialIfDeleted`).

## Lo que intenté y NO se rompió

- R1–R7 y O3/O4 del cierre 2: todos en el sentido correcto.
- Empate exacto `expiresAt == now`: coherente en el plan, en el driver y en FGA (C3-4).
- `expiredDelete` frente a un deny vencido que el origen renueva: nunca entra en el borrado previo (`sourceByKey` lo excluye).
- C2-3, rama `carriedDenyUnknown` en sus dos variantes: ruidosa y marcada parcial; ningún éxito falso.
- C2-5: evento único, sin doble notificación, sin regresión en el resto de `#write`.
- Stores: cero residuos `aud*`.

## Preguntas abiertas para el arquitecto

1. 🟠 C3-1: ¿una `renewal-unsafe` por EXTENSIÓN retiene los allows que su deny corta (o niega la partición), o se acepta como residuo con la fecha en la letra? Sin una de las dos cosas, la APTA no es posible: es la misma clase que C2-1.
2. 🟡 C3-2: ¿un deny condicional del destino se decide en el PLAN (paridad dry/real)?
