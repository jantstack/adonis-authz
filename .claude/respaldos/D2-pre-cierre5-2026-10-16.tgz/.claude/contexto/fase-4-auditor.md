# Fase 4 · `relations/` — AUDITORÍA ADVERSARIAL (atacante)

> Base: `main` @ `76c5846`. Audito el PLAN `.claude/contexto/fase-4-plan.md` (nada implementado aún).
> Reproducido contra `:8101` (OpenFGA v1.19) con el generador REAL `openFgaFactsModel`. Stores creados
> (`audit4_*`) borrados; `:8101` a 0 stores al cerrar.

## Veredicto en una línea

**Inseguro tal cual — hay que cambiar el plan antes de implementar.** Un 🔴 EXPLOTABLE reproducido contra el
servidor: `relate()`, tal como el plan lo especifica (gramática + partición-por-string + cotas FGA 50/256),
puede escribir una tupla `role_binding:<scopeKey>|<roleUuid>#assignee@<atacante>` y hacer que `roles.authorize`
(`can_<P>`) devuelva `true`. La frontera roles↔relations que el paquete promete **no la cierra ninguna pieza
del plan**: la cierra por accidente el número de segmentos del id (protege `scope`/`role`) y NADA protege
`role_binding`. Falta el invariante que el plan da por hecho en §5: **`relate`/`unrelate` tienen que rechazar
todo `object.type` y `relation` que no estén declarados en `defineRelationsConfig`.**

---

## Hallazgos (ordenados por severidad)

### 🔴 1 · `relate()` puede escribir en `role_binding#assignee` y conceder en `roles.authorize`

- **Escenario (precondición → acción → resultado):**
  - Precondición: existe un grant legítimo del rol `R` (que vincula el permiso `p0`) en el scope
    `S = unit|<partUuid>` (o en un ANCESTRO, incluida `app`). Es lo normal: en el store viven ya
    `scope:S#binding@role_binding:S|R`, `role_binding:S|R#role@role:R` y `role:R#permits_p0@user:*`.
  - Acción: el atacante llama `relate(subject={type:'user',uuid:'evil'}, relation:'assignee',
    object={type:'role_binding', id:'<R>'}, partition={type:'unit', uuid:'<partUuid>'})`.
    El driver compone el id del objeto igual que para un `document`: `<object.type>:<scopeKey(partition)>|<object.id>`
    = `role_binding:unit|<partUuid>|<R>` — **byte a byte el id del binding real** (`role_binding` tiene la forma
    `<scopeKey>|<roleUuid>`, con un `|` interno del propio `scopeKey`, así que la partición encaja como los dos
    primeros segmentos).
  - Resultado: `check(user:evil, can_p0, scope:S)` = **`true`**. Una escritura de `relations/` acaba concediendo
    en `roles/`. Rompe F-01/F-02 y el invariante de frontera de CLAUDE.md.
- **Evidencia:** ✅ medido contra `:8101`
  (`scratchpad/audit4_boundary.ts`). Salida literal:
  ```
  CONTROL alice can_p0@S = true
  id compuesto por relate = role_binding:unit|11111111-…-1111|22222222-…-2222 === binding real? true
  1a assignee SIN condicion vía relate ⇒ ACEPTADO
  ATAQUE evil can_p0@S = true   (true ⇒ relate cruzó a roles.authorize)
  ```
  Nota clave: el comentario del modelo dice `assignee: [<holders> with not_expired]`, pero el código
  (`openfga_facts.ts:334`, `directWithExpiry`) declara `directly_related_user_types` con la forma PLANA **y**
  la condicionada. Por eso una tupla `assignee` SIN condición (lo que un `relate` de tuplas planas escribe)
  **se acepta y concede sin caducidad** — no hay «protección por condición» que salve la frontera.
- **Qué NO protege (medido/razonado):**
  - `scope#denied_<P>` y `scope#binding`: NO alcanzables. Los ids de `scope` son de 1–2 segmentos
    (`app` / `unit|<uuid>`) y la composición de `relate` mete la partición como segmento extra
    (`scope:unit|<partUuid>|<obj>`, 3 segmentos) ⇒ nunca coincide. Protección **accidental** por conteo de
    segmentos, no por diseño.
  - `role#permits_<P>`: NO alcanzable (id `role:<uuid>`, 1 segmento; la composición añade partición).
  - `role_binding#assignee` y `role_binding#role`: **SÍ alcanzables** — el id del binding es
    `<scopeKey>|<roleUuid>` = 3 segmentos para scopes no-raíz, y 2 para roles a nivel `app`
    (`role_binding:app|<roleUuid>`), que es justo lo que compone `relate(partition=APP_SCOPE, object.id=<roleUuid>)`.
    En **mono-tenant** (partición `app`, recomendado por el plan) el atacante se une a CUALQUIER binding de nivel
    `app` ⇒ escalada global.
- **Steelman del defensor:** «`relate` solo se llamará con tipos `document`/`group`; el consumidor no pasa
  `role_binding`.» → **No me convence.** El paquete vende la frontera como garantía frente a entrada
  malformada (para eso están F-01…F-04 y el throw de partición). Si la defensa es «el consumidor se porta
  bien», entonces F-01/F-02 sobran y la promesa «una tupla de relación no concede en roles» es falsa en cuanto
  el `object.type` viaja desde una request. Además R-12 valida GRAMÁTICA, y `role_binding`/`assignee` son
  gramaticalmente válidos.
- **Mitigación mínima:** `relate`/`unrelate` (ambos drivers) rechazan con 422 todo `object.type` que no esté en
  los tipos declarados por `defineRelationsConfig` y toda `relation` que no esté declarada para ese tipo — y el
  namespace de ids de relaciones se demuestra DISJUNTO de los ids de `facts` (nunca `role_binding`/`scope`/`role`);
  caso de contrato en los dos drivers.

### 🟡 2 · Purga con alias de la PARTICIÓN — residuo que sobrevive a un `purgeObject` «exitoso»

- **Escenario:** el consumidor guarda el uuid de la partición (un scope) en una columna que funde
  `dashless↔dashed` (tipo `uuid` de PG, `char(36) *_ci` de MySQL). `relate(...partition={unit, <dashless>})`
  escribe `document:unit|<dashless>|<obj>`. Más tarde `purgeObject(doc, partition={unit,<dashed>})` demuestra
  cero sobre la ortografía con guiones y **lanza `true` (purga completa) mientras la tupla `dashless` sobrevive**
  y sigue concediendo la relación. Es el mismo patrón que el 🟠 3 de 3b-2h (auditor R2): en LECTURA el alias es
  fail-closed, en ESCRITURA/purga es fail-open (residuo que nadie borra).
- **Evidencia:** 🟡 razonado. `assertScope` acepta las dos ortografías (`identity.ts`: gramática del uuid
  `[a-z0-9_.-]+`, solo mata mayúsculas). El plan §1 dice explícitamente que la partición **NO se resuelve** con
  `resolveChain`, así que NO hay ortografía canónica y NADA aplica `scopeSpellings` a la partición en `purge*`.
  Precondición más estrecha que en `facts` (allí el split canónico-vs-llamante lo metía el propio paquete; aquí
  hace falta que el consumidor sea inconsistente), por eso 🟡 y no 🟠.
- **Steelman:** «El consumidor pasará siempre la misma ortografía.» → **A medias.** Es exactamente la asunción
  que 3b-2h desmintió; y si el consumidor reutiliza para la partición el mismo `ScopeRef` que ya pasa por
  `resolveChain` en `roles/`, el split reaparece. El paquete no puede delegar la frontera de tenant a la
  disciplina de tipeo del consumidor.
- **Mitigación mínima:** o `purgeObject`/`purgeSubject` aplican `scopeSpellings` a la partición (barren las dos
  ortografías), o el plan exige una única ortografía canónica del uuid de partición (gramática más estricta que
  prohíba la forma sin guiones), fijado con caso.

### 🟡 3 · Republicar el modelo sin la config de relaciones lo deja inconsistente con sus tuplas

- **Escenario:** store compartido (recomendado, §0.4). `defineRelationsConfig` publica el modelo fusionado V2
  (con tipo `document`) y `relate` escribe tuplas `document`. Después, en OTRO proceso/camino, `syncAuthzCatalog`
  reconstruye y republica el modelo — y si esa ruta no lee la config de relaciones de una fuente DURABLE
  compartida (la tiene solo en memoria del proceso que llamó `defineRelationsConfig`), republica V3 **sin** el
  tipo `document`. Las tuplas `document` quedan referidas a un tipo que el modelo ya no declara.
- **Evidencia:** 🟡 razonado. El plan §0.4 afirma que «todo `syncAuthzCatalog` Y todo `defineRelationsConfig`
  republican el modelo entero», pero NO especifica de dónde saca `syncAuthzCatalog` la config de relaciones ni
  que viaje bajo el gate de versión compartida (invariante 14). Es fail-closed para relaciones (los `check`
  fallan), no un bypass — de ahí 🟡; pero es «el store con un modelo y las tuplas de otro» que pregunta el encargo.
- **Steelman:** «La config de relaciones se persiste y toda ruta la lee.» → Me convence SI el plan lo dice.
  Hoy no lo dice; hay que fijarlo.
- **Mitigación mínima:** la config de relaciones se persiste (como el catálogo) y **toda** ruta que republica el
  modelo la lee de esa fuente durable bajo el mismo gate de versión (invariante 14); el gate de bytes fusionado
  (§0.1) corre sobre ese estado combinado. Caso: republicar desde un proceso sin `defineRelationsConfig` en
  memoria NO puede dejar caer los tipos de relaciones.

### ⚪ 4 · Tipo de objeto de relaciones que colisiona con un tipo de `facts` ⇒ 400 opaco del servidor

- **Escenario:** el consumidor declara en `defineRelationsConfig` un `objectType` llamado `scope`,
  `role_binding`, `role`, `group`, `user`, `admin` o `integration`. El modelo fusionado tiene tipos duplicados.
- **Evidencia:** ✅ medido (`scratchpad/audit4_duptype.ts`): OpenFGA rechaza con
  `an authorization model cannot contain duplicate types` (**fail-closed**, bien) — pero el `sync` entero se cae
  con un 400 de motor en vez de un 422 del paquete que nombre la colisión. El driver `database` NO tiene esta
  defensa (los guarda como filas de `authz_relations`), así que además es una **divergencia de paridad**
  (openfga rechaza, database acepta).
- **Steelman:** «`defineRelationsConfig` validará los nombres.» → De acuerdo, pero el plan no lo lista.
- **Mitigación mínima:** `defineRelationsConfig` rechaza (422) todo `objectType`/relación reservado por `facts`
  (`scope`, `role`, `role_binding`, `group`, holder types) y aplica `RESERVED_SLUGS`/`RESERVED_SLUG_PREFIXES`
  a las relaciones de objeto; mismo 422 en ambos drivers (paridad).

### ⚪ 5 · El id de relaciones tiene DOS separadores `|` — fijar el parseo de partición

- **Escenario:** `document:<partitionKey>|<uuid>` con `partitionKey = <tipo>|<uuid>` ⇒ el id lleva **dos** `|`
  (`document:unit|<partUuid>|<objUuid>`). Un parser que asuma «un separador» extrae mal la partición.
- **Evidencia:** ⚪ razonado. No es explotable hoy (los componentes no admiten `|`/`#`/`:` por `assertComponent`,
  así que no hay inyección de separador), pero el plan describe la comparación de partición «por string» sin fijar
  el parseo, y el `role_binding` del 🔴 1 demuestra que la ambigüedad de segmentos es justo por donde entra el fallo.
- **Mitigación mínima:** el plan fija el parseo canónico (partición = todo menos el ÚLTIMO segmento; el objeto no
  contiene `|`) y un caso que lo verifique con partición no-raíz.

---

## Lo que intenté y NO se rompió

- **Falsificar la partición por igualdad de string entre dos tenants distintos.** Imposible con `assertScope`:
  dos uuids distintos dan strings distintos; el alias `dashless↔dashed` afecta al MISMO uuid (fail-closed para
  aislamiento, no fuga). La comparación por string exacto del plan resiste el cruce fail-OPEN entre particiones
  (el residuo de purga del 🟡 2 es otra cosa).
- **Inyección de separador (`|`/`#`/`:`) en un id de objeto/userset o en un componente de partición.** Bloqueado
  por la lista blanca de `assertComponent` (`identity.ts`): ningún componente serializa esos caracteres.
- **Alcanzar `scope#denied_<P>` (fabricar un deny ajeno) o `scope#binding`/`role#permits_<P>` vía `relate`.** No
  alcanzables: el conteo de segmentos del id compuesto no coincide con el de esos tipos (protección accidental,
  no de diseño — ver 🔴 1).
- **Tipo de objeto duplicado con un tipo de `facts`.** OpenFGA lo rechaza (fail-closed); no clobbera `can_<P>`
  ni `rooted` (⚪ 4).
- **Dirección roles→relations (un `grant` crea una relación).** No: las escrituras de `roles/` solo producen ids
  `scope`/`role`/`role_binding`, nunca `document`/`group`. F-02 se sostiene por construcción.
- **Profundidad y «un Check».** No los reauditué (el analista los midió 22/25 sobre el fusionado y el
  tester-contrato los cubre); no vi nada que los mueva.

---

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. **¿`relate`/`unrelate` van a hacer whitelist de `object.type`+`relation` contra `defineRelationsConfig`?**
   Sin ese invariante NUEVO (no está en el plan), el 🔴 1 es explotable en cuanto un binding exista en el scope
   o un ancestro. Es lo que reabre el diseño.
2. **¿La config de relaciones se persiste y viaja bajo el gate de versión (invariante 14)?** De ello depende el
   🟡 3 (modelo republicado que deja caer los tipos de relaciones).
3. **¿La partición se canoniza o se prohíbe la forma sin guiones?** Decide si el 🟡 2 (residuo de purga) hereda o
   no el fail-open de 3b-2h.

---

## Redacción exacta para cerrar el 🔴 1 (para pegar en el plan, §5)

> **F-05 (frontera de ESCRITURA, ambos drivers, bloqueante):** `relate`/`unrelate` rechazan con 422
> `E_AUTHZ_RELATION_TYPE_UNKNOWN` todo `object.type` que no esté declarado en `defineRelationsConfig` y con 422
> `E_AUTHZ_RELATION_UNKNOWN` toda `relation` que no esté declarada para ese tipo. La gramática (R-12) y la
> partición-por-string son insuficientes: en el store compartido los tipos de `facts` (`role_binding`, `scope`,
> `role`) viven en el MISMO espacio de ids, y la composición `<type>:<scopeKey(partition)>|<id>` reproduce byte a
> byte el id de un `role_binding` real (`<scopeKey>|<roleUuid>`) cuando `partition` es el scope del binding (o
> `app`). Caso positivo: `relate(evil, assignee, {type:'role_binding', id:<roleUuid>}, partition=S)` ⇒ 422 y
> `check(evil, can_<P>, S)` sigue `false` con el binding legítimo intacto. Medido: sin este gate,
> `check(evil, can_<P>, S) = true` (auditor Fase 4).
