# Fase 2 · Lote 2E — informe de implementación (2026-08-28) — CIERRE

Rama `v2/fase-0` sobre `4346bcc` (**sin commits**; el commit lo hace el dueño). Node 22.23.2, OpenFGA `:8101`
(v1.19.0) y servidor efímero tope 3 (`openfga-tiny`, `:8103`, memoria; **eliminado al terminar**). Sin `skip`/`only`
(grep = 0). `npm run typecheck` verde. Spec: `.claude/contexto/fase-2-correcciones-2e.md` (H1–H4 bloqueantes, I1–I7).
Regla cumplida: rojo→verde por pieza con el fallo real anotado; tras cada pieza `typecheck` + `npm test` +
`OPENFGA_TEST_URL=http://localhost:8101 npm test`; al cierre, tope 3. No llegaron hallazgos H5+ del code-review.

## Conteo de tests por configuración

| Momento | `npm test` (SQLite) | `:8101` | tope 3 (`:8103`) |
|---|---|---|---|
| HEAD `4346bcc` + parche del tester (H4) | 250 | 332 | — |
| tras H1 | 252 | 335 | — |
| tras H2 | 254 | 337 | — |
| tras H3 + I2 | 255 | 338 | — |
| tras I1 + I3 | 257 | 340 | — |
| tras I5 (tercer harness `database (sin listDenies)`, 55 casos + 1 del harness) | 313 | 396 | — |
| **cierre (docs I4/I6/I7)** | **313 ✅** | **396 ✅** | **396 ✅** |

Casos del juez: 36 core / 49 en 2.0 / **61** en 2.1 con `listDenies: true` (**55** con `listDenies: false`);
`contract_harness.spec` actualizado y con un test nuevo del par. La línea `authz: seguridad opt-in sin activar` ya no
aparece en la salida de la suite (I5: faltaba `warnOnOptInSecurity: false` en UNA config de `manager.spec`, l. 868).

## Rojos de partida (scripts del auditor, `scratchpad/v4/`, `node --import @poppinss/ts-exec`)

- **H1** `a5_move_steal.mjs` (`database`): `antes: false` → `scopes.moved(unit de B → orgA, within: orgA) ⇒ ACEPTADO` →
  ` FALLA después: authorize(mallory, docs:read, unit de B) = true`. (La rama `openfga` del script revienta en
  `d.onScopeAttached is not a function`: el driver openfga no implementa ese hook; bug del script, no del paquete.)
- **H2** dos procesos `node` reales sobre `shared.sqlite` + FGA `:8101` (`c5_reader.mjs` / `c5_writer.mjs`, bump con el
  `db` global antes del `DELETE`): `[A] fase 2 (tras la escritura ajena) #0/#1/#2: true, true, true` (`c5_A_red.log`).
- **H3** `f9_view.mjs` «reloj hacia ATRÁS con la vista viva»: ` FALLA … la vista de 20 ms responde true`;
  `c_catalog_fga.mjs` C2 (en el informe del auditor): `tras 2 ventanas con el reloj atrasado: true/true`.

## Piezas (rojo × estado × conteos)

| # | Rojo (fallo real anotado) | Estado / verde | SQLite | `:8101` |
|---|---|---|---|---|
| **H4** | Parche del tester: `git apply` limpio. Sus dos aserciones son de cobertura (ya verdes en HEAD; matan los mutantes «`findPermission` antes de `assertIdentity`» y «`assertScope` fuera de `#descendants`» según su informe) | ✅ | 250 | 332 |
| **H1** | Script `a5_move_steal.mjs` (arriba). En la suite, con `src/manager.ts` en HEAD (`git stash`): **2 failed / 252** — juez «within contrasta también el ORIGEN…» y `manager.spec` «H1: moved/attached…» (`moved: origen fuera: debería haber rechazado`) | ✅ `moved`: `within ∈ chain(newParent)` **y** `within ∈ chain(child)` (fresco; hijo desconocido ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE`); `attached`: padre y, si el hijo ya existe, su cadena. Script: `⇒ E_AUTHZ_NOT_WITHIN`, `después: … = false` | 252 | 335 (juez 61) |
| **H2** | `c5_*` dos procesos (arriba). En la suite: `bumpAuthzCatalogVersion()` sin trx se aceptaba (firma `client?` con el `db` global por defecto); `bump` desde dentro de una transacción con el `db` global se confirmaba antes que la escritura | ✅ `bumpAuthzCatalogVersion(trx)` exige `isTransaction === true` (Lucid y knex) ⇒ sin él 500 `E_AUTHZ_CONFIG` con receta; `withAuthzCatalogWrite(fn, { driver?, timeoutMs?, connection? })`: transacción + `fn(trx)` + bump al final dentro; `syncAuthzCatalog` pasa por él. Dos procesos con `c5_writer_fixed.mjs`: `[B] bumpAuthzCatalogVersion() sin trx ⇒ 500 E_AUTHZ_CONFIG; versión sigue en 1` → `[B] … versión subida a 2 en la MISMA transacción` → `[A] fase 2 #0/#1/#2: false, false, false` (`c5_A_green.log`). Tests: bump sin trx (6 formas) ⇒ 500 y versión intacta; el `UPDATE` de versión va tras el `INSERT` del consumidor y antes del `COMMIT` (espiado con `countQueries`); `fn` que lanza ⇒ rollback, versión intacta, error tal cual; juez de dos memos y `catalog_cache.spec` de dos memos reescritos con el helper (siguen verdes y siguen probando la FILA: el contador del proceso no se toca, afirmado) | 254 | 337 |
| **H3** | Scripts del auditor (arriba). En la suite: al cambiar a reloj monótono, F9 (que parcheaba `Date.now`) falló: `default 30 s: debería haber rechazado` — prueba de que `Date.now` ya no gobierna la vista | ✅ `performance.now()` en `CatalogCache.#checkedAt`/`#needsCheck` y en `#readsUntil` de la vista; `CatalogCacheOptions.now` / `ForRequestOptions.now` inyectables (solo tests; función o 500/TypeError). F9 reescrito con `now` (29 999 lee, 30 000 no) + `Date.now` atrasado 1 h ⇒ la vista caducada sigue caducada y una nueva caduca igual; `catalog_cache.spec` «H3: … reloj MONÓTONO»: `Date.now` −1 h y `everyMs: 40` ⇒ tras 60 ms revalida y ve el cambio; frontera 39/40 con `now` inyectado. Scripts: `c2_fixed.mjs` (openfga, `everyMs: 400`, reloj −1 h) ⇒ `false`; `f9_h3.mjs` (vista caducada de verdad antes de atrasar el reloj) ⇒ `E_AUTHZ_VIEW_EXPIRED` | 255 | 338 |
| **I2** | F9 con la aserción nueva: `expandExcludedSubtrees: debería haber rechazado` (la vista caducada respondía) | ✅ `#assertReadable()` extraído de `#reader()` y llamado también en `expandExcludedSubtrees` | 255 | 338 |
| **I1** | `catalog_cache.spec` «I1: sin la fila…»: `memo caliente: debería haber lanzado` (devolvía versión 0 y recargaba) | ✅ `readAuthzCatalogVersion`: fila ausente o `version` no numérica ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE` con «migración 2.0 no aplicada» (memo caliente, carga en frío y la función); el test borra la fila y la restaura | 257 | 340 |
| **I3** | `catalog_cache.spec` «I3: …»: `database: debería haber lanzado` (el `catalogRevalidate` se ignoraba) | ✅ `assertCatalogOptions(driver, options)` en `catalog_cache.ts`, llamado por los dos constructores ⇒ 500 `E_AUTHZ_CONFIG` nombrando `catalogRevalidate` | 257 | 340 |
| **I5** | Mutante «`#optional` devuelve `async () => []` cuando falta el método» ⇒ **3 failed / 313**: juez «sin listDenies en el puerto: … 500 E_AUTHZ_UNSUPPORTED» (harness `database (sin listDenies)`) + `manager.spec` B5 y B3. Revertido | ✅ `DriverCapabilities.listDenies` (par en `'2.1'`: `true` ⇒ los 7 casos que restan denies + F1; `false` ⇒ el caso «lo dice»; `true` en core/2.0 ⇒ lanza al registrar); tercer harness real en `contract.spec.ts` sobre una vista por prototipo del driver `database` sin `listDenies`; `contract_harness.spec` con el test del par (7 títulos, 55 = 61 − 7 + 1) | 313 | 396 |
| **I4** | — (documental) | ✅ README §Containment: «`within` must come from the session, never from the request body»; `within = scope` (o su padre) satisface por definición; jsdoc de `ScopedWriteOptions.within` y `requireWithin`; invariante 15 | — | — |
| **I6** | — (documental) | ✅ README §Enumerating scopes «What it costs»: O(descendientes × `resolveAncestors`), `maxScopes` no corta el paseo, `maxDescendants` es la cota del trabajo; invariante 16. Algoritmo sin cambios | — | — |
| **I7** | — | ✅ CHANGELOG «Lot 2E — final closing»; CLAUDE.md invariantes 14/15/16, mapa (`manager`, `catalog`, `catalog_cache`, `contract`, `tests`) y roadmap (2E ✅); `contract_harness` 61/55 | — | — |
| **cierre** | — | ✅ tope 3 (`:8103`): **396**; `docker rm -f openfga-tiny` hecho | 313 | 396 / 396 |

## Desviaciones respecto a la spec (con porqué)

1. **H2 · `withAuthzCatalogWrite` NO invalida el contador del proceso** (a diferencia de `syncAuthzCatalog`, que
   además hace `invalidateAuthzCatalog()` en su `finally`). Si el helper invalidara en memoria, el caso del juez de
   dos memos y los de `catalog_cache.spec` pasarían por el contador y dejarían de probar la fila (el mutante F1
   «`view()` sirve sin revalidar» sobreviviría). Es el canal entre procesos puro; documentado en jsdoc, README y
   CLAUDE.md: con `'always'` la siguiente pregunta de este proceso lo ve; con `{ everyMs }`, al cerrar la ventana, o
   llama a `invalidateAuthzCatalog()` tú (lo que hace el sync).
2. **H2 · el trx se reconoce por `isTransaction === true`** (lo ponen `TransactionClient` de Lucid y el transactor
   de knex; el `db` global y `QueryClient` llevan `false`). `CatalogVersionTransaction.isTransaction` se tipa
   `boolean` porque así lo tipa `TransactionClientContract`; la exigencia es en tiempo de ejecución.
3. **H3 · `now` inyectable es una opción pública marcada «SOLO TESTS»** (`ForRequestOptions.now`,
   `CatalogCacheOptions.now`): la spec decía «opciones internas»; no hay otro punto de inyección sin exponer las
   clases. Sin clamp adicional: `performance.now()` es monótono por construcción y un clamp sobre un reloj falso no
   añade ninguna observación distinta (queda anotado como analizado y descartado).
4. **I5 · `listDenies` es clave OBLIGATORIA de `DriverCapabilities`** (un harness de terceros que compile contra
   2.1 tiene que declararla; 2.x no está publicado). En core/2.0 debe declararse `false` (no hay caso que lo
   observe; regla H1 del harness: «declara lo observable hoy»). **F1** («el catálogo que decide es el de la base»)
   queda dentro de la cara `true` porque observa el catálogo con `effectivePermissions` (el tester anotó que en
   `database` es la ÚNICA aserción que mata el mutante F1): un driver sin `listDenies` no es juzgado en F1.
5. **I5 · coste**: el tercer harness añade 55 casos a `npm test` (+≈1 s). Es la única forma de que la cara `false`
   se EJECUTE en el paquete y no solo se registre.
6. **I1 · `bumpAuthzCatalogVersion` sigue sembrando la fila si falta** (camino de escritura: el UPDATE afecta 0 filas
   ⇒ INSERT; carrera resuelta por la PK). Lo fail-closed es la LECTURA: sin fila legible nadie sirve catálogo hasta
   que alguien la siembre (migración o un `withAuthzCatalogWrite`). `migration_stub.spec` sigue verde.
7. **H1 · sin `within` no se consulta el origen** en `moved`/`attached` (cero llamadas extra al árbol para una config
   laxa; con `requireWithin` el `within` es obligatorio y el origen siempre se mira). `moved` de un hijo que el
   árbol no conoce, con `within`, es 422 `E_AUTHZ_UNKNOWN_SCOPE` (igual que `detached`): no hay origen que contrastar.
8. **Scripts del auditor**: `f9_view.mjs` «reloj hacia atrás» no espera a que la vista de 20 ms caduque, así que su
   `true` de HEAD era la vista viva sirviendo su memo (documentado), no solo el reloj; `f9_h3.mjs` (misma prueba con
   `sleep 30` antes de atrasar el reloj) es el rojo/verde limpio. `c_catalog_fga.mjs` y `c5_writer.mjs` usan el bump
   sin trx, que ahora es 500: sus versiones corregidas son `c2_fixed.mjs` y `c5_writer_fixed.mjs`.

## Tests existentes cambiados (nunca relajados)

- Juez «el catálogo que decide es el de la base…»: `withoutLink` escribe por `withAuthzCatalogWrite` (antes
  `db` global + `bumpAuthzCatalogVersion()`); mismas aserciones. Movido, con los otros 6 que restan denies, bajo
  `caseFor('listDenies', { whenTrue })` (I5).
- `catalog_cache.spec`: «bumpAuthzCatalogVersion() sin invalidateAuthzCatalog()…» → «withAuthzCatalogWrite() sin
  invalidateAuthzCatalog()…»; «dos memos…» usa el helper y además afirma versión +1, resultado de `fn` devuelto y
  contador del proceso intacto; el caso de `everyMs` escribe con el helper; `linkNewPermissionByHand` acepta el
  cliente (trx o `db`).
- `manager.spec` F9: el bloque del reloj pasa de parchear `Date.now` a inyectar `now` (mismas fronteras) y añade
  `expandExcludedSubtrees` caducada (I2), `Date.now` hacia atrás (H3) y `now` inválido ⇒ 500.
- `contract_harness.spec`: `NONE.listDenies = false`; 2.1 se cuenta con `listDenies: true` (61).
- `contract.spec`: `CAPABILITIES_TODAY.listDenies = true` + harness `database (sin listDenies)`.

## Archivos tocados

`src/manager.ts` (H1 `#assertWithinOrigin`, H3 reloj monótono + `ForRequestOptions.now`, I2 `#assertReadable`),
`src/catalog_cache.ts` (H2 `bumpAuthzCatalogVersion(trx)`, `withAuthzCatalogWrite`, `CatalogVersionTransaction`,
`AuthzCatalogWriteOptions`; H3 `now`; I1 `unreadableVersionRow`; I3 `assertCatalogOptions`), `src/catalog.ts` (sync
vía el helper), `src/drivers/database_driver.ts`, `src/drivers/openfga_driver.ts` (I3), `src/testing/contract.ts`
(H1 caso, H2 `withoutLink`, I5 par `listDenies`), `src/types.ts`, `src/define_config.ts` (I4 jsdoc), `index.ts`
(exports), `stubs/migration.stub` (comentario), `tests/manager.spec.ts` (parche del tester, H1, F9 con H3/I2,
flag l. 868), `tests/spies.spec.ts` (parche del tester), `tests/catalog_cache.spec.ts` (H2, H3, I1, I3),
`tests/contract.spec.ts`, `tests/contract_harness.spec.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`.
Scratchpad `v4/`: `c5_writer_fixed.mjs`, `c2_fixed.mjs`, `f9_h3.mjs`, `c5_A_red.log`, `c5_B_red.log`,
`c5_A_green.log`, `c5_B_green.log`.

## Hallazgos por el camino

- `contract_harness` es load-bearing también para el par: sin `listDenies: true` en la llamada de 2.1 el conteo cae a
  55 y el test lo dice.
- `tests/manager.spec.ts` sigue importando `withTableMissing` de `database_driver.spec` (no se puede correr suelto);
  no es de este lote.
- La medida «el bump va después de la escritura y antes del COMMIT» se afirma sobre los eventos `query` de knex; si
  el dialecto no emite `COMMIT` como consulta, la aserción del commit se omite (la del orden con la escritura no).
