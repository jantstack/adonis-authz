# Fase 2 (2A+2B, HEAD bf3fac9) — verificación del auditor de seguridad (resumen guardado por el coordinador)

Veredicto: **APTA CON CORRECCIONES**. 15 reproducciones en `scratchpad/v3/r_*.mjs` (SQLite + OpenFGA :8101). Árbol intacto.

| # | Sev | Hallazgo | Evidencia | Decisión (fase-2-correcciones.md) |
|---|---|---|---|---|
| 1 | 🔴 | openfga: `rolesGranting`/`catalogRoles` salen del memo del catálogo ⇒ un sync en OTRO proceso no invalida ⇒ permiso retirado sigue concediendo indefinidamente (sin TTL por defecto); `database` hace join vivo y falla cerrado ⇒ divergencia | ✅ `openfga=true database=false` tras retirar vínculo; `invalidateAuthzCatalog()` ⇒ false | F1: `authz_catalog_version` compartida en BD, revalidación por defecto en cada `view()` |
| 2 | 🟠 | `requireWithin: true` solo cubre grant/deny; `removeDeny`/`revoke`/`scopes.detached` en scope ajeno se aceptan y `within` pasado se ignora | ✅ 4 FALLA reproducidos | F2: las seis escrituras con `ScopedWriteOptions` + `#assertWithin`; `'non-root'` |
| 3 | 🟠 | `authorizedScopes`: `descendantsOf(deny)` ⇒ `null` se trata como `[]` ⇒ subárbol denegado listado; descendientes ajenos aceptados | ✅ `some{[team:A1a]}` con `authorize=false`; unit de tenant B listada | F3: null en deny ⇒ 503; verificación de pertenencia por `resolveAncestors`; caso del juez authorizedScopes ≡ authorize |
| 4 | 🟡 | `effectivePermissions` usa el memo ⇒ contradice a `authorize` con memo frío (también database) | ✅ | Cae con F1 |
| 5 | 🟡 | Vista `forRequest()` reutilizada fuera del request sirve cadena vieja tras un `moved` (cruce de tenant, sin cota) | ✅ | F9: `maxAgeMs` default 30 s ⇒ `E_AUTHZ_VIEW_EXPIRED` |
| 6 | 🟡 | `authorizedScopes` pasea todo el árbol antes de acotar | 🟡 | F8: cortar antes de bajar y dentro del bucle |
| 7 | 🟡 | `excludedSubtrees: ScopeRef[]` se lee como scopes, no subárboles | 🟡 | F10: tipo nominal + helper de expansión |
| 8 | 🟡 | `manager.driver()` público esquiva actor/within/onWrite | ✅ | G4: documentado como salida de las barreras |
| 9 | 🟡 | `within: APP_SCOPE` satisface `requireWithin` siempre | ✅ | F2: `requireWithin: 'non-root'` |
| 10 | ⚪ | `hierarchicalScopeResolver`: clave sin separador (falso ciclo 422); `{app,uuid}` normalizado en silencio | ✅ | F6 |
| 11 | ⚪ | `sqlDescendantsOf` no valida `scopeType`; TTL con reloj de proceso; `maxScopes` por llamada sube la cota | ✅ | G1, F8 |

No se rompió: foto mixta del memo (orden permisos→roles→vínculos = siempre más restrictiva; versión capturada antes de leer); cargas concurrentes; el memo nunca cachea hechos; batch único (error ⇒ 503 antes de mirar allowed; >50 troceado correcto; duplicados correlacionados); ninguna escritura usa el memo de ancestros; `sqlDescendantsOf` (identificadores, ciclos 2 y 3, MySQL 500); `authorizeMany` (identidad de todas antes de ejecutar; `[]` sin backend; nunca parcial); `authorizedScopes` (`maxScopes` exacto completo; tipo antes de la cota; `all` siempre con excluidos; deny en raíz ⇒ none); FK impide denies huérfanos; regresiones Fase 1 (L0.3, N1 mismo proceso, S4, D1, L0.7) ✅.

Preguntas al arquitecto (respondidas por el coordinador en fase-2-correcciones.md): el memo NO puede alimentar decisiones sin versión compartida (F1); `requireWithin` es postura global (F2); `authorizedScopes` promete coherencia con `authorize` (F3).
