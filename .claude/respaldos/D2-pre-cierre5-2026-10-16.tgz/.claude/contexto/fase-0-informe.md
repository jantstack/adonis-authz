# Fase 0 · Informe del implementador (2026-08-28)

Rama `v2/fase-0`. **Sin commits** (los hace el dueño tras revisión). Node 22.23.2. OpenFGA local `:8101` (v1.19.0 para el segundo servidor de prueba).

**Estado de partida medido:** `npm test` 40/40 · con OpenFGA 67/67 · 281 stores en `:8101`.
**Estado final (tras correcciones C1–C7):** `npm test` **69/69** · con OpenFGA `:8101` **109/109** · con OpenFGA `:8103` `MAX_RESULTS=3` **109/109** · **29 stores** en `:8101` (constante antes/después de cada ejecución; 0 huérfanos en `:8103`) · `npm run typecheck` y `npm run build` en verde.
(Números previos a la revisión: 63 / 101 / 100.)

## Tabla pieza × estado × tests × verificación

| Pieza | Estado | Tests antes → después (SQLite / +OpenFGA) | Comando de verificación |
|---|---|---|---|
| F0.7 `check:purity` en `npm test` + regla 2 de módulos + `tests/purity.spec.ts` | ✅ | 40 → 44 / 67 → 71 | `npm test` (corre `check:purity` primero). Demo: `echo "import c from '#config/x'" > src/_demo.ts && npm test` → aborta con `✖ purity: src/_demo.ts → importa aliases del consumidor` antes de la suite. |
| F0.6 Teardown de stores + `scripts/openfga_prune_stores.mjs` | ✅ | sin cambio de conteo | `curl :8101/stores` antes y después de `OPENFGA_TEST_URL=http://localhost:8101 npm test` → **29 / 29**. Prune: dry-run 252/281 con prefijo → borrados 252 → quedan 29 (ninguno con prefijo de test). |
| F0.1 Firma del harness (`level`, `capabilities`, `makeTree`/`makeDriver(tree)`) + `memoryScopeTree` + `tests/scope_tree.spec.ts` | ✅ | 44 → 50 / 71 → 77 (6 tests del árbol) | `npm run typecheck`; harness con firma 1.1 en scratchpad → `tsc` **exit 2** (`Property 'capabilities' is missing`); harness `database` sin `level` → **52/52** en verde (19 core). |
| F0.2 Los 8 casos sobre `tree` + demostración | ✅ | sin cambio de conteo | Demostración abajo: con árbol vacío fallan 3 casos × 2 drivers. |
| F0.3 9 casos nuevos `level: '2.0'` | ✅ | 50 → 59 / 77 → 95 | `npm test` y con OpenFGA: los 9 pasan en ambos drivers a la primera. |
| F0.4 Par `truncationSignal` (`caseFor`) + `exhaustiveLists` | ✅ | 59 → 60 / 95 → 96 | `npm test` (caso de 1.200 asignaciones solo en `database`; no encarece la suite: 6 s). |
| F0.5 Espías (`tests/helpers/spies.ts`) + `tests/spies.spec.ts` | ✅ | 60 → 62 / 96 → 100 | `npm test` y con OpenFGA: `authorize` con cadena de 3 llama a `resolveAncestors` **exactamente 1 vez** en ambos drivers. `withFailingRead` de `contract.spec.ts` ahora usa `withFailing`. |
| F0.8 CI con 2.º OpenFGA `MAX_RESULTS=3`, imagen `v1.19.0`, `limits.listMaxResults` | ✅ | sin cambio | Local: `docker run … openfga-tiny -p 8103:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3 -e OPENFGA_LIST_USERS_MAX_RESULTS=3 …` → `OPENFGA_TEST_URL=http://localhost:8103 OPENFGA_LIST_MAX_RESULTS=3 npm test` → **100/100**, 0 stores huérfanos; contenedor eliminado. YAML validado. |
| F0.9 CHANGELOG `[Unreleased] — 2.0.0` | ✅ | — | README **no tocado** (decisión del juez). |
| Extra: `tests/contract_harness.spec.ts` (regla de capacidades ejecutable) | ✅ | 62 → 63 / 100 → 101 | Un harness que declara `truncationSignal: true` (sin par) → `runAuthorizationDriverContract` **lanza** al registrarse. |

Conteo final por fichero nuevo: `purity.spec` 4 · `scope_tree.spec` 6 · `spies.spec` 2 (×2 con OpenFGA) · `contract_harness.spec` 1 · contrato: 19 core + 10 nivel 2.0 (`database`) / 19 + 9 (`openfga`, sin el de 1.200).

## Demostración F0.2 — el caso 10 ya no pasa en falso (números reales tras C1)

Tras C1 el harness inyecta `resolveAncestorsFrom(tree)`: scope desconocido ⇒ `[]` (sin herencia implícita de `app`). La demostración ya no necesita tocar el fallback: basta con quitar los `tree.attach` de `orgUnder`/`unitUnder` en `src/testing/contract.ts` (restaurado después; verificado con `grep`).

`OPENFGA_TEST_URL=http://localhost:8101 npm test -- --files tests/contract.spec.ts` → **51 passed, 20 failed (71)**, 10 por driver, idénticos en `database` y `openfga`:

- Core (3): caso 10 «herencia hacia abajo: grant a nivel app autoriza dentro de una org», caso 11 «deny en el scope cercano bloquea el grant heredado, solo ahí», caso 14 «hasRole respeta scope, herencia y expiración».
- Nivel 2.0 (7): N1, N1b, N2, N4, N5, N6 e I7set (los que leen el árbol; N4/N5/N6 caen además en el guard de `tree.move` sobre una unit inexistente).

Los core 9, 15, 16, 18, 19 siguen verdes sin árbol: su aserción es de aislamiento o de lista directa y no depende de la arista.

(Antes de C1, con fallback `[APP_SCOPE]`, quitar los `attach` no hacía fallar nada: había que forzar el fallback a `[]` a mano. Eran 6 fallos — 10, 11, 14 × 2 drivers — sobre 49 casos; ese número queda como histórico.)

## Conteo de stores en `:8101`

| Momento | Total | Con prefijo de test |
|---|---|---|
| Inicio (tras las dos ejecuciones baseline) | 281 | 252 (`contract-` 120, `regrant-` 40, `authz-contract` 92; `authz-panel2`/`p1-` 0) |
| Tras `openfga_prune_stores.mjs` (solo esos 5 prefijos) | 29 | 0 |
| Tras cada `OPENFGA_TEST_URL=… npm test` posterior (×6) | 29 | 0 |

Los 29 restantes (`api-loco-base`, `demo-*`, `audit-*`, `trunc*`, `dbdown*`, `tester-facts*`, `id`, `undef`) no se tocaron. Tras las correcciones: 29 → 29 en cada ejecución contra `:8101`; 0 huérfanos en `:8103`.

## Desviaciones del plan (con su porqué)

1. **`makeTree` es opcional** en `DriverContractHarness` (default `memoryScopeTree()`), tal como sugiere la nota "default exportado" del plan; `makeDriver(tree)` sí es obligatorio recibir el árbol. Un harness de resolutor solo necesita inyectarlo.
2. **`caseFor` no acepta lados "pendientes" con función vacía.** El plan pedía "documentado como pendiente, sin caso vacío". Lo resolví con `PENDING_TRUE_PAIRS`: el juez **lanza al registrarse** si un harness declara `true` una capacidad cuyo par aún no existe. Es la regla "jamás un skip" hecha ejecutable (test en `tests/contract_harness.spec.ts`). Solo `truncationSignal` usa `caseFor` hoy; `hierarchyFacts:false` se documenta como "N1 es el par" en un comentario, sin caso duplicado.
3. **I7set** se aplicó de dos formas: (a) los casos 15 y 16 usan igualdad de conjunto (sustituye `includeMembers`/`notInclude`, como pedía el plan), y (b) un caso nuevo de nivel 2.0 sobre árbol real (`app → org → unit`) que fija que `listScopes`/`listRoles`/`listRoleScopes` no enumeran la unit heredada — es la única prueba del invariante 7 con profundidad > 2. Así son 9 casos nuevos como dice la tabla del plan sin duplicar 15/16.
4. **`memoryScopeTree` también rechaza un padre desconocido** (además de ciclo y `app` como hijo). No lo pedía el plan; evita que un test cuelgue `unit` de una `org` que olvidó registrar y pase por el fallback `[APP_SCOPE]`.
5. **`countCalls` sobre `resolveAncestors`** se hace a través de un "holder" `{ resolveAncestors }` al que el driver delega de forma tardía, porque el driver captura la función en el constructor y reemplazarla después no contaría. Documentado en `tests/spies.spec.ts`. El contador sobre el cliente FGA (`check`, `batchCheck`, `read`, `write`, `listObjects`) funciona igual sobre `driver['client']` (Proxy con propiedades asignables, como ya usaba `withFailingRead`); no se añadió un test que lo use porque ninguna pieza de Fase 0 lo exige (Fase 3b lo necesita para `singleCheckAuthorize`).
6. **Fixtures de `tests/purity.spec.ts` en `os.tmpdir()`** (`mkdtemp`, borrado en teardown) y no en el scratchpad de esta sesión: el test debe correr en cualquier máquina/CI.
7. **`openfga_prune_stores.mjs` usa `fetch`**, no el SDK: es herramienta de mantenimiento y así corre sin el peer opcional.
8. **Un test extra no previsto** (`tests/contract_harness.spec.ts`), ver desviación 2.
9. **CI**: ambos contenedores con `OPENFGA_DATASTORE_ENGINE=memory` (el plan solo lo ponía en el segundo); es lo que ya hacía implícitamente la imagen y evita cualquier duda de persistencia entre jobs.

**Ningún archivo de `src/drivers/*`, `src/manager.ts`, `src/catalog.ts` fue tocado.** `.gitignore`, `package-lock.json` (modificados) y `CLAUDE.md` (sin trackear) ya estaban así antes de empezar.

## Hallazgos (cosas que no pasaban como se esperaba)

1. **El fallback `?? [APP_SCOPE]` del harness sigue tapando el árbol.** Con el fallback actual (obligatorio hasta L0.3), quitar los `tree.attach` **no** hace fallar nada: un scope desconocido cae a `[app]` y el caso 10 pasa igual. La demostración exige cambiar el fallback a `[]`. Conclusión: hasta que L0.3 (Fase 1) haga que `null` deniegue, el juez prueba la herencia real **solo porque el harness cuelga las orgs**; no puede aún castigar a un driver que ignore el árbol para scopes desconocidos. Es exactamente lo que L0.3 debe cerrar y ahora el test lo verá.
2. **Los 9 casos nuevos y el de 1.200 pasaron en verde a la primera en ambos drivers**: ninguno destapó un defecto hoy (como predecía el plan). El único "rojo" real de la fase fue el de la demostración de F0.2.
3. **Un resolutor que lanza no produce `false` silencioso** en ninguno de los dos drivers (test en `spies.spec.ts`). Matiz: el error sale **crudo** (`Error`), no como `AuthorizationBackendError` 503 — el envoltorio de `openfga_driver` solo cubre el cliente FGA. No es defecto de contrato hoy (invariante 5 habla del backend), pero es un candidato para Fase 1 junto a L0.11 (caída del catálogo SQL ⇒ 503).
4. **La suite contra `MAX_RESULTS=3` pasa 100/100**, incluidos los 9 casos nuevos: ninguno enumera más de 3 objetos, como se cuidó. El de 1.200 queda fuera de `openfga` por `exhaustiveLists` (decisión documentada en el código); si se registrara, devolvería 3 en silencio: ese es L0.7, listo para su par rojo→verde.
5. **`check_purity.mjs` reporta el destino como lo escribe el import** (`src/manager.js`, no `.ts`); el test se ajustó a eso. Los patrones de la regla 2 aceptan ambas extensiones.
6. **Estrechamiento de tipos**: dentro de `if (openFgaTestUrl)`, las `function` hoisted no ven el estrechamiento de TS (`string | undefined`); se resolvió con un alias `const apiUrl: string`.
7. **Stores**: en el punto de partida ya había 281 (no 92): 120 `contract-` y 40 `regrant-` más de los que contó el panel, acumulados por ejecuciones posteriores. El teardown nuevo mantiene el número constante en las 6 ejecuciones posteriores.

## Archivos tocados

- Modificados: `.github/workflows/ci.yml`, `CHANGELOG.md`, `package.json` (`test` script), `scripts/check_purity.mjs`, `src/testing/contract.ts`, `src/testing/main.ts`, `tests/contract.spec.ts`.
- Nuevos: `scripts/openfga_prune_stores.mjs`, `src/testing/scope_tree.ts`, `tests/helpers/spies.ts`, `tests/purity.spec.ts`, `tests/scope_tree.spec.ts`, `tests/spies.spec.ts`, `tests/contract_harness.spec.ts`.

## Comandos de cierre (los tres en verde)

```bash
npm run typecheck
npm test                                              # 63/63 (incluye check:purity)
OPENFGA_TEST_URL=http://localhost:8101 npm test       # 101/101, stores 29 → 29
```

## Correcciones tras revisión (C1–C7)

Veredicto de las tres revisiones: APTA CON CORRECCIONES. A1 («no determinista») descartado por el coordinador (contaminación externa); no se persiguió.

| # | Corrección | Estado | Verificación |
|---|---|---|---|
| C1 | `resolveAncestorsFrom(tree)` exportado desde `src/testing/scope_tree.ts` (desconocido ⇒ `[]`); usado en ambos harness de `contract.spec.ts` y en `spies.spec.ts` (copias eliminadas); comentario de N1 corregido (el par de `hierarchyFacts:false` son N1b/N2/N4/N5). `middleware.spec.ts` y `manager.spec.ts` no usan harness ni resolutor (`grep` vacío). | ✅ | Demo sin `attach`: **20 fallos / 71** (10 por driver: core 10, 11, 14 + 7 de nivel 2.0). Con `attach`: 109/109. |
| C2 | `exhaustiveLists` dentro de `DriverCapabilities`. `caseFor('truncationSignal').whenFalse` registra SIEMPRE: `exhaustiveLists:true` ⇒ 1.200; `false` ⇒ caso de **frontera** con exactamente `limits.listMaxResults` asignaciones (igualdad de conjunto); sin `limits` ⇒ el juez lanza al registrar. Harness openfga declara `limits.listMaxResults` = `OPENFGA_LIST_MAX_RESULTS` o **1.000** (default del servidor). `PENDING_TRUE_PAIRS` y la rama `whenTrue` inalcanzable sustituidos por un registro (`covered`) comprobado al cerrar el grupo: toda capacidad `true` sin par ⇒ lanza. | ✅ | Frontera con 1.000 tuplas en `:8101`: el spec pasa de 7 s a **12 s** (≈ 5 s el caso, < 10 s ⇒ se queda en 1.000). En `:8103` con `=3` el caso se titula «frontera del tope: 3 …» y pasa. `tests/contract_harness.spec.ts`: 4 tests (true sin par lanza; `exhaustiveLists:false` sin límite lanza; con límite 3 registra el título correcto; `core` registra **22** casos y `2.0` **30**, y los core son prefijo de los 2.0). |
| C3 | `openfga_prune_stores.mjs`: dry-run por defecto, borra solo con `--force`; prefijos vacíos/`undefined`/< 4 caracteres rechazados; flag sin valor ⇒ error claro (también en `check_purity.mjs`, exit 2 con mensaje, sin stack). Comentario del script, CHANGELOG e informe actualizados (incluye `--prefix spies-`). | ✅ | `--prefix` (sin valor) ⇒ «--prefix necesita un valor»; `--prefix ab` ⇒ rechazado; `--prefix contract- --prefix regrant- --prefix spies-` ⇒ lista 0/29 sin borrar. |
| C4 | README: solo el bloque del harness de terceros (`level`, `capabilities`, `makeDriver(tree)` con `resolveAncestorsFrom`); nada más. CHANGELOG: (a) `core` ya no se describe como «unchanged» — se explica igualdad de conjunto, árbol obligatorio en los 8 casos y los 3 invariantes nuevos como core (problema → decisión → qué no se hace); (b) «never a skip» ajustado a lo real (par para `truncationSignal`/`exhaustiveLists`; el resto lanza si se declara `true`); (c) la frase del árbol vacío dice **qué** casos fallan (10, 11, 14 + los 2.0 que leen el árbol), cierta tras C1. | ✅ | Lectura del diff de `README.md` y `CHANGELOG.md`. |
| C5 | I8 (`rank` es metadata) e I6b (deny repetido) pasan a `test(...)` core. Caso core nuevo de orden: `deny` → `grant` ⇒ `authorize` false (y `docs:read` sigue true). | ✅ | Los tres verdes en ambos drivers; `core` = 22 casos. |
| C6 | `check_purity.mjs`: un solo regex de especificadores que cubre `from '…'`/`"…"`, `import '…'` (efecto lateral), `export … from`, `import('…')` dinámico y `require('…')`; destino comparado sin extensión (`../manager` ≡ `../manager.js`); `invokedDirectly` con `fs.realpathSync` en ambos lados; `MODULES` derivado de los directorios de `KNOWN_MODULES` (`catalog`, `relations`, `http`) que existan bajo `src/` — hoy ninguno. `tests/purity.spec.ts`: `SCRIPT` con `fileURLToPath`; fixtures nuevos: alias con comillas dobles + dinámico + efecto lateral (fallan los tres), y módulo `catalog` sin declarar con import sin extensión y dinámico (falla). | ✅ | `tests/purity.spec.ts`: 6 tests verdes; `node scripts/check_purity.mjs` ✔ sobre el repo. |
| C7 | Título de grupo `authorization contract [database · 2.0]`; docblock: llamar en top level del spec; `memoryScopeTree`: clave con `\u001f`, rama muerta eliminada, `ancestorsOf` con conjunto de visitados; `contract.spec.ts`: `client.read` restaurado en `finally` en el caso de carrera; `spies.spec.ts` ya nombraba `spies-…` y los borra en teardown — añadido a la doc del prune; `git checkout package-lock.json` (diff eran campos `libc`; `npm test` sigue verde). **`CLAUDE.md` sigue sin trackear: debe entrar en el commit del dueño.** | ✅ | `git status`: `package-lock.json` limpio. Suite verde tras el checkout. |

**Cambio estructural no previsto en las correcciones (necesario para C2):** Japa rechaza `test.group` desde un test en marcha («Cannot import japa test file directly»), así que la regla de capacidades no podía probarse en proceso. Se separó el registro del runner: `registerAuthorizationDriverContract(harness, api)` con `ContractTestApi = { group, test }` (exportado desde `contract.ts`, **no** desde `main.ts`); `runAuthorizationDriverContract` lo llama con Japa. El test usa una API falsa que solo anota títulos — lo que además permite afirmar cuántos casos registra cada `level` sin duplicar la suite.

**Aplazado a Fase 1 (según el documento):** N7/N8, N9, par `truncationSignal:true` (L0.7), resolutor que lanza ⇒ 503.

### Conteo final por fichero
`contract.spec` (database 30 + openfga 30 + regrant 8 + inalcanzable 3 = 71) · `spies.spec` 2 (×2 con OpenFGA) · `scope_tree.spec` 6 · `purity.spec` 6 · `contract_harness.spec` 4 · `manager`/`middleware`/`migration_stub` 21. SQLite: **69**. Con OpenFGA: **109**.

### Comandos de cierre (los cuatro en verde)

```bash
npm run typecheck
npm test                                                                  # 69/69
OPENFGA_TEST_URL=http://localhost:8101 npm test                           # 109/109, stores 29 → 29
docker run -d --name openfga-tiny -p 8103:8080 -e OPENFGA_LIST_OBJECTS_MAX_RESULTS=3 \
  -e OPENFGA_LIST_USERS_MAX_RESULTS=3 -e OPENFGA_DATASTORE_ENGINE=memory openfga/openfga:v1.19.0 run
OPENFGA_TEST_URL=http://localhost:8103 OPENFGA_LIST_MAX_RESULTS=3 npm test  # 109/109, 0 huérfanos
docker rm -f openfga-tiny
```

## Cierre (coordinador, 2026-08-28)
Verificación final del tester: APTA para commit. Ajustes posteriores aplicados por el coordinador:
H1 (par de capacidad juzgado en todos los niveles: `caseFor` solo marca cubierta si registró; casos del par con `test`, no `since('2.0')`; `contract_harness.spec` core=23, core ⊆ 2.0), H2 (test de colisión de clave en `memoryScopeTree`), H5 (`{}` del prune solo si hay objetivos), H6 (20/71).
Estado final medido: typecheck ✔ · `npm test` **70/70** · `:8101` **110/110** (stores 29→29) · tope 3 **110/110**.
Pendiente para Fase 1 (no bloqueante): H3 (regex de pureza: template literal y comentarios), H4 (test de `invokedDirectly` con symlink), test automatizado del script de prune.
