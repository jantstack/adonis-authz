# Lote A (plan 2.5 ⇒ 2.5.0-alpha.1) — re-ataque del auditor (2026-10-14)

Árbol `main` sin commit sobre `645af34`. Leído: `loteA-informe.md`, `CLAUDE.md` (5–11), diff completo de `src/`, `commands/`,
README §D4/§Testing expiry, CHANGELOG. Medido solo en SQLite `:memory:` (más dos consultas sueltas de solo lectura a
`postgres18`/`mysql84` para fijar comportamiento del motor). **Repro**: `.claude/reproducciones/loteA-reataque.spec.ts`
(runner `loteA-run.ts`): `env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec .claude/reproducciones/loteA-run.ts`
⇒ **3/3 VERDES = 3 defectos presentes** (A1, A2, A3). No re-corrí `check:guard-mutants` (el implementador midió 103/103; no
propongo mutantes nuevos que lo cambien).

## Veredicto en una línea

**Inseguro tal cual en D4** (la receta resucita revocaciones y la regla deja abierta la misma clase de alias); `checkMany`,
`relationTupleKey`, P5 y F-R2/F-R3 resisten con reservas menores.

## Hallazgos (ordenados por severidad)

### 🟠 A1 · La receta D4 RESUCITA lo que la ortografía canónica ya había revocado
- **Escenario**: instalación 2.4 con la compartición `user:U viewer document:D` escrita por las dos ortografías (un camino
  con el id de la URL sin guiones, otro con el de la fila) → offboarding `purgeSubject(U, unit|<con guiones>)` (en 2.4
  `scopeSpellings` solo expandía DESDE la sin guiones, así que la purga canónica no tocaba la fila vieja; en 2.5 tampoco la
  ve) → `check(U, viewer, D, canónica) = false` → el operador corre el detector, ve filas y aplica la receta «en el mismo
  deploy» como dice el README → **`check(...) = true`**: el usuario purgado vuelve a ver el documento. Mismo efecto con
  `unrelate`/`purgeObject` canónicos, y con un `relate(..., { expiresAt: pronto })` canónico que acortaba el acceso: la
  fusión «gana la caducidad más larga / NULL gana» lo vuelve permanente.
- **Evidencia**: ✅ repro A1 (verde). Código viejo: `git show 645af34:src/identity.ts` `scopeSpellings` (`!DASHLESS_UUID.test ⇒ [scope]`);
  receta README `-- D4 · SQLite/PostgreSQL/MySQL` (re-clavado incondicional + `CASE … NULL … GREATEST`). El propio caso del
  implementador (`upgrade_recipe.spec`, u1) afirma `false → true` por la canónica y lo llama «vuelve a conceder».
- **Steelman**: «las dos ortografías eran el MISMO tenant; la partición sin guiones era el bug (H5) y la receta reunifica lo que
  el consumidor escribió». → **No me convence**: la receta no puede distinguir «escrito sin guiones y nunca revocado» de
  «revocado por la canónica y superviviente por el alias»; elige la UNIÓN, que es la opción fail-open. El H5 del propio panel
  parte justo de «la purga canónica no veía la otra», o sea, la población con filas en el detector es la que tiene este caso.
- **Mitigación mínima**: receta fail-closed por defecto (borrar las sin guiones o volcarlas a una tabla de revisión) y el
  re-clavado/fusión como paso opt-in tras revisar el listado del detector; como mínimo, la advertencia literal en README/CHANGELOG.

### 🟠 A2 · D4 cierra «32 hex sin guiones» pero deja abierta la MISMA clase con otra colocación de guiones
- **Escenario**: consumidor con columna `uuid` de PostgreSQL que pasa como partición el id de la URL (patrón que D4 quería
  neutralizar). PG acepta `a0eebc99-9c0b4ef8-bb6d6bb9-bd380a11` o `8-4-4-16` (canónica sin el último guion, 35 chars) como la
  misma fila → `assertPartition` lo acepta (no es 32 hex puro, ≤ 36, `[a-z0-9-]`) → es OTRA partición → un insider con permiso
  de compartir escribe con el alias → `purgeSubject(U, canónica)` no lo toca → `check(U, viewer, D, alias) = true` tras el
  offboarding. El detector de la receta tampoco ve esas filas.
- **Evidencia**: ✅ repro A2 (verde) + medido en `postgres18`: `select 'a0eebc99-9c0b4ef8-bb6d6bb9-bd380a11'::uuid,
  'a0eebc999c0b4ef8bb6d6bb9bd380a11'::uuid` ⇒ ambas `a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11`. `src/identity.ts:305`
  (`DASHLESS_UUID = /^[0-9a-f]{32}$/` como única rama). La fila S5 del auditor R2-7 pedía «alias de partición ⇒ 422 o forma
  canónica; nunca `true`».
- **Steelman**: «la partición viene de la sesión/la fila canónica; el README dice "byte a byte, una ortografía"». → **No me
  convence**: el mismo argumento valía para la sin guiones y el dueño decidió rechazarla (D4); la regla se justifica como
  «la ortografía que un motor funde» y PG funde también estas.
- **Mitigación mínima**: en `assertPartition`, todo valor que tras quitar `-` sea 32 hex y no esté en la forma exacta
  8-4-4-4-12 ⇒ 422 (y el detector de la receta con la misma condición).

### 🟡 A3 · La validación de la respuesta de terceros no ve HUECOS (`Array#some` se los salta) — gemelo en `authorizeMany`
- **Escenario**: driver de terceros con `checkMany` que construye `new Array(n)` y rellena por correlación, con un resultado
  perdido → longitud correcta, posición vacía → `answers.some(a => typeof a !== 'boolean')` es `false` para los huecos →
  el manager devuelve `undefined` donde el puerto promete `boolean`. Un consumidor `if (out[i] === false) deny` deja pasar.
- **Evidencia**: ✅ repro A3 (verde). `src/relations/manager.ts` (`checkMany`, validación) y el gemelo `src/manager.ts:2880`
  (`authorizeMany`, misma forma, también `describeAnswer`).
- **Steelman**: «exige un driver de terceros roto; con `if (!out[i])` es fail-closed». → **Parcialmente**: baja a 🟡 por la
  precondición, pero la validación se publica justo como la defensa contra ese driver (invariante 5: nunca un `false`/vacío
  silencioso; aquí ni siquiera es `false`).
- **Mitigación mínima**: `for (let i = 0; i < n; i++) if (typeof answers[i] !== 'boolean') …` (o `Array.from`), en los dos.

### 🟡 A4 · F-R1: lo podado pierde el DETALLE y el verde dice «no respaldaban nada» aunque el resolutor esté medio ciego
- **Escenario**: pasada de mantenimiento `authz:reconcile --to=openfga --prune` con un `resolveChain` que devuelve `null` para
  los scopes de UN tenant (filtro por contexto, réplica atrasada; el seguro masivo solo salta con `usable === 0` global) → sus
  asignaciones y **denies** van a `pruned['unknown-scope']` y se borran → exit 0, letra «BORRADOS … no respaldaban nada».
  Antes del lote: mismo borrado, pero exit 1 y la lista `details` decía cuáles. Ahora `discard` NO llama a `note` ⇒ cero
  entradas en `details`, también en `--dry-run --prune` (el verificador ya no enseña QUÉ se va a borrar antes de la real).
  Al arreglar el resolutor, los permisos de ancestros vuelven a heredar hasta esos scopes sin sus denies.
- **Evidencia**: ✅ código `src/drivers/openfga_driver.ts` (`discard` ⇒ `pruned[reason]++` sin `details`) y
  `commands/authz_reconcile.ts` (solo el conteo). ❓ no ejecutado contra OpenFGA (restricción de entorno).
- **Steelman**: «el borrado ya existía con `--prune`; F-R1 solo arregla la letra (L8)». → **Sí en el borrado, no en el detalle**:
  quitar la lista de la operación destructiva no era necesario para arreglar el exit.
- **Mitigación mínima**: `discard` también empuja a `details` (con `kind`), y los denies podados como `warning` aparte.

### 🟡 A5 · La receta de `createTestClock` del README rompe el arranque en producción
- **Escenario**: el consumidor copia `import { createTestClock } from '@jantstack/adonis-authz/testing'` en
  `config/authorization.ts` → `/testing` importa estáticamente `@japa/runner`, `@japa/assert` y
  `@adonisjs/lucid/services/db` → en un despliegue con `--omit=dev` el config no carga y la app no arranca
  (`ERR_MODULE_NOT_FOUND`). No es fail-open (no hay fuga del reloj: `app.inTest` es falso fuera de tests), es caída.
- **Evidencia**: ✅ código `src/testing/main.ts` + `src/testing/{contract,relations_contract,…}.ts:1-23`; README §«Testing expiry
  from your app». `createTestClock` no está en la raíz (`index.ts`): bien.
- **Steelman**: «es `/testing`, ya dice que requiere Japa». → **No**: el README lo pone en un fichero de config de producción.
- **Mitigación mínima**: subpath propio sin dependencias (`/testing/clock`) o importarlo solo desde el bootstrap de tests.

### 🟡 A6 · Ruptura no declarada: TODA partición de 32 hex es 422, también ids que no son uuids
- **Escenario**: consumidor cuyos tenants se identifican con `randomBytes(16).toString('hex')`/md5 (32 hex legítimos, nunca
  uuids) → 2.5 rechaza su partición en las once operaciones y la receta la re-clava a una forma con guiones que su tabla no
  tiene. El CHANGELOG justifica NO rechazar ids de objeto porque «un 32 hex puede ser un id no-uuid legítimo»; el mismo
  argumento aplica aquí y no se declara.
- **Evidencia**: ✅ `assertPartition` (no distingue versión/variante); CHANGELOG «D4».
- **Steelman**: «decisión del dueño D4». → Válida como decisión; lo que falta es declararla con esa población nombrada.
- **Mitigación mínima**: frase en CHANGELOG/README (o restringir a uuids con nibble de versión/variante válidos).

### 🟡 A7 · D13 no exige F-05 a `membersOf` del driver de terceros llamado directamente
- **Escenario**: driver de terceros con `membersOfNative: true` que no valida tipo → `manager.driver().membersOf(role_binding,
  'assignee', S)` enumera asignados de un rol (la clase del 🟠 2 de alpha.3) y el runner publicado sigue verde: la lista
  directa del caso D13 omite `membersOf` (y el CHANGELOG dice «nine operations» listando ocho).
- **Evidencia**: ✅ `src/testing/relations_contract.ts:1066-1085`.
- **Steelman**: «los dos drivers del paquete lo validan y la guardia lo sondea». → Para el paquete sí; D13 es justo la
  exigencia a TERCEROS.
- **Mitigación mínima**: añadir `membersOf` a `typeAttempts` cuando el driver lo trae.

### ⚪ A8 · `checkMany` en MySQL: el hint de recursión va después de `DISTINCT` y se ignora
- `SELECT DISTINCT ${meta.hint}…` (`database_relations_driver.ts:659`) vs `SELECT ${meta.hint}DISTINCT` en `listObjects`.
  Medido en `mysql84`: con el hint tras `DISTINCT` ⇒ `ERROR 3636 … after 1001 iterations`; delante ⇒ responde. Con anidación
  de grupos > 1000, `checkMany` es 503 y `check` es `true`: rompe «≡ N check» (fail-closed, ruidoso). Fix de una línea.

### ⚪ A9 · `relationTupleKey` no valida sus componentes (salvo partición y `kind`)
- Objeto, relación y sujeto no pasan por la gramática: `{relation:'b@user:c#d', subject:user:e}` y
  `{relation:'b', subject:{user:c}#'d@user:e'}` dan la MISMA clave; el docblock promete «parseo unívoco». Solo afecta a tuplas
  que la API no admite, pero es una función pública para indexar metadatos. `kind: null` ⇒ `allow`. **Para el lote D**: el
  default `allow` es el modo de fallo peligroso (un deny enumerado sin `kind` casa con el allow en `reconcileRelations`); que
  `RelationTuple` lleve `kind` obligatorio desde el driver cuando llegue el deny. 🟡 hipotético hasta D.

### ⚪ A10 · Gemelo de la alineación: misma función, regla del `error` duplicada
- `correlateBatchResults` es UNA (importada, no copiada) ✅; pero «`error` por ítem ⇒ 503» está escrita dos veces
  (`openfga_driver.ts:819`, `openfga_relations_driver.ts:~543`). Un resultado ausente es 500 `E_AUTHZ_INTERNAL`, no 503
  (fail-closed y ruidoso; clasificación discutible).

### ⚪ A11 · El lease del freeze lo decide el reloj del ESCRITOR (preexistente, ahora documentado como feature)
- `#assertNotFrozen` usa `options.clock` contra `untilMs` escrito con el reloj de quien congeló; un proceso con reloj
  adelantado > lease escribe dentro de la ventana de una pasada. No lo introduce el lote (provider ya cableaba el reloj;
  roles igual). Las ventanas de operador sin lease no se ven afectadas.

### ⚪ A12 · Higiene/letra
- Tuplas sin guiones en `openfga`: sin detector, invisibles para `reconcile`/`--prune` para siempre (declarado).
- `RelationsReconcileReport.allowMassDelete` es campo OBLIGATORIO de un tipo exportado (ruptura de tipos menor, no declarada).
- El caso D13 directo de `checkMany` pone el `role_binding` en la ÚLTIMA posición y no prueba el tope 50/`[]` en el driver
  directo (los tres lo hacen hoy; el runner no lo exige a terceros).

## Lo que intenté y NO se rompió

- **`checkMany` F-05/gramática por ítem ANTES del backend** en manager, `database`, `openfga` y doble; tope 50 y `[]` ⇒ 422 en
  los tres (`assertCheckManyObjects` es la primera línea en cada uno).
- **Alineación**: el SDK 0.9.6 descarta ids ajenos y resultados nulos, los duplicados son imposibles (mapa) y lanza si el id se
  repite en la petición; los distintos llevan `correlationId` único; respuesta barajada ⇒ alineada; ausencia ⇒ 500; `error` ⇒ 503.
  Duplicados del lote se reparten por índice del distinto: no hay cruce de posición.
- **Mismo `now`**: `#checkContext(this.#now())` una vez por lote, igual que `check`; `database` un `at` para la CTE y el filtro.
- **Partición ajena colada por el id**: imposible, el id no admite `|` en ninguna de las tres implementaciones (el doble no valida
  ids, pero guarda partición aparte).
- **Respaldo del manager** sin `checkMany`: N `check` por posición, el primer 503 corta sin booleanos.
- **D4 punto único**: las 11 operaciones del manager, las de los dos drivers (`#keyOf` ⇒ `partitionKey`), el doble y
  `partitionsOf` de `reconcileRelations` pasan por `assertPartition`; enumeraciones filtran por la clave canónica.
- **Receta D4 como transformación**: no pierde tuplas en los casos userset/`subject_partition`, NULL vs fecha, gemelos; tras
  fusión+borrado el re-clavado no puede chocar con el UNIQUE; idempotente. (El problema es de política —A1—, no de SQL.)
- **Roles ↔ relaciones**: tipos y tablas disjuntos; la doble ortografía de roles no alcanza objetos de relación.
- **`relationTupleKey`**: literal de oro fijado, `kind` delante, caducidad fuera; reconcile usa la misma función.
- **`createTestClock`** no se exporta desde la raíz; no muta `systemClock`.
- **F-R1**: lo descartado con `prune`+`self` sí se borra (no está en `wanted` ⇒ sobra); el seguro masivo no depende de `skipped`.
  **F-R2**: con el seguro levantado la pasada real ya borró (si no, habría lanzado) ⇒ exit 0 coherente con el efecto; dry-run
  sigue siendo deriva. **F-R3**: paridad de códigos entre los dos comandos.

## Preguntas abiertas para el arquitecto

1. ¿La receta D4 debe ser fail-closed por defecto (A1)? Cambia el veredicto: con re-clavado incondicional es una concesión
   que el operador no ve.
2. ¿D4 rechaza «32 hex sin guiones» o «todo alias que PG funde»? Si es lo primero, la razón publicada de D4 no se sostiene (A2).
