# Fase 4 · Lote 4-1 — modelo FUSIONADO + generador + gate de bytes fusionado

> Base: `main` @ `76c5846` (Fase 3b mergeada, `2.3.0-alpha`). Árbol principal, sin commits.
> Plan: `fase-4-juez.md` §4-1 + `fase-4-plan.md` §1. Alcance: SOLO el generador y su gate,
> a nivel UNITARIO (como `openfga_facts.spec.ts` con `factsModelBytes`). Nada de `check`,
> `relate`, puerto ni driver (eso es 4-2/4-3/4-4). Store COMPARTIDO, modelo FUSIONADO.

## Qué se implementó (todo aditivo)

- **El generador**: `openFgaFactsModel(holderTypeMap, permissions, relationsConfig?)` emite ADEMÁS
  los `type_definitions` de `group` + los tipos de objeto de la config de relaciones, en el MISMO
  modelo. Tercer parámetro OPCIONAL: sin él, el modelo es EXACTAMENTE el de hoy (aditividad).
- **Gate de bytes FUSIONADO**: `assertFactsModelPublishable(holderTypeMap, permissions, warn?, relationsConfig?)`
  ahora construye el modelo FUSIONADO y lo mide. `factsModelBytes` ya era agnóstico a la forma del
  modelo — se le pasa el fusionado y cuenta los tipos de relaciones.
- **⚪4 + F-04 (nivel de modelo)**: `assertRelationsConfigPublishable(...)` valida ANTES de emitir y
  lanza `422 E_AUTHZ_RELATION_CONFIG` del PAQUETE (clase nueva en `src/errors.ts`).
- **Tipos** `FactsRelationsConfig`/`RelationObjectType`/`RelationObjectRelation`, constantes
  `FACTS_GROUP_TYPE`/`FACTS_GROUP_MEMBER_RELATION`/`RESERVED_FACTS_TYPES`, todo exportado por
  `src/openfga.js`; `RelationConfigError` re-exportado por `index.ts` (lo exige la regla 3E · Q3) y
  añadido a la tabla de errores del README.

Ficheros: `src/drivers/openfga_facts.ts`, `src/errors.ts`, `src/openfga.ts`, `index.ts`, `README.md`,
`tests/openfga_facts.spec.ts` (+14 casos).

## Rojo→verde por pieza (mutante que lo pone rojo, y restaurar)

### P1 · el generador emite el literal FUSIONADO de la §1
Mutante: no apéndar los tipos de relaciones (`if (false && relationsConfig)`).
```
❯ facts · 4-1 — el generador FUSIONA relaciones / openFgaFactsModel(H, P, RELATIONS) es el literal FUSIONADO de la §1
- Expected  - 120
+ Received  +   0
ℹ AssertionError: expected { schema_version: '1.1', …(2) } to deeply equal { schema_version: '1.1', …(2) }
```
Verde: el generador emite `facts` + `group` + `document` (owner ⊆ editor ⊆ viewer, usersets
`[holders, group#member]`), en ese orden. `type_definitions: user, admin, integration, role,
role_binding, scope, group, document`.

### P2 · el gate de bytes mide el modelo FUSIONADO (dos caras)
Mutante: `assertFactsModelPublishable` mide `facts`-solo (ignora `relationsConfig`).
```
❯ facts · 4-1 — el gate de bytes mide el modelo FUSIONADO (dos caras) / los tipos de relaciones CUENTAN para el techo
  Comparing two different types of values. Expected number but received undefined.
ℹ AssertionError: expected undefined to equal 500   (caught.status: el gate no lanzó)
```
Verde: con una base de 460 permisos realistas que en `facts`-solo CABE (no lanza), añadir tipos de
objeto la hace rebasar ⇒ 500 `E_AUTHZ_MODEL_TOO_LARGE` nombrando los bytes reales y el techo; el
modelo justo por debajo publica (devuelve `{bytes}` con `bytes > factsOnly`); al 80 % avisa una vez.
Self-calibrado (busca el nº de tipos que cruza cada umbral), sin cifras mágicas.

### P3 · ⚪4 (tipo/familia reservados) + F-04 (permiso↔relación)
Mutante: no llamar a `assertRelationsConfigPublishable` en `factsRelationTypeDefinitions`.
```
❯ facts · 4-1 — ⚪4 ... / ⚪4 · un objectType que DUPLICA un tipo reservado de `facts`
ℹ Error: openFgaFactsModel tenía que lanzar y no lanzó
```
Verde:
- objectType `role_binding`/`scope`/`role`/`deny_binding`/`group`/`user` ⇒ 422 `E_AUTHZ_RELATION_CONFIG`;
- relación `parent`/`rooted`/`assignee`/`binding`/`ancestor`/`role` ⇒ 422;
- relación con prefijo `can_`/`denied_`/`permits_` ⇒ 422;
- **F-04**: permiso `viewer` + relación `viewer` ⇒ 422 con «el permiso 'viewer'»;
- include a otro tipo / tipo duplicado ⇒ 422;
- `document#viewer` + `folder#viewer` (misma relación lógica en tipos distintos) ⇒ LEGAL.

### P4 · profundidad `can_<P>` intacta (22) sobre el FUSIONADO, 500 reps
Mutante: `FACTS_MAX_RESOLVE_DEPTH = 23`.
```
❯ facts · 4-1 — profundidad `can_<P>` intacta sobre el FUSIONADO (500 reps) / la cota es 23 y NO 24 ...
- 0
+ 4
ℹ AssertionError: a 23 saltos 4/10 lotes NO resolvieron sobre el FUSIONADO: los tipos de relaciones
  estarían bajando la profundidad de `can_<P>`: expected 4 to equal +0
```
Verde: con la cota en 22, sobre el modelo FUSIONADO, 10 lotes de 50 (500 resoluciones) resuelven
enteras a 22 saltos y a 23 falla al menos una vez (borde probabilístico). Un tipo de relación con
usersets (`group`/`document`) NO baja los 22 — `can_<P>` nunca recorre esos tipos.

## Medido contra el `:8101` (un doble en memoria no prueba nada)

- **Modelo fusionado PUBLICADO (201)**: `writeAuthorizationModel(openFgaFactsModel(H, P, RELATIONS))`
  devuelve un `authorization_model_id`. Tipos aceptados por FGA: group + document con usersets.
- **Gate de bytes contra el servidor (delta 0)**: un fusionado que rebasa reporta
  `... model exceeds size limit: <N> bytes vs 262144 bytes`; `factsModelBytes(fusionado) === N`.
  (facts-only 2 perms = 1546 B; +group +document = 1902 B, o sea +356 B: group ≈ 86, document ≈ 270,
  que es el ~271/tipo medido por el analista.)
- **Semántica fusionada en UN store**: `viewer` resuelve por userset (`group:eng#member`) y por
  includes (`owner ⊆ viewer`); y `can_docs_read` de `facts` sigue respondiendo en el MISMO store;
  una relación ReBAC NO concede en `facts` (espacios disjuntos).
- **Profundidad 500 reps** (10 lotes de 50): 22 sólido, 23 falla — sobre el FUSIONADO.

## Cifras del gate (las 4 + tope 3)

Con `factsModelBytes` (delta 0 contra el servidor):
| modelo | bytes | % de 262144 |
|---|---|---|
| facts-only, 2 perms, 3 holders | 1546 | 0,6 % |
| + `group` + `document` (1 tipo, 3 relaciones) | 1902 | 0,7 % |
| facts-only, 460 realistas | 255074 | 97,3 % (CABE, no lanza) |
| + 25 tipos de objeto (justo por debajo) | 261950 | 99,9 % (PUBLICA) |
| + 26 tipos de objeto | 262222 | rebasa ⇒ 500 |
- Coste por tipo de objeto (owner/editor/viewer + includes + userset): ~271 B, coincide con el plan.

## Verificación (todo verde)

- `npx tsc --noEmit -p tsconfig.json` + `npm run typecheck` + `check:purity` + `build`: OK.
- `OPENFGA_TEST_URL=:8101 npm test`: **810 passed** (base 796 + 14).
- `test:sqlite-file` (+OpenFGA): **815 passed** (base 801 + 14).
- `test:pg` (+OpenFGA): **909 passed** (base 895 + 14).
- `test:mysql` (+OpenFGA): **909 passed** (base 895 + 14).
- 0 stores de mis prefijos quedan en el `:8101` (los teardowns barren; queda 1 store PRE-EXISTENTE
  ajeno, no tocado).

## Lo que NO se hizo, y por qué

- **`check`/`relate`/`unrelate`/el puerto `RelationsDriver`/`defineRelationsConfig`/F-05**: es 4-2/4-4.
  El generador consume una config de relaciones MÍNIMA (`FactsRelationsConfig`) definida en
  `openfga_facts.ts`; el puerto completo y su validación de ESCRITURA (F-05) son 4-2.
- **Wiring del gate fusionado en el camino del SYNC**: `syncAuthzCatalog`/`catalogProjection` NO le
  pasan todavía la config de relaciones (no existe `defineRelationsConfig`). El MECANISMO está
  cerrado (`assertFactsModelPublishable` acepta y mide el fusionado, con caso unitario de dos caras);
  conectarlo al sync es 4-2, cuando exista la config persistida. Hoy el driver sigue midiendo
  `facts`-solo, que es correcto porque aún no hay relaciones declaradas.
- **0 tuplas de relaciones escritas** y `authorize`/`roles/` sin tocar: el lote es puramente el
  generador + gate. Las 5 suites de la Fase 3b siguen verdes idénticas.
