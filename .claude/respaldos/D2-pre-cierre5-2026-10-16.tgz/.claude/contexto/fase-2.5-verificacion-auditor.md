# Fase 2.5 (HEAD `e2cf8cd`) — verificación del auditor de seguridad

Primera auditoría con los **motores reales**. Reproducciones en `scratchpad/v5/` (PostgreSQL 18 `postgres18`,
MySQL 8.4 `mysql84`, SQLite fichero, OpenFGA `:8101`; bases propias con sufijo, todas borradas — 0 residuos en PG,
MySQL y `/tmp` al cerrar). Árbol del repo intacto (`git status` limpio, HEAD `e2cf8cd`).

Suites de referencia re-ejecutadas antes de atacar:
`OPENFGA_TEST_URL=:8101 npm run test:pg` ⇒ **425 passed**; `… npm run test:mysql` ⇒ **425 passed**.

## Veredicto en una línea

**APTA CON CORRECCIONES** — J1 (reloj), J2 (harness), J4 (concurrencia) y el grueso de J3 aguantan todo lo que les
tiré; pero J3 arregló la collation de identidad **solo en `authz_*`** y dejó fuera la mitad de la superficie que el
propio paquete lee: el **árbol de scopes**. Ahí el mismo defecto que J3 cerró (`abc` = `ABC`) reaparece como
**bypass de deny en PostgreSQL y MySQL, en los dos drivers** — y es invisible para la suite porque el juez usa un
árbol en memoria. Además, `expires_at` en MySQL guarda hora de pared del proceso que escribe: dos procesos con TZ
distinta no comparten la caducidad.

## Hallazgos (ordenados por severidad)

### 🔴 1 · Alias de uuid en el ÁRBOL: el deny se evade en PostgreSQL y MySQL

- **Escenario**:
  *Precondición* — tabla de scopes del consumidor con `uuid` nativo (PG) o `char(36)` con collation por defecto
  (MySQL), que es exactamente lo que usa `demo_scopes` del harness; Mallory es `admin` de
  `organization:aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa` y tiene un **deny explícito** de `docs:read` en
  `unit:bbbbbbbb-2222-4222-8222-bbbbbbbbbbbb`.
  *Acción* — Mallory pide el recurso con el id de la unit escrito de otra forma legal para la gramática del paquete
  (`[A-Za-z0-9._-]{1,36}`): en MAYÚSCULAS, o sin guiones (32 hex). Es el `params.unitId` de la URL, el sitio natural
  del que sale el `ScopeRef` en un PEP.
  *Resultado* — el árbol funde el alias con la fila real, así que la cadena resuelve a
  `[unit:<ALIAS>, organization:aaaa…, app]` y el grant del ancestro aplica; pero el deny está guardado con la forma
  canónica en `authz_denies` (`varchar(64) utf8mb4_bin`, J3) y **no casa**. `authorize` pasa de `false` a **`true`**
  y `listDenies` de 1 a 0.

  | alias | PG `database` | PG `openfga` | MySQL `database` | MySQL `openfga` | SQLite |
  |---|---|---|---|---|---|
  | canónico | `false` (denies 1) | `false` | `false` (denies 1) | `false` | `false` |
  | MAYÚSCULAS | **`true`** | **`true`** | **`true`** | **`true`** | `false` |
  | 32 hex sin guiones | **`true`** | **`true`** | `false` | `false` | `false` |

- **Evidencia**: ✅ `scratchpad/v5/a2_deny_bypass.ts` (driver `database`, los tres motores) y
  `a3_deny_bypass_fga.ts` (driver `openfga` con el catálogo en PG y en MySQL). En código:
  `src/drivers/backend_guard.ts:155` — `return [scope, ...ancestors]` devuelve **el scope tal y como lo escribió el
  llamante**, nunca el canónico que el árbol acaba de encontrar; el puerto `ScopeAncestorsResolver` solo devuelve
  ancestros, así que el paquete ni siquiera *puede* enterarse de que el nodo se llama de otra forma.
  El DDL real lo confirma: `demo_scopes.uuid` = `char(36) utf8mb4_0900_ai_ci` en MySQL y `uuid` nativo en PG
  (`scratchpad/v5/ddl.ts`), mientras `authz_denies.scope_uuid` = `varchar(64) utf8mb4_bin` / `varchar(64)`.
- **Por qué la suite no lo ve**: ✅ el caso J3 del juez (`src/testing/contract.ts:1076`, «…dos que solo difieren en
  mayúsculas jamás se cruzan (holder y scope)») declara los dos scopes con `tree.attach(orgLower)` /
  `tree.attach(orgUpper)` sobre `memoryScopeTree`, un `Map` de JS que compara byte a byte. Demuestra que `authz_*`
  los distingue y **da por supuesto que el árbol también**. `grep -rn toUpperCase tests/ src/testing/` no devuelve
  ni un caso que meta el case en el árbol. Los 425 tests pasan en PG y MySQL con el agujero abierto.
- **Steelman del defensor**: *«El árbol es del consumidor. El invariante 1 dice que el árbol lo inyecta él con
  `resolveAncestors`, y `demo_scopes` es una tabla ficticia del harness, no esquema publicado. Si su tabla funde
  mayúsculas, su bug.»* → **No me convence.** Tres razones: (a) el paquete **publica** `sqlDescendantsOf` y
  `hierarchicalScopeResolver` documentados sobre esa tabla, y la única tabla de árbol que el paquete enseña es la
  que falla; (b) la premisa entera de J3 fue que esta clase de defecto es del paquete — cambiaron el stub y el
  README para `authz_*` («Identity columns and slugs are compared byte-wise»), pero **no dicen ni una palabra de la
  tabla del árbol**, que es donde se decide si el deny está en la cadena; (c) el paquete puede cerrarlo sin conocer
  el árbol: hoy confía en el string del llamante después de que el árbol lo haya validado con otra regla de
  igualdad. Con SQLite (lo único que había antes de 2.5) no se veía nada: es justo el tipo de defecto que 2.5
  existía para encontrar.
- **Mitigación mínima**: que el contrato del resolutor devuelva el nodo **canónico** (`[self, ...ancestors]`) y que
  `resolveChain` use ese, no el del llamante; con eso el alias resuelve a la identidad real y el deny casa.
  Mientras tanto, documentar que la tabla del árbol exige `varchar` + `utf8mb4_bin` igual que `authz_*` y añadir el
  caso al juez con un árbol **SQL** (no en memoria).

### 🟠 2 · `expires_at` (`DATETIME(3)`) en MySQL guarda hora de pared del proceso que escribe: dos procesos con TZ distinta no comparten la caducidad

- **Escenario**: *Precondición* — MySQL; despliegue con más de un proceso (API en un contenedor `TZ=UTC`, worker o
  cron en `TZ=America/Caracas`, que es el default de esta máquina). *Acción* — el proceso UTC concede
  `grant(alice, editor, app, { expiresAt: 2030-06-15T12:00:00Z })`; el proceso de Caracas evalúa `authorize`.
  *Resultado* — para el segundo proceso la asignación **caduca 4 horas más tarde** de lo que dice el `Date` que se
  guardó: sigue concediendo durante 4 h después de su instante. Con un lector en `Asia/Tokyo` el efecto se invierte
  (caduca 9 h antes). PostgreSQL no tiene el problema (`timestamptz(3)` guarda el instante absoluto).
- **Evidencia**: ✅ `scratchpad/v5/b2_tz_two_procs.ts`, dos procesos `node` reales sobre la misma base:
  ```
  --- mysql ---
  [write TZ=UTC] grant con expiresAt = 2030-06-15T12:00:00.000Z
  [read  TZ=UTC]             authorize(T-1s)=true  authorize(T+1s)=false   correcto
  [read  TZ=America/Caracas] authorize(T-1s)=true  authorize(T+1s)=true    ⇐⇐ EL PLAZO SE HA MOVIDO
  [read  TZ=America/Caracas] la caducidad efectiva está en T+4.00 h  (debería ser T+0)
  [read  TZ=Asia/Tokyo]      la caducidad efectiva está en T-9.00 h
  --- pg --- (los tres correctos)
  ```
  Y el contenido crudo de la columna para el MISMO instante (`scratchpad/v5/b1_expiry.ts`): MySQL escribe
  `2030-06-15 08:34:56.789` desde Caracas, `12:34:56.789` desde UTC y `21:34:56.789` desde Tokio; PG escribe
  siempre `2030-06-15 12:34:56.789+00`.
- **Nota**: dentro de un solo proceso el ida y vuelta es exacto (Δ = 0 ms) y la frontera T−1/T/T+1 es correcta en
  los dos motores, que es lo que el juez comprueba. El defecto solo aparece con **dos procesos**, que es
  precisamente el despliegue que 2D/2E se molestaron en probar para el catálogo.
- **Steelman del defensor**: *«Está documentado: el README dice “Time comparisons use the JavaScript clock of your
  process … so the server's time zone setting only matters in that the same process writes and reads them; keep the
  process on NTP”.»* → **Me convence a medias.** La frase existe, pero está redactada como tranquilizadora y
  nombra el problema equivocado: no es la zona del *servidor* MySQL ni NTP (los relojes pueden estar perfectos), es
  que **`DATETIME` no guarda zona** y `mysql2` serializa con el `TZ` del proceso. Y la condición peligrosa —«el
  mismo proceso escribe y lee»— se enuncia como si fuera lo normal cuando el paquete asume explícitamente varios
  procesos. Además es una divergencia entre motores que la fase declaraba haber nivelado.
- **Mitigación mínima**: `expires_at` en MySQL como `TIMESTAMP(3)` (instante absoluto, y ya no muere en 2038 porque
  el tope es 2038 solo para `TIMESTAMP`… luego: fijar `timezone: 'Z'` en la conexión mysql2 y documentarlo como
  requisito), o exigir `TZ=UTC` en todos los procesos y fijarlo con un caso del juez que escriba y lea con dos
  relojes de zona distinta.

### 🟡 3 · `withAuthzCatalogWrite`: PG deja escapar el error de transacción abortada sin clasificar (y con el SQL dentro); MySQL **confirma** la misma escritura

- **Escenario**: *Precondición* — un seeder/migración de datos que escribe `authz_*` con `withAuthzCatalogWrite` y
  que, dentro de `fn(trx)`, se come con un `try/catch` un error de SQL (un `SELECT` a una tabla que no existe, una
  constraint). *Acción* — tras ese `catch`, sigue con su `UPDATE` de `authz_roles`. *Resultado* — divergencia total
  por motor: en **PostgreSQL** la transacción está envenenada (`25P02 current transaction is aborted`), el error sale
  **sin `status` y sin `code` del paquete** (llega el error crudo de `pg`, con el texto del `UPDATE` y el nombre de la
  tabla) ⇒ el manejador de Adonis lo rinde como 500 con internals; en **MySQL** la misma llamada **se confirma**
  (`rank=7`, versión subida) y no lanza nada.
- **Evidencia**: ✅ `scratchpad/v5/e6_purge_abort.ts`:
  ```
  pg    ⇒ (sin status) 25P02: update "authz_roles" set "rank" = $1 where "slug" = $2 - current transaction is aborted…
          estado final: rank=0 (revertido)
  mysql ⇒ resuelto SIN error;  estado final: rank=7 (confirmado)
  ```
  Código: `src/catalog_cache.ts` — `catch (error) { if (consumerError !== null && …=== error) throw error; … }`:
  todo lo que sale de `fn` se propaga intacto por diseño, incluido un fallo del backend.
- **Steelman del defensor**: *«El jsdoc lo dice literalmente: “lo que lance `fn` es del consumidor y sale intacto”.
  Envolverlo escondería el error del seeder. Y en los dos motores el estado queda coherente: PG revierte, MySQL
  confirma lo que el consumidor pidió.»* → **Me convence para la clasificación, no para la divergencia ni para la
  fuga.** Que el mismo código deje la base en dos estados distintos según el motor es justo lo que J3 fue a cazar; y
  «error del consumidor» no debería significar «error sin `status` con SQL crudo cruzando la frontera del paquete»,
  cuando la regla de higiene es que la abstracción no filtra.
- **Mitigación mínima**: clasificar como 503 los errores de `fn` que sean del driver SQL (no los `AuthzError` ni los
  del consumidor) y fijar el caso en la suite en los dos motores.

### ⚪ 4 · `authz_roles.scope_type` es la única columna de identidad sin la decisión J3

- **Escenario**: el barrido de J3 puso `collate('utf8mb4_bin')` en `holder_type`, `holder_uuid`, `scope_type` y
  `scope_uuid` de `authz_assignments`/`authz_denies` y en los `slug`, pero **no** en `authz_roles.scope_type`, que
  queda `utf8mb4_0900_ai_ci` y forma parte del índice único `authz_roles_slug_scope_uq`.
- **Evidencia**: ✅ DDL real (`scratchpad/v5/ddl.ts`, MySQL): `authz_roles.scope_type varchar(20)
  coll=utf8mb4_0900_ai_ci` frente a `authz_assignments.scope_type … coll=utf8mb4_bin`. **No es explotable hoy**:
  `assertScopeType` obliga a minúsculas y lo comprobé (`scratchpad/v5/z_resiste.ts`): un `scopeType: 'ORGANIZATION'`
  en `syncAuthzCatalog` es 422 `E_AUTHZ_INVALID_IDENTITY` en los dos motores.
- **Steelman**: *«La gramática ya lo garantiza; la collation es defensa en profundidad y sobra.»* → **Me convence**
  como severidad (⚪), no como criterio: si la defensa en profundidad valía para las otras cuatro columnas, vale
  para esta, y una asimetría sin motivo es lo que hace que la siguiente revisión no sepa si fue decisión u olvido.
- **Mitigación mínima**: añadir el `collate` también ahí, en el stub y en el espejo, o anotar por qué no.

### ⚪ 5 · Una terminación anormal deja la base de test huérfana en el servidor

- **Escenario**: `bin/test.ts` borra la base en el `teardown` de Japa y en `run().finally(...)`, lo que cubre el
  camino feliz y un test rojo — pero no una excepción no capturada, un `process.exit()` ni una señal.
- **Evidencia**: ✅ `scratchpad/v5/g1_crash.ts`, cuatro modos sobre PG: `ok` borra; `throw`, `exit` y `sigkill`
  dejan las tres bases (`authz_test_21b69c40`, `authz_test_cf350eb4`, `authz_test_100656f5`, verificadas en
  `pg_database` y borradas a mano después). En mi propia sesión un script que murió antes del teardown dejó dos
  (una en PG y otra en MySQL, ambas a las 03:59 UTC), lo que confirma que pasa en la práctica.
  ✅ Lo que **sí** está corregido y verifiqué: el proceso hijo de `load_without_sdk.ts` ahora hace
  `finally { await app.teardown() }` (no fuga), y `teardown()` es fiable incluso con una consulta en vuelo
  (`scratchpad/v5/g2_teardown.ts`, 5/5 borradas, `pg_sleep(3)` incluido). El sufijo es `randomBytes(4)`: no es
  predecible y no permite adivinar la base de otra ejecución.
- **Steelman**: *«En CI los servicios son efímeros; en local se ven a simple vista por el sufijo.»* → **Me convence**
  para la severidad. Lo dejo anotado porque el informe §6 afirma «0 residuos» y esa afirmación solo vale para el
  camino feliz.
- **Mitigación mínima**: un `process.on('uncaughtException'|'SIGINT'|'SIGTERM')` que llame al `teardown`.

### ⚪ 6 · `maxDescendants` por encima del rango de `cte_max_recursion_depth` degrada el 422 del contrato a un 503

- **Escenario**: `scopes.maxDescendants` es entero ≥ 1 sin tope; por encima de ~4.29e9 el `SET_VAR` del hint sale
  del rango y un ciclo en el árbol deja de ser el 422 «posible ciclo» del contrato.
- **Evidencia**: ✅ `scratchpad/v5/d_cte.ts` con un ciclo A↔B: 422 `E_AUTHZ_TOO_MANY_SCOPES` correcto hasta
  `maxNodes = 1_000_000` en los dos motores; a partir de `4_294_967_293`, MySQL ⇒ 503 `E_AUTHZ_BACKEND_TIMEOUT`
  (5 s) y PG ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE`. Coste: `maxNodes = 1_000_000` cuesta **2,2 s de CPU** por llamada
  en MySQL (0,96 s en PG) — amplificación si alguien sube la cota y tiene un ciclo.
- **Steelman**: *«`maxNodes` sale del config, nunca de la petición (lo verifiqué: `#scopeBounds` solo deja BAJAR la
  cota por llamada), y ambos casos fallan cerrado.»* → **Me convence**: es ⚪, endurecimiento de config.
- **Mitigación mínima**: acotar `maxDescendants` a un máximo razonable al validarlo.

## Lo que intenté y NO se rompió

- **Inyección en el hint de MySQL**: `%DEPTH%` solo recibe `String(cap + 2)` con `cap` ya validado. `maxNodes` =
  `0`, `-1`, `1.5`, `NaN`, `Infinity`, `null`, `undefined` ⇒ 500 `E_AUTHZ_CONFIG` sin tocar la base; `'50'` coacciona
  a número sin salirse. El hint **no se filtra a la sesión** (`@@session.cte_max_recursion_depth` sigue en 1000
  después). PG usa el mismo SQL sin hint.
- **Identidad de holder (invariante 4)** en PG y MySQL: `users:abc.def_42` vs `users:ABC.DEF_42` vs
  `admins:abc.def_42` no se cruzan en `authorize`, `listDenies` ni el índice único; el deny de uno no toca al otro.
  Aquí J3 funciona (`z_resiste.ts`). El problema del 🔴 es el árbol, no `authz_*`.
- **Fail-closed del scope desconocido (L0.3)**: `authorize` ⇒ `false`, `grant` ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE` en los
  dos motores. Resolutor que lanza o devuelve un ancestro mal formado ⇒ 503 `E_AUTHZ_RESOLVER_FAILED`, nunca `false`.
- **Reloj (J1)**: `grep` de `new Date()`/`Date.now()` en `src/`, `commands/`, `providers/`, `services/`, `index.ts`
  limpio — solo `src/clock.ts` (y `performance.now()` en los dos relojes monótonos, que es lo correcto). Lo que
  queda fuera es inocuo (`stubs/migration.stub` sembrando `updated_at`, `configure.ts` nombrando el fichero).
  Driver de terceros sin `withClock` + `config.clock` ⇒ 500 `E_AUTHZ_CONFIG`; `clock` que no es función (`'ahora'`,
  `123`, `null`) ⇒ 500. No hay camino por el que el reloj de tests llegue a producción salvo poniéndolo en el config
  a sabiendas.
- **Caducidad al milisegundo**: T−1 concede / T no concede / T+1 no concede, exacto en PG y MySQL con
  `DATETIME(3)`/`timestamptz(3)`; ida y vuelta con Δ = 0 ms; `2040-01-01` válido. (El agujero es de zona, no de
  precisión: hallazgo 2.)
- **Catálogo con mayúsculas**: `scopeType: 'ORGANIZATION'` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY`; slug `'DOCS:READ'` o
  `'ADMIN'` ⇒ 422 `E_AUTHZ_INVALID_SLUG`. `authz_catalog_version` no tiene ninguna columna de identidad (int/bigint/
  timestamp): nada que fundir.
- **J4 · dos `grant` concurrentes con caducidades distintas** (PG, MySQL, sqlite-file): una sola fila, la segunda
  gana con `GrantOutcome` coherente (`existed:true`, `previousExpiresAt`). Sin duplicados, sin 409 necesario.
- **J4 · `purgeScope` concurrente con `grant`** en el escenario **realista** (el consumidor ya sacó el scope del
  árbol antes de notificar `scopes.detached`): **0/30 filas huérfanas** en PG y MySQL — el `grant` se rechaza con
  422 porque el árbol ya no lo conoce. (Con el scope todavía en el árbol el `grant` posterior gana, 30/30, pero eso
  es «purgar y volver a conceder», no una fuga.)
- **J4 · `syncAuthzCatalog` concurrente con `authorize`**: 25 rondas × 12 preguntas en los tres motores, siempre
  monótono (una vez `false`, nunca vuelve a `true`) y `false` al terminar. No conseguí una foto mixta permisiva.
- **`withAuthzCatalogWrite` concurrente**: 8 escrituras simultáneas ⇒ 8 bumps, ninguno perdido, en PG y MySQL (el
  `increment` toma el lock de fila). En sqlite-file 6 de 8 mueren con `SQLITE_BUSY` — ruido de motor, no pérdida.
- **N1/F1 · dos procesos `node` REALES** sobre la misma base, en **PG y MySQL** y en **ambos drivers**: el proceso A
  con el memo caliente responde `true`; B retira el vínculo con `withAuthzCatalogWrite`; A responde
  `[false,false,false]` en su siguiente pregunta y `docs:read` sigue `true` (no es un fail-closed global). El 🔴 de
  la Fase 2D sigue cerrado en los motores reales.
- **Regresión completa**: `test:pg` y `test:mysql`, con `OPENFGA_TEST_URL=:8101`, **425/425** cada uno (L0.3, L0.7,
  F2, F3 y los casos J3/J4 incluidos).

## Preguntas abiertas para el arquitecto

1. **¿El árbol de scopes entra en el contrato de identidad o no?** Es la pregunta que decide el 🔴. Si `resolveAncestors`
   pasa a devolver `[self, ...ancestors]` (nodo canónico incluido), el alias muere para todos los consumidores y para
   los dos drivers; si se queda como está, hay que decir en el README que la tabla del árbol exige la misma
   comparación byte a byte que `authz_*` — y aun así queda a merced de que el consumidor lo haga bien. Cambiar el
   puerto es **breaking** para drivers de terceros, así que es decisión tuya y probablemente de 3b, no de 2.5.
2. **¿MySQL con `DATETIME(3)` es una configuración soportada o exige `TZ=UTC` en todos los procesos?** Si es lo
   segundo, es un requisito de despliegue, no una nota al pie: debería fallar al arrancar si no se cumple.
3. **¿El juez debe correr al menos una vez con un árbol SQL en vez de `memoryScopeTree`?** Es lo único que habría
   visto el 🔴, y es la misma lección que J3: lo que no se ejecuta contra el motor real no está observado.
