# `2.4.0-alpha.3` — informe del CIERRE-2 (implementador, INCREMENTAL)

**Base:** el árbol del cierre (`alpha3-cierre-informe.md`, 1133 / 1157 / 1252 / 1252), sin commitear.
Encargo: `alpha3-auditor-cierre.md` (re-ataque: 🟠 1 regresión + 🟡 2/3 + ⚪ 4/5/7) según las decisiones
**2026-09-02 (2d)**. Quirúrgico, sin commits, sin subir `version`. Logs en `$S` (scratchpad de la sesión).

---

## 0 · ROJO de partida (las reproducciones del auditor, tal cual)

`alpha3-cierre-auditor.ts` (`$S/red2_unit.log`):
```
1a membersOf(role_binding, assignee)  ⇒ NINGUNO {"subjects":[]}
1b membersOf(document, relación NO declarada) ⇒ NINGUNO {"subjects":[]}
2a check(relation: undefined) ⇒ NINGUNO resultado=false
2b listSubjects(relation: undefined) ⇒ NINGUNO {"subjects":[]}
2c listObjects(relation: undefined) ⇒ NINGUNO {"objects":[]}
2e relate(relation: undefined) ⇒ NINGUNO          ← ESCRIBE la tupla (la regresión)
2f unrelate(relation: undefined) ⇒ NINGUNO
2g purgeSubject(userset relation: undefined) ⇒ NINGUNO
3a markPartialWrite(error CONGELADO) ⇒ LANZA TypeError
```
`alpha3-cierre-openfga.ts` contra el `:8101` (`$S/red2_openfga.log`): O1a `relate(undefined)` ⇒ **503**
`E_AUTHZ_BACKEND_UNAVAILABLE`; O1b `listSubjects(undefined)` ⇒ la UNIÓN (los dos holders); O1c/O1d ⇒ 503;
O1e `membersOf(role_binding)` ⇒ 500 `E_AUTHZ_UNSUPPORTED` (no F-05).
`alpha3-cierre-parcial.ts` (`$S/red2_parcial.log`): B (falla el `Read` inicial, mensaje «NO es timeout») ⇒
`E_AUTHZ_BACKEND_TIMEOUT` con `indeterminate=true` y `tuplas que quedan=2` (no borró nada); C ⇒ también
como TIMEOUT (por el substring del mensaje).

## 0b · VERDE de las mismas reproducciones (`$S/green2_*.log`)

```
1a ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422   1b ⇒ E_AUTHZ_RELATION_UNKNOWN 422
2a/2b/2c/2e/2f/2g ⇒ E_AUTHZ_RELATION_UNKNOWN 422       3a ⇒ ok
O1a/O1b/O1c/O1d ⇒ E_AUTHZ_RELATION_UNKNOWN 422          O1e ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422
A control: 1 evento sin indeterminate · B: E_AUTHZ_BACKEND_UNAVAILABLE 503, partialWrite=undefined, quedan=2, eventos=0
C: E_AUTHZ_BACKEND_UNAVAILABLE 503, partialWrite=true, quedan=0, eventos=1 indeterminate=true
```

---

## 1 · 🟠 1 · dos funciones, no un opcional

`src/relations/define_relations_config.ts`:
- `assertRelationDeclared(config, object, relation: string)` **ESTRICTA**: llama a `assertObjectTypeDeclared`
  y después exige `typeof relation === 'string' && relation.length > 0` (si no ⇒ 422
  `E_AUTHZ_RELATION_UNKNOWN`, nombrando la operación y «sin ella no hay tupla que escribir ni pregunta que
  responder»), y por último `isDeclared`. La usan: manager `relate`/`unrelate`/`check`/`listSubjects`/
  `listObjects` (con `{ type: objectType }`)/`membersOf` y `#assertSubject` (userset); `database`
  `relate`/`unrelate`/`check`/`listObjects`/`listSubjects`/`membersOf`, `#subjectColumns` (userset) y
  `purgeSubject` (userset); `openfga` `relate`/`unrelate`/`check`/`listObjects`/`listSubjects`, `#subjectUser`
  (userset) y `purgeSubject` (userset).
- `assertObjectTypeDeclared(config, object)` (solo el TIPO): manager `#assertTypeDeclared` ← `purgeObject`;
  `database` y `openfga` `purgeObject`.
- **Nota sobre `listObjects`**: la decisión lo lista con la de TIPO; aquí lleva la ESTRICTA con
  `{ type: objectType }` porque `listObjects` SÍ nombra una relación (`listObjects(u, undefined, 'document')`
  era un 503 del servidor en `openfga`, O1d) y el cierre-1 ya validaba ese par en verde — superconjunto de la
  decisión, no contradicción (invariante 5). Se reporta.
- El userset del sujeto también va por la estricta (2g del auditor: `purgeSubject({ object, relation:
  undefined })` ⇒ 422); antes en `database` lo salvaba `#assertId` con `E_AUTHZ_INVALID_IDENTITY` y en
  `openfga` componía `…#undefined`. Ahora el MISMO `code` en los dos.

| caso | ROJO | verde | mutante |
|---|---|---|---|
| `relations.spec.ts` «cierre-2 · 🟠 1 / 🟡 2 · … SIN relación»: `undefined`/`''`/`null`/`7` × relate/unrelate/check/listSubjects/listObjects/membersOf | 2e/2f del auditor («NINGUNO»: escribe) | 422 `E_AUTHZ_RELATION_UNKNOWN`, `calls = []`, `events = []`, `check` false; `purgeObject` (tipo) entra | **M10** reintroducir `if (relation === undefined) return` ⇒ 7 rojos: «ROJO (relate): ENTRÓ sin relación» (spec + runner), la UNIÓN, y la paridad de `database` (`INVALID_IDENTITY` ≠ `RELATION_UNKNOWN`) (`$S/mut2_optional.log`, restaurado por md5) |
| runner publicado (caso F-05 ampliado: `/membersOf` en el título y el bloque «SIN relación») | ídem | `state.calls() = 0` en los DOS harnesses + `database` + `openfga` | M10 |
| `relations_database.spec.ts` L-0 (ampliado): las seis + `purgeSubject(userset sin relación)` EN DIRECTO al driver | antes `E_AUTHZ_INVALID_IDENTITY` (`#assertId`) | `E_AUTHZ_RELATION_UNKNOWN`, `connections() = 0` | M10 |
| `relations_openfga.spec.ts` «cierre-2 · relate/unrelate/check/listSubjects/listObjects con relation: undefined …» por MANAGER y por DRIVER contra el `:8101` | O1a (503) | 422, `spy.calls = []`, cero eventos | M10 (no ejecutado contra el `:8101`: el manager corta antes; la parte del driver la cubre la misma función) |

## 2 · 🟡 2 · `listSubjects` sin relación ⇒ 422 (no la unión)

Lo cierra (1). Casos: `relations.spec.ts` «🟡 2 · listSubjects(undefined) ya NO es la unión» (u viewer + v
owner ⇒ 422; con relación, solo esa) y el CONTROL del caso `:8101` (`listSubjects('owner') = [v]`,
`listSubjects('viewer') = [u]`, O1b antes daba los dos).

## 3 · 🟡 3 · `membersOf` es la OCTAVA

Manager `membersOf`: `#assertDeclared(object, relation)` + `#assertObjectId` ANTES de la comprobación de
capacidad (⇒ `role_binding` es 422 también donde `membersOf` sería 500 `E_AUTHZ_UNSUPPORTED`, O1e). Driver
`database` `membersOf`: `assertRelationDeclared` primera línea. Casos: `relations.spec.ts` «🟡 3 · membersOf
pasa por F-05 (par) ANTES de la capacidad» (1a/1b del auditor; con y sin `membersOfNative`), `database` L-0
(`membersOf`/`membersOf(rel)`/`membersOf/undefined`, `connections() = 0`), runner (F-05 con `membersOf` en las
tres listas). Docs: «siete» → «ocho» en README (F10 ampliado: `notInclude('all seven operations')`),
`types.ts`, `define_relations_config.ts`, `manager.ts`, CHANGELOG, `CLAUDE.md`.

## 4 · ⚪

| ⚪ | cierre | caso |
|---|---|---|
| 4 · `markPartialWrite` sobre error congelado | `try/catch` en `defineProperty`; si no puede marcar devuelve el ORIGINAL sin marca (se pierde el `indeterminate` de esa purga, no el 503/500) | `relations.spec.ts` «⚪ 4 · markPartialWrite sobre un error CONGELADO…»: mismo objeto, sin propiedad, por el manager el 503 original se propaga (no `TypeError`), cero eventos |
| 5 · `isTimeoutLike` por substring | el driver de relaciones importa `isTimeoutLike` + `withDeadline` de `backend_guard.ts` y `#guard` replica `guardBackendErrors` de roles: deadline TOTAL PROPIO por llamada (`timeoutMs`) ⇒ `AuthorizationBackendTimeoutError`; lo que lanza el cliente se clasifica con la estricta (`ECONNABORTED`/`ETIMEDOUT`/`.timeout`/`KnexTimeoutError`). La función local con `/timeout/i` se borró y el docblock dice ahora la verdad. **Por qué el deadline propio**: con solo la estricta, el caso C4 (servidor MUDO) pasaba a `E_AUTHZ_BACKEND_UNAVAILABLE` (el error del SDK contra un socket mudo no lleva `ECONNABORTED` en ≤ 6 niveles de `cause`); roles lo resuelve con su propio `withDeadline`, y eso es «el mismo criterio que roles» de verdad | `relations_openfga.spec.ts` «cierre-2 · ⚪ 5 · un error cuyo MENSAJE dice «timeout» pero no lo es ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE` y CERO eventos; `ETIMEDOUT` ⇒ TIMEOUT e `indeterminate: true`»; C4 sigue verde (`$S/subset3.log`) |
| 7 · BREAKING de las lecturas | párrafo **BREAKING** en el CHANGELOG: `check`/`listSubjects`/`listObjects`/`membersOf` con tipo/relación no declarados (o relación ausente) lanzan 422 en vez de responder | **F13** en `relations_events_docs.spec.ts` (+ la regresión contada como problema → decisión, `assertObjectTypeDeclared`) |
| 6 · deber de marcar sin juez | sin cambio (ya registrado en el roadmap 2.6+) | — |

## 5 · Lo que NO hice y por qué

- **`listObjects` solo con la de TIPO** (letra de la decisión): lleva ADEMÁS la estricta sobre la relación que
  nombra — ver §1; quitarla reabriría O1d (503) y pondría en rojo casos verdes del cierre-1.
- **El doble F del auditor (`3b`, driver de terceros que borra y no marca ⇒ 0 eventos)** y **`3c` (marca sin
  borrar ⇒ evento fabricado)**: son el deber del driver sin juez, diferido (⚪ 6); sin cambio.
- **`5d` (`actor.session.ip` anidado sigue siendo alias)**: coherente con «copia por nivel de identidad, actor sin
  poda»; el auditor lo dejó en ⚪ sin pedir cambio.
- **Reproducciones del auditor**: intactas (las tres se re-ejecutan tal cual y salen verdes).
- **Commits / `version`**: ninguno.

## 6 · Mutante

**M10** (`$S/mutants2.sh` → `$S/mut2_optional.log`): reintroducir `if (relation === undefined) return` en la
estricta (la regresión literal del cierre-1) ⇒ **7 rojos** en `relations.spec` + `relations_contract.spec` +
`relations_database.spec`: «ROJO (relate): ENTRÓ sin relación» ×3 (spec y los dos harnesses del runner),
«ROJO: sin relación devolvió la UNIÓN (u y v)», y la paridad de `database` (`E_AUTHZ_INVALID_IDENTITY` ≠
`E_AUTHZ_RELATION_UNKNOWN`). Restaurado y verificado por md5. Un primer intento de mutante
(`relation !== undefined && …`) resultó EQUIVALENTE —`isDeclared(type, undefined)` ya es `false`—, lo que
confirma que la regresión era el `return` temprano, no la ausencia de comprobación de tipo.

## 7 · Cifras de cierre (`$S/final.sh` → `$S/final2.log`)

Estáticas: `npx tsc --noEmit` ✅ · `npm run typecheck` ✅ · `npm run check:purity` ✅ · `npm run build` ✅.

| modo (todos con `OPENFGA_TEST_URL=http://localhost:8101`) | cierre-1 | cierre-2 | Δ | log |
|---|---|---|---|---|
| `npm test` (sqlite `:memory:`) | 1133 | **1141** | +8 | `/tmp/s.log` |
| `npm run test:sqlite-file` | 1157 | **1165** | +8 | `/tmp/sf.log` |
| `npm run test:pg` | 1252 | **1260** | +8 | `/tmp/pg.log` |
| `npm run test:mysql` | 1252 | **1260** | +8 | `/tmp/my.log` |

Cero ✖. Desglose de los +8 (los mismos en los cuatro modos): `relations.spec.ts` 5 (SIN relación, 🟡 2
unión, userset sin relación, 🟡 3 `membersOf`, ⚪ 4 congelado) + `relations_openfga.spec.ts` 2 (`undefined`
por manager y driver contra el `:8101`; ⚪ 5 clasificación de timeout) + `relations_events_docs.spec.ts` 1
(F13). Los casos AMPLIADOS (no nuevos): el F-05 del runner (título con `/membersOf`, bloque «SIN relación»;
el harness sigue en 22), el L-0 de `database` y F10 de letra. Sin `skip`. Aditivo: ningún caso existente
cambió de resultado (el C4 «servidor MUDO» sigue verde gracias al deadline propio de `#guard`).

Acumulado desde alpha.3 pre-cierre: 1107 / 1131 / 1226 / 1226 → **1141 / 1165 / 1260 / 1260** (+34 en cada
modo). Árbol: 21 ficheros modificados + `tests/relations_events_docs.spec.ts`; sin commit, `version` sigue
`2.4.0-alpha.2`.
