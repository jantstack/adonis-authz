# Fase 3 (lotes 3A + 3B) · Auditor de seguridad — verificación adversarial

> Contra el código real en `v2/fase-0`, HEAD `f563465` (`git diff 7a28cdf..f563465`).
> Suite base **verde con los hallazgos vivos**: 643/643 en PostgreSQL 18 + OpenFGA `:8101`
> (`TEST_DB=pg`, `OPENFGA_TEST_URL=http://localhost:8101`), incluidos «database (árbol SQL)»
> y «openfga (árbol SQL)». Reproducciones (no se tocó ni un archivo del repo) en
> `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/v6/`:
> `repro1_shadow.ts`, `repro2_effective.ts`, `repro3_varios.ts`, `repro4_global.ts`,
> `repro5_resiste.ts`. Todas ejecutadas contra PG.

## Veredicto en una línea

**NO APTA tal cual**: la unicidad de la que depende TODO el modelo de 3B —«dentro de un scope un
`(slug, nivel)` identifica un solo rol»— es un check *read-then-write* contra el memo, sin ninguna
barrera en la base, y las APIs de escritura y la policy de delegación siguen direccionando roles
**por slug**. Con dos peticiones concurrentes (o un `scopes.moved` legítimo) un tenant obtiene un
permiso que nunca tuvo. Dos 🔴 reproducidos de principio a fin. La policy de delegación en sí
(lista blanca, efectivos, C2, rank, inmutabilidad de globales) **resiste todo lo que le tiré**.

---

## Hallazgos (ordenados por severidad)

### 🔴 V1 · `#rolesAlong` resuelve el rol del actor POR SLUG: la policy de delegación le atribuye los permisos de un homónimo

- **Escenario**: `pepe` tiene asignado en `unit:U1` el rol local `lead@unit` **owner `organization|A`**
  (solo `docs:read`). En la misma cadena existe otro `lead@unit` **owner `unit|U1`** (con
  `billing:write`) → `manager.effectivePermissions(pepe, U1)` devuelve `['billing:write']` (¡no
  `docs:read`!) mientras `authorize(pepe,'billing:write',U1)` es `false` → `pepe` llama
  `defineScopedRole(pepe, U1, { permissions: ['billing:write'] })`, la policy lo acepta, crea el rol,
  se lo concede a un títere y **`authorize(títere,'billing:write',U1) = true`**.
- **Evidencia**: ✅ reproducido en PG (`repro2_effective.ts`, salida literal):
  `authorize(pepe, billing:write, U1) = false` · `effectivePermissions(pepe, U1) = [ 'billing:write' ]`
  · `ESCALADA: pepe delegó billing:write sin tenerlo` · `authorize(titere, billing:write, U1) = true`.
  Código: `src/manager.ts:682-710` — el driver resuelve por uuid y devuelve `{scope, role: slug}`
  (`database_driver.ts:rolesInChain`, `openfga_driver.ts` igual), y el manager **vuelve a resolver ese
  slug** con `catalog.roleVisible(role, level.type, ownerKeys.slice(index))`, que devuelve el owner
  **más cercano** (`catalog_cache.ts:675-689`), no el rol que el holder tiene. Afecta a los DOS
  drivers (es código del manager) y arrastra también `rank` (el actor hereda el rank del homónimo).
- **Steelman del defensor**: *«dos homónimos en la misma cadena no pueden existir: `#assertNoRoleCollision`
  lo impide»* → **no me convence**: ese check mira el árbol de HOY y un memo, y V2 muestra tres
  caminos legales para llegar a ese estado. Además `effectivePermissions` se documenta como
  «exactamente `{p | authorize(p)}`» (README) y aquí no lo es en NINGUNA de las dos direcciones.
- **Mitigación mínima**: `rolesInChain`/`listRoles` deben devolver el **uuid** del rol (o el manager
  resolver por uuid); nunca un ida y vuelta por slug en el camino de policy.

### 🔴 V2 · La unicidad de `(slug, nivel)` dentro de una cadena no la garantiza nadie: dos homónimos conviven (carrera de dos `define`, carrera `define` vs `sync`, o un `moved`)

- **Escenario A (dos `define` en paralelo, sin tocar el árbol)**: el mismo admin (o dos admins)
  lanzan a la vez `defineScopedRole(..., orgA, {slug:'lead',scopeType:'unit'})` y
  `defineScopedRole(..., unitU1, {slug:'lead',scopeType:'unit', permissions:['billing:write']})`.
  Cada uno comprueba la colisión contra **su** foto del catálogo; el unique de la base es
  `(slug, scope_type, owner_scope_key)` y los owners difieren ⇒ **ambos se insertan**. Luego
  `grant(x,'lead',U1)` resuelve al más cercano (`unit|U1`) ⇒ `authorize(x,'billing:write',U1)=true`.
- **Escenario B (`define` vs `syncAuthzCatalog`, el más feo)**: el deploy añade el rol **global**
  `viewer@unit` (solo `docs:read`) mientras el admin del tenant define su `viewer@unit` local con
  `docs:write`. Conviven; el local **tapa al global** (`roleVisible`) ⇒ la plataforma reparte «su»
  `viewer` por slug y entrega `docs:write`.
- **Escenario C (sin carreras)**: dos locales homónimos en subárboles disjuntos (legal y probado por
  el juez: «dos tenants definen el mismo slug») + un `scopes.moved` que junta las cadenas.
- **Evidencia**: ✅ los tres, en PG. A y C: `repro3_varios.ts` (`define(owner orgA) = fulfilled` +
  `define(owner U1) = fulfilled`, dos filas `lead@unit`, `authorize(currante, billing:write, U1) = true`)
  y `repro1_shadow.ts`. B: `repro4_global.ts` (`roles viewer@unit: [owner global, owner unit|…]`;
  `authorize(nuevo, docs:write, U1) = true` / `docs:read = false`, es decir el rol global **cambió de
  significado** dentro de ese subárbol). Código: `manager.ts:1048-1074` (check sobre `catalog`, una
  foto, sin bloqueo y con un `await` de resolutor entre el check y el `INSERT`), `catalog.ts:226-240`
  (el mismo check del sync, en otra transacción), `stubs/migration.stub:55` (el unique NO puede
  expresar «visible desde la misma cadena»).
- **Steelman del defensor**: *«es una ventana de milisegundos y `revalidate: 'always'` la estrecha»* →
  **no me convence**: la ventana la abre el propio código (entre `catalog.view()` y el `INSERT` hay
  `resolveChain` + 2 lecturas al driver + N `resolveChain` del check de colisión: cientos de ms con
  un árbol SQL), es alcanzable desde una API pública de tenant con dos peticiones, y el estado que
  deja es **permanente**. El escenario C ni siquiera necesita carrera.
- **Mitigación mínima**: serializar la escritura del catálogo (lock de la fila de
  `authz_catalog_version`, o `SELECT … FOR UPDATE` sobre `authz_roles` por `(slug, scope_type)`) y
  repetir el check de colisión **dentro** de la transacción, leyendo de la base, no del memo — más un
  chequeo de homónimos en `scopes.moved/attached`.

### 🟠 V3 · `grant`/`revoke`/`hasRole`/`listSubjects` siguen direccionando por slug: el admin de A concede el rol de B

- **Escenario**: `unit:U1` nace en el tenant B; el admin de B define `lead@unit` **owner `unit|U1`**
  con `billing:write`; el admin de A define su `lead@unit` **owner `organization|A`** con solo
  `docs:read` (ninguna colisión: subárboles disjuntos). La plataforma transfiere U1 a A
  (`scopes.moved`, operación legítima). El admin de A hace
  `grant(nuevo, 'lead', U1, { within: orgA })` creyendo dar lectura → se asigna **el rol de B** y
  `authorize(nuevo,'billing:write',U1) = true`.
- **Evidencia**: ✅ `repro1_shadow.ts` en PG: `rol realmente asignado: … <-- ES EL DE B`,
  `authorize(victima, billing:write, U1) = true`, `listRoles = ['lead']`, `hasRole = true`. En
  `repro2` el mismo mecanismo da la incoherencia contraria: `listRoles = ['lead']` con
  `hasRole(lead@unit) = false`. Código compartido por ambos drivers:
  `database_driver.ts:visibleRoleOrFail` + `catalog_cache.roleVisible`.
- **Steelman**: *«el `within` protege el cruce de tenants»* → **no me convence**: aquí `within` se
  cumple (U1 ya está dentro de A); lo que cruza es la *identidad del rol*, y el propio CHANGELOG/README
  dicen «el slug no identifica un rol, el uuid sí» — pero ninguna API pública acepta el uuid.
  `listSubjects('lead', U1)` enumera además holders del otro tenant, y `revoke` borra las
  asignaciones de TODOS los homónimos del scope (esto último cierra, no abre).
- **Mitigación mínima**: aceptar `RoleQuery` por `{ uuid }` en `grant`/`revoke`/`listSubjects`
  (`hasRole` ya lo admitiría) y documentar que el slug es ambiguo si el árbol se mueve.

### 🟠 V4 · La API de delegación es una SÉPTIMA escritura sin `within`: `requireWithin` no la cubre (contradice el plan B3 y el README)

- **Escenario**: config con `requireWithin: 'non-root'` y `requireActor: true`. `currante`, cuyo único
  rol es `miembro@app` (rank 5, `docs:read`, concedido en la raíz), llama
  `defineScopedRole(currante, orgB, {...})` con `orgB` **tomado del cuerpo de la petición** → crea un
  rol dentro del tenant B. Con el mismo rol raíz puede `updateScopedRole`/`deleteScopedRole` sobre
  roles locales de cualquier tenant con rank menor.
- **Evidencia**: ✅ `repro3_varios.ts` sección (b): `currante (solo miembro@app) creó un rol dentro de
  orgB: … organization|…`, con `requireWithin:'non-root'` puesto. Código: `manager.ts:748/798/871` —
  las tres firmas no tienen `options`, no llaman a `#assertWithin`/`#requiredWithin`
  (`ScopedRoleSpec`/`ScopedRoleChanges` en `types.ts:508-525` tampoco lo traen). El plan de fase pedía
  literalmente *«`within` = `ownerScope` implícito, `requireWithin` aplica»*; el README (línea 145)
  sigue diciendo «**All six writes**».
- **Impacto** (honesto): no es bypass de `authorize` — la policy de efectivos+rank contiene al admin
  de un tenant (probado: define en un hermano o en un ancestro ⇒ 422). Lo que abre es (a) escritura
  cruzada en el catálogo de otro tenant por cualquier holder con un rol en la **raíz**, (b) *squatting*
  de slug: un local `admin@organization` creado por un tenant hace que el `syncAuthzCatalog` del
  siguiente deploy falle 422 para siempre (V5 lo empeora), (c) edición/borrado de roles ajenos de
  rank menor.
- **Steelman**: *«sin permisos efectivos en el owner no hay delegación posible, y eso ya es
  contención»* → **me convence a medias**: contiene al tenant, no al holder con rol raíz, y deja al
  consumidor sin la barrera que el config le promete. Que el README diga «seis escrituras» mientras
  hay nueve es lo que convierte un hueco en un fallo.
- **Mitigación mínima**: `options?: ScopedWriteOptions` en las tres y `#assertWithin(ownerScope, …)`
  antes de nada; o documentar explícitamente la excepción en README/CLAUDE (invariante 15).

### 🟡 V5 · Un rol local cuyo owner desaparece del árbol es indeleteable por la API y bloquea el slug global para siempre

- **Escenario**: `defineScopedRole(admin, unitU1, {slug:'huerfano'})` → el consumidor destruye la unit
  y notifica `scopes.detached(unitU1)` → `deleteScopedRole` responde **422 `E_AUTHZ_UNKNOWN_SCOPE`**
  (resuelve el owner en fresco) y la fila del rol sobrevive; `purgeScope` no borra roles cuyo owner
  sea ese scope. A partir de ahí `syncAuthzCatalog` rechaza (422 `E_AUTHZ_CATALOG_CONFLICT`) cualquier
  rol global con ese `(slug, scopeType)` — para siempre, salvo SQL a mano o `manager.driver().purgeRole()`.
- **Evidencia**: ✅ `repro3_varios.ts` sección (d): `deleteScopedRole tras purgar el owner: 422
  E_AUTHZ_UNKNOWN_SCOPE` · `la fila del rol sigue: 1`. Código: `manager.ts:879` (`assertKnownScope`),
  `database_driver.purgeScope` (solo `authz_assignments`/`authz_denies`), `catalog.ts:226-240`.
- **Steelman**: *«`manager.driver().purgeRole(uuid)` es la salida documentada para la plataforma»* →
  **me convence a medias**: existe, pero nada lo dice en el README para este caso y la API «normal»
  falla justo cuando hay que limpiar. Combinado con V4, un tenant puede dejar minas de slug.
- **Mitigación mínima**: si el owner ya no existe, `deleteScopedRole` debería poder purgar igual
  (el rol no concede en ningún sitio); o que `purgeScope` arrastre los roles cuyo owner sea el scope.

### 🟡 V6 · El README dice que el motor «nunca evalúa el `actor`» — desde 3B es lo único que sostiene la delegación

- **Escenario**: un consumidor lee la línea 159 del README («Every write takes `{ actor }` … The
  engine never evaluates it») y pasa a `defineScopedRole` un actor procedente del cuerpo de la
  petición (como haría con `onWrite`) → cualquiera delega los permisos de cualquiera. El paquete solo
  valida **gramática** (`assertSubject`), que es lo correcto, pero no lo dice donde hace falta.
- **Evidencia**: ✅ `manager.ts:#requireActor` (solo `assertSubject`) + README 159 vs 255. El aviso
  fuerte («must come from the session, never from the request body») existe **solo** para `within`
  (README 155), que es la barrera que además falta aquí (V4).
- **Steelman**: *«es obvio que el actor es la sesión»* → **no me convence**: el mismo README enseña
  lo contrario tres párrafos antes y `within` sí tiene el aviso; la asimetría es la trampa.
- **Mitigación mínima**: una frase en §Scoped roles con el mismo tono que la de `within`.

### ⚪ V7 · Higiene (no explotable hoy, debilita defensas)

- `syncAuthzCatalog` puede **endurecer** `assignable_at` de un permiso sin revalidar los roles
  LOCALES que ya lo llevan, y `authz:catalog:diff` no los lista como deriva (solo compara spec↔base a
  nivel de permiso). El operador cree que la restricción quedó aplicada; los grants nuevos fallan 422
  y los viejos siguen concediendo (esto último sí es invariante 1, correcto). `catalog.ts:174-220`.
- `owner_scope_key` escrito a mano como `'app'` produce un rol visible en TODA la cadena (`app` está
  siempre en `chainKeys`): un global disfrazado que `syncAuthzCatalog` no gobierna. La API lo impide
  (`#assertOwnerScope`), `ownerOf()` no. `catalog_cache.ts:591`.
- `#notifyCatalog` se dispara DESPUÉS de escribir y **se traga** los fallos del hook: un sink de
  auditoría caído pierde `role_defined`/`role_purged` sin rastro más allá del log (mismo patrón que
  B6 del panel 1). `manager.ts:1095`.
- `authz_permissions.assignable_at varchar(500)`: con muchos niveles, MySQL no estricto truncaría el
  JSON ⇒ `parseAssignableAt` lanza 500 en cada `view()` (cerrado, pero es un corte de servicio total
  por un dato de config).
- `defineScopedRole` acepta `permissions: []`: un rol vacío es legal y ocupa el `(slug, nivel)` del
  tenant. Sin la policy de rank sería squatting libre; con ella es solo ruido.

---

## Lo que intenté y NO se rompió

Batería completa en `repro5_resiste.ts` (PG), todo 422 antes de escribir:

- **Escalada por delegación**: delegar un permiso que el actor no tiene (`E_AUTHZ_PERMISSION_NOT_DELEGABLE`);
  delegar uno que tiene pero no está en `delegablePermissions`; colar `org:settings` en un rol de nivel
  `unit` (`assignableAt`); pedir `rank` = el propio, `rank: 0`, `rank` no entero; sin `actor`; actor con
  uuid vacío.
- **C2 (lavado de deny vía títere)**: con deny del permiso en el owner **y** con el deny en un ancestro
  del owner ⇒ 422 en ambos casos, también al reintroducirlo por `updateScopedRole`. Cerrado.
- **Delegación hacia arriba/lados**: un admin de `unit` definiendo en su ancestro `organization` ⇒ 422;
  el admin de A definiendo en el tenant hermano B ⇒ 422; owner = raíz `app` ⇒ 422.
- **Roles ajenos**: el admin de B editando/borrando el rol de A ⇒ 422; un actor de rank menor que el rol
  ⇒ 422; editar o borrar un rol **global** ⇒ 422 `E_AUTHZ_ROLE_IMMUTABLE`; subir el rank de un rol por
  encima del propio ⇒ 422 (la escalera de rank es monótona: `rank < min(actorRank, topGlobalRank)`).
- **`updateScopedRole` re-subiendo un permiso perdido**: tras revocarle su rol al actor ⇒ 422; tras
  denegárselo ⇒ 422.
- **`grant` fuera del owner**: rol local de A en un scope de B ⇒ 422 `E_AUTHZ_ROLE_NOT_VISIBLE`; en un
  scope que el árbol no conoce ⇒ 422 `E_AUTHZ_UNKNOWN_SCOPE`. Nada escrito.
- **`purgeRole` (`database`)**: borra las asignaciones del rol en **todos** los scopes (owner y
  descendientes), los vínculos y la fila, y sube la versión compartida dentro de la misma transacción
  (5 → 6 observado); los denies del holder sobreviven (correcto: el deny no es del rol). `openfga` lo
  rechaza con 500 `E_AUTHZ_UNSUPPORTED` sin tocar nada (`#optional` resuelve el método antes de leer).
- **`assignableAt` nunca se evalúa**: no aparece en el SQL de `authorize` ni en `checksFor` de openfga;
  el caso del juez lo fija en ambos drivers (invariante 1 intacto).
- **Binding ids por uuid (3A)**: `parseBindingId` parte por el ÚLTIMO `|` y valida `isValidScope` +
  `isCatalogUuid`; un id 1.x (con slug, con `~`) no parsea ⇒ no es membresía ni concede, y el importador
  lo cuenta como `extra`. `importAuthzFactsToOpenFga` exporta las asignaciones de roles locales por
  `role_uuid` (join con `authz_roles`), así que `--prune` **no** borra tuplas legítimas: solo lo que SQL
  no tiene. No encontré colisión posible entre uuids de rol y de permiso (v7, tipos de objeto distintos).
- **Memo/versión (B7)**: `defineScopedRole`/`purgeRole` suben la versión como última sentencia de su
  transacción ⇒ otro proceso lo ve en su siguiente pregunta (caso del juez verde en PG y en openfga); un
  `grant` con el memo viejo falla cerrado (422 rol desconocido), nunca concede de más.
- **Regresiones pedidas, en PG con árbol SQL** (`tests/contract.spec.ts`, reporter spec, 400 casos
  verdes ×4 harness): L0.3 (scope desconocido ⇒ false / 422, jamás `[app]`), K1 (alias del uuid por
  mayúsculas/guiones no evade un deny), F1 (dos memos, versión compartida), F2 (`within` en las seis
  escrituras + origen de `moved`/`attached` + `requireWithin`), N1 (`hasRole` por `{slug, scopeType}`).
  Suite completa: **643/643** con `TEST_DB=pg` + OpenFGA.

## Preguntas abiertas para el arquitecto

1. **¿La identidad pública del rol pasa a ser el uuid?** V1 y V3 son la misma raíz: el modelo dice
   «el uuid identifica», la API dice «el slug». Si `grant`/`revoke`/`listSubjects` no aceptan `{uuid}`,
   cualquier corrección será un parche sobre la resolución «más cercano gana».
2. **¿Se acepta serializar las escrituras del catálogo?** Sin un lock (o un re-check dentro de la
   transacción) el invariante «un `(slug, nivel)` por cadena» no es un invariante, es una carrera
   ganada casi siempre. ¿Coste aceptable para una API de delegación (baja frecuencia)?
3. **¿`scopes.moved`/`attached` deben rechazar un movimiento que junte dos homónimos?** Es la única
   forma de mantener el invariante sin carreras, y encaja con que el paquete ya valida ciclos ahí.
4. **¿`defineScopedRole` lleva `within`** (y entonces el README pasa a «nueve escrituras»), o se
   documenta como excepción consciente porque la policy de efectivos ya contiene? Hoy el código y el
   plan 3B dicen cosas distintas.
