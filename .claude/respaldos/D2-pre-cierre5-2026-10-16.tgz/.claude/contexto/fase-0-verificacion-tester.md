# Fase 0 · Verificación independiente (tester-contrato) — 2026-08-28

Rama `v2/fase-0`, cambios sin commit. Node v22.23.2. OpenFGA `:8101` (v1.19.0) y un
segundo servidor levantado por mí en `:8104` con `MAX_RESULTS=3` (eliminado al terminar).

**Método**: no me creo el informe. Ejecuto cada criterio, y para los casos clave rompo
la condición que dicen probar y confirmo que el test se pone rojo. Estado final del
árbol de trabajo verificado byte a byte contra un `tar` tomado antes de empezar:
`diff -r` → **sin diferencias**.

## 1. Medidas de partida y de cierre (reales)

| Comando | Resultado medido |
|---|---|
| `npm test` (incluye `check:purity`) | **63 passed (63)**, 7 s |
| `npm run typecheck` | verde |
| `npm run build` | verde (`build/` borrado después) |
| `OPENFGA_TEST_URL=http://localhost:8101 npm test` | **101 passed (101)**, 8 s |
| `OPENFGA_TEST_URL=http://localhost:8104 OPENFGA_LIST_MAX_RESULTS=3 npm test` | **101 passed (101)**, 8 s |
| stores en `:8101` antes / después de la corrida con OpenFGA | **29 / 29** |
| stores en `:8104` tras la corrida | **0** |
| stores con prefijo `contract-`/`regrant-`/`authz-contract`/`spies-` en `:8101` | **0** |
| `grep` de `.skip` / `.only` / `.pin` en `tests/` y `src/testing/` | **ninguno** |
| `.github/workflows/ci.yml` | YAML válido; jobs `test`, `openfga`, `compat`; dos contenedores v1.19.0 |

Los 29 stores restantes en `:8101` son de las sesiones de panel (`audit-*`, `trunc*`,
`tester-facts*`, `dbdown*`, `demo-*`, `id-*`, `undef-*`, `api-loco-base`): ninguno de la suite.

## 2. Tabla pieza × criterio × resultado medido

| Pieza | Criterio del plan | Resultado medido (comando) | |
|---|---|---|---|
| **F0.1** | `npm test` + OpenFGA + `tsc` en verde | 63/63, 101/101, `tsc` limpio | ✅ |
| F0.1 | harness `database` **sin `level`** sigue pasando (solo los 19 de 1.x) | Registré un harness sin `level` en un spec temporal: **19 passed (19)**. Confirma además que `exhaustiveLists:true` no cuela el caso de 1.200 en nivel `core` | ✅ |
| F0.1 | un harness escrito contra la firma 1.1 **no compila** | `tsc -p tsconfig.test.json` → `error TS2345: … Property 'capabilities' is missing in type … but required in type 'DriverContractHarness'` | ✅ |
| F0.1 | `memoryScopeTree` exportado desde `./testing`, anti-ciclo | Exportado (`src/testing/main.ts`). Fuzz de 20.000 operaciones aleatorias `attach/move/detach` sobre 12 nodos: **0 ciclos, 0 cuelgues** (11.767 aceptadas / 8.233 rechazadas) | ✅ |
| **F0.2** | los 8 casos usan `tree.attach` | Verificado en el diff: 9, 10, 11, 14, 15, 16, 18, 19 pasan por `orgUnder(tree, APP_SCOPE)` | ✅ |
| F0.2 | **con árbol vacío el caso 10 falla** | Reproducido (fallback `?? []` + `orgUnder` sin `attach`): el caso 10 falla en los dos drivers por aserción (`expected false to be true`, `contract.ts:275`) | ✅ |
| F0.2 | — | **Números reales de la demostración: 48 passed, 20 failed (68)**, no los 6/49 del informe. Ver §5 | ⚠️ |
| **F0.3** | 9 casos nuevos verdes en ambos drivers | Presentes y verdes; 6 de ellos verificados por mutación (§4) | ✅ |
| **F0.4** | par `truncationSignal:false` con `exhaustiveLists` (1.200 asignaciones) | Registrado y verde solo en `database`; verificado rojo al truncar el driver a 1.000 | ✅ |
| F0.4 | par `false` para `openfga` | **No se registra ningún caso**: `whenFalse` hace `if (!harness.exhaustiveLists) return`. Es un skip silencioso con otro nombre | ❌ |
| F0.4 | `hierarchyFacts:false` → "su par es N1" | N1 se registra por `since('2.0')`, no por `caseFor`: un harness `core` con `hierarchyFacts:false` no tiene par ninguno | 🟡 |
| **F0.5** | `authorize` con cadena de 3 llama a `resolveAncestors` **1 vez** en ambos drivers | Verde en los dos; verificado rojo mutando `chain()` de cada driver para llamar dos veces (§4, M9 y M10) | ✅ |
| F0.5 | `withFailing` genérico eleva `withFailingRead` | Hecho; `contract.spec.ts` delega en el helper | ✅ |
| **F0.6** | conteo de stores igual antes y después | 29 → 29 en tres corridas (`:8101`), 0 en `:8104` | ✅ |
| F0.6 | script de prune one-shot | `node scripts/openfga_prune_stores.mjs --prefix … --dry-run` → `29 stores, 0 con prefijo`. Sin `--prefix` sale con código 2 sin borrar | ✅ |
| **F0.7** | `npm test` falla si aparece `from '#config/x'` en `src/` | `echo "import c from '#config/authorization'" > src/_verif_demo.ts && npm test` → **exit 1**, `✖ purity: src/_verif_demo.ts → importa aliases del consumidor` **antes** de arrancar la suite. Archivo borrado | ✅ |
| F0.7 | regla 2 (módulos) ejercitada con fixture | 4 tests en `tests/purity.spec.ts`, verdes; `MODULES = []` en producción → la regla está **inerte** en el repo real | 🟡 |
| **F0.8** | suite verde contra un 2.º OpenFGA con `MAX_RESULTS=3` | Levanté `openfga-verify` en `:8104` (v1.19.0, `LIST_OBJECTS`/`LIST_USERS` = 3, datastore memory): **101/101**, 0 stores huérfanos. Contenedor eliminado | ✅ |
| F0.8 | `harness.limits.listMaxResults` expuesto | Declarado en la interfaz y rellenado desde `OPENFGA_LIST_MAX_RESULTS`, pero **`grep limits src/testing/contract.ts` → solo la declaración**: nadie lo lee | 🟡 |
| F0.8 | CI con dos contenedores, imagen v1.19.0 | YAML válido, dos `docker run`, healthz de ambos, `npm test` dos veces | ✅ |
| **F0.9** | `CHANGELOG` con `[Unreleased] — 2.0.0`, README intacto | Sección presente con estilo problema→decisión→qué NO se hace; `git diff` no toca `README.md` | ✅ |
| **Extra** | `contract_harness.spec.ts`: capacidad `true` sin par ⇒ lanza | **Es real**: puse `truncationSignal: true` en el harness real de `contract.spec.ts` y la suite entera aborta con `[contrato database] declara 'truncationSignal: true' … (pendiente de Fase 1 (L0.7))` en `contract.ts:151` | ✅ |

## 3. Verificación de la regla "capacidad `true` sin par ⇒ lanza"

Sí, es real y no es decorativa: se ejecuta antes de `test.group`, con lo que el fichero
entero deja de importarse y la suite falla. Verificado en el harness de producción, no
solo en el fake del spec.

Matiz: **cubre las cinco capacidades**, porque `PENDING_TRUE_PAIRS` las lista todas. Es
decir, hoy `capabilities` solo admite un valor legal (`false` × 5). El mecanismo de
pares `{ whenTrue, whenFalse }` **nunca se ha ejecutado end-to-end**: la rama `whenTrue`
de `caseFor` es código inalcanzable (lo demostré quitando la entrada de
`truncationSignal` de `PENDING_TRUE_PAIRS`: no llega al `throw` de `whenTrue`, revienta
antes en `test.group` con `Cannot import japa test file directly`).

## 4. Tests que rompí y se pusieron rojos (prueba de que prueban)

Todas las mutaciones son sobre código de producción o de infraestructura del árbol,
nunca sobre la aserción. Todas restauradas.

| # | Mutación | Archivo | Rojo esperado | Rojo medido |
|---|---|---|---|---|
| M1 | `ancestorsOf` devuelve solo el padre inmediato (`chain.slice(0,1)`) | `src/testing/scope_tree.ts` | N1 | **8 failed / 68**: N1, N2, N6, I7set × 2 drivers |
| M2 | `authorize` busca el deny en `[scope]` en vez de en `chain` (el deny deja de heredar) | `src/drivers/database_driver.ts` | N2 | **1 failed / 32**: solo N2. *El caso 11 de 1.x NO lo detecta* (su org cuelga directo de app) |
| M3 | `tree.move` convertido en no-op | `src/testing/scope_tree.ts` | N4 | **4 failed / 68**: N4 y N5 × 2 drivers |
| M4 | `authorize` concede si el holder tiene un rol con `rank >= 100` (el motor evalúa rank) | `src/drivers/database_driver.ts` | I8 | **1 failed / 32**: solo I8 |
| M5 | `deny` sin guarda de idempotencia + sin índice `unique` + `removeDeny` borra una sola fila | driver + `tests/helpers/schema.ts` | I6b | **1 failed / 32**: solo I6b |
| M6 | `listRoles` enumera la herencia (usa `chain`) | `src/drivers/database_driver.ts` | I7set | **2 failed / 32**: I7set y el caso 18 |
| M7 | `listSubjects` ignora el filtro de scope y de `scope_type` (devuelve holders de otra org) | `src/drivers/database_driver.ts` | caso 15 con igualdad de conjunto | **1 failed / 32**: caso 15. **La aserción vieja (`includeMembers` + `notInclude(expired)`) habría pasado** → el cambio a `deepEqual` es load-bearing |
| M8 | `listScopes` trunca en 1.000 en silencio | `src/drivers/database_driver.ts` | par `truncationSignal:false` | **1 failed / 32**: el caso de 1.200 |
| M9 | `listScopes` devuelve cada scope duplicado | `src/drivers/database_driver.ts` | igualdad de conjunto | **3 failed / 32**: caso 16, I7set y el de 1.200 → **los duplicados sí se detectan** |
| M10 | `chain()` llama a `resolveAncestors` dos veces (driver `database`) | `src/drivers/database_driver.ts` | espía | **1 failed / 4**: `espías [database]` |
| M11 | `chain()` llama a `resolveAncestors` dos veces (driver `openfga`) | `src/drivers/openfga_driver.ts` | espía | **1 failed / 4**: `espías [openfga]` |
| M12 | `truncationSignal: true` en el harness real | `tests/contract.spec.ts` | regla de capacidades | La suite **aborta** al importar el fichero |
| M13 | quitar `truncationSignal` de `PENDING_TRUE_PAIRS` | `src/testing/contract.ts` | `contract_harness.spec.ts` | **1 failed / 1** |
| M14 | `#config/authorization` en `src/` | `src/_verif_demo.ts` | gate de pureza | `npm test` **exit 1** antes de la suite |

Conclusión: **N1, N2, N4, I8, I6b, I7set, el par `truncationSignal` y los dos espías
fallan cuando se rompe lo que dicen probar.** Ninguno pasa por casualidad. Y M2/M4/M5
son especialmente valiosos porque el mutante **solo** lo caza el caso nuevo: N2 es el
único guardián del deny heredado a profundidad 3, I8 el único del invariante 8 e I6b el
único del "re-deny no duplica".

## 5. Reproducción de la demostración F0.2 — discrepancia con el informe

Reproduje la manipulación exacta que describe el informe (fallback `ancestors ?? []` en
`tests/contract.spec.ts` + `orgUnder` sin `tree.attach` en `src/testing/contract.ts`) y
corrí `OPENFGA_TEST_URL=http://localhost:8101 … --files tests/contract.spec.ts`:

```
Tests  48 passed, 20 failed (68)
```

**El informe dice `43 passed, 6 failed (49)`.** El total de 49 no es alcanzable con el
código entregado (hoy `contract.spec.ts` con OpenFGA registra 68 tests), así que esa
medición es de un estado anterior y no se volvió a ejecutar.

Desglose real de los 20 fallos (10 por driver):

- **Por aserción de contrato** (los que demuestran de verdad que ya no pasan en falso):
  caso 10 (`herencia hacia abajo`), caso 11 (`deny en el scope cercano`), caso 14
  (`hasRole … herencia`) → **3 × 2 drivers = 6**. Coincide con la lista del informe.
- **Por error del fixture, no por semántica**: los 7 casos de nivel 2.0 que usan
  `unitUnder` mueren con `Error: memoryScopeTree: el padre organization:… no existe en
  el árbol` (`scope_tree.ts:65`) → **7 × 2 = 14**. Eso no demuestra nada sobre el
  driver: es el guard del árbol de test protestando. El informe los omite.

Segunda medición, más reveladora: **quitando solo los `attach` y dejando el fallback
`?? [APP_SCOPE]`** (que es como corre hoy la suite):

```
Tests  54 passed, 14 failed (68)
```

Los 14 fallos son *todos* los casos 2.0 muriendo en el guard del árbol. **Los casos 10,
11 y 14 pasan igual.** Confirma el hallazgo 1 del informe y lo agrava: mientras el
fallback sea `[APP_SCOPE]`, los 8 casos reescritos en F0.2 **no castigan** a un driver
que ignore el árbol; el invariante 1 se prueba porque el harness cuelga las orgs, no
porque el juez lo exija. La demostración solo funciona con la doble mutación.

También confirmo lo que el informe dice de los otros cinco: 9, 15, 16, 18 y 19 siguen
verdes con árbol vacío. Es decir, de los 8 casos de F0.2, **solo 3 dependen realmente de
la arista del árbol**. El plan solo pedía que fallara el 10, así que el criterio se
cumple; la promesa del CHANGELOG ("with an empty tree, the inheritance cases now fail")
es cierta solo si "inheritance cases" = {10, 11, 14}.

## 6. Huecos

**H1 · Las capacidades no tienen juez.** Cinco capacidades declaradas, **un solo caso
registrado** (`truncationSignal:false`, y solo para `database`). `transactions`,
`singleCheckAuthorize`, `injectableClock` y `hierarchyFacts` no tienen caso ni en `true`
ni en `false`: declarar `false` hoy no se verifica en ninguna de las cuatro. La rama
`whenTrue` de `caseFor` es código muerto inalcanzable. El mecanismo existe pero está sin
estrenar.

**H2 · `exhaustiveLists` es un `skip` con otro nombre.** Para `openfga`, `whenFalse`
hace `return` sin registrar nada. El harness declara `truncationSignal: false` y **nadie
comprueba esa declaración**. Es exactamente la regla que la Fase 0 dice hacer ejecutable.
Al menos debería registrarse un caso honesto para el lado con tope (p. ej. "con
`limits.listMaxResults = k`, `listScopes` de `k+1` asignaciones devuelve `k` y **no**
lanza — comportamiento hoy, marcado explícitamente como defecto L0.7"), que es el que se
volverá rojo→verde en Fase 1.

**H3 · El fallback `?? [APP_SCOPE]` neutraliza el árbol.** Ya explicado en §5. Está
documentado como L0.3 (Fase 1), pero conviene que quede escrito que **F0.2 no cierra
"los casos pasan en falso"**: lo cierra a medias.

**H4 · `limits.listMaxResults` se declara y no se consume.** El segundo job de CI dobla
el tiempo del job `openfga` sin añadir ninguna aserción nueva hoy. Su único valor real
—que ningún caso del juez enumere más de 3 objetos— pasa por casualidad, no por
aserción. Barato de arreglar: un caso que enumere `limits.listMaxResults + 1` y fije el
comportamiento actual.

**H5 · La regla 2 de pureza está inerte.** `MODULES = []`: solo la ejercita el fixture
del test. Cuando nazca `src/catalog/` en la Fase 3, alguien tiene que acordarse de
añadirlo a la lista. Propuesta: derivar `MODULES` del filesystem (todo directorio bajo
`src/` que no esté en una lista blanca `drivers|models|traits|middleware|testing`), y así
el primer módulo nace vigilado de verdad.

**H6 · `FORBIDDEN_ALIAS` es frágil.** `/from\s+'#[^']+'/g` no ve `import("#x")`,
`require('#x')`, `export … from "#x"` ni comillas dobles. Ahora que es puerta de
`npm test` y no solo del build, merece endurecerse.

**H7 · I7set(b) pasa en parte por razón débil.** `listRoleScopes(alice, 'unit')` da `[]`
trivialmente: `CONTRACT_CATALOG` no tiene ningún rol con `scopeType: 'unit'`, así que
nunca podría devolver nada. De hecho **en toda la suite no hay un solo `grant` sobre un
scope de tipo `unit`**: `unit` solo aparece como objeto de `authorize`. La parte que sí
prueba algo es `listScopes` y `listRoles(alice, unit)`, confirmadas por M6.

**H8 · `detach` no se prueba contra ningún driver.** Solo vive en `scope_tree.spec.ts`.
N7/N8 están diferidos con nota a Fase 1, así que es una deuda declarada, no un descuido.

**H9 · Nadie fija el orden de las escrituras.** Todos los casos de deny hacen
`grant` → `deny`. No hay ninguno con `deny` → `grant` (¿un grant posterior levanta el
deny? debe seguir denegando). Es un caso barato y del núcleo del invariante 2; lo pediría
para Fase 1 si no antes.

**H10 · El teardown de stores no tiene test.** Se verifica a ojo con `curl`. Si alguien
rompe `deleteCreatedStores` en un refactor, nadie se entera hasta que el servidor local
vuelva a tener 300 stores. Propuesta barata: en `group.teardown` del harness openfga,
listar `/stores` y afirmar 0 con prefijo `contract-`.

**H11 · Ruido de infraestructura en los fallos.** El guard "padre desconocido" de
`memoryScopeTree` (desviación 4, buena decisión en sí) hace que un error de fixture
aparezca en la salida del juez con la misma pinta que un fallo de contrato — lo vimos en
§5. No bloqueante, pero explica cómo el informe pudo leer mal su propia demostración.

**Sin hallazgos**: no hay `skip`/`only`/`pin`; `memoryScopeTree` no deja pasar ciclos
(20.000 operaciones aleatorias); `level` sin declarar excluye de verdad los casos 2.0
(19/19 medidos); la igualdad de conjunto en `list*` es estricta con **duplicados** (M9) y
con **elementos de más** (M7); es insensible al orden por diseño (`.sort()`), que es lo
correcto para un conjunto.

## 7. Discrepancias con el informe del implementador

| # | Informe dice | Medido | Gravedad |
|---|---|---|---|
| D1 | Demostración F0.2: `43 passed, 6 failed (49)` | `48 passed, 20 failed (68)`. El total 49 es inalcanzable con el código entregado | **Media**: la evidencia central de la fase no se re-ejecutó contra el estado final |
| D2 | Los fallos de la demo son los casos 10, 11, 14 | Correcto para los fallos *por aserción*, pero omite 14 fallos más por `Error` del fixture en los casos 2.0 | Media |
| D3 | `MAX_RESULTS=3` → 100/100 | 101/101 (el informe ya avisa: "medido antes del último test añadido") | Baja |
| D4 | CHANGELOG: "declaring `false` is verified too" | Falso para 4 de las 5 capacidades, y falso para `truncationSignal` en `openfga` | **Media**: el CHANGELOG es contrato público |
| D5 | Estado de partida "281 stores" vs plan "92" | No verificable a posteriori; el resultado final (29, 0 de test) sí lo verifiqué | Nula |
| D6 | "Ningún archivo de `src/drivers/*`, `src/manager.ts`, `src/catalog.ts` fue tocado" | Confirmado con `git status`/`git diff` | Nula (a favor) |

El resto del informe es honesto y coincide con lo medido, incluidos sus propios hallazgos
1 (el fallback tapa el árbol) y 3 (el resolutor que lanza produce un `Error` crudo, no un
`AuthorizationBackendError`).

## 8. Veredicto

### APTA CON CORRECCIONES

La Fase 0 hace lo que prometía: el juez ya conoce el árbol, los nueve casos nuevos son
load-bearing (probado por mutación uno a uno), la suite corre en los tres entornos
(SQLite, OpenFGA default, OpenFGA con tope 3), el gate de pureza aborta `npm test`, los
stores dejaron de acumularse y la regla de capacidades es ejecutable de verdad. Ningún
cambio de comportamiento de driver. Nada bloqueante.

Correcciones antes de dar la fase por cerrada:

1. **(Documental, obligatoria)** Rehacer la demostración F0.2 del informe con los números
   reales: 68 tests, 20 fallos, de los cuales **6 por aserción** (casos 10, 11, 14 × 2
   drivers) y **14 por el guard del árbol** en los casos 2.0. Y dejar escrito que sin
   tocar el fallback `?? [APP_SCOPE]` **ningún caso core falla** (medido: 14 fallos, todos
   2.0), es decir que F0.2 cierra el "pasan en falso" solo para 3 de los 8 casos.
2. **(Documental, obligatoria)** Corregir en `CHANGELOG.md` la frase "declaring `false`
   is verified too": hoy solo se verifica `truncationSignal:false` y solo en el harness
   `database`. Decirlo tal cual, con la lista de lo que queda sin juez.
3. **(Código, recomendada — H2)** Registrar un caso para el lado `truncationSignal:false`
   *con* backend con tope, que fije el comportamiento de hoy y lo marque como L0.7. Sin
   él, `exhaustiveLists` es un `skip` disfrazado y contradice la regla de la propia fase.
4. **(Código, recomendada — H4)** Consumir `limits.listMaxResults` en al menos un caso,
   para que el segundo servidor de CI aporte una aserción y no solo tiempo.
5. **(Código, barata — H5, H6)** Derivar `MODULES` del filesystem y endurecer el patrón
   de aliases (comillas dobles, `import()`, `require`).
6. **(Código, barata — H9, H10)** Un caso `deny` → `grant` (el grant posterior no levanta
   el deny) y una aserción de fuga de stores en el teardown del harness openfga.

Las correcciones 1, 2, 5 y 6 son de minutos. La 3 y la 4 pueden ir al principio de la
Fase 1 junto a L0.7, que es su sitio natural.

---

**Constancia de no-intrusión**: 14 mutaciones aplicadas y restauradas; `build/` generado
por `npm run build` y borrado; contenedor `openfga-verify` (`:8104`) creado y eliminado;
ficheros temporales `src/_verif_demo.ts`, `tests/_verif_legacy_harness.ts` y
`tests/_verif_core.spec.ts` creados y borrados. Comprobación final:
`diff -r` contra el snapshot previo → **sin diferencias**; `git status --short` idéntico
al inicial (9 modificados, 7 sin trackear + `CLAUDE.md`).
