# Respuesta a COGNITIV — recibido vuestro «Respuesta al plan 2.5» (2026-10-15)

**De:** `@jantstack/adonis-authz` · **Para:** `api-cognitiv` · **Re:** `respuesta-paquete-authz-2026-10-15.md`

Gracias: las 13 respuestas cuadran con lo firmado el 2026-10-14 y ninguna reabre un lote. Lo que entra en el plan por vuestros datos:

1. **Versión fijada exacta.** Perfecto; cada alpha llevará su nota de rupturas en el CHANGELOG y en «Upgrading to 2.5.0».
2. **Partición canónica.** 0 de 65 en desarrollo. Mandadnos la cifra de producción cuando la tenga el owner; si sale > 0, la rama `--rekey` de la receta está probada en PostgreSQL.
3. **alpha.2 (lote B, en curso).** Confirmado que solo os toca el import de `runRelationsReconcile`, que pasa a `@jantstack/adonis-authz/relations/reconcile`. Lo demás (ciclos de `includes`, claves desconocidas, usersets ≠ `group#member`, `requireTransaction` por defecto) ya lo cumplís. `truncated` por deadline en `listObjects` de `openfga` llega en alpha.2; tratarlo como 503 es la lectura correcta y es la que escribirá el README.
4. **`decideMany` (alpha.3).** Misma firma que proponéis y las mismas garantías que `checkMany`: tope 50, `[]` ⇒ 422, error de un ítem ⇒ 503 para todos, orden de salida = orden de entrada. Queda como requisito explícito del lote D.
5. **`OPENFGA_MODEL_ID` obligatorio con `openfga` en alpha.3**: es exactamente D14. El runbook del lote D dirá «provision → fijar `modelId` → desplegar», en ese orden.

**Vuestras tres peticiones**

- **`purgePartition`**: es una operación nueva del puerto, gemela de `purgeScope` de roles (prueba de cero incluida). Tiene sentido y cierra el riesgo del censo fuera de transacción que señalamos. **Entra en el lote C (alpha.4)**, con panel antes de implementarse, como capacidad opcional (`capabilities.purgePartition`): `database` en una transacción con prueba de cero; `openfga` por lotes con barrido y prueba de cero, y los estados de una operación larga (abortada a medias, repetida) escritos y con caso. Vuestro barrido sigue valiendo hasta entonces.
- **`decideMany` para un invitado de otra partición**: ya es así por construcción (un holder no lleva partición; solo los usersets la llevan y se cortan). Lo nombramos como caso de la suite común en alpha.3, con el mismo caso para `check`/`checkMany`.
- **`truncated` en `listObjectsForSubject`**: sí, misma forma; es una propiedad de toda enumeración del driver desde alpha.2 y la guardia de superficie la exige en alpha.4.

**RC:** de acuerdo en hacerla coincidir con el final de vuestra F0. Mandadnos la fecha cuando la cierre vuestro owner; los 7 días del ensayo empiezan con el tarball exacto de `2.5.0-rc.1` (`--tag next`).
