# Lote alpha.9 · B — el reconcile de hechos respeta el store COMPARTIDO

Prerrequisito: el lote A (banderas de ace) terminó y está verificado. Leer `alpha9-informe-A.md` y el diff antes de
tocar nada. Decisiones: `decisiones-dueno-2026-08-28.md` §2026-09-11 (2) — **no las reabras**. Evidencia:
`panel-shared-store-{auditor,analista}.md` (medidas, repro `.claude/reproducciones/shared-store-tipos-legado.sh`).

## S1 · `familyOfTuple` sin catch-all (trivial, camino crítico)
`src/drivers/openfga_driver.ts:3450`. Constante PROPIA del módulo (no `RESERVED_FACTS_TYPES`, que incluye `group`):
los CUATRO tipos que el reconcile de hechos gobierna — `scope`, `role`, `role_binding` y el obsoleto `deny_binding`
(2.2: `enumerateFacts` todavía lo lee y emite como deny, 3b-8 · A2, así que es PROPIO aunque no se pueda escribir) —
con el porqué en el docblock y la regla escrita: «un tipo nuevo de `facts` entra aquí en el MISMO commit».
Lo que no está en la lista ⇒ **`foreign`**, y sale ANTES de `deletes.push` y de `phases[...]`. La clasificación **no
lee nada** (ni config, ni modelo, ni tablas).

## S2 · Casos (fácil) — el rojo es la medida del analista
- Store compartido (contra `:8101`): hechos + relaciones (`document`, `space` y **`group`**) ⇒ `--prune` borra **0**
  ajenas, el store queda intacto y `clean = true`. ROJO hoy: borra las 60 y —peor— reporta `clean = true`/exit 0.
- **Prueba decisiva de que lo propio sigue barriéndose**: `deny_binding` de 2.2 y un `role_binding` con id de 1.x en el
  store ⇒ `--prune` los BORRA (2 de 2) mientras las ajenas sobreviven.
- Mutantes obligatorios: (a) devolver el catch-all `return 'facts'` ⇒ rojo; (b) **usar `RESERVED_FACTS_TYPES` tal cual
  como lista blanca ⇒ rojo** (borraría `group`); (c) decidir «ajena» leyendo `relations.config` ⇒ rojo con el config
  ausente (el caso de COGNITIV).
- Sin `--prune`: las ajenas ya no ensucian `skipped['extra-fact']` ⇒ `clean` puede ser `true`.

## S3 · Reporte (fácil)
`foreign?: { tuples: number; types: Record<string, number>; relations?: number; unknown?: number }` de nivel superior
en el reporte del reconcile, **fuera de `skipped`** (`commands/authz_reconcile.ts:165` decide `clean` con eso) y fuera
de `details` (tope 200: miles de ajenas expulsarían los `extra-fact` reales, que son los que conceden). `phases` NO
crece. `reconcileLines` (pura) imprime, cuando `foreign.tuples > 0`: que el store es COMPARTIDO, cuántas ajenas se
respetaron y por tipo, y con `--prune` «se han respetado N tuplas ajenas». Nunca deriva, nunca exit ≠ 0.

## S4 · Partir el reporte (fácil-medio, opcional si aprieta el tiempo)
Si el manager tiene `relations.config`, `foreign` se parte en `relations` (tipos declarados + `group`) y `unknown`;
sin config, todo va a `unknown`. **Solo para el REPORTE**: la decisión de borrar ya está tomada en S1 y no mira esto.

## S5 · Docs (medio)
CHANGELOG `[Unreleased] — 2.4.0-alpha.9` (continuar el del lote A), en estilo 1.1.0 y **empezando por el impacto**:
`authz:reconcile --prune` borraba TODAS las tuplas de relación de un store compartido (60 de 60 medidas) y reportaba
`clean = true` con exit 0; quien lo haya corrido con `--prune` tiene que reconstruir sus relaciones con
`authz:relations:reconcile`. Qué NO se hace y por qué: no se filtra el `Read` (400 medido), no se toca `relations/`
(no hay defecto simétrico: medido), no hay `--prune-foreign`, `phases` no crece.
**Corrige en este lote** la frase publicada de `CLAUDE.md` («la basura de un modelo anterior, que se lee y se borra
aunque ya no se pueda escribir» ⇒ vale solo para los CUATRO tipos propios) y el docblock de `readEveryTuple`.
README: sección del reconcile — store compartido, `foreign`, y el **residuo declarado**: las tuplas de un tipo de
relación NO declarado (o retirado de `relations.config`) no las barre nadie y resucitan si el tipo se re-declara;
salida hoy: declarar el tipo y `authz:relations:reconcile --prune`. Roadmap 2.5: `--prune-undeclared`.

Base: las cifras del informe A. Aditivo. Informe INCREMENTAL en `alpha9-informe-B.md`. Verificación: las 4 corridas.
