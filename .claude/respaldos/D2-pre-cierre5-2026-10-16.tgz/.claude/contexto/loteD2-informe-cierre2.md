# Sublote D2 · cierre 2 — informe del implementador (2026-10-16)

Brief: `loteD2-cierre2-coordinador.md` (N1–N6). Origen: re-ataque `loteD2-auditor-cierre.md`.
Árbol: `main` sobre `75353fe` (D1), con D2 + cierre 1 + cierre 2 SIN commit. Sin `npm version`, sin push, CHANGELOG
solo bajo `[Unreleased]` (bloque `[2.5.0-alpha.1]` y `[2.5.0-alpha.2]` intactos: `git diff HEAD -- CHANGELOG.md` = 0
líneas borradas).

## Cómo se hizo (reanudación)

- El implementador anterior se cortó (última escritura 22:56 del 15-10) **sin informe**. Respaldo intacto en
  `.claude/respaldos/D2-cierre2-parcial-20261016-1013.tgz` (no lo toqué).
- Inventario: lo hice contrastando el brief con el árbol (grep de «cierre 2 de D2», lectura de `tuple_order.ts`,
  `order_bruteforce.ts`, los casos y el CHANGELOG) y **ejecutando** la suite completa antes de tocar nada:
  `:memory:` + OpenFGA `:8090` = **2016 passed, 2 skipped**, typecheck limpio, `relations_order_exhaustive` 7/7.
- Resultado del inventario: **el anterior había dejado N1–N6 implementados casi enteros** (código, casos, guardia,
  README, CHANGELOG). Lo que faltaba o estaba flojo, y que hice yo:
  1. **N1 · espía-barrera** del brief: el caso solo tenía un `check` concurrente con `Promise.all` (no garantiza caer
     ENTRE los dos `Write`) y además su siembra era redundante (U ∈ g directo Y por h ⊂ g): con el mutante «sin la
     negativa» el hueco quedaba tapado por el otro camino y el `check` daba `false`. Rehecho (ver N1).
  2. **N1 · gemelo de roles** con EVIDENCIA ejecutable (el anterior solo lo escribió en el CHANGELOG).
  3. **N1/N4/N6 · mutantes medidos** (no había ninguno fuera de la guardia; los de orden sí estaban).
  4. **N4 · un ciclo de `continuation_token`** (`a → b → a`) colgaba el barrido para siempre ahora que no hay cota
     (la guarda solo miraba el token inmediato). Arreglado con caso y mutante.
  5. **N3 · el título de `relations.reconcile.order`** seguía siendo universal (el auditor lo marcó ⚪); ahora nombra
     el residuo. Actualizadas las 9 referencias de `expectRed` en `guard_mutants.json`.
  6. CHANGELOG: las cuatro precisiones anteriores.
  7. Verificación completa (4 modos + 3 gates), en primer plano.

## N1 🟠 · renovación de una membresía portadora en `openfga` (L10, 5.ª aparición)

**Qué hay (implementador anterior, verificado por mí):**
- `src/drivers/openfga_relations_driver.ts` · `relate`: si la tupla existe con otra caducidad, el objeto es `group` y
  `#carriedDeny` encuentra un deny vivo de la partición sobre `group:G#member` o sobre un grupo que lo contiene
  (cierre por anidación hacia arriba) ⇒ **409 `E_AUTHZ_RENEWAL_UNSAFE`** (`RenewalUnsafeError`, `src/errors.ts`,
  exportado) con **cero `Write`** y la receta en el mensaje («`unrelate` + `relate` aceptando la ventana, o
  `removeDeny` antes»). Coste: solo en renovación de membresía, un `Read` por `user`+tipo por tipo con deny y otro de
  padres, por grupo del cierre.
- Renovación permitida: si el 2.º `Write` falla tras el delete ⇒ `markPartialWrite` ⇒ el `RelationsManager` notifica
  `indeterminate: true` (invariante 13).
- Capacidad nueva **`atomicRenewal`** (D15: `?:`, normalizada a `false`; `database` `true`, `openfga` `false`) con su
  par en `runRelationsDriverContract` (`src/testing/relations_contract.ts`; el doble se porta como declara).
- Reconcile: `planPartition` saca de `toUpdate` la membresía portadora si el destino no declara `atomicRenewal` ⇒
  residuo `renewal-unsafe` (destino) con receta; mismos números en `--dry-run` y real; línea con prefijo estable
  `sin renovar (renewal-unsafe) destino:`; exit ≠ 0. `partialReconcileError`: `partial = writes > 0 ||
  isPartialWrite(error)` ⇒ la línea jamás dice «sin escribir nada» si el driver borró.
- README (`E_AUTHZ_RENEWAL_UNSAFE` en la tabla de errores; bloque de `relate`), CHANGELOG.

**Lo que hice yo:**
- `tests/relations_openfga.spec.ts`, caso «🟠 N1 · renovar … TRANSPORTA un deny»: **espía-barrera** — Proxy sobre
  `client.write` que, tras cada `Write` que SOLO borra y antes de devolver el control, hace `check` del sujeto (o sea,
  exactamente entre el delete y el write). Dos sujetos SIN redundancia: `user` ∈ g directo; `nested` ∈ h, h ⊂ g; deny en
  `g#member`. Afirma `barrier` sin `true` y vacía (no hay dos `Write`) en las dos renovaciones, y como CONTROL que la
  renovación de una membresía sin deny SÍ dispara la barrera (`[false]`). **Rojo→verde medido**: con la negativa
  quitada, `ROJO (N1): un check ENTRE los dos Write concedió a un denegado: expected [ true ] to not include true`
  (reproduce el `gapEntreLosDosWrite: true` del auditor); con el código, verde.
- `tests/openfga_facts.spec.ts`, caso nuevo «gemelo de roles de N1»: ver línea (a).

**Cuatro líneas de cierre (CLAUDE.md punto 5):**
- **(a) Gemelos.** *Roles* (`grant` con otra caducidad en `facts`): **también renueva en dos llamadas**
  (`replaceAssignment`: `deleteTuples` + `writeTuples`, `src/drivers/openfga_driver.ts:1213`), pero **no aplica**
  porque el deny de roles es `scope#denied_<P>` cuyo sujeto directo son SOLO holders y solo se hereda por `parent`: un
  `assignee` no transporta nada que corte, y en el hueco el holder solo PIERDE el grant (fail-closed). Evidencia
  ejecutable: caso nuevo en `tests/openfga_facts.spec.ts` sobre el modelo generado (`denied_<P>` solo en `scope`, solo
  holders, sin userset ni `*`, reescritura sin `binding`/`assignee`, con `parent`); mutante
  `n1.roles-twin.denied-userset` (añadir `role_binding#assignee` a `denied_<P>`) ⇒ rojo (10 casos, entre ellos el
  nuevo). *Fuera del alcance y anotado*: en roles, un 2.º `writeTuples` que falla tras el delete sigue saliendo como
  503 sin marca parcial (letra ≠ efecto, pero fail-closed); el manager de roles no tiene la rama `isPartialWrite` —
  candidato para la RC/lote propio, no lo toqué. *Comando ↔ manager ↔ función*: `relate` por el manager (409 + 0
  eventos), por `manager.driver()` (el driver decide), y `reconcileRelations`/`runRelationsReconcile`/comando
  (plan `renewal-unsafe`, línea): casos en `relations_openfga.spec`, `relations_reconcile_deny.spec`,
  `relations_reconcile_l9.spec`. `database`: no aplica (renueva en UNA transacción, `atomicRenewal: true`, cara `true`
  del par).
- **(b) Tabla de verdad** (ejes: `atomicRenewal` del destino × clase de tupla × cambio de caducidad × camino; guardia de
  producto y rama):

  | atomicRenewal | tupla existente | caducidad | camino | resultado / rama | caso |
  |---|---|---|---|---|---|
  | false (`openfga`) | membresía PORTADORA (directa o por grupo contenedor) | distinta | `relate` | 409 `E_AUTHZ_RENEWAL_UNSAFE`, 0 `Write`, barrera nunca salta | `relations_openfga` N1 + par `false` del juez |
  | false | membresía portadora | igual / omitida vigente | `relate` | no-op (sin lectura de denies) | contrato núcleo (invariante 6) |
  | false | membresía SIN deny | distinta | `relate` | delete + write (2 `Write`); barrera salta y no concede | `relations_openfga` N1 (control) |
  | false | cualquiera no portadora | distinta, 2.º `Write` falla | `relate` por manager | 503 marcado `isPartialWrite` + evento `indeterminate: true` | `relations_openfga` N1 (b) |
  | false | allow (no `group`) | distinta | `relate` | delete + write (solo quita en el hueco) | R-15 existentes |
  | true (`database`, doble `true`) | membresía portadora | distinta | `relate` | renueva en una escritura, el deny sigue negando | par `true` del juez |
  | false | membresía portadora | distinta en origen | reconcile `--dry-run` / real | `renewal-unsafe` (mismos números), 0 `relate`, línea `sin renovar (renewal-unsafe) destino:`, exit ≠ 0 | `relations_reconcile_deny` N1, `relations_openfga` N1 reconcile, L9 · N6 |
  | true | membresía portadora | distinta en origen | reconcile real | `updated 1`, sin residuo | `relations_reconcile_deny` N1 |
  | false | renovación permitida cuyo 2.º `Write` falla | — | reconcile real | `report.partial: true` aunque `written 0`; línea «PARCIAL», jamás «sin escribir nada» | `relations_reconcile_deny` (partial) |

- **(c) Casos existentes puestos rojos, justificados:** conteos del arnés (`relations_harness.spec`: núcleo 29 → 30,
  capacidades 9 → 10) y las listas de claves de capacidad de `capabilities.spec`/`guard_surface.spec` (una clave
  opcional nueva). Ninguno se debilitó.
- **(d) Linaje:** L10 (PROMOVIDO §2026-10-15 (8)), 5.ª aparición, fuera de `tuple_order.ts`. Cierre ESTRUCTURAL: la
  operación ya no tiene estado intermedio para la portadora (se rechaza, decisión del dueño (9)); la capacidad
  `atomicRenewal` es la propiedad declarada en el puerto con su par en el juez publicado (un driver de terceros que no
  la declare DEBE negar), y el reconcile no le pide esa renovación nunca. No hay entrada nueva en la guardia de
  superficie (L1) para esto: la propiedad la juzga el par del contrato en los tres harness (doble, `database`,
  `openfga`) y los mutantes medidos de abajo.

**Mutantes N1 (medidos a mano sobre una copia del árbol, `scratchpad/c2/mutants.py`):**

| id | mutación | resultado |
|---|---|---|
| `n1.fga.no-refusal` | `openfga` no lanza la 409 | MUERTO (2: par `false` del juez en `openfga` + caso N1; con la barrera: `[ true ]`) |
| `n1.fga.no-nesting` | `#carriedDeny` no sube por la anidación | MUERTO (2) |
| `n1.fga.no-partial` | el 2.º `Write` fallido sin `markPartialWrite` | MUERTO (1: N1 (b)) |
| `n1.double.no-refusal` | el doble del juez renueva la portadora | MUERTO (1: par `false` en `relations_contract.spec`) |
| `n1.plan.no-renewal-unsafe` | el plan deja de clasificar `renewal-unsafe` | MUERTO (2: `relations_reconcile_deny` N1 + L9 · N6) |
| `n1.pass.ignore-driver-partial` | `partial` ignora la marca del driver | MUERTO (1) |
| `n1.roles-twin.denied-userset` | `denied_<P>` admite `role_binding#assignee` | MUERTO (10) |

## N3 🟡 · el orden de la transición entera (estructural) — y N2 🟡

**Qué hay (implementador anterior, verificado por mí):**
- `src/relations/tuple_order.ts`: UNA función, `relationTransitionOrder`, para escrituras + renovaciones + borrados
  (`relationWriteOrder`/`relationDeleteOrder` son atajos de ella; la purga de `openfga` —`purgeWrites`— y
  `applyPartition` del reconcile la usan). Cinco fases: denies nuevos → allows sobrantes (no-`group`) → **membresías
  que entran y salen por un GRAFO DE PRECEDENCIAS** (C1–C4, Tarjan + prioridad estable) → allows nuevos y renovaciones →
  denies sobrantes. El auto-corte (D5) solo con `toConfig`; sin él, más precedencias (más residuo), nunca menos
  garantía.
- **El candidato del brief se DESCARTÓ con contraejemplo** (no es seguro): `U ∈ h` entra antes de que `h ⊂ g` salga y U
  alcanza el allow de g (`inicial [g@h#member x@g#member] → final [h@u1 x@g#member]`, concede tras 1). El del cierre 1
  también (C2 del auditor). Ambos fijados en el spec.
- Demostración por fuerza bruta (`tests/helpers/order_bruteforce.ts`, oráculo cruzado con `cutPathAllows` del paquete
  en las 1 024 máscaras de E1) y `tests/relations_order_exhaustive.spec.ts`. Propiedad de guardia
  **`relations.order.exhaustive`** (E1-reduced, 131 072 pares) con 13 mutantes del orden; `relations.reconcile.order`
  con filas nuevas (ex-miembro, composición anidada, N2, allow antes que la portadora) y el mutante
  `rec.apply.writes-then-prune`.
- `report.orderResidue` + línea de aviso con prefijo estable `orden SIN garantía` (caso en `relations_reconcile_deny`).
- README («Denies migrate as denies») y CHANGELOG con la garantía exacta y las cifras.

**Lo que demuestra, exactamente** (medido por mí, ejecución del 16-10):
- **E1 EXHAUSTIVO** (1 usuario, 2 grupos h ⊂ g, 2 objetos, `viewer` con deny; 10 tuplas; 4^10 × {`--prune`, sin} =
  **2 097 152 pares**, 21,3 s): **0 pares conceden sin residuo declarado**, 0 malformados; 4 560 con ciclo, 828 de ellos
  conceden en algún prefijo, **352 sin ningún orden seguro** (DP sobre subconjuntos del diff).
- **U2** (el universo del brief completo: 2 usuarios, allows/denies directos y por grupo; 21 tuplas), muestra declarada de
  30 000 pares por modo (semilla 20261015): 0 sin residuo; 233 con ciclo, 9 conceden, 0 inherentes.
- **E3** (3 grupos, dos niveles de anidamiento; 20 tuplas), muestra 30 000/modo: 0 sin residuo; 842/7/0.
- Sin `toConfig` (E1-reduced exhaustivo): 0 sin residuo, y más residuo que con el auto-corte.
- Garantía publicada: **«si el grafo de precedencias no tiene ciclo, ningún prefijo concede fuera de inicial ∪ final
  ni a un denegado en los dos»**. El residuo es el ciclo, inherente en parte (ejemplo fijado: U ∈ g y U ∈ h, g concede
  X y deniega Y, h al revés, `--prune` a ninguna: cualquier primer paso concede).

**N2:** la frase vieja («another such group») desaparece: con el grafo de precedencias el caso del re-ataque (el otro
grupo solo transporta un deny) **se ordena** y deja de ser residuo (fila `N2 · …` en `relations.reconcile.order` +
contraejemplo literal en el spec: el orden del cierre 1 concedía tras 1, el nuevo no). El único residuo es el ciclo, con
su frase.

**Lo que hice yo:** el título de `relations.reconcile.order` decía la frase universal (⚪ del auditor); ahora: «… no
concede lo que no concedían ni el estado inicial ni el final **—salvo el RESIDUO declarado: un ciclo del grafo de
precedencias, que la pasada lista en report.orderResidue (cifras en relations.order.exhaustive)—** …». 9 `expectRed`
actualizados; guardia 236/236 y corredor 176/176 tras el cambio. CHANGELOG lo dice.

**Cuatro líneas de cierre:**
- **(a) Gemelos.** Purga de relaciones (`purgeWrites`) ↔ reconcile: la MISMA función (`relationDeleteOrder` →
  `relationTransitionOrder`), propiedad `openfga.purge.order` + `relations.reconcile.order`. Comando ↔
  `runRelationsReconcile` ↔ `reconcileRelations`: todos pasan por `applyPartition`. Roles (`purgeScope` de `facts`):
  propiedad `openfga.roles.purgeScope.order` del cierre 1 (estructura → hechos → denies), sin membresías anidadas en roles:
  no aplica el grafo. `database` relaciones/roles: una sentencia o transacción por escritura, sin multi-request: no
  aplica.
- **(b) Tabla de verdad:** la sustituye la fuerza bruta (es el punto del brief): ejes = presencia de cada una de las 10
  tuplas en inicial y final × {`--prune`, sin} × con/sin `toConfig`, recorridos ENTEROS en E1; el veredicto por par es
  {seguro, residuo-que-concede, residuo-inherente}, cifras arriba.
- **(c) Casos existentes puestos rojos:** las cifras fijadas del cierre 1 en los casos de orden del reconcile y de la
  purga se re-expresaron sobre la función única (las aserciones viejas siguen; ninguna debilitada); la frase universal del
  cierre 1 en README/CHANGELOG queda superada por la exacta (el bloque del cierre 1 en `[Unreleased]` no se reescribe: el
  del cierre 2 dice «This supersedes…»).
- **(d) Linaje:** L10 PROMOVIDO: propiedad universal (`relations.order.exhaustive`, demostrada), punto de paso único
  (`tuple_order.ts`, pura, regla 2) y entrada en la guardia de superficie con 13 mutantes del orden que la ponen roja.

## N4 🟡 · `provision --store-id` nunca bloqueado para siempre

**Anterior:** el barrido de `--allow-drop-deny` en STREAMING (`countLiveDenies`, exportada), sin cota de tuplas
(`PROVISION_DROP_DENY_SWEEP_MAX` retirada), recuento + 3 ejemplos; página sin `tuples` o token repetido ⇒ exit 1 con
«el barrido falló a medias»; caso de 10 001 páginas (1 000 100 tuplas) con el deny en la última; la fila de la cota fuera
de Limits (`scope_depth.spec`). Se eligió streaming, no bandera ⇒ `flag-mutants` sin cambios (37/37).

**Yo:** la guarda solo miraba el token INMEDIATO; sin la cota, un ciclo `t1 → … → t5 → t1` iteraba para siempre (letra
«exhaustivo o ruidoso» falsa). Ahora `Set` de tokens vistos (`commands/openfga_provision.ts`); caso nuevo «N4 · un
CICLO de continuation_tokens … también LANZA» en `tests/command_flags_d2.spec.ts`. CHANGELOG actualizado.

Mutantes: `n4.sweep.cap` (reponer el corte a 1 M) ⇒ MUERTO; `n4.sweep.immediate-only` (volver al token inmediato) ⇒
MUERTO (el caso nuevo; con el código viejo el doble cortaba a pages + 10 con otro mensaje).

## N5 ⚪ · letra del recuento

**Anterior:** README «**The recount narrows the window, it does not close it**» + «step 0 (the whole fleet on `deny:
'read'` before counting) is what closes it» en el bloque de `provision` y en el paso 3 del procedimiento; caso «N5 · la
letra» en `command_flags_d2.spec`. Verificado.

## N6 ⚪ · la guardia L9 ve `deny-conditional` y `renewal-unsafe`

**Anterior:** `RELATIONS_RECONCILE_DETAIL_REASONS` (motivos en runtime) y `RELATION_RESIDUES` (dónde se clasifica cada
uno: `plan` o `pass`, con el porqué de la excepción a «mismos números en `--dry-run`») en `src/relations/reconcile.ts`;
grupo «L9 · cierre 2 de D2 · ⚪ N6» en `tests/relations_reconcile_l9.spec.ts`: reflexión (un motivo sin entrada es
rojo), `deny-conditional` única excepción `pass`, y un caso EJECUTABLE por motivo (`renewal-unsafe` en el plan con
mismos números; `deny-conditional` en la pasada).

Mutantes (míos): `n6.residues.drop-renewal` ⇒ MUERTO; `n6.residues.drop-conditional` ⇒ MUERTO.

## Ficheros

- Del cierre 2 (anterior): `src/relations/tuple_order.ts`, `src/relations/reconcile.ts`,
  `src/drivers/openfga_relations_driver.ts`, `src/drivers/database_relations_driver.ts`, `src/errors.ts`,
  `src/types.ts`, `src/testing/relations_contract.ts`, `commands/openfga_provision.ts`,
  `commands/authz_relations_reconcile.ts`, `README.md`, `CHANGELOG.md`, `tests/helpers/order_bruteforce.ts`,
  `tests/relations_order_exhaustive.spec.ts`, `tests/guard_surface.spec.ts`, `tests/fixtures/guard_manifest.ts`,
  `tests/fixtures/guard_mutants.json`, `tests/relations_{harness,database,openfga,reconcile_deny,reconcile_l9}.spec.ts`,
  `tests/{capabilities,command_flags_d2,scope_depth}.spec.ts`.
- Míos: `tests/relations_openfga.spec.ts` (barrera, dos sujetos), `tests/openfga_facts.spec.ts` (gemelo de roles),
  `commands/openfga_provision.ts` (tokens vistos), `tests/command_flags_d2.spec.ts` (ciclo),
  `tests/fixtures/guard_manifest.ts` + `tests/fixtures/guard_mutants.json` (título), `CHANGELOG.md`.
- `git diff --stat HEAD`: 31 ficheros, +3168 / −264, más 7 sin seguimiento (`tuple_order.ts` y 6 specs/helpers).

## Casos nuevos (cierre 2, total)

N1: par `atomicRenewal` (2 caras) en el juez publicado ×3 harness; `relations_openfga` (portadora directa+anidada con
barrera, N1 (b) parcial+evento, reconcile `renewal-unsafe`); `relations_reconcile_deny` (sin/con `atomicRenewal`,
partial del driver); `relations_harness` (par); `capabilities`; `openfga_facts` (gemelo de roles, mío). N3/N2:
`relations_order_exhaustive` (7), `relations.order.exhaustive` (guardia), filas nuevas en `relations.reconcile.order`,
residuo avisado (3 en `relations_reconcile_deny`). N4: 3 (+1 mío). N5: 1. N6: 2 + uno por motivo.

## Verificación (yo, 2026-10-16, en primer plano, en secuencia, `docker restart openfga-dev && sleep 8` antes de cada suite con OpenFGA)

Entorno: Node 22, `OPENFGA_TEST_URL=http://localhost:8090`, `TEST_PG_URL` con la contraseña de `postgres18`. Logs en
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/c2/final/`.

| paso | resultado |
|---|---|
| `npm run build` | exit 0 |
| `npm run typecheck` | exit 0 |
| `npm run check:purity` | exit 0 |
| `npm test` (`:memory:` + OpenFGA) | **2018 passed, 2 skipped (2020)** |
| `test:sqlite-file` | **2046 passed, 2 skipped (2048)** |
| `test:pg` | **2143 passed, 1 skipped (2144)** |
| `test:mysql` | **2145 passed, 1 skipped (2146)** |
| `check:guard-mutants` | **176 muertos / 176**, 0 vivos (391 s) |
| `check:flag-mutants` | **37 / 37 muertos**, 0 vivos, 0 exentos, 1 pendiente (`--prune-undeclared`), VERDE |
| `cutover-runbook` sqlite-file | **22 pasos en verde**, 0 pendientes, VERDE |
| `cutover-runbook` pg | **22 pasos en verde**, 0 pendientes, VERDE |
| `relations_order_exhaustive.spec` | 7/7 (E1 2 097 152 pares en 21,3 s) |
| mutantes a mano N1/N4/N6 (`scratchpad/c2/mutants.py`) | **13 / 13 muertos** |

Antes del cierre 2 (verificación del coordinador del cierre 1): 1987 / 2015 / 2112 / 2114, 171/171, 37/37.

Nada queda corriendo en segundo plano.

## No hecho (con razón)

- **Marca parcial en la renovación de ROLES** (`replaceAssignment` cuyo `writeTuples` falla tras el delete): letra ≠
  efecto pero fail-closed; el manager de roles no tiene la rama `isPartialWrite`. Fuera del brief (que pedía el gemelo
  del DENY); anotado para la RC.
- **TOCTOU de la comprobación de portadora**: un `deny` que entra entre la lectura de `#carriedDeny` y los dos `Write`
  de una renovación de membresía sin deny vuelve a abrir el hueco. No lo pidió el brief; la ventana es la de dos
  escrituras concurrentes de admin. A declarar o a medir por el auditor.
- `linajes.md`, `CLAUDE.md` (mapa del código: `tuple_order.ts` con el grafo, `atomicRenewal`, `RenewalUnsafeError`,
  `countLiveDenies`) y `RETOMAR.md`: le tocan al coordinador.
- Auditoría de sistema (punto 9): antes de publicar, del coordinador.
