# Lote D · sublote D1 · RE-ATAQUE del cierre 1 — auditor · 2026-10-15

Árbol: `main` sobre `493c649` con D1 + cierre 1 sin commitear. Copia en
`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/audD1c/tree/` (guardia de stores de
`bin/test.ts` APAGADA en la copia), mutantes en `…/audD1c/mut-{db,fga,order}/`. Stores efímeros `audD1c-*` en `:8090`
creados y borrados por cada caso (comprobado al final: 0 restos). Ni contenedores, ni `test:pg|mysql`, ni gates. El delta
del cierre se aisló comparando con la copia auditada de D1 (`…/audD1/tree`): 14 ficheros.

## Veredicto en una línea

**D1 es cerrable cuando se añada un caso y un mutante. No hace falta tocar código.** El 🟠 1 está cerrado en el código:
lo medí, y la fila declarada coincide exactamente con el efecto. Pero la tabla de verdad del cierre no tiene la fila
simétrica, «allow transportado por grupo + deny DIRECTO». El mutante «denies antes que membresías» es un fail-open real
(medido: `DESPUÉS true`) y SOBREVIVE a los 5 casos del cierre (🟡 N1). El candidato de linaje es en realidad la 3.ª
iteración (M8).

---

## Hallazgos del auditor anterior → estado

| # | Estado | Evidencia |
|---|---|---|
| 🟠 1 purga cortada concede | **CERRADO en el código** · le falta un diente (🟡 N1) | ✅ Repro del predecesor sobre el árbol cerrado: `ANTES false · 503 · lote 1 incluye member@group: false · DESPUÉS false`. (i) 101 membresías: **deny-primero** (`aaa-deny`…`zzz-allow`) ⇒ `lotes 100,1 · 503 partial=true · DESPUÉS true`; repetida ⇒ `false`. **allow-primero** ⇒ `DESPUÉS false`. La fila declarada dice exactamente eso y depende del orden de los ids de grupo (decisión 3). (iii) `purgeSubject(g#member)` con `g⊂h⊂k` y deny en k, corte tras k=1 y k=2 ⇒ `false/false`: la arista `h⊂k` es de `h#member`, no de g, así que el anidado a dos niveles es el mismo caso que a uno. Grupo del cierre (5 casos) verde en `:8090`. |
| (ii) `purgeObject(group:g)` | **No aplica** (razonado, ✅ código) | Todas las tuplas leídas son `group:g#member@X`. Para cada sujeto, el estado intermedio solo cambia UN bit («∈ g»), y lo hace una sola vez, de T a F. Por eso cualquier estado intermedio es el inicial o el final de ese sujeto. Coincido con el informe. |
| (iv) `--max-tuples-per-write` < 100 | **Letra falsa en un caso + purga imposible para siempre** (⚪ N3) | ✅ código: `#guard` convierte el 400 en `AuthorizationBackendError` 503 `E_AUTHZ_BACKEND_UNAVAILABLE`. Ver ⚪ N3. |
| (v) atomicidad del `Write` | **Medido: atómico** | ✅ `Write{deletes:[existe, ausente]}` sin `Ignore` ⇒ **400 y `a` sigue**; con `onMissingDeletes: Ignore` ⇒ `a` borrada. SDK 0.9.6: `deleteTuples` sin `transaction.disable` manda UNA request (`client.js:274`). Concurrencia: un `unrelate` ajeno entre el `Read` y el `Write` único ⇒ el `Write` lo ignora, sale 200 y nada queda a medias. Un `relate` ajeno tras el `Read` ⇒ 500 `E_AUTHZ_PURGE_INCOMPLETE` con `partial=true`: el allow nuevo sobrevive, que es la linealización «purga y luego relate», legal. |
| 🟡 2 puerta `denyable` en drivers | **CERRADO, con efecto** | ✅ A mano en la copia, `guard_surface.spec` en `:memory:`: mutante `database.deny.denyable` ⇒ `ROJO (database.deny [base] · denyable · tipo sin opt-in ('note')): la operación ENTRÓ`. `openfga.deny.denyable` ⇒ el mismo rojo de efecto. Además G-M cae por el `find`, pero la sonda de efecto cae sola. Manager y doble, por lectura: la sonda exige 0 llamadas al driver y `listDenies` vacío respectivamente, así que es efecto y no estructura. |
| 🟡 3 `decideMany` sin pin | **CERRADO** | ✅ El memo (`#modelDenied`) solo lo leen `decideMany` y la guarda D-31 (`#assertModelDeny`). D-31 vuelve antes de leer nada si la config no tiene tipos con deny, y con tipos con deny D14 exige pin en el constructor. Sin pin, `check`/`checkMany`/`listObjects` los evalúa el servidor con el último modelo (resta el deny: fail-closed) y no dependen del memo. No hay otro camino con la ventana. `decideMany` es nuevo en D1, así que la exigencia no rompe nada publicado. |
| 🟡 4 `membersOf` cota/deadline | **CERRADO** | ✅ `database_relations_driver.ts`: la cota cuenta los candidatos DESPUÉS de la CTE (que ya era ilimitada sin deny) y ANTES del primer `check`. Los denies consultados son `deniableAbove` = `up*(down*(R))`, la definición amplia, así que un deny en `owner` también activa la resta de `membersOf(viewer)`. Deadline total con bandera que corta el bucle. `openfga` no tiene gemelo (`membersOfNative: false` ⇒ 500). Status: ver decisión 1. |
| ⚪ 5 letra decisión 4 | CERRADO | docblock de `removeDeny` alineado. |
| ⚪ 6 doble publicado | CERRADO | línea «Third-party drivers…» en `[Unreleased]`. |
| ⚪ 7 D-31 forma | **CERRADO a medias** (⚪ N4) | ✅ Exige `difference.subtract = denied_<rel>`. Con el modelo del generador no hay falsos positivos (salida inspeccionada: `viewer`/`editor`/`owner` son `difference`; `denied_editor = this ∪ denied_viewer`). No mira el CIERRE del deny: ver ⚪ N4. |

## Hallazgos nuevos (por severidad)

### 🟡 N1 · La tabla de verdad del 🟠 1 no tiene la fila simétrica: el mutante «denies antes que membresías» es fail-open y sobrevive
- **Escenario (EJECUTADO, `:8090`).**
  - Precondición: `U ∈ g_allow`, `g_allow#member` es viewer de V, `deny(U, viewer, V)` DIRECTO y 100 allows de relleno de U.
  - Acción: con el código del cierre los lotes son `[100 allows][1 membresía][1 deny]`. Cortando tras k=1 o k=2 ⇒ `false/false`.
  - Resultado incorrecto: con el mutante `return [...chunks(allows), ...chunks(denies), ...chunks(memberships)]` los lotes son `[100 allows][1 deny][1 membresía]` y, cortando tras k=2, **`ANTES false … DESPUÉS true`**. Concede algo que no concedían ni el estado inicial ni el final.
  - Ese mutante, corrido contra el grupo del cierre (`relations_openfga.spec`, «lote D · cierre 1 de D1 · 🟠 1 …»), da **5/5 VERDE**.
- **Por qué pasa.** Las filas de la tabla son {deny directo sin membresías, deny por grupo sin denies directos, anidado, allow+deny ambos por grupo, >100 membresías}. Ninguna combina una membresía que transporta un ALLOW con un deny DIRECTO. Los 4 mutantes del informe (`prefix-only`, `memberships-first`, `contiguous`, `no-single-write`) no cubren esa permutación. La propiedad publicada tiene dos mitades: «membresías DESPUÉS de los allows» y «membresías ANTES de los denies». Solo la primera tiene diente.
- **Evidencia:** ✅ `…/audD1c/tree/tests/audc_purge.spec.ts` («AUDC M»), sobre el árbol y sobre `…/audD1c/mut-order`.
- **Steelman:** «el código está bien y el orden se ve a simple vista». No me convence. Es el MISMO argumento que dejó pasar el orden «solo prefijo» de D1, y CLAUDE.md §5(b) exige la tabla.
- **Mitigación mínima:** añadir la fila «allow por grupo × deny directo» (holder y userset) y el mutante `fga.purge.denies-before-memberships`. Mejor aún: meter los 5 mutantes de purga en el corredor publicado (ver Linaje).

### ⚪ N2 · Linaje: no son 2 iteraciones, son 3 (M8)
Todas son la misma propiedad: «una operación de varios pasos no expone un estado intermedio que conceda lo que no concedían ni
el estado inicial ni el final».
1. 3b-2f · R3: orden de `purgeScope` en `facts`, «los denies, los últimos» (`fase-3b-lote-2f-informe.md:204`).
2. 3b-6 · P1 🔴: el origen del reconcile en dos barridos, «el rol sin su deny, concediendo lo que ni el estado anterior ni el posterior concedían» (`fase-3b-lote-6-informe.md:15`).
3. D1 · 🟠 1.

El implementador cuenta «D-26 → 🟠 1». D-26 no fue un defecto: era una regla de diseño del panel (P1-21). El precedente L9 se
promovió con 3 apariciones. Lo que M8 exige y el cierre ya tiene: la propiedad universal escrita y un punto de paso único
(`purgeWrites`). Lo que falta: la entrada en la guardia de superficie, porque los mutantes de purga siguen siendo «por pieza» y
fuera del corredor. N1 es justo el agujero que M7 existe para impedir.

Para D2 (❓, no verificado en ejecución): `openfga_driver.ts:2719` aplica en roles «DELETES primero … de MENOS
(fail-closed)». Con `--prune`, un deny que se mueve de unit a org deja una ventana sin ningún deny, que concede. Cuando D2 haga
que `reconcileRelations` lleve los denies, esa ventana es la cuarta candidata.

### ⚪ N3 · Servidor con `--max-tuples-per-write` < 100: la letra del docblock es falsa en el caso de varios `Write`, y la purga queda imposible para siempre con un error que parece transitorio
- **Escenario (✅ por lectura de código; no se puede medir sin reconfigurar el servidor).**
  - Precondición: tope 50 y un sujeto con 3 allows + 60 membresías + 40 denies (103 tuplas).
  - Acción: la purga trocea `[3][60][40]`. El `[3]` se aplica y el `[60]` da 400.
  - Resultado: 503 `E_AUTHZ_BACKEND_UNAVAILABLE` **marcado como parcial**. El docblock de `RELATIONS_PURGE_WRITE_MAX` dice «503 sin haber borrado nada», y eso es falso en este caso.
  - Al repetir quedan 100 tuplas ≤ 100 ⇒ un solo `Write` de 100 ⇒ 400 en cada intento. **La purga no termina nunca** y el error dice «backend no disponible» (reintentable).
- **No concede nada**: es fail-closed en el estado (solo se borraron allows) y ruidoso. Pero la baja de un usuario no termina nunca.
- **Steelman:** «el tope por defecto es 100 y nadie lo baja». Me convence para la severidad, no para la letra.
- **Mitigación mínima:** no hace falta una opción `maxTuplesPerWrite`. Basta con dos cosas:
  - clasificar ese 400 («exceeds the allowed limit») como 500 `E_AUTHZ_CONFIG` que nombre `--max-tuples-per-write ≥ 100`;
  - poner ese requisito en «Limits».

  Es un gemelo: el driver de roles (`projectCatalog`, `applyReconcileWrites`) asume el mismo 100.

### ⚪ N4 · D-31 juzga la resta, no el cierre del deny
- **Escenario (✅ por lectura; razonado contra la salida del generador).**
  - Precondición: un modelo escrito a mano con `denied_editor: [user]` (sin `or denied_viewer`) y `editor` bien restado.
  - Acción: pasa D-31. Luego `deny(U, viewer, doc)` con U owner.
  - Resultado incorrecto: `openfga` `check(U, editor) = true`, mientras `database` (`cutPathAllows`: `up*(owner) ∋ viewer`) da `false`.
- Requiere un modelo a mano; el paquete no lo produce.
- **Mitigación mínima:** comparar las definiciones `<rel>`/`denied_<rel>` de los tipos con opt-in con las de `openFgaFactsModel(config)`, que es pura, en vez de mirar solo `subtract`. Si no, declararlo.

### ⚪ N5 · Higiene
- `assertDenyNoExpiry` solo tiene caso por el MANAGER (D-19). Quitarlo de un driver deja escribir un deny permanente cuando el llamante esperaba que caducara. Es fail-closed, sin diente.
- La regla `notDeny` (`exceptOperations: ['deny']`) es por NOMBRE. Una operación futura que escriba `denied_*` (`denyMany`) heredaría `na` sin sonda.
- Las cabeceras de alpha.2 y alpha.1 del CHANGELOG son idénticas byte a byte a `HEAD` (sha1 de las líneas 134…fin = HEAD 3…fin). El caso N12 solo fija el hash de alpha.1, y alpha.2 está publicada sin hash.

## Decisiones nuevas del cierre (§9)

| # | Decisión | Veredicto | Por qué |
|---|---|---|---|
| 1 | `E_AUTHZ_MEMBERS_DENY_LIMIT` 500 | **Ratificar con letra** | 503 sería falso (no es reintentable). Hay precedente de 500 (`TOO_MANY_LOCAL_ROLES`, `RECONCILE_TOO_LARGE`). Pero la lectura análoga, `authorizedScopes` (`E_AUTHZ_TOO_MANY_SCOPES`), es **422**: conviene escribir por qué esta es 500. |
| 2 | deadline total = `timeoutMs` | **Ratificar** | La cota efectiva es min(1000, timeoutMs/latencia por `check`). El caso de 1000 `check` pasa en los 4 modos según el informe; la frase del README ya dice «under one total deadline». |
| 3 | membresías ordenadas por objeto/sujeto | **Ratificar** | Hace la fila declarada determinista (medido: deny-primero ⇒ T, allow-primero ⇒ F). |
| 4 | `RELATIONS_PURGE_WRITE_MAX` fijo en 100 | **Condicionar** (⚪ N3) | Hay que corregir el docblock: con varios `Write` puede borrar antes del 400. Además, el 400 del tope debe salir como 500 de config, y el requisito tiene que estar en «Limits». No hace falta opción. |
| 5 | `decideMany` sin pin ⇒ 500 siempre | **Ratificar** | Es la única primitiva que consume el memo. La operación no está publicada, así que no rompe a nadie. |

## Transversal
- **Sin debilitamientos en el delta del cierre.** Las únicas líneas `assert`/`throw` quitadas son cambios de mensaje.
- `EXPECTED_FUSED`, `migration_stub.spec` y `freeze.spec` están intactos.
- Bloques publicados del CHANGELOG intactos. La letra del README sobre la purga coincide con el efecto medido: el «never in default» desapareció y la fila declarada es exacta.
- Linaje: promover el candidato (ver ⚪ N2).

## Lo que intenté y NO se rompió
- Repro del predecesor.
- (i) en los dos órdenes.
- (iii) a dos niveles.
- Atomicidad del `Write`, con y sin `Ignore`.
- `unrelate` y `relate` concurrentes con la purga.
- Mutantes `denyable` de `database` y `openfga` (efecto).
- `decideMany`, `check`, `checkMany` y `listObjects` sin pin.
- `membersOf` con deny por debajo (`owner`).
- Clasificación de membresías por prefijo `group:`: ningún tipo del consumidor puede llamarse `group` y ninguna relación de dominio empieza por `denied_`.
- Ninguna tupla de la clase «allows» transporta un deny: v1 no tiene `from`, y el único userset es `group#member`.
