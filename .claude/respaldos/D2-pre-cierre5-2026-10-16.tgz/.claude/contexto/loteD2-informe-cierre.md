# Lote D · sublote D2 — cierre 1 (implementador) · 2026-10-15

**Árbol `main` sobre `75353fe`**, con D2 sin commitear debajo. Fui el único agente que mutó el árbol. Sin commit, sin
`version` y sin push.
- Brief: `loteD2-cierre-coordinador.md`.
- Entorno: Node 22.23.2, OpenFGA `:8090` (`openfga-dev`, reiniciado antes de cada suite y de cada runbook), `postgres18`
  y `mysql84`. No usé `:8101` ni `:8103`.
- Logs en `scratchpad/d2c1/`: `order_mutants.log`, `red_enumeration.txt`, `piece_mut.log`, `mutants.json`,
  `logs/<mutante>.log` y `final/*.log`.
- Sin tocar: `EXPECTED_FUSED`, `migration_stub.spec` y `freeze.spec`.
- CHANGELOG: `git diff -U0` da un solo hunk (`@@ -180,0 +181,142 @@`), todo dentro de `[Unreleased]`. `[2.5.0-alpha.2]` y
  `[2.5.0-alpha.1]` están intactos.
- No añadí ningún `skip` ni `pending`.

---

## 🟠 1 · Un punto de paso ÚNICO para el orden de escritura y de borrado (linaje L10)

### Qué cambia

**Fichero nuevo `src/relations/tuple_order.ts`** (130 líneas, puro):
- `relationOrderClass` (`:55`) clasifica cada tupla en una de tres clases:
  - `deny`: `denied_*` o `kind: 'deny'`.
  - `membership`: cualquier allow sobre un objeto `group`.
  - `allow`: el resto.
- `denyCarrierGroups` (`:64`) calcula los grupos portadores de deny. Un grupo es portador si su `#member` es sujeto de
  algún deny. El cierre baja por la anidación: con `G#member@H#member` y G portador, H también lo es.
- Los rangos de orden son estos:

  | Constante | Línea | Orden |
  |---|---|---|
  | `WRITE_RANK` | `:89` | deny → membresía portadora → membresía → allow |
  | `DELETE_RANK` | `:91` | allow → membresía → membresía portadora → deny |

- Dentro de las membresías se ordena por (objeto, sujeto), nunca por el orden de enumeración.
- `relationWriteOrder` (`:123`) y `relationDeleteOrder` (`:128`) aceptan un `context`: las tuplas que existen pero no se
  escriben. Un deny que ya está en el destino también convierte a su grupo en portador.

**Usan esta función los dos caminos:**
- `src/relations/reconcile.ts`:
  - `applyPartition`, escritura en `:658` y poda en `:709`.
  - `PartitionPlan.orderContext`: el origen utilizable más el destino.
  - `orderView`.
- `src/drivers/openfga_relations_driver.ts`:
  - `purgeWrites` en `:1473`, que trocea por CLASE.
  - `#purgeByFilters` (docblock).

**Letra:**
- README, en «Denies migrate as denies» y en el párrafo de la purga: dice exactamente lo que se garantiza y el residuo.
- CHANGELOG, en «Closure 1 of sublot D2»: el bloque de D2 (sin publicar) corrige en el sitio «never an allow without its
  deny».

### Garantía exacta y residuo

Si la pasada se corta tras cualquier escritura, ningún estado intermedio concede algo que no concedieran ni el estado
inicial ni el final.

**Residuo declarado:** un grupo que transporta a la vez un allow y un deny. Mientras se escriben (o borran) sus
membresías, puede abrir un allow que el destino YA tenía antes de que llegue (o después de que se vaya) la membresía
portadora de otro grupo mixto.

Una primera migración a un destino vacío no tiene residuo. Tampoco lo tiene la parte de «lo que el origen niega»
durante la poda, porque los caminos de deny del origen quedan completos.

### Casos

**Propiedad `relations.reconcile.order`** (`tests/guard_surface.spec.ts:1726`), reescrita. Se ejecuta con dos dobles
reales y un corte tras k escrituras.

| Fila | Prune |
|---|---|
| deny directo (allow + deny del mismo hecho) | no |
| corte de camino (owner, deny en editor) | no |
| deny por grupo | no |
| deny anidado (U ∈ h ⊂ g, deny en g#member) | no |
| portadora antes que la membresía de un grupo cuyo allow el destino YA tenía | no |
| portadora ANIDADA, mismo caso | no |
| poda de un allow + deny sobrantes | sí |
| poda: la membresía portadora se borra la ÚLTIMA | sí |

Cada fila se recorre en {orden de enumeración del origen, orden INVERSO} × {corte tras k = 0…n}.

**Propiedad `openfga.purge.order`:** la tabla no cambia. Ahora juzga `purgeWrites` → `relationDeleteOrder`.

**Caso con origen `database` REAL** (`tests/relations_reconcile_deny.spec.ts:462`). Reproduce el A1b del auditor:
- Afirma que `database` enumera primero el allow.
- Afirma el orden de escritura deny → membresía → allow.
- Afirma que con k = 0…3 el destino nunca concede.

### Rojo observado

- El mutante `order.write.enumeration` es el código de D2: denies primero y el resto en orden de enumeración. Contra la
  propiedad (`red_enumeration.txt`) da: «deny por grupo · orden de enumeración del origen · tras 2 de 3 escrituras:
  CONCEDE ;; deny anidado … tras 2 de 4 / 3 de 4 ;; portadora … tras 2 de 3 ;; portadora ANIDADA …».
- El caso con origen `database` da con el mismo mutante: «orden de ESCRITURA: deny → membresía → allow: expected …»,
  1 failed.

### Mutantes (en el corredor publicado, todos muertos)

**En `tuple_order.ts`:**

| Mutante | Qué rompe | Propiedades en rojo |
|---|---|---|
| `order.write.enumeration` | el de hoy | reconcile |
| `order.write.allows-before-memberships` | — | reconcile |
| `order.write.no-carriers-first` | — | reconcile |
| `order.delete.no-carriers-last` | — | reconcile |
| `order.carriers.no-nesting` | — | reconcile; antes vivía, por eso añadí la fila «portadora ANIDADA» |
| `rec.order.allows-before-denies` | reescrito sobre `WRITE_RANK` | reconcile |
| `rec.order.prune-denies-first` | — | reconcile + purge |
| `fga.purge.memberships-first` | — | purge + reconcile |
| `fga.purge.denies-before-memberships` | — | purge + reconcile; el corredor lo marcó colateral y lo añadí a las dos listas cerradas |

**En `purgeWrites`:** `fga.purge.prefix-only`, `fga.purge.contiguous` y `fga.purge.no-single-write`, reescritos sobre el
código nuevo. Los tres ponen en rojo solo `openfga.purge.order`.

### Tabla de verdad del orden

Ejecutada: 8 filas × 2 órdenes × k = 0…n. Inicial = F y final = F en todas.

| fila | escrituras (pasada completa) | código D2, enumeración del origen | código D2, inverso | cierre 1 (los dos órdenes) |
|---|---|---|---|---|
| deny directo | 2 | F en todo k | F | F |
| corte de camino | 2 | F | F | F |
| deny por grupo | 3 | **T tras 2** | F | F |
| deny anidado | 4 | **T tras 2 y 3** | F | F |
| portadora + allow ya en destino | 3 | **T tras 2** | F | F |
| portadora ANIDADA + allow ya en destino | 4 | **T tras 2 y 3** | F | F |
| poda allow + deny sobrantes | 2 | F | F | F |
| poda: portadora la última | 2 | — (la poda de D2 no tenía orden de membresías: `fga.purge.memberships-first` / `order.delete.no-carriers-last` ⇒ T tras 1) | — | F |

### Cuatro líneas de cierre (🟠 1)

- **(a) Gemelos.**
  - La purga de `openfga` (D1) y el reconcile usan la MISMA función, y las dos propiedades la juzgan.
  - Comando ↔ `runRelationsReconcile` ↔ primitivo: una sola `applyPartition`.
  - Roles (`purgeScope` en `facts`): no aplica, porque ninguna tupla de roles transporta un deny por membresía. Su orden
    sigue fijado por `openfga.roles.purgeScope.order`.
- **(b) Tabla de verdad:** la de arriba. Los ejes son fila (directo, grupo, anidado, portadora, poda) × orden de
  enumeración × k.
- **(c) Casos existentes que el arreglo puso en rojo:**
  - Cambió el título de la propiedad `relations.reconcile.order`, y con él `expectRed` en `guard_mutants.json`.
  - Los cinco mutantes `fga.purge.*` y los dos `rec.order.*` buscaban texto que ya no existe y se reescribieron.
  - Ningún caso de efecto se puso en rojo.
- **(d) Linaje L10**, 4.ª iteración ⇒ estructural:
  - Propiedad universal escrita.
  - Punto de paso único `tuple_order.ts`.
  - Dos propiedades en la guardia, con 12 mutantes de orden entre las dos.
  - `linajes.md` está sin tocar (le toca al coordinador).

---

## 🟠 2 · Rollback: paso previo «flota a `'read'`», recuento antes de publicar y efecto en el paso 21

### Qué cambia

**`commands/openfga_provision.ts`:**
- `recountBeforePublish` (`:278`), llamado en `:158` justo antes de `writeAuthorizationModel`.
- Si aparece un deny nuevo ⇒ exit 1 «provision NEGADO: el RECUENTO justo antes de publicar …» con la receta
  `deny: 'read'`, y CERO modelos.

**README «Upgrading to 2.5.0-alpha.3»:** el procedimiento queda numerado.
0. Flota a `deny: 'read'`, desplegada antes de contar, barrer o publicar.
1. Contar.
2. Retirar.
3. `provision --allow-drop-deny`.
4. Contar otra vez: tiene que dar 0.
5. Fijar, desplegar y hacer el rollback.

**Runbook paso 21** (`tests/cutover_runbook.spec.ts:697`), con EFECTO:
- **21a:** cuenta 2; `provision` sale con 1, con y sin bandera; el store queda intacto.
- **21b (sin paso 0):**
  1. `removeDeny` ×2 y `--prune` («borrados 2»); la cuenta llega a 0.
  2. Un pod en `'write'` vuelve a denegar: la cuenta sube a 1.
  3. El espejo recibe el deny.
  4. `provision --allow-drop-deny` sale con 1 («tiene 1 deny(s)») en vez de publicar, y el deny sigue negando.
- **21c (paso 0):**
  1. FLOTA-READ.
  2. `deny` ⇒ `E_AUTHZ_RELATION_NOT_DENYABLE/422` en database y en openfga; la cuenta no sube.
  3. `removeDeny` y `--prune` («borrados 1»); la cuenta llega a 0.
  4. Se publica («0 denies vivos»).
  5. La cuenta final es 0 y no queda ni un `denied_viewer` en el store.

### Casos y rojo

- **Kernel** (`tests/command_flags_d2.spec.ts:188`): el OpenFGA de mentira inyecta un `denied_viewer` al terminar el
  PRIMER barrido.
  - Rojo observado antes del código: «exit 0», publicó (2 modelos).
  - Mutante `o2.no-recount`: muerto.
- **Runbook:**
  - Mutante `o2.runbook-sweep-blind` (el barrido no ve denies): rojo en el paso 21.
  - Verde en sqlite-file y en pg.

### Tabla de verdad de `provision --store-id`

Ejes: modelos del store × denies vivos × bandera × deny tardío.

| ¿algún modelo del store declara un `denied_*` que el nuevo no? | ¿lo declara el ÚLTIMO? | `--allow-drop-deny` | denies vivos en el barrido | deny tras el barrido | resultado (caso) |
|---|---|---|---|---|---|
| no | — | — | — | — | publica, sin barrido (`:149` de D2) |
| sí | sí | no | — | — | exit 1 «QUITA …», 0 modelos (D2) |
| sí | sí | sí | 0 | no | publica «0 denies vivos» (D2) |
| sí | sí | sí | ≥ 1 | — | exit 1 «no apaga denies VIVOS: … N deny(s)» (D2, runbook 21a/21b) |
| sí | sí | sí | 0 | **sí** | **exit 1 «el RECUENTO …», 0 modelos** (🟠 2, `:188`) |
| sí | **no** (modelo intermedio) | no | ≥ 1 | — | **exit 1 «N deny(s) VIVOS … modelo ANTERIOR», 0 modelos** (🟡 3, `:172`) |
| sí | no | no | 0 | no | publica sin la bandera (🟡 3, `:172`) |
| — | — | — | barrido falla | — | exit 1 «provision NEGADO: el barrido del store falló a medias» (⚪ 10 c, `:204`) |
| historia ilegible | — | — | — | — | exit 1 «no se pudo leer el modelo ACTUAL …» (D2, R-1) |

### Cuatro líneas de cierre (🟠 2)

- **(a) Gemelos.**
  - `openfga`: la barrera es el barrido más el recuento de `provision`.
  - `database`: la barrera es la consulta del README, que el runbook afirma en 21b (cuenta 1 ≠ 0) y en 21c (0).
  - Comando ↔ runbook: los dos pasos.
  - Roles: no aplica, porque no hay opt-in del deny por fases en roles.
- **(b) Tabla de verdad:** la de arriba, más los tres estados del paso 21 (flota en `'write'` sin paso 0 → detectado;
  flota en `'read'` → 422 y cero).
- **(c) Casos existentes que el arreglo puso en rojo:** el paso 21 se reescribió (la cuenta 1 → 2, «tiene 1 deny(s)» →
  2, por el deny por grupo de 🟡 5). No hubo más.
- **(d) Linaje:** es la ventana operativa del mismo patrón que L10, aunque no es una 3.ª iteración de una guarda de
  `linajes.md`.
  - Lo que cierra la carrera es el paso 0, que es un requisito del procedimiento, no un mecanismo.
  - El recuento solo estrecha la ventana, y la letra lo dice.

---

## 🟡 3 · La guarda de `provision` juzga el ESTADO del store

- `commands/openfga_provision.ts`:
  - `guardDroppedDenies` (`:199`).
  - `readModelHistory` (`:362`): lee todos los modelos, paginado.
  - `droppedEver` (`:213`): la unión de todos los modelos frente al nuevo; decide el barrido.
  - `droppedLatest`: decide la intención, es decir, si hace falta la bandera.
- Constante `PROVISION_MODEL_HISTORY_MAX = 10_000` (`:359`), con fila en «Limits» y atada en `tests/scope_depth.spec.ts`.
- Caso: `tests/command_flags_d2.spec.ts:172`. El historial es modelo con deny → modelo alpha.10 sin deny, más un deny vivo.
- Rojo observado: publicó («Nuevo authorization model escrito…», «expected +0 to equal 1»).
- Mutante `y3.latest-model-only`: muerto.
- **Coste declarado:** tras retirar un opt-in, cada `provision --store-id` barre el store (O(store)), porque la historia
  sigue declarando ese `denied_*`.

## 🟡 4 · Re-deny sobre un deny CONDICIONAL en `openfga` ⇒ 500

**Medido contra `:8090`:**
- Escribir sin condición y con `on_duplicate: ignore` da `409 … already exists with a different condition`.
- El driver lo convertía en 503 `E_AUTHZ_BACKEND_UNAVAILABLE`.

**Cambios:**
- `src/errors.ts:106`: `AuthorizationConfigError.conditionalDeny`, con `denyConditional: true` y la receta
  `removeDeny` + `deny` con su ventana.
- `src/drivers/openfga_relations_driver.ts:761`: ante un 409, relee la tupla. Si tiene condición ⇒ 500; si no, el 503 de
  siempre. No mira el texto del error.
- `src/relations/reconcile.ts:666`: residuo del destino `deny-conditional` (nuevo `RelationsReconcileDetail.reason`).
  Suma a `denies.extra` y a `extra`, y la pasada sigue.
- `commands/authz_relations_reconcile.ts:177`: línea propia «sobra (deny-conditional) destino:».

**Casos:**
- `tests/relations_openfga.spec.ts:1597`, contra el servidor:
  - 500 con la letra.
  - Reconcile database → openfga en dos pasadas: residuo, `updated` 0, nunca 503.
  - La receta deja el deny permanente y la pasada siguiente queda limpia.
- `tests/relations_reconcile_deny.spec.ts:332`, con dobles:
  - La pasada sigue.
  - `clean = false`.
  - La línea lleva `removeDeny`.

**Rojo observado:**
- «E_AUTHZ_BACKEND_UNAVAILABLE …: expected 503 to equal 500».
- El caso con dobles no compilaba (`conditionalDeny`, `deny-conditional`).

**Mutantes:** `y4.driver-409` y `y4.reconcile-residue`, muertos.

**Declarado:** `--dry-run` lo cuenta como «rehecho» porque solo el destino lo sabe, y el caso lo afirma. La letra de D2
«lo rehace permanente» se corrigió: solo vale para `database`.

## 🟡 5 · Paso 20 del runbook con deny POR GRUPO y membresía con caducidad (M6)

- `tests/cutover_runbook.spec.ts:638`, en 20c. B tiene el allow de `docG` el lunes; el martes entra en el grupo con
  caducidad +1 h; el grupo está denegado sobre `docG`.
- Comprobaciones:
  - `check` da F en database.
  - La migración dice «denies: escritos 2».
  - `check` da F en openfga.
  - Con el reloj del hijo +2 h, `check` da T en los dos drivers (M6, paridad).
  - Con el reloj de vuelta, F.
- `tests/helpers/cutover_child.ts`: `relate` acepta `expiresAt`.
- Mutante `y5.group-deny-dropped` (el plan descarta los denies con sujeto userset): rojo en el paso 20 («expected … to
  include 'denies: escritos 2'»).

## 🟡 6 · Una receta POR MOTIVO, y la de `undeclared` ejecutada

- `src/relations/reconcile.ts:378`: `denyRefusalRecipe`; `DenyRefusal.recipe` es obligatorio. Va en la letra del 500 y en
  cada línea `deny NO migrable (…) … Receta: …`.
- Caso `tests/relations_reconcile_deny.spec.ts:260`, sobre `database` real:
  - Con `approver` retirado y un deny vivo, la pasada niega con `undeclared` y su receta.
  - La receta vieja, `removeDeny` en el origen, da **422**.
  - Se re-declara la relación SIN opt-in, se hace `removeDeny` y la pasada entra (`written` 1).
- Caso `:294`: seis motivos con seis recetas distintas, y ninguna es la genérica de D2.
- Rojo observado: `refusal.recipe` era `undefined` (assertion inválida).
- Mutantes `y6.recipe-generic` (2 rojos) y `y6.cli-generic` (CLI): muertos.

---

## ⚪ 7–12

### ⚪ 7 · L9 escanea `src/shared/`

- Cambio en `tests/relations_reconcile_l9.spec.ts`.
- Rojo observado: «SIN clasificar … NoScopeResolverError, UnknownScopeError».
- Las dos clases entran como `unreachable` con su porqué (`src/relations/reconcile.ts:1268`).
- Mutante `w7.shared-not-scanned` (las entradas quedan rancias): muerto.

### ⚪ 8 · Deny del DESTINO sin `kind` ⇒ negativa `unmarked` en el plan

- Cambio en `src/relations/reconcile.ts:1092`.
- Caso `tests/relations_reconcile_deny.spec.ts:219`.
- Rojo observado: «expected undefined to deeply equal ['unmarked document#denied_viewer']».
- Mutante `w8.dest-unmarked`: muerto.

### ⚪ 9 · Cara `denyPhase` en el runner del DRIVER

- `src/testing/relations_contract.ts:2402`, cara `true`:
  - La fase de SU config por tipo.
  - El efecto sobre `deny()`.
  - Las tres variantes de F-05.
- Cara `false`: el mismo caso D-28, más «no afirma una fase».
- Cuentas H9: 22 → 23 (`tests/relations_harness.spec.ts`). Rojo observado: «expected 51 to equal 52».
- README «Third-party drivers».
- Mutante `w9.double-lies-phase`: muerto.

### ⚪ 10 · «PARCIAL» solo con ≥ 1 escritura

- `src/relations/reconcile.ts:604`.
- El comando imprime `pasada FALLIDA sin escribir nada:` (`commands/authz_relations_reconcile.ts:544`).
- Caso `tests/command_flags_d2.spec.ts:371`. Rojo observado: un stack crudo con 503.
- Mutante `w10.partial-always`: muerto.

### ⚪ 10 c · Barrido de `provision` que falla a medias

- Caso `:204`. Rojo observado: publicaba.
- Mutante `w10c.sweep-raw`: muerto.

### ⚪ 11 · Letra de la negativa `phase` cuando hay que honrar un deny

- Explica D8 dentro de `denyGate`.
- Cubierto por el caso `:294`.
- Mutante `w11.letter`: muerto.

### ⚪ 12 · El cambio de significado de los totales

- CHANGELOG (D2 corregido en el sitio, más el bloque de cierre) y README: `written`, `unchanged` y `extra` incluyen
  denies, con la frase para quien los parsea.

### Mutantes de pieza

`scratchpad/d2c1/piece_mut.log`: **14/14 muertos**, corridos sobre el árbol final.

### Casos existentes que el cierre puso en rojo (punto 5 c)

Todos están justificados:
1. **`openfga_driver.spec` N5** (grep `tuples ??`): mi primera versión de `deny` usaba `?? []`. Arreglé el código, no el
   caso, con `Array.isArray`: un 200 sin `tuples` no demuestra nada y devuelve el 503 original.
2. **`command_flags.spec` ⚪ 3** (docblock huérfano en `errors.ts`): había insertado el método entre un docblock y su
   método. Arreglé el código moviéndolo.
3. **`relations_reconcile_cli.spec`:** el literal `DenyRefusal` necesita `recipe`, porque cambió el tipo. Gana además la
   aserción de la receta.
4. **`relations_harness.spec`:** cuentas 22 → 23 (⚪ 9).
5. **Runbook pasos 20/21:** cambian las cuentas por el deny por grupo (🟡 5).
6. **Guardia:** cambió el título de `relations.reconcile.order` y se reescribieron los `find` de 7 mutantes de orden.

---

## Cifras

Todo en secuencia, con `:8090` reiniciado antes de cada suite. Logs en `scratchpad/d2c1/final/`.

| Modo / gate | Resultado | Δ sobre la partida |
|---|---|---|
| `npm run build` | rc 0 | — |
| `npm test` (`:memory:` + `:8090`) | **1987** passed, 2 skipped | +13 |
| `test:sqlite-file` | **2015** passed, 2 skipped | +13 |
| `test:pg` | **2112** passed, 1 skipped | +13 |
| `test:mysql` | **2114** passed, 1 skipped | +13 |
| `check:guard-mutants` | **171 / 171** muertos | 166 → 171 |
| `check:flag-mutants` | **37 / 37** muertos, 1 pending (`--prune-undeclared`, lote C) | = |
| `cutover-runbook` sqlite-file / pg | verde ×2: **22 pasos, 0 pendientes** | = (con efecto nuevo en 20/21) |
| mutantes de pieza | **14 / 14** muertos | — |

Los +13 se reparten así:
- Reconcile con deny: +5.
- Kernel D2: +4.
- La cara `denyPhase`: +1 por harness con `relationDenies: true` (3).
- `openfga` contra el servidor: +1.

## No hecho (con razón)

- **`linajes.md` y `CLAUDE.md` sin tocar.** Le toca al coordinador:
  - promover L10, con su punto de paso `tuple_order.ts` y dos propiedades;
  - el mapa del código (`tuple_order.ts`, `denyRefusalRecipe`, `deny-conditional`, `PROVISION_MODEL_HISTORY_MAX`).
- **El residuo de los grupos mixtos** (allow y deny en el mismo grupo) está declarado, no cerrado. Cerrarlo pide
  transaccionalidad (un `Write`) o congelar lecturas; ninguna de las dos es el orden.
- **La purga de `openfga` calcula los portadores solo con las tuplas que purga.** No lee los denies de otros sujetos. El
  residuo de > 100 membresías de D1 no cambia.
- **El recuento TOCTOU de `provision` se juzga por el kernel con el servidor de mentira**, no en el runbook (no hay forma
  determinista de meter un deny entre los dos barridos de un hijo). El runbook juzga la detección por la cuenta y el
  barrido (21b).
- **⚪ 10 b** (que las líneas «pasada PARCIAL» digan en qué ventana del freeze corrió la pasada): no estaba en el brief.
- **La receta de `invalid`** («a mano») no está ejecutada. Solo se ejecutó la de `undeclared`, que era la exigida.
- **El caso de la cara `denyPhase`** no siembra a mano un deny en un tipo `'read'`: la siembra depende del driver.
- **Auditoría de sistema (punto 9):** le toca al coordinador antes de publicar.

## Estado del árbol

```
 M CHANGELOG.md
 M README.md
 M commands/authz_relations_reconcile.ts
 M commands/openfga_provision.ts
 M index.ts
 M scripts/flag_mutants.manifest.json
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_driver.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/relations/define_relations_config.ts
 M src/relations/reconcile.ts
 M src/shared/backend_guard.ts
 M src/testing/relations_contract.ts
 M src/testing/relations_reconcile_contract.ts
 M src/types.ts
 M tests/command_flags_r.spec.ts
 M tests/cutover_runbook.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/guard_surface.spec.ts
 M tests/helpers/cutover_child.ts
 M tests/relations_harness.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/relations_reconcile.spec.ts
 M tests/relations_reconcile_cli.spec.ts
 M tests/scope_depth.spec.ts
 M tests/upgrade_recipe.spec.ts
?? src/relations/tuple_order.ts
?? tests/command_flags_d2.spec.ts
?? tests/openfga_write_limit.spec.ts
?? tests/relations_reconcile_deny.spec.ts
?? tests/relations_reconcile_l9.spec.ts
```

- `git diff --stat` contra `75353fe`: 28 ficheros, +2320 / −244. El cierre 1 suma `tests/relations_openfga.spec.ts` a los
  modificados.
- Hay un fichero nuevo sin seguimiento: `src/relations/tuple_order.ts`.
