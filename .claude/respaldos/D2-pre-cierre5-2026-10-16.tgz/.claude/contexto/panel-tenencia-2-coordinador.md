# Panel tenencia · ronda 2 — «hacer la 2.5 de una vez» (propuesta del dueño, 2026-10-14)

Contexto: ronda 1 en `panel-tenencia-{analista,auditor,tester,juez}.md`. El juez dejó P1 (deny) «después, condicionado».
El dueño quiere el paquete IDEAL y genérico (no acoplado a COGNITIV, pero usable por COGNITIV) y pregunta: ¿por qué no
hacer el deny bien hecho y AHORA? Postura del coordinador, para que el panel la ataque o la mejore:

**Una sola línea, la siguiente estable es 2.5.0 (no 2.4.0).** Orden:
1. Lote 0 · guardia de superficie de F-05 (L1) — condición de entrada de cualquier operación nueva.
2. Lote A · P5 (caso P5-1 + `createTestClock`), clave pura `relationTupleKey` (con `kind` desde el principio, usada por reconcile),
   `checkMany` booleano ⇒ **2.5.0-alpha.1** (COGNITIV arranca su fase 0).
3. Mediciones del deny (antes de comprometer): bytes del modelo con deny, latencia de `but not`, ciclos de `includes`
   (hoy no se rechazan), `ListObjects` parcial por deadline, y si FGA admite delete+write de la misma clave en UN `Write`.
4. Lote D · deny completo: corte de camino (D5), propia relación, opt-in por tipo, ≤43 chars, sin `*`, deny sobre group=422,
   reconcile con `kind` y censo (denies primero; prune allows primero/denies al final), purga openfga ordenada, uuid de
   partición no canónico ⇒ 422 en las 8 operaciones (D4), `expiresAt` omitido en re-deny ⇒ permanente, caducidad según
   medición (D3) ⇒ **2.5.0-alpha.2** con migración de modelo FGA (§Upgrading).
5. Lote C · P2 `listObjectsForSubject` (solo holders, directas con includes resueltos, respeta deny, cursor
   `(partition_key, object_uuid)`, índice nuevo) ⇒ **2.5.0-alpha.3**.
6. RC 2.5.0 con el criterio de estable de CLAUDE.md punto 10 (runbook, guardia, mutantes, auditoría M4, ensayo COGNITIV).

Preguntas al panel: ¿este orden es el correcto (¿C antes que D para que COGNITIV tenga «compartido conmigo» antes?)?
¿Qué se rompe al meter D y C en la misma línea que el cutover de roles (modelo FGA compartido, reconcile de hechos vs
relaciones, runbook)? ¿Qué pasa con los consumidores en 2.4.0-alpha.10 al subir (migración, `latest`, deprecate)? ¿Cuál es
el criterio de aceptación por lote y las horas totales? ¿Qué preguntar a COGNITIV ahora que el deny SÍ entra (C1–C5 siguen)?
