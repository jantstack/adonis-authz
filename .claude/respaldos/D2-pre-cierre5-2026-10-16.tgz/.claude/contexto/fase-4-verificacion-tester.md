# Fase 4 (`relations/`, ReBAC) — VERIFICACIÓN DEL TESTER (mutación)

> Worktree aislado en `2691d83`. Motores: OpenFGA `:8101`, `postgres18`, `mysql84`.
> Método: planto un mutante que rompe la propiedad que un test dice fijar y compruebo que la
> suite se pone ROJA **por la razón correcta**. Un test que sobrevive a un mutante que rompe su
> propiedad no vale. Incremental: se escribe según avanza.

## Veredicto

**La Fase 4 está probada, con UNA grieta de observación real (no una escalada) y un parche.** Planté
**9 mutantes** que rompen propiedades que la fase dice fijar; **8 murieron por la razón correcta** y
**1 sobrevivió** (M6, el guard «capacidad `true` sin método» del manager: el test liar del harness
sub-asere — comprueba el mensaje, no el 500). El 🔴 (F-05 + ⚪4), la paridad DB↔FGA, el censo del
reconcile en los dos drivers, el trigger de partición en los TRES motores × INSERT/UPDATE, y la carrera
config↔catálogo tienen dientes verificados. El superviviente NO es una escalada: el código real es
correcto; es un test que daría un falso verde ante una regresión plausible. Lo cierra el parche adjunto
(`tests-tester-fase-4.patch`), verificado rojo→verde.

Base verde confirmada:
- SQLite en memoria (sin OpenFGA): **726** passed.
- Batería de relaciones completa con `:8101`: **147** passed (con el parche aplicado).
- `relations_database` en `TEST_DB=pg` (postgres18) y `TEST_DB=mysql` (mysql84): **26/26** cada uno.

## Resumen de mutantes (se actualiza)

| # | Mutante | Fichero | Test que debe matarlo | ¿Muere? | Razón correcta |
|---|---------|---------|----------------------|---------|----------------|
| 1 | F-05 neutralizado (`#assertDeclared` no-op) | `relations/manager.ts` | bridge VERDE + 2 F-05 unit | SÍ | sí (no lanza ⇒ escalada) |
| 2 | ⚪4 off (no rechaza tipo reservado) | `relations/define_relations_config.ts` | ⚪4 unit + persisted-config | SÍ | sí (declara `role_binding`) |
| 3 | reconcile tira usersets, `written` miente | `relations/reconcile.ts` | CENSO del contrato reconcile | SÍ | sí (censo, no contador; DB+FGA, 2 dir) |
| 4 | database `#expandDown` no expande includes | `drivers/database_relations_driver.ts` | paridad DB↔FGA (check/listObjects) | SÍ | sí (deepEqual diverge) |
| 5 | openfga `#objectId` ignora partición | `drivers/openfga_relations_driver.ts` | paridad aislamiento+listObjects + ROJO control | SÍ | sí (deepEqual + id no byte-exacto) |
| 6 | manager `membersOf`/`enumerateRelations` guard = **solo capacidad** (no el método) | `relations/manager.ts` | harness liar (`relations_harness.spec.ts:102`) | **NO — SOBREVIVE** | el test solo exige `/membersOf/`; un `TypeError: ...membersOf is not a function` casa |
| 7a | trigger SQLite condición always-false | `relation_partition_trigger.ts` | `relations_database.spec.ts:84/92` (INSERT/UPDATE) | SÍ (sqlite) | sí (INSERT y UPDATE) |
| 7b | trigger PostgreSQL condición always-false | `relation_partition_trigger.ts` | idem, `TEST_DB=pg` | SÍ (pg) | sí (INSERT y UPDATE) |
| 7c | trigger MySQL condición always-false | `relation_partition_trigger.ts` | idem, `TEST_DB=mysql` | SÍ (mysql) | sí (INSERT y UPDATE) |
| 8 | `republishFusedModel` publica sin la mitad de relaciones | `relations_config_store.ts` | `relations_republish.spec.ts:92/131` | SÍ | sí (modelo pinado mutilado, `:8101`) |

---

## Detalle por mutante

### Mutante 1 — F-05 neutralizado (la escalada global, capa manager)
`#assertDeclared` → `return` inmediato. Muere:
- `relations_bridge.spec.ts:136` (VERDE del exploit contra `:8101`): `manager.relate` no lanza ⇒ `assert.fail('debería haber lanzado F-05')`.
- `relations.spec.ts:120` y `:142` (F-05 unit, tipo y relación).
**Matiz observado**: la aserción que OBSERVA la escalada real (`relations_bridge.spec.ts:162`,
`isFalse(authorize(evil))`) queda *ensombrecida*: el test ya cae en `assert.equal(caught.status,422)`
porque `assert.fail` mete un `AssertionError` en `caught`. El mutante muere igual, pero la línea 162 no
llega a correr — la prueba de la escalada VIVA la sostiene el par ROJO/VERDE, no la 162. Aceptable.

### Mutante 2 — ⚪4 desactivado (no se puede DECLARAR un tipo reservado)
`if (reservedTypes.has(type))` → `if (false && ...)`. Muere:
- `relations.spec.ts:49` (⚪4 tipo reservado: role_binding/scope/role/group/deny_binding).
- `relations.spec.ts:57` (⚪4 colisión con holder type).
- `relations_persisted_config.spec.ts:77` (guardar config con `role_binding` ⇒ 422).
Las dos capas del 🔴 (declaración + escritura) tienen dientes independientes.

### Mutante 3 — pérdida SILENCIOSA de usersets en el reconcile (censo de la 3b)
En el bucle de escritura de `reconcileRelations`, `continue` si el sujeto es userset; `written` sigue
en 6 (el contador MIENTE). Muere en el CENSO (`relations_reconcile_contract.ts:102`), NO en el contador:
- `doble en memoria` A→B y B→A.
- **`database ↔ openfga` A→B y B→A** (contra `:8101`) — la prueba que importa para el store fusionado.
- `relations_reconcile.spec.ts:59` (el caso dedicado del origen omisivo) también lo caza.
`assert.equal(report.written, 6)` PASA con el mutante: confirma que el contador es decorativo para
detectar pérdida y el censo directo (`listSubjects`) es el verificador real. Confirmado en los dos drivers.

### Mutantes 4 y 5 — paridad database↔openfga con dientes por los DOS lados
- **M4** (`database`): `#expandDown` → `[relation]` (no expande includes). Muere la paridad
  `check con includes` y `listObjects` (`relations_bridge.spec.ts:242`, deepEqual DB≠FGA).
- **M5** (`openfga`): `#objectId` compone con partición fija `fixed|`. Muere la paridad
  `aislamiento de partición` y `listObjects`, **y** el control ROJO (`:130`): la escalada exige el id
  byte-exacto `role_binding:app|<uuid>`; con la partición mutada no compone el binding real.
**Cobertura de la paridad**: cubre `check` (includes + userset ANIDADO), `listObjects`, aislamiento de
partición y `unrelate`. **Hueco observado**: la paridad head-to-head NO incluye `listSubjects` ni
`membersOf` (esta última es imposible en paridad: `openfga` la declara no soportada). Ambas quedan
fijadas por-driver en el runner de contrato, no como paridad DB↔FGA. Ver §Huecos.

### Frontera F-01/F-02 — dientes reales vs por-construcción (focus 2)
El juez ya dictaminó (§2, «gana el tester») que F-01/F-02 son **decorativos en `database`** (tablas
disjuntas) y solo tendrían dientes en `openfga`. **Confirmo, con matiz**: en `openfga` tampoco son
mutation-killable con un mutante realista de UNA pieza. `can_p0` vive en el tipo `scope`
(`intersection[difference(base, denied), rooted]`, `openfga_facts.ts:387`) y su `base` solo lee
`role_binding`/`scope` (`ttu('binding'/'parent')`). Una tupla `document:...#viewer` está en OTRO tipo:
ningún `Check` sobre `scope:app#can_p0` la puede satisfacer. Para «conflar» habría que **escribir una
tupla cross-tipo** (un `assignee`/`binding`), que es EXACTAMENTE lo que M1 (F-05) y M2 (⚪4) ya matan, o
emitir un modelo que FGA rechazaría. **Conclusión honesta**: F-01/F-02 son guardas de regresión
by-construction, NO son sensibles a mutación; las verdaderas defensas de la frontera son el exploit
(M1) y ⚪4 (M2), que SÍ mueren. Esto coincide con la degradación a documentación que el juez aceptó.

### Mutante 6 — SUPERVIVIENTE: el guard «capacidad `true` sin método» no comprueba el 500
El manager degrada el guard de `membersOf`/`enumerateRelations` a comprobar **solo la capacidad**, no el
método. El código real está bien (comprueba método Y capacidad); el mutante representa una regresión
plausible («simplifico el guard»). **Ningún test lo mata**:
- `relations_harness.spec.ts:102` («un driver que MIENTE ⇒ 500, jamás un skip») solo asere
  `assert.rejects(..., /membersOf/)` y `assert.rejects(..., /enumerateRelations/)`. Bajo el mutante el
  manager delega a ciegas y estalla con `TypeError: this[#driver].membersOf is not a function`
  (status `undefined`, code `undefined`) — cuyo **mensaje contiene «membersOf»**, así que la regex
  casa y el test pasa VERDE. Probado empíricamente.
- `relations.spec.ts:183` (que SÍ asere 500 + `E_AUTHZ_UNSUPPORTED`) usa `membersOfNative:false`
  (capacidad falsa, sin método): con el mutante el guard sigue lanzando limpio ⇒ tampoco lo caza.
**Por qué importa**: el propio docstring del test promete «⇒ 500, jamás un skip», pero no comprueba el
500. Un `TypeError` crudo escapando al llamante es justo lo que el invariante 5 prohíbe (nunca fugar el
error crudo del backend; clasificarlo). El único caso que ejercita «capacidad `true` + método ausente»
sub-asere. **Parche propuesto** (abajo): en la liar del harness, capturar y aserir `status===500` y
`code==='E_AUTHZ_UNSUPPORTED'`. Verificado: con esa aserción, el mutante 6 MUERE y el verde se mantiene.

### Mutantes 7a/7b/7c — el trigger de partición en los TRES motores (focus 6)
`relation_partition_trigger.ts` tiene una DDL DISTINTA por motor y el test solo corre contra el `TEST_DB`
activo. Verifiqué los tres por separado, plantando en cada rama una condición always-false
(`NEW.partition_key IS NOT/DISTINCT FROM/<=> NEW.partition_key`):
- **SQLite** (`WHEN … IS NOT …`): mueren `INSERT ⇒ RECHAZA` y `UPDATE que MUEVE ⇒ RECHAZA`.
- **PostgreSQL** (`IF … IS DISTINCT FROM … THEN RAISE`): baseline 26 verde (trigger real dispara), mutante
  mata INSERT y UPDATE. Corrido con `TEST_DB=pg` contra `postgres18`.
- **MySQL** (`IF … NOT (… <=> …) SIGNAL`): baseline 26 verde, mutante mata INSERT y UPDATE. `TEST_DB=mysql`
  contra `mysql84`.
Los tres motores × {INSERT, UPDATE} tienen dientes. La lección de los 8 defectos de 2.5 está cubierta:
el test NO se contenta con un motor. **Nota**: para que el gate valga, la CI debe correr los TRES modos
(el spec por sí solo solo prueba el motor activo). El dialecto ajeno (`E_AUTHZ_UNSUPPORTED_DIALECT`) y la
CTE ajena también están fijados (`relations_database.spec.ts:107/120`).

### Mutante 8 — la carrera config↔catálogo OBSERVA la pérdida (focus 7)
`republishFusedModel` publica el modelo pasando `undefined` al publisher (tira la mitad de relaciones)
pero sigue reportando `relationTypes`. Muere:
- `relations_republish.spec.ts:92` (🟡3): `modelHasDocument(modelId)` = false ⇒ el modelo republicado no
  declara `document`.
- `relations_republish.spec.ts:131` (carrera): el modelo PINADO tras la carrera no declara `document`.
La carrera NO es decorativa: comprueba el modelo pinado real contra el `:8101` y ejecuta `relate`+`check`
sobre él. **Matiz honesto**: las dos persistencias SQL de la carrera las serializa el gate de versión
(no compiten en SQL — el propio test lo documenta); lo que compite de verdad es el CAS del `model_id`, y
las dos republicaciones son IDÉNTICAS (ambas leen las dos mitades), así que «nada se pierde» es en parte
por-construcción. Pero el mutante 8 demuestra que la ASERCIÓN tiene dientes: un modelo mutilado se caza.
El 409 de la contención que no cede está fijado con un stub del CAS (`:151`, `published > 1`).

---

## El conteo del juez (focus 5): qué está clavado y qué se acepta

- **Clavado (con dientes)**: `EXPECTED_CASES = 17` y `registered === 17` / `covered.size === 6` salen del
  registro REAL del runner (`registerRelationsDriverContract`). Quitar/añadir un caso o una cara de
  capacidad rompería estas aserciones. El `9` del reconcile (`4×2 + 1`) igual. El guard
  `listObjectsTruncation:true SIN limits ⇒ throws` (`:98`) tiene dientes.
- **Aceptado (documentación, SIN dientes)**: el test «el conteo literal del juez (~41)» (`:199`) es
  aritmética AUTO-REFERENCIAL: suma un `BREAKDOWN` hardcodeado (39) + `DEFERRED` (2) = 41. NO observa el
  número real de casos en los ficheros; si un fichero perdiera un caso, este test seguiría verde. Es un
  ancla de documentación, no una verificación. Honesto que el juez lo pidió así («aterrizado»), pero no
  confundir con cobertura: la cobertura la dan el `17` y el `9`, que sí son reales.

## Huecos de observación

1. **M6 — el guard del manager sub-asere** (parche adjunto). Único superviviente; ya explicado.
2. **La paridad DB↔FGA no cubre `listSubjects` head-to-head** (sí `check`/`listObjects`/aislamiento/
   `unrelate`). `membersOf` es imposible en paridad (openfga la declara no soportada). Ambas quedan
   fijadas por-driver en el runner de contrato, no como paridad. Riesgo bajo; se cerraría añadiendo un
   caso `listSubjects` a `bothAnswerSame` en `relations_bridge.spec.ts`.
3. **`reconcileRelations` escribe por el DRIVER directo, saltándose F-05** (confesión #4 del lote 4-6).
   NINGÚN test observa que una migración NO propague una tupla envenenada (`role_binding`), y no puede
   haber una aserción «segura» porque el reconcile copia fielmente. La mitigación declarada («un origen
   envenenado no puede existir porque el otro driver aplica F-05 al escribir») es FRÁGIL a nivel de
   verificación: el DRIVER no aplica F-05 —solo el manager lo hace, y el test ROJO del puente
   (`relations_bridge.spec.ts:111`) lo PRUEBA escribiendo `role_binding` en directo—. `modelDrift` lo
   REPORTA en `--dry-run` pero NO bloquea la escritura en una pasada real (`reconcile.ts:149`). **Es una
   decisión de arquitectura/seguridad: la escalo al AUDITOR**, no la juzgo yo. Como verificador solo
   constato: no hay observación de este camino.
4. **F-01/F-02 by-construction, no mutation-killable** (detallado arriba). Aceptado por el juez; lo
   confirmo. Los dientes reales de la frontera son M1 (F-05) y M2 (⚪4).
5. **El gate de los TRES motores del trigger vive en el runner, no en un solo `npm test`**. Solo prueba
   el motor activo; la CI DEBE correr los tres modos o el defecto de un motor no medido pasa (justo la
   lección de 2.5). Verificado a mano que los tres tienen dientes; el aviso es para el pipeline.

## Lo que intenté romper y NO pude (bien defendido)

- **La escalada global (🔴)**: neutralicé F-05 (M1) y ⚪4 (M2) por separado; los dos mueren. No encontré
  forma de escalar `relate`→`roles.authorize` por el manager sin que un caso caiga rojo.
- **El censo del reconcile**: una pérdida SILENCIOSA de usersets con el contador `written` intacto se
  caza en `doble en memoria` Y en `database ↔ openfga` (las dos direcciones). El contador es decorativo;
  el censo directo es el verificador — tal como prometió la lección 3b.
- **La paridad**: un defecto en CUALQUIERA de los dos drivers (includes en database, partición en
  openfga) rompe el `deepEqual`. No hay falso-verde por un solo lado.
- **El trigger de partición**: en los tres motores, INSERT y UPDATE. Ningún motor quedó sin dientes.
- **La carrera config↔catálogo**: un modelo pinado mutilado (mitad de relaciones perdida) se caza contra
  el `:8101`. El 409 de contención que no cede está fijado.

## Cómo aplicar el parche

`git apply .claude/contexto/tests-tester-fase-4.patch` desde la raíz del repo. Refuerza el caso liar de
`relations_harness.spec.ts` para aserir `status===500` + `code==='E_AUTHZ_UNSUPPORTED'` (no solo la
regex). Verificado: rojo bajo M6, verde con el código actual. Cero cambios de producción.
