# Informe de COGNITIV (10-09-2026, 3º) — alpha.5/6/7 verificadas; 3 bloqueantes del cutover + 7 no bloqueantes

Instalada `2.4.0-alpha.7` (typecheck limpio, 831/831 con `database`, contrato y costura verdes). `only` medido: 14 ms
frente a 456 ms con 500 ajenas. Panel propio (analista/auditor/tester/juez) contra el paquete real con dobles.

## Bloqueantes para su cutover a `openfga`
1. **La raíz `app` como clave de bloqueo = mutex de plataforma.** `#changeKeys` incluye al PADRE; entre dos
   `attached(X, app)` no hay orden que conservar (la raíz no se mueve ni se purga), pero `scopeKey(APP_SCOPE) === 'app'`
   hace que UNA aparcada de un tenant pare el alta de organización de TODOS (incluido el registro público). Medido:
   cinco pasadas completas del cron con `applied = []`. Piden exentar la raíz (o `blockOnParentKey: false` para la raíz,
   u opción de config). Variante fail-open: un aparcado en `moved(unit → org A)` contamina `organization|A` y todo
   `moved` posterior de esa org queda `deferred` indefinidamente ⇒ el store conserva el padre VIEJO sin caducidad.
2. **`requeue` que aplique en la misma pasada** (`requeueScopeChanges([id], { apply: true })`): hoy vuelve a `pending()`
   con su id ORIGINAL (menor) y `attempts = max − 1`; la siguiente pasada `only` del tenant sale `depends-on:<id>`; el
   incidente no se cierra con un comando, hace falta un `relay` completo detrás (medido, tester P14).
3. **Edad de la cola en el reporte** (`oldestPendingAt`/`pendingAgeMs`) y/o aparcado por TIEMPO además de por intentos:
   como el 503 no consume intento, una caída larga del store deja `attempts = 0`, `dead = 0` y la cola creciendo — la
   única alarma del contrato es ciega justo ahí (medido, auditor B2: 10 pasadas, 0/0).

## No bloqueantes
4. `origin: 'parked' | 'pending' | 'failed'` en la entrada del reporte (hoy solo en la prosa de `deferred[].error`).
5. `dead` filtrado u omitido bajo `only` (`report.dead` global aunque `deadEntries` se filtre): les llega `last_error`
   y actor de otros tenants.
6. `enqueue` sin `{ transaction }` ⇒ debería ser 500 `E_AUTHZ_CONFIG` antes del INSERT (hoy acepta y escribe fuera de la
   unidad de trabajo; tester P13).
7. Con una transacción ya cerrada, el error es `E_AUTHZ_BACKEND_UNAVAILABLE` «no respondió (enqueue)»: es del
   llamante, debería ser `E_AUTHZ_CONFIG`.
8. `enumerateRelationsManyNative` en `RelationsDriverCapabilities` (o implementarlo en `database_relations_driver`):
   sin capacidad hay que adivinar por el cursor si se está en el camino de respaldo, que no permite reanudar.
9. `relayScopeChanges({ waitForLeaseMs })`: `busy` es inmediato; una pasada completa con backlog convierte a todo
   escritor concurrente en `busy` durante segundos.
10. El 422 `E_AUTHZ_SCOPE_DEPTH_LIMIT` nombra `OPENFGA_RESOLVE_NODE_LIMIT` y el techo del servidor (fuga a un tenant
    si no se mapea). Docs: `maxDepth` cuenta SALTOS hasta `app` ⇒ N niveles con raíz = 1 necesita `maxDepth = N + 1`.

Mientras tanto: sonda del aparcado antes de abrir la trx (excluida la raíz), alarma por edad, cron cada minuto +
inline, `requeue` + `relay` en el runbook; cutover a `openfga` condicionado a 1–3.
