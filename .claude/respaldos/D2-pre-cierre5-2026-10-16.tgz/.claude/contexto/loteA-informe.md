# Lote A (plan 2.5) — informe del implementador (2026-10-14) ⇒ `2.5.0-alpha.1`

**Árbol `main` sobre `645af34`** (lote 0 + lote R fusionados). Único agente que muta el árbol; **sin commit y sin tocar
`version`** (los hace el coordinador al cerrar). Entorno medido: Node 22.23.2 (`nvm use 22`), `postgres18`, `mysql84`,
OpenFGA **`:8090`** (`openfga-dev`, reiniciado con `docker restart openfga-dev && sleep 8` antes de cada suite; `:8101` no
responde). Método: rojo observado → verde → mutante por pieza; gemelos; tablas de verdad; toda salida nueva dice qué rama
corrió; los TRES gates al final.

## 0 · Rojos observados ANTES de cada pieza (el método)

| Pieza | Rojo observado (sin tocar tests, tras el cambio de `src/`) |
|---|---|
| `checkMany` + guardia | `guard_surface.spec`: **G-0 rojo en las TRES capas y en el doble** («RelationsManager tiene operaciones SIN fila: checkMany», ídem `DatabaseRelationsDriver`, `OpenFgaRelationsDriver`, `makeRelationsDriver`), G-R «clasificación obligatoria» rojo (sin `PORT_READS`), «todo método se invoca» rojo (sin `INVOKE`), G-M rojo (finds que ya no casan). 53 rojos en total en la primera corrida (ver abajo). Es exactamente el criterio de aceptación de la fila A del juez: «la guardia se pone roja al añadir `checkMany` sin su fila». |
| D4 | Las 42 celdas `partition` (manager 11, database 11, openfga 10, doble 10) rojas con `DASHLESS_PARTITION = 'accepted'` («uuid sin guiones: hoy se ACEPTA» ⇒ recibió 422) — los casos cambian de EXPECTATIVA, no de forma; y los tres casos de «purge barre las dos ortografías» de `relations_database.spec.ts:206/229/252` rojos (ya no barre: 422). |
| P5-1 | Caso A-1 escrito → mutante «borrar `clock: config.clock`» aplicado en scratch ⇒ **rojo** («el reloj del config NO llegó al manager de relaciones: con la hora de pared, 2030 es futuro y concede»); restaurado ⇒ verde. Hasta este lote sobrevivía (tester §0, medido). |
| P5-3 | Primera versión de la lista literal: rojo por `created_at: systemClock(),` del driver `database` — un SELLO (K5), no una decisión: entra en la lista literal con su razón. |
| F-R1 | `reconcile.spec` «alpha.10 · 4 · EFECTO» ampliado: `podado.skipped['unknown-scope']` era 1 y `reconcileLines(podado).clean` era `false` ⇒ rojo; con el bucket `pruned`, verde. El runbook (paso 13) lo tenía como hallazgo abierto. |
| F-R2 | `relations_reconcile_cli.spec` tabla de verdad: fila «levantado y real» daba `error` + `clean=false` ⇒ rojo; `command_flags_r.spec` R-8 con exit 1 y «En una pasada real es 500» ⇒ rojo. Gemelo de roles (`reconcile.spec` tabla F-R2): «antes de usar --allow-mass-delete» sobre una pasada que lo usó ⇒ rojo. |
| F-R3 | `command_flags.spec` F-R3: `run.error` = `FreezeHeldError` (crudo) ⇒ rojo; runbook paso 16 afirmaba el error crudo (reescrito a `ko(…)` con letra). |
| D13 | Caso «driver llamado directamente» verde en los dos drivers y en el doble desde el lote 0 (H8 ya cerrado ahí): se afirma, no hubo rojo que observar; el rojo lo da un harness de terceros que siembre tipos no declarados por su driver (ruptura declarada). |
| `relationTupleKey` | A-7 (por fuente): la primera versión de `reconcile.ts` conservaba `scopeKeyOf` ⇒ rojo del grep «sin copia de scopeKey»; unificado ⇒ verde. |

## 1 · Piezas entregadas (qué existe ahora)

### P5 · reloj (`createTestClock`, P5-1/P5-2/P5-3, A-4)
- `src/testing/test_clock.ts`: `createTestClock(start?)` ⇒ `TestClock` = función ESTABLE `() => Date` con `set`/`advance`/`now`/`at`. No muta `systemClock`. Exportado por `/testing` (`main.ts`).
- Casos: `relations_service.spec` **P5-1** (A-1, mutante medido: borrar `clock: config.clock` del provider ⇒ rojo), **P5-2** (estable, UTC, validación de entradas, `systemClock` intacto), **A-4** (fila de freeze con lease T+15 s plantada con `acquireFreeze`: en T relaciones 503 `E_AUTHZ_FROZEN`; `clock.advance(16_000)` ⇒ la escritura entra; un manager sin reloj (hora de pared) sigue congelado ⇒ el MISMO reloj decide la barrera de `relations/manager.ts:~373`). `clock.spec` **P5-3**: en `src/relations/{manager,reconcile}.ts` y los dos drivers de relaciones, ninguna llamada directa `systemClock()` y las menciones son EXACTAMENTE la lista literal de defaults (+ el sello `created_at` de `database`, K5).
- README «Testing expiry from your app (2.5.0)» con el ejemplo `app.inTest ? testClock : undefined` y el aviso del freeze/lease.

### `relationTupleKey` (P3) y unificación
- `src/relations/tuple_key.ts`: `relationTupleKey({ partition, object, relation, subject, kind? })` pura, exportada desde la raíz (`index.ts`) junto a `relationSubjectKey` y los tipos; `kind` ∈ {allow, deny}, default `allow`, **delante** en la clave: `allow|unit|<uuid>|document:<id>#viewer@user:<uuid>`. **Literal de oro** fijado en `tests/relation_tuple_key.spec.ts` (allow y deny sobre la misma terna, `app`, userset).
- `src/relations/reconcile.ts`: `tupleKey = relationTupleKey` (alias, identidad de función), `scopeKeyOf` eliminado ⇒ `scopeKey` de `identity.ts`; A-7 por fuente (patrón C5). A-5 inyectividad (11 variantes), A-8 dos ortografías ⇒ dos claves. A-6 («la clave no cambia al renovar; reconcile cuenta `updated`») lo cubre el caso R-15 del contrato de reconcile ya existente (misma clave, otra caducidad ⇒ `updated: 1`) y la idempotencia; no se añadió fila al REC (sigue en 11): el literal de oro + A-5 fijan que la caducidad NO entra en la clave.
- El doble de `/testing` usa `partitionKey` (D4 lo alcanza, ⚪ 11); `NON_SURFACE_FUNCTIONS` clasifica `relationTupleKey`/`relationSubjectKey`.

### `checkMany` (P4)
- Puerto: `RelationsDriver.checkMany?(subject, relation, objects, partition): Promise<boolean[]>` (opcional, SIN capacidad —conflicto 9 del juez—). `src/relations/check_many.ts`: `RELATIONS_CHECK_MANY_MAX = 50` (= `FGA_MAX_BATCH_CHECK`, afirmado en `scope_depth.spec`), `assertCheckManyObjects` (vacío o > 50 ⇒ 422 **`E_AUTHZ_CHECK_MANY_BATCH`**, clase nueva `CheckManyBatchError` en `errors.ts`, exportada), `distinctObjects`/`expandByPosition` (duplicados por posición).
- Manager: F-05 y gramática del id **por ítem**, partición (D4), sujeto; delega si el driver lo trae y **valida** la respuesta (`boolean[]` de la longitud exacta o 500 `E_AUTHZ_INTERNAL` nombrando el driver, paridad `authorizeMany`); si no, compone N `check` (el primer 503 propaga, ningún booleano).
- `database`: UNA consulta (CTE `principal` + `SELECT DISTINCT object_type, object_uuid` con un grupo por TIPO —los includes se expanden por tipo— y UN `now`). `openfga`: un `batchCheck` por cada 50 distintos (con el tope: uno), `correlationId` por ítem, `correlateBatchResults` del driver de roles (alineación por id, nunca por posición), `current_time` en cada ítem (el mismo), `error` por ítem ⇒ 503 total.
- Doble: `checkMany` solo con `singleCheckRelations` (el MÍNIMO no lo trae ⇒ el runner ejerce el respaldo del manager, A-15/P4-9); un `now` por lote (A-18).
- Runner (COMÚN, 6 harnesses): **P4-1/P4-2** (≡ N check posición a posición: directo, includes, userset ANIDADO, caducada, nada; orden de la petición con ids en orden inverso, F/T patrón calculado con N check), **P4-4a** `[a,a,b]⇒[x,x,y]`, **P4-5** 50 responde / 51 y `[]` ⇒ 422 con CERO llamadas, **P4-6** F-05 por ítem (role_binding en la posición 21 de 21, id inválido en la última, relación no declarada) con cero llamadas, **P4-7** tipos mezclados `document`/`workspace` (H10: segundo tipo en `contractRelationsConfig`, `RELATIONS_CONTRACT_OBJECT_TYPES` exportado). **A-18** ampliado en la cara `injectableClock:true` (reloj que avanza 1 ms por lectura ⇒ `reads === 1` y las tres conceden). **A-15** en `relations.spec` (respaldo: orden, primer 503 corta, sin booleanos) + validación de terceros (5 formas malas ⇒ 500). **A-16/A-17/A-19** en `relations_openfga.spec` contra el servidor real (espía sobre `client.batchCheck`: respuesta barajada ⇒ alineada; 45 distintos en 50 posiciones ⇒ 1 llamada/45 ítems; `error` en un ítem ⇒ 503; un resultado de menos ⇒ 500; `current_time` idéntico en cada ítem). **A-17 database** (una consulta) lo juzga la sonda G-R + `countQueries` en `relations_database.spec` (D4 cero sentencias) y el propio diseño; no se añadió espía aparte.
- Guardia: fila `checkMany` en las cuatro capas (`managerRead`/`driverRead`/`doubleOp`), `PORT_READS`, `INVOKE.checkMany` con la variante en la **posición 1** (y relación `viewer` para la variante `type`: así lo único que falla es el `role_binding` de [1]), `F05_VARIANTS.checkMany`, **9 mutantes nuevos** (`manager.checkMany.f05`, `.f05.first-only` —validar solo `objects[0]`—, `.partition`; `database.checkMany.f05/.partition`; `openfga.checkMany.f05/.partition`; `double.checkMany.f05`; `double.partition.grammar` amplía a `double.checkMany.partition`). ⚪11 pasa a «diez operaciones».
- README: §Relations «Deciding in bulk: `checkMany`» con la frase literal pedida («`checkMany` returns one boolean per object: `false` does not distinguish "denied here" from "nothing here", so it cannot implement deny-wins along a chain of objects that you walk yourself»), «F-05 covers **all nine operations of the port**» (F10 de `relations_events_docs.spec` reescrito: nine, `checkMany` (per item)), fila «Objects per `checkMany`» en Limits atada a la constante.
- `EXPECTED_CASES` 22 → **28** (+5 checkMany: P4-1/P4-2 van en UN caso; +1 D13), `CAPABILITY_KEYS` 8, con desglose en `relations_harness.spec` y un caso que exige los seis en FULL y MÍNIMO y que el MÍNIMO no traiga `checkMany`.

### D4 · partición sin guiones ⇒ 422 + receta
- `src/identity.ts`: `assertPartition` (= `assertScope` + «32 hex sin guiones ⇒ 422 `E_AUTHZ_INVALID_IDENTITY`», mensaje con la forma 8-4-4-4-12 y la receta), `partitionKey` (= `assertPartition` + `scopeKey`), `isDashlessUuid`, `dashedUuid`; exportados desde la raíz. **Punto de paso único**: `RelationsManager` (las 11 operaciones + `#assertSubject`), los dos drivers (`#keyOf` ⇒ `partitionKey`; `assertPartition` como defensa en profundidad), el doble (`scopeKeyOf ⇒ partitionKey`) y `reconcileRelations` (`partitionsOf`). **Se elimina el barrido de dos ortografías** (`scopeSpellings` ya no se importa en los drivers de relaciones; `#partitionSpellings` borrado en los dos): una partición es UNA clave. Roles NO cambian en el lote A (`assertScope`/`scopeSpellings` siguen: ahí canoniza la cadena, invariante 17) — **y en el cierre-2 `scopeSpellings` adopta la MISMA regla que las particiones** (🟠 R1: donde no hay cadena, toda ortografía no canónica añade la canónica).
- Guardia: `DASHLESS_PARTITION = { status: 422, code: 'E_AUTHZ_INVALID_IDENTITY' }` (los 42 casos cambian de expectativa, no de forma), mutantes `partition` reescritos a las formas nuevas (identity: `partitionKey` sin `assertPartition`; driver: sin la línea; `enumerateRelationsMany` de `database`: la clave con `scopeKey` a secas), y **mutante GLOBAL `identity.dashless.D4`** (apaga la rama del 32 hex ⇒ las 42 celdas rojas).
- Casos reescritos como «sin guiones ⇒ 422»: `relations_database.spec` (las 11 operaciones con cero sentencias y la fila canónica intacta; el manager con cero eventos — la barrera del freeze lee ANTES, por diseño, así que se afirma «cero sentencias de ESCRITURA»), `relations_openfga.spec` (el caso 3-4/3-6: `org|U` vs `organization|U` siguen sin cruzarse; la sin guiones ⇒ 422 en `enumerateRelations`/`enumerateRelationsMany` (posición 1)/`purgeObject`/`checkMany` con CERO llamadas al cliente), `relations_reconcile.spec` C2 (particiones de prueba ahora con guiones). **Ids de objeto y sujeto NO se rechazan**: caso «byte a byte en las dos direcciones» (objeto escrito sin guiones y preguntado con, y al revés; holder igual) + frase del README («compared byte for byte; use one spelling»).
- **Receta ejecutada** (`upgrade_recipe.spec`, grupo D4, en pg, mysql y sqlite): bloques `-- D4 · PostgreSQL/MySQL/SQLite` del README (§«Upgrading to 2.5.0: partitions written without dashes»), una sentencia por línea: **detector** (`split_part … ~ '^[0-9a-f]{32}$'` / `SUBSTRING_INDEX … REGEXP` / `substr … GLOB '[0-9a-f]×32'`), **fusión** con el gemelo canónico quedándose con la caducidad que MÁS dura (`NULL` = nunca gana; patrón `folded-scope`), **borrado** del duplicado, **re-clavado** del resto con su `subject_partition` (el trigger BEFORE UPDATE exige que vayan juntos; en MySQL la asignación de `subject_partition` va ANTES porque MySQL evalúa `SET` de izquierda a derecha con el valor ya actualizado). El caso siembra 8 filas (sola, gemela con caducidad lejana vs cercana, gemela NULL vs caducidad, userset con `subject_partition` viejo, id de 32 caracteres NO hex), observa el driver 2.5 ANTES (422 por la sin guiones, `false` por la canónica = H5) y DESPUÉS (concede, incluido el userset re-clavado; detector 0), y corre la receta **dos veces** (idempotente). **openfga**: caso contra el servidor real (`relations_openfga.spec` «D4 · receta»): tupla vieja `document:unit|<32hex>|…` plantada con el SDK ⇒ 422/`false`; `reconcileRelations` desde `database` (ya canonizada) escribe la canónica (`check` true); `client.write({ deletes })` borra la vieja; la concesión sobrevive (write ANTES de delete: fail-closed).

### D13 · segunda mitad
- Caso nuevo del runner (COMÚN): «D13 · F-05 en el DRIVER llamado directamente (sin manager)»: `relate/unrelate/check/checkMany/listObjects/listSubjects/purgeObject/purgeSubject(userset)` contra `role_binding` ⇒ 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN`; relación no declarada ⇒ `E_AUTHZ_RELATION_UNKNOWN`; control: lo declarado entra por el driver y la enumeración no tiene `role_binding`. Corre sobre `database` (4 modos), `openfga` y los dos dobles. `EXPECTED_CASES` lo cuenta (+1). README §Upgrading to 2.5.0 (ruptura para harness de terceros) y CHANGELOG.

### D15 · regla
- `CLAUDE.md`: regla de higiene «Regla D15» junto a «Un driver DECLARA…» y punto 11 de «Cómo se decide»: desde 2.5.0 toda clave nueva de capabilities es `?:`, se normaliza a `false` y entra con su par; `checkMany` entró sin capacidad a propósito.

### F-R1 / F-R2 / F-R3 (linaje L8, letra ≠ efecto) — cuatro líneas de cierre cada uno

**F-R1** — `authz:reconcile --to=openfga --prune` (mantenimiento) contaba en `skipped.unknown-scope` lo que borraba ⇒ exit 1.
Arreglo: `ReconcileFactsOrigin.self` (lo pone `#factsOrigin` del manager en la pasada de mantenimiento, `#isMaintenancePass`), y en `openfga_driver.reconcile` un `discard(kind, reason, detail)` que con `prune && origin.self` cuenta en **`report.pruned[reason]`** (nuevo, opcional) y si no, `note` (⇒ `skipped`). Lo usan las SEIS salidas de descarte de `wantAssignment`/`wantDeny`/`readOriginFacts` (`expired`, `unknown-scope`, `unknown-role`, `unknown-holder-type`, `unknown-permission`, `permission-not-in-model`); `role-not-visible` sigue en `note` (ese hecho SÍ se quiere). `reconcileLines` imprime «N hecho(s) del propio store por '<motivo>' BORRADOS por --prune» (dry-run: «se BORRARÍAN») y `pruned` no es deriva.
- (a) *Gemelos*: `--to=database` **no aplica**: `database` no declara `hierarchyFacts`, no hay pasada de mantenimiento y sus descartes del store (`unknown-scope`) son filas que nadie borra (la fila del origen sigue): `skipped` es el estado real. Migración `--from=<otro>`: igual, `skipped` (caso existente `reconcile.spec` «--prune borra los hechos del scope que ya no resuelve» sigue afirmando `skipped.unknown-scope ≥ 1` en dry-run+prune). `authz:relations:reconcile`: no aplica (sin mantenimiento ni `unknown-scope`).
- (b) *Tabla de verdad* `origen(self|ajeno) × prune × dryRun` (ejecutada en `reconcile.spec` «F-R1 · tabla de verdad» contra el servidor real, 4 filas self; las filas «ajeno» las cubren los casos existentes):

| origen | prune | dryRun | bucket | `deleted` | `clean`/exit | letra |
|---|---|---|---|---|---|---|
| self | no | no | `skipped.unknown-scope` + `extra-fact` | 0 | false / 1 | «repite con --prune» |
| self | no | sí | `skipped` | 0 | false / 1 | ídem |
| self | sí | sí | `pruned.unknown-scope` | 3 (haría) | false / 1 (DERIVA) | «se BORRARÍAN con --prune» |
| self | sí | no | `pruned.unknown-scope` | 3 | **true / 0** | «BORRADOS por --prune» |
| ajeno (`authz_*`/`--from`) | sí | * | `skipped` | los gemelos del store | false / 1 | la fila del origen la resuelve el humano |
| ajeno | no | * | `skipped` | 0 | false / 1 | «repite con --prune» |

- (c) *Casos existentes que el arreglo puso rojos*: ninguno; se AMPLIÓ «alpha.10 · 4 · EFECTO» (ahora afirma `pruned`, `clean`, letra) y el runbook paso 13 (el `finding` F-R1 se queda como aserción + letra). `reconcile.spec:1986` («skipped unknown-scope ⇒ no clean») sigue siendo verdad para `skipped`.
- (d) *Linaje*: **L8, 5.ª iteración** (🟡): no se parchea en el comando; el bucket del REPORTE clasifica el estado real (`pruned`) y el comando solo imprime. `linajes.md` actualizado.

**F-R2** — `--allow-mass-delete` levantaba el seguro y la letra decía «borraría … En una pasada real es 500» con exit 1.
Arreglo: `allowMassDelete` viaja en el reporte de los DOS puertos (`RelationsReconcileReport.allowMassDelete`, `ReconcileReport.allowMassDelete?` puesto por los dos drivers de roles); `relationsReconcileLines`/`reconcileLines`: levantado + real ⇒ warning «se LEVANTÓ con --allow-mass-delete: se han borrado N» y limpia; levantado + dry-run ⇒ «la pasada real las/los BORRARÁ» (deriva); sin levantar ⇒ el error de siempre.
- (a) *Gemelos*: roles ↔ relaciones: los DOS arreglados (roles tenía el mismo defecto: «antes de usar --allow-mass-delete» de una pasada que lo usó; `clean` de roles no miraba `massDelete` así que allí era solo letra). Comando ↔ manager: la bandera llega al manager (A-6 y R-8 ya lo medían) y vuelve en el reporte.
- (b) *Tabla de verdad* massDelete × allowMassDelete × dryRun (6 filas en `relations_reconcile_cli.spec` F-R2 y 6 en `reconcile.spec` F-R2; R-8 por el kernel afirma exit 0 + letra):

| massDelete | allow | dryRun | línea | nivel | clean |
|---|---|---|---|---|---|
| sí | sí | no | «se LEVANTÓ … se han borrado N» | warning | **true** |
| sí | sí | sí | «borraría N … la pasada real las BORRARÁ» | warning | false |
| sí | no | no/sí | «En una pasada real es 500 …» / «antes de usar --allow-mass-delete» | error | false |
| no | * | * | ninguna | — | según el resto |

- (c) *Casos existentes rojos*: R-8 (`command_flags_r.spec`) cambió de afirmar solo el EFECTO a afirmar efecto + exit 0 + letra (el comentario «no se arregla aquí» desaparece). Ninguno más.
- (d) *Linaje*: L8, 6.ª iteración; propiedad universal ampliada: «toda bandera que levanta un seguro viaja en el reporte».

**F-R3** — `authz:reconcile` con freeze VIVO ajeno (423) salía como error crudo; su gemelo lo imprimía.
Arreglo: el `catch` de `authz:reconcile` trata `E_AUTHZ_FREEZE_HELD` y `E_AUTHZ_MASS_RECONCILE_REFUSED` como su gemelo (letra + exit 1), además de `STALE_SOURCE` y `OPERATOR_WINDOW_EXPIRED`.
- (a) *Gemelos*: comando ↔ comando: el conjunto de códigos con letra es el MISMO en los dos (`authz:relations:reconcile` ya lo tenía); manager: sin cambio (el 423 sigue siendo `FreezeHeldError` para la API).
- (b) *Tabla de verdad*: no aplica (una entrada discreta: el código del error; caso por código en `command_flags.spec` F-R3: 423 ⇒ letra con dueño, fence y `authz:unfreeze`, `destino.seen = 0`; 500 masivo ⇒ letra «NI UN hecho utilizable» + exit 1).
- (c) *Casos existentes rojos*: runbook paso 16 (`held.error.code === 'E_AUTHZ_FREEZE_HELD'`) reescrito a `ko(held, …, '--fence=N')` + `error` nulo.
- (d) *Linaje*: L8, 7.ª iteración.

## 2 · Gemelos (roles ↔ relaciones) comprobados para las piezas nuevas

- ¿`roles` tiene `checkMany`? Tiene `authorizeMany(subject, permission, scopes)` (2B), que ya es «N `authorize` por posición, `[]` ⇒ `[]`, un `batchCheck`». **Divergencia declarada y a propósito**: `authorizeMany([])` ⇒ `[]` (contrato publicado desde 2.1) y `checkMany([])` ⇒ 422 (decisión del juez, conflicto 10: `[]` ⇒ `[]` se confundía con «todo denegado»); el tope 50 de `checkMany` no existe en `authorizeMany` (ahí el SDK trocea). No se cambia `authorizeMany` (sería breaking de 2.1).
- ¿`batchCheck` de roles comparte la alineación? **Sí**: `correlateBatchResults` (export de `openfga_driver.ts`) es la MISMA función; el driver de relaciones la importa (no la copia). El `error` por ítem ⇒ 503 es la misma regla (invariante 5).
- Barrera del freeze: el mismo reloj en roles (`#assertNotFrozen` de `src/manager.ts`) y relaciones (A-4 lo mide en relaciones; roles ya lo medía `freeze.spec` con reloj inyectado).
- D4: roles **no cambia** (invariante 17: canoniza la cadena; `scopeSpellings` sigue para `detached`/`revoke`); README lo dice.

## 3 · Ficheros

Nuevos: `src/relations/tuple_key.ts`, `src/relations/check_many.ts`, `src/testing/test_clock.ts`, `tests/relation_tuple_key.spec.ts`.
Modificados: `src/identity.ts`, `src/types.ts`, `src/errors.ts`, `src/relations/{manager,reconcile}.ts`, `src/drivers/{database,openfga}_relations_driver.ts`, `src/drivers/{database,openfga}_driver.ts` (reporte: `allowMassDelete`, `pruned`), `src/manager.ts` (`self`), `src/testing/{main,relations_contract}.ts`, `index.ts`, `commands/authz_reconcile.ts`, `commands/authz_relations_reconcile.ts`, `tests/fixtures/{guard_manifest.ts,guard_mutants.json}`, `tests/{guard_surface,clock,command_flags,command_flags_r,cutover_runbook,reconcile,relations,relations_database,relations_events_docs,relations_harness,relations_openfga,relations_reconcile,relations_reconcile_cli,relations_service,scope_depth,upgrade_recipe}.spec.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`, `.claude/contexto/linajes.md`.
Sin tocar: `version` de `package.json`, `EXPECTED_FUSED` de `openfga_facts.spec` (usa su propio `RELATIONS`), `migration_stub.spec`.

## 4 · Cifras y gates (medido EN SECUENCIA, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite)

| Qué | Resultado |
|---|---|
| `tsc --noEmit` · `npm run typecheck` · `check:purity` · `build` | ✔ los cuatro (exit 0) |
| `npm test` (`:memory:` + OpenFGA) | **1656 / 1656** (antes del lote: 1598 ⇒ +58) |
| `npm run test:sqlite-file` | **1684 / 1684** |
| `npm run test:pg` | **1780 / 1780** |
| `npm run test:mysql` | **1782 / 1782** (primera pasada 1781/1782: un defecto del SPEC nuevo de la receta D4 —leía `expires_at` sin `ExpiryCodec.select`, el codec de MySQL lo rechaza ruidoso—; corregido en el spec, la receta en los 4 motores y la suite entera de MySQL re-medidas en verde) |
| `check:guard-mutants` (`:memory:`) | **103 / 103 muertos**, 0 vivos, 0 sin casar (84 s) |
| `check:guard-mutants -- --db sqlite-file` | **103 / 103 muertos** (84 s; línea base 165 casos) |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes (`--allow-drop-deny` D, `--prune-undeclared` C) (48,8 s) |
| `cutover-runbook` sqlite-file | **VERDE**: 20 pasos + 2 pendientes, guardia del README 7 líneas / 42 invocaciones, 13,3 s (presupuesto 60 s) |
| `cutover-runbook` pg | **VERDE**: 20 pasos + 2 pendientes, 15,9 s |
| Bases huérfanas (PG/MySQL) al terminar | 0 / 0 |

Desglose del +58 en `:memory:` (6 harnesses del runner de relaciones corren la COMÚN en ese modo): runner **+6 × 6 = 36**
(P4-1/2, P4-4a, P4-5, P4-6, P4-7, D13; `EXPECTED_CASES` 22 → 28); `relation_tuple_key.spec` **+5**; `relations.spec` **+3**;
`relations_service.spec` **+3** (P5-1, P5-2, A-4); `clock.spec` **+1** (P5-3); `relations_harness.spec` **+1**; `reconcile.spec` **+3**
(F-R1 tabla, F-R1 lines, F-R2 lines; la «alpha.10 · 4» ampliada no suma); `relations_reconcile_cli.spec` **+1**;
`command_flags.spec` **+1** (F-R3); `relations_openfga.spec` **+4** (A-16, A-17, A-19, receta D4); `relations_database.spec` **+0 neto**
(3 casos de dos ortografías ⇒ 3 casos D4); `upgrade_recipe.spec` **+1** (receta D4; en pg/mysql son 3 casos, en sqlite 2 — la
receta 1.x→2.x solo corre en pg/mysql). Primera corrida tras el cambio de `src/` sin tocar tests: **53 rojos** (los de §0).

Un rojo del ARNÉS observado en el camino, corregido en el spec y no en `src/`: el paso 16 del runbook afirmaba el 423 como error
crudo (`held.error.code`) — con F-R3 el comando imprime letra; la primera reescritura buscaba `--fence=N` y el mensaje del 423
dice `fence N` + `authz:unfreeze` (como el caso unitario F-R3, corregido igual).

## 5 · Lo que queda fuera (declarado)

- `authorizeMany([]) ⇒ []` (roles, 2.1) vs `checkMany([]) ⇒ 422`: divergencia a propósito (juez, conflicto 10); no se toca
  `authorizeMany`.
- `checkMany` compuesto por el manager (driver sin el método) decide cada `check` con su propio instante: escrito en el README; el
  «un solo now» es promesa de los dos drivers del paquete.
- En `openfga` las tuplas viejas sin guiones no las barre ningún comando (el driver ya no compone ese id): receta documentada y
  ejecutada = reconcile desde `database` + delete con el SDK; «si el store es la única copia», a mano con el SDK (README).
- `report.pruned` solo lo publica la pasada de mantenimiento de `openfga` (único driver con `hierarchyFacts`); un driver de
  terceros sin mantenimiento no lo trae (campo opcional).
- A-6 (REC «clave estable al renovar») no añadió fila al contrato de reconcile: lo fija el literal de oro + el caso R-15 existente
  (`updated: 1`); REC sigue en 11.

## Cierre (auditor) — 2026-10-15 (`loteA-auditor.md`: 2 🟠, 5 🟡, 5 ⚪; decisiones del dueño §2026-10-15)

Mismo árbol `main` sobre `645af34`, sin commit y sin tocar `version`. Método por hallazgo: rojo observado (el repro del auditor
o un caso nuevo contra el `src/` del lote A) → verde → mutante aplicado en scratch y restaurado. **Los TRES repros del auditor
están ahora en ROJO sobre el árbol cerrado** (`env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec
.claude/reproducciones/loteA-run.ts` ⇒ 3 failed: A1 «expected false to be true» porque la receta por defecto ya no re-clava;
A2 «assertPartition acepta un alias» lanza; A3 el manager lanza 500 antes del `isUndefined`) y convertidos en casos invertidos
(A1 → `upgrade_recipe.spec` default; A2 → `relations_database.spec` A2 + tabla de verdad + pg `::uuid`; A3 → `relations.spec`
«HUECOS» + `manager.spec` F5).

### 🟠 A1 · la receta D4 resucitaba lo revocado ⇒ receta FAIL-CLOSED por defecto, `--rekey` opt-in

Arreglo: README §«Upgrading to 2.5.0: non-canonical partition spellings» con DOS bloques por motor: `-- D4 · <Motor>` =
**detector** (particiones no canónicas y cuántas tuplas), **listado** (cada fila que se va a borrar, con sujeto y caducidad)
y **DELETE**; `-- D4 · <Motor> · --rekey` = borrar la no canónica cuyo gemelo canónico existe (el gemelo NO se toca: la
caducidad nunca se alarga, `NULL` no gana, la lejana no gana) + re-clavar el resto con su `subject_partition`. La fusión
`CASE … NULL … GREATEST` desaparece. Ejecutado literal en pg/mysql/sqlite (`upgrade_recipe.spec`, grupo D4: «default» y
«--rekey», cada uno dos veces = idempotente); el escenario del auditor —fila sin guiones + `relate` canónico + `purgeSubject`
canónico ⇒ `false` ⇒ receta— afirma **`false` tras el default** (ROJO (A1) si vuelve a conceder) y `true` tras `--rekey` (la
decisión revisada, no el default). En `openfga` el default fail-closed es el delete con el SDK; el caso existente de
`relations_openfga.spec` queda como el equivalente de `--rekey` (título reescrito).
- (a) *Gemelos*: `openfga` ↔ `database`: no hay receta SQL en openfga (el store son las tuplas); el README dice las dos ramas
  para él (delete con el SDK = default; reconcile desde database + delete = `--rekey`). Roles: ~~no aplica~~ **SÍ aplica
  en la rama SIN cadena** (corregido en el cierre-2, 🟠 R1 del re-ataque: `scopeSpellings` solo expandía el alias sin
  guiones; con la fila viva la cadena canoniza, invariante 17). Comando ↔ receta: no hay comando (es SQL del
  operador, a propósito: el listado se revisa antes). **Y desde el cierre-2 la receta tiene TRES ramas** (🟡 R3): por
  defecto SOLO lectura, `--delete` y `--rekey`.
- (b) *Tabla de verdad* rama × fila (ejecutada en los tres motores):

| fila (partición no canónica) | default | `--rekey` |
|---|---|---|
| sola, sin gemelo canónico | BORRADA (el acceso NO vuelve) | re-clavada con su propia caducidad |
| con gemelo canónico, caduca más tarde que él | BORRADA | BORRADA; el gemelo conserva la CERCANA |
| sin caducidad, gemelo canónico con caducidad | BORRADA | BORRADA; el gemelo conserva su fecha (`NULL` no gana) |
| userset (`subject_partition` = clave vieja) | BORRADA | re-clavadas las dos columnas (el trigger lo exige) |
| 32 caracteres no hex / md5 con `_` (id legal) | intacta, no listada | intacta |
| escenario del auditor (purgada por la canónica) | sigue `false` | vuelve `true` (opt-in revisado) |

- (c) *Casos existentes rojos*: el caso D4 de `upgrade_recipe.spec` («fusiona … gana la caducidad más larga») se REESCRIBE
  en dos (default y `--rekey`): su expectativa «u1 vuelve a conceder» era el defecto; el repro A1 del auditor en rojo.
- (d) *Linaje*: no es iteración de ninguno de `linajes.md` (la receta nació en el lote A); propiedad universal escrita en
  README: «una fila que la purga canónica no veía es una concesión invisible: se borra, no se re-clava».

### 🟠 A2 · D4 cerraba solo «32 hex sin guiones» ⇒ 422 para TODO uuid no canónico

Arreglo: `isNonCanonicalUuid(v)` = «sin guiones es 32 hex Y no es exactamente 8-4-4-4-12» (`src/identity.ts`, exportada
desde la raíz); `assertPartition` la usa (mensaje: «guiones mal colocados» / «sin guiones», nombra la canónica y la receta);
el detector de la receta es la MISMA regla en SQL (`replace(uuid,'-','') ~ '^[0-9a-f]{32}$' AND uuid !~ '^8-4-4-4-12$'`, y
sus equivalentes `REGEXP`/`GLOB`), y `upgrade_recipe.spec` lo mide: para cada partición sembrada, `assertPartition` rechaza
⇔ el detector la lista. Medido en pg (caso A2, solo pg): `'<8-4-4-16>'::uuid = '<canónica>'::uuid`, ídem `8-8-8-8`,
`12-4-4-12` y sin guiones; 33 hex y 31 hex los rechaza PG y la regla los deja pasar (son ids legales).
- (a) *Gemelos*: manager ↔ drivers ↔ doble ↔ `reconcileRelations`: todos pasan por `assertPartition` (punto único del lote A,
  sin cambio); la guardia lo sondea en las 42 celdas con la sonda NUEVA `misdashed` (`8-4-4-16`) además de `dashless`. Roles:
  ~~no aplica (la cadena canoniza)~~ **SÍ aplica donde NO hay cadena** —`detached` de una fila borrada, `revoke`/`removeDeny`
  con cadena `null`—: `scopeSpellings` adopta `isNonCanonicalUuid` en el cierre-2 (🟠 R1). Receta ↔ API: misma regla, medida.
- (b) *Tabla de verdad de formas* (`relations_database.spec` «A2 · tabla de verdad», ejes: ¿32 hex sin guiones? × ¿forma
  exacta 8-4-4-4-12?):

| forma | 32 hex sin guiones | canónica | veredicto | PG `::uuid` |
|---|---|---|---|---|
| `8-4-4-4-12` | sí | sí | entra | = |
| 32 hex sin guiones (D4) | sí | no | 422 | funde |
| `8-4-4-16` (= sin el último guion) | sí | no | 422 | funde (medido) |
| `8-8-8-8` | sí | no | 422 | funde (medido) |
| `12-4-4-12` (sin el primer guion) | sí | no | 422 | funde (medido) |
| `4×8` (39 chars) | sí | no | 422 (ya por longitud 36) | — |
| guion inicial / final / doble guion | sí | no | 422 | — |
| 33 hex / 31 hex | no | — | entra (id legal) | rechaza |
| 32 chars no todos hex / md5 con `_` | no | — | entra (id legal) | — |
| id corto (`tenant-7`) | no | — | entra | — |

- (c) *Casos existentes rojos*: ninguno (los 42 `partition` de la guardia siguen verdes con la sonda vieja y ganan la nueva);
  el repro A2 del auditor en rojo. Guardia: 165/165; mutante NUEVO `identity.misdashed.A2` (vuelve a «solo sin guiones»):
  **42 rojos** medidos (⚪ R4: el texto decía 43 y la tabla 42; el gate con `--only` da 42); `identity.dashless.D4` reescrito a la forma nueva.
- (d) *Linaje*: L1 (F-05/partición canónica), misma propiedad universal que D4, punto de paso único intacto; entrada nueva
  en la guardia = la sonda `misdashed` + el mutante global.

### 🟡/⚪ (A3–A12), uno por línea

- **🟡 A3** huecos: `everyPositionBoolean` por índice en `RelationsManager.checkMany` y en `authorizeMany` de roles (gemelo);
  `describeManyAnswer`/`describeAnswer` nombran el HUECO. Casos: `relations.spec` (`new Array(3)`, un hueco en [1], un
  `undefined` explícito) y `manager.spec` F5 (`new Array(2)`, hueco en [0]). Mutantes (volver a `.some`) aplicados en cada
  manager: rojo en los dos.
- **🟡 A4** detalle de lo podado: `discard` empuja a `details` con `pruned: true` (`ReconcileSkip.pruned?`); el comando
  imprime «se BORRARÍA con --prune (motivo) kind: detalle» en dry-run y «BORRADO por --prune …» en la real, nivel `log`,
  nunca «sin migrar». Caso «A4 · resolutor medio ciego» (`reconcile.spec`, servidor real): la fila del tenant desaparece,
  dry-run+prune lista la asignación Y el deny con `kind`, la real los deja escritos, el tenant vivo no aparece; unitario de
  `reconcileLines` ampliado. Mutante (quitar el `details.push` de `discard`): rojo.
- **🟡 A5** reloj ligero: subpath `./testing/clock` → `build/src/testing/test_clock.js` (solo importa `src/clock.ts`), `/testing`
  lo re-exporta, README importa el ligero en `config/authorization.ts` (con la razón en una línea). Caso P5-4 (`clock.spec`):
  cierre transitivo de imports relativos = exactamente `clock.ts` + `test_clock.ts`, cero paquetes; control: `/testing` sí trae
  Japa; README afirmado. Mutante (un `import … '@japa/runner'` en `test_clock.ts`): rojo.
- **🟡 A6** CHANGELOG D4: la población nombrada (ids de tenant de 32 hex que no son uuid —`randomBytes(16).toString('hex')`,
  md5— quedan rechazados en relaciones; ids de objeto/sujeto no) y el porqué (indistinguibles de un uuid sin guiones).
- **🟡 A7** D13 directo incluye `membersOf` cuando `membersOfNative` y el driver lo trae (afirma 9 intentos, 8 sin nativo);
  CHANGELOG lista las nueve con `membersOf`. Corre en los 6 harnesses del runner (openfga nativo lo ejerce).
- **⚪ A8** hint de MySQL delante de `DISTINCT` en `checkMany`; caso solo-MySQL con 1 002 grupos anidados (`relations_database.spec`
  «A8»): `check` true y `checkMany` `[true,false]`, y el SQL afirmado. Mutante (hint detrás): **`ERROR 3636` ⇒ 503 medido**, rojo.
- **⚪ A9** `relationTupleKey`: `kind` OBLIGATORIO sin default (ausente/`null` ⇒ 422 «ausente»), objeto/relación/sujeto por
  `assertRelationId`/`assertSubject`; las dos formas que colapsaban del auditor ⇒ 422 (12 variantes en el spec); `reconcile.ts`
  pasa `kind: 'allow'` explícito (sigue `const tupleKey = relationTupleKey`, P3-4 verde). README/CHANGELOG: «kind is required».
- **⚪ A10** `alignBatchResults(driver, op, checks, results)` (export de `/openfga`): correlación + «error ⇒ 503»; ausente/duplicado/
  ajeno ⇒ 500 (coherente, declarado). Los dos drivers la usan; `openfga_driver.spec` lo afirma por comportamiento y por fuente
  (el de relaciones importa `alignBatchResults` y no tiene `r.error`; `find((r) => r.error)` aparece UNA vez).
- **⚪ A11** README (§Testing expiry) y CHANGELOG: el lease lo juzga el reloj del proceso que LEE la fila del freeze contra el
  `untilMs` del que congeló; un escritor adelantado > lease escribe dentro de la ventana; preexistente; NTP en todo proceso que escribe.
- **⚪ A12** `RelationsReconcileReport.allowMassDelete?` opcional (el comando lee `=== true`); D13 directo prueba 51 y `[]` ⇒ 422
  `E_AUTHZ_CHECK_MANY_BATCH` y el tope exacto responde.

### Guardia y manifiesto

`guard_manifest.ts`: comentarios de la columna `partition` y de `DASHLESS_PARTITION` reescritos (D4 + A2, dos sondas, dos
mutantes). `guard_surface.spec.ts`: variante `misdashed` (`MISDASHED` = `8-4-4-16` de `DASHLESS`), `NON_CANONICAL` recorre las
dos formas en las cuatro capas (manager con cero llamadas Y cero eventos; database cero sentencias; openfga cero llamadas;
doble). `guard_mutants.json`: 103 → **104** (`identity.misdashed.A2`; `identity.dashless.D4` con el `find` nuevo).

### Ficheros tocados en el cierre

`src/identity.ts` (`CANONICAL_UUID`, `isNonCanonicalUuid`, `assertPartition`), `index.ts` (export), `src/relations/manager.ts`
(A3), `src/manager.ts` (A3), `src/drivers/openfga_driver.ts` (A4 `discard`, A10 `alignBatchResults`),
`src/drivers/openfga_relations_driver.ts` (A10), `src/drivers/database_relations_driver.ts` (A8), `src/relations/tuple_key.ts`
(A9), `src/relations/reconcile.ts` (A9, A12), `src/types.ts` (`ReconcileSkip.pruned`), `src/openfga.ts` (export),
`src/testing/test_clock.ts` (docblock), `src/testing/relations_contract.ts` (D13: A7, A12), `commands/authz_reconcile.ts` (A4),
`package.json` (`./testing/clock`), `README.md` (D4, Upgrading 2.5.0 con 6 bloques, Testing expiry, A11), `CHANGELOG.md`,
`CLAUDE.md`, `tests/{upgrade_recipe,relations_database,relations,manager,reconcile,clock,relation_tuple_key,openfga_driver,
guard_surface,relations_openfga}.spec.ts`, `tests/fixtures/{guard_manifest.ts,guard_mutants.json}`, `.claude/contexto/linajes.md`.

### Cifras y gates (EN SECUENCIA, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite)

| Qué | Resultado |
|---|---|
| `tsc --noEmit` · `npm run typecheck` · `check:purity` · `build` | ✔ los cuatro (exit 0) |
| repro del auditor (`loteA-run.ts`, VERDE = defecto) | **3 failed / 3** (A1, A2, A3 en rojo sobre el árbol cerrado) |
| `npm test` (`:memory:` + OpenFGA) | **1663 / 1663** passed, 2 skipped (A8 solo-MySQL, A2-cast solo-PG); antes del cierre 1656 ⇒ +7 |
| `npm run test:sqlite-file` | **1691 / 1691**, 2 skipped |
| `npm run test:pg` | **1788 / 1788**, 1 skipped (A8) — incluye A2 medido con `::uuid` |
| `npm run test:mysql` | **1790 / 1790**, 1 skipped (A2-cast) — incluye A8 con 1 002 niveles |
| `check:guard-mutants` (`:memory:`) | **104 / 104 muertos**, 0 vivos, 0 sin casar (84 s); `identity.dashless.D4` 42 rojos, `identity.misdashed.A2` 42 rojos |
| `check:guard-mutants -- --db sqlite-file` | **104 / 104 muertos** (86 s) |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes (`--allow-drop-deny` D, `--prune-undeclared` C) (48,3 s) |
| `cutover-runbook` sqlite-file | **VERDE**: 2 verdes · 0 rojos · 0 saltados, 13,2 s (presupuesto 60 s) |
| `cutover-runbook` pg | **VERDE**: 15,2 s |
| Bases huérfanas (PG/MySQL) al terminar | 0 / 0 |

Desglose del +7 en `:memory:`: `reconcile.spec` +1 (A4 resolutor medio ciego), `clock.spec` +1 (P5-4), `relation_tuple_key.spec`
+1 (A9), `openfga_driver.spec` +1 (A10), `upgrade_recipe.spec` +1 (D4 en dos ramas: 1 → 2; el caso A2-cast cuenta como skipped
fuera de pg), `relations_database.spec` +2 (A2 tabla de verdad, A2 alias; A8 skipped fuera de MySQL). Los casos ampliados (A3 en
`relations.spec` y `manager.spec`, A7/A12 en D13 del runner, F-R1 lines, D13 title) no suman. Mutantes medidos a mano y restaurados:
A3 ×2 (`.some`), A4 (`discard` sin `details`), A5 (import de japa), A8 (hint tras `DISTINCT` ⇒ `ERROR 3636`), A2 sobre la guardia
(42 rojos en `guard_surface.spec`; ⚪ R4 corrige el 43); los globales D4/A2 los mide el gate.

**Queda fuera (declarado)**: dos ortografías no canónicas del MISMO tenant sin gemelo canónico chocan en el UNIQUE al re-clavar
(`--rekey` falla ruidoso; README lo dice: borrar una a mano); el default las borra las dos. `openfga` no tiene detector de tuplas
no canónicas (ya declarado en ⚪ A12 del auditor): el README da las dos ramas con el SDK. `RelationTuple` sigue sin `kind` (llega
con el deny del lote D); mientras, `reconcileRelations` casa todo como `allow` de forma explícita.


## Cierre-2 (re-ataque del auditor) — 2026-10-15 (`loteA-auditor-cierre.md`: 1 🟠, 1 🟡, 2 ⚪; decisiones del dueño §2026-10-15 (2))

Mismo árbol `main` sobre `645af34`, sin commit y sin tocar `version`; único agente que lo muta. Método por hallazgo: rojo observado
(el repro del auditor, o el caso nuevo contra el `src/` del cierre-1) → verde → mutante aplicado en una COPIA en el scratchpad
(`node_modules` enlazado, como hace el corredor de la guardia) y medido. **Los DOS repros del auditor están en ROJO sobre el
árbol cerrado** (`env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec .claude/reproducciones/loteA-cierre-run.ts`
⇒ **2 failed / 2**: R1 «expected […(4)] to not include 'purgeScope unit:<canónica>'» —la canónica SÍ se purga—; R2 «expected
undefined to exist» —la basura ya no lanza—) y convertidos en casos invertidos (R1 → `scope_outbox.spec` 3b-2h · 🟠 3 «🟠 R1» +
el caso contra el servidor real + `openfga_facts.spec` A4; R2 → `relations_reconcile.spec` grupo «⚪ R2», tres casos).

### 🟠 R1 · el gemelo de A2 en ROLES: `scopeSpellings` adopta `isNonCanonicalUuid`

El cierre-1 escribió «Roles: no aplica (invariante 17 canoniza por la cadena)» en las líneas (a) de A1 y de A2, y era falso
justo en la rama SIN cadena: `scopeSpellings` (`src/identity.ts`) solo expandía el alias de 32 hex sin guiones (lo que 3b-2h
cerró para el 🟠 3), así que con `8-4-4-16` —que PG funde con la canónica, medido en A2— `scopes.detached` de una fila ya
borrada (`manager.ts:1123`) y el fan-out de `revoke`/`removeDeny` con cadena `null` (`canonicalScopeTargets`,
`backend_guard.ts`) purgaban/borraban una clave sin hechos y la canónica sobrevivía: en `facts` el scope concedía para
siempre; en `database` resucitaba al restaurar el uuid (invariante 11).
Arreglo: `scopeSpellings` usa `isNonCanonicalUuid` —la MISMA función que `assertPartition`— y añade la canónica
(`dashedUuid(uuid sin guiones)`) para TODA ortografía no canónica; una sola línea de código, docblock reescrito. Sin cambio en
`manager.ts` ni en `backend_guard.ts` (ya pasaban por `scopeSpellings`: el punto de paso único era el bueno, la regla era la
estrecha).
- (a) *Gemelos*: roles ↔ relaciones: **la regla es ahora UNA** (`isNonCanonicalUuid`) en los dos puertos; manager (`detached`)
  ↔ drivers (`revoke`/`removeDeny` en `database` y `openfga`, vía `canonicalScopeTargets`): el mismo `scopeSpellings`, casos en
  los dos (A4 ampliado recorre `[sql, fga]` × `[sin guiones, 8-4-4-16]`); outbox ↔ directo: por la outbox viajan las dos
  ortografías también para `8-4-4-16` (caso ampliado). `relay`/`requeue`: no aplica (relevan lo encolado; la decisión se toma al
  encolar, que es donde está la información, y el caso lo afirma).
- (b) *Tabla de verdad* forma × cadena (ejecutada en `scope_outbox.spec` «🟠 R1», `:memory:`; la fila `facts` contra `:8090`):

| ortografía del llamante | `isNonCanonicalUuid` | con cadena (fila viva) | sin cadena (fila borrada) | `facts`, sin cadena |
|---|---|---|---|---|
| canónica `8-4-4-4-12` | no | 1 purga: `chain[0]` | 1 purga: la del llamante | deja de conceder (3b-2h) |
| 32 hex sin guiones | sí | 1 purga: `chain[0]` | 2 purgas: alias + canónica (3b-2h) | deja de conceder (3b-2h) |
| `8-4-4-16` (sonda `misdashed`) | sí | 1 purga: `chain[0]` | **2 purgas** (antes: 1, la canónica viva) | **deja de conceder** (antes: para siempre) |
| `8-8-8-8` | sí | 1 purga | 2 purgas | — (mismo mecanismo) |
| `12-4-4-12` (sin el primer guion) | sí | 1 purga | 2 purgas | — |
| 32 caracteres NO hex (id legal) | no | 1 purga | 1 purga (no es alias de nada: el caso normal no paga) | — |
| mayúsculas | — | 422 `assertScope` antes de llegar | 422 | 422 |

- (c) *Casos existentes que el arreglo puso rojos*: **ninguno** (los de 3b-2h siguen afirmando lo mismo para el sin guiones; el
  caso «un uuid que no es un alias de nada sigue siendo UNA purga» sigue verde porque `isNonCanonicalUuid` no toca un uuid
  canónico ni un id legal). Mutante (volver a `DASHLESS_UUID.test` en `scopeSpellings`): **`scope_outbox.spec` 3 rojos en
  `:memory:` y 4 contra el servidor** (el caso `facts` «bajo la identidad REAL quedaban `parent` y `binding`» / «concedía para
  siempre»), **`openfga_facts.spec` A4 rojo** («8-4-4-16 · database: el revoke por alias … no-op silencioso»).
- (d) *Linaje*: L1 (F-05/partición canónica), gemelo en roles de la propiedad universal de A2: «toda ortografía que un motor
  funde con la canónica cuenta como alias de ella, en los DOS puertos, con UNA función». `linajes.md` actualizado; «Roles: no
  aplica» corregido en este informe (A1 (a), A2 (a)), en CLAUDE.md (invariante 17 y estructura de `src/`) y en el README (el
  párrafo de `openfga` de §Upgrading: «Roles are not affected» → «Roles have nothing to migrate but do have the same rule»).

### 🟡 R3 · la receta D4 con TRES ramas; la de por defecto NO escribe

La receta del cierre-1 tenía el DELETE como rama por defecto y el README decía «un id que no es un uuid queda intacto»: para la
población que 🟡 A6 nombra —ids de tenant de 32 hex que NUNCA fueron uuid— el detector lista TODAS sus particiones y el
default le vaciaba `authz_relations`.
Arreglo (README §«Upgrading to 2.5.0», bloques `-- D4 · <Motor>` / `· --delete` / `· --rekey` en pg, mysql y sqlite): **por
defecto SOLO lectura** = detector + listado + **conteos** (`with-canonical-twin` / `without-twin`, con el MISMO predicado de
gemelo que el paso 1 de `--rekey`, así el conteo dice exactamente qué haría `--rekey` con cada fila); **`--delete`** = el DELETE
fail-closed (población A: uuids escritos con otra ortografía, alias invisibles a la purga canónica); **`--rekey`** = borrar la no
canónica con gemelo + re-clavar el resto (población B: 32 hex por construcción; firma: «el detector lista todas tus
particiones»). El README nombra las DOS poblaciones, cuál rama es la suya, y que `--delete` sobre la B vacía la tabla
(pinado). `upgrade_recipe.spec`: `d4Recipe('default' | 'delete' | 'rekey')`; el caso del escenario del auditor afirma que las
tres sentencias del default empiezan por `SELECT`, los conteos `{ with-canonical-twin: 3, without-twin: 1 }`, y que el CENSO de
la tabla antes y después de correr la rama entera es IDÉNTICO (byte a byte); caso NUEVO «población B»: dos tenants
`randomBytes(16).toString('hex')` con 4 filas (userset incluido), detector = todas sus particiones, conteos `without-twin: 4`,
default sin escribir, `--delete` ⇒ 0 filas (la frase del README), re-sembrado + `--rekey` ⇒ 4 filas bajo `unit|<8-4-4-4-12>`,
`subject_partition` del userset re-clavado, `check` por el id con guiones `true` ×3 y por los 32 hex a secas 422.
- (a) *Gemelos*: pg ↔ mysql ↔ sqlite: los tres bloques ejecutados literal (el conteo usa `GROUP BY 1` y una subconsulta
  correlacionada, válidos en los tres; en SQLite el `SELECT` admite alias `d`, cosa que el `DELETE` no). `openfga`: el párrafo
  del README dice las mismas tres ramas con el SDK (listar = `read({})`; `--delete` = `write({ deletes })`; `--rekey` =
  reconcile desde `database` + delete) y el caso de `relations_openfga.spec` «D4 · receta» cambia de título (sigue siendo el
  equivalente de `--rekey`). Comando ↔ receta: sigue sin comando, a propósito. Roles: nada que migrar (R1 dice la regla).
- (b) *Tabla de verdad* rama × población (ejecutada en los tres motores):

| población | detector | conteos | default | `--delete` | `--rekey` |
|---|---|---|---|---|---|
| A · uuid con otra ortografía, SIN gemelo (purgado por la canónica, escenario A1) | la lista | `without-twin` | **0 escrituras** | borrada: sigue `false` | re-clavada: vuelve `true` (decisión revisada) |
| A · con gemelo canónico | la lista | `with-canonical-twin` | 0 escrituras | borrada; el gemelo intacto | borrada; el gemelo conserva su caducidad (`NULL` no gana, la lejana no gana) |
| B · 32 hex por construcción (todas sus particiones) | **todas** | `without-twin` | 0 escrituras | **tabla vacía** (pinado) | **todo conservado** bajo 8-4-4-4-12, userset incluido |
| id legal (31/33 hex, no-hex, `_`) | no | — | — | intacta | intacta |

- (c) *Casos existentes rojos*: el caso «default (fail-closed)» de `upgrade_recipe.spec` se REESCRIBE (ahora afirma solo
  lectura + conteos + censo idéntico, y corre `--delete` después); el `--rekey` no cambia. Mutantes medidos (copia en scratch,
  SQLite): el bloque default con el DELETE añadido ⇒ **2 rojos** («la rama por defecto solo lee» + población B); el `--rekey`
  sin el re-clavado de `subject_partition` ⇒ **2 rojos** (población B «perdió relaciones» + el caso `--rekey` existente).
- (d) *Linaje*: L8 (letra ≠ efecto), 10.ª iteración: el README decía «intacto» de una población que el default borraba;
  propiedad universal: «ninguna rama de una receta escribe sin su sentencia explícita, y la rama por defecto es de lectura».

### ⚪ R2 · una tupla ENUMERADA fuera de la gramática ⇒ `extra` con motivo, nunca 422

`planPartition` (`src/relations/reconcile.ts`) aplicaba `tupleKey` (= `relationTupleKey`, que desde ⚪ A9 valida cada
componente) a las tuplas enumeradas del destino: `document:<key>|ABC` escrita a mano ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` toda la
pasada, también `--dry-run --prune`, y nadie la barría.
Arreglo: `enumeratedKey` (captura SOLO `InvalidIdentityError`, lo demás relanza) + `describeTuple` (línea legible sin validar);
destino ⇒ `toDelete` + detalle `{ side: 'destino', reason: 'invalid-identity', tuple, message, pruned? }`; origen ⇒
`skipped.invalid` (campo opcional nuevo) + detalle `side: 'origen'`. Con `--prune` la pasada real se la pide al driver **tal
como la enumeró**; si el driver la rechaza por el puerto con un 422 (R-16 en `unrelate`: los DOS drivers del paquete lo hacen,
el doble no), `pruned: false`, vuelve a `extra`, y el comando imprime «NO se pudo borrar con --prune … bórrala a mano
(SQL/SDK)» con exit 1 — nunca un throw a mitad de pasada por un dato ajeno. `report.details?: RelationsReconcileDetail[]`
(exportado desde la raíz, opcional como `allowMassDelete` ⚪ A12). `relationsReconcileLines`: una línea por tupla (origen ⇒
error/deriva; destino sin prune ⇒ warning «sobra … repite con --prune»; dry-run + prune ⇒ «se pedirá al driver del destino que
la BORRE … si la rechaza por el puerto, la pasada real lo dirá»; real `pruned: true` ⇒ «BORRADA por --prune»; `pruned: false`
⇒ error); `clean` exige `skipped.invalid = 0` y ninguna rechazada; el resumen añade «fuera de la gramática en el origen N».
**Decisión de mecanismo, declarada**: NO se relaja la gramática de `unrelate` en los drivers reales (sería un cambio del
contrato del driver llamado en directo, fuera de la letra de la decisión); con `database`/`openfga` la pasada LISTA la tupla
con su línea exacta y exit 1 hasta que se borre a mano — la misma doctrina que D4 da a las particiones no canónicas de
`openfga` («the package cannot address it: delete it with the SDK»). Pregunta abierta para el dueño al final.
- (a) *Gemelos*: origen ↔ destino: los dos lados clasificados (el origen también enumeraba basura por el mismo camino);
  `authz:reconcile` de roles: no aplica (sus hechos se parsean desde el id del store y lo no parseable ya cuenta en
  `diagnostics.unparseableBindings`/`leftovers`, 2.2); doble ↔ `database`: casos con los dos (el doble borra; `database` rechaza
  y se dice); `openfga`: mismo camino que `database` (`#objectId` ⇒ `assertRelationId` en `unrelate`), no se añadió caso con
  servidor (el mecanismo es el `catch` del 422, medido con `database`).
- (b) *Tabla de verdad* lado × prune × dryRun × respuesta del driver (`relations_reconcile_cli.spec` «⚪ R2», 5 filas, +
  `relations_reconcile.spec` con driver real):

| lado | prune | dryRun | driver | contador | `pruned` | línea | nivel | `clean` |
|---|---|---|---|---|---|---|---|---|
| destino | no | * | — | `extra` | — | «sobra (invalid-identity) destino: … repite con --prune» | warning | sí (el operador eligió no podar) |
| destino | sí | sí | — | `deleted` | `true` | «se pedirá al driver del destino que la BORRE … si la rechaza … lo dirá» | log | no (haría algo) |
| destino | sí | no | borra (doble) | `deleted` | `true` | «BORRADA por --prune …» | log | sí |
| destino | sí | no | 422 (`database`/`openfga`) | `extra` | `false` | «NO se pudo borrar con --prune … a mano» | error | **no** |
| origen | * | * | — | `skipped.invalid` | — | «sin migrar (invalid-identity) origen: … a mano» | error | **no** |

- (c) *Casos existentes rojos*: ninguno (`relations_reconcile_cli.spec` construye reportes sin `details`/`skipped.invalid` y
  siguen compilando y limpios: caso de control). Mutantes: `enumeratedKey` relanzando ⇒ **3 rojos** en `relations_reconcile`;
  el comando sin el bucle de `details` ⇒ **1 rojo** en `relations_reconcile_cli`.
- (d) *Linaje*: L8, 9.ª iteración («una operación destructiva lista lo que destruye», ahora también lo que NO pudo destruir y
  por qué). Invariante 5 por fuente: el único `throw` de 422 que sale de `reconcileRelations` por un dato enumerado ya no existe.

### ⚪ R4 · letra

- `--rekey` (README): «delete one of them by hand first» → «keep the row with the nearest expiry (a `NULL` expiry is the
  farthest) and delete the other one, so the re-keyed tuple never outlives what either row already granted»; y la atomicidad
  del UPDATE («nothing is re-keyed, for any tenant, until the statement succeeds») escrita.
- Conteos: «43 rojos» (texto de A2 (c) y del desglose) → **42** en este informe y en CLAUDE.md (fila `tests/`); el gate con
  `--only` da 42.

### Guardia y manifiesto

Sin fila nueva (no hay operación nueva). `guard_mutants.json`: las 18 notas de las celdas `partition` de los drivers que
decían «en purgas/enumeraciones también `scopeSpellings`» (rancias desde D4) reescritas: `partitionKey/scopeKey`; «desde D4
ningún driver de relaciones barre ortografías — `scopeSpellings` es solo de roles, misma regla `isNonCanonicalUuid` desde el
cierre-2». Los `find` de los 104 mutantes no cambian (`isNonCanonicalUuid`/`partitionKey` intactos); `identity.misdashed.A2`
sigue matando sus 42 celdas (y, como `scopeSpellings` ahora comparte la función, ese mutante pondría rojos además los casos
R1 de roles — fuera del spec de la guardia, que es el único que el corredor mira).

### Ficheros tocados en el cierre-2

`src/identity.ts` (`scopeSpellings` + docblocks), `src/relations/reconcile.ts` (`RelationsReconcileDetail`, `details`,
`skipped.invalid`, `enumeratedKey`, `describeTuple`, poda con `catch` del 422), `commands/authz_relations_reconcile.ts`
(líneas R2, `clean`, resumen), `index.ts` (export del tipo), `README.md` (§Upgrading: tres ramas, dos poblaciones, R4, párrafo
de `openfga` y de roles), `CHANGELOG.md` (D4 tres ramas; bloque «Re-audit of the closure» R1–R4), `CLAUDE.md` (invariante 17,
estructura `src/`, fila `tests/` 43→42, fila de `reconcile.ts` R2), `tests/{scope_outbox,openfga_facts,relations_reconcile,
relations_reconcile_cli,upgrade_recipe,relations_openfga}.spec.ts`, `tests/fixtures/guard_mutants.json` (notas),
`.claude/contexto/linajes.md`, este informe (A1 (a), A2 (a), 43→42 y esta sección). Sin tocar: `version`, manifiesto de la
guardia, drivers de relaciones.

### Cifras y gates (EN SECUENCIA, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite)

| Qué | Resultado |
|---|---|
| `tsc --noEmit` · `npm run typecheck` · `check:purity` · `build` | ✔ los cuatro (exit 0) |
| repro del auditor (`loteA-cierre-run.ts`, VERDE = defecto) | **2 failed / 2** (R1, R2 en rojo sobre el árbol cerrado) |
| `npm test` (`:memory:` + OpenFGA) | **1670 / 1670** passed, 2 skipped (A8 solo-MySQL, A2-cast solo-PG); antes del cierre-2 1663 ⇒ **+7** (86 s) |
| `npm run test:sqlite-file` | **1698 / 1698**, 2 skipped (97 s) |
| `npm run test:pg` | **1795 / 1795**, 1 skipped (A8) (144 s) |
| `npm run test:mysql` | **1797 / 1797**, 1 skipped (A2-cast) (156 s) |
| `check:guard-mutants` (`:memory:`) | **104 / 104 muertos**, 0 vivos, 0 sin casar (85 s); `identity.dashless.D4` 42 rojos, `identity.misdashed.A2` 42 rojos |
| `check:guard-mutants -- --db sqlite-file` | **104 / 104 muertos** (85 s) |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes (`--allow-drop-deny` D, `--prune-undeclared` C) (51,7 s) |
| `cutover-runbook` sqlite-file | **VERDE**: 2 verdes · 0 rojos · 0 saltados, 12,9 s (presupuesto 60 s) |
| `cutover-runbook` pg | **VERDE**: 16,4 s |
| Bases huérfanas (PG/MySQL) al terminar | 0 / 0 |

Desglose del +7 (igual en los cuatro modos): `scope_outbox.spec` **+2** («🟠 R1» tabla de formas en `:memory:`; «🟠 R1» contra el
servidor real en el grupo 3b-2h de `facts`), `relations_reconcile.spec` **+3** (R2: doble, fila a mano en `database`, origen),
`relations_reconcile_cli.spec` **+1** (R2 letra × 5 filas), `upgrade_recipe.spec` **+1** (población B; el caso default/--delete
reescrito no suma). `openfga_facts.spec` A4 ampliado (×2 formas) no suma. Mutantes medidos a mano en copia y restaurados: R1
(`scopeSpellings` a «solo sin guiones»): 3 rojos en `:memory:`, 4 contra OpenFGA + A4 rojo; R2 planificador (`enumeratedKey`
relanza): 3 rojos; R2 letra (sin bucle de `details`): 1 rojo; R3 default con DELETE: 2 rojos; R3 `--rekey` sin `subject_partition`:
2 rojos. Los globales D4/A2 los mide el gate (42 y 42).

**Queda fuera (declarado) y pregunta abierta para el dueño**: (1) con los dos drivers reales `--prune` NO borra una tupla
fuera de la gramática —sus `unrelate` aplican R-16 y la pasada lo dice con la línea exacta y exit 1 (a mano)—; la letra de la
decisión R2 («`--prune` la borra») se cumple en el puerto y en el doble, y en los drivers del paquete se cumple «la pide y dice
si no pudo». Relajar la gramática del id en el DELETE de los drivers reales («lo que el driver enumera, su `unrelate` lo borra»:
quitar nunca concede) haría que `--prune` la borre también ahí; es un cambio del contrato del driver llamado en directo y se
deja a decisión del dueño, no se hace en un cierre-2. (2) En `openfga` no hay detector SQL: las tres ramas van con el SDK
(README). (3) `skipped.invalid` y `details` son opcionales en el tipo: un reporte de terceros anterior compila; el comando lee
`?? 0` / `?? []`.

## Cierre-3 (repaso del cierre-2) — 2026-10-15 (`loteA-auditor-cierre2.md`: 0 🔴/🟠, 1 🟡 ampliado, 2 ⚪; decisiones del dueño §2026-10-15 (3))

Mismo árbol `main` sobre `645af34`, sin commit y sin tocar `version`; único agente que lo muta. Método: el repro del auditor
(`loteA-cierre2-reataque.spec.ts`, VERDE = defecto/hecho presente; **5/5 verdes sobre el árbol del cierre-2**) → arreglo →
**2 passed / 3 failed sobre el árbol cerrado** (C2-1 «arrastra la canónica», C2-2 «se purgan los hechos de un scope VIVO ajeno»
y C2-3 «quitar un deny de `-<hex>` quita el deny del scope vivo» en ROJO; el control y ⚪ C2-4 siguen verdes) → casos
invertidos en `tests/` → mutantes medidos en una COPIA en el scratchpad (`node_modules` enlazado) y restaurados.

### 🟡 C2-1/C2-2/C2-3 · dos reglas por propósito + descarte estructural de lo VIVO

**(1) Dos reglas con nombre** (`src/identity.ts`). `pgFusedSpellings(uuid): string[]` = la canónica con la que el tipo `uuid`
de PostgreSQL funde ESA ortografía, o `[]`; regex `/^([0-9a-f]{4}-?){7}[0-9a-f]{4}$/` = guiones únicamente detrás de grupos de
cuatro (la letra de la doc de PG, `datatype-uuid.html`: «adding a hyphen after any group of four digits»), **medida contra
PostgreSQL 18** (`select '<forma>'::uuid`): funde canónica, 32 hex, `8-4-4-16`, `8-8-8-8`, `12-4-4-12`, `8-24`, `4×8` (39);
rechaza `-<32hex>`, `<32hex>-`, `a0e-ebc99…`, `8--24` («invalid input syntax for type uuid»). La usa `scopeSpellings`
(roles). `isNonCanonicalUuid` (ancha: «32 hex sin guiones y no 8-4-4-4-12») se queda SOLO en `assertPartition` (422 de
particiones de relaciones), con docblock que dice que es un superconjunto y por qué ahí es inocuo. La letra «UNA función en
los dos puertos» del cierre-2 se corrige a «UNA regla por PROPÓSITO» (fundir ↔ rechazar), que es la decisión (3)(1).
**(2) Estructural** (`src/shared/backend_guard.ts` · `canonicalScopeTargets`, único punto de paso del fan-out sin cadena): con
cadena ⇒ `[chain[0]]`; sin resolutor ⇒ el fan-out entero (solo existe la raíz, nada puede estar vivo); sin cadena ⇒ la del
llamante + cada alias de `scopeSpellings` **contrastado con el resolutor: si resuelve (VIVO) se descarta**; si el resolutor
lanza ⇒ 503 `E_AUTHZ_RESOLVER_FAILED` y el driver no recibe nada. `manager.scopes.detached` deja de componer
`resolveChain` + `scopeSpellings` a mano y pasa por `canonicalScopeTargets` (import de `scopeSpellings` fuera del manager:
`grep -c scopeSpellings src/manager.ts` = 1, el comentario). `revoke`/`removeDeny` de los dos drivers ya pasaban por ahí.
- (a) *Gemelos*: **manager (`detached`) ↔ drivers (`revoke`/`removeDeny` en `database` y `openfga`)**: la MISMA función,
  casos en los tres (espía + `openfga_facts.spec` «cierre-3» recorre `[sql, fga]` × `[32 hex, 8-4-4-16]` por las tres
  operaciones). **¿Relaciones tiene fan-out sin cadena?** No: el puerto de relaciones no canoniza por cadena (`partitionKey`
  compara byte a byte y rechaza con 422 lo no canónico, D4); no hay ortografías que barrer ⇒ no aplica, y la guardia de
  superficie lo fija (18 notas de `guard_mutants.json` reescritas: «scopeSpellings es solo de roles y desde el cierre-3 tiene
  regla PROPIA»). **¿`purgeScope` directo (`manager.driver().purgeScope`)?** No hace fan-out: los dos drivers usan
  `canonicalOrSelf` (singular: la fila si resuelve, la ortografía del llamante tal cual si no) y `onScopeDetached` de `openfga`
  igual (`openfga_driver.ts:1702`) — la salida documentada de las barreras purga EXACTAMENTE lo que se le pide, nunca de más;
  el fan-out es del manager y del delete de hechos. **Outbox ↔ directo**: la decisión se toma al encolar (`targets` antes del
  `enqueue`), así que por la cola viaja una fila por ortografía SUPERVIVIENTE; `relay`/`requeue` no aplica (relevan lo
  encolado). **`isWithin`/`within`**: no cambia (con `within` el hijo tiene que resolver: hay cadena, un solo destino).
- (b) *Tabla de verdad* forma × motor × estado de la canónica (ejecutada: columnas `422`/`funde` en `relations_database.spec`
  «A2/C2-1» en los 4 modos; filas sin cadena en `scope_outbox.spec` «R1/C2-1» y «C2-2» con espía; las dos filas PG × víctima
  viva contra `database` y `facts` `:8090` en `openfga_facts.spec` «cierre-3»):

| ortografía del llamante | `isNonCanonicalUuid` (422 partición) | PG la funde (`pgFusedSpellings`) | sin cadena, canónica BORRADA | sin cadena, canónica VIVA (otro scope) | resolutor falla al contrastar |
|---|---|---|---|---|---|
| canónica `8-4-4-4-12` | no | — (ya es canónica) | 1 purga | 1 purga | no se contrasta nada |
| 32 hex sin guiones | sí | **sí** | 2 purgas (3b-2h) | **1 purga: la víctima intacta** (antes: 2, fail-open `database` / DoS `facts`) | **503, 0 purgas** |
| `8-4-4-16` · `8-8-8-8` · `12-4-4-12` · `8-24` | sí | **sí** | 2 purgas (cierre-2 · R1) | **1 purga** | 503, 0 purgas |
| `-<32hex>` · `<32hex>-` · `a0e-…` · `8--24` | sí | **NO** (medido) | **1 purga** (antes del cierre-3: 2) | 1 purga | — (no hay alias que contrastar) |
| `4×8` (39 caracteres) | sí | sí (PG) | 422 `assertScope` ANTES (⚪ C2-4, visible) | 422 | 422 |
| 31/33 hex, 32 no-hex, `_`, id corto | no | no | 1 purga | 1 purga | — |
| mayúsculas | — | — | 422 `assertScope` | 422 | 422 |

- (c) *Casos existentes que el arreglo puso rojos*: **ninguno** por el arreglo; dos casos se REESCRIBEN por su letra: la tabla
  A2 de `relations_database.spec` (gana la columna `funde` + 2 filas: `8-24`, `a0e-…`) y el «🟠 R1» de `scope_outbox.spec`
  (su aserción `isNonCanonicalUuid(alias) === (purges === 2)` pasa a `pgFusedSpellings(alias).length === purges − 1` y gana 4
  filas no-PG con `purges === 1`). Los casos 3b-2h/R1 contra el servidor (`:8090`) no cambian (la canónica está BORRADA: se
  sigue purgando). **Mutantes** (copia en scratch, `:memory:` + `:8090`, los tres specs): **M1** «usar la ancha en roles»
  (`scopeSpellings` sobre `isNonCanonicalUuid`) ⇒ **2 rojos** (`relations_database.spec` «A2/C2-1» —columna `funde` de `-<hex>`/`<hex>-`/`a0e-…`/`8--24`— y `scope_outbox.spec` «R1/C2-1» —las cuatro filas no-PG purgan 2—; 328 verdes del resto); **M2** «sin contraste con el resolutor» (`targets.push(alias)` a
  secas) ⇒ **3 rojos** (`openfga_facts.spec` «cierre-3» —`32 hex · database: … se llevó el deny de la víctima VIVA`, es decir fail-open medido en `database` y el gemelo en `facts`—, `scope_outbox.spec` «C2-2 · la canónica VIVA no se purga» y «C2-2 · resolutor falla ⇒ 503» —`expected undefined to equal 503`: sin contraste el detached pasa y purga—; 327 verdes del resto). Y desde el cierre-3 el mutante global `identity.misdashed.A2` de la guardia ya NO alcanza a roles
  (reglas separadas): sigue matando sus 42 celdas `partition` y nada más, como mide el gate.
- (d) *Linaje*: L1/`partition` × roles, rama «fan-out sin cadena»: 3b-2h (32 hex) → cierre-2 (toda colocación) → **cierre-3
  (scope vivo ajeno)** = 3.ª iteración ⇒ **estructural, no parche**: propiedad universal «nunca se purga un scope VIVO que no
  es el pedido», punto de paso único `canonicalScopeTargets` (manager + dos drivers), regla de fusión con nombre y tabla de
  verdad; `linajes.md` actualizado. Lo que queda fuera de la guardia de superficie (declarado): el fan-out de roles no está en
  el manifiesto L1 (es de relaciones); su mutante se mide a mano en este informe, como en el cierre-2.

### ⚪ C2-4 · formas > 36 caracteres

Docblock en `pgFusedSpellings`: PG funde también `4×8` (39, el ejemplo literal de su doc), pero `IDENTITY_LIMITS.uuid = 36`
(columna publicada) y `assertScope` la rechaza ANTES del fan-out con 422 `E_AUTHZ_INVALID_IDENTITY`, ruidoso y visible; «el
conjunto de este fan-out es lo que PG funde Y cabe en 36». Fila `4×8` de la tabla A2/C2-1: `pgFusedSpellings` dice que funde
(verdad de PG) y `scopeSpellings` es 422 (verdad del paquete). Sin cambio de código. No hay guardia de docs sobre docblocks.

### ⚪ docblocks falsos

«esas son TODAS las formas que el tipo `uuid` de PostgreSQL funde» (`scopeSpellings`, falso en los dos sentidos) → la regla
`pgFusedSpellings`, con la historia 3b-2h → cierre-2 → cierre-3; «Quitar nunca concede, así que borrar de más no existe aquí»
(`canonicalScopeTargets`) → «era FALSO en dos sitios: quitar un DENY concede (`removeDeny`), y `purgeScope` en `database` borra
también `authz_denies`… por eso se descarta lo vivo». `isNonCanonicalUuid`: «son las formas que PG FUNDE» → «regla ANCHA,
superconjunto, solo para el 422». Mismo cambio de letra en CLAUDE.md (invariante 17; estructura de `src/`) y en el README
(§Upgrading, párrafo de roles: `pgFusedSpellings`, «narrower than the partition rule», «a live scope is never purged by that
fan-out», «never purge just in case»).

### ⚪ R2 · letra del dry-run

`commands/authz_relations_reconcile.ts` (dry-run + prune + `invalid-identity` en el destino): «si la rechaza por el puerto, la
pasada real lo dirá y se borra a mano» → «OJO: con los drivers del paquete (database/openfga) la pasada real NO la borrará (su
gramática en unrelate la rechaza, R-16) y saldrá con exit 1 hasta que la borres a mano (SQL/SDK): bórrala ya, no esperes a la
pasada real». Caso de letra en `relations_reconcile_cli.spec` «⚪ R2» (match positivo + `notMatch(/la pasada real lo dirá/)`).
Gemelo `authz:reconcile` (roles): no aplica (lo no parseable va a `diagnostics`, 2.2; no hay rama «se pedirá al driver»).

### Guardia y manifiesto

Sin fila nueva. `guard_mutants.json`: solo las 18 NOTAS (texto) de las celdas `partition` de los drivers; ningún `find` cambia
(`identity.misdashed.A2` sigue casando `return DASHLESS_UUID.test(value.replace(/-/g, '')) && !CANONICAL_UUID.test(value)`
exactamente una vez: la regla nueva vive en otra constante, `PG_FUSED_UUID`). `index.ts` exporta `pgFusedSpellings`.

### Ficheros tocados en el cierre-3

`src/identity.ts` (`PG_FUSED_UUID`, `pgFusedSpellings`, `scopeSpellings`, docblocks de `isNonCanonicalUuid`/`assertPartition`),
`src/shared/backend_guard.ts` (`canonicalScopeTargets` + docblock), `src/manager.ts` (`detached` por `canonicalScopeTargets`;
fuera el import de `scopeSpellings`), `index.ts`, `commands/authz_relations_reconcile.ts` (letra R2), `tests/{relations_database,
scope_outbox,openfga_facts,relations_reconcile_cli}.spec.ts`, `tests/fixtures/guard_mutants.json` (18 notas), `README.md`,
`CHANGELOG.md` (bloque «Re-audit of cierre-2 … cierre-3»), `CLAUDE.md`, `.claude/contexto/linajes.md`, este informe. Sin tocar:
`version`, manifiesto de la guardia, drivers de relaciones, el repro del auditor (queda como está: 2/3 sobre el árbol cerrado).

### Cifras y gates (EN SECUENCIA, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite)

| Qué | Resultado |
|---|---|
| `tsc --noEmit` · `npm run typecheck` · `check:purity` · `build` | ✔ los cuatro (exit 0) |
| repro del auditor (`loteA-cierre2-run.ts`, VERDE = defecto/hecho) | **2 passed / 3 failed** (C2-1, C2-2, C2-3 en rojo sobre el árbol cerrado; control y ⚪ C2-4 verdes) |
| `npm test` (`:memory:` + OpenFGA `:8090`) | **1673 / 1673** passed, 2 skipped; antes del cierre-3 1670 ⇒ **+3** (86 s) |
| `npm run test:sqlite-file` | **1701 / 1701**, 2 skipped (97 s) |
| `npm run test:pg` | **1798 / 1798**, 1 skipped (142 s) |
| `npm run test:mysql` | **1800 / 1800**, 1 skipped (148 s) |
| `check:guard-mutants` (`:memory:`) | **104 / 104 muertos**, 0 vivos, 0 sin casar (86 s); `identity.dashless.D4` 42 rojos, `identity.misdashed.A2` 42 rojos |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes (50,5 s) |
| `cutover-runbook` sqlite-file | **VERDE**: 2 verdes · 0 rojos · 0 saltados, 13,7 s (presupuesto 60 s) |
| `cutover-runbook` pg | **VERDE**: 16,1 s |
| Bases huérfanas (PG/MySQL) al terminar | 0 / 0 |

Desglose del +3 (igual en los cuatro modos): `scope_outbox.spec` **+2** («C2-2 · la canónica VIVA no se purga», «C2-2 · resolutor
falla ⇒ 503»), `openfga_facts.spec` **+1** («cierre-3 · C2-2/C2-3» contra `database` y `facts`, solo con `OPENFGA_TEST_URL`,
como el resto del grupo 3b-8). Reescritos sin sumar: tabla A2/C2-1 (`relations_database.spec`), R1/C2-1 (`scope_outbox.spec`),
letra R2 (`relations_reconcile_cli.spec`). Mutantes M1/M2 medidos a mano en copia (arriba) y restaurados; los globales D4/A2
los mide el gate (42 y 42).
