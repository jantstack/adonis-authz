# `2.4.0-alpha.3` — informe del CIERRE (implementador, INCREMENTAL)

**Base:** HEAD `7e21c46` = `2.4.0-alpha.2` + el lote alpha.3 sin commitear (verificado en verde:
1107 / 1131 / 1226 / 1226 con `:8101`). Encargo: cerrar `alpha3-auditor.md` según las decisiones
**2026-09-02 (2c)** de `decisiones-dueno-2026-08-28.md`. Sin commits, sin subir `version`. Único agente
sobre el árbol. Toda corrida a fichero en `$S` = scratchpad de la sesión
(`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`) o `/tmp/*.log`.

Formato: por hallazgo, el ROJO (la reproducción del auditor o el caso nuevo), el VERDE y el MUTANTE.

---

## 0 · El ROJO de partida (las reproducciones del auditor, tal cual)

`node --import @poppinss/ts-exec .claude/reproducciones/alpha3-auditor.ts` (`$S/red_auditor.log`):

```
A1 assertWrite=>false : llamado=1 ESCRITURA ENTRÓ=true
A2 assertWrite=>thenable FUNCIÓN : error=ninguno ESCRITURA ENTRÓ=true
B  hook que cuelga : TIMEOUT 1500ms: relate NO volvió | la tupla YA está escrita=true
D1 purgeSubject sujeto mal formado : error=NINGUNO eventos=1 subject={"type":"user","uuid":"A#B|evil"}
D2 purgeSubject subject={} : error=NINGUNO eventos=1 subject={}
D3 purgeSubject userset NO declarado (role_binding) : error=NINGUNO eventos=1 …
D4 purgeObject tipo NO declarado (role_binding) : error=NINGUNO eventos=1 …
E1 actor: null : error=E_AUTHZ_INVALID_IDENTITY eventos=0
F  purga a medias (503 no-timeout) : borró=1 error=E_AUTHZ_BACKEND_UNAVAILABLE EVENTOS=0
G  aliasing del evento : el evento guardado dice object.id=MUTADO-DESPUES
```

`OPENFGA_TEST_URL=http://localhost:8101 node --import @poppinss/ts-exec .claude/reproducciones/alpha3-f05-purge.ts`
(`$S/red_f05.log`):

```
ANTES  · authorize(user:U, read, organization:S) = true
(a) relate role_binding ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422 (F-05 corta)
(b) listSubjects(assignee, role_binding:R) ⇒ FUGA: [{"type":"user","uuid":"…"}]
(c) purgeObject(role_binding:R) ⇒ NO LANZÓ. eventos: [{"operation":"purgeObject",…}]
DESPUÉS · authorize(user:U, read, organization:S) = false
tuplas del binding que quedan: 0
```

## 0b · El VERDE de las mismas reproducciones tras el cierre

`$S/green_f05.log`:

```
ANTES  · authorize(user:U, read, organization:S) = true
(a) relate role_binding ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422 (F-05 corta)
(b) listSubjects ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422
(c) purgeObject ⇒ E_AUTHZ_RELATION_TYPE_UNKNOWN 422 El tipo de objeto 'role_binding' no está declarado…
DESPUÉS · authorize(user:U, read, organization:S) = true
tuplas del binding que quedan: 2
```

(«quedan: 2» = las dos tuplas cuyo OBJETO es el binding —`role` y `assignee`—, las mismas que antes
del ataque; el `scope#binding` tiene otro objeto.)

`alpha3-auditor.ts`: en la primera corrida tras el cierre el script ABORTÓ en A1 con
`AuthorizationConfigError 500 E_AUTHZ_CONFIG` (`$S/green_auditor.log`) — que ES el verde de 🟠 3 —, así
que se le añadió un `try/catch` en A1 (única edición a la reproducción, marcada con comentario) para que
el resto se observe: ver §7 para la salida final.

---

## 1 · 🔴 1 + 🟠 2 · F-05 cubre las CUATRO escrituras y las TRES lecturas

**Mecanismo.** `assertRelationDeclared(config, object, relation?)` (`define_relations_config.ts`):
`relation` pasa a OPCIONAL (solo el TIPO); el mensaje nombra ya las siete operaciones. Se aplica como
primera línea (misma posición relativa que L-0/L-5: puerta 1 → freeze → F-05 en las purgas; primera
línea en las lecturas) en:

| operación | manager (`src/relations/manager.ts`) | `database` | `openfga` |
|---|---|---|---|
| `purgeObject` | `#assertDeclared(object)` (tipo) | `assertRelationDeclared(config, object)` | ídem, tras `#rejectTransaction` |
| `purgeSubject` | `#assertSubject` (F-05 del userset + `assertSubject` del holder — también ⚪ 7) | userset en `#subjectColumns` + primera línea | userset en `#subjectUser` + primera línea |
| `check` | par + `#assertSubject` | par (+ userset por `#subjectColumns`) | par (+ userset por `#subjectUser`) |
| `listObjects` | `{ type: objectType }` + relación + `#assertSubject` | ídem | ídem |
| `listSubjects` | par | par | par |

`reconcileRelations` no cambia: lee por `enumerateRelations` y escribe por `relate`/`unrelate` (ya con
F-05 desde L-0); un userset de tipo no declarado que llegue del origen cae ahora en `skipped.undeclared`
por la misma vía (`relateOrSkip` captura `RelationTypeUnknownError`). `relations_reconcile.spec.ts` verde
en la corrida de subset (`$S/subset1.log`, 190/190 antes de añadir casos).

**ROJO → VERDE → MUTANTE.**

| caso | ROJO observado | verde | mutante |
|---|---|---|---|
| reproducción `alpha3-f05-purge.ts` | «(c) purgeObject ⇒ NO LANZÓ … DESPUÉS = false, quedan 0» | «422 … DESPUÉS = true, quedan 2» (`$S/green_f05.log`) | M1/M2 (abajo) |
| `relations_openfga.spec.ts` · «cierre alpha.3 · 🔴 1 / 🟠 2 … por el MANAGER» (store compartido, `:8101`) | escrito tras el fix; su rojo es el de la reproducción (idéntico montaje) y lo confirma el mutante M1 | 422 en las cinco, `authorize` SIGUE `true`, tuplas del binding intactas, `spy.calls = []`, `events = []` | **M1** quitar `#assertDeclared(object)` de `purgeObject` del manager ⇒ rojo (ver §7) |
| ídem «por el DRIVER en directo» | ídem | el MISMO 422 con cero llamadas al cliente FGA, `authorize` true | **M2** quitar `assertRelationDeclared` de `purgeObject` del driver `openfga` ⇒ rojo |
| `relations.spec.ts` · «cierre alpha.3 · 🔴 1 / 🟠 2 …» (dobles): purgas | D3/D4 del auditor («error=NINGUNO eventos=1») | 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN`, `calls = []`, `events = []` | M1 |
| ídem: lecturas (`check`/`listObjects`/`listSubjects`, tipo y relación, y el userset del sujeto) | (b) de la reproducción («FUGA») | 422 tipo/relación, `calls = []` | **M9** quitar `#assertDeclared` de `listSubjects` ⇒ rojo |
| `relations_database.spec.ts` · L-0 · «cierre alpha.3 · … EN DIRECTO al driver» | escrito tras el fix | 422 en las siete formas, `connections() = 0` | **M6** quitar `assertRelationDeclared` de `purgeObject` de `database` ⇒ rojo |
| runner publicado · «F-05 · purgeObject/purgeSubject(userset)/check/listObjects/listSubjects …» (caso NUEVO del núcleo, 21 → 22; corre 4 veces) | ídem | `state.calls() = 0` (el espía del runner cuenta ahora también las TRES lecturas), `state.events = []`, y el control declarado entra | M9 (vía `relations_contract.spec.ts`) |

`relations_harness.spec.ts`: `EXPECTED_CASES = 22`, `BEYOND_JUEZ.f05PurgesAndReads = 1` (beyond = 5), y
el título del caso nuevo se exige en los DOS harnesses.

## 2 · 🟠 3 + 🟡 4 · `assertWrite` rechaza TODO retorno ≠ `undefined`

`#assertWrite`: `if (result === undefined) return; if (thenable) descartar rechazo; throw
AuthorizationConfigError.assertWriteReturned(op, result)`. `assertWriteReturned` devuelve la letra de
`asyncAssertWrite` (byte a byte, F4 sigue verde) si el valor es thenable —objeto O función—, y si no una
letra nueva («no devuelve veredictos: LANZA para rechazar o vuelve sin valor … un 'true' es el mismo error
de modelo … servicio del consumidor»). `isThenable` exportado desde `errors.ts`.

| caso | ROJO | verde | mutante |
|---|---|---|---|
| A1 del auditor | «llamado=1 ESCRITURA ENTRÓ=true» | «error=E_AUTHZ_CONFIG ESCRITURA ENTRÓ=false» (§7) | **M3** dejar pasar los booleanos ⇒ rojo |
| A2 (thenable-función) | «error=ninguno ESCRITURA ENTRÓ=true» | 500 con la letra del async | M3 no lo cubre; lo cubre la condición única (quitar todo el `if` deja pasar los dos) |
| `relations.spec.ts` · «cierre alpha.3 · 🟠 3 / 🟡 4 …»: `false`/`true`/`null`/string/objeto × relate/unrelate | escrito tras el fix (su rojo es A1) | 500 antes del driver, `calls = []`, `events = []`, `check` false | M3 |
| thenable-función | A2 | `message === asyncAssertWrite('relations.relate').message`, rechazo descartado | — |
| CONTROL | — | `undefined` entra; lanzar propaga tal cual | — |

## 3 · 🟡 5 · hook que no resuelve — SIN deadline (decisión: paridad con roles); frase publicada

README, sección «The relation write event», bullet del hook: «the sink is **awaited**, so it is on the
critical path of the write … with `{ transaction }`, inside your transaction: a sink that never resolves
keeps it open … There is no deadline on the hook, on purpose … defer anything slow to `trx.after('commit')`
or to a queue». Caso de letra **F7** en `relations_events_docs.spec.ts` (nace verde con la frase; quitarla
⇒ rojo: es letra). No se tocó `#notify`.

## 4 · 🟡 6 · purga a medias en `openfga` ⇒ `indeterminate: true`

**Mecanismo elegido (el mínimo, sin tocar las firmas del puerto):**

- `src/errors.ts`: `markPartialWrite(error)` (propiedad NO enumerable `partialWrite: true`; la clase y el
  `code` no cambian) e `isPartialWrite(error)`. Exportados en `index.ts` (un driver de terceros con purga
  multi-request tiene el mismo deber; documentado en el docblock de `RelationsDriver` y en el README).
- `openfga_relations_driver.ts`: `#purgeByFilter` recibe `progress: { deleted }` y suma cada lote de
  `deleteTuples` que VOLVIÓ (el `Write` de FGA es transaccional: un lote que falla no borró nada);
  `purgeObject`/`purgeSubject` envuelven sus bucles y, en el `catch`, `#partialIfDeleted` marca el error si
  `progress.deleted > 0`. Cubre el 503 no-timeout Y el 500 `E_AUTHZ_PURGE_INCOMPLETE` (la demostración de
  cero corre después de borrar, así que siempre es «después de haber borrado»).
- `manager.ts` `#write`: `if (error instanceof AuthorizationBackendTimeoutError || isPartialWrite(error))
  notify({ ...event, indeterminate: true })`.
- Por qué no `AuthorizationBackendTimeoutError` reutilizada: mentiría en el `code` (no es un timeout) y el
  encargo lo restringe a «solo si ES timeout». Por qué no una clase nueva: el error que ve el llamante debe
  seguir siendo el 503/500 clasificado que ya conoce; lo que cambia es solo la auditoría.
- `database`: UN `DELETE`; no necesita marca (la frase «no ocurrió» es cierta ahí).

| caso | ROJO | verde | mutante |
|---|---|---|---|
| F del auditor (doble que falla tras borrar, SIN marca) | «borró=1 … EVENTOS=0» | ese doble sigue sin evento a propósito (no está marcado): es la cara C2; el auditor lo simulaba con un `Error` crudo | — |
| `relations.spec.ts` · «cierre alpha.3 · 🟡 6 …»: 503 marcado (purgeObject) y `PurgeIncompleteError` marcado (purgeSubject) | escrito tras el fix; con M4 se ve el rojo «borró ≥ 1 y EVENTOS=0» | UN evento `indeterminate: true` con la forma de la purga, ANTES del error; clase y `code` conservados | **M4** quitar `isPartialWrite` de `#write` ⇒ rojo |
| ídem CONTROL (sin marca) | — | cero eventos | — |
| `relations_openfga.spec.ts` · «🟡 6 · … contra el :8101» (espía sobre el cliente REAL que hace fallar la request siguiente a un `deleteTuples`, `ECONNRESET`): purgeObject y purgeSubject | ídem | `fired = 1`, `seen` incluye `deleteTuples`, las tuplas YA no están (borró ≥ 1), 503 `E_AUTHZ_BACKEND_UNAVAILABLE` propagado, `[['purgeObject', true]]` y la secuencia `hook → catch` | **M7** `#partialIfDeleted` sin marcar ⇒ rojo; M4 también |
| ídem CONTROL: falla el PRIMER `Read` | — | 503, cero eventos, la tupla sigue | — |

**Frase reescrita** («that write did not happen»): README bullet `indeterminate` (acotada: 422/assertWrite/
freeze siempre; 503 no-timeout en `relate`/`unrelate` y en `database`; en `openfga` solo si nada se
borró) + `types.ts` docblock de `RelationWriteEvent.indeterminate` + docblock del puerto + filas
`E_AUTHZ_PURGE_INCOMPLETE` de la tabla de errores. Caso de letra **F8**.

## 5 · ⚪

| ⚪ | cierre | caso |
|---|---|---|
| 7 · `purgeSubject` sin validar sujeto | `#assertSubject(subject, partition)` en `purgeSubject` (F-05 del userset + `assertSubject`); `isRelUserset` tolera `null`/no-objeto (antes `TypeError` con `null`) | `relations.spec.ts` «⚪ 7 · purgeSubject valida su SUJETO…»: `A#B|evil`, `{}`, `{type}`, `{uuid}`, `null` ⇒ 422 identidad, cero llamadas/eventos; **M8** quitar la línea ⇒ rojo |
| 8 · aliasing | `#copyEvent`: copia por nivel de identidad (spread: `subject` —userset con su `object`—, `object`, `partition`, `actor`, `expiresAt` como `Date` nuevo) en las cuatro | «mutar object/partition/subject/actor DESPUÉS…»: G del auditor; el sink hostil no alcanza las constantes del llamante; **M5** devolver el alias ⇒ rojo |
| 9 · actor con campos de más | se conserva (spread, sin poda) y se afirma en el mismo caso (`e.actor.admin === true`) — documentado | ídem |
| 10 · `actor: null` | 422 `E_AUTHZ_INVALID_IDENTITY` en las cuatro (ya lo hacía H3); anunciado **BREAKING** en el CHANGELOG (párrafo propio) | «actor: null ⇒ 422 … en las CUATRO escrituras»; **F12** (letra del CHANGELOG) |
| 12 · `relations.requireActor: false` sobre raíz `true` | README: «overrides the root for relations, silently — `warnOnOptInSecurity` does not cover it» | **F11** |
| 11 · invariante 13 en los runners | registrado en `roadmap-2.0.md` (Diferido 2.6+, roles Y relaciones) y en el invariante 13 de `CLAUDE.md` | — |

## 6 · Docs

- **README**: párrafo nuevo tras el de F-05 («F-05 covers **all seven operations of the port**…», con el
  exploit y los casos), la sección del evento (purgas pasan por F-05 primero; `indeterminate` acotado y
  el mecanismo parcial; el sink en el camino crítico; `assertWrite` no devuelve veredictos; la anulación
  silenciosa de `requireActor`), filas `E_AUTHZ_CONFIG` («or any value at all») y
  `E_AUTHZ_PURGE_INCOMPLETE`. Casos de letra F7–F12 (+ el de la fila del 500 ampliado).
- **CHANGELOG** `[Unreleased] — 2.4.0-alpha.3`: sección «The closing lot · the auditor's NO APTA verdict»
  (problema → decisión por hallazgo: F-05 un call-site más allá, pre-existente en alpha.2, cerrado con
  caso contra el servidor; `assertWrite` sin veredictos; `indeterminate` parcial con `markPartialWrite`;
  los ⚪) y párrafo **BREAKING** de `actor: null`.
- **CLAUDE.md** (español, aditivo): fila `relations/` (F-05 en las siete, `assertWriteReturned`,
  `markPartialWrite`, `#copyEvent`, …) e invariante 13 (parcial; ningún runner lo juzga).
- **roadmap-2.0.md** · Diferido (2.6+): «Invariante 13 en los runners publicados (roles Y relaciones)».
- `types.ts`: docblocks de `RelationWriteEvent.indeterminate`, del puerto `RelationsDriver` y de
  `purgeObject`/`purgeSubject`; `manager.ts`: docblock de `RelationsManagerOptions.assertWrite`.

## 7 · Mutantes (`$S/mutants.sh`, logs `$S/mut_<nombre>.log`, resumen `$S/mutants.log`)

Cada mutante aplica UNA sustitución con ancla única, corre el spec y restaura. **Incidencia**: el
restaurador de M1 falló (su texto de vuelta, `assertScope(partition)`, no era único) y M1 quedó APLICADO
durante M2–M9 — por eso cada uno de ellos muestra, además del suyo, el rojo de M1 («ROJO (purgeObject): la
purga de un tipo NO declarado ENTRÓ»). Los rojos ESPECÍFICOS de cada mutante están igualmente medidos
(son aserciones distintas); M1 se restauró a mano y se re-verificó: reproducción del auditor
(`$S/green_auditor2.log`) y `relations.spec` + `relations_openfga.spec` + `relations_database.spec` +
`relations_contract.spec` = **170/170** (`$S/unit6.log`).

| mutante | qué quita | rojo específico observado |
|---|---|---|
| **M1** manager `purgeObject` sin `#assertDeclared(object)` | F-05 de la purga en el manager | `relations.spec`: «ROJO (purgeObject): la purga de un tipo NO declarado ENTRÓ (el 🔴 1 del auditor)» + runner «CERO llamadas al driver: expected 1 to equal +0»; `relations_openfga`: «ROJO (purgeObject): ENTRÓ contra el role_binding real del store compartido» (2 fallos + los del store) |
| **M2** driver `openfga` `purgeObject` sin `assertRelationDeclared` | F-05 de la purga en el driver | «ROJO (driver.purgeObject): ENTRÓ contra el role_binding real del store compartido» |
| **M3** `#assertWrite` deja pasar los booleanos | 🟠 3 | «ROJO (false/relate): la escritura ENTRÓ con un assertWrite que devuelve false (A1 del auditor: fail-open)» |
| **M4** `#write` sin `isPartialWrite` | 🟡 6 (manager) | dobles: «ROJO (F del auditor): borró ≥ 1 y EVENTOS=0»; `:8101`: `expected [] to deeply equal [['purgeObject', true]]` y el de `purgeSubject` |
| **M5** `#copyEvent` devuelve el alias | ⚪ 8 | «ROJO (relate): el evento es un ALIAS de la partición del llamante (G del auditor): expected 'MUTADO-DESPUES' to equal '01a0…'» |
| **M6** driver `database` `purgeObject` sin `assertRelationDeclared` | F-05 de la purga en `database` | «ROJO (purgeObject): el driver ACEPTÓ el tipo/relación no declarado» |
| **M7** `#partialIfDeleted` no marca | 🟡 6 (driver) | los mismos dos rojos del `:8101` que M4 (borró ≥ 1, `[]`) |
| **M8** `purgeSubject` sin `#assertSubject` | ⚪ 7 | «ROJO: purgeSubject({"type":"user","uuid":"A#B\|evil"}) ENTRÓ sin validar el sujeto» |
| **M9** manager `listSubjects` sin `#assertDeclared` | 🟠 2 | `relations.spec` + `relations_contract.spec` (runner con dobles): 3 fallos específicos («entró contra un tipo NO declarado») |

Mutante NO ejecutado: «quitar el `await` de `#notify`» (🟡 5) — no hay cambio de código en 🟡 5 (decisión:
sin deadline); el rojo del caso F7 es quitar la frase del README (es letra).

## 8 · La reproducción del auditor, después (`$S/green_auditor2.log`)

```
A1 assertWrite=>false : llamado=1 error=E_AUTHZ_CONFIG ESCRITURA ENTRÓ=false
A2 assertWrite=>thenable FUNCIÓN : error=E_AUTHZ_CONFIG ESCRITURA ENTRÓ=false
A3 assertWrite async (control) : error=E_AUTHZ_CONFIG status=500 ENTRÓ=false
B  hook que cuelga : TIMEOUT 1500ms: relate NO volvió | la tupla YA está escrita=true   ← decisión: sin deadline (frase publicada, F7)
C  hook lanza en indeterminate : … eventos=1 indeterminate=true logs=1                    ← sin cambio (ya era correcto)
D1 purgeSubject sujeto mal formado : error=E_AUTHZ_INVALID_IDENTITY eventos=0
D2 purgeSubject subject={} : error=E_AUTHZ_INVALID_IDENTITY eventos=0
D3 purgeSubject userset NO declarado (role_binding) : error=E_AUTHZ_RELATION_TYPE_UNKNOWN eventos=0
D4 purgeObject tipo NO declarado (role_binding) : error=E_AUTHZ_RELATION_TYPE_UNKNOWN eventos=0
E1 actor: null : error=E_AUTHZ_INVALID_IDENTITY eventos=0                                ← BREAKING anunciado
E2 actor con campo extra : … "admin":true                                                ← documentado (sin poda)
F  purga a medias (503 no-timeout) : borró=1 error=E_AUTHZ_BACKEND_UNAVAILABLE EVENTOS=0 ← el doble del auditor lanza un Error CRUDO sin marcar: es la cara C2 a propósito; el driver openfga REAL marca (caso contra el :8101)
G  aliasing del evento : el evento guardado dice object.id=01a0…                         ← copia
```

## 9 · Cifras de cierre (`$S/final.sh` → `$S/final.log`)

Estáticas: `npx tsc --noEmit` ✅ · `npm run typecheck` ✅ · `npm run check:purity` ✅ (los drivers de
relaciones no importan del manager; `markPartialWrite` vive en `src/errors.ts`) · `npm run build` ✅.

| modo (todos con `OPENFGA_TEST_URL=http://localhost:8101`) | base alpha.3 | cierre | Δ | log |
|---|---|---|---|---|
| `npm test` (sqlite `:memory:`) | 1107 | **1133** | +26 | `/tmp/s.log` |
| `npm run test:sqlite-file` | 1131 | **1157** | +26 | `/tmp/sf.log` |
| `npm run test:pg` | 1226 | **1252** | +26 | `/tmp/pg.log` |
| `npm run test:mysql` | 1226 | **1252** | +26 | `/tmp/my.log` |

Cero ✖ en los cuatro. Desglose de los +26 (los mismos en los cuatro modos: nada nuevo depende del
motor): `relations.spec.ts` 10 (F-05 3 + `assertWrite` 3 + parcial 2 + copia/`actor: null` 2) + runner
«F-05 · purgas y lecturas» × 4 harnesses (4) + `relations_database.spec.ts` L-0 (1) +
`relations_openfga.spec.ts` (2 del store compartido + 3 de la purga a medias = 5) +
`relations_events_docs.spec.ts` F7–F12 (6) = 26. Sin `skip`. Aditivo: ningún caso existente cambió de
resultado (los dos títulos del runner F-05 no cambian; el conteo del harness sube 21 → 22).

## 10 · Lo que NO hice y por qué

- **Deadline en `#notify`** (🟡 5): decisión (2c) explícita — paridad con roles; solo la frase (F7).
- **Reutilizar `AuthorizationBackendTimeoutError` para la purga parcial**: mentiría en el `code`; el
  encargo lo permitía «solo si ES timeout». Mecanismo elegido: marca `markPartialWrite` (§4).
- **`indeterminate` en los runners publicados** (⚪ 11): registrado en el roadmap (2.6+); toca roles.
- **Poda del `actor` en el evento** (⚪ 9): se copia con spread y se documenta «sin poda» (el auditor no pedía
  poda; la decisión dice «copia defensiva»).
- **Aviso de construcción para `relations.requireActor: false` sobre raíz `true`** (⚪ 12): la decisión
  dice «aviso de la anulación en README» — frase + caso de letra F11; no se tocó `warnOnOptInSecurity`.
- **Cambiar el orden de guardas de `relate`/`unrelate`** (puerta 1 → freeze → F-05): el auditor lo dio por
  correcto; las purgas copian ese orden (F-05 justo tras el freeze) y las lecturas llevan F-05 en la
  primera línea.
- **La reproducción `alpha3-auditor.ts`**: una sola edición (try/catch en A1, comentada) para que el script
  no aborte en el 500 —que es el verde— y se lean B–G. `alpha3-f05-purge.ts` intacta.
- **El doble F del auditor** (un driver falso que lanza un `Error` crudo tras «borrar»): sigue dando
  `EVENTOS=0` a propósito — no está marcado; la marca es deber del driver (el `openfga` real la pone y
  está medida contra el `:8101`). Un driver de terceros sin la marca queda como está: registrado en el
  roadmap con el invariante 13 en los runners.
- **Mutante «sin `await` en `#notify`»**: no aplica (sin cambio de código en 🟡 5).
- **Commits / `version`**: ninguno (sigue `2.4.0-alpha.2`). Árbol: 21 ficheros modificados +
  `tests/relations_events_docs.spec.ts` (nuevo desde alpha.3). Ficheros que este cierre TOCA respecto al
  lote alpha.3: `src/relations/manager.ts`, `src/relations/define_relations_config.ts`, `src/errors.ts`,
  `src/types.ts`, `src/drivers/database_relations_driver.ts`, `src/drivers/openfga_relations_driver.ts`,
  `src/testing/relations_contract.ts`, `index.ts`, `tests/relations.spec.ts`, `tests/relations_harness.spec.ts`,
  `tests/relations_database.spec.ts`, `tests/relations_openfga.spec.ts`, `tests/relations_events_docs.spec.ts`,
  `README.md`, `CHANGELOG.md`, `CLAUDE.md`, `.claude/contexto/roadmap-2.0.md`,
  `.claude/reproducciones/alpha3-auditor.ts` y este informe.
