# Panel 2.4.0-alpha.4 — AUDITOR (adversarial)

Fecha: 2026-09-09 · Base: `main` @ `9a107ad` (2.4.0-alpha.3, árbol limpio)
Alcance: **cambio 1** (`openfga:provision` deja de ser `startApp: false`) y **cambio 2**
(`authorization.capabilities()` / `relations.capabilities()`).
Reproducciones: `/tmp/.../scratchpad/repro/caps2.ts`, `caps3.ts`, `fakeapp/` (fuera del repo, solo lectura aquí).

## Veredicto en una línea

**Seguro con reservas para el cambio 1 si es la opción B; el cambio 2 es seguro solo si `capabilities()`
NO resuelve el driver por un camino propio y NO devuelve la referencia viva** — con la implementación
"obvia" (resolver el driver saltándose las puertas para que la lectura no dé 500) el lote introduce un
bypass permanente del gate de deriva.

---

## Hallazgos (ordenados por severidad)

### 🔴 1 · `capabilities()` que esquive las puertas ENVENENA el driver cacheado (bypass permanente de las dos puertas)

- **Escenario**: precondición — despliegue `openfga` con `hierarchy: facts` y sin `scopes.outbox` ni
  `acceptScopeDriftRisk` (o con `requireTransactionalWrites: true`). El implementador, para que
  `capabilities()` sea "una lectura que no lanza", resuelve el driver con la factory y lo guarda:
  `this.#driver ??= await factory()` (o llama a un `#resolveDriverRaw()` compartido que no invoca
  `#assertTransactionalWritesRequired` / `#assertScopeDriftGuarded`). Acción — cualquier call-site
  (un middleware, un health-check, el propio arranque) llama `authorization.capabilities()` **una vez**.
  Resultado — a partir de ahí `driver()` devuelve el cacheado en `src/manager.ts:370` **sin evaluar
  jamás las puertas**: `manager.scopes.attached/moved/detached` vuelve a escribir el árbol en el store
  dentro de la transacción del consumidor (S5: el rollback no lo deshace y el store queda adelantado a
  la base) y `requireTransactionalWrites` se convierte en un flag decorativo.
- **Evidencia**: 🟡 hipótesis sobre la implementación, ✅ mecanismo verificado — `driver()` cachea DESPUÉS
  de las puertas (`src/manager.ts:392-394`) y devuelve el caché sin re-evaluarlas (`:370`); las puertas son
  `#assertTransactionalWritesRequired` (`:409-419`) y `#assertScopeDriftGuarded` (`:468-479`). Medido:
  con un driver `hierarchyFacts: true` sin firma, `driver()` da `E_AUTHZ_SCOPE_DRIFT_UNGUARDED` 500
  **y la factory se llamó 1 vez** (o sea, hay un objeto driver construido esperando a ser cacheado).
- **Steelman del defensor**: *"nadie va a implementarlo así; `capabilities()` va a ser
  `(await this.driver()).capabilities` y punto"* → **no me convence**: el propio enunciado del lote
  pregunta explícitamente si resolver el driver puede disparar la puerta 2 y el gate de deriva, que es
  justo la presión que empuja a escribir un camino de resolución alternativo. Y el fallo es silencioso:
  ningún test de hoy vuelve a llamar a `driver()` después de un `capabilities()`.
- **Mitigación mínima**: `capabilities()` == `(await this.driver()).capabilities` y nada más; si se quiere
  que no lance, se envuelve el resultado (`{ available: false, reason: e.code }`) **sin tocar `#driver`**.
  Diente: un test que llame `capabilities()` primero y exija que `driver()` siga dando
  `E_AUTHZ_SCOPE_DRIFT_UNGUARDED`.

### 🟠 2 · Opción A (`startApp: true`): el bootstrap del appliance queda rehén de `start()`/`ready()`/preloads del consumidor, y puede ser CIRCULAR

- **Escenario**: precondición — appliance recién instalado: hay `.env` y `config/`, **no hay base de
  datos ni store**. Acción — el operador ejecuta `node ace openfga:provision`. Resultado — el kernel de
  ace hace `await app.boot(); await app.start(() => {})` **antes** de `run()`
  (`node_modules/@adonisjs/core/build/main-B2M1tZ4I.js:70-75`), y `start()` ejecuta, por este orden:
  `provider.start()` de TODOS los providers del consumidor, los hooks `starting`, **la importación de
  todos los preloads** (`start/routes.ts`, `start/kernel.ts`, `start/*` propios) y `provider.ready()`
  (`@adonisjs/application/build/application-BCWLhWpE.js:2510-2536`). Un `ready()` que toque la base
  (health-check, scheduler, warm-up de caché, "asegura el usuario admin") revienta o —peor— **se ejecuta
  a medias con la base ausente**; el comando ni siquiera llega a `run()` (exit 1, error renderizado).
  Variante circular y peor: si algún preload importa `@jantstack/adonis-authz/services/relations`, el
  `await app.booted(...)` de `services/relations.ts` resuelve `authz.relations` ⇒ `buildRelationsManager`
  ⇒ **construye el driver de relaciones** ⇒ el de `openfga` pide `OPENFGA_STORE_ID`… que es exactamente
  lo que este comando existe para producir (`FgaValidationError: storeId must be in ULID format`, error
  CRUDO del SDK, verificado). El appliance no puede aprovisionarse nunca sin editar la app.
- **Evidencia**: ✅ medido con una app Adonis mínima (`fakeapp/`, providers + preload reales):
  ```
  [B] tras init(): app.config = undefined  <-- TypeError en openfga_provision.ts:46
      provider.register() / provider.boot() → app.config disponible
  [B] sin start(): ni preloads ni provider.start()/ready()
  [A] …lo mismo + provider.start() + PRELOAD start/routes.js IMPORTADO + provider.ready()
  [A] app.start() LANZÓ: ready(): SELECT 1 falla, la base todavía no existe
  ```
  ✅ `commands/openfga_provision.ts:46` es el TypeError real (`app.config` no existe hasta `boot()`:
  `ConfigManager.process` se llama en `boot()`, `application-BCWLhWpE.js:2460`).
  ✅ El provider de ESTE paquete no aporta nada al problema: `providers/authz_provider.ts` solo tiene
  `register()` con dos singletons **perezosos**; no hay `boot()`, `start()` ni `ready()`, así que ni
  resuelve el driver, ni lee `authz_catalog_version`, ni arranca el `RelationsManager` al arrancar.
  Lo que sí se dispara con la app booteada son los `app.booted(...)` de `services/main.ts` y
  `services/relations.ts` — y ese segundo **sí** construye el driver de relaciones y aplica la puerta 2
  (`src/relations/manager.ts:122`) en el constructor.
- **Steelman del defensor**: *"los otros ocho comandos son `startApp: true` y no pasa nada; la
  consistencia vale más"* → **no me convence para ESTE comando**: los otros ocho necesitan la base (leen
  `authz_*`), este corre por definición **antes** de que exista nada, y su valor entero es no depender de
  la app. La consistencia que importa aquí es con su propio docblock ("bootstrap del appliance, ANTES de
  que haya base").
- **Mitigación mínima**: **opción B** — `if (!this.app.config) await this.app.boot()` al principio de
  `run()`, dejando `startApp: false`.
- No es un bypass: es fail-closed y ruidoso (ace envuelve todo en try/catch, `exitCode = 1`,
  `app.terminate()` corre igual). Lo marco 🟠 porque **bloquea la operación que el lote quiere arreglar**
  y porque ejecuta código del consumidor contra una base ausente, que es donde nacen los estados a medias.

### 🟠 3 · Devolver el objeto `capabilities` por REFERENCIA reintroduce por la puerta de atrás lo que la API quiere quitar

- **Escenario**: precondición — driver de terceros (o cualquiera cuyo `capabilities` no esté congelado).
  Acción — código de tenant, que ya no necesita `driver()`, hace
  `(await authorization.capabilities()).transactionalWrites = true`. Resultado — el objeto es **el mismo**
  que lee `#assertTransactionalWrite` (`src/manager.ts:430-434`) sobre el driver **cacheado**: la puerta 1
  del manager deja pasar `{ transaction }` a un driver que no sabe honrarla.
- **Evidencia**: ✅ medido (`caps2.ts`): con un driver de terceros,
  `isFrozen(capabilities)=false`; tras `d.capabilities.transactionalWrites = true` la segunda llamada a
  `driver()` (misma instancia cacheada, `factoryCalls=1`) ya declara `true`. Los drivers del paquete
  aguantan: `database` congela el VALOR (`src/drivers/database_driver.ts:499`, mutar lanza `TypeError`)
  y `openfga` lo sirve por getter que devuelve un objeto nuevo y congelado
  (`src/drivers/openfga_driver.ts:609`).
- **Lo que salva la severidad**: la segunda barrera del driver no lee `capabilities`
  (`openfga_driver.ts:966` rechaza `{transaction}` incondicionalmente; `database_driver.ts:612` usa el
  campo privado `this.transactionalWrites`), así que la escritura acaba en 500 igual: **fail-closed**.
  Por eso 🟠 y no 🔴 — el daño real es apagar una puerta del manager y perder su mensaje, no colar la
  escritura.
- **Steelman del defensor**: *"quien puede llamar a `capabilities()` ya está dentro del proceso; si quiere
  romper algo tiene `driver()`"* → **no me convence**: el argumento de venta de este lote es precisamente
  *"para no repartir `driver()`"*. Si el sustituto entrega un handle mutable al estado de las puertas, no
  ha sustituido nada.
- **Mitigación mínima**: devolver **una copia congelada y normalizada**:
  `Object.freeze({ transactionalWrites: d.capabilities?.transactionalWrites === true, … })` — de paso
  cierra el `undefined` vs `false` de los drivers de terceros (mismo patrón que ya usan las puertas).

### 🟡 4 · Una "lectura" que puede lanzar 500 — y con errores crudos de fuera del paquete

- **Escenario**: precondición — `requireTransactionalWrites: true` con `openfga`, o `facts` sin outbox ni
  firma, o `@openfga/sdk` no instalado. Acción — un controlador expone `GET /capabilities` (el caso de uso
  que motiva la API). Resultado — `E_AUTHZ_CONFIG` 500 / `E_AUTHZ_SCOPE_DRIFT_UNGUARDED` 500 /
  `ERR_MODULE_NOT_FOUND` / `FgaValidationError` según el caso, y **en cada request** (el driver no llega a
  cachearse, la factory del consumidor se re-ejecuta cada vez).
- **Evidencia**: ✅ medido (`caps2.ts`): `drift gate ⇒ E_AUTHZ_SCOPE_DRIFT_UNGUARDED (status 500)`,
  `puerta 2 ⇒ E_AUTHZ_CONFIG (status 500)`; ✅ `caps3.ts`: construir `OpenFgaAuthorizationDriver` con un
  `storeId` no-ULID lanza `FgaValidationError` **del SDK, sin `code` ni status del paquete**, y lo hace en
  `openfga_driver.ts:684`, es decir **antes** de `assertScopeDriftGuarded` (`:699`) — un storeId mal puesto
  tapa el gate de deriva en el mensaje.
- **Lo que NO se rompe**: construir el driver `openfga` **no abre ninguna conexión** (el constructor solo
  arma el `OpenFgaClient` de axios; `createStore` solo aparece en `provisionOpenFgaStore`), y los drivers
  `database` tampoco tocan el pool al construirse. La "lectura" no genera tráfico.
- **Steelman**: *"que lance es correcto: son fallos de config"* → me convence a medias: lo correcto es que
  lance en el arranque, no una vez por request en un endpoint de metadatos.
- **Mitigación mínima**: documentar en el docblock que `capabilities()` **resuelve el driver** y por tanto
  hereda las dos puertas y la factory del consumidor; que el consumidor lo llame en un `booted`/`ready`
  hook, no por request.

### 🟡 5 · Una capacidad que MIENTE hacia `false` sí es fail-open (por dónde no implementarla)

- **Escenario**: precondición — `capabilities()` responde desde una fuente que no es la instancia que
  ejecuta las escrituras (el config, un mapa estático, un driver recién construido por la factory, o un
  valor memorizado antes de un `clearCachedDriver()`). Acción — el consumidor hace
  `if (caps.transactionalWrites) { await authorization.grant(..., { transaction: trx }) } else { await authorization.grant(...) }`
  (el patrón exacto que la API promueve) y la respuesta es `false` cuando el driver real es `database`.
  Resultado — el `grant` se escribe **fuera** de la transacción del llamante: el `rollback` del consumidor
  deshace su operación de negocio y **el permiso concedido se queda**. Ese es el único sentido en que una
  capacidad equivocada concede algo; el sentido contrario (`true` falso) es 500 fail-closed en las dos
  barreras.
- **Evidencia**: 🟡 razonamiento sobre la implementación futura; ✅ el asimetría está verificada
  (`manager.ts:430`, `database_driver.ts:612`, `openfga_driver.ts:966`).
- **Steelman**: *"`capabilities()` va a leer del mismo driver, es imposible que mienta"* → me convence
  **si y solo si** se escribe el diente: un caso que cambie `transactionalWrites` del driver y compruebe
  que `capabilities()` y el comportamiento de `grant({transaction})` no divergen nunca.
- **Mitigación mínima**: una sola fuente (`(await this.driver()).capabilities`) y un caso en
  `src/testing/contract.ts` (junto a los de `:4064-4080`) que exija coherencia entre lo que declara
  `capabilities()` y lo que hace la puerta 1, en las dos caras.

### ⚪ 6 · `driver().capabilities = {...}` funciona HOY en el driver `database` (el `readonly` es solo de TypeScript)

- **Escenario**: código de plataforma (o un test dejado suelto) hace
  `(await manager.driver() as any).capabilities = { transactionalWrites: false }`; a partir de ahí la
  puerta 1 del manager rechaza toda escritura transaccional legítima (DoS fail-closed), y `#factsOrigin`
  (`src/manager.ts:1272`) leería un `hierarchyFacts` falseado al elegir el origen de `authz:reconcile`.
- **Evidencia**: ✅ medido (`caps3.ts`): `database: REEMPLAZAR el objeto entero funcionó`. `Object.freeze`
  en `database_driver.ts:499` congela el **valor**, no la propiedad. En `openfga` el reemplazo lanza
  (getter sin setter) y solo cede a `Object.defineProperty`.
- **Steelman**: *"para eso hace falta `driver()`, que ya es API de plataforma con `purgeRole` incluido"* →
  **me convence**: quien llega ahí ya puede escribir lo que quiera. Por eso es ⚪ y no condiciona el lote.
  Deja de ser ⚪ si `capabilities()` reparte el objeto (hallazgo 3).
- **Mitigación mínima**: declarar `capabilities` con `Object.defineProperty(this, 'capabilities', { value: …, writable: false })` o pasarlo a getter como en `openfga`.

### ⚪ 7 · El cambio 1 ACTIVA un camino que hoy nadie recorre: `createStore` antes de validar el modelo

- **Escenario**: con el comando arreglado (A o B), un catálogo con dos permisos que colisionan en el
  espacio de relaciones (`x` y `can_x`), un slug demasiado largo, `holderTypes` vacío o un catálogo que
  desborda `FACTS_MODEL_MAX_BYTES`. Resultado — `provisionOpenFgaStore` crea el store **primero**
  (`src/drivers/openfga_driver.ts:313-316`) y **después** construye el modelo: el error sale (bien:
  `factsRelationMap` lanza `InvalidSlugError` y `assertHolderTypes` 500) pero deja un **store huérfano
  sin modelo** en el servidor, y el operador repite y acumula. Además el camino de provisión **no** llama
  a `assertFactsModelPublishable`, que es quien mide el techo de bytes y avisa al 80 % (solo lo usa
  `catalogProjection()`, `openfga_driver.ts:2109`): ahí el fallo llega como error crudo del SDK.
- **Evidencia**: ✅ lectura del código (orden de las líneas 313-316) y ✅ `openfga_facts.ts:82` / `:291-317`
  (las colisiones y las cotas de nombre sí están cubiertas — S4 aguanta).
- **Mitigación mínima**: construir y validar el modelo (`assertFactsModelPublishable`) **antes** de
  `createStore`.

### ⚪ 8 · `run()` del comando no tiene ni un caso: por eso el TypeError de `:46` se publicó

- `tests/openfga_facts.spec.ts:3890` y `tests/relations_provision.spec.ts` juzgan `permissionsOfCatalogs`
  y `relationsConfigOf` (las dos funciones exportadas), pero **nadie ejecuta `run()`** ni comprueba
  `OpenFgaProvision.options.startApp`. El patrón ya existe para otro comando
  (`tests/scope_outbox.spec.ts:861-867`: "necesita la app: el manager sale del config").
- **Mitigación mínima**: un caso que fije `options.startApp` y la decisión de arranque elegida, y otro que
  ejecute `run()` con un `app` de doble (config presente / config ausente ⇒ mensaje con la receta, no
  `TypeError`).

### ⚪ 9 · `boot()` es un no-op SILENCIOSO si el estado no es `initiated` (riesgo de la opción B)

- `Application.boot()` devuelve sin hacer nada si `#state !== 'initiated'`
  (`application-BCWLhWpE.js:2445-2448`). Bajo ace eso solo ocurre si la app ya está booteada (y entonces
  `app.config` existe) o si `init()` no corrió (imposible por el ignitor), pero un `await this.app.boot()`
  a secas seguido de `this.app.config.get(...)` repite el fallo de hoy en cualquier arnés que no llame a
  `init()`.
- **Mitigación mínima**: `await this.app.boot(); if (!this.app.config) { this.logger.error('…'); this.exitCode = 1; return }`.

---

## Postura A vs B (con el porqué de seguridad)

**B: `startApp: false` + `await this.app.boot()` dentro de `run()`.**

1. `boot()` da **exactamente** lo que el comando necesita —`config/authorization.ts` cargado
   (`catalogs`, `relations.config`, `holderTypes`, `openfga.url`)— y nada más: medido, `boot()` corre
   hooks `booting`, carga config, `register()` + `boot()` de providers y hooks `booted`; **no** importa
   preloads ni ejecuta `start()`/`ready()`.
2. `start()` añade superficie que este comando no puede permitirse: preloads del consumidor, `start()` y
   `ready()` de todos sus providers, **con la base ausente** — el escenario del hallazgo 2, incluida la
   dependencia circular con `OPENFGA_STORE_ID`. Un bootstrap no debe depender de que la app entera
   arranque; si depende, el operador acaba comentando providers para poder aprovisionar, que es peor que
   cualquier cosa que el lote arregle.
3. La superficie que **no** existe en A, y conviene decirlo para no exagerar: `app.start(() => {})` del
   kernel de ace pasa un callback vacío — **no se abre ningún socket HTTP**, no hay servidor escuchando
   durante el comando. Las rutas se registran en memoria y ya. El riesgo de A es el código del consumidor
   (`ready()`, preloads, workers/schedulers que arrancan ahí), no el servidor.
4. B no deja el contenedor a medias: los singletons de este paquete son perezosos
   (`providers/authz_provider.ts`) y `app.terminate()` funciona desde el estado `booted`
   (`application-BCWLhWpE.js:2574-2578`: solo se salta desde `created`/`terminated`), así que los
   `shutdown()` de los providers corren igual.
5. Coste de B: rompe la simetría con los otros ocho comandos. Es un coste de estética; los ocho leen la
   base y este corre antes de que exista. Que quede escrito en el docblock, que ya lo dice.

**Sobre el `catalogs` no puro (pregunta (d))**: no encuentro un camino fail-open. Si un catálogo toca la
base y lanza ⇒ el comando muere sin crear nada. Si devuelve `[]` silenciosamente ⇒ salta el guardián de
`resolvePermissions` (`commands/openfga_provision.ts:110-119`, exit 1). Si devuelve un **subconjunto**
(dos catálogos, uno degradado) ⇒ el modelo se publica sin `can_<P>` para los permisos que faltan, y ahí
la respuesta es **503, no `false`**: cualquier error del SDK (incluido el 400 "relation not found") pasa
por `guardBackendErrors` (`openfga_driver.ts:403-434`) y sale como `AuthorizationBackendError`, y el
`authz:catalog:sync` posterior también fallaría al escribir `permits_<P>`. Además un store recién
aprovisionado **no tiene marcador de raíz** (`scope:app#rooted@…` lo escribe la proyección del catálogo,
no la provisión), así que hasta el primer `sync` **deniega todo** (invariante 9, fail-closed total).
El riesgo real de un `catalogs` impuro no es la autorización: es publicar un modelo que no case con el
catálogo de la base y descubrirlo en producción — ruidoso, no permisivo.

---

## Lo que intenté y NO se rompió

- **El provider del paquete al arrancar**: no resuelve driver, no lee `authz_catalog_version`, no arranca
  el `RelationsManager`; dos `container.singleton` perezosos y nada más. Con A o con B, el paquete no hace
  **nada** hasta que alguien resuelve. No hay degradación silenciosa por su parte.
- **Mutar `capabilities` de los drivers del paquete**: `database` lanza `TypeError` al mutar el valor;
  `openfga` sirve un objeto nuevo congelado por getter (mutarlo y reasignarlo lanzan).
- **Colar `{ transaction }` a `openfga` falseando capacidades**: imposible; el rechazo del driver
  (`openfga_driver.ts:966`) no consulta `capabilities`, y el de `database` usa un campo privado.
- **Colisión de slugs en el modelo publicado** (`x` vs `can_x`, `docs:read` vs `docs_read`, nombres largos,
  `holderTypes` vacío o no inyectivo): todo lanza antes de escribir el modelo (S4, `factsRelationMap`,
  `assertHolderTypes`). No pude fabricar un modelo ambiguo desde `catalogs`.
- **Construir el driver `openfga` para "leer capacidades" no abre conexiones** ni llama al servidor.
- **`app.terminate()` tras un `boot()` sin `start()`**: corre los `shutdown()` (no deja el pool abierto).
- **El error de un `ready()` bajo la opción A**: ace lo captura (`#execMain` try/catch), `exitCode = 1` y
  renderiza; no queda proceso colgado ni escritura del paquete a medias.
- **`--store-id` (segunda rama del comando)**: mismo modelo, mismos guardianes; no encontré camino por el
  que escriba un modelo distinto del de la rama de creación.

## Preguntas abiertas para el arquitecto

1. ¿`capabilities()` va a resolver el driver (y por tanto puede dar 500) o va a ser "best-effort"
   devolviendo el motivo? Si es lo segundo, **exijo por escrito** que no toque `#driver` (hallazgo 1).
2. ¿La forma publicada es un objeto plano congelado o el `DriverCapabilities` del puerto tal cual? Con
   drivers de terceros hay que decidir qué se hace con `undefined` (hoy las puertas lo tratan como
   `false`; la API debería normalizarlo igual y no dejar que el consumidor lea `undefined`).
3. ¿`relations.capabilities()` se sirve del driver ya construido (`RelationsManager` lo tiene eager,
   `src/relations/manager.ts:131`) — sin efectos, sin puertas? Si es así, las dos APIs no son simétricas
   en coste ni en fallos, y eso hay que documentarlo (la de roles resuelve, la de relaciones no).
