# Panel metodología — tester de contrato (2026-09-13)

Evalúo las cuatro medidas de TEST del diagnóstico (`metodologia-diagnostico-coordinador.md`): M2, M6, M1, M3.
Todo lo medido es sobre **HEAD = `7fbc638` (alpha.9)** en un worktree aislado
(`scratchpad/wt`, `node_modules` enlazado), nunca sobre el árbol del implementador. Ficheros sueltos, nunca la
suite entera. OpenFGA = `:8101` donde se indica.

Reproducibilidad (todo en `/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/`):
- `prototipos-instrumentacion.patch`: registrador de invocaciones y mutante «bandera inerte» en `tests/helpers/ace.ts`;
  plugin de Japa que apunta por caso `hasError`/alcance/duración (`M6_LOG`); interruptores `M6_REVERT*` en `src/`.
- `m2/static_guard.mjs` (guardia estática por AST), `m2/burla/` (fichero trampa), `flags.txt`, `inert-names.txt`.
- `m6b_revert.py`, `commands.m6b/` (los 18 `name:` reinsertados, idénticos a `7fbc638^`), `m6*-*.jsonl`, `m6report.py`.
- `m3_truth_table.spec.ts` (tabla de verdad ejecutable).

Leyenda de cobertura: **[hoy]** tiene test hoy · **[propongo]** se puede testear, digo cómo · **[no observable]** falta infra.

---

## Resumen para el juez

| medida | verificable | coste de prueba | riesgo de ceremonia | lo que dicen los números |
|---|---|---|---|---|
| **M2** invocación + guardia de banderas | **sí**, pero solo con mutante; la guardia estática sola se burla | bajo: estática 0,5 s; mutante 29 s para 34 banderas (sqlite `:memory:`) | bajo si es el mutante; alto si es «grep del literal» | 27/34 banderas pasan por el kernel; solo **22/34** tienen un caso que muere si la bandera queda inerte (23 con `:8101`) |
| **M6** retirar el arreglo | **sí**, solo con instrumentación del ALCANCE; «qué sigue verde» a secas no significa nada | medio: 3–45 s de ejecución por defecto, pero aislar el arreglo es trabajo humano y propenso a errores (me equivoqué en uno) | medio-alto | 4 defectos, **0 casos decorativos reales** en los tests de cierre; el hueco real es otro: entradas que nunca alcanzan la condición (238 de 241 en (a)) y 1 falso positivo por arreglos solapados |
| **M1** runbook ejecutable | **sí**, diseño abajo | medio de construir (hijo por fase, reloj inyectable); **~6–10 s** por motor al ejecutarse | bajo si es job obligatorio y el README se deriva de él | contrafactual: caza el prune compartido y 4–5 de las 18 banderas; los dos de alpha.10 **solo si el paso existe**, y el paso lo genera M5, no M1 |
| **M3** tabla de verdad | **sí** (tabla literal + guardia de producto cartesiano) | muy bajo: 17 casos, ~100 ms | medio (las filas «PROPUESTA» exigen decisión del dueño) | contra alpha.9 la tabla da **rojas las 2 filas de `type=app` con uuid** que COGNITIV encontró después, y 3 filas más sin dueño |

**Tesis del tester.** El diagnóstico acierta en P1 y P4; los números **no** apoyan que el problema sean tests
decorativos (P5 existe, pero M6 no lo caza en su forma propuesta: hay que darle la vuelta). El patrón medido
es **ceguera de entrada y de puerta**: casos que nunca pasan la bandera, nunca siembran una tupla ajena, nunca
combinan dos valores. M2 (con mutante) y M3 lo atacan de forma mecánica y barata; M1 lo ataca en la frontera
pero depende de que alguien enumere los estados (M5).

---

## M2 · La unidad de test de un comando es su invocación

### Caso de contrato
Dado un comando registrado en `commands/main.ts` con la bandera `--B`, cuando la bandera queda inerte (la
propiedad no recibe el valor: el defecto de alpha.9 reproducido en ejecución), entonces al menos un caso que
ejecuta el comando por `aceFor(...).exec([... '--B' ...])` se pone rojo.

### Estado HOY (HEAD alpha.9): comando × bandera

Método. (1) **Presencia**: guardia estática por AST (`m2/static_guard.mjs`) **y** registrador en `exec()`
(`AUTHZ_FLAG_LOG`): coinciden exactamente, 27/34. (2) **Efecto**: mutante por bandera (`AUTHZ_INERT=cmd#flag`
renombra `flag.name` durante ese `exec` y lo restaura; así la guardia estática A-G no lo delata), corriendo
`command_flags.spec.ts` + `commands.spec.ts`. 34 corridas, **29 s** en total.

| comando | bandera | caso por el kernel que la pasa | ¿muere el mutante inerte? |
|---|---|---|---|
| `openfga:provision` | `--url` | `commands.spec.ts:251` (A-4) | sí (A-4) |
| | `--store-id` | `commands.spec.ts:399` (L-F); B-2 solo con `OPENFGA_TEST_URL` | **no** sin servidor (L-F rechaza antes de mirar el store); sí con `:8101` (B-2) |
| | `--name` | NINGUNO | — |
| `authz:catalog:diff` | `--fail-on-shadows` | `command_flags.spec.ts:654` (A-10) | sí |
| `authz:catalog:sync` | `--keep-links` | NINGUNO | — |
| `authz:catalog:prune-orphans` | `--force` | `command_flags.spec.ts:593` (A-9) | sí |
| | `--allow-mass-purge` | `:593` (A-9) | sí |
| `authz:scopes:relay` | `--dry-run` | `:262` (A-1) | sí |
| | `--limit` | `:298` (A-2) | sí |
| | `--batch-size` | `:325` (A-3) | sí |
| | `--only` | NINGUNO | — |
| | `--wait-lease-ms` | `:325` (A-3) | sí |
| | `--max-age` | `:298` (A-2) | sí |
| `authz:scopes:requeue` | `--id` | `:348` (A-4) | sí |
| | `--force` | NINGUNO | — |
| | `--apply` | `:348` (A-4) | sí |
| | `--wait-lease-ms` | `:348` (A-4) | sí |
| `authz:reconcile` | `--to` | `:426`, `:447` | sí (A-5, A-6) |
| | `--from` | `:426`, `:447` | **no**: con dos drivers el origen se infiere igual (mutante equivalente en ese montaje) |
| | `--dry-run` | `:426` (A-5) | sí |
| | `--prune` | `:447` (A-6) | **no**: A-6 la pasa y no afirma que llegue |
| | `--allow-mass-delete` | `:447` | sí |
| | `--batch-size` | `:447` | sí |
| | `--max-tuples` | `:447` | sí |
| `authz:relations:reconcile` | `--to` | `:495`, `:523`, `:543` + C-3 | sí |
| | `--from` | `:495`, `:523`, `:543` | **no** (equivalente: dos drivers) |
| | `--dry-run` | `:495`, `:523`, `:543` | **no**: el origen doble no tiene tuplas y nadie afirma cero escrituras |
| | `--prune` | NINGUNO | — |
| | `--allow-mass-delete` | NINGUNO | — |
| | `--partition-type` | `:495`, `:543` | sí (A-7, A-7c) |
| | `--partition-uuid` | `:495`, `:523` | sí (A-7, A-7b) |
| `authz:freeze` | `--reason` | `:566` (A-8) | sí |
| | `--lease-ms` | `:566` (A-8) | sí |
| `authz:unfreeze` | `--fence` | NINGUNO | — |

Totales: **34 banderas** · **27** pasan por el kernel · **22** protegidas de verdad sin servidor (**23** con
`:8101`) · **7 sin caso** · **5 presencias decorativas**.

Las que importan, en orden de daño:
1. **`authz:relations:reconcile --dry-run`**: presente en 3 casos y **ninguno la protege**. Es la gemela de la
   bandera que escribía en alpha.8; si vuelve a quedar inerte, la suite sigue verde.
2. **`authz:reconcile --prune`**: la bandera del defecto B de alpha.9. El manager con `prune: true` sí tiene
   casos (`reconcile.spec.ts` B-1/B-2), pero **el cable comando → manager no**.
3. **`authz:scopes:requeue --force`** (revierte el store a sabiendas) y **`authz:unfreeze --fence`** (levanta
   la barrera de otro): nunca por el kernel. `scope_outbox.spec.ts` solo hace grep del fuente
   (`'force: this.force === true'`), que no ve un `name:` en la declaración.
4. `--keep-links`, `--only`, `--name`, relaciones `--prune`/`--allow-mass-delete`: sin caso.

(Nota: el lote alpha.10 en curso añade `--allow-stale-source` y casos de `unfreeze`; esta tabla es HEAD.)

### ¿Robusta la guardia «la bandera aparece en ≥ 1 `exec`»?

Prototipo estático por AST (no grep): resuelve `aceFor(<Clase>)` → import → `commandName`, sigue variables
`const ace = await aceFor(X)`, lee los literales y la cabeza de las plantillas del array. Comparado con el
registro de ejecución: **27/27 idéntico**, 0,5 s, ignora comentarios. Dos invocaciones reales quedan «no
resolubles» (`commands.spec.ts:443` clase de una tabla, `:470` argv por parámetro).

Burlas medidas con un fichero trampa (`m2/burla/tests/zz_burla.spec.ts`):

| trampa | guardia estática | registrador en ejecución | mutante inerte |
|---|---|---|---|
| `test.skip(... exec(['--keep-links']))` | **ENGAÑADA** (la cuenta) | la caza (no se ejecutó) | la caza |
| `exec(['--only=1'])` sin aserción | **ENGAÑADA** | **ENGAÑADO** | la caza |
| `const argv = ['--fence=3']; exec(argv)` | la marca «no resoluble» (falla cerrada) | la cuenta | según aserción |
| `exec(['--' + 'force'])` | «no resoluble» (falla cerrada) | la cuenta | según aserción |
| literal en un comentario | ignorado (AST) | — | — |
| caso bajo `if (OPENFGA_TEST_URL)` (B-2 real) | **ENGAÑADA** en el job sin servidor | la caza por job | la caza por job |

Conclusión: la guardia de PRESENCIA reproduce la ilusión de P1 un nivel más abajo: 5 de las 27 presencias hoy
son decorativas. **Lo único que no se burla sin escribir una aserción es el mutante inerte.** Sus límites:
mutantes equivalentes (`--from` con dos drivers: el remedio es montar tres drivers, no una lista de excepciones)
y la cobertura por job (hay que correrlo en el job con `OPENFGA_TEST_URL` para `--store-id`).

**Propuesta verificable**: (i) la guardia estática A-G que ya existe se queda (nombre efectivo); (ii) un caso
nuevo que, por cada bandera booteada de los diez comandos, ejecuta los dos ficheros de kernel con la bandera
inerte y exige ≥ 1 rojo, con una lista de excepciones que exige razón escrita (hoy vacía si se arreglan
`--from`). 29 s: cabe en el job `openfga` de CI; en local, script aparte (`scripts/check_flag_mutants.mjs`).
Coste de prueba: **bajo**. Veredicto: **verificable con cambios**.

---

## M6 · Retirar el arreglo y ver qué casos de la zona siguen verdes

### Método (y por qué «qué sigue verde» a secas no vale)
Sin instrumentar, casi todo sigue verde siempre: la mayoría de casos de un fichero prueban otra cosa. Así que
por cada defecto instrumenté la **condición del defecto** (la rama que el arreglo cambia) con un contador por
caso (plugin de Japa, `M6_LOG`) y medí tres cosas: casos de la zona, casos cuya entrada **alcanza** la
condición, y rojos al retirar el arreglo. **Decorativo = alcanza la condición y sigue verde.** Línea base sin
retirar: todo verde en los cuatro.

### (a) catch-all de `familyOfTuple` (alpha.9 · B)
Retirado: se quita el `return 'foreign'` (vuelve a caer en `'facts'`). Zona: `reconcile.spec.ts`,
`openfga_facts.spec.ts`, `relations_openfga.spec.ts` contra `:8101`, 36–46 s.

```
casos en la zona: 241 · alcanzan la condición del defecto: 3 · rojos con el arreglo retirado: 3
ROJOS:
  - reconcile.spec.ts · B-1 · `--prune` no borra NI UNA tupla ajena ... (hits=16)
  - reconcile.spec.ts · B-2 · la prueba DECISIVA ... (hits=10)
  - reconcile.spec.ts · B-3 · los tipos declarados parten el REPORTE ... (hits=28)
ALCANZAN LA CONDICIÓN Y SIGUEN VERDES: (ninguno)
```
B-2 cae por el EFECTO (`expected 11 to equal 2`: borró las 9 ajenas); B-1 cae primero por el campo nuevo
`foreign` (`expected +0 to equal 8`). **0 decorativos.** Lo que M6 revela: **238 de 241 casos nunca meten una
tupla ajena en el store**. Antes de alpha.9 eran 0 de 238: ahí M6 habría dado «todo verde» y no significaba
«tests decorativos», significaba «nadie probó esa entrada».

### (b) `name:` en las banderas (alpha.9 · A)
Retirado: los 18 `name:` reinsertados (`commands.m6b/`, idénticos en los `name:` a `7fbc638^`). Zona:
`command_flags`, `commands`, `relations_reconcile_cli`, `freeze`, `scope_outbox`, `reconcile` (sqlite), 3,4 s.
Condición: una bandera PASADA cuyo `flag.name` lleva guion.

```
zona 252 · alcanzan condición 12 · rojos 14
  ROJO A-G-1, A-G-3 (guardias estáticas, sin alcance)
  ROJO A-1, A-2, A-3, A-4, A-5, A-6, A-7, A-7b, A-7c, A-8, A-9, A-10 (los 12 que alcanzan)
  alcanzan y siguen verdes: (ninguno)
```
**0 decorativos en el agregado — y aun así hay 5 presencias decorativas** (tabla de M2): el agregado de 18
banderas tapa que `relations --dry-run` o `reconcile --prune` no están protegidas, porque sus casos caen por
OTRA bandera del mismo `exec`. **M6 por defecto compuesto es demasiado grueso: la unidad tiene que ser la
mutación mínima.**

Aviso de honestidad: mi primer script de reversión estaba mal (el regex apilaba los 18 `name:` en la primera
declaración de cada fichero) y dio un resultado distinto y engañoso (11 rojos, A-2/A-3/A-4 verdes). Lo detecté
porque A-2/A-3/A-4 no aparecían ni en rojos ni en alcance. Es exactamente el riesgo de M6: **una reversión mal
hecha produce conclusiones falsas con aspecto de medición**.

**P5 medido en su forma real** (tests que codifican el defecto): corrí `tests/scope_outbox.spec.ts` de
`7fbc638^` (alpha.8) contra los comandos de HEAD y contra los revertidos:

```
con arreglo: ROJO | sin arreglo: verde | declara las banderas que el operador usa: --dry-run, --limit y --batch-size
con arreglo: ROJO | sin arreglo: verde | R-10 (comando): `authz:scopes:requeue` declara `--apply` ... y `--wait-lease-ms`
con arreglo: ROJO | sin arreglo: verde | letra: el README dice que `waitForLeaseMs` es opt-in ...
con arreglo: ROJO | sin arreglo: verde | `authz:scopes:relay --max-age=<ms>`: declara la bandera ...
con arreglo: ROJO | sin arreglo: verde | el comando declara `--only` y su salida es por entrada
```
5 casos (el commit dice seis aserciones) verdes CON el defecto y rojos con el arreglo. **M6 tal como está
escrita no los encuentra**: al retirar el arreglo siguen verdes, que es lo esperado. Los encuentra la
dirección contraria: **aplicar el arreglo contra la suite de ANTES y listar los que se ponen rojos**.

### (c) exención de la raíz `app` en `#changeScopes` (alpha.8)
Retirado: `#isRootRef(parent)` deja de devolver `[child]`. Zona: `scope_outbox`, `scope_outbox_contract`,
`scope_outbox_harness`, `scope_outbox_multiprocess`, `command_flags` (sqlite), 2,5 s. Alcance amplio = pasa por
la exención; estrecho = ≥ 2 hijos distintos de `app` en el mismo caso (condición necesaria para que `app` sea
la única clave compartida).

```
zona 215 · pasan por la exención (amplio) 28 · ≥2 hijos de app en el caso (estrecho) 10 · rojos 8
 ROJO  O-07b (×3 harnesses), A-2, A-3, A-8, A-6, D-1
 estrecho y VERDE:
  - A-1 (S1 · el síntoma medido): aparcada `attached(orgA, app)` ⇒ el alta de orgB SE APLICA ...
  - mata al mutante «variante B metida en `#changeKeys`» ...
```
El segundo prueba otra cosa (legítimo). **A-1 parece decorativo y no lo es**: retirando TAMBIÉN la variante B
(el censo de aparcadas siembra solo la clave del hijo) se pone rojo; retirando SOLO la variante B cae otro caso
(«EL CASO (m7)»):

```
exención + variante B retiradas: 7 rojos, A-1 incluido
solo variante B retirada:        1 rojo  (EL CASO m7)
```
A-1 está protegido por **dos arreglos solapados**. **M6 de un solo arreglo da un falso positivo** aquí.

### (d) F-05 en `purgeObject` (alpha.3), defensa en profundidad en tres capas
Retirado por capa (`M6_REVERT_F05=manager|drivers|all`). Zona: 10 ficheros de relaciones + `freeze` con `:8101`,
7 s por modo. Alcance: `purgeObject` con tipo no declarado.

```
zona 286 · alcanzan: 9
  manager:ROJO  drivers:verde all:ROJO  | relations.spec.ts · purgeObject(role_binding) ... ⇒ 422
  manager:ROJO  drivers:verde all:ROJO  | relations_contract.spec.ts · F-05 ... (×2 harnesses)
  manager:ROJO  drivers:verde all:ROJO  | relations_database.spec.ts · F-05 ...
  manager:ROJO  drivers:verde all:ROJO  | relations_openfga.spec.ts · F-05 ...
  manager:verde drivers:ROJO  all:ROJO  | relations_database.spec.ts · EN DIRECTO al driver ...
  manager:verde drivers:ROJO  all:ROJO  | relations_openfga.spec.ts · por el DRIVER en directo ...
  manager:verde drivers:verde all:ROJO  | relations_openfga.spec.ts · por el MANAGER: purgeObject(role_binding:R) ⇒ 422, authorize SIGUE true
  manager:verde drivers:verde all:verde | freeze.spec.ts · relay: un freeze adquirido a MITAD ...   <- ARTEFACTO
```
Totales: 5 rojos (solo manager), 2 (solo drivers), 8 (las tres). El caso decisivo contra el `:8101` («authorize
SIGUE true») solo cae sin las tres capas: redundancia deseada, no decoración. La fila de `freeze.spec` es un
**artefacto de mi instrumentación** (ese caso no llama a `purgeObject`; es trabajo asíncrono de un caso anterior
que cae tras el `test:start` siguiente): el contador por caso tiene fugas entre casos asíncronos.

### Veredicto M6
- **Decorativos reales encontrados en 4 defectos: 0.** Los tests de cierre de este paquete sí protegen lo que
  dicen.
- M6 tal como está escrita da tres lecturas falsas medidas: **ceguera tomada por salud** (a), **agregado que tapa
  presencias decorativas** (b), **falso positivo con arreglos solapados** (c, d).
- Versión verificable que propongo: cada cierre deja un `revert.patch` mínimo **por mutación** (no por
  defecto) y un script que lo aplica en un worktree, corre los ficheros de la zona y exige ≥ 1 rojo; un parche
  que ya no aplica falla ruidoso. Más la dirección contraria para P5: la suite de `HEAD^` contra el código
  arreglado, listar los rojos y justificar cada uno en el informe.
- Coste: **medio** (ejecución 3–45 s por parche; el trabajo real es aislar el arreglo, y me equivoqué en uno).
  Riesgo de ceremonia: **medio-alto** si es manual; **medio** si son parches con job. Veredicto: **verificable
  con cambios**; por sí sola no habría evitado ninguno de los siete defectos de la tabla del coordinador.

---

## M1 · Runbook ejecutable del cutover dentro de la suite

### Restricción de infraestructura medida
Los comandos resuelven el manager de `services/main.ts`, capturado **una vez** al bootear la app global de la
suite (`tests/helpers/app.ts:341`, `database` solo). `command_flags.spec.ts` lo resuelve parcheando métodos
sueltos (`patchManager`). Para un runbook eso no vale: el cutover **cambia `config.default`** entre fases (es
un redeploy). Diseño: **un proceso hijo por fase** (patrón `freeze_child.ts`/`relay_child.ts`) que hace
`bootApp({ reuse })` con el config de ESA fase y ejecuta los pasos por el kernel de ace dentro del hijo; el
padre afirma el efecto leyendo el store (`OpenFgaClient.read`) y la base. Consecuencia: **no corre en
`:memory:`** (el hijo no abre esa base); sí en sqlite-file, pg, mysql.

### Secuencia (siembra = la de `runMigrationContract`: 7 nodos, 6 holders, 14 grants, 5 caducidades, 6 denies, para reutilizar sus 448 preguntas como verificación de paridad) + relaciones en DOS particiones (org A y org B, con `group`)

**Fase ANTES (hijo con `default: 'database'`)**

| # | invocación por el kernel | efecto que se afirma |
|---|---|---|
| 0 | `openfga:provision --url=$OPENFGA_TEST_URL --name=runbook-<id>` | store existe; modelo con `can_`/`denied_`/`permits_`/`rooted` |
| 1 | `authz:catalog:sync` y `authz:catalog:diff` | exit 0 las dos; `authz_catalog_version` sube una vez |
| 2 | `authz:reconcile --to=openfga --dry-run` | exit 1 (deriva); **store con 0 tuplas** |
| 3 | `authz:freeze --reason=cutover` | fila `id=2` kind operator, `untilMs` null; una escritura desde OTRO proceso ⇒ 503 `E_AUTHZ_FROZEN` |
| 4 | `authz:relations:reconcile --to=openfga --from=database --partition-type=organization --partition-uuid=<A> --dry-run` | 0 tuplas de relación en el store |
| 5 | ídem sin `--dry-run`, para A y para B | tuplas de relación de A y de B en el store, contadas por tipo (`group` incluido) |
| 6 | `authz:reconcile --to=openfga` | exit 0; `frozen.lapsed = false`; 448 preguntas iguales en los dos drivers |
| 7 | `authz:reconcile --to=openfga --prune` (store ya COMPARTIDO) | tuplas de relación intactas (mismo conjunto antes y después); `foreign.tuples` = las sembradas |
| 8 | `authz:reconcile --to=openfga --dry-run` | exit 0, limpia (el verificador de cron en verde tras el cutover) |
| 9 | `authz:unfreeze` | exit 0; fila limpia; la escritura del otro proceso entra |

**Fase DESPUÉS (hijo nuevo con `default: 'openfga'`)**

| # | invocación | efecto |
|---|---|---|
| 10 | API: `revoke` de G1 y `deny` nuevo; `scopes.detached(orgB)` + `authz:scopes:relay` | `authorize(H1)` false; hechos de orgB purgados del store |
| 11 | **repetir la migración en dirección rancia**: `authz:reconcile --to=openfga --from=database` (y con `--prune`) | exit 1 y `E_AUTHZ_STALE_SOURCE_REFUSED`; conjunto de tuplas idéntico; `authorize(H1)` sigue false |
| 12 | mantenimiento: `authz:reconcile --to=openfga`; luego borrar una fila de `demo_scopes` sin `detached` y `--prune` | 0 escrituras de hechos; con `--prune` borradas 3, la otra org sigue concediendo; la letra no dice «ni borra» |
| 13 | **ventana caducada**: `authz:freeze --reason=x --lease-ms=60000`; reloj del config +5 min (reloj inyectado en el hijo por IPC, nunca `sleep`); escritura del otro proceso; `authz:unfreeze` | la escritura entra; `unfreeze` exit 1 con la hora ISO; fila limpia; el segundo `unfreeze` exit 0 |
| 14 | ventana adoptada: `freeze --lease-ms` + `reconcile` | `frozen.untilMs` y `leaseMs` restantes en el reporte |

**Fase VUELTA (hijo con `default: 'database'`)**

| # | invocación | efecto |
|---|---|---|
| 15 | `freeze`; `authz:reconcile --to=database --from=openfga`; `authz:relations:reconcile --to=database --from=openfga` por partición; `unfreeze` | censo de `authz_*` = hechos del store (el revoke del paso 10 presente como ausencia); 448 preguntas iguales |
| 16 | repetir en dirección rancia con `database` activo: `authz:reconcile --to=database` **sin `--from`** | **hoy no hay decisión**: es el hueco que el propio implementador reporta en `alpha10-informe.md` §1. El runbook obliga a escribir esta fila |

### Motores y coste
- **Tiempo, con medidas existentes** (`:8101`, este worktree): `command_flags.spec.ts` 15 casos / 0,1 s;
  `commands.spec.ts` 27 / 0,2 s (B-1/B-2 provisionan contra el servidor en decenas de ms); reconcile contra
  servidor real 13 casos / 0,6 s (`--to=openfga`) y 16 / 1,2 s (`--to=database`), es decir **50–75 ms por
  pasada**; `migration_contract.spec.ts` **~1,4 s por dirección** (siembra + 448 × 2 + censo). Runbook: unas 20
  pasadas (≈ 1,5 s) + 4 verificaciones de paridad (≈ 3–4 s) + 3 arranques de hijo (≈ 1–3 s: estimado, no medido
  aquí) ⇒ **≈ 6–10 s por motor**. Para comparar, solo `openfga_facts.spec.ts` se lleva ~30 s del job `openfga`.
- **Motores**: la lógica del runbook es composición de comandos, no dialecto; el freeze entre procesos sí
  depende del motor. Propuesta: **job de CI propio `cutover-runbook` con pg + OpenFGA, obligatorio**, y mysql en
  la matriz `engines` si cabe (+10 s).

### Cómo evitar que acabe en `skip`
1. **Un solo test con pasos numerados** (`step(n, etiqueta, fn)` que prefija cada aserción con el paso y la
   línea de comando para reproducirlo a mano). No una cadena de tests que dependen del orden: falla en el
   primer paso roto y dice cuál.
2. **Sin sleeps**: toda caducidad con el reloj del config, adelantado por IPC.
3. **Store propio por ejecución** (`runbook-<id>`) borrado en el teardown y cubierto por la red de
   `openfga_stores.ts` (C5). Sin estado compartido con el resto de la suite.
4. **Docs con dientes**: la sección «Cutover runbook» del README se afirma igual a la tabla de pasos (mismo
   patrón que `trx_docs.spec.ts`). Si alguien lo salta, el README deja de estar respaldado y un caso del job
   por defecto lo dice.
5. **Guardia en el job por defecto**: el fichero del runbook no contiene `.skip`/`.pin`/`test.fixme` y el job
   `cutover-runbook` es check requerido. Un runbook que no corre en CI es exactamente «lo probamos a mano».
6. **Presupuesto de tiempo con dientes**: el runbook falla si pasa de 30 s. Si crece, se parte por fases, no se
   desactiva.

### Contrafactual: ¿habría salido rojo en casa?

| defecto | ¿rojo? | paso | condición honesta |
|---|---|---|---|
| alpha.9 · banderas inertes | **parcial: 4 de 18** (5 si existe el paso 13) | 2 (`reconcile --dry-run`), 4 (`relations --dry-run`), 5 (`--partition-type/-uuid`), 13 (`--lease-ms`) | caza las dos con pérdida de datos. `--max-age`, `--fail-on-shadows`, `--allow-mass-*`, `--batch-size`, `--wait-lease-ms`, `--max-tuples` no son de cutover: esas son de M2 |
| alpha.9 · `--prune` en store compartido | **sí** | 7 | **solo si las relaciones se migran ANTES del `--prune` de hechos**. Con el orden «hechos con prune, luego relaciones» (plausible) no sale. El orden de la tabla es parte del diseño |
| alpha.10 · dirección rancia | **sí** | 11 | solo porque el paso «repetir en dirección rancia» está en la lista. Ese paso no sale de «ida y vuelta», sale de enumerar el estado «repetida» (M5) |
| alpha.10 · `unfreeze` con ventana caducada | **sí** | 13 | solo si el runbook usa `--lease-ms`, y COGNITIV lo prohíbe en el suyo: un runbook copiado del consumidor no lo tendría. Otra vez M5 («abortada/caducada») |

Veredicto M1: **verificable**. Coste de construir **medio** (hijo por fase y reloj por IPC es infraestructura
nueva, aunque con precedentes), coste de ejecutar **bajo**. **M1 es el vehículo; M5 genera los pasos.** Sin
M5, M1 habría cazado alpha.9 · B (condicionado al orden) y parte de alpha.9 · A; con los estados de M5 × los
comandos del runbook, los cuatro.

---

## M3 · Tabla de verdad en los cierres

### ¿Verificable o disciplina?
Verificable en la parte mecánica: **dominios declarados + tabla literal + guardia de producto cartesiano**.
Prototipo ejecutado contra HEAD (`m3_truth_table.spec.ts`, por el kernel, dobles de A-7):

- Dominios: `--partition-type` ∈ {ausente, `app`, otro (`organization`), inválido (`Org!`)};
  `--partition-uuid` ∈ {ausente, válido, vacío, inválido (`NO-ES-UUID`)}.
- Guardia: `Object.keys(TABLE)` = producto de los dominios; cada fila lleva resultado (`raiz` | `tenant` |
  `rechazo` | `parser`) con su fuente, o `imposible` con razón. Añadir un valor al dominio deja la guardia roja.
- Cada fila se ejecuta: `rechazo` = cero particiones enumeradas y exit 1 (o 422); `raiz`/`tenant` = las
  particiones que llegan al motor.

Salida real contra alpha.9:
```
✔ guardia: producto completo
✔ ausente × ausente ⇒ raiz          ✔ ausente × valido ⇒ rechazo      ✔ ausente × vacio ⇒ parser     ✔ ausente × invalido ⇒ rechazo
✔ app × ausente ⇒ raiz              ✖ app × valido ⇒ rechazo          ✔ app × vacio ⇒ parser         ✖ app × invalido ⇒ rechazo
✔ otro × ausente ⇒ rechazo          ✔ otro × valido ⇒ tenant          ✔ otro × vacio ⇒ parser        ✖ otro × invalido ⇒ rechazo
✔ invalido × ausente ⇒ rechazo      ✖ invalido × valido ⇒ rechazo     ✔ invalido × vacio ⇒ parser    ✖ invalido × invalido ⇒ rechazo
Tests  12 passed, 5 failed (17)
```

Lectura:
- **`app × valido` y `app × invalido`: rojas contra alpha.9** (observado `raiz`, exit 0, `[success]`). Es el
  punto 5 del sexto informe de COGNITIV, que alpha.10 cierra. **La tabla lo habría dado en el cierre de alpha.9**,
  que cubrió 2 de las 16 filas por intuición (P3 confirmado con número).
- **Las cuatro filas «vacío»**: la tabla obligó a mirar y resultó que **ace rechaza `--partition-uuid=` antes de
  `run()`** («Missing value for option») y `kernel.exec` **lanza** en ese caso. La regla 2 de
  `tests/helpers/ace.ts` («`kernel.exec` NO relanza») no vale para errores del parser. No es peligroso (un caso
  así sale rojo, no verde), pero el comentario del helper es incompleto.
- **`otro × invalido`, `invalido × valido`, `invalido × invalido`**: el comando y `runRelationsReconcile` entregan
  al motor una identidad mal formada (`{type:'Org!', …}`) con exit 0. Con los drivers REALES no pasa:
  `enumerateRelations` hace `assertScope(partition)` en los dos
  (`database_relations_driver.ts:818`, `openfga_relations_driver.ts:616`), así que el resultado real es un 422.
  La fila roja es cierta sobre el comando y falsa sobre el sistema: **los dobles pueden hacer mentir a una
  fila**, y la tabla tiene que decir en qué capa se juzga cada una. Si la validación debe estar también en el
  comando es decisión del arquitecto o del auditor; **lo reporto, no lo decido**.

Lo que NO es mecánico: **qué valores forman el dominio** (¿por qué 4 y no 5?: mayúsculas, uuid con guiones y sin
ellos) y la **fuente de cada fila** (5 filas del prototipo son PROPUESTA mía y piden decisión del dueño). Una
guardia asegura que la tabla está completa respecto de sus dominios, no que los dominios estén bien.

Coste: **muy bajo** (17 casos, ~100 ms; escribir la tabla, del orden de media hora). Riesgo de ceremonia:
**medio**, porque la tentación es rellenar las filas copiando lo que el código hace hoy (que es P5 otra vez).
Remedio: una fila cuya fuente sea «lo que hace hoy» no se acepta; la fuente tiene que ser el README, una
decisión del dueño o un invariante. Veredicto: **verificable** para combinaciones de entradas; para ESTADOS de
operaciones largas (M5) la tabla es la del runbook de M1.

---

## Comparación

| medida | casos nuevos | invariantes / defectos en riesgo que cubre | coste de prueba | veredicto |
|---|---|---|---|---|
| M2 (con mutante inerte) | 7 banderas sin caso + 5 presencias por reforzar (`relations --dry-run`, `reconcile --prune`, `--from` ×2 con 3 drivers, `--store-id` sin servidor) + 1 caso guardia | «`--dry-run` es read-only por contrato» (hoy sin guardia por el kernel en relaciones), seguros de borrado masivo, `requeue --force`, `unfreeze --fence` | bajo (29 s) | verificable con cambios |
| M6 (parche por mutación + dirección contraria) | 0 por sí misma; se valida la suite, no el producto | ninguno nuevo; detecta tests que codifican el defecto (P5: 5 medidos) | medio | verificable con cambios; valor bajo frente a su coste |
| M1 (runbook, hijo por fase, job propio) | 1 test, 16 pasos | freeze durable entre procesos, `--dry-run` read-only, store compartido, dirección rancia, ventana caducada, paridad de 448 | medio de construir, ~6–10 s por motor | verificable |
| M3 (tabla literal + guardia) | 1 tabla por par de entradas cerrado | P3; en el ejemplo, 2 filas rojas contra alpha.9 (=COGNITIV) y 3 que piden decidir la capa | muy bajo | verificable |

**Orden que propongo, por rendimiento medido:** M3 y M2 con mutante primero (mecánicos, baratos, atacan P1/P3
con número); M1 después, **con la lista de estados de M5 como entrada obligatoria**; M6 solo en su versión con
parche por mutación y en la dirección contraria para P5, o no adoptarla.

**Patrón que no cubre ninguna de las cuatro:** entradas que nadie concibió (el store compartido de (a) no lo
habría sembrado ni M2, ni M3, ni M6). Solo M1 + M5 lo alcanzan, y solo si el runbook se escribe desde el uso del
consumidor (relaciones y hechos en el mismo store) y no desde el paquete.

## Para el arquitecto y el auditor (fuera de mi veredicto)
1. `authz:relations:reconcile --dry-run` y `authz:reconcile --prune` no tienen guardia por el kernel (mutante inerte en verde).
2. Identidad de partición mal formada llega al runner con exit 0; hoy la para solo el driver (`assertScope`).
3. `--partition-uuid=` vacío lo rechaza ace, no el paquete: si se quiere letra propia, hace falta otra cosa.
4. Con `database` activo, `--to=database` sin `--from` (paso 16) sigue sin decisión (ya reportado por el implementador).

Worktree de medición: `scratchpad/wt` (detached en `7fbc638`, con la instrumentación aplicada). Para retirarlo:
`git worktree remove --force <ruta>`.
