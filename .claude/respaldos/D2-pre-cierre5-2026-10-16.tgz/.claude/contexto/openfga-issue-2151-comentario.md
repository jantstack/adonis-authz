# Comentario para openfga/openfga#2151

Destino: https://github.com/openfga/openfga/issues/2151 (comentar en el issue existente; uno nuevo se cerraría como duplicado).
Reproducción verificada contra OpenFGA v1.19.0 el 2026-10-16.

---

**This is a security issue, not only an ergonomics one: with exclusion (`but not`), the delete-then-write workaround is fail-open.**

We maintain an authorization library that uses OpenFGA as a backend. We hit this when renewing a time-bound membership in a group that is used for **exclusion**, e.g. "suspended users cannot view this document". The expiry lives in the condition context, so extending the suspension means changing the context of an existing tuple. That is exactly the operation this issue asks for.

### Minimal reproduction (v1.19.0)

Model:

```
model
  schema 1.1
type user
type group
  relations
    define member: [user with not_expired]
type document
  relations
    define blocked: [group#member]
    define viewer: [user] but not blocked
condition not_expired(current_time: timestamp, valid_until: timestamp) {
  current_time < valid_until
}
```

Tuples:

```
user:anne            viewer   document:x
group:suspended#member blocked document:x
user:anne            member   group:suspended   (not_expired, valid_until=2026-10-20)
```

Goal: extend Anne's suspension to `2026-10-30`.

| Step | Result |
|---|---|
| `Check(user:anne, viewer, document:x)` | `allowed: false` (correct) |
| `Write` with the new context while the old tuple exists | 400 `cannot write a tuple which already exists` |
| `Write` with `deletes` + `writes` of the same key in one request | 400 `cannot_allow_duplicate_tuples_in_one_request` |
| `on_duplicate: ignore` | does not update the context (and the docs say a condition mismatch is a conflict) |
| Workaround, step 1: `Write { deletes: [anne member suspended] }` | 200 |
| **`Check` between the two writes** | **`allowed: true`** ← the suspended user can view the document |
| Workaround, step 2: `Write { writes: [anne member suspended, valid_until=2026-10-30] }` | 200 |
| `Check` after | `allowed: false` |

### Why this matters

- **Concurrent checks see the gap.** We hammered a renewal loop while running concurrent `Check`s. Checks that overlapped a renewal returned `allowed: true` for the excluded user in roughly half of the cases (53–54 % in our runs).
- **If the second `Write` fails** (network error, pod restart, server unavailable), the gap is **permanent**: the exclusion is silently gone until someone notices and re-writes the tuple.
- There is no client-side fix. Writing the new tuple before deleting the old one is impossible with the same key. Using a second relation as an alternate "slot" works, but because a `Check` does not read one consistent snapshot, it also needs a delay of at least `--request-timeout` before deleting the old slot. That makes a simple context update a multi-second operation that depends on server configuration.

### What would solve it

Any one of these, in order of preference:

1. **`on_duplicate: "update"`** (or a `replace`/`upsert` write mode) that atomically replaces the condition/context of an existing tuple with the same key. Several people asked for this above.
2. **Allow `deletes` and `writes` of the same key in one `Write`**, applying deletes before writes inside the same transaction. The request is already all-or-nothing; this only removes the duplicate-key validation for that case.

Both keep the existing default behaviour (strict, error on duplicates) and are opt-in.

Happy to provide the full reproduction script or test against a branch. Thanks for OpenFGA!
