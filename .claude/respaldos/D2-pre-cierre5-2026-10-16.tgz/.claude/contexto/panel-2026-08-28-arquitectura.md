# Panel 28-08-2026 · Analista técnico — respuesta del PAQUETE a las exigencias de COGNITIV

> Evaluado contra el código real de `@jantstack/adonis-authz` v1.1.0 (`252ea8c`), no contra el build
> en `node_modules` del consumidor. Todo lo marcado ✅ está leído en el archivo:línea que se cita o
> ejecutado contra el OpenFGA local (`:8101`, **v1.19.0**, defaults de fábrica).
> 🟡 = asumido/diseñado · ❌ = no existe hoy.
>
> Pregunta que responde este informe: **cada exigencia, ¿es factible sobre el código real y compatible
> con "usable en cualquier proyecto, maleable, sin acoplarse a ningún dominio"?**

---

## 0. Lo primero: los dos "spikes" del documento ya están resueltos (no hacen falta 90 min)

El documento deja dos incógnitas ❓ que bloqueaban el diseño de `relations/`. Las he ejecutado contra
el OpenFGA local. Resultado:

| Incógnita del doc | Veredicto | Evidencia |
|---|---|---|
| ¿Conditions sobre tuplas de **userset** (`unit:U#member with not_expired`)? | ✅ **SÍ, funciona end-to-end** | Modelo con `{"type":"unit","relation":"member","condition":"not_expired"}` en `directly_related_user_types` → **aceptado** por `POST /authorization-models`. Tupla `ia_spaces:S1#viewer@unit:U1#member` con `valid_until` futuro → `check` de `user:alice` = **true**; con `valid_until` pasado = **false**; `list-objects` devuelve solo S1. La paridad de caducidad entre drivers **es alcanzable también sobre usersets**. |
| ¿`streamed-list-objects` sin límite de 1000? | ✅ **SÍ**: 1200 tuplas escritas → `list-objects` devuelve **exactamente 1000**, `streamed-list-objects` devuelve **1200** | Verificado. Y el flag real es `--listObjects-max-results` (default 1000, `0` = todos) |

Y tres hallazgos que el documento **no tiene** y que cambian dos de sus propuestas:

1. ❌ **`ListObjects` NO admite `continuation_token`.** Verificado en el SDK instalado:
   `node_modules/@openfga/sdk/dist/apiModel.d.ts:783-828` (`ListObjectsRequest` no tiene `page_size`
   ni `continuation_token`) y `:832-839` (`ListObjectsResponse` es **solo** `objects: string[]`, sin
   señal de corte). El issue openfga#2828 sigue siendo una *feature request*.
   **⇒ La corrección propuesta en L0.7 ("paginación con continuation_token en los dos listObjects")
   es literalmente irrealizable.** Ver D-L0.7 para la corrección que sí funciona.
2. ✅ **El API `Read` SÍ pagina**: `ReadRequest` tiene `page_size`, `continuation_token` y
   `consistency` (`apiModel.d.ts:1143-1167`), el cliente lo expone (`client.d.ts:298`), y verifiqué
   `POST /read` con `{"object":"ia_spaces:","user":"user:bob","page_size":50}` → 50 tuplas +
   `continuation_token` no vacío. **Como el modelo que genera el paquete solo tiene relaciones
   directas (`assignee: {this}`, `denied: {this}`, `openfga_driver.ts:147-165`), `Read` es
   equivalente exacto a `ListObjects` para este caso y además es enumerable sin truncamiento.**
3. ❌ **`listSubjects` tiene el MISMO defecto de truncamiento que `listScopes`, y el documento no lo
   ve**: `--listUsers-max-results` también es 1000 por defecto y `openfga_driver.ts:616-621` llama a
   `listUsers` sin paginar. L0.7 está incompleto.

Dos avisos operativos verificados que afectan al diseño:

- El `--listObjects-deadline` (3 s) aplica **también a `streamed-list-objects`**. El streaming quita
  el tope de 1000, **no** el deadline: sigue sin haber señal explícita de corte por tiempo.
  Prometer "detección de truncamiento" a secas seguiría siendo mentira aunque se migre a streaming.
- Un `check` sobre una tupla condicionada **sin** `context` no devuelve `false`: devuelve
  `400 validation_error` (`"missing context parameters '[current_time]'"`). Hoy no explota porque los
  denies no llevan condición, pero `openfga_driver.ts:441-445` (deny checks) y `:670-674`
  (`listObjects` de denies) **no envían `context`**: el día que el deny tenga caducidad (1.3), esas dos
  llamadas empiezan a dar 400 → `guardBackendErrors` las convierte en **503**. Es una bomba de relojería
  ya colocada por el diseño de 1.3 que propone el propio documento.

---

## 1. Las tres pruebas que le aplico a cada exigencia

1. **Prueba de vocabulario**: ¿mete una palabra del dominio de COGNITIV en el paquete? (`tenant`,
   `organization`, `space`, `membresía` → fuera; `scope`, `partition`, `owner`, `container` → dentro).
2. **Prueba del consumidor mínimo**: un blog de un solo tenant que instala el paquete, ¿queda obligado
   a algo que no necesita?
3. **Prueba del invariante de portabilidad** (CLAUDE.md, regla de higiene 5): *"un cambio de driver es
   migración de hechos, no reescritura"*. Si una exigencia hace que un call-site tenga que cambiar al
   cambiar de driver, está mal **salvo que el fallo se produzca en el boot y no en tiempo de ejecución**.

Y una nota de semver que gobierna todo el informe:

> **CLAUDE.md regla 4: "un cambio que rompa el contrato para drivers de terceros es major".**
> Tal como está escrita, **añadir un caso a `runAuthorizationDriverContract` convierte en major
> cualquier mejora**, porque un driver de tercero que pasaba deja de pasar. Con ese candado, L0+L1
> completos son 2.0 y no hay camino incremental.
> **Recomendación transversal nº1: introducir capacidades en el juez ANTES de tocar nada más.**
> ```ts
> runAuthorizationDriverContract({
>   name, makeDriver, seedCatalog, cleanup,
>   level: 'core' | '1.2' | '1.3',          // casos que se exigen
>   supports: { transactions: false, denyExpiry: false, unknownScope: true },
> })
> ```
> Con `level` por defecto `'core'` (los 19 casos de hoy, `src/testing/contract.ts`), un driver de
> tercero sigue pasando sin tocar nada y **opta** al nivel nuevo. Eso baja de major a **minor** casi
> todo lo que viene después. Sin esta pieza, la mitad de este informe es 2.0.
> Ojo: `supports` NO es "eximir de cumplir"; el juez exige lo contrario — si `transactions: false`,
> el driver debe **lanzar** al recibir `{trx}`, y hay un caso que lo comprueba.

---

## 2. Ítem por ítem

### A · Reestructurar en módulos opt-in `roles/`, `relations/`, `catalog/` (+ `http/`)

**Veredicto: 🟡 entra con cambios.** La idea es correcta; la palabra "reestructurar" es el problema.

- **Factibilidad ✅**: el `exports` map (`package.json:43-52`) ya tiene subpaths (`./testing`,
  `./types`, `./commands/*`); añadir `./relations`, `./catalog`, `./http` es aditivo. `configure.ts:309-347`
  ya publica stubs y migración con `makeUsingStub`; hacerlo interactivo es trivial con el prompt de Ace.
- **La frontera "por construcción" ✅ es real y barata**: `relations/` no puede llamar a
  `roles.authorize()` si su manager no recibe el otro por constructor y su directorio no importa
  `../manager.js`. Se verifica con una regla más en `scripts/check_purity.mjs:53-69` (que hoy solo
  mira aliases `#`): *ningún archivo bajo `src/relations/` importa `src/manager.js`, `src/drivers/*`
  ni `types.ts#ScopeAncestorsResolver`*. Es un grep, no una disciplina. **Esto es lo mejor del
  documento entero** y lo suscribo tal cual.
- **Lo que cambio**: **no mover `src/drivers/*` ni `src/manager.ts` de sitio, y no tocar el export
  raíz `.`** (`index.ts:255-298`). Un consumidor de 1.1.0 no debe notar nada. `roles/` es un
  *nombre de módulo conceptual y un subpath nuevo que reexporta*, no una carpeta a la que se mudan
  35 archivos. Mover archivos con el paquete ya publicado es coste puro sin beneficio observable, y
  rompe los deep-imports que alguien haya hecho.
- **Migraciones separadas ✅ obligatorio**: la migración de `authz_*` ya está publicada en repos
  consumidores (`stubs/migration.stub`); `relations/` y `catalog/` traen **stubs nuevos e
  independientes**, jamás una edición del stub existente.
- **Prueba del consumidor mínimo ✅**: `configure` interactivo con los tres módulos desmarcados por
  defecto salvo `roles/`. Un blog instala y no ve `authz_relations` por ningún lado.
- **Semver: minor** (aditivo) si no se mueve nada; **major** si se mueven rutas o cambia el export raíz.
- **Steelman de lo contrario**: "modularizar antes de tener el segundo módulo escrito es diseño
  especulativo; hazlo cuando `relations/` exista y se vea la costura real". Es un buen argumento y
  por eso la fase 3 del doc (1,5 d de reestructuración *antes* de escribir nada) me parece invertida:
  **el módulo se descubre escribiéndolo**. Contrapropuesta: escribir `catalog/` y `relations/` ya
  como subpaths nuevos, y consolidar la estructura *después*, con dos ejemplos en la mano.

### B · Módulo `relations/` (§3)

**Veredicto: ✅ entra (con dos cambios concretos).** Es el diseño más sólido del documento y pasa las
tres pruebas: `object`, `relation`, `partition`, `userset` son vocabulario de ReBAC, no de COGNITIV.

Punto por punto:

| Pieza | Veredicto | Nota |
|---|---|---|
| Puerto `relate/unrelate/check/listObjects(lote)/listSubjects/purgeObject/purgeSubject` | ✅ | `listObjects` **por lote desde el día 1** es la decisión correcta: el driver `openfga` puede unir N sujetos y el `database` hace un `whereIn`. Añadir el lote después habría sido breaking. |
| `partition: ScopeRef` obligatoria y no-nullable | ✅ **con un matiz** | Reutilizar `ScopeRef` + `scopeKey()` (`openfga_driver.ts:84-89`) es correcto: es serialización, no semántica. **Cambio:** en vez de "un consumidor no multi-tenant usa una constante" (que le obliga a inventarse un uuid falso), el paquete **exporta `APP_SCOPE` como partición válida** (`types.ts:63`). Sigue siendo obligatoria y no-nullable, y el consumidor mínimo escribe `relations.check(s,'viewer',o, APP_SCOPE)`. Cero constantes inventadas, y el trigger/FK sencillamente no aplica. |
| Sin `attributes` en el paquete, `externalRef` + tabla del consumidor | ✅ | El argumento (dos backends sin transacción) es correcto y verificable: `openfga_driver.ts` solo toca FGA + catálogo de lectura. |
| Modelo declarativo TS/JSON con `includes`, sin `from` | ✅ | "Sin herencia entre objetos" como **imposibilidad verificable** en vez de promesa es exactamente la filosofía de la casa. `from` después es aditivo. |
| Usersets de **un nivel**, recursión en `usersetsOf` del consumidor, `maxNodes` que **lanza** | ✅ | Y el detalle que más me gusta: *"cualquier `catch` en la ruta de decisión es un defecto"*. Consistente con el invariante 5 (503 nunca se traduce a `false`). |
| `membersOf` devuelve **subquery**, no array | ✅ | Correcto para el driver `database`. Detalle: obliga a que el tipo del puerto exponga un `QueryBuilder` de Lucid → acopla `relations/` a Lucid. Ya lo está todo el paquete (`database_driver.ts:1`), así que no empeora nada, pero conviene que el **puerto** hable de un tipo opaco y solo el **driver database** conozca el builder. |
| Userset no declarado → throw; userset de otra partición → throw | ✅ | Fail-closed por construcción, sin depender del hook. |
| Driver openfga: fusión de modelos + throw ante colisión de tipos | ✅ factible | `openFgaAuthorizationModel(holderTypeMap)` (`openfga_driver.ts:140-177`) pasa a `(holderTypeMap, extensions?)`: **parámetro opcional ⇒ minor**. La colisión hay que detectarla contra `role_binding`/`deny_binding` y contra los propios `holderTypes`. |
| Prefijo de partición en el object id + filtro obligatorio al leer | ✅ | Verifiqué que `|` es un carácter **legal** en un id de FGA (`user:a\|b` se escribe sin error), así que el esquema `ia_spaces:<partitionKey>\|<uuid>` es válido. El filtro al leer es imprescindible **y** hay que reusar `assertScopeComponent` (`:69-77`) sobre el uuid del objeto, no solo sobre la partición. |
| `listObjects` con `HIGHER_CONSISTENCY` + `RelationsResultTruncatedError` por cantidad | 🟡 **cambio** | Ver §0: hay una opción mejor. Para relaciones **directas** (`includes` se resuelve en el modelo, así que no siempre) usar `Read` paginado; para las que sí requieren evaluación del modelo, `streamedListObjects` (verificado: 1200/1200) **y aun así** el deadline de 3 s sigue sin señal. Lo honesto en el README: *"la enumeración por lote es completa salvo corte por deadline del servidor, que no es distinguible; para conjuntos grandes, usa `check` sobre candidatos"*. |
| Caducidad por condición, renovar = delete+write, fallo del 2.º paso ⇒ **lanza** | ✅ | Ya es el patrón de `grant` (`openfga_driver.ts:498-521`), incluido el `readAssignment` de tres estados (`:532-550`) — reutilizable tal cual. **Y el spike confirma que la condición funciona sobre usersets**, así que hay paridad real. |
| Esquema `authz_relations` (§3.4) | ✅ | Índices correctos. Un detalle: `subject_key varchar(200)` con la forma `role_binding:organization\|<uuid>\|<uuid>#assignee` son ~85 chars; holgado. Mantener `subject_type/subject_uuid/subject_relation` **desglosados** además de `subject_key` es la decisión correcta (columna para lo que se consulta, no blob). |
| `relationPartitionTrigger(objectType, table, uuidCol, partitionCol)` | 🟡 | Es un **generador de SQL para la migración del consumidor**, y ahí es donde tiene que vivir: el paquete emite texto, no conoce la tabla. Riesgo real: SQL de trigger **no es portable** (PG ≠ MySQL ≠ SQLite) y el paquete se anuncia para los tres (`package.json:33-35`). ⇒ o se implementa por dialecto, o se documenta "solo PostgreSQL" y se **lanza** en los demás. No dejarlo a medias. |
| `{trx}` solo en `database`, rechazada explícitamente por `openfga` | 🟡 **el punto más delicado** | Ver G. |

- **Semver: minor** (módulo nuevo, puerto nuevo, `AuthorizationDriver` intacto).
- **Steelman de lo contrario**: "ReBAC en un paquete que se vende como RBAC jerárquico diluye el
  producto y duplica la superficie de test (28×2 casos) para un solo consumidor". Es cierto que el
  coste de mantenimiento se dobla; el contraargumento que gana es que **el modelo de llaves por
  recurso no es expresable con `roles/`** (`SubjectRef` no admite usersets, `types.ts:36-39`; la cadena
  hereda incondicionalmente, `database_driver.ts:55-57`) y sin él el paquete no cubre su propio caso
  de uso. Pero eso solo justifica `relations/` **si hay un segundo consumidor** (ver J.1).

### C · Módulo `catalog/` — roles por tenant (§4)

**Veredicto: 🟡 entra con cambios (dos de ellos importantes).**

- **Factibilidad ✅ pero más cara de lo que dice el documento.** Toca las dos rutas de resolución de
  rol: `database_driver.ts:81-94` (`findRoleOrFail`), `:188-195` (`revoke`), `:284-296`
  (`listSubjects`), `:301-315` (`listRoles`) y `openfga_driver.ts:400-412` + `:415-428`
  (`rolesGranting`). Además cambia el `unique(slug, scope_type)` publicado
  (`stubs/migration.stub:34`) ⇒ **migración de un índice ya desplegado** en cualquier consumidor.
- **Corrección al documento:** "`listSubjects` (bug latente: hoy cruza tenants por slug)" — ❌ **hoy
  no hay bug**: el `unique(slug, scope_type)` hace imposible el homónimo. No es un defecto presente,
  es un **requisito derivado** del cambio. Importa la distinción: L0 se hace "pase lo que pase", esto
  no.
- **Cambio 1 (fuerte): el binding id de 4 partes está mal especificado.** `parseBindingId`
  (`openfga_driver.ts:91-100`) parsea **por número de partes**. El `owner` propuesto es él mismo un
  `scopeKey`, que puede ser 1 parte (`app`) o 2 (`organization|X`) ⇒ el id resultante tiene 4 **o 5**
  partes y el parseo por conteo es ambiguo. **Propuesta mejor, que además el propio documento pide en
  §6.3 ("roles por uuid desde el día 1"): el binding id lleva el UUID del rol, no el slug ni el owner.**
  `role_binding:<scopeKey>|<roleUuid>`. El uuid ya es globalmente único, así que el owner sobra en la
  llave; el catálogo local (que existe con los dos drivers) resuelve owner y permisos. Ventajas:
  (a) desaparece la ambigüedad de parseo; (b) `rolesGranting` deja de generar un check por cada
  homónimo de cada tenant — que es el problema real de rendimiento que el documento señala;
  (c) `authorize` no necesita saber nada de owners. Coste: **migración de hechos** (reescribir los ids
  de las tuplas) → exactamente lo que el paquete ya sabe hacer (`importAuthzFactsToOpenFga`,
  `openfga_driver.ts:268`) con un comando de reescritura. Es un coste de una vez, honesto y visible.
- **Cambio 2 (vocabulario): `createTenantRole` y `tenantAssignablePermissions` no pasan la prueba 1.**
  El propio documento **rechaza "tenant" como concepto del paquete en III.2** y luego lo usa como
  nombre de dos APIs públicas. Nombres que sí pasan: `defineScopedRole(actor, ownerScope, spec)`,
  `delegablePermissions` (o `catalog.delegable: string[]`), `purgeRole`, `onCatalogWrite`.
- ✅ **`owner_scope_key` + resolución `owner ∈ chain ∪ global`**: correcto y sin dominio.
  ✅ **`purgeRole`**: imprescindible (hoy borrar un rol deja asignaciones colgando; `authz_assignments.role_uuid`
  es `onDelete('RESTRICT')`, `stubs/migration.stub:70-75`, así que hoy **ni siquiera se puede borrar**).
  ✅ **exportar `assertValidSlug`**: hoy es privada (`catalog.ts:25`) y el consumidor no tiene forma de
  validar un slug de usuario antes de escribirlo. Barato y necesario.
  ✅ **`catalog.js` deja de pisar el `rank` de los locales** (`catalog.ts:86-90`): correcto, hoy el sync
  machaca rank incondicionalmente.
- **Prueba del consumidor mínimo ✅**: con `owner_scope_key DEFAULT 'global'` un consumidor sin roles
  locales no cambia una línea.
- **Semver: minor en API / major de facto en operación** (índice único + ids de FGA). Con el `level`
  del juez (recomendación transversal nº1) los 8 casos nuevos no rompen drivers de terceros.
- **Steelman de lo contrario**: "roles por tenant es una feature de producto SaaS, no de un motor;
  el consumidor puede modelarlo con un prefijo de slug (`org-<uuid>-editor`) sin tocar el paquete".
  Es factible y cuesta 0 días de paquete… hasta que quieres `listRoles` legible, `purgeRole` o un
  techo de permisos: entonces reimplementas medio catálogo en el consumidor. El argumento pierde,
  pero deja una consecuencia: **`catalog/` solo vale la pena si `defineScopedRole` con policy entra
  completo**; a medias es peor que el prefijo.

### D · L0.1–L0.8 · "defectos presentes" — uno por uno

| # | ¿Existe el defecto? | Archivo:línea | ¿La corrección propuesta es la correcta? |
|---|---|---|---|
| **L0.1** `whereScopeIn([]) ⇒ 1=0` | ✅ **existe, latente** | `database_driver.ts:60-68`. **Verificado ejecutando knex**: el grupo vacío no emite cláusula alguna → `select * from authz_denies where holder_type = 'users'` (sin filtro de scope). Hoy es inalcanzable porque `chain()` (`:55-57`) siempre devuelve ≥1 scope; se vuelve alcanzable en cuanto `authorizedScopes`/`descendantsOf` pasen listas. | ✅ **Sí**, y **mejor aún**: en vez de `whereRaw('1 = 0')` (que reintroduce SQL crudo en un driver que presume de no tenerlo, `database_driver.ts:39-40`), usar `query.whereRaw('1 = 0')` es aceptable pero prefiero **lanzar** `new Exception('whereScopeIn con lista vacía')` en la ruta de escritura y devolver `[]`/`false` **antes** de construir la query en la ruta de lectura. Una lista de scopes vacía es un error del llamante, no una condición de negocio. |
| **L0.2** `holderTypes` inyectivo | ✅ **existe** | `openfga_driver.ts:612-614`: `Object.fromEntries` sobre pares invertidos **colapsa silenciosamente** (`{users:'principal', admins:'principal'}` → todo vuelve como el último). `listSubjects` devuelve el tipo equivocado ⇒ un `revoke` sobre ese resultado no borra nada y el bucle "revoca a todos" deja asignaciones vivas. | ✅ Sí. **Verificación en el constructor del driver** (`:353-365`), no "en boot": el paquete no controla el boot del consumidor, y el driver es el único que sabe si el mapa importa (el driver `database` lo ignora, `define_config.ts:141-145`). Coste: 4 líneas. |
| **L0.3** `UnknownScopeError` | ✅ **existe el agujero**, con matiz | `database_driver.ts:50-53` y `openfga_driver.ts:361-363`: sin resolutor, **todo tipo distinto de `app` cuelga de `app`**. Un scope inexistente/borrado resuelve a `[scope, app]` y un grant de plataforma gobierna un recurso que no existe. | 🟡 **La dirección es correcta; la propuesta mezcla dos cosas.** (a) *"sin resolutor, declarar tipos ≠ app ⇒ throw"* — ✅ sí, pero no "en boot": en la **primera llamada** con un scope no-`app` sin resolutor. Es el mismo fallo, en el sitio donde el paquete tiene la información. (b) *`resolver → null` ⇒ `authorize` false y `grant/deny` throw* — ✅ correcto y es la asimetría adecuada (leer deniega, escribir grita). **Semver:** cambiar el tipo a `Promise<ScopeRef[] \| null>` es compatible para quien lo implementa (ampliar el retorno), pero **añade un caso al juez** ⇒ major sin la recomendación transversal nº1. |
| **L0.4** `expiresAt`: `undefined` = no tocar, `null` = quitar | ✅ **existe** | `database_driver.ts:137` (`options.expiresAt ?? null`) y `:152-154`: un re-grant sin opciones **borra una caducidad vigente**; el contrato incluso lo bendice (`contract.ts:177-192`, "re-grant refresca la expiración"). En `openfga` pasa lo mismo (`openfga_driver.ts:479-487`). | ✅ Sí, la semántica de tres estados es la correcta. **Es un cambio de semántica observable ⇒ major** (o 1.2 con opt-in `expiryMode: 'replace' \| 'preserve'`, default `'replace'`, y flip en 2.0). También hay que **cambiar el caso 177-192 del juez**, que hoy exige lo contrario. La acción `extended` con `previousExpiresAt` en el evento: ✅ aditivo, minor. |
| **L0.5** `assertIdentityComponent` en ambos drivers | ✅ **existe la divergencia**, pero el daño no es el que dice el documento | `openfga_driver.ts:103-114` construye `${fgaType}:${uuid}` **sin validar**; `database_driver` no valida nada. **Verificado contra el servidor**: un uuid con `#` (`user:zz#member`) **no** crea un userset accidental — OpenFGA lo rechaza con `400 validation_error` (*"relation 'user#member' not found"*) porque los holder types del paquete se generan con `relations: {}` (`:150`). Un uuid con `:` también se rechaza (*"malformed"*). **Pero**: `guardBackendErrors` (`:212-233`) convierte ese 400 en **`AuthorizationBackendError` 503** ⇒ un error del llamante se reporta como "el backend no responde", que es justo lo que el invariante 5 dice que **no** debe pasar. Y en `database` la misma escritura **funciona** (en SQLite/MySQL; en PostgreSQL la columna `uuid` la rechaza, `stubs/migration.stub:69`) ⇒ divergencia entre drivers **y entre motores**. | ✅ Sí, y con más motivo del que da el documento: no es solo higiene, es (a) cerrar la puerta **antes** de que `relations/` meta usersets de verdad en el modelo (ahí sí sería explotable), y (b) dejar de disfrazar un 422 de 503. **Añadir**: validar longitudes contra las columnas publicadas (`scope_type` es `varchar(20)`, `slug` `varchar(100)`, `stubs/migration.stub:26,22`). |
| **L0.6** `hasRole` no es decisión de acceso | ✅ **existe, y es el peor de los ocho** | Verificado: `authorize` consulta denies (`database_driver.ts:102-111`), `hasRole` **no** (`:208-224`); en openfga igual (`:565-577` no mira `deny_binding`). Y el paquete **publica un PEP indenegable**: `app_access_middleware.ts:229` usa `hasRole`. El README promete *"Explicit deny wins. A deny anywhere in the scope chain blocks the permission"* (README:36) mientras el middleware que el propio paquete registra en `configure.ts:318-323` no lo respeta. Es la brecha narrativa↔realidad más grande del repo. | ✅ Sí: documentar + **caso de contrato** ("un deny no afecta a `hasRole`" — pinnearlo explícitamente es mejor que arreglarlo: `hasRole` responde *"¿tiene este rol?"*, no *"¿puede?"*) y **deprecar `appAccess({ role })`**. La forma `hasRole(s, {slug, scopeType}, scope)` es además prerrequisito de C (roles homónimos). **Semver: deprecación = minor; quitar `{role}` = major.** |
| **L0.7** Truncamiento silencioso en `listObjects` | ✅ **existe, y es peor de lo descrito** | `openfga_driver.ts:633-639` (`listBindings`) y `:670-674` (denies) no paginan; **verificado: 1200 tuplas → 1000 resultados, respuesta sin ninguna señal**. Consecuencia real y grave: en `listScopes` (`:663-693`) los **denies truncados** hacen que un scope denegado se devuelva como concedido = **fail-open**. Ninguno de los 67 tests lo ve. **Y falta**: `listSubjects` (`:616-621`) usa `listUsers`, que también trunca a 1000 (`--listUsers-max-results`). | ❌ **La corrección propuesta no es implementable**: `ListObjects` no tiene `continuation_token` (verificado en el SDK y en el issue upstream). **Corrección correcta:** para el modelo que genera este paquete —todas las relaciones son directas (`:147-165`)— sustituir **las tres** llamadas de enumeración por el **API `Read` paginado** (`user` + `object: '<tipo>:'`, `page_size`, `continuation_token`, verificado funcionando). Da enumeración **exacta y completa**, sin tope y sin deadline, y permite filtrar la caducidad leyendo `condition.context.valid_until` (que ya se sabe leer, `:543`). Contrapartida a documentar: `Read` **no expande** relaciones computadas, así que si un tercero extiende el modelo con relaciones derivadas sobre `role_binding`, esta enumeración las ignoraría → el driver debe declararlo. Alternativa peor pero válida: `streamedListObjects` (verificado 1200/1200) y aceptar el deadline sin señal. **`RelationsResultTruncatedError` sigue haciendo falta** para `relations/`, donde sí hay `includes` que exigen evaluación del modelo. |
| **L0.8** Modelos exportados de solo lectura | ✅ **existe** | `index.ts:291-295` exporta los cinco modelos Lucid; `AuthzAssignment.create()` salta el catálogo, la idempotencia y (si entra) `assertWrite`. | 🟡 **Sí, pero no como "readonly"**. Quitar `create/save/delete` de un modelo Lucid es frágil (herencia, `query().update()`, `db.table()` sigue ahí) y da falsa seguridad: **la puerta trasera real no es el modelo, es `db.from('authz_assignments')`**, que no se puede cerrar. Mejor: (a) documentar los modelos como "lectura/relaciones/joins", (b) mantenerlos exportados (el consumidor los necesita para `preload`), y (c) poner la garantía donde sí se puede: **un `CHECK`/trigger no; un caso de contrato tampoco**. Sinceramente: esto es documentación, no mecanismo. Bajarlo a prioridad mínima. |

**Resumen D:** 8/8 defectos **existen** (7 con daño real, L0.8 es de higiene). **6 correcciones son
correctas tal cual (L0.1–L0.6)**, **L0.7 hay que rehacerla** (el mecanismo propuesto no existe en
OpenFGA) y **L0.8 hay que rebajarla**.

### E · L1 primitivas

| Primitiva | Veredicto | Razón |
|---|---|---|
| `within`/`isWithin`/`requireWithin` | ✅ **entra** | Pasa la prueba de vocabulario (contención en la cadena, no "tenant"). Factible: `isWithin(a,b)` es `chain(b).some(...)`, ya existe la maquinaria (`database_driver.ts:55-57`). `GrantOptions.within?` es aditivo (`types.ts:65-68`) ⇒ **minor**; `requireWithin: true` por defecto ⇒ **major** (2.0), como dice el documento. |
| `authorizedScopes → all\|some\|none` | ✅ **entra, y es la primitiva de más valor de toda la lista** | Es la única respuesta honesta a "dame los departamentos donde puede X": hoy el consumidor usa `listScopes`, que por contrato **no enumera herencia** (`types.ts:114-119`) — o sea, la respuesta correcta con la pregunta equivocada. El tri-estado `all` (grant en la raíz) evita materializar el árbol entero. Que **lance** sin `descendantsOf` y al superar `maxScopes` es lo correcto: una lista incompleta de scopes autorizados es fail-open. **Minor** (no toca el puerto del driver si se construye **sobre** `authorize`/`listScopes`). |
| `descendantsOf` como **puerto del consumidor** | ✅ **entra** | Correcto: el paquete no conoce el árbol (invariante 1 de CLAUDE.md). Prohibirlo dentro de `authorize`/`listScopes` ✅ (si no, `authorize` pasa de O(cadena) a O(subárbol)). |
| `hierarchicalScopeResolver({parentOf, maxDepth:64})` | ✅ **entra** | Helper opt-in, anti-ciclos, cota que **lanza** (truncar la cadena perdería el deny de la raíz = fail-open ✅ correcto). No mete dominio: `parentOf` lo escribe el consumidor. |
| `memoizeAncestors(resolver, {ttl:'request'})` | 🟡 **entra con cuidado** | Memoizar **ancestros** (no decisiones) es correcto y hoy hace falta: `listScopes` llama a `chain()` **una vez por fila** (`database_driver.ts:357`, `openfga_driver.ts:689`) — N+1 puro. **Pero** `ttl:'request'` implica `AsyncLocalStorage` o un `ctx` que el paquete no tiene; un `Map` global con TTL temporal es un **caché de autorización con invalidación por reloj**, justo lo que el CHANGELOG evita. Recomendación: `memoizeAncestors(resolver)` que devuelve un resolutor **con memoria de una sola llamada** (se instancia por request en el config del consumidor, que sí tiene el ctx). El paquete ofrece la función pura; el ciclo de vida es del consumidor. |
| `listDenies(subject, scope?)` | 🟡 | Útil (hoy no hay forma de saber qué denies tiene alguien: no está en el puerto, `types.ts:70-120`). Pero **es un método nuevo del driver** ⇒ rompe drivers de terceros salvo con `level` en el juez. Y en openfga hereda el problema de enumeración de L0.7 (se resuelve con `Read` paginado). |
| `effectivePermissions(subject, scope)` | ✅ **entra — pero NO como método del driver** | Se compone: roles vigentes en la cadena + join al catálogo local (que existe con **ambos** drivers, invariante de higiene 2) − denies. **Composición sobre el puerto actual ⇒ cero impacto en drivers de terceros ⇒ minor limpio.** Es prerrequisito de C (techo de permisos al delegar), así que va antes. |
| `authorizeMany(subject, permission, scopes[])` | ✅ **entra como composición con override opcional** | Default: `Promise.all` de `authorize` (funciona con cualquier driver de tercero, sin romper nada). Un driver **puede** implementarlo mejor (en openfga es un `batchCheck` natural, `:379-392`). Patrón: `interface AuthorizationDriver { authorizeMany?(...) }` opcional + fallback en el manager. **Minor.** |

> **Recomendación transversal nº2 (sale de aquí y aplica a todo L1):** las primitivas nuevas se
> añaden **al manager como composiciones sobre el puerto existente**, con `?` opcional en el driver
> para que quien pueda las optimice. Así L1 entero es **minor** en vez de major. Lo único que
> obliga a tocar el puerto es `listDenies`, y por eso lo dejaría para 1.3.

### F · L2 · Módulo `http/` con `resourceAccess(...)`

**Veredicto: 🟡 entra con cambios — y probablemente NO ahora (ver J.1).**

- **Factibilidad ✅**: no existe nada parecido hoy (❌ `src/middleware/` solo tiene
  `app_access_middleware.ts`, atado a `APP_SCOPE`). El diseño propuesto es correcto y respeta la
  pureza: **`load()` y `gate()` los escribe el consumidor**, el paquete nunca carga un modelo.
- ✅ **El orden 401 → 403 → 404 → 404 es correcto y es la parte valiosa**: devolver **404 y nunca 403**
  cuando el recurso no está en el contenedor del actor cierra el oráculo de existencia. Es
  exactamente lo que se rechaza en III.2 para `scopeOf` y se aplica bien aquí.
- ✅ **`AuthorizationBackendError` nunca disfrazado de 404**: coherente con el invariante 5.
- 🟡 **Vocabulario**: `tenantParam` **no pasa la prueba 1** (el propio doc rechaza "tenant" en III.2).
  Renombrar a `containerParam` + `containerScope`, o reutilizar el nombre que ya se elige en E:
  `withinParam`. Un consumidor con `project → task` lo entiende igual.
- 🟡 **`resources` como registro con clave**: el `resourceAccess({resource:'space'})` obliga a un
  registro global de recursos en el config. Alternativa más maleable y con menos indirección: pasar
  el `load` directamente en las opciones del middleware. El registro solo gana cuando el mismo
  recurso se usa en 5 rutas — regla de tres: **empezar por el `load` inline**.
- **Semver: minor** (subpath nuevo + middleware nuevo; nada del contrato cambia).
- **Steelman de lo contrario (y creo que gana hoy):** un middleware HTTP es la pieza **más** acoplada
  al estilo del consumidor (formato de errores, forma del ctx, guardas, i18n) y la **menos** costosa
  de escribir en el consumidor (~2 d según el propio doc). III.3 ya manda `load`, `gate`,
  `descendantsOf` y "formato de errores HTTP" al consumidor: lo que queda en el paquete es
  esencialmente *el orden de cuatro `if`*. **Eso no es un módulo, es un párrafo del README + un test
  de referencia.** Recomendación: escribirlo en COGNITIV, y **promoverlo al paquete cuando exista un
  segundo consumidor** que lo pida (regla de tres). Si aun así entra ya, que entre **sin registro de
  recursos** y con nombres neutrales.

### G · L3 hooks

| Pieza | Veredicto | Razón |
|---|---|---|
| `AuthzWriteEvent.actor` + `requireActor` | ✅ **entra** | Hoy el evento no lleva actor (`types.ts:137-146`) ⇒ la auditoría del consumidor no puede saber **quién** concedió. Factible y aditivo. **Condición**: el actor entra **explícito** por `GrantOptions.actor?: SubjectRef`, nunca por `AsyncLocalStorage` mágico (rompería la pureza y los jobs). `requireActor: true` en config ⇒ el manager lanza si falta: eso convierte "hay que acordarse" en mecanismo. **Minor.** |
| `assertWrite(event)` puro, fail-closed, en ambos drivers | 🟡 **entra, pero hay que resolver una contradicción del documento** | III.2 **rechaza** "`beforeWrite` unificado" y III.1-L3 **acepta** `assertWrite`, que es un beforeWrite unificado con otro nombre. Mi lectura: lo que hay que rechazar es un hook **con I/O** en la ruta de escritura (abre latencia, transacciones implícitas y un `catch` que se traga políticas). Lo que sí entra: **una función pura y síncrona que solo puede lanzar**, documentada como *policy*, sin acceso a base de datos. Con esa definición ✅ entra, y es **imprescindible para `relations/`** (`assertObjectInPartition` sin hook ⇒ el paquete se niega a escribir). Ponerlo **en el manager**, no en cada driver: así se cumple por construcción para drivers de terceros y **no** rompe el contrato. |
| `onWriteInTrx(event, trx)` **solo** `database` | 🟡 | Fallar en **boot** al registrarlo con `openfga` es la decisión correcta (el fallo es visible al cambiar de driver, no en producción). Pero el paquete **no controla el boot**: se hace en la factory del driver / al construir el manager. |
| `{trx}` en `GrantOptions`, rechazada por `openfga` | 🟡 **es la exigencia que más tensiona la filosofía** | **Choca de frente con el invariante de higiene 5** (*"un cambio de driver es migración de hechos, no reescritura"*): un consumidor que pase `{trx}` en 40 call-sites **no puede** cambiar a `openfga` sin reescribirlos. Verificado que hoy no existe: `database_driver.ts:159` escribe con `db.table(...)` global. **Recomendación**: (a) el driver **declara** su capacidad (`supports.transactions`), (b) el config declara lo que el consumidor **exige** (`requireTransactionalWrites: true`), (c) si el driver activo no la tiene, **el manager falla al construirse** — no en el call-site, no en producción. Así el precio del cambio de driver se paga en el `.env`, en el arranque, con un mensaje que dice exactamente qué se pierde. Y el juez tiene un caso: *"con `supports.transactions:false`, `grant(...,{trx})` lanza"*. Con eso, `{trx}` deja de romper la promesa: **la promesa pasa a ser "cambiar de driver es migrar hechos, o el arranque te dice por qué no"**. Eso sí lo puedo defender en un README. |

- **Semver: minor** (todo aditivo) **si** `assertWrite` va en el manager y `{trx}` es capacidad
  declarada. **Major** si se exige `assertWrite` a los drivers.
- **Steelman de lo contrario**: "los hooks son la puerta por la que se cuela el dominio en el motor;
  cada hook nuevo es una API que hay que mantener para siempre". Cierto — por eso `assertWrite` debe
  ser **puro y sin I/O** por contrato, y por eso `onWrite` (post-escritura, se traga fallos,
  `manager.ts:114-120`) debe quedarse **exactamente como está**, como pide el documento.

### H · L4 `assignableAt` + `authz:catalog:diff`

**Veredicto: ✅ entran los dos. Es el lote de mejor relación valor/riesgo del informe.**

- `assignableAt` como **control de composición** (¿en qué niveles puede un rol llevar este permiso?)
  y **nunca** como barrera de evaluación: ✅ correcto y crítico. Si se evaluara en `authorize`
  rompería el invariante 1 (*"un grant en un scope vale en todos sus descendientes"*), que es la
  identidad del paquete. El aviso en el README es obligatorio, no opcional.
- `authz:catalog:diff` que falla en CI: ✅ **cierra un agujero real y verificado**. `syncAuthzCatalog`
  es **estrictamente aditivo**: inserta vínculos rol→permiso (`catalog.ts:92-110`) y **nunca borra**.
  Quitar un permiso de un rol en `config/app_acl.ts` **no le quita el permiso a nadie**, y hoy nada
  lo avisa. Un comando que compare config vs tablas y salga con código ≠ 0 es ~80 líneas
  (el patrón de comando ya existe, `commands/openfga_provision.ts`).
- **Semver: minor** (comando nuevo + campo opcional en `CatalogRoleSpec`, `types.ts:154-170`).
- **Steelman de lo contrario**: "el diff es responsabilidad del consumidor (su CI, su config)". Pero
  el que sabe que el sync es aditivo es el paquete; dejar que cada consumidor lo redescubra por un
  incidente es exactamente la brecha narrativa↔realidad que hay que cerrar.

### I · Los rechazos de III.2

| Rechazo | ¿De acuerdo? | Argumento |
|---|---|---|
| `resourceScopes` / `scopeOf(tipo, uuid)` en el motor | ✅ **De acuerdo, sin matices** | Obligaría al paquete a saber en qué tabla vive cada recurso y a leerla: rompe la pureza (`check_purity.mjs`), crea un **oráculo de existencia** y, sin tenant, cruza inquilinos. Es el rechazo mejor argumentado del documento. |
| Carga de recursos por el paquete | ✅ De acuerdo | Misma raíz. `load()` del consumidor es la costura correcta. |
| "membresía"/"tenant" como conceptos del paquete | ✅ **De acuerdo — y hay que aplicarlo**, porque C y F los reintroducen por la puerta de atrás (`tenantParam`, `createTenantRole`, `tenantAssignablePermissions`). Renombrar. |
| `beforeWrite` unificado / `onWrite` transaccional | 🟡 **De acuerdo a medias** | `onWrite` transaccional: ✅ rechazar (metería I/O del consumidor dentro de la transacción del motor). `beforeWrite`: el rechazo es **incompatible con aceptar `assertWrite`** en el mismo documento. Hay que quedarse con una sola formulación: *hook previo puro, sin I/O, que solo puede lanzar* — sí; *hook previo con I/O* — no. |
| `descendantsOf` implementado por el paquete sobre `parentOf` | 🟡 **De acuerdo como default, no como prohibición** | Hay una **asimetría injustificada**: el documento acepta `hierarchicalScopeResolver({parentOf})` (el paquete recorre hacia **arriba**) y rechaza el equivalente hacia **abajo**. La diferencia real no es de pureza sino de coste: hacia arriba son ≤64 saltos, hacia abajo es un subárbol sin cota. ⇒ Rechazar el **default automático** ✅, pero ofrecer un helper **opt-in** `sqlDescendantsOf({ table, uuidColumn, parentColumn, maxNodes })` que genera la CTE recursiva — mismo patrón que el `relationPartitionTrigger` que sí aceptan (el paquete **genera SQL**, no conoce el dominio). Con el mismo aviso de portabilidad de dialecto. |
| `permission.grantableAt` en la evaluación | ✅ **De acuerdo, rotundamente** | Rompería el invariante 1. Su lugar es `assignableAt` (ítem H), en composición. |
| Middleware de `roles/` consultando `relations/` | ✅ De acuerdo | Es la frontera del §0.2; si se cruza en el middleware, la separación "por construcción" es decorativa. |
| `from` / ABAC en v1 | ✅ De acuerdo | "Imposibilidad verificable" > "promesa". Aditivo después. |
| Deny con caducidad → 1.3 | ✅ De acuerdo **con un aviso** | Cuando entre, hay que enviar `context` en los **dos** sitios que hoy consultan denies sin él (`openfga_driver.ts:441-445` y `:670-674`) o esas llamadas empezarán a devolver 400 → 503 (verificado en §0). |

**¿Alguno debería entrar?** Sí, uno: **el helper opt-in `sqlDescendantsOf`** (como acabo de razonar).
Ninguno de los otros.

### J · Las 8 preguntas de III.6 — mi recomendación como dueño del paquete

1. **¿Habrá un segundo consumidor real en los próximos meses?**
   **Esta es LA pregunta estratégica que decide la técnica, y no la puedo contestar yo — pero sí puedo
   decir qué depende de ella.** Mi recomendación: **asumir que NO**, y actuar en consecuencia:
   **L0 se hace igual** (son defectos, no features); **L1 entra** porque son primitivas de motor puro
   que ya usa COGNITIV mal (`listScopes` en caminos calientes); **L2 `http/` NO entra todavía** — se
   escribe en COGNITIV y se promociona por regla de tres. Con un solo consumidor, un middleware en el
   paquete es una API pública que hay que mantener para siempre a cambio de ahorrar 2 días una vez.
2. **¿1.2 puede ser breaking?** **No.** Dato: el paquete tiene **575 descargas el último mes**
   (npm API, verificado) — mayormente mirrors/bots, pero es público y no es verificable que nadie lo
   use. Plan: **1.2 = todo aditivo + fail-closed detrás de flags con default = comportamiento actual**
   (`expiryMode`, `strictScopes`, `requireWithin`, `requireActor`); **2.0 = voltear los defaults**, con
   los flags ya rodados y documentados. Además, con el `level` del juez (recomendación transversal
   nº1) los drivers de terceros no se rompen en ninguna de las dos.
3. **¿`ScopeRef.uuid` es uuid (validar) o string (ampliar columnas)?**
   **Uuid, y validarlo.** Razón: las columnas publicadas ya lo imponen (`stubs/migration.stub:82`
   `table.uuid('scope_uuid')`, `:69` `holder_uuid`) y **en PostgreSQL ya rechazan** cualquier otra
   cosa, mientras SQLite/MySQL la aceptan: hoy el paquete **ya** se comporta distinto según el motor,
   y eso es peor que cualquiera de las dos opciones. Validar en el paquete unifica el comportamiento
   y **elimina el 500 en lectura**. Aflojar a `string` más adelante es aditivo; apretar no lo es.
   Sobre anunciar MySQL/SQLite: se puede seguir anunciando **si** hay un caso de contrato por motor;
   si no, quitarlo del README es más honesto que mantenerlo por marketing.
4. **¿Se sostiene "un solo juez para los dos drivers"?** **Sí, y hay que reforzarlo, no bifurcarlo.**
   La paridad no es "hacen lo mismo", es **"dan la misma respuesta observable o se niegan
   explícitamente"**. Con `supports: { transactions, denyExpiry, exactEnumeration }` el juez exige a
   quien no tiene la capacidad que **lance** (nunca que la ignore ni la simule a medias). Un contrato
   bifurcado por driver deja de ser un juez y pasa a ser dos suites que se parecen.
5. **¿CI con un segundo OpenFGA de `--listObjects-max-results` pequeño?** **Sí, y es barato**: un
   segundo servicio en el compose de CI con `--listObjects-max-results=5` (nombre de flag verificado)
   y una variable `OPENFGA_TINY_URL`. Sin él, el test del truncamiento de denies **no se escribe** y
   el fail-open de L0.7 vuelve. Nota: si se adopta la ruta `Read` paginado que propongo en D-L0.7,
   este servidor sigue haciendo falta — precisamente para demostrar que **ya no** trunca.
6. **¿`assertWrite` obligatorio cuando el consumidor declara recursos o roles locales?**
   **Obligatorio en `relations/`** (sin él, la contención objeto↔partición no es verificable por
   nadie: no hay FK posible sobre una tabla polimórfica; el paquete debe **negarse a escribir**).
   **Opcional en `roles/`** (ahí la contención se cubre con `within`, que es declarativo y no
   requiere código del consumidor). Regla: *el hook es obligatorio solo donde el motor no puede
   comprobar el invariante por sí mismo*.
7. **¿El README promete algo que el código no hace?** **Sí, dos cosas verificadas:**
   (a) **README:36** *"Explicit deny wins... blocks the permission"* frente a `hasRole` sin denies
   (`database_driver.ts:208-224`, `openfga_driver.ts:565-577`) **y el propio middleware del paquete
   usando `hasRole`** (`app_access_middleware.ts:229`). Hay que acotar la frase a `authorize` y decir
   explícitamente que `hasRole` **no** es una decisión de acceso.
   (b) El README no advierte que, con driver `openfga`, `listScopes`/`listSubjects`/`listRoles`
   **truncan en silencio a 1000** (verificado). Mientras no se arregle, es una omisión que produce
   fail-open. Corolario: **arreglar L0.7 antes de tocar el README, o el README tendrá que confesar
   un fail-open.**
8. **¿Un permiso puede reservarse a un nivel aunque rompa la herencia hacia abajo?**
   **No.** Es la pregunta de producto que sostiene la arquitectura entera: si un permiso puede "no
   heredar", `authorize` deja de ser *"¿hay un grant en mi cadena?"* y pasa a ser un evaluador de
   excepciones por permiso — adiós al invariante 1, adiós a la equivalencia entre los dos drivers y
   adiós a la simplicidad que hace este paquete defendible. La necesidad real ("que un rol de unit no
   pueda llevar `org.settings.write`") se cubre **al componer el rol** (`assignableAt`, ítem H) y **al
   delegar** (`delegablePermissions`, ítem C). Si algún día hay que romperlo, que sea 2.0 y con otro
   nombre de método.

### K · Estimación y orden

**Veredicto sobre la estimación: 🟡 el rango base es razonable; el total con todo es optimista, y el
orden está invertido en dos puntos.**

- **14–16 d de base**: creíble **si** no se mueven archivos (ítem A) y **si** `catalog/` va con el
  binding id por uuid (que quita trabajo de parseo, no lo añade, pero **suma** un comando de
  migración de hechos: **+0,5 d** no contemplado).
- **Lo que falta en la estimación** (todo verificado como necesario arriba):
  - **Capacidades/`level` en el juez** (recomendación transversal nº1): **+1 d**. Es lo que evita que
    todo esto sea 2.0.
  - **L0.7 por la ruta `Read` paginado**: es más trabajo que "añadir un token" — hay que reescribir
    3 enumeraciones y filtrar caducidad en cliente: **+1 d** sobre lo estimado.
  - **`relationPartitionTrigger` por dialecto** (o el throw explícito en los no soportados): **+0,5 d**.
  - **CI con el segundo OpenFGA**: **+0,5 d**.
  ⇒ **Base realista: 16–18 d. Con todo: 29–33 d**, no 27–29. Y eso sin contar que el bloque
  "suite real (5 d)" del tester es, en mi experiencia, el que más se desborda.
- **Lo que quitaría** (compensa buena parte de lo anterior): **L2 `http/` (−1,5 d)** a COGNITIV;
  **L0.8 (−0,5 d)** a documentación; **L3 aplazado** como ya propone el documento (−2 d).
- **Orden: dos cambios.**
  1. El documento pone *"reestructurar en módulos (1,5 d)"* **antes** de escribir `catalog/` y
     `relations/`. **Lo invierto**: la estructura se descubre escribiendo el segundo módulo. Primero
     `catalog/` como subpath nuevo (que es la pieza pequeña y el ensayo real), luego se consolida.
  2. Los "spikes de FGA (0,5 d)" **ya están hechos** (§0) → −0,5 d y desbloquean `relations/` hoy.
- ✅ **"T2 no espera al paquete"**: de acuerdo al 100%, y es la decisión más sana del documento.
  Corolario que suscribo: **cero cambios al paquete durante T2**.

---

## 3. Tabla resumen

| Ítem | Veredicto | Semver (drivers de 3.º) | Riesgo principal |
|---|---|---|---|
| **A** módulos opt-in + frontera por construcción | 🟡 entra con cambios (no mover archivos, no tocar export raíz) | **minor** (major si se mueven rutas) | Reestructurar antes de tener el 2.º módulo = diseño especulativo |
| **B** `relations/` | ✅ entra (partición = `APP_SCOPE` para mono-tenant; enumeración por `Read`/streaming; trigger por dialecto) | **minor** | Duplica la superficie de test para un único consumidor; deadline de 3 s sin señal |
| **C** `catalog/` roles locales | 🟡 entra con cambios (binding id **por uuid de rol**, no 4 partes; renombrar `tenant*`) | minor en API / **major operativo** (índice único + ids FGA ⇒ migración de hechos) | Id de 4 partes ambiguo (`parseBindingId` parsea por conteo); a medias es peor que un prefijo de slug |
| **D-L0.1** `whereScopeIn([])` | ✅ entra (mejor: lanzar en escritura, `[]`/`false` en lectura) | patch/minor | Fail-open latente en cuanto exista `descendantsOf` |
| **D-L0.2** `holderTypes` inyectivo | ✅ entra (en el constructor del driver) | **minor** | `listSubjects` miente ⇒ revocación en bucle deja asignaciones vivas |
| **D-L0.3** `UnknownScopeError` | ✅ entra (throw en 1.ª llamada, no "en boot") | **major** sin `level` en el juez; minor con él | Cambia el resultado de `authorize` para scopes borrados |
| **D-L0.4** semántica de `expiresAt` | ✅ entra (con flag `expiryMode` en 1.2, flip en 2.0) | **major** (cambia un caso existente del juez, `contract.ts:177-192`) | Semántica observable distinta con el mismo código de llamada |
| **D-L0.5** `assertIdentityComponent` + longitudes | ✅ entra | **minor** | Hoy un 400 de FGA se disfraza de 503; divergencia PG vs SQLite/MySQL |
| **D-L0.6** `hasRole` no decide acceso | ✅ entra (documentar + caso + deprecar `appAccess({role})`) | minor (deprecación) / major (retirada) | **El README promete "deny wins" y el PEP del propio paquete lo ignora** |
| **D-L0.7** truncamiento silencioso | ✅ entra **con otra corrección**: `Read` paginado (o streaming), **no** `continuation_token` en `ListObjects` (no existe) | **minor** (interno del driver) | **Fail-open real y ya presente**: denies truncados ⇒ scope denegado devuelto como concedido. Afecta también a `listSubjects` (`listUsers`, 1000) |
| **D-L0.8** modelos de solo lectura | 🟡 baja a documentación | patch | Falsa sensación de cierre: `db.from('authz_assignments')` sigue abierto |
| **E** primitivas L1 | ✅ entran **como composiciones sobre el puerto** (`listDenies` a 1.3) | **minor** (major solo si se toca el puerto) | `memoizeAncestors` con TTL global = caché de decisiones por la puerta de atrás |
| **F** `http/` | ➡️ **va al consumidor hoy**; 🟡 entra tras el 2.º consumidor | minor cuando entre | Es "el orden de cuatro `if`" + el formato de errores, que ya se manda al consumidor |
| **G** hooks L3 | 🟡 entran (`assertWrite` **en el manager**, puro y sin I/O; `{trx}` como **capacidad** que falla en boot) | **minor** así; major si se exige a los drivers | `{trx}` tal cual propuesto **rompe** "cambiar de driver no es reescribir" |
| **H** `assignableAt` + `catalog:diff` | ✅ entran los dos | **minor** | Que `assignableAt` acabe evaluándose en `authorize` (rompería el invariante 1) |
| **I** rechazos de III.2 | ✅ de acuerdo con 7 de 9; 🟡 dos matices (`beforeWrite` vs `assertWrite`; `descendantsOf` helper opt-in) | — | Contradicción interna del documento en `assertWrite` |
| **J** 8 preguntas | respondidas arriba | — | La nº1 (segundo consumidor) decide L1+L2 |
| **K** estimación 14–16 / 25–29 | 🟡 realista la base, optimista el total: **16–18 / 29–33**, menos lo que se saque | — | El orden pone la reestructuración antes del segundo módulo |

---

## 4. Fases propuestas y camino crítico

**Camino crítico = `level`/capacidades en el juez.** Todo lo demás cuelga de ahí: sin esa pieza,
cada mejora es un major y no hay ruta incremental. Es 1 día y desbloquea ~20.

| Fase | Qué entra | Resultado demostrable al final | Días |
|---|---|---|---|
| **0 · Desbloqueo** | `level` + `supports` en `runAuthorizationDriverContract`; segundo OpenFGA de CI (`--listObjects-max-results=5`) | Un driver de tercero de 1.1.0 sigue pasando **sin tocar nada**; existe un entorno donde el truncamiento es reproducible | **1,5** |
| **1 · L0 defectos (1.2, todo aditivo o tras flag)** | L0.1, L0.2, L0.5, L0.6 (doc+caso+deprecación), **L0.7 por `Read` paginado** (las 3 enumeraciones), L0.3 y L0.4 detrás de flag con default actual | Un test rojo→verde por cada fail-open; el README deja de prometer de más | **4** |
| **2 · Primitivas de motor (1.2)** | `isWithin`/`within`, `effectivePermissions`, `authorizeMany`, `authorizedScopes` + puerto `descendantsOf` del consumidor, `hierarchicalScopeResolver`, `memoizeAncestors`, helper `sqlDescendantsOf` | COGNITIV puede responder "X en su departamento" **sin** `listScopes` ni CTE incrustada | **3,5** |
| **3 · `catalog/` (1.3)** | `owner_scope_key`, resolución por owner ∈ chain ∪ global, **binding id por uuid de rol** + comando de migración de hechos, `purgeRole`, `defineScopedRole` con policy, `onCatalogWrite`, `assignableAt`, `authz:catalog:diff`, exportar `assertValidSlug` | Un tenant define su rol, no puede inventarse permisos ni superar su rango, y borrarlo no revive nada | **3,5** |
| **4 · `relations/` (1.4)** | Puerto + modelo declarativo + driver `database` (`{trx}` como capacidad) + driver `openfga` (fusión de modelos, prefijo de partición, enumeración honesta) + ~28 casos × 2 + `assertWrite` en el manager + `actor` | La misma suite pasa contra los dos drivers; el caso "Drive" y el caso "llaves" se modelan **sin un `if`** | **9** |
| **5 · Consolidación** | Estructura definitiva de módulos, `configure` interactivo, stubs/migraciones separadas, README de 3 módulos + guía de upgrade | `node ace configure` deja instalar solo lo que se usa | **2,5** |
| **6 · Diferido** | `http/` (si aparece 2.º consumidor), `listDenies`, deny con caducidad, `from`, L0.8 | — | — |

**Total fases 0–5: ~24 d.** Fuera del paquete y en paralelo: **T2 en COGNITIV con los seams de §6**
(3,5 d) y el swap posterior (1–1,5 d).

**Decisiones que hay que tomar antes de la fase 3** (no las puedo tomar yo):
- ❓ **¿Habrá un segundo consumidor?** → decide si `http/` entra y si `relations/` se diseña para dos
  casos o para uno.
- ❓ **¿1.2 puede romper?** → mi recomendación es que no; si la respuesta fuera "sí", L0.3/L0.4/L0.6
  se simplifican bastante y se ahorra ~1 d de flags.
- ❓ **¿Se acepta migrar los ids de las tuplas FGA a uuid de rol?** → sin eso, `catalog/` arrastra un
  parseo ambiguo para siempre.

---

## 5. Recomendación en una frase

**El documento está bien pensado en lo grande (tres módulos con frontera por construcción y `relations/`
con partición obligatoria: suscrito), pero antes de escribir una línea de `relations/` hay que hacer dos
cosas que no están en su plan: dar niveles/capacidades al juez —o todo esto es 2.0— y rehacer L0.7,
porque `ListObjects` no tiene `continuation_token` y hoy el paquete tiene un fail-open real y
demostrable en los denies.**

**Siguiente paso concreto:** aprobar la **fase 0 (1,5 d)** y, en paralelo, contestar la única pregunta
que cambia el alcance: **¿va a haber un segundo consumidor real del paquete en los próximos meses?**
Si la respuesta es "no", `http/` sale del plan hoy y se recuperan 1,5 días.

---

### Anexo · Cómo se verificó (reproducible)

- Código: lectura directa de `src/**` en `/home/jose/proyectos/Personal/adonis-authz` (v1.1.0, `252ea8c`).
- `whereScopeIn([])`: construcción de la query con el `knex` del propio repo → SQL sin cláusula de scope.
- OpenFGA: servidor local `:8101` (**v1.19.0**, defaults). Store temporal creado y **borrado** al terminar.
  - Modelo con `directly_related_user_types: [{type:'unit', relation:'member', condition:'not_expired'}]` → aceptado.
  - `check` con `valid_until` futuro/pasado sobre tupla de userset → `true`/`false`.
  - 1200 tuplas: `list-objects` → 1000 (sin señal); `streamed-list-objects` → 1200.
  - `read` con `object:'ia_spaces:'` + `page_size:50` → 50 + `continuation_token`.
  - Escrituras con `user` malformado (`#`, `:`, `*`) → `400 validation_error`; `user:a|b` → aceptado.
  - Flags confirmados: `--listObjects-max-results` (1000), `--listUsers-max-results` (1000),
    `--listObjects-deadline` (3s), `--max-tuples-per-write` (100).
- SDK instalado: `node_modules/@openfga/sdk/dist/apiModel.d.ts:783-839` (ListObjects sin paginación),
  `:1143-1167` (Read con paginación), `:1243-1268` (`RelationReference` admite `relation` + `condition`),
  `dist/client.d.ts:298` (`read` con `PaginationOptions`), `:438` (`streamedListObjects`).
- npm: 575 descargas el último mes (`api.npmjs.org/downloads/point/last-month`).
