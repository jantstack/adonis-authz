# Fase 3b · Lote 6 — los dos defectos que el panel 3 declaró independientes del `freeze()`

**Fecha:** 2026-08-31 · **Rama:** `v2/fase-3b` · **Base:** `e4a5102` (árbol limpio al empezar)
**Alcance:** P1 (🔴 3 del auditor / §1 de los innegociables del juez) y P2 (§3 del juez).
**Fuera de alcance, y no tocado:** el diseño de `freeze()` (opciones A/B/C/D/E) — sigue en decisión
del dueño. Lo único que se tocó de él es la CONDICIÓN de `dryRun` que el juez dictaminó.
**Sin commits** (los hace el dueño).

---

## Resumen

| | Qué era | Qué es ahora |
|---|---|---|
| **P1** | El origen se leía en DOS barridos sueltos (`authz_assignments`, luego `authz_denies`), cada página sobre el `db` global. Un offboarding completo caído en el hueco dejaba el destino con **el rol sin su deny**, concediendo lo que ni el estado anterior ni el posterior concedían, con `clean=true` | Los dos barridos van en **UNA transacción de lectura repetible** (`withSourceSnapshot`). El peor resultado de la ventana es «el estado consistente de `t0`»: deriva recuperable, no un estado inventado |
| **P2** | `manager.reconcile` envolvía la pasada en `withFrozenWrites` **siempre**, sin mirar `options.dryRun` | `--dry-run` **no congela**; la pasada que escribe sigue congelando |

Ficheros tocados: `src/drivers/openfga_driver.ts`, `src/manager.ts`, `commands/authz_reconcile.ts`,
`tests/reconcile.spec.ts`, `README.md`, `CHANGELOG.md`, `CLAUDE.md`.

---

## P1 · La migración fabricaba un permiso

### La reproducción del auditor, FALLANDO ANTES (salida literal)

Caso nuevo `3b-6 · foto consistente del origen (servidor real + segundo escritor) / el offboarding
COMPLETO entre los dos barridos no FABRICA un permiso en el destino`, contra el `:8101` real y PG,
comparando con el driver `database` en paralelo sobre el mismo árbol y el mismo catálogo:

```
❯ 3b-6 · foto consistente del origen (servidor real + segundo escritor) / el offboarding COMPLETO entre los dos barridos no FABRICA un permiso en el destino

- Expected  - 1
+ Received  + 1

- false
+ true

ℹ AssertionError: la migración FABRICÓ un permiso que nadie concedió (reporte: written=13 extra=0 skipped={}): expected true to be false

 ⁃ at Assert.isFalse (node_modules/@japa/assert/build/index.js:125:19)
 ⁃ at Object.executor (tests/reconcile.spec.ts:2133:14)

 FAILED

Tests  1 failed (1)
```

`written=13 extra=0 skipped={}` es **dígito a dígito** lo que midió el auditor
(`written=13 extra=0 deleted=0 skipped={} clean=true`).

Y el caso estructural que corre en los CUATRO motores, también rojo antes:

```
❯ 3b-6 · foto consistente del origen / los DOS barridos de `authz_*` leen por el MISMO cliente, y ese cliente es una transacción

- Expected  - 1
+ Received  + 1

- true
+ false

ℹ AssertionError: el origen tiene que leerse dentro de una transacción y llegó undefined: expected false to be true
```

### Los casos

Los dos viven en `tests/reconcile.spec.ts`, bajo la cabecera `3b-6 · El ORIGEN se lee en UNA foto
consistente (🔴 3 del panel 3)` (línea ~1960):

1. **`los DOS barridos de authz_* leen por el MISMO cliente, y ese cliente es una transacción`**
   (grupo `3b-6 · foto consistente del origen`). Estructural, **sin servidor y sin segundo
   escritor**: por eso corre en los cuatro motores, incluido el SQLite `:memory:` de `npm test`.
   Parchea `eachRow`, ejecuta `readSourceFacts` y afirma dos cosas: que el cliente que llega es una
   transacción (`isTransaction === true`) y que es **el mismo objeto** en los dos barridos.
   Mata dos mutantes: leer sin transacción (el código de hoy) y **una transacción por barrido**.
2. **`el offboarding COMPLETO entre los dos barridos no FABRICA un permiso en el destino`**
   (grupo `3b-6 · … (servidor real + segundo escritor)`). La reproducción del auditor, entera y
   **determinista**: el hueco entre barridos se hace observable parcheando `eachRow` para que, en
   cuanto termina `reconcile.assignments`, RR.HH. haga el offboarding desde **otra conexión** —
   `revoke` + `removeDeny`, dos escrituras de UNA operación de negocio. Sin `sleep` y sin carrera.
   Afirma: (a) el origen no concedía `docs:write` ni antes ni después; (b) el destino tampoco puede
   concederlo — ése es el criterio de aceptación; (c) lo que SÍ queda es el estado de `t0`
   (`docs:read = true` en el destino) y **una segunda pasada lo repara** (`deleted > 0`, paridad con
   `database`), que es la diferencia entre «atrasado» e «inventado».

   Detalle del montaje: la siembra lleva un segundo holder (`ada`) que **no** se va. Sin él, tras el
   offboarding `authz_*` se queda sin una sola fila de hechos y el `--prune` de la segunda pasada se
   niega con `E_AUTHZ_MASS_RECONCILE_REFUSED` — otro seguro, correcto, pero no lo que este caso mide.

### El código que lo puso verde

`src/drivers/openfga_driver.ts`:

- **`withSourceSnapshot(fn)`** (privado, nuevo): abre UNA transacción sobre la conexión del `db`
  global y le pasa el cliente a `fn`. El nivel de aislamiento se decide por dialecto (abajo). Lo que
  lance `fn` sale intacto (cada consulta ya pasa por `this.sql`); lo que falle al ABRIR o cerrar la
  transacción se clasifica aquí — 503 `AuthorizationBackendError` /
  `AuthorizationBackendTimeoutError`, operación `reconcile.snapshot` — para que un error crudo de
  knex no cruce la frontera del driver (invariante 5).
- **`readSourceFacts`**: los dos `eachRow` pasan a estar dentro de ese `withSourceSnapshot`.
- **`eachRow(client, operation, batchSize, build, handle)`**: el cliente llega **por parámetro y sin
  default**. Antes hacía `build(db)`, que es exactamente lo que hacía que dos barridos consecutivos
  fuesen dos fotos. Sin default a propósito: un call-site nuevo no puede reabrir el hueco por
  descuido.

Imports añadidos: `isAuthzError` (de `backend_guard.js`) e `isSqliteDialect` (de `sql_expiry.js`).

### La reproducción, SIN EFECTO DESPUÉS

```
[suite] motor SQL: pg (authz_test_eb8f4a51)
✔ (×59)
 PASSED
Tests  59 passed (59)
```

Y el mutante «una transacción POR barrido» (M2), puesto y quitado, mata los dos casos:

```
❯ 3b-6 · foto consistente del origen / los DOS barridos de `authz_*` leen por el MISMO cliente, y ese cliente es una transacción
ℹ AssertionError: los dos barridos tienen que compartir la MISMA foto: expected { Object (_events, _eventsCount, ...) } to equal { Object (_events, _eventsCount, ...) }
❯ 3b-6 · foto consistente del origen (servidor real + segundo escritor) / el offboarding COMPLETO entre los dos barridos no FABRICA un permiso en el destino
ℹ AssertionError: la migración FABRICÓ un permiso que nadie concedió (reporte: written=14 extra=0 skipped={}): expected true to be false
Tests  57 passed, 2 failed (59)
```

(Restaurado: 59 passed.)

---

## Qué garantiza cada motor sobre la lectura repetible

**No es lo mismo en los tres, y por eso se declara en vez de suponerse** (es el tipo de diferencia
que sacó a la luz la Fase 2.5). El paquete pregunta el dialecto (`isSqliteDialect`) y manda el nivel
solo donde significa algo:

| Motor | Qué se manda | Qué garantiza | Cómo se comprueba aquí |
|---|---|---|---|
| **PostgreSQL 18** | `BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ` (lo compone knex, `pg-transaction.js`) | La foto se toma en la primera sentencia de la transacción y no se mueve. Garantía del motor | El caso 2 corre en `test:pg` con el `:8101` |
| **MySQL 8.4 / InnoDB** | `SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;` + `BEGIN;` (el `begin` genérico de knex) | Lectura consistente fijada en la **primera consulta** de la transacción. REPEATABLE READ es el default de InnoDB, pero **el default es config del servidor**, no una promesa del paquete: por eso se manda explícito y no se hereda | El caso 2 corre en `test:mysql` con el `:8101` |
| **SQLite (better-sqlite3)** | **Nada**: no se le manda nivel | SQLite **no acepta** nivel de aislamiento (knex lo dice literalmente: *«sqlite3 only supports serializable transactions, ignoring the isolation level param»*, y avisa por el logger). Su transacción de LECTURA ya es una foto: en WAL el lector conserva su snapshot mientras un escritor confirma; sin WAL el escritor espera al lector | El caso 2 corre en `test:sqlite-file` (WAL, pool 2..5). En `:memory:` (pool 1/1) no cabe un segundo escritor: ahí corre solo el caso estructural |

Mandarle el nivel a SQLite «por uniformidad» habría metido un aviso del logger en cada pasada sin
comprar nada, así que se pregunta el dialecto. Es la misma forma que `lockCatalogForWrite` (3E · Q5).

### Y no se afirma de oídas: las dos garantías, MEDIDAS

Un sondeo directo contra los motores de esta máquina, con **la sesión configurada en READ
COMMITTED** (el servidor «mal configurado», que es donde la declaración explícita se gana el
sueldo), dos conexiones, y el escritor entrando **entre** los dos barridos:

**PostgreSQL 18** (`scratchpad/pg_rr.mjs`, base propia `authz_rr_probe`, creada y borrada):

```
BEGIN a secas                       → {"nivel":"read committed","primerBarrido":1,"segundoBarrido":99}
BEGIN ... REPEATABLE READ (knex)    → {"nivel":"repeatable read","primerBarrido":1,"segundoBarrido":1}
```

**MySQL 8.4** (`scratchpad/mysql_rr.mjs`, misma forma; `SET SESSION TRANSACTION ISOLATION LEVEL READ
COMMITTED` primero, y luego el `SET TRANSACTION …; BEGIN;` que compone knex):

```
sesión READ COMMITTED, SIN el SET  → {"primerBarrido":1,"segundoBarrido":99}
sesión READ COMMITTED, CON el SET  → {"primerBarrido":1,"segundoBarrido":1}
```

`99` es el segundo barrido viendo la escritura de en medio: **dos fotos**. `1` es la foto única. En
MySQL esto es además lo que hace que la declaración NO sea decorativa: con la sesión en READ
COMMITTED el default de InnoDB no ayuda, y sin el `SET` la ventana sigue abierta.

**SQLite** no se sondea aparte: la prueba es conductual y está en la suite — la reproducción entera
corre en `test:sqlite-file` (WAL, pool 2..5) y pasa.

---

## Lo que queda DECLARADO y NO cubierto

**La dirección inversa sigue abierta, y está escrito en los tres sitios** (README, `CLAUDE.md`,
CHANGELOG) además de en el docblock de `withSourceSnapshot`:

- La foto consistente cubre la dirección cuyo origen es **`authz_*`** (`--to=openfga`).
- Cuando la fuente de verdad de los hechos es el **STORE** —`readOriginFacts` → `enumerateFacts`:
  `--to=database` y la pasada de MANTENIMIENTO— las páginas de `Read` **tampoco son una foto
  consistente**, y ahí no hay `REPEATABLE READ` que valga: la misma composición de media transacción
  sigue siendo posible.
- La instrumentación posible en esa dirección es **`readChanges({ startTime })`** como testigo de
  ventana —detectar y NOMBRAR la tupla que se movió, no prevenirla—, y **no está implementada**. El
  juez la injertó como AVISO, no como garantía, y explícitamente NO como parte de este lote.
- La frase publicada dice hoy que esa dirección tiene una ventana abierta y que lo único que la
  cierra es repetir la pasada tras el cutover. No se finge que una foto cubra las dos direcciones.

**Riesgo residual que ya estaba y no cambia** (auditor 🟠 5 / juez, riesgo 2): en `--to=openfga` la
pasada copia también la proyección del catálogo, leída con una foto DISTINTA de la de los hechos
(`readCatalogProjectionSnapshot`, antes de abrir el snapshot). Un `syncAuthzCatalog` a mitad deja el
destino mezclando dos versiones. No se tocó: es parte del expediente del `freeze()` y meterlo en la
misma transacción cambiaría de dónde lee el sync, que es la pieza que 3b-2a dejó compartida a
propósito.

---

## P2 · `--dry-run` ya no congela

### Fallando ANTES (salida literal)

```
❯ 3b-3a · manager.reconcile / 3b-6 · `--dry-run` NO congela: el verificador read-only no puede parar las escrituras del proceso

- Expected  - 1
+ Received  + 1

- false
+ true

ℹ AssertionError: con --dry-run el motor NO puede quedar congelado: expected true to be false

 ⁃ at Assert.isFalse (node_modules/@japa/assert/build/index.js:125:19)
 ⁃ at Object.executor (tests/reconcile.spec.ts:1181:12)

Tests  7 passed, 1 failed (8)
```

### El caso

`tests/reconcile.spec.ts:1153`, en el grupo `3b-3a · manager.reconcile`. Es el par entero que el juez
dictó, en un solo caso: **con `dryRun: true` un `grant` concurrente ENTRA; con `dryRun: false` es 503
`E_AUTHZ_FROZEN`**, y además afirma `manager.frozen` desde DENTRO de la pasada (`false` en la seca,
`true` en la que escribe). El mutante que mata es exactamente el código de hoy: `withFrozenWrites`
incondicional.

### El código

`src/manager.ts`: el cuerpo de la pasada se extrae a `pass()` y

```ts
// La pasada que escribe congela; el verificador NO (ver el docblock).
if (options.dryRun === true) return pass()
return this.withFrozenWrites(`authz:reconcile --to=${name}`, pass)
```

Nada más del `freeze()` se ha tocado: ni `freeze`/`unfreeze`/`frozen`/`withFrozenWrites`, ni su
alcance, ni el token, ni la duración. El docblock de `reconcile` explica el porqué (y el
contraargumento descartado: los números de un verificador read-only no son una garantía de nada).

---

## Verificación

Todo con `OPENFGA_TEST_URL=http://localhost:8101`.

```
npx tsc --noEmit -p tsconfig.json   ✔
npm run typecheck                   ✔
npm run check:purity                ✔
npm run build                       ✔
```

| Suite | Antes | Ahora | Δ |
|---|---|---|---|
| `npm test` (SQLite `:memory:`) | 765 | **767 passed** | +2 |
| `npm run test:sqlite-file` | 767 | **770 passed** | +3 |
| `npm run test:pg` (PG 18) | 861 | **864 passed** | +3 |
| `npm run test:mysql` (MySQL 8.4) | 861 | **864 passed** | +3 |

Las cuatro, repetidas sobre el árbol FINAL (después de todas las ediciones de documentación) y con la
salida a fichero: `scratchpad/final_sqlitefile.out`, `final_pg.out`, `final_mysql.out` y
`run1..8.out`.

Los +3 son los tres casos nuevos. En `:memory:` son +2: el de la reproducción **no se registra**
ahí (pool 1/1: un segundo escritor no puede existir; ver «Lo que NO se hizo»).

**Modo «tope 3»** (`openfga-tiny`, `OPENFGA_LIST_OBJECTS_MAX_RESULTS=3` /
`OPENFGA_LIST_USERS_MAX_RESULTS=3`, `:8103`), con la salida a fichero desde la primera pasada
(`scratchpad/tope3.out`):

```
[suite] motor SQL: sqlite (:memory:)
 PASSED
Tests  767 passed (767)
Time  43s
```

Contenedor `openfga-tiny` borrado al terminar.

**Stores**: `GET :8101/stores` ⇒ `{"stores":[],"continuation_token":""}` — a cero. Las bases de PG
y MySQL las destruye el harness (`base destruida: authz_test_<8 hex>` en cada corrida). Las dos bases
propias de los sondeos de motor (`authz_rr_probe`) se crean y se borran dentro del propio guion.
Queda en MySQL una base ajena, `authz_t3b_3ce181d3`: **no es de este lote** (su nombre base es
`authz_t3b`, de las corridas del panel con `TEST_MYSQL_URL` propia); se deja como estaba y se apunta.

### Un rojo intermitente que apareció UNA vez y no se ha reproducido

Honestidad primero, porque la regla del paquete es que un caso que no se entiende no está verde:
**una corrida de `npm test` dio `766 passed, 1 failed (767)`** justo después de editar los
docblocks, y **la salida se perdió** (estaba filtrada por `tail -6`). Es el mismo patrón —y la misma
pérdida de evidencia— que el coordinador anotó en el lote 2h.

Qué se hizo con eso, en vez de darlo por bueno: **ocho corridas seguidas de `npm test` con la salida
COMPLETA a fichero** (`scratchpad/run1..8.out`, conservadas):

```
run1: Tests 767 passed (767)     run5: Tests 767 passed (767)
run2: Tests 767 passed (767)     run6: Tests 767 passed (767)
run3: Tests 767 passed (767)     run7: Tests 767 passed (767)
run4: Tests 767 passed (767)     run8: Tests 767 passed (767)
```

**8 de 8 verdes**, más la de tope 3 y las tres de motor. Sigue **sin identificar**, como el del 2h:
lo que se sabe es que existió un fallo una vez; lo que no, cuál. Se deja escrito aquí para que la
próxima tanda no tenga que redescubrirlo, y con la lección aplicada: **la salida a fichero desde la
primera pasada, siempre**, también fuera del modo tope 3.

---

## Documentación

- **README**: (a) `--dry-run` — «**And it does not freeze**… a pass that writes nothing has nothing
  to protect… which is precisely what *run it in a cron* invites»; (b) el párrafo del freeze pasa a
  «While the pass that **WRITES** runs…» con el paréntesis «never under `--dry-run`»; (c) dos
  párrafos nuevos: la foto consistente con lo que garantiza **cada motor**, y **lo que NO cubre**
  (la dirección cuyo origen es el store, con `readChanges` nombrado como no implementado).
  No se ha tocado ninguna otra frase del freeze (la de «maintenance window of seconds» y la promesa
  fuerte son de la opción B y de la decisión del dueño).
- **CHANGELOG**: `### Lot 3b-6`, en el estilo del 1.1.0 (problema medido → decisión → qué NO se hace
  y por qué), con la cifra `written=13 extra=0 skipped={} clean=true` y el párrafo de lo declarado.
- **CLAUDE.md**: la viñeta de `authz:reconcile` recoge las dos cosas (la condición de `dryRun` y la
  foto consistente con la tabla de motores y el hueco abierto); el mapa del código apunta
  `withSourceSnapshot` y el `dryRun` de `manager.reconcile`.
- **`commands/authz_reconcile.ts`**: docblock del comando, misma frase.

---

## Lo que NO se hizo, y por qué

1. **Nada del diseño de `freeze()`**: ni el token/fence, ni el lease, ni `report.frozen`, ni
   `authz:freeze`/`authz:unfreeze`, ni el renombre a `freezeThisProcess()`, ni la reescritura de la
   frase falsa del README (`:615`) ni de «*a maintenance window of seconds*». **Es la decisión
   abierta del dueño** (§6 del juez) y el encargo lo prohíbe explícitamente. La única excepción es
   la condición de `dryRun`, que el juez dictaminó como defecto independiente.
2. **El testigo `readChanges({ startTime })` de la dirección inversa**: el juez lo pone en el lote 2
   (E), como AVISO y no como garantía, y el encargo dice literalmente «deja la otra escrita y
   declarada». Está escrita y declarada, no fingida.
3. **La reproducción no se registra en `npm test` (SQLite `:memory:`)**. No es un `skip`: el grupo
   real-servidor se registra bajo `openFgaTestUrl && CONCURRENT_ENGINE`, igual que `contract.spec`
   registra «database (árbol SQL)» solo en PG/MySQL. El motivo es físico y ya documentado en el
   paquete: `:memory:` es pool 1/1 y una segunda conexión no existe, así que un segundo escritor
   **colgaría el pool**, no fallaría. Es la misma limitación que el tester midió para el caso A2 del
   panel. **Lo que sí corre ahí es el caso estructural**, que mata los dos mutantes del mecanismo.
   Consecuencia para CI, dicha y no escondida: **la reproducción exige un gate por motor**
   (`sqlite-file`, `pg` o `mysql`); en la configuración por defecto la propiedad se sujeta solo con
   el caso estructural.
4. **El catálogo NO entra en la foto** (riesgo residual arriba): sigue leyéndose con
   `readCatalogProjectionSnapshot` antes de abrir la transacción, que es la MISMA función que usa
   `syncAuthzCatalog` a propósito (3b-2a · A5). Cambiarlo aquí tocaría el sync.
5. **`readOriginFacts` (el puerto) no se envuelve**: no tendría sentido —su origen no es SQL— y
   envolverlo daría la falsa impresión de que esa dirección quedó cubierta.
6. **Ningún `skip`, ninguna aserción relajada, ningún error sin `status` + `code`**: el único error
   nuevo (`reconcile.snapshot`) reutiliza `AuthorizationBackendError`/`…TimeoutError` (503).

---

## Actualización del coordinador · la caza del intermitente (2026-08-31)

Tras la segunda aparición (una vez en tope 3 en el lote 2h, una vez en `:memory:` en el 3b-6, ambas con la salida perdida): **14 pasadas de `npm test` contra el `:8101` con la salida capturada a fichero desde la primera — 14/14 verdes (767)**. Con las 8 del implementador del 3b-6: **22 verdes consecutivas**.

Estado: **sin identificar y sin reproducir**. Frecuencia observada ≤ 2 apariciones en varias decenas de corridas de toda la fase. Se queda como **vigilancia con datos**, no como bloqueo: toda corrida de suite va a fichero desde ya (regla anotada en RETOMAR.md), y a la próxima aparición tendremos el caso con nombre. Si reaparece, se persigue ANTES de cualquier publicación.
