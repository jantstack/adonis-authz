# Fase 3b · Lote 3b-2e — capacidades, barrido del rol local en `moved`, `purgeRole`, borrado del `resolver`

> Informe **incremental**: se escribe según avanza el lote, no al final.

**Punto de partida.** Rama `v2/fase-3b`, HEAD `2ef4f6b`, árbol limpio.
Suites verificadas antes de tocar nada: `npm test` = **633** (`OPENFGA_TEST_URL=http://localhost:8101`).

## Orden de trabajo

E1 (barrido) → E4 (`purgeRole`) → E3 (gate del manager) → E2 (capacidades) → E5 (límites) →
E6 (el juez contra `facts`) → E7 (borrado del `resolver`, solo si E1–E6 están verdes).

E1 va antes que E4 a propósito (encargo): E4 es lo que ABRE el fail-open que E1 cierra, así que el
agujero se tapa antes de abrir la puerta.

---

## E1 · El barrido del rol local en `moved`

**Los casos** (`tests/openfga_facts.spec.ts`, grupo «facts · 3b-2e · E1 — el barrido del rol local
en `moved`», contra el servidor REAL del `:8101`, nunca un doble):

1. **PARIDAD** entre `database` y `facts`: sacar la unit del owner del rol local retira lo
   concedido en los dos, y devolverla lo restaura.
2. **Y solo esas**: un rol GLOBAL no se toca, y el rol local sobrevive en los scopes que NO
   salieron del owner.
3. **Por SUBÁRBOL**, no por nodo: la asignación cuelga del NIETO del nodo movido.

Los tres montan el MISMO catálogo y el MISMO árbol para los dos drivers y comparan la respuesta de
`authorize`, que es el criterio de aceptación que fijó el dueño (consecuencia 3).

### La salida ROJA (literal)

```
❯ facts · 3b-2e · E1 … / PARIDAD: sacar la unit del owner del rol local retira lo concedido en los DOS drivers, y devolverla lo restaura
- Expected  - 1
+ Received  + 1
- false
+ true
ℹ AssertionError: facts: fuera del owner tampoco (si concede, es el fail-open del hallazgo 2 del 2c): expected true to be false

❯ facts · 3b-2e … / y SOLO esas: un rol GLOBAL no se toca, y un rol local se conserva en los scopes que NO salieron del owner
ℹ AssertionError: facts: el local sale con el subárbol: expected true to be false

❯ facts · 3b-2e … / el barrido es por SUBÁRBOL movido, no por nodo: los descendientes del nodo movido también cambian de cadena
ℹ AssertionError: facts: el barrido tiene que bajar el subárbol entero: expected true to be false
```

Falla **por la razón correcta**: `database` responde `false` tras el `moved` y `facts` responde
`true`. Es el fail-open del hallazgo 2 del informe 2c, reproducido contra el servidor real.

**Un rojo anterior, que es un hallazgo por sí mismo:** el primer intento fallaba ANTES del move
(`facts: concede dentro del owner: expected false to be true`). Causa: un rol local escrito fuera
de `syncAuthzCatalog` no tiene su proyección `role:<uuid>#permits_<P>` en el store, y en `facts`
un rol sin proyección **no concede nada**. Queda anotado porque es exactamente el agujero que E4
tiene que cerrar para `defineScopedRole` (ver más abajo).

### El código que lo puso verde

- `src/catalog_cache.ts` — `CatalogView.localRoles()`: todos los roles con owner ≠ `global`.
  Es lo que permite que el barrido cueste **cero requests** en un catálogo sin roles locales
  (el de todo consumidor que no usa delegación), y por eso las cuentas de requests de `moved`
  del 2b (1 `Read` + 1 `Write`) siguen siendo exactas.
- `src/drivers/openfga_driver.ts` — `sweepLocalRoleBindings(movedKey)`, llamado desde `reparent`
  (o sea, desde `scopes.moved` **y** desde `scopes.attached` de un nodo que ya existía, que es un
  move); y `storeChain(key)`, que sube por `scope#parent` **del store**.
  - Se toca la arista `scope#binding` (lo que hace ALCANZABLE la asignación): se **borra** donde el
    owner ya no está en la cadena y se **reescribe** donde vuelve a estarlo (invariante 18:
    devolver la unit restaura). El `assignee` no se toca: el hecho de la asignación no cambia
    porque el árbol se mueva, igual que en `database`.
  - `Ignore` en las dos direcciones (`onDuplicateWrites`/`onMissingDeletes`): el barrido declara el
    estado que DEBE quedar, no un delta.
  - Los `role_binding` de un rol se enumeran con `Read({ user: 'role:<uuid>', relation: 'role',
    object: 'role_binding:' })` — con `user`, que es lo que el servidor real exige cuando el objeto
    es solo un tipo (lección del 2c).
- `MAX_SCOPE_CHAIN_HOPS` (1.000): red del recorrido hacia arriba; un ciclo escrito a mano en el
  store es 422 `E_AUTHZ_SCOPE_CYCLE`, no un bucle.

### Decisiones donde el encargo no decidía

1. **La cadena y el subárbol se leen del STORE, no del consumidor.** Es el árbol con el que FGA va
   a decidir, y con la outbox el relay aplica el `moved` MÁS TARDE, cuando el árbol del consumidor
   ya puede haberse movido otra vez. Usar `resolveChain` ahí habría barrido con un árbol que no es
   el que decide.
2. **Se barre también en `scopes.attached`**, porque un `attach` sobre un nodo que ya existe *es*
   un move (lo dice el propio código desde 2b). Para un nodo nuevo el barrido no cuesta nada
   (subárbol vacío, sin bindings).
3. **Consecuencia operativa que hay que tener escrita: en `facts`, `scopes.moved` ahora CONSULTA EL
   CATÁLOGO.** Sin outbox eso ocurre dentro de la transacción del consumidor, y con un pool de UNA
   conexión (SQLite en memoria de la suite) la lectura se queda esperando a la transacción. Es una
   razón más para la outbox, que es el camino soportado: con ella el driver no se toca dentro de la
   transacción. Se anota en `tests/scope_outbox.spec.ts` (ese montaje es justo el que el gate
   rechaza) declarando `catalogRevalidate: { everyMs: 60_000 }`, que hace que el memo ya cargado
   responda sin SQL.
4. **La guardia de fuente de A6 se actualiza en vez de esquivarse.** Ahora hay DOS sitios que
   escriben `role:` en el driver; el caso comprueba que el segundo está en el barrido y que lo que
   enumera son objetos `role_binding`, no el tipo `role` — A6 prohíbe preguntarle al store *qué
   permisos tiene un rol*, no mencionar el tipo.

**Verde: 633 → 636 casos** (`npm test`), ninguno existente en rojo.

---

## E4 · `purgeRole` pasa a SOPORTADO en `openfga`

**Los casos** (`tests/openfga_facts.spec.ts`, grupo «facts · 3b-2e · E4 — `purgeRole` y la API de
delegación», servidor real):

1. `defineScopedRole` deja de negarse **y el rol CONCEDE de verdad**.
2. `updateScopedRole` que quita un permiso deja de conceder al instante.
3. `purgeRole` se lleva las asignaciones de TODOS los scopes, los vínculos y la fila; recrear el
   slug no revive nada; y el store queda a cero (ningún binding apunta al rol).
4. uuid desconocido ⇒ 422 `E_AUTHZ_UNKNOWN_ROLE`; mal formado ⇒ 422 `E_AUTHZ_INVALID_IDENTITY`.
5. **CASO NEGATIVO**: en modo `resolver` el driver sigue sin traer `purgeRole` y `defineScopedRole`
   se niega ANTES de escribir.

### La salida ROJA (literal)

```
❯ facts · 3b-2e · E4 … / `defineScopedRole` deja de negarse Y el rol CONCEDE de verdad (la proyección se mantiene)
ℹ UnsupportedOperationError: defineScopedRole necesita 'purgeRole' y el driver 'openfga' no lo implementa: es un método
  opcional del puerto (2.1) que este driver tiene que añadir para usar esta primitiva. Los roles locales a un scope
  necesitan poder purgarse; en el driver openfga llegan con el modo `facts` (fase 3b).

❯ facts · 3b-2e · E4 … / uuid desconocido ⇒ 422 E_AUTHZ_UNKNOWN_ROLE; mal formado ⇒ 422 E_AUTHZ_INVALID_IDENTITY
ℹ AssertionError: expected undefined to equal 422      (no había método al que llamar)
```

**El caso 5 pasaba ya**, así que se puso rojo con un MUTANTE (`if ((this.hierarchy as string) ===
'NUNCA')` en vez de `if (this.hierarchy !== 'facts')`, o sea: declarar `purgeRole` también en modo
`resolver`) y se restauró:

```
❯ authorization contract [openfga · 2.2] / sin purgeRole: el puerto NO lo trae … 
ℹ AssertionError: purgeRole: false ⇒ el puerto no lo trae; un método que solo lanza al llamarlo no deja al manager
  protegerte: expected [AsyncFunction purgeRole] to equal undefined
❯ facts · 3b-2e · E4 … / CASO NEGATIVO: en modo `resolver` el driver sigue diciendo que no sabe purgar …
ℹ AssertionError: sin `scope#binding` los bindings de un rol no se enumeran: el modo `resolver` no lo trae: expected
  [AsyncFunction purgeRole] to equal undefined
Tests  639 passed, 2 failed (641)
```

### El código

- `src/drivers/openfga_driver.ts` — `purgeRole(roleUuid)`. Lo hace posible (c2): el binding APUNTA
  a su rol (`role_binding#role`), así que sus bindings se enumeran filtrando por `user`, y
  `scope#binding` dice de qué scope cuelga cada uno. Orden **hechos primero, catálogo después**
  (el de `detached`, S6) y **demostración de cero** (invariante 11): si algo sobrevive, 500
  `E_AUTHZ_PURGE_INCOMPLETE` y el catálogo **no se toca**. No hay transacción que abarque FGA y
  SQL; lo que se garantiza es la dirección segura (un rol vivo sin hechos es reintentable; hechos
  huérfanos sin rol resucitarían con el slug).
- El constructor **retira** `purgeRole` en modo `resolver` (`Object.defineProperty(this,
  'purgeRole', { value: undefined })`), que es la forma documentada de decir «no sé purgar» (3E ·
  Q4) y lo que deja al manager negarse ANTES de escribir (P4). Desaparece con E7.
- `projectCatalogRole(roleUuid)` (**nuevo método OPCIONAL del puerto**, `src/types.ts`) y sus dos
  llamadas en `src/manager.ts` (`defineScopedRole`, `updateScopedRole` cuando cambian los permisos).

### La decisión que el encargo no traía, y por qué era obligatoria

En `facts` **lo que un rol concede son TUPLAS** (`role:<uuid>#permits_<P>@<holder>:*`), no el
catálogo local. `syncAuthzCatalog` mantiene ese espejo cuando el consumidor le pasa la proyección,
pero la API de delegación escribe el catálogo por fuera del sync. Sin `projectCatalogRole`:

- `defineScopedRole` habría creado un rol que **no concede nada** (no-op silencioso), y
- `updateScopedRole` que quita un permiso lo habría seguido concediendo: **fail-open**.

Es exactamente el rojo que apareció al montar E1 (un rol local escrito fuera del sync no concedía).
Se cierra con una lectura por holder y un `Write`, y solo cuando los permisos cambian.

---

## E3 · El agujero del gate que declaró el 2d, cerrado

El 2d lo dejó escrito (decisión 5 de su informe): *el gate comprueba la opción `outbox` DEL DRIVER;
quien encola es el MANAGER, que lee `config.scopes.outbox`. Pasar la instancia solo al driver deja
el gate contento y la mitigación APAGADA.*

**Los casos** (`tests/scope_outbox.spec.ts`, grupo «3b-2e · E3 — el gate también en el MANAGER»):

1. **outbox SOLO en el driver ⇒ el manager lanza** 500 `E_AUTHZ_SCOPE_DRIFT_UNGUARDED` (en
   `authz.driver()` y en `authz.scopes.attached`).
2. Con la MISMA outbox en el config, el manager sí construye.
3. La salida explícita también vive en el config (`scopes.acceptScopeDriftRisk: true`): la firma
   del driver **no firma por el manager**.
4. **CASO NEGATIVO**: con un driver que no declara `hierarchyFacts` (modo `resolver`, `database`, o
   un driver de terceros sin `capabilities`) el gate no aplica — no hay dos árboles.

### La salida ROJA (literal)

```
❯ 3b-2e · E3 … / outbox SOLO en el driver ⇒ el manager lanza 500 E_AUTHZ_SCOPE_DRIFT_UNGUARDED
ℹ AssertionError: la outbox del driver no es la del manager: debería haber lanzado: expected null to not equal null
❯ 3b-2e · E3 … / la salida explícita también existe en el config: `scopes.acceptScopeDriftRisk: true`
ℹ AssertionError: la firma del driver no firma por el manager: debería haber lanzado: expected null to not equal null
❯ 3b-2e · E3 … / CASO NEGATIVO: con un driver que NO declara `hierarchyFacts` el gate no aplica
ℹ TypeError: Cannot read properties of undefined (reading 'hierarchyFacts')
```

El tercero es el caso negativo y **también estuvo rojo**: `capabilities` no existía todavía.

### El código

- `src/types.ts` — `AuthorizationDriverCapabilities` y `readonly capabilities?` en el puerto.
- `src/drivers/database_driver.ts` / `openfga_driver.ts` — cada uno declara las suyas (en openfga
  es un **getter**, porque dependen del modo y una vista por prototipo tiene que declarar lo mismo).
- `src/define_config.ts` — `scopes.acceptScopeDriftRisk?: boolean`.
- `src/manager.ts` — `#assertScopeDriftGuarded(driver)` en `driver()`. Un driver sin
  `capabilities` (2.x o de terceros) se trata como `hierarchyFacts: false`.

### Efecto colateral que confirma que el gate MUERDE

Al implementarlo se pusieron rojos **cuatro montajes existentes** que construían un manager sobre un
driver `facts` firmando el riesgo solo en el driver (3 en `openfga_facts.spec.ts` y el `world()` sin
outbox de `scope_outbox.spec.ts`). No son roturas: son el agujero, y ahora hay que firmar donde
importa. Se les añadió `scopes.acceptScopeDriftRisk: true` con la explicación.

**Verde: 641 → 645.**

---

## E2 · Capacidades declaradas, cada una con su caso

### El puerto y el juez

- `AuthorizationDriverCapabilities` en el puerto (`src/types.ts`) y `driver.capabilities` en los dos
  drivers (ver E3).
- `DriverCapabilities` del contrato (`src/testing/contract.ts`) gana **`roleInheritanceNative`** y
  **`listObjectsInherited`**, cada una con su `caseFor(...whenFalse)` — que es el valor que TODO
  driver del paquete declara, también en `facts` (cruce 6).

**`roleInheritanceNative: false`** — «la MEMBRESÍA la resuelve el paquete con el árbol del
consumidor: hasRole/listRoles/listRoleScopes/listSubjects/listScopes lo consultan». Espía sobre
`tree.chainOf` con las cinco primitivas del literal, más la consecuencia observable (mover el nodo
cambia la membresía sin escribir).

**`listObjectsInherited: false`** — «los `list*` NO enumeran herencia (invariante 7): un grant en el
ancestro no aparece abajo, aunque `authorize` diga `true`». El rol del caso es del **mismo nivel**
que los dos scopes (`unit-editor@unit`) a propósito: con un rol de otro nivel el filtro de nivel
taparía una enumeración que sí heredara y el caso no probaría nada — se descubrió con el mutante.

### Los dos casos pasaban al escribirlos: MUTANTES

```
# MUTANTE A (roleInheritanceNative): database_driver.hasRole con `const chain = [scope]`
❯ authorization contract [database · 2.2] / la MEMBRESÍA la resuelve el paquete con el árbol del consumidor …
ℹ AssertionError: hasRole: con roleInheritanceNative: false tiene que consultar el árbol: expected +0 to be above +0

# MUTANTE B (listObjectsInherited): database_driver.listRoles enumerando `chain` en vez de `[chain[0]]`
❯ authorization contract [database · 2.2] / los `list*` NO enumeran herencia (invariante 7) …
ℹ AssertionError: la enumeración NO: expected [ 'unit-editor' ] to deeply equal []
```

**El primer intento del mutante B no mató nada** (`listSubjects`/`listRoles` con un rol
`org-editor@organization` seguían devolviendo `[]`: los tapaba el filtro de NIVEL). Eso es un
hallazgo sobre el caso, no sobre el código: se reescribió con un rol del mismo nivel y entonces sí
murió. Un caso que un mutante razonable no mata no vale.

### El README

- El **literal exacto del cruce 6**, en su propio bloque de cita, con las cinco lecturas nombradas.
- La frase que **prohíbe el titular**: *«"no SQL in the hot path" is not a claim this package
  makes»*, con lo que sí es cierto («no SQL per request in `authorize`»).
- Una **tabla de capacidades declaradas** por driver y modo, con lo que el juez fija de cada una.
- El párrafo del invariante 18 reescrito (ver E1) y el del gate del manager (E3).

Tres casos nuevos lo fijan (`facts · 3b-2e · E2 — el README promete el literal del cruce 6 y nada
más`), y también estuvieron rojos con mutantes (borrar la frase que desmiente el titular; declarar
`roleInheritanceNative: facts`):

```
❯ … / el titular PROHIBIDO no se vende: «no SQL in the hot path» solo aparece para desmentirlo
ℹ AssertionError: expected '# @jantstack/adonis-authz…' to include '"no SQL in the hot path" is not a cla…'
❯ … / las capacidades declaradas del driver son las de la tabla del README
ℹ AssertionError: expected { hierarchyFacts: true, …(4) } to deeply equal { hierarchyFacts: true, …(4) }
```

**Verde: 645 → 654.** (Las cuentas literales de `tests/contract_harness.spec.ts` suben en 2: los dos
pares nuevos registran su cara `false` en todos los niveles.)

---

## E5 · Los límites, como capacidades con caso negativo — y la profundidad MEDIDA sobre (c2)

### La cifra real, medida contra el `:8101` (OpenFGA v1.19, `--resolve-node-limit` por defecto = 25)

Sonda contra el servidor real sobre el modelo (c2), con el grant en la raíz y el `Check` a
profundidad creciente:

| relación | saltos `parent` que resuelve | primer fallo |
|---|---|---|
| **`can_<P>`** (la decisión de `authorize`) | **23** | 24 |
| `denied_<P>` (el deny heredado) | 25 | 26 |
| `ancestor` (`isWithin`/`descendantsOf` nativos) | 26 | 27 |

Salida literal de la sonda:

```
PROBE hops-ok: 23 primer fallo: {"depth":24,"reason":"FgaApiValidationError: FGA API Validation Error: post check :
  Error Authorization Model resolution required too many rewrite rules to be resolved. Check your authorization model
  for infinite recursion or too much nesting"}
PROBE deny hops-ok: 25 primer fallo: {"depth":26, …}
PROBE ancestor hops-ok: 26 primer fallo: {"depth":27, …}
```

**Manda la más baja: `can_<P>` = 23 saltos (24 nodos contando el scope preguntado.)** Es la resta
(`difference`) sobre una unión con DOS TTU (`binding` y `parent`), así que gasta dos reescrituras
más que las otras dos ramas. Los «~23» del panel eran de un modelo más simple y estaban **sin medir
sobre (c2)**: el número coincide, pero ahora está medido donde toca. Queda en
`FACTS_MAX_RESOLVE_DEPTH` (exportado desde `@jantstack/adonis-authz/openfga`) con la tabla y la
consecuencia escritas en el docblock.

### Los casos

- **`la cadena de 23 saltos SÍ decide`** (borde exacto, verde).
- **CASO NEGATIVO: `a 24 saltos … eso es 503 — jamás un `false` silencioso`**. Fail-closed pero
  RUIDOSO: un `false` sería indistinguible de «no tiene permiso». Y por debajo de la cota la misma
  pregunta responde.
- **`authorizeMany` pasa del tope de 50 checks por lote sin truncar ni desordenar** (120 scopes, 60
  dentro y 60 fuera, comprobando la respuesta POSICIÓN a posición: es donde un troceo mal
  correlacionado se vería).
- Relación ≤ 50 y objeto ≤ 256 **ya tenían sus casos** desde 3b-2a (`facts · A4`), y el techo de
  262.144 bytes también (`facts · A3`): no se duplican, se declaran junto a los demás.

### Los mutantes que fijan la cifra por los DOS lados

```
# FACTS_MAX_RESOLVE_DEPTH = 24
❯ … / la cadena de 24 saltos SÍ decide: la cota medida sobre (c2) es esa y no otra
ℹ AuthorizationBackendError: El backend de autorización 'openfga' no respondió (check)
Tests  655 passed, 2 failed (657)

# FACTS_MAX_RESOLVE_DEPTH = 22
❯ … / CASO NEGATIVO: a 23 saltos el servidor no puede resolver, y eso es 503 — jamás un `false` silencioso
ℹ AssertionError: la operación: debería haber lanzado: expected null to not equal null
Tests  656 passed, 1 failed (657)
```

Con 24 la cota es demasiado alta (el borde ya no decide) y con 22 demasiado baja (el «negativo»
responde). **23 es el único valor que deja los dos casos verdes.**

**Verde: 654 → 657.**

---

## E6 · Los casos del juez contra `facts` — **HECHO EL HARNESS, NO VERDE EL JUEZ**

### Lo que se construyó (las dos piezas que anotó el 2c, y dos más)

1. **El espejo del árbol.** `src/testing/contract.ts`: cuando el harness declara
   `hierarchyFacts: true`, el `setup` parchea `tree.attach`/`tree.move` para notificar al driver
   (`onScopeAttached`/`onScopeMoved`) después de escribir la fila del consumidor, y `tree.detach`
   —que ya purgaba— añade `onScopeDetached` **después** de la purga (S6). El espejo tolera un
   `E_AUTHZ_INVALID_IDENTITY` del driver y **solo ese**: el juez cuelga a propósito el uuid
   centinela de la raíz para comprobar que ninguna escritura lo acepta.
2. **`seedCatalog` pasa la proyección y el modelo se publica por catálogo.** En
   `tests/contract.spec.ts`, `factsHarness(...)`: `makeDriver` crea el store, publica
   `openFgaFactsModel(holders, permisos del catálogo de ESE caso)` y re-sincroniza con
   `{ projection: driver.catalogProjection() }`; los `seedCatalog` de mitad de caso también
   proyectan.
3. **Los escritores «a mano» del catálogo rehacen la proyección** (`localRole`, `linkByHand`,
   `withoutLink`), igual que ya tenían que invalidar el memo. Sin esto, seis casos medían el espejo
   en vez del invariante.
4. **Las dos caras `whenTrue`** que faltaban: `singleCheckAuthorize` (`authorize` con 0
   `resolveChain` y aun así hereda) y `hierarchyFacts` (`authorize` sobrevive a la caída del
   resolutor; `hasRole` **no**, y eso sigue siendo 503).

### El resultado: **el juez corre contra `facts` y CINCO/SEIS casos siguen rojos**

`AUTHZ_CONTRACT_FACTS=1 npm test` (SQLite + árbol en memoria) ⇒ **742 passed, 5 failed (747)**.
`AUTHZ_CONTRACT_FACTS=1 npm run test:pg` (árbol SQL en PostgreSQL) ⇒ **916 passed, 5 failed (921)**.

No son fallos del harness: **son divergencias reales del modo `facts`**, y por el encargo se anotan
y se para, no se silencian ni se declaran «esperadas».

```
❯ [openfga facts · 2.2] / authorizeMany: … un scope que lanza ⇒ lanza entero
ℹ AssertionError: debería haber rechazado

❯ [openfga facts · 2.2] / dos grant concurrentes … (o falla con 409, nunca con 500/503)
ℹ AssertionError: ronda 0: El backend de autorización 'openfga' no respondió (writeTuples): expected 503 to equal 409

❯ [openfga facts · 2.2] / purgeScope concurrente con grant … nunca un estado a medias
ℹ AssertionError: ronda 0: authorize coherente: expected false to equal true

❯ [openfga facts · 2.2] / paridad entre drivers (3D · N1): una asignación cuyo rol está declarado para OTRO nivel no cuenta …
ℹ AssertionError: el rol ya no existe en ese nivel: expected true to be false

❯ [openfga facts · 2.2] / scopes.detached purga los HECHOS del scope y SOLO los hechos …
ℹ AssertionError: el nieto pierde su cadena y con ella todo: expected true to be false

# solo con el árbol SQL (PG/MySQL), donde el alias del uuid funde con la fila real:
❯ [openfga facts (árbol SQL) · 2.2] / un alias del uuid del scope … jamás evade un deny
ℹ AssertionError: sin guiones: lo concedido sigue concedido: expected false to be true
```

### Los seis hallazgos, y a qué se reducen

| # | Caso | Qué pasa | Raíz |
|---|---|---|---|
| 1 | `authorizeMany` con resolutor caído | **no lanza**: responde | La cara fea de `singleCheckAuthorize: true` — la decisión ya no pasa por el árbol, así que su caída no se puede observar desde `authorize`. El caso del juez codifica la conducta de `hierarchyFacts: false` sin estar bajo un par: **o se convierte en par de capacidad, o `facts` no puede pasarlo nunca.** |
| 2 | Dos `grant` concurrentes | **503** en vez de 409 | El `grant` de (c2) escribe primero las DOS aristas del binding y luego el `assignee`. El manejo del 409 (releer y re-aplicar, D6) solo cubre el `assignee`; un conflicto en las aristas sale como caída del backend. |
| 3 | `purgeScope` concurrente con `grant` | `listRoles` dice que SÍ y `authorize` dice que NO | Misma raíz: el grant son **tres** tuplas y la purga puede llevarse la arista entre la primera y la última. En `database` el grant es UNA fila. Es una incoherencia entre enumeración y decisión, que es peor que perder la escritura. |
| 4 | Paridad de NIVEL (3D · N1) | el rol sigue concediendo tras cambiarle el nivel | **(c2) no tiene el nivel del rol.** La proyección dice qué permisos vincula un rol, no en qué nivel se declara. Es del mismo tipo que el hallazgo del 2c que resolvió la decisión del 30-08 (allí era el *owner*), y admite la misma familia de soluciones: barrer las aristas `scope#binding` cuando el nivel deja de casar. |
| 5 | `scopes.detached` de un ancestro | el NIETO sigue concediendo | En `facts` el nieto tiene su propio `role_binding` colgado de su propio `scope:`, y el `Check` no necesita que la cadena llegue a la raíz. En `database` `resolveChain` devuelve `null` y no concede nada (invariante 9). **Un scope con la cadena rota sigue decidiendo en `facts`.** |
| 6 | Alias del uuid del scope (solo árbol SQL) | lo concedido deja de concederse | Consecuencia declarada por el 2c (decisión 1 de su informe): `authorize` en `facts` NO canoniza, así que un alias no encuentra nada. Es fail-**CLOSED** (nunca concede de más), pero **rompe la igualdad de respuesta** que el juez exige, y por eso aparece aquí. |

Reducidos a tres raíces: **(R1) la proyección no puede expresar el nivel del rol**, **(R2) el árbol
del store decide sin la cadena del consumidor** (nº 1, 5 y 6) y **(R3) el `grant` de (c2) son tres
tuplas y no es atómico** (nº 2 y 3).

### Por qué el harness NO se registra por defecto

Registrarlo deja la suite en rojo y bloquea todo lo demás; no registrarlo y callarlo sería peor. Se
registra **solo con `AUTHZ_CONTRACT_FACTS=1`**, y el porqué —los cinco casos, uno a uno— está escrito
en `tests/contract.spec.ts` junto al `if`, no solo aquí. **E6 no está verde y el criterio de
aceptación del lote 3b-2 no está cumplido.**

Reproducción:

```bash
AUTHZ_CONTRACT_FACTS=1 OPENFGA_TEST_URL=http://localhost:8101 npm test
AUTHZ_CONTRACT_FACTS=1 TEST_PG_URL=... OPENFGA_TEST_URL=http://localhost:8101 npm run test:pg
```

---

## E7 · Borrar el modo `resolver` — **NO EMPEZADO, a propósito**

El encargo lo condiciona a que E1–E6 estén verdes. **E6 no lo está**, y además las tres raíces de
arriba se resuelven —o se declaran— en el modo `facts`, que es justo lo que quedaría como único modo.
Borrar el `resolver` ahora dejaría al paquete sin la única configuración que hoy pasa el juez entero.
No se ha tocado ni una línea del camino `resolver`.

---

## Documentación reescrita

- **`CLAUDE.md`** — invariante 18 reescrito (**breaking**): «se retira al instante y sin escribir»
  pasa a «se retira; en `database` sin escribir, en `facts` con una escritura que aplica el relay —
  y `reconcile` la reconcilia si el relay se perdió», con el barrido por subárbol y el criterio de
  paridad. Además, `purgeRole` soportado en `facts` + `projectCatalogRole`, y **tres reglas de
  higiene nuevas**: las capacidades declaradas (con la prohibición del titular), el gate de deriva
  en el manager y las cotas MEDIDAS de (c2).
- **`README.md`** — el literal aprobado del cruce 6 en su propio bloque de cita; la frase que
  desmiente «no SQL in the hot path»; la tabla de capacidades por driver y modo; el párrafo del
  invariante 18 con el barrido; y el gate del manager en *Driver options*.
- **`CHANGELOG.md`** — «Lot 3b-2e», con **dos BREAKING** marcados (el invariante 18 y el gate del
  manager) y la cifra de profundidad medida.

---

## Verificación

```
npx tsc --noEmit -p tsconfig.json    ✓ (sin salida)
npm run typecheck                    ✓
npm run check:purity                 ✓ el paquete no depende de ningún proyecto consumidor
npm run build                        ✓
```

| Suite | Antes (3b-2d) | Después |
|---|---|---|
| `npm test` (SQLite memoria + OpenFGA) | 633 | **660** |
| `npm run test:sqlite-file` | 635 | **662** |
| `npm run test:pg` | 801 | **834** |
| `npm run test:mysql` | 801 | **834** |

**+27 / +27 / +33 / +33**, y ni un caso existente en rojo. Sin `skip` en ninguna parte. En PG y
MySQL suben 6 más que en SQLite porque ahí corren tres harnesses del juez en vez de dos (los pares
`roleInheritanceNative`/`listObjectsInherited` registran su caso en cada uno).

**No quedan stores huérfanos en el `:8101`**: los harnesses nuevos borran los suyos en el teardown
(comprobado enumerando el servidor al terminar: 0 stores con los prefijos de este lote).

### La cifra de profundidad, medida sobre (c2)

**22 saltos de `parent`** es la profundidad que `can_<P>` —la relación con la que decide
`authorize`— resuelve SIEMPRE, con el `--resolve-node-limit` por defecto (25) de OpenFGA v1.19. A
**23 el borde es probabilístico** (24 de 25 repeticiones resuelven, 1 falla) y a **24 falla
siempre**. `denied_<P>` llega a 25 y `ancestor` a 26; manda la más baja. Se declara 22 y no 24
porque un caso apoyado en un borde probabilístico habría sido un flake en el artefacto publicado —
y de hecho lo fue una vez, antes de medirlo con repeticiones.

---

## Lo que NO hice, y por qué

1. **E7 (borrar el modo `resolver`): no empezado.** El encargo lo condiciona a E1–E6 en verde y
   **E6 no lo está**. Además, borrarlo dejaría al paquete sin la única configuración que hoy pasa el
   juez entero. No se ha tocado una línea de ese camino: ni la expansión de cadena de
   `authorize`/`authorizeMany`, ni `deny_binding`, ni `openfga:provision`. Un borrado a medias es
   peor que no empezarlo.
2. **E6 está a medias y se dice: el harness existe y funciona, el juez NO pasa.** Las cuatro piezas
   del harness (espejo del árbol, proyección en `seedCatalog`, modelo por catálogo, caras `whenTrue`)
   están hechas y probadas; con ellas el juez corre contra `facts` y deja **5 casos rojos en SQLite y
   5 en PostgreSQL** (6 distintos entre las dos, y uno de ellos —el 409 de dos `grant` concurrentes—
   depende del reparto de tiempos). Están listados arriba uno a uno con su salida literal. El harness
   se registra solo con `AUTHZ_CONTRACT_FACTS=1`, y el porqué está escrito **en el propio
   `tests/contract.spec.ts`**, no solo en este informe.
3. **No arreglé las tres raíces de E6.** Dos de ellas piden decisión del dueño, exactamente como la
   del 30-08:
   - **(R1) (c2) no tiene el NIVEL del rol.** Cambiar `scope_type` no retira lo concedido. Admite la
     misma familia de soluciones que el owner (barrer aristas `scope#binding`), pero es un cambio de
     alcance —haría que la arista signifique «el rol es visible aquí» y no «esta asignación existe»—
     y hay que decidirlo, no improvisarlo a las 3 de la mañana del lote.
   - **(R2) el árbol del store decide sin la cadena del consumidor.** Un scope cuya cadena está rota
     sigue concediendo por su propio binding (invariante 9), un resolutor caído ya no puede hacer
     lanzar a `authorize` (es la cara fea de `singleCheckAuthorize: true`, y su caso del juez debería
     ser un par de capacidad) y un alias del uuid deja de encontrar sus hechos (fail-closed, pero
     rompe la igualdad).
   - **(R3) el `grant` de (c2) son TRES tuplas y no es atómico**: contra un `purgeScope` concurrente
     `listRoles` y `authorize` se contradicen, y un conflicto en las aristas sale como 503 en vez de
     409. Esta sí es un **bug del driver** y es la que yo arreglaría primero: no necesita decisión,
     necesita que las tres tuplas viajen en un `Write` y que el 409 se maneje como en el `assignee`.
4. **No toqué `hasRole`/`listRoles`/`listRoleScopes`/`listSubjects`/`listScopes`.** Siguen usando
   `resolveChain` en `facts`: es lo medido, lo aprobado (cruce 6) y ahora lo **declarado** con su
   caso. Convertirlos no estaba en el encargo y en (c2) no hay alternativa.
5. **No hay comando de migración de la forma vieja a la nueva** (un store escrito en modo `resolver`
   sigue sin verse desde `facts`). Es `authz:reconcile` (3b-3), como ya decía el 2c.
6. **No cambié el par `purgeRole` de los harnesses `openfga` existentes** (siguen en `false`): esos
   harnesses corren en modo `resolver`, donde el método sigue sin existir. La inversión del par ocurre
   en el harness `facts`, que es donde `purgeRole: true` se declara — y ese harness es E6.
