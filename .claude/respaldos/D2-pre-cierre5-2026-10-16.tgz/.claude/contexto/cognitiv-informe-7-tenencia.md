# Informe al paquete `@jantstack/adonis-authz` · peticiones desde `api-cognitiv` (2026-10-14)

**Para:** el modelo/mantenedor del paquete `@jantstack/adonis-authz` (versión consumida: `2.4.0-alpha.10`).
**De:** `api-cognitiv` (plano de control de COGNITIV), consumidor con los dos drivers (`database` y `openfga`) en CI.
**Motivo:** el diseño de un módulo nuevo, la **tenencia documental** (carpetas y archivos catalogados desde conectores
Google Drive / OneDrive / GitHub / S3 propio, con control de acceso por carpeta y documento y compartición con
personas de otras organizaciones), ha pasado por tres paneles (actas `panel-conectores-acta.md`,
`panel-tenencia-acta.md`). El motor de relaciones (ReBAC, §Relations del README) es la base elegida. Al diseñar el
evaluador de la tenencia han aparecido **cinco necesidades genéricas** —valen para cualquier proyecto con recursos
compartibles, no solo para COGNITIV— que hoy el consumidor tendría que reconstruir encima del paquete. Este informe las
describe con el contrato propuesto, la semántica esperada en ambos drivers, los casos de prueba que esperaríamos en la
suite del paquete, y lo que **no** pedimos. Nada de esto está implementado en el consumidor: podemos adaptar el diseño
a lo que el paquete decida.

Convenciones: ✅ = verificado en el README o en `build/**/*.d.ts` de alpha.10; 🟡 = supuesto; ❓ = duda al paquete.

---

## 0 · Resumen y prioridad

| # | Petición | Ahorro en el consumidor | Tamaño estimado en el paquete | Prioridad |
|---|---|---|---|---|
| P1 | **Deny en relaciones** (tupla negativa que gana en `check`/`listObjects`/`listSubjects`/`membersOf`) | Alto: hoy habría que inventar una relación `blocked` y reinterpretarla en un evaluador propio | Medio (semántica + ambos drivers + modelo FGA) | **1** |
| P2 | **`listObjectsForSubject` sin partición** (qué objetos tiene un sujeto en cualquier partición, paginado) | Alto: sin ello hace falta un índice local duplicado del motor para "Compartido conmigo" | Medio (`database` trivial; `openfga` requiere diseño) | **2** |
| P3 | **Metadatos por tupla** (`meta` opaco: quién concedió, motivo, flags) | Medio: una tabla "meta" por tipo de objeto en el consumidor (hoy ya existe `ia_space_access_meta`) | Pequeño-medio | 3 |
| P4 | **`checkMany` / `checkChain`** (un sujeto, una relación, N objetos en una llamada) | Medio: el evaluador de herencia pregunta por toda la cadena de ancestros (profundidad 5–20) | Pequeño (`database`: un `IN`; `openfga`: `batchCheck`) | 4 |
| P5 | **Reloj inyectable expuesto en el provider** y documentado para pruebas de caducidad al borde | Pequeño, pero hoy no observable desde el consumidor | Trivial | 5 |

Lo que **no** pedimos ahora: herencia objeto→objeto (`from`/tuple-to-userset). Ver §6.

---

## 1 · Contexto del consumidor (lo justo para entender las peticiones)

- **Objeto nuevo:** `tenancy_node` (carpeta o archivo de la tenencia de una organización). Relaciones previstas:
  `manager ⊇ editor ⊇ viewer` (con `includes`, como `document` del README ✅).
- **Herencia por carpetas:** NO la pedimos al motor. La resuelve un evaluador puro del consumidor con la cadena de
  ancestros del nodo (tabla propia `tenancy_nodes.ancestor_uuids`, reescrita en la misma transacción al mover), que
  pregunta al motor por cada nodo de la cadena. Fail-closed: cualquier error del motor ⇒ 503; lista truncada ⇒ 503;
  ancestro desconocido ⇒ denegar.
- **Sujetos:** `users:<uuid>` (de esta o de OTRA organización: hemos verificado ✅ que un holder `users:<uuid>` se
  guarda **sin partición** en ambos drivers — `database_relations_driver.js` escribe `subject_partition` nulo;
  `openfga_relations_driver.js` compone `user:<uuid>` sin partición— y que la regla "solo sujetos de la propia org" es
  nuestra, en `space_keys_service.ts`), `integrations:<uuid>`, y grupos (`group#member`: departamentos y cargos que ya
  mantiene nuestro espejo de membresía).
- **Partición:** siempre la organización dueña del nodo.
- **Compartición cross-org (fase 2):** el invitado es un `users:<uuid>` de otra organización, con tupla en la partición
  del dueño, con `expiresAt` obligatorio; **nunca** miembro de la organización dueña.
- **Volumen:** tuplas solo donde se concede (carpetas raíz, carpetas concretas, algún archivo suelto): decenas a
  miles por organización, no una por archivo sincronizado.

---

## 2 · P1 · Deny en relaciones

### 2.1 Necesidad
"Todo el departamento ve `Finanzas`, pero **nadie** ve `Finanzas/Nóminas` salvo el owner." Con el motor actual, la
única forma es una relación positiva inventada (`blocked`) que el consumidor reinterpreta como negativa en su
evaluador. Eso significa que `check`, `listObjects`, `listSubjects` y `membersOf` del paquete devuelven resultados
**que el consumidor tiene que corregir después**, y que un segundo consumidor del mismo paquete tendría que reinventar
la misma convención. El paquete ya tiene deny para permisos de rol ("Explicit deny wins", semántica 2 ✅); pedimos la
misma garantía para relaciones.

### 2.2 Contrato propuesto
```ts
// RelationsManager
await rel.deny(subject, relation, object, partition, options?: RelationWriteOptions)      // tupla negativa
await rel.removeDeny(subject, relation, object, partition, options?: RelationWriteOptions)
await rel.listDenies(object, partition, page?): Promise<RelationSubjectsPage>              // denies directos del objeto
```
- `subject` admite lo mismo que `relate`: holder directo, userset (`{ object: group, relation: 'member' }`) y, si se
  desea, el comodín "todos" (ver 2.4).
- `options.expiresAt` con los **mismos tres estados** que `relate` (invariante 10 ✅): un deny temporal es útil
  ("bloqueado hasta el cierre contable").
- Idempotencia como el deny de roles (semántica 6 ✅): re-deny no duplica; `removeDeny` repetido es no-op.
- Evento `onWrite` con `action: 'relation_denied' | 'relation_deny_removed'` (el consumidor lo audita como ya hace con
  `relation_written` ✅ §"The relation write event").

### 2.3 Semántica esperada (ambos drivers, misma suite)
1. **Deny gana sobre cualquier allow para el mismo objeto**, venga el allow por tupla directa, por `includes`
   (`manager` no salva a quien tiene deny en `viewer`… ver 2.5) o por userset (`group#member`).
2. **`check(subject, relation, object)`** ⇒ `false` si hay un deny vivo del sujeto para esa relación en ese objeto,
   **o** para cualquier relación que la incluya hacia arriba (ver 2.5), **o** por un userset al que el sujeto
   pertenece.
3. **`listObjects(subject, relation, type, partition)`** omite los objetos con deny vivo para el sujeto.
4. **`listSubjects(relation, object)`** y **`membersOf`** omiten los sujetos con deny vivo.
5. **Caducidad estricta** igual que en relate (R-15 ✅): un deny que expira *ahora* ya no bloquea.
6. **`purgeObject`/`purgeSubject`** borran también los denies (hoy `purgeScope` borra denies de rol ✅; misma promesa).
7. **`enumerateRelations`** devuelve los denies con una marca (`kind: 'deny'`) para `authz:relations:reconcile`, y el
   reconcile los migra como tales (no como allows).
8. **Deny no afecta a `hasRole`** ni a nada del motor de roles (los dos motores siguen sin responderse entre sí ✅).

### 2.4 Comodín "todos" ❓
Para "nadie ve `Nóminas`" hoy el consumidor pondría un deny al grupo `organizations:<uuid>#member` (todos los
miembros). Preguntamos si el paquete quiere ofrecer un sujeto comodín (`*` / `public`) en deny. No es imprescindible:
el grupo "toda la org" ya lo tenemos. Si se ofrece, que sea **solo** para deny (un allow a `*` sería un enlace
público, que no queremos).

### 2.5 Interacción con `includes` ❓ (decisión del paquete)
Si `viewer` incluye `editor` incluye `manager`, ¿un deny en `viewer` bloquea también a un `manager`? Proponemos **sí**
("no puede ver ⇒ no puede nada"), es decir, el deny se evalúa sobre la relación pedida **y sobre todas las que la
incluyen**. Alternativa: deny literal por relación. Pedimos que la elección quede fijada en la suite con un caso con
nombre (*"un deny en viewer bloquea al manager"* o lo contrario), igual que las semánticas 1–7 del README.

### 2.6 En `openfga`
Sugerencia (🟡, el paquete decide): el modelo fusionado ya tiene `not_expired` por condición ✅; un deny puede ser una
relación paralela `viewer_denied` por tipo y la relación efectiva `viewer_effective = viewer but not viewer_denied`
(exclusión, soportada por el DSL). Las relaciones efectivas son las que consultan `check`/`listObjects`. Esto cambia
el modelo publicado ⇒ cuenta como migración de modelo (bump + `authz:reconcile`), como `subject_relation` en
alpha.2→alpha.3 ✅ §Upgrading.

### 2.7 Casos de prueba que esperaríamos (nombres en el estilo de la suite)
- *"deny en relación gana sobre el allow directo"*; *"deny antes del allow también bloquea"*; *"deny repetido no se
  duplica; un removeDeny lo levanta"*.
- *"deny a un userset bloquea a sus miembros"*; *"deny directo bloquea aunque el sujeto sea miembro de un grupo con
  allow"*.
- *"deny caducado no bloquea (estricto, al instante)"*; *"renovar la caducidad de un deny es delete+insert"* (database).
- *"listObjects omite los objetos denegados aunque haya más denies que el tope del backend"* (contra el segundo OpenFGA
  con tope 3, como *listScopes resta el deny…* ✅).
- *"listSubjects y membersOf omiten a los denegados"*; *"purgeObject borra también los denies"*.
- *"un deny en viewer bloquea al manager"* (o su contrario, según 2.5).
- *"un deny no afecta a hasRole ni a authorize"*.
- *"reconcile migra los denies como denies"*.

---

## 3 · P2 · `listObjectsForSubject` sin partición ("Compartido conmigo")

### 3.1 Necesidad
`listObjects(subject, relation, objectType, partition)` exige partición ✅. "¿Qué me han compartido, en cualquier
organización?" es la pregunta inversa y no tiene respuesta en el motor; recorrer todas las particiones es leer el
store entero. El consumidor tendría que mantener un **índice local** (tabla `tenancy_access_meta` o similar) que
duplica al motor y puede quedar desfasado (caducidades, purgas, revocaciones). Es genérico: cualquier producto con
compartición entre tenants lo necesita.

### 3.2 Contrato propuesto
```ts
await rel.listObjectsForSubject(
  subject: RelSubject,            // holder directo (users:<uuid>, integrations:<uuid>); ❓ ¿usersets?
  relation: string,
  objectType: string,
  page?: RelationPage,
  options?: { partitions?: ScopeRef[] }   // opcional: acotar a un conjunto; sin ello, todas
): Promise<RelationObjectsPageWithPartition>   // cada objeto viene con su partición
```
- Devuelve **solo tuplas directas y vivas** del sujeto (como el resto de `list*`: "direct facts" ✅ semántica 7) más,
  si el paquete lo admite, las que llegan por usersets de los que el sujeto es miembro (❓ coste en openfga).
- Respeta deny (P1) y caducidad.
- Paginación estable; en `openfga`, si el backend no puede responder sin partición, el driver puede: (a) iterar
  particiones candidatas obtenidas de un **índice propio del driver** (`authz_relations` ya tiene `subject_type/uuid`
  indexables en `database`; en `openfga` el driver podría mantener una tabla auxiliar `authz_subject_partitions`), o
  (b) declarar `capabilities.listObjectsForSubject = false` y que el consumidor lo sepa en arranque (como
  `membersOf` es database-only ✅ §"Reading capabilities at runtime").

### 3.3 Casos de prueba
- *"lo compartido con un sujeto en dos particiones sale entero y con su partición"*.
- *"una tupla caducada o denegada no aparece en listObjectsForSubject"*.
- *"purgeSubject en una partición no toca lo compartido en otra"*; *"purgeScope de la partición dueña lo retira"*.
- *"paginación estable entre páginas aunque se inserte una tupla nueva"*.
- *"capabilities declara si el driver lo soporta; si no, lanza E_AUTHZ_UNSUPPORTED en vez de responder vacío"* (nunca
  un `[]` silencioso: en el consumidor eso sería un fail-open de visibilidad al revés —el usuario no ve lo que sí
  tiene— pero sobre todo rompería la promesa "los list* son exhaustivos").

---

## 4 · P3 · Metadatos por tupla

### 4.1 Necesidad
Quién concedió, cuándo, motivo, si fue auto-concedida, encargado. Hoy en `api-cognitiv` vive en una tabla aparte por
tipo de objeto (`ia_space_access_meta` para las colecciones de IA) con su costura; la tenencia necesitaría otra
(`tenancy_access_meta`). Es genérico: toda compartición tiene un "por qué" que hay que mostrar y auditar.

### 4.2 Contrato propuesto
```ts
await rel.relate(subject, relation, object, partition, { expiresAt, meta: { grantedBy: 'users:…', reason: '…' } })
// meta: Record<string, string | number | boolean | null>, ≤ 2 KB serializado, opaco para el motor
await rel.listSubjects(relation, object, partition)   // cada fila incluye `meta`
```
- El motor **no interpreta** `meta`; solo lo guarda, lo devuelve en `list*`/`enumerateRelations`, lo migra en
  `reconcile` y lo borra con la tupla.
- Tres estados como `expiresAt`: omitido conserva, `null` borra, objeto sustituye (nunca merge parcial).
- En `openfga` el store no admite metadatos por tupla ❓: el driver tendría que guardarlos en una tabla auxiliar
  (`authz_relation_meta` por clave canónica de la tupla). Si el paquete prefiere **no** cargar el driver `openfga` con
  una tabla SQL, puede declararlo por `capabilities.relationMeta` y el consumidor seguiría con su tabla propia; en ese
  caso pedimos al menos que **`relate` devuelva un identificador estable de la tupla** (hoy `database` cambia el uuid
  al renovar ✅) o la clave canónica, para que la tabla externa pueda referenciarla sin reconstruirla.

### 4.3 Casos de prueba
- *"meta se guarda con la tupla y vuelve en listSubjects"*; *"meta no influye en check"*; *"renovar la caducidad
  conserva meta si se omite y la borra con null"*; *"purge borra meta"*; *"reconcile migra meta"*; *"meta > 2 KB es 422"*.

---

## 5 · P4 · `checkMany` / `checkChain`

### 5.1 Necesidad
El evaluador de herencia del consumidor, para decidir sobre `Finanzas/2026/Nóminas/informe.pdf`, pregunta al motor por
el archivo y por cada ancestro (profundidad típica 3–8, máximo que admitimos 20). Hoy son N `check` secuenciales; en
`openfga` son N viajes de red por petición HTTP de un usuario.

### 5.2 Contrato propuesto
```ts
await rel.checkMany(subject, relation, objects: RelObject[], partition): Promise<boolean[]>   // mismo orden
```
- Semántica idéntica a N `check` (deny, caducidad, usersets, `includes`), **todo o nada en errores**: si un elemento
  falla con 503, toda la llamada es 503 (como el `batchCheck` del motor de roles que ya trata un `error` por ítem como
  503 ✅ semántica 5). Nunca un `false` que esconda una caída.
- `database`: una consulta con `IN`; `openfga`: `batchCheck` (ya usado por roles ✅) con troceado por el tope del
  servidor.
- Tope de objetos por llamada (p. ej. 50) ⇒ 422 por encima.

### 5.3 Casos de prueba
- *"checkMany equivale a N check (incluidos deny, caducado y userset)"*; *"un error en un ítem es 503 para todos"*;
  *"más de 50 objetos es 422"*; *"orden de la respuesta = orden de la petición"*.

---

## 6 · P5 · Reloj inyectable, expuesto y documentado para el consumidor

El `RelationsManager` ya acepta `clock` (`RelationsManagerOptions.clock` ✅ `manager.d.ts:32`) y "the provider passes
`config.clock`" ✅. En `api-cognitiv` `config/authorization.ts` no lo fija, y nuestros tests de caducidad siembran
fechas pasadas en vez de mover el reloj: el borde exacto ("expira *ahora*") no es observable desde el consumidor.
Pedimos: (a) un helper documentado para tests del consumidor (`withClock(() => Date)` sobre la instancia del provider,
o una sección del README "Testing expiry from your app"), y (b) que el `clock` se propague también a `listObjectsForSubject`
y `checkMany` cuando existan.

---

## 7 · Lo que NO pedimos (y por qué)

**Herencia objeto→objeto (`from`, tuple-to-userset: "viewer de la carpeta ⇒ viewer de su contenido").** Es genérica y
el README la deja fuera de v1 a propósito ("includes, no `from` in v1" ✅). No la pedimos ahora porque: (1) un árbol de
carpetas agota con facilidad el techo de profundidad de resolución de OpenFGA; (2) **mover** una carpeta exige
reescribir las tuplas `parent` del subárbol en los dos drivers con garantías transaccionales que hoy el motor de
relaciones no ofrece; (3) nuestro evaluador con cadena de ancestros es más barato, determinista y comprobable. Si un
segundo consumidor lo necesita, proponemos diseñarlo entonces con lo aprendido en la tenencia (y con P1 y P4 ya
resueltos, el evaluador externo queda muy fino: una `checkMany` sobre la cadena y la regla "deny gana").

**Compartir con una organización entera como sujeto** (`organizations:<uuid>` de OTRA partición). Verificado ✅ que
un userset (`group#member`) no puede cruzar particiones (trigger en `database`, forma del id en `openfga`). Lo
resolveremos, si llega, en el consumidor (expansión de la membresía de la org destino en cada petición). No pedimos
cambiar esa regla: es una garantía de aislamiento.

---

## 8 · Compatibilidad y entrega

- Las cinco peticiones son **aditivas**: ningún método existente cambia de firma. P1 y P3 cambian el modelo `openfga`
  publicado ⇒ bump de modelo con `authz:reconcile` y nota en §Upgrading, como en alphas anteriores.
- Cada petición debería entrar con sus casos en la **suite común que juzga a todos los drivers** ("Custom drivers,
  judged by the same suite" ✅) y con `capabilities` para lo que un driver no pueda ofrecer.
- Orden sugerido: P1 → P4 → P5 (pequeñas, desbloquean la F0 de la tenencia) → P3 → P2 (la de más diseño).
- Versión: todo cabe en la línea `2.4.x` / `2.5` sin romper 2.x. Si P1 cambia la semántica de `listObjects`
  (omitir denegados), es un cambio observable: proponemos que vaya en **minor** con nota, no en patch.

## 9 · Preguntas abiertas para el paquete ❓

1. P1 §2.5: ¿deny por relación literal, o deny en `viewer` bloquea también a `editor`/`manager`?
2. P1 §2.4: ¿comodín `*` solo para deny?
3. P2: ¿usersets incluidos en `listObjectsForSubject` o solo tuplas directas?
4. P3: ¿`meta` en el driver `openfga` (tabla auxiliar) o `capabilities.relationMeta=false` + identificador estable?
5. P4: tope por llamada y comportamiento con duplicados en `objects`.

Contacto de vuelta: el consumidor adapta su evaluador a lo que el paquete fije; cualquiera de las dos respuestas de
cada pregunta nos vale, lo que necesitamos es que esté **fijada en la suite con un caso con nombre**.
