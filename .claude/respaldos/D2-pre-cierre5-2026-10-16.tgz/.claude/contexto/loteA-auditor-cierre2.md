# Re-ataque del auditor al cierre-2 del lote A (roles × `scopeSpellings`) — 2026-10-14

Alcance: solo la regresión posible en ROLES por el cambio de `scopeSpellings` (`src/identity.ts:272`) a
`isNonCanonicalUuid`, más la pregunta R2 (exit 1 con `pruned: false`). Repro: `.claude/reproducciones/loteA-cierre2-reataque.spec.ts`
(runner `loteA-cierre2-run.ts`; `env -u TEST_DB -u OPENFGA_TEST_URL node --import @poppinss/ts-exec .claude/reproducciones/loteA-cierre2-run.ts`
⇒ **5 passed / 5**, VERDE = hecho/defecto presente). Solo dobles en memoria.

## Veredicto en una línea
Seguro con reservas: no hay regresión 🔴/🟠 en roles. Hay una ampliación 🟡 de un defecto de clase que ya existía desde 3b-2h/3b-8:
la regla nueva es MÁS ANCHA que lo que funde PostgreSQL, y el docblock dice lo contrario.

## Hallazgos (ordenados por severidad)

### 🟡 C2-1/C2-2/C2-3 · `isNonCanonicalUuid` es un superconjunto de lo que funde PG; el fan-out sin cadena puede alcanzar un scope VIVO ajeno
- Escenario: un consumidor con ids de scope de TEXTO (no columna `uuid`) que deja elegir el id (slug) a un tenant; la víctima tiene
  `unit:a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11` con un deny de `U` sobre `P` heredando de `org` un grant de `P`. El atacante usa el id
  `a0e-ebc999c0b4ef8bb6d6bb9bd380a11` (o `-<32hex>`, `<32hex>-`, `xxxxxxxx--…`: son ≤36 chars y legales por `[a-z0-9_.-]+`; PG
  **no** los acepta como uuid —solo admite guiones «after any group of four digits»—). Crea su unit, la borra y el consumidor llama
  `scopes.detached` (sin `within`) ⇒ sin cadena ⇒ `scopeSpellings` devuelve `[alias, canónica-víctima]` ⇒ `purgeScope` + `onScopeDetached`
  sobre la víctima VIVA. En `database`, `purgeScope` borra `authz_assignments` **y `authz_denies`** de la víctima mientras la herencia
  viene del resolutor ⇒ el deny desaparece y `U` vuelve a tener `P` heredado: **fail-open cross-tenant**. En `facts` se borra además la
  arista `parent` ⇒ DoS (fail-closed). Mismo camino con `removeDeny`/`revoke` por `canonicalScopeTargets` (repro C2-3).
- Evidencia: ✅ `src/identity.ts:272-276` (antes del cierre-2 `DASHLESS_UUID` exigía 32 hex puros ⇒ estas formas devolvían `[id]`);
  ✅ `src/manager.ts:1123`; ✅ `src/shared/backend_guard.ts:297-309`; ✅ `src/drivers/database_driver.ts:1212-1238` (borra denies);
  ✅ repro C2-1 (4 formas no-PG ⇒ 2 ortografías), C2-2 (detached de alias inexistente purga `unit:<víctima>` viva), C2-3.
  Doc PG verificada (postgresql.org/docs/current/datatype-uuid.html). El docblock de `scopeSpellings`/`isNonCanonicalUuid` afirma
  «esas son TODAS las formas que PG funde»: es falso en los dos sentidos (ver ⚪ C2-4) y el de `canonicalScopeTargets` dice
  «Quitar nunca concede, así que borrar de más no existe aquí»: falso para `removeDeny` y para `purgeScope` en `database`.
- Por qué 🟡 y no 🟠: la clase es PREEXISTENTE (con `<32hex>` sin guiones ya pasaba desde 3b-2h/3b-8: un tenant de la «población B»
  con id de 32 hex coincidente con el uuid de otro scope) y exige ids de scope de texto elegibles por el atacante + `detached` sin
  `within` (o una policy de `removeDeny` que autorice sobre un scope inexistente). Con columna `uuid` de PG el atacante no puede crear
  esas formas (o PG las rechaza o las funde con la víctima ⇒ unique/403). El cierre-2 solo AMPLÍA el conjunto de ids peligrosos, y con
  formas que PG ni siquiera reconoce (expansión sin beneficio).
- Steelman: «sin la fila no se sabe cuál es la buena; expandir de más solo cuesta un delete vacío». → No me convence del todo: el
  delete NO es vacío cuando la canónica es otro scope vivo, y para `-<hex>`/`a0e-…` no hay ningún motor del README que las funda.
- Mitigación mínima: que `scopeSpellings` (no `assertPartition`, donde 422 de más es inocuo) expanda solo formas que un motor funde
  (grupos de 4 alineados: `/^([0-9a-f]{4}-?){7}[0-9a-f]{4}$/`), y/o que la canónica añadida se descarte si el resolutor la conoce VIVA.
  Corregir los dos docblocks.

### ⚪ C2-4 · formas que PG SÍ funde y no caben en 36 chars mueren en `assertScope`
- Escenario: `DELETE /units/a0ee-bc99-9c0b-4ef8-bb6d-6bb9-bd38-0a11` (ejemplo literal de la doc de PG, 39 chars) acierta con la fila
  en PG; el consumidor pasa el parámetro de la URL a `detached` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` ⇒ los hechos de la canónica quedan.
- Evidencia: ✅ repro C2-4; `IDENTITY_LIMITS.uuid = 36`.
- Steelman: es ruidoso (422), no silencioso; el consumidor ve el fallo. → Me convence: higiene/doc, no explotable en silencio.
- Mitigación: declarar en el docblock que el conjunto es «≤36 chars»; nada de código.

### ⚪ R2 · `pruned: false` ⇒ exit 1 hasta borrado manual
- Con `database`/`openfga` (los drivers del paquete rechazan en `unrelate` por gramática), una sola tupla rota en el destino deja
  `relations:reconcile --prune` (real) en exit 1 y `--dry-run --prune` «no clean» hasta que alguien la borre a mano (SQL/SDK). Sin
  `--prune` es warning y `clean` (tabla del informe). No es rojo PERMANENTE: es rojo hasta la acción manual, y está declarado
  (CHANGELOG:126-134, informe §⚪ R2, pregunta abierta al dueño). Matiz: la línea del dry-run («se pedirá al driver… si la rechaza… lo
  dirá») sugiere que la pasada real lo arreglará cuando con los drivers del paquete NUNCA lo hará; un runbook COGNITIV que haga
  dry-run ⇒ real esperando verde descubrirá el rojo una pasada tarde. `cutover-verify` no existe en este repo (es del lado COGNITIV):
  ❓ no verificable aquí si su paso tolera exit 1 con `details` de `invalid-identity`.
- Mitigación: que la línea del dry-run diga explícitamente que `database`/`openfga` la rechazarán y hay que borrarla a mano ya.

## Lo que intenté y NO se rompió
- **Uuid canónico ⇒ 1 ortografía** (✅ control): no se duplican purgas, recibos de outbox ni filas para el caso normal.
- **Ids no-uuid** (`z`×32, slug, 31/33 hex, `a.b_c`) ⇒ exactamente `[id]` (✅ control).
- **`scopeKey` sin cambios** (el diff de `identity.ts` no lo toca; `unit|<uuid>`); los ids `role_binding:<scopeKey>|<uuid>` se componen
  con `scopeKey(target)` en `revoke` (`openfga_driver.ts:1236`) ⇒ byte a byte idénticos.
- **Deletes de tuplas inexistentes en openfga**: `revoke`, `removeDeny`, `purgeScope` y barridos usan
  `onMissingDeletes: Ignore` (`openfga_driver.ts:1238, 1289, 2050, 1967, 2303, 3434`); `purgeScope` además lee antes de borrar ⇒ no
  hay 400 por la canónica extra. (Requiere un servidor con soporte de `conflict`; preexistente, no lo introduce el cierre-2.)
- **Seguro de borrado masivo**: `E_AUTHZ_MASS_PURGE_REFUSED` es de `pruneOrphanRoles`, `massDelete` de reconcile; ninguno consume
  `scopeSpellings` ⇒ sin efecto.
- **Outbox/relay**: una fila por ortografía (ya era así para 32 hex); con `limit` el relevo puede aplicar el alias y dejar la canónica
  para la siguiente pasada — reanudable, sin pérdida. Sin cambio de semántica, solo más filas para formas no canónicas.
- **Con fila viva** sigue siendo `[chain[0]]` (manager y `canonicalScopeTargets`): la ampliación solo actúa sin cadena.

## Preguntas abiertas para el arquitecto
1. ¿Se acepta que la expansión de ROLES use una regla más ancha que la fusión real de los motores (y con ello amplíe C2-2), o se
   separa `scopeSpellings` (fusión real, grupos de 4) de `isNonCanonicalUuid` (422 de particiones, donde más ancho es inocuo)?
   Ojo: la decisión del dueño fue «UNA función en los dos puertos»; separar contradice la letra, no el espíritu.
2. ¿El fan-out sin cadena debe descartar una ortografía que el resolutor reconoce VIVA? Cierra C2-2/C2-3 también para el caso
   32-hex preexistente.
