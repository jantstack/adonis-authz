# Panel «paquete óptimo» — juez (2026-10-16)

Fuentes: `panel-optimo-brief.md`, `panel-optimo-analista-renovacion.md` (AR), `panel-optimo-analista-global.md` (AG),
`panel-optimo-auditor.md` (AU), `panel-optimo-tester.md` (TE); contexto `loteD2-auditor-cierre4.md`, `RETOMAR.md`,
`decisiones-dueno-2026-08-28.md` (§2026-10-14 (2), §2026-10-15 (8) y (9)), `linajes.md`.
Lecturas propias (solo lectura): `.claude/reproducciones/panel-optimo-renovacion.ts:190-265` (fase `hammer`),
`panel-optimo-tester-mbb.ts:76,83`, `panel-optimo-auditor-slots.ts:176`, `src/drivers/openfga_relations_driver.ts:106-121,1366-1410`,
`src/drivers/openfga_driver.ts:1758-1774`, `src/relations/define_relations_config.ts:73,614`. No ejecuté nada contra OpenFGA.

## Veredicto

**Recomendación:** opción **B: make-before-break con la ranura `member_alt` solo en `group.member`, más una gracia
G ≥ `--request-timeout`**. Va como sublote **D2-R**, que sustituye los cierres 2–4, y lleva los injertos de abajo.
Puntuación: **75/100**, frente a 60,5 de A y 37,5 de C.

Por qué decide:
- Es la única opción con una medición que pone a prueba la propiedad que importa: que ningún `Check` concurrente conceda.
  Midió 0 concesiones en unos 360 000 `Check`, y la cota «G ≥ request-timeout» se puede demostrar.
- Borra la familia que ha producido un naranja por cierre (`renewal-unsafe`, retención, `carrier-conflict`, RACED) en vez
  de pedir un quinto cierre de L10.

La variante «swap en UN `Write`» (la hipótesis del brief, y lo que el tester y el auditor dieron por bueno) queda
**descalificada**: midió entre un 1,4 y un 1,8 % de concesiones a un denegado.

**Con estos injertos de otras opciones:**
1. **AU I1–I4 como estructura, no como disciplina.**
   - Un punto de paso único `slotsOf` para toda lectura y todo borrado.
   - Columna `slots` en la guardia de superficie, con un mutante por entrada.
   - Borrar = las dos ranuras en un `Write`.
   - La reparación de dos ranuras pasa por `tuple_order`: la dominada primero, y con G.
   - Deriva `two-slots`/`folded-slot` en el reconcile; la ranura nunca es `undeclared` (AU MB-6, TE P4).
2. **AU I6 sobre lo que ya existe (D10/D12/D14).**
   - La ranura nace en el MISMO modelo que introduce `denied_*`, ya en la fase `'read'`.
   - Las escrituras en `member_alt` solo se habilitan cuando algún tipo está en `'write'`.
   - `openfga:provision` se niega a publicar un modelo sin ranura si quedan `*_alt` vivas.
   - El rollback queda prohibido, extendiendo D12.
   - Como nadie tiene todavía un modelo con deny (alpha.3 sin publicar), MB-2 se reduce al deber que D10/D14 ya imponen.
3. **AU MB-4 / TE M4.** Un 400 «cannot delete a tuple which does not exist» o «already exists» se trata como choque: se
   relee `{user, object}` y se re-aplica; si no cede, 409. Nunca 503. Se reutiliza `isTreeWriteRace`.
4. **TE hook (a) en el juez publicado.** La cara `atomicRenewal: true` tiene que observar el estado intermedio
   (`interruptBackendAfter(k)` o el número de escrituras de backend), no solo el final.
5. **TE opción (ii) / AR §5.7.** Un destino sin `atomicRenewal`, con opt-in de deny, da 500 por adelantado en
   `runRelationsReconcile`. Con eso se borran la rama «dos Write» de la fuerza bruta, `relationWithheldWrites`,
   13 mutantes, el oráculo `preexisting` (H2) y D4-1/2/3.
6. **AU R2 (D-31 en todos los tipos y en `group`) entra en D2-R.** La ranura cambia las reglas de `group`; sin esto, un
   modelo fijado viejo concede sin error (medido en tipos sin deny).
7. **AR §5.3.** `renewalGraceMs` se valida como `listObjectsDeadlineMs` («declara el `--request-timeout` del servidor»;
   default 3 000). Con `consistency: 'minimize_latency'`, 500 salvo que se declare además el TTL de la caché.
8. **TE §3.1.** Caso literal U2 para `order.c4.off` (es de seguridad y hoy solo muere por cifras), literal `walkVigencia`
   para `c4h.order.renewals-not-changing`, y los mutantes del cierre 4 que sobrevivan al borrado entran al manifiesto.
   `priority.deletes-first` y `c2.no-exclusion` quedan declarados como «cifras» con su razón.

**Condición para proceder:**
1. Que el dueño firme las decisiones 1–3 de la última sección.
2. Que antes de la primera línea de D2-R se hagan dos mediciones. Son el primer caso del sublote, no un supuesto:
   - (a) La cota de G: en un `openfga-tiny` con `--request-timeout` corto (p. ej. 200 ms), comprobar que un `Check` más
     largo NO devuelve decisión. Es el 🟡 de AR §3.2.
   - (b) La concurrencia de make-before-break en dos `Write` (creador rancio frente a renovador; renovador frente a
     renovador). AR §3.5 la tiene diseñada, no medida.

---

## Criterios (fijados antes de leer las posturas; los pidió el coordinador)

| Criterio | Peso | Qué mide |
|---|---|---|
| Seguridad demostrable | 30 | Fail-open medido o abierto y no mitigado en la propia opción; garantía demostrable frente a garantía probabilística |
| Flexibilidad para el consumidor | 15 | Qué puede hacer el consumidor (renovar, migrar) sin 409/500 de diseño |
| Rendimiento medido | 10 | Latencia de `Check`/`BatchCheck`, coste de renovación, cotas (profundidad, bytes), solo con cifra |
| Simplicidad / coste de mantenimiento y verificación | 20 | Código y tests netos, tiempo del gate, número de clases de error y de motivos |
| Riesgo de calendario hacia la RC | 15 | Tamaño e incertidumbre del trabajo que falta hasta alpha.3 y la RC |
| Impacto en COGNITIV | 10 | Rupturas, despliegue, latencia y superficie que tienen que entender |

Cada criterio se puntúa de 0 a 10; el total es la suma de puntuación × peso / 10.

## Tabla de puntuación (opciones de D2)

Las tres opciones, tal como las entiendo:
- **A.** Negar la partición con cero escrituras y receta, sin ranuras. Se borra la retención en cascada. Se conservan
  `#carriedDeny`, el 409 de §2026-10-15 (9) y RACED, y la renovación sigue en dos `Write`.
- **B.** D2-R con los injertos de arriba.
- **C.** Un quinto cierre de la retención: D4-1 como `carrier-conflict` de candidatos, más H2 y H3 del oráculo.

| Criterio (peso) | A | B | C | Nota |
|---|---|---|---|---|
| Seguridad (30) | 6 | 8 | 3 | **A** conserva la ventana TOCTOU de N1: un deny que aparece entre el `#carriedDeny` y el 2.º `Write` concede durante el hueco, y RACED solo lo detecta después. **B**: 0/360k medido y cota demostrable (falta verificar la cancelación del servidor); MB-1 y MB-2 son naranjas abiertos con mitigación dentro de la propia opción (injertos 1–2). **C**: D4-1 sigue abierto, el oráculo lo esconde (H2: 23 485/33 612/41 795) y L10 va por su 6.ª iteración |
| Flexibilidad (15) | 3 | 8 | 4 | **A**: una membresía con caducidad en un grupo con deny no se puede renovar en `openfga`. **B**: renueva siempre, a costa de G. **C**: negativas globales que un tenant puede forzar (D4-3) |
| Rendimiento (10) | 9 | 7 | 9 | **B**: el `Check` cuesta lo mismo (2,29–2,37 frente a 2,31–2,44 ms p50), el modelo crece un 0,6 % y la anidación baja de 25 a 24 niveles (AU, medido). Cada renovación de membresía suma +G (3 s) |
| Simplicidad / verificación (20) | 6 | 8 | 2 | **B**: neto −300 líneas de src y −600 de tests (🟡 estimado). Fuera el modo «dos Write» de la fuerza bruta (−1,56 s por mutante, −23 s de spec, medido por TE). Entra `slotsOf` más una columna de guardia. **A**: conserva la mitad no atómica de la fuerza bruta. **C**: la curva que llevó el gate de 6,5 a 17,5 min |
| Calendario (15) | 8 | 6 | 3 | **B** es una reescritura de los cierres 2–4, que siguen sin commit, más dos mediciones previas. **C** no tiene fin acotado: cada cierre abrió un naranja |
| COGNITIV (10) | 5 | 7 | 5 | **B**: el despliegue cabe en D10/D14, que ya aceptaron; 3 s por renovación (❓ si les vale); verán tuplas `member_alt` si leen el store a mano. **A**: 409 de diseño |
| **Total** | **60,5** | **75** | **37,5** | |

Ninguna opción tiene un rojo abierto. «B-swap» (un solo `Write`) sí lo tendría (fail-open medido con
`atomicRenewal: true` declarado) y queda fuera.

---

## Conflictos entre panelistas

### 1. Contradicción central: ¿basta el swap en un `Write`?

- **Posturas:** AR mide un 1,4–1,8 % de concesiones con el swap en un `Write`. TE (M2) dice «el deny no deja de cortar en
  ningún instante» y AU (S1) «sin ventana».
- **Manda la medición de AR.** Lo comprobé en los scripts:
  - El `hammer` de AR (`panel-optimo-renovacion.ts:215-263`) lanza 4 o 24 lectores `Check` concurrentes con
    `HIGHER_CONSISTENCY` mientras un renovador hace 300–600 swaps.
  - Comprueba que la siembra NO concede (`:209`) y que el estado final tampoco (`finalGranted: false`, `writeErrors: 0`).
    Así que toda concesión contada es una lectura intermedia.
  - TE y AU **no midieron con lectores concurrentes**:
    - M2 y S1 son `Check` SECUENCIALES antes y después del `Write`, en `now` y en +1,5 h / +2 h.
    - Su única concurrencia es entre ESCRITORES: `Promise.all` de renovadores en `panel-optimo-tester-mbb.ts:76,83`
      (M4/M5) y en `panel-optimo-auditor-slots.ts:176` (S11).
  - Eso prueba la atomicidad para el escritor, que AR también confirma. No prueba la propiedad para el lector.
- **Carga de la prueba:** la tenía quien afirma «un `Write` basta», y está falsada.
- **Lo que queda abierto en AR:**
  - El mecanismo («una lectura de datastore por relación») es inferido.
  - Medido solo con datastore postgres en v1.19.
  - La cota exige la condición 2(a).

### 2. TE P1/P2 frente al diseño de AR

- **P1** de TE exige «exactamente UN `client.write` `{writes, deletes}`». **P2** exige «≤ 1 ranura tras cada `Write`»,
  con la regla «escribir X borra ¬X en el mismo `Write`».
- Las dos son incompatibles con make-before-break, que deja dos ranuras vivas durante G a propósito.
- **Resolución:**
  - P1 pasa a ser «`Write` 1 (ranura libre, STRICT) → espera ≥ G (reloj/sleep inyectado) → `Write` 2 (borra la vieja)»,
    cortando el cliente en k = 0, 1, 2. Todo estado observable es el inicial, «ambas» o el final; «ambas» es la unión,
    que no concede nada que el inicial no concediera en ese instante.
  - P2 pasa a ser «≤ 2 ranuras; dos ranuras vivas solo en una renovación en vuelo o como deriva `two-slots` que el
    reconcile repara».
  - La carga es del implementador de D2-R, con la medición 2(b).

### 3. Creador rancio (AU MB-1/S4) frente a «gana el último escritor»

- Con dos ranuras, dos `relate` concurrentes con caducidades distintas pueden dejar las dos vivas. Manda la mayor, así que
  se pierde un acortamiento.
- Ni AR ni TE lo resuelven del todo. La regla M9 de TE («la creación borra ¬X en el mismo `Write`») reintroduce el swap en
  un `Write` y su lectura rasgada, aunque solo durante la carrera.
- **Resolución:** se declara.
  - La semántica de lectura es el máximo; nunca concede menos que el inicial.
  - Tras escribir, una relectura de `{user, object}`. Dos ranuras sin renovación en vuelo ⇒ deriva y `indeterminate`.
  - El acortamiento perdido en carrera es un residuo con letra y caso.
- Lo prueba P3 de TE contra el servidor real, con el resultado esperado escrito ANTES de implementar.

### 4. «Desaparece la familia entera» (brief) frente a «falso en el orden» (AU)

- No es un conflicto real.
- AR §6 («Lo que NO cae») y TE §1.4 coinciden con AU: el orden de L10 para transiciones multi-tupla y el horizonte
  `shortening` se quedan, y con ellos la rama `atomic: true` de la fuerza bruta.
- Lo que cae es la retención, `renewal-unsafe`, `carrier-conflict` y RACED.

### 5. ¿Qué sobra de la verificación? TE (i)/(ii) frente a AG §7

- AG da por hecho el borrado. TE demuestra que solo ocurre con la opción (ii).
- **Resolución:** injerto 5. Es la decisión 3 del dueño.

### 6. `moved` y `grant` de roles «a salvo» (AR, hallazgo lateral)

- AR afirma que `moved` es seguro porque reescribe la misma (objeto, relación) `parent`.
- En el modelo (c2r), `can_P`, `denied_P` y `rooted` recorren `parent` por TTU **en ramas distintas** del mismo `Check`.
  Si cada rama lee la tupla en un instante distinto, cabe una mezcla: el padre viejo para el allow y el nuevo para el deny.
- No está medido en ninguno de los dos sentidos. Entra en el barrido (abajo, punto 5) como ❓, no como hecho.

---

## Afirmaciones descartadas por falta de evidencia

- **Brief:** «swap en UN `Write` ⇒ `atomicRenewal: true` ⇒ desaparece la familia». Falsada por medición (AR §3.2).
- **TE M2:** «el deny no deja de cortar en ningún instante». Muestrea dos instantes en serie, sin lectores concurrentes.
- **AU S1:** «Sin ventana». Mismo motivo.
- **AR §6 y AG §8:** cifras de tamaño (−300/−600 líneas) y de tiempo (guard-mutants de 10–12 min; verificación de
  38 a ~17 min). Son 🟡 estimaciones; se tratan como incertidumbre, no como ahorro comprometido.
- **AR §3.2:** «cota demostrable G ≥ `--request-timeout`». El razonamiento es correcto, pero depende de que el servidor
  cancele la resolución, y eso no está medido ⇒ condición 2(a).
- **AR, hallazgo lateral:** «`moved` queda a salvo». Sin medición; ver el conflicto 6.
- **AG §6:** el truncado del README a 64 KB en npmjs.com. Lo marca ❓ el propio panelista.
- **TE §2.3:** «≤ 1,5 min en CI» para G1+G2. Es una proyección; la condición de aceptación (los 181 mutantes en los dos
  modos con el mismo estado) es la que vale.

---

## Barrido: garantías que suponen que un lector ve atómico un `Write` multi-par (pregunta 3)

Lo medido es que un `Check` puede ver un `Write` a medias cuando ese `Write` toca pares (objeto, relación) distintos.
Por el mismo mecanismo, también puede ver dos `Write` consecutivos mezclados si el `Check` abarca el hueco: AR midió un
0,02 % con G = 0.

Por eso la doctrina de L10, verificada por la fuerza bruta sobre **prefijos**, no cubre al lector concurrente. Para
cada punto hace falta **medición** (adaptar `hammer`) y después una de dos: letra declarada, o gracia entre fases.

| # | Garantía | Dónde | Riesgo |
|---|---|---|---|
| 1 | Purga de relaciones: «cabe en 100 ⇒ UN `Write`, **no hay estado intermedio**» | `openfga_relations_driver.ts:110-111` y `:1374-1375` (docblock de `#purgeByFilters`); README «Deny on relations» | Un `Write` que borra un allow directo y la membresía que transporta el deny puede leerse como «allow aún vivo + deny ya no llega» ⇒ concede a un sujeto que no concedía ni antes ni después. **Prioridad 1** (es la frase publicada) |
| 2 | Reconcile de relaciones: «un `Write` transaccional si cabe» | punto de paso de L10 (`linajes.md`, `tuple_order.ts`) | Igual que el 1, en escritura (allow y portadora en el mismo `Write`) |
| 3 | L10 en general: orden denies → portadoras → resto → allows en `Write` consecutivos sin gracia | `tuple_order.ts`; propiedades `openfga.purge.order` y `relations.reconcile.order` | Un `Check` que abarque dos fases puede ver un estado que no es prefijo. Hay que reformular la propiedad como «ningún PREFIJO concede» y declarar el lector rasgado, o meter G entre fases |
| 4 | Roles `purgeScope` (estructura → hechos → denies) | `openfga.roles.purgeScope.order` | Igual que el 3 |
| 5 | Roles `moved`: delete y write de `scope#parent` en un `Write` | `openfga_driver.ts:1758+` | ❓ Lo leen varias ramas TTU (`can_P`, `denied_P`, `rooted`). Una mezcla «padre viejo concede / padre nuevo no niega» concedería. Medir |
| 6 | Roles `moved` más el barrido `sweepLocalRoleBindings` (inv. 18) | `openfga_driver.ts` | ❓ Si van en `Write` distintos (o en el mismo, por el 5): un rol local visible desde la cadena nueva durante el hueco |
| 7 | Roles: reconcile «un `Write` por lote con deletes y writes juntos» | `openfga_driver.ts:2240` | Igual que el 2 en la proyección y los hechos de roles |
| 8 | Lote C: `purgePartition` (si entra) | plan | Nace con esta clase: diseñarla con la regla resultante |
| — | A salvo (razonado, sin medir): el `grant` de tres tuplas (mezcla = fail-closed, `can_P` exige las tres); `projectCatalog` (cada `permits_P` es independiente y monótono); `replaceAssignment` (fail-closed); `deny` (una tupla) | | |

**Gravedad:** concesiones transitorias de un solo `Check`, nunca persistentes. Es la misma clase que el lag del relay,
que ya está aceptado y declarado, pero varias letras publicadas afirman lo contrario (linaje L8).

**Recomendación:** medir 1, 3 y 5 antes de la RC. Después, declarar con letra y caso. La gracia solo donde salga barata
(el reconcile); en la purga no, por el invariante 11: una purga no espera.

---

## Prioridades del resto (pregunta 4)

| Tema | Cuándo | Motivo |
|---|---|---|
| Aceleración del gate **G1 + G2** (solo `expectRed` por mutante, más copias en paralelo), con la prueba de equivalencia de una vez | **Antes de alpha.3, lo PRIMERO** (antes de D2-R) | D2-R va a pasar el gate varias veces; de 17,5 min a 3 min o menos sin perder detección. No se toca `src/` |
| G3 (fuerza bruta en una sola pierna de la matriz de CI, limitada a los 19 independientes del motor) | Antes de alpha.3 | Barato; sin pérdida |
| **R2 (AU): D-31 en todos los tipos y en `group`** | **Antes de alpha.3** (dentro de D2-R) | Naranja medido. La ranura cambia las reglas de `group` |
| R3 (AU), la parte que toca D2-R: «cannot delete» / «already exists» ⇒ choque/409; `validation_error` de `member_alt` con modelo viejo ⇒ 500 ANTES de escribir (TE P8) | **Antes de alpha.3** | Lo exige el diseño (invariante 6) |
| Mutantes solo por cifras: literal `c4.off` (U2), `walkVigencia` para `renewals-not-changing`, declarar `priority`/`no-exclusion`; los supervivientes del cierre 4 al manifiesto | **Antes de alpha.3** | `c4.off` es de seguridad. Lo demás es barato |
| Fila de «Limits»: anidación de grupos 25 → 24 con ranura | Antes de alpha.3 | La cifra cambia con D2-R |
| R3 (AU), la regla general: 4xx deterministas (`resolution_too_complex`, `validation_error`) nunca 503; clasificador único compartido por los dos drivers, más el ❓ del relay | Antes de la RC | Amarillo. Afecta a la política «503 ⇒ reintenta» del consumidor y de la outbox |
| R1 (AU): `relations.maxGroupDepth` (422 al anidar por encima) y `drift.tooDeep` | Antes de la RC | DoS con escrituras normales y paridad rota entre drivers. El gemelo de árbol ya existe |
| Letra del README de `authorize` (AG R1: 1 SQL con `'always'`, 503 con la base caída) | Antes de la RC | L8. Es una decisión de arquitectura del consumidor |
| `peerDependencies["@openfga/sdk"]` con rango `>=0.9.6 <0.10.0` y `engines.node >=24` | Antes de la RC (si cabe sin retrasar, en alpha.3) | Metadatos de una línea. Lo que entre en la RC es lo que fija COGNITIV |
| `RelationPage` ignorado ⇒ rechazar (500 `E_AUTHZ_UNSUPPORTED` con `page` ≠ `undefined`) | Antes de la RC | L5. Es firma pública: después de 2.5.0 sería major |
| Source maps fuera del tarball | Antes de la RC (decide el dueño) | −28 % gz; las trazas apuntan al `.js` |
| G5/G6 (el spec exhaustivo en `worker_threads` y un job `order-proof` por rutas) | Antes de la RC | Las cifras fijadas se re-fijan una vez |
| Barrido del lector rasgado (sección anterior) | Antes de la RC | Seguridad y letra |
| S1–S9 de AG (CTE ascendente, `batchCheckChunk`, `membersOf` con deny en 1–2 consultas, `WriteFunnel`, partir `manager.ts`, índices redundantes, README → docs) | 2.6 | Refactors o rendimiento sin defecto; no se re-anclan mutantes antes de la RC |
| Inventario de L10 por reflexión (AU R4) | 2.6 | Blanco |
| Ranura en `assignee` de roles | 2.6, opcional | `replaceAssignment` ya es fail-closed |
| **No hacer** | | VB lease (+50 % `Check`, ×2,8 `BatchCheck`); G empírico de 25 ms como garantía; ranura en allows o en `denied_*` (+50–60 % `BatchCheck`); I7 marcador «≤ 1» (×2 tuplas); muestrear mutantes; cambiar el default de `catalogRevalidate`; bajar `FGA_MAX_BATCH_CHECK` sin medir en producción; refactors de `src/` antes de la RC |

---

## Plan por fases

**Fase 0 (antes de D2-R; horas, sin tocar `src/`)**
1. Respaldar el árbol actual (`.tgz` en `.claude/respaldos/`).
2. G1 + G2 + G3 en `check_guard_mutants.mjs`, con la prueba de equivalencia sobre los 181 mutantes.
3. Mediciones previas:
   - 2(a) cota de G con `openfga-tiny`;
   - 2(b) concurrencia de make-before-break;
   - punto 1 del barrido (purga en un `Write` con lectores, adaptando `hammer`).

**Fase 1: sublote D2-R (⇒ alpha.3)**
- **Modelo:** ranura `member_alt` condicionada al opt-in de deny, presente desde la fase `'read'`; D-29 intacto sin opt-in.
- **`relate`:** make-before-break con G y CAS. Clasificación de choques (injerto 3).
- **`unrelate` y purgas:** borran las dos ranuras.
- **Lecturas:** `slotsOf` como punto único, con columna `slots` en la guardia.
- **Reconcile:** pliega con el máximo, deriva `two-slots`, reparación por `tuple_order` con G.
- **Capacidades:** `atomicRenewal: true` en `openfga`; 500 para destinos no atómicos con deny (ii).
- **Se borra:** retención, `renewal-unsafe`, `carrier-conflict`, RACED y `#carriedDeny`. Un deny condicional vivo en
  el destino ⇒ negativa simple (AR §5.6).
- **Modelo fijado y despliegue:** D-31 en todos los tipos; guarda de `provision` y rollback prohibido.
- **Validación:** `renewalGraceMs`.
- **Juez publicado:** hook (a).
- **Casos:** P1–P9 reescritos (conflicto 2), literales de §3.1 de TE, fila de «Limits».
- **Cierre:** tester y auditor sobre D2-R, verificación en 4 modos, alpha.3.

**Fase 2 (antes de la RC)**
- R3 general, R1, letra de `authorize`, metadatos, `RelationPage`, source maps y G5/G6.
- Conclusión del barrido del lector rasgado: letras y casos; L10 reformulada como «prefijos» más el residuo declarado.
- Lote C con la regla resultante.
- Auditoría de sistema de la RC.

**2.6:** S1–S9, R4, la ranura en roles. **3.0:** T1–T3 de AG.

---

## Riesgos que quedan aunque se elija la ganadora

- **La garantía depende de un parámetro del SERVIDOR** que declara el operador (`--request-timeout`). Si se declara
  mal, vuelve la lectura rasgada, y el paquete no lo puede comprobar en tiempo de ejecución (es la misma clase que
  `listObjectsDeadlineMs`).
- **Con `minimize_latency` y las cachés del servidor activas, G no está medido** (❓). El injerto 7 lo cierra con un 500.
- **Escritores ajenos al paquete** (SDK, `fga tuple write`) no conocen `member_alt`: un `unrelate` suyo no revoca
  (MB-8). Se declara y el reconcile lo lista.
- **Flota mixta durante el despliegue** (MB-2). Depende de seguir D10/D14; la guarda de `provision` cubre la publicación,
  no el pod viejo.
- **Dos `relate` concurrentes con caducidades distintas:** se pierde el acortamiento (conflicto 3, residuo declarado).
- **Proceso que muere entre los dos `Write`:** quedan dos ranuras. Una extensión queda bien; un acortamiento queda sin
  aplicar (`indeterminate`) hasta que el reconcile lo repara.
- **Anidación de grupos:** un nivel menos (24).
- **Renovación más lenta:** +3 s por renovación de membresía con otra caducidad (solo con deny activo), y +G por pasada
  del reconcile.
- **Orden de L10 para acortamientos:** sigue y conserva su fuerza bruta atómica.
- **Clase del lector rasgado** en purgas, reconcile y `moved` de roles (barrido): es independiente de la opción elegida y
  sigue abierta hasta la fase 2.

---

## Decisiones que necesita el dueño

1. **Camino de D2.**
   - Recomiendo **B (D2-R)**.
   - **Coste:** reescribir los cierres 2–4 (sin commit; se respaldan), más dos mediciones previas. alpha.3 se retrasa un
     sublote con su auditoría, pero se acaba la cadena de cierres de L10.
   - Alternativa: A (60,5), si no se aceptan los 3 s.
2. **Aceptar G = `--request-timeout` del servidor (3 s por defecto) por renovación de membresía con otra caducidad**,
   solo con opt-in de deny, o bajar `--request-timeout` en el servidor.
   - Recomiendo **aceptar**, con `renewalGraceMs` configurable al valor declarado.
   - **Coste:** latencia en una operación poco frecuente.
   - No recomiendo un G empírico de 25 ms: deja de ser garantía.
3. **Destinos sin `atomicRenewal` con deny en el reconcile.**
   - Recomiendo **(ii) 500 por adelantado**.
   - **Coste:** un driver de terceros tiene que implementar la renovación atómica para recibir denies. No rompe a nadie,
     porque D2 no está publicado.
   - Con (i) se conserva toda la maquinaria y D4-1/2/3 siguen abiertos para terceros.
4. **Hook de corte en el juez publicado** (cara `atomicRenewal: true` con `BOTH_FACES_REQUIRED`).
   - Recomiendo **sí**.
   - **Coste:** API nueva del harness.
5. **«≤ 1 ranura»:** higiene estructural con I1–I4 y la columna `slots`, o el marcador I7.
   - Recomiendo **I1–I4, sin I7**.
   - **Coste de I7, si se quisiera:** ×2 tuplas por relación.
6. **D-31 en todos los tipos (AU R2) dentro de D2-R.**
   - Recomiendo **sí**.
   - **Coste:** un modelo fijado que hoy se tolera pasa a ser 500 al usarlo, lo que solo afecta a despliegues ya mal
     configurados.
7. **Lector rasgado** (barrido).
   - Recomiendo **medir antes de la RC y DECLARAR** con letra y caso (concesión transitoria de un `Check`, como el lag del
     relay). Gracia solo en el reconcile.
   - **Coste:** reformular la propiedad de L10 («prefijos») y corregir las frases «sin estado intermedio».
8. **Gate:** G1 + G2 + G3 ya, y una pasada completa con colaterales en nocturno.
   - Recomiendo **sí**.
   - **Coste:** un script, más una corrida de equivalencia.
9. **Metadatos y empaquetado:**
   - rango del SDK — **sí**;
   - `engines >=24` — **sí**, con el gate local en Node 24;
   - source maps fuera — **sí** (−28 % gz).
   - **Coste:** mínimo; ruptura de metadato mientras aún es alpha.
10. **`RelationPage`:** rechazar o honrar.
    - Recomiendo **rechazar (500)** antes de la RC.
    - **Coste:** un caso por operación y una columna en la guardia.

## Lo que preguntaría al humano antes de implementar

- ¿COGNITIV renueva membresías con caducidad en grupos que transportan deny (frecuencia, y si una petición HTTP puede
  esperar ~3 s)? ¿Puede su OpenFGA correr con un `--request-timeout` menor? Esto cambia la decisión 2 y, si la respuesta
  es «no» a todo, el camino pasa a ser A.
- ¿COGNITIV escribe o borra tuplas en el store compartido fuera del paquete (SDK propio, import)? Si sí, MB-8 deja de
  ser un residuo teórico y hay que valorar I7.
- ¿`purgePartition` (lote C o 2.6, pendiente) sigue en C? Si sí, nace bajo la regla del barrido del lector rasgado.
