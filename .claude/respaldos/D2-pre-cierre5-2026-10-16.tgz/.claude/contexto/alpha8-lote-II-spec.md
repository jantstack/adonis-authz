# Lote alpha.8 · Implementador II — edad de la cola, `requireTransaction`, menores, docs

Prerrequisito: implementador I terminó (cursor C2/C1, X-1, raíz exenta + variante B, `requeue --apply`,
`waitForLeaseMs`), verificado en 4 modos. Leer `alpha8-informe-I.md` y el diff. Decisiones: `decisiones-dueno-2026-08-28.md`
§2026-09-10 (4); veredicto `panel-relay2-juez.md` cuestiones 5, 6, 7.

## Edad de la cola (fácil)
`PendingScopeTreeChange.createdAt?: Date` opcional (el `rowToPending` de `sqlScopeOutbox` lo devuelve: `created_at` ya
existe); `ScopeRelayReport.queue: { oldestPendingAt: Date | null, pendingAgeMs: number | null }` GLOBAL (también bajo
`only`), calculado con el reloj inyectable del manager (`Math.max(0, now - createdAt)`; JAMÁS `Date.now()` en `src/`:
`tests/clock.spec.ts` lo caza) reusando el `pending(1)` que la pasada ya hace al final; un `ScopeOutbox` de terceros sin
`createdAt` ⇒ `null`, no 0. `authz:scopes:relay --max-age=<ms>` ⇒ exit ≠ 0 si `pendingAgeMs > max` (solo con umbral).
Casos (rojo = B2 de COGNITIV: 10 pasadas con 503, `attempts` 0, `dead` 0 y nada de tiempo): con reloj inyectado la edad
crece entre pasadas; bajo `only` sigue siendo global; terceros ⇒ `null`; `--max-age` rojo/verde; contrato del puerto:
par de capacidad `createdAt`. `parkAfterMs` NO existe (no lo añadas).

## `enqueue` sin `{ transaction }` (fácil)
Opción `requireTransaction?: boolean` en `sqlScopeOutbox` (y en `config.scopes.outbox` si el manager la construye):
con `true`, `enqueue` sin transacción ⇒ 500 `E_AUTHZ_CONFIG` ANTES del INSERT, mensaje que nombra la fuga S5 («encolar
fuera de tu unidad de trabajo: un rollback tuyo deja el cambio en la cola y el relay lo aplica»). Default `false` en
alpha.8; CHANGELOG y README anuncian que en **2.5 pasa a `true`** (decisión del dueño) y que el contrato publicado pasará
la trx en `ctx()` entonces. Casos: P13 del tester como rojo con `requireTransaction: true` (hoy escribe); con `false`
sigue como hoy; el contrato publicado sigue verde (15/16 casos, `ctx()` sin trx).

## Menores
- `entries[].origin: 'parked' | 'pending' | 'failed'` (el mismo dato que hoy va en la prosa de `deferred[].error`).
- `report.deadCount` siempre; bajo `only`, `dead[]` lleva ids/`change`/`attempts` SIN `lastError` por DEFECTO
  (`deadDetail: 'full'` opt-in devuelve lo de hoy). Corrección a COGNITIV: el actor no viaja.
- Transacción ya cerrada en `enqueue` ⇒ 500 `E_AUTHZ_CONFIG` (`isCompleted === true`, medido por el analista), no 503
  `BACKEND_UNAVAILABLE`; en los tres llamadores de `assertCallerTransaction` (outbox, roles, relaciones).
- 422 `E_AUTHZ_SCOPE_DEPTH_LIMIT`: el `message` público sin `openfga`, sin `FACTS_MAX_RESOLVE_DEPTH` ni
  `OPENFGA_RESOLVE_NODE_LIMIT` (van a `details` para el operador); caso de letra. README: `maxDepth` cuenta SALTOS hasta
  `app` ⇒ un árbol de N niveles necesita `maxDepth = N + 1`, con caso EJECUTABLE (árbol de 3 niveles, `maxDepth: 3` ⇒ 422
  en el tercero; `maxDepth: 4` ⇒ entra).
- `dead[].supersededBy` read-only si es barato (la última aplicada posterior de la misma clave, la que `laterApplied`
  ya calcula); si no es barato, no.

## Docs / cierre
CHANGELOG `[Unreleased] — 2.4.0-alpha.8` (continuar la sección del I; supersede y `parkAfterMs` como «qué NO se hace y
por qué», con las medidas del auditor; el requisito traducido `reconcile` acotado ⇒ 2.5), README (edad, `--max-age`,
`requireTransaction` y su default en 2.5, `deadDetail`, `origin`), `CLAUDE.md` (higiene (ix)+), `roadmap-2.0.md` (2.5:
reconcile acotado por tenant; `requireTransaction` default). Base: cifras del informe I. Informe INCREMENTAL en
`alpha8-informe-II.md`. Verificación: las 4 corridas, en PRIMER PLANO y en secuencia.
