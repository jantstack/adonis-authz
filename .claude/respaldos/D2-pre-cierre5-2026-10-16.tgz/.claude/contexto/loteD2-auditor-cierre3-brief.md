# Repaso corto del auditor — cierre 3 de D2 (2026-10-16)

Mismas reglas que `loteD2-auditor-cierre2-brief.md` (solo lectura; reproducciones en `.claude/reproducciones/`; SQLite `:memory:` y stores efímeros en `:8090`; sin docker restart ni gates).

Lee: `loteD2-cierre3-coordinador.md`, `loteD2-informe-cierre3.md`, tu veredicto `loteD2-auditor-cierre2.md`.

Coordinador verificó el árbol: 2037/2065/2162/2164, guardia 178/178, banderas 37/37, runbook ×2.

Comprueba:
1. C2-1…C2-5 cerrados en efecto: re-ejecuta tus `loteD2-auditor-cierre2-fga.ts` y `-orden.ts`.
2. `liveInDestination` (frontera `now`): ¿empates en el instante exacto de caducidad, relojes distintos entre plan y apply, tuplas que vencen ENTRE el plan y la aplicación? ¿Alguna pasa a conceder?
3. El borrado previo y fuera de orden de sobrantes vencidas (`expiredDelete`): ¿puede borrar algo que sigue vivo en el momento del borrado, o un deny vencido que el origen renueva?
4. La fuerza bruta con vigencia (`tests/helpers/order_bruteforce.ts`): ¿modela fielmente plan y apply reales? Busca un contraejemplo fuera del universo.
5. C2-3: re-comprobación tras dos `Write` y rama `carriedDenyUnknown` (sin caso): ¿fail-open?
6. C2-5 roles: marca parcial + `indeterminate` sin regresión en el resto del manager.

Salida: `.claude/contexto/loteD2-auditor-cierre3.md`, veredicto APTA / NO APTA y hallazgos 🔴🟠🟡⚪ con reproducción.
