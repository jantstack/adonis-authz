# Lote B (plan 2.5) — auditor adversarial sobre el diff (2026-10-15)

Base `beb1d0a` + working tree (36 ficheros + `src/relations_reconcile.ts`). Repros en una COPIA del árbol
(`/tmp/claude-1000/-home-jose/66ad04a0-7bc5-4fa8-a9ef-332517233778/scratchpad/audB/repo`, `node_modules` enlazado),
solo SQLite `:memory:`, sin servidor OpenFGA, sin gates. Specs propios: `tests/audb_b3.spec.ts`, `tests/audb_b4.spec.ts`,
`tests/audb_b6.spec.ts` de esa copia (`node --import @poppinss/ts-exec bin/test.ts --files tests/audb_bN.spec.ts`).
No se ha tocado ningún fichero del repo salvo este informe.

## Veredicto en una línea

**APTA con cambios.** Ningún 🔴: no encontré escalada ni fallo abierto. Hay dos 🟠 en el mismo punto (B3 × reconcile, la
decisión 4) y seis 🟡. Los 🟠 hay que cerrarlos antes de sellar alpha.2.

## Hallazgos (por severidad)

### 🟠 1 · B3 × `--prune`: un residuo pre-2.5 en el destino `database` aborta la pasada A MITAD, después de escribir
- **Escenario:** el destino `database` tiene una fila de antes de 2.5 con un sujeto userset ≠ `group#member`
  (`document:D1#viewer@document:D2#viewer`, la fila «inerte» que B3 declara como residuo). Corre una pasada
  `reconcileRelations`/`authz:relations:reconcile --prune` hacia ese destino; por ejemplo, la VUELTA openfga → database del
  runbook. Lo que pasa:
  1. El plan mete el residuo en `toDelete`: su identidad cabe en la gramática y no está en el origen.
  2. Se aplican los `toWrite` de la partición.
  3. `to.unrelate(residuo)` llega a `#subjectColumns` → `assertUsersetSubject` → 422 `E_AUTHZ_RELATION_USERSET_UNSUPPORTED`.
  4. El `catch` del bucle de poda (`src/relations/reconcile.ts`, el que empieza por «La tupla fuera de la gramática se le
     pide al DRIVER…») solo absorbe el 422 de las tuplas `invalid`, así que **relanza**.
  5. El comando no reconoce ese `code` (`commands/authz_relations_reconcile.ts`, el `catch` de `runRelationsReconcile`)
     y hace `throw error`: sale un stack crudo.
- **Evidencia ✅ ejecutada** (`audb_b3.spec.ts`, primer caso): `PRUNE err: E_AUTHZ_RELATION_USERSET_UNSUPPORTED 422`;
  `W escrita (parcial): true`; tras el throw quedan 3 filas, la sobrante `X` sin borrar. Es la escritura parcial que el
  propio código promete evitar: «Nunca un throw a mitad de pasada por un dato ajeno». Cada `--prune` siguiente vuelve a
  morir en el mismo sitio. Por el paquete no hay salida: `purgeSubject(userset)` da 422, y `purgeObject(D2)`, el objeto
  del userset, deja el residuo (`residuo tras purgeObject(d2): n=1`). La letra choca con el efecto: README §Upgrading
  punto 6 dice «A relations reconcile that enumerates one from a pre-2.5 source counts it in `skipped.undeclared` instead
  of aborting». Es cierto para el ORIGEN y falso para el destino con `--prune`.
- **Steelman:** «el residuo tiene receta SQL en §Upgrading; quien no la corrió se lo buscó». ¿Me convence? **No.** La
  receta no es un paso obligatorio ni la vigila nada. El reconcile es justo la herramienta que el runbook pone en la
  vuelta, y aquí falla de la peor forma: parcial y bajo la ventana.
- **Qué exige el cierre:**
  - Clasificar el residuo del DESTINO como ya se hace con `invalid-identity`: `extra` con `details`
    (`side: 'destino'`, motivo propio, p. ej. `userset-unsupported`, `pruned: false` y «bórralo a mano» con la receta).
    Nunca un throw.
  - Un caso `--prune` hacia `database` con el residuo sembrado por SQL, que afirme cero escrituras parciales y exit ≠ 0
    con la línea del residuo.
  - Corregir la letra del punto 6.

### 🟠 2 · B3 × reconcile desde un ORIGEN con residuo: `--dry-run` ≠ pasada real, motivo falso y el verificador nunca vuelve a salir limpio
- **Escenario:** origen `database` con el residuo y destino cualquiera (en el repro, el doble). Pasa esto:
  - `planPartition` no conoce B3. Hay `toConfig` y el tipo y la relación del residuo están declarados, así que va a
    `toWrite`.
  - `--dry-run` informa `written: 1` («haría 1 escritura»).
  - La pasada real lo manda a `relateOrSkip`. El destino responde 422 y, como `RelationUsersetUnsupportedError` hereda
    de `RelationUnknownError` (decisión 4), se cuenta en `skipped.undeclared`.
  - La línea impresa dice «su tipo de objeto o su relación no están declarados en defineRelationsConfig del DESTINO …
    decláralos en el destino (y republica su modelo)». Es falso: están declarados, y el consejo no lo arregla.
  - `report.details` sale vacío: no lo lista con lado ni motivo, cuando L8 y el ⚪ R2 del lote A exigen exactamente eso.
  - El siguiente `--dry-run` vuelve a decir `written: 1`, `clean = false` y exit 1. Así para siempre, hasta que alguien
    ejecute SQL a mano.
- **Evidencia ✅ ejecutada** (`audb_b3.spec.ts`, segundo caso):
  `dry1 {"w":1,"sk":{…"undeclared":0},"det":[]}` · `real {"w":0,"sk":{…"undeclared":1},"det":[]}` ·
  `dry2 … clean= false` · `dry con toConfig {"w":1,…}` (con `toConfig` tampoco se filtra antes del driver).
  Va contra el comentario L-0 de `planPartition`: «así `--dry-run` y la pasada real dan los mismos números». El caso B3
  del implementador (`tests/relations_reconcile.spec.ts`) solo mira la pasada real sin `dryRun` ni `prune`, así que la
  línea (a) «Gemelos: Reconcile» del cierre de B3 cubre la mitad.
- **Steelman:** «se cuenta, no se pierde, y el exit ≠ 0 avisa». ¿Me convence? **No.** Se cuenta con el motivo
  equivocado, la acción que se recomienda es inútil, y el verificador del CI queda rojo de forma permanente sin decir la
  causa. Es el mismo patrón «422 ⇒ `skipped` vía `relateOrSkip`» que R2-5 de la ronda 2 marcó como camino a evitar para
  el lote D. Hacer que una clase nueva HEREDE de la de F-05 para que la absorba en silencio amplía ese patrón en vez de
  cerrarlo.
- **Qué exige el cierre:**
  - Clasificar en el PLAN, antes del driver, con `assertUsersetSubject` sobre `tuple.subject`, haya `toConfig` o no.
    Contarlo como `skipped.invalid`, o con un contador propio, y listarlo en `details`
    (`side: 'origen'`, `reason: 'userset-unsupported'`, la receta).
  - Mismos números en `--dry-run` y en la pasada real.
  - Revisar la decisión 4: que `relateOrSkip` NO trague esta clase.
  - Caso dry/real/dry2 con línea de letra.

### 🟡 3 · B6: con pool 1, la letra del 500 lleva a un 503. Y el README solo nombra `:memory:`, cuando el pool 1 es el default de knex en TODO SQLite
- **Escenario:** consumidor SQLite (fichero) con la config por defecto de Lucid/knex. knex fija `pool {min:1,max:1}` en
  `sqlite3`, y `better-sqlite3` lo hereda (`node_modules/knex/lib/dialects/sqlite3/index.js:228`). La secuencia:
  1. Con 2.5, `scopes.attached` sin trx ⇒ 500 `E_AUTHZ_CONFIG`. La letra dice «Pasa el `trx` de db.transaction()…» y no
     menciona el pool.
  2. Hace caso y pasa la trx ⇒ **503 `E_AUTHZ_BACKEND_TIMEOUT` a `freezeTimeoutMs`** (5 s por defecto) en cada
     `scopes.*`: la barrera del freeze lee por otra conexión y no la hay.
- **Evidencia ✅ ejecutada** (`audb_b6.spec.ts`, `:memory:`, `freezeTimeoutMs: 300`):
  `sin trx: 500 E_AUTHZ_CONFIG` y el mensaje no incluye «pool»; `con trx (siguiendo la letra): 503
  E_AUTHZ_BACKEND_TIMEOUT 301 ms`. README §Upgrading 9 y el párrafo de `requireTransaction` dicen «on SQLite `:memory:`
  keep the opt-out». No es solo `:memory:`: es cualquier pool de 1.
- **Steelman:** «pool ≥ 2 para `{ transaction }` es doctrina desde alpha.2 (invariante 14)». ¿Me convence? **A medias.**
  La doctrina existe, pero en 2.4 ese consumidor funcionaba con el default (`false`). Hoy la única salida que funciona
  es el opt-out, y ni el 500 ni el README se la dan en su caso.
- **Qué exige el cierre:** que la letra del 500 nombre «`{ transaction }` por el manager exige pool ≥ 2; con pool 1:
  `requireTransaction: false`»; que el README diga «pool max 1 —el default de knex para SQLite—»; y caso de letra.

### 🟡 4 · B4: la línea (a) del cierre dice que el `Read` de ROLES es «exhaustivo o 500». Es falso, y el envoltorio de `ListObjects` tampoco lo es ante un 200 sin `objects`
- **Evidencia ✅ ejecutada** (`audb_b4.spec.ts`):
  - `OpenFgaAuthorizationDriver.readAllTuples` con un `read` que responde `{}` devuelve `[]`
    (`src/drivers/openfga_driver.ts:3493`, `response.tuples ?? []`; lo mismo en `:3285` y `:3400`).
  - `purgeScope` demuestra el cero con esa función (`purgeable` → `readAllTuples`). Con una respuesta malformada,
    «demuestra» cero sin borrar nada: el invariante 11 queda abierto (no lo introduce este lote).
  - En relaciones, `#listObjectsPage` con `listObjects` → `{}` devuelve `{"objects":[]}` sin `truncated`
    (`openfga_relations_driver.ts:619`, `response.objects ?? []`). Es una lista «completa» muda, dentro del mismo punto
    de paso que M8 declara universal. `#readAll` sí lanza en el caso equivalente.
- **Steelman:** «hace falta un servidor o un proxy que responda 200 sin cuerpo». ¿Me convence? Sí, en cuanto a la
  severidad (🟡). No en cuanto a la letra: el cierre de B4 dice «roles: … su `Read` es el mismo patrón
  exhaustivo-o-500» y no lo es.
- **Qué exige el cierre:** `!Array.isArray(response?.objects)` ⇒ 503 en `#listObjectsPage`, con su mutante en la columna
  `truncation`. En roles, el mismo `Array.isArray` en las tres lecturas, o corregir la línea (a) y registrarlo como
  deuda con fecha.

### 🟡 5 · B3 no está en el runner PUBLICADO: un driver de relaciones de terceros pasa el contrato sin cumplirlo
- **Evidencia ✅:** `grep USERSET_UNSUPPORTED src/testing/` = 0. La variante `usersetUnsupported` solo existe en
  `tests/guard_surface.spec.ts`, es decir, en las capas del paquete. `src/testing/relations_contract.ts` cambia solo el
  doble (`assertSubjectDeclared`). Un tercero que guarde la fila inerte, o que devuelva 503, pasa
  `runRelationsDriverContract` entero, aunque B3 se declara «variante de F-05» y para F-05 el README promete «the
  published contract plants the exploit» y D13 exige F-05 al driver llamado directamente.
- **Steelman:** «no hay escalada: la fila es inerte». ¿Me convence? Sí para la severidad. No para la paridad: el reconcile
  hacia ese tercero y `manager.driver()` repiten las filas 🟠 1/2.
- **Qué exige el cierre:** caso en el núcleo del runner (manager y driver directo: 422 con ese `code` y cero llamadas en
  `relate`/`check`/`listObjects`/`purgeSubject`), con el recuento de casos actualizado y su entrada en §Upgrading
  (punto 2, D13).

### 🟡 6 · B2 (L5, 5.ª iteración): en roles el punto de paso NO es único, y la entrada en la guardia falta
- **Evidencia ✅:** `assertKnownConfigKeys` solo se llama en `defineConfig` (`src/define_config.ts:453-457`). El provider
  (`providers/authz_provider.ts:81,91`, `config.get('authorization')`) y `new AuthorizationManager(config)` no
  revalidan. Un `config/authorization.ts` que exporta `{ … } satisfies AuthorizationConfig` sin `defineConfig`, o
  cualquier `new AuthorizationManager({ requireWithing: true })`, sigue tragándose el typo sin decir nada.
  - En relaciones el punto de paso sí es único de hecho: `RelationsConfig` lleva funciones y solo la fabrica
    `defineRelationsConfig`.
  - CLAUDE.md punto 5(d) pide, a partir de la 3.ª iteración, «propiedad universal, punto de paso único y entrada en la
    guardia». El informe (§2 B2 (d) y §6) reconoce que la entrada en la guardia no existe.
- **Steelman:** «el stub usa `defineConfig`; quien no lo usa, se sale del camino». ¿Me convence? A medias: el tipo
  `AuthorizationConfig` está publicado y se acepta sin `defineConfig`.
- **Qué exige el cierre:** llamar a la misma validación en el constructor del manager (o en el provider) y añadir un caso.
  Para la guardia de config: o firma del dueño que la aplace (exención explícita) o un test por reflexión sobre la
  instancia por defecto del stub. No vale la prosa de §6.

### 🟡 7 · B1/B2 sobre la config PERSISTIDA: una fila escrita antes de 2.5 bloquea `authz:relations:reconcile` (exit 1) hasta un re-save manual, y §Upgrading no lo dice
- **Escenario:** antes de 2.5, `saveRelationsConfig(spec)` guardaba `JSON.stringify(spec)` TAL CUAL, con las claves que
  `defineRelationsConfig` tiraba en silencio (`src/relations_config_store.ts:57`). Tras actualizar:
  `readRelationsConfig()` → `defineRelationsConfig` → 422 → la rama B5 «lanza» → exit 1 en cada pasada, también en el
  cron del `--dry-run`, con la letra «No se pudo leer la config de relaciones persistida … Una lectura que falla NO es
  «no hay config»». Pero no falló una lectura: la fila no valida. Nadie del paquete la reescribe.
- **Evidencia ✅** (lectura de código): §Upgrading 5 y 8 no mencionan que la fila persistida se revalida. Lo mismo pasa
  con un ciclo de `includes` persistido (B1).
- **Steelman:** «es fail-closed, que es lo correcto». ¿Me convence? Sí en el comportamiento. No en la letra ni en la
  salida: falta «re-guarda con `saveRelationsConfig(<spec corregida>)`».
- **Qué exige el cierre:** separar en el comando «lectura que falla (503)» de «config persistida inválida (422)», con
  línea propia; una frase en §Upgrading 5/8; caso por el kernel con la fila sembrada `{"objectTypes":…,"deny":true}`.

### 🟡 8 · B4: el deadline del servidor se puede declarar mal y no hay forma de decir «sin deadline»; los terceros no tienen juez
- **Evidencia:**
  - ✅ El driver rechaza `listObjectsDeadlineMs: 0` (500).
  - ❓ No pude verificar contra la referencia oficial de configuración de OpenFGA (solo hilos de la comunidad): un
    `--listObjects-deadline` a 0 desactiva el corte. Si es así, ese despliegue no se puede declarar, y con el default
    (3 000) cualquier `ListObjects` ≥ 2,7 s sale `truncated`, que para COGNITIV es un 503.
  - Si el servidor corta ANTES que el valor configurado (servidor a 1 s, driver con el default), la lista parcial sale
    muda: depende de la config. La letra «set it to your server's value» está; el caso del 0 no.
  - Decisión 6: el par `listObjectsTruncation` del runner solo juzga el TOPE. Un tercero que no implemente el deadline
    pasa, y M8 queda como propiedad del driver del paquete, no del puerto.
- **Qué exige el cierre:** que el README diga qué hacer con `--listObjects-deadline=0` (p. ej. aceptar `Infinity` o un
  valor explícito), y una línea en «Third-party drivers»: el deadline no lo juzga el runner.

### ⚪ 9 · `monotonic` («SOLO TESTS») es una opción PÚBLICA de `OpenFgaRelationsDriverOptions`
`monotonic: () => 0` apaga la señal del deadline en producción. Solo se valida `typeof === 'function'`. Hoy no es
explotable: el config es de confianza. Para cerrarlo: sacarla del tipo publicado (símbolo o opción interna), o que un
caso fije que el README no la documenta.

### ⚪ 10 · El «punto de paso único» de `ListObjects` no tiene guardia por fuente
Hoy hay una sola llamada a `client.listObjects` (`openfga_relations_driver.ts:617`). Pero una segunda llamada, fuera de
`#listObjectsPage`, no pondría rojo ningún mutante. Para cerrarlo: un `grep` en un spec (solo un `client.listObjects` y
dentro del envoltorio), mismo patrón que C5.

### ⚪ 11 · Letra B3: «`purgeObject` still removes them by object»
Es el objeto de la TUPLA (D1), y purgarlo se lleva TODAS sus comparticiones legítimas. `purgeObject` sobre el objeto del
userset (D2) NO borra el residuo (✅ ejecutado, `n=1`). Para cerrarlo: precisar la frase o quitarla.

### ⚪ 12 · Decisión 5: la receta SQL de B3 no está en `upgrade_recipe.spec`
La sentencia es correcta en los tres motores (`subject_relation <> ''` excluye las filas de holder con `NULL` de antes de
L-4b). Aceptable SI se cierra el 🟠 1/2. Si no, la receta es la única salida y tiene que ejecutarse con caso.

### ⚪ 13 · Bordes de la letra de B2
- `saveRelationsConfig(config.relations.config)` (la config YA definida: el tipo estructural lo permite) da 422 con
  «'membersOf' en la raíz de la spec no existe», sin pista de que se pasó una config ya definida.
- `database: true` (no objeto) sigue ignorándose en silencio: `assertKnownKeys` sale si el valor no es un objeto.
- `includes: {}` lanza un `TypeError` crudo. Viene de antes de este lote.

### ⚪ 14 · Decisión 8: el precio no está cuantificado
«Lento pero completo ⇒ `truncated`» está escrito en el README, pero no su coste para un consumidor que trata
`truncated` como 503 (COGNITIV): cada `ListObjects` del p99 por encima de 2,7 s es un 503 de usuario. Una frase con ese
precio en «Limits».

## Lo que intenté y NO se rompió

- **B1:**
  - Un `includes` hacia una relación inexistente se rechaza ANTES del DFS (`!own.has(included)`).
  - La autoinclusión es el ciclo de longitud 1.
  - Un ciclo en la config PERSISTIDA se detecta: `readRelationsConfig` pasa por `defineRelationsConfig`.
  - `provision` solo lee la config estática, ya validada al cargarla.
- **B2:**
  - Un `__proto__` en un JSON parseado es clave PROPIA ⇒ 422.
  - Las claves símbolo no llegan por JSON.
  - Las listas de roles coinciden con el tipo `AuthorizationConfig` campo por campo.
  - Ninguna lectura `config.*` del paquete usa una clave fuera de la lista.
  - El stub y los ejemplos del README solo usan claves de la lista.
  - D11 (422) es de relaciones; el 500 de roles es coherente con su familia.
- **B3:**
  - Ninguna ruta de escritura lleva un userset ≠ `group#member` al backend: manager `#assertSubject`, `database`
    `#subjectColumns`, `openfga` `#subjectUser`, doble, `relateOrSkip` (422 antes del INSERT/Write), purgas y
    `checkMany`. No hay outbox ni comandos de relaciones que escriban por otro camino.
  - El residuo de `database` es inerte de verdad: la CTE de principales y `membersOf` solo bajan por
    `subject_type='group' AND subject_relation='member'`, y un holder no puede llamarse como un tipo de objeto.
  - Sin escalada.
- **B4:**
  - Una sola llamada a `ListObjects`.
  - `timeoutMs` del cliente < deadline: no queda ventana muda, el cliente lanza 503 antes.
  - La vista `withClock` hereda deadline y reloj.
  - El manager pasa la página tal cual, y el `whenTrue` de `listObjectsTruncation` lo ejercita por el manager con el
    doble, así que `na: passthrough` tiene respaldo.
  - `#readAll` de relaciones lanza con un token repetido o sin `tuples`.
  - `membersOf` de `database` usa CTE con `UNION` y no tiene `LIMIT`.
- **B5:** la fila «lanza × real» hace `return` antes de `runRelationsReconcile`: nada se construye, congela ni escribe
  (código + caso por el kernel). Roles no tiene `.catch` que se trague una lectura en el camino del reconcile.
- **B6:**
  - Las tres llamadas a `outbox.enqueue` del paquete (`src/manager.ts:1034/1067/1137`) pasan `options.transaction`; no
    hay encolado interno sin trx.
  - El hijo del runbook encola dentro de `db.transaction()`.
  - La cara `true` del contrato corre sobre `sqlScopeOutbox` real en sqlite-file, pg y mysql.
- **B7:**
  - El cuerpo movido es idéntico byte a byte (`diff` = solo la ruta del `import()` dinámico).
  - `./commands/authz_relations_reconcile` ya no exporta la función: un import con nombre falla al enlazar.
  - No hay comodín en `exports` que exponga `src/`.
  - C5 sigue probando lo mismo: solo la vía con guard y el harness importan el primitivo.
- **B8:**
  - `readAuthorizationModel()` del SDK usa `getAuthorizationModelId(options)` = el id del cliente
    (`node_modules/@openfga/sdk/dist/client.js:187-192`).
  - Sin `modelId` ⇒ el último, como documenta §Upgrading 11.
  - La vista hereda `modelId` por prototipo.
  - Relaciones no lee el modelo: no hay gemelo que tocar.
- **B9:** `grep republishFusedModel README.md CLAUDE.md src commands` = 0.
- **Transversal:**
  - `freeze.spec` solo cambia la ruta del import.
  - `EXPECTED_FUSED` y `migration_stub.spec` no aparecen en el diff.
  - No hay `skip`/`pending` nuevos.
  - Los asserts quitados son del caso «default `false`», reescrito para el `true`.
  - Las nueve piezas tienen entrada en el CHANGELOG, y B1–B8 en §Upgrading.

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. ¿El residuo B3 del lado DESTINO en `--prune` debe acabar en `details` con `pruned: false` (receta manual) o borrarse
   por una vía de plataforma (DELETE por uuid de fila)? Las dos cierran el 🟠 1. La segunda además deja de exigir SQL.
2. ¿Se mantiene la decisión 4 (subclase para que `relateOrSkip` la trague) sabiendo que el lote D va a querer
   exactamente lo contrario (R2-5: «jamás `skipped`»)?

## Decisiones §4 del implementador

| # | Decisión | Veredicto | Por qué |
|---|---|---|---|
| 1 | B2 · `E_AUTHZ_RELATION_CONFIG_UNKNOWN_KEY` como subclase de `RelationConfigError` | **Ratificar** | Distingue el typo y conserva `instanceof`. |
| 2 | B2 · gemelo roles con 500 `E_AUTHZ_CONFIG`, solo claves por nivel | **Condicionar** | El 500 está bien (familia de roles; D11 es de relaciones). Falta el punto de paso único: validar también en el manager o en el provider (🟡 6). |
| 3 | B3 integrado en F-05 (variante, no columna) | **Condicionar** | Bien en la guardia. Falta en el runner publicado (🟡 5). |
| 4 | `RelationUsersetUnsupportedError extends RelationUnknownError` para que `relateOrSkip` la cuente | **Rechazar** | Es la causa del 🟠 2: dry ≠ real, motivo falso, sin `details`. Amplía el patrón «422 ⇒ skipped» que R2-5 manda evitar. Clasificar en el plan. |
| 5 | Residuo declarado; receta SQL no ejecutada | **Condicionar** | Aceptable solo con el 🟠 1/2 cerrados; con ellos abiertos, la receta es la única salida y tiene que ejecutarse con caso. Corregir la letra de `purgeObject` (⚪ 11). |
| 6 | B4 sin capacidad nueva | **Ratificar con letra** | Una sola señal está bien. Escribir que el runner no juzga el deadline de terceros (🟡 8). |
| 7 | Reloj monótono inyectable `monotonic` | **Ratificar** | Doctrina H3. Sacarlo de la superficie publicada (⚪ 9). |
| 8 | Señal conservadora (lento ⇒ `truncated`) | **Ratificar con letra** | Escribir el precio para quien trata `truncated` como 503, y el caso del servidor con deadline 0 (🟡 8, ⚪ 14). |
| 9 | `truncation` sondea solo `openfga`; `exhaustive`/`passthrough`/`double` | **Condicionar** | Las `na` están justificadas (el `passthrough` lo respalda el par del runner). Pero el envoltorio acepta un 200 sin `objects` como lista completa: falta un mutante para eso (🟡 4). |
| 10 | Harness SQL en `:memory:` con opt-out y `requiresTransaction: false` | **Ratificar** | Medido; la cara `true` corre en tres motores. |
| 11 | Los arneses que encolan sin trx declaran `requireTransaction: false` | **Ratificar** | Opt-out explícito y comentado; el hijo del runbook usa la trx. |
| 12 | Módulo en `src/relations_reconcile.ts`; no se mantiene el export viejo | **Ratificar** | Movimiento verbatim; regla 2 de pureza respetada; ruptura en §Upgrading 10. |
| 13 | B8 vía `readAuthorizationModel()` sin argumentos | **Ratificar** | Verificado en el SDK: es el mismo id que cada Write/Check. |
| 14 | `linajes.md` sin editar (texto propuesto) | **Ratificar** | Lo administra el coordinador. Corregir antes la línea (a) de B4 sobre roles (🟡 4). |
