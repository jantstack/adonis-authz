# Fase 3 · Lote 3D — informe incremental (correcciones de cierre)

Base: `f563465` (lotes 3A + 3B; árbol limpio). Spec: `.claude/contexto/fase-3-correcciones.md`
(M1–M6 bloqueantes, N1–N7 obligatorias). Veredictos de partida: **auditor NO APTA** (2 🔴 + 2 🟠
reproducidos en PG), **tester APTA CON CORRECCIONES**, code-review parcial (solo el ángulo *reuse*).

Reglas seguidas: rojo→verde por pieza reproduciendo primero el escenario del auditor cuando existe
(salida literal antes y después); typecheck + `npm test` + `OPENFGA_TEST_URL=:8101 npm test` tras cada
pieza; cierre en los 4 modos + `:8101` + tope 3. Sin skip/only, sin commits.

## 0. Rojos de partida — los cuatro `repro*.ts` del auditor contra PostgreSQL 18

`TEST_DB=pg TEST_PG_URL='postgres://postgres:***@127.0.0.1:5432/authz_test'`,
scripts en `…/scratchpad/v6/repro{1_shadow,2_effective,3_varios,4_global}.ts`, **sin tocar el árbol**.
Los cuatro reproducen. Salida literal (recortada a lo que afirma cada hallazgo):

```
=============== repro1_shadow ===============            (V3 🟠 — grant/hasRole/listSubjects por slug)
rol realmente asignado: 01a04dd8-095b-7208-827b-cb90aeee2936 <-- ES EL DE B
authorize(victima, billing:write, U1) = true
effectivePermissions(victima, U1) = [ 'docs:read', 'billing:write' ]
listRoles(victima, U1) = [ 'lead' ]
hasRole(victima, lead@unit, U1) = true

=============== repro2_effective ===============          (V1 🔴 — #rolesAlong por slug ⇒ escalada)
authorize(pepe, docs:read, U1)      = true
authorize(pepe, billing:write, U1)  = false
effectivePermissions(pepe, U1)      = [ 'billing:write' ] <-- debería ser {p | authorize(p)}
listRoles(pepe, U1)                 = [ 'lead' ]
hasRole(pepe, lead@unit, U1)        = false
ESCALADA: pepe delegó billing:write sin tenerlo: 01a04dd8-0b3f-74d8-9cf7-798278e2439e
authorize(titere, billing:write, U1) = true

=============== repro3_varios ===============             (V2 🔴 A/C, V4 🟠, V5 🟡)
=== (a) carrera del chequeo de colisión: dos managers, dos memos ===
define(owner orgA) = fulfilled 01a04dd8-0cf0-76be-b43d-213b594c021c
define(owner U1)   = fulfilled 01a04dd8-0cf3-72d5-b73a-5c29bd6c86bf
DOS HOMÓNIMOS EN LA MISMA CADENA sin mover el árbol: grant por slug resuelve al más cercano
authorize(currante, billing:write, U1) = true
=== (b) define en un scope de OTRO tenant, con requireWithin: non-root ===
currante (solo `miembro@app`) creó un rol dentro de orgB: 01a04dd8-0cfb-722d-b43b-f21c46ad9513 organization|…
=== (d) rol local cuyo owner ya no existe en el árbol ===
deleteScopedRole tras purgar el owner: 422 E_AUTHZ_UNKNOWN_SCOPE
la fila del rol sigue: 1

=============== repro4_global ===============             (V2 🔴 B — define vs sync)
sync   = fulfilled
define = fulfilled 01a04dd8-121c-7158-ab5a-a2f30b231800
roles `viewer@unit`: [ { owner_scope_key: 'global', rank: 1 }, { owner_scope_key: 'unit|…', rank: 9 } ]
authorize(nuevo, docs:write, U1) = true <-- el global `viewer` NO da docs:write
authorize(nuevo, docs:read,  U1) = false
```

## Tabla pieza × rojo reproducido × estado

| Pieza | Rojo de partida (reproducido) | Estado |
|---|---|---|
| **M5** parche del tester (H1 visibilidad por nivel, H2 efectivos en toda la cadena del owner) | mutante `chainKeysFrom ⇒ keys.map(() => keys)` VIVO en 3 motores × 2 drivers | ✅ 387 / 488 |
| **M1** ambigüedad ⇒ 422 + puerto por uuid + `RoleQuery {uuid}` | `repro1` (V3), `repro2` (V1, escalada), `repro4` (V2-B) | ✅ 390 / 493 |
| **M2** unicidad serializada + re-chequeo en la transacción + `ambiguousRoles` en el diff | `repro3` (a): dos `define` ⇒ dos filas; `repro4`: `define` vs `sync` ⇒ conviven | ✅ 392 / 496 |
| **M3** `within` en las nueve escrituras | `repro3` (b): `currante` con rol raíz creó un rol dentro de `orgB` con `requireWithin: 'non-root'` | ✅ 393 |
| **M4** `scopes.detached` purga los roles cuyo owner es el scope | `repro3` (d): 422 `E_AUTHZ_UNKNOWN_SCOPE` y `la fila del rol sigue: 1` | ✅ 395 / 499 |
| **M6** FKs stub↔espejo + K11 con `delete_rule`/`update_rule` + cero por el puerto público | `grep referential_constraints` = 0; espejo sin `onDelete`, stub con `CASCADE`/`RESTRICT` | ✅ 395 / PG 482 / MySQL 482 |
| **N1–N7** obligatorias | tester H4/H5/H6, auditor V6/V7, code-review *reuse* | ✅ |

### M1 — la ambigüedad es un error, y el puerto habla por uuid

**Decisión (a).** `CatalogView.roleVisible(slug, nivel, chainKeys)` deja de elegir «el owner más cercano»:
devuelve **el** rol visible, `null` si no hay ninguno y **lanza 422 `E_AUTHZ_AMBIGUOUS_ROLE`** (error nuevo,
`src/errors.ts`) si hay más de uno, nombrando uuid y owner de cada uno. Todas las rutas que direccionan por
slug pasan por ahí (`grant`, `hasRole`, `listSubjects`, la composición sin `rolesInChain`); `authorize` **no**
—no direcciona por slug— y por eso sigue respondiendo (invariante 1: lo asignado concede lo que su rol vincula).

**Decisión (b).** `rolesInChain` devuelve `Array<{ scope, role: CatalogRoleRef }>` (`uuid` + `slug` +
`scopeType` + `owner`; `CatalogRoleRef` se muda a `src/types.ts` y gana `scopeType`). `manager.#rolesAlong`
resuelve por uuid con defensa en profundidad (nivel + `isRoleVisibleWith`) y **nunca** vuelve del slug al
catálogo. `effectivePermissions` y el rank del actor son otra vez exactos.

**Decisión (c).** `RoleQuery = string | { slug, scopeType } | { uuid }` en `grant`/`revoke`/`hasRole`/
`listSubjects` (manager y puerto). `{ uuid }` no admite mezclarse con `slug`/`scopeType` (422). Helpers
compartidos por ambos drivers en `database_driver.ts`: `resolveRoleQuery` (escritura exacta),
`visibleRoleFor` (lectura), `rolesToRevoke`, `hasRoleTargets`.

Salida literal DESPUÉS (mismos scripts, PG):

```
repro1_shadow  →  AmbiguousRoleError: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles en esta
                  cadena (…owner=unit|…; …owner=organization|…)  ·  status: 422 code: E_AUTHZ_AMBIGUOUS_ROLE
                  (lanzado en driver.grant, ANTES de escribir)
repro2_effective → authorize(pepe, docs:read, U1)     = true
                   authorize(pepe, billing:write, U1) = false
                   effectivePermissions(pepe, U1)     = [ 'docs:read' ]   ← ya es {p | authorize(p)}
                   hasRole(pepe, lead@unit, U1)       → 422 E_AUTHZ_AMBIGUOUS_ROLE
                   (el script muere ahí: la ESCALADA ya no llega a ejecutarse)
repro4_global   →  AmbiguousRoleError: 'viewer' (nivel 'unit') … (owner=global; owner=unit|…) · 422
```

**Casos del juez nuevos** (`since('2.2')`, los dos drivers):
«un `scopes.moved` legítimo junta dos homónimos…» (grant/revoke/hasRole/listSubjects por slug ⇒ 422; `{uuid}`
concede el correcto; `authorize` responde; `revoke` por slug quita los dos; deshecho el cruce el slug vuelve)
y «`effectivePermissions` es EXACTAMENTE `{p | authorize(p)}`…» (V1 completo, con `defineScopedRole`).

### M2 — la unicidad deja de ser una carrera

1. **Serialización**: `withAuthzCatalogWrite` bloquea la fila de `authz_catalog_version`
   (`SELECT … FOR UPDATE`) como PRIMERA sentencia de su transacción, y el bump sigue siendo la última.
   SQLite se salta el cerrojo (ya serializa las escrituras). Todas las escrituras de `authz_*` pasan por ahí,
   así que `define` vs `define` y `define` vs `sync` van en serie. Los HECHOS no pasan por aquí.
2. **Re-chequeo dentro de la transacción, contra la BASE**: `defineScopedRole` relee
   `authz_roles WHERE slug=? AND scope_type=?` y compara con la foto del memo. `updateScopedRole` no lo
   necesita (no cambia slug, nivel ni owner) y `syncAuthzCatalog` ya lo hacía dentro de su transacción.
3. **`authz:catalog:diff`**: `CatalogDiff.ambiguousRoles`, cuenta para `catalogInSync` (exit ≠ 0) y sale en
   `formatCatalogDiff`. La pareja global+local se detecta siempre; la de dos locales, con el `resolveChain`
   del config (el comando se lo pasa).

Salida literal DESPUÉS: `repro3` (a) `define(owner orgA) = fulfilled …` / `define(owner U1) = rejected
E_AUTHZ_CATALOG_CONFLICT`, **una sola fila** en la base; `repro4` `sync = fulfilled` / `define = rejected
E_AUTHZ_CATALOG_CONFLICT`, queda solo el global.

### M3 — nueve escrituras

`defineScopedRole`/`updateScopedRole`/`deleteScopedRole` toman `options?: ScopedWriteOptions` y pasan por
`#assertWithinChain(owner, chain, …)` con la cadena ya resuelta en fresco. `requireWithin` las exige;
`'non-root'` rechaza la raíz. Salida literal DESPUÉS: `repro3` (b) `rechazado: E_AUTHZ_WITHIN_REQUIRED
defineScopedRole: el config exige 'within' (requireWithin: "non-root")…`.

### M4 — un rol sin owner no sobrevive

`scopes.detached(child)` purga **primero** (antes de los hechos) los roles locales cuyo owner es ese scope
(`CatalogView.rolesOwnedBy(ownerKey)` + `driver.purgeRole` por rol, con `role_purged` por cada uno). En un
driver sin `purgeRole` de verdad el `detached` es 500 `E_AUTHZ_UNSUPPORTED` **sin tocar nada** (por eso va
antes que `purgeScope`). `AuthzCatalogWriteEvent.actor` pasa a opcional: el de `scopes.detached` es el
`WriteOptions.actor` de esa notificación y puede no venir. Salida literal DESPUÉS: `repro3` (d)
`deleteScopedRole tras purgar el owner: 422 E_AUTHZ_UNKNOWN_ROLE` · `la fila del rol sigue: 0`.

### M6 — el «todo o nada» de `purgeRole` deja de depender de un accidente

(a) `tests/helpers/schema.ts` alineado con `stubs/migration.stub` (`role_permissions.role_uuid`/
`permission_uuid` CASCADE, `assignments.role_uuid` RESTRICT, `denies.permission_uuid` CASCADE).
(b) `describeAuthzForeignKeys` (nuevo, `information_schema.referential_constraints`, PG y MySQL) y K11
compara `delete_rule`/`update_rule` además de tipo/longitud/precisión/nulabilidad/collation, con asertos
literales de las cuatro reglas. (c) El caso `purgeRole` `whenTrue` afirma el cero por el puerto público:
tras recrear el slug se concede a un tercer holder y `listSubjects` devuelve **solo** a ese.

### M5 — parche del tester

`git apply .claude/contexto/tests-tester-fase-3.patch` (3 ficheros, +87/−5). Aplica limpio sobre
`f563465`. Conteos del juez a 74 (2.2 con `listDenies`) / 68 (sin) / 78 (con reloj).

| Ejecución | Antes (`f563465`) | Después de M5 |
|---|---|---|
| `npm test` (SQLite memoria) | 384 | **387** ✅ |
| `OPENFGA_TEST_URL=:8101 npm test` | 484 | **488** ✅ |

`npm run typecheck` limpio.


## Obligatorias (N1–N7)

| # | Qué se hizo | Dónde |
|---|---|---|
| **N1** | Caso de paridad `since('2.2')` en ambos drivers: una asignación cuyo rol pasa a estar declarado para OTRO nivel deja de contar en los dos (`authorize`, `hasRole`, `listRoles`, `listSubjects`, `listScopes`, `listRoleScopes`, `grant` ⇒ 422) y vuelve a contar al restaurar el nivel. Helper `retypeRole` (el catálogo es SQL en los dos drivers, así que no hace falta escribir hechos a mano — que en `openfga` no serían escribibles por el puerto). **Mutante comprobado**: `where('r.scope_type', s.type)` ⇒ `whereNotNull` mata 2 tests (era VIVO). | `src/testing/contract.ts` |
| **N2** | `owner_scope_key` corrupto ⇒ 500 `E_AUTHZ_INTERNAL` (caso, con `'basura'`, `'app'` y `''`, por el memo Y por la API). `updateScopedRole` con `slug`/`scopeType`/`owner` ⇒ 422 `E_AUTHZ_INVALID_IDENTITY` en vez de ignorarlas: `#parseScopedRoleChanges` valida las claves. | `src/manager.ts`, `tests/manager.spec.ts` |
| **N3** | `owner_scope_key = 'app'` es corrupto (`ownerOf` exige `global` o `<tipo>\|<uuid>` de un scope que no sea la raíz): la raíz está en TODAS las cadenas, así que era un global disfrazado. `assignableAt` que no cabe en `varchar(500)` ⇒ 422 al ESCRIBIR (`ASSIGNABLE_AT_MAX`, sync y diff), no 500 al leer en cada `view()`. `defineScopedRole` con `permissions: []` ⇒ 422. | `src/catalog_cache.ts`, `src/catalog.ts`, `src/manager.ts`, `tests/manager.spec.ts` |
| **N4** | README §Actor: «for these six writes the engine never evaluates it — **but the delegation API of 2.2 does**». README §Scoped roles: «**It must come from the session, never from the request body**», con el mismo tono que el aviso de `within`, y el porqué (el paquete solo valida su gramática). | `README.md` |
| **N5** | `assertRoleAssignableAt` delega en `assertAssignableAt` (`catalog.ts`): una sola regla. `declaredRoleAt(catalog, uuid, scopeType, chainKeys)` nuevo y compartido: lo usan `listRoles`, `rolesInChain`, `visibleAt` (`database`) y `declaredRole` (`openfga`). `chainKeysFrom` se muda a `identity.ts` (junto a `scopeKey`) y `manager.#rolesAlong` la usa; `database_driver` unifica su clave de fila en `dbScopeKey`/`rowScopeKey`; `AuthorizationManager.#scopeKey` queda documentada como la clave LAXA de candidatos (`authorizedScopes`, anti-ciclo), no la canónica. `storedAssignableAt` da al sync y al diff la MISMA normalización (un valor desordenado a mano salía «en sync» y el sync lo reescribía; ahora un diff limpio significa que el sync es no-op — test). Retirado el wrapper `rolesGranting` del driver openfga. | `src/drivers/*.ts`, `src/identity.ts`, `src/manager.ts`, `src/catalog.ts`, `tests/manager.spec.ts` |
| **N6** | Anotado que «`parseBindingId` parsea desde la derecha» es hoy un **mutante equivalente** (con la gramática actual un `scopeKey` tiene 1 o 2 partes y ambas lecturas coinciden para todo id admisible) y solo tendrá oráculo cuando el `scopeKey` crezca de partes en 3b; y que **la regla de owner en `authorize` cuelga de UN solo caso por harness**. En `CLAUDE.md` (mapa del driver openfga y `contract_harness`) y en `README.md` (§OpenFGA notes y §Custom drivers). | `CLAUDE.md`, `README.md` |
| **N7** | `CHANGELOG.md`: sección «Lot 3D» con el breaking de `RoleQuery`/`rolesInChain`/la API de delegación, el porqué de cada decisión y qué NO se hace. `CLAUDE.md`: invariante 15 (**nueve** escrituras + el actor de la sesión), invariante 18 (identidad por uuid, ambigüedad ⇒ 422, unicidad defendida, `detached` purga, `owner_scope_key` válido), mapa (types, catalog_cache, identity, drivers, manager, catalog, errores, tests, conteos del juez) y roadmap 3D ✅. `README.md`: §Containment (nueve), §Actor, §Scoped roles (identidad/ambigüedad, unicidad, `detached`, policy, storage), §The catalog (`ambiguousRoles`), §Errors (`E_AUTHZ_AMBIGUOUS_ROLE` + `E_AUTHZ_ROLE_NOT_VISIBLE` ampliado + `E_AUTHZ_NOT_WITHIN` a nueve), §Custom drivers. | `CHANGELOG.md`, `CLAUDE.md`, `README.md` |

## Desviaciones respecto a la spec (con porqué)

1. **M2(a): el cerrojo NO va sobre `authz_roles`, va sobre la fila de `authz_catalog_version`.** La spec pedía
   `SELECT … FOR UPDATE` sobre `authz_roles WHERE slug=? AND scope_type=?`. Ese cerrojo **no cierra el caso**:
   cuando el rol todavía no existe no hay filas que bloquear y PostgreSQL no tiene gap locks, así que los dos
   `define` de la carrera A seguirían insertando. La fila de la versión existe siempre y TODA escritura de
   `authz_*` pasa por `withAuthzCatalogWrite`, así que bloquearla serializa de verdad a los escritores del
   catálogo (era la otra mitigación que el propio auditor proponía). El re-chequeo dentro de la transacción,
   leyendo la base, sigue siendo el que decide.
2. **M2(a): `updateScopedRole` no re-comprueba colisión.** No puede cambiar `slug`, `scopeType` ni `owner`
   (N2 lo hace explícito con un 422), así que no hay clave nueva que colisionar. `syncAuthzCatalog` ya hacía
   su chequeo dentro de la transacción y contra la base; solo le faltaba la serialización, que ahora tiene.
3. **El re-chequeo dentro de la transacción no resuelve el árbol.** Para un homónimo que apareció en la
   ventana y cuyo owner no es global ni ancestro haría falta `resolveChain`, es decir OTRA conexión mientras
   se sostiene el cerrojo del catálogo: con un pool de 1 es un abrazo mortal. Se rechaza igual (422
   `E_AUTHZ_CATALOG_CONFLICT`, «el catálogo cambió mientras se validaba; reintenta») y el segundo intento
   valida con la foto buena. Fail-closed y sin bloqueos.
4. **`revoke` por slug sigue quitando los hechos de TODOS los homónimos** en el scope exacto, sin 422 de
   ambigüedad. No *resuelve* la ambigüedad —no elige uno—, y quitar nunca concede; además el scope puede ya
   no existir para el árbol (D8). `{ uuid }` es la forma precisa. Documentado en README y CHANGELOG.
5. **Un driver de terceros sin `rolesInChain` compone por slug.** El puerto mantiene `rolesInChain` opcional,
   así que en ese caso `#rolesAlong` resuelve con `roleVisible` — que desde M1 **falla cerrada** (422), nunca
   elige un homónimo. La escalada V1 queda cerrada en ambos caminos; los dos drivers del paquete van por uuid.
6. **`AuthzCatalogWriteEvent.actor` pasa a opcional.** Los `role_purged` que arrastra `scopes.detached` (M4)
   llevan el `WriteOptions.actor` de esa notificación del árbol, que puede no venir. La API de delegación lo
   sigue exigiendo siempre.
7. **M4: la purga de roles del owner no comparte transacción con `purgeScope`.** Cada `purgeRole` es atómico
   (asignaciones + vínculos + fila + versión); el conjunto no lo es. Un rol cuyo owner ya no está en el árbol
   no es visible en ningún sitio, así que una purga a medias no cambia ninguna decisión: solo deja filas que
   la siguiente llamada recoge. Compartir transacción exigiría meter `purgeRole(trx)` en el puerto.
8. **El caso de la carrera de dos `define` afirma «nunca DOS», no «exactamente uno».** En SQLite con pool
   2..5 el segundo escritor puede recibir un `SQLITE_BUSY` (503 `E_AUTHZ_BACKEND_UNAVAILABLE`): su transacción
   NO se aplicó, así que es un fallo de backend legítimo, no un 422. El caso fija lo innegociable (nunca dos
   filas; la base tiene exactamente lo confirmado; el perdedor no escribe) y, **en serie**, que el segundo
   `define` choque siempre con 422 `E_AUTHZ_CATALOG_CONFLICT` venga del owner que venga y con el memo viejo.
   Reforzado, no relajado.
9. **Casos reescritos por choque con la spec nueva** (explicados en su comentario):
   `tests/catalog_cache.spec.ts` («el más cercano gana» ⇒ la ambigüedad es 422, con `rolesOwnedBy`);
   `src/testing/contract.ts` D11 («un `RoleQuery` objeto donde el contrato pide un slug ⇒ 422» ⇒ «un
   `RoleQuery` MAL FORMADO ⇒ 422; las tres formas legales valen y apuntan al mismo rol»);
   `tests/manager.spec.ts` (la lista de identidades inválidas cambia los tres objetos legales por cinco
   objetos mal formados). Ninguna aserción se debilita: los tres suman asertos.
10. **`AuthzWriteEvent.role` pasa de `string` a `RoleQuery`.** La auditoría registra lo que se pidió; a qué
    rol resolvió lo decide el driver con el árbol de ese instante.

## Conteos del juez

| Registro | Antes de 3D | Ahora |
|---|---|---|
| `'2.2'` con `listDenies: true`, `purgeRole: false` | 73 | **78** |
| `'2.2'` con `purgeRole: true` | 73 | **79** (el par es asimétrico desde M4) |
| `'2.2'` sin `listDenies` | 67 | **70** |
| `'2.2'` con `injectableClock: true` | 77 | **82** |

Casos nuevos del juez: ambigüedad tras un `moved` (M1), `effectivePermissions` con homónimo + delegación (M1),
carrera de dos `define` (M2), `scopes.detached` purga los roles del owner (M4, cara `purgeRole: true`),
paridad de nivel entre drivers (N1). Más, dentro de casos existentes: el `detached` con 500 sin tocar nada
(cara `purgeRole: false`) y el cero por el puerto público en `purgeRole` (M6 c).

## Ejecuciones de cierre (2026-08-29; `npm run typecheck` limpio; `check:purity` verde dentro de `npm test`)

| Ejecución | Resultado |
|---|---|
| `npm test` (SQLite memoria) | **399 passed** (base `f563465`: 384) |
| `OPENFGA_TEST_URL=:8101 npm test` | **504 passed** (base: 484) |
| `OPENFGA_TEST_URL=:8101 npm run test:sqlite-file` (pool 2..5) | **506 passed** ×3 ejecuciones seguidas (sin flakes) |
| `OPENFGA_TEST_URL=:8101 npm run test:pg` (PG 18) | **674 passed** (base: 643) |
| `OPENFGA_TEST_URL=:8101 npm run test:mysql` (MySQL 8.4) | **674 passed** (base: 643) |
| `OPENFGA_TEST_URL=http://localhost:8103 npm test` (`openfga-tiny`, `MAX_RESULTS=3`) | **504 passed**; contenedor retirado |

Sin skip, sin only, sin commits. Residuos: 0 bases `authz_test%` en PostgreSQL y MySQL, `openfga-tiny` borrado.

## Los cuatro `repro*.ts` del auditor, DESPUÉS (mismos scripts, PG, sin tocarlos)

```
=============== repro1_shadow ===============            (V3 🟠)
WithinRequiredError: defineScopedRole: el config exige 'within' (requireWithin: "non-root") y la escritura
sobre unit:01a04e05-… no lo declara.
  status: 422, code: 'E_AUTHZ_WITHIN_REQUIRED'
   ← M3 lo corta AÚN ANTES: el script define el rol del tenant B sin `within` teniendo `requireWithin:'non-root'`.
     Con solo M1 aplicado, el mismo script moría más adelante, en el `grant` por slug:
     «AmbiguousRoleError: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles en esta cadena
      (…owner=unit|…; …owner=organization|…)  ·  status: 422  code: E_AUTHZ_AMBIGUOUS_ROLE»

=============== repro2_effective ===============          (V1 🔴)
pepe tiene el rol de A: true
B pudo definir el homónimo: 01a04e05-e02e-72e9-b00f-9826b9bd442d
authorize(pepe, docs:read, U1)      = true
authorize(pepe, billing:write, U1)  = false
effectivePermissions(pepe, U1)      = [ 'docs:read' ]      ← ya es exactamente {p | authorize(p)}
listRoles(pepe, U1)                 = [ 'lead' ]
AmbiguousRoleError: 'lead' (nivel 'unit') es AMBIGUO aquí: hay 2 roles visibles en esta cadena
(…owner=organization|…; …owner=unit|…). status: 422  code: 'E_AUTHZ_AMBIGUOUS_ROLE'
   ← el script muere en `hasRole`: la ESCALADA («pepe delegó billing:write sin tenerlo» /
     «authorize(titere, billing:write, U1) = true») ya no llega a ejecutarse.

=============== repro3_varios ===============             (V2 🔴 A, V4 🟠, V5 🟡)
=== (a) carrera del chequeo de colisión: dos managers, dos memos ===
define(owner orgA) = fulfilled 01a04e05-e23f-747b-b299-44e48f322809
define(owner U1)   = rejected E_AUTHZ_CATALOG_CONFLICT
roles `lead@unit` en la base: [ { uuid: '01a04e05-e23f-…', owner_scope_key: 'organization|…' } ]   ← UNA fila
=== (b) define en un scope de OTRO tenant, con requireWithin: non-root ===
rechazado: E_AUTHZ_WITHIN_REQUIRED defineScopedRole: el config exige 'within' (requireWithin: "non-root") …
=== (c) purgeRole ===
asignaciones restantes: 0 · vínculos restantes: 0 · fila del rol: 0 · denies restantes: 1 · versión: 3 -> 4
=== (d) rol local cuyo owner ya no existe en el árbol ===
deleteScopedRole tras purgar el owner: 422 E_AUTHZ_UNKNOWN_ROLE
la fila del rol sigue: 0                                   ← el (slug, nivel) vuelve a estar libre

=============== repro4_global ===============             (V2 🔴 B)
sync   = fulfilled
define = rejected E_AUTHZ_CATALOG_CONFLICT
roles `viewer@unit`: [ { uuid: '01a04e05-e703-…', owner_scope_key: 'global', rank: 1 } ]   ← solo el global
```

**Los cuatro ataques fallan.** Ninguno consigue ya escribir el estado que los hacía explotables, y donde el
script seguía leyendo (`repro2`) el motor responde exactamente lo que `authorize` responde.

### Regresión: `repro5_resiste.ts` (la batería del auditor que NO se rompía) sigue verde

Las 23 barreras siguen respondiendo 422 antes de escribir: delegación hacia arriba/lados/raíz, permiso ajeno,
fuera de la lista blanca, `assignableAt`, rank (=, 0, no entero, por encima del propio), sin actor, actor mal
formado, **C2** (deny en el owner y en un ancestro), roles ajenos, globales inmutables, `updateScopedRole`
re-subiendo un permiso perdido o denegado, `grant` fuera del owner y en scope desconocido.

## Archivos tocados

- `src/errors.ts` — `AmbiguousRoleError` (422 `E_AUTHZ_AMBIGUOUS_ROLE`).
- `src/types.ts` — `RoleQuery` con `{ uuid }`, `NormalizedRoleQuery`, `CatalogRoleRef`; `grant`/`revoke`/`listSubjects` por `RoleQuery`; `rolesInChain` ⇒ `CatalogRoleRef`; `ScopedWriteOptions` (nueve escrituras); `AuthzWriteEvent.role`; `AuthzCatalogWriteEvent.actor` opcional.
- `src/identity.ts` — `normalizeRoleQuery` con `{ uuid }`; `chainKeysFrom` (N5).
- `src/catalog_cache.ts` — `roleVisible` fail-closed, `rolesOwnedBy`, `ownerOf` estricto, cerrojo del catálogo en `withAuthzCatalogWrite`.
- `src/manager.ts` — `#rolesAlong` por uuid; `grant`/`revoke`/`listSubjects` por `RoleQuery`; `within` en las tres de delegación; `#purgeRolesOwnedBy` en `scopes.detached`; re-chequeo de colisión en la transacción; `#parseScopedRoleChanges` estricto; `permissions: []` ⇒ 422.
- `src/drivers/database_driver.ts` — `resolveRoleQuery`/`visibleRoleFor`/`rolesToRevoke`/`hasRoleTargets`/`declaredRoleAt`; `dbScopeKey`/`rowScopeKey`; `rolesInChain` ⇒ `CatalogRoleRef`; `assertRoleAssignableAt` delega en `assertAssignableAt`.
- `src/drivers/openfga_driver.ts` — mismas rutas por `RoleQuery`; `declaredRole` ⇒ `declaredRoleAt`; sin wrapper `rolesGranting`.
- `src/catalog.ts` — `ambiguousRoles` + `findAmbiguousRoles`, `storedAssignableAt`, `ASSIGNABLE_AT_MAX`, `runCatalogDiff({ resolveChain })`.
- `commands/authz_catalog_diff.ts` — pasa el `resolveChain` del config.
- `src/testing/contract.ts` — 5 casos nuevos, D11 reescrito, `purgeRole` `whenTrue`/`whenFalse` reforzados, helper `retypeRole`.
- `tests/helpers/schema.ts` — FKs alineadas al stub + `describeAuthzForeignKeys`.
- `tests/migration_stub.spec.ts` (K11 con acciones de FK), `tests/contract_harness.spec.ts` (conteos), `tests/manager.spec.ts` (M3, N2, N3, N5, M2 d), `tests/catalog_cache.spec.ts` (M1).
- `CHANGELOG.md` (Lot 3D), `CLAUDE.md` (invariantes 15 y 18, mapa, roadmap), `README.md` (§Containment, §Actor, §Scoped roles, §The catalog, §Errors, §Custom drivers, §OpenFGA notes).
- Este informe.
