# Panel store compartido — AUDITOR (ataque a la corrección de COGNITIV)

Base: `main`, `d18af8e`, `2.4.0-alpha.8`. Repro contra el `:8101` (levantado, `{"status":"SERVING"}`).
Script: `.claude/reproducciones/shared-store-tipos-legado.sh` (crea su propio store, no toca nada más).

## Veredicto en una línea

**Seguro con reservas, y solo con UNA forma concreta**: el núcleo de la corrección es correcto —ninguna
tupla fuera de `{scope, role, role_binding}` puede influir en `can_<P>`, verificado por el modelo y por el
servidor—, pero **«ajena = lo que no reconozco» es inaceptable**: la lista tiene que ser **EXPLÍCITA,
congelada y con los tipos HISTÓRICOS dentro** (`RESERVED_FACTS_TYPES \ {group}` = `scope`, `role`,
`role_binding`, `deny_binding`), y `foreign` no puede pasar por `note()`.

---

## Hallazgos (ordenados por severidad)

### 🟠 1 — «lo que no reconozco es ajeno» abandona `deny_binding` y rompe la propiedad publicada

- **Escenario**: store migrado desde el modo `resolver` de 2.2 (tiene `deny_binding:<key>|<permUuid>#denied@user:X`)
  → operador corre `authz:reconcile --to=openfga --prune` tras la corrección → la tupla ya no es `facts`, es
  `foreign` ⇒ **no se borra nunca más**. Hoy sí se borra, y CLAUDE.md lo publica con esas palabras
  («la basura de un modelo anterior, **que se lee y se borra aunque ya no se pueda escribir**»,
  bloque «Todo en un driver o todo en otro»; el mismo docblock está en `src/drivers/openfga_driver.ts:3288-3294`).
- **Evidencia**: ✅ medido contra el `:8101` (`.claude/reproducciones/shared-store-tipos-legado.sh`):
  con el modelo nuevo publicado, una tupla `deny_binding` **se lee** en `Read({})`, **escribir** otra es
  `400 "type 'deny_binding' not found"`, y **borrarla es `200`**. La promesa es real y es la que se pierde.
- **Y no es solo basura**: `enumerateFacts` (`src/drivers/openfga_driver.ts:3255-3281`, «3b-8 · A2») **lee esa
  tupla como un HECHO** (deny explícito de 2.2) en la dirección `--to=database` y en la pasada de
  MANTENIMIENTO. O sea: el mismo driver la trata como propia por un lado y, con la corrección ingenua, como
  ajena por el otro. La consecuencia concreta: hoy la pasada de mantenimiento **cura** el store (lee el
  `deny_binding` como deny, escribe el `scope#denied_<P>` moderno —`wantDeny`, `openfga_driver.ts:3016`— y
  `--prune` barre el legado); con la corrección ingenua el legado se queda para siempre, duplicado, y
  `clean = true` mintiendo.
- **¿Concede alguno de los tipos históricos si se queda?** **No, ninguno** (y esto es lo que salva la
  corrección). Tipos que este paquete ha escrito alguna vez, sacados del historial
  (`git show 464f7b7^:src/drivers/openfga_driver.ts` → `role_binding`, `deny_binding`;
  `openfga_facts.ts` → `scope`, `role`; relaciones → `group`):
  | tipo | ¿existe hoy en el modelo? | ¿concede si se queda? |
  |---|---|---|
  | `role_binding` (ids 1.x con slug incluidos) | sí | es NUESTRO ⇒ se sigue podando; el id 1.x no tiene `scope#binding` ni `role_binding#role` ⇒ inerte |
  | `scope` (`#ancestor`, `#binding`, `#parent`, `rooted`) | sí | NUESTRO ⇒ se sigue podando |
  | `role` (`permits_<P>`) | sí | NUESTRO ⇒ espejo, se rehace siempre |
  | `deny_binding` | **no** (c2r no lo declara) | **no concede** (ningún camino de `can_<P>` lo toca) — pero es un DENY perdido y un hecho para `enumerateFacts` |
  | `group` | sí (lo emite relaciones) | **no** en roles: `role_binding#assignee` solo admite holder types |
- **Steelman**: «si no está en el modelo, no concede; dejarlo es inocuo». → **No me convence del todo**: no es
  fail-open, pero rompe una propiedad publicada, deja `--prune` sin la mitad de su trabajo y estropea la ruta
  de subida desde 2.2 (que es exactamente el escenario de un cutover).
- **Mitigación mínima**: la lista de tipos PROPIOS es explícita y viene de `RESERVED_FACTS_TYPES` menos
  `group` (`src/identity.ts:329`), no de tres literales nuevos; lo que no está en ninguna lista se cuenta
  como `foreign` y **se reporta, no se borra**.

### 🟠 2 — si «ajena» se decide con algo que se lee en runtime, el 🔴 vuelve (e intermitente)

- **Escenario**: la corrección se implementa como «ajena = tipo declarado en `relations.config`» o
  «= tipo del modelo publicado que no es mío». Precondición: (a) el consumidor corre el reconcile desde un
  proceso sin `relations.config` —**el caso literal de COGNITIV al migrar**— o (b) el
  `readLatestAuthorizationModel` falla/devuelve un store sin modelo → acción: `--prune` → resultado:
  `relationTypes` vacío ⇒ las 60 tuplas de relación vuelven a ser `facts` ⇒ **borradas**, `[success]`, exit 0.
- **Evidencia**: ✅ el precedente de fallback permisivo está en la MISMA función:
  `openfga_driver.ts:2492-2494`, `const usable = (p) => publishable === null || publishable.has(...)` —un
  implementador que copie ese patrón produce exactamente este agujero. Y `relations.config` es opcional
  (`providers/authz_provider.ts:36`: sin él `authz.relations` ni se construye), mientras que la tabla
  `authz_relations_config` también puede estar vacía (`readRelationsConfig` ⇒ `null`).
- **Steelman**: «el modelo siempre está publicado en un store en producción». → **No me convence**: el propio
  código ya contempla `publishable === null`, y el store recién provisionado / el rollback de modelo son
  escenarios de cutover, que es justo cuando se corre esto.
- **Mitigación mínima**: la decisión de BORRAR depende **solo** de la lista propia congelada. La config de
  relaciones y el modelo pueden usarse para ENRIQUECER el reporte (desglose de `foreign` por tipo), nunca
  para decidir un `delete`.

### 🟠 3 — tras la corrección, las tuplas de un tipo de relación NO declarado no las limpia nadie, y RESUCITAN

- **Escenario**: el consumidor quita/renombra `document` de `objectTypes` (creyendo que así lo desactiva) →
  las tuplas `document:app|d1#viewer@user:1` siguen en el store → hoy `authz:reconcile --prune` las borra
  (caen en `facts`/`extra`); tras la corrección son `foreign` y **ninguna herramienta del paquete las
  alcanza**: `enumerateRelations` no las enumera (allowlist: `openfga_relations_driver.ts:667`),
  `reconcileRelations --prune` por tanto no las ve, y `purgeObject` es 422 por F-05
  (`assertObjectTypeDeclared`). Acción del atacante/operador: volver a declarar `document` meses después →
  **todos los `viewer` viejos vuelven a conceder** sin que nadie haya escrito una tupla.
- **Evidencia**: ✅ código (`src/drivers/openfga_relations_driver.ts:667-672` filtra por
  `new Set([group, ...config.objectTypes])`; `src/relations/reconcile.ts:404` `declaredIn`; F-05 en
  `define_relations_config.ts:125-136`). 🟡 el paso final (resurrección) es deducción del modelo, no lo medí.
- **Steelman**: «quitar un tipo de la config es un cambio de esquema; que lo limpie el operador». → **No me
  convence**: el paquete no publica ninguna forma de limpiarlo y hoy sí se limpia (por accidente). Como
  mínimo tiene que salir en el reporte con su tipo.
- **Mitigación mínima**: `foreign` desglosado **por tipo** en el reporte, y una línea del comando que diga
  «tipos ajenos vistos: `document` (n), `group` (m)» — el operador necesita ver un tipo que ya no declara.

### 🟡 4 — `clean` sigue en falso (o el operador pierde las líneas que importan) si `foreign` entra por `note()`

- **Escenario (a)**: `note('tuple','foreign', id)` ⇒ `skipped.foreign > 0` ⇒
  `drifting = Object.keys(report.skipped).filter(r => r !== 'expired')` no queda vacío
  (`commands/authz_reconcile.ts:165`) ⇒ **`clean = false` eterno**, que es justo el corolario que había que
  cerrar. La corrección no arreglaría nada.
- **Escenario (b)**, con lever de tenant: aunque `foreign` se exima del `drifting`, `note()` empuja a
  `details` con tope 200 (`openfga_driver.ts:2469`, `RECONCILE_MAX_DETAILS` en `src/reconcile.ts:30`) y el
  comando imprime **una warning por entrada** (`commands/authz_reconcile.ts:64-66`). Un tenant que use
  `relate` con normalidad genera miles de tuplas ajenas; si el bucle las encuentra primero (orden del
  `Read({})` del store, que él no controla pero sí puede dominar por volumen), las 200 líneas se gastan en
  ruido y **desaparece el detalle de los `extra-fact` reales** —los que SÍ conceden—. Los contadores
  sobreviven; el «qué tupla» no.
- **Evidencia**: ✅ las tres líneas citadas.
- **Steelman**: «el operador mira los contadores, no las warnings». → medio convence: el contador sigue ahí,
  por eso es 🟡 y no 🟠. Pero el detalle es lo único que dice QUÉ borrar.
- **Mitigación mínima**: `foreign` es un **campo propio del reporte** (`foreign: { total, byType }`), fuera de
  `skipped` y fuera de `details`. Nada de reutilizar `note()`.

### 🟡 5 — cómo se parte la tupla, y la forma del reporte

- **Escenario**: se copia el método de COGNITIV («el tipo del objeto tras la última `@` del `detail`»). El
  `detail` es `factsTupleId` = `user#relation@object` (`openfga_facts.ts:~643`); el driver **ya tiene el
  campo estructurado** (`tuple.object`). Parsear la cadena mete un parser evitable en la ruta que decide un
  `delete`: un `user` de tipo userset (`group:x#member`) ya lleva `#`, y un id de objeto de relaciones lo
  elige el consumidor. Usa `tuple.object.slice(0, indexOf(':'))`, y con `indexOf`, no `split`.
- **Escenario 2**: si `foreign` se añade como cuarta `ReconcileFamily`, `phases[family]` revienta o publica
  una forma nueva: `emptyReconcilePhases`/`sumReconcilePhases` (`src/reconcile.ts:60-69`) tienen las cuatro
  familias fijas y `ReconcileReport.phases` es tipo publicado. Decide: o `foreign` NO es una familia (es un
  contador aparte, mi recomendación) o se toca el tipo publicado y el CHANGELOG.
- **Evidencia**: ✅ código. **Steelman**: «es detalle de implementación» → sí, por eso es 🟡; pero el primero
  decide un borrado y el segundo es un `TypeError` en la herramienta de reparación.

### ⚪ 6 — el store compartido come la cota y la memoria del reconcile de roles

`readEveryTuple` vuelca el store ENTERO en memoria con tope `DEFAULT_RECONCILE_MAX_TUPLES = 1_000_000`
(`src/types.ts:813`, `openfga_driver.ts:3322`). Las tuplas de relación cuentan aunque la corrección las
ignore después: un despliegue ReBAC grande puede dejar `authz:reconcile` en
`E_AUTHZ_RECONCILE_TOO_LARGE` —la herramienta de reparación de roles caída por datos de otro subsistema—.
No es explotable hoy; sí es una línea en el README de «Limits».

### ⚪ 7 — `defineRelationsConfig` sin `holderTypes` deja declarar un tipo con nombre de holder

`holderTypes` es opcional en el spec (`define_relations_config.ts:66-70,195`): sin él, `objectTypes: [{type:'user'}]`
pasa la validación y solo lo caza el generador del modelo fusionado (`openfga_facts.ts:888-905`, que sí recibe
los holder types del driver). No afecta a la corrección (esos tipos serían ajenos igualmente), pero es un
error que llega tarde.

---

## Respuestas directas a las cinco preguntas

1. **Basura que deja de limpiarse**: `deny_binding:*` (modo `resolver` 2.2), `group:*` huérfano de un rollout
   de relaciones abandonado, y tuplas de un tipo de relación ya no declarado (🟠 3). **Ninguna concede hoy**
   —verificado—, así que ignorar por tipo **no es fail-open para roles**; pero por eso mismo la lista tiene
   que ser explícita e incluir los tipos históricos, no un «lo demás».
2. **¿Puede una tupla de relación tener un objeto de tipo nuestro?** **No**, doble puerta:
   `defineRelationsConfig` rechaza `RESERVED_FACTS_TYPES` (`define_relations_config.ts:200,211`) y el
   generador del modelo fusionado lo vuelve a rechazar (`openfga_facts.ts:888,900`). **¿Y al revés?**
   Tampoco: los objetos de `facts` son solo `scope|role|role_binding` y ningún string del consumidor entra
   en el tipo. **Qué ganaría el atacante**: (a) «suya → nuestra» = destrucción de datos ReBAC con `--prune`
   (fail-CLOSED para el acceso: el modelo de relaciones no tiene negación, ver `factsRelationTypeDefinitions`,
   solo uniones); (b) «nuestra → ajena» = una tupla que concede sobrevive a `--prune` — **eso sí sería el
   🔴**, y está cerrado por el modelo: ningún objeto fuera de esos tres tipos aparece en la expansión de
   `can_<P>` (`openfga_facts.ts:352-418`).
   ⚠️ Nota: `RelationsConfig` es una interfaz **estructural sin marca**; un consumidor puede pasar un objeto
   a mano con `hasType` mentiroso. No lo cuento como hallazgo (es su propio pie), pero si algún día la
   clasificación dependiera de esa config, pasaría a serlo.
3. **¿Necesita el reconcile la `relations.config`?** **No, y no debe usarla** (ver 🟠 2). Con una lista propia
   congelada, los tres casos que preguntas salen bien sin config: sin `relations` declaradas y con tuplas de
   relación en el store (COGNITIV) → ajenas, respetadas; con relaciones distintas de las del store → igual,
   porque la decisión no mira esa lista. El modelo publicado (`modelPermissions`, `openfga_driver.ts:2489`)
   ya está leído y sirve para el desglose por tipo, nunca para decidir el borrado.
4. **La vuelta (`authz:relations:reconcile` sobre el mismo store)**: **NO existe el defecto simétrico**. El
   barrido de relaciones es un **allowlist**: `relationTypes = {group} ∪ objectTypes` y además exige que el
   id parsee como `<key>|<uuid>` (`openfga_relations_driver.ts:667-676`, `#parseObjectId:347`). Las tuplas de
   `facts` (`role_binding:app|r1`, `scope:org|u`, `role:<uuid>`) no entran, así que ni el origen ni el
   destino las ven y `toDelete` (`src/relations/reconcile.ts:391`) nunca las contiene. **Ese es exactamente
   el patrón que tiene que copiar el reconcile de hechos**, y es el argumento más fuerte a favor del
   allowlist frente al «catch-all invertido».
5. **`clean = false` eterno**: no basta con sacarlo de `skipped`; hay que **reportarlo aparte y por tipo**
   (🟡 4 y 🟠 3). Y sí, un tenant hace crecer ese número a voluntad con `relate` normal: por eso `foreign`
   no puede tocar `details` (tope 200, una warning por entrada) ni entrar en la cuenta de deriva.

---

## Mi condición para que la corrección sea segura (las cinco, todas)

1. **Lista blanca explícita y congelada** de tipos propios = `RESERVED_FACTS_TYPES` **menos** `group`
   (`scope`, `role`, `role_binding`, `deny_binding`), importada de `src/identity.ts`, **no** tres literales
   nuevos en `openfga_driver.ts`. Regla escrita: *un tipo nuevo del modelo `facts` entra en
   `RESERVED_FACTS_TYPES` en el MISMO commit* (así `defineRelationsConfig` grita al arrancar en vez de
   borrar en silencio los datos de quien ya usaba ese nombre).
2. **`familyOfTuple` deja de tener catch-all**: `return 'facts'` solo para los tipos de la lista; lo demás
   devuelve `foreign` y sale del bucle **antes** de `deletes.push` —y también antes de `phases[...]`—.
3. **La clasificación no lee nada**: ni `relations.config`, ni `authz_relations_config`, ni el modelo
   publicado. Un fallo de lectura no puede volver a convertir una tupla ajena en borrable.
4. **`foreign` se reporta aparte**: campo propio (`foreign: { total, byType }`), fuera de `skipped`, fuera de
   `details`, y con una línea del comando. Sin eso, `clean` sigue roto o el reporte se ahoga.
5. **La propiedad publicada se actualiza en el mismo lote**: CLAUDE.md y el docblock de `readEveryTuple`
   dicen hoy «se lee y se borra aunque ya no se pueda escribir». Tras la corrección eso vale para **la basura
   de los tipos PROPIOS** y deja de valer para lo ajeno. Si esa frase no se corrige, el siguiente auditor la
   cobra como mentira publicada.

---

## Lo que intenté y NO se rompió

- **Escalada de relaciones a roles por el `group`**: `role_binding:x#assignee@group:g1#member` ⇒ `400
  "'group#member' is not an allowed type restriction for 'role_binding#assignee'"` (medido). Una tupla de
  `group` que sobreviva a la corrección **no concede un rol**.
- **Colisión de tipos en los dos sentidos**: doble puerta (config + generador del modelo). No encontré vía.
- **`authz:relations:reconcile --prune` borrando hechos**: no ocurre (allowlist + clave de partición entera).
- **Colisión de ids**: `factsTupleId` de una tupla de relación nunca coincide con una `wanted` (el tipo del
  objeto difiere siempre), así que no hay forma de que una relación «ocupe» el sitio de un hecho.
- **Nombres de relación**: `RESERVED_SLUGS` + `RESERVED_SLUG_PREFIXES` impiden que una relación declarada se
  llame `assignee`/`denied_x`/`parent`… ⇒ `enumerateFacts` no puede confundir una tupla de relación con un
  hecho en la dirección `--to=database` (ahí simplemente se ignora, sin contarla; aceptable).
- **El seguro de borrado masivo**: tras la corrección sigue midiendo lo correcto (`phases.facts.deleted` ya
  no incluye ajenas), y en el caso medido por COGNITIV dejaría de haber borrado que justificar.

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. ¿`deny_binding` se queda en «propios» (mi recomendación: sí, para no perder ni el barrido ni la cura de la
   migración 2.2) o se declara muerto y se documenta que un store de 2.2 se limpia a mano?
2. ¿`foreign` es campo nuevo del `ReconcileReport` (cambio de tipo publicado, CHANGELOG) o se mete en `drift`?
   Lo que NO puede ser es `skipped`.
3. Tras la corrección, ¿el paquete ofrece alguna salida para las tuplas de un tipo de relación ya no
   declarado (🟠 3), o se documenta «renombrar un `objectType` deja tuplas vivas que resucitan al volver a
   declararlo»? Una de las dos, pero por escrito.

---

# RE-ATAQUE al lote alpha.9 (working tree sin commitear, 11-09-2026)

Veredicto del re-ataque: **APTA**. Ningún 🔴/🟠 nuevo; mis tres 🟠 anteriores están cerrados y verificados
uno a uno. Quedan **dos 🟡 y un ⚪** que NO condicionan el lote (los tres son de tres líneas y están en
ficheros que el lote ya toca, así que recomiendo meterlos, no aplazarlos).

## Mis cinco condiciones, juzgadas

| # | condición | estado |
|---|---|---|
| 1 | lista blanca explícita y congelada | ✅ **con matiz** (ver ⚪ C) — el `OWN_FACTS_OBJECT_TYPES` propio me vale |
| 2 | `familyOfTuple` sin catch-all, fuera antes de `phases`/`note`/`deletes` | ✅ verificado |
| 3 | la clasificación no lee nada en runtime | ✅ verificado |
| 4 | `foreign` campo propio, fuera de `skipped` y de `details` | ✅ verificado |
| 5 | propiedad publicada corregida | ✅ verificado (CLAUDE.md, docblock, README con el residuo) |

**Sobre (1) y la constante propia en vez de `RESERVED_FACTS_TYPES \ {group}`: me basta, y de hecho es mejor
que lo que pedí.** Mi versión tenía un defecto que el dueño evitó: `RESERVED_FACTS_TYPES` y «lo que esta
pasada gobierna» son conjuntos con propósitos distintos, y derivar el segundo del primero con una resta deja
la resta como el único punto donde alguien puede equivocarse (quitar `group` de la resta = el 🔴 de vuelta).
La lista literal + el caso que afirma `OWN ⊆ RESERVED` cubre **la dirección peligrosa** (añadir un tipo a
`OWN` sin añadirlo a `RESERVED` ⇒ `defineRelationsConfig` lo dejaría declarar y esta pasada borraría datos
del consumidor ⇒ rojo). Ver ⚪ C por la dirección que NO cubre.

## (a) `deny_binding` en las DOS caras — ✅ intacto

- **Cara `--prune`**: `LEGACY_DENY_BINDING_TYPE` está en `OWN_FACTS_OBJECT_TYPES`
  (`src/drivers/openfga_driver.ts:3499`) ⇒ `familyOfTuple` no lo marca `foreign`, cae en `facts` ⇒ `extra` ⇒
  `--prune` lo borra. Sigue cumpliéndose la promesa publicada.
- **Cara `enumerateFacts`**: el bloque de 3b-8 · A2 (`openfga_driver.ts:3279-3281`) **no lo toca el diff**
  (el diff de ese fichero son 4 hunks: imports, el bucle, el docblock de `readEveryTuple` y las funciones
  nuevas). Sigue emitiendo el deny legacy como hecho en `--to=database` y en la pasada de mantenimiento.
- **Repro re-ejecutado** (`.claude/reproducciones/shared-store-tipos-legado.sh`, store
  `01M29P5WXAQA424ET5V5425Q1V`): con el modelo nuevo publicado, la tupla `deny_binding` **se lee**, escribir
  otra es `400 type 'deny_binding' not found`, **borrarla es `200`**, y `role_binding#assignee@group:g1#member`
  es `400 "'group#member' is not an allowed type restriction"`. Los tres hechos en los que se apoya el lote
  siguen siendo ciertos.

## (b) ¿Queda algún camino en que BORRAR dependa de una lectura? — ✅ no

`grep` de `relationTypes` en todo `src/`: solo tres sitios —el tipo (`src/types.ts:725`), el manager que lo
rellena (`src/manager.ts:1970-1978`) y `foreignReport` (`openfga_driver.ts:3556-3568`)—. `foreignReport` solo
construye campos del reporte; el criterio de borrado es `OWN_FACTS_OBJECT_TYPES.has(objectTypeOf(object))`
en `familyOfTuple:3534`, sin argumentos ni I/O. El `?? `/`undefined` está bien orientado: sin
`relations.config` **todo va a `unknown`** (la verdad: este proceso no sabe de quién es) y nunca a «borrable».
`objectTypeOf` usa `indexOf` (no `split`) y un objeto sin `:` da `''`, que no está en la lista ⇒ ajeno ⇒
intocable. El orden tipo-antes-que-relación está y es correcto: una ajena llamada `rooted` no puede caer en
una familia derivada (las que se borran sin `--prune`).

## (c) El residuo: declarado, y la salida existe pero la RECETA publicada se queda corta — 🟡 A

- **Escenario**: el operador lee el README («take `document` out of `objectTypes` … the way out today is to
  declare the type and run `authz:relations:reconcile --prune`»), re-declara el tipo y corre el comando →
  **500 `E_AUTHZ_MASS_RECONCILE_REFUSED`**, porque el ORIGEN (`database`) no tiene ni una tupla de esa
  partición y el destino sí (`src/relations/reconcile.ts:257`, `planPartition:392`
  `massDelete = prune && toDelete.length > 0 && sourceTuples.length === 0`). La reacción natural es
  `--allow-mass-delete`… que sobre una partición equivocada vacía relaciones VIVAS.
- Y falta la otra mitad: el comando reconcilia **UNA partición por pasada**
  (`commands/authz_relations_reconcile.ts:274-277`), así que la receta hay que repetirla por tenant; un
  residuo en una partición que no se nombre se queda.
- **Evidencia**: ✅ código. **Steelman**: «la receta es un puntero, no un runbook». → a medias: es la única
  salida publicada de un camino destructivo, y el 500 que se encuentra de frente empuja justo a la bandera
  peligrosa. **Mitigación**: una frase — «por partición, y con `--allow-mass-delete` si esa partición no
  existe en el origen; comprueba antes con `--dry-run`».

## (d) `details` y `clean` con miles de ajenas — ✅ intacto

El `continue` del `foreign` está **antes** de cualquier `note()` (`openfga_driver.ts:2590-2595`), así que las
ajenas no gastan ni una de las 200 entradas de `details` ni aparecen en `skipped`; `drifting` sigue siendo
`Object.keys(report.skipped)` menos `expired` (`commands/authz_reconcile.ts:165`) ⇒ **`clean` puede ser
`true` con el store compartido**, que era el corolario a cerrar, y los `extra-fact` reales conservan su línea.

## (e) ¿Puede un tenant inflar `foreign` para esconder algo? — ✅ no

- `foreign.tuples` sí crece con `relate` normal, pero **no toca nada más**: ni `details`, ni `skipped`, ni
  `phases`, ni el exit.
- `foreign.types` está acotado por los tipos del MODELO (el servidor rechaza un tipo no declarado: medido),
  así que la línea `[document (40), group (10)]` no se puede alargar a voluntad.
- El único aviso (`level: 'warning'`) es el de `unknown > 0`, y un tenant **no puede inflar `unknown`**: para
  escribir necesita un tipo declarado (F-05 + modelo), y un tipo declarado cuenta como `relations`. Subir
  `unknown` exige tocar la config o entrar por `manager.driver()`, que es plataforma.
- Lo único que un tenant puede provocar con volumen es `E_AUTHZ_RECONCILE_TOO_LARGE` (cota `maxTuples`, 1 M),
  que es ruidoso y está declarado en el README nuevo. No es ocultación.

## (f) LOTE A — ✅ ni un nombre público cambió, y la guardia aguanta

- **Nombres**: la corrección es quitar `name:` (que en ace pisa el nombre de la PROPIEDAD:
  `{ name, flagName: dashCase(name), ...options }` + `defineProperty(this, flag.name, …)`,
  `node_modules/@adonisjs/ace/build/index.js:376-382` y `:676-679`). `flagName` ya era `dashCase(propiedad)`
  en todos los casos, así que **la bandera pública no cambia**. Verificado ejecutando `string.dashCase` sobre
  las 21 propiedades declaradas: `dryRun→dry-run`, `allowMassDelete→allow-mass-delete`, `leaseMs→lease-ms`,
  `waitLeaseMs→wait-lease-ms`, `partitionUuid→partition-uuid`, `failOnShadows→fail-on-shadows`,
  `maxAge→max-age`, `only→only`, `id→id`… todas coinciden con el `name:` retirado. **Cero renombres.**
- **La guardia se puede burlar?** Lo intenté por tres vías y las tres mueren:
  (i) `flagName: "otra-cosa"` con comillas DOBLES escapa al regex de A-G-2 → lo caza A-G-3
  (`flag.flagName === dashCase(flag.name)` sobre los flags BOOTEADOS);
  (ii) un comentario entre el decorador y el `declare` rompe el regex de `declaredFlags()` → la bandera
  desaparece de `declaradas` y A-G-3 falla por `declaradas.has(flag.name)`; falla **cerrado**, bien;
  (iii) una bandera declarada fuera de `commands/` → mismo `declaradas.has` en rojo.
  A-G-3 recorre la metadata REAL del loader (`commands/main.js`), no una lista a mano, así que un comando
  nuevo entra solo. La única vía que quedaría es un comando que no esté en el loader — y eso ya lo cierra
  el diente C-5 de `commands.spec.ts` («cada fichero de `commands/` está en el loader»).
- **`--allow-mass-delete` / `--allow-mass-purge`**: se pasan con `=== true`
  (`authz_reconcile.ts:326`, `authz_relations_reconcile.ts:299`) y el driver compara
  `options.allowMassDelete !== true` (`openfga_driver.ts:2636`): solo un `true` literal levanta el seguro;
  `--no-allow-mass-delete`, ausencia o `undefined` lo dejan puesto. Correcto.
- **🟡 B (nuevo, mismo lote A)**: `--partition-uuid` **sin** `--partition-type` se ignora en SILENCIO
  (`commands/authz_relations_reconcile.ts:274-277`: el ternario solo mira `partitionType`) ⇒ la pasada
  reconcilia `app`, escribe 0 y sale `[success]` con exit 0. Es **la misma forma** del 🔴 2 del quinto
  informe («migra 0 y reporta éxito») sobreviviendo a un error de tecleo plausible en el runbook de cutover.
  Lo mismo con `--partition-type=app --partition-uuid=X`. Y `--partition-type=org` a secas construye
  `{ type:'org', uuid:'' }`, que muere en `assertScope` (ruidoso, bien).
  **Mitigación**: `--partition-uuid` sin `--partition-type` ⇒ exit 1 con la frase; tres líneas, en el fichero
  que el lote ya toca.

## ⚪ C — la dirección que `OWN ⊆ RESERVED` no cubre

El caso B-6 (`tests/reconcile.spec.ts:2991-3004`) afirma `OWN ⊆ RESERVED_FACTS_TYPES`. Eso mata «añadir a
`OWN` y olvidar `RESERVED`». La dirección contraria —un tipo NUEVO del modelo `facts` que entre en el modelo
y en `RESERVED` pero **no** en `OWN`— pasa el caso en verde y deja ese tipo **sin gobernar para siempre**: su
espejo no se repara y `--prune` no lo limpia (si ese tipo concede, como `role#permits_<P>`, una tupla rancia
seguiría concediendo). No es explotable hoy —hoy los tipos del modelo son exactamente los cuatro—, pero es el
mismo bug a un commit de distancia y sin diente.
**Diente exacto, mecánico y barato** (no lo escribo yo, es de tres líneas):
para `openFgaFactsModel(HOLDERS, PERMISSIONS).type_definitions`, todo `type` que no sea un holder type tiene
que estar en `OWN_FACTS_OBJECT_TYPES`. Con eso las dos direcciones quedan atadas al MODELO, que es la
autoridad real, y la regla escrita en el docblock («entra en la lista en el MISMO commit») deja de depender
de que alguien la lea.

## (g) ¿Reabre algo de alpha.5/6/8? — ✅ no

- Los casos tocados en `tests/scope_outbox.spec.ts` (5) **se endurecen**, no se aflojan: `f.name ?? f.flagName`
  → `f.flagName`. Ese `?? f.name` era precisamente el punto ciego que dejaba pasar el defecto (`f.name` valía
  `'dry-run'` por el bug y la aserción pasaba con la bandera inerte).
- Cambios de comportamiento reales al despertar las banderas, todos declarados en el CHANGELOG y todos en la
  dirección segura: `relay --dry-run` deja de APLICAR; `--max-age` puede sacar exit ≠ 0 donde antes siempre
  era 0; `--fail-on-shadows` idem; `--only` filtra de verdad; `--lease-ms` hace que la ventana del freeze
  **caduque sola** donde antes no caducaba (lo único que empeora la disponibilidad de la garantía, pero es la
  semántica pedida y el comando ahora lo dice al revés que antes — A-8 lo fija).
- El CHANGELOG es honesto en el detalle que más fácil habría sido maquillar: `--only` y `--id` llevaban
  `name:` y **no** eran inertes (`dashCase('only') === 'only'`), y lo dice.
- Nada del lote toca `projectCatalog` (que lee con filtro `{user:'<holder>:*', object:'role:'}` y además
  exige `permits_`), ni las purgas, que leen por objeto exacto: **no hay una segunda instancia del catch-all**
  en otro camino que borre sin `--prune`. Lo comprobé.
