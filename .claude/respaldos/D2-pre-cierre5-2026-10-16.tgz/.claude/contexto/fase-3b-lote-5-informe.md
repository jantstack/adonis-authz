# Fase 3b · lote 5 — los dos 🔴 de la auditoría final

**Encargo:** cerrar los hallazgos **1** y **2** del auditor final
(`.claude/contexto/fase-3b-auditor-final.md`) y **solo** esos. El 🟠 3 (`freeze()` de proceso)
está pendiente de decisión del dueño y NO se toca; los 🟡 4/5 y el ⚪ 6 van al plan siguiente.

**Estado:** CERRADO. Los dos 🔴 quedan cerrados por un solo arreglo; nada más se tocó.

## La raíz, y por qué un solo arreglo

Los dos 🔴 son el mismo defecto visto por dos caras: **`authz:reconcile --to=openfga` lee los
hechos de `authz_assignments`/`authz_denies` sin comprobar que esas tablas sean la fuente de
verdad de los hechos en ESTE despliegue.** En `hierarchy: 'facts'` no lo son —los hechos son
tuplas del store— y de ahí salen las dos cosas medidas por el auditor:

- lo que **falta** en `authz_*` se reescribe (un `revoke` posterior al cutover se deshace) y lo
  que **sobra** en el store se cuenta como `extra-fact` (con `--prune`, se borra: los denies
  vivos) → 🔴 2;
- y como `wanted.facts` sale vacío, el conjunto `forbidden` —lo único que retira una arista
  `scope#binding`— también, así que el barrido de visibilidad del invariante 18 **no se aplica
  por este camino**, mientras el árbol sí se rehace: se aplica la mitad que concede de un
  `moved` perdido y no la que retira → 🔴 1.

El arreglo ataca la raíz: **los hechos los pone quien es su fuente de verdad**, y quién es se
decide en voz alta (lote 3b-3b ya tenía la pieza: `--from` y la capacidad `enumerateFacts`).

## 1 · La reproducción del auditor, ANTES (roja)

### 🔴 1 — `repro/a1b.ts` (HEAD `2507f45`)

```

=== 1. Un rol LOCAL de orgA, nivel unit, asignado en unit (que cuelga de orgA) ===
  rol local: unit-lead@unit uuid=01a05949-938d-77da-9220-e1f0add5b572 owner=organization|01a05949-936a-72e0-9366-e608d36f1402
  authorize(victima, docs:write, unit) con unit BAJO orgA        facts=true   database=(pendiente) *** FACTS FAIL-OPEN ***

=== 2. El consumidor mueve unit a orgB (otro tenant). El relay PIERDE la entrada (aparcada) ===
  outbox: pending=0 dead=1
  authorize(victima, docs:write, unit) con unit BAJO orgB, antes de reconcile facts=true   database=(pendiente) *** FACTS FAIL-OPEN ***

=== 3. `authz:reconcile --to=openfga` — el remedio que documenta el invariante 18 ===
  fases: {"root":{"written":0,"updated":0,"unchanged":3,"extra":0,"deleted":0},"catalog":{"written":0,"updated":0,"unchanged":6,"extra":0,"deleted":0},"tree":{"written":1,"updated":0,"unchanged":2,"extra":1,"deleted":1},"facts":{"written":0,"updated":0,"unchanged":0,"extra":6,"deleted":0}}
  skipped: {"extra-fact":6}
  drift: {"rootMarker":false,"multiParent":[],"roleVisibility":0,"pendingRelay":0,"deadRelay":1}
  authorize(victima, docs:write, unit) DESPUES de reconcile      facts=true   database=(pendiente) *** FACTS FAIL-OPEN ***

=== 4. El árbol del store SÍ se movió (la mitad que concede), la arista de visibilidad NO ===
  role_binding:app|01a05949-9331-7469-90a7-d0a08418dbd6#binding@scope:app
  role_binding:unit|01a05949-936a-72e0-9366-eef45ee0d7bc|01a05949-938d-77da-9220-e1f0add5b572#binding@scope:unit|01a05949-936a-72e0-9366-eef45ee0d7bc
  scope:app#parent@scope:organization|01a05949-936a-72e0-9366-e608d36f1402
  scope:app#parent@scope:organization|01a05949-936a-72e0-9366-e9d85c3863c2
  scope:organization|01a05949-936a-72e0-9366-e9d85c3863c2#parent@scope:unit|01a05949-936a-72e0-9366-eef45ee0d7bc
  orgA=organization|01a05949-936a-72e0-9366-e608d36f1402
  orgB=organization|01a05949-936a-72e0-9366-e9d85c3863c2
  unit=unit|01a05949-936a-72e0-9366-eef45ee0d7bc

=== 5. El operador limpia el dead-letter (no hay otra salida) y repite reconcile ===
  drift: {"rootMarker":false,"multiParent":[],"roleVisibility":0,"pendingRelay":0,"deadRelay":0}
  skipped: {"extra-fact":6}
  clean=false
  [log] marcador de raíz: escritas 0, actualizadas 0, iguales 3, sobran 0, borradas 0
  [log] proyección del catálogo: escritas 0, actualizadas 0, iguales 6, sobran 0, borradas 0
  [log] árbol: escritas 0, actualizadas 0, iguales 3, sobran 0, borradas 0
  [log] hechos: escritas 0, actualizadas 0, iguales 0, sobran 6, borradas 0
  [warning] sin migrar (extra-fact) tuple: role:01a05949-9331-7469-90a7-d0a08418dbd6#role@role_binding:app|01a05949-9331-7469-90a7-d0a08418dbd6
  [warning] sin migrar (extra-fact) tuple: role_binding:app|01a05949-9331-7469-90a7-d0a08418dbd6#binding@scope:app
  [warning] sin migrar (extra-fact) tuple: user:01a05949-936a-72e0-9366-f1afb89861fc#assignee@role_binding:app|01a05949-9331-7469-90a7-d0a08418dbd6
  [warning] sin migrar (extra-fact) tuple: role:01a05949-938d-77da-9220-e1f0add5b572#role@role_binding:unit|01a05949-936a-72e0-9366-eef45ee0d7bc|01a05949-938d-77da-9220-e1f0add5b572
  [warning] sin migrar (extra-fact) tuple: role_binding:unit|01a05949-936a-72e0-9366-eef45ee0d7bc|01a05949-938d-77da-9220-e1f0add5b572#binding@scope:unit|01a05949-936a-72e0-9366-eef45ee0d7bc
  [warning] sin migrar (extra-fact) tuple: user:01a05949-936a-72e0-9366-f6fe3226666d#assignee@role_binding:unit|01a05949-936a-72e0-9366-eef45ee0d7bc|01a05949-938d-77da-9220-e1f0add5b572
  [warning] 6 sin migrar por 'extra-fact'
  authorize(victima, docs:write, unit) FINAL                     facts=true   database=(pendiente) *** FACTS FAIL-OPEN ***

=== 6. Ahora SÍ: la respuesta del driver `database` sobre el MISMO árbol y el MISMO catálogo ===
  filas en authz_assignments: 2
  authorize(victima, docs:write, unit)                           facts=true   database=false  *** FACTS FAIL-OPEN ***
```

Lo que hay que leer: `tree: written 1 … deleted 1` (la mitad que CONCEDE, aplicada),
`facts: extra 6, deleted 0` y `drift.roleVisibility: 0` (la mitad que RETIRA, no aplicada), y la
divergencia final `facts=true` / `database=false`, permanente.

### 🔴 2 — `repro/a2_reconcile_resucita.ts` (HEAD `2507f45`)

```

=== FASE 1 — la era `database`: dos empleados con org-admin; se migra al store ===
  filas en authz_assignments: 2
  migración: escritas 5, iguales 9
  authorize(despedido, docs:write, org) tras migrar              facts=true   database=true   PARIDAD

=== FASE 2 — CUTOVER: el motor sirve desde `facts`. Se despide a uno y se le DENIEGA al otro ===
  (nadie trunca authz_assignments: nada lo pide, y el catálogo vive en las mismas tablas)
  authorize(despedido, docs:write, org)                          facts=false  database=false  PARIDAD
  authorize(empleado,  docs:write, org)                          facts=false  database=false  PARIDAD
  filas que quedaron en authz_assignments: 2
  filas en authz_denies: 0

=== FASE 3 — meses después, `authz:reconcile --to=openfga --dry-run` (el VERIFICADOR de CI) ===
  escribiría 1, borraría 0; clean=false
  skipped: {"extra-fact":1}

=== FASE 4 — el operador «arregla la deriva»: `authz:reconcile --to=openfga` (sin --prune) ===
  escritas 1, borradas 0, sobran 1
  massDelete=false
  authorize(despedido, docs:write, org)  [REVOCADO hace meses]   facts=true   database=false  *** FACTS FAIL-OPEN ***
  authorize(empleado,  docs:write, org)  [DENEGADO hace meses]   facts=false  database=false  PARIDAD

=== FASE 5 — y si además usa --prune (lo que el propio comando sugiere ante `unknown-scope`) ===
  NO se negó: escritas 0, borradas 1, massDelete=false
  authorize(despedido, docs:write, org)  [REVOCADO]              facts=true   database=false  *** FACTS FAIL-OPEN ***
  authorize(empleado,  docs:write, org)  [DENEGADO]              facts=true   database=false  *** FACTS FAIL-OPEN ***
  tuplas de hechos que quedan:
    user:01a05949-969d-70da-8241-2e78e53a084e#assignee@role_binding:organization|01a05949-969d-70da-8241-2aef07a05235|01a05949-969c-706e-98b1-3f1cd0626a80
    user:01a05949-969d-70da-8241-30022933426f#assignee@role_binding:organization|01a05949-969d-70da-8241-2aef07a05235|01a05949-969c-706e-98b1-3f1cd0626a80
```

Lo que hay que leer: la FASE 4 (**sin ninguna bandera**) resucita el grant revocado
(`escritas 1`, `facts=true`) y la FASE 5 (`--prune`, `massDelete=false`: el seguro no salta)
borra el `denied_<P>` vivo y deja a los dos holders concediendo.

## 2 · El arreglo

**Una pregunta nueva, en el sitio donde se puede responder.** `ReconcileSource` lleva desde este
lote `factsOrigin: { name, authzTables }` (`src/types.ts`). Lo decide el **manager**
(`#factsOrigin`, `src/manager.ts`), que es el único que sabe **qué driver está sirviendo**
(`config.default`) y **qué declara cada uno** (`capabilities.hierarchyFacts`); el driver de destino
lo obedece.

Las tres respuestas, en orden:

1. **`--to` es el driver ACTIVO y declara `hierarchyFacts`** ⇒ sus hechos son SUYOS y se leen **de
   él**, por el puerto `enumerateFacts` que ya publicó el lote 3b-3b. Es la pasada de
   **MANTENIMIENTO**: rehace lo derivado (marcador de raíz, proyección del catálogo, árbol) y
   aplica el barrido de visibilidad del invariante 18 con el árbol y el catálogo de HOY, y **no
   escribe ni borra un solo hecho**. Un driver en esa posición que no sepa enumerar sus hechos es
   500 `E_AUTHZ_UNSUPPORTED` nombrando el método: leerle `authz_*` sería justo el defecto.
2. **`--from=<driver>`** ⇒ manda el operador. Si los hechos de ese driver son `authz_*` (el
   `database` del paquete), `--to=openfga` es la MIGRACIÓN de un solo sentido de siempre.
3. **En cualquier otro caso** ⇒ `authz_*`, como hasta ahora.

En el driver (`src/drivers/openfga_driver.ts`) el cambio es una bifurcación y un refactor:
`readSourceFacts` (SQL) y el nuevo `readOriginFacts` (puerto, con la misma disciplina de cursor que
`--to=database`) **comparten** `wantAssignment`/`wantDeny`, que son la única implementación de la
regla —`expired`, `unknown-scope`, `unknown-role`, `unknown-holder-type`, `role-not-visible` y las
tres tuplas de un grant—. Tenerla dos veces era tenerla distinta según de dónde salieran los hechos.

Y **nada de esto es silencioso**: `ReconcileReport.factsFrom` dice de dónde salieron los hechos y
`reconcileLines` lo imprime en la PRIMERA línea, con la receta (`--from=…`) cuando la pasada es de
mantenimiento.

Lo que **no** se ha tocado, a propósito: el seguro `E_AUTHZ_MASS_RECONCILE_REFUSED` sigue siendo el
del origen VACÍO (es lo único que cubría y lo único que sigue cubriendo); la regla de resolución del
origen de 3b-3b (`--from` obligatorio con más de un candidato, 500 sin ninguno) es la misma; y no se
ha añadido ninguna bandera nueva.

## 3 · Los casos

Tres nuevos en `tests/reconcile.spec.ts`, grupo **`3b-5 · la fuente de verdad de los hechos
(servidor real)`** —contra el `:8101` REAL, con la outbox del gate, el árbol SQL del harness y el
driver `database` al lado sobre el MISMO catálogo—, más uno puro sobre `reconcileLines`:

| Caso | Qué fija |
|---|---|
| `🔴 2 — tras el cutover, --to=openfga NO resucita lo revocado ni --prune borra un deny vivo` | la migración documentada (`--from=database`), el cutover, el `--dry-run` **limpio**, y las pasadas con y sin `--prune` sin escribir ni borrar; el `denied_<P>` sigue en el store y el revocado no vuelve |
| `🔴 1 — --to=openfga aplica el barrido de visibilidad del moved que el relay perdió (invariante 18)` | `authz_assignments` VACÍA (la precondición del hallazgo), la entrada aparcada, y tras la pasada `drift.roleVisibility: 1`, `skipped {role-not-visible: 1}`, `facts.deleted 1` SIN `--prune`, `tree.written 1`, idempotencia y **paridad con `database`** |
| `el ORIGEN se dice en el reporte, y --from sigue siendo la migración de un solo sentido` | la regla es observable por los dos lados: sin `--from`, `factsFrom: 'openfga'` y cero hechos escritos; con `--from=database`, `factsFrom: 'database'` y las tablas mandan |
| `3b-5: la primera línea dice DE DÓNDE salieron los hechos…` (puro) | las dos formas de la línea y que un reporte de un driver de terceros sin `factsFrom` no rompe nada |
| `3b-5: el destino ACTIVO cuyos hechos son suyos y no sabe enumerarlos es 500…` (dobles) | la única rama nueva que lanza: 500 `E_AUTHZ_UNSUPPORTED` nombrando `enumerateFacts` **antes** de llamar al destino, en vez de reconstruirlo desde `authz_*` |

### Rojo→verde por pieza

El código ya estaba escrito cuando se añadieron los casos, así que el rojo se provocó con un
**mutante** que restaura exactamente el comportamiento de 3b-3a (leer siempre `authz_*`):

```ts
    const facts = true /* MUTANTE 3b-5: el comportamiento de 3b-3a */
      ? await this.readSourceFacts(catalog, batchSize, now, factsCtx)
      : await this.readOriginFacts(source, batchSize, maxTuples, catalog, now, factsCtx)
```

Salida literal con el mutante puesto (`OPENFGA_TEST_URL=http://localhost:8101 npm test -- --files=reconcile.spec.ts`):

```
❯ 3b-5 · la fuente de verdad de los hechos (servidor real) / 🔴 2 — tras el cutover, `--to=openfga` NO resucita lo revocado ni `--prune` borra un deny vivo
ℹ AssertionError: expected 1 to equal +0            (assert.equal(seco.written, 0))
❯ 3b-5 · la fuente de verdad de los hechos (servidor real) / 🔴 1 — `--to=openfga` aplica el barrido de visibilidad del `moved` que el relay perdió (invariante 18)
ℹ AssertionError: la arista de visibilidad estaba mal y la pasada lo DICE: expected +0 to equal 1
❯ 3b-5 · la fuente de verdad de los hechos (servidor real) / el ORIGEN se dice en el reporte, y `--from` sigue siendo la migración de un solo sentido
ℹ AssertionError: lo que hay en `authz_*` no es un hecho de este despliegue: expected 3 to equal +0

Tests  51 passed, 3 failed (54)
```

Y el **segundo mutante**, complementario, sobre la decisión del manager (`if (false && from === undefined && to === this.#config.default && …)`,
o sea: el destino activo deja de ser su propia fuente), mata los cuatro casos, incluido el del 500:

```
❯ 3b-5 · … / 🔴 2 — tras el cutover, `--to=openfga` NO resucita lo revocado ni `--prune` borra un deny vivo
ℹ AssertionError: los hechos son los del propio driver activo: expected 'authz_assignments/authz_denies' to equal 'openfga'
❯ 3b-5 · … / 🔴 1 — `--to=openfga` aplica el barrido de visibilidad del `moved` que el relay perdió (invariante 18)
ℹ AssertionError: expected 'authz_assignments/authz_denies' to equal 'openfga'
❯ 3b-5 · … / el ORIGEN se dice en el reporte, y `--from` sigue siendo la migración de un solo sentido
ℹ AssertionError: expected 'authz_assignments/authz_denies' to equal 'openfga'
❯ 3b-3b · manager.reconcile: el ORIGEN / 3b-5: el destino ACTIVO cuyos hechos son suyos y no sabe enumerarlos es 500, …
ℹ AssertionError: expected undefined to equal 'E_AUTHZ_UNSUPPORTED'

Tests  52 passed, 4 failed (56)
```

Los dos mutantes retirados ⇒ `Tests  56 passed (56)`. (El caso puro de `reconcileLines` es rojo por
construcción sobre el HEAD anterior: la línea `hechos:` no existía.)

## 4 · La reproducción del auditor, DESPUÉS (sin efecto)

### 🔴 1 — `repro/a1b.ts`

```

=== 1. Un rol LOCAL de orgA, nivel unit, asignado en unit (que cuelga de orgA) ===
  rol local: unit-lead@unit uuid=01a05957-5d9e-769c-8df9-d04a1505c370 owner=organization|01a05957-5d6a-77c5-b7e4-63e4776cf7dc
  authorize(victima, docs:write, unit) con unit BAJO orgA        facts=true   database=(pendiente) *** FACTS FAIL-OPEN ***

=== 2. El consumidor mueve unit a orgB (otro tenant). El relay PIERDE la entrada (aparcada) ===
  outbox: pending=0 dead=1
  authorize(victima, docs:write, unit) con unit BAJO orgB, antes de reconcile facts=true   database=(pendiente) *** FACTS FAIL-OPEN ***

=== 3. `authz:reconcile --to=openfga` — el remedio que documenta el invariante 18 ===
  fases: {"root":{"written":0,"updated":0,"unchanged":3,"extra":0,"deleted":0},"catalog":{"written":0,"updated":0,"unchanged":6,"extra":0,"deleted":0},"tree":{"written":1,"updated":0,"unchanged":2,"extra":1,"deleted":1},"facts":{"written":0,"updated":0,"unchanged":5,"extra":1,"deleted":1}}
  skipped: {"role-not-visible":1}
  drift: {"rootMarker":false,"multiParent":[],"roleVisibility":1,"pendingRelay":0,"deadRelay":1}
  authorize(victima, docs:write, unit) DESPUES de reconcile      facts=false  database=(pendiente) *** DIVERGE ***

=== 4. El árbol del store SÍ se movió (la mitad que concede), la arista de visibilidad NO ===
  role_binding:app|01a05957-5d33-72b9-8606-1ba4d7b43ba9#binding@scope:app
  scope:app#parent@scope:organization|01a05957-5d6a-77c5-b7e4-63e4776cf7dc
  scope:app#parent@scope:organization|01a05957-5d6a-77c5-b7e4-659bd6844e3b
  scope:organization|01a05957-5d6a-77c5-b7e4-659bd6844e3b#parent@scope:unit|01a05957-5d6a-77c5-b7e4-68e1b26dbfc8
  orgA=organization|01a05957-5d6a-77c5-b7e4-63e4776cf7dc
  orgB=organization|01a05957-5d6a-77c5-b7e4-659bd6844e3b
  unit=unit|01a05957-5d6a-77c5-b7e4-68e1b26dbfc8

=== 5. El operador limpia el dead-letter (no hay otra salida) y repite reconcile ===
  drift: {"rootMarker":false,"multiParent":[],"roleVisibility":0,"pendingRelay":0,"deadRelay":0}
  skipped: {"role-not-visible":1}
  clean=false
  [log] hechos: los del propio 'openfga' — es el driver ACTIVO, así que sus hechos son SUYOS y no los de authz_assignments/authz_denies. Esta pasada rehace lo derivado (marcador de raíz, proyección del catálogo, árbol y visibilidad de rol) y no escribe ni borra un solo hecho. Si lo que quieres es MIGRAR desde las tablas, nómbralas: --from=<driver cuyos hechos son authz_*>.
  [log] marcador de raíz: escritas 0, actualizadas 0, iguales 3, sobran 0, borradas 0
  [log] proyección del catálogo: escritas 0, actualizadas 0, iguales 6, sobran 0, borradas 0
  [log] árbol: escritas 0, actualizadas 0, iguales 3, sobran 0, borradas 0
  [log] hechos: escritas 0, actualizadas 0, iguales 5, sobran 0, borradas 0
  [warning] sin migrar (role-not-visible) assignment: user:01a05957-5d6a-77c5-b7e4-71511414f701#assignee@role_binding:unit|01a05957-5d6a-77c5-b7e4-68e1b26dbfc8|01a05957-5d9e-769c-8df9-d04a1505c370
  [warning] 1 sin migrar por 'role-not-visible'
  authorize(victima, docs:write, unit) FINAL                     facts=false  database=(pendiente) *** DIVERGE ***

=== 6. Ahora SÍ: la respuesta del driver `database` sobre el MISMO árbol y el MISMO catálogo ===
  filas en authz_assignments: 2
  authorize(victima, docs:write, unit)                           facts=false  database=false  PARIDAD
```

Ahora la pasada **aplica las dos mitades del `moved`**: el árbol (`tree: written 1, deleted 1`) y la
visibilidad (`facts: extra 1, deleted 1`, `skipped {role-not-visible: 1}`, `drift.roleVisibility: 1`),
`authorize` cae a `false` y el paso 6 cierra en **PARIDAD** con el driver `database`. Y el ruido se
fue: ya no hay 6 `extra-fact`; los 5 hechos vivos salen como `iguales`.

### 🔴 2 — `repro/a2_reconcile_resucita.ts`

```

=== FASE 1 — la era `database`: dos empleados con org-admin; se migra al store ===
  filas en authz_assignments: 2
  migración: escritas 1, iguales 9
  authorize(despedido, docs:write, org) tras migrar              facts=false  database=true   *** DIVERGE ***

=== FASE 2 — CUTOVER: el motor sirve desde `facts`. Se despide a uno y se le DENIEGA al otro ===
  (nadie trunca authz_assignments: nada lo pide, y el catálogo vive en las mismas tablas)
  authorize(despedido, docs:write, org)                          facts=false  database=false  PARIDAD
  authorize(empleado,  docs:write, org)                          facts=false  database=false  PARIDAD
  filas que quedaron en authz_assignments: 2
  filas en authz_denies: 0

=== FASE 3 — meses después, `authz:reconcile --to=openfga --dry-run` (el VERIFICADOR de CI) ===
  escribiría 0, borraría 0; clean=true
  skipped: {}

=== FASE 4 — el operador «arregla la deriva»: `authz:reconcile --to=openfga` (sin --prune) ===
  escritas 0, borradas 0, sobran 0
  massDelete=false
  authorize(despedido, docs:write, org)  [REVOCADO hace meses]   facts=false  database=false  PARIDAD
  authorize(empleado,  docs:write, org)  [DENEGADO hace meses]   facts=false  database=false  PARIDAD

=== FASE 5 — y si además usa --prune (lo que el propio comando sugiere ante `unknown-scope`) ===
  NO se negó: escritas 0, borradas 0, massDelete=false
  authorize(despedido, docs:write, org)  [REVOCADO]              facts=false  database=false  PARIDAD
  authorize(empleado,  docs:write, org)  [DENEGADO]              facts=false  database=false  PARIDAD
  tuplas de hechos que quedan:
    user:01a05957-6026-7349-92fb-e57e1d9fc939#denied_docs_write@scope:organization|01a05957-6026-7349-92fb-de9386572302
```

La FASE 3 (el verificador de CI) sale **`clean=true`** sobre el estado correcto; la FASE 4 escribe
**0** y el `revoke` sigue hecho; la FASE 5 con `--prune` borra **0** y el `denied_docs_write` sigue
en el store. Ninguno de los dos holders concede.

Nota sobre la FASE 1 de ese script: el montaje declara `default: 'openfga'` desde el principio (el
auditor simulaba con un solo manager la era `database` y la posterior), así que la «migración» de la
FASE 1 es hoy una pasada de MANTENIMIENTO y no copia los hechos de `authz_*` — lo dice
`factsFrom`, y la receta es `--from=database`. En un despliegue real la migración se hace mientras
el motor sirve desde el otro driver (`default: 'database'`), que es el escenario del caso
`3b-3a · de punta a punta por el manager`, verde y sin cambios.

## 5 · Cómo queda la documentación

**El invariante 18 NO se reescribe: la frase vuelve a ser verdad.** «`authz:reconcile` la
reconcilia si el relay se perdió» se cumple ahora por la pasada de MANTENIMIENTO, y en `CLAUDE.md`
y en el README se dice **con qué comando** (`--to=<el driver desde el que sirves>`) y **cómo** (lee
los hechos del propio store, recalcula `declaredRoleAt` con el árbol y el catálogo de HOY, borra las
`scope#binding` que la regla prohíbe, escribe las que exige y las cuenta en `drift.roleVisibility`),
más el porqué del defecto anterior, que es lo que impide que vuelva.

- **`CLAUDE.md`**: invariante 18 (la frase, con la mecánica y el defecto que había) y la regla de
  higiene «Todo en un driver o todo en otro» (párrafo nuevo: **de dónde salen los hechos lo decide
  quién es su fuente de verdad**, las tres respuestas, `factsFrom`, y que el seguro de masa sigue
  cubriendo solo el origen vacío).
- **`README.md`**: la sección `authz:reconcile` lleva el bloque nuevo *«Whoever owns the facts is
  where they are read from»* con las tres respuestas y la consecuencia para CI; el ejemplo de
  comandos distingue migración (`--from=database`) de mantenimiento; el párrafo del `--prune` dice
  ahora **qué NO cubre** el seguro (el origen caduco, que era el 🔴 2); la salida de un store de la
  versión anterior nombra `--from=database`; la frase del invariante 18 (README:301) queda
  corregida como arriba; y las dos filas de la tabla de errores
  (`E_AUTHZ_MASS_RECONCILE_REFUSED`, `E_AUTHZ_UNSUPPORTED`) recogen el caso nuevo.
- **`commands/authz_reconcile.ts`**: el docblock del comando explica los dos modos, y la salida los
  distingue en la primera línea. El `--dry-run` limpio ya no dice «coincide con authz_*» sino con
  el origen que se usó.
- **`CHANGELOG.md`**: entrada `Lot 3b-5` en el estilo del 1.1.0 (problema → decisión → qué NO se
  hace y por qué).

## 6 · Verificación

Todo en verde, en los cuatro motores y en el modo «tope 3», con las cifras de partida entre
paréntesis:

| Pasada | Resultado |
|---|---|
| `npx tsc --noEmit -p tsconfig.json` + `npm run typecheck` + `npm run check:purity` + `npm run build` | OK |
| `OPENFGA_TEST_URL=…:8101 npm test` | **765 passed** (760) |
| `OPENFGA_TEST_URL=…:8101 npm run test:sqlite-file` | **767 passed** (762) |
| `TEST_PG_URL=… OPENFGA_TEST_URL=…:8101 npm run test:pg` | **861 passed** (856) |
| `OPENFGA_TEST_URL=…:8101 npm run test:mysql` | **861 passed** (856) |
| «tope 3» (`openfga-tiny`, `:8103`), **primera pasada, a fichero** | **765 passed** |

+5 en cada motor: los 3 casos del grupo `3b-5` (que solo corren con `OPENFGA_TEST_URL`) y los dos
del manager/comando (`reconcileLines` y el 500 del destino activo), que corren siempre.

**Higiene:** `GET :8101/stores` ⇒ `{"stores":[]}` antes y después de cada pasada; el contenedor
`openfga-tiny` se creó para el modo «tope 3» y se borró (`docker rm -f`); ninguna base
`authz_test*` sobreviviente; los scripts de reproducción vivieron en `repro/` del árbol y se
**borraron** al terminar (el árbol solo lleva los 9 ficheros del cambio).

## 7 · Lo que NO se hizo, y por qué

- **🟠 3 · el `freeze()` de proceso**: fuera del encargo, pendiente de la decisión del dueño. No se
  tocó `manager.freeze()`, ni su alcance, ni la frase del README:608 que el auditor desmiente. **No
  bloqueó este lote**: los dos 🔴 se cierran sin tocar la ventana del freeze (la pasada de
  mantenimiento no escribe hechos, así que ni siquiera hay escritura que perder por ahí).
- **🟡 4 · la fila mal formada que tumba la pasada** (`scopeKey` sin `try` en `readSourceFacts`):
  va al plan siguiente. Se comprobó que el camino NUEVO no añade otra instancia del defecto: los
  hechos que llegan por el puerto pasan por `parseBindingId`/`scopeFromKey`, que ya validan con
  `isValidScope`, así que un scope mal formado no puede llegar a `scopeKey` por ahí.
- **🟡 5 · el orden del relay con una entrada aparcada** y **⚪ 6 · el contrato de migración sin un
  solo rol local ni un destino no vacío**: al plan siguiente, sin tocar. El ⚪ 6 es, además, la
  explicación de por qué el 🔴 1 llegó vivo hasta la auditoría final; el grupo `3b-5` cubre ahora
  esa superficie desde el lado del paquete (rol local + destino con estado previo), pero **no**
  desde `MIGRATION_CATALOG`, que es lo que corre un driver de terceros.
- **Ninguna bandera nueva** ni cambio del seguro de masa: el encargo pedía atacar la raíz («quién
  es la fuente de verdad»), no añadir otra salida de escape. El único camino que sigue pudiendo
  sobrescribir los hechos de un store vivo es `--from=<driver cuyos hechos son authz_*>` contra el
  driver activo, que es **explícito**, está documentado como migración de un solo sentido y sale
  nombrado en el reporte.
