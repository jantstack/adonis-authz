# Fase 3b · lote 2h — las tres correcciones del auditor R2 (🔴 2, 🟠 3, 🟠 4)

**Encargo**: arreglar los hallazgos **🔴 2**, **🟠 3** y **🟠 4** de
`.claude/contexto/fase-3b-auditor-r2.md`, cada uno derivado de SU reproducción, con caso en la
suite y demostrado contra el OpenFGA real del `:8101`. **NO se toca el 🔴 1** (`scopes.detached`
de un nodo intermedio como `removeDeny` masivo): es cambio del modelo (c2) y lo está diseñando
otro agente.

**Método**: las siete reproducciones del auditor, copiadas literalmente (solo cambian las rutas de
los `import`, porque viven en el repo principal y no en su copia) en
`.claude/reproducciones/2h/` — carpeta ignorada por git—. Se corren ANTES (rojo) y DESPUÉS (sin
efecto) contra el `:8101` y, la del alias, contra PostgreSQL 18. Cada arreglo tiene además su caso
en `tests/scope_outbox.spec.ts`, y cada caso se ha visto ROJO con un mutante antes de darlo por
bueno. **Cero stores huérfanos** en el `:8101` (`lote-2h*` y `outbox-rollback*`: 0 al terminar) y
ninguna base `authz_test*`/`lote_2h*` viva.

---

## 🔴 2 · Un tapón en la outbox congelaba el árbol de todos los tenants

### ANTES — la reproducción del auditor (`b1_relay_poison.ts`), salida literal

```
relay #2 (con el tapón):
  applied: 1  failed: attached → El scope organization:01a05600-8cfa-70dd-87fd-bc8695ed3527 no existe para el resolutor de
  remaining: true

relay #3 (una pasada más, como haría el cron):
  applied: 0  failed: attached  remaining: true

La unit nueva cuelga de una org con deny explícito para alice:
  authorize(alice, docs:write, unit)                       facts=true  database=false *** FACTS FAIL-OPEN ***
  aristas de la unit en el store: binding→role_binding:unit|01a05600-8d01-…  (ninguna arista parent)

Y tampoco se purga lo que se borra: scopes.detached(unit) queda en la cola
  relay #4 applied: 0  failed: attached
  authorize(alice, docs:write, unit) tras borrarla         facts=true  database=false *** FACTS FAIL-OPEN ***

  cola pendiente: [{"id":3,"op":"attached","attempts":3},{"id":4,"op":"detached","attempts":0},
                   {"id":5,"op":"attached","attempts":0},{"id":6,"op":"detached","attempts":0}]
```

Reproducido tal cual: tres pasadas después, la unit NUEVA de otro cambio no tiene arista `parent`,
el deny de su organization no la alcanza y su `detached` posterior no purga. La ventana no está
acotada por el ciclo del relay: es infinita, y la abre cualquier tenant en dos peticiones.

### El caso

`tests/scope_outbox.spec.ts`, grupos `3b-2h · 🔴 2 — una entrada envenenada ya no congela la cola
de todos` y `3b-2h · 🔴 2 — la cola convergiendo: paginación, aparcado y desbloqueo`, y contra el
servidor real `3b-2h · las reproducciones del auditor R2, contra el servidor real / 🔴 2 · con una
entrada envenenada en la cola, la unit NUEVA recibe su arista y el deny la alcanza`. Seis casos:

1. **EL CASO**: la entrada irreparable falla, APLAZA lo que depende de ella (el `detached` de su
   padre) y el cambio del tenant de al lado SÍ se propaga.
2. la dependencia es **transitiva** (lo que depende de un aplazado también se aplaza).
3. un fallo **NO** contamina a quien no comparte ningún scope con él.
4. `pending(limit, after)` continúa después de un id.
5. una entrada que agota `maxAttempts` sale de `pending()` y aparece en `dead()`, con su causa.
6. aparcada la irreparable, el relay la reporta en **cada** pasada y lo que dependía de ella por
   fin avanza (la cola CONVERGE).
7. (servidor real) la unit nueva recibe su arista `parent` pese al tapón, el deny la alcanza
   (`authorize` = `false`) y su `detached` posterior purga de verdad.

### Rojo con mutante (`break outer` tras `failures.push`, o sea el «para en el primer fallo» de 2d)

```
❯ …/ EL CASO: la entrada irreparable falla, APLAZA lo que depende de ella y el resto de la cola avanza
ℹ AssertionError: el tenant de al lado NO se queda sin propagar por el tapón del otro: expected [ Array(1) ] to deeply equal [ …(2) ]
❯ …/ la dependencia es transitiva: lo que depende de un APLAZADO también se aplaza
ℹ AssertionError: el nieto cuelga del hijo, que quedó sin aplicar: no se adelanta: expected [] to deeply equal [ Array(1) ]
❯ …/ un fallo NO contamina a quien no comparte ningún scope con él
ℹ AssertionError: expected [] to deeply equal [ …(2) ]
❯ …/ aparcada la irreparable, el relay la reporta en cada pasada y lo que dependía de ella por fin avanza
ℹ AssertionError: expected [] to have a length of 1 but got +0
❯ …contra el servidor real / 🔴 2 · con una entrada envenenada en la cola, la unit NUEVA recibe su arista y el deny la alcanza
ℹ AssertionError: y aun así la unit nueva SÍ se propaga: expected [ Array(1) ] to include 'attached 01a05613-4400-…'
Tests  49 passed, 5 failed (54)
```

Y con el mutante que quita el tope de intentos (`pending` sin `where('attempts','<',maxAttempts)`):

```
❯ …/ una entrada que agota `maxAttempts` sale de `pending()` y aparece en `dead()`, con su causa
ℹ AssertionError: agotados los intentos, deja de ofrecerse: expected [ { id: 16, … } ] to deeply equal []
❯ …/ aparcada la irreparable, el relay la reporta en cada pasada y lo que dependía de ella por fin avanza
ℹ AssertionError: la aparcada ya no se reintenta: expected [ { id: 17, … } ] to deeply equal []
```

Y con el que hace que `pending` ignore `after`:

```
❯ …/ `pending(limit, after)` continúa DESPUÉS de un id: sin eso, lo saltado volvería a salir el primero
ℹ AssertionError: expected [ { op: 'detached', …(1) }, …(1) ] to deeply equal [ { op: 'detached', child: { …(2) } } ]
```

### El código

- **`src/manager.ts` · `relayScopeChanges`**: un fallo ya no para la pasada; **contamina las claves
  de scope que el cambio nombra** (`#changeKeys`: hijo, y padre si lo hay). Todo cambio posterior
  que toque una clave contaminada se aplaza sin intentarse y contamina a su vez (transitivo); el
  resto se aplica. **El orden del árbol se conserva** porque dos cambios que pueden interactuar en
  el árbol comparten siempre un nodo: `attached(P, org)` antes que `attached(C, P)`, un `moved`
  antes que el `detached` del mismo nodo. Lo que ya no pasa es que el tenant A congele al tenant B.
  El reporte crece: `failures` (todos), `deferred` (lo no intentado y por qué), `dead` y `busy`;
  `failed` sigue siendo el primer fallo, para no romper a quien lo mira.
- **Paginación**: como una fila puede quedarse pendiente a propósito, la pasada lleva cursor —
  `pending(limit, after?)` en el puerto—. Una outbox que ignore `after` sigue siendo válida: el
  relay detecta que no avanza y termina la pasada (sin dar vueltas y sin el 500 de «no marcas lo
  aplicado», que se conserva intacto para su caso).
- **`src/scope_outbox.ts`**: `maxAttempts` (default 5). Agotados los intentos la fila queda
  **APARCADA**: `pending()` deja de ofrecerla y sale por `dead(limit)` (nuevo método OPCIONAL del
  puerto). Aparcar no es olvidar — el relay la reporta en TODAS las pasadas y el comando sale ≠ 0
  mientras exista— pero es lo que hace que la cola converja en vez de reintentar un imposible para
  siempre.
- **`commands/authz_scopes_relay.ts`**: imprime aplicados, aplazados, fallos y **aparcados** uno a
  uno; exit ≠ 0 si hubo fallos o hay aparcados.

### DESPUÉS — la misma reproducción, sin efecto

```
relay #2 (con el tapón):
  applied: 1  failed: attached → El scope organization:01a0560b-37db-… no existe para el resolutor de
  remaining: true

relay #3 (una pasada más, como haría el cron):
  applied: 1  failed: attached  remaining: true

La unit nueva cuelga de una org con deny explícito para alice:
  authorize(alice, docs:write, unit)                       facts=false database=false PARIDAD
  aristas de la unit en el store: parent→scope:organization|01a0560b-37c0-…, binding→role_binding:unit|…

Y tampoco se purga lo que se borra: scopes.detached(unit) queda en la cola
  relay #4 applied: 1  failed: attached
  authorize(alice, docs:write, unit) tras borrarla         facts=false database=false PARIDAD

  cola pendiente: [{"id":3,"op":"attached","attempts":3},{"id":4,"op":"detached","attempts":0}]
```

Y la convergencia, con la continuación `b2_aparcado.ts` (mismo guion, ocho pasadas):

```
relay #2: aplicó [attached] falló [attached] aplazó [detached] aparcado []
relay #3..#6: aplicó [] falló [attached] aplazó [detached] aparcado []
relay #7: aplicó [detached] falló [] aplazó [] aparcado [attached#3]
relay #8: aplicó [] falló [] aplazó [] aparcado [attached#3]
cola pendiente al final: [{"id":3,"op":"attached","attempts":5}]
```

---

## 🟠 3 · El alias del uuid era fail-OPEN en la escritura

### ANTES — la reproducción del auditor (`c1_alias_fail_open.ts`, `TEST_DB=pg`), salida literal

```
el árbol (PG) funde los dos: chain(alias)[0] = {"type":"unit","uuid":"01a05600-dfc0-7058-8aaa-62b4fbcec4f2"}

1) Antes de borrar nada:
  authorize(alice, docs:write, unit canónica)              facts=true  database=true  PARIDAD
  authorize(alice, docs:write, unit ALIAS)                 facts=false database=true  *** FACTS FAIL-CLOSED ***

2) fila borrada; chain(canónica) = null
   scopes.detached({ unit, uuid: ALIAS }) — ni lanza ni avisa:
   → purgeScope devolvió OK (demostración de cero sobre `scope:unit|<alias>`)

3) Lo que quedó en el store bajo la identidad REAL:
    parent→scope:organization|01a05600-dfc0-… | binding→role_binding:unit|01a05600-dfc0-…
  authorize(alice, docs:write, unit canónica)              facts=true  database=false *** FACTS FAIL-OPEN ***

4) CONTROL — el mismo detached con la forma canónica:
  authorize(alice, docs:write, unit canónica)              facts=false database=false PARIDAD
```

### El caso

`tests/scope_outbox.spec.ts`, grupo `3b-2h · 🟠 3 — el alias del uuid en la ESCRITURA (fila ya
borrada)` (cuatro casos) y, contra el servidor real, `🟠 3 · un `detached` con el uuid SIN guiones
y la fila borrada purga el scope REAL`:

1. **EL CASO**: sin cadena, un `detached` con el uuid SIN guiones purga TAMBIÉN la forma canónica
   (`purgeScope` + `onScopeDetached` por cada ortografía, en orden).
2. con la fila **VIVA** nada cambia: la identidad es la canónica del árbol y se purga UNA vez.
3. un uuid que no es alias de nada sigue siendo UNA purga: **el caso normal no paga**.
4. por la OUTBOX viajan las dos ortografías (la decisión se toma al encolar, que es donde está la
   información).
5. (servidor real) bajo la identidad REAL no queda `parent` ni `binding`, y `authorize` pasa a
   `false` — el control del auditor.

### Rojo con mutante (`scopeSpellings` devolviendo siempre `[scope]`)

```
❯ …/ EL CASO: sin cadena, un `detached` con el uuid SIN guiones purga TAMBIÉN la forma canónica
ℹ AssertionError: expected [ …(2) ] to deeply equal [ …(4) ]
❯ …/ por la OUTBOX viajan las dos ortografías: el relevo no puede canonizar nada
ℹ AssertionError: la decisión se toma donde está la información: al encolar: expected [ '01a05613bed6…' ] to deeply equal [ …(2) ]
❯ …contra el servidor real / 🟠 3 · un `detached` con el uuid SIN guiones y la fila borrada purga el scope REAL
ℹ AssertionError: bajo la identidad REAL no queda ni el `parent` ni el `binding`: expected [ …(2) ] to have a length of +0 but got 2
```

### El código

- **`src/identity.ts` · `scopeSpellings(scope)`** (nuevo): las ortografías de las que el uuid del
  llamante puede ser alias. Hoy exactamente una regla: un uuid de **32 hex sin guiones** también
  nombra su forma canónica `8-4-4-4-12`. Es la única dirección que un motor produce fundiendo
  —PostgreSQL canoniza CON guiones y la collation `*_ci` de MySQL funde mayúsculas, no guiones; el
  alias por mayúsculas ya muere en `assertScope`—, así que **el consumidor que pasa sus uuids como
  los guarda su tabla no paga nada**.
- **`src/manager.ts` · `scopes.detached`**: con cadena, un objetivo (la identidad canónica, como
  hasta ahora). **Sin cadena** —la fila ya borrada, que es el orden soportado desde 3F · S1— los
  objetivos son `scopeSpellings(child)`: se purga y se desengancha cada uno, y por la outbox se
  encolan los dos cambios. **Normalizar en vez de expandir no vale**: sin la fila no hay forma de
  saber cuál de las dos ortografías es la de la tabla, y elegir mal deja los hechos vivos, que es
  justo el fallo que se cierra.

### DESPUÉS — la misma reproducción (PostgreSQL 18), sin efecto

```
2) fila borrada; chain(canónica) = null
   scopes.detached({ unit, uuid: ALIAS }) — ni lanza ni avisa:
3) Lo que quedó en el store bajo la identidad REAL:
    (nada)
  authorize(alice, docs:write, unit canónica)              facts=false database=false PARIDAD
4) CONTROL — el mismo detached con la forma canónica:
  authorize(alice, docs:write, unit canónica)              facts=false database=false PARIDAD
```

---

## 🟠 4 · Dos escritores del árbol: el disparador, medido

El encargo pedía **primero intentar reproducir el disparador** (dos pasadas de relay concurrentes,
porque `pending()` no toma lease y el lote de 100 no se relee) y, si se reproduce, cerrarlo.

### Lo que NO se reprodujo, con lo que medí

**Dos padres por dos pasadas del relay: no se reproduce.** `g1_relay_concurrente.ts` (20 rondas de
`Promise.all([relay(), relay()])` con `attached(C, A)` + `moved(C, B)` encolados) y
`g3_traza.ts` (desfases de 0, 2, 4, 6, 8, 10, 15, 20 y 30 ms, con traza de qué aplicó cada pasada):
**0 nodos con dos padres en ~50 intentos**. La razón está medida: la ventana exige que la pasada
rezagada LEA los padres antes de que la otra escriba y ESCRIBA después de que la otra haya aplicado
el `moved`, y antes de eso la rezagada muere en la primera fila, porque FGA rechaza escribir una
tupla que ya existe.

Lo que sí salió, en **20 de 20** pasadas concurrentes:

```
20 rondas de dos relays concurrentes: 0 con DOS padres, 20 pasada(s) con error
   20× failed:El backend de autorización 'openfga' no respondió (write)
```

Un choque de escrituras saliendo como **503**, contra el invariante 6 («…jamás como un 503, porque
respondió»). Con el «para en el primer fallo» de 2d, ese 503 además marcaba la fila y podía
envenenar la cabecera de la cola: los dos hallazgos se tocan.

### Lo que SÍ se reprodujo del mismo hueco (peor, y silencioso)

`g4_lote_rancio.ts` — dos pasadas del relay ordinarias, la primera lenta (el driver duerme entre
que el relay lee su lote y aplica el primer cambio: es lo que hace un lote de 100 o un servidor
cargado; el paquete no se toca):

```
pasada rápida: attached,moved
  padres tras la pasada rápida: orgB
pasada lenta: {"applied":[{"id":3,"change":{"op":"attached", …
  padres al final: orgA (1)
  el consumidor dice: orgB
  authorize(alice, docs:write, unit ya de B)               facts=false database=true  *** FACTS FAIL-CLOSED ***
  authorize(org-admin de A, docs:write, unit de B)         facts=true  database=false *** FACTS FAIL-OPEN ***
```

El árbol del store queda **REVERTIDO al padre viejo con UN solo padre** —así que `assertOneParent`
no lo delata jamás— y el **tenant antiguo conserva `docs:write` sobre una unit que ya no es suya**.
Es el «segundo efecto» que el auditor sospechaba y tampoco había medido. Con eso, el hueco (sin
lease, lote sin releer) queda demostrado de punta a punta aunque su forma concreta no sea la de los
dos padres.

### Los casos

`tests/scope_outbox.spec.ts`, grupo `3b-2h · 🟠 4 — el relay es escritor ÚNICO (lease de la
outbox)` (tres casos: la segunda pasada simultánea no aplica nada y lo dice; el lease se suelta
aunque la pasada falle; una outbox sin lease se comporta como siempre) y, contra el servidor real,
`🟠 4 · dos `attached` del mismo nodo a la vez: los dos OK, UN padre, y jamás un 503` y
`🟠 4 · un nodo con DOS padres se repara con `scopes.detached` + `attached` (y `moved` lo denuncia)`.

### Rojo con mutantes

```
(manager ignorando `acquire`)
❯ …/ dos pasadas a la vez: la segunda no aplica NADA y lo dice (`busy`)
ℹ AssertionError: la segunda pasada ve el lease tomado: expected false to be true

(reparent sin tratar la carrera)
❯ …contra el servidor real / 🟠 4 · dos `attached` del mismo nodo a la vez: los dos OK, UN padre, y jamás un 503
ℹ AssertionError: el perdedor de la carrera se llevaba un 503 «el backend no respondió»: expected [ 'fulfilled', 'rejected' ] to deeply equal [ 'fulfilled', 'fulfilled' ]
```

Y la salida cruda del choque, antes del arreglo (`h1_reparent_duplicado.ts`, cinco rondas):

```
  ronda 0: ok / 503 E_AUTHZ_BACKEND_UNAVAILABLE | padres: 1
  … (5/5)
```

### El código

- **`ScopeOutbox.acquire?()`** (opcional en el puerto) + `ScopeOutboxLease`: el manager toma el
  lease al empezar la pasada y lo suelta en un `finally`; si otra pasada lo tiene, devuelve
  `busy: true` sin aplicar nada (y el comando lo dice, sin exit ≠ 0: es el diseño, no un error).
  `sqlScopeOutbox.acquire()` usa **cerrojo del servidor**: `pg_try_advisory_xact_lock` en
  PostgreSQL y `GET_LOCK(name, 0)` en MySQL, sobre una transacción que solo sostiene el cerrojo; en
  SQLite —y en cualquier dialecto sin cerrojo de sesión— es un cerrojo de **proceso**, y está
  escrito: SQLite ya serializa sus escrituras y no es el motor de un despliegue con dos réplicas.
- **`openfga_driver.reparent`**: el choque de dos escritores del árbol deja de ser un 503. Se relee
  y se re-aplica (`isTreeWriteRace`: la tupla que se escribe ya está, o la que se borra ya no está
  porque la borró el otro), de modo que el reintento ve la arista del otro y sale por el no-op; una
  contención que no cede en 3 vueltas es **409 `E_AUTHZ_WRITE_CONFLICT`**, como manda el
  invariante 6.

### DESPUÉS — las mismas reproducciones, sin efecto

```
(g1, 10 rondas de dos relays a la vez)
10 rondas de dos relays concurrentes: 0 con DOS padres, 0 pasada(s) con error
  cola pendiente al final: []

(g4, lote rancio)
  padres al final: orgB (1)
  el consumidor dice: orgB
  authorize(alice, docs:write, unit ya de B)               facts=true  database=true  PARIDAD
  authorize(org-admin de A, docs:write, unit de B)         facts=false database=false PARIDAD

(h1, choque de dos `attached`)
  ronda 0..4: ok / ok | padres: 1
```

### La CONSECUENCIA, y una corrección al informe del auditor

Un nodo con dos padres **sigue siendo posible** si dos escritores llaman al driver a la vez con
padres DISTINTOS (FGA no tiene compare-and-set y el `Read` de `reparent` es un check-then-write):
lo que lo impide en el camino soportado es el escritor único. Lo que **no** es cierto es que ese
nodo sea «irreparable con el paquete»: el auditor probó `moved` (500 `E_AUTHZ_SCOPE_TREE_DRIFT`, a
propósito: no se elige por ti) y `driver.purgeScope` (que por contrato no toca la arista), pero
**`scopes.detached` se lleva TODAS las aristas del nodo**, así que sacarlo y volver a colgarlo
repara. Medido (`f2_reparar.ts`) y fijado con un caso contra el servidor real:

```
padres tras la carrera: 2
  authorize(mallory de B, docs:write, unit de A)           facts=true  database=false *** FACTS FAIL-OPEN ***
moved: 500 E_AUTHZ_SCOPE_TREE_DRIFT (la deriva se DENUNCIA, no se elige por ti)
padres tras scopes.detached: 0
padres tras volver a colgarla: 1
  authorize(mallory de B, docs:write, unit de A)           facts=false database=false PARIDAD
```

---

## Las cuatro cifras (y el juez contra `facts`)

| Suite | Antes | Ahora |
|---|---|---|
| `OPENFGA_TEST_URL=… npm test` (SQLite memoria) | 667 | **686** |
| `OPENFGA_TEST_URL=… npm run test:sqlite-file` | 669 | **688** |
| `TEST_PG_URL=… OPENFGA_TEST_URL=… npm run test:pg` | 841 | **860** |
| `OPENFGA_TEST_URL=… npm run test:mysql` | 841 | **860** |

Todas **PASSED**, 0 fallos, 0 `skip`.

`npx tsc --noEmit -p tsconfig.json` ✅ · `npm run typecheck` ✅ · `npm run check:purity` ✅
(«el paquete no depende de ningún proyecto consumidor…») · `npm run build` ✅.

**El juez contra `facts`** (`AUTHZ_CONTRACT_FACTS=1`), sin cambios respecto al punto de partida:
**2 rojos en SQLite** (`353 passed, 2 failed`) y **3 en PG** (`521 passed, 3 failed`), los mismos y
todos de R2 — `authorizeMany` con el resolutor caído no lanza; el nieto de un `detached` sigue
concediendo (🔴 1, que no se toca); y en PG, además, el alias sin guiones en LECTURA
(fail-closed declarado). Ninguno nuevo.

---

## Cómo quedó la frase del README

La del 2d era **falsa** y el auditor lo midió. Se sustituye por tres cosas, todas con caso
(`el ciclo del relay NO acota la ventana de lo que no se puede aplicar, y va escrito`, que además
comprueba que la frase vieja **ya no está** en el README):

> …it is an accepted 🟠 risk of `hierarchy: 'facts'`, and a shorter relay cycle shortens that
> window **only for the changes the queue can actually apply**. A change that fails is not bounded
> by your cycle: it is retried pass after pass, and once it is parked it is never applied at all.
> While it is unapplied that node's tree is frozen in the store — a new scope never inherits its
> denies and a deleted one is never purged — so the window there is as long as it takes you to
> look. The relay tells you, on every pass and in the exit code (`failures`, `deferred`, `dead`);
> nothing else will.

Y en el mismo apartado, sustituyendo al «it **stops at the first failure**»:

> A change that cannot be applied **defers what depends on it and lets the rest through**… Until
> 2.0 the pass stopped at the first failure, and a single change that can never be applied blocked
> every later change of every tenant, indefinitely. `sqlScopeOutbox` also **parks** an entry after
> `maxAttempts` failures (default 5)…
>
> **The relay is a single writer.** …the straggler re-applies an old `attached` after the other
> applied the new `moved`, and the store is left with the **old parent and a single edge, so
> nothing denounces it** — the old tenant keeps access to a subtree that is no longer theirs
> (measured).

`CHANGELOG.md` (lote 3b-2h, con el porqué de cada uno) y `CLAUDE.md` (invariante 17, el párrafo de
la outbox, el mapa de `src/scope_outbox.ts` y el de `commands/`) quedan coherentes con esto.

---

## Lo que NO hice, y por qué

1. **🔴 1** (`scopes.detached` de un nodo intermedio = `removeDeny` masivo del subárbol). Prohibido
   por el encargo: es cambio del modelo (c2) y lo está diseñando otro agente. Sigue rojo en el juez
   de `facts` («el nieto pierde su cadena y con ella todo»), como estaba.
2. **La expansión de ortografías NO se llevó a `revoke`/`removeDeny`.** El mismo mecanismo
   (`canonicalScope` usa la ortografía del llamante cuando no hay cadena) los alcanza, pero lo
   MEDIDO por el auditor es `purgeScope`/`scopes.detached`, que es donde la consecuencia es «el
   scope entero sigue concediendo para siempre». Llevarlo a los otros dos exige devolver una lista
   de scopes desde `canonicalScope` y recorrerla en los dos drivers (seis call-sites), que es un
   diff mayor y sin reproducción que lo dirija. **Queda declarado aquí como pendiente**: un
   `revoke`/`removeDeny` con el uuid sin guiones sobre un scope ya borrado sigue operando sobre la
   ortografía del llamante.
3. **No se tocó `onScopeDetached` para la carrera de escrituras.** El arreglo del choque
   (`isTreeWriteRace`) está solo en `reparent`, que es donde se midió el 503. El `write` de
   `detached` puede chocar igual (borrar una arista que otro acaba de borrar); no tengo
   reproducción y no quise añadir código sin caso.
4. **No se convirtió el lease en obligatorio.** `acquire` es OPCIONAL en el puerto: exigirlo
   rompería a cualquier implementación de terceros y a la propia noción de que el paquete no impone
   tabla. Lo que sí queda escrito, en el puerto, en el comando y en el README: sin lease, el relay
   se corre de una pasada en una.
5. **No se acotó `dead()` con paginación propia.** Se lee con el `batchSize` de la pasada; si un
   despliegue acumula más aparcados que eso, el reporte enseña los primeros. Es un reporte de
   operación, no un inventario, y el exit ≠ 0 no depende de verlos todos.
6. **No se tocó el conteo del juez ni `contract_harness.spec`**: ningún caso nuevo es del contrato
   de drivers (son de la outbox, del manager y del driver openfga), así que los conteos declarados
   (36/49/66/75…) no cambian.

## Dónde está todo

- Reproducciones (ignoradas por git): `.claude/reproducciones/2h/` — `harness.ts`,
  `b1_relay_poison.ts`, `b2_aparcado.ts`, `c1_alias_fail_open.ts`, `f1_dos_padres.ts`,
  `f2_reparar.ts`, `g1_relay_concurrente.ts`, `g2_relay_desfasado.ts`, `g3_traza.ts`,
  `g4_lote_rancio.ts`, `h1_reparent_duplicado.ts`.
- Diff: `CHANGELOG.md`, `CLAUDE.md`, `README.md`, `commands/authz_scopes_relay.ts`,
  `src/drivers/openfga_driver.ts`, `src/identity.ts`, `src/manager.ts`, `src/scope_outbox.ts`,
  `src/types.ts`, `stubs/scopes_outbox_migration.stub`, `tests/scope_outbox.spec.ts`
  (11 ficheros, +1375 / −120). **Sin commits: los hace el dueño.**

---

## Nota del coordinador · un rojo intermitente sin identificar en modo «tope 3»

Al verificar este lote en el modo que el implementador **no** corre (`OPENFGA_LIST_*_MAX_RESULTS=3`, `:8103`), la **primera** pasada dio `685 passed, 1 failed`. **No se capturó qué caso era** (la salida se perdió), y **5 pasadas posteriores dieron 686/686**.

Lo que se sabe: existió un fallo, una vez, en tope 3. Lo que **no** se sabe: cuál, ni por qué.

Hipótesis no confirmada —y no se debe tratar como explicación— es que la primera pasada corrió contra un contenedor recién arrancado (`sleep 6`), y este lote añade casos de concurrencia y lease que dependen de tiempos.

**Qué hacer con esto, en orden:**
1. En la próxima tanda, correr tope 3 **con la salida redirigida a fichero desde la primera pasada** (`npm test > log 2>&1`), para no volver a perder la evidencia.
2. Dar al contenedor más margen antes de la primera pasada.
3. Si reaparece: es un flake real en un paquete cuya suite es su garantía, y **se persigue antes de cerrar la fase**, no después.

Se anota aquí en vez de darlo por bueno: la regla del proyecto es que un caso que no se entiende no está verde, está sin mirar.
