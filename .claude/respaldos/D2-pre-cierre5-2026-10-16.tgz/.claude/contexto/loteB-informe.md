# Lote B (plan 2.5) — informe del implementador (2026-10-15) ⇒ `2.5.0-alpha.2`

**Árbol `main` sobre `beb1d0a`** (= `v2.5.0-alpha.1`). Único agente que muta el árbol; **sin commit, sin tocar `version`,
sin `git push`** (los hace el coordinador). Entorno medido: Node 22.23.2 (`nvm use 22`), `postgres18`, `mysql84`, OpenFGA
**`:8090`** (`openfga-dev`, `docker restart openfga-dev && sleep 8` antes de cada suite; `:8101` no responde). Método por
pieza: rojo observado → verde → mutante aplicado y revertido (o por el corredor) → gemelos → cuatro líneas de cierre (B1–B4).
Toda salida nueva dice qué rama corrió (B5). Las piezas son las nueve del juez (`panel-tenencia-2-juez.md` §1) con las
exigencias del brief (`loteB-coordinador.md`).

## 0 · Rojos observados ANTES de cada pieza (el método)

| Pieza | Rojo observado |
|---|---|
| B1 | Casos escritos primero en `tests/relations.spec.ts` («lote B · B1»): **4 rojos** (directo `a ⊇ a` —hoy un 422 distinto sin la cadena—, de 2, de 3 y el control con ciclo en el segundo tipo) sobre el `src/` de alpha.1. |
| B2 | Casos escritos primero («lote B · B2»): **3 rojos** (raíz `denny`/`deny`, `objectTypes[1].deny`, `relations[1].denny`/`database.foo`): hoy entran y se tiran (lo que midió H3). Gemelo roles (`tests/manager.spec.ts` «B2 (gemelo roles)»): **2 rojos** («la clave desconocida entró en silencio» en la raíz y en `scopes.resolveChainz`): `defineConfig` era la identidad. |
| B3 | Los cuatro mutantes de B3 SON el código de alpha.1 (cada capa con `assertRelationDeclared` a secas sobre el userset): aplicados por el corredor ⇒ **6 rojos por capa** (las celdas f05 con sujeto: relate/unrelate/check/checkMany/listObjects/purgeSubject) en manager, database, openfga y doble. Es el rojo de la variante nueva `usersetUnsupported` sobre el código viejo. |
| B4 | Caso escrito primero en `tests/relations_openfga.spec.ts` («lote B · B4», sin servidor, reloj monótono inyectado): **2 rojos** (`DEFAULT_LIST_OBJECTS_DEADLINE_MS` no existe; `listObjectsDeadlineMs: 0` no es 500). Con el envoltorio escrito, los 3 mutantes de la columna `truncation` (tope apagado, deadline apagado, «página vacía = fin») ⇒ 1 / 1 / 5 rojos. |
| B5 | Tabla de verdad por el kernel (`tests/command_flags.spec.ts` «lote B · B5») escrita primero: **rojo** en la fila `leída × dry-run` («la línea de la rama» no existía) — y las filas `lanza` daban exit 0 con 1 escritura en real (el `.catch(() => undefined)`). |
| B6 | Flip del default a `true` SIN tocar harnesses, en `:memory:`: **56/148 rojos** en `scope_outbox.spec`, **16/51** en `scope_outbox_contract.spec` (el harness de `sqlScopeOutbox`), **4/49** en `command_flags.spec`, **1/67** en `reconcile.spec`; `manager`/`freeze`/`commands`/`scope_outbox_harness` sin rojos (dobles). **Esa es la medida**: 77 casos de arnés encolaban sin transacción (ninguno es consumidor). |
| B7 | Caso escrito primero («lote B · B7»): **rojo** («sin subpath ./relations/reconcile en package.json exports»). Tras el movimiento, además: G-0·exports rojo por `RelationConfigUnknownKeyError` sin clasificar (B2) ⇒ clasificada. |
| B8 | Caso escrito primero en `tests/reconcile.spec.ts` (servidor real, «B8»): **rojo** en la dirección (i): `{"permission-not-in-model":1}` leyendo el ÚLTIMO modelo con el fijado que sí tiene `docs:write`. (La dirección (ii) salió verde tras una corrección del propio caso: `bea` tenía `docs:read` DENEGADO por la siembra; se afirma sobre `ana`/`org`.) |
| B9 | Letra: `grep republishFusedModel` = 3 (README:682, `src/relations_config_store.ts:18`, y la cabecera `(2.5)` de README:377) ⇒ 0 tras el cambio. |

## 1 · Piezas entregadas (ficheros, casos, mutantes)

### B1 · ciclos de `includes` ⇒ 422 nombrando el ciclo
- `src/relations/define_relations_config.ts`: `findIncludesCycle(relations)` (DFS con pila de colores sobre `relation → includes`
  del tipo; devuelve el ciclo NOMBRADO desde el nodo que lo cierra) y el 422 `E_AUTHZ_RELATION_CONFIG` con la cadena
  `type#a → type#b → type#a` y el porqué (OpenFGA rechaza cualquier ciclo al publicar; `database` lo serviría: paridad). El
  antiguo «se incluye a sí misma» es ahora el ciclo de longitud 1 del mismo recorrido.
- Casos: `tests/relations.spec.ts` «lote B · B1» ×4 (directo, de 2 —el medido por el tester—, de 3 que arranca en una relación sin
  ciclo —la cadena nombrada es el ciclo, no el camino—, diamante entra + ciclo en el segundo tipo nombra ese tipo).
- Mutante (aplicado/revertido): `if (false && cycle)` ⇒ 4 rojos.

### B2 · claves desconocidas ⇒ 422 (y el gemelo en roles ⇒ 500)
- `src/relations/define_relations_config.ts`: `RELATIONS_SPEC_KEYS` (lista blanca por nivel: raíz / `objectTypes[i]` /
  `relations[j]` / `database`), `assertKnownKeys(value, known, path)` ⇒ `RelationConfigUnknownKeyError` (422
  **`E_AUTHZ_RELATION_CONFIG_UNKNOWN_KEY`**, subclase de `RelationConfigError`; `src/errors.ts`, exportada desde la raíz,
  clasificada en `NON_SURFACE_FUNCTIONS`) nombrando la ruta y la lista. Se aplica ANTES de leer nada de cada nivel; `membersOf`
  en la raíz conserva su 422 propio (corre antes).
- Gemelo roles: `src/define_config.ts` `AUTHORIZATION_CONFIG_KEYS` (raíz + `openfga`/`scopes`/`relations`/`hooks`) y
  `assertKnownConfigKeys` ⇒ 500 `E_AUTHZ_CONFIG` nombrando la ruta; `defineConfig` devuelve la MISMA referencia. El stub
  `stubs/config/authorization.stub` usa solo claves de la lista (comprobado: `default/openfga/scopes/drivers/catalogs/
  delegablePermissions/relations/hooks`; `relations.config/default/onRelationWrite/drivers`).
- Casos: `tests/relations.spec.ts` «lote B · B2» ×4; `tests/manager.spec.ts` «B2 (gemelo roles)» ×2 (raíz + cuatro bloques,
  y el control con TODAS las claves conocidas).
- Mutantes: `assertKnownKeys` inerte (`return` inmediato) ⇒ 3 rojos; en roles, quitar las dos llamadas (raíz y `scopes`) ⇒ 2 rojos.

### B3 · userset ≠ `group#member` ⇒ 422 en manager + 2 drivers + doble
- `src/relations/define_relations_config.ts`: `RELATION_USERSET_TYPE`/`RELATION_USERSET_RELATION` y
  **`assertUsersetSubject(config, subject)`** = F-05 del par (la estricta) + «solo `group#member`» ⇒
  `RelationUsersetUnsupportedError` (422 **`E_AUTHZ_RELATION_USERSET_UNSUPPORTED`**, `src/errors.ts`; **subclase de
  `RelationUnknownError`** para que `relateOrSkip` del reconcile la cuente en `skipped.undeclared` en vez de reventar).
- Punto de paso único llamado en las cuatro capas: `RelationsManager.#assertSubject`, `DatabaseRelationsDriver.#subjectColumns`,
  `OpenFgaRelationsDriver.#subjectUser`, `makeRelationsDriver.assertSubjectDeclared` ⇒ cubre `relate`/`unrelate`/`check`/
  `checkMany`/`listObjects`/`purgeSubject` (toda operación con sujeto), ANTES del backend (cero INSERT / cero Write-Read-Check).
- Guardia (decisión escrita: **se integra en F-05**, no columna nueva): variante `usersetUnsupported` (`{ object: DOC, relation:
  'viewer' }`: declarado, no `group#member`) en `F05_VARIANTS` de las seis operaciones con sujeto; `INVOKE.purgeSubject` la
  construye; **4 mutantes nuevos** (`manager.userset.B3`, `database.userset.B3`, `openfga.userset.B3`, `double.userset.B3`: cada
  capa vuelve al F-05 a secas ⇒ 6 celdas rojas por capa). Los dos mutantes existentes de `purgeSubject.f05` (database/openfga)
  reapuntados a la línea nueva (sus `find` ya no casaban: G-M lo dijo).
- Gemelo reconcile: `tests/relations_reconcile.spec.ts` «B3»: una tupla del ORIGEN con sujeto `document#viewer` ⇒ el destino
  (`database` real) dice 422 ⇒ `skipped.undeclared = 1`, la pasada sigue, cero filas con ese sujeto, lo declarado migra.
- Las suites de relaciones (`relations`, `relations_contract` ×6 harnesses, `relations_database`, `relations_reconcile`)
  siguen verdes: ningún caso existente usaba un userset ≠ `group#member` como sujeto legítimo.

### B4 · `truncated` por deadline + letra + columna `truncation` en la guardia (M8)
- `src/drivers/openfga_relations_driver.ts`: `DEFAULT_LIST_OBJECTS_DEADLINE_MS = 3_000` y `LIST_OBJECTS_DEADLINE_RATIO = 0.9`
  (exportadas; re-exportadas desde `src/openfga.ts`); opciones `listObjectsDeadlineMs` (entero > 0, 500 si no) y `monotonic`
  (SOLO TESTS, fuente del reloj monótono, default `performance.now`; función o 500); **punto de paso ÚNICO `#listObjectsPage`**:
  mide la llamada con el reloj monótono y `truncated = raw.length >= tope || elapsed >= 0,9 × deadline` (la misma señal para
  las dos causas; conservadora a propósito). `#readAll` documentado como el envoltorio de `Read`: exhaustivo o 503 (sin
  `tuples`, token repetido, > 10 000 páginas). `withClock` hereda deadline y reloj (`...this.#options`).
- `src/types.ts`: docblock de `listObjectsTruncation` = «tope O deadline» (sin capacidad nueva, ver §4).
- Guardia: **columna nueva `truncation`** en `tests/fixtures/guard_manifest.ts` (`GuardColumn`, `GUARD_COLUMNS`, razones `na`
  nuevas `passthrough` —manager, lecturas— y `exhaustive` —database—, `double` ampliada; reglas en `NA_MATRIX`; filas via
  `fgaTruncation(op)`), sonda en `tests/guard_surface.spec.ts` para las SEIS operaciones de `openfga` que enumeran:
  `listObjects` con tres caras (tope 2 de 2 ⇒ truncado; deadline 900 de 1000 ms con el reloj inyectado ⇒ truncado; control 1 de
  2 y 899 ms ⇒ sin señal falsa) y `listSubjects`/`enumerateRelations`/`enumerateRelationsMany`/`purgeObject`/`purgeSubject` con un
  `Read` que no puede ser exhaustivo (página vacía con token que no avanza; respuesta sin `tuples`) ⇒ 503 y cero `deleteTuples`/
  `write`. `fakeFgaClient` gana `respond`/`during` (respuesta scriptada; avanzar el reloj DURANTE la llamada).
  **3 mutantes**: `openfga.listObjects.truncation.cap`, `openfga.listObjects.truncation.deadline`, `openfga.readAll.truncation`
  («página vacía o sin tuples = fin»: 5 celdas rojas). G-M exige mutante por celda nueva: 171 casos en la guardia.
- Caso con reloj inyectado fuera de la guardia: `tests/relations_openfga.spec.ts` «lote B · B4» ×2 (corre en los 4 modos sin
  servidor): 2 700 de 3 000 ⇒ truncado, 2 699 ⇒ no; deadline configurado 1 000 ⇒ 900 sí / 899 no, también en la vista
  `withClock`; el tope sigue siendo la otra causa; validación de opciones.
- Letra: README (bloque de relaciones: las dos causas, la promesa anterior era falsa para el deadline, `Read` exhaustivo o 503)
  + fila nueva en «Limits» atada a las constantes en `tests/scope_depth.spec.ts` (y `notInclude('never a mute partial list')`).

### B5 · `toConfig` del reconcile: fallo de lectura = error
- `commands/authz_relations_reconcile.ts`: `try { toConfig = await readRelationsConfig() } catch ⇒ logger.error(...) + exit 1 +
  return` ANTES de `runRelationsReconcile` (nada construido, congelado ni escrito); `null` ⇒ línea «ninguna persistida … la
  deriva del modelo NO se vigila»; leída ⇒ «leída de authz_relations_config (N tipo(s)): la deriva del modelo se vigila».
- Caso: `tests/command_flags.spec.ts` «lote B · B5» — tabla de verdad §3 por el kernel de ace (`withTableMissing` para «lanza»,
  `saveRelationsConfig` para «leída»), con dobles de drivers que cuentan escrituras.
- Mutante: `readRelationsConfig().catch(() => null)` dentro del try ⇒ rojo (la fila `lanza` sale como «ninguna persistida»).

### B6 · `requireTransaction` por defecto `true` + `ctx()` del contrato con trx
- `src/scope_outbox.ts`: default `true`; docblock y letra de los dos 500 (nombra el opt-out `requireTransaction: false`).
- `src/testing/scope_outbox_contract.ts`: capacidad **`requiresTransaction?: boolean`** (D15: `?:`, ausente ⇒ `false`;
  `OPTIONAL_SCOPE_OUTBOX_CAPABILITY_KEYS`; con `true` exige `transactions.begin` al registrar); `viaTransaction(fn)` abre
  `begin()`, encola/notifica y confirma; `enqueue(outbox, change, actor?)` sustituye a `outbox.enqueue(change, ctx())` en TODO
  el contrato y `scopes.attached/moved/detached(manager, …)` sustituye a `manager.scopes.*` (todo encolado del juez lleva la
  trx cuando el harness la declara); **par nuevo** `requiresTransaction` (true: sin trx ⇒ 500 nombrando `requireTransaction`,
  cero filas, por la outbox sola Y por `scopes.*` con el driver intacto; con la trx entra · false: sin trx entra por las dos vías);
  la cara `transactionalEnqueue:false` encola con el helper (ignora la trx). El doble `makeScopeOutbox` honra la capacidad
  (500 con la misma letra).
- `tests/scope_outbox_contract.spec.ts`: el harness SQL corre con el **default** y declara `requiresTransaction: true` en
  `sqlite-file`/pg/mysql; en `:memory:` (pool 1) construye con `requireTransaction: false` y declara `false` (razón escrita:
  `{ transaction }` por el manager exige pool ≥ 2 — la barrera del freeze lee por otra conexión; verificado: el caso de
  `scope_outbox.spec` que pasa trx por el manager ya estaba gateado a pool ≥ 2); el doble FULL declara `true` con un `begin()`
  de mentira (la cara true corre también en `:memory:`); MINIMAL `false`. `scope_outbox_harness.spec`: `EXPECTED_CASES` 17 → **18**,
  `CAPABILITY_KEYS` 8 → **9**, y el caso «ausente (D15) ⇒ false, mismo total; `true` sin `begin` se rechaza».
- Arneses que encolan sin trx a propósito, ahora con el opt-out EXPLÍCITO y comentario: `tests/scope_outbox.spec.ts` (todas las
  `sqlScopeOutbox(…)` salvo las del grupo `alpha.8 · T`, que juzgan la opción), `command_flags.spec` ×4, `reconcile.spec` ×4,
  `scope_depth.spec` ×1, `scope_outbox_multiprocess.spec` ×1, `helpers/relay_child.ts` ×1. **El hijo del runbook
  (`helpers/cutover_child.ts`) encola DENTRO de `db.transaction()`** como la receta del README (es un consumidor; pg/sqlite-file
  tienen pool ≥ 2).
- Caso del default: `scope_outbox.spec` «B6 (2.5.0) · el DEFAULT es `true`» (`sqlScopeOutbox()` y `sqlScopeOutbox({})` ⇒ 500
  nombrando `requireTransaction` y el opt-out, cero filas; con trx entra; opt-out explícito entra sin trx) + caso de letra
  (README «The default is **`true` since 2.5.0**», `requireTransaction: false`, `requiresTransaction`; CHANGELOG Unreleased).
- Mutante «default `false`»: rojo el caso del default en `:memory:` (2/148) **y** rojo `requiresTransaction:true` del harness SQL
  en `sqlite-file` (1/54). Las dos corridas medidas y revertidas.

### B7 · `runRelationsReconcile` en `./relations/reconcile`
- Nuevo `src/relations_reconcile.ts` (raíz de `src/`, como `relations_config_store.ts`: la regla 2 de pureza prohíbe que
  `src/relations/` importe el manager ni con `import type`): la función y `RunRelationsReconcileOptions`, movidas del comando
  tal cual (import dinámico de `./relations/reconcile.js`). `package.json` `exports['./relations/reconcile']`. El comando la
  importa de ahí y **ya no la exporta** (ni el tipo). `index.ts` (comentario), README (ruta) actualizados.
- Casos: `tests/command_flags.spec.ts` «lote B · B7» (subpath existe; el módulo exporta la función y SOLO eso como valor; sus
  imports no tocan `@adonisjs/core/ace` ni `commands/`; el módulo del comando no exporta la función ni el tipo —por import y por
  fuente—; `./commands/*` sigue sirviendo la clase). Guardias ajustadas con razón: C5 «solo X importa el VALOR del primitivo»
  ⇒ `src/relations_reconcile.ts` + el harness (el comando importa la función, no el primitivo); R1 sigue encontrando
  `runRelationsReconcile` recorriendo `exports` (ahora por el subpath nuevo); C7.2 de `reconcile.spec` lee el fichero nuevo.
  Imports de tests (`freeze.spec` ×3, `command_flags.spec` ×6) cambiados a la ruta nueva.
- Mutante: no aplica como «quitar una guarda» (es un movimiento); el caso B7 es rojo si la función vuelve a salir del comando
  o si el subpath desaparece (los dos observados: rojo inicial y G-0·exports).

### B8 · el verificador lee el modelo FIJADO
- `src/drivers/openfga_driver.ts`: campo `modelId`; `modelPermissions()` = `this.modelId ? client.readAuthorizationModel()
  (usa el id configurado en el cliente, el mismo de cada Write/Check) : readLatestAuthorizationModel()`.
- Caso: `tests/reconcile.spec.ts` «B8» (servidor real; las dos direcciones: fijado con `docs:write` + último sin él ⇒ 0
  `permission-not-in-model` y `authorize(bea, docs:write, unit)` true; fijado sin + último con ⇒ no revienta, se cuenta ≥ 1 y lo
  que el fijado declara concede).
- Mutante: siempre el último ⇒ rojo (dirección i). Aplicado y revertido.

### B9 · letra
- README: cabecera `resourceAccess (2.4.0-alpha.1)` (es la versión en la que salió, CHANGELOG 2.4.0-alpha.1 resumen); párrafo de la
  config persistida reescrito (sin `republishFusedModel` ni CAS: `openfga:provision` publica desde el config estático; el único
  lector de la persistida es `authz:relations:reconcile`, B5); `src/relations_config_store.ts` comentario sin el nombre;
  `CLAUDE.md` punto 10 = «Criterio de `2.5.0` estable (…; no hay `2.4.0` estable, decisión del dueño 2026-10-14)» en una frase.
  `grep -rn republishFusedModel README.md CLAUDE.md src/` ⇒ **0**.

### Letra transversal
- `CHANGELOG.md` `## [Unreleased] — plan 2.5 · lot B`: una entrada por ruptura (problema → decisión → qué NO se hace) B1–B9.
- README «Upgrading to 2.5.0»: puntos 4–11 (B1–B8, qué se rompe y cómo se adapta; B3 con el detector/borrado SQL de las filas
  viejas; B6 con el opt-out y el pool; B7 con la ruta).
- `CLAUDE.md`: cabecera (lote B, `2.5.0-alpha.2`), punto 10, cifra de mutantes (111).

## 2 · Cuatro líneas de cierre (punto 5)

**B1**
- (a) *Gemelos*: roles ↔ relaciones: el catálogo de roles no tiene `includes` (los vínculos rol→permiso son planos; la
  jerarquía es de scopes y su anti-ciclos ya existe en `scopes.attached/moved` y en `hierarchicalScopeResolver` 422
  `E_AUTHZ_SCOPE_CYCLE`) ⇒ **no aplica**. Comando ↔ manager ↔ función: `openfga:provision` y `saveRelationsConfig` pasan por
  `defineRelationsConfig` ⇒ el mismo 422 (caso de `relations_persisted_config.spec` «config INVÁLIDA no ensucia la tabla» sigue).
  database ↔ openfga: es config, el 422 vale antes de que exista driver ⇒ paridad por construcción.
- (b) *Tabla de verdad*: no aplica (una sola entrada discreta: el grafo; los cuatro casos cubren longitud 1/2/3, diamante y
  segundo tipo).
- (c) *Casos existentes puestos rojos*: ninguno (el antiguo «se incluye a sí misma» no tenía caso; su 422 sigue siendo
  `E_AUTHZ_RELATION_CONFIG`).
- (d) *Linaje*: no es iteración de ninguno de `linajes.md`.

**B2**
- (a) *Gemelos*: roles: `defineConfig` tenía el MISMO agujero (identidad) ⇒ **caso + arreglo** (500 por familia). Comando ↔
  manager: `saveRelationsConfig`/`readRelationsConfig` pasan por `defineRelationsConfig` ⇒ una config persistida con clave
  desconocida (escrita a mano) ya no se lee en silencio: es 422 al leer (y B5 convierte ese fallo en exit 1 del comando).
- (b) *Tabla de verdad* nivel × clave: raíz / `objectTypes[i]` / `relations[j]` / `database` × {conocida, desconocida} — las
  cuatro filas «desconocida» ⇒ 422 con la ruta (casos), las cuatro «conocida» ⇒ entra (control con TODAS las claves).
- (c) *Casos existentes rojos*: ninguno.
- (d) *Linaje*: **L5, 5.ª iteración ⇒ estructural**: propiedad universal «ninguna clave de una spec de config se descarta»,
  punto de paso único `assertKnownKeys`/`assertKnownConfigKeys` con lista blanca explícita por nivel (y el gemelo). **Entrada en
  la guardia**: no hay guardia de superficie de CONFIG (la de L1 es de operaciones); lo que exige el linaje queda cubierto por
  la lista blanca única + caso por nivel; añadir una guardia por reflexión sobre los tipos de config queda en §6.

**B3**
- (a) *Gemelos*: roles: el sujeto de roles es `SubjectRef` (holder) y no admite usersets ⇒ **no aplica** (`assertSubject`
  ya rechaza objetos que no son `{type, uuid}`). database ↔ openfga ↔ doble: la MISMA función en las tres (+ manager).
  Reconcile: caso «B3» (`skipped.undeclared`, sin throw). `listSubjects`: devuelve lo almacenado (salida, no entrada):
  tabla §3.
- (b) *Tabla de verdad* (§3, lecturas): check/checkMany/listObjects × {holder, `group#member`, otro userset} × {manager,
  database, openfga}.
- (c) *Casos existentes rojos*: G-M (dos mutantes `purgeSubject.f05` cuyo `find` dejó de casar: reapuntados); ningún caso de
  comportamiento.
- (d) *Linaje*: es L1 (F-05: «nadie toca…») en su 6.ª iteración —la grammar del sujeto— y por eso NO se parchea: entra como
  variante de F-05 en la guardia de superficie con mutante por capa (lo que L1 ya exige), y la función es única.

**B4**
- (a) *Gemelos*: roles: el driver de roles NO usa `ListObjects` (sus `list*` van por `Read` paginado, README «Enumerations read
  tuples»): no aplica el deadline; su `Read` es el mismo patrón exhaustivo-o-500. database: `listObjects` es un `SELECT` sin
  LIMIT (exhaustivo o lanza) ⇒ `na: exhaustive` con sonda nula declarada. Doble: simula el tope del contrato ⇒ `na: double`.
  `listSubjects`/`enumerateRelations(Many)`/purgas de openfga: `#readAll`, sondeadas (503, nunca página corta).
- (b) *Tabla de verdad* `tope × deadline` (ejecutada en la sonda y en el caso): {≥ tope, < tope} × {≥ 0,9×, < 0,9×} ⇒
  `truncated: true` salvo (< tope, < 0,9×).
- (c) *Casos existentes rojos*: `scope_depth.spec` «Limits» ampliado (fila nueva + `notInclude` de la frase vieja): no rojo, se
  amplió; G-M nace con 6 celdas nuevas que exigen mutante (cubiertas).
- (d) *Linaje*: **L8, 5.ª iteración y primera [N] ⇒ M8 activado**: propiedad universal «toda enumeración que se puede cortar
  devuelve `truncated` o lanza», punto de paso único = el envoltorio de cada API de lista (`#listObjectsPage` / `#readAll`),
  **entrada en la guardia de superficie: columna `truncation`** con 3 mutantes. `linajes.md` NO se ha tocado (fuera de git; el
  coordinador/dueño registra la iteración; propuesta de texto en §4).

## 3 · Tablas de verdad

**B3 · lecturas** (manager / database / openfga; sujeto × operación):

| sujeto | `check` / `checkMany` | `listObjects` | `listSubjects` (salida) | `purgeSubject` |
|---|---|---|---|---|
| holder `user:U` | responde | responde | lo lista si lo tiene | purga |
| `group:G#member` | responde (F-05 del par: `group#member` declarado built-in) | responde | lo lista | purga |
| userset declarado ≠ group#member (`document:D#viewer`) | **422 `E_AUTHZ_RELATION_USERSET_UNSUPPORTED`** en las tres capas, cero llamadas | **422** ídem | lo lista SI una fila pre-2.5 lo tiene (salida; receta SQL en README) | **422** (la fila vieja se quita por `purgeObject` o a mano) |
| userset de tipo no declarado (`role_binding:R#assignee`) | 422 `E_AUTHZ_RELATION_TYPE_UNKNOWN` (F-05, como hasta hoy) | ídem | — | ídem |
| hoy (alpha.1), fila 3 | database: fila/consulta INERTE (responde `false`); openfga: 400 del servidor ⇒ **503 mal clasificado** | ídem | ídem | database borraba la fila; openfga 400 ⇒ 503 |

**B5 · `toConfig` × modo** (ejecutada por el kernel; exit / escrituras en el destino / línea):

| config persistida | dry-run | real |
|---|---|---|
| leída | exit 1 (deriva: haría 1 escritura) · 0 escrituras · «leída de authz_relations_config (1 tipo(s)): la deriva del modelo se vigila» | exit 0 · 1 escritura · la misma línea |
| `null` (no hay) | exit 1 · 0 · «ninguna persistida en authz_relations_config … la deriva del modelo NO se vigila» | exit 0 · 1 · la misma línea |
| lanza (tabla ausente) | **exit 1 · 0 · «No se pudo leer la config de relaciones persistida … NO es «no hay config» … No se ha construido, congelado ni escrito nada»** | **exit 1 · 0 · ídem** (hoy: exit 0 y 1 escritura) |

**B6 · `requireTransaction` × `{ transaction }` × vía** (contrato + `scope_outbox.spec`):

| opción | contexto | `outbox.enqueue` | `manager.scopes.*` |
|---|---|---|---|
| default (`true`) | sin trx | 500 `E_AUTHZ_CONFIG` nombra `requireTransaction` y el opt-out; 0 filas | 500 ídem; 0 filas; driver sin tocar |
| default (`true`) | trx abierta de la conexión | encola | encola (`{ queued }`) — exige pool ≥ 2 (barrera del freeze por otra conexión) |
| default (`true`) | trx ajena / cerrada / `db` | 500 `E_AUTHZ_CONFIG` (`assertCallerTransaction`, como hasta hoy) | ídem |
| `false` (opt-out explícito) | sin trx | encola | encola |
| no booleano | — | 500 al construir | — |

## 4 · Decisiones del implementador que el coordinador debe ratificar

1. **B2 · código propio** `E_AUTHZ_RELATION_CONFIG_UNKNOWN_KEY` como SUBCLASE de `RelationConfigError` (misma familia y status;
   `instanceof RelationConfigError` sigue siendo verdad). Alternativa descartada: reutilizar `E_AUTHZ_RELATION_CONFIG` a secas
   (S18 del tester pide distinguir «clave desconocida»; el llamante lo necesita para un typo vs una forma inválida).
2. **B2 · gemelo roles con 500 `E_AUTHZ_CONFIG`** (no 422): la familia de config de roles siempre fue 500. Y `defineConfig`
   valida SOLO claves por nivel (raíz + 4 bloques), no `drivers`/`catalogs` (mapas abiertos del consumidor) ni valores.
   Alternativa descartada: no tocar roles («no aplica») — era falso: la identidad tiene el mismo agujero.
3. **B3 · integrado en F-05, no columna nueva**: la función `assertUsersetSubject` es la gramática del sujeto («qué sujetos
   existen»), la MISMA frontera de L1; entra como variante de F-05 con mutante por capa. Alternativa descartada: columna
   `userset` en la guardia (duplicaría la sonda de F-05 con otro nombre y abriría una matriz `na` nueva sin razón).
4. **B3 · `RelationUsersetUnsupportedError` extiende `RelationUnknownError`** para que `relateOrSkip` del reconcile la cuente en
   `skipped.undeclared` (una fila inerte pre-2.5 enumerada por `database` no revienta la migración). Alternativa descartada:
   clase independiente + catch nuevo en `relateOrSkip` (más superficie para el mismo efecto).
5. **B3 · residuo declarado**: filas pre-2.5 con userset ≠ `group#member` quedan listables por `listSubjects` y NO purgables por
   `purgeSubject(userset)`; receta SQL (detector + DELETE) en README §Upgrading, NO ejecutada en `upgrade_recipe.spec` (una
   sola sentencia trivial; se puede añadir si el coordinador lo quiere ejecutable).
6. **B4 · sin capacidad nueva**: `listObjectsTruncation` ya significa «el driver señala el corte»; el deadline es la segunda
   causa de la misma señal (docblock). Alternativa descartada: `listObjectsDeadlineTruncation?:` (D15) — el consumidor no
   necesita distinguir la causa, y el par de capacidad no se puede juzgar en el runner sin dormir (el tope sí, contra `:8103`).
7. **B4 · reloj MONÓTONO inyectable (`monotonic`, SOLO TESTS)** en vez de medir con el reloj de pared `now`: doctrina 2E · H3
   (una ventana no se mide con un reloj que salta). Alternativa descartada: `withClock` como fuente del elapsed.
8. **B4 · señal conservadora**: una llamada lenta pero completa sale `truncated: true` (escrito en README). Alternativa
   descartada: ninguna que distinga «lento» de «cortado» sin señal del servidor.
9. **B4 · la columna `truncation` sondea SOLO `openfga`**; `database` = `na: exhaustive` (SQL sin LIMIT; `membersOf` CTE con
   el techo de recursión del motor ⇒ error, no página corta), manager = `na: passthrough`, doble = `na: double`. Alternativa
   descartada: sonda en el manager «devuelve `truncated` tal cual» (no hay guarda que quitar: sería un mutante artificial).
10. **B6 · harness SQL en `:memory:` con opt-out explícito y `requiresTransaction: false`**, porque `{ transaction }` por el
    manager exige pool ≥ 2 (medido/doctrina). La cara `true` sobre `sqlScopeOutbox` corre en `sqlite-file`/pg/mysql; en
    `:memory:` corre sobre el doble FULL con un `begin()` de mentira. Alternativa descartada: contrato que solo pase trx en los
    encolados directos y no por el manager (dejaría sin juzgar la vía real del consumidor).
11. **B6 · los arneses que encolan sin trx a propósito declaran `requireTransaction: false`** (77 casos) en vez de envolver cada
    encolado en una transacción. El hijo del runbook (consumidor) SÍ encola dentro de `db.transaction()`.
12. **B7 · el módulo nuevo vive en `src/relations_reconcile.ts`** (raíz de `src/`), no en `src/relations/` (regla 2 de pureza:
    ni `import type` del manager). El subpath público es `./relations/reconcile` como pide el juez. **No se mantiene** el export
    desde el comando (ruptura antes de la estable), y sí se pudo impedir sin romper el loader (el comando sigue siendo la clase
    por defecto): no hace falta «límite escrito».
13. **B8 · lectura del modelo fijado vía `client.readAuthorizationModel()` sin argumentos** (el SDK usa el id configurado):
    así es el MISMO id que cada `Write`/`Check` del driver. Alternativa descartada: pasar `this.modelId` explícito (equivalente;
    se prefiere la fuente única del cliente).
14. **`linajes.md` no se ha editado** (fuera de git, lo administra el coordinador). Texto propuesto: L5 gana la 5.ª iteración
    (B2, estructural: lista blanca única por nivel + gemelo roles; B5 como 6.ª —`.catch(() => undefined)`—); L8 gana la 5.ª y
    primera [N] (B4 ⇒ M8: columna `truncation`); L1 gana la 6.ª (B3: la gramática del userset como variante de F-05).

## 5 · Cifras (4 modos + 3 gates; medido EN SECUENCIA, `nvm use 22`, OpenFGA `:8090` reiniciado antes de cada suite)

| Qué | Resultado |
|---|---|
| `npm run build` (purity + typecheck + tsc + stubs) | ✔ exit 0 |
| `npm test` (`:memory:` + OpenFGA) | **1698 passed, 2 skipped (1700)**, exit 0 (partida 1673: **+25**) |
| `npm run test:sqlite-file` | **1726 passed, 2 skipped (1728)**, exit 0 (partida 1701: +25) |
| `npm run test:pg` | **1823 passed, 1 skipped (1824)**, exit 0 (partida 1798: +25) |
| `npm run test:mysql` | **1825 passed, 1 skipped (1826)**, exit 0 (partida 1800: +25) |
| `check:guard-mutants` (`:memory:`) | **111 / 111 muertos**, 0 vivos, 0 sin casar (97 s; línea base 171 casos) |
| `check:guard-mutants -- --db sqlite-file` | **111 / 111 muertos** (92 s) |
| `check:flag-mutants` | **36 / 36 muertos**, 0 vivos, 0 exenciones, 2 pendientes (`--allow-drop-deny` D, `--prune-undeclared` C) (48,5 s) |
| `TEST_DB=sqlite-file cutover-runbook` | **VERDE**: 20 pasos + 2 pendientes, exit 0 |
| `TEST_DB=pg cutover-runbook` | **VERDE**: 20 pasos + 2 pendientes, exit 0 (el hijo encola `detached` DENTRO de `db.transaction()`, B6) |
| Bases huérfanas (PG / MySQL) al terminar | 0 / 0 |
| Stores en `:8090` al terminar | 5, todos anteriores al lote (sept.: `api-cognitiv-*`, `adonisjs_app`); ninguno creado por estas corridas |

Desglose del **+25** (`:memory:`; el runner de relaciones corre la COMÚN en 6 harnesses): `relations.spec` **+8** (B1 ×4, B2 ×4);
`manager.spec` **+2** (B2 gemelo roles); `reconcile.spec` **+1** (B8, servidor real); `command_flags.spec` **+2** (B5 tabla, B7);
`relations_reconcile.spec` **+1** (B3 gemelo); `relations_openfga.spec` **+2** (B4, sin servidor); `scope_outbox_contract.spec`
**+3** (par `requiresTransaction` × 3 harnesses: 17 → 18 casos cada uno); `guard_surface.spec` **+6** (celdas `truncation` de openfga:
165 → 171). Los casos reescritos no suman (`scope_outbox.spec` «default» reescrito; `scope_depth` Limits ampliado; C5/C7.2
reapuntados). En pg/mysql el B8 cuenta igual (servidor real en los 4 modos). Rojos del ARNÉS corregidos en el spec, no en
`src/`: la aserción (ii) de B8 (`bea` tenía `docs:read` denegado por la siembra ⇒ se afirma sobre `ana`); el caso B7 buscaba
`@adonisjs/core/ace` en el TEXTO del módulo (lo cita el docblock) ⇒ se afirma sobre los `import … from`; el README decía
«never a mute partial list» dentro de la explicación de B4 ⇒ reformulado para que `notInclude` sea honesto.

## 6 · Lo que NO se hizo y por qué

- **Guardia de superficie para CONFIG (B2, L5)**: no existe una guardia por reflexión sobre los tipos `AuthorizationConfig` /
  `RelationsConfigSpec` (las listas blancas son a mano y un campo nuevo del tipo sin entrar en la lista sería un 422/500 falso,
  no un silencio — el fallo es ruidoso, en la dirección segura). Una guardia «toda clave del tipo está en la lista» exige
  reflexión sobre tipos (no hay en runtime) o un generador: fuera de lote.
- **Receta SQL de B3 no ejecutada en `upgrade_recipe.spec`** (decisión 5).
- **Caso de B4 contra el servidor real con deadline bajo** (`--listObjects-deadline=1ms` en un contenedor aparte): no se levantó
  otro OpenFGA; la causa se juzga con reloj inyectado (lo que pide el juez) y el tope sigue medido contra `:8103` en CI.
- **`listSubjects` con un userset ≠ group#member en SALIDA** no se filtra (es un hecho almacenado; filtrarlo sería esconder una
  fila que el operador tiene que borrar): declarado en README.
- **`check:guard-mutants -- --db sqlite-file`**: ver §5 (si no figura, no se corrió por tiempo; el de `:memory:` sí).

## Estado del árbol al cierre

```
$ git status --short
 M CHANGELOG.md
 M CLAUDE.md
 M README.md
 M commands/authz_relations_reconcile.ts
 M index.ts
 M package.json
 M src/define_config.ts
 M src/drivers/database_relations_driver.ts
 M src/drivers/openfga_driver.ts
 M src/drivers/openfga_relations_driver.ts
 M src/errors.ts
 M src/openfga.ts
 M src/relations/define_relations_config.ts
 M src/relations/manager.ts
 M src/relations_config_store.ts
 M src/scope_outbox.ts
 M src/testing/relations_contract.ts
 M src/testing/scope_outbox_contract.ts
 M src/types.ts
 M tests/command_flags.spec.ts
 M tests/fixtures/guard_manifest.ts
 M tests/fixtures/guard_mutants.json
 M tests/freeze.spec.ts
 M tests/guard_surface.spec.ts
 M tests/helpers/cutover_child.ts
 M tests/helpers/relay_child.ts
 M tests/manager.spec.ts
 M tests/reconcile.spec.ts
 M tests/relations.spec.ts
 M tests/relations_openfga.spec.ts
 M tests/relations_reconcile.spec.ts
 M tests/scope_depth.spec.ts
 M tests/scope_outbox.spec.ts
 M tests/scope_outbox_contract.spec.ts
 M tests/scope_outbox_harness.spec.ts
 M tests/scope_outbox_multiprocess.spec.ts
?? src/relations_reconcile.ts

$ git diff --stat
 CHANGELOG.md                             | 120 +++++++++++++++++++
 CLAUDE.md                                |  13 +-
 README.md                                |  90 +++++++++++---
 commands/authz_relations_reconcile.ts    | 182 +++++-----------------------
 index.ts                                 |   4 +-
 package.json                             |   1 +
 src/define_config.ts                     |  76 ++++++++++++
 src/drivers/database_relations_driver.ts |   5 +-
 src/drivers/openfga_driver.ts            |  29 ++++-
 src/drivers/openfga_relations_driver.ts  | 117 ++++++++++++++----
 src/errors.ts                            |  33 +++++
 src/openfga.ts                           |   2 +-
 src/relations/define_relations_config.ts | 147 +++++++++++++++++++++--
 src/relations/manager.ts                 |   6 +-
 src/relations_config_store.ts            |  10 +-
 src/scope_outbox.ts                      |  23 ++--
 src/testing/relations_contract.ts        |   5 +-
 src/testing/scope_outbox_contract.ts     | 200 +++++++++++++++++++++++--------
 src/types.ts                             |  10 +-
 tests/command_flags.spec.ts              | 138 +++++++++++++++++++--
 tests/fixtures/guard_manifest.ts         |  54 ++++++---
 tests/fixtures/guard_mutants.json        | 143 +++++++++++++++++++++-
 tests/freeze.spec.ts                     |   6 +-
 tests/guard_surface.spec.ts              | 102 +++++++++++++---
 tests/helpers/cutover_child.ts           |   4 +-
 tests/helpers/relay_child.ts             |   2 +-
 tests/manager.spec.ts                    |  66 ++++++++++
 tests/reconcile.spec.ts                  |  64 +++++++++-
 tests/relations.spec.ts                  | 117 ++++++++++++++++++
 tests/relations_openfga.spec.ts          |  80 +++++++++++++
 tests/relations_reconcile.spec.ts        |  35 ++++++
 tests/scope_depth.spec.ts                |   9 +-
 tests/scope_outbox.spec.ts               | 173 ++++++++++++++------------
 tests/scope_outbox_contract.spec.ts      |  26 +++-
 tests/scope_outbox_harness.spec.ts       |  18 ++-
 tests/scope_outbox_multiprocess.spec.ts  |   2 +-
 36 files changed, 1693 insertions(+), 419 deletions(-)
```
