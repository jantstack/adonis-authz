# Panel 2.5 — AUDITOR (adversarial) · relay/outbox: los cuatro cambios de COGNITIV

Fecha: 2026-09-09 · árbol `main` `5547fa4` (`2.4.0-alpha.4`) · solo lectura fuera de
`.claude/contexto/` y `.claude/reproducciones/`.

Medido contra **PostgreSQL 18** (`postgres18`) y el **OpenFGA `:8101`** real.
Reproducciones: `.claude/reproducciones/relay-auditor-{1,2,3,4,5}.ts`
(`TEST_DB=pg TEST_PG_URL=… OPENFGA_TEST_URL=http://127.0.0.1:8101 node --import @poppinss/ts-exec …`).

## Veredicto en una línea

**Inseguros tal cual los tres primeros** (1 `only`, 2 `requeue`/inline, 3 lease por lote): el
`only` produce **escalada cruzada medida contra el servidor real**, el `requeue` **revierte el
árbol** (medido) y el lease por lote quita el único limitador que hoy existe sobre el aparcado;
el 4 (`enumerateRelations`) es un **límite de coste real** cuya «mejora» por prefijo **no
funciona y falla en silencio** (medido); el 5 (profundidad) es **fail-closed y NO afecta a
otros tenants** (medido con control), pero el paquete deja construir el árbol que su propio PDP
no sabe decidir.

---

## Hallazgos (ordenados por severidad)

### 🔴 1 — `relayScopeChanges({ only })` mata el aplazamiento transitivo: escalada cruzada MEDIDA

- **Escenario**: precondición — cola con `#1 moved(unit → orgB)` (el tenant B compra la unit al
  tenant A) y `#2 attached(child, unit)`; ambas confirmadas en SQL. Acción — el consumidor hace
  el relay inline de «lo suyo»: `relayScopeChanges({ only: [2] })`. Resultado — el store recibe
  `child#parent@unit` mientras `unit#parent@orgA` sigue siendo la arista viva: **el editor de
  orgA autoriza sobre `child`, que en SQL cuelga de orgB**.
- **Evidencia**: ✅ medido contra el `:8101` (`relay-auditor-2.ts`):
  ```
  cola: 1:moved , 2:attached
  relay({ only: [2] }) ⇒ applied=attached deferred=0 failures=0 remaining=false
  FGA dice: authorize(A@orgA, docs:read, child) = true   ← A ya NO es dueño de nada de esto
  FGA dice: authorize(B@orgB, docs:read, child) = false  ← el dueño legítimo
  ```
  El motivo está en el código: **todo el orden del árbol lo sostiene que `pending()` devuelva la
  cola ENTERA ordenada por id** (`src/scope_outbox.ts:265`) y que el `blocked` se calcule sobre
  lo que la pasada VE (`src/manager.ts:1053`, colisión en `:1094`). Un `only` que filtre
  `pending()` deja el `blocked` vacío por construcción: no hay «aplazado», hay adelanto.
  Nótese además `remaining=false` y `deferred=0`: **el reporte sale en verde**.
- **Bonus medido**: `only: [1]` con un id AJENO (autoincremental, adivinable) aplicó el `moved`
  de otro tenant y **devolvió su cambio completo en el reporte** (uuids de scope; con `actor` en
  la fila, también el sujeto). O sea: el `only` con ids ajenos no es escalada *por contenido*
  —el relay aplica lo que la plataforma ya aceptó— pero **sí lo es por ORDEN y por MOMENTO**: el
  atacante elige qué entrada ajena se aplica sola, fuera de su secuencia. Con el par
  `detached(#20)` / `attached(#21)` de un re-cuelgue ajeno, elegir `only:[21]` deja al otro
  tenant con el subárbol **desraizado** (invariante 1/9: no concede nada) hasta el próximo
  `authz:reconcile`: DoS dirigido.
- **Steelman del defensor**: «dos cambios que interactúan comparten scope y son del MISMO tenant,
  así que un tenant solo se rompe a sí mismo». → **No me convence**: (a) el caso medido es
  exactamente del mismo tenant y el que gana acceso es el OTRO; (b) los ids son
  autoincrementales y el `only` no tiene noción de dueño; (c) el propósito declarado del cambio
  («¿se aplicó lo mío?») empuja a relayar SIEMPRE un subconjunto, es decir a no aplicar nunca la
  cola en orden.
- **Mitigación mínima**: `only` no filtra `pending()`; filtra el REPORTE. Si hace falta acotar el
  trabajo, que sea un **prefijo** de la cola («aplica hasta mi id inclusive»), nunca un subconjunto.

### 🔴 2 — `authz:scopes:requeue --id` reaplica un cambio obsoleto y REVIERTE el árbol (medido)

- **Escenario**: precondición — `#1 moved(unit → orgB)` se aparca (store caído durante sus
  intentos); después `#2 moved(unit → orgC)` se aplica y SQL y store coinciden en orgC. Acción —
  el operador (o un endpoint) hace `requeue --id 1`. Resultado — el relay lo aplica por id, **sin
  mirar que ya hay un cambio posterior aplicado sobre la misma clave de scope**: el store vuelve
  a orgB, SQL sigue en orgC, **el tenant de orgB recupera acceso y hay UN solo padre, así que
  `assertOneParent` no lo delata**. Es el 🟠 4 de 3b-2h reintroducido por la puerta de servicio.
- **Evidencia**: ✅ medido (`relay-auditor-5.ts`):
  ```
  2) tras el segundo 'moved': el driver ha visto → moved unit → organization:0d18
  3) requeue de #1 (moved → organization:69f0)
     el driver ha visto → moved unit → 0d18 | moved unit → 69f0
  ⇒ REVERSIÓN: SQL dice 0d18 y el store 69f0.
  ```
  En el código no hay nada que lo impida: `#applyScopeChange` (`src/manager.ts:1503`) aplica el
  `change` tal cual y `reparent` (`src/drivers/openfga_driver.ts:1716`) sustituye la arista.
- **Sobre el bucle aparcar/requeue** que preguntas: **no hay bucle infinito** (re-aparca a los
  `maxAttempts`), pero cada ciclo de requeue vuelve a **contaminar la clave** en cada pasada
  (`src/manager.ts:1111`), así que un requeue automatizado de lo `dead` es un **grifo de
  aplazamiento permanente** sobre ese scope: los cambios NUEVOS de ese tenant se aplazan una y
  otra vez mientras el cron reintenta lo irreparable.
- **Steelman**: «requeue es de plataforma, lo lanza un humano que sabe lo que hace». → **A medias**:
  el humano no puede saber, con la información que da el comando, si hubo un cambio posterior
  sobre la misma clave — el reporte de `dead` no lo dice. Y COGNITIV pide justamente exponerlo
  («lo escribirán ellos; mejor en el paquete»), que en su `app/` acaba en un endpoint.
- **Mitigación mínima**: `requeue` rechaza (o exige `--force` con el diff impreso) si existe una
  entrada APLICADA con id mayor que comparta clave de scope; y nunca por HTTP.

### 🔴 3 — La «mejora» de `enumerateRelations` con `Read` por PREFIJO devuelve vacío EN SILENCIO

- **Escenario**: precondición — store con tuplas `document:unit|<uuid>|<obj>`. Acción — se
  «optimiza» `enumerateRelations` con `Read({ object: 'document:unit|<uuid>|' })`. Resultado —
  **0 tuplas, sin error**: la enumeración de origen de `authz:reconcile` se queda vacía (una
  migración que no copia nada y lo llama éxito) y una purga por partición «demuestra cero» sin
  haber borrado nada.
- **Evidencia**: ✅ medido contra el `:8101`
  (scratchpad `prefix.mjs`): `object exacto → [tupla]`, `object prefijo → []`,
  `object prefijo sin | → []`, `object solo tipo → validation_error`, `tipo+user → [tupla]`.
  OpenFGA **no hace prefix-match**: o id exacto, o tipo + `user` obligatorio. Por eso el driver
  hace `Read({})` (`src/drivers/openfga_relations_driver.ts:614`) y lo dice en el docblock.
- **Steelman**: «lo probaremos antes de subirlo». → Sí, pero el modo de fallo es **silencioso y en
  el ORIGEN de una migración**, que es la peor combinación posible; merece quedar escrito.
- **Mitigación mínima**: si se optimiza, la ruta alternativa tiene que **fallar ruidosa** cuando no
  puede enumerar exhaustivamente (nunca devolver menos sin decirlo).

### 🟠 4 — El presupuesto `maxAttempts` de MI entrada lo gasta el TRÁFICO de otro, y lo aparcado deja de ordenar

- **Escenario**: precondición — store caído unos segundos; en la cola, `#1 moved(unitV → orgV2)`
  del tenant víctima y `#2 attached(child, unitV)` suyo también. Acción — otro tenant hace 5
  escrituras de árbol seguidas con **relay inline** (la receta del README): cada pasada procesa la
  cola entera, reintenta `#1` (que va primero) y le gasta un intento. Resultado — `#1` **aparcada
  en 5 peticiones ajenas**; al volver el store, `#2` se aplica **sin su dependencia** y el árbol
  del store se queda con el padre VIEJO de forma permanente.
- **Evidencia**: ✅ medido (`relay-auditor-1.ts`):
  ```
  [A] petición 1..5 del tenant atacante → intentos de la entrada AJENA (moved): 1,2,3,4,5
  [A] entradas APARCADAS tras 5 peticiones del atacante: 1 (moved)
  [B] tras recuperarse el store, aplicados: attached
  [B] ¿el attached del hijo se aplicó sin su moved?: SÍ — árbol del store: child→unit→orgV1 (el VIEJO), permanente
  ```
  Código: `pending()` esconde lo aparcado (`src/scope_outbox.ts:264`), y `dead` **solo se
  reporta**, no siembra `blocked` (`src/manager.ts:1011` + `:1053`). `markFailed` cuenta el
  intento **sea cual sea la causa** (`src/manager.ts:1110`), incluido un 503 del backend que no
  tiene nada que ver con esa entrada.
- Lo que COGNITIV vio («`maxAttempts: 5` está dimensionado para job, no para relay inline») es la
  mitad: con cron son 5 × periodo de **tiempo**; con relay inline son 5 **peticiones de
  cualquiera**. Lo que no vieron es que **el aparcado de una entrada es un evento de otro tenant**
  y que aparcar = dejar de ordenar.
- **Steelman**: «aparcar en vez de taponar fue una decisión medida (3b-2h 🔴 2) y el comando sale
  ≠ 0 mientras haya `dead`». → **Convence para el caso irreparable, no para éste**: aquí la causa
  es transitoria y ajena, el `exit ≠ 0` no existe en el camino inline (nadie mira el reporte de
  una petición HTTP), y la consecuencia no es «un nodo divergente» sino **desorden aplicado**.
- **Mitigación mínima**: no contar intento cuando el error es un 503 del backend (misma causa para
  todos ⇒ es la caída, no la entrada) y sembrar `blocked` con las claves de `dead()` — el tapón
  queda acotado a la CLAVE, que es justo la diferencia con el 🔴 2 de 3b-2h.

### 🟠 5 — `{ organization }` es INDECIDIBLE para `detached`, que es la operación que RETIRA

- **Escenario**: la outbox no sabe de tenants; filtrar por subárbol exige resolver cada entrada
  con el árbol del CONSUMIDOR en el momento del relay. Pero `scopes.detached` soporta —y
  documenta (3F · S1, invariante 17)— que **la fila ya no exista**: por eso el manager hace
  `chain ? [chain[0]] : scopeSpellings(child)` (`src/manager.ts:926`). En el relay esa entrada
  **no pertenece a ninguna organización**: o se excluye siempre (sus hechos **no se purgan
  nunca** ⇒ los grants del scope borrado siguen concediendo: fail-open permanente) o se incluye
  siempre (cualquiera relaya el `detached` de cualquiera).
- Y para `moved`: la cadena de HOY da el padre **NUEVO**, así que la entrada se atribuye al
  destino. Un tenant que relaya «lo mío» aplica los `moved` que traen cosas HACIA él y deja sin
  aplicar los que las sacan — exactamente el sesgo que conserva accesos.
- Un `resolveChain` desactualizado (réplica de lectura, caché) o mentiroso mueve la frontera en
  las dos direcciones: se relaya lo ajeno o se deja lo propio para siempre.
- **Evidencia**: ✅ código (`src/manager.ts:924-936`, invariante 17 de CLAUDE.md) — 🟡 la variante
  «réplica desfasada» es razonamiento, no medida.
- **Steelman**: «guardamos el `organization` en una columna al ENCOLAR y no resolvemos nada en el
  relay». → **Eso sí me convence**, y es la única forma que veo de que el filtro sea sano: la
  atribución se decide donde está la información (al encolar, con la sesión), no al relevar. Pero
  entonces sigue en pie el 🔴 1: **filtrar `pending()` por tenant reordena igual**, porque las
  dependencias cruzan tenants (la org que la plataforma cuelga de `app`, el `moved` del padre).
- **Mitigación mínima**: si se hace, `organization` viene de la SESIÓN y se guarda en la fila al
  encolar (invariante 15: `within` nunca del cuerpo), y **solo filtra el reporte**.

### 🟠 6 — El lease por LOTE quita el único limitador de aparcado que hay hoy

- **Escenario**: hoy `acquire()` sostiene el lease toda la pasada (`src/scope_outbox.ts:305`), así
  que **10 relays inline simultáneos consumen UN intento**: nueve responden `busy` sin tocar la
  cola. Con lease por lote entran los diez.
- **Evidencia**: ✅ medido (`relay-auditor-1.ts`):
  `[C] 10 relays CONCURRENTES (lease por pasada): busy=9 · intentos consumidos=1`.
  Con lease por lote serían 10 ⇒ **aparcado (5) en una sola ráfaga**, y con eso el 🟠 4 pasa de
  «5 peticiones seguidas» a «una ráfaga concurrente».
- **Y el entrelazado que pides**: lo intenté y **no conseguí reordenar solo con el lease por
  lote** mientras `pending()` siga sin filtro y ordenado por id — el bloqueador que falla queda
  pendiente y ordena ANTES que sus dependientes, así que el relay B lo reintenta primero. El
  orden por clave **sobrevive a un lease por lote** con dos condiciones: (i) el lease cubre
  **leer el lote, aplicarlo y marcarlo** (si se suelta entre leer y aplicar, es literalmente el
  🟠 4 medido de 3b-2h: dos pasadas sobre el mismo lote y árbol REVERTIDO con un solo padre); y
  (ii) nada esconde entradas de `pending()` — o sea, **el lease por lote es incompatible con el
  cambio 1 tal como lo piden**, porque el único guardián del orden entre lotes es la cola entera
  en orden de id. Lo que sí se pierde siempre es que el `blocked`/`parked` de una pasada deja de
  valer entre lotes (es estado en memoria de UN proceso, `src/manager.ts:1053`).
- **Steelman**: «así bajamos el pool, que es lo que nos duele». → El precio está escrito en
  `acquire()` («una conexión ocupada mientras dura la pasada, que es el precio de que dos pasadas
  no se pisen»). Bajar el lease no es la única forma de bajar el pool: acotar `limit` por pasada
  deja el lease corto sin tocar la exclusión.
- **Mitigación mínima**: si se hace, lease = `pending` + aplicar + `markApplied` del lote, y un
  intento por entrada y ventana de tiempo (no por pasada).

### 🟡 7 — El reporte del relay es global: enumeración entre tenants por la puerta del «resultado por entrada»

- **Escenario**: el relay inline devuelve `applied`/`deferred`/`failures`/`dead` de TODA la cola,
  con ids autoincrementales, tipos y uuids de scope, `actor` y el `lastError` (2000 caracteres del
  mensaje del backend). Si el consumidor devuelve el reporte en la respuesta —que es justo lo que
  pide el cambio 1—, cada petición de escritura de árbol de un tenant es una lectura del
  movimiento de árbol de todos.
- **Evidencia**: ✅ medido (`relay-auditor-2.ts` imprime el `change` completo de otro tenant desde
  el reporte); código: `src/manager.ts:1126-1136`.
- **Steelman**: «el consumidor no devuelve el reporte al usuario». → Hoy no; el cambio pedido
  existe para poder mirarlo en la petición. Vale como aviso, no como bloqueo.
- **Mitigación mínima**: si se añade `only`, que el REPORTE sí quede filtrado a lo pedido (y `dead`
  se resuma a un contador).

### 🟡 8 — `enumerateRelations` O(store): coste lineal medido, amplificable por tenant

- **Evidencia**: ✅ medido contra el `:8101` (`relay-auditor-3.ts`), partición con 3 tuplas:
  `~0 ajenas → 4 ms` · `~2.000 → 55 ms` · `~6.000 → 214 ms`. Lineal y con la constante mala
  (páginas de 100, `MAX_READ_PAGES = 10.000` ⇒ techo de 1M tuplas). Extrapolando, **1M de tuplas
  ≈ 35 s por operación**, y es una operación **por tenant** (purga de partición, su reconcile de
  llaves): N tenants × store entero. No es fail-open, es DoS de coste y presión sobre el store
  compartido.
- **Steelman**: «lo anotamos como límite declarado». → Vale como límite si además se acota el
  gatillo: hoy nada impide que un tenant lo dispare en bucle.
- **Mitigación mínima**: que la operación no sea disparable por petición de tenant (cola/cron), o
  un índice propio del consumidor; **nunca** el prefijo (🔴 3).

### 🟡 9 — El relay es escritor ÚNICO y su coste por entrada crece con la profundidad del árbol del vecino

- **Escenario**: aplicar UNA arista cuesta O(profundidad) lecturas (`assertEdge` + `storeChain`,
  `src/drivers/openfga_driver.ts:1747`). Un tenant con árbol profundo encarece **la cola de
  todos**, y la cola es la que cierra la ventana fail-open del `moved`/`detached`.
- **Evidencia**: ✅ medido (`relay-auditor-4.ts`): un `attached` cuesta **8,3 ms a profundidad 1**,
  **28 ms a 10**, **35,7 ms a 22**, **48,3 ms a 34**. ×5,8 de amplificación con un árbol que el
  producto permite crear.
- **Steelman**: «el lag ya está declarado como riesgo 🟠 aceptado». → Sí, pero el declarado es
  «segundos»; esto dice que el vecino elige cuántos.
- **Mitigación mínima**: cota de profundidad al crear el scope (ver 🟡 10), que ataja las dos.

### 🟡 10 — Profundidad: el paquete deja construir el árbol que su propio PDP no sabe decidir (self-DoS permanente)

- **Escenario**: un tenant encadena scopes bajo su org (feature de producto). Acción — 34 niveles.
  Resultado — **todas las escrituras de árbol se aceptan** (paquete y store) y meses después el
  `authorize` de ese subárbol es un **503 permanente** en el camino caliente.
- **Evidencia**: ✅ medido contra el `:8101` (`relay-auditor-3.ts` y `-4.ts`): profundidad
  1..**23 ⇒ `true`**; **24 ⇒ 503 `E_AUTHZ_BACKEND_UNAVAILABLE`**; 25/30/34 ⇒ 503. Fail-closed,
  invariante 5 respetado. `FACTS_MAX_RESOLVE_DEPTH = 22` (`src/drivers/openfga_facts.ts:205`) es
  conservador respecto al punto de rotura real (24), como dice su docblock.
- **¿Afecta a otros?** ✅ **No, medido con control** (`relay-auditor-4.ts`): vecino poco profundo
  en reposo **2,7 ms**; con 8 clientes martilleando una cadena de **1 nivel: 4,4 ms**; con 8
  clientes sobre una cadena de **22 niveles: 3,9 ms** ⇒ amplificación atribuible a la profundidad
  **×0,88**, o sea ninguna: la degradación es la concurrencia, no el `resolve-node-limit`. **No
  hay presupuesto global** observable ni DoS del `:8101` por cadenas profundas. Y `authz:reconcile`
  no hace `Check` (`src/reconcile.ts`), así que una cadena profunda tampoco tumba la pasada de
  plataforma.
- **Steelman**: «es fail-closed y está en CLAUDE.md; lo bajaron ellos». → Convence en cuanto a
  severidad (por eso 🟡, no 🟠), no en cuanto a que baste con documentarlo: el 503 aparece lejos
  del sitio donde se creó el problema y el árbol ya no se puede «desprofundizar» sin mover datos.
- **Mitigación mínima**: 422 al crear el nivel que pasa del techo del driver (o aviso al 80 %, que
  ya existe para el modelo con `FACTS_MODEL_WARN_RATIO`), además de la tabla del README.

---

## Lo que intenté y NO se rompió

- **Cruzar particiones con un id de objeto de relación** (`|`, `:`, `#`, espacios): cerrado.
  `COMPONENT_FORMAT = /^[a-z0-9_.-]+$/` (`src/identity.ts:92`) rige tipo y uuid de scope y el
  `object.id` (`assertRelationId`, `src/identity.ts:198`), y se aplica en el manager
  (`src/relations/manager.ts:315`) **y** en el driver antes de componer
  (`src/drivers/openfga_relations_driver.ts:308`, R-16). El parseo desde la derecha
  (`lastIndexOf('|')`) es consistente con la escritura. No encontré camino.
- **Reordenar con un lease por LOTE sin tocar `pending()`**: no lo conseguí (ver 🟠 6). Mientras
  la cola entera salga en orden de id, el bloqueador siempre precede a su dependiente.
- **Dos pasadas simultáneas hoy**: el lease aguanta — 10 relays concurrentes, `busy=9`, un solo
  intento consumido, un solo `attached` en el driver.
- **Aplazamiento transitivo dentro de una pasada sin filtrar**: aguanta, también en el segundo
  eslabón (lo vi en `tests/scope_outbox.spec.ts` y lo reproduje: `deferred=1` en cada una de las
  5 pasadas mientras el bloqueador era reintentable).
- **Cadenas profundas como DoS del `:8101` para vecinos**: no existe (control medido, ×0,88).
- **Que una cadena profunda rompa `authz:reconcile`**: no; reconcile no evalúa `Check`.

## Condición para que cada cambio sea seguro

1. **`only` / resultado por entrada** — *se hace SOLO si*: (a) `enqueue` devuelve id/clave (eso es
   inocuo y resuelve su problema real); (b) `only`/`organization` **no filtran `pending()`**: la
   pasada sigue viendo la cola entera en orden de id y el filtro se aplica al REPORTE; (c) si de
   verdad hace falta acotar el TRABAJO, la primitiva es un **prefijo** («aplica hasta el id N
   inclusive», que conserva el orden), jamás un subconjunto; (d) `remaining` y `dead` nunca se
   filtran. Sin (b)+(c): **no se hace** — está medida la escalada cruzada.
2. **Relay inline + `maxAttempts` + `requeue`** — *se hace SOLO si*: (a) un 503 del backend **no
   consume intento** (o el aparcado pasa a ser por tiempo/backoff con `next_attempt_at`, que es lo
   que de verdad quieren); (b) las claves de `dead()` **siembran `blocked`** en cada pasada (tapón
   por CLAVE, no por cola); (c) `requeue` se niega —o exige `--force` con el diff— si hay una
   entrada aplicada posterior que comparta clave de scope; (d) `requeue` y `relayScopeChanges`
   siguen siendo API de plataforma: **no se exponen por HTTP** (se saltan `requireActor`/
   `requireWithin` a propósito, como `driver()` y `prune-orphans`), y un `only` que venga del
   cuerpo de la petición es policy en una API sin policy. Sin (c)+(d): **no se hace**.
3. **Lease por LOTE** — *se hace SOLO si*: (a) el lease cubre `pending` + aplicar + `markApplied`
   del lote entero (soltarlo entre leer y aplicar es el 🟠 4 medido de 3b-2h); (b) el consumo de
   intentos se limita por entrada y ventana de tiempo, no por pasada (hoy el lease por pasada es
   el único limitador, medido); (c) **no se combina con el cambio 1**: sin la cola entera en orden
   de id no queda nadie guardando el orden entre lotes. Si lo que duele es el pool, la salida
   barata es `limit` por pasada, no soltar el lease.
4. **`enumerateRelations`** — el límite se declara y **no se optimiza con `Read` por prefijo**
   (medido: devuelve vacío sin error). Cualquier alternativa tiene que fallar ruidosa si no puede
   enumerar exhaustivamente, porque es el ORIGEN de una migración. Y el gatillo no debería estar
   en el camino de una petición de tenant.
5. **Profundidad 22** — al README sí, pero con una barrera: 422 al crear el nivel que pasa del
   techo que el driver declara (o aviso al 80 %). Hoy el paquete acepta construir un árbol que su
   propio PDP no puede decidir, y encima encarece la cola compartida del relay (🟡 9).

## Preguntas abiertas para el arquitecto (solo las que cambian el veredicto)

1. ¿`only`/`organization` van a llegar desde el **cuerpo de la petición**? Si sí, el cambio 1 es
   policy dentro de una API que se salta `requireWithin` a propósito, y el veredicto es «no se
   hace» sin discusión de diseño.
2. ¿El relay inline sigue siendo la receta RECOMENDADA del README? Si sí, el aparcado por conteo
   de pasadas (🟠 4) hay que cambiarlo antes que nada de lo demás: es el único hallazgo que ya
   está vivo en producción de COGNITIV hoy, sin ninguno de los cuatro cambios.
3. ¿Se acepta que `requeue` compare contra la última entrada aplicada de la misma clave? Si no
   hay comparación, la reversión medida (🔴 2) es el comportamiento, no el bug.
