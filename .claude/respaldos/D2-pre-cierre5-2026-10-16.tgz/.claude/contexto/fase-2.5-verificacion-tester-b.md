# Fase 2.5 · Lote B — verificación del tester de contrato

> Worktree aislado sobre `1ce0817` («Fase 2.5 lote B», HEAD de `v2/fase-0`; el worktree nació en
> otra rama y se hizo `checkout --detach 1ce0817`). Node 22.23.2, `npm ci` limpio.
> Motores: PostgreSQL 18 (`postgres18`, `TEST_PG_URL` con la contraseña del contenedor),
> MySQL 8.4 (`mysql84`), OpenFGA `:8101`, tope 3 en `openfga-tiny-tester2` `:8123`
> (**creado y borrado**; el `openfga-tiny` de CI y el `:8113` del auditor no se tocaron).
> Todos los mutantes se revirtieron (`git checkout <fichero>`); el árbol quedó limpio salvo el parche.
> Base de la verificación anterior: `fase-2.5-verificacion-tester.md`.

---

## 1. Suites (estado de partida, `1ce0817` sin parche)

| Configuración | sin OpenFGA | con `:8101` | tope 3 (`:8123`) | esperado |
|---|---|---|---|---|
| `npm test` (SQLite memoria) | **350** ✅ | **442** ✅ | **442** ✅ | 350 / 442 |
| `npm run test:sqlite-file` | **352** ✅ | **444** ✅ | — | 352 / 444 |
| `npm run test:pg` (PG 18) | **425** ✅ | **587** ✅ | — | 425 / 587 |
| `npm run test:mysql` (MySQL 8.4) | **425** ✅ | **587** ✅ | — | 425 / 587 |

**Los ocho conteos coinciden exactamente con el informe.** `npm run build` (purity + typecheck + tsc +
stubs) y `npm run typecheck` verdes. Sin skip, sin only.

**Residuos: 0** en los tres frentes, medidos tras las ~35 ejecuciones de esta sesión (incluidas las que
fallaron por un mutante):

- PostgreSQL: `select … from pg_database where datname like 'authz%'` ⇒ 0 filas.
- MySQL: `show databases like 'authz%'` ⇒ 0 filas.
- `/tmp/authz-sqlite-*` ⇒ 0 directorios.
- Stores de FGA en `:8101`: 60, **ninguno de la suite** (`auditv4-*`, `auditor-n1-*`, `atk-*`, `phantom-*`,
  `steal-*`, `api-loco-base`: scripts a mano del auditor y del otro proyecto). El `deleteCreatedStores`
  de `contract.spec` limpia lo suyo. En el `:8123` de tope 3, 0 stores al terminar.

⚪ Nota de DX: `npm run test:pg` **sin** `TEST_PG_URL` usa el default `postgres://postgres:postgres@…`
y muere con una traza cruda de `pg-protocol` (`Parser.handlePacket`), no con un mensaje sobre
credenciales. Me costó un falso positivo; el `CLAUDE.md` ya avisa, pero el arranque podría diagnosticarlo.

## 2. El juez

`contract_harness.spec` **ejecutado** (6 casos, verde): **36** core / **49** en `'2.0'` / **66** en `'2.1'`
con `listDenies: true`, **70** con `injectableClock: true`, y sin `listDenies` la aserción es
`withIt.length - needIt.length + 1` = 66 − 7 + 1 = **60** ✅.

⚪ El 60 es *derivado*, no literal: si mañana cambian a la vez los casos que necesitan `listDenies` y el
total de 2.1, la aserción sigue pasando y el número documentado deja de ser cierto. Un
`assert.lengthOf(without, 60)` extra cuesta una línea.

Registros del juez por motor (verificados por qué muere y qué no, ver §3):

| Harness | sqlite | sqlite-file | pg | mysql |
|---|---|---|---|---|
| `database` | ✅ | ✅ | ✅ | ✅ |
| `database (sin listDenies)` | ✅ | ✅ | ✅ | ✅ |
| `database (árbol SQL)` | — | — | ✅ | ✅ |
| `openfga` / `openfga (sin…)` (con `:8101`) | ✅ | ✅ | ✅ | ✅ |
| `openfga (árbol SQL)` | — | — | ✅ | ✅ |

### 2.1 «¿el caso del alias corre en SQLite por sus dos ramas?» — **No, y el informe lo dice de forma ambigua**

El caso `un alias del uuid del scope … jamás evade un deny` se registra en `'2.1'`, así que **corre en
todos los harness**, pero tiene dos ramas mutuamente excluyentes según `await tree.chainOf(alias) !== null`:

- rama **desconocido** (`known === false`): SQLite, sqlite-file **y MySQL**. El alias sin guiones (32 hex)
  no casa con `char(36)`; el alias por mayúsculas ya murió en la gramática. Solo se afirma «nada concede».
- rama **canónico** (`known === true`): **solo PostgreSQL** (tipo `uuid` nativo, que funde `bbbb…` con
  `bbbb-…`). Es la rama que contiene las aserciones que demuestran K1: el grant/revoke sobre el alias
  queda bajo la forma canónica.

Comprobado empíricamente, no por lectura: el mutante K1c (quitar `canonicalScope` de `revoke`) mata la
aserción de conducta `revoke sobre el alias quita el hecho canónico` **solo en PG**.

El informe (§3.6) dice «El caso del alias corre en todos los harness (memoria incluida) afirmando “nunca
`true`” **por las dos ramas**». Se lee como si cada harness ejercitase ambas. **Corregir la frase**: cada
harness ejercita la rama que le toca, y la rama que prueba la corrección de K1 solo existe en PG.

### 2.2 `level: '2.0'`/`'2.1'` de terceros con el puerto renombrado

El CHANGELOG **sí documenta el breaking**, y bien: `[Unreleased] — 2.1.0` → «Lot 2.5-B», primer bullet
`**BREAKING — the tree resolver answers the canonical chain, and uuids are lowercase**`, con problema →
decisión → «Not done», nombrando `ScopeChainResolver`, `config.scopes.resolveChain`, `withChainResolver`,
`hierarchicalScopeResolver({ nodeOf })`, `chainOf`/`resolveChainFrom` y la gramática en minúsculas.
Un harness de tercero escrito para 2.0/2.1 **no compila** (que es la desviación #2 del informe, y es la
decisión correcta: mejor que responder cadenas sin el nodo canónico en silencio). `CLAUDE.md` recoge el
invariante 17. Sin objeciones aquí.

## 3. Mutantes por pieza (siempre en `src/` salvo donde se indica)

Cada mutante se aplicó, se corrió el motor indicado, se anotó el fallo **literal** y se revirtió.
«VIVE» = la suite pasó entera con el defecto reintroducido.

| Pieza | Mutante | sqlite | sqlite-file | pg | mysql | Quién lo mata |
|---|---|---|---|---|---|---|
| **K1a** | `resolveChain` devuelve `[scope, ...chain.slice(1)]` (el llamante fija la identidad) | VIVE (350) | n/e¹ | **MUERE** 424/425; con `:8101` 585/587 (**database y openfga**, árbol SQL) | **VIVE (425)** | contract «alias», rama canónica |
| **K1b** | `assertIdentity` admite mayúsculas en uuids | **MUERE** 346/350 (4) | n/e | n/e | **MUERE** 419/425 (6) | contract J3 + «alias» |
| **K1a+K1b** | los dos a la vez | — | — | — | **MUERE** (6) en la aserción 422, **nunca llega a mostrar el bypass** | — |
| **K1c** | `canonicalOrSelf` devuelve `scope` en `revoke`/`removeDeny` (ambos drivers) | **MUERE** (spies) | n/e | **MUERE** (conducta + spies) | **MUERE** (spies) | contract «alias» (PG) + `spies.spec` |
| **K1d** | `#assertEdge` sin canonizar el hijo | **MUERE solo por conteo** | n/e | idem | idem | ❌ ninguna aserción de conducta → **parche** |
| **K1e** | `resolveChain` deja de validar que `chain[0]` sea el scope pedido | **VIVE (350)** | n/e | **VIVE (425)** | n/e | ❌ **nada** → **parche** |
| **K1e′** | `resolveChain` deja de rechazar la cadena vacía | **VIVE (350)** | n/e | n/e | n/e | ❌ **nada** → **parche** |
| **K1e″** | la comparación de `chain[0]` pasa a `===` (estricta) | VIVE² | — | — | — | ❌ nada → **parche** (inverso) |
| **K2** | `sqlExpiryCodec` devuelve siempre `identityCodec` (el driver vuelve a depender de la conexión) | n/a³ | n/a | n/a | **MUERE** 423/425 (2) | `expiry_timezone.spec` |
| **K2b** | el importador de openfga lee `a.expires_at` sin `expiry.select(...)` | — | — | — | **MUERE** 585/588 (3, con `:8101`) | guard del propio codec |
| **K3** | `comparablePrimaryKey` sin `CAST(?? AS text)` | n/a³ | n/a | **MUERE** 423/425 (2) | n/a | `authz_scopes_trait.spec` |
| **K4** | `refreshAssignment` ignora el conteo del UPDATE | **MUERE** (1) | n/e | n/e | **MUERE** (1) | `database_driver.spec`; **J4(b) NO lo mata** |
| **K5** | `created_at: this.now()` en vez de `systemClock()` | n/e | n/e | n/e | **MUERE** (2) | contract «2040» |
| **K6** | `withAuthzScopes({ clock })` ignora el reloj | **MUERE** (1) | n/e | n/e | n/e | `authz_scopes_trait.spec` |
| **K9** | un `context` por check en vez de por operación | **MUERE** (1) | n/e | n/e | n/e | `openfga_driver.spec` (unitario, cliente falso) |
| **K11** | `stubs/migration.stub` sin `collate` en `authz_roles.scope_type` | **MUERE** (1, textual) | n/e | n/e | **MUERE** (2: textual + estructural) | `migration_stub.spec` |
| **K11′** | el **espejo** (`tests/helpers/schema.ts`) sin esa collation | VIVE (correcto) | n/e | VIVE (correcto) | **MUERE** (1, estructural) | guard K11 vía `information_schema` |
| **K12** | `isSqlDriverError` deja de reconocer el SQLSTATE de `pg` | n/e | n/e | **MUERE** (1) | n/e | `catalog_cache.spec` (36/36 en PG) |
| **K14** | receta del README: PG sin `ALTER COLUMN expires_at TYPE timestamptz(3)` | — | — | **MUERE** | — | `upgrade_recipe.spec` |
| **K14′** | receta del README: MySQL sin `MODIFY expires_at datetime(3)` | — | — | — | **MUERE** (el hijo revienta) | idem |
| **K14″** | receta del README: `holder_uuid` con `utf8mb4_0900_ai_ci` | — | — | — | **MUERE** | idem («byte a byte») |
| **K16** | `bootApp` de `sqlite-file` con `pool { min:1, max:1 }` | n/a | **MUERE** (2) | n/e | n/e | `pool_concurrency.spec` |

¹ n/e = no ejecutado (el mutante es equivalente a otro motor ya cubierto o el árbol es el mismo).
² el inverso: con `===`, la cadena canónica sin guiones —lo que devuelve el tipo `uuid` de PG— sería un 503.
³ n/a = el mutante es un no-op en ese motor (el código mutado solo se emite en el motor indicado).

**Fallos literales** (los que la spec pedía anotar):

- K1a · PG: `sin guiones: el deny se evade: expected true to be false`, en
  `[database (árbol SQL) · 2.1]` y en `[openfga (árbol SQL) · 2.1]`.
- K1b · MySQL: `AssertionError: debería haber rechazado` en J3 y en «alias», en los tres harness.
- K1c · PG: `sin guiones: revoke sobre el alias quita el hecho canónico: expected [ 'unit-editor' ] to deeply equal []`
  + `spies.spec: expected 2 to equal 3`.
- K1d · sqlite/pg: **solo** `spies.spec:311: expected 7 to equal 8`.
- K2 · MySQL: `leído desde TZ=Asia/Tokyo: expected {…} to deeply equal {…}` y
  `escrito en Asia/Tokyo: T no concede aquí: expected true to be false`.
- K2b · MySQL: `AuthorizationInternalError: expires_at llegó como Date en MySQL: la lectura tiene que pasar por ExpiryCodec.select(...)`.
- K3 · PG: `operator does not exist: uuid = character varying` (DatabaseError).
- K4 · sqlite/MySQL: `no había fila que refrescar: es una inserción: expected true to be false`.
- K5 · MySQL: `Incorrect datetime value: '2040-01-01 00:00:00.000' for column 'created_at' at row 1`.
- K6: `expected [ …(2) ] to deeply equal [ Array(1) ]`.
- K9: `batch 0: un solo current_time (llegaron …00.001Z, …00.002Z, …00.003Z, …00.000Z): expected 5 to equal 1`.
- K11 · MySQL: `scope_type (roles, assignments, denies): expected […(2)] to have a length of 3 but got 2`
  y `expected [ {…(7)}, … ] to deeply equal [ … ]`.
- K12 · PG: `update "authz_roles" … current transaction is aborted…: expected undefined to equal 503`.
- K14 · PG: `el esquema subido es el publicado: expected […] to deeply equal […]`;
  K14″ · MySQL: `byte a byte: USER-42 no es user-42: expected 1 to equal +0`.
- K16 · sqlite-file: `pool.max = 1: expected 1 to be at least 2` y
  `la lectura se quedó esperando la conexión de la transacción: expected { timeout: true } to not have nested property 'timeout'`.

## 4. Huecos

### 🔴 H1 — La validación de `resolveChain` que el invariante 17 promete **no tiene ningún test** (cerrado por el parche)

La spec K1 exige literalmente: *«Validación en `resolveChain`: `chain[0].type === scope.type` y
`chain[0].uuid` igual al pedido ignorando mayúsculas y guiones — si no ⇒ 503 `E_AUTHZ_RESOLVER_FAILED`»*,
y el `CLAUDE.md` la eleva a invariante 17. El código la implementa. **Ningún test la observa.**

Anular las dos guardas (elemento 0 ≠ scope pedido; cadena vacía) deja la suite **entera en verde** en
SQLite (350/350) y en PostgreSQL (425/425). El caso de `spies.spec` que parecía cubrirlo
(`un ancestro inválido devuelto por el resolutor es 503`) solo prueba respuestas **mal formadas**
(`{app,'X'}`, `'a|b'`, sin uuid, no-array), que ya morían en `assertScope` desde D13; ninguna es un
elemento 0 bien formado que sea *otro scope*. Consecuencia práctica: un resolutor de un consumidor que
devolviera la cadena del **padre** (un `off-by-one` trivial al migrar de `resolveAncestors` a
`resolveChain` — exactamente el error que el breaking invita a cometer) haría que **todos los hechos de
un scope se escribiesen y leyesen bajo la identidad de su padre**, en silencio, y la suite no lo vería.

Y no basta con probar la cara negativa: si la comparación se endureciera a `===`, la canonicalización por
guiones del tipo `uuid` de PG —el corazón de K1— pasaría a ser 503. Hay que fijar las dos caras.

**Cerrado** en el parche ampliando el caso de `spies.spec` (tres respuestas malas nuevas: `[]`, elemento 0
de otro tipo, elemento 0 del mismo tipo con otro uuid) más el inverso (elemento 0 = mismo id sin guiones
⇒ autoriza, no lanza). Verificado en los dos sentidos: los tres mutantes de arriba lo matan.

### 🟠 H2 — El anti-ciclo con la identidad canónica del hijo solo se observa por un **conteo de llamadas** (cerrado por el parche)

K1d (`#assertEdge` sin canonizar el hijo) mata exactamente una aserción en toda la suite y en los tres
motores: `spies.spec:311: expected 7 to equal 8`. Un conteo de llamadas no es la promesa; es su factura.
El agujero real —colgar `orgA` escrito sin guiones de su propio descendiente `unitA1` cierra el ciclo
`app ← orgA ← unitA1 ← orgA` y a partir de ahí un grant en `orgA` concede en la raíz— no lo afirma nadie.
`memoryScopeTree` compara byte a byte y no puede mostrarlo; `manager.spec` solo usa ese árbol.

**Cerrado** en el parche con un caso nuevo en `manager.scopes` sobre un resolutor que funde las dos formas
(como el tipo `uuid` de PG), sin depender de ningún motor: `attached`/`moved` con el alias del hijo ⇒ 422
`E_AUTHZ_SCOPE_CYCLE` y `calls === []`; más el inverso (una arista legítima escrita con el alias sí pasa,
para que el caso no sea «todo es un ciclo»). Verificado: mata K1d con
`attached: el alias del hijo desciende del padre: … expected undefined to equal 422`.

### 🟡 H3 — La cadena canónica (K1a) **no es observable en MySQL**

Con `resolveChain` devolviendo el scope del llamante, `npm run test:mysql` pasa **425/425**. La razón es
estructural: en MySQL `demo_scopes.uuid` es `char(36)`, que no funde el alias de 32 hex, y el alias por
mayúsculas ya muere en la gramática (K1b). El único motor donde la corrección de K1 es verificable es
PostgreSQL. Corolario: **quien revierta la cadena canónica y conserve la gramática tendrá la suite de
MySQL verde**. No es bloqueante (PG cubre la pieza en ambos drivers) pero el informe no debería sugerir
que MySQL lo prueba; y el bypass por `*_ci` de MySQL, que fue el hallazgo original del auditor, hoy
**nunca se observa como bypass**: incluso con las dos defensas anuladas el caso muere antes, en la
aserción del 422. Es defensa en profundidad correcta; solo hay que decirlo en el informe.

### 🟡 H4 — J4(b) **no** afirma sobre el `GrantOutcome` lo que la spec K4 pedía

La spec dice: *«caso J4(b) afirma sobre el `GrantOutcome` además de `listRoles`»*. El caso afirma
`outcome.expiresAt === later` (y el comentario dice «`existed: true` solo si de verdad refrescó una fila
que seguía ahí»), pero **no afirma `outcome.existed`**, y el mutante K4 sobrevive a J4(b): lo mata solo
`database_driver.spec` («si el UPDATE no toca ninguna fila…», con lectura fantasma, determinista, en los
tres motores). La cobertura es suficiente y del tipo correcto (un test determinista es mejor juez que una
carrera), pero la afirmación del informe sobre J4(b) es más fuerte de lo que el código sostiene. En J4(b)
`existed` **no** es asertable de forma determinista (la purga puede aterrizar antes o después): la
corrección es de redacción, no de test.

### 🟡 H5 — El README se contradice con la gramática nueva

`README.md:380` (§Operational notes, primer bullet, el que la spec mandaba reescribir por K1) sigue
diciendo:

> `holder_uuid` and `scope_uuid` hold whatever your grammar-valid id is (**`[A-Za-z0-9._-]`**, ≤ 36 chars)

La gramática es `[a-z0-9._-]{1,36}` desde este lote y un uuid con mayúsculas es 422
`E_AUTHZ_INVALID_IDENTITY` — lo afirma el propio juez tres párrafos más abajo del mismo README y el caso
J3 en los cuatro modos. Un consumidor que lea esa línea diseñará ids con mayúsculas y se los rechazará el
paquete. **Corrección de una línea.** No propongo test (un grep del README sería frágil); es doc.

### 🟡 H6 — La suite no es independiente del subconjunto: `manager.spec` importa de otro `.spec`

`tests/manager.spec.ts:656` hace `await import('./database_driver.spec.js')` para usar `withTableMissing`.
Correr `--files=manager` en solitario falla con un error en `database_driver.spec.ts:18` (el
`test.group` se registra con el runner ya en marcha). **Verificado en el HEAD limpio, sin mi parche**:
46 passed / 1 failed. La suite completa no se entera porque ambos ficheros se cargan en la colección.

Es higiene, no corrección, y es anterior a este lote — pero rompe la regla «nada de tests que dependan del
orden» y estorba justo cuando más falta hace (aislar un caso para depurar un mutante). Arreglo: mover
`withTableMissing` a `tests/helpers/`.

### ⚪ H7 — `contract_harness` no fija el 60 literal (§2). ⚪ H8 — el default de `TEST_PG_URL` (§1).

### Aserciones relajadas respecto a `e2cf8cd`: ninguna

Revisadas **todas** las líneas `-` con aserción de `git diff e2cf8cd..HEAD -- tests/ src/testing/`. Las
bajas son de tres clases y ninguna pierde cobertura:

1. **Renombres mecánicos** del puerto (`ancestorsOf` → `chainOf`, `resolveAncestors` → `resolveChain`,
   `parentOf` → `nodeOf`): misma aserción con otro nombre.
2. **Reescrituras que la spec ordena** (J3): `ORG-TENANT-A es OTRO scope` y `abc.def_42 es OTRO holder`
   desaparecen porque las mayúsculas ya no son identidad; el caso nuevo es **más fuerte** (13
   `rejectsWith` sobre lecturas y escrituras, holder y scope, + «nada de lo anterior tocó los hechos»).
   La propiedad que esas líneas defendían —que `authz_*` compara **byte a byte**— sigue observada, y lo
   comprobé con un mutante: poner `utf8mb4_0900_ai_ci` en la receta del README mata
   `upgrade_recipe.spec` con `byte a byte: USER-42 no es user-42: expected 1 to equal +0` (MySQL).
3. **Refuerzos**: el grep de collations de `migration_stub` pasa de 2 columnas a 3 (⚪4).

### `spies.spec` reescrito: los conteos nuevos **son** discriminantes

Probado, no leído: `resolveChain === 3` (línea 294) muere con K1c y `resolveChain === 8` (línea 311) con
K1d, en los tres motores. Los demás conteos son de las fases 2A/2D y quedan fuera de este lote.

### Promesas nuevas del README con test

| Promesa | Test que la fija | Mutante que lo demuestra |
|---|---|---|
| identidad canónica del resolutor (K1) | contract «alias» (PG) + `spies.spec` ampliado (parche) | K1a, K1c, K1e ✅ |
| uuids en minúsculas | contract J3 | K1b ✅ |
| `expires_at` UTC sin depender de `timezone`/`TZ` | `expiry_timezone.spec` (hijos UTC/Tokio/Caracas) | K2 ✅ |
| el importador lee igual | contract openfga en MySQL | K2b ✅ |
| el trait compara igual / PK casteada en PG | `authz_scopes_trait.spec` | K3, K6 ✅ |
| sellos `created_at` con reloj de sistema | contract «2040» | K5 ✅ |
| «nada más en `src/` lee la hora» | `clock.spec.ts` (grep, lista blanca solo `clock.ts` — **no se amplió** con K5) | ✅ |
| stub ≡ espejo (tipo/longitud/precisión/collation) | `migration_stub.spec` K11 | K11, K11′ ✅ |
| no tragarse errores SQL en `fn` | `catalog_cache.spec` K12 | K12 ✅ |
| receta 1.x→2.x ejecutable | `upgrade_recipe.spec` (lee los bloques ```sql del propio README) | K14, K14′, K14″ ✅ |
| cota `MAX_SCOPE_BOUND` | `manager.spec` | (no mutado; rojo anotado por el implementador) |
| `[A-Za-z0-9._-]` | ❌ **falso** (H5) | — |

### `CLAUDE.md` invariante 17

Redacción correcta y completa. Sus promesas y su cobertura tras el parche:

| Promesa del invariante 17 | Cobertura |
|---|---|
| `chain[0]` es la identidad de todos los hechos | ✅ contract «alias» (PG, ambos drivers) + `spies.spec` |
| elemento 0 ≠ scope pedido ⇒ 503 | ✅ **solo tras el parche** (antes ❌) |
| cadena vacía ⇒ 503 | ✅ **solo tras el parche** (antes ❌) |
| elemento mal formado ⇒ 503 | ✅ `spies.spec` (D13, previo) |
| uuids en minúsculas ⇒ 422 | ✅ contract J3 |
| ciclo de `scopes.attached/moved` con `chain[0]` | ✅ **solo tras el parche** (antes: un conteo) |

## 5. Parche

`/home/jose/proyectos/Personal/adonis-authz/.claude/contexto/tests-tester-fase-2.5b.patch`
(2 ficheros, +84 líneas, **solo `tests/`**; no toca `src/`, ni el juez, ni el harness, ni conteos del juez):

- `tests/manager.spec.ts` — caso nuevo en `manager.scopes`:
  *«el anti-ciclo usa la identidad CANÓNICA del hijo: un alias del uuid (guiones quitados, como el tipo
  uuid de PG) no cuela una arista que cierra el ciclo (2.5-B · K1)»*. Cierra **H2**.
- `tests/spies.spec.ts` — amplía *«un ancestro inválido devuelto por el resolutor es 503…»* con `[]`,
  elemento 0 de otro tipo, elemento 0 del mismo tipo con otro uuid, y el inverso (mismo id sin guiones ⇒
  autoriza). Cierra **H1**.

Conteos con el parche (todos verdes, `typecheck` verde, residuos 0):

| Configuración | sin OpenFGA | con `:8101` | tope 3 |
|---|---|---|---|
| `npm test` | 351 | 443 | 443 |
| `npm run test:sqlite-file` | 353 | 445 | — |
| `npm run test:pg` | 426 | 588 | — |
| `npm run test:mysql` | 426 | 588 | — |

## 6. Veredicto

# APTA CON CORRECCIONES

El lote B hace lo que dice: los ocho conteos son exactos, no hay residuos, no hay aserción relajada, y las
doce piezas más las cinco del tester tienen un mutante que las mata en el motor que corresponde —incluidas
las difíciles (K2 con procesos hijos reales en tres zonas, K11 por `information_schema`, K14 ejecutando el
README, K16 con una transacción abierta).  El breaking está documentado y el invariante 17 está escrito.

Lo que impide un APTA seco es que **el invariante 17 se escribió antes que su test**: las dos validaciones
que la spec K1 pide explícitamente (`chain[0]` es el scope pedido; cadena no vacía) no las observaba nada,
y el anti-ciclo canónico solo se veía en un contador de llamadas. Son exactamente el tipo de promesa que
un consumidor migrando de `resolveAncestors` a `resolveChain` va a romper por accidente.

Para cerrar la Fase 2.5:

1. **Aplicar el parche** (`git apply .claude/contexto/tests-tester-fase-2.5b.patch`) y actualizar los
   conteos del informe y del `CLAUDE.md` a 351/443, 353/445, 426/588, 426/588. — bloqueante.
2. **Corregir `README.md:380`**: `[A-Za-z0-9._-]` → `[a-z0-9._-]`. — bloqueante (documenta lo contrario
   de lo que el paquete hace).
3. **Corregir la redacción** del informe: §3.6 (el caso del alias no corre «por las dos ramas» en cada
   harness; la rama canónica solo existe en PG) y la fila K4 (J4(b) afirma la caducidad, no `existed`).
   — no bloqueante, pero el informe es lo que el dueño leerá dentro de seis meses.
4. Opcional: mover `withTableMissing` a `tests/helpers/` (H6), fijar el 60 literal (H7).

Nada de esto toca `src/`: el código del lote B es correcto en los cuatro modos y en los dos drivers.
