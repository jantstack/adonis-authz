# Lote B — cierre 2: decisiones del coordinador sobre `loteB-auditor-cierre.md` (re-ataque, 2026-10-15)

Verificación PROPIA del cierre 1: **1718 / 1746 / 1843 / 1845** (2/2/1/1 skipped), guard-mutants 112/112, flag-mutants 36/36,
runbook VERDE ×2 (cuadra con el informe del cierre). Re-ataque: 1 🟠 nuevo (N1), 3 🟡 (N2, N3, N4), 4 ⚪ (N5–N8); cerrados 🟠 1,
🟡 3, 🟡 4, 🟡 6, 🟡 7, ⚪ 9–14. Sin debilitamientos. TODO lo de abajo entra en este cierre.

## Respuesta a la pregunta del auditor (N1)
**Se RETIRA `Infinity`.** `listObjectsDeadlineMs` pasa a significar «el corte EFECTIVO del servidor», que es
`--listObjects-deadline` si ≠ 0 y, si es 0, `--request-timeout` (default 3 s; medido por el auditor en v1.19.0: con deadline 0 y
request-timeout 30 ms, 200 con 0 de 40 000 objetos). `Infinity`/`NaN`/≤ 0/no finito ⇒ 500 al construir, con la letra «el servidor
siempre corta en alguno de los dos; declara el menor». Los dos a 0 NO se soportan (límite declarado: el gateway HTTP no está medido);
la letra lo dice y no promete «sin deadline». Caso `relations_openfga.spec.ts:1626` reescrito (Infinity ⇒ 500). README §Upgrading 7,
fila Limits, docblock y CHANGELOG corregidos con la medición del auditor y la versión. **Cuatro líneas de cierre** (es L8).

## Lo que entra
| # | Qué exige el cierre | Nota del coordinador |
|---|---|---|
| 🟠 N1 | Lo de arriba. | La propiedad universal de M8 no admite una receta que produzca una lista muda. |
| 🟡 N2 | `classifySubject`: **forma del userset ANTES que la declaración F-05**, con o sin `toConfig`. Decisión 3 del cierre 1 rechazada tal como está. Caso: residuo con userset cuyo tipo/relación NO están en `toConfig` ⇒ `skipped.usersetUnsupported` + `details` + receta (nunca `undeclared`). Mutante: invertir el orden ⇒ rojo. | |
| 🟡 N3 | La línea «no pasaste --prune: repite con --prune» SOLO cuando no se pasó `--prune` Y el residuo es de los que `--prune` borra de verdad. Para `userset-unsupported` nunca. **Unificación (condición del auditor a la decisión 1): un residuo del DESTINO que ningún driver del paquete borra —`userset-unsupported` E `invalid-identity`— tiene la MISMA semántica en los dos: `extra` + `details` con `pruned: false`, exit ≠ 0 en los cuatro modos, receta en la línea, jamás «repite con --prune».** Tabla de verdad {motivo del residuo} × {prune} × {dry-run, real} ⇒ línea, exit. Casos existentes de `invalid-identity` que cambien de exit: listados y justificados (línea (c)). | «Una regla, no dos»: la fijé yo en el cierre 1 y el cierre 1 la cumplió a medias. |
| 🟡 N4 | Runner B3: tras el 422 por el driver DIRECTO, el runner afirma por `listSubjects` (y `check`) que NO quedó fila. Mutante «guarda la fila y después lanza» sobre el doble ⇒ el runner se pone rojo (medido). Decisión 8 del cierre 1 rechazada en su premisa. | |
| ⚪ N5 | `Array.isArray` en `readAssignment` (`openfga_driver.ts:1221`) y `#readTuple` (`openfga_relations_driver.ts:518`); grep del caso ampliado a `tuples\s*(\?\?|\?\.\[)`. | |
| ⚪ N6 | `readRelationsConfigSpec`: JSON persistido que no es objeto (`null`/`0`/`false`/`""`/`[]`) ⇒ 422 rama «NO valida»; solo la ausencia de fila es `null`. Caso. | |
| ⚪ N7 | `Array.isArray(holderTypes)` en la spec de relaciones ⇒ 422 (caso). Roles: línea de límite en el informe (`holderTypes`/`drivers` fallan después, al resolver). | |
| ⚪ N8 | Desglose de R-17: cuenta `usersetUnsupported` e `invalid` por su nombre; nunca «todas de tipos que el destino no declara» si no es verdad. Caso de letra. | |
| Dec. 4 | «exit propio» (CLAUDE.md punto 7): precisar en el punto 7: **exit propio = ≠ 0 y distinto del de éxito; la RAMA se identifica por un prefijo ESTABLE de la línea** (nombrarlo en el caso). No se inventan códigos de salida por rama. | Lo edita el implementador en CLAUDE.md punto 7 por orden del coordinador. |

## Reglas
Rojo → verde → mutante. Cuatro líneas para N1 y N3. CHANGELOG `[Unreleased]` («Closure 2 of lot B»). Verificación final 4 modos +
3 gates. Informe `loteB-informe-cierre2.md` (sección por hallazgo, tabla de verdad de N3, cifras, no hecho). Sin commit, sin
`version`, sin push.
