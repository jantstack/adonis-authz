# Sublote D1 — cierre 2 (corto): decisiones del coordinador sobre `loteD1-auditor-cierre.md` (2026-10-15)

Re-ataque: 🟠 1 cerrado en código (medido en `:8090`: repro original ⇒ F; anidado a dos niveles F/F; fila declarada de > 100
membresías exacta; `Write` único atómico). 🟡 2/3/4 cerrados. Sin debilitamientos. Queda lo de abajo; todo entra.

| # | Qué exige | Decisión |
|---|---|---|
| 🟡 N1 | Fila simétrica «allow TRANSPORTADO por grupo + deny DIRECTO» sin caso: el mutante «denies antes que membresías» concede (`DESPUÉS true`) y deja verdes los 5 casos del cierre. | Fila en la tabla de verdad para holder Y userset, caso nombrado, mutante `fga.purge.denies-before-memberships` muerto (medido). |
| ⚪ N2 | Linaje «purga multi-request: el estado intermedio concede»: 3 iteraciones (3b-2f R3, 3b-6 P1 🔴, D1 🟠 1). | **Estructural (M8):** los mutantes de orden de purga (`solo prefijo`, `membresías primero`, `troceado contiguo`, `sin Write único`, `denies antes que membresías`) entran en un CORREDOR publicado (`check:guard-mutants` o el que encaje), no solo por pieza. El coordinador registra el linaje en `linajes.md` (L10 propuesto al dueño). |
| ⚪ N3 | Servidor con `--max-tuples-per-write` < 100: el 1.er lote pequeño se aplica antes del 400, el docblock dice «503 sin borrar» (falso) y la purga nunca termina con un 503 que parece transitorio. | El 400 «too many tuples» del `Write` de la purga ⇒ **500 `E_AUTHZ_CONFIG`** con letra (tope del servidor < `RELATIONS_PURGE_WRITE_MAX`), marcado parcial si ya borró (`markPartialWrite`), docblock corregido, requisito «`--max-tuples-per-write` ≥ 100» en «Limits» atado a la constante. Sin opción nueva. Caso con un cliente falso que da ese 400 en el 2.º `Write`. |
| ⚪ N4 | D-31 mira la resta pero no el cierre `denied_X = this ∪ denied_P` (corte de camino): un modelo escrito a mano concede donde `database` niega. | La guarda D-31 compara la definición de `denied_<rel>` (y la de `<rel>`) con la que GENERA el paquete para ese tipo (igualdad estructural con `openFgaRelationsModel`/el generador), no solo la forma. Caso con el modelo mal cerrado ⇒ 500. |
| Dec. 1 | `E_AUTHZ_MEMBERS_DENY_LIMIT` 500. | Ratificada; una línea en el docblock/README: 500 y no 422 porque no es una pregunta inválida del llamante sino una cota del despliegue (precedente `E_AUTHZ_TOO_MANY_LOCAL_ROLES`). |

Reglas: rojo → verde → mutante; CHANGELOG `[Unreleased]` («Closure 2 of sublot D1»; bloques publicados intactos); verificación
4 modos + 3 gates. Informe `loteD1-informe-cierre2.md`. Sin commit, sin `version`, sin push.
